

# Generated at 2022-06-24 02:19:52.574295
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    data = """TEST=$HOME/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    fobj = io.StringIO(data)
    lines = fobj.readlines()

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-24 02:20:00.961786
# Unit test for function expand
def test_expand():
    with test.temp_file() as env_file:
        with open(env_file, 'w') as f:
            lines = [
                'TEST=/tmp/test',
                'TEST2=xx${TEST}yy',
                'TEST3=$TEST/test',
                'TEST4=$USER',
            ]
            f.write('\n'.join(lines))

        env = load_env_file(lines, write_environ=None)

        assert env == collections.OrderedDict([
            ('TEST', '/tmp/test'),
            ('TEST2', 'xx/tmp/testyy'),
            ('TEST3', '/tmp/test/test'),
            ('TEST4', os.environ.get('USER')),
        ])

# Generated at 2022-06-24 02:20:08.764740
# Unit test for function load_env_file
def test_load_env_file():
    from doppel import sysattrs
    from io import StringIO
    import os

    # Test the function in a small, known environment
    env = dict(
        A='a',
        B='b',
        C='c',
        D='d',
        E='e',
        HOME='/home',
        PATH='/path',
        X='x',
        Y='y',
    )

    # Capture stdout and stderr
    captured = sysattrs.capture_sysattrs(env=env)

    # Run the function with bad input
    with pytest.raises(TypeError):
        load_env_file(None)  # type: ignore

    # Set up an input file and the expected output

# Generated at 2022-06-24 02:20:15.616799
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'TEST=${HOME}/yeee-$PATH\n')
        f.write(b'THISIS=~/a/test\n')
        f.write(b'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
        f.flush()

        contents = list(load_env_file([line.strip() for line in f]))
        assert contents[0][1] == 'yeee-$PATH'
        assert contents[1][1] == 'a/test'
        assert contents[2][1] == 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:20:20.738279
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test'])
    assert isinstance(env, collections.OrderedDict)
    assert env['TEST'].endswith('/yeee')
    assert env['THISIS'].endswith('/a/test')



# Generated at 2022-06-24 02:20:25.783167
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:20:34.308672
# Unit test for function expand
def test_expand():
    assert os.path.join(os.getcwd(), 'test') == expand('./test')
    assert os.path.join(os.path.dirname(__file__), 'test') == expand('./test')  # Would fail if __file__ was a symlink
    assert os.path.join(os.getenv('HOME'), 'test') == expand('~/test')
    assert expand('$HOME/test') == os.path.join(os.getenv('HOME'), 'test')

# Generated at 2022-06-24 02:20:39.572986
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    pairs = list(parse_env_file_contents(lines))
    assert pairs == [('TEST', '${HOME}/yeee'),
                     ('THISIS', '~/a/test'),
                     ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    print("passed")



# Generated at 2022-06-24 02:20:48.469497
# Unit test for function expand

# Generated at 2022-06-24 02:20:53.984186
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = parse_env_file_contents(lines)

    assert isinstance(changes, types.GeneratorType)
    changes = list(changes)

    assert changes == [
        ('TEST', expand('${HOME}/yeee-$PATH')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]



# Generated at 2022-06-24 02:21:00.004782
# Unit test for function load_env_file
def test_load_env_file():
    # Arrange
    filename = "testdata/test1.txt"
    env = dict()

    # Act
    load_env_file(file_name=filename, write_environ=env)

    # Assert
    assert env["VAR1"] == "Hello World!"
    assert env["VAR2"] == "Double Quote"
    assert env["VAR3"] == "Single Quote"
    assert env["VAR4"] == "Backslash"
    assert env["VAR_NO_VALUE"] == ""
    assert env["VAR5"] == "name-value1"
    assert env["VAR6"] == "name-value2"
    assert env["VAR7"] == "name-value3"
    assert env["VAR8"] == "name-value4"

# Generated at 2022-06-24 02:21:04.123348
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee') == os.path.expanduser('~/yeee')
    assert expand('~/yeee') == os.path.expanduser('~/yeee')



# Generated at 2022-06-24 02:21:08.489447
# Unit test for function expand
def test_expand():
    os.environ["HOME"] = "/home/heggs"
    print("os.environ")
    print(os.environ)

    print("expand($HOME)")
    print(expand("$HOME"))

    print("expand(~)")
    print(expand("~"))

    print("expand(~heggs)")
    print(expand("~heggs"))

    print("expand(~/test)")
    print(expand("~/test"))



# Generated at 2022-06-24 02:21:13.573116
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('${HOME}/Desktop') == os.path.expanduser('~/Desktop')

# Generated at 2022-06-24 02:21:15.267222
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.run_docstring_examples(parse_env_file_contents, globals())

# Generated at 2022-06-24 02:21:24.871805
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    print(env)
    assert env['TEST'] == expand('${HOME}/yeee')
    assert env['THISIS'] == expand('~/a/test')
    assert env['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:21:35.000113
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ)
    assert write_environ['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-', ':'.join(os.getenv('PATH').split(':')))
    assert write_environ['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-24 02:21:40.641308
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:21:44.175639
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:21:50.170676
# Unit test for function expand
def test_expand():
    test_cases = [
        ("~/.viaa-scheduler", "..."),
        ("${HOME}/.viaa-scheduler", "..."),
        ("$HOME/.viaa-scheduler", "..."),
        (".../.viaa-scheduler/$PATH", ".../.viaa-scheduler/..."),
        (".../.viaa-scheduler/$UNKNOWN", ".../.viaa-scheduler/$UNKNOWN"),
    ]

    for test_case in test_cases:
        assert expand(test_case[0]) == test_case[1]

# Generated at 2022-06-24 02:22:01.297816
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THIS_IS=~/a/${MY_KEY}",
        "THISIS2=~/a/${MY_KEY}-andmore",
        "THISIS3=~/a/${MY_KEY}-andmore/andmore",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

    data = parse_env_file_contents(io.StringIO("\n".join(lines)))

    assert len(list(data)) == 5

    assert next(data) == ("TEST", os.path.expanduser("~") + "/yeee-" + os.environ["PATH"])

# Generated at 2022-06-24 02:22:03.439557
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import doctest
    (failures, total) = doctest.testmod(sys.modules[__name__])
    assert failures == 0


# Generated at 2022-06-24 02:22:04.277300
# Unit test for function expand
def test_expand():
    assert expand("/tmp") == "/tmp"



# Generated at 2022-06-24 02:22:10.851889
# Unit test for function expand
def test_expand():
    # Create a dictionary with some values
    environ = {
        "HOST": "localhost",
        "USER": "johndoe",
    }

    # Expand variables
    lines = [
        "DB_HOST = '$HOST'",
        "DB_USER = '$USER'",
        "DB_PASSWORD = ''",
        "DB_NAME = 'mydb'",
    ]

    # Get the dictionary of values
    values = load_env_file(lines, write_environ=environ)

    assert values['DB_HOST'] == environ['HOST']
    assert values['DB_USER'] == environ['USER']
    assert values['DB_PASSWORD'] == ''
    assert values['DB_NAME'] == 'mydb'

# Generated at 2022-06-24 02:22:20.008306
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = load_env_file(lines, write_environ=dict())

    assert result == {
        'TEST': expand('$HOME/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-24 02:22:29.909501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    cases = [
        (['TEST=${HOME}/yeee'], '.../yeee'),
        (['THISIS=~/a/test'], '.../a/test'),
        (['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    for lines, expected_res in cases:
        actual_res = list(parse_env_file_contents(lines))

        err_msg = 'load_env_file({}) failed with {} instead of expected {}'.format(lines, actual_res, expected_res)
        assert len(actual_res) == len(lines), err_msg

# Generated at 2022-06-24 02:22:36.822050
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:43.730209
# Unit test for function expand
def test_expand():
    from tempfile import mkdtemp
    from shutil import rmtree

    tmp_dir = mkdtemp()
    os.environ['TEST_ENV_DIR'] = tmp_dir

    assert expand('~/') == os.path.expanduser('~')
    assert expand('${TEST_ENV_DIR}/home') == os.path.expandvars('${TEST_ENV_DIR}') + '/home'

    rmtree(tmp_dir)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:22:55.500128
# Unit test for function expand
def test_expand():

    # Set up environ variables for testing
    os.environ.setdefault('HOME', '{}/dir/dir'.format(os.getcwd()))
    os.environ.setdefault('USER', 'someuser')
    os.environ.setdefault('PATH', '{}/dir'.format(os.getcwd()))

    # Testing expand function
    assert expand('${USER}/subdir') == 'someuser/subdir'
    assert expand('~/subdir') == '{}/dir/dir/subdir'.format(os.getcwd())
    assert expand('$PATH/subdir') == '{}/dir/subdir'.format(os.getcwd())
    assert expand('${HOME}') == '{}/dir/dir'.format(os.getcwd())
    assert expand('~')

# Generated at 2022-06-24 02:22:59.143944
# Unit test for function expand
def test_expand():
    assert '~/yolo' == expand('~/yolo')
    assert 'yolo/yolo' == expand('$HOME/yolo')
    assert '/yolo/yolo' == expand('$HOME/yolo')
    assert '~/yolo' == expand('~/yolo')



# Generated at 2022-06-24 02:23:07.903355
# Unit test for function load_env_file
def test_load_env_file():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee'])) == [('TEST', '${HOME}/yeee')]
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-24 02:23:12.647097
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Unit test for function parse_env_file_contents."""

    from collections import OrderedDict

    lines = (
        # Normal
        "TEST='${HOME}/yeee'",
        # Spaces
        'THIS_IS_A= "~/a/test" ',
        # Quotes
        'THAT_IS_A= "~/a/test with spaces" ',
        # No space
        'THISIS=YO',
        # No quotes
        "THISIS='YO'",
        # Quotes
        'THISIS="YO"',
    )

    results = list(parse_env_file_contents(lines))


# Generated at 2022-06-24 02:23:23.351436
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = io.StringIO("""TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""")

    changes = load_env_file(lines, write_environ=dict())

    expected_changes = collections.OrderedDict(
        [('TEST', '.../.../yeee-...:...'),
         ('THISIS', '.../a/test'),
         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    )

    assert changes == expected_changes



# Generated at 2022-06-24 02:23:25.622083
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~/test') == os.path.expanduser('~/test')



# Generated at 2022-06-24 02:23:30.127600
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')



# Generated at 2022-06-24 02:23:34.176198
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert os.environ['HOME'].strip('/') in load_env_file(lines)['TEST']

# Generated at 2022-06-24 02:23:41.012521
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:23:48.620075
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]) == [('TEST', expand('$HOME/yeee')), ('THISIS', expand('~/a/test')), (
        'YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]

# Generated at 2022-06-24 02:23:51.581536
# Unit test for function expand
def test_expand():
    result = '.../.../yeee-...:...'
    expected = expand('${HOME}/yeee-$PATH')
    assert expected == result

# Generated at 2022-06-24 02:24:02.813090
# Unit test for function load_env_file
def test_load_env_file():
    d1 = {
        "PATH": os.environ["PATH"],
        "HOME": os.environ["HOME"],
    }

    d2 = load_env_file(["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])

    assert "TEST" in d2 and "THISIS" in d2 and "YOLO" in d2

    assert d2["TEST"] == f"{d1['HOME']}/yeee-{d1['PATH']}"
    assert d2["THISIS"] == f"{d1['HOME']}/a/test"

# Generated at 2022-06-24 02:24:05.826073
# Unit test for function expand
def test_expand():
    val = '$HOME'
    res = expand(val)
    assert res == os.environ['HOME']



# Generated at 2022-06-24 02:24:10.773681
# Unit test for function expand
def test_expand():
    cwd = os.getcwd()
    home = os.path.expanduser(os.getenv('HOME'))

    assert expand('~') == home
    assert expand('~/') == home + '/'
    assert expand('${HOME}') == home
    assert expand('${HOME}/') == home + '/'
    assert expand('${PWD}') == cwd
    assert expand('${PWD}/') == cwd + '/'

# Generated at 2022-06-24 02:24:18.175228
# Unit test for function expand
def test_expand():
    assert expand("~/yeee") == os.path.expanduser("~/yeee")
    assert expand("${HOME}/yeee") == os.path.expandvars("${HOME}/yeee")
    assert expand("~/yeee-${HOME}") == os.path.expandvars(os.path.expanduser("~/yeee-${HOME}"))



# Generated at 2022-06-24 02:24:27.893690
# Unit test for function expand
def test_expand():
    """
    >>> test_expand()
    """
    def check_variable(name, value):
        assert os.environ[name] == value
        assert expand("$" + name) == value
        assert expand("${" + name + "}") == value
        assert expand("$" + name + "X") == value + "X"
        assert expand("${" + name + "}X") == value + "X"
        assert expand("X$" + name) == "X" + value
        assert expand("X${" + name + "}") == "X" + value
        assert expand("X$" + name + "Y") == "X" + value + "Y"
        assert expand("X${" + name + "}Y") == "X" + value + "Y"


# Generated at 2022-06-24 02:24:38.394074
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("~/") == os.path.expanduser("~/")
    assert expand("~/home") == os.path.expanduser("~/home")
    assert expand("~/home/") == os.path.expanduser("~/home/")
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("$HOME/") == os.path.expandvars("$HOME/")
    assert expand("$HOME/home") == os.path.expandvars("$HOME/home")
    assert expand("$HOME/home/") == os.path.expandvars("$HOME/home/")



# Generated at 2022-06-24 02:24:46.204494
# Unit test for function expand
def test_expand():

    env = {}

    for key, val in [('EXPAND_ME', '${HOME}/yeee'), ('HOME', '/home/username')]:
        env[key] = val

    assert expand('${EXPAND_ME}') == '/home/username/yeee'

    assert expand('${EXPAND_ME}/force') == '/home/username/yeee/force'

    assert expand('${EXPAND_ME}force') == '/home/username/yeeeforce'

# Generated at 2022-06-24 02:24:52.261865
# Unit test for function expand
def test_expand():
    test_data = {
        "~/foo/bar": os.path.expanduser("~") + "/foo/bar",
        "~/foo/$PATH": os.path.expanduser("~") + "/foo/" + os.environ['PATH'],
        "~/foo/$NONE": os.path.expanduser("~") + "/foo/$NONE"
    }

    for e in test_data:
        assert expand(e) == test_data[e]


# Unit tests for functions parse_env_file_contents and load_env_file

# Generated at 2022-06-24 02:25:04.363107
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ_orig = os.environ.copy()

    initial_environ = {
        'TEST': 'hello world',
        'THISIS': 'hello world',
        'YOLO': 'hello world',
    }

# Generated at 2022-06-24 02:25:07.415562
# Unit test for function expand
def test_expand():
    test_string = '~/hello/${USER}/hi'
    correct_string = os.path.expanduser('~/hello/' + os.getenv('USER') + '/hi')
    assert expand(test_string) == correct_string

# Generated at 2022-06-24 02:25:13.835901
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import os
    from pprint import pprint

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    pprint(
        load_env_file(
            lines,
            write_environ=os.environ,
        )
    )



# Generated at 2022-06-24 02:25:22.709419
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Given
    lines = [
        "TEST_A=a",
        "TEST_B=b",
        "TEST_C=c",
        "TEST_D=d",
        "TEST_E=e",
        "TEST_F=f",
    ]

    # When
    result = parse_env_file_contents(lines)

    # Then
    assert isinstance(result, collections.abc.Generator)
    assert list(result) == [
        ("TEST_A", "a"),
        ("TEST_B", "b"),
        ("TEST_C", "c"),
        ("TEST_D", "d"),
        ("TEST_E", "e"),
        ("TEST_F", "f"),
    ]

# Generated at 2022-06-24 02:25:28.325801
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME/test') == os.path.expanduser(os.path.expandvars('$HOME/test'))
    assert expand('${HOME}/test') == os.path.expanduser(os.path.expandvars('${HOME}/test'))
    assert expand('${HOME}/${HOME}/test') == os.path.expanduser(
        os.path.expandvars('${HOME}/${HOME}/test'))



# Generated at 2022-06-24 02:25:37.498993
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import operator

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    k, v = next(parse_env_file_contents(lines))
    assert k == 'TEST'
    assert v == '${HOME}/yeee-$PATH'

    results = list(parse_env_file_contents(lines))
    assert len(results) == 3
    assert results[0] == ('TEST', '${HOME}/yeee-$PATH')
    assert results[1] == ('THISIS', '~/a/test')

# Generated at 2022-06-24 02:25:41.254121
# Unit test for function expand
def test_expand():
    os.environ['TEST_VAR'] = 'testing'
    assert expand('$TEST_VAR') == 'testing'

    home = os.path.expanduser('~')
    assert expand('~') == home
    assert expand('$HOME') == home

    assert expand('~/hello') == os.path.join(expand('~'), 'hello')



# Generated at 2022-06-24 02:25:48.808435
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(results) == expected



# Generated at 2022-06-24 02:25:55.686718
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = load_env_file(lines, write_environ=dict())

    assert output == collections.OrderedDict([('TEST', '.../yeee'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
                                              ])

# Generated at 2022-06-24 02:25:58.325922
# Unit test for function expand
def test_expand():
    v = expand('$HOME/yeee')
    assert v

    v = expand('~/a/test')
    assert v

    v = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert v



# Generated at 2022-06-24 02:26:08.645342
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import pathlib
    sys.path.append(str(pathlib.Path(__file__).parent))

    # Load the test data from the test_data.txt file
    test_data_file = pathlib.Path(__file__).parent / 'test_data.txt'
    with test_data_file.open() as f:
        lines = f.readlines()

    # Load the env file and store the result
    result = load_env_file(lines)

    # Compare the result to what we expect
    # If something doesn't match, raise an error

# Generated at 2022-06-24 02:26:13.933955
# Unit test for function expand
def test_expand():
    path = expand('./${HOME}/~$PATH/')
    assert path == os.path.expanduser(os.path.join('~', '~$PATH'))


if __name__ == '__main__':
    print(load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=None))

# Generated at 2022-06-24 02:26:21.274633
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['PATH=$PATH:/usr/local/bin', 'HOME=/home/johndoe']
    load_env_file(lines)

    assert os.environ['PATH'] == os.getenv('PATH') + ':/usr/local/bin'
    assert os.environ['HOME'] == '/home/johndoe'



# Generated at 2022-06-24 02:26:31.697963
# Unit test for function load_env_file
def test_load_env_file():
    #
    # first test with empty list of envs
    #
    lines = []
    envs = load_env_file(lines)
    assert len(envs) == 0, "no envs should be set"

    #
    # next test with list of envs
    #
    lines = ['TEST=value1', 'TEST2=value2']
    envs = load_env_file(lines)
    assert len(envs) == 2, "2 envs should be set"
    assert envs['TEST'] == 'value1', "env 'Test' should be set to 'value1'"
    assert envs['TEST2'] == 'value2', "env 'Test2' should be set to 'value2'"

    #
    # next test with list of envs with trailing comments
    #

# Generated at 2022-06-24 02:26:38.616893
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    assert True

# Generated at 2022-06-24 02:26:48.116374
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import subprocess

    # Strip non-portable environ vars from test
    strip = [
        'TMPDIR', 'TEMP', 'TMP', 'COMSPEC', 'PROMPT', 'PATHEXT',
        'SYSTEMROOT', 'SystemDrive', 'PROGRAMFILES', 'PROGRAMFILES(x86)',
        'ProgramData', 'COMPUTERNAME', 'USERPROFILE', 'HOMEPATH',
        'USERNAME', 'SESSIONNAME', 'APPDATA', 'LOCALAPPDATA', 'PUBLIC',
        'WINDIR',
    ]

    env = dict(os.environ)
    for key in strip:
        env.pop(key, None)


# Generated at 2022-06-24 02:26:52.162948
# Unit test for function expand
def test_expand():
    assert expand('~/') == expand('${HOME}/')



# Generated at 2022-06-24 02:26:56.802660
# Unit test for function expand
def test_expand():
    path = '~/test'
    assert expand(path) == os.path.expanduser(path)
    assert expand(path) != '~/test'

    path = 'test'
    assert expand(path) == path

    # Test expand with a variable
    os.environ['TEST_VAR'] = 'test'
    path = '${TEST_VAR}'
    assert expand(path) == 'test'



# Generated at 2022-06-24 02:26:58.428169
# Unit test for function expand
def test_expand():
    home_dir = os.path.expanduser("~")
    assert expand("~/") == home_dir + "/"



# Generated at 2022-06-24 02:27:09.745839
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:27:19.764876
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_lines = parse_env_file_contents(lines)

    res = collections.OrderedDict()
    for k, v in parsed_lines:
        res[k] = v

    assert res == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-24 02:27:21.689438
# Unit test for function expand
def test_expand():
    assert os.path.abspath(expand('~/')) == os.path.expanduser('~/')
    assert os.path.abspath(expand('${HOME}/')) == os.path.expandvars('${HOME}/')

# Generated at 2022-06-24 02:27:29.281994
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    var_map = load_env_file(lines, write_environ=dict())

    assert var_map['TEST']
    assert var_map['THISIS']
    assert var_map['YOLO']

# Generated at 2022-06-24 02:27:37.163045
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass

# Generated at 2022-06-24 02:27:40.492211
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/swaggins') == os.environ['HOME'] + '/swaggins'



# Generated at 2022-06-24 02:27:44.097538
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), "env")

    with open(filename) as f:
        lines = f.readlines()

    result = load_env_file(lines=lines, write_environ=dict())
    expected = {'TEST': os.path.expanduser('~/yeee'),
                'THISIS': os.path.expanduser('~/a/test')}

    assert result == expected

# Generated at 2022-06-24 02:27:55.428850
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_cases = [
        (
            ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
            collections.OrderedDict([
                ('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
            ])
        )
    ]

    for lines, expected_results in test_cases:
        results = parse_env_file_contents(lines)
        results = collections.OrderedDict(results)

        assert results == expected_results



# Generated at 2022-06-24 02:28:00.581647
# Unit test for function load_env_file
def test_load_env_file():
    contents = ['FOO=/test/path', 'BAZ=$FOO/bar']

    # Write to os.environ (dynamic)
    load_env_file(contents)

    assert os.environ['FOO'] == '/test/path'
    assert os.environ['BAZ'] == '/test/path/bar'

    # Write to dict (static)
    env = {}
    load_env_file(contents, env)

    assert env['FOO'] == '/test/path'
    assert env['BAZ'] == '/test/path/bar'



# Generated at 2022-06-24 02:28:05.079471
# Unit test for function expand
def test_expand():
    assert expand("$PATH") == os.environ["PATH"]
    assert expand("~/") == os.path.expanduser("~/")



# Generated at 2022-06-24 02:28:10.113800
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:28:22.595707
# Unit test for function load_env_file
def test_load_env_file():
    def assert_same_dicts(d1, d2):
        assert type(d1) == type(d2)
        assert d1 == d2

    with os.popen('env') as env_output:
        lines = [line for line in env_output.readlines() if line.strip() != '']

    env_dict_1 = os.environ.copy()

    loaded_env_dict = load_env_file(lines)
    env_dict_2 = os.environ.copy()

    assert_same_dicts(env_dict_1, loaded_env_dict)
    assert_same_dicts(env_dict_1, env_dict_2)


if __name__ == '__main__':
    import doctest

    print('Testing `expand`')
    doctest.testmod()

# Generated at 2022-06-24 02:28:27.258655
# Unit test for function load_env_file
def test_load_env_file():
    if __name__ == "__main__":
        import doctest
        doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:28:33.125855
# Unit test for function load_env_file
def test_load_env_file():
    from pytest import raises
    from contextlib import redirect_stdout
    from io import StringIO

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:28:42.485811
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    if os.name == "nt":
        match = re.match(r"([a-zA-Z]):", os.environ['HOME'])
        if match:
            newhome = "{}$".format(match.group(1))
            lines = [s.replace(os.environ['HOME'], newhome) for s in lines]

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:28:50.714711
# Unit test for function expand
def test_expand():
    test_env = dict(HOME="/a/home/path", PATH="/a/path/to/somewhere/else")
    with mock.patch.dict(os.environ, test_env):
        assert expand("${HOME}") == "/a/home/path"
        assert expand("~") == os.path.expanduser("~")
        assert expand("~/some_path") == os.path.expanduser("~") + "/some_path"
        assert expand("${PATH}") == "/a/path/to/somewhere/else"



# Generated at 2022-06-24 02:29:02.980824
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict())[
        'TEST'] == f"{os.environ['HOME']}/yeee-{os.environ['PATH']}"
    assert load_env_file(lines, write_environ=dict())['THISIS'] == f"{os.environ['HOME']}/a/test"

# Generated at 2022-06-24 02:29:09.996393
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        """
        Test class for load_env_file
        """

        def test_expand(self):
            """
            Tests that expanding "${HOME}" and "~" works.
            """
            v = expand('${HOME}/yeee-$PATH')
            self.assertTrue('yeee-' in v)

            v = expand('~/a/test')
            self.assertTrue('a/test' in v)

            v = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
            self.assertTrue('swaggins' in v)



# Generated at 2022-06-24 02:29:11.993159
# Unit test for function expand
def test_expand():
    assert expand('~/test') == '{}/test'.format(os.getenv('HOME'))



# Generated at 2022-06-24 02:29:16.676467
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:29:21.533704
# Unit test for function expand
def test_expand():
    assert expand("~/a/test") == os.path.expanduser("~/a/test")
    assert expand("${HOME}/a/test") == os.path.expanduser("~/a/test")
    assert expand("${HOME}/a/test") == os.path.expandvars("${HOME}/a/test")



# Generated at 2022-06-24 02:29:26.602500
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')  # nosec
    assert expand('/home') == '/home'  # nosec
    assert expand('${HOME}') == os.path.expandvars('${HOME}')  # nosec



# Generated at 2022-06-24 02:29:32.530199
# Unit test for function load_env_file
def test_load_env_file():
    for lines, environ in (
        (['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO2=~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}'], {}),
    ):
        # Fake os.environ
        os.environ['HOME'] = '...'
        os.environ['PATH'] = '...:...'

        changes = load_env_file(lines)

        for k, v in changes.items():
            assert isinstance(k, str)
            assert isinstance(v, str)
            assert k in lines

        assert os.environ == environ

# Generated at 2022-06-24 02:29:37.982578
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:29:42.914841
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile() as env_file:
        env_file.write(b'TEST=${HOME}/yeee-$PATH\n')
        env_file.write(b'THISIS=~/a/test\n')
        env_file.write(b'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')

        env_file.flush()

        changes = load_env_file(env_file.readlines(), write_environ=os.environ)

        assert changes['TEST'] == os.path.join(os.environ['HOME'], 'yeee-' + os.environ['PATH'])