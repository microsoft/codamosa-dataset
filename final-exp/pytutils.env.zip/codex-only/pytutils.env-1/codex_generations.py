

# Generated at 2022-06-24 02:19:44.542918
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)
    results = collections.OrderedDict(results)

    expected_results = {
        "TEST": "...",
        "THISIS": "...",
        "YOLO": "...",
    }

    for key, value in results.items():
        correct_value = expected_results[key]

        assert value[:len(correct_value)] == correct_value, value



# Generated at 2022-06-24 02:19:53.562458
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Given
    given = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

    # When
    actual = parse_env_file_contents(given)

    # Then
    assert list(actual) == expected



# Generated at 2022-06-24 02:19:55.188298
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:19:59.214278
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    assert changes.keys() == ['TEST', 'THISIS', 'YOLO']

# Generated at 2022-06-24 02:20:06.607906
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    output = {
        "TEST": "${HOME}/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    }

    for key, val in parse_env_file_contents(lines):
        assert output[key] == val



# Generated at 2022-06-24 02:20:09.948714
# Unit test for function expand
def test_expand():
    assert expand('~/swaggins') == os.path.expanduser('~/swaggins')
    assert expand('$PATH') == os.path.expandvars('$PATH')


# Generated at 2022-06-24 02:20:19.730440
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = ('TEST=${HOME}/yeee-$PATH\n', 'THISIS=~/a/test\n', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')

    test_vars = load_env_file(lines, write_environ=dict())

    assert 'TEST' in test_vars
    assert 'THISIS' in test_vars
    assert 'YOLO' in test_vars

    with io.StringIO() as env_file:

        env_file.writelines(lines)
        env_file.seek(0)

        test_vars = load_env_file(env_file, write_environ=dict())

        assert 'TEST' in test_vars

# Generated at 2022-06-24 02:20:24.044692
# Unit test for function expand
def test_expand():
    os.environ = dict()
    path = os.path.abspath(os.path.expanduser('~/Documents/svn'))
    os.environ['SVN_PATH'] = path
    assert expand('${SVN_PATH}') == path



# Generated at 2022-06-24 02:20:34.809264
# Unit test for function load_env_file
def test_load_env_file():
    # Test function load_env_file
    # Test case in docstring

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = {}
    load_env_file(lines, write_environ=environ)

    assert environ['TEST'].endswith('/yeee')
    assert environ['THISIS'].endswith('/a/test')
    assert environ['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:20:39.274790
# Unit test for function expand
def test_expand():
    # Expandable strings
    assert expand('$PATH') == os.environ['PATH']
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~/test') == os.path.join(os.environ['HOME'], 'test')

    # Non-expandable strings
    assert expand('$DOESNOTEXIST') == '$DOESNOTEXIST'
    assert expand('~/doesnotexist/') == '~/doesnotexist/'



# Generated at 2022-06-24 02:20:50.450295
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(["TEST=123", "TEST2='123'", 'TEST3="123"'])
    assert os.environ["TEST"] == "123"
    assert os.environ["TEST2"] == "123"
    assert os.environ["TEST3"] == "123"

    load_env_file(["TEST=123", "TEST2='123'", 'TEST3="123"'])
    os.environ["TEST"] = "abc"
    del os.environ["TEST2"]
    os.environ["TEST3"] = "abc"
    load_env_file(["TEST=123", "TEST2='123'", 'TEST3="123"'])
    assert os.environ["TEST"] == "123"
    assert os.environ

# Generated at 2022-06-24 02:20:52.258453
# Unit test for function load_env_file
def test_load_env_file():
    with open('test.env') as f:
        lines = f.read().splitlines()

    load_env_file(lines)



# Generated at 2022-06-24 02:20:54.915016
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:21:01.580894
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = load_env_file(lines, write_environ=dict())

    assert data['TEST'].startswith('/home/')
    assert data['TEST'].endswith('/yeee-')
    assert data['THISIS'].startswith('/home/')
    assert data['YOLO'].startswith('/home/')
    assert 'NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in data['YOLO']
    assert 'PATH' in data['TEST']



# Generated at 2022-06-24 02:21:04.568281
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:21:07.031444
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:21:09.659453
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tests.helpers

    data = tests.helpers.get_test_data('env-format-2')

    result = parse_env_file_contents(data)

    assert len(list(result)) == 73



# Generated at 2022-06-24 02:21:13.501610
# Unit test for function load_env_file
def test_load_env_file():
    print(load_env_file(['TEST=$PATH:/A/B/C:/D/E/F', 'TEST_R=${HOME}/test-${PATH}']))



# Generated at 2022-06-24 02:21:19.697743
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict(
        [('TEST', f'{os.getenv("HOME")}/yeee'),
         ('THISIS', f'{os.getenv("HOME")}/a/test'),
         ('YOLO', f'{os.getenv("HOME")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:21:29.421451
# Unit test for function load_env_file
def test_load_env_file():
    import pathlib

    here = pathlib.Path(__file__).parent.absolute()

    # load_env_file()
    lines = """
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    test_load_env_file_lines = load_env_file(lines.splitlines())

    assert test_load_env_file_lines.keys() == ["TEST", "THISIS", "YOLO"]

    # load_env_file()

# Generated at 2022-06-24 02:21:36.735091
# Unit test for function load_env_file
def test_load_env_file():
    from pprint import pprint

    lines = 'TEST=${HOME}/yeee-$PATH THISIS=~/a/test YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.split()

    changes = load_env_file(lines, write_environ=dict())

    pprint(changes)

# Generated at 2022-06-24 02:21:49.641291
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class LoadEnvFile(unittest.TestCase):
        def test_load_env_file_1(self):
            test = """
                foo=bar
                FOO=baz
                bar=baz
                """

            result = load_env_file(test.splitlines())

            expected = collections.OrderedDict([
                ('foo', 'bar'),
                ('FOO', 'baz'),
                ('bar', 'baz')
            ])

            self.assertEqual(expected, result)

        def test_load_env_file_2(self):
            test = """
                foo=bar
                FOO=baz
                bar=baz
                """

            result = load_env_file(test.splitlines(), write_environ=dict())

            expected = collections.Ord

# Generated at 2022-06-24 02:21:56.596078
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_lines = parse_env_file_contents(lines)

    for k, v in parsed_lines:
        assert '$' not in v



# Generated at 2022-06-24 02:22:04.971097
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert isinstance(result, collections.OrderedDict)
    assert result.get('TEST').startswith(expand('${HOME}'))
    assert result.get('TEST').endswith('yeee')
    assert result.get('THISIS').startswith(expand('~'))
    assert result.get('THISIS').endswith('a/test')
    assert result.get('YOLO').startswith(expand('~'))
    assert result.get('YOLO').end

# Generated at 2022-06-24 02:22:17.172002
# Unit test for function load_env_file
def test_load_env_file():
    # Test for case with no ${}
    # Equivalent to:
    #   $ cat .env/test.env.no_expansion
    #   TEST=teststring
    #   $ TEST=teststring python -c "import os; print(os.environ['TEST'])"
    #   teststring
    lines = ['TEST=teststring']
    write_environ = dict()
    changes = load_env_file(lines, write_environ=write_environ)
    assert changes['TEST'] == 'teststring'
    assert write_environ['TEST'] == 'teststring'

    # Test for case with ${}
    # Equivalent to:
    #   $ cat .env/test.env
    #   TEST=${HOME}/yeee-$PATH
    #   THISIS=~/a/

# Generated at 2022-06-24 02:22:24.568692
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expanduser('~')
    assert expand('$HOME') == expand('${HOME}')
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~')



# Generated at 2022-06-24 02:22:29.219445
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == {
        'TEST': expand('${HOME}/yeee'), 'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }



# Generated at 2022-06-24 02:22:34.209529
# Unit test for function expand
def test_expand():
    assert expand('~/a/b') == os.path.expanduser('~/a/b')

    assert expand('${PATH}/abc') == os.path.expandvars('${PATH}/abc')

# Generated at 2022-06-24 02:22:39.802825
# Unit test for function expand
def test_expand():
    assert expand("~/yolo") == expand("$HOME/yolo")
    assert expand("~/yolo") == expand("${HOME}/yolo")
    assert expand("~/yolo") == expand("${HOME}/${HOME}/yolo")



# Generated at 2022-06-24 02:22:44.228591
# Unit test for function expand
def test_expand():
    if os.name == 'nt':
        assert expand('%path%') == os.environ['path']
        assert expand('%PATH%') == os.environ['PATH']
    else:
        assert expand('$PATH') == os.environ['PATH']

    assert expand('${PATH}') == os.environ['PATH']



# Generated at 2022-06-24 02:22:51.429714
# Unit test for function expand
def test_expand():
    env = {
        'HOME': '/home/test'
    }

    with mock.patch.dict('os.environ', env):
        assert expand('$HOME') == '/home/test'
        assert expand('$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:22:56.953858
# Unit test for function expand
def test_expand():
    assert expand("$HOME/") == expand("~/")
    assert expand("~/") == os.path.join(os.environ["HOME"], "/")
    assert expand("${HOME}") == os.path.join(os.environ["HOME"], "")
    assert expand("$MY_SECRET/$MY_TEST") == expand("") + expand("")



# Generated at 2022-06-24 02:23:07.226074
# Unit test for function load_env_file
def test_load_env_file():
    file_contents = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    environ = os.environ.copy()

    load_env_file(file_contents, write_environ=environ)

    assert environ['TEST'] == os.path.normpath(os.getenv('HOME') + '/yeee')
    assert environ['THISIS'] == os.path.normpath(os.getenv('HOME') + '/a/test')

# Generated at 2022-06-24 02:23:13.286921
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO as strIO

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    stream = strIO('\n'.join(lines))
    load_env_file(stream)

# Generated at 2022-06-24 02:23:24.779832
# Unit test for function load_env_file
def test_load_env_file():
    contents = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    ret = load_env_file(contents, write_environ=None)

    assert len(ret) == len(contents)


# Generated at 2022-06-24 02:23:31.968141
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):
        def test_parse_env_file_contents(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            contents = parse_env_file_contents(lines)
            self.assertEqual(['TEST', 'THISIS', 'YOLO'], [key for key, val in contents])
            self.assertEqual(['.../yeee', '.../a/test', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], [val for key, val in contents])

# Generated at 2022-06-24 02:23:38.388988
# Unit test for function expand
def test_expand():
    original = '~/test/${HOME}/abc'
    expanded = expand(original)

    # Check that the value was changed
    assert original != expanded

    # Check that the expansion was done correctly
    expected_expanded = os.path.expandvars(os.path.expanduser(original))
    assert expanded == expected_expanded



# Generated at 2022-06-24 02:23:46.937966
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Parse a simple line
    assert list(parse_env_file_contents(['TEST=123'])) == [('TEST', '123')]

    # Parse a line with multiple = signs
    assert list(parse_env_file_contents(['TEST=1=2=3'])) == [('TEST', '1=2=3')]

    # Parse a line with $HOME
    expected = [('TEST', '$HOME/yeee')]
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee'])) == expected

    # Parse a line with ~
    expected = [('TEST', '~/yeee')]
    assert list(parse_env_file_contents(['TEST=~/yeee'])) == expected

   

# Generated at 2022-06-24 02:23:58.022471
# Unit test for function expand
def test_expand():
    """
    Test the expand function.

    >>> test_expand()
    True
    """
    import sys
    import os

    assert os.path.expanduser("~") == expand("~")
    assert os.path.expandvars("$USER") == expand("$USER")

    # To test for a real environment, the program needs to run with elevated privileges
    # if sys.platform.startswith("linux"):
    #    assert os.environ["USER"] == expand("$USER")

    assert "$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST" == expand("$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

    return True



# Generated at 2022-06-24 02:24:07.438801
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = iter([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    for result_line, expected_line in zip(result, expected):
        assert result_line == expected_line



# Generated at 2022-06-24 02:24:11.970099
# Unit test for function expand
def test_expand():
    """
    Test for function expand.
    """
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('${HOME}') == os.path.expandvars('${HOME}')
    assert expand('~/a/test') == os.path.expanduser('~/a/test')
    assert expand('~/a/$HOME') == os.path.expanduser('~/a/$HOME')

# Generated at 2022-06-24 02:24:21.483853
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST="$HOME/yeee"', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = {k: v for k, v in parse_env_file_contents(lines)}
    assert result == {
        "TEST": expand('$HOME/yeee'),
        "THISIS": expand('~/a/test'),
        "YOLO": expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }



# Generated at 2022-06-24 02:24:25.586754
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ.get('HOME')
    assert expand('~') == os.environ.get('HOME')
    assert expand('${HOME}') == os.environ.get('HOME')
    assert expand('~/swag') == os.path.expanduser('~/swag')


# Generated at 2022-06-24 02:24:33.126783
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Regex portion
    m = parse_env_file_contents(lines)
    m = list(m)
    assert m[0] == ("TEST", "${HOME}/yeee-$PATH")
    assert m[1] == ("THISIS", "~/a/test")
    assert m[2] == ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

    # Full function test
    os.environ["HOME"] = "/home/test"

# Generated at 2022-06-24 02:24:43.380615
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(verbose=False)


if __name__ == '__main__':
    if '--help' in sys.argv[1:]:
        print(__doc__)
        sys.exit(0)

    if '--test' in sys.argv[1:]:
        sys.exit(test_load_env_file())

    if len(sys.argv) == 2:
        # only one argument: assume it's an env file (legacy for usage with `source`)
        filename = sys.argv[1]
        env = load_env_file(open(filename))

        for line in env.values():
            print(line)
    else:
        print("Usage: load_env_file.py <env_file>")
        sys.exit(1)

# Generated at 2022-06-24 02:24:52.973735
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    d1 = load_env_file(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"], write_environ=None)
    assert d1["TEST"] != "..."
    assert d1["THISIS"] != "..."
    assert d1["YOLO"] == "..."


# Run the doc tests
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:24:57.404215
# Unit test for function expand
def test_expand():
    a = '$HOME/test'
    b = expand(a)
    assert a != b
    assert os.path.exists(b)



# Generated at 2022-06-24 02:25:08.449220
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_lines = dict(parse_env_file_contents(lines))

    # Test if TEST is properly expanded
    assert parsed_lines['TEST'] == os.path.expanduser('~/yeee')

    # Test if THISIS is properly expanded
    assert parsed_lines['THISIS'] == os.path.expanduser('~/a/test')

    # Test if YOLO is not expanded
    assert parsed_lines['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:25:17.527414
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_file = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    parsed_env_file = list(parse_env_file_contents(env_file))
    parsed_values = [
        x[1]
        for x in parsed_env_file
    ]

    assert len(env_file) == len(parsed_values)

    expanded_values = [
        expand(x)
        for x in env_file
    ]

    for val1, val2 in zip(expanded_values, parsed_values):
        assert val1 == val2

# Generated at 2022-06-24 02:25:19.215913
# Unit test for function expand
def test_expand():
    """
    >>> expand('$PATH')
    '...'
    """
    pass



# Generated at 2022-06-24 02:25:27.483530
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    values = list(parse_env_file_contents(['TEST="$HOME/yeee-$PATH" "bob"', 'THISIS=~/a/test', 'YOLO=~/swaggins/$JESUS']))
    assert len(values) == 3
    assert values[0] == ('TEST', '.../.../yeee-... "bob"')
    assert values[1] == ('THISIS', '.../a/test')
    assert values[2] == ('YOLO', '.../swaggins/$JESUS')

    values = list(parse_env_file_contents(['TEST="$HOME/yeee-$PATH', 'HOLA=TEST']))
    assert len(values) == 2

# Generated at 2022-06-24 02:25:35.840444
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    actual = load_env_file(lines, dict())
    for k, v in expected.items():
        assert actual[k] == v



# Generated at 2022-06-24 02:25:41.063449
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:25:48.726353
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests the load_env_file function
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_map = load_env_file(lines, write_environ=dict())
    assert len(test_map) > 0
    assert isinstance(test_map, collections.OrderedDict)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:56.952576
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(iter(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))) == [
        ('TEST', os.path.expanduser(os.path.expandvars('${HOME}/yeee'))),
        ('THISIS', os.path.expanduser(os.path.expandvars('~/a/test'))),
        ('YOLO', os.path.expanduser(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))),
    ]

# Generated at 2022-06-24 02:26:00.875503
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:26:09.202962
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    os.environ['PATH'] = 'test_parsing_$PATH'
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-24 02:26:17.630354
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

    # from tempfile import NamedTemporaryFile
    # import os

    # with NamedTemporaryFile('w+', delete=False) as f:
    #     f.write("""\
    #     TEST=${HOME}/yeee-$PATH
    #     THISIS=~/a/test
    #     YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    #     """)

    # ood = load_env_file(f.name)
    # assert ood == OrderedDict([('TEST', '.../.../yeee-...:...'),
    #                            ('THISIS', '.../a/test'),
    #                            ('YOLO', '.../swaggins/$

# Generated at 2022-06-24 02:26:23.092803
# Unit test for function load_env_file
def test_load_env_file():
    contents = b"""
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    """

    text = contents.decode('utf-8')
    lines = text.splitlines()

    expected = {
        'TEST': expand('${HOME}/yeee-$PATH'),
        'THISIS': '~/a/test',
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

    assert load_env_file(lines) == expected

# Generated at 2022-06-24 02:26:29.449978
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:26:39.149336
# Unit test for function load_env_file
def test_load_env_file():
    environ = dict()
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=environ)
    assert len(environ) == 3
    assert environ['TEST'].startswith('/home/') is True
    assert environ['TEST'].endswith('/yeee-') is True
    assert ':' in environ['TEST']
    assert environ['THISIS'].startswith('/home/') is True
    assert ':' not in environ['THISIS']
    assert environ['YOLO'].startswith('/home/') is True

# Generated at 2022-06-24 02:26:48.504866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    from .load import parse_env_file_contents

    x = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.split("\n")

    v1 = dict(parse_env_file_contents(x))
    assert v1 == {'TEST': '.../.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


# Generated at 2022-06-24 02:26:56.698463
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THIS HELP IS INVISIBLE TO THE EYEEEEE',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    files = []

    for test_file in lines:

        test_file = [
            line.strip() if line != '\n' else line
            for line in test_file.split("\n")
        ]

        files.append("\n".join(test_file) + "\n")

    values = parse_env_file_contents(lines=files)

    assert list(values)[0] == ('TEST', '.../.../yeee-...:...')


# Generated at 2022-06-24 02:26:58.323228
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    if doctest.testmod()[0] == 0:
        print("Success! Passed an initial round of tests!")

# Generated at 2022-06-24 02:27:03.647994
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert isinstance(result, collections.abc.Generator), 'Result of function parse_env_file_contents is not a generator'
    assert list(result) == [('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))], 'Result of function parse_env_file_contents does not match expected result'



# Generated at 2022-06-24 02:27:06.919181
# Unit test for function expand
def test_expand():
    os.environ["HOME"] = "/home"
    assert expand("$HOME") == "/home"
    assert expand("~/a/test") == "/home/a/test"
    assert expand("${HOME}${PATH}") == "/home:/usr/bin"



# Generated at 2022-06-24 02:27:09.649979
# Unit test for function expand
def test_expand():
    pass



# Generated at 2022-06-24 02:27:10.915092
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:27:18.913741
# Unit test for function load_env_file
def test_load_env_file():
    import os


# Generated at 2022-06-24 02:27:27.602198
# Unit test for function expand
def test_expand():
    import inspect

    env_vars = {i: os.environ[i] for i in os.environ
                if re.match(r"[A-Z_]+", i) and not re.match(r"^(PWD|OLDPWD|TERM|SHLVL)$", i)}
    # print(env_vars)

    home = expand("~")
    home = re.sub(r'\A(.+)/.+\Z', r'\1', home)

    # print(home)

    current_file = expand("$PWD/" + inspect.getfile(inspect.currentframe()))

    # print(current_file)


# Generated at 2022-06-24 02:27:29.481367
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    result = doctest.testmod()

    if result.failed:
        import sys

        sys.exit(1)

# Generated at 2022-06-24 02:27:35.676331
# Unit test for function expand
def test_expand():
    val = expand("~")
    assert val == os.path.expanduser("~")

    val = expand("$PATH")
    assert val == os.path.expandvars("$PATH")

    val = expand("${PATH}")
    assert val == os.path.expandvars("$PATH")
    # TODO: Add tests for os.path.expandvars()



# Generated at 2022-06-24 02:27:46.497417
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestEnvFileParser(unittest.TestCase):
        def setUp(self):
            self.environ_copy = os.environ.copy()

        def tearDown(self):
            os.environ.clear()

            for k, v in self.environ_copy.items():
                os.environ[k] = v

        def test_load_env_expand_home(self):
            """Checks that $HOME is correctly expanded when reading from an env file"""

            lines = ['TEST=$HOME/yeee']
            assert load_env_file(lines) == collections.OrderedDict([('TEST', expand('$HOME/yeee'))])


# Generated at 2022-06-24 02:27:56.393382
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    got = [i for i in parse_env_file_contents(lines)]
    want = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    for i, j in zip(got, want):
        assert i == j



# Generated at 2022-06-24 02:28:06.778839
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = {
        'TEST': '{}/yeee-{}'.format(expand('$HOME'), expand('$PATH')),
        'THISIS': expand('~/a/test'),
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    changes = load_env_file(lines, write_environ=dict())

    for k, v in expected.items():
        assert changes[k] == v



# Generated at 2022-06-24 02:28:13.585154
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$PATH', 'THISIS=~/a/test']
    load_env_file(lines, write_environ=dict())

    for contents in [
        ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
        ["TEST=''", 'THISIS=""'],
    ]:
        parsed = dict(parse_env_file_contents(contents))
        assert parsed['TEST'] == ''
        assert parsed['THISIS'] == ''



# Generated at 2022-06-24 02:28:22.511916
# Unit test for function load_env_file
def test_load_env_file():
    def test_lines():
        yield 'TEST=${HOME}/yeee'
        yield 'THISIS=~/a/test'
        yield 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    assert load_env_file(test_lines(), write_environ=dict()) == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

# Generated at 2022-06-24 02:28:33.377737
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:28:41.723497
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import logging

    logger = logging.getLogger(__name__)

    m = dict()
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
        f.flush()
        load_env_file([f.name], write_environ=m)

    logger.info(m)



# Generated at 2022-06-24 02:28:53.380803
# Unit test for function expand

# Generated at 2022-06-24 02:29:02.689778
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for key, value in parse_env_file_contents(lines):
        if key == 'TEST':
            assert os.getenv('HOME') in value
        elif key == 'THISIS':
            assert os.getenv('HOME') in value
        elif key == 'YOLO':
            assert os.getenv('HOME') in value
        else:
            assert False



# Generated at 2022-06-24 02:29:12.660112
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    assert(len(changes) == 3)
    assert(changes['TEST'].startswith('.../.../yeee-'))
    assert(changes['TEST'].endswith(':...'))
    assert(changes['THISIS'].startswith('.../a/test'))
    assert(changes['YOLO'].endswith('$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-24 02:29:15.977721
# Unit test for function expand
def test_expand():
    assert expand('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert expand('~/foo') == os.path.expanduser(os.path.expandvars('~/foo'))



# Generated at 2022-06-24 02:29:27.567876
# Unit test for function load_env_file
def test_load_env_file():
    import inspect
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    frame = inspect.currentframe()
    globals = frame.f_globals
    locals = frame.f_locals

# Generated at 2022-06-24 02:29:34.529963
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:29:42.534936
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = collections.OrderedDict(
        (k, v)
        for k, v in parse_env_file_contents(lines)
    )

    assert 'TEST' in values
    assert 'THISIS' in values
    assert 'YOLO' in values

    assert values['TEST'] == os.path.expanduser('~') + '/yeee'
    assert values['THISIS'] == os.path.expanduser('~/a/test')