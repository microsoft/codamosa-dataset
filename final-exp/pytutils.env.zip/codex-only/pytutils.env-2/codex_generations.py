

# Generated at 2022-06-24 02:19:52.822878
# Unit test for function load_env_file
def test_load_env_file():
    # Base case.
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == {
        'TEST': expand('${HOME}/yeee-$PATH'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

    # Empty file.
    lines = []
    assert load_env_file(lines) == {}

# Generated at 2022-06-24 02:20:00.689856
# Unit test for function expand
def test_expand():
    env = dict(X='something', Y='$X/else')
    assert expand('$X') == 'something'
    assert expand('${X}') == 'something'
    assert expand('$X/other') == 'something/other'
    assert expand('${X}/other') == 'something/other'
    assert expand('$X/$Y') == 'something/something/else'
    assert expand('${X}/$Y') == 'something/something/else'
    assert expand('$X/${Y}') == 'something/something/else'
    assert expand('${X}/${Y}') == 'something/something/else'

    assert expand('~/.profile') == os.path.expanduser('~/.profile')



# Generated at 2022-06-24 02:20:08.550654
# Unit test for function expand
def test_expand():
    env = {
        'HOME': 'test',
        'CHEESE': 'var',
        'YOLO': 'swaggins',
        'TEST': 'yeee'
    }

    with mock.patch.dict(os.environ, env):
        assert expand('$HOME/yeee-$PATH') == 'test/yeee-%PATH%'
        assert expand('~/a/test') == '%HOME%/a/test'
        assert expand('~/swaggins/$YOLO') == '%HOME%/swaggins/swaggins'
        assert expand('${HOME}/yeee-$PATH') == 'test/yeee-%PATH%'
        assert expand('${CHEESE}${YOLO}') == 'varswaggins'

# Generated at 2022-06-24 02:20:11.306845
# Unit test for function load_env_file
def test_load_env_file():
    with open(os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '.env')), 'r') as f:
        load_env_file(f.readlines())
        assert False

# Generated at 2022-06-24 02:20:13.244903
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expandvars('${HOME}')



# Generated at 2022-06-24 02:20:21.326595
# Unit test for function expand
def test_expand():
    assert expand("hello") == "hello"
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("${HOME}") == os.path.expanduser("~")

    os.environ["YOLO"] = "swaggins"
    assert expand("$YOLO") == "swaggins"
    assert expand("${YOLO}") == "swaggins"
    assert expand("${YO${LO}") == "swaggins"



# Generated at 2022-06-24 02:20:25.638016
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert result == collections.OrderedDict(
        [
            ('TEST', '.../.../yeee-...:...'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        ]
    )



# Generated at 2022-06-24 02:20:35.835551
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = {}
    load_env_file(lines, environ)

    assert 'HOME' in environ
    assert 'PATH' in environ
    assert 'TEST' in environ
    assert 'THISIS' in environ
    assert 'YOLO' in environ
    assert environ['THISIS'] == '.../a/test'
    assert environ['TEST'] == '.../.../yeee-...:...'

# Generated at 2022-06-24 02:20:47.572484
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.path.expanduser('$HOME/test')
    assert expand('${HOME}/test') == os.path.expanduser('${HOME}/test')
    assert expand('$HOME/${HOME}') == os.path.expanduser('$HOME/${HOME}')
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('~/~/') == os.path.expanduser('~/~/')
    assert expand('') == os.path.expanduser('')
    assert expand('${SOMETHING_THAT_DOES_NOT_EXIST}') == os.path.expanduser('${SOMETHING_THAT_DOES_NOT_EXIST}')

# Generated at 2022-06-24 02:20:59.264988
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "hello world"
    assert expand("$TEST") == "hello world"

    os.environ["TEST1"] = "hello"
    os.environ["TEST2"] = "world"
    assert expand("${TEST1} ${TEST2}") == "hello world"

    # os.environ["TEST1"] = "hello"
    # os.environ["TEST2"] = "world"
    # assert expand("${TEST1} $TEST2") == "hello world"

    assert expand("~/hello") == f"{os.path.expanduser('~')}/hello"
    assert expand("~/hello/world") == f"{os.path.expanduser('~')}/hello/world"

# Generated at 2022-06-24 02:21:04.035007
# Unit test for function expand
def test_expand():
    # Arrange
    os.environ['test'] = 'test'

    # Act
    res = expand('${test}')

    # Assert
    assert res == 'test'
    assert isinstance(res, str)



# Generated at 2022-06-24 02:21:06.737709
# Unit test for function expand
def test_expand():
    assert os.path.abspath(expand("${HOME}/test")) == os.path.abspath("~/test")
    assert os.path.abspath(expand("~/test")) == os.path.abspath("~/test")

# Generated at 2022-06-24 02:21:15.572824
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert dict(parse_env_file_contents(lines)) == {
        "TEST": "${HOME}/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }



# Generated at 2022-06-24 02:21:26.332587
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=dict())
    assert isinstance(values, collections.OrderedDict)

# Generated at 2022-06-24 02:21:32.107037
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents()) == []
    assert list(parse_env_file_contents([])) == []

    assert list(parse_env_file_contents("TEST=${HOME}/yeee".split("\n"))) == [("TEST", "${HOME}/yeee")]



# Generated at 2022-06-24 02:21:33.637930
# Unit test for function expand
def test_expand():
    assert expand('~/some/path/to/somewhere') == os.path.expanduser('~/some/path/to/somewhere')



# Generated at 2022-06-24 02:21:41.452718
# Unit test for function expand
def test_expand():
    import tempfile
    import shutil
    import os

    with tempfile.TemporaryDirectory() as tmp_dir_path:
        old_path = os.getcwd()
        os.chdir(tmp_dir_path)

# Generated at 2022-06-24 02:21:47.509883
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:21:50.821852
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("~") == os.path.expandvars("~")
    assert expand("~/foo") == os.path.expandvars("~/foo")



# Generated at 2022-06-24 02:22:01.789974
# Unit test for function expand
def test_expand():
    # Testing os.path.expanduser
    env = os.environ.copy()
    env['HOME'] = os.path.dirname(os.path.realpath(__file__))
    s = '~/test_expand.py'
    assert expand(s) == os.path.join(env['HOME'], 'test_expand.py')

    # Testing os.path.expandvars
    s = '${HOME}/test_expand.py'
    assert expand(s) == os.path.join(env['HOME'], 'test_expand.py')

    # Testing both
    s = '~/${HOME}/test_expand.py'
    assert expand(s) == os.path.join(env['HOME'], env['HOME'], 'test_expand.py')

# Generated at 2022-06-24 02:22:07.788532
# Unit test for function expand
def test_expand():
    import pytest
    variable_name = "HOME"
    variable = os.environ[variable_name]
    os.environ.update({"HOME": variable})
    with pytest.raises(KeyError):
        os.environ.pop(variable_name)
        os.environ[variable_name]
    assert expand(variable_name) == variable
    assert expand("~/a/b") == variable + "/a/b"
    assert expand("${HOME}/a/b") == variable + "/a/b"
    assert expand("~/${HOME}") == variable + variable



# Generated at 2022-06-24 02:22:18.200950
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Testing parse_env_file_contents

    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict([('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    assert actual == expected



# Generated at 2022-06-24 02:22:26.548360
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(["TEST=${HOME}/yeee",
                                    "THISIS=~/a/test",
                                    "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]) == \
           [("TEST", "${HOME}/yeee"),
            ("THISIS", "~/a/test"),
            ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]



# Generated at 2022-06-24 02:22:32.664695
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee']) == collections.OrderedDict([('TEST', '.../yeee')])


if __name__ == '__main__':
    import doctest

    print('Testing...')
    doctest.testmod()  # doctest.run_docstring_examples(load_env_file, globals())

# Generated at 2022-06-24 02:22:41.595994
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', expand(os.environ['HOME']) + '/yeee'),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]

    # from honcho.tests

# Generated at 2022-06-24 02:22:49.975398
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=dict())

    assert environ == collections.OrderedDict([('TEST', os.path.expanduser('~/yeee-') + os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])




# Generated at 2022-06-24 02:22:55.103899
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')


# Generated at 2022-06-24 02:22:57.969907
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")

    os.environ["TEST"] = "test"
    assert expand("$TEST") == "test"



# Generated at 2022-06-24 02:23:06.508014
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = '''TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''.splitlines()

    r = load_env_file(lines, write_environ=None)

    assert r.keys() == ['TEST', 'THISIS', 'YOLO']

    for key, value in r.items():
        if key == 'YOLO':
            assert value == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
        else:
            assert value.startswith('~')



# Generated at 2022-06-24 02:23:13.214272
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "test"
    os.environ["PATH"] = ":/bin/:/sbin/"
    assert os.path.expanduser(expand("$TEST/home")) == os.path.expanduser(os.environ["TEST"] + "/home")
    assert expand("$PATH") == os.path.expanduser(os.environ["PATH"])



# Generated at 2022-06-24 02:23:21.861742
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path

    basedir = Path(__file__).parent

    env_lines = read_lines_as_str(Path(basedir, 'resources', 'env.test.txt'))

    expected_lines = read_lines_as_str(Path(basedir, 'resources', 'test_parse_env_file_contents.expected.txt'))

    actual_lines = parse_env_file_contents(env_lines)

    assert list(actual_lines) == [line.split('=') for line in expected_lines]

# Generated at 2022-06-24 02:23:23.878468
# Unit test for function expand
def test_expand():
    val = "${USER}/yeee"
    v2 = expand(val)
    assert val != v2



# Generated at 2022-06-24 02:23:25.118032
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 02:23:28.619560
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)


# Base class

# Generated at 2022-06-24 02:23:38.902166
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    testing_vars = collections.OrderedDict([('TEST', '${HOME}/yeee'),
                                            ('THISIS', '~/a/test'),
                                            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    testing_vars_res = collections.OrderedDict()

    testing_vars_res['TEST'] = '~/yeee'
    testing_vars_res['THISIS'] = '~/a/test'
    testing_vars_res['YOLO'] = '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-24 02:23:46.192433
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:23:57.968064
# Unit test for function expand
def test_expand():
    # Has to be in the same directory, but that's okay for a test.
    filename = os.path.abspath(__file__)
    basepath = os.path.dirname(filename)
    test_text = "$HOME"
    assert expand(test_text) == os.path.expanduser(test_text)
    test_text = "$HOME/yolo"
    assert expand(test_text) == os.path.expanduser(test_text)
    test_text = "~/yolo"
    assert expand(test_text) == os.path.expanduser(test_text)
    test_text = "~/yolo\n~/yolo"
    assert expand(test_text) == os.path.expanduser(test_text)

# Generated at 2022-06-24 02:24:06.633465
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    solution = [('TEST', '${HOME}/yeee'),
                ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == solution



# Generated at 2022-06-24 02:24:14.093218
# Unit test for function expand
def test_expand():
    # Testing expansion with environment variables
    assert expand('${FOO}bar') == 'bar'
    assert expand('${HOME}bar') == '%sbar' % os.path.expanduser('~')

    # Testing expansion with ~
    assert expand('~bar') == os.path.expanduser('~bar')
    assert expand('~/bar') == os.path.expanduser('~/bar')
    assert expand('~/b~ar') == os.path.expanduser('~/b~ar')

    # Testing expansion with expandvars
    os.environ['FOO'] = '/foo'
    assert expand('$FOO') == os.environ['FOO']
    assert expand('${FOO}bar') == '/foobar'

    # Testing normal strings
    assert expand('foo') == 'foo'


# Generated at 2022-06-24 02:24:16.168795
# Unit test for function expand
def test_expand():
    expanded_val = expand('$HOME/yeee-$PATH')
    home_dir = os.path.expanduser('~')
    assert expanded_val == home_dir + '/yeee-' + os.environ['PATH']

# Generated at 2022-06-24 02:24:25.725506
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

# Generated at 2022-06-24 02:24:28.928207
# Unit test for function expand
def test_expand():
    assert expand("${HOME}") == os.path.expandvars("${HOME}")
    assert expand("~/yeee") == os.path.expanduser("~/yeee")



# Generated at 2022-06-24 02:24:40.507825
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())

    assert 'TEST' in env
    assert env['TEST'].startswith('/Users')
    assert env['TEST'].endswith('yeee')

    assert 'THISIS' in env
    assert env['THISIS'].startswith('/Users')
    assert env['THISIS'].endswith('a/test')

    assert 'YOLO' in env
    assert env['YOLO'].startswith('/Users')

# Generated at 2022-06-24 02:24:44.114851
# Unit test for function expand
def test_expand():
    assert expand("~/pipelines") == os.path.expanduser("~/pipelines")
    assert expand("${HOME}/pipelines") == os.path.expandvars("${HOME}/pipelines")
    assert expand("~/pipelines") == os.path.expandvars("~/pipelines")



# Generated at 2022-06-24 02:24:53.325781
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = load_env_file(lines, write_environ=None)

    assert results['TEST'].endswith('/yeee')
    assert results['THISIS'].endswith('/a/test')
    assert results['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:24:56.719969
# Unit test for function expand
def test_expand():
    assert expand("$HOME/foo") == os.environ["HOME"] + "/foo"
    assert expand("~/foo") == os.environ["HOME"] + "/foo"

    test_val = '${HOME}\n${192.168.0.1}'
    assert expand(test_val) == os.environ["HOME"] + '\n${192.168.0.1}'

# Generated at 2022-06-24 02:24:58.085311
# Unit test for function expand
def test_expand():
    assert expand('$HOME/a') == os.path.expanduser('$HOME/a')



# Generated at 2022-06-24 02:25:08.505050
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class Test(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            #                                  0                  1                  2
            result = load_env_file(lines, write_environ=dict())

            import os
            import re

            self.assertTrue(re.match(r'\A' + re.escape(os.path.expanduser(os.path.expandvars('${HOME}'))) + r'/yeee-[^/]+:[^/]+\Z', result['TEST']))

# Generated at 2022-06-24 02:25:18.092114
# Unit test for function expand

# Generated at 2022-06-24 02:25:19.367328
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: add a way to write the function to a file and test the function
    pass

# Generated at 2022-06-24 02:25:29.011830
# Unit test for function load_env_file
def test_load_env_file():
    content = """USER=test
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"""

    environ = os.environ.copy()
    try:
        new_env = load_env_file(content.splitlines(), environ)
    finally:
        os.environ.clear()
        os.environ.update(environ)

    assert new_env["USER"] == "test"
    assert "HOME" in new_env["TEST"]
    assert "/yeee" in new_env["TEST"]
    assert new_env["THISIS"] == os.path.expanduser("~/a/test")

# Generated at 2022-06-24 02:25:37.898459
# Unit test for function expand
def test_expand():
    """
    >>> expand("~/yeee")
    '.../yeee'
    >>> expand("${HOME}/yeee")
    '.../yeee'
    >>> os.environ["NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"] = "meep"
    >>> expand("~/yeee-${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}") == os.path.expanduser("~/yeee-meep")
    True
    """
    pass



# Generated at 2022-06-24 02:25:40.277733
# Unit test for function expand
def test_expand():
    assert expand('~/aa/bb') == os.path.expanduser('~/aa/bb')



# Generated at 2022-06-24 02:25:43.223229
# Unit test for function expand
def test_expand():
    assert expand('$USER') == f'{os.getenv("USER")}'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:25:49.526154
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == collections.OrderedDict([('TEST', os.path.expandvars(os.path.expanduser('${HOME}/yeee-$PATH'))), ('THISIS', os.path.expandvars(os.path.expanduser('~/a/test'))), ('YOLO', os.path.expandvars(os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))])

# Generated at 2022-06-24 02:25:54.307780
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:25:55.914084
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test'])

# Generated at 2022-06-24 02:25:58.305381
# Unit test for function expand
def test_expand():
    home = os.environ.get('HOME')
    assert expand('~/swaggins') == os.path.join(home, 'swaggins')
    assert expand('$HOME/swaggins') == os.path.join(home, 'swaggins')



# Generated at 2022-06-24 02:26:04.203340
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=$HOME/yeee", "THISIS=~/a/test",
             "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    assert parse_env_file_contents(lines) == [
        ('TEST', '$HOME/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:26:13.220299
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-24 02:26:18.190638
# Unit test for function load_env_file
def test_load_env_file():
    data = """
TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    lines = data.splitlines(keepends=False)
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:26:22.635449
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(('TEST=${HOME}', 'THIS=${HOME}/a')) == OrderedDict([('TEST', '/home/travis'), ('THIS', '/home/travis/a')])


if __name__ == "__main__":
    print(load_env_file(['TEST=$HOME']))

# Generated at 2022-06-24 02:26:31.047472
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Make sure we can open a file.
    assert list(parse_env_file_contents(['TEST=yeee'])) == [('TEST', 'yeee')]

    # Make sure we can expand variables
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee'])) == [('TEST', '.../yeee')]

    # Make sure we can expand tilde
    assert list(parse_env_file_contents(['TEST=~/yeee'])) == [('TEST', '.../yeee')]

    # Make sure we can expand both

# Generated at 2022-06-24 02:26:39.258124
# Unit test for function expand
def test_expand():
    assert expand('$TEST') == expand('TEST')
    assert expand('~$TEST') == expand('~$TEST')
    assert expand('~/test') == expand('~/test')
    assert expand('${HOME}/test') == expand('~/test')
    assert expand('${HOME}/test') == expand('${HOME}/test')
    assert expand('${HOME}/test') == expand('$HOME/test')
    assert expand('$HOME/test') == expand('~/test')
    assert expand('${HOME}/test') == expand('~/test')
    assert expand('${PATH}/test') == expand('$PATH/test')
    assert expand('${PATH}') == expand('$PATH')
    assert expand('${PATH}') == expand('{PATH}')

# Generated at 2022-06-24 02:26:45.718229
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file.
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:26:54.049975
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ])) == [
        ('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
        ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test')),
        ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]



# Generated at 2022-06-24 02:26:59.482874
# Unit test for function expand
def test_expand():
    # Test for expand to expandvars
    os.environ["PATH"] = "C:/Users/mattb/Desktop"
    assert expand("PATH=$PATH") == "PATH=C:/Users/mattb/Desktop"
    assert expand("PATH=$PATH/new") == "PATH=C:/Users/mattb/Desktop/new"

    # Test for expand to expanduser
    os.environ["HOME"] = "C:/Users/mattb/Desktop"
    assert expand("HOME=~/Desktop") == "HOME=C:/Users/mattb/Desktop/Desktop"



# Generated at 2022-06-24 02:27:10.030227
# Unit test for function expand
def test_expand():
    # Home directory should be expanded
    assert '~/yeee-$PATH' == expand('~/yeee-$PATH')
    assert os.path.expanduser('~/yeee-$PATH') == expand('~/yeee-$PATH')

    # Variables should also be expanded
    assert 'thing' == expand('$yeee')
    assert 'thing' == expand('${yeee}')

    # But if you are trying to get a value from an undefined variable
    # Then they should NOT be expanded
    assert '$yeee' == expand('$yeee')
    assert '${yeee}' == expand('${yeee}')

    # Create the variables, and things should work
    os.environ['yeee'] = 'thing'
    assert 'thing' == expand('$yeee')

# Generated at 2022-06-24 02:27:15.194580
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> value = load_env_file(['TEST=hi'], write_environ=dict())
    >>> assert value == {'TEST': 'hi'}
    """



# Generated at 2022-06-24 02:27:18.738620
# Unit test for function expand
def test_expand():
    pass



# Generated at 2022-06-24 02:27:23.379961
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    load_env_file(lines, write_environ=None)

# Generated at 2022-06-24 02:27:31.897844
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])



# Generated at 2022-06-24 02:27:38.642228
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME/test') == os.path.expanduser('~/test')
    assert expand(r'${HOME}/test') == os.path.expanduser('~/test')
    assert expand(r'${HOME}') == os.path.expanduser('~')

    assert expand(r'~/test') == os.path.expanduser('~/test')



# Generated at 2022-06-24 02:27:47.967679
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile

    env_filename = 'env.txt'

    with open(env_filename, 'w') as f:
        print('HOME={}'.format(os.path.expanduser('~')), file=f)
        print('PATH={}'.format(os.environ['PATH']), file=f)

    # Make sure the file is deleted even if an error occurs

# Generated at 2022-06-24 02:27:49.866428
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.getenv('HOME')
    assert expand('~') == os.getenv('HOME')



# Generated at 2022-06-24 02:27:52.880245
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = ''
    assert expand('${TEST}') == ''
    assert expand('~/') == '.../'
    assert expand('${TEST}') == ''



# Generated at 2022-06-24 02:27:59.886823
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:28:05.810694
# Unit test for function expand
def test_expand():
    import os

    path = '/home/usr/file'
    assert expand(path) == path

    path = '~/file'
    assert expand(path) == os.path.expanduser(path)

    path = '$HOME/file'
    assert expand(path) == os.path.join(os.environ['HOME'], 'file')

    path = '${HOME}/file'
    assert expand(path) == os.path.join(os.environ['HOME'], 'file')

    path = '$NONEXISTENT_VAR/file'
    assert expand(path) == os.path.join(os.getenv('NONEXISTENT_VAR', ''), 'file')

    path = '${NONEXISTENT_VAR}/file'

# Generated at 2022-06-24 02:28:10.808815
# Unit test for function expand
def test_expand():
    test = "~/test/me"
    result = expand(test)
    home = os.path.expanduser('~')
    path = home + '/test/me'
    assert result == path



# Generated at 2022-06-24 02:28:20.971704
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expect_result = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(result) == expect_result


# Unit tests for function load_env_file

# Generated at 2022-06-24 02:28:31.232470
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from ._test.doc_test_helper import get_doc_test_io

    # Try doctest
    for line in get_doc_test_io(__name__, 'test_parse_env_file_contents()'):
        print(line.rstrip())

    # Manual testing
    test_str = """
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        # This is a comment, and should be ignored!
    """

    result = list(parse_env_file_contents(test_str.splitlines()))

# Generated at 2022-06-24 02:28:33.340393
# Unit test for function expand
def test_expand():
    assert os.path.expanduser('~/') in expand('~/')


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-24 02:28:41.677137
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-24 02:28:46.476360
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-24 02:28:58.363669
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',)
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '${HOME}/yeee-$PATH')
    assert next(values) == ('THISIS', '~/a/test')
    assert next(values) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:29:04.745679
# Unit test for function load_env_file
def test_load_env_file():
    from os.path import join

    # Load example env files
    with open(join("tests", "example_env_files", "set_env_files"), "r") as f:
        content = f.read()

    lines = content.split("\n")

    # Test loading env file into OrderedDict
    output = load_env_file(lines, write_environ=dict())

    # Test if value is different from input line
    assert output["TEST"] != lines[0]

    # Test if value is different from input line
    assert output["THISIS"] != lines[1]

    # Test if value is different from input line
    assert output["YOLO"] != lines[2]

# Generated at 2022-06-24 02:29:10.066939
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:29:16.755447
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:29:28.355878
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(['a=b', 'c=d', 'e=f'])) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert dict(parse_env_file_contents(['a=b', 'c=d', 'e=f', '# comment', 'a=g'])) == {'a': 'g', 'c': 'd', 'e': 'f'}
    assert dict(parse_env_file_contents(['a=b', 'c=d', 'e=f', '# comment'])) == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-24 02:29:33.492206
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile(prefix='test_load_env_file_', delete=False) as fp:
        fp.write(
            'TEST=${HOME}/yeee-$PATH'.encode('ascii'))
        fp.write('\n'.encode('ascii'))
        fp.write(r'THISIS=~/a/test'.encode('ascii'))
        fp.write('\n'.encode('ascii'))
        fp.write(
            r'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.encode('ascii'))
        fp.write('\n'.encode('ascii'))

        filename = fp

# Generated at 2022-06-24 02:29:40.271142
# Unit test for function load_env_file
def test_load_env_file():
    # Test with correct env file
    correct_env = """TEST=${HOME}/yeee-$PATH
THIS=${HOME}
THISIS=${HOME}/a/test
YOLO=${HOME}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
ANOTHER=${HOME}/swaggins/$YOLO
"""
    correct_dict = {
        'TEST': '.../.../yeee-...:...',
        'THIS': '...',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'ANOTHER': '.../swaggins/$YOLO'
    }
    assert load_env

# Generated at 2022-06-24 02:29:47.592312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = list(parse_env_file_contents(lines))
    print(lines)

