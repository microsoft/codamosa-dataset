

# Generated at 2022-06-24 02:19:50.383553
# Unit test for function load_env_file
def test_load_env_file():
    loading_dir = os.path.dirname(__file__)
    env_file_path = os.path.join(loading_dir, '..', 'test', '.env')

    values = load_env_file(open(env_file_path))
    assert len(values) > 0
    assert values['TEST'] is not None
    assert values['TEST'] == 'yeee'

# Generated at 2022-06-24 02:19:51.460895
# Unit test for function expand
def test_expand():
    # Put the tests here
    expand('~/x')
    expand('$HOME')

# Generated at 2022-06-24 02:20:02.288950
# Unit test for function load_env_file

# Generated at 2022-06-24 02:20:08.932414
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test multiple lines
    lines = 'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    result = parse_env_file_contents(lines.splitlines())
    expected = [('TEST', '~/yeee-~/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'),
                ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert result == expected

# Generated at 2022-06-24 02:20:10.652534
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.run_docstring_examples(load_env_file, globals(), verbose=True)

# Generated at 2022-06-24 02:20:13.690770
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:20:25.055856
# Unit test for function load_env_file

# Generated at 2022-06-24 02:20:28.036274
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == dict(TEST='.../yeee', THISIS='.../a/test', YOLO='.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:20:28.948444
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:20:38.722224
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    assert list(parse_env_file_contents([])) == []



# Generated at 2022-06-24 02:20:44.250471
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    gen = parse_env_file_contents(lines)
    assert next(gen) == ('TEST', expand('${HOME}/yeee'))
    assert next(gen) == ('THISIS', expand('~/a/test'))
    assert next(gen) == ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-24 02:20:50.771287
# Unit test for function load_env_file
def test_load_env_file():
    # Third argument is for mutating the environ object (really don't want to do this in unit testing)
    # so just pass in None
    load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
                  write_environ=None)


####################################################################################################
# Tests

# Unit test function

# Generated at 2022-06-24 02:20:52.288374
# Unit test for function expand
def test_expand():
    assert expand('hello') == 'hello'
    assert expand('~/hello') == expand('$HOME/hello')



# Generated at 2022-06-24 02:20:57.944659
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = os.path.join(os.path.dirname(__file__), 'test.env')

    with open(filename) as fp:
        contents = parse_env_file_contents(fp)
        for c in contents:
            print(c)
        assert os.path.expandvars('${PATH}') == os.environ['PATH']
        assert os.path.expandvars('${SHELL}') == os.environ['SHELL']
        assert os.path.expandvars('${HOME}') == os.environ['HOME']

# Generated at 2022-06-24 02:21:05.601421
# Unit test for function expand
def test_expand():
    # No expansion happening
    assert expand("Hello world") == "Hello world"

    # Only user expansion
    assert expand("Hello~") == "Hello~"

    # Only env var expansion
    assert expand("Hello $HOME") == "Hello {}".format(os.environ["HOME"])

    # Combination of both
    assert expand("~Hello $HOME/test") == "~Hello {}/test".format(os.environ["HOME"])



# Generated at 2022-06-24 02:21:13.174988
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input_str = '''# comment
TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''

    output = dict(parse_env_file_contents(input_str.splitlines()))

    assert output['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert output['TEST'] == os.path.expandvars(os.path.expanduser('${HOME}/yeee'))
    assert output['THISIS'] == os.path.expanduser('~/a/test')



# Generated at 2022-06-24 02:21:20.948144
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=COOL']
    load_env_file(lines, write_environ=dict())

    lines = ['TEST=${HOME}/yeee-$PATH']
    load_env_file(lines, write_environ=dict())

    lines = ['TEST=$HOME/yeee-$PATH']
    load_env_file(lines, write_environ=dict())

    lines = ['TEST="$HOME/yeee-$PATH"']
    load_env_file(lines, write_environ=dict())

    lines = ['TEST=\'$HOME/yeee-$PATH\'']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-24 02:21:28.396566
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())

    assert len(env) == 3

    assert 'TEST' in env
    assert env['TEST'] == '.../.../yeee-...:...'

    assert 'THISIS' in env
    assert env['THISIS'] == '.../a/test'

    assert 'YOLO' in env
    assert env['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:21:31.254981
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.environ['HOME'] + '/test'
    assert expand('~/test') == os.environ['HOME'] + '/test'



# Generated at 2022-06-24 02:21:40.407830
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), 'env_file_test.txt')
    with open(filename, 'r') as f:
        lines = f.readlines()

    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([
        ('TEST', os.path.expanduser('~/yeee-') + os.pathsep + os.path.expandvars('$PATH')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])

# Generated at 2022-06-24 02:21:47.556475
# Unit test for function expand
def test_expand():
    os.environ['ENV_0'] = '0'
    assert expand('${ENV_0}') == '0'
    assert expand('${ENV_${ENV_0}}') == '$ENV_0'
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-24 02:21:58.873037
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()

    load_env_file(lines, write_environ=write_environ)

    assert write_environ['TEST'] == os.path.expanduser(os.path.join('~', 'yeee-') + os.environ['PATH'])
    assert write_environ['THISIS'] == os.path.expanduser(os.path.join('~', 'a', 'test'))

# Generated at 2022-06-24 02:22:02.833369
# Unit test for function expand
def test_expand():
    assert expand('~/home') == os.path.expanduser('~/home')
    assert expand('${HOME}/home') == os.path.join(os.path.expandvars('${HOME}'), 'home')
    assert expand('${HOME}') == os.path.expandvars('${HOME}')



# Generated at 2022-06-24 02:22:11.234232
# Unit test for function expand
def test_expand():
    test_str = '~/test'
    assert os.path.expanduser(test_str) == '/home/<user>/test'

    test_str = '$HOME/test'
    assert os.path.expandvars(test_str) == '/home/<user>/test'

    test_str = '~/$HOME/test'
    assert os.path.expanduser(os.path.expandvars(test_str)) == '/home/<user>/<user>/test'



# Generated at 2022-06-24 02:22:21.310634
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ=write_environ)
    assert write_environ['TEST'] == os.path.join(expand('$HOME'), 'yeee-' + expand('$PATH'))
    assert write_environ['THISIS'] == expand('~/a/test')
    assert write_environ['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-24 02:22:26.348752
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    load_env_file(lines, write_environ=environ)



# Generated at 2022-06-24 02:22:29.276751
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:33.377761
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:22:36.521699
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import contextlib
    with contextlib.redirect_stdout(None):
        import doctest

        doctest.testmod()

# Generated at 2022-06-24 02:22:46.087048
# Unit test for function load_env_file
def test_load_env_file():
    import operator

    lines = (
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    )
    environ = load_env_file(lines)
    assert isinstance(environ, collections.OrderedDict)

    key, val = next(iter(environ.items()))
    assert operator.contains(key, 'TEST')
    assert operator.contains(val, 'yeee')

    key, val = next(operator.itemgetter(1)(environ.items()))
    assert operator.contains(key, 'THISIS')
    assert operator.contains(val, 'test')


# Generated at 2022-06-24 02:22:49.549703
# Unit test for function expand
def test_expand():
    test_data = [
        {
            'input': r'${HOME}/yeee',
            'expected': expand(r'${HOME}/yeee')
        }
    ]

    for test_case in test_data:
        assert test_case['expected'] == expand(test_case.get('input'))



# Generated at 2022-06-24 02:22:58.249133
# Unit test for function expand
def test_expand():
    """Test function expand."""
    # Test expand
    # Note: os.path.expanduser does not work for windows, but it should be fine for this case

    os.environ["TEST"] = "/test/test"
    expected = os.path.expandvars('$TEST/test')
    assert expected == expand('$TEST/test')

    os.environ["HOME"] = "/test/test"
    expected = os.path.expanduser('~/test')
    assert expected == expand('~/test')



# Generated at 2022-06-24 02:23:02.671088
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    import sys

    print("Running doctest...")
    doctest.testmod(sys.modules[__name__], raise_on_error=True)

    print("...done")



# Generated at 2022-06-24 02:23:05.407861
# Unit test for function expand
def test_expand():
    assert expand('~/yee') == os.path.expanduser('~/yee')
    assert expand('$TEST/yee') == os.path.expandvars('$TEST/yee')



# Generated at 2022-06-24 02:23:12.127008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test for function parse_env_file_contents.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    with open(os.path.join(thisdir, 'test_env_file_contents.txt')) as f:
        vals = parse_env

# Generated at 2022-06-24 02:23:23.438634
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    expected_result = [
        ('TEST', os.path.expandvars('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

    result = parse_env_file_contents(lines=test_lines)


# Generated at 2022-06-24 02:23:27.219413
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:23:34.034701
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = '/tmp'

    assert expand('$TEST/test') == '/tmp/test'
    assert expand('$TEST/test/$TEST') == '/tmp/test/$TEST'

    del os.environ['TEST']

    assert expand('$TEST/test') == '$TEST/test'



# Generated at 2022-06-24 02:23:42.212835
# Unit test for function load_env_file
def test_load_env_file():
    """Unit test for function load_env_file"""
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    with pytest.raises(FileNotFoundError):
        load_env_file('INVALID/FILENAME/PATH.txt')



# Generated at 2022-06-24 02:23:48.504610
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    env_vars = parse_env_file_contents(lines)
    env_vars = dict(env_vars)

    print(env_vars)

    assert len(env_vars) == 3

    for val in env_vars.values():
        # Must be expanded to be valid
        assert '~' not in val

        # And must have '$' and '{'
        assert ('$' in val) or '{' in val



# Generated at 2022-06-24 02:24:00.374443
# Unit test for function expand
def test_expand():
    """
    >>> test_expand()
    """
    import tempfile

    with tempfile.NamedTemporaryFile('w', delete=False) as tfile:
        tfile.write('YOLO=~/yeee.txt')

    lines = ['TEST=${HOME}/yeee.txt', 'THISIS=~/a/test', 'YOLO=%s' % tfile.name]

    os.environ['AWESOME_TEST_ENV_VAR'] = 'kthxbye'

    changes = load_env_file(lines)

    os.unlink(tfile.name)

    assert changes['TEST'] == '%s/yeee.txt' % os.environ['HOME']
    assert changes['THISIS'] == '%s/a/test' % os.environ

# Generated at 2022-06-24 02:24:09.406223
# Unit test for function load_env_file
def test_load_env_file():
    from pathlib import Path

    tmpdir = Path(tempfile.gettempdir())
    env_file = tmpdir / "test_load_env_file.env"

    lines = ["TEST=$HOME/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    with env_file.open("w") as fp:
        fp.write("\n".join(lines))

    assert load_env_file(lines) == load_env_file(env_file.read_text().splitlines())


# From docker-compose

# Generated at 2022-06-24 02:24:15.936447
# Unit test for function expand
def test_expand():
    test_dict1 = {'a': '$HOME'}
    test_dict2 = {'b': '~'}
    test_dict3 = {'c': '${HOME}'}
    test_dict4 = {'d': '~'}
    test_dict5 = {'e': '${HOME}'}

    assert expand_dict(test_dict1)['a'] == os.path.expanduser('~')
    assert expand_dict(test_dict2)['b'] == os.path.expanduser('~')
    assert expand_dict(test_dict3)['c'] == os.path.expanduser('~')
    assert expand_dict(test_dict4)['d'] == os.path.expanduser('~')

# Generated at 2022-06-24 02:24:26.129231
# Unit test for function expand

# Generated at 2022-06-24 02:24:30.127008
# Unit test for function expand
def test_expand():
    """
    Unit test for function expand
    """
    assert expand('~/foo') == os.path.expanduser('~/foo')
    assert expand('${HOME}/foo') == os.path.expandvars('${HOME}/foo')



# Generated at 2022-06-24 02:24:41.382744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)

    assert next(data) == ('TEST', '.../yeee')
    assert next(data) == ('THISIS', '.../a/test')
    assert next(data) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    with pytest.raises(StopIteration):
        next(data)

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test']
    data = parse_

# Generated at 2022-06-24 02:24:47.822411
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('${HOME}') == os.path.expandvars('${HOME}')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')

# Generated at 2022-06-24 02:24:53.403562
# Unit test for function expand
def test_expand():
    # Expand to absolute path
    assert expand('.') == os.getcwd()

    # Expand to relative path
    assert expand('$PWD') == '.'

    # Expand to relative path (without the leading $)
    assert expand('PWD') == '.'

    # Expand variable that does not exist
    assert expand('$HUGO') == '$HUGO'

    # Expand variable to variable
    assert expand('$PWD/$PWD') == './.'

# Generated at 2022-06-24 02:24:55.313098
# Unit test for function expand
def test_expand():
    s = expand("$HOME/yeee")
    assert s == os.path.expandvars(os.path.expanduser("$HOME/yeee"))



# Generated at 2022-06-24 02:25:06.546118
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = """
# This is a comment
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    values = parse_env_file_contents(contents.splitlines())

    assert sorted(values) == sorted(
        [('TEST', '.../.../yeee-...:...'),
         ('THISIS', '.../a/test'),
         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-24 02:25:17.889162
# Unit test for function load_env_file
def test_load_env_file():
    try:
        import hypothesis
    except ImportError:
        return

    from hypothesis import given
    from hypothesis import strategies

    from . import util

    @given(strategies.text())
    def test_expanding_to_identical(env_file_contents):
        # This test is trivial but it's good to have it around.
        expected = expand(env_file_contents)
        actual = load_env_file([env_file_contents])[env_file_contents]
        assert actual == expected

    @given(strategies.lists(util.env_key_value(), min_size=1))
    def test_load_env_file_from_env_key_values(env_key_values):
        environ = dict()

# Generated at 2022-06-24 02:25:27.106218
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_file = load_env_file(lines, write_environ=dict())

    for k, v in env_file.items():
        assert k in lines[0] or k in lines[1] or k in lines[2]
        assert os.path.expanduser(k) in v
        assert os.path.expandvars(k) in v



# Generated at 2022-06-24 02:25:35.026360
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile() as fp:
        pass


#   lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
#   load_env_file(lines, write_environ=fp)
#   print(fp)


# To test that the same file is loaded into os.environ
#   fp = os.environ
#   load_env_file(lines, write_environ=fp)
#   print(fp['PATH'])

# Generated at 2022-06-24 02:25:42.798151
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    # Tests below depend on environment variables being set.
    assert changes['TEST'] == '{}/yeee-{}'.format(expand('~'), expand('$PATH'))
    assert changes['THISIS'] == expand('~/a/test')
    assert changes['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Tests that write_environ is optional

# Generated at 2022-06-24 02:25:46.623608
# Unit test for function expand
def test_expand():
    assert expand('$USER') == os.environ['USER']
    assert expand('~/abc') == os.path.expanduser('~/abc')
    assert expand('${HOME}/abc') == os.path.expanduser('~/abc')



# Generated at 2022-06-24 02:25:53.793699
# Unit test for function load_env_file
def test_load_env_file():
    # No asserts, just make sure no errors are raised and returned values are as expected.
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:26:06.177470
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest
    lines = ['TEST=$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))
    assert d['TEST'] == '$PATH'
    assert d['THISIS'] == '~/a/test'
    assert d['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:26:11.329213
# Unit test for function expand
def test_expand():
    test_values = [
        ('$USER', os.path.expandvars('$USER')),
        ('$HOME', os.path.expandvars('$HOME')),
        ('~', os.path.expanduser('~')),
        ('~/', os.path.expanduser('~/')),
        ('~/a', os.path.expanduser('~/a')),
    ]

    for val, expected in test_values:
        assert expected == expand(val)



# Generated at 2022-06-24 02:26:21.703794
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    raw_dict = {
        'TEST': '$HOME/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }
    raw_dict_out = {
        'TEST': os.path.join(os.path.expanduser('~'), 'yeee'),
        'THISIS': os.path.join(os.path.expanduser('~'), 'a', 'test'),
        'YOLO': os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }


# Generated at 2022-06-24 02:26:31.072217
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/test') == os.environ['HOME'] + '/test'
    assert expand('~/test') == os.environ['HOME'] + '/test'
    assert expand('$HOME/test') == os.environ['HOME'] + '/test'
    assert expand('$HOME/test') == os.environ['HOME'] + '/test'

    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~') == os.environ['HOME']
    assert expand('$HOME') == os.environ['HOME']
    assert expand('$HOME/test') == os.environ['HOME'] + '/test'



# Generated at 2022-06-24 02:26:37.772476
# Unit test for function expand
def test_expand():
    tests = [
        ('$HOME/test', os.path.expandvars('$HOME/test')),
        ('~/test', os.path.expanduser('~/test')),
    ]

    for text, expected in tests:
        if os.name == 'nt':
            expected = expected.replace('\\', '/')

        assert expand(text) == expected

# Generated at 2022-06-24 02:26:42.930822
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.expanduser("~/.bashrc")

    with open(filename) as fp:
        lines = fp.readlines()

    result = load_env_file(lines, write_environ=None)
    assert len(result) > 0
    assert isinstance(result, collections.OrderedDict)

# Generated at 2022-06-24 02:26:47.770747
# Unit test for function expand
def test_expand():
    import configparser
    import logging
    import tempfile
    import unittest
    import shutil

    from pathlib import Path

    # logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    ##########################################################################
    # Test case classes

    class TestConfigParser(unittest.TestCase):
        """
        Test case class
        """

        ######################################################################

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.config_file_name = "test.ini"
            self.config_file = Path(self.tmpdir, self.config_file_name)

            # The parser we're testing
            self.parser = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())



# Generated at 2022-06-24 02:26:56.034616
# Unit test for function load_env_file
def test_load_env_file():
    import argparse

    # Create the top-level parser
    parser = argparse.ArgumentParser(description="Test for module env_file")

    # Add the argument
    parser.add_argument("--test-load-env-file", type=str, help="Run test for function load_env_file")
    parser.add_argument("--test-load-env-file-filename", type=str, default="", help="Filename containing test case")
    parser.add_argument("--test-load-env-file-expected-output", type=str, default="", help="Expected output of the test")

    # Parse the command-line arguments
    args = parser.parse_args()

    # Enter the test for function load_env_file

# Generated at 2022-06-24 02:27:06.633620
# Unit test for function load_env_file
def test_load_env_file():
    from control.core.environment import load_env_file
    from control.core.environment import parse_env_file_contents

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())
    assert changes['TEST'] != '${HOME}/yeee'
    assert changes['TEST'] != '~/yeee'
    assert changes['TEST'] != '~/yeee'
    assert changes['TEST'] != '$HOME/yeee'

# Generated at 2022-06-24 02:27:09.313682
# Unit test for function load_env_file
def test_load_env_file():
    pass

# Generated at 2022-06-24 02:27:13.343379
# Unit test for function expand
def test_expand():
    os.environ['HOME'] = 'me'
    os.environ['PATH'] = 'you'
    assert expand('/home/you') == '/home/you'
    assert expand('$HOME/you') == 'me/you'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:27:19.612084
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def get_result(env_file_contents):
        return list(parse_env_file_contents(env_file_contents.split('\n')))

    assert get_result('') == []
    assert get_result('A=1') == [('A', '1')]
    assert get_result(' A = 2 ') == [('A', '2')]
    assert get_result('A="2 3"') == [('A', '2 3')]
    assert get_result('A="2 3"\nB=1') == [('A', '2 3'), ('B', '1')]



# Generated at 2022-06-24 02:27:23.765782
# Unit test for function expand
def test_expand():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        # Relative path
        assert os.path.abspath(expand('.')) == os.path.abspath(os.getcwd())

        # Absolute path
        assert os.path.abspath(expand(tmpdir)) == os.path.abspath(tmpdir)

        # Expand environment variables
        assert os.path.abspath(expand('$' + os.path.basename(tmpdir))) == os.path.abspath(tmpdir)

        # Expand user home
        assert os.path.abspath(expand('~' + os.path.basename(os.path.expanduser('~')))) == os.path.abspath(os.path.expanduser('~'))



# Generated at 2022-06-24 02:27:27.979910
# Unit test for function expand
def test_expand():
    assert expand("~/test/test") == os.environ['HOME'] + os.sep + "test/test"
    assert expand("$HOME/test") == os.environ['HOME'] + os.sep + "test"

# Generated at 2022-06-24 02:27:35.643904
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['x=y', '#this=is not valid', 'a=b', 'c="d"', "e='f'"]
    result = [i for i in parse_env_file_contents(lines)]
    assert result == [('x', 'y'), ('a', 'b'), ('c', 'd'), ('e', 'f')]

    # test escaping chars
    lines = [r'a=b\\x\x']
    result = [i for i in parse_env_file_contents(lines)]
    assert result == [('a', r'b\\x\x')]

    lines = [r'a="b\\x\x"']
    result = [i for i in parse_env_file_contents(lines)]
    assert result == [('a', r'b\\x\x')]

   

# Generated at 2022-06-24 02:27:41.403049
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) is not None

# Generated at 2022-06-24 02:27:48.537624
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=dict())

    assert isinstance(values, collections.OrderedDict)

    assert values['TEST'] == expand('${HOME}/yeee')
    assert values['THISIS'] == expand('~/a/test')
    assert values['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:27:51.982457
# Unit test for function load_env_file
def test_load_env_file():
    for key, value in test_load_env_file.__doc__.split("\n"):
        assert key in os.environ
        assert os.environ[key] == value


test_load_env_file()

# Generated at 2022-06-24 02:27:58.400384
# Unit test for function expand
def test_expand():
    env = dict(HOME='${PWD}')
    os.environ.update(env)

    curdir = os.path.abspath(os.path.curdir)

    print('curdir:', curdir)

    for exp in ('$PWD', '~', '~/', '~/.', '~/..', '~/$HOME'):
        print('expand:', exp, '->', expand(exp))

    assert expand('~') == expand('${HOME}') == curdir

# Generated at 2022-06-24 02:28:02.206819
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-' + os.environ['PATH'], 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ={})


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:28:11.962883
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Explicitly test with different types of line endings.
    import io
    lines = io.StringIO('''TEST=${HOME}/yeee-$PATH\r
THISIS=~/a/test\n
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\r\n
''')

# Generated at 2022-06-24 02:28:17.205744
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')
    assert expand('test') == 'test'
    assert expand('$HOME') == os.environ['HOME']



# Generated at 2022-06-24 02:28:18.416031
# Unit test for function expand
def test_expand():
    assert expand('~'), os.path.expanduser('~')


# Generated at 2022-06-24 02:28:29.329415
# Unit test for function load_env_file
def test_load_env_file():
    _environ = dict()
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes1 = load_env_file(lines, write_environ=_environ)
    assert changes1['TEST'] == '{HOME}/yeee-{PATH}'.format(**_environ)
    assert changes1['THISIS'] == '{HOME}/a/test'.format(**_environ)
    assert changes1['YOLO'] == '{HOME}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(**_environ)



# Generated at 2022-06-24 02:28:37.742524
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as fp:
        fp.write('\n'.join(lines) + '\n')

    changes = load_env_file(lines)


# Generated at 2022-06-24 02:28:49.073394
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    os.environ['HOME'] = '...'
    os.environ['PATH'] = '...'
    expected = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])
    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert result == expected



# Generated at 2022-06-24 02:28:51.264585
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:28:56.562819
# Unit test for function load_env_file
def test_load_env_file():
    try:
        import doctest
        doctest.testmod(verbose=True)
    except:
        print("No module named 'doctest'")

# Generated at 2022-06-24 02:28:58.794190
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:29:03.171856
# Unit test for function expand
def test_expand():
    source = '~/a/b'
    target = expand(source)

    if '~' in target:
        raise Exception('Expanding {} failed. Result: {}'.format(source, target))

    source = '/$HOME/a/b'
    target = expand(source)

    if '$HOME' in target:
        raise Exception('Expanding {} failed. Result: {}'.format(source, target))



# Generated at 2022-06-24 02:29:10.200594
# Unit test for function expand
def test_expand():
    assert expand('hello') == 'hello'
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/hello') == os.path.expanduser('~') + '/hello'
    assert expand('${HOME}/hello') == os.path.expanduser('~') + '/hello'



# Generated at 2022-06-24 02:29:17.142418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Loads valid env files
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test']
    load_env_file(lines)

    # Loads invalid env files
    lines = ['TEST=${HOME/yeee-$PATH', 'THISIS=~/a/test']
    load_env_file(lines)



# Generated at 2022-06-24 02:29:21.365869
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    for line in parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']):
        print(line)



# Generated at 2022-06-24 02:29:29.600731
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'test'
    os.environ['HELLO'] = 'hello'

    assert expand('test') == 'test'
    assert expand('$TEST') == 'test'
    assert expand('${TEST}') == 'test'
    assert expand('${TEST}/asd') == 'test/asd'
    assert expand('${TEST}/$HELLO') == 'test/hello'
    assert expand('${TEST}/${HELLO}') == 'test/hello'
    assert expand('${TEST}/${HELLO}/${TEST}') == 'test/hello/test'

# Generated at 2022-06-24 02:29:32.108877
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ['HOME']
    assert expand('~') == os.environ['HOME']
    assert expand('${HOME}/.') == os.environ['HOME'] + '/.'



# Generated at 2022-06-24 02:29:42.010093
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import io

    env = load_env_file(io.StringIO('''test=test
test2=${test}2
test3="${test}"3
test4='${test}'4
'''))
    assert env['test'] == 'test'
    assert env['test2'] == 'test2'
    assert env['test3'] == 'test3'
    assert env['test4'] == '${test}4'

    env = load_env_file(io.StringIO('''test=test
test2=${test}2
test3="${test}"3
test4='${test}'4
'''), {})

    assert env['test'] == 'test'
    assert env['test2'] == 'test2'
    assert env['test3'] == 'test3'
    assert env

# Generated at 2022-06-24 02:29:46.235065
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=False)


if __name__ == "__main__":
    test_parse_env_file_contents()