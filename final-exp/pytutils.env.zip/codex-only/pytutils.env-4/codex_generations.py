

# Generated at 2022-06-24 02:19:46.034059
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # "TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    envs = [("TEST", "~/yeee"), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    for env, line in zip(envs, lines):
        key, val = env

        new_key, new_val

# Generated at 2022-06-24 02:19:47.369685
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")

# Generated at 2022-06-24 02:19:50.046599
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:19:59.859503
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ref = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    result = load_env_file(lines, write_environ=dict())

    assert result == ref

# Generated at 2022-06-24 02:20:07.295830
# Unit test for function load_env_file
def test_load_env_file():

    import io

    lines = [
        "TEST = ${HOME}/yeee-$PATH",
        "THISIS = ~/a/test",
        "YOLO = ~/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    # Load env file
    env_dict = load_env_file(lines, write_environ=dict())

    # Assertions
    assert env_dict == {
        "TEST": "...",
        "THISIS": "...",
        "YOLO": "...",
    }, f"Env file not loaded successfully: {env_dict}"


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:20:19.039077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Basic unit test.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """


# Generated at 2022-06-24 02:20:24.353197
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    yml = """
    environment:
      TEST: ${HOME}/yeee
      THISIS: "~/a/test"
      YOLO: "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    """
    load_env_file(yml.splitlines())



# Generated at 2022-06-24 02:20:35.132691
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO',
                                         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    actual = collections.OrderedDict(parse_env_file_contents(lines))
    assert actual == expected, "Don't match"



# Generated at 2022-06-24 02:20:41.376048
# Unit test for function load_env_file
def test_load_env_file():
    from click.testing import CliRunner
    from click import File, Context

    runner = CliRunner()
    with runner.isolated_filesystem():
        with open('test.env', 'w') as f:
            f.write("test='test v'\n")
            f.write('test2="test v2"\n')
            f.write("test3='test v3'\n")
            f.write("test4='test v\\'5'\n")
            f.write('test5="test v\\"6"\n')
            f.write('test6=test\n')
            f.write('test7=$HOME\n')
            f.write('test8=test\n')

        output = load_env_file(File('test.env').readlines())


# Generated at 2022-06-24 02:20:50.655043
# Unit test for function load_env_file
def test_load_env_file():
    import honcho.compat
    import tempfile

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    fd, filename = tempfile.mkstemp()


# Generated at 2022-06-24 02:20:59.642393
# Unit test for function load_env_file
def test_load_env_file():
    env_file_contents = """
    # This is a comment
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    lines = (l.strip() for l in env_file_contents.splitlines() if l != '' and not l.strip().startswith('#'))
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:08.838692
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    lines = parse_env_file_contents(lines)
    assert next(lines) == ('TEST', '.../yeee')
    assert next(lines) == ('THISIS', '.../a/test')

    # Parse single quoted variables
    lines = ["TEST='this is a $TEST'",
             "THISIS=\"this is a ${TEST}\"",
             "YOLO='test'",
             "YOLO2=\"test\""]
    lines = parse_env_file_contents(lines)
    assert next(lines) == ("TEST", "this is a $TEST")
    assert next(lines) == ("THISIS", "this is a ${TEST}")

# Generated at 2022-06-24 02:21:18.608480
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))
    lines = ['TEST=${HOME}/yeee-$PATH']
    print(load_env_file(lines, write_environ=dict()))
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))



# Generated at 2022-06-24 02:21:23.428519
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:21:33.665432
# Unit test for function load_env_file

# Generated at 2022-06-24 02:21:40.772940
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']

    results = load_env_file(lines, write_environ=dict())

    # TODO: use pytest.raises to validate results
    assert results['TEST'].endswith('/yeee')
    assert results['THISIS'].endswith('/a/test')
    assert results['YOLO'].endswith('/swaggins')


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:21:46.404472
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:21:54.454959
# Unit test for function load_env_file

# Generated at 2022-06-24 02:22:06.113496
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:22:17.429939
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> from collections import OrderedDict
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at ...>
    >>> OrderedDict(parse_env_file_contents(lines))
    OrderedDict([('TEST', '${HOME}/yeee-$PATH'),
             ('THISIS', '~/a/test'),
             ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-24 02:22:26.618469
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = [
        'MYVAR1=value1',
        'MYVAR2=value2',
        'MYVAR3=$MYVAR1',
        'MYVAR4="My name is $MYVAR2"',
        'MYVAR5="My name is $MYVAR2"',
        'MYVAR6="My name is $MYVAR2"',
    ]

    d = parse_env_file_contents(contents)

    assert d is not None

    for k, v in d:
        print(f'{k}={v}')


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:22:33.629250
# Unit test for function expand
def test_expand():
    assert expand("~/hello") == os.path.expanduser("~/hello")
    assert expand("$HOME/a") == os.path.expandvars("$HOME/a")



# Generated at 2022-06-24 02:22:39.732950
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> values = parse_env_file_contents([
    ...     'TEST=${HOME}/yeee', 'THISIS=~/a/test',
    ...     'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ...     'MAYBE~=plz',
    ... ])
    >>> values.send(None)
    Traceback (most recent call last):
        ...
    StopIteration
    """
    pass

# Generated at 2022-06-24 02:22:48.288057
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    p = parse_env_file_contents(lines)
    assert next(p) == ("TEST", os.getenv('HOME') + "/yeee")
    assert next(p) == ("THISIS", os.getenv('HOME') + "/a/test")
    assert next(p) == ("YOLO", os.getenv('HOME') + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    with pytest.raises(StopIteration):
        next(p)



# Generated at 2022-06-24 02:22:56.483543
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = dict(parse_env_file_contents(lines))
    assert contents['TEST'] == os.path.join(expand("${HOME}"), "yeee")

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', "YOLO='${HOME}/swaggins'/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    contents = dict(parse_env_file_contents(lines))

# Generated at 2022-06-24 02:23:05.566542
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_data = '''TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
'''

    lines = test_data.splitlines()

    lines_iter = parse_env_file_contents(lines)

    result = collections.OrderedDict(lines_iter)

    assert result == {
        'TEST': f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}',
        'THISIS': f'{os.environ["HOME"]}/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

# Generated at 2022-06-24 02:23:15.835331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .testing_utils import capture_stdout


# Generated at 2022-06-24 02:23:24.395668
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    home = expand('~')
    assert env['TEST'].startswith(home)
    assert env['TEST'].endswith('/yeee-')
    assert env['THISIS'].startswith(expand('~'))
    assert env['YOLO'].startswith(expand('~'))



# Generated at 2022-06-24 02:23:34.142284
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())

    assert (
        dict(parse_env_file_contents(lines)) ==
        dict([
            ('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        ])
    )



# Generated at 2022-06-24 02:23:45.150507
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def _test_parse_env_file_contents(input: str, output: str) -> None:
        lines = input.splitlines()
        assert list(parse_env_file_contents(lines)) == eval(output)

    _test_parse_env_file_contents("TEST=${HOME}/yeee", "[('TEST', '$HOME/yeee')]")
    _test_parse_env_file_contents("TEST='${HOME}/yeee'", "[('TEST', '.../yeee')]")
    _test_parse_env_file_contents("TEST='${HOME}/yeee'", "[('TEST', '.../yeee')]")

# Generated at 2022-06-24 02:23:50.884368
# Unit test for function expand
def test_expand():
    # Test to see that, if a variable is not set, expand returns the same string
    assert expand('$VARIABLE') == '$VARIABLE', "expand() not working properly"
    assert expand('${VARIABLE}') == '${VARIABLE}', "expand() not working properly"



# Generated at 2022-06-24 02:24:02.167915
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest
    import unittest.mock as mock

    class TestParseEnvFile(unittest.TestCase):
        @mock.patch('sys.stdout', new_callable=io.StringIO)
        def test_env_file(self, mock_stdout):
            test_lines = ('TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
                          'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
            test_dict = parse_env_file_contents(test_lines)
            for key, value in test_dict:
                print(key, value)
            output = mock_stdout.getvalue().split('\n')
            self.assertE

# Generated at 2022-06-24 02:24:11.813964
# Unit test for function expand
def test_expand():
    env = {
        'HOME': 'home/test',
        'PATH': 'path/test',
    }

    os.environ = env  # type: ignore
    orig_expanduser = os.path.expanduser  # type: ignore
    orig_expandvars = os.path.expandvars  # type: ignore

    def test_expanduser(path: str) -> str:
        return 'home/test' + path[4:]

    # noinspection PyTypeChecker
    os.path.expanduser = test_expanduser  # type: ignore
    os.path.expandvars = lambda path: path  # type: ignore

    assert expand('~/test') == 'home/test/test'
    assert expand('$HOME/test') == 'home/test/test'

# Generated at 2022-06-24 02:24:16.880253
# Unit test for function expand
def test_expand():
    var = '${HOME}'
    assert var != expand(var)
    assert var != expand(var).replace('\\', '/')

    path = '~/folder'
    assert path != expand(path)
    assert path != expand(path).replace('\\', '/')

# Generated at 2022-06-24 02:24:27.963234
# Unit test for function expand
def test_expand():
    # NOTE: expand user will only work with a home dir of /Users/ in this test
    assert expand('~/something') == expand('${HOME}/something') == expand('/Users/something')
    assert expand('something') == '/Users/something'
    assert expand('./something') == expand('${PWD}/something') == '/Users/something'
    assert expand('../../something') == expand('${PWD}/../../something') == '/Users/something'

    assert expand('${HOME}/something') == '/Users/something'
    assert expand('${PWD}/something') == '/Users/something'
    assert expand('${PWD}/../../something') == '/Users/something'

    assert expand('${HOME}/something') == '/Users/something'

# Generated at 2022-06-24 02:24:38.146157
# Unit test for function expand
def test_expand():
    for env_var, expected in [
        ('$HOME/yeee-$PATH', os.path.expandvars('$HOME/yeee-$PATH')),
        ('~/a/test', os.path.expanduser('~/a/test')),
        ('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
         os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]:
        assert expand(env_var) == expected


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:24:43.832606
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    # This fails on Python 3.7
    doctest.testmod()  # verbose=True)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:24:52.654924
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import unittest.mock

    filename = 'test.env'

    with unittest.mock.patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True

        with unittest.mock.patch('builtins.open') as mock_open:
            mock_open.return_value = io.StringIO('TEST=testval')

            result = load_env_file(filename)

            assert result == {'TEST': 'testval'}

# Generated at 2022-06-24 02:25:03.070558
# Unit test for function expand
def test_expand():
    def assert_expand(before, expected):
        assert before == expected, "expected {}, got {} for {}".format(expected, expand(before), before)

    assert_expand("~/bob/test.conf", "...")
    assert_expand("${HOME}/bob/test.conf", "...")
    assert_expand('~/swaggins', "...")
    assert_expand('${HOME}/swaggins', "...")
    assert_expand('/path/to/file/$NOT_AN_ENV_VAR', '/path/to/file/$NOT_AN_ENV_VAR')
    assert_expand('/path/to/file/$AN_ENV_VAR', "/path/to/file/...")

# Generated at 2022-06-24 02:25:14.379012
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Good assert
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = [kv for kv in parse_env_file_contents(lines)]
    assert values == [('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # assert parse_env_file_contents("") == ""


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:21.557777
# Unit test for function expand
def test_expand():
    from pkg_resources import resource_filename

    test_path = resource_filename('gencore_app', 'tests/data/test.env')

    with open(test_path, 'r') as fh:
        lines = fh.readlines()

    loaded = load_env_file(lines)

    assert loaded['TEST'] == '~/yeee-$PATH'
    assert loaded['THISIS'] == '~/a/test'
    assert loaded['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:25:24.493906
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")



# Generated at 2022-06-24 02:25:29.505522
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:25:38.532886
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-24 02:25:41.205713
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:50.919010
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = "test/test2/test3"

    home = os.environ['HOME']
    assert expand('~/test1') == "{}/test1".format(home)
    assert expand('${HOME}/test1') == "{}/test1".format(home)
    assert expand('$TEST') == "test/test2/test3"
    assert expand('${TEST}/test1') == "test/test2/test3/test1"
    assert os.environ['TEST'] == "test/test2/test3"
    assert expand('$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == "$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-24 02:25:57.589974
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Making OrderedDict to get same order as lines
    parsed_lines = collections.OrderedDict(parse_env_file_contents(lines))

    assert parsed_lines['TEST'] == '${HOME}/yeee'
    assert parsed_lines['THISIS'] == '~/a/test'
    assert parsed_lines['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:26:02.783575
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')



# Generated at 2022-06-24 02:26:06.142476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_lines = ['A=1', 'B=2']
    env_dict = dict(parse_env_file_contents(env_lines))
    assert env_dict['A'] == '1'
    assert env_dict['B'] == '2'



# Generated at 2022-06-24 02:26:09.334054
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(['TEST=0'])
    assert os.environ['TEST'] == '0'

    load_env_file(['TEST=0'], write_environ=None)
    with pytest.raises(KeyError):
        os.environ['TEST']



# Generated at 2022-06-24 02:26:13.365810
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ.get('HOME', '')



# Generated at 2022-06-24 02:26:23.149278
# Unit test for function expand
def test_expand():

    line = 'TEST=${HOME}/yeee-$PATH'

    m1 = re.match(r'\A([A-Za-z_0-9]+)=(.*)\Z', line)
    assert m1

    key, val = m1.group(1), m1.group(2)

    m2 = re.match(r"\A'(.*)'\Z", val)
    if m2:
        val = m2.group(1)

    m3 = re.match(r'\A"(.*)"\Z', val)
    if m3:
        val = re.sub(r'\\(.)', r'\1', m3.group(1))

    result = expand(val)

    assert os.path.join(os.environ["HOME"], "yeee-") in result

# Generated at 2022-06-24 02:26:27.535505
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 02:26:34.556544
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []
    assert list(parse_env_file_contents(['TEST=1'])) == [('TEST', '1')]
    assert list(parse_env_file_contents(['TEST=1', 'TEST2=2'])) == [('TEST', '1'), ('TEST2', '2')]
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test'])) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test')]



# Generated at 2022-06-24 02:26:38.767309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)

    assert res is not None



# Generated at 2022-06-24 02:26:40.401729
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['MULTILINES=test\\\ntest\\\ntest'])) == [
        ('MULTILINES', 'testtesttest')
    ]



# Generated at 2022-06-24 02:26:42.211499
# Unit test for function expand
def test_expand():
    home = os.environ['HOME']
    assert expand(f'~/bla.txt') == f'{home}/bla.txt'
    assert expand(f'${HOME}/bla.txt') == f'{home}/bla.txt'



# Generated at 2022-06-24 02:26:53.111321
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    got = load_env_file(lines, write_environ=None)

    assert got == {
        'TEST': '{}/yeee'.format(expand('$HOME')),
        'THISIS': '{}/a/test'.format(expand('~')),
        'YOLO': '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(expand('~')),
    }



# Generated at 2022-06-24 02:27:06.609295
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from tempfile import NamedTemporaryFile as tmpfile

    with tmpfile() as f:

        f.write(b'''
        INVALID LINE
        OVERRIDE=will_overwrite_existing
        PYTHONPATH=$PYTHONPATH:${PWD}
        INVALID LINE
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        ''')

        f.flush()

        from io import TextIOWrapper
        results = load_env_file(TextIOWrapper(f))


# Generated at 2022-06-24 02:27:16.810605
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def tmpfile(lines):
        with tempfile.NamedTemporaryFile() as fp:
            for l in lines:
                fp.write((l + os.linesep).encode(encoding='UTF-8', errors='strict'))
            fp.flush()
            yield fp.name

    # Unit test for function load_env_file

# Generated at 2022-06-24 02:27:23.129261
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    c = parse_env_file_contents(lines)
    assert c.__next__() == ('TEST', '${HOME}/yeee')
    assert c.__next__() == ('THISIS', '~/a/test')
    assert c.__next__() == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:27:31.211436
# Unit test for function load_env_file
def test_load_env_file():
    loader = load_env_file(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    loader = list(loader.items())
    assert loader == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-24 02:27:34.871050
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.REPORT_ONLY_FIRST_FAILURE)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:27:45.622939
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=$HOME/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    values = load_env_file(lines, write_environ=dict())

    assert len(values) == 3

    assert values['TEST'] is not None
    assert values['TEST'].startswith('/home/') and values['TEST'].endswith('/yeee-')
    assert values['THISIS'] == os.path.expanduser('~/a/test')
    assert values['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:27:53.408650
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=$HOME/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    r = dict(parse_env_file_contents(lines))
    assert r["TEST"] == "$HOME/yeee"
    assert r["THISIS"] == "~/a/test"
    assert r["YOLO"] == "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-24 02:27:55.739453
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THIS=test']
    od = load_env_file(lines, dict())
    assert list(od.keys()) == ['TEST', 'THIS']



# Generated at 2022-06-24 02:28:06.922034
# Unit test for function load_env_file
def test_load_env_file():
    import nose.tools

    # Check for OrderedDict
    test_data = {
        'TEST': '${HOME}/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

# Generated at 2022-06-24 02:28:09.803249
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'hello'
    assert expand('$TEST') == 'hello'
    assert expand('~/foo') == os.path.expanduser('~/foo')



# Generated at 2022-06-24 02:28:10.997697
# Unit test for function expand
def test_expand():
    assert os.environ["HOME"] == expand("$HOME")



# Generated at 2022-06-24 02:28:17.049731
# Unit test for function load_env_file
def test_load_env_file():
    result = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    expected = {
        'TEST': '{}/yeee-{}'.format(os.environ.get('HOME'), os.environ.get('PATH')),
        'THISIS': '{}/a/test'.format(os.environ.get('HOME')),
        'YOLO': '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ.get('HOME')),
    }
    assert result == expected

# Generated at 2022-06-24 02:28:24.798096
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [b'TEST=${HOME}/yeee-$PATH', b'THISIS=~/a/test', b'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)
    for k, v in results:
        if k == 'THISIS':
            assert v == expand('~/a/test')
        elif k == 'YOLO':
            assert v == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        elif k == 'TEST':
            assert v == expand('${HOME}/yeee-$PATH')



# Generated at 2022-06-24 02:28:26.995297
# Unit test for function expand
def test_expand():
    given_input = '$HOME/foo:$PATH'
    expected_output = os.environ['HOME'] + '/foo:' + os.environ['PATH']
    assert expand(given_input) == expected_output



# Generated at 2022-06-24 02:28:32.449386
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    changes = load_env_file(lines)
    assert changes == expected

# Generated at 2022-06-24 02:28:34.558254
# Unit test for function expand
def test_expand():
    val = "~/test"
    print(expand(val) == os.path.expanduser(val))



# Generated at 2022-06-24 02:28:40.077890
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):

        def test_valid(self):
            input_file = ['TEST=AAA', 'THISIS=BBB']
            expected = [('TEST', 'AAA'), ('THISIS', 'BBB')]
            actual = list(parse_env_file_contents(input_file))
            self.assertEqual(expected, actual)

        def test_no_equals(self):
            input_file = ['TEST', 'THISIS']
            expected = []
            actual = list(parse_env_file_contents(input_file))
            self.assertEqual(expected, actual)

        def test_empty(self):
            input_file = ['']
            expected = []

# Generated at 2022-06-24 02:28:51.099813
# Unit test for function expand
def test_expand():
    # Case 1: checking if it expands environment variables correctly
    os.environ['PATH'] = '/home/a/b/c/d'
    assert '/home/a/b/c/d' == expand('$PATH')

    # Case 2: checking if it expands environment variables correctly
    os.environ['TEST'] = '$HOME'
    assert '$HOME' == expand('$TEST')

    # Case 3: checking if it expands home correctly
    os.environ['HOME'] = '/home/a'
    assert '/home/a' == expand('~')

    # Case 4: checking if it expands home correctly
    os.environ['HOME'] = '/home/a/b/c'
    assert '/home/a/b/c' == expand('~/d')

    # Case 5: checking if it expands home correctly
   

# Generated at 2022-06-24 02:29:01.810650
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))

# Generated at 2022-06-24 02:29:10.544685
# Unit test for function expand
def test_expand():
    test_list = [
        ("~/test", expand("~/test")),
        ("${USER}/test", expand("${USER}/test"))
    ]

    for assert_list in test_list:
        assert os.path.expanduser(assert_list[0]) == assert_list[1]
        assert os.path.expandvars(assert_list[0]) == assert_list[1]


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:29:18.575420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Basic test for functioning of parse_env_file_contents
    assert list(parse_env_file_contents(['TEST=test'])) == [('TEST', 'test')]

    # Check if env var substitutions are applied
    assert list(parse_env_file_contents(['TEST=$PATH'])) == [('TEST', expand('$PATH'))]

    # Check if multiple env var substitutions are applied
    assert list(parse_env_file_contents(['TEST=$PATH:$PATH'])) == [('TEST', expand('$PATH:$PATH'))]

    # Check if env var substitutions are applied

# Generated at 2022-06-24 02:29:28.347009
# Unit test for function expand
def test_expand():
    # test tilde expansion, var expansion, and os.path.realpath
    os.environ['TEST_ENV_VAR'] = 'hello world'
    assert expand('~/a/file') == os.path.realpath('%s/a/file' % os.path.expanduser('~'))
    assert expand('${TEST_ENV_VAR}') == 'hello world'
    assert expand('${TEST_ENV_VAR}/another/file') == 'hello world/another/file'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:29:35.201007
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = list(parse_env_file_contents(lines))

    assert ('TEST', '${HOME}/yeee-$PATH') in result
    assert ('THISIS', '~/a/test') in result
    assert ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in result

# Generated at 2022-06-24 02:29:41.447759
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(lines=["PYTHONPATH=" + os.path.abspath(__file__)]) == [("PYTHONPATH", os.path.abspath(__file__))]

