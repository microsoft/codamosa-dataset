

# Generated at 2022-06-26 01:52:08.368812
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = ['TEST=${HOME}/yeee']
    str_1 = parse_env_file_contents(str_0)
    str_2 = expand(str_1)


# Generated at 2022-06-26 01:52:17.051458
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # CASE_0
    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    list_0 = list(parse_env_file_contents(lines_0))
    str_0 = '/home/'
    str_1 = '/home/'
    str_2 = os.path.basename(os.environ.get('HOME'))
    str_3 = os.environ.get('HOME')
    str_4 = os.path.basename(os.environ.get('HOME'))
    str_5 = os.environ.get('HOME')
    str_6 = os.environ.get('HOME')
    str_7

# Generated at 2022-06-26 01:52:27.518809
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    t_list = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_0 = {}
    dict_0 = load_env_file(t_list, dict_0)
    assert (dict_0.values() == ["/Users/pizzy/yeee", "/Users/pizzy/a/test", "/Users/pizzy/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])


# Generated at 2022-06-26 01:52:32.594109
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST = ${HOME}/yeee", "THISIS = ~/a/test", "YOLO = ~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    value_0 = parse_env_file_contents(lines)
    value_1 = next(value_0)
    assert value_1 == ('TEST', '.../yeee')
    value_1 = next(value_0)
    assert value_1 == ('THISIS', '.../a/test')
    value_1 = next(value_0)
    assert value_1 == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-26 01:52:42.794132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', '#this is a comment']

    test_load = list(parse_env_file_contents(lines))
    assert len(test_load) == 2
    assert test_load[0][0] == 'TEST'
    assert test_load[0][1] == '${HOME}/yeee'
    assert test_load[1][0] == 'THISIS'
    assert test_load[1][1] == '~/a/test'



# Generated at 2022-06-26 01:52:54.404745
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:53:01.272389
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    for index, item in enumerate(results):
        assert list(item) == expected[index], f'Error in test #{index + 1}'


# Generated at 2022-06-26 01:53:11.177318
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    r = parse_env_file_contents(lines)
    r = list(r)
    assert r == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    print('* passed sub test of parse_env_file_contents')


# Generated at 2022-06-26 01:53:15.273516
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(["TEST=$HOME/yeee"])) == [('TEST', '$HOME/yeee')]

# Generated at 2022-06-26 01:53:25.458336
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = "test_parse_env_file_contents.txt"
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    with open(filename, "w") as f:
        for line in lines:
            f.write(line)

    values = parse_env_file_contents(lines)

    kv_0 = next(values)
    k_0 = kv_0[0]
    v_0 = kv_0[1]

    assert (k_0 == "TEST")




# Generated at 2022-06-26 01:53:37.530462
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}', 'PATH=$HOME']
    data_dict = {}
    data_dict = load_env_file(lines)
    assert('TEST' in data_dict)
    assert('PATH' in data_dict)
    assert(type(data_dict) == type(collections.OrderedDict()))
    keys = list(data_dict.keys())
    assert(keys[0] == 'TEST')
    assert(keys[1] == 'PATH')
    assert(data_dict['TEST'] is not None)
    assert(data_dict['PATH'] is not None)
    assert(os.path.exists(data_dict['TEST']))
    assert(os.path.exists(data_dict['PATH']))
    # Home directory should be the same

# Generated at 2022-06-26 01:53:40.952572
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("test_parse_env_file_contents")

    lines = ["TEST=fu"]
    print(list(parse_env_file_contents(lines)))


# Generated at 2022-06-26 01:53:50.633509
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = list(parse_env_file_contents(lines))
    assert result == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:53:56.819798
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 01:54:05.001027
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [('TEST', '.../yeee'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Unit test for function load_env_file

# Generated at 2022-06-26 01:54:09.689806
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)


# Generated at 2022-06-26 01:54:11.080849
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True == True


# Generated at 2022-06-26 01:54:12.182622
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass


# Generated at 2022-06-26 01:54:20.515240
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_input = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_output = parse_env_file_contents(test_input)
    assert test_output == (('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 01:54:28.237520
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    files = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = list(parse_env_file_contents(files))
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert actual == expected, 'ERROR'



# Generated at 2022-06-26 01:54:40.839002
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    #print(result)
    result_test = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert result == result_test


# Generated at 2022-06-26 01:54:51.857943
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test case 1
    lines_1 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ans_1 = collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    res_1 = collections.OrderedDict(parse_env_file_contents(lines_1))
    assert f'{res_1}' == f'{ans_1}'



# Generated at 2022-06-26 01:55:00.859108
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)

    assert next(result) == ("TEST", "..." + "/yeee")
    assert next(result) == ("THISIS", "..." + "/a/test")
    assert next(result) == ("YOLO", "..." + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")


# Generated at 2022-06-26 01:55:06.327548
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    
    


# Generated at 2022-06-26 01:55:18.442277
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test empty string
    assert list(parse_env_file_contents([])) == []

    # Test valid values
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
             'YOLO=~/swaggins/$',
             'IS_VALID=YES',
             'WITH_SPACE=A SPACE',
             'WITH_QUOTE="A SPACE"',
             'WITH_QUOTE=\'A SPACE\'']

# Generated at 2022-06-26 01:55:27.894799
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee"])) == [('TEST', '.../yeee')]
    assert list(parse_env_file_contents(["TEST=~/yeee"])) == [('TEST', '.../yeee')]
    assert list(parse_env_file_contents(["TEST='${HOME}/ye=ee'"])) == [('TEST', '${HOME}/ye=ee')]
    assert list(parse_env_file_contents(["TEST=\"${HOME}/ye=ee\""])) == [('TEST', '${HOME}/ye=ee')]

# Generated at 2022-06-26 01:55:40.347022
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing parse_env_file_contents')
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-26 01:55:49.504416
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing function parse_env_file_contents()')

    # Test arguments
    expected: typing.Generator[typing.Tuple[str, str], None, None] = load_env_file(['BASEPATH=${HOME}/source_id_store', 'USER=~/a/test'])
    actual: typing.Generator[typing.Tuple[str, str], None, None] = parse_env_file_contents(['BASEPATH=${HOME}/source_id_store', 'USER=~/a/test'])

    assert expected == actual
    print('test_parse_env_file_contents() passed!')



# Generated at 2022-06-26 01:55:50.595053
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert isinstance(parse_env_file_contents(), collections.Iterable)



# Generated at 2022-06-26 01:55:59.351155
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert type(result) is typing.GeneratorType
    assert next(result) == ('TEST', '.../yeee')
    assert next(result) == ('THISIS', '.../a/test')
    assert next(result) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
