

# Generated at 2022-06-26 01:52:01.165463
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True



# Generated at 2022-06-26 01:52:04.294955
# Unit test for function load_env_file
def test_load_env_file():
    print("Testing function 'load_env_file'")
    test_case_0()  # test case #0
    print("Passed!")

"""
    Usage:
    python3 test_load_env_file.py
"""

# Generated at 2022-06-26 01:52:14.539754
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():  # Coverage is at 100%
    # Test case 0
    assert list(parse_env_file_contents(iter([]))) == []
    # Test case 1
    assert list(parse_env_file_contents(iter(["foo=bar"]))) == [("foo", "bar")]
    # Test case 2
    assert list(parse_env_file_contents(iter(["foo='bar'"]))) == [("foo", "bar")]
    # Test case 3
    assert list(parse_env_file_contents(iter(["foo=\"bar\""]))) == [("foo", "bar")]
    # Test case 4
    assert list(parse_env_file_contents(iter(["foo='bar=baz'"]))) == [("foo", "bar=baz")]
    # Test case 5
    assert list

# Generated at 2022-06-26 01:52:22.109893
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    generator_1 = parse_env_file_contents()
    assert iterator_to_list(generator_1) == []
    generator_2 = parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    result_2 = parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

# Generated at 2022-06-26 01:52:25.965141
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines)

# Generated at 2022-06-26 01:52:30.264895
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ)

# Generated at 2022-06-26 01:52:33.093420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for function parse_env_file_contents
    pass


# Generated at 2022-06-26 01:52:42.067634
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    generator_0 = parse_env_file_contents(lines)
    assert list(generator_0)[2][1] == "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-26 01:52:45.628727
# Unit test for function load_env_file
def test_load_env_file():
    d = load_env_file(("TEST=${HOME}/yeee","YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST","THISIS=~/a/test"))
    assert(d["TEST"] is not None)


# Generated at 2022-06-26 01:52:47.965842
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert str(type(parse_env_file_contents())) == "<class 'generator'>"

