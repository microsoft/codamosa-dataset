

# Generated at 2022-06-26 01:52:06.468620
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert 'foo' == next(parse_env_file_contents(('foo=1',)))[0]


# Generated at 2022-06-26 01:52:15.970219
# Unit test for function load_env_file
def test_load_env_file():
    if 'HOME' not in os.environ:
        os.environ['HOME'] = '/home'
    if 'PATH' not in os.environ:
        os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/bin/X11:/usr/games:/bin/vendor_perl'
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-26 01:52:24.520848
# Unit test for function load_env_file
def test_load_env_file():
    test_str = 'TEST=${HOME}/yeee-$PATH'
    os.environ['PATH'] = 'spam'
    os.environ['HOME'] = 'eggs'
    test_dict = {'TEST': 'eggs/yeee-spam'}
    assert load_env_file(test_str) == test_dict


test_case_0()
test_load_env_file()

# Generated at 2022-06-26 01:52:25.880533
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() == None


# Generated at 2022-06-26 01:52:36.286105
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    gen_0 = parse_env_file_contents([])
    list_0 = [str(x) for x in gen_0]
    assert list_0 == []
    gen_1 = parse_env_file_contents(['hello=world'])
    tuple_0 = next(gen_1)
    assert tuple_0[0] == 'hello'
    assert tuple_0[1] == 'world'
    gen_2 = parse_env_file_contents(['hello=world\\'])
    tuple_1 = next(gen_2)
    assert tuple_1[0] == 'hello'
    assert tuple_1[1] == 'world\\'
    gen_3 = parse_env_file_contents(['hello=\'world\\\''])
    tuple_2 = next(gen_3)
   

# Generated at 2022-06-26 01:52:42.368714
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'utf-8'
    generator_0 = parse_env_file_contents(str_0)

    assert generator_0 != ""

test_parse_env_file_contents()


# Generated at 2022-06-26 01:52:43.793542
# Unit test for function load_env_file
def test_load_env_file():
    assert callable(load_env_file)



# Generated at 2022-06-26 01:52:50.612569
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    number_0 = 'utf-8'
    generator_0 = parse_env_file_contents(number_0)
    str_0 = 'u4'
    str_1 = 'u4'
    str_2 = "'"
    str_3 = 'u4'
    str_4 = "'"
    tuple_0 = (str_2, str_3, str_4)
    assert not hasattr(generator_0, str_0)
    assert not hasattr(generator_0, str_1)
    assert tuple_0 == tuple(generator_0)
    number_0 = 'utf-8'
    generator_0 = parse_env_file_contents(number_0)
    str_0 = 'u4'
    str_1 = 'u4'
    str_2 = '"'


# Generated at 2022-06-26 01:52:53.043459
# Unit test for function load_env_file
def test_load_env_file():
    lines = []
    mapping_0 = os.environ
    dict_0 = load_env_file(lines, mapping_0)


# Generated at 2022-06-26 01:52:54.130915
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_case_0()




# Generated at 2022-06-26 01:53:06.642777
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Check that TypeError is raised when argument is of wrong type
    with pytest.raises(TypeError):
        generator_0 = parse_env_file_contents(1.1)
    # Check that TypeError is raised when argument is of wrong type
    with pytest.raises(TypeError):
        generator_1 = parse_env_file_contents(2)
    # Check that TypeError is raised when argument is of wrong type
    with pytest.raises(TypeError):
        generator_2 = parse_env_file_contents("")
    # Check that TypeError is raised when argument is of wrong type
    with pytest.raises(TypeError):
        generator_3 = parse_env_file_contents(2.2)
    # Check that TypeError is raised when argument is of wrong type

# Generated at 2022-06-26 01:53:13.319859
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print ("Testing parse_env_file_contents()")
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = os.environ
    environ = load_env_file(lines, write_environ)
    print(environ)
    print ("Parsing complete")
    print ()


# Generated at 2022-06-26 01:53:24.507418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    _env = [
        'SOME=TEST',
        'TEST="double qoute"',
        'TEST_SINGLE="single"',
        'TEST_EMPTY=',
        'PATH=$HOME',
        'PATH_EMPTY=$HOME'
    ]
    _file = StringIO('\n'.join(_env))
    _dict = parse_env_file_contents(_file)
    _dict = collections.OrderedDict(_dict)
    assert len(_dict) == 6
    assert _dict['SOME'] == 'TEST'
    assert _dict['TEST'] == 'double qoute'
    assert _dict['TEST_SINGLE'] == 'single'
    assert _dict['TEST_EMPTY'] == ''

# Generated at 2022-06-26 01:53:32.432898
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:53:40.122193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_output = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines = [lines[0] + '\n', lines[1] + '\n', lines[2]]

    output = parse_env_file_contents(lines)
    output = list(output) # get rid of generator object

    assert output == expected_output


# Generated at 2022-06-26 01:53:44.582504
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = ["TEST=$HOME/yeee"]
    result = parse_env_file_contents(content)
    for item in result:
        print(item)


if __name__ == "__main__":
    test_case_0()
    test_parse_env_file_contents()

# Generated at 2022-06-26 01:53:57.217068
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    keys = []
    values = []
    for k, v in parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']):
        keys.append(k)
        values.append(v)
    assert keys == ['TEST', 'THISIS', 'YOLO']
    assert isinstance(values[0], str)
    assert isinstance(values[1], str)
    assert isinstance(values[2], str)
    assert '...' in values[0]


# Generated at 2022-06-26 01:53:59.028739
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with pytest.raises(TypeError):
        parse_env_file_contents(None)


# Generated at 2022-06-26 01:53:59.923670
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True


# Generated at 2022-06-26 01:54:04.293264
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    generator_0 = parse_env_file_contents(lines)
    assert next(generator_0) == ('TEST', '${HOME}/yeee')
    assert next(generator_0) == ('THISIS', '~/a/test')
    assert next(generator_0) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    with pytest.raises(StopIteration):
        next(generator_0)


# Generated at 2022-06-26 01:54:11.820150
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = [f'pjU={str_1}']
    # parse_env_file_contents(lines_0)



# Generated at 2022-06-26 01:54:20.295354
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Inject a
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:54:21.643428
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    list_0 = [expand('FYO=QQ')]

    output = parse_env_file_contents(list_0)


# Generated at 2022-06-26 01:54:25.322502
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing function parse_env_file_contents')
    lines = ['HOME=/home/yoloswag', 'HOME=/root/yoloswag']
    parse_env_file_contents(lines)


# Generated at 2022-06-26 01:54:31.507028
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Assert all of the arguments are right
    assert test_parse_env_file_contents.__annotations__ == typing.get_type_hints(parse_env_file_contents)
    lines_0 = ['pjU=pjU', 'pjU=pjU']
    res_0 = collections.Counter(parse_env_file_contents(lines_0))
    assert len(res_0) == 1
    assert res_0 == collections.Counter([('pjU', 'pjU')])


# Generated at 2022-06-26 01:54:35.207022
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: Write tests for parse_env_file_contents
    assert False, "TODO: Write tests for parse_env_file_contents"


# Generated at 2022-06-26 01:54:47.267943
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_str = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parser_ret = parse_env_file_contents(file_str)

    test_0 = next(parser_ret)
    assert(test_0[0] == 'TEST')
    assert(test_0[1] == '${HOME}/yeee-$PATH')

    test_1 = next(parser_ret)
    assert(test_1[0] == 'THISIS')
    assert(test_1[1] == '~/a/test')

    test_2 = next(parser_ret)
    assert(test_2[0] == 'YOLO')

# Generated at 2022-06-26 01:54:57.588963
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual_result = parse_env_file_contents(lines)
    expected_result = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for actual, expected in zip(actual_result, expected_result):
        assert actual == expected


# Generated at 2022-06-26 01:55:05.356362
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines, write_environ=dict())

    assert '~' in res['TEST']
    assert res['TEST'].endswith('/yeee')
    assert res['THISIS'].endswith('/a/test')
    assert '~' in res['THISIS']
    assert res['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

if __name__ == '__main__':
    test_case_0()
    test_parse_env_file

# Generated at 2022-06-26 01:55:13.532727
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing whether parse_env_file_contents throws any exception
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    try:
        output = parse_env_file_contents(lines)
        typed_output = typing.cast(typing.Tuple[str, str], output)
    except Exception:
        print("Threw exception parsing env file")


# Generated at 2022-06-26 01:55:23.103990
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from hypothesis import given
    from hypothesis.strategies import lists, text

    @given(lists(text()))
    def test_parse_env_file_contents_1(lines: typing.List[str]) -> None:
        results = list(parse_env_file_contents(lines))
        print(results)
        #assert len(results) == len(lines)

    test_parse_env_file_contents_1()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:55:29.465107
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Simple assertion
    assert('test', '${HOME}/yeee-$PATH') in parse_env_file_contents('TEST=${HOME}/yeee-$PATH'.splitlines())

    # Simple assertion
    assert('test', '${HOME}/yeee-$PATH') in parse_env_file_contents(['TEST=${HOME}/yeee-$PATH'])

    # Simple assertion
    assert('thisis', '~/a/test') in parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test'])

    # Simple assertion

# Generated at 2022-06-26 01:55:40.392143
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_case = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    results = parse_env_file_contents(test_case)

    assert(next(results) == ('TEST', '.../yeee'))
    assert(next(results) == ('THISIS', '.../a/test'))
    assert(next(results) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 01:55:50.938034
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines, write_environ=dict())
    assert out['TEST'] == '${HOME}/yeee'
    assert out['THISIS'] == '~/a/test'
    assert out['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    # 2

# Generated at 2022-06-26 01:55:59.641774
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert lines[0] == 'TEST=${HOME}/yeee'
    assert lines[1] == 'THISIS=~/a/test'
    assert lines[2] == 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:56:05.727785
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    example_0 = 'pjU'
    expected_0 = [('pjU', '${HOME}/yeee-$PATH')]
    expected_0 = sorted(expected_0)
    assert expected_0 == parse_env_file_contents(example_0)

if __name__ == '__main__':
    test_case_0()
    test_parse_env_file_contents()

# Generated at 2022-06-26 01:56:07.747303
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents([])
    assert result == []


# Generated at 2022-06-26 01:56:16.650052
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    '''
    This function tests if the right output is being generated.
    '''
    lines = ['FOO=BAR', 'BAZ=ZIG']
    assert next(parse_env_file_contents(lines)) == ('FOO', 'BAR'), 'Error: parse_env_file_contents is returning incorrectly.'
    assert next(parse_env_file_contents(lines)) == ('BAZ', 'ZIG'), 'Error: parse_env_file_contents is returning incorrectly.'
    try:
        next(parse_env_file_contents(lines))
    except StopIteration:
        pass
    else:
        assert False, 'Error: parse_env_file_contents not generating StopIteration.'



# Generated at 2022-06-26 01:56:19.803677
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'TEST=~/yeee-$PATH'
    iterable_0 = [str_0]
    generator_0 = parse_env_file_contents(iterable_0)
    next(generator_0)


# Generated at 2022-06-26 01:56:31.896033
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    TEST_0 = ""
    arr_0 = []
    for i in parse_env_file_contents([TEST_0]):
        arr_0.append(i)
    assert arr_0 == [], "test 0 failed"

    TEST_1 = "TEST=$HOME/yeee"
    arr_1 = []
    for i in parse_env_file_contents([TEST_1]):
        arr_1.append(i)
    assert arr_1 == [('TEST', '.../yeee')], "test 1 failed"

    TEST_1 = "TEST=/home/kevvyf/yeee"
    arr_1 = []
    for i in parse_env_file_contents([TEST_1]):
        arr_1.append(i)
    assert arr_1

# Generated at 2022-06-26 01:56:41.578832
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines, write_environ=dict())
    assert ret == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:56:50.032296
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)

    for line in res:
        pass

    lines = ['TEST=\'${HOME}/yeee-$PATH\'']
    res = parse_env_file_contents(lines)

    for line in res:
        pass


# Generated at 2022-06-26 01:56:55.873395
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    gen = parse_env_file_contents(lines)
    for i in gen:
        print(i)


# Generated at 2022-06-26 01:57:06.384803
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with the following inputs:
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Expected output: ['.../.../yeee-...:...', '.../a/test', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)

# Generated at 2022-06-26 01:57:10.300541
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True


# Generated at 2022-06-26 01:57:23.560408
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    str_0 = 'pjU'
    str_1 = '$'
    item_0 = str_0 + str_1

    str_2 = 'MMM'
    item_1 = item_0 + ':' + str_2

    str_3 = './'
    item_2 = str_3 + item_1

    str_4 = '~'
    item_3 = str_4 + '/' + item_2

    str_5 = 'HOME'
    str_6 = 'Y'
    str_7 = 'PATH'
    str_8 = 'a'
    str_9 = '${'
    str_10 = 'b'
    str_11 = str_9 + str_10 + '}'
    str_12 = str_8 + str_11
    str_13 = '$'


# Generated at 2022-06-26 01:57:33.727685
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret_val = load_env_file(lines, write_environ=dict())

    assert ret_val == collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:57:45.771380
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["a=${HOME}/yeee", "b=~/a/test", "c=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    generator = parse_env_file_contents(lines)

    a_1, b_1, c_1 = next(generator)
    a_2, b_2, c_2 = next(generator)
    a_3, b_3, c_3 = next(generator)

    assert (a_1, b_1, c_1) == ('a', '${HOME}/yeee', None)
    assert (a_2, b_2, c_2) == ('b', '~/a/test', None)

# Generated at 2022-06-26 01:57:57.318274
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    results = load_env_file(lines, write_environ=environ)
    assert results == OrderedDict([('TEST', '.../yeee'), 
        ('THISIS', '.../a/test'), 
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]), "Dict not what was expected or returned"

    # Test to make sure that lines with # are not considered

# Generated at 2022-06-26 01:58:05.433726
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open('./test/test_env_file.txt', 'r') as f:
        lines = f.readlines()
    vals = parse_env_file_contents(lines)

    ret = []
    for v in vals:
        ret.append(v)

    exp = [('TEST', '~/yeee-/usr/bin:/usr/local/bin:/usr/bin:/bin'),
           ('THISIS', '~/a/test'),
           ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert ret == exp



# Generated at 2022-06-26 01:58:22.221008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Create example file contents
    file_contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ_dict = load_env_file(file_contents)
    for key, value in parse_env_file_contents(file_contents):
        try:
            assert value == environ_dict[key]
        except:
            print("FAILED ON: ")
            print(key, value)
            print(environ_dict[key])
            raise


# Generated at 2022-06-26 01:58:30.635770
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = dict(parse_env_file_contents(lines=lines))
    assert result['TEST'].split('/')[-1] == 'yeee'
    assert result['THISIS'].split('/')[-1] == 'test'
    assert result['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:58:31.610656
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True == False



# Generated at 2022-06-26 01:58:37.556559
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    #assert list(parse_env_file_contents(lines)) == list(parse_env_file_contents(lines))
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:58:44.779092
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('\n*** Test ***\n')
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_case_0()
    test_parse_env_file_contents()

# Generated at 2022-06-26 01:58:55.540918
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
        actual = load_env_file(lines, write_environ=dict())
        assert actual == expected
    except AssertionError as e:
        print("test_parse_env_file_contents failed.")
        print("Actual: " + str(actual))
        print("Expected: " + str(expected))
        raise e

# Generated at 2022-06-26 01:58:59.609774
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-PATH', 'THISIS=~/a/test-$PATH', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    # print(result)


# Generated at 2022-06-26 01:59:04.618771
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['A1=B1',
             'A2=B2',
             'A3=B3']
    testing_data = {'A1': 'B1',
                    'A2': 'B2',
                    'A3': 'B3'}
    res = {k:v for k, v in parse_env_file_contents(lines)}
    assert res == testing_data


# Generated at 2022-06-26 01:59:05.999400
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    unit = False

    m = parse_env_file_contents()



# Generated at 2022-06-26 01:59:17.052417
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_ut_1 = collections.OrderedDict(parse_env_file_contents(lines))
    assert expected_ut_1 == collections.OrderedDict([('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-26 01:59:42.903160
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing strings
    test_string_0 = 'TEST=$HOME/yeee-$PATH'
    test_string_1 = 'THISIS=~/a/test'
    test_string_2 = 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    test_string_3 = 'FOO=bar'
    test_string_4 = 'NO_EQUALS_SIGN'
    test_string_5 = 'SPACE = '

    # Testing values
    test_value_0 = '.../.../yeee-...:...'
    test_value_1 = '.../a/test'
    test_value_2 = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-26 01:59:53.983522
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    print('')
    print('Testing')
    print('====================')
    print('')
    test_case_0()
    test_parse_env_file_contents()

# Generated at 2022-06-26 02:00:06.952319
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    import io
    import os

    # Test 0:
    # Mock up an "env file" with some key/value pairs.
    s_0 = io.StringIO('A=1\\nB=2\\nC=3')
    d_0 = parse_env_file_contents(s_0)
    d_0_expected = {'A': '1', 'B': '2', 'C': '3'}
    d_0_test = dict(d_0)
    assert d_0_expected == d_0_test

    # Test 1:
    # Make sure values are properly expanded.

# Generated at 2022-06-26 02:00:16.581833
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert lines == ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-26 02:00:21.054153
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = ('p', 'x')
    result = next(parse_env_file_contents(('p=x',)))
    assert result == expected

    expected = ('a', 'x')
    result = next(parse_env_file_contents(('a=x',)))
    assert result == expected



# Generated at 2022-06-26 02:00:32.342666
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file_result = load_env_file(lines, write_environ=dict())
    expected_result = collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert(load_env_file_result == expected_result)

# Generated at 2022-06-26 02:00:41.416372
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import StringIO

    capturedOutput = StringIO.StringIO()
    sys.stdout = capturedOutput

    str_2 = 'BUG=${BUG}'
    str_3 = 'BUG_FILE=${BUG_FILE}'

    real_stdout = sys.stdout
    for line in parse_env_file_contents((str_2, str_3)):
        real_stdout.write(line)
    sys.stdout = real_stdout

    assert(capturedOutput.getvalue() == str_2+'\n'+str_3+'\n')


# Generated at 2022-06-26 02:00:52.089835
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    obj_0 = load_env_file(['TEST=${HOME}/yeee'])
    obj_1 = load_env_file(['THISIS=~/a/test'])
    obj_2 = load_env_file(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert str(obj_0).replace(" ", "").replace("\n", "") == 'OrderedDict([("TEST",".../yeee")])'
    assert str(obj_1).replace(" ", "").replace("\n", "") == 'OrderedDict([("THISIS",".../a/test")])'

# Generated at 2022-06-26 02:01:02.654391
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        '#aaa=123',
        '#aaa=123',
        'aa=123',
        'aa=${HOME}',
        'aa="123"',
        'aa=\'123\'',
        'aa=\'\'\'123\'\'\'',
        'aa=\'\'\'123"4\'\'\'',
        'aa=123\'\'\'4\'\'\'',
        'aa=123"4',
        'aa="123\'',
        'aa=\'123"',
    ]


# Generated at 2022-06-26 02:01:07.401278
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_0 = load_env_file(lines, write_environ=dict())
    print(dict_0)


# Generated at 2022-06-26 02:01:41.625090
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [
        ('GITHUB_USER', 'jeffbaumes'),
        ('PASSWORD', 'jdsuisgdaubidshg')
    ]
    assert list(parse_env_file_contents(['GITHUB_USER=jeffbaumes', 'PASSWORD=jdsuisgdaubidshg'])) == expected

    file_path_0 = 'test/test_env.txt'
    with open(file_path_0, 'r') as f:
        assert list(parse_env_file_contents(f)) == expected


# Generated at 2022-06-26 02:01:52.576387
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open('test_file.txt') as file:
        lines = [line[:-1] for line in file]
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 02:01:58.814845
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # create testing variables
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # call the tested function
    result = parse_env_file_contents(lines)

    # check if the result is as expected
    assert result == [('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 02:02:06.321914
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    pass
