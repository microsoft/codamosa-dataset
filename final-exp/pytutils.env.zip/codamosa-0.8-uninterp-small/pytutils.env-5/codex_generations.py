

# Generated at 2022-06-26 01:52:08.727018
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../.../a/test'),
             ('YOLO',
              '.../.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-26 01:52:16.563309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert isinstance(result, collections.abc.Generator)
    answer = [(('TEST', '.../yeee'),), (('THISIS', '.../a/test'),), (('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),)]
    for g, a in zip(result, answer):
        assert g == a


# Generated at 2022-06-26 01:52:26.733973
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = OrderedDict([('TEST', '.../yeee'),
                            ('THISIS', '.../a/test'),
                            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    actual = parse_env_file_contents(lines)
    assert actual == expected


# Generated at 2022-06-26 01:52:29.061466
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents()
    assert "lazy" in result
    assert "lazy" in result


# Generated at 2022-06-26 01:52:32.538162
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '~/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]


# Generated at 2022-06-26 01:52:36.881647
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:52:46.930948
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert __salt__['kiwi_helper.load_env_file'](lines) == {
        'TEST': '.../.../yeee-...:...',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }


# Generated at 2022-06-26 01:52:56.480676
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Test that generator returns expected values
    assert expected == list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))


# Generated at 2022-06-26 01:53:08.158886
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing function: parse_env_file_contents', end='')

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    od_0 = parse_env_file_contents(lines)
    dict_0 = dict(od_0)

    assert dict_0['TEST'] == expand('${HOME}/yeee')
    assert dict_0['THISIS'] == expand('~/a/test')
    assert dict_0['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    print('  Passed!')



# Generated at 2022-06-26 01:53:15.268330
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    assert result == OrderedDict([('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:53:26.206787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected_0 = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines_0 = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    observed_0 = list(parse_env_file_contents(lines_0))
    assert observed_0 == expected_0


# Generated at 2022-06-26 01:53:28.839250
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() # Type hinting fails here. 
    assert parse_env_file_contents() == None # Generator should produce None.



# Generated at 2022-06-26 01:53:30.314391
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True


# Generated at 2022-06-26 01:53:39.217678
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename_0 = os.path.join(os.path.dirname(__file__), 'fixtures', 'example.env')

    
    lines_0 = [f'TEST={filename_0}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_return_0 = [('TEST', '.../fixtures/example.env'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    actual_return_0 = parse_env_file_contents(lines_0)

    print("Return value: "+str(actual_return_0))
    assert actual_return

# Generated at 2022-06-26 01:53:52.505526
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    wanted_0 = collections.OrderedDict(
        [
            ("TEST", "{HOME}/yeee"),
            ("THISIS", "~/a/test"),
            ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
        ]
    )
    res_0 = parse_env_file_contents(lines);


# Generated at 2022-06-26 01:54:00.548763
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('\n * test_parse_env_file_contents')

    try:
        lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        parse_env_file_contents(lines)
    except Exception as e:
        print('test_parse_env_file_contents [Error - Expected]: ', e)


# Generated at 2022-06-26 01:54:06.495563
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_name = 'test.env'
    f = open(file_name, 'w')
    contents = """TEST2=${HOME}/yeee"""
    f.write(contents)
    f.close()
    with open(file_name) as f:
        lines = (line.strip() for line in f)

    expected = [('TEST2', '/Users/brian/yeee')]
    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-26 01:54:12.986074
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = parse_env_file_contents(lines)

    # Assert that the returned value matches what we expected
    assert ret == (('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 01:54:14.888388
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert next(test_case_0) == None

test_parse_env_file_contents()



# Generated at 2022-06-26 01:54:19.967193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()).keys() == ['TEST', 'THISIS', 'YOLO']


# Generated at 2022-06-26 01:54:27.287158
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    s = b"""
TEST=${HOME}/yeee ${PATH}
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    lines = str(s).splitlines()

    values = parse_env_file_contents(lines)
    changes = load_env_file(lines, write_environ=dict())

    pprint(changes)


# Generated at 2022-06-26 01:54:34.654488
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:54:39.865234
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:54:44.602456
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:54:56.932733
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # AssertionError: AssertionError: 3 == 2
    _input_str = "parse_env_file_contents() did not return the expected number of lines"
    _expected_str = '2'
    _actual_str = '3'
    assert int(_expected_str) == int(_actual_str), '{0}\nExpected: {1}\nActual: {2}'.format(_input_str, _expected_str, _actual_str)

    _input_str = "parse_env_file_contents() did not return the expected number of lines"
    _expected_str = '2'
    _actual_str = '3'

# Generated at 2022-06-26 01:55:05.095351
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([]) == iter(())
    assert list(parse_env_file_contents(['THIS=is=a=test'])) == [('THIS', 'is=a=test')]
    assert list(parse_env_file_contents(['THIS=is a test'])) == [('THIS', 'is a test')]

# Generated at 2022-06-26 01:55:17.073701
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = load_env_file(lines, write_environ=dict())
    assert_equal(result, collections.OrderedDict([('TEST', '${HOME}/yeee'),
                                                  ('THISIS', '~/a/test'),
                                                  ('YOLO',
                                                   '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]))

    result = load_env_file(lines)

# Generated at 2022-06-26 01:55:25.949279
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Tests for function parse_env_file_contents
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:55:37.508792
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert expand('') == ''
    assert expand('$HOME') == '/Users/jason'
    assert expand('$PATH') == '/Users/jason/anaconda3/bin:/Users/jason/anaconda3/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/Library/TeX/texbin:/opt/X11/bin:/Applications/Wireshark.app/Contents/MacOS'
    assert expand('${HOME}') == '/Users/jason'
    assert expand('$HOME/.bashrc') == '/Users/jason/.bashrc'
    assert expand('${HOME}/.bashrc') == '/Users/jason/.bashrc'
    assert expand('${HOME}/yeee') == '/Users/jason/yeee'
    assert expand('${HOME}-$PATH')

# Generated at 2022-06-26 01:55:41.012909
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test using doctest
    # TODO: add more tests
    lines = ['TEST=${HOME}/yeee']
    parse_env_file_contents(lines)


# Generated at 2022-06-26 01:55:44.260035
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass



# Generated at 2022-06-26 01:55:51.722230
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert collections.OrderedDict(parse_env_file_contents(lines)) == collections.OrderedDict(
        [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:56:01.296174
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_1 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res_1 = list(parse_env_file_contents(test_1))
    test_2 = [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert res_1 == test_2


# Generated at 2022-06-26 01:56:12.385959
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test that it correctly parses empty lines
    assert list(parse_env_file_contents([''])) == []
    assert list(parse_env_file_contents([
        '',
        'HOWDY=  '
    ])) == [('HOWDY', '  ')]

    # Test that it correctly parses lines
    assert list(parse_env_file_contents(['HOWDY=123'])) == [('HOWDY', '123')]
    assert list(parse_env_file_contents([' HOWDY=123 '])) == [('HOWDY', '123')]

    # Test that it ignores lines that aren't valid assignments
    assert list(parse_env_file_contents(['123'])) == []

# Generated at 2022-06-26 01:56:18.558929
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Dict {str: str}
    lines = dict()
    lines['HELP'] = '£$%^'
    lines['HELP2'] = '£$%^'
    lines['HELP3'] = '£$%^'
    assert list(parse_env_file_contents(lines)) == list()

    # Dict {str: str}
    lines = dict()
    tmp = list()
    tmp.append('BAR = Foo')

    assert list(parse_env_file_contents(tmp)) == [('BAR', 'Foo')]



# Generated at 2022-06-26 01:56:30.233373
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    got = parse_env_file_contents(lines)
    want = [('TEST', expand('${HOME}/yeee')),
            ('THISIS', expand('~/a/test')),
            ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]

    for g in got:
        if g not in want:
            print(f'Got {g} which was not in want.')
            return False

    return True



# Generated at 2022-06-26 01:56:38.670860
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:56:47.352474
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert expand(
        '${HOME}') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('~/yo') == os.path.expanduser('~/yo')
    assert expand('~/yo/') == os.path.expanduser('~/yo/')

    # TODO: Fix this
    # assert expand(
    #     '~/yo/yo') == os.path.expanduser('~/yo/yo')



# Generated at 2022-06-26 01:56:58.938161
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    testfile_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    testfile_lines_gen = parse_env_file_contents(testfile_lines)

    # Tests that the key-value pairs are generated in order
    testfile0_key = 'TEST'
    testfile0_val = '${HOME}/yeee'
    testfile0_tup = (testfile0_key, testfile0_val)
    assert next(testfile_lines_gen) == testfile0_tup

    testfile1_key = 'THISIS'
    testfile1_val = '~/a/test'
    testfile1_tup

# Generated at 2022-06-26 01:57:06.705249
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    f = parse_env_file_contents
    actual = list(f(lines))

    assert expected == actual


# Generated at 2022-06-26 01:57:11.016724
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True

# Generated at 2022-06-26 01:57:16.866430
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 01:57:25.634305
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    val = parse_env_file_contents(lines)
    assert val == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

test_case_0()
test_parse_env_file_contents()


# Generated at 2022-06-26 01:57:34.548096
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert result == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:57:45.802946
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Test: parse_env_file_contents"""
    func = parse_env_file_contents
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines, write_environ=dict())
    assert out == {'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'THISIS': '.../a/test', 'TEST': '.../yeee'}
    #
    # check failed for {'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_

# Generated at 2022-06-26 01:57:55.179130
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = dict(parse_env_file_contents(lines))

    assert results['TEST'] == '.../.../yeee'
    assert results['THISIS'] == '.../a/test'
    assert results['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-26 01:58:05.177242
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    From honcho.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """


# Generated at 2022-06-26 01:58:18.514132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_contents = ['\n', '\n', 'export TEST=${HOME}/yeee\n', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    truth = {'TEST': '/home/jacob/yeee', 'YOLO': '/home/jacob/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'THISIS': '/home/jacob/a/test'}
    res = parse_env_file_contents(file_contents)
    res_dict = {}
    # !TODO: Add how this is getting used to docs.
    for key, val in res:
        res_dict[key] = val
   

# Generated at 2022-06-26 01:58:25.795829
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Tested with lines from the "Example¶" section of the sources.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines)

    for key, value in results.items():
        if key == 'TEST':
            assert value
        elif key == 'THISIS':
            assert value
        elif key == 'YOLO':
            assert value



# Generated at 2022-06-26 01:58:30.263342
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(list(parse_env_file_contents(lines)))


# Generated at 2022-06-26 01:58:48.835076
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        "YOLO='~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}'",
        'DONE="~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}"'
    ]
    d = load_env_file(lines)
    assert isinstance(d, collections.OrderedDict), type(d)
    assert d['TEST'].endswith('yeee-')
    assert d['TEST'].startswith(os.path.expanduser('~'))
    assert d['THISIS'].endswith('a/test')

# Generated at 2022-06-26 01:58:56.394302
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([]) == iter([])
    assert parse_env_file_contents(['foo']) == iter([])
    assert parse_env_file_contents([
        'foo=bar',
    ]) == iter([
        ('foo', 'bar'),
    ])
    assert parse_env_file_contents([
        'foo=bar',
        'fizz=buzz',
    ]) == iter([
        ('foo', 'bar'),
        ('fizz', 'buzz'),
    ])



# Generated at 2022-06-26 01:58:58.760150
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(None) == iter(())
    assert parse_env_file_contents(iter(())) == iter(())



# Generated at 2022-06-26 01:59:05.154798
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    actual = parse_env_file_contents(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    expected = OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert actual == expected


# Generated at 2022-06-26 01:59:16.898667
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THING=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [
        ('TEST', '/.../yeee'),
        ('THING', '/.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    actual = [(key, expand(val)) for key, val in parse_env_file_contents(lines)]

    assert actual == expected


# Generated at 2022-06-26 01:59:21.818786
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    r = parse_env_file_contents(lines)
    assert len(list(r)) == 3


# Generated at 2022-06-26 01:59:28.536960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # >>> load_env_file(lines, write_environ=dict())
    # OrderedDict([('TEST', '.../yeee'),
    #          ('THISIS', '.../a/test'),
    #          ('YOLO',
    #           '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert 0


# Generated at 2022-06-26 01:59:37.468993
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([]) == []
    assert list(parse_env_file_contents(['TEST=$HOME/yeee', 'YOLO=a/test'])) == [('TEST', '.../yeee'), ('YOLO', 'a/test')]
    assert list(parse_env_file_contents(['TEST=~/yeee', 'YOLO=a/test'])) == [('TEST', '.../yeee'), ('YOLO', 'a/test')]

# Generated at 2022-06-26 01:59:46.601409
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = []
    expected_0 = []
    result_0 = list(parse_env_file_contents(lines_0))
    assert expected_0 == result_0

    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_0 = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]
    result_0 = list(parse_env_file_contents(lines_0))
    assert expected_

# Generated at 2022-06-26 01:59:47.789273
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True
