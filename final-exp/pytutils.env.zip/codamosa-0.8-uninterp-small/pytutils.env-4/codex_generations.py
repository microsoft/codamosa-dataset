

# Generated at 2022-06-26 01:52:01.546993
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True, "Failure"


# Generated at 2022-06-26 01:52:11.908643
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert next(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == ('TEST', '.../yeee')
    assert next(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == ('THISIS', '.../a/test')

# Generated at 2022-06-26 01:52:18.906228
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True
    # lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # assert load_env_file(lines, write_environ=dict()) == OrderedDict({'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_

# Generated at 2022-06-26 01:52:28.883814
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = ['TEST', 'THISIS', 'YOLO']
    actual = []
    for key, val in parse_env_file_contents(lines):
        actual.append(key)
        assert(expand(val) == val)

    assert(len(actual) == 3)

    for i in range(3):
        assert(actual[i] == expected[i])


# Generated at 2022-06-26 01:52:41.839452
# Unit test for function load_env_file
def test_load_env_file():
    print("Testing function load_env_file...")

    # TEST CASE 1 (values are read in by the program and tested
    #              to see that they are interpreted correctly.
    #              in this case they are written to a dictionary
    #              and printed)
    print("\nTesting case 1")
    lines = ['TEST=${HOME}/yeee-$PATH','THISIS=~/a/test','YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    value = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-26 01:52:45.440056
# Unit test for function load_env_file
def test_load_env_file():
    arg_0 = test_case_0()
    arg_1 = None
    assert load_env_file(arg_0, arg_1) == None, 'The function did not return the expected value'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 01:52:51.988964
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST_VAR=HELLO"]
    contents = parse_env_file_contents(lines)
    for c in contents:
        key, val = c
        if key == "TEST_VAR" and val == "HELLO":
            print("PASS")
            return
    assert False, "Test fail"


# Generated at 2022-06-26 01:53:00.796053
# Unit test for function load_env_file
def test_load_env_file():
    print('Test for function load_env_file.')
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    print('Expected: "OrderedDict([(\'TEST\', \'.../.../yeee-...:...\'), (\'THISIS\', \'.../a/test\'), (\'YOLO\', \'.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\')])"')
    print('Actual: ' + str(load_env_file(lines, write_environ=dict())))
    print()


# Generated at 2022-06-26 01:53:12.423004
# Unit test for function load_env_file
def test_load_env_file():

    test_lines = ["HELLO=world", "HERE=IAM", "=NOT", "NOT_HERE=", "=", "THIS_IS_A_TEST=this is a test",
                  "THAT_IS_A_TEST=that is a test"]
    expected = collections.OrderedDict()
    expected["HELLO"] = "world"
    expected["HERE"] = "IAM"
    expected["=NOT"] = ""
    expected["NOT_HERE"] = ""
    expected["="] = ""
    expected["THIS_IS_A_TEST"] = "this is a test"
    expected["THAT_IS_A_TEST"] = "that is a test"


# Generated at 2022-06-26 01:53:24.129799
# Unit test for function load_env_file
def test_load_env_file():
    # Test of correct types in automatic context
    # Test of correct values in automatic context
    lines = []
    write_environ = {}
    assert type(load_env_file(lines, write_environ)) == collections.OrderedDict
    if type(load_env_file(lines, write_environ)) == collections.OrderedDict:
        assert True
    # Test of correct types in automatic context
    # Test of correct values in automatic context
    lines = []
    write_environ = {}
    assert type(load_env_file(lines, write_environ)) == collections.OrderedDict
    if type(load_env_file(lines, write_environ)) == collections.OrderedDict:
        assert True
    # Test of correct types in automatic context
    # Test of correct values in automatic context

# Generated at 2022-06-26 01:53:36.637463
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test case with file contents of "TEST={HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_0 = parse_env_file_contents(lines)
    # Test cases with file contents of "TEST={HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"

# Generated at 2022-06-26 01:53:38.703202
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'If\\H9'
    ordered_dict_0 = parse_env_file_contents(str_0)
    print(ordered_dict_0)



# Generated at 2022-06-26 01:53:40.564285
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass


# Generated at 2022-06-26 01:53:50.155876
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert set(parse_env_file_contents(lines)) == {('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}


# Generated at 2022-06-26 01:53:51.986674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() == None


# Generated at 2022-06-26 01:54:02.623000
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    for i, (k, v) in enumerate(parse_env_file_contents(lines)):
        assert expected[k] == v

    print("Test passed")


# Generated at 2022-06-26 01:54:04.087422
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert len(parse_env_file_contents('If\\H9')) == 0

# Generated at 2022-06-26 01:54:19.643864
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'If\\H9'
    lines = [str_0]
    array_0 = []
    for line in lines:
        m1 = re.match(r'\A([A-Za-z_0-9]+)=(.*)\Z', line)
        if m1:
            key, val = m1, m1.group(1)
            m2 = re.match(r"\A'(.*)'\Z", val)
            if m2:
                val = m2.group(1)
            m3 = re.match(r'\A"(.*)"\Z', val)
            if m3:
                val = re.sub(r'\\(.)', r'\1', m3.group(1))
            if val is not None:
                tuple_0 = key, val


# Generated at 2022-06-26 01:54:23.287312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test case 0
    generator_0 = parse_env_file_contents()
    assert str(generator_0[0]) == 'TEST=/yeee'
    assert str(generator_0[1]) == 'THISIS=~/a/test'
    assert str(generator_0[2]) == 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:54:32.417771
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ordered_dict_0 = load_env_file(lines)

    assert ordered_dict_0.get('TEST') == os.environ.get('HOME') + '/yeee-' + os.environ.get('PATH')
    assert ordered_dict_0.get('THISIS') == os.environ.get('HOME') + '/a/test'
    assert ordered_dict_0.get('YOLO') == os.environ.get('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:54:36.312025
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert not parse_env_file_contents()


# Generated at 2022-06-26 01:54:41.541870
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    value_1 = ['']
    parse_env_file_contents_retval_1 = parse_env_file_contents(value_1)
    print('parse_env_file_contents_retval_1:', parse_env_file_contents_retval_1)



# Generated at 2022-06-26 01:54:51.354245
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    #  Parameters:
    #  - lines:
    #  - write_environ:

    #  Returns:
    #  - An ordered dict containing these values.
    str_1 = load_env_file(lines)
    assert str_1 == '.../.../yeee-...:...'

    #  - If `write_environ` is not None, then modify that mapping.


# Generated at 2022-06-26 01:54:52.718469
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # This is just a dummy test
    assert True == True


# Generated at 2022-06-26 01:54:54.616967
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        assert True
    except:
        Check.error("Test case 0 failed")


# Generated at 2022-06-26 01:55:02.878562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-26 01:55:15.096510
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    correct = collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    
    result = load_env_file(lines)
    
    for key in result:
        assert result[key] == correct[key]


if __name__ == "__main__":
    test_case_0()
#    test_parse_env_file

# Generated at 2022-06-26 01:55:15.733442
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True


# Generated at 2022-06-26 01:55:26.529965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Code coverage for function parse_env_file_contents

    # Test str, in range (0, 20)
    str_0 = 'AuVk$9e5c'
    iterator_0 = parse_env_file_contents(str_0)
    # Test tuple, size 2
    tuple_0 = (({'!', 'J', '>d3(~?&[I,', ','}), ({}))
    iterator_0 = parse_env_file_contents(tuple_0)
    # Test set, size 2
    set_0 = ({2, 1})
    iterator_0 = parse_env_file_contents(set_0)
    # Test list, size 2
    list_0 = [set(), str()]

# Generated at 2022-06-26 01:55:32.416949
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing function parse_env_file_contents")
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:55:36.820161
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert 0 == 0


# Generated at 2022-06-26 01:55:38.338328
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert 1 == 1


# Generated at 2022-06-26 01:55:43.733525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for function parse_env_file_contents
    assert parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'TEST=${HOME}/yeee', 'THISIS=~/a/test']) == ['YOLO', 'TEST', 'THISIS']

# Generated at 2022-06-26 01:55:45.415600
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    assert parse_env_file_contents() # returns None


# Generated at 2022-06-26 01:55:53.281816
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    str_0 = 'If\\H9'
    ordered_dict_0 = load_env_file(str_0)
    ordered_dict_1 = collections.OrderedDict(
        {'IfH9': ''},
    )
    assert ordered_dict_0 == ordered_dict_1

    # Test 2
    lines_0 = ['If\\H9']
    ordered_dict_0 = parse_env_file_contents(lines_0)

    ordered_dict_1 = collections.OrderedDict(
        {'IfH9': ''},
    )
    assert list(ordered_dict_0) == list(ordered_dict_1.items())

# Generated at 2022-06-26 01:56:03.287974
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert(parse_env_file_contents('TEST=${HOME}/yeee-$PATH') == '.../.../yeee-...:...')
    assert(parse_env_file_contents('THISIS=~/a/test') == '.../a/test')
    assert(parse_env_file_contents('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-26 01:56:13.824980
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def parse_env_file_contents_ref_0():
        list_0 = ['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        for str_0 in list_0:
            yield str_0

    list_0 = parse_env_file_contents(parse_env_file_contents_ref_0())
    assert len(list_0) == 1
    assert len(list_0[0]) == 2
    assert list_0[0] == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    # Checkpoint: Parse env file contents

# Generated at 2022-06-26 01:56:23.055630
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        assert isinstance(parse_env_file_contents(""), typing.Generator)
    except AssertionError:
        raise AssertionError("Test #1 failed: parse_env_file_contents("")")
    else:
        pass
    try:
        assert isinstance(parse_env_file_contents(""), typing.Generator)
    except AssertionError:
        raise AssertionError("Test #2 failed: parse_env_file_contents("")")
    else:
        pass
    try:
        assert isinstance(parse_env_file_contents(""), typing.Generator)
    except AssertionError:
        raise AssertionError("Test #3 failed: parse_env_file_contents("")")
    else:
        pass

# Generated at 2022-06-26 01:56:35.168003
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    ordered_dict_0 = collections.OrderedDict()
    ordered_dict_0['d'] = 'If\\H9'
    ordered_dict_0['@'] = 'If\\H9'
    ordered_dict_0['v'] = 'If\\H9'
    lines_0 = ['v=If\\H9', 'd=If\\H9', '@=If\\H9']
    assert list(parse_env_file_contents(lines_0)) == list(ordered_dict_0.items())
    lines_0 = ['d=If\\H9']
    ordered_dict_0 = collections.OrderedDict()
    ordered_dict_0['d'] = 'If\\H9'
    assert list(parse_env_file_contents(lines_0)) == list(ordered_dict_0.items())

# Generated at 2022-06-26 01:56:42.298519
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    source = '''
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''
    lines = source.split('\n')
    expected = [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]
    assert list(parse_env_file_contents(lines)) == expected


# Generated at 2022-06-26 01:56:54.468466
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    var = parse_env_file_contents(lines)
    assert var is not None


# Generated at 2022-06-26 01:57:01.015668
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # int_0 = getrandbits(1)
    ordered_dict_0 = load_env_file()
    ordered_dict_1 = load_env_file(ordered_dict_0)
    ordered_dict_2 = load_env_file(ordered_dict_0)


if __name__ == "__main__":
    test_case_0()
    #test_parse_env_file_contents()

# Generated at 2022-06-26 01:57:09.170935
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'j\\H'
    assert list(parse_env_file_contents(str_0)) == [('j', '\\H')]
    str_1 = ';uV@W$! N'
    assert list(parse_env_file_contents(str_1)) == [(';uV@W$!', 'N')]
    str_2 = 'Sn8,B'
    assert list(parse_env_file_contents(str_2)) == [('Sn8', 'B')]
    str_3 = 'r~#t\\B'
    assert list(parse_env_file_contents(str_3)) == [('r~#t\\', 'B')]
    str_4 = '[d5C5"H'

# Generated at 2022-06-26 01:57:22.107084
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for parsing environment files
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict([('TEST', '{0}/yeee'.format(os.environ['HOME'])),
             ('THISIS', '{0}/a/test'.format(os.environ['HOME'])),
             ('YOLO',
              '{0}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ['HOME']))])

    # Test for parsing valid and invalid lines

# Generated at 2022-06-26 01:57:31.240861
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = r'\A([A-Za-z_0-9]+)=(.*)\Z'
    str_1 = 'If\\H9'
    str_2 = 'If\\H9'
    parse_env_file_contents(str_2)

    print(os.environ)

    """
    unit test for function load_env_file
    """



# Generated at 2022-06-26 01:57:44.844465
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from unittest import TestCase
    from io import StringIO
    import contextlib

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected_keys = ['TEST', 'THISIS', 'YOLO']
    expected_values = [
        os.path.expandvars('${HOME}/yeee'),
        os.path.expanduser('~/a/test'),
        os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    @contextlib.contextmanager
    def test_for_stream(stream):
        gen = parse

# Generated at 2022-06-26 01:57:50.847699
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Given
    lines = ['FOO=BAR', 'BAZ=QUX']

    # When
    data = parse_env_file_contents(lines)

    # Then
    assert tuple([('FOO', 'BAR'), ('BAZ', 'QUX')]) == tuple(data)



# Generated at 2022-06-26 01:57:58.973854
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Case 0
    str_0 = '*'
    ordered_dict_0 = test_case_0()

    # Case 1
    ordered_dict_1 = load_env_file(['*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*'], write_environ=None)

    # Case 2
    ordered_dict_2 = load_env_file(['</'], write_environ=None)

    # Case 3
    ordered_dict_3 = load_env_file(['%c'], write_environ=None)

    # Case 4
    ordered_dict_4 = load_env_file(['_1'], write_environ=None)

    # Case 5
    ordered_

# Generated at 2022-06-26 01:58:03.131880
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    a = parse_env_file_contents(['a= "I am the best!"', 'b=I am the worst'])

    assert next(a) == ('a', 'I am the best!')
    assert next(a) == ('b', 'I am the worst')



# Generated at 2022-06-26 01:58:05.939908
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['If\\H9']
    var_mark_0 = parse_env_file_contents(lines)

# Generated at 2022-06-26 01:58:26.928633
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> test_parse_env_file_contents()
    True
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert result is not None
    return True


# Generated at 2022-06-26 01:58:35.876207
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["a=b", "c=\"d\"", "e='f'", "g='h\\'", "i='j'", "k='l'", "m='n\\", "o='p'", "q='r'", "s='t'", "u='v'", "w='x'", "y='z'"]
    out = collections.OrderedDict()
    out["a"] = "b"
    out["c"] = "d"
    out["e"] = "f"
    out["g"] = "h'"
    out["i"] = "j"
    out["k"] = "l"
    out["m"] = "n\\"
    out["o"] = "p"
    out["q"] = "r"
    out["s"] = "t"
    out["u"]

# Generated at 2022-06-26 01:58:41.186678
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    pass


# Generated at 2022-06-26 01:58:43.018303
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents == parse_env_file_contents


# Generated at 2022-06-26 01:58:49.867667
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        # Add a test line to test
        lines = "TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
        # Should work
        assert list(parse_env_file_contents(lines)) == list(parse_env_file_contents(lines))
    except AssertionError:
        raise AssertionError('Test case failed to parse env file successfully')



# Generated at 2022-06-26 01:59:00.034834
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    list_0 = ()
    list_1 = ()
    list_1 = load_env_file(list_0)
    assert tuple(list_1) == tuple(list_1)
    lines = []
    list_2 = ()
    list_3 = ()
    list_3 = load_env_file(list_2)
    assert tuple(list_3) == tuple(list_3)
    list_4 = (0,)
    list_5 = ()
    list_5 = load_env_file(list_4)
    assert tuple(list_5) == tuple(list_5)

# Generated at 2022-06-26 01:59:11.040732
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-26 01:59:22.453021
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    inp = ['test=']
    out = list(parse_env_file_contents(inp))
    correct_out = [('test', '')]

    # assert isinstance(out, collections.OrderedDict)
    assert out == correct_out

    inp = ['test=test', 'yolo=swag']
    out = list(parse_env_file_contents(inp))
    correct_out = [('test', 'test'), ('yolo', 'swag')]

    assert out == correct_out

    inp = ['this="yolo\\\\test"']
    out = list(parse_env_file_contents(inp))
    correct_out = [('this', 'yolo\\test')]

    assert out == correct_out


# Generated at 2022-06-26 01:59:23.776231
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() is not None


# Generated at 2022-06-26 01:59:29.135057
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)

# Generated at 2022-06-26 01:59:50.520509
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 01:59:59.287392
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from nose.tools import assert_equal
    from nose.tools import assert_is_instance
    from nose.tools import assert_raises
    from nose.tools import raises

    # Test 1
    str_0 = 'J1'
    list_0 = []
    list_1 = []
    list_1.append(str_0)
    list_1.append(str_0)
    assert_raises(TypeError, load_env_file, list_0)
    assert_equal(list_1, load_env_file(list_1))



# Generated at 2022-06-26 02:00:10.117360
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-26 02:00:19.888662
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == (('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 02:00:27.967758
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == OrderedDict([('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 02:00:31.125770
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test line: If\H9

    ordered_dict_0 = load_env_file_contents()

# Generated at 2022-06-26 02:00:35.142476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'W\\zv'
    list_0 = [str_0]
    ordered_dict_0 = load_env_file(list_0)
    print(ordered_dict_0)


test_case_0()
test_parse_env_file_contents()

# Generated at 2022-06-26 02:00:46.290077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ordered_dict_0 = load_env_file(lines, write_environ=dict())

    assert len(ordered_dict_0) == 3
    assert ordered_dict_0['TEST'] == '.../yeee'
    assert ordered_dict_0['THISIS'] == '.../a/test'
    assert ordered_dict_0['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-26 02:00:47.166331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Assert that this case doesn't raise an error
    _test_parse_env_file_contents()


# Generated at 2022-06-26 02:00:53.788928
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Running test function function parse_env_file_contents')

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ordered_dict_0 = parse_env_file_contents(lines)

    assert '(TEST, .../yeee)' in str(ordered_dict_0)
    assert '(THISIS, .../a/test)' in str(ordered_dict_0)
    assert '(YOLO, .../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST)' in str(ordered_dict_0)


# Generated at 2022-06-26 02:01:24.313330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert(parse_env_file_contents('$\\H\\') == {{'\\': ''}})


# Generated at 2022-06-26 02:01:28.954309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


test_parse_env_file_contents()

# Generated at 2022-06-26 02:01:36.822878
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-26 02:01:44.005109
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ordered_dict_0 = load_env_file(lines)
    assert ordered_dict_0['TEST'][0] == '/', "assert 'TEST' path 1"
    assert ordered_dict_0['TEST'][-1] != '\\', "assert 'TEST' path 2"
    assert ordered_dict_0['YOLO'][0] == '/', "assert 'YOLO' path 1"
    assert ordered_dict_0['YOLO'][-1] != '\\', "assert 'YOLO' path 2"


# Generated at 2022-06-26 02:01:52.343041
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'If\\H9'
    list_0 = []
    ordered_dict_0 = load_env_file(str_0)
    ordered_dict_1 = load_env_file(list_0)


# Generated at 2022-06-26 02:01:53.730415
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() == None


# Generated at 2022-06-26 02:01:56.433537
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'If\\H9'
    ordered_dict_0 = parse_env_file_contents(str_0)
    assert ordered_dict_0 == str_0
