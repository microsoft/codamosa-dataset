

# Generated at 2022-06-26 01:52:02.506871
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-26 01:52:04.270377
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        test_case_0()
    except TypeError:
        pass


# Generated at 2022-06-26 01:52:14.539791
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    observed = load_env_file(lines, write_environ)

    # assert len(observed) == 3
    # assert observed['TEST'] == '.../yeee-...:...'
    # assert observed['THISIS'] == '.../a/test'
    # assert observed['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    assert True


if __name__ == '__main__':
    import argparse
    parser = argparse.Argument

# Generated at 2022-06-26 01:52:19.829113
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines,write_environ)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_load_env_file()

# Generated at 2022-06-26 01:52:29.112265
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    return_value = load_env_file(lines, write_environ=dict())

    assert return_value == collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:52:34.444450
# Unit test for function load_env_file
def test_load_env_file():
    print('\nRunning unit test for function load_env_file()')
    lines = []
    load_env_file(lines)
    # make sure the return type of function load_env_file is dict
    assert (type(load_env_file(lines)) is dict)
    return True

if __name__ == '__main__':
    test_case_0()
    test_load_env_file()

# Generated at 2022-06-26 01:52:46.748633
# Unit test for function load_env_file
def test_load_env_file():
    lines_0 = [
                'TEST=${HOME}/yeee-$PATH',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
                ]
    load_env_file_output = load_env_file(lines_0, write_environ=dict())
    assert load_env_file_output == collections.OrderedDict(
                                [
                                    ('TEST', '.../.../yeee-...:...'),
                                    ('THISIS', '.../a/test'),
                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
                                ]
                            )
    assert load_

# Generated at 2022-06-26 01:52:58.791711
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Test: parse_env_file_contents")
    import collections
    import os
    import re
    import typing

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_keys = ['TEST', 'THISIS', 'YOLO']
    expected_values = [os.path.expandvars(x) for x in lines]
    expected = zip(expected_keys, expected_values)

    actual = parse_env_file_contents(lines)

    assert len(expected) == len(actual)

    for i in range(len(expected)):
        assert expected[i][0] == actual[i][0]

# Generated at 2022-06-26 01:53:11.563178
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("TESTING: parse_env_file_contents")

    print('Test 1')
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    generator_1 = parse_env_file_contents(lines)

    assert next(generator_1) == expected[0]
    assert next(generator_1) == expected[1]
    assert next

# Generated at 2022-06-26 01:53:15.677168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test fixture data
    lines = ["TEST=$HOME/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    expected = (("TEST", "$HOME/yeee"), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))
    # Local variables
    generator_1 = parse_env_file_contents(lines)
    # test function
    actual = tuple()
    for temp_0 in generator_1:
        if (isinstance(temp_0, tuple)):
            actual = temp_0
    # Test output
    assert(tuple(actual) == expected)

# Generated at 2022-06-26 01:53:25.046611
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input0 = ['TEST=${HOME}/yeee','THISIS=~/a/test','YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    excepted_output = [(['TEST', '.../yeee'], ['THISIS', '.../a/test'], ['YOLO', '.../swaggins/...'])]
    computed_output = parse_env_file_contents(input0)

    assert computed_output == excepted_output


# Generated at 2022-06-26 01:53:26.048039
# Unit test for function load_env_file
def test_load_env_file():
    test_case_0()

# Generated at 2022-06-26 01:53:26.630426
# Unit test for function load_env_file
def test_load_env_file():
    assert False

# Generated at 2022-06-26 01:53:37.348879
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_case_0_actual = ()
    test_case_0_expected = None
    test_case_0_actual = tuple(parse_env_file_contents(lines))
    test_case_0_expected = (('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-26 01:53:46.121005
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        "TEST=${HOME}/yeee-\\$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ])) == [
        ("TEST", "~/yeee-$PATH"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]



# Generated at 2022-06-26 01:53:54.305758
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 01:54:03.310427
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    assert load_env_file(lines, write_environ) == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:54:07.990697
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = {'HOME': '/home/john',
     'PATH': ':/usr/bin'}
    assert load_env_file(lines, environ) == {'HOME': '/home/john', 'PATH': ':/usr/bin'}


# Generated at 2022-06-26 01:54:09.582316
# Unit test for function load_env_file
def test_load_env_file():

    lines = []

    values = load_env_file(lines)

    assert values is not None


    return

# Generated at 2022-06-26 01:54:20.442334
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # fpath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # fpath = os.path.join(fpath, 'test_data', 'test.env')
    # with open(fpath, "r") as f:
    #     lines = f.readlines()
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))
    pass

if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-26 01:54:28.482410
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ={}) == OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-26 01:54:34.380962
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    o_d = load_env_file(lines, write_environ=dict())
    assert o_d == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-26 01:54:35.394731
# Unit test for function load_env_file
def test_load_env_file():
    pass

# Generated at 2022-06-26 01:54:37.618568
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents()
    assert isinstance(result, typing.Generator)


# Generated at 2022-06-26 01:54:45.490001
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:54:57.867196
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(lines=['TEST=${HOME}/yeee']) == 'TEST=.../yeee'
    assert parse_env_file_contents(lines=['TEST="test"']) == 'TEST=test'
    assert parse_env_file_contents(lines=['TEST="te\'st"']) == 'TEST=te\'st'
    assert parse_env_file_contents(lines=['TEST=\'te"st\'']) == 'TEST=te"st'
    assert parse_env_file_contents(lines=['TEST="te\\st"']) == 'TEST=te\st'

# Generated at 2022-06-26 01:55:04.297674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])==[('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')], 'Fail: test_parse_env_file_contents'


# Generated at 2022-06-26 01:55:15.999423
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Line 17
    f = open('tests/data/env_file_0.env', 'r')
    lines = f.readlines()
    output_1 = parse_env_file_contents(lines)
    output_2 = list(output_1)
    # Assertions
    assert len(output_2) == 3
    assert output_2[0][0] == 'TEST'
    assert output_2[0][1] == '${HOME}/yeee'
    assert output_2[1][0] == 'THISIS'
    assert output_2[1][1] == '~/a/test'
    assert output_2[2][0] == 'YOLO'

# Generated at 2022-06-26 01:55:25.876887
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    values = parse_env_file_contents(lines=[
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

    expected_values = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for t in zip(values, expected_values):
        assert t[0] == t[1]



# Generated at 2022-06-26 01:55:37.418383
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    dict_0 = dict()
    dict_0['HOME'] = os.path.expanduser('~')
    dict_0['PATH'] = os.pathsep.join(os.environ['PATH'].split(os.pathsep)[:4]) # For the path to shrink...
    dict_1 = dict()
    dict_1['TEST'] = os.path.join(dict_0['HOME'], 'yeee', '-' + dict_0['PATH'])
    dict_1['THISIS'] = os.path.join(dict_0['HOME'], 'a', 'test')
    dict_1['YOLO'] = os.path.join(dict_0['HOME'], 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    dict_

# Generated at 2022-06-26 01:55:45.002847
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True



# Generated at 2022-06-26 01:55:46.946133
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    out_0 = parse_env_file_contents()
    assert(out_0 == None)


# Generated at 2022-06-26 01:55:55.329928
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env = load_env_file(lines)
    assert load_env["TEST"] == os.path.expanduser('~') + "/yeee"
    assert load_env["THISIS"] == os.path.expanduser('~') + "/a/test"
    assert load_env["YOLO"] == os.path.expanduser('~') + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"


if __name__ == '__main__':
    test_case_0()
    test_parse_env_file

# Generated at 2022-06-26 01:55:57.820614
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open('.env') as f:
        lines = list(f)
    parse_env_file_contents(lines)


# Generated at 2022-06-26 01:56:07.746866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    exp_result = [(('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]
    act_result = parse_env_file_contents(lines)
    assert exp_result == act_result

# Generated at 2022-06-26 01:56:09.118996
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True
    assert True
    assert True


# Generated at 2022-06-26 01:56:16.799639
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    print(result)
    assert expected == result


# Generated at 2022-06-26 01:56:22.563930
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str0 = 'TEST=$(HOME)/yeee-$PATH'
    str1 = 'THISIS=~/a/test'
    str2 = 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    strings = [str0, str1, str2]
    for x in parse_env_file_contents(strings):
        print(x)


# Generated at 2022-06-26 01:56:34.748471
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]
    output = list(parse_env_file_contents(lines))
    assert len(output) == 3
    assert output[0] == ("TEST", "${HOME}/yeee")

    # Test 2
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS='~/a/test'",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

# Generated at 2022-06-26 01:56:42.705645
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    From honcho.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """

# Generated at 2022-06-26 01:56:55.872769
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict(
        [('TEST', '/Users/rxie/yeee'),
         ('THISIS', '/Users/rxie/a/test'),
         ('YOLO', '/Users/rxie/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:57:06.386575
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import collections

    # Test with line_0 + line_1
    line_0 = 'TEST=${HOME}/yeee'
    line_1 = 'THISIS=~/a/test'

    lines_0 = [line_0, line_1]
    result_iterator = parse_env_file_contents(lines_0)
    result_list = list(result_iterator)
    expected_list = [('TEST', '.../yeee'),
                     ('THISIS', '.../a/test')]
    
    assert result_list == expected_list, 'ERROR: expected result_list == {}'.format(expected_list)

    # Test with a line that contains a non-existing var

# Generated at 2022-06-26 01:57:10.297531
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    o = parse_env_file_contents(['abc=abc', 'def="def"', 'ghi="g\\"hi"', 'jkl=\'jkl\'', 'mno="mno"','pqr=pqr','stu="s\\\'tu"'])
    # . . .
    pass


# Generated at 2022-06-26 01:57:20.663515
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/test', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/test', 'THISIS': '~/a/test',
                                                    'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-26 01:57:26.517722
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)
    assert output == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:57:31.415505
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected_result = [('HOME', '...')]
    contents = ['HOME=...']
    results = list(parse_env_file_contents(contents))

    assert expected_result == results



# Generated at 2022-06-26 01:57:44.844073
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'nhzT"CNSw1iW6Tid'
    str_1 = expand(str_0)
    str_2 = 'nhzT"CNSw1iW6Tid'
    str_3 = expand(str_2)
    str_4 = 'nhzT"CNSw1iW6Tid'
    str_5 = expand(str_4)
    lines = ['TEST="$HOME"/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert values[0] == ('TEST', '.../.../yeee-...:...')
    assert values

# Generated at 2022-06-26 01:57:56.888483
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:58:01.738614
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 01:58:07.208871
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vals = load_env_file(lines, write_environ=dict())
    assert vals == OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:58:18.156486
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')) == [('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO',
             '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Unit test for function load_env_file

# Generated at 2022-06-26 01:58:23.138837
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    list_0 = [ 'nhzT"CNSw1iW6Tid=Bx', 'Kf5OtLw="tFm1mq', ':K%' ]
    tuple_0 = parse_env_file_contents(list_0)
    assert type(tuple_0) is typing.GeneratorType
    assert type(next(tuple_0)) is tuple
    assert type(next(tuple_0)) is tuple
    assert type(next(tuple_0)) is tuple

    list_1 = [ 'nhzT"CNSw1iW6Tid=Bx', 'Kf5OtLw="tFm1mq', ':K%' ]
    tuple_1 = parse_env_file_contents(list_1)

# Generated at 2022-06-26 01:58:33.237719
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    ans_0 = parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    ans_0 = list(ans_0)
    I_0 = 0
    str_0 = ans_0[I_0][0]
    str_1 = ans_0[I_0][1]
    I_1 = 1
    str_2 = ans_0[I_1][0]
    str_3 = ans_0[I_1][1]
    I_2 = 2
    str_4 = ans_0[I_2][0]
    str_5 = ans_0[I_2][1]

# Unit

# Generated at 2022-06-26 01:58:41.948440
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '/home/josh/yeee'),
                ('THISIS', '/home/josh/a/test'),
                ('YOLO', '/home/josh/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    result = parse_env_file_contents(lines)
    assert expected == result


# Generated at 2022-06-26 01:58:52.744227
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'c6G48lJX1BTsjCzs'
    str_1 = expand(str_0)
    str_2 = '0Ghg9f3qxH'
    str_3 = expand(str_2)
    str_4 = '1'
    str_5 = expand(str_4)
    str_6 = 'QDZV7E4Kj0lV'
    str_7 = expand(str_6)
    lines = [str_5+'='+str_1, str_7+'='+str_3]
    str_12 = '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    str_13 = expand(str_12)

# Generated at 2022-06-26 01:58:55.067771
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Check that there's no error when we call `parse_env_file_contents`
    parse_env_file_contents()



# Generated at 2022-06-26 01:59:02.612990
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    read_values = parse_env_file_contents(lines)

    # Test that values are expanded
    test_values = [('TEST', '.../yeee'), ('THISIS', '.../a/test'),
                   ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    for pair in read_values:
        if pair not in test_values:
            raise ValueError('{0} not in expected values'.format(pair))


# Generated at 2022-06-26 01:59:13.886750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents(): # if __name__ == "__main__":
    # Test Case 0
    print("Test Case 0")
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    soln = load_env_file(lines, write_environ=dict())
    print(soln)
    assert soln == collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:59:18.568059
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 01:59:26.368945
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)

    # OrderedDict([('TEST', '.../yeee'),
    #             ('THISIS', '.../a/test'),
    #             ('YOLO',
    #              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    pass



# Generated at 2022-06-26 01:59:55.609969
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [ 'TEST=/yeee',
              'THISIS=~/a/test',
              'YOLO=$HOME/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for x, y in parse_env_file_contents(lines):
        print(x, y)

    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, None)
    print(d)



# Generated at 2022-06-26 02:00:08.193104
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'nhzT"CNSw1iW6Tid'
    str_1 = expand(str_0)
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret_0 = parse_env_file_contents(lines)
    ret_1 = collections.OrderedDict()
    pass_ = True
    try:
        while True:
            ret_1[next(ret_0)[0]], ret_1[next(ret_1)[1]]
            if not next(ret_1)[0] == next(ret_1)[1]:
                pass_ = False
    except StopIteration:
        pass


# Generated at 2022-06-26 02:00:19.273932
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = """
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    lines = str_0.splitlines()
    lines = [l.strip() for l in lines if len(l.strip())]

    output = load_env_file(lines, write_environ=None)

    print(output)

    assert os.environ.get('TEST') is None


if __name__ == '__main__':
    test_parse_env_file_contents()
    test_case_0()

# Generated at 2022-06-26 02:00:26.627509
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('test_parse_env_file_contents...', end='')
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))
    print('Passed.')


# Generated at 2022-06-26 02:00:38.954219
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    results_list = list(results)

    assert results_list[0][0] == 'TEST'
    assert results_list[0][1] == '${HOME}/yeee'

    assert results_list[1][0] == 'THISIS'
    assert results_list[1][1] == '~/a/test'

    assert results_list[2][0] == 'YOLO'

# Generated at 2022-06-26 02:00:40.663132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-26 02:00:51.689899
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from cStringIO import StringIO

    lines = StringIO('''TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST''')

    expected = collections.OrderedDict([
        ('TEST', os.path.expanduser('~') + '/yeee-' + os.path.expanduser('${PATH}')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

    actual = load_env_file(lines)

    assert actual == expected

# Generated at 2022-06-26 02:00:52.727126
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass


# Generated at 2022-06-26 02:01:03.190705
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []
    assert list(parse_env_file_contents(["export PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'"])) \
        == [('PATH', '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin')]
    assert list(parse_env_file_contents(['export HOME="/root"'])) == [('HOME', '/root')]

# Generated at 2022-06-26 02:01:13.932965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    items = list(parse_env_file_contents(lines))
    assert len(items) == len(lines)
    assert items[0][0] == 'TEST'
    assert items[0][1] == '${HOME}/yeee'
    assert items[1][0] == 'THISIS'
    assert items[1][1] == '~/a/test'
    assert items[2][0] == 'YOLO'
    assert items[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-26 02:01:56.852564
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
