

# Generated at 2022-06-26 01:52:13.169785
# Unit test for function load_env_file
def test_load_env_file():
    if __package__ is None or __package__ == '':
    # created with
    # python3 -m venv -p python3.6 env
    # source env/bin/activate
    # pip install pytest
    # pytest tests/test_pyenvfile.py
        from .. import pyenvfile
        assert pyenvfile.load_env_file is not None

    assert load_env_file is not None
    assert load_env_file(['HOME=~/', 'PATH=~/bin/to/bin'], {}).get('HOME') == expand('~/')
    assert load_env_file(['HOME=~/', 'PATH=~/bin/to/bin'], {}).get('PATH') == expand('~/bin/to/bin')


# Generated at 2022-06-26 01:52:21.125398
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_text_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_dict_0 = load_env_file(env_text_0, write_environ=dict())
    print(env_dict_0)
    env_dict_0_expected = collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert env_dict_0 == env_dict_0_expected


# Generated at 2022-06-26 01:52:30.916873
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = {}
    correct_result = {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    computed_result = load_env_file(lines, write_environ)
    assert computed_result == correct_result

# Unit test from honcho.tests import load

# Generated at 2022-06-26 01:52:36.559068
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = load_env_file(lines, write_environ=dict())
    expected = OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert actual == expected



# Generated at 2022-06-26 01:52:48.071461
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:52:50.077072
# Unit test for function load_env_file
def test_load_env_file():
    pass

# Generated at 2022-06-26 01:52:59.795830
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Test case 0: ")
    generator_0 = parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])
    print(list(generator_0))
    assert list(generator_0) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    print("Test case 1: ")

# Generated at 2022-06-26 01:53:06.228673
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    #All good, test passes.
    return 0


# Generated at 2022-06-26 01:53:07.652391
# Unit test for function load_env_file
def test_load_env_file():
    assert "0.0.1" == honcho.__version__



# Generated at 2022-06-26 01:53:14.953255
# Unit test for function load_env_file
def test_load_env_file():
    os.environ['FOO'] = 'BAR'
    print(os.environ['FOO'])
    os.environ['FOO'] = '123'
    print(os.environ['FOO'])
    os.environ['BAZ'] = '456'
    print(os.environ['BAZ'])
    os.environ['BAZ'] = ''
    print(os.environ['BAZ'])
    given_lines = ['FOO=123', 'BAZ=', 'BAR=']
    load_env_file(given_lines, write_environ=None)


# Generated at 2022-06-26 01:53:21.915170
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)

    for k, v in res:
        assert os.path.expanduser(v) == v



# Generated at 2022-06-26 01:53:24.808006
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str0 = '1<3==3-4'
    ordered_dict_0 = parse_env_file_contents(str0)


# Generated at 2022-06-26 01:53:35.554949
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []
    assert list(parse_env_file_contents(['FOO=1'])) == [('FOO', '1')]
    assert list(parse_env_file_contents(['FOO=2', 'SPAM=2'])) == [('FOO', '2'), ('SPAM', '2')]
    assert list(parse_env_file_contents(['FOO="2"', 'SPAM=2'])) == [('FOO', '2'), ('SPAM', '2')]
    assert list(parse_env_file_contents(['FOO="2"', 'SPAM=2', 'BAR="1'])) == [('FOO', '2'), ('SPAM', '2'), ('BAR', '')]

# Generated at 2022-06-26 01:53:40.296658
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    list_0 = ['string#1', 'string#2', 'string#3']
    list_1 = []
    try:
        generator_0 = parse_env_file_contents(list_0)
        list_1 = []
        while (len(list_1) < 3):
            list_1.append(next(generator_0))
    except StopIteration:
        pass
    tuple_0 = [list_1[2], list_1[1], list_1[0]]
    assert (list_1 == tuple_0)


# Generated at 2022-06-26 01:53:51.986212
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    dict_0 = dict()
    dict_0['dict_0'] = 'dict_0'
    dict_0['dict_1'] = 'dict_1'
    dict_0['dict_2'] = 'dict_2'
    list_0 = list()
    list_0.append(('dict_0', 'dict_0'))
    list_0.append(('dict_1', 'dict_1'))
    list_0.append(('dict_2', 'dict_2'))
    for dict_1, dict_2 in parse_env_file_contents(str(dict_0)):
        assert (dict_1, dict_2) in list_0


# Generated at 2022-06-26 01:54:03.711470
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ])) == [
        ('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
        ('THISIS', os.path.join(os.path.expanduser('~'), 'a/test')),
        ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

# Generated at 2022-06-26 01:54:09.641902
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:54:19.560416
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: Randomize.
    # TODO: Make errors.
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = list(parse_env_file_contents(lines))
    assert result == [('TEST', '${HOME}/yeee-$PATH'),
                      ('THISIS', '~/a/test'),
                      ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')], result



# Generated at 2022-06-26 01:54:24.383857
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ld = parse_env_file_contents(lines)
    assert ld is not None


# Generated at 2022-06-26 01:54:33.022720
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_1 = '2U6W3I6G;=Xn;@Rn'
    str_2 = '{E6/PG.3@Uj3lq3'
    str_3 = 'jRU|-y%c=zEw~6iB'
    generator_0 = parse_env_file_contents(str_1)
    iterator_0 = iter(generator_0)
    value_0 = next(iterator_0)
    value_1 = next(iterator_0)
    value_2 = next(iterator_0)
    value_3 = next(iterator_0)
    value_4 = next(iterator_0)
    value_5 = next(iterator_0)
    value_6 = next(iterator_0)
    value_7 = next(iterator_0)
   

# Generated at 2022-06-26 01:54:37.848259
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = '1jld!^HY!$a;m'
    ordered_dict_0 = load_env_file(str_0)
    
    

# Generated at 2022-06-26 01:54:42.305227
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing function: parse_env_file_contents")

    

    
    
    
    
    
    



if __name__ == "__main__":
    test_case_0()

    test_parse_env_file_contents()

# Generated at 2022-06-26 01:54:51.249056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-26 01:55:01.995678
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with an empty string
    lines = []
    assert list(parse_env_file_contents(lines)) == [], "Test case with an empty string failed"

    # Test with a single line
    lines = ['Hello=World']
    assert list(parse_env_file_contents(lines)) == [('Hello', 'World')], "Test case with a single line failed"

    # Test with a quoted string
    lines = ['Hello=World', 'Hello2="Hello with a quote"']
    assert list(parse_env_file_contents(lines)) == [('Hello', 'World'), ('Hello2', 'Hello with a quote')], "Test case with a quoted string failed"

    # Test with a quoted string with escaped quotes
    lines = ['Hello=World', 'Hello2="Hello with a quote \" within quote"']
    assert list

# Generated at 2022-06-26 01:55:14.426186
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    list_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(list_0)
    assert values == [(['TEST', '.../yeee'], ['THISIS', '.../a/test'], ['YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])]

# Unit test

# Generated at 2022-06-26 01:55:16.918701
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_parse_env_file_contents_0()
    test_parse_env_file_contents_1()


# Generated at 2022-06-26 01:55:25.129290
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:55:28.699494
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert str(parse_env_file_contents('/tmp/')) == "[('TEST', '${HOME}/yeee')]"
    assert str(parse_env_file_contents('/home/user')) == "[('TEST', '${HOME}/yeee')]"


# Generated at 2022-06-26 01:55:38.701030
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    assert list(result) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:55:45.157343
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    global lines
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    global parse_env_file_contents
    parse_env_file_contents = parse_env_file_contents(lines)
    assert parse_env_file_contents == 1


# Generated at 2022-06-26 01:55:54.046299
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert result.__next__() == ('TEST', '.../yeee')
    assert result.__next__() == ('THISIS', '.../a/test')
    assert result.__next__() == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-26 01:56:04.500154
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    '''
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    '''


# Generated at 2022-06-26 01:56:14.689665
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing parse_env_file_contents')
    
    # Test Cases
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    testCase1 = parse_env_file_contents(lines)
    print('testCase1: ', testCase1)

    # Test Results
    testResults = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    print('testResults: ', testResults)

    # Compare Results

# Generated at 2022-06-26 01:56:16.535746
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'Ia1?>gm3TJjP'
    ordered_dict_0 = load_env_file(str_0)


# Generated at 2022-06-26 01:56:22.551191
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # input string
    str_0 = ''
    # expected output tuple
    expected_tuple = ""
    # create a return tuple from invoking parse_env_file_contents
    actual_tuple = parse_env_file_contents(str_0)

    # compare the expected and actual return tuple
    if(expected_tuple == actual_tuple):
        print('Passed case 0')
    else:
        print('Failed case 0')



# Generated at 2022-06-26 01:56:29.949656
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    d = ['qX9J;tCx%}v{', '1+8D:0b4<!_e', '=L+8|&(?nfUV']
    gen = parse_env_file_contents(d)
    assert next(gen) == (
        'qX9J;tCx%}v{', '1+8D:0b4<!_e')



# Generated at 2022-06-26 01:56:31.895418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents == 'parse_env_file_contents should return'


# Generated at 2022-06-26 01:56:40.996849
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Running function parse_env_file_contents')
    # Test parameters
    file_contents = 'TEST=${HOME}/yeee THISIS=~/a/test YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    # Test output
    expected_output = OrderedDict([('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    actual_output = load_env_file(file_contents)
    assert expected_output == actual_output
    print('parse_env_file_contents test case passed')

# Generated at 2022-06-26 01:56:52.731689
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_dict = collections.OrderedDict()
    for i, (k, v) in enumerate(parse_env_file_contents(lines)):
        parsed_dict[k] = v
    assert (parsed_dict == collections.OrderedDict([('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])), 'test_parse_env_file_contents failed'



# Generated at 2022-06-26 01:56:58.042211
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Example usage
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    assert True



# Generated at 2022-06-26 01:57:09.076712
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from unittest.mock import MagicMock
    from unittest.mock import patch

    # Input params assignment
    test_case_0 = 'TMw*hVSPo1<ruC'
    test_case_1 = '%'

    # Expected exception
    Exception_0 = ValueError

    # Expected output
    expected_out_0 = None
    expected_out_1 = None

    # Test implementation
    result_0 = parse_env_file_contents(test_case_0)
    result_1 = parse_env_file_contents(test_case_1)

    assert(expected_out_0 == result_0)
    assert(expected_out_1 == result_1)



# Generated at 2022-06-26 01:57:20.102606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_values = ['TEST=${HOME}/yeee',
                  'THISIS=~/a/test',
                  'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(env_values)
    assert next(result) == ('TEST', '${HOME}/yeee')
    assert next(result) == ('THISIS', '~/a/test')
    assert next(result) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-26 01:57:35.231199
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ordered_dict_0 = load_env_file(lines)
    assert 'TEST' in ordered_dict_0
    assert ordered_dict_0['TEST'] == '.../yeee'
    assert 'THISIS' in ordered_dict_0
    assert ordered_dict_0['THISIS'] == '.../a/test'
    assert 'YOLO' in ordered_dict_0
    assert ordered_dict_0['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:57:45.832733
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert iter(parse_env_file_contents()) is not None
    assert next(parse_env_file_contents()) == ('a', '1')
    assert next(parse_env_file_contents()) == ('b', '2')
    assert next(parse_env_file_contents()) == ('c', '3')
    assert next(parse_env_file_contents()) == ('a', '1')
    assert next(parse_env_file_contents()) == ('b', '2')
    assert next(parse_env_file_contents()) == ('c', '3')
    assert next(parse_env_file_contents()) == ('a', '1')
    assert next(parse_env_file_contents()) == ('b', '2')

# Generated at 2022-06-26 01:57:57.380623
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Test Case 0
    line = 'TZ=America/New_York'
    result = parse_env_file_contents(line)
    assert result == None
    expected = None
    assert result == expected

    # Test Case 1
    line = 'PATH=/sbin:/usr/sbin:/bin:/usr/bin'
    result = parse_env_file_contents(line)
    assert result == None
    expected = None
    assert result == expected

    # Test Case 2
    line = 'PWD=/'
    result = parse_env_file_contents(line)
    assert result == None
    expected = None
    assert result == expected

    # Test Case 3
    line = 'LANG=en_US.UTF-8'
    result = parse_env_file_contents(line)

# Generated at 2022-06-26 01:58:00.150640
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [ '1=1' ]
    assert list(parse_env_file_contents(lines)) == [('1', '1')]

# Generated at 2022-06-26 01:58:07.533696
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for valid input
    # All expected values should be equal to actual values
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_file_contents = parse_env_file_contents(lines)
    
    expected_0 = {'TEST': '${HOME}/yeee'}
    next_0 = next(env_file_contents)
    assert(('TEST', '${HOME}/yeee') == next_0)
    
    expected_1 = {'THISIS': '~/a/test'}
    next_1 = next(env_file_contents)

# Generated at 2022-06-26 01:58:13.771457
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Setup
    str_0 = 'Me^B28p.xrWt9=3!b $\'fQ[e'
    list_0 = None

    # Invocation
    dict_0 = parse_env_file_contents(str_0)

    # Verification
    assert dict_0 == list_0


# Generated at 2022-06-26 01:58:18.810140
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)


# Generated at 2022-06-26 01:58:28.938108
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:58:44.830772
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-$PATH'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:58:55.627755
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = ''
    str_1 = '/'
    str_2 = '`'
    str_3 = '`/'
    str_4 = './'
    str_5 = '../'
    str_6 = '.\\'
    str_7 = '..\\'
    str_8 = 't'
    str_9 = 'te'
    str_10 = 'tes'
    str_11 = 'test'
    str_12 = './test'
    str_13 = '../test'
    str_14 = '.\\test'
    str_15 = '..\\test'
    str_16 = 'test/'
    str_17 = 'test\\'
    str_18 = 'test/ '
    str_19 = 'test\\ '
    str_20 = 'test/\\'


# Generated at 2022-06-26 01:59:03.214968
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['foo=bar'])) == [('foo', 'bar')]
    assert list(parse_env_file_contents(['foo=bar', 'baz=quux'])) == [('foo', 'bar'), ('baz', 'quux')]

    assert list(parse_env_file_contents(['export foo=bar'])) == []

    assert list(parse_env_file_contents(['foo=bar', '', '# baz=quux'])) == [('foo', 'bar')]

    assert list(parse_env_file_contents(['foo=bar', 'baz=quux', 'lorem=ipsum'])) == [('foo', 'bar'), ('baz', 'quux'), ('lorem', 'ipsum')]

# Generated at 2022-06-26 01:59:11.040466
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert str in globals()
    assert callable(str)
    assert list in globals()
    assert callable(list)
    assert list in globals()
    assert callable(list)
    assert list in globals()
    assert callable(list)
    assert __name__ == '__main__'

    # Test with: str
    # Test with: list
    # Test with: str
    # Test with: list
    # Test with: str
    # Test with: list



# Generated at 2022-06-26 01:59:22.412002
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'TMw*hVSPo1<ruC'
    str_1 = 'G:T;T==Tp|Wy'

# Generated at 2022-06-26 01:59:24.096201
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_case_0()
    print("Unit test for function parse_env_file_contents")



# Generated at 2022-06-26 01:59:27.396943
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:59:36.496481
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Ensures that the loaded env files are valid.
    """
    # TODO: Replace with unittest
    assert True
    #assert False
    
    files = [
        'tests/env.test',
    ]

    for file in files:
        with open(file) as f:
            lines = (l.strip() for l in f)
            load_env_file(lines)



if __name__ == '__main__':
    #test_case_0()
    test_parse_env_file_contents()
    print("Unit test done!")

# Generated at 2022-06-26 01:59:43.288566
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open('../tests/data/test_env', 'rt') as f:
        actual_list = list(parse_env_file_contents(f))
    expected_list = [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert actual_list == expected_list


# Generated at 2022-06-26 01:59:45.935947
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True == True


# Generated at 2022-06-26 02:00:01.603576
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents is not None


# Generated at 2022-06-26 02:00:07.330047
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_1 = parse_env_file_contents(lines)
    print(dict_1)


# Generated at 2022-06-26 02:00:20.259534
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Case 0
    lines_0 = [ '/pk(h', '_I7>0!>~Y2.V$|/1p(4nq3', 'b+A$I9;R"]N2Q"n+n{zC`', '^J?A[1=5%c<)V7.5M;J_]' ]
    actual_0 = parse_env_file_contents(lines_0)

# Generated at 2022-06-26 02:00:23.577507
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(["TEST='a'"]) == [('TEST', 'a')]



# Generated at 2022-06-26 02:00:30.011906
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_content = """
    # Comment
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    lines = file_content.splitlines()
    result = list(parse_env_file_contents(lines))



# Generated at 2022-06-26 02:00:42.200693
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    
    # Test 2
    lines = ['TEST=\'~/yeee\'', 'THISIS="~/a/test"', 'YOLO="Some \\$variable"']

# Generated at 2022-06-26 02:00:46.256619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # We pass a test string to the function.
    test_string = "line 1\nline 2"
    result = list(parse_env_file_contents(test_string.splitlines()))
    print("Result: ", result)



# Generated at 2022-06-26 02:00:51.921502
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = ['Q2^-ViRZP5', 'TMw*hVSPo1<ruC']
    generator_0 = parse_env_file_contents(lines_0)
    assert len(generator_0) == 2
    assert (generator_0[0] == ('TMw*hVSPo1', '<ruC'))
    assert (generator_0[1] == ('Q2^-ViRZP5', ''))

# Generated at 2022-06-26 02:00:55.275118
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with required args
    # Test passes
    assert load_env_file('/n,64PnN>8i>') == 'E=zSkPT&0K'


# Generated at 2022-06-26 02:00:57.770193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents('x=y') == ('x', 'y')

# Test case for function load_env_file

# Generated at 2022-06-26 02:01:37.907555
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['hello = world !']
    val = parse_env_file_contents(lines)
    assert next(val) == ('hello', 'world !')
    try:
        next(val)
    except StopIteration:
        pass
    else:
        assert False # expected exception

    lines = ['hello = "world !"']
    val = parse_env_file_contents(lines)
    assert next(val) == ('hello', 'world !')
    try:
        next(val)
    except StopIteration:
        pass
    else:
        assert False # expected exception

    lines = ['hello = \'world !\'']
    val = parse_env_file_contents(lines)
    assert next(val) == ('hello', 'world !')

# Generated at 2022-06-26 02:01:38.457458
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert 1


# Generated at 2022-06-26 02:01:51.150338
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing parse_env_file_contents')
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = parse_env_file_contents(lines)
    assert actual == expected

# Generated at 2022-06-26 02:01:59.236379
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_contents = list(parse_env_file_contents(lines))
    assert env_contents == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO',
                                                                               '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]