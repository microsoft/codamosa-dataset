

# Generated at 2022-06-26 01:52:06.130450
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = (('FOO', 'bar'), ('BAZ', 'quux'), ('SPAM', 'eggs'))
    result = tuple(parse_env_file_contents(('FOO=bar', 'BAZ=quux', 'SPAM=eggs')))

    assert(result == expected)


# Generated at 2022-06-26 01:52:14.329791
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    generator_0 = parse_env_file_contents(lines)
    
    assert tuple(generator_0) == (('TEST', '.../yeee'),
                                  ('THISIS', '.../a/test'),
                                  ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 01:52:20.172438
# Unit test for function load_env_file
def test_load_env_file():

    # Arrange
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    # Act
    result = load_env_file(lines)

    # Assert


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_load_env_file()

# Generated at 2022-06-26 01:52:22.777540
# Unit test for function load_env_file
def test_load_env_file():
    pass



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:52:24.686950
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents()
    assert result is not None


# Generated at 2022-06-26 01:52:26.888814
# Unit test for function load_env_file
def test_load_env_file():
    file = open('test.env', 'r')
    lines = file.readlines()
    load_env_file(lines)

# Generated at 2022-06-26 01:52:33.210635
# Unit test for function load_env_file
def test_load_env_file():
    assert( ExpansionUtil.load_env_file('dummyfile') == OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]))

# Generated at 2022-06-26 01:52:45.748587
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert tuple(parse_env_file_contents(lines_0)) == (('TEST', expand(os.path.expandvars('${HOME}/yeee'))), ('THISIS', expand(os.path.expandvars('~/a/test'))), ('YOLO', expand(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))))

# Generated at 2022-06-26 01:52:57.933043
# Unit test for function load_env_file
def test_load_env_file():
    assert(load_env_file([]) == {})
    assert(load_env_file(['a=b']) == {'a':'b'})
    assert(load_env_file(['a=b', 'c=d']) == {'a':'b', 'c':'d'})
    assert(load_env_file(['a=b', 'c=d', 'a=e']) == {'a':'e', 'c':'d'})
    assert(load_env_file(['a=b', 'c=d', 'a=e', 'b=a']) == {'a':'e', 'c':'d', 'b':'a'})

# Generated at 2022-06-26 01:53:05.221928
# Unit test for function load_env_file
def test_load_env_file():
    file_name = os.path.join(os.path.dirname(__file__), "fixtures/env_file_0")
    write_environ = dict()
    load_env_file(open(file_name), write_environ=write_environ)
    #assert os.environ == {'TEST': '5', 'TWO': '3'}


# Generated at 2022-06-26 01:53:11.408823
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)

    return results


# Generated at 2022-06-26 01:53:16.482452
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    import json
    print(json.dumps(list(parse_env_file_contents(lines))))


# Generated at 2022-06-26 01:53:21.036270
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:53:32.540432
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        assert next(parse_env_file_contents(["export A=1"])) == ('A', '1')
    except:
        print(parse_env_file_contents(["export A=1"]))

    assert next(parse_env_file_contents(["A=1"])) == ('A', '1')
    assert next(parse_env_file_contents(["A=123"])) == ('A', '123')
    assert next(parse_env_file_contents(["A='123'"])) == ('A', '123')
    assert next(parse_env_file_contents(['A="123"'])) == ('A', '123')

# Generated at 2022-06-26 01:53:38.676441
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert(parse_env_file_contents(lines) == [(('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))] )


# Generated at 2022-06-26 01:53:52.448763
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    str_0 = "D~|(rU6"
    str_1 = [str_0]

    ret_list_1 = list(parse_env_file_contents(str_1))

    ret_list_2 = [(str_0, str_1)]
    assert ret_list_1 == ret_list_2

    str_0 = "D~|(rU6"
    str_1 = "7M~T%8}"
    str_2 = [str_0, str_1]

    ret_list_4 = list(parse_env_file_contents(str_2))

    ret_list_5 = [(str_0, str_1), (str_2, str_0)]
    assert ret_list_4 == ret_list_5


# Generated at 2022-06-26 01:54:04.216548
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TEST 1
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    res = parse_env_file_contents(lines)

    for k,v in res:
        print(k, v)
    
    # # TEST 2
    # lines = '~/Documents'
    # res = expand(lines)
    # print(res)

    # # TEST 3
    # lines = '$HOME/Documents'
    # res = expand(lines)
    # print(res)

    # # TEST 4
    # lines = '${HOME}/Documents'
    # res = expand(lines)
    # print

# Generated at 2022-06-26 01:54:16.642351
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=['TEST=${HOME}/yeee', 'THIS=IS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '${HOME}/yeee'), ('THIS', 'IS=~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:54:18.508773
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert True
    # TODO: add test for function parse_env_file_contents


# Generated at 2022-06-26 01:54:19.917016
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents("HOME=/home/")


# Generated at 2022-06-26 01:54:23.204464
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:54:30.317454
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = parse_env_file_contents(lines)
    assert out == [('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:54:43.313232
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Parse empty list
    assert list(parse_env_file_contents(lines=[])) == []

    # Parse one line
    assert list(parse_env_file_contents(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == \
           [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


if __name__ == "__main__":
    test_case_0()
    test_parse_env_file_contents()

# Generated at 2022-06-26 01:54:55.388289
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['a=b', 'c=d'])) == [('a', 'b'), ('c', 'd')]
    assert list(parse_env_file_contents(['a = b', 'c=d'])) == [('a', 'b'), ('c', 'd')]
    assert list(parse_env_file_contents(['a = "b"', 'c=d'])) == [('a', 'b'), ('c', 'd')]
    assert list(parse_env_file_contents(['a = "b1', 'b2"', 'c=d'])) == [('a', 'b1\nb2'), ('c', 'd')]

# Generated at 2022-06-26 01:55:02.690090
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    value = next(values)
    assert value[0] == 'TEST'
    value = next(values)
    assert value[0] == 'THISIS'
    value = next(values)
    assert value[0] == 'YOLO'


# Generated at 2022-06-26 01:55:07.542365
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:55:20.162369
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test input for function parse_env_file_contents
    # src: https://raw.githubusercontent.com/dgleba/.env/master/test/test_env.txt
    str_0 = \
"""
# Comment 1
# Comment 2

TEST=${HOME}/yeee-$PATH
# Comment 3

# Comment 4
THISIS=~/a/test



YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    # Test output for function parse_env_file_contents
    # src: https://raw.githubusercontent.com/dgleba/.env/master/test/test_env.txt

# Generated at 2022-06-26 01:55:27.793490
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(list(parse_env_file_contents(lines)))

    # Case 0
    # case_0_dict = dict()
    # case_0_dict = load_env_file(lines, case_0_dict)
    # print(case_0_dict)

    # for k, v in case_0_dict.items():
    #     print('{}: {}'.format(k, v))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 01:55:33.473574
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert (1 == 1)


# Generated at 2022-06-26 01:55:45.414098
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', '# YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    try:
        assert next(result) == ('TEST', '.../yeee')
    except StopIteration:
        assert False
    try:
        assert next(result) == ('THISIS', '.../a/test')
    except StopIteration:
        assert False
    try:
        next(result)
        assert False
    except StopIteration:
        assert True
    try:
        next(result)
        assert False
    except StopIteration:
        assert True


# Generated at 2022-06-26 01:55:55.209884
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
    'TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-26 01:55:56.955560
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(None)


# Generated at 2022-06-26 01:55:59.539960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print(parse_env_file_contents('../tests/test_envfile_content.txt'))


# Generated at 2022-06-26 01:56:08.210290
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    list_0 = list(parse_env_file_contents(lines))

    assert list_0 == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:56:14.730637
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-26 01:56:24.043824
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['VAL=1']) == [('VAL', '1')]
    assert parse_env_file_contents(['VAL=\'1\'']) == [('VAL', '\'1\'')]
    assert parse_env_file_contents(['VAL="1"']) == [('VAL', '"1"')]
    assert parse_env_file_contents(['VAL="1$PATH"']) == [('VAL', '"1$PATH"')]
    assert parse_env_file_contents(['VAL="1$PATH$PATH"']) == [('VAL', '"1$PATH$PATH"')]
    assert parse_env_file_contents(['VAL="1$PATH", "2$PATH"']) == [('VAL', '"1$PATH", "2$PATH"')]

# Generated at 2022-06-26 01:56:36.143312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee\'', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    import io
    result_0 = parse_env_file_contents(lines)
    result_1 = collections.OrderedDict([('TEST', '${HOME}/yeee\''), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    for k, v in result_0:
        result_1[k] = v
    print(result_1)

# Generated at 2022-06-26 01:56:38.670540
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test function signature
    try:
        test_case_0()
    except TypeError as e:
        assert(type(e) == TypeError)



# Generated at 2022-06-26 01:56:49.757010
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert(result == [('TEST', '${HOME}/yeee'),
                      ('THISIS', '~/a/test'),
                      ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result

# Generated at 2022-06-26 01:56:55.486530
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]
    dict_0 = dict(parse_env_file_contents(lines))


# Generated at 2022-06-26 01:57:10.380115
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing function parse_env_file_contents()")
    # Test Case 0
    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
               'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_0 = {'TEST': '.../yeee', 'THISIS': '.../a/test',
                  'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    test_env_parse = parse_env_file_contents(lines_0)
    actual_0 = {}
    for item in test_env_parse:
        actual_0[item[0]] = item[1]


# Generated at 2022-06-26 01:57:11.690367
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() == None


# Generated at 2022-06-26 01:57:24.732646
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Parses env file content.
    :return:
    """
    env_file_contents_source = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        ]
    env_file_contents_expected = {
        "TEST": os.environ.get("HOME", "")+"/yeee",
        "THISIS": os.environ.get("HOME", "")+"/a/test",
        "YOLO": os.environ.get("HOME", "")+"/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }


# Generated at 2022-06-26 01:57:34.942645
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing parse_env_file_contents')
    lines = '''TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''
    lines = lines.split('\n')
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:57:41.440351
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing if function parse_env_file_contents is working fine
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(list(parse_env_file_contents(lines)))


# Generated at 2022-06-26 01:57:48.400340
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    string_0 = 'TEST=/data/.../yeee'
    string_1 = 'THISIS=~/a/test'
    string_2 = 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    result_0 = parse_env_file_contents([string_0, string_1, string_2])
    assert list(result_0) == [('TEST', '/data/.../yeee'),
                              ('THISIS', '~/a/test'),
                              ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:57:58.030888
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_0 = dict(parse_env_file_contents(lines))
    e_str_0 = '.../yeee'
    e_str_1 = '.../a/test'
    e_str_2 = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    l_0 = [dict_0[key] for key in ['TEST', 'THISIS', 'YOLO']]
    e_l_0 = [e_str_0, e_str_1, e_str_2]


# Generated at 2022-06-26 01:58:00.397095
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:58:11.147944
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)
    print(list(res))
    print(list(load_env_file(lines)))
    test_0(lines)



# Generated at 2022-06-26 01:58:19.059687
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'Path = $PATH\nHOME = ~\nHOMER = ~\nPATH = something\n'
    str_1 = ['Path = $PATH', 'HOME = ~', 'HOMER = ~', 'PATH = something', '']
    res_2 = parse_env_file_contents(str_1)
    res_3 = collections.OrderedDict()
    res_4 = collections.OrderedDict()


# Generated at 2022-06-26 01:58:45.142943
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'PIPENV_VENV_IN_PROJECT=false'
    ls_0 = ['PIPENV_VENV_IN_PROJECT=false']
    ret_0 = parse_env_file_contents(ls_0)
    ls_1 = [str_0]
    # print(list(ret_0))
    assert list(ret_0) == ls_1
    assert list(ret_0) == ls_1
    # print(str_0)
    str_1 = 'PIPENV_IGNORE_VIRTUALENVS=false'
    ls_2 = [str_1]
    ls_3 = ['PIPENV_IGNORE_VIRTUALENVS=false']
    ret_1 = parse_env_file_contents(ls_3)
    # print

# Generated at 2022-06-26 01:58:52.280850
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([]) == []
    assert parse_env_file_contents(['TEST=${HOME}/yeee']) == [('TEST', '${HOME}/yeee')]
    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test']) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test')]


# Generated at 2022-06-26 01:58:59.561119
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-26 01:59:06.042624
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:59:16.253144
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    actual = []
    for k, v in parse_env_file_contents(lines):
        actual.append((k, v))
    assert actual == expected



# Generated at 2022-06-26 01:59:26.254178
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_content  = '''
        TEST=$HOME/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''
    file_content  = file_content.split('\n')

    results = parse_env_file_contents(file_content) # type: typing.Generator[typing.Tuple[str, str], None, None]
    results = list(results)

    assert results[0] == ('TEST', '$HOME/yeee')
    assert results[1] == ('THISIS', '~/a/test')

# Generated at 2022-06-26 01:59:33.667360
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) \
        == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:59:39.554669
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_0 = expand('APP_MODE=prod\\nAPP_PORT=8080')
    print(file_0)
    file_1 = file_0.split('\\n')
    file_2 = parse_env_file_contents(file_1)
    file_3 = load_env_file(file_1)


# Generated at 2022-06-26 01:59:47.829491
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = ['THISIS=~/a/test']
    lines_1 = expand(lines_0)

    contents_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents_1 = expand(contents_0)

    lines_2 = ['TEST=${HOME}/yeee']
    lines_3 = expand(lines_2)

    contents_2 = ['THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents_3 = expand(contents_2)


# Generated at 2022-06-26 01:59:57.507967
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 02:00:37.209502
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        # Code inside this block will be executed only if the test case passed
        # the 'if' condition and will be ignored otherwise
        # This can be used to test only a particular code-fragment
        assert True == True
    except Exception as e:
        # Code inside this block will be executed only if the test case fails
        # the 'if' condition and will be ignored otherwise
        raise e
    finally:
        # You can also use this space to clean and close any comples objects
        # created for testing, like files etc
        pass


# Generated at 2022-06-26 02:00:42.245525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 02:00:51.593822
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = load_env_file(lines, write_environ=dict())
    expected = [('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for item in output:
        if item not in expected:
            return False
    return True


# Generated at 2022-06-26 02:01:02.172224
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = '-8.7V)R+6M*'
    str_1 = '7M~T%8}'
    str_2 = '@Q/X'
    str_3 = '4N<8[O+4>'
    list_0 = []
    list_0.append(str_0)
    list_0.append(str_1)
    list_0.append(str_2)
    list_0.append(str_3)
    list_1 = parse_env_file_contents(list_0)
    #print(list(list_1))

# Generated at 2022-06-26 02:01:12.622370
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v

        environ[k] = v

    assert changes == [('TEST', '.../yeee'),
                  ('THISIS', '.../a/test'),
                  ('YOLO',
                  '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 02:01:21.450316
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['PATH=${HOME}', 'TEST=~/test'],) == [('PATH', '/home/...'), ('TEST', '.../test')]
    assert parse_env_file_contents(['PATH=${HOME}', 'TEST=~/test']) == [('PATH', '/home/...'), ('TEST', '.../test')]
    assert parse_env_file_contents(['HELLO=hello'],) == [('HELLO', 'hello')]
    assert parse_env_file_contents(['HELLO=hello']) == [('HELLO', 'hello')]
    assert parse_env_file_contents() == []
    assert parse_env_file_contents([]) == []

# Generated at 2022-06-26 02:01:25.492636
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)


# Generated at 2022-06-26 02:01:36.929224
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path
    from .test_module import _TestDict
    from .test_module import _TestList
    from .test_module import _TestTuple

    # build test_contents
    test_contents = [
        '# comment',
        'HOME = /Users/driller',
        'TEST = ${HOME}/yeee',
        'THISIS = "~/a/test"',
        'YOLO = "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"',
        'PATH = /some/path'
    ]

    # build expected_pairs
    # NOTE: This is the most readable way, but turns out to be the slowest in
    # terms of overall parse_env_file_contents() runtime.
    expected

# Generated at 2022-06-26 02:01:43.523261
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Case 0
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    fetched = parse_env_file_contents(lines)
    expected = [
        ('TEST', '~/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]
    result = [val for val in fetched]

    assert(result == expected)


# Generated at 2022-06-26 02:01:57.561203
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Input arguments
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Function under test
    ret_val = parse_env_file_contents(lines)

    # Output values
    expected_ret_val = [('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Assertions
    message = 'Unexpected return value for function, expected "%s", received "%s"' % (expected_ret_val, ret_val)
    assert ret_val