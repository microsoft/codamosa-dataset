

# Generated at 2022-06-26 01:52:06.590649
# Unit test for function load_env_file
def test_load_env_file():
    env_vars = load_env_file(
        ['export TEST=${HOME}/yeee-$PATH', 'export THISIS=~/a/test', 'export YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
        write_environ=None
    )
    #print(env_vars)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-26 01:52:07.754926
# Unit test for function load_env_file
def test_load_env_file():
    assert True



# Generated at 2022-06-26 01:52:15.414518
# Unit test for function load_env_file
def test_load_env_file():
    env_file_path = os.path.join(os.path.dirname(__file__), 'env_vars')
    with open(env_file_path) as f:
        lines = f.readlines()

    lines = [line.strip() for line in lines]

    d = load_env_file(lines)
    assert len(d.items()) == 3

    assert d['TEST'] == 'this works'
    assert d['THISIS'] == '~/a/test'
    assert d['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-26 01:52:26.383235
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)
    expected = [('TEST', '${HOME}/yeee-$PATH'),
                ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert(output == expected)



# Generated at 2022-06-26 01:52:34.317865
# Unit test for function load_env_file
def test_load_env_file():
    env_file_lines = """
# I am a comment
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    os.environ['HOME'] = os.path.expanduser('~')
    os.environ['PATH'] = os.pathsep.join(os.environ['PATH'].split(os.pathsep)[:2])
    load_env_file(env_file_lines.split('\n'))



# Generated at 2022-06-26 01:52:39.603082
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:52:49.207565
# Unit test for function load_env_file
def test_load_env_file():
    env = {'HOME': '/home/y'}

    expected = collections.OrderedDict((
        ('TEST', os.path.join(env['HOME'], 'yeee', 'yes')),
        ('THISIS', os.path.join(env['HOME'], 'a/test')),
        ('YOLO', os.path.join(env['HOME'], "swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))
    ))

    lines = [
        "TEST='$HOME'/yeee/'yes'",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]


# Generated at 2022-06-26 01:52:59.547063
# Unit test for function load_env_file
def test_load_env_file():
    test_lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    changes = load_env_file(test_lines)

    assert 'TEST' in changes
    assert '${HOME}' not in changes['TEST']
    assert '${HOME}' in test_lines[0]
    assert '$PATH' not in changes['TEST']
    assert '~' not in changes['TEST']
    assert '~' in test_lines[0]

    assert 'THISIS' in changes
    assert '~' not in changes['THISIS']

    assert 'YOLO' in changes

# Generated at 2022-06-26 01:53:01.313118
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing function parse_env_file_contents")

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    parse_env_file_contents(lines)



# Generated at 2022-06-26 01:53:12.673117
# Unit test for function load_env_file
def test_load_env_file():
    str_0 = 'ey&:IplaH]&{%'
    str_1 = expand(str_0)

    lines_0 = [
    "${$",
    '{${${${${${]}&]&%{&%',
    "${$",
    "{$$"
    ]

    write_environ_0 = dict()
    write_environ_1 = dict()

    write_environ_0['TEST'] = 'test'

    changes_0 = load_env_file(lines_0, write_environ_1)
    changes_0 = load_env_file(lines_0, write_environ_0)
    changes_0 = load_env_file(lines_0, write_environ_0)

# Generated at 2022-06-26 01:53:24.458328
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert next(result) == expected[0]
    assert next(result) == expected[1]
    assert next(result) == expected[2]
    return


# Generated at 2022-06-26 01:53:32.432720
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = {'TEST':'~/yeee', 'THISIS':'~/a/test', 'YOLO':'~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    assert result == expected


# Generated at 2022-06-26 01:53:38.814142
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    print(result)
    assert result == (('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


# Generated at 2022-06-26 01:53:48.099123
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [('TEST', '/home/yeee'), ('THISIS', '/home/a/test'), ('YOLO', '/home/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]





# Generated at 2022-06-26 01:53:50.160317
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(states)) == [('FOO', 'test')]



# Generated at 2022-06-26 01:53:56.259721
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 01:54:06.068939
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Parses env file content.

    From honcho.
    """

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out_1 = dict(parse_env_file_contents(lines))
    print('out_1: {0}'.format(out_1))
    assert out_1 == OrderedDict([('TEST',
                                  '${HOME}/yeee'),
                                 ('THISIS',
                                  '~/a/test'),
                                 ('YOLO',
                                  '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-26 01:54:14.230232
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Example 0
    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results_0 = parse_env_file_contents(lines_0)
    if (results_0[0][0] == 'TEST'):
        assert(results_0[0][1] == expand(lines_0[0].split('=')[1]))

    # Example 1
    lines_1 = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results_1 = parse_env_file_

# Generated at 2022-06-26 01:54:21.407980
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_dict = load_env_file(lines, write_environ=dict())
    assert env_dict == {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


# Generated at 2022-06-26 01:54:23.381242
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: Test case 1
    test_parse_env_file_contents_1()


# Generated at 2022-06-26 01:54:31.723889
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert [x for x in parse_env_file_contents(lines)] == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-26 01:54:41.269878
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    assert result['TEST'] == '.../yeee'
    assert result['THISIS'] == '.../a/test'
    assert result['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-26 01:54:42.696208
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert 1 == 1
    print("Test case 0 passed successfully")


# Generated at 2022-06-26 01:54:54.571184
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        '# comment',
        '',
        'export TEST=${HOME}/yeee-$PATH',
        "export THISIS='~/a/test'",
        'export YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"',
    ]

    r = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        r[k] = v


# Generated at 2022-06-26 01:55:04.161264
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict([('TEST', os.path.expandvars('${HOME}/yeee')),
             ('THISIS', os.path.expanduser('~/a/test')),
             ('YOLO',
              os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    lines = ['KEY=VAL']
    assert load_env_file(lines, write_environ=dict()) == OrderedDict

# Generated at 2022-06-26 01:55:06.036155
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = '$HOME/'
    str_1 = expand(str_0)


# Generated at 2022-06-26 01:55:15.731189
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = tuple(parse_env_file_contents(test_lines))
    expected = (('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    assert result == expected


# Generated at 2022-06-26 01:55:26.530298
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    global expansion_dict
    expansion_dict = dict() # holds expansions of environment variables in the form of expansion_dict["variable_name"] = "expansion"
    #expansion_dict = {"variable_name":"expansion"}
    global expansion_list
    expansion_list = [] # holds environment variables in the form of expansion_list[index] = "variable_name"
    #expansion_list = ["variable_name"]

    global expansion_index
    expansion_index = 0 # holds the index of the most recently added environment variable into the expansion_list

    global expansion_val
    expansion_val = [] # holds expansions of environment variables in the form of expansion_list[index] = "expansion"
    #expansion_val = ["expansion"]

    global expansion_val_index
    expansion_val_index = 0 # holds the index of the most recently added

# Generated at 2022-06-26 01:55:37.005861
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines      = ['TEST=${HOME}/yeee','THISIS=~/a/test','YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result_key = ['TEST','THISIS','YOLO']
    result_val = ['.../yeee','.../a/test','.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    for i,(key,val) in enumerate(result):
        assert key == result_key[i]
        assert val == result_val[i]


# Generated at 2022-06-26 01:55:48.378619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    #  - test empty env file
    res = list(parse_env_file_contents())
    assert res == [], f'unexpected output for empty env file {res}'
    
    #  - test empty env file with new line
    res = list(parse_env_file_contents([""]))
    assert res == [], f'unexpected output for empty env file with new line {res}'

    #  - test empty env file with new line and spaces
    res = list(parse_env_file_contents(["  "]))
    assert res == [], f'unexpected output for empty env file with new line and spaces {res}'

    #  - test empty env file with new line and spaces and comments

# Generated at 2022-06-26 01:55:57.520044
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file = 'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    assert list(parse_env_file_contents(file.split('\n'))) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]


# Generated at 2022-06-26 01:56:06.347237
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert result == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:56:08.136222
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents() == (('DB_NAME','my_name'),('DB_USER','my_user'),
                                         ('DB_PASS','my_pass'),('DB_HOST','my_host'))


# Generated at 2022-06-26 01:56:17.550486
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Example 1:
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    my_result = list(parse_env_file_contents(lines))
    expected_result = [('TEST', '${HOME}/yeee'),('THISIS', '~/a/test'),('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert my_result == expected_result, "Error in test #1"
    # Example 2:
    lines = ['TEST=\'$HOME/yeee\'']

# Generated at 2022-06-26 01:56:22.551784
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert len(list(values)) == 3


# Generated at 2022-06-26 01:56:31.706498
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)
    assert res == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 01:56:35.318619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print(parse_env_file_contents())
    for k,v in parse_env_file_contents():
        print(k,v)
    print(list(parse_env_file_contents()))

# Generated at 2022-06-26 01:56:36.682370
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents('') == ''

# Generated at 2022-06-26 01:56:43.814368
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing function: parse_env_file_contents')

    # Test 1
    print('\tTest 1')

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_parse_env_file_contents_1_actual = list(parse_env_file_contents(lines))
    test_parse_env_file_contents_1_expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert test_parse_env_file_cont

# Generated at 2022-06-26 01:56:50.310634
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open(os.path.join(os.path.dirname(__file__), 'tests/test_parse_env_file_contents.txt')) as f:
        lines: typing.List[str] = f.readlines()

    lines_out: typing.Generator[typing.Tuple[str, str], None, None] = parse_env_file_contents(lines)
    for line_out in lines_out:
        print(line_out)


# Generated at 2022-06-26 01:57:04.877547
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # from io import StringIO

    # lines = StringIO("TEST=~/yeee THINGS=swag\nOVERFLOW=0")
    # lines = StringIO("TEST='~/yeee' THINGS='swag'")

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    mappings = parse_env_file_contents(lines)
    print(list(mappings))

    # with open('/Users/hannes/Dropbox/Python/Baum/config/local.env', 'r') as f:
    #     mappings = parse_env_file_contents(f)
    # for k, v

# Generated at 2022-06-26 01:57:07.944503
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-26 01:57:18.702043
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    changes = load_env_file(lines, write_environ=dict())
    assert changes == OrderedDict([('TEST', '.../yeee-$PATH'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-26 01:57:27.223176
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'ey&:IplaH]&{%'
    str_1 = '"\tSTR_0 = \'asd\'"'
    str_2 = '"\tSTR_1 = \'{0}\'"'.format(str_0)
    str_3 = '"\tSTR_2 = \'{0}\'"'.format(str_1)
    str_4 = '"\tSTR_3 = \'{0}\'"'.format(str_2)
    str_5 = '\tSTR_5 = \'{0}\''.format(str_3)
    str_6 = '\tSTR_6 = \'{0}\''.format(str_4)
    str_7 = '\tSTR_7 = \'{0}\''.format(str_5)

# Generated at 2022-06-26 01:57:37.126425
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # case 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result_1 = list(parse_env_file_contents(lines))
    expected_result_1 = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert result_1 == expected_result_1
    # case 2

# Generated at 2022-06-26 01:57:46.483693
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing for function parse_env_file_contents")
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_result = dict(parse_env_file_contents(lines))
    expected_result = {'TEST': '$HOME/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    assert test_result == expected_result, f"Expected: {expected_result}, but got: {test_result}"
    print("Test result: success")


# Generated at 2022-06-26 01:57:57.644343
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    str_0 = 'nTaEjnYJ`C}`ml'
    str_1 = 'ZbKG?i[F,f'
    str_2 = 'Yk-EF#}w/A]/'
    str_3 = 'gJmUOU'
    str_4 = 'lA}Kj'
    str_5 = '`f T|>'
    str_6 = 'vjK'
    str_7 = 'W-j'
    str_8 = 'qT'
    str_9 = 't|X'
    str_10 = 'V{'
    str_11 = 'iOo|'
    str_12 = 'ZeIQr'
    str_13 = 'k-Ic'
    str_14 = 'B'

# Generated at 2022-06-26 01:58:06.261985
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing with:
    #  ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Should give:
    #  OrderedDict([('TEST', '.../.../yeee-...:...'),
    #               ('THISIS', '.../a/test'),
    #               ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    # In prelude:
    #   version = 3.6

    # Init
    var_1 = range(16)
    var_2 = range(256)
    var_3 = int()
    var_4

# Generated at 2022-06-26 01:58:13.151554
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    empty_dict = {}
    out = parse_env_file_contents(lines)
    assert out != empty_dict


# Generated at 2022-06-26 01:58:22.137597
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee',
                                    'THISIS=~/a/test',
                                    'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [('TEST', '.../.../yeee'),
                                                                                                 ('THISIS', '.../a/test'),
                                                                                                 ('YOLO',
                                                                                                  '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-26 01:58:35.427034
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert(parse_env_file_contents(["FOO=BAR"]) == [("FOO", "BAR")])
    assert(parse_env_file_contents(["FOO=BAR", "#", "  #  BAZ=WOW"]) == [("FOO", "BAR")])
    assert(parse_env_file_contents(["FOO=BAR", "", "  ", "BAZ=WOW"]) == [("FOO", "BAR"), ("BAZ", "WOW")])
    assert(parse_env_file_contents(["FOO=BAR", "#"]) == [("FOO", "BAR")])
    assert(parse_env_file_contents(["FOO=BAR WOW"]) == [("FOO", "BAR WOW")])
   

# Generated at 2022-06-26 01:58:40.690989
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_0 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    str_0 = parse_env_file_contents(lines_0)


# Generated at 2022-06-26 01:58:51.107473
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_cases=[]
    # test case 1
    test_case1_input = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_case1_output = [('TEST', '~/yeee-~/swaggins:~/a/test'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    test_cases.append([test_case1_input,test_case1_output])


# Generated at 2022-06-26 01:58:52.505008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass


# Generated at 2022-06-26 01:58:54.093844
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assertEqual(parse_env_file_contents(), None)


# Generated at 2022-06-26 01:59:01.117587
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_0 = dict(parse_env_file_contents(lines))
    assert(dict_0['TEST'] == '.../yeee')
    assert(dict_0['THISIS'] == '.../a/test')
    assert(dict_0['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-26 01:59:05.693532
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True


# Generated at 2022-06-26 01:59:13.594889
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == dict(TEST='$HOME/yeee', THISIS='~/a/test', YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-26 01:59:24.494088
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Default case
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) ==  [('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    # Single quote case
    lines = ['TEST="${HOME}"/yeee', 'THISIS=\'~/a/test\'']

# Generated at 2022-06-26 01:59:25.341576
# Unit test for function parse_env_file_contents

# Generated at 2022-06-26 01:59:46.824377
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Check to see if the behavior is correct
    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-26 01:59:59.598981
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Input
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Expected
    expected = [('TEST', '.../yeee'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    actual = list(parse_env_file_contents(lines))

    # Are the two the same? (order shouldn't matter)
    expected_set = set(expected)
    actual_set = set(actual)

    assert expected_set == actual_set


# Generated at 2022-06-26 02:00:10.255566
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Unit test for parse_env_file_contents")

    # Test case 0 for function parse_env_file_contents
    print("Test case 0 for function parse_env_file_contents")

    T0_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    T0_expected_output = [('TEST', '.../.../yeee-...:...'),
                          ('THISIS', '.../a/test'),
                          ('YOLO',
                           '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-26 02:00:22.190080
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    list_0 = []
    list_0.append('ey&:IplaH]&{%')
    list_0.append('[pZ%)I|/f-Vi')
    list_0.append('8Mi9-zt7`%c[')
    list_0.append('#|>J;R4-a4+g')
    list_0.append('-:P5S5_5+E1Q')
    list_0.append(')FxU6X2!K$+U')
    list_0.append('B^_eHjK0/b-c')
    list_0.append('0_:1u,7Zh^q<')
    list_0.append('}xU+&*U6XdU6')

# Generated at 2022-06-26 02:00:26.970989
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, dict())




# Generated at 2022-06-26 02:00:32.131853
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=~/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']
    load_env_file(lines, write_environ=None)

    print(parse_env_file_contents(lines))



# Generated at 2022-06-26 02:00:37.614063
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO
    from .evil_test import expect_str
    source = StringIO('yolo=swaggins')
    lines = parse_env_file_contents(source)
    got_str = [k for k, v in lines]
    expect_str(got_str, 'yolo')



# Generated at 2022-06-26 02:00:42.654548
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = None
    if false:
        assert 0== parse_env_file_contents(lines)
    elif false:
        assert 0== parse_env_file_contents(lines)
    else:
        assert 0== parse_env_file_contents(lines)


# Generated at 2022-06-26 02:00:52.582894
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    source_str = '''
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''
    expected_str = '''OrderedDict([('TEST', '.../yeee'),
                     ('THISIS', '.../a/test'),
                     ('YOLO',
                      '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])'''
    lines = source_str.split('\n')
    lines = [l.strip() for l in lines if l]
    actual_str = str(parse_env_file_contents(lines))
    assert actual_str == expected_str

# Generated at 2022-06-26 02:00:57.506677
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-26 02:01:33.309870
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))

# Generated at 2022-06-26 02:01:40.536197
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert result == [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-26 02:01:43.282002
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    tstr = '@ { \n " +   [    6    ,    5    ]    :},{4:5,5:4}'
    vals = parse_env_file_contents(tstr.split(','))
    assert next(vals) == ('6', '5')


# Generated at 2022-06-26 02:01:55.792765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    str_00 = 'TEST=$HOME/yeee-$PATH'
    str_01 = 'THISIS=~/a/test'
    str_02 = 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    list_0 = [str_00, str_01, str_02]

    # print(list_0)

    ret_0 = parse_env_file_contents(list_0)

    # print(ret_0)

    for i_0 in ret_0:
        print(i_0)
