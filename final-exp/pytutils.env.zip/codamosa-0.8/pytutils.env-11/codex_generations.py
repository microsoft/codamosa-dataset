

# Generated at 2022-06-12 07:23:11.409097
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "# This is a comment",
        '# This is a comment too',
        "TEST = ${HOME}/yeee",
        "THISIS = '~/a/test'",
        '"YOLO" = "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"',
    ]

    correct_loads_dict = {"TEST": "~/yeee", "THISIS": "~/a/test", "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"}

    assert dict(parse_env_file_contents(lines)) == correct_loads_dict



# Generated at 2022-06-12 07:23:20.062590
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Arrange
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Act
    result = load_env_file(lines, write_environ=dict())

    # Assert
    assert len(result) == 3
    assert result['TEST'].startswith('.../yeee')
    assert result['THISIS'].startswith('.../a/test')
    assert result['YOLO'].startswith('.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:23:22.860741
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    failure_count, test_count = doctest.testmod(report=True)
    if failure_count:
        raise Exception('Doctest failed!')


test_load_env_file()

# Generated at 2022-06-12 07:23:33.187675
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Testing function parse_env_file_contents.
    """
    # First test case
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = load_env_file(lines, write_environ=dict())
    expected_lines = OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
        '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert lines == expected_lines

    # Second test case

# Generated at 2022-06-12 07:23:37.515600
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:23:42.731862
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-12 07:23:45.972975
# Unit test for function load_env_file
def test_load_env_file():
    # Load some arbitrary file, it doesn't matter
    with open('/etc/hosts', 'r') as f:
        lines = f.readlines()
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:23:51.940072
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_lines = [
        'TEST=test_value',
        'TEST2=another_test_value',
        'TEST3=test',
        f'TEST4={os.environ["HOME"]}',
    ]
    for k, v in parse_env_file_contents(env_lines):
        assert k in env_lines[0] or k in env_lines[1] or k in env_lines[2] or k in env_lines[3], f'"{k}" was not expected'

# Generated at 2022-06-12 07:23:57.726133
# Unit test for function load_env_file
def test_load_env_file():
    from unittest.mock import patch

    # Test patching environment variables
    with patch.dict(os.environ, {}, clear=True):
        lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
        load_env_file(lines)

        assert os.environ["TEST"] == "..."
        assert os.environ["THISIS"] == "..."

        # Test return value
        assert load_env_file(lines) == collections.OrderedDict(
            [("TEST", "..."), ("THISIS", "...")])

# Generated at 2022-06-12 07:24:06.467701
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-12 07:24:18.960996
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents.
    """

    def assert_env_file_contents(lines: typing.Iterable[str],
                                 expected_env_vars: typing.Dict[str, str]):
        for k, v in parse_env_file_contents(lines):
            assert k in expected_env_vars
            assert v == expected_env_vars[k]


# Generated at 2022-06-12 07:24:21.176686
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing parse_env_file_contents.')

    print(parse_env_file_contents(['ONE=1', 'TWO=2', 'THREE="$ONE/$TWO"']))



# Generated at 2022-06-12 07:24:31.806550
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Tests

    # Test empty file
    assert list(parse_env_file_contents([])) == []

    # Test a single line
    lines = ['TEST=${HOME}/yeee-$PATH']
    result = list(parse_env_file_contents(lines))
    assert result[0][0] == "TEST"
    assert result[0][1] == '${HOME}/yeee-$PATH'
    assert result[0][1].startswith("$")

    assert list(parse_env_file_contents(lines)) == list(parse_env_file_contents(iter(lines)))

    # Test a file with 3 lines

# Generated at 2022-06-12 07:24:37.775272
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:24:45.576900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines, write_environ=dict())
    assert len(ret) == 3
    assert ret['TEST'] != ''
    assert ret['THISIS'] != ''
    assert ret['YOLO'] != ''


if __name__ == '__main__':
    import sys
    sys.exit(load_env_file(sys.stdin) or 0)

# Generated at 2022-06-12 07:24:52.364780
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # No result lines
    def empty_generator():
        for i in range(0, 0):
            yield None

    assert None is next(parse_env_file_contents(empty_generator()), None)

    # Three result lines
    result = list(parse_env_file_contents(lines))

    assert len(result) == 3

    assert result[0] == ('TEST', os.path.expandvars(lines[0].split("=")[1]))

# Generated at 2022-06-12 07:24:59.255631
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Check that all of the following parse
    # Check that the values are expanded
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    changes = load_env_file(lines, write_environ=None)

    assert changes["TEST"].startswith(os.path.expanduser("~"))
    assert changes["TEST"].endswith("-{}".format(os.getenv("PATH")))
    assert changes["THISIS"].startswith(os.path.expanduser("~"))

# Generated at 2022-06-12 07:25:09.235331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)

    # Transform to list, it's easier to work with (and we don't care about order)
    results = list(results)

    assert len(results) == 3

    # We don't care about order, so we sort the list
    results = sorted(results, key=lambda x: x[0])

    # Test first entry
    assert results[0][0] == 'TEST'
    assert results[0][1] == '${HOME}/yeee'

    # Test second entry
    assert results[1][0] == 'THISIS'

# Generated at 2022-06-12 07:25:18.054754
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST="${HOME} yeee"',
        'THISIS=\'~/a/test\'',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'COMMENT',
        'ESCAPE_QUOTES=\\"',
    ]
    assert tuple(parse_env_file_contents(lines)) == (
        ('TEST', '... yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ('ESCAPE_QUOTES', '"'),
    )

# Generated at 2022-06-12 07:25:22.595866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST={HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    print(values)



# Generated at 2022-06-12 07:25:33.920867
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    msg = r"Got a different result than expected when parsing env file contents."
    assert expand(r"${HOME}") == expand(r"~"), msg
    assert expand(r"${HOME}") == expand(r"~"), msg
    assert expand(r"${HOME}/a") == expand(r"~/a"), msg
    assert expand(r"${HOME}/a/b") == expand(r"~/a/b"), msg
    assert expand(r"${HOME}/a/b/c") == expand(r"~/a/b/c"), msg
    assert expand(r"${HOME}/a/b/c/d") == expand(r"~/a/b/c/d"), msg

# Generated at 2022-06-12 07:25:40.779671
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    values = parse_env_file_contents(lines)

    assert (('TEST', '${HOME}/yeee') == next(values))
    assert (('THISIS', '~/a/test') == next(values))
    assert (('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == next(values))



# Generated at 2022-06-12 07:25:43.621438
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-12 07:25:52.233349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing if the values of each key are expanded
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v

    assert changes['TEST'] == os.environ['HOME'] + '/yeee-' + os.environ['PATH']
    assert changes['THISIS'] == os.environ['HOME'] + '/a/test'

# Generated at 2022-06-12 07:26:00.721384
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import contextlib
    import textwrap

    contents = textwrap.dedent('''
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        NOT_EXPANDED=$ENV_VAR_THAT_DOES_NOT_EXIST
        'TEST2=TEST_TWO'
    ''').strip()


# Generated at 2022-06-12 07:26:10.717947
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'REPLACE_FOO=${FOO/foo/bar}',
        'REPLACE_HOME=${HOME/home/swag}',
        'REPLACE_EMPTY=${EMPTY/foo/bar}'
    ]


# Generated at 2022-06-12 07:26:17.403413
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '{}/yeee'.format(os.path.expanduser('~'))),
        ('THISIS', '{}/a/test'.format(os.path.expanduser('~'))),
        ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.path.expanduser('~')))
    ]



# Generated at 2022-06-12 07:26:27.307860
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    test_data = [
        # triplet of (filename, expected_data, raises)
        ('./testenvfile.env', {'PATH': '/home/yeee', 'TEST': '${PATH}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}, None),
        # ('./testenvfile_bad.env', {}, ValueError),
    ]

    for filename, expected_data, raises in test_data:
        try:
            actual_data = load_env_file(lines=open(filename), write_environ=None)
        except Exception as e:
            actual_data = repr(e)

# Generated at 2022-06-12 07:26:35.806112
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # type: () -> None
    import pathlib

    env_file_contents = 'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    env_file = pathlib.Path('test.env')
    env_file.write_text(env_file_contents)

    values = parse_env_file_contents(env_file.read_text().splitlines())

    for k, v in values:
        v = expand(v)
        assert (k, v) is not None
        if k == 'TEST':
            assert v == '{}/yeee-{}'.format(expand('${HOME}'), expand('${PATH}'))

# Generated at 2022-06-12 07:26:46.054440
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '{}/yeee'.format(os.environ.get('HOME'))),
                                                    ('THISIS', '{}/a/test'.format(os.environ.get('HOME'))),
                                                    ('YOLO',
                                                     '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(
                                                         os.environ.get('HOME')))]



# Generated at 2022-06-12 07:26:55.234864
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    ('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-12 07:27:04.906965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    results = load_env_file(lines, write_environ=None)
    assert results == {
        'TEST': os.path.expanduser('~') + '/yeee',
        'THISIS': os.path.expanduser('~') + '/a/test',
        'YOLO': os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-12 07:27:11.376987
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:27:22.746221
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .test_functional import assert_function_returns
    from .test_functional import assert_function_return_type

    assert_function_return_type(
        parse_env_file_contents,
        (
            ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
        ),
        tuple,
    )


# Generated at 2022-06-12 07:27:26.533226
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    >>> for k, v in parse_env_file_contents(lines):
    ...     print(k, v)
    TEST .../yeee
    THISIS .../a/test
    """



# Generated at 2022-06-12 07:27:35.489020
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = [{'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}]
    assert list(parse_env_file_contents(lines)) == output



# Generated at 2022-06-12 07:27:41.956585
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest as ut

    test_cases = [
        ("TEST=${HOME}/yeee", "TEST", "..." + os.sep + "/yeee"),
        ("THISIS=~/a/test", "THISIS", "..." + os.sep + "a" + os.sep + "test"),
        (r'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
         "YOLO", "..." + os.sep + "swaggins" + os.sep + "/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]


# Generated at 2022-06-12 07:27:46.108630
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-12 07:27:55.717843
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert d['TEST'] == os.path.expandvars(os.path.join('${HOME}', 'yeee'))
    assert d['THISIS'] == os.path.expanduser(os.path.join('~', 'a', 'test'))
    assert d['YOLO'] == os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:28:03.998255
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Imports (use when testing functions)
    # import pytest
    # from typing import Iterable
    # from typing import Generator
    # from typing import Tuple

    # Functions
    def get_friendly_vals(lines: typing.Iterable[str] = None) -> typing.Generator[typing.Tuple[str, str], None, None]:
        for k, v in parse_env_file_contents(lines):
            v = v.replace("/home/dev/Workspace/projects/proj", "$HOME")
            v = v.replace("/home/dev/Workspace/projects/proj/.venv/lib/python3.6/site-packages", "$PYTHON_SITE_PACKAGES")

# Generated at 2022-06-12 07:28:08.651206
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:28:15.571913
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = {}

    for k, v in parse_env_file_contents(lines):
        d[k] = v

    print(d)



# Generated at 2022-06-12 07:28:24.680695
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    vals = parse_env_file_contents(lines)
    vals = list(vals)  # make an actual list out of the generator

    assert len(vals) == 3

    assert vals[0][0] == 'TEST'
    assert re.search(r'.../.../yeee-...:...', vals[0][1]) is not None

    assert vals[1][0] == 'THISIS'
    assert re.search(r'.../a/test', vals[1][1]) is not None


# Generated at 2022-06-12 07:28:35.263181
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', f'{os.environ["HOME"]}/yeee'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:28:40.879279
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = parse_env_file_contents(lines)
    assert (('TEST', '~/yeee') in lines)
    assert (('THISIS', '~/a/test') in lines)
    assert (('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in lines)



# Generated at 2022-06-12 07:28:49.309201
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = load_env_file(lines, write_environ=dict())

    assert output['TEST'] == os.path.expanduser('~/yeee')
    assert output['THISIS'] == os.path.expanduser('~/a/test')
    assert output['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:28:54.316154
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['ONE=foo', 'TWO=bar', 'THREE=baz']

    result = collections.OrderedDict()
    for key, value in parse_env_file_contents(lines):
        result[key] = value

    assert result == collections.OrderedDict([('ONE', 'foo'), ('TWO', 'bar'), ('THREE', 'baz')])



# Generated at 2022-06-12 07:28:58.698765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Parse env file contents unit test.

    From honcho.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:01.424418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:03.403560
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from . import utils
    assert utils.run_doctest(parse_env_file_contents, globals())



# Generated at 2022-06-12 07:29:10.445109
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    output = parse_env_file_contents(lines)
    assert list(output) == [
        ("TEST", "${HOME}/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]

# Generated at 2022-06-12 07:29:18.856416
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = """# This is a comment
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    results = parse_env_file_contents(contents.split("\n"))
    expected = [("TEST", "{HOME}/yeee-$PATH"),
                ("THISIS", "~/a/test"),
                ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]

    for result, expected in zip(results, expected):
        assert result == expected



# Generated at 2022-06-12 07:29:26.759634
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert d['TEST'].endswith('yeee')
    assert d['THISIS'].endswith('a/test')
    assert d['YOLO'].endswith('swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:29:36.913265
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)

    expected = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    # We can't portably compare two dicts directly, so test each item individually.
    for key in expected:
        assert key in result
        assert result[key] == expected[key]



# Generated at 2022-06-12 07:29:43.132827
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import os
    import tempfile

    _, filename = tempfile.mkstemp('.env', 'test_expandenv_parse_')


# Generated at 2022-06-12 07:29:53.949787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    assert isinstance(values, collections.abc.Generator)

    values = list(values)

    assert len(values) == 3

    assert values[0] == ('TEST', '$HOME/yeee')
    assert values[1] == ('THISIS', '~/a/test')
    assert values[2] == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:30:03.440418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:30:10.799811
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == OrderedDict([('TEST', '.../yeee'),
                                  ('THISIS', '.../a/test'),
                                  ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:30:18.384299
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = '''
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''

    result = list(parse_env_file_contents(content.split('\n')))

    assert [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ] == result


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:30:27.706055
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from unittest import TestCase
    from itertools import chain

    class ParseEnvFileContentsTest(TestCase):

        def test_single_line_flat(self):
            lines = ['TEST=${HOME}/yeee']

            actual = list(parse_env_file_contents(lines))

            self.assertEqual(1, len(actual))

            self.assertEqual('TEST', actual[0][0])
            self.assertEqual(os.environ['HOME'] + '/yeee', actual[0][1])

        def test_single_line_flat_with_tilde(self):
            lines = ['TEST=~/yeee']

            actual = list(parse_env_file_contents(lines))

            self.assertEqual(1, len(actual))

            self

# Generated at 2022-06-12 07:30:39.258832
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected_output = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    output = list(parse_env_file_contents(lines))

    assert len(expected_output) == len(output)
    for i in range(len(expected_output)):
        assert expected_output[i] == output[i]



# Generated at 2022-06-12 07:30:45.436468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    example = {
        'TEST': '${HOME}/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    results = parse_env_file_contents(example.keys())

    assert dict(results) == example



# Generated at 2022-06-12 07:30:55.173831
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:31:01.655272
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    sample_line = "TEST=${HOME}/yeee-$PATH"
    values = parse_env_file_contents([sample_line])
    key, val = next(values)
    val = os.path.expanduser(val)
    val = os.path.expandvars(val)

    assert key == "TEST"
    assert val.startswith(os.path.expanduser(os.environ["HOME"]))
    assert val.endswith(os.environ["PATH"])



# Generated at 2022-06-12 07:31:10.787520
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import os
    import shutil
    import logging

    logging.basicConfig(level=logging.DEBUG)

    test_data = (
        "TEST=${HOME}/yeee-PATH\n",
        "THISIS=~/a/test\n",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n",
    )

    with tempfile.TemporaryDirectory() as tmp_dir:
        env_file_path = os.path.join(tmp_dir, "test.env")
        logging.debug("Using env file: %s", env_file_path)

        with open(env_file_path, mode="w") as f:
            f.writelines(test_data)

        expected = collections.Ord

# Generated at 2022-06-12 07:31:18.911242
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    class TestCase:
        def __init__(self, lines, expected_changes):
            self.lines = lines
            self.expected_changes = expected_changes


# Generated at 2022-06-12 07:31:27.295093
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO
    from contextlib import redirect_stdout

    f = StringIO()
    with redirect_stdout(f):
        env_lines = (
            'TEST=${HOME}/yeee',
            'THISIS=~/a/test',
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        )
        actual = parse_env_file_contents(env_lines)
        expected = ('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        print(actual, expected)
        assert actual == expected



# Generated at 2022-06-12 07:31:38.169671
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Empty lines should be ignored
    lines = ['\n', '\n', '\n', '\n']
    assert [] == list(parse_env_file_contents(lines))

    # Should be able to parse empty lines and comments
    lines = ['A=2\n', '#B=3\n', '# this is comment for C\n', '# this is comment for D\n', '#\n', '', 'E=4\n']
    assert [('A', '2'), ('E', '4')] == list(parse_env_file_contents(lines))

    # Should be able to parse empty quotes
    lines = ['A=\n', 'B=""\n', "C=''"]

# Generated at 2022-06-12 07:31:46.423971
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = collections.OrderedDict(list(parse_env_file_contents(lines)))
    assert changes['TEST'] == os.getenv('HOME') + '/yeee-' + os.getenv('PATH')
    assert changes['THISIS'] == os.getenv('HOME') + '/a/test'
    assert changes['YOLO'] == os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    return


if __name__ == '__main__':
    import doctest
    doctest

# Generated at 2022-06-12 07:31:48.132262
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 07:32:05.709202
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests the function parse_env_file_contents on a toy env file.
    """
    test_env_file = """# Comment
                                                    TEST=${HOME}/yeee
                                                    THISIS=~/a/test
                                                    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"""
    test_env_dict = dict([('TEST', '${HOME}/yeee'),
                          ('THISIS', '~/a/test'),
                          ('YOLO',
                           '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    # test_env_dict_results = dict([('TEST', '/Users/juan/yeee'),
    #                

# Generated at 2022-06-12 07:32:14.761957
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Expected output is a 2-tuple; the first element should be the key and the second element the value.
    """
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '${HOME}/yeee'),
                ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == expected

# Generated at 2022-06-12 07:32:15.841719
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:32:24.628414
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = """
    TEST=${HOME}/yeaa
    BEEF=${HOME}/${BEEF_ISSUE}
    """
    changes = collections.OrderedDict()
    for k, v in parse_env_file_contents(contents.strip().split('\n')):
        changes[k] = v
    assert changes == collections.OrderedDict([('TEST', '.../yeaa'),
                                               ('BEEF', '.../$BEEF_ISSUE')])
    environ = collections.OrderedDict()
    changes = load_env_file(contents.strip().split('\n'), write_environ=environ)

# Generated at 2022-06-12 07:32:29.383143
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = dict(parse_env_file_contents(lines))
    assert 'TEST' in env
    assert 'THISIS' in env
    assert 'YOLO' in env



# Generated at 2022-06-12 07:32:34.681765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pprint import pprint

    pprint(parse_env_file_contents(['PATH=$PATH:/usr/local/bin', 'TMP=${TMP}/app']))
    pprint(parse_env_file_contents(['PATH=$PATH:/usr/local/bin', 'TMP=${TMP}/app']))

    # >>> pprint(parse_env_file_contents(['PATH=$PATH:/usr/local/bin', 'TMP=${TMP}/app']))
    # <generator object parse_env_file_contents at 0x7f8f0a825b48>
    # >>> pprint(parse_env_file_contents(['PATH=$PATH:/usr/local/bin', 'TMP=${TMP}/app']))
    # <generator object parse_env_file

# Generated at 2022-06-12 07:32:46.237599
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)

    # This makes pytest fail
    assert contents.__next__() == ('TEST', os.path.expanduser('~/yeee'))
    assert contents.__next__() == ('THISIS', os.path.expanduser('~/a/test'))
    assert contents.__next__() == ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-12 07:32:53.660830
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test file parsing
    content = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST

    # This is a comment!
    TEST2="Test with spaces"
    """

    values = parse_env_file_contents(content.splitlines())

    expected_values = [
        ("TEST", "${HOME}/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
        ("TEST2", "Test with spaces"),
    ]


# Generated at 2022-06-12 07:33:03.887918
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Simple test to check that values returned by parse_env_file_contents() function
    are as expected.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    value_of_home = os.path.split(os.path.expanduser('~'))[-1]
    value_of_path = os.path.expandvars('$PATH')
    current_dir = os.path.dirname(os.path.realpath(__file__))
