

# Generated at 2022-06-12 07:22:59.110608
# Unit test for function load_env_file
def test_load_env_file():
    # load_env_file
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:23:03.609390
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    for k, v in parse_env_file_contents(lines):
        assert changes[k] == v



# Generated at 2022-06-12 07:23:14.750401
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.expandvars(os.path.expanduser('${HOME}/yeee'))),
        ('THISIS', os.path.expandvars(os.path.expanduser('~/a/test'))),
        ('YOLO', os.path.expandvars(os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))),
    ]



# Generated at 2022-06-12 07:23:18.564398
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=("TEST='test value'", "YOLO=swag"))) == [("TEST", "test value"), ("YOLO", "swag")]

# Generated at 2022-06-12 07:23:20.650308
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-12 07:23:28.557490
# Unit test for function load_env_file
def test_load_env_file():
    from unittest import TestCase, main
    import sys

    class TestVariableDefaults(TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-12 07:23:40.000842
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import sys
    import unittest

    from contextlib import redirect_stdout

    from hamcrest import *

    from .load_env_file import load_env_file

    class Test(unittest.TestCase):
        def test_load_env_file_01(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            environ = dict()

            result = load_env_file(lines, write_environ=environ)

            f = io.StringIO()

            with redirect_stdout(f):
                print(environ)

            assert_that(environ, has_entries(environ))



# Generated at 2022-06-12 07:23:43.375693
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee'], {}) == collections.OrderedDict([('TEST', os.environ['HOME'] + '/yeee')])



# Generated at 2022-06-12 07:23:53.488929
# Unit test for function load_env_file
def test_load_env_file():
    values = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    changes = load_env_file(values)

    # print(changes)

    assert len(changes) == 3

    assert changes['TEST'] == os.environ['HOME'] + '/yeee-' + os.environ['PATH']
    assert changes['THISIS'] == os.environ['HOME'] + '/a/test'
    assert changes['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:23:57.109482
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:24:08.363217
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    items = parse_env_file_contents(lines)

    assert isinstance(items, collections.abc.Generator)

    output = collections.OrderedDict(items)

    assert isinstance(output, collections.abc.Mapping)

    assert output['TEST'] == os.path.expandvars(os.path.expanduser('${HOME}/yeee'))
    assert output['THISIS'] == os.path.expandvars(os.path.expanduser('~/a/test'))
    # Does not expand nonexistent variables
    assert output['YOLO'] == os

# Generated at 2022-06-12 07:24:17.063552
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:24:20.616296
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True



# Generated at 2022-06-12 07:24:28.873382
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:24:33.329685
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert isinstance(values, collections.Iterator)
    assert isinstance(next(values), tuple)



# Generated at 2022-06-12 07:24:40.022056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_contents = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    lines = env_contents.strip().split("\n")

    expected_output = [("TEST", f"{os.path.expanduser('~')}/yeee"),
                       ("THISIS", f"{os.path.expanduser('~')}/a/test"),
                       ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]

    output = [(k, v) for k, v in parse_env_file_contents(lines)]

    assert output == expected_output

# Generated at 2022-06-12 07:24:48.304815
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = dict(parse_env_file_contents(lines))

    assert len(values) == 3
    assert values['TEST'] == os.path.expanduser('~') + '/yeee'
    assert values['THISIS'] == os.path.expanduser('~/a/test')
    assert values['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:24:56.103227
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = parse_env_file_contents(lines)

    assert next(lines) == (
        'TEST',
        os.path.join(os.getenv('HOME'), 'yeee'),
    )

    assert next(lines) == (
        'THISIS',
        os.path.join(os.getenv('HOME'), 'a', 'test'),
    )


# Generated at 2022-06-12 07:25:03.539750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = dict(parse_env_file_contents(lines))
    assert(len(result) == 3)
    assert(result['TEST'] == expand('${HOME}/yeee'))
    assert(result['THISIS'] == expand('~/a/test'))
    assert(result['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-12 07:25:08.739117
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Normal case
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    parse_env_file_contents(lines)


if __name__ == '__main__':
    pass

# Generated at 2022-06-12 07:25:19.422991
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Note: This is not a reasonable use case for a generator, but it is useful for testing
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    vars = parse_env_file_contents(lines)
    vars = list(vars)

    assert vars[0] == ('TEST', '.../yeee')
    assert vars[1] == ('THISIS', '.../a/test')
    assert vars[2] == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:25:28.899710
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # From pkginfo on rtd.
    lines = ['FOO=1', 'FOO=2', 'BAR=1']

    assert list(parse_env_file_contents(lines)) == [('FOO', '1'), ('FOO', '2'), ('BAR', '1')]

    # From honcho.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert [item[1] for item in parse_env_file_contents(lines)] == ['.../yeee', '.../a/test', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-12 07:25:32.527610
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = io.StringIO(
        'TEST=${HOME}/yeee-$PATH\n'
        'THISIS=~/a/test\n'
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n'
    )

    ret = parse_env_file_contents(lines)

    results = collections.OrderedDict(ret)

    home_val = expand('~')
    path_val = expand('$PATH')

    assert results['TEST'] == os.path.join(home_val, 'yeee-') + path_val
    assert results['THISIS'] == os.path.join(home_val, 'a', 'test')

# Generated at 2022-06-12 07:25:40.998029
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def compare_ordered_dicts(dict1: dict, dict2: dict) -> bool:
        if len(dict1) != len(dict2):
            return False

        for k in dict1.keys():
            if k not in dict2.keys() or dict1[k] != dict2[k]:
                return False
        return True


# Generated at 2022-06-12 07:25:50.993201
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    assert os.path.expanduser('~') in next(values)[1]
    assert os.path.expanduser('~') in next(values)[1]
    assert os.path.expanduser('~') in next(values)[1]
    assert next(values, None) is None  # this is to verify that the generator is exhausted



# Generated at 2022-06-12 07:25:58.586410
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '$HOME/yeee-$PATH', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:26:04.528424
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:26:11.523409
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    expected = [
        ('TEST', expand('$HOME/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

    actual = list(parse_env_file_contents(lines))

    assert actual == expected



# Generated at 2022-06-12 07:26:17.595875
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    data = [
        ('TEST=${HOME}/yeee', ('TEST', expand('${HOME}/yeee'))),
        ('THISIS=~/a/test', ('THISIS', expand('~/a/test'))),
        ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))),
    ]

    for line, expected in data:
        result = next(parse_env_file_contents([line]))
        assert result == expected



# Generated at 2022-06-12 07:26:23.606995
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = parse_env_file_contents(lines)
    assert changes == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_

# Generated at 2022-06-12 07:26:31.969907
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$TEST/yeee',
             'THISIS=~/a/test',
             "YOLO='~/swaggins/$TEST'"]

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '$TEST/yeee')
    assert next(values) == ('THISIS', '~/a/test')
    assert next(values) == ('YOLO', '\'~/swaggins/$TEST\'')



# Generated at 2022-06-12 07:26:38.066746
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(['TEST=${HOME}/yeee', 'YOLO=~/swaggins'])) == {'TEST': '/.../yeee', 'YOLO': '/.../swaggins'}
    assert dict(parse_env_file_contents(['TEST=${HOME}/yeee', 'YOLO=~/swaggins', 'PATH=$PATH:~/my/path'])) == {'TEST': '/.../yeee', 'YOLO': '/.../swaggins', 'PATH': '/...:/.../my/path'}

# Generated at 2022-06-12 07:26:45.964680
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

# Generated at 2022-06-12 07:26:51.378381
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from sys import version_info
    from textwrap import dedent

    # Python 3.4+
    if version_info.major >= 3 and version_info.minor >= 4:
        exec(dedent(test_parse_env_file_contents.__doc__))


if __name__ == '__main__':
    import dbxdeploy.fs.env as env

    env.test_parse_env_file_contents()

# Generated at 2022-06-12 07:26:56.446294
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    assert results == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:05.548534
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()

    changes1 = parse_env_file_contents(lines)
    changes1_list = sorted(changes1, key=lambda x: x[0])

    changes2 = load_env_file(lines, environ)
    changes2_list = sorted(changes2, key=lambda x: x[0])


# Generated at 2022-06-12 07:27:13.060877
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=None)
    assert results == collections.OrderedDict([('TEST', '.../yeee'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO',
                                                '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:27:16.683391
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> test_parse_env_file_contents()
    """
    # TODO - how to get more informative failure message from doctest??
    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:27:25.066705
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = parse_env_file_contents(lines)
    results = dict(output)

    assert results == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:27:34.654631
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:27:44.447422
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_output = [('TEST', '...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == expected_output



# Generated at 2022-06-12 07:27:53.781997
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = load_env_file(lines, write_environ=None)

    assert lines['TEST'] == os.path.join(os.environ['HOME'], 'yeee-' + os.environ['PATH'])
    assert lines['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')
    assert lines['YOLO'] == os.path.join(os.environ['HOME'], 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:28:02.905656
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import io
    # capture output
    temp_stdout = sys.stdout
    sys.stdout = io.StringIO()
    test_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(test_lines)
    captured = sys.stdout.getvalue()
    # close the stream
    sys.stdout.close()
    # put the old stream back in place
    sys.stdout = temp_stdout
    # assert

# Generated at 2022-06-12 07:28:10.747076
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_file_contents = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    # Create mappings that hold the result
    expected_result = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    # Test
    assert expected_result == load_env_file(test_file_contents, write_environ=None)


# Unit test

# Generated at 2022-06-12 07:28:15.801380
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)
    # os.environ

# Generated at 2022-06-12 07:28:19.219998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['456=123', '456=567']
    values = parse_env_file_contents(lines)
    assert next(values) == ('456', '123')
    assert next(values) == ('456', '567')
    assert list(values) == []



# Generated at 2022-06-12 07:28:27.359863
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    parsed_lines = parse_env_file_contents(lines)

    expected_results = [
        (
            'TEST',
            '${HOME}/yeee-$PATH',
        ),
        (
            'THISIS',
            '~/a/test',
        ),
        (
            'YOLO',
            '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        ),
    ]

# Generated at 2022-06-12 07:28:36.485302
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO',
                                                                                   '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:28:42.469590
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    r = load_env_file(lines, write_environ=dict())

    assert r == collections.OrderedDict([('TEST', os.path.expandvars('${HOME}/yeee')),
                                        ('THISIS', os.path.expanduser('~/a/test')),
                                        ('YOLO', os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-12 07:28:52.626063
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', os.path.expanduser(os.path.expandvars('${HOME}/yeee-$PATH')))
    assert next(values) == ('THISIS', os.path.expanduser(os.path.expandvars('~/a/test')))

# Generated at 2022-06-12 07:29:08.411258
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    result = dict(parse_env_file_contents(lines))
    expected = dict(TEST=expand('${HOME}/yeee'),
                    THISIS=expand('~/a/test'),
                    YOLO=expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

    assert result == expected



# Generated at 2022-06-12 07:29:09.294789
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:29:13.677651
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:29:21.518073
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test that variable expansion works
    assert len(list(parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH']))) == 1
    assert len(list(parse_env_file_contents(lines=['TEST=$HOME/yeee-$PATH']))) == 1
    assert len(list(parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test']))) == 2
    assert len(list(parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins']))) == 3

    # TODO: How do I use unittest to check that os.path.expanduser and os.

# Generated at 2022-06-12 07:29:28.511130
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:29:38.677246
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """ Test function parse_env_file_contents """
    # Simple string
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert isinstance(values, collections.deque)

    # Expected values
    expected_values = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    for actual, expected in zip(values, expected_values):
        assert actual == expected

# Generated at 2022-06-12 07:29:46.124940
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:29:56.289940
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Single key, single value
    lines = ['TEST=test']
    assert list(parse_env_file_contents(lines)) == [('TEST', 'test')]

    # Single key, with quotes
    lines = [r'TEST="test \" test"']
    assert list(parse_env_file_contents(lines)) == [('TEST', 'test " test')]

    # Single key, with quotes
    lines = [r'TEST=\'test " test\'']
    assert list(parse_env_file_contents(lines)) == [('TEST', 'test " test')]

    # Single key, with quotes
    lines = [r'TEST="test \" test"' 'YOLO=swaggins']

# Generated at 2022-06-12 07:30:05.005178
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)
    assert data.__next__() == ('TEST', '~/yeee')
    assert data.__next__() == ('THISIS', '~/a/test')
    assert data.__next__() == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:30:05.818727
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:30:35.544318
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    dict_values = dict(values)

    assert os.path.expanduser(lines[0]) == dict_values[lines[0].split('=')[0]]
    assert os.path.expanduser(lines[1]) == dict_values[lines[1].split('=')[0]]
    assert os.path.expanduser(lines[2]) == dict_values[lines[2].split('=')[0]]



# Generated at 2022-06-12 07:30:40.666419
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    retval = load_env_file(lines, write_environ=dict())

    assert isinstance(retval, collections.OrderedDict)
    assert len(retval) == 3

    assert '${HOME}/yeee' != retval['TEST']
    assert '~/a/test' != retval['THISIS']
    assert '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' == retval['YOLO']



# Generated at 2022-06-12 07:30:47.427337
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass

# Generated at 2022-06-12 07:30:54.598807
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    vals = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parses = parse_env_file_contents(vals)

    assert next(parses) == ('TEST', '.../yeee')
    assert next(parses) == ('THISIS', '.../a/test')
    assert next(parses) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:31:04.093424
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    def test_parsing(lines: typing.Sequence[str], expected: typing.Dict[str, str]) -> None:
        lines = io.StringIO('\n'.join(lines))
        res = dict(parse_env_file_contents(lines))
        assert res == expected


# Generated at 2022-06-12 07:31:10.949233
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))
    assert d['TEST'] == expand('${HOME}/yeee')
    assert d['THISIS'] == expand('~/a/test')
    assert d['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:31:16.604562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['a=23', 'b=34', 'c=34']
    env = parse_env_file_contents(lines)
    assert (dict(env)) == {'a': '23', 'b': '34', 'c': '34'}

    lines = ['a=\\"nothing-to-see-here\\"']
    env = parse_env_file_contents(lines)
    assert (dict(env)) == {'a': '"nothing-to-see-here"'}

# Generated at 2022-06-12 07:31:22.118278
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        "THIS_IS_QUOTED='to test'",
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'EMPTY_STRING=""',
    ]

    keys = {
        'TEST',
        'THISIS',
        'THIS_IS_QUOTED',
        'YOLO',
        'EMPTY_STRING',
    }

    result = parse_env_file_contents(lines)

    for var in result:
        assert var[0] in keys
        keys.remove(var[0])

    assert not keys



# Generated at 2022-06-12 07:31:25.816722
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with pytest.raises(ValueError):
        lines = [
            'THISIS=~/a/test',
            '',
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        ]
        parse_env_file_contents(lines)



# Generated at 2022-06-12 07:31:34.914708
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    x = list(parse_env_file_contents(lines))
    assert len(x) == 3
    assert x == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:32:16.925522
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("TEST=${HOME}/yeee-$PATH\n")
        f.write("THISIS=~/a/test\n")
        f.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
        f.flush()

        lines = list(open(f.name))

        res = load_env_file(lines, write_environ=None)


# Generated at 2022-06-12 07:32:25.681731
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert 'TEST' in list(parse_env_file_contents(lines))[0]
    assert 'THISIS' in list(parse_env_file_contents(lines))[1]
    assert 'YOLO' in list(parse_env_file_contents(lines))[2]

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-12 07:32:31.266247
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:32:42.775785
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        changes[k] = v

    assert changes['TEST'] == str(Path.home() / "yeee")
    assert changes['THISIS'] == str(Path.home() / "a" / "test")
    assert changes['YOLO'] == str(Path.home() / "swaggins" / "$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")


# Unit

# Generated at 2022-06-12 07:32:51.907842
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "THING=stuff",
        "@@@@=SWAG",
        "DICK=true",
        "LICK=false",
        "HAS=2",
        "PI=3.141592654",
        "MYSQL_DATABASE=redcv",
        "MYSQL_ROOT_PASSWORD=my-secret-pw",
        "MYSQL_USER=redcv",
        "MYSQL_PASSWORD=redcv",
        "MYSQL_ENV_MYSQL_PASSWORD=redcv",
        "MYSQL_ENV_MYSQL_ROOT_PASSWORD=my-secret-pw",
    ]

# Generated at 2022-06-12 07:32:58.251286
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """
    pass

