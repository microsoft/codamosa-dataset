

# Generated at 2022-06-12 07:23:06.074517
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file((
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )) == collections.OrderedDict((
        ('TEST', os.getenv('HOME') + '/yeee-' + os.getenv('PATH')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ))


# Generated at 2022-06-12 07:23:17.457015
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import tempfile


# Generated at 2022-06-12 07:23:20.002699
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:23:24.934254
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']

    changes = parse_env_file_contents(lines)

    assert len(list(changes)) == 2

    changes = parse_env_file_contents(reversed(lines))

    assert len(list(changes)) == 2



# Generated at 2022-06-12 07:23:36.390822
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Use subshell to get env values (path, home, etc)
    path = expand('$PATH')
    home = expand('~')

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    expected = collections.OrderedDict([
        ('TEST', '{}/yeee-{}'.format(home, path)),
        ('THISIS', '{}/a/test'.format(home)),
        ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(home))
    ])


# Generated at 2022-06-12 07:23:37.817403
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:23:40.515490
# Unit test for function load_env_file
def test_load_env_file():
    """Unit tests for `load_env_file`."""
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:23:47.974293
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    r = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:23:56.828438
# Unit test for function load_env_file
def test_load_env_file():
    import unittest.mock


# Generated at 2022-06-12 07:24:05.878734
# Unit test for function load_env_file
def test_load_env_file():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes['TEST'] == os.path.expanduser('~/yeee')
    assert changes['THISIS'] == os.path.expanduser('~/a/test')
    assert changes['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:24:15.303352
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(('TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:24:22.491396
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import os
    import shutil
    import textwrap

    with tempfile.TemporaryDirectory() as path:

        p = os.path.join(path, "test.txt")

        input_text = textwrap.dedent(
            """\
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """
        )

        with open(p, "w") as f:
            f.write(input_text)

        with open(p) as f:
            lines = [line.strip() for line in f.readlines()]
        assert lines == input_text.splitlines()

        # Same results

# Generated at 2022-06-12 07:24:27.738544
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:24:34.739627
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = load_env_file(lines, write_environ=None)

    assert type(parsed) == collections.OrderedDict

    assert parsed['TEST'] == str(expand('${HOME}/yeee-$PATH'))
    assert parsed['THISIS'] == str(expand('~/a/test'))
    assert parsed['YOLO'] == str(expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-12 07:24:36.999561
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-12 07:24:46.885439
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests the function parse_env_file_contents

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-12 07:24:52.058223
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert env['TEST'] == expand('${HOME}/yeee')
    assert env['THISIS'] == expand('~/a/test')
    assert env['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:24:59.101161
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # noinspection PyShadowingNames
    from pymk.mk_testing import assert_that

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = list(parse_env_file_contents(lines))

    assert_that(results).contains_all_of(
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )


if __name__ == '__main__':
    import doctest
    doctest.testmod

# Generated at 2022-06-12 07:24:59.888389
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:25:10.096043
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        '# this is a comment',
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        '# this is another comment',
        'TEST2="test"'
    ]

    env = dict()

    changes = load_env_file(lines, env)

    home = expand('~')
    path = os.environ['PATH']

    assert env['TEST'] == f'{home}/yeee'
    assert env['THISIS'] == f'{home}/a/test'

# Generated at 2022-06-12 07:25:18.485553
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert load_env_file(
        lines=["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    ) == collections.OrderedDict(
        [
            ("TEST", expand("${HOME}/yeee")),
            ("THISIS", expand("~/a/test")),
            ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
        ]
    )

# Generated at 2022-06-12 07:25:28.109021
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    with pytest.raises(StopIteration):
        next(parse_env_file_contents())

    with pytest.raises(StopIteration):
        next(parse_env_file_contents(lines=[]))

    assert next(parse_env_file_contents(lines=[''])) == ("", "")
    assert next(parse_env_file_contents(lines=[' '])) == ("", "")
    assert next(parse_env_file_contents(lines=['\t'])) == ("", "")
    with pytest.raises(StopIteration):
        next(parse_env_file_contents(lines=['\n']))

# Generated at 2022-06-12 07:25:36.968267
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    text = '''TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''
    items = list(parse_env_file_contents(text.splitlines()))

    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert expected == items



# Generated at 2022-06-12 07:25:44.973593
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Expected result, given the ENV vars that are already set in this
    # environment
    result = [(('TEST', expand(os.getenv('HOME')) + '/yeee-' + expand(os.getenv('PATH')))),
              (('THISIS', expand(os.path.expanduser('~/a/test')))),
              (('YOLO', expand(os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))))]


# Generated at 2022-06-12 07:25:51.925572
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test parse_env_file_contents

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:25:56.401054
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True

# Generated at 2022-06-12 07:26:05.088820
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=None)

    assert environ.get('TEST') == os.path.expanduser('${HOME}/yeee')
    assert environ.get('THISIS') == os.path.expanduser('~/a/test')
    assert environ.get('YOLO') == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:26:16.036331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    c = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        c[k] = v

    assert(c['TEST'] == os.path.expanduser('~/yeee-') + os.environ['PATH'])
    assert(c['THISIS'] == os.path.expanduser('~/a/test'))
    assert(c['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-12 07:26:23.417734
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:26:30.728751
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=$HOME/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v


# Generated at 2022-06-12 07:26:37.791976
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents.
    """
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):
        def test_parse_env_file_contents(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            load_env_file(lines, write_environ=dict())

    unittest.main(module=__name__, argv=[''], verbosity=2, exit=False)


# Generated at 2022-06-12 07:26:48.992724
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env_values = parse_env_file_contents(lines)
    env_values = list(env_values)

    assert len(env_values) == 3

    key, val = env_values[0]
    assert key == 'TEST'
    assert val == os.path.join(os.path.expanduser("~"), 'yeee')

    key, val = env_values[1]
    assert key == 'THISIS'
    assert val == os.path.join(os.path.expanduser("~"), 'a', 'test')


# Generated at 2022-06-12 07:26:55.707534
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'FOO=one\\ two\\ three',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('FOO', 'one\\ two\\ three'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:05.319147
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


    # Test with None as parameter
    assert list(parse_env_file_contents(None)) == []

    # Test env file with existing variables
    env = os.environ.copy()

# Generated at 2022-06-12 07:27:06.625159
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:27:16.545933
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # https://docs.python.org/3/library/unittest.mock.html
    import unittest.mock

    # Use mock to replace the method `expand` with a custom method
    def dummy_expand(val):
        """
        Replaces '~' and '~user' with '/abs/path/to/home/user'
        Replaces '$VAR' or '${VAR}' with '/abs/path/to/$VAR'.
        """

        tokens = ["/abs/path/to", "home"]

        for s in val.split('/'):
            if s.startswith("~"):
                if len(s) > 1:
                    tokens.append(s[1:])

# Generated at 2022-06-12 07:27:20.025859
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # pylint: disable=import-error
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:27:28.327523
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = ['FOO=bar', '# comment', 'ENV_FILE=${FOO}', 'ENV_FILE2=${FOO}-baz', 'ENV_FILE3="hello there"', 'ENV_FILE4="hello this is a quoted string"', 'ENV_FILE5="hello this is an escaped quote \" string"', 'ENV_FILE6="hello this is an escaped single quote \' string"', 'ENV_FILE7=\'hello there\'']

    name_value_pairs = list(parse_env_file_contents(lines))


# Generated at 2022-06-12 07:27:38.048068
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    expected_result = {'TEST': os.getenv('HOME') + '/yeee',
                       'THISIS': os.getenv('HOME') + '/a/test',
                       'YOLO': os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    assert result == expected_result



# Generated at 2022-06-12 07:27:46.578765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = dict(parse_env_file_contents(lines))
    assert result['TEST'] == '.../yeee'
    assert result['THISIS'] == '.../a/test'
    assert result['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    with pytest.raises(AttributeError) as err:
        result['NONEXISTENT']
    assert 'has no attribute' in str(err)



# Generated at 2022-06-12 07:28:00.478088
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    def verify(lines, expected):
        result = list(parse_env_file_contents(lines))
        try:
            assert result == expected
        except AssertionError:
            sys.stderr.write("\n{}\n\n{}\n\n".format(result, expected))
            raise

    verify([], [])
    verify(["YO"], [])
    verify(["YO=42"], [("YO", "42")])
    verify(["YO_42='moo'"], [("YO_42", "moo")])
    verify(["YO_42=\"moo\""], [("YO_42", "moo")])
    verify(["YO_42=moo"], [("YO_42", "moo")])


# Generated at 2022-06-12 07:28:08.260671
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    data = b"""
    VAR1=value1
    VAR2=value2
    VAR3='value 3'
    VAR4="value 4"
    PATH=$PATH:/value5
    """

    results = parse_env_file_contents(lines=data.splitlines())

    assert collections.OrderedDict(results) == collections.OrderedDict({'VAR1': 'value1', 'VAR2': 'value2', 'VAR3': 'value 3', 'VAR4': 'value 4', 'PATH': os.environ['PATH'] + ':/value5'})



# Generated at 2022-06-12 07:28:09.392214
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:28:19.529665
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())
    assert changes == collections.OrderedDict([('TEST', os.environ.get('HOME') + '/yeee'),
                                               ('THISIS', expand('~/a/test')),
                                               ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-12 07:28:25.381309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pprint import pprint

    lines = ["# This is a comment\n", 'TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines=lines)
    results = list(results)

    pprint(results)



# Generated at 2022-06-12 07:28:36.681956
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):
        def test_parse_env_file_contents_1(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            write_environ = dict()
            load_env_file(lines, write_environ=write_environ)
            self.assertEqual(write_environ['TEST'], os.path.join(os.environ['HOME'], 'yeee'))

# Generated at 2022-06-12 07:28:44.695585
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = io.StringIO('\n'.join(lines))

    loads = collections.OrderedDict(parse_env_file_contents(lines))

    assert loads == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:28:52.664613
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee',
                                         'THISIS=~/a/test',
                                         'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:28:53.722595
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:29:01.268733
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        '"FOO=$HOME"',
        "'BAR=${PATH}'",
        '"BAZ=\\$HOME"'
    ]
    values = parse_env_file_contents(lines)

    assert ["TEST", "${HOME}/yeee"] in values
    assert ["THISIS", "~/a/test"] in values
    assert ["YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"] in values
    assert ["FOO", "$HOME"] in values

# Generated at 2022-06-12 07:29:18.382885
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    for o, e in zip(parse_env_file_contents(lines), expected):
        assert o[0] == e[0]
        assert o[1] == e[1]

    print("parse_env_file_contents OK")


# Unit test

# Generated at 2022-06-12 07:29:28.329819
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME',
        '# THISIS=~test',
        '# YOLO=$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'SINGLEQUOTE=\'test\'',
        'DOUBLEQUOTE="test"',
        '# ANOTHER_VAR=$TEST',
        'DOUBLEQUOTE2="$TEST"',
        'DOUBLESINGLEQUOTE=\'$TEST\'',
        'DOUBLEDOUBLEQUOTE="$TEST"',
    ]

    results = parse_env_file_contents(lines)
    for k, v in results:
        if k == 'TEST':
            assert v == '$HOME'


# Generated at 2022-06-12 07:29:32.282673
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(list(parse_env_file_contents(lines)))



# Generated at 2022-06-12 07:29:41.252721
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    line_tests = (
        ('TEST=${HOME}/yeee', 'TEST', '${HOME}/yeee'),
        ('THISIS=~/a/test', 'THISIS', '~/a/test'),
        ('HOME=~/swaggins', 'HOME', '~/swaggins'),
        ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )

    for test in line_tests:
        output = []
        for result in parse_env_file_contents([test[0]]):
            output += result

        assert (test == tuple(output))



# Generated at 2022-06-12 07:29:47.392664
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    cur_dir = os.path.dirname(os.path.abspath(__file__))

    test_fixture_file_path = os.path.join(cur_dir, 'fixtures/python_parse_env_file_contents.txt')
    with open(test_fixture_file_path, 'rt') as test_fixture:
        lines = test_fixture.readlines()

    output_dict = load_env_file(lines)

    assert len(output_dict) == 3
    assert 'TEST' in output_dict
    assert 'THISIS' in output_dict
    assert 'YOLO' in output_dict

# Generated at 2022-06-12 07:29:52.910740
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:54.018461
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:29:55.545075
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:30:00.203566
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)



# Generated at 2022-06-12 07:30:02.651537
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    _, errors = doctest.testmod()

    if errors:
        raise SystemExit(1)



# Generated at 2022-06-12 07:30:28.303639
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    expected_changes = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    changes = collections.OrderedDict(parse_env_file_contents(lines))

    assert changes == expected_changes

# Generated at 2022-06-12 07:30:37.627774
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import math

    EPSILON = math.sqrt(math.finfo("d").eps)
    assert EPSILON > 0

    # Test string parsing
    lines = ["MOLTEN_IODINE=test", "STRING=test string", "QUOTED='test string'", 'QUOTED="test string"', 'QUOTED="test string"']
    values = parse_env_file_contents(lines)

    assert ("MOLTEN_IODINE", "test") in values
    assert ("STRING", "test string") in values
    assert ("QUOTED", "'test string'") in values
    assert ("QUOTED", "test string") in values
    assert ("QUOTED", "test string") in values

    # Test parsing with variables

# Generated at 2022-06-12 07:30:45.050331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing the function "parse_env_file_contents"')
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        print(f'k={k}, v={v}')
    print('_' * 79)



# Generated at 2022-06-12 07:30:50.416031
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    assert 1 == 1  # No assertion error denotes success (lol)

# Generated at 2022-06-12 07:30:59.638133
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:31:04.371864
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests that `parse_env_file_contents` runs without exceptions.
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-12 07:31:13.152935
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)

    test1 = ('TEST', '.../yeee')
    test2 = ('THISIS', '.../a/test')
    test3 = ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    assert test1 in results
    assert test2 in results
    assert test3 in results

    results = parse_env_file_contents(lines)

    test1 = ('TEST', '.../yeee')

# Generated at 2022-06-12 07:31:19.432948
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert isinstance(parse_env_file_contents(lines), collections.abc.Generator)
    assert load_env_file(lines) == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:31:26.501410
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert isinstance(list(parse_env_file_contents(lines)), list)
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:31:36.052169
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:32:18.639620
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:32:25.070381
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-12 07:32:32.030221
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        "# Test",
        "TEST=${HOME}/yeee-${PATH}",
        "THISIS='~/a/test'",
        "YOLO=\"~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}\""
    ])) == [("TEST", os.path.expandvars("${HOME}/yeee-${PATH}")), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}")]



# Generated at 2022-06-12 07:32:42.408991
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = parse_env_file_contents(lines)
    assert next(expected) == ('TEST', '.../yeee')
    assert next(expected) == ('THISIS', '.../a/test')
    assert next(expected) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert list(parse_env_file_contents([])) == []



# Generated at 2022-06-12 07:32:50.376976
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test the env file parsing function

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-12 07:32:57.742807
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    results = collections.OrderedDict(results)
    assert results == collections.OrderedDict([('TEST', expand('${HOME}/yeee')),
                                               ('THISIS', expand('~/a/test')),
                                               ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

