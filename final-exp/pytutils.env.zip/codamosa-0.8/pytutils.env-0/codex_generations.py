

# Generated at 2022-06-12 07:23:05.617562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


if __name__ == '__main__':
    import pytest
    import sys

    sys.exit(pytest.main(["-qq", "-s", __file__]))

# Generated at 2022-06-12 07:23:17.033032
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert os.environ['TEST'] == os.path.expanduser('~/yeee')
    assert os.environ['THISIS'] == os.path.expanduser('~/a/test')
    assert os.environ['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    os.environ.pop('TEST')
    os.environ.pop('THISIS')
    os.en

# Generated at 2022-06-12 07:23:24.780849
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ=write_environ)

    assert isinstance(write_environ, dict)
    assert isinstance(write_environ['TEST'], str)
    assert write_environ['THISIS'] == "~/a/test"

# Generated at 2022-06-12 07:23:28.411570
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:23:34.754741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    for k, v in parse_env_file_contents(lines):
        assert expand(v) == v



# Generated at 2022-06-12 07:23:41.632469
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(lines=[
        "TEST=${HOME}/a",
        "TEST2=${HOME}/b",
        "TEST3=${HOME}/c",
        "TEST4=${HOME}/d",
        "TEST5=${HOME}/e",
    ])
    assert os.environ.get("TEST") is not None
    assert os.environ.get("TEST2") is not None
    assert os.environ.get("TEST3") is not None
    assert os.environ.get("TEST4") is not None
    assert os.environ.get("TEST5") is not None

# Generated at 2022-06-12 07:23:48.075971
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO

    lines = StringIO('''
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
''')

    result = parse_env_file_contents(lines)
    expected_result = [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert [kv for kv in result] == expected_result



# Generated at 2022-06-12 07:23:56.891635
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: This is a temporary hack until we can update pytest to 3.3
    # (which includes the -s switch that can disable capturing stdout)
    # Without this + pytest -s, no output will be printed
    print('Pytest is running in setup_env.py')

    test_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(test_lines, write_environ=dict())

    for k, v in results.items():
        assert k in ['TEST', 'THISIS', 'YOLO']
        assert type(v) == str

        # We can only check whether the home and path variables were expanded

# Generated at 2022-06-12 07:24:03.057948
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ)

    print(write_environ)

    assert False



# Generated at 2022-06-12 07:24:09.988669
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert list(values) == [('TEST', '.../yeee'),
                            ('THISIS', '.../a/test'),
                            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')], \
        "test_parse_env_file_contents FAILED"

    # Test that the parse_env_file_contents generator is reusable

# Generated at 2022-06-12 07:24:20.739349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(
        parse_env_file_contents(lines=['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    ) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]


# Generated at 2022-06-12 07:24:28.476292
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Check that the output contains exactly the contents of the file and that
    # whitespace is trimmed.
    with open(os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'env_file', 'simple.env'), 'rt') as f:
        output = parse_env_file_contents(f)
        assert list(output) == [('FOO', 'bar'), ('BAZ', '123')]


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:24:33.914577
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    values = parse_env_file_contents(lines)
    assert set(values) == set([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test')])

    lines = ['TEST=${HOME}/yeee']
    values = parse_env_file_contents(lines)
    assert set(values) == set([('TEST', '${HOME}/yeee')])



# Generated at 2022-06-12 07:24:40.104194
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Unit test for function parse_env_file_contents
    changes = collections.OrderedDict()

    for k, v in parse_env_file_contents(lines):
        v = expand(v)

        changes[k] = v

    print('Changes:', changes)

    assert changes['TEST'] == (expand('~/yeee-') + os.pathsep + expand('$PATH'))
    assert changes['THISIS'] == expand('~/a/test')

# Generated at 2022-06-12 07:24:47.488550
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_result = [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == expected_result



# Generated at 2022-06-12 07:24:51.236480
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    env = dict()
    result = load_env_file(lines, write_environ=env)
    print(result)



# Generated at 2022-06-12 07:24:54.784505
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test']))

    assert result == [('TEST', '{HOME}/yeee'),
                      ('THISIS', '~/a/test')]



# Generated at 2022-06-12 07:25:00.421186
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        if '$' in v:
            v = os.path.expandvars(v)
        if '$' in v:
            v = os.path.expanduser(v)

        assert '$' not in v



# Generated at 2022-06-12 07:25:04.121091
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ={})

# Generated at 2022-06-12 07:25:13.432882
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    parsed = list(parse_env_file_contents(lines))

    assert len(parsed) == 3
    assert ('TEST', '.../yeee') in parsed
    assert ('THISIS', '.../a/test') in parsed
    assert ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in parsed



# Generated at 2022-06-12 07:25:18.164313
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pprint import pprint as pp

    pp(list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))



# Generated at 2022-06-12 07:25:22.362391
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:25:25.138374
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(("TEST=10", "TEST2=20"))) == {"TEST": "10", "TEST2": "20"}



# Generated at 2022-06-12 07:25:29.171783
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())

    return True



# Generated at 2022-06-12 07:25:38.244369
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        if k == 'TEST':
            assert v == '.../yeee'
        elif k == 'THISIS':
            assert v == '.../a/test'
        elif k == 'YOLO':
            assert v == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
        else:
            assert False



# Generated at 2022-06-12 07:25:42.259458
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert [x for x in parse_env_file_contents(lines=['TEST=${HOME}/yeee'])] == [('TEST', '.../yeee')]


if __name__ == '__main__':
    exit(pytest.main([str(__file__.replace('\\', '/')), '-v', '-s']))

# Generated at 2022-06-12 07:25:50.484736
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    data = parse_env_file_contents(lines)

    assert ('TEST', '${HOME}/yeee') in data
    assert ('THISIS', '~/a/test') in data
    assert ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in data

# Generated at 2022-06-12 07:25:55.211928
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:26:01.729086
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents
    """
    import random
    import string

    def create_random_string(max_length):
        chars = ''.join([random.choice(string.lowercase) for _ in range(int(random.random() * max_length))])
        return chars

    # Test 1

# Generated at 2022-06-12 07:26:04.332762
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    if __name__ == "__main__":
        import doctest

        doctest.testmod()

# Generated at 2022-06-12 07:26:14.634128
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    test_contents = '''
    export TEST=${HOME}/yeee
    export    THISIS=~/a/test
    '''

    with tempfile.TemporaryFile(mode='w+t') as tf:
        tf.write(test_contents)
        tf.seek(0)

        results = parse_env_file_contents(tf)

        assert list(results) == [('TEST', '.../.../yeee'), ('THISIS', '.../a/test')]

# Generated at 2022-06-12 07:26:21.814114
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(lines=dict(TEST='').keys()) == dict(TEST='').items()
    assert parse_env_file_contents(lines=dict(TEST='good').keys()) == dict(TEST='good').items()
    assert parse_env_file_contents(lines=dict(TEST='good/$OTHER_VAR_NAME').keys()) == dict(TEST='good/$OTHER_VAR_NAME').items()



# Generated at 2022-06-12 07:26:25.657077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:26:29.631131
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print(list(parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))



# Generated at 2022-06-12 07:26:36.526986
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)

    expected_results = [('TEST', '${HOME}/yeee'),
                        ('THISIS', '~/a/test'),
                        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert set(expected_results).issubset(set(results))



# Generated at 2022-06-12 07:26:47.656330
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:26:54.260711
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    assert environ == collections.OrderedDict([('TEST', '.../yeee'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO',
                                                '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:26:56.629925
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-12 07:27:03.573881
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == \
        [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:10.062707
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert tuple(parse_env_file_contents(lines)) == (
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )



# Generated at 2022-06-12 07:27:18.368407
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:27:27.776172
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=dict())
    assert isinstance(results, collections.OrderedDict)
    assert 'TEST' in results
    assert 'THISIS' in results
    assert 'YOLO' in results
    assert results['TEST'] == os.path.join(expand('${HOME}'), 'yeee-') + expand('${PATH}')
    assert results['THISIS'] == expand('~/a/test')

# Generated at 2022-06-12 07:27:38.508410
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Can parse regular normal key=value lines
    assert dict(list(parse_env_file_contents(['TEST=test']))) == {'TEST': 'test'}

    # Can parse lines with $VARIABLES and ~USER
    assert dict(list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test']))) == {
        'TEST': os.path.expanduser('~') + '/yeee-' + os.environ['PATH'],
        'THISIS': os.path.expanduser('~/a/test')
    }

    # Can parse lines with quotes

# Generated at 2022-06-12 07:27:47.247881
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=1234'])) == [('TEST', '1234')]
    assert list(parse_env_file_contents(['TEST="1234"'])) == [('TEST', '1234')]
    assert list(parse_env_file_contents(['TEST="1234', '5678"'])) == [('TEST', '12345678')]
    assert list(parse_env_file_contents(['TEST="1234"'])) == [('TEST', '1234')]
    assert list(parse_env_file_contents(['TEST="123\\4"'])) == [('TEST', '1234')]

# Generated at 2022-06-12 07:27:54.798676
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = parse_env_file_contents(lines)

    expected = (
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )

    assert actual == expected



# Generated at 2022-06-12 07:28:01.854896
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO

    lines = StringIO('TEST=${HOME}\nTHISIS=~/a\\\n/test\nYOLO=$A_VAR_THAT_DOES_NOT_EXIST\n')

    try:
        load_env_file(lines, write_environ=None)
    except Exception as e:
        import traceback
        traceback.print_exc()

    print('test_parse_env_file_contents done')


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:28:10.218562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Basic string test
    lines = ['TEST=yeee', 'THIS=is a test']
    assert list(parse_env_file_contents(lines)) == [('TEST', 'yeee'), ('THIS', 'is a test')]

    # Single quote test
    lines = ["TEST='${THIS} is a test'"]
    assert list(parse_env_file_contents(lines)) == [('TEST', '${THIS} is a test')]

    # Double quote test
    lines = ['TEST="${THIS} is a test"']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${THIS} is a test')]
    lines = ['TEST="${THIS} is \\"a test\\""']

# Generated at 2022-06-12 07:28:19.794349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from nose.tools import assert_equals

    text = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    actual = parse_env_file_contents(text)

    assert_equals(list(actual), expected)



# Generated at 2022-06-12 07:28:27.760899
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():  # pragma: no cover
    # For test coverage, comment this line to run this unit test.
    return

    # First tests
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    # Yeah, this is hacky, but it's so much easier
    d['TEST'] = d['TEST'].replace(os.path.expanduser('~'), '...')
    d['THISIS'] = d['THISIS'].replace(os.path.expanduser('~'), '...')

# Generated at 2022-06-12 07:28:38.380892
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    if 'HOME' not in os.environ:
        raise RuntimeError('HOME is not in environment')

    # Required for test
    assert os.environ.get('HOME')

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = load_env_file(lines=lines, write_environ=dict())


# Generated at 2022-06-12 07:28:55.972652
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests for function parse_env_file_contents

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    log_info("testing function parse_env_file_contents")


# Generated at 2022-06-12 07:29:02.197931
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(
        ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == dict(
        TEST=os.path.join(os.path.expanduser('${HOME}'), 'yeee'),
        THISIS=os.path.join(os.path.expanduser('~'), 'a', 'test'),
        YOLO=os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )



# Generated at 2022-06-12 07:29:09.719573
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['A=B'])) == [('A', 'B')]
    assert list(parse_env_file_contents(['A=B  '])) == [('A', 'B')]
    assert list(parse_env_file_contents(['A=B C'])) == [('A', 'B C')]
    assert list(parse_env_file_contents(['A= B C'])) == [('A', 'B C')]
    assert list(parse_env_file_contents(['A= B  C'])) == [('A', 'B  C')]
    assert list(parse_env_file_contents(['A =B C'])) == [('A', 'B C')]

# Generated at 2022-06-12 07:29:18.266238
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    actual = parse_env_file_contents(lines)

    expected = [
        ("TEST", "${HOME}/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]

    assert list(actual) == expected



# Generated at 2022-06-12 07:29:28.100582
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v


# Generated at 2022-06-12 07:29:35.928542
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

# Generated at 2022-06-12 07:29:37.373388
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:29:46.493683
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()

    values = load_env_file(lines, write_environ=environ)

    assert values == {
        'TEST': os.path.normpath('%s/yeee' % os.environ['HOME']),
        'THISIS': os.path.normpath('%s/a/test' % os.environ['HOME']),
        'YOLO': os.path.normpath('%s/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' % os.environ['HOME'])
    }



# Generated at 2022-06-12 07:29:52.911186
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/dir', 'THISIS=~/a/test']
    for k, v in parse_env_file_contents(lines):
        if k == 'TEST':
            assert v == expand('${HOME}/dir')
        elif k == 'THISIS':
            assert v == expand('~/a/test')
        else:
            raise AssertionError



# Generated at 2022-06-12 07:30:02.885331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # given
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # when
    changes = load_env_file(lines, write_environ=dict())

    # then
    assert changes == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

# Generated at 2022-06-12 07:30:25.495319
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:30:35.830833
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    parsed = parse_env_file_contents(lines)

    test_dict = {
        'TEST': str(Path(os.environ['HOME']) / 'yeee'),
        'THISIS': str(Path(os.environ['HOME']) / 'a' / 'test'),
        'YOLO': str(Path(os.environ['HOME']) / 'swaggins' / '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }


# Generated at 2022-06-12 07:30:45.402274
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:30:49.908148
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-12 07:30:56.821318
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = dict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    results = dict(parse_env_file_contents(lines))
    assert results == expected



# Generated at 2022-06-12 07:31:05.725544
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Test function parse_env_file_contents")

    # Define test cases
    import filecmp
    data_dir = '../data/'
    test_cases = ((data_dir + 'example_env_file', data_dir + 'parsed_example_env_file.txt'),)
    for tc in test_cases:
        with open(tc[1]) as f:
            f.readline()
            expected = f.read()

        with open(tc[0]) as f:
            actual = ''.join(map('='.join, parse_env_file_contents(f)))

        # Compare actual and expected output
        assert expected == actual, 'Epected: {0} and actual: {1}'.format(expected, actual)



# Generated at 2022-06-12 07:31:13.486914
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = load_env_file(lines, write_environ=dict())
    assert d['TEST'].endswith('/yeee')
    assert d['THISIS'].endswith('/a/test')
    assert d['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:31:20.645125
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee',
             'TEST2=$TEST/something',
             'TEST3="$TEST2/\"$TEST2\"/"',
             "TEST4='hahaha'",
             'TEST5="hahaha"',
             'TEST6="hahaha',
             "TEST7='hahaha",
             'meow',
             '\n',
             'meow',
             '']

    res = parse_env_file_contents(lines)

    res_dict = collections.OrderedDict()

    for t in res:
        res_dict[t[0]] = t[1]

    assert 'TEST' in res_dict
    assert res_dict['TEST'] == '${HOME}/yeee'


# Generated at 2022-06-12 07:31:26.627597
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:31:37.811669
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['A=1'])) == [('A', '1')]
    assert list(parse_env_file_contents(['A=1', 'B=2'])) == [('A', '1'), ('B', '2')]
    assert list(parse_env_file_contents(['A="1"', 'B=2'])) == [('A', '1'), ('B', '2')]
    assert list(parse_env_file_contents(['A="1"', 'B="2"'])) == [('A', '1'), ('B', '2')]

# Generated at 2022-06-12 07:32:04.820266
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test parse_env_file_contents.
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values_expected = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    values_actual = list(parse_env_file_contents(lines))
    assert values_expected == values_actual



# Generated at 2022-06-12 07:32:15.438888
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict([
        ('TEST', os.path.join(expand('${HOME}'), 'yeee')),
        ('THISIS', os.path.join(expand('~'), 'a', 'test')),
        ('YOLO', os.path.join(expand('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

    result = collections.OrderedDict(parse_env_file_contents(lines))

    assert result == expected
    assert result['TEST']

# Generated at 2022-06-12 07:32:20.862098
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def lines():
        for line in ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']:
            yield line

    content = parse_env_file_contents(lines())
    assert content.__next__() in ('TEST', ('TEST', '.../yeee'))



# Generated at 2022-06-12 07:32:21.588561
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:32:30.117764
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from tempfile import NamedTemporaryFile
    from os import environ
    from os.path import expanduser

    write_environ = dict()
    load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
                  write_environ=write_environ)
    assert write_environ['TEST'] == '%s/yeee-%s' % (expanduser("~"), environ['PATH'])
    assert write_environ['THISIS'] == '%s/a/test' % expanduser("~")

# Generated at 2022-06-12 07:32:40.431227
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    with pytest.raises(AssertionError):
        parse_env_file_contents(lines=None)

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert tuple(parse_env_file_contents(lines)) == (
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )



# Generated at 2022-06-12 07:32:48.481070
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:32:54.683157
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    # Unit test for function parse_env_file_contents
    """
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):
        def test_parse_env_file_contents_1(self):
            """
            Test function parse_env_file_contents - 1
            """
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            results = load_env_file(lines, None)
