

# Generated at 2022-06-12 07:23:03.734214
# Unit test for function load_env_file
def test_load_env_file():
    env = dict()
    changes = load_env_file([
        'A=1',
        'B=2'
    ], write_environ=env)

    assert env['A'] == '1'
    assert env['B'] == '2'

    assert len(changes) == 2
    assert changes['A'] == '1'
    assert changes['B'] == '2'

    assert len(env) == 2



# Generated at 2022-06-12 07:23:05.564080
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:23:14.231601
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:23:20.938379
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:23:28.682566
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    envs = load_env_file(lines, write_environ=dict())

    assert len(envs) == 3
    # print(envs)
    assert 'TEST' in envs
    assert 'THISIS' in envs
    assert 'YOLO' in envs

    assert '/yeee-' in envs['TEST']
    assert '/a/test' == envs['THISIS']
    assert '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' == envs['YOLO']



# Generated at 2022-06-12 07:23:32.140748
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-12 07:23:34.034691
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:23:42.037109
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Changes to environ needed for this test to pass.
    os.environ['HOME'] = '...'
    os.environ['PATH'] = '...'


# Generated at 2022-06-12 07:23:50.165546
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']  # noqa: E501
    new_env = load_env_file(lines, write_environ=dict())
    assert new_env['TEST'] == '~/yeee-$PATH'
    assert new_env['THISIS'] == '~/a/test'
    assert new_env['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-12 07:23:54.179349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['PATH=/usr/bin:$PATH', 'HOME=/home/$USER']

    values = parse_env_file_contents(lines)
    results = dict(values)

    assert results == {
        'PATH': '/usr/bin:$PATH',
        'HOME': '/home/$USER'
    }

# Generated at 2022-06-12 07:24:05.450162
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    dict_list = list(parse_env_file_contents(lines))

    assert dict_list[0] == ('TEST', '${HOME}/yeee')
    assert dict_list[1] == ('THISIS', '~/a/test')
    assert dict_list[2] == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:24:11.735054
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = [
        "TEST_VAR_1=TEST_VAL_1",
        "TEST_VAR_2=TEST_VAL_2",
        "TEST_VAR_3=TEST_VAL_3",
        "TEST_VAR_4=TEST_VAL_4",
        "TEST_VAR_5=TEST_VAL_5",
        "TEST_VAR_6=TEST_VAL_6",
    ]
    parsed_values = parse_env_file_contents(test_lines)

# Generated at 2022-06-12 07:24:19.148304
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert tuple(parse_env_file_contents(lines)) == (
        ("TEST", "~/yeee"), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    )



# Generated at 2022-06-12 07:24:29.377244
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = parse_env_file_contents(lines)

    assert next(output) == ("TEST", os.path.expanduser("~/yeee-$PATH"))
    assert next(output) == ("THISIS", os.path.expanduser("~/a/test"))
    assert next(output) == ("YOLO", os.path.expanduser("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))



# Generated at 2022-06-12 07:24:31.918267
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=(doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE | doctest.REPORT_ONLY_FIRST_FAILURE))

# Generated at 2022-06-12 07:24:33.438825
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


# Unit test function load_env_file

# Generated at 2022-06-12 07:24:39.017210
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']
    changes = load_env_file(lines, write_environ=dict())

    assert changes
    assert 'TEST' in changes
    assert 'THISIS' in changes
    assert 'YOLO' in changes
    assert changes['TEST'].endswith('/yeee')
    assert changes['THISIS'].endswith('/a/test')
    assert changes['YOLO'].endswith('/swaggins')



# Generated at 2022-06-12 07:24:47.937496
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_ = load_env_file(lines, write_environ=os.environ)
    assert dict_['TEST'] == f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'
    assert dict_['THISIS'] == f'{os.environ["HOME"]}/a/test'
    assert dict_['YOLO'] == f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-12 07:24:52.164185
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    s = parse_env_file_contents(lines)
    print('\n'.join('{}={}'.format(k, v) for k, v in s))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:24:58.798187
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents([
        "TEST=$HOME/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ])) == {
        'TEST': f'{os.path.expanduser("~")}/yeee',
        'THISIS': f'{os.path.expanduser("~")}/a/test',
        'YOLO': f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-12 07:25:11.333592
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=hello'])) == [('TEST', 'hello')]
    assert list(parse_env_file_contents(['TEST="hello world"'])) == [('TEST', 'hello world')]
    assert list(parse_env_file_contents(['TEST="hello\tworld"'])) == [('TEST', 'hello\tworld')]
    assert list(parse_env_file_contents(['TEST="hello\\tworld"'])) == [('TEST', 'hello\\tworld')]
    assert list(parse_env_file_contents(['TEST="hello\\\\tworld"'])) == [('TEST', 'hello\\tworld')]


# Generated at 2022-06-12 07:25:19.643502
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from hypothesis import given, settings
    from hypothesis.strategies import text
    import pytest

    @given(text(min_size=1, alphabet='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_01234567890'))
    @settings(max_examples=5)
    def test_parse_env_file_contents_simple(a):
        result = list(parse_env_file_contents([a]))
        assert result[0][0] == a
        assert result[0][1] == ''

    test_parse_env_file_contents_simple()


# Generated at 2022-06-12 07:25:28.385656
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    for result_item, expected_item in zip(result, expected):
        assert result_item == expected_item



# Generated at 2022-06-12 07:25:38.625606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test1 = dict(parse_env_file_contents(lines))
    res1 = dict()
    res1['TEST'] = os.path.expandvars('$HOME/yeee')
    res1['THISIS'] = os.path.expanduser('~/a/test')
    res1['YOLO'] = os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert test1 == res1, 'parse_env_file_contents - test 1'

# Generated at 2022-06-12 07:25:44.824911
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:25:49.958092
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    r = parse_env_file_contents(lines)

    assert isinstance(r, collections.abc.Generator)
    assert len(list(r)) == 3



# Generated at 2022-06-12 07:25:50.762284
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:25:59.240606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:26:04.952938
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from typing import Iterator
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test')]



# Generated at 2022-06-12 07:26:15.923772
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:26:28.339164
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Tests function parse_env_file_contents."""
    lines = (
        '# This is a comment',
        '',
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    actual = list(parse_env_file_contents(lines))
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert actual == expected, 'Got: {}'.format(actual)



# Generated at 2022-06-12 07:26:35.386457
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for key, value in parse_env_file_contents(lines):
        # print(key, value)
        assert key in ['TEST', 'THISIS', 'YOLO']
        assert value in ['${HOME}/yeee', '~/a/test', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']



# Generated at 2022-06-12 07:26:44.769778
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    changes = collections.OrderedDict(values)

    assert changes == collections.OrderedDict([
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-12 07:26:53.730494
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=collections.OrderedDict())


# Generated at 2022-06-12 07:27:01.770912
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'),
                                                    ('THISIS', '.../a/test'),
                                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:07.810402
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test function parse_env_file_contents.
    """
    import tempfile
    import shutil
    import os
    import os.path

    tmpdir = tempfile.mkdtemp()

    with open(os.path.join(tmpdir, 'test.env'), 'w') as f_env:
        f_env.write('# A comment\n')
        f_env.write('# Export\n')
        f_env.write('export TEST=${HOME}/yeee-$PATH\n')
        f_env.write('THISIS=~/a/test\n')
        f_env.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')


# Generated at 2022-06-12 07:27:17.894542
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(contents)
    for k, v in data:
        if k == 'TEST':
            assert v == os.path.expandvars('${HOME}/yeee')
        elif k == 'THISIS':
            assert v == os.path.expandvars('~/a/test')
        elif k == 'YOLO':
            assert v == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        else:
            raise Exception

# Generated at 2022-06-12 07:27:26.499269
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    values = parse_env_file_contents(lines)
    for key, value in values:
        assert(key in ['TEST', 'THISIS', 'YOLO'])
        assert(value in ['${HOME}/yeee', '~/a/test', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

# Generated at 2022-06-12 07:27:35.798790
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:27:42.070202
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for key, val in parse_env_file_contents(lines):
        if key == 'TEST':
            assert re.match(r'\A.*/yeee$', val)
        elif key == 'THISIS':
            assert re.match(r'\A.*/a/test$', val)
        elif key == 'YOLO':
            assert val == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
        else:
            raise KeyError(key)



# Generated at 2022-06-12 07:27:56.560463
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'),
                                                     ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:59.870930
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:28:09.061255
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    try:
        assert next(values)
    except StopIteration:
        print("iterator exhausted")  # Should print this



# Generated at 2022-06-12 07:28:19.035085
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict([
        ('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    res = collections.OrderedDict(parse_env_file_contents(lines))

    assert res == expected



# Generated at 2022-06-12 07:28:26.588088
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ={})

    assert(environ['TEST'] == os.environ['HOME'] + '/yeee')
    assert(environ['THISIS'] == os.environ['HOME'] + '/a/test')
    assert(environ['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:28:34.823819
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:28:41.892871
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("parse_env_file_contents")

    lines = (
            'TEST=${HOME}/yeee-$PATH',
            'THISIS=~/a/test',
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    )

    result_lines = (
            ('TEST', '.../.../yeee-...:...'),
            ('THISIS', '.../a/test'),
            ('YOLO',
             '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )

    for val, result in zip(parse_env_file_contents(lines), result_lines):
        print(val)
        key, val = val

# Generated at 2022-06-12 07:28:51.997861
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = {'HOME': '/home/haxe/haxe', 'PATH': '...'}
    config = parse_env_file_contents(lines)

    next_item = config.__next__()

    assert next_item[0] == 'TEST'
    assert next_item[1] == '/home/haxe/haxe/yeee-...:...'

    next_item = config.__next__()

    assert next_item[0] == 'THISIS'
    assert next_item[1] == '~/a/test'

    next_item = config

# Generated at 2022-06-12 07:29:00.020102
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert isinstance(result, collections.OrderedDict)
    assert result['TEST'] == os.path.join(os.path.expanduser('~'), "yeee")
    assert result['THISIS'] == os.path.join(os.path.expanduser('~'), "a", "test")

# Generated at 2022-06-12 07:29:09.042998
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:29:18.751953
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    m = doctest.testmod(verbose=True)
    if m.failed != 0:
        exit(1)



# Generated at 2022-06-12 07:29:25.563952
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_env_file_contents(lines) == [(k, v) for k, v in load_env_file(lines, write_environ=dict()).items()]


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:29:27.518791
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:29:37.923473
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_parse_env_file_contents()

    # Example usage
    # changes = load_env_file(filename='/home/user/Documents/my.env')
    # print(changes)
    # # OrderedDict([('TEST', '.../yeee'),
    # #          ('THISIS', '.../a/test'),
    # #          ('YOLO',
    # #           '.../swaggins/$NONEXISTENT_VAR_

# Generated at 2022-06-12 07:29:45.393276
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_env_file_contents(contents) == [('TEST', '.../yeee'),
                                                 ('THISIS', '.../a/test'),
                                                 ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:29:48.147328
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest
    import textwrap



# Generated at 2022-06-12 07:29:49.961713
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:29:56.475132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # :s
    assert parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == parse_env_file_contents(
        ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])



# Generated at 2022-06-12 07:30:05.189404
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    changes = parse_env_file_contents(lines)
    assert changes == [
        ("TEST", expand("${HOME}/yeee")),
        ("THISIS", expand("~/a/test")),
        ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ]

# Generated at 2022-06-12 07:30:10.490726
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}', 'THISIS=~/a/test']

    ret = parse_env_file_contents(lines)

    assert next(ret) == ('TEST', os.getenv('HOME'))
    assert next(ret) == ('THISIS', os.path.expanduser('~/a/test'))

    try:
        next(ret)
    except StopIteration:
        pass



# Generated at 2022-06-12 07:30:28.961875
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', f'{os.environ["HOME"]}/yeee'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:30:37.627484
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = {}
    for key, value in parse_env_file_contents(lines):
        d[key] = value

    assert d == {'TEST': os.path.expanduser('~/yeee'),
                 'THISIS': os.path.expanduser('~/a/test'),
                 'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
                 }



# Generated at 2022-06-12 07:30:45.604960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=$HOME/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    changes = parse_env_file_contents(lines)

    assert changes.get("HOME", None) is not None
    assert changes.get("TEST", None) is not None
    assert changes.get("THISIS", None) is not None
    assert changes.get("YOLO", None) is not None


# Generated at 2022-06-12 07:30:55.249303
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test_simple_format1
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH'])) == [('TEST', '${HOME}/yeee-$PATH')]

    # test_simple_format2
    assert list(parse_env_file_contents(['THISIS=~/a/test'])) == [('THISIS', '~/a/test')]

    # test_simple_format3
    assert list(parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # test_singlequote_

# Generated at 2022-06-12 07:31:04.731378
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = os.environ.copy()

    changes = load_env_file(lines)

    assert changes == collections.OrderedDict([('TEST', '{}/yeee-{}:'.format(environ['HOME'], environ['PATH'])),
                                               ('THISIS', '{}/a/test'.format(environ['HOME'])),
                                               ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(environ['HOME']))])

# Generated at 2022-06-12 07:31:11.237586
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = parse_env_file_contents(lines)
    assert loaded == [('TEST', '.../yeee'),
                      ('THISIS', '.../a/test'),
                      ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:31:19.193081
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    EXPECTED = (
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )

    print()

    for result, expected in zip(parse_env_file_contents(os.linesep.join(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
                                                                          'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])),
                                EXPECTED):
        print(f'result = {result}')
        print(f'expected = {expected}')
       

# Generated at 2022-06-12 07:31:26.598283
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # lines = ['# this is a comment', 'TEST=${HOME}/yeee', '# this is another comment', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:31:37.488981
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        import pytest
    except ModuleNotFoundError:
        raise Exception('Please run pip install -r requirements-dev.txt')

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vars = load_env_file(lines, write_environ=None)
    assert vars == {'TEST': '.../.../yeee-...:...',
                    'THISIS': '.../a/test',
                    'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:31:45.820316
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test for function parse_env_file_contents
    
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """

# Generated at 2022-06-12 07:32:14.571148
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .files.tmp_file import tmp_file

    file = tmp_file()
    file.write("""\
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
""")

    file.close()

    with open(file.name) as f:
        results = load_env_file(f.readlines())


# Generated at 2022-06-12 07:32:20.861408
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:32:25.452644
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = load_env_file(lines, write_environ=dict())
    assert 'TEST' in loaded
    assert 'THISIS' in loaded
    assert 'YOLO' in loaded

# Generated at 2022-06-12 07:32:27.259168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.run_docstring_examples(parse_env_file_contents, globals())



# Generated at 2022-06-12 07:32:33.810316
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import os
    import tempfile
    import unittest

    data = [
        ('TEST=${HOME}/yeee', 'TEST', os.path.expanduser('~/yeee')),
        ('THISIS=~/a/test', 'THISIS', os.path.expanduser('~/a/test')),
        ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]


# Generated at 2022-06-12 07:32:45.577960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    variables = parse_env_file_contents(lines)
    assert isinstance(variables, collections.Iterable)
    for k, v in variables:
        assert isinstance(k, str)
        assert isinstance(v, str)

    content = list(variables)
    assert len(content) == 3


# Generated at 2022-06-12 07:32:53.390419
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = collections.OrderedDict(parse_env_file_contents(lines))

    assert len(d) == 3
    assert 'TEST' in d
    assert 'THISIS' in d
    assert 'YOLO' in d

    assert d['TEST'] == os.environ['HOME'] + '/yeee'
    assert d['THISIS'] == os.environ['HOME'] + '/a/test'

# Generated at 2022-06-12 07:33:03.568764
# Unit test for function parse_env_file_contents