

# Generated at 2022-06-12 07:23:08.854555
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class LoadEnvFileTest(unittest.TestCase):
        def setUp(self):
            self.env = dict(TEST_A='test_a', TEST_B='test_b')

        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            o: collections.OrderedDict = load_env_file(lines, write_environ=self.env)

            self.assertEqual(len(o), 3, 'Should have 3 items in the dict')

# Generated at 2022-06-12 07:23:10.646897
# Unit test for function load_env_file
def test_load_env_file():
    from . import utils

    utils.test_func(load_env_file)



# Generated at 2022-06-12 07:23:20.202446
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == \
           dict(TEST=os.path.expanduser(os.path.expandvars('${HOME}/yeee')),
                THISIS=os.path.expanduser(os.path.expandvars('~/a/test')),
                YOLO=os.path.expanduser(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))



# Generated at 2022-06-12 07:23:28.392206
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests that we can load env file contents properly.
    """
    filename = os.path.join(os.path.dirname(__file__), 'test_resources', 'test.env')

    with open(filename, 'r') as f:
        lines = f.readlines()

    load_env_file(lines)

    # Due to the way this works, we cannot directly test inter-vars crossing. We have to manually do it.
    assert os.environ.get('TEST') == '{HOME}/yeee-{PATH}'.format(HOME=os.environ.get('HOME'), PATH=os.environ.get('PATH'))
    assert os.environ.get('THISIS') == os.path.expanduser('~/a/test')



# Generated at 2022-06-12 07:23:32.258825
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['key=value'], write_environ=dict()) == collections.OrderedDict([('key', 'value')])



# Generated at 2022-06-12 07:23:40.405073
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    expected = [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    actual = list(parse_env_file_contents(lines))

    assert actual == expected



# Generated at 2022-06-12 07:23:47.909923
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import tempfile
    import os

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    with tempfile.NamedTemporaryFile() as tf:
        os.write(tf, '\n'.join(lines).encode('utf-8'))
        tf.flush()
        res = load_env_file(lines)


# Generated at 2022-06-12 07:23:50.251730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    for line in parse_env_file_contents(["TEST=0", "TEST=1"]):
        print("line =", line)



# Generated at 2022-06-12 07:23:58.302481
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:24:00.072323
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:24:05.607189
# Unit test for function load_env_file
def test_load_env_file():
    sample_env_file = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    load_env_file(sample_env_file)

# Generated at 2022-06-12 07:24:11.839486
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import io

    # Capture stderr output
    stderr = sys.stderr
    sys.stderr = io.StringIO()

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_lines = parse_env_file_contents(lines)
    parsed_lines = collections.OrderedDict(parsed_lines)

    assert 'TEST' in parsed_lines
    assert 'THISIS' in parsed_lines
    assert 'YOLO' in parsed_lines


# Generated at 2022-06-12 07:24:20.303841
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = os.path.join(os.path.dirname(__file__), 'data', 'test.env')

    with open(filename) as f:
        values = parse_env_file_contents(f)

    wanted = [('TEST', '.../.../yeee-...:...'),
              ('THISIS', '.../a/test'),
              ('YOLO',
               '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for (k1, v1), (k2, v2) in zip(values, wanted):
        assert k1 == k2
        assert v1 == v2



# Generated at 2022-06-12 07:24:31.009111
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    # Hack to test against an empty environ
    # os.environ.clear()

    if 'HOME' in os.environ:
        os.environ.pop('HOME')

    os.environ['PATH'] = os.pathsep.join([os.path.dirname(sys.executable)])

    # os.environ['FOO'] = 'bar'

    # import pprint
    # pprint.pprint(os.environ)

    output = [('HOME', os.path.expanduser('~')), ('PATH', os.pathsep.join([os.path.dirname(sys.executable)]))]

    for key, expected_output in output:
        assert os.environ[key] == expected_output


# Generated at 2022-06-12 07:24:38.887602
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import tempfile

    contents = """
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    
    with tempfile.NamedTemporaryFile('w') as tf:
        tf.write(contents)
        tf.flush()

        with open(tf.name, 'r') as f:
            changes = load_env_file(f)
    

# Generated at 2022-06-12 07:24:43.967750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    return



# Generated at 2022-06-12 07:24:50.902357
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '/.../yeee'),
             ('THISIS', '/.../a/test'),
             ('YOLO',
              '/.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:24:55.618149
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines) == load_env_file(lines, write_environ=None)
    assert isinstance(load_env_file(lines), collections.OrderedDict)

# Generated at 2022-06-12 07:25:02.927765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    expected = [('TEST', '.../yeee'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    output = [(k, v) for (k, v) in values]

    assert output == expected



# Generated at 2022-06-12 07:25:09.634153
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    config = {'DATABASE_URL': 'postgres://postgres:postgres@localhost'}
    file_contents = '\n'.join(f'{k}={v}' for k, v in config.items())

    actual = parse_env_file_contents(file_contents.split('\n'))

    expected = [('DATABASE_URL', 'postgres://postgres:postgres@localhost')]

    assert list(actual) == expected



# Generated at 2022-06-12 07:25:17.008899
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=test', "THISIS='test'", 'YOLO="test"', 'EMPTY=', 'COMMENTS=test # this is a comment', 'EMPTY_COMMENT=#']

    env = parse_env_file_contents(lines)

    assert dict(env) == {'TEST': 'test', "THISIS": 'test', 'YOLO': 'test', 'EMPTY': '', 'COMMENTS': 'test', 'EMPTY_COMMENT': ''}



# Generated at 2022-06-12 07:25:21.115336
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        assert v == expand(v)



# Generated at 2022-06-12 07:25:25.463052
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    a = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(a):
        print(k, v)



# Generated at 2022-06-12 07:25:36.231062
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert values.__next__() == ('TEST', os.path.join(os.path.expanduser('~'), 'yeee-') + os.pathsep + os.environ.get('PATH'))
    assert values.__next__() == ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test'))

# Generated at 2022-06-12 07:25:42.935146
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '.../yeee'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    actual = list(parse_env_file_contents(lines))

    assert actual == expected



# Generated at 2022-06-12 07:25:45.813448
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.run_docstring_examples(parse_env_file_contents, globals())



# Generated at 2022-06-12 07:25:52.811897
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())
    assert environ['TEST'] == os.path.join(os.getenv('HOME'), 'yeee')
    assert environ['THISIS'] == os.path.join(os.getenv('HOME'), 'a', 'test')
    assert environ['YOLO'] == os.path.join(os.getenv('HOME'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:26:00.983286
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=['TEST=$HOME/yeee'])) == [('TEST', '$HOME/yeee')]
    assert list(parse_env_file_contents(lines=['TEST="$HOME/yeee"'])) == [('TEST', '$HOME/yeee')]
    assert list(parse_env_file_contents(lines=['TEST=\'$HOME/yeee\''])) == [('TEST', '$HOME/yeee')]

# Generated at 2022-06-12 07:26:10.882398
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)
    # Expected result
    expected = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for res, exp in zip(result, expected):
        assert res[0] == exp[0], 'Unexpected key, exp: {0:s}, got: {1:s}'.format(exp[0], res[0])


# Generated at 2022-06-12 07:26:17.494797
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # This is a written test case that doesn't demonstrate how it is actually used (in load_env_file)
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-${PATH}'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}')]



# Generated at 2022-06-12 07:26:28.271214
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_lines = list(parse_env_file_contents(lines))
    assert parsed_lines == [('TEST', '.../.../yeee'),
                            ('THISIS', '.../a/test'),
                            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-12 07:26:36.527883
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = parse_env_file_contents(lines)

    from pathlib import Path
    p = Path(__file__)


# Generated at 2022-06-12 07:26:47.280719
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    result = parse_env_file_contents(lines)

    expect = [
        ('TEST', os.path.join(expand("~"), "yeee-") + os.environ["PATH"]),
        ('THISIS', expand("~/a/test")),
        ('YOLO', expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ]

    result = list(result)

    assert result == expect

# Generated at 2022-06-12 07:26:55.327731
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    result = load_env_file(lines, write_environ=dict())

    assert list(result) == [
        "TEST",
        "THISIS",
        "YOLO",
    ]

    assert result["TEST"] == os.path.join(expand("$HOME"), "yeee-") + expand("$PATH")
    assert result["THISIS"] == expand("~/a/test")
    assert result["YOLO"] == expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

    # Test expanded

# Generated at 2022-06-12 07:27:05.259969
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = parse_env_file_contents(lines)

    assert changes is not None

    assert len(changes) == 3

    for k, v in changes:
        if k == 'YOLO':
            assert v == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        if k == 'TEST':
            assert v == os.path.expanduser('~/yeee-%s' % os.environ['PATH'])

# Generated at 2022-06-12 07:27:12.477014
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))
    assert d['TEST'] == expand('${HOME}/yeee')
    assert d['THISIS'] == expand('~/a/test')
    assert d['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:27:21.283727
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = list(parse_env_file_contents(lines))

    assert loaded == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:27:28.372735
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    new_lines = parse_env_file_contents(lines)

    assert list(new_lines) == [
        ('TEST', os.path.expandvars('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]



# Generated at 2022-06-12 07:27:37.496192
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    with open('env_file.txt', 'w') as f:
        for line in lines:
            f.write(line)
            f.write('\n')

    with open('env_file.txt', 'r') as f:
        values = parse_env_file_contents(f)
        for v in values:
            print(v)

    assert 1 == 1



# Generated at 2022-06-12 07:27:43.102280
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("\nTesting parse_env_file_contents")

    lines = ['TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    for key, value in values:
        print("Key:", key)
        print("Value:", value)
        print("")



# Generated at 2022-06-12 07:27:56.637660
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    source = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    parsed_source = [i for j, i in parse_env_file_contents(source)]

    assert parsed_source[0].startswith('/')
    assert parsed_source[0].endswith('/yeee-')
    assert '/' in parsed_source[0]

    assert parsed_source[1].startswith('/')
    assert parsed_source[1].endswith('/a/test')
    assert '/' in parsed_source[1]

    assert parsed_source[2].startswith('/')

# Generated at 2022-06-12 07:28:02.933835
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:28:07.301900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:28:16.598546
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:28:21.811068
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests loading env file contents with `parse_env_file_contents()`
    """
    from pprint import pprint

    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    res = parse_env_file_contents(lines)

    pprint(list(res))



# Generated at 2022-06-12 07:28:28.350722
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test',
                                                    'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"']
   

# Generated at 2022-06-12 07:28:34.167404
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    r = load_env_file(lines, write_environ=dict())
    print(r)



# Generated at 2022-06-12 07:28:41.596945
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """\
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    results = parse_env_file_contents(lines.splitlines())

    assert list(results) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    results = parse_env_file_contents(lines.splitlines())
    results = load_env_file(lines.splitlines())


# Generated at 2022-06-12 07:28:51.075350
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee--$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    expected_result = [
        ("TEST", expand("${HOME}/yeee--$PATH")),
        ("THISIS", expand("~/a/test")),
        ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))
    ]

    for result_item, expected_item in zip(result, expected_result):
        assert result_item == expected_item



# Generated at 2022-06-12 07:28:59.091796
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Test data
    contents = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    # Parse contents
    values = parse_env_file_contents(contents)

    # Convert to dictionary
    env_vars = dict(values)

    # Assertions
    assert env_vars['TEST'] == '${HOME}/yeee'
    assert env_vars['THISIS'] == '~/a/test'
    assert env_vars['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Unit test

# Generated at 2022-06-12 07:29:09.043418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expect = {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    assert dict(parse_env_file_contents(lines)) == expect


# Unit tests for function load_env_file

# Generated at 2022-06-12 07:29:18.455511
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # ref: https://stackoverflow.com/a/3845990
    expected = collections.OrderedDict([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert actual == expected, 'Failed to parse env file contents'

# Generated at 2022-06-12 07:29:28.420772
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=['HELLO=WORLD'])) == [('HELLO', 'WORLD')]
    assert list(parse_env_file_contents(lines=['HELLO="WORLD"'])) == [('HELLO', 'WORLD')]
    assert list(parse_env_file_contents(lines=['HELLO="WORLD with spaces"'])) == [('HELLO', 'WORLD with spaces')]
    assert list(parse_env_file_contents(lines=['HELLO="WORLD \\" with spaces and quotes \\""'])) == [('HELLO', 'WORLD " with spaces and quotes "')]

# Generated at 2022-06-12 07:29:32.362783
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:41.086924
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [("TEST", "${HOME}/yeee"), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")], "Failed to parse a valid .env file"
    assert list(parse_env_file_contents(["TEST=THIS IS NOT VALID"])) == [("TEST", "THIS IS NOT VALID")], "Failed to parse an invalid .env file"



# Generated at 2022-06-12 07:29:47.004196
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        "TEST": expand('${HOME}/yeee'),
        "THISIS": expand('~/a/test'),
        "YOLO": expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }



# Generated at 2022-06-12 07:29:48.396878
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:29:56.090111
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = dict(parse_env_file_contents(lines))
    assert output['TEST'] == '${HOME}/yeee'
    assert output['THISIS'] == '~/a/test'
    assert output['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:30:03.644765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing basic key-value line
    lines = ['TEST=${HOME}/yeee-$PATH']
    load_env_file(lines, write_environ=dict())

    # Testing line with single quotes
    lines = ["TEST='${HOME}/yeee-$PATH'"]
    load_env_file(lines, write_environ=dict())

    # Testing line with double quotes
    lines = ['TEST="${HOME}/yeee-$PATH"']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:30:06.713153
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])