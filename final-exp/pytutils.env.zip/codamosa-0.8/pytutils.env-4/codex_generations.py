

# Generated at 2022-06-12 07:23:07.681368
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    import pprint as pp

    pp.pprint(list(parse_env_file_contents(lines)))

    assert True



# Generated at 2022-06-12 07:23:18.491958
# Unit test for function load_env_file
def test_load_env_file():
    # pylint: disable=invalid-name
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = dict()


# Generated at 2022-06-12 07:23:27.557549
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(
        os.path.dirname(__file__),
        '..',
        'example',
        '.env',
    )

    with open(filename, 'rt') as f:
        lines = [l.strip() for l in f.readlines()]

    changes = load_env_file(lines)
    assert len(changes) == 4
    assert list(changes.keys()) == ['PATH', 'TEST', 'THISIS', 'YOLO']
    assert list(changes.values()) == [
        '$HOME/.local/bin:$PATH',
        "$HOME/yeee-$PATH",
        "$HOME/a/test",
        "$HOME/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

# Generated at 2022-06-12 07:23:29.727295
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-12 07:23:38.907178
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    with tempfile.NamedTemporaryFile(mode='w') as env_file:
        for line in lines:
            env_file.write(line + "\n")
        env_file.flush()

        with open(env_file.name) as f:
            changes = load_env_file(f)

    # assert changes == changes_expected



# Generated at 2022-06-12 07:23:43.828923
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents([])) == dict()
    assert dict(parse_env_file_contents(['foo=bar'])) == dict(foo='bar')
    assert dict(parse_env_file_contents(['foo=bar', 'biz=baz'])) == dict(foo='bar', biz='baz')

# Generated at 2022-06-12 07:23:48.458344
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:23:55.805124
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = load_env_file(lines, write_environ=dict())
    assert loaded == collections.OrderedDict([('TEST', '.../yeee'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO',
                                               '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:24:06.877069
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = {}
    for k, v in parse_env_file_contents(lines):
        d[k] = v

    # Make test deterministic by sorting, since these values should not depend on the order they were read
    d = collections.OrderedDict(sorted(d.items()))

# Generated at 2022-06-12 07:24:15.577666
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert add(1, 1) == 2
    assert add(1, 2) == 3
    assert add(2, 2) == 4
    assert add(3, 5) == 8
    assert add(5, 8) == 13
    assert add(8, 13) == 21
    assert add(13, 21) == 34
    assert add(21, 34) == 55
    assert add(34, 55) == 89

    assert add(-2, 2) == 0
    assert add(0, 2) == 2
    assert add(5, -8) == -3



# Generated at 2022-06-12 07:24:21.069049
# Unit test for function load_env_file
def test_load_env_file():
    # noinspection SpellCheckingInspection
    lines = ['HELLO=world', 'NICE_TO_MEET_YOU=${HELLO}', 'YES="indeed"']
    res = load_env_file(lines)

    assert res == {
        'HELLO': 'world',
        'NICE_TO_MEET_YOU': 'world',
        'YES': 'indeed'
    }



# Generated at 2022-06-12 07:24:28.965730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
    ('THISIS', '~/a/test'),
    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:24:33.485603
# Unit test for function load_env_file
def test_load_env_file():
    f = io.StringIO()
    f.write('TEST=${HOME}/yeee-$PATH\n')
    f.write('THISIS=~/a/test\n')
    f.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
    f.seek(0)
    load_env_file(f)



# Generated at 2022-06-12 07:24:40.085915
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import os

    # Test for empty environment
    parsed_values = list(parse_env_file_contents())
    assert len(parsed_values) == 0

    # Test for simple environment
    parsed_values = list(parse_env_file_contents(["test=test", "test2=test2", "test3=test3"]))

    assert len(parsed_values) == 3

    assert parsed_values[0][0] == "test"
    assert parsed_values[1][0] == "test2"
    assert parsed_values[2][0] == "test3"

    # Test for `os.path.expandvars` and `os.path.expanduser`

# Generated at 2022-06-12 07:24:44.775037
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:24:50.399891
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = list(parse_env_file_contents(lines))
    assert values == [('TEST', '.../yeee'),
                      ('THISIS', '.../a/test'),
                      ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:24:57.977741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [
        ('TEST', os.path.join(os.environ.get('HOME', ''), 'yeee')),
        ('THISIS', os.path.join(os.environ.get('HOME', ''), 'a', 'test')),
        ('YOLO', os.path.join(os.environ.get('HOME', ''), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]

    result = [t for t in parse_env_file_contents(lines)]


# Generated at 2022-06-12 07:25:05.887616
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = load_env_file(lines, write_environ=dict())

    expected = {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }

    for k in result:
        assert result[k] == expected[k]



# Generated at 2022-06-12 07:25:16.466239
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(["a=aaa"]))['a'] == 'aaa'
    assert dict(parse_env_file_contents(["a=aaa", "b=bbb"]))['b'] == 'bbb'
    assert dict(parse_env_file_contents("a=aaa\nb=bbb".split("\n")))['b'] == 'bbb'
    assert dict(parse_env_file_contents("a=aaa\\nb=bbb".split("\n")))['a'] == 'aaa\\nb=bbb'
    assert dict(parse_env_file_contents("a='aaa'".split("\n")))['a'] == 'aaa'

# Generated at 2022-06-12 07:25:25.425839
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import os

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = parse_env_file_contents(lines)

    expected = [('TEST', '{}/yeee-{}'.format(os.environ['HOME'], os.environ['PATH'])),
                ('THISIS', '{}/a/test'.format(os.environ['HOME'])),
                ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ['HOME']))]

    assert expected == list(changes)


# Unit test

# Generated at 2022-06-12 07:25:30.012905
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']

    result = parse_env_file_contents(lines)

    assert (result is not None)



# Generated at 2022-06-12 07:25:37.154954
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    new_lines = list()
    for k, v in values:
        v = expand(v)
        new_lines.append(f'{k}={v}')

    assert new_lines == lines



# Generated at 2022-06-12 07:25:45.010787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Shallow tests
    assert isinstance(parse_env_file_contents(lines), type(
        (x for x in [])))  # parse_env_file_contents returns a generator

    # Contents tests
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:25:46.499497
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:25:49.600438
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env = parse_env_file_contents(['PATH = ./', 'SPAM = "eggs"'])
    assert dict(env) == {'PATH': './', 'SPAM': 'eggs'}



# Generated at 2022-06-12 07:25:55.702604
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:26:02.365620
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    @mock.patch('os.path.expandvars')
    @mock.patch('os.path.expanduser')
    def t(environ_mock, expanduser_mock):
        environ_mock.side_effect = lambda x: x

        expanduser_mock.side_effect = lambda x: x

        lines = [
            'TEST=$HOME/yeee-$PATH',
            'THISIS=~/a/test',
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        ]

        values = parse_env_file_contents(lines)

# Generated at 2022-06-12 07:26:11.460400
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test normal string
    input_string = ['TEST=${HOME}/yeee']
    parse_env_file_contents(input_string)

    # Test single quote
    input_string = ["TEST='${HOME}/yeee'"]
    parse_env_file_contents(input_string)

    # Test double quotes
    input_string = ['TEST="${HOME}/yeee"']
    parse_env_file_contents(input_string)
    # Test special char
    input_string = ["TEST=\"${HOME}/yee\\\"e\""]
    parse_env_file_contents(input_string)

    input_string = ["TEST=${HOME}/ye\\eee"]
    parse_env_file_contents(input_string)

    # Test key

# Generated at 2022-06-12 07:26:15.862015
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at ...>
    """



# Generated at 2022-06-12 07:26:26.037048
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test basic parsing
    env = ['FOO=BAR', 'BAR=FOO']
    parsed = list(parse_env_file_contents(env))
    assert len(parsed) == 2
    assert parsed[0] == ('FOO', 'BAR')
    assert parsed[1] == ('BAR', 'FOO')

    # test parsing of quoted values
    env = ['FOO="BAR"', "BAR='FOO'"]
    parsed = list(parse_env_file_contents(env))
    assert len(parsed) == 2
    assert parsed[0] == ('FOO', 'BAR')
    assert parsed[1] == ('BAR', 'FOO')

    # test parsing of quoted values containing double quotes

# Generated at 2022-06-12 07:26:35.682745
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    results = parse_env_file_contents(lines)
    results = list(results)

    keys = [result[0] for result in results]
    assert keys == [
        'TEST',
        'THISIS',
        'YOLO'
    ]

    vals = [result[1] for result in results]

# Generated at 2022-06-12 07:26:39.810170
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['VAR=value', 'VAR2=some_value', 'VAR3=value3']
    assert list(parse_env_file_contents(lines)) == [('VAR', 'value'), ('VAR2', 'some_value'), ('VAR3', 'value3')]



# Generated at 2022-06-12 07:26:50.019487
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # A doc test would be nice, but it's unclear how to do it with the generators and such.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)
    assert changes['TEST'] == os.environ['HOME'] + '/yeee'
    assert changes['THISIS'] == os.environ['HOME'] + '/a/test'
    assert changes['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-12 07:26:56.999856
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        lines_given = ['HEAD=HEAD', 'TEST=${HOME}/yeee', 'THISIS=~/a/test', 'NEW_HOME=${HOME}', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        changes = load_env_file(lines_given)
        test = str(changes)
        assert(test == "OrderedDict([('HEAD', 'HEAD'), ('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('NEW_HOME', '...'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])")
    except:
        assert(False)

    # Uncomment the lines below to test that

# Generated at 2022-06-12 07:27:05.934483
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines)

    assert isinstance(environ, collections.OrderedDict)

    assert environ['TEST'] == os.path.join(os.environ['HOME'], 'yeee')
    assert environ['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')
    assert environ['YOLO'] == os.path.join(os.environ['HOME'], 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:27:15.947966
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import textwrap

    lines = textwrap.dedent("""
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """).strip().splitlines()

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '.../.../yeee-...:...')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    with pytest.raises(StopIteration):
        next(values)



# Generated at 2022-06-12 07:27:22.521049
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for key, val in parse_env_file_contents(lines):
        # print(key, val)
        assert isinstance(key, str)
        assert isinstance(val, str)



# Generated at 2022-06-12 07:27:29.257889
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # All lines are correct
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']
    exp = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins')]
    try:
        obs = [(k, v) for k, v in parse_env_file_contents(lines)]
        assert exp == obs
    except ValueError:
        assert False

    # One line is bad
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']
    exp = [('TEST', '.../yeee'), ('THISIS', '.../a/test')]
   

# Generated at 2022-06-12 07:27:35.626012
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)

    for key, val in result:
        print(key, val)



# Generated at 2022-06-12 07:27:40.946743
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '$HOME/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:27:46.147924
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:27:53.657801
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    unit test for function parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == dict(TEST='${HOME}/yeee', THISIS='~/a/test', YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:28:01.244875
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> list(parse_env_file_contents(lines))
    [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """
    pass



# Generated at 2022-06-12 07:28:09.213578
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """ Simple Unit test for function parse_env_file_contents """

    import io

    file = io.StringIO("TEST_ENV_VALUE=TEST\nTEST_ENV_VALUE2=TEST2")
    lines = parse_env_file_contents(file)
    res = list(lines)

    assert len(res) == 2
    assert res[0][0] == "TEST_ENV_VALUE"
    assert res[1][0] == "TEST_ENV_VALUE2"
    assert res[0][1] == "TEST"
    assert res[1][1] == "TEST2"



# Generated at 2022-06-12 07:28:20.582055
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=['TEST=foo'])) == [('TEST', 'foo')]
    assert list(parse_env_file_contents(lines=['TEST="foo"'])) == [('TEST', 'foo')]
    assert list(parse_env_file_contents(lines=['TEST="foo bar"'])) == [('TEST', 'foo bar')]
    assert list(parse_env_file_contents(lines=['TEST="foo bar baz"'])) == [('TEST', 'foo bar baz')]
    assert list(parse_env_file_contents(lines=['TEST="foo bar baz"'])) == [('TEST', 'foo bar baz')]

# Generated at 2022-06-12 07:28:27.846997
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import random
    import string

    def random_string(length, lower=False):
        chars = string.ascii_letters + string.digits + '_'
        if lower:
            chars = chars.lower()
        return (random.choice(chars) for _ in range(length))

    for _ in range(50):
        lines = (
            ''.join(random_string(10, True)) + '=' +
            ''.join(random_string(random.randint(0, 50)))
            for _ in range(random.randint(0, 25))
        )

        changes = load_env_file(lines)

        for line, change in zip(lines, changes.items()):
            key, val = change

            assert line.startswith(key + '=')


# Generated at 2022-06-12 07:28:34.072357
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    lines = parse_env_file_contents(lines)

    for line in lines:
        print(line)



# Generated at 2022-06-12 07:28:39.897559
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # See if it expands things
    expected = {
        'TEST': os.environ['HOME'] + '/yeee',
        'THISIS': os.environ['HOME'] + '/a/test',
    }
    result = dict(parse_env_file_contents(lines))

    assert result == expected



# Generated at 2022-06-12 07:28:48.835955
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)
    res2 = collections.OrderedDict()
    for k, v in res:
        res2[k] = v
    assert res2 == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:28:56.459986
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_cases = [
        (['TEST=${HOME}/yeee'], '.../yeee'),
        (['THISIS=~/a/test'], '.../a/test'),
        (['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        (['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]


# Generated at 2022-06-12 07:29:09.042998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents([]) == []
    assert list(parse_env_file_contents(['TEST=yeet'])) == [('TEST', 'yeet')]
    assert list(parse_env_file_contents(['TEST=yeee-$PATH'])) == [('TEST', 'yeee-$PATH')]
    assert list(parse_env_file_contents(['TEST=~/yeet'])) == [('TEST', '~/yeet')]
    assert list(parse_env_file_contents(['TEST=${HOME}/yeet'])) == [('TEST', '${HOME}/yeet')]

# Generated at 2022-06-12 07:29:17.522154
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    write_environ = os.environ

    changes = load_env_file(lines, write_environ)

    assert changes["TEST"] == os.path.join(os.path.expanduser("~"), "yeee")
    assert changes["THISIS"] == os.path.join(os.path.expanduser("~"), "a", "test")



# Generated at 2022-06-12 07:29:26.233015
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = collections.OrderedDict(parse_env_file_contents(lines))

    assert values['TEST'] == os.path.expanduser('${HOME}/yeee')
    assert values['THISIS'] == os.path.expanduser('~/a/test')
    assert values['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:29:36.523744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = io.StringIO(
        "\n".join(
            [
                "TEST=$HOME/yeee",
                "THISIS=~/a/test",
                "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
            ]
        )
    )

    def test(var_dict, expected):
        actual = dict(var_dict)
        assert actual == expected, "{} vs. {}".format(actual, expected)

    yeee_dir = os.path.expanduser("~/yeee")
    a_test_dir = os.path.expanduser("~/a/test")
    swaggins_dir = os.path.expanduser("~/swaggins/")
    empty = ""



# Generated at 2022-06-12 07:29:43.032643
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:29:54.084041
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    This is a simple unit test for function parse_env_file_contents.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = collections.OrderedDict()

    for key, value in parse_env_file_contents(lines):
        result[key] = value


# Generated at 2022-06-12 07:29:58.922063
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test']
    env_vars = parse_env_file_contents(lines)
    print(env_vars)


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:30:08.315991
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    lines = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    )

    for k, v in parse_env_file_contents(iter(lines)):
        assert (k, v) == expected.pop(0)



# Generated at 2022-06-12 07:30:14.822376
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["GIT_SSH=/home/${USER}/.ssh/ssh_wrapper.sh",
             "GIT_SSL_NO_VERIFY=1",
             "GREP_OPTIONS='--color=auto'"]

    for key, value in parse_env_file_contents(lines=lines):
        print(key, "=", value)

    print("-" * 64)

    lines = ["GIT_SSH=/home/${USER}/.ssh/ssh_wrapper.sh",
             "GIT_SSL_NO_VERIFY=1",
             "GREP_OPTIONS='--color=auto'",
             "DANES='--color=auto', '--danes are cool'"]

    values = parse_env_file_contents(lines=lines)

    for item in values:
        print

# Generated at 2022-06-12 07:30:21.638493
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    x = list(parse_env_file_contents(lines))

    assert set(x) == set([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # Unit test for function load_env_file

# Generated at 2022-06-12 07:30:37.571233
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = load_env_file(lines, write_environ=None)
    assert len(data) == 3
    assert data['TEST'].startswith(os.environ['HOME'])
    assert data['TEST'].endswith('/yeee')
    assert data['YOLO'].startswith(os.environ['HOME'])



# Generated at 2022-06-12 07:30:47.166836
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [('TEST', '.../yeee'),
                                                                                                                                         ('THISIS', '.../a/test'),
                                                                                                                                         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:30:50.737310
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:31:00.009263
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:31:01.482447
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    results = doctest.testmod()
    assert results.failed == 0



# Generated at 2022-06-12 07:31:10.566571
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = list(parse_env_file_contents(lines))

    assert results[0][0] == 'TEST'
    assert expand(results[0][1]) == expand('${HOME}/yeee')

    assert results[1][0] == 'THISIS'
    assert expand(results[1][1]) == expand('~/a/test')

    assert results[2][0] == 'YOLO'
    assert expand(results[2][1]) == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


#

# Generated at 2022-06-12 07:31:17.795341
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # From honcho
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        env[k] = v
    assert env == {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:31:21.491560
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-12 07:31:29.143092
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    from io import StringIO

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-12 07:31:38.170429
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # make sure the example code in docstring passes
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert isinstance(values, typing.Generator)
    assert list(values) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:32:01.755294
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    contents = dict(parse_env_file_contents(lines))
    assert 'TEST' in contents
    assert 'THISIS' in contents
    assert 'YOLO' in contents

# Generated at 2022-06-12 07:32:11.603492
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    o = parse_env_file_contents(lines)
    res = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    for i, kv in enumerate(o):
        assert kv == res[i]



# Generated at 2022-06-12 07:32:14.091468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        assert expand(v)

# Generated at 2022-06-12 07:32:22.612657
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # noinspection PyArgumentList
    assert collections.OrderedDict(parse_env_file_contents(lines=lines)) == \
           collections.OrderedDict([('TEST', expand('${HOME}/yeee')),
                                    ('THISIS', expand('~/a/test')),
                                    ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    # unit test for function load_env_file
    # noinspection PyArgumentList

# Generated at 2022-06-12 07:32:29.827420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests parsing of an env file content.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:32:33.656780
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert lines == list(parse_env_file_contents(lines))



# Generated at 2022-06-12 07:32:45.404793
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

    test = list(parse_env_file_contents(lines))

    assert len(test) == 3
    assert test[0][0] == "TEST"
    assert test[0][1] == "${HOME}/yeee"
    assert test[1][0] == "THISIS"
    assert test[1][1] == "~/a/test"
    assert test[2][0] == "YOLO"

# Generated at 2022-06-12 07:32:53.289499
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env_vars = parse_env_file_contents(lines)

    assert isinstance(env_vars, collections.Generator)

    env_dict = collections.OrderedDict(env_vars)

    assert isinstance(env_dict, collections.OrderedDict)

    assert env_dict['TEST'].endswith('/yeee')
    assert env_dict['THISIS'].endswith('/a/test')

# Generated at 2022-06-12 07:32:59.722637
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .common import assert_equals
    from .common import here
    from pathlib import Path

    lines = Path(here(__file__), 'test.env').read_text().splitlines()
    assert_equals(list(parse_env_file_contents(lines=lines)), [
        ('TEST', '/home/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

