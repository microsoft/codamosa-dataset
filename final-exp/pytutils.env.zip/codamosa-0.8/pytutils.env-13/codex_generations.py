

# Generated at 2022-06-12 07:23:05.260655
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert list(values) == [('TEST', '{}/yeee-{}'.format(expand('$HOME'), expand('$PATH'))),
                            ('THISIS', '{}/a/test'.format(expand('~'))),
                            ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(expand('~')))]



# Generated at 2022-06-12 07:23:13.130340
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = load_env_file(lines, write_environ=dict())

    assert data['TEST'] == expand('${HOME}/yeee')
    assert data['THISIS'] == expand('~/a/test')
    assert data['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:23:21.512765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import itertools

    test_cases = [('TEST=${HOME}/yeee-$PATH', 'TEST', '{}/yeee-{}'.format(os.environ['HOME'], os.environ['PATH'])),
                  ('THISIS=~/a/test', 'THISIS', '{}/a/test'.format(os.environ['HOME'])),
                  ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO',
                   '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ['HOME']))]

    test_case_lines = list(map(lambda t: t[0], test_cases))

    test_

# Generated at 2022-06-12 07:23:28.889750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test data
    lines = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    # Parse the lines, execute the generator
    result = list(parse_env_file_contents(lines))

    # Assertions
    assert len(result) == 3
    assert result[0] == ('TEST', '.../yeee')
    assert result[1] == ('THISIS', '.../a/test')
    assert result[2] == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:23:40.234602
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(b"PATH=/usr/bin")) == {"PATH": "/usr/bin"}
    assert dict(parse_env_file_contents(b"  PATH=/usr/bin  ")) == {"PATH": "/usr/bin"}
    assert dict(parse_env_file_contents(b"  PATH = /usr/bin  ")) == {"PATH": "/usr/bin"}

    assert dict(parse_env_file_contents(b"PATH=/usr/bin  # Comment")) == {"PATH": "/usr/bin"}
    assert dict(parse_env_file_contents(b"PATH=/usr/bin  \n# Comment")) == {"PATH": "/usr/bin"}


# Generated at 2022-06-12 07:23:47.820900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # First test
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    if results.keys() != expected.keys():
        raise Exception("Keys don't match")


# Generated at 2022-06-12 07:23:56.695336
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())
    assert d == collections.OrderedDict([('TEST', '.../yeee'),
                                         ('THISIS', '.../a/test'),
                                         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-12 07:24:01.668244
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:24:07.477626
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:24:18.882616
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    for arg, expected in (
            (None, []),
            (['TEST=${HOME}/yeee-PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
             [('TEST', os.path.expanduser(os.path.expandvars('${HOME}/yeee-$PATH'))),
              ('THISIS', os.path.expanduser(os.path.expandvars('~/a/test'))),
              ('YOLO', os.path.expanduser(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))]),
    ):
        actual = parse

# Generated at 2022-06-12 07:24:20.980909
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass

# Generated at 2022-06-12 07:24:31.622186
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())

    # TEST=${HOME}/yeee
    # THISIS=~/a/test
    # YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST

    assert d.get('TEST') is not None
    assert d.get('THISIS') is not None
    assert d.get('YOLO') is not None

    assert d.get('TEST') == os.path.join(os.environ.get('HOME'), 'yeee')
   

# Generated at 2022-06-12 07:24:36.190734
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import json
    import sys

    args = sys.argv[1:]

    if args:
        # Print the values passed to json.dumps

        data = parse_env_file_contents(args)
        json.dump(dict(data), sys.stdout)

    else:
        # Run the tests

        import doctest

        doctest.testmod()

# Generated at 2022-06-12 07:24:41.838476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import sys
    sys.exit(test_parse_env_file_contents())

# Generated at 2022-06-12 07:24:50.028262
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    values = parse_env_file_contents(contents)
    results = []

    for k, v in values:
        v = expand(v)
        print(k, v)
        results.append((k, v))

    assert results[0] == ("TEST", "..." + "/yeee")
    assert results[1] == ("THISIS", "..." + "/a/test")

# Generated at 2022-06-12 07:24:57.658245
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Testing parse_env_file_contents function.
    """
    import sys
    from io import StringIO

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    load_env_file(lines, write_environ=dict())
    sys.stdout = old_stdout

    # Validate dictionary
    dictionary = mystdout.getvalue().strip()


# Generated at 2022-06-12 07:25:06.519187
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Ensure that the function is properly handling strings
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
        ('THISIS', os.path.join(os.path.expanduser('~'), 'a/test')),
        ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])

# Generated at 2022-06-12 07:25:08.032772
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from doctest import testmod

    testmod()



# Generated at 2022-06-12 07:25:17.972058
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = {}

    for k, v in parse_env_file_contents(lines):
        environ[k] = v

    assert environ['TEST'] == '{}/yeee-{}'.format(os.environ['HOME'], os.environ['PATH'])
    assert environ['THISIS'] == '{}/a/test'.format(os.environ['HOME'])

# Generated at 2022-06-12 07:25:27.645876
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test what happens when string is a variable
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    # Test what happens when string is in single quotes
    lines = ["TEST='$HOME/yeee'", 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    # Test what happens when string is in double quotes

# Generated at 2022-06-12 07:25:37.267576
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:25:41.111556
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ret = parse_env_file_contents(lines)
    assert len(ret) == 3



# Generated at 2022-06-12 07:25:50.355525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-12 07:25:59.864098
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:26:01.339369
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:26:10.857809
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Write environment variable to os.environ
    load_env_file(lines)

    # Check for values of environment variables
    assert os.environ['TEST'] == os.path.expanduser('~/yeee')
    assert os.environ['THISIS'] == os.path.expanduser('~/a/test')
    assert os.environ['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:26:12.964589
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert ("TEST", "...") in list(parse_env_file_contents(["TEST=..."]))



# Generated at 2022-06-12 07:26:23.056546
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = {'TEST': '.../.../yeee-...:...',
               'THISIS': '.../a/test',
               'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
               }

    for k, v in parse_env_file_contents(lines):
        assert results[k] == v


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:26:24.448462
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(globs={}, verbose=True)

# Generated at 2022-06-12 07:26:33.418123
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # pylint: disable=unused-variable,unused-argument

    def unit_test(expected_changes, lines):
        changes = load_env_file(lines, write_environ=dict())
        assert changes == expected_changes, "Unexpected changes"

    # Format:
    # unit_test(expected_changes, lines)


# Generated at 2022-06-12 07:26:45.211013
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Possibility to use StringIO instead: https://stackoverflow.com/questions/37302839/how-to-mock-sys-stdout-in-python-with-pytest
    assert parse_env_file_contents(lines) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'),
                                              ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:26:48.017328
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    current_env = load_env_file(open(".env"))
    assert current_env["TEST"] == "yeee-$PATH"



# Generated at 2022-06-12 07:26:53.981530
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:27:04.151293
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    # print(list(environ_key_value_pairs(lines)))

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    dict_ = dict(parse_env_file_contents(lines))

    assert dict_['TEST'] == os.path.expanduser('~/yeee')
    assert dict_['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-12 07:27:11.150647
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '$HOME/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:27:18.140645
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import os
    import unittest

    class TestParseEnvFile(unittest.TestCase):
        def test_parse_env_file(self):
            environ = dict()
            parse_env_file_contents(iter(['FOO=bar', 'FOO=baz']), environ)

            self.assertEqual(environ['FOO'], 'baz')

    if sys.version_info[0] < 3:
        unittest.main()



# Generated at 2022-06-12 07:27:27.634750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    parsed = parse_env_file_contents(lines)

    home = os.path.expanduser('~')

    expected = [
        ('TEST', home + '/yeee-' + os.environ['PATH']),
        ('THISIS', home + '/a/test'),
        ('YOLO', home + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]


# Generated at 2022-06-12 07:27:28.621538
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:27:39.098543
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    data = parse_env_file_contents(lines)
    expected = collections.OrderedDict([
        ('TEST', os.path.expanduser('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

    data = collections.OrderedDict(data)

    assert data == expected



# Generated at 2022-06-12 07:27:47.743968
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests for function parse_env_file_contents
    """
    import datetime
    import pytest

    from dockerfiles_python.core import io

    def _test_case(
        lines: typing.Iterable[str],
        expected: typing.Dict[str, str],
    ) -> None:
        """
        Runs a test case.
        """
        actual = dict(parse_env_file_contents(lines))

        assert actual == expected


# Generated at 2022-06-12 07:27:55.377986
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=None) is not None



# Generated at 2022-06-12 07:28:02.276395
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]



# Generated at 2022-06-12 07:28:10.267610
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    expected = [
        ('TEST', expand('${HOME}/yeee-$PATH')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

    for index, (k, v) in enumerate(values):
        assert k == expected[index][0]
        assert k == expected[index][0]

# Generated at 2022-06-12 07:28:20.934786
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert list(values)[0][0] == 'TEST'
    assert list(values)[1][0] == 'THISIS'
    assert list(values)[2][0] == 'YOLO'

    assert 'HOME' in list(values)[0][1]
    assert 'yeee' in list(values)[0][1]
    assert 'a' in list(values)[1][1]
    assert 'test' in list(values)[1][1]
    assert 'swaggins' in list(values)[2][1]
   

# Generated at 2022-06-12 07:28:28.013051
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-~/$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vals = parse_env_file_contents(lines)
    assert next(vals) == ('TEST', '.../yeee-.../...')
    assert next(vals) == ('THISIS', '.../a/test')
    assert next(vals) == (
        'YOLO', '.../swaggins/...')

    vals = parse_env_file_contents(['TEST=${HOME}'])
    assert next(vals) == ('TEST', '...')


# Generated at 2022-06-12 07:28:38.548049
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

    gen = parse_env_file_contents(lines)
    assert gen.__next__() == ("TEST", ".../yeee")
    assert gen.__next__() == ("THISIS", ".../a/test")
    assert gen.__next__() == ("YOLO", ".../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

    try:
        gen.__next__()
        assert False, "Expected StopIteration error with next()"
    except StopIteration:
        pass



# Generated at 2022-06-12 07:28:48.991089
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-12 07:28:56.543939
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_obj = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    results = parse_env_file_contents(file_obj.split("\n"))

    assert isinstance(results, typing.Generator)

    results = list(results)

    assert isinstance(results, list)
    assert len(results) == 3

    assert isinstance(results[0], tuple)
    assert isinstance(results[1], tuple)
    assert isinstance(results[2], tuple)

    assert results[0][0] == "TEST"
    assert results[0][1] == "${HOME}/yeee"

    assert results[1][0]

# Generated at 2022-06-12 07:29:04.360092
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """ Test parse_env_file_contents."""
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    generated = collections.OrderedDict(parse_env_file_contents(lines))

    expected = collections.OrderedDict({
        'TEST': expand(os.environ['HOME'] + '/yeee-' + os.environ['PATH']),
        'THISIS': expand(os.environ['HOME'] + '/a/test'),
        'YOLO': expand(os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    })

# Generated at 2022-06-12 07:29:07.818664
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)



# Generated at 2022-06-12 07:29:21.856730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Check the output of parse_env_file_contents
    assert (tuple(load_env_file(lines, write_environ=None).items()) ==
            (('TEST', os.environ.get('HOME') + "/yeee"),
             ('THISIS', os.path.expanduser('~/a/test')),
             ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))))

    # Check the output of parse_env_file_contents
    # Ensure that

# Generated at 2022-06-12 07:29:31.866755
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', os.path.expandvars('${HOME}/yeee')),
                                                    ('THISIS', os.path.expandvars('~/a/test')),
                                                    ('YOLO', os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]

# Generated at 2022-06-12 07:29:41.004256
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['A=1', 'B=2']
    res = parse_env_file_contents(lines)
    assert res == [('A', '1'), ('B', '2')]

    lines = ['A="1"', 'B="2"']
    res = parse_env_file_contents(lines)
    assert res == [('A', '1'), ('B', '2')]

    lines = ['A="1 2"', 'B="3 4"']
    res = parse_env_file_contents(lines)
    assert res == [('A', '1 2'), ('B', '3 4')]

    lines = ['A="1 \"2\""', 'B="3 \'4\' 5"']
    res = parse_env_file_contents(lines)

# Generated at 2022-06-12 07:29:43.005381
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:29:45.083397
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests `parse_env_file_contents()` using doctests.
    """
    import doctest
    import envparse

    doctest.testmod(envparse)



# Generated at 2022-06-12 07:29:55.142448
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = collections.OrderedDict({
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    })

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert expected == actual



# Generated at 2022-06-12 07:30:05.818940
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO',
                                                                                   '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:30:12.542730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee-$PATH')),
                                                    ('THISIS', expand('~/a/test')),
                                                    ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:30:16.231019
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:30:24.960379
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = 'envfile'
    with open(filename, 'w') as envfile:
        envfile.write('TEST=${HOME}/yeee-$PATH\n')
        envfile.write('THISIS=~/a/test\n')
        envfile.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:30:48.880924
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest

    from unittest import mock

    from . import unittest_helper

    class Test(unittest.TestCase):
        def test_1(self):
            m = mock.Mock()
            parse_env_file_contents(io.StringIO(''), m)
            m.assert_not_called()

        def test_2(self):
            m = mock.Mock()
            parse_env_file_contents(io.StringIO('A=3\n'), m)
            m.assert_called_once_with('A', '3')

        def test_3(self):
            m = mock.Mock()
            parse_env_file_contents(io.StringIO('A="3"'), m)
            m.assert_called_once_with

# Generated at 2022-06-12 07:30:57.319911
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual_dict = collections.OrderedDict(list(parse_env_file_contents(lines)))

    expected_dict = collections.OrderedDict()
    expected_dict['TEST'] = '.../yeee'
    expected_dict['THISIS'] = '.../a/test'
    expected_dict['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-12 07:31:06.580453
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Example from honcho source
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    # Check they have been parsed correctly
    assert collections.OrderedDict(values) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test',
                                              'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    # Example from honcho source

# Generated at 2022-06-12 07:31:15.335594
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert {k: expand(v) for k, v in parse_env_file_contents(lines)} == {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    import argparse
    parser = argparse.ArgumentParser(description='Evaluates and loads a .env file.')

# Generated at 2022-06-12 07:31:21.341298
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with a newline at the end of the file
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n']
    load_env_file(lines, write_environ=dict())
    # Test with no newline at the end of the file
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:31:29.114152
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests parse_env_file_contents function
    """

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v


# Generated at 2022-06-12 07:31:38.169327
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = os.path.join(os.path.dirname(__file__), "sample.env")

    with open(filename) as f:
        data = list(parse_env_file_contents(f))

    assert len(data) == 4

    assert data[0] == ("TEST", "-e ./tests/test.py")
    assert data[1] == ("HOME", "/Users/test")
    assert data[2] == ("LANG", "en_US.UTF-8")
    assert data[3] == ("YOLO", "$PATH")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:31:46.424014
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-12 07:31:47.859868
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:31:57.364490
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'WITH QUOTES="AND THINGS"']
    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')), ('WITH', expand('QUOTES="AND THINGS"'))]


# Generated at 2022-06-12 07:32:32.263312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    values = parse_env_file_contents(lines)

    assert tuple(values) == (
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )



# Generated at 2022-06-12 07:32:43.920582
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        "YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'",
        'EQUALS_NEXT_LINE="firstline\nsecondline\n"',
        'MULTIPLE_EQUALS_NEXT_LINE="firstline\nsecondline\n"',
        'MULTIPLE_EQUALS_NEXT_LINE="secondline\n"',
    ]

# Generated at 2022-06-12 07:32:47.438137
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    doc = test_parse_env_file_contents.__doc__.replace(">>>", "")

    if doc != parse_env_file_contents.__doc__:
        raise AssertionError("Unit test failed.")



# Generated at 2022-06-12 07:32:54.179262
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test a basic file
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == \
        collections.OrderedDict([('TEST', '.../yeee'),
                                 ('THISIS', '.../a/test'),
                                 ('YOLO',
                                  '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # Test escape characters
    lines = ['TEST=\\$HOME', 'THISIS=\\m/', 'YOLO=\\\\m/']