

# Generated at 2022-06-12 07:23:07.194624
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:23:17.539586
# Unit test for function load_env_file
def test_load_env_file():
    """
    Loads (and returns) an env file specified by `filename` into the mapping `environ`.

    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """
    pass

# Generated at 2022-06-12 07:23:25.159231
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=dict())



# Generated at 2022-06-12 07:23:34.665541
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict([
        ('TEST', '/home/yeee'),
        ('THISIS', '/home/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    assert environ == expected



# Generated at 2022-06-12 07:23:40.913923
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:23:48.021693
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    test_cases = [
        ("TEST", "~/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]

    for key, val in parse_env_file_contents(lines):
        assert key in [k for k, v in test_cases]
        assert val in [v for k, v in test_cases]



# Generated at 2022-06-12 07:23:50.441336
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: Use pytest
    try:
        import doctest
        doctest.testmod()
    except ImportError:
        raise Exception('Failed to import doctest')

# Generated at 2022-06-12 07:23:58.401117
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines)

    test_file = io.StringIO(u'HOME=/home/test')
    test_file_changes = load_env_file(parse_env_file_contents(test_file), write_environ=changes)

    with open(__file__) as actual_file:
        actual_file_changes = load_env_file(parse_env_file_contents(actual_file), write_environ=changes)

    import sys
    import pytest
    # Test that changes are indeed recorded
    assert changes['TEST']

# Generated at 2022-06-12 07:24:08.084484
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = dict()

    changes = load_env_file(lines, write_environ=environ)

    assert changes['TEST'] == os.path.expanduser(os.path.expandvars('~/yeee-$PATH'))
    assert changes['THISIS'] == os.path.expanduser(os.path.expandvars('~/a/test'))

# Generated at 2022-06-12 07:24:18.961417
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
             'VAR1=value1', 'VAR2=value2']
    result = collections.OrderedDict(
        [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
         ('VAR1', 'value1'), ('VAR2', 'value2')])

    assert load_env_file(lines, write_environ=None) == result

# Generated at 2022-06-12 07:24:27.316546
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert True


if __name__ == "__main__":
    test_parse_env_file_contents()
    print('___LOAD_ENV_FILE_TEST_PASSED___')

# Generated at 2022-06-12 07:24:33.693592
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """



# Generated at 2022-06-12 07:24:40.090960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pytest import raises
    from io import StringIO

    with raises(TypeError):
        parse_env_file_contents()

    with raises(TypeError):
        parse_env_file_contents(None)

    with raises(TypeError):
        parse_env_file_contents(1)

    assert parse_env_file_contents([]) is not None

    with StringIO() as f:
        f.write('TEST=${HOME}/yeee')
        f.write('\n')
        f.seek(0)

        items = parse_env_file_contents(f)
        assert items is not None

        item = next(items)

        assert isinstance(item, tuple)
        assert len(item) == 2
        assert item[0] == 'TEST'


# Unit test

# Generated at 2022-06-12 07:24:44.458716
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-12 07:24:50.097537
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:24:50.834343
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    return None



# Generated at 2022-06-12 07:24:58.338876
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = '''
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''

    lines = iter(contents.splitlines())

    changes = load_env_file(lines)

    assert 'TEST' in changes.keys()
    assert '${HOME}' not in changes['TEST']

    assert 'THISIS' in changes.keys()
    assert '~/a/test' in changes['THISIS']

    assert 'YOLO' in changes.keys()
    assert '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in changes['YOLO']



# Generated at 2022-06-12 07:25:04.955918
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test',
                                                    'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:25:13.525966
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = dict(parse_env_file_contents(lines))
    assert results['TEST'] == '${HOME}/yeee'
    assert results['THISIS'] == '~/a/test'
    assert results['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:25:20.702829
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # parse_env_file_contents should return an empty generator if the file is empty
    assert list(parse_env_file_contents('')) == []
    # parse_env_file_contents should return an empty generator if the file is None
    assert list(parse_env_file_contents(None)) == []
    # parse_env_file_contents should return an empty generator if the file is blank
    assert list(parse_env_file_contents('')) == []
    # parse_env_file_contents should return an empty generator if the file only contains a comment
    assert list(parse_env_file_contents('#Comment')) == []
    # parse_env_file_contents should return an empty generator if the file only contains a comment

# Generated at 2022-06-12 07:25:28.187809
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'),
                                              ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:25:35.956697
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    f = io.TextIOWrapper(io.StringIO("""
        FOO=bar
        BAZ=qux
        SPAM=eggs
        """
        ), 'utf-8')

    # OrderedDict because we need to test the order of the lines
    assert collections.OrderedDict(parse_env_file_contents(f)) == collections.OrderedDict([
        ('FOO', 'bar'),
        ('BAZ', 'qux'),
        ('SPAM', 'eggs')
    ])



# Generated at 2022-06-12 07:25:40.209418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        print(k, v)



# Generated at 2022-06-12 07:25:49.709995
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.expanduser('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

# Generated at 2022-06-12 07:25:58.373258
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['# tes', 'TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = list(parse_env_file_contents(lines=lines))
    assert [t[0] for t in lines] == ['TEST', 'THISIS', 'YOLO']
    assert [t[1] for t in lines] == ['${HOME}/yeee', '~/a/test', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-12 07:26:07.084455
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> from pprint import pprint
    >>> pprint(list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))
    [('TEST', '.../yeee'),
     ('THISIS', '.../a/test'),
     ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    """



# Generated at 2022-06-12 07:26:15.642231
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-12 07:26:24.171319
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    for key, val in parse_env_file_contents(lines):
        if key == "TEST":
            assert val == os.path.expanduser("~/yeee-") + os.environ["PATH"]
        if key == "THISIS":
            assert val == os.path.expanduser("~/a/test")



# Generated at 2022-06-12 07:26:28.829758
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    print(load_env_file(lines, write_environ=dict()))


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:26:36.694678
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # import doctest
    # doctest.testmod(verbose=False)
    # doctest.testmod(verbose=False, optionflags=doctest.ELLIPSIS)
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:26:45.966646
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:26:54.673809
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pathlib
    import tempfile

    f = tempfile.NamedTemporaryFile('w', delete=False)

# Generated at 2022-06-12 07:27:03.539265
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    output = parse_env_file_contents(lines=lines)

    assert list(output) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:27:07.160101
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:27:15.639910
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test against an example file
    with open("example.env") as example_file:
        parsed = parse_env_file_contents(example_file)

    parsed_dict = collections.OrderedDict(parsed)

    expected = collections.OrderedDict([('TEST', '${HOME}/yeee-$PATH'),
                                        ('THISIS', '~/a/test'),
                                        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert parsed_dict == expected


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:27:20.279604
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:27:24.809642
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest
    from textwrap import dedent


# Generated at 2022-06-12 07:27:35.441102
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests that :func:`parse_env_file_contents` works as intended.

    >>> assert list(parse_env_file_contents([
    ...     'TEST=1234', 'TEST2=5678', 'TEST3=foo'])) == [
    ...         ('TEST', '1234'), ('TEST2', '5678'), ('TEST3', 'foo')]
    """
    assert list(parse_env_file_contents([
        'TEST=1234', 'TEST2=5678', 'TEST3=foo'])) == [
                ('TEST', '1234'), ('TEST2', '5678'), ('TEST3', 'foo')]



# Generated at 2022-06-12 07:27:39.066896
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test that the test cases pass
    import doctest
    (failures, _) = doctest.testmod(verbose=False)

    if failures == 0:
        print('PASSED')
    else:
        print('FAILED')


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:27:46.035116
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Unit test for function parse_env_file_contents."""
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert sorted(list(parse_env_file_contents(lines))) == sorted([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:27:48.304754
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:27:56.480318
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    got = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict([
        ('TEST', '.../.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    assert got == expected



# Generated at 2022-06-12 07:27:59.458122
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:28:04.937103
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [
        ( 'TEST', expand(os.path.expanduser('~/yeee')) ),
        ( 'THISIS', expand(os.path.expanduser('~/a/test')) ),
        ( 'YOLO', expand(os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')) ),
    ]
    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-12 07:28:11.481408
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, "test.env"), "w") as env_file:
            env_file.write(lines[0])
            env_file.write("\n")
            env_file.write(lines[1])
            env_file.write("\n")
            env_file.write(lines[2])
            env_file.write("\n")


# Generated at 2022-06-12 07:28:19.876673
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict([
        ('TEST', expand(lines[0].split('=')[1])),
        ('THISIS', expand(lines[1].split('=')[1])),
        ('YOLO', expand(lines[2].split('=')[1])),
    ])

    assert expected == results

# Generated at 2022-06-12 07:28:27.759616
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [('TEST', '{0}/yeee'.format(os.path.expanduser('~'))), ('THISIS', '{0}/a/test'.format(os.path.expanduser('~'))),
         ('YOLO', '{0}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.path.expanduser('~')))]
    )


# Generated at 2022-06-12 07:28:38.341776
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Setup
    lines = [
        "TEST=test",
        "THIS THAT=$TEST",
        "THAT=THIS",
        "MULTI=0 1 2 3 4 5 6 7 8 9 10",  # assumes no whitespace in other parts.
        "FOO= 'in quotes'",
        'BAR="in quotes"',
        'BAZ=\'in quotes\'"',
        'QUX="escaped \\" quote \\" thing"',
        "TILDE=~/home",
    ]
    # Test

    # Ensure all the keys are there.
    values = parse_env_file_contents(lines)
    keys = [x[0] for x in values]
    for line in lines:
        if "=" in line:
            assert line.split("=")[0] in keys

    # Ensure

# Generated at 2022-06-12 07:28:40.354281
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:28:48.916430
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert isinstance(d, dict)
    assert os.path.dirname(d['TEST']) == os.getenv("HOME")
    assert os.path.dirname(d['THISIS']) == os.getenv("HOME")
    assert os.path.dirname(d['YOLO']) == os.getenv("HOME")



# Generated at 2022-06-12 07:28:54.910713
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_file_contents = ["SOME=value", "SOME=value", "SOMEOTHER=value"]

    values = parse_env_file_contents(env_file_contents)

    v_copy = []
    v_copy.extend(values)

    # Check that iterator is consumed after first iteration
    assert len(v_copy) == 2



# Generated at 2022-06-12 07:29:02.088221
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_content = """
        # This is a comment, should be ignored
        EMPTY_VAR =
        SPACE_VAR = abc def
        UNQUOTED_VAR = unquoted
        SINGLEQUOTES_VAR = 'singlequoted'
        DOUBLEQUOTES_VAR = "doublequoted"
        DOUBLEQUOTES_VAR_SPACES = "double quoted"
        DOUBLEQUOTES_VAR_QUOTES = "double \"quoted\""
        DOUBLEQUOTES_VAR_BACKSLASHES = "double backslashed \\"
        DOUBLEQUOTES_VAR_BACKSLASHES_AND_QUOTES = "double backslashed \\" and \"quoted\""
        """
    parsed = parse_env_file_cont

# Generated at 2022-06-12 07:29:08.337341
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = dict(parse_env_file_contents(lines))

    assert changes['TEST'] == '${HOME}/yeee'
    assert changes['THISIS'] == '~/a/test'
    assert changes['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:29:14.877599
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST="$HOME/foo"',
        'TEST2=b',
        'TEST3=\'$PATH\'',
        'TEST4=c',
    ]
    parsed = list(parse_env_file_contents(lines))
    assert parsed == [
        ('TEST', '.../foo'),
        ('TEST2', 'b'),
        ('TEST3', '$PATH'),
        ('TEST4', 'c'),
    ]



# Generated at 2022-06-12 07:29:22.062252
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~^/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file_contents(lines)
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '~^/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-12 07:29:26.632520
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:35.570856
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import json

    lines = ['#comment here', 'TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    l = list(parse_env_file_contents(lines))
    result = json.dumps(l)
    expected = """[["TEST", ".../yeee"], ["THISIS", ".../a/test"], ["YOLO", ".../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]]"""
    assert result == expected



# Generated at 2022-06-12 07:29:42.509195
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    result = {k: v for k, v in parse_env_file_contents(lines)}

    assert result['TEST'] == os.path.expanduser('~/yeee')
    assert result['THISIS'] == os.path.expanduser('~/a/test')
    assert result['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    # fail

# Generated at 2022-06-12 07:29:48.242145
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env = parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])
    assert [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')] == list(env)

    env = parse_env_file_contents(['TEST=test', "THISIS='test'", 'YOLO="test"'])
    assert [('TEST', 'test'), ('THISIS', 'test'), ('YOLO', 'test')] == list(env)

    env = parse

# Generated at 2022-06-12 07:29:56.206034
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # assert list(parse_env_file_contents(lines)) == \
    #     [('TEST', '.../.../yeee-...:...'),
    #      ('THISIS', '.../a/test'),
    #      ('YOLO',
    #       '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:30:08.274747
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_vars = parse_env_file_contents(lines)

    assert env_vars == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:30:14.777288
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [('TEST', '.../.../yeee-'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # This is the values function needed to make the function under test callable without a file
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Call the parse_env_file_contents function
    actual = list(parse_env_file_contents(lines))

    # Values with a file

# Generated at 2022-06-12 07:30:16.806816
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    print(doctest.testmod(optionflags=doctest.ELLIPSIS))



# Generated at 2022-06-12 07:30:23.517107
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "",
        "",
        "",
        "",
        "",
        "NAME=matt",
        "",
        "",
        "",
        "#",
        "#",
        "#",
        "NAME=notmatt",
        "",
        "",
        "#",
        "#",
        "#",
        "#",
        "",
        "",
        "",
    ]
    assert (
        list(parse_env_file_contents(lines))
        == [("NAME", "matt"), ("NAME", "notmatt")]
    )

# Generated at 2022-06-12 07:30:32.809058
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test function parse_env_file_contents.
    env_lines = """
    BASEDIR=$(dirname "$0")
    APPENV=dev
    WTF=$HOME/somtext-$HOME
    LOL=/asdf/sdf/a
    """

    parsed_lines = list(parse_env_file_contents(env_lines.splitlines(keepends=False)))

    assert parsed_lines == [
        ('BASEDIR', '$(dirname "$0")'),
        ('APPENV', 'dev'),
        ('WTF', '$HOME/somtext-$HOME'),
        ('LOL', '/asdf/sdf/a')
    ]



# Generated at 2022-06-12 07:30:39.690694
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for None
    assert parse_env_file_contents() == []

    # Test for empty
    assert list(parse_env_file_contents(lines=[])) == []

    # Test with actual data
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_data1 = list(parse_env_file_contents(lines))
    assert test_data1 == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:30:47.166534
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # list of strings meant to be parsed
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:30:48.085695
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:30:51.712863
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['FOO=bar', 'BAZ="hi there"', 'FOO="nope"']
    values = parse_env_file_contents(lines)
    assert dict(values) == {'FOO': 'nope', 'BAZ': 'hi there'}



# Generated at 2022-06-12 07:31:00.847547
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    write_environ = {}
    _ = load_env_file(lines, write_environ)

    assert write_environ['TEST'] == '{}/yeee-{}:{}'.format(os.environ['HOME'], os.environ['HOME'], os.environ['PATH'])
    assert write_environ['THISIS'] == '{}/a/test'.format(os.environ['HOME'])

# Generated at 2022-06-12 07:31:18.276771
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    output = list(parse_env_file_contents(input))
    assert output[0][0] == 'TEST'
    assert output[0][1] == '${HOME}/yeee'
    assert output[1][0] == 'THISIS'
    assert output[1][1] == '~/a/test'
    assert output[2][0] == 'YOLO'
    assert output[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-12 07:31:27.165972
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        import unittest.mock
    except ImportError:
        import mock

    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    with unittest.mock.patch("os.path.expanduser") as expanduser:
        with unittest.mock.patch("os.path.expandvars") as expandvars:
            expanduser.return_value = "awesome"
            expandvars.return_value = "swag"

            values = parse_env_file_contents(lines)
            for k, v in values:
                assert k == "TEST"

# Generated at 2022-06-12 07:31:32.580793
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    parse_env_file_contents(lines)


# Generated at 2022-06-12 07:31:40.405587
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # > os.environ['TESTING'] = 'test'
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    od = collections.OrderedDict(parse_env_file_contents(lines=lines))

    assert od['TEST'] == expand('${HOME}/yeee')
    assert od['THISIS'] == expand('~/a/test')

    # > os.environ['TESTING'] = 'test'
    lines = ['TESTIS=$TESTING_THIS', 'TESTING=This is a test']
    od = collections.OrderedDict(parse_env_file_contents(lines=lines))
   

# Generated at 2022-06-12 07:31:46.104182
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)
    assert data == [('TEST', '${HOME}/yeee'),
                    ('THISIS', '~/a/test'),
                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    return data



# Generated at 2022-06-12 07:31:54.338008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test parse_env_file_contents function.
    """
    contents = ['TEST=${HOME}/yeee-$PATH',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(contents)) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-12 07:32:03.113744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee']) == [('TEST', '.../yeee')]
    assert parse_env_file_contents(['THISIS=~/a/test']) == [('THISIS', '.../a/test')]
    assert parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:32:13.941939
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    load_env_file(lines, write_environ=environ)

    assert environ['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert environ['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')
    assert environ['YOLO'] == os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:32:20.263251
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test that its actual behavior of parse_env_file_contents is the same as
    its expected behavior defined above. If these two do not match, this
    function will raise an AssertionError.
    """

    # Capture the results of the function
    result = parse_env_file_contents()

    # Capture the results of the expected behavior
    expected_result = None

    # Ensure that the results of the function match the expected results.
    assert result == expected_result, "parse_env_file_contents() does not match its expected behavior."



# Generated at 2022-06-12 07:32:23.833662
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)



# Generated at 2022-06-12 07:32:50.343282
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = parse_env_file_contents(lines)
    changes_dict = dict(changes)

    assert len(changes_dict) == 3

    assert re.search(r'\A' + os.path.expanduser('~') + r'/yeee-', changes_dict['TEST'])
    assert re.search(r'\A' + os.path.expanduser('~') + r'/a/test\Z', changes_dict['THISIS'])

# Generated at 2022-06-12 07:32:57.261946
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    values = list(parse_env_file_contents(lines))
    assert values == [
        ('TEST', expand('${HOME}/yeee-$PATH')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]

