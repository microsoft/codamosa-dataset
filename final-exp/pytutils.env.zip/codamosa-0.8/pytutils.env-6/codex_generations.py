

# Generated at 2022-06-12 07:23:10.214935
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict(
        [
            ('TEST', expand('${HOME}/yeee')),
            ('THISIS', expand('~/a/test')),
            ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
        ]
    )



# Generated at 2022-06-12 07:23:20.120745
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class EnvFileTest(unittest.TestCase):
        @property
        def lines(self) -> typing.Iterator[str]:
            yield 'TEST=${HOME}/yeee'
            yield 'THISIS=~/a/test'
            yield 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

        def test_parse_env_file_contents(self):
            loaded = list(parse_env_file_contents(self.lines))

# Generated at 2022-06-12 07:23:28.346672
# Unit test for function load_env_file
def test_load_env_file():
    """
    Test if the function load_env_file works as expected
    """
    import pytest

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # If write_environ is not specified, the env variables must be empty

# Generated at 2022-06-12 07:23:38.283968
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    changes = parse_env_file_contents(lines)
    assert changes == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:23:45.829607
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for actual, expected in zip(parse_env_file_contents(lines), expected):
        assert actual == expected



# Generated at 2022-06-12 07:23:55.010531
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())
    d = {k: v[1:] if v.startswith("~") else v for k, v in d.items()}

    _ = os.path.abspath(__file__)
    _ = os.path.dirname(_)
    _ = os.path.join(_, "yeee")
    _ = os.path.join(_, "a")
    _ = os.path.join(_, "test")
    _ = os.path.join(_, "swaggins")

# Generated at 2022-06-12 07:23:58.402278
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests function load_env_file.
    """
    import test.generic

    test.generic.test_runner(test_load_env_file)

# Generated at 2022-06-12 07:24:08.084742
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import stat

    import shutil
    import tempfile

    file_contents = [
        'HOME=/home/testuser',
        'PATH=/home/testuser/bin:$PATH',
        'UNDEFINED=',
        "UNDEFINED2='$UNDEFINED'",
        'UNDEFINED3="$UNDEFINED"',
        'UNDEFINED4="hi"',
        'UNDEFINED5="hi $UNDEFINED"',
        'UNDEFINED6="hi \$UNDEFINED"',
        'UNDEFINED7="hi \$UNDEFINED\\\\"',
    ]

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "test.env")


# Generated at 2022-06-12 07:24:18.961844
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines)

# Generated at 2022-06-12 07:24:20.237406
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


# Main function for calling from the command line

# Generated at 2022-06-12 07:24:32.453485
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST1=foo",
        "TEST2=bar",
        "",
        "# bar=foo",
        "TEST3=foo #bar=foo",
        "TEST4='foo'",
        "TEST5=\"bar\"",
        "TEST6=foo bar",
        "TEST7=${TEST6}",
        "TEST8='\"'",
        "TEST9=\"\\\"\"",
        "TEST10='a\\a'",
    ]

    results = parse_env_file_contents(lines)


# Generated at 2022-06-12 07:24:38.652442
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    expected = [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert list(result) == expected


# Generated at 2022-06-12 07:24:45.033234
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> test_parse_env_file_contents()
    True
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vals = list(parse_env_file_contents(lines))

    assert len(vals) == 3

    return True


# Generated at 2022-06-12 07:24:51.126616
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [('TEST', expand('${HOME}/yeee')),
         ('THISIS', expand('~/a/test')),
         ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]
    )



# Generated at 2022-06-12 07:24:57.164711
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:25:04.075177
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', expand('${HOME}') + '/yeee'),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]

# Generated at 2022-06-12 07:25:08.217672
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:25:09.937644
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:25:18.965573
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # This should not throw
    parse_env_file_contents([])

    lines = ['TEST=${HOME}/yeah', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = collections.OrderedDict()

    for k, v in parse_env_file_contents(lines):
        changes[k] = v

    assert changes['TEST'] == os.path.expandvars('${HOME}/yeah')
    assert changes['THISIS'] == os.path.expanduser('~/a/test')
    assert changes['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:25:21.305291
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    failure_count, test_count = doctest.testmod(verbose=True)
    assert failure_count == 0, "Doctests failed"



# Generated at 2022-06-12 07:25:32.010228
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = list(parse_env_file_contents(lines))
    expected_results = [('TEST', os.path.expandvars(os.path.expanduser('${HOME}/yeee'))),
                        ('THISIS', os.path.expandvars(os.path.expanduser('~/a/test'))),
                        ('YOLO', os.path.expandvars(os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))]
    assert results == expected_

# Generated at 2022-06-12 07:25:40.731272
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:25:49.131211
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert (('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')) == tuple(parse_env_file_contents(lines))



# Generated at 2022-06-12 07:25:49.588934
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass

# Generated at 2022-06-12 07:25:50.799304
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(verbose=True)



# Generated at 2022-06-12 07:25:52.569006
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-12 07:25:58.739203
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    assert result == {'TEST': f'{os.path.expanduser("~")}/yeee', 'THISIS': f'{os.path.expanduser("~")}/a/test',
                      'YOLO': f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:26:04.767253
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:26:15.737254
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = collections.OrderedDict()

    for k, v in parse_env_file_contents(lines):
        d[k] = v


# Generated at 2022-06-12 07:26:23.147156
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:26:27.655743
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    # Shouldn't crash or throw any exception

# Generated at 2022-06-12 07:26:36.053910
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents()) == []
    assert list(parse_env_file_contents(lines=[])) == []

    assert list(parse_env_file_contents(lines=['TEST=1'])) == [('TEST', '1')]
    assert list(parse_env_file_contents(lines=['TEST="1"'])) == [('TEST', '1')]
    assert list(parse_env_file_contents(lines=['TEST="1 test"'])) == [('TEST', '1 test')]
    assert list(parse_env_file_contents(lines=['TEST=\'1 test\''])) == [('TEST', '1 test')]

# Generated at 2022-06-12 07:26:44.869372
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [(x, expand(y)) for x, y in [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]]
    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-12 07:26:52.928822
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test that the parsing of env files works as intended. If this test fails, ensure the parsing of
    the env file is correct.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines_parsed = [var for var in parse_env_file_contents(lines)]

    for line, parsed in zip(lines, lines_parsed):
        assert line.split("=")[0] == parsed[0]
        assert expand(line.split("=")[1]) == parsed[1]



# Generated at 2022-06-12 07:27:03.020349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Test function parse_env_file_contents."""
    # Test parse_env_file_contents
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    res = collections.OrderedDict(parse_env_file_contents(lines))


# Generated at 2022-06-12 07:27:07.160323
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    for key, value in parse_env_file_contents(lines):
        assert key
        assert value

# Generated at 2022-06-12 07:27:17.266478
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path
    from tempfile import NamedTemporaryFile

    def get_test_data():
        return [
            ('TEST=${HOME}/yeee', 'TEST', '.../yeee'),
            ('THISIS=~/a/test', 'THISIS', '.../a/test'),
            ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ]

    def test_parse_env_file_contents_success(data):
        lines = (f'{key}={val}' for key, val in data)

# Generated at 2022-06-12 07:27:27.087399
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from glob import glob
    from os.path import dirname, join
    import re

    import pytest

    datafiles = sorted(glob(join(dirname(__file__), 'data', '*')))


# Generated at 2022-06-12 07:27:32.708587
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        print(f"{k} -> {v}")

# Generated at 2022-06-12 07:27:39.789696
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = (
        'HOME=${HOME}\n',
        'FOO=${FOO:bar}\n',
        'FOO=foo\n',
        'FOO=\n',
        'FOO=""" \'quoted\' """\n',
        'FOO=""" \'\'\'quoted\'\'\' """\n',
    )

    values = collections.OrderedDict(parse_env_file_contents(lines))
    assert len(values) == 2
    assert values['HOME'] == '${HOME}'
    assert values['FOO'] == '""" \'quoted\' """'



# Generated at 2022-06-12 07:27:45.836707
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert isinstance(parse_env_file_contents(lines), typing.Generator)



# Generated at 2022-06-12 07:27:54.381838
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at 0x...>
    """
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines)



# Generated at 2022-06-12 07:28:03.241370
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import re
    import copy
    import unittest

    env_dict = {
        'ENV_VAR': '...',
        'ENV_VAR2': 'a/b/c',
        'ENV_VAR3': '~/a/b/c',
        'ENV_VAR4': '~/a/path with space'
    }
    lines = [
        'ENV_VAR=${ENV_VAR}',
        'ENV_VAR2=~/$ENV_VAR2',
        'ENV_VAR3=~/$ENV_VAR3',
        'ENV_VAR4=~/$ENV_VAR4'
    ]


# Generated at 2022-06-12 07:28:08.651431
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = [
        "TEST='a'",
        'THISIS="b',
        "YOLO='c",
        '$HOME',
    ]

    parsed_contents = list(parse_env_file_contents(contents))

    assert parsed_contents == [
        ('TEST', 'a'),
        ('THISIS', 'b'),
        ('YOLO', 'c'),
        ('HOME', '')
    ]

# Generated at 2022-06-12 07:28:16.432209
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    changes = load_env_file(lines, write_environ=dict())

    assert len(changes) == 2

    assert os.path.join(os.environ['HOME'], 'yeee') == list(changes.values())[0]
    assert os.path.join(os.environ['HOME'], 'a/test') == list(changes.values())[1]



# Generated at 2022-06-12 07:28:22.762035
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Set up env file
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Parse the env file
    parsed_env_file = dict(parse_env_file_contents(lines))

    assert parsed_env_file == {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-12 07:28:28.709952
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_

# Generated at 2022-06-12 07:28:36.969874
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert list(values) == [('TEST', '/yeee'),
                            ('THISIS', '~/a/test'),
                            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:28:39.390602
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    line = "TEST=${HOME}/yeee"
    values = parse_env_file_contents([line])
    assert next(values) == ("TEST", "...")



# Generated at 2022-06-12 07:28:49.347021
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ])) == [
        ("TEST", "${HOME}/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]


# Generated at 2022-06-12 07:29:01.321773
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents('a=1'.splitlines()) == [('a', '1')]
    assert parse_env_file_contents('A=som\nB=val\n'.splitlines()) == [('A', 'som'), ('B', 'val')]
    assert parse_env_file_contents(' A = som\nB=val\n'.splitlines()) == [('B', 'val')]
    assert parse_env_file_contents('str="this is a string"\n'.splitlines()) == [('str', 'this is a string')]
    assert parse_env_file_contents('str="this is a string"\n'.splitlines()) == [('str', 'this is a string')]

# Generated at 2022-06-12 07:29:09.301384
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:29:18.074322
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

    assert list(parse_env_file_contents(lines)) == [
        ("TEST", expand("${HOME}/yeee-$PATH")),
        ("THISIS", expand("~/a/test")),
        ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))
    ]



# Generated at 2022-06-12 07:29:25.792019
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }



# Generated at 2022-06-12 07:29:33.277921
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = io.StringIO("""TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""")

    out = parse_env_file_contents(lines)
    assert list(out) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:29:41.143629
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', f'{os.environ["HOME"]}/yeee'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-12 07:29:47.194954
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    lines = io.StringIO(u'TEST=$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins\nTHIS_IS_OVERRIDDEN=not_this')

    test_data = [
        ('TEST', '$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins'),
        ('THIS_IS_OVERRIDDEN', 'not_this')
    ]

    # Test that the input is what we expect
    output = list(parse_env_file_contents(lines))
    assert output == test_data, output

# Generated at 2022-06-12 07:29:56.683489
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from os import environ, pathsep
    from io import StringIO
    from unittest import TestCase
    from hashlib import md5

    try:
        home = environ["HOME"]
    except KeyError:
        home = "/tmp"
    try:
        path = environ["PATH"]
    except KeyError:
        path = "/tmp"

    def md5sum(filename):
        with open(filename, mode="rb") as f:
            d = md5()
            while True:
                buf = f.read(4096)
                if not buf:
                    break
                d.update(buf)
        return d.hexdigest()


# Generated at 2022-06-12 07:30:05.674787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = collections.OrderedDict()

    for k, v in parse_env_file_contents(lines):
        changes[k] = v

    assert changes == collections.OrderedDict([('TEST', '~/yeee'),
                                                ('THISIS', '~/a/test'),
                                                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:30:08.450965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:30:25.383012
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '$HOME/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:30:34.865881
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/${PATH}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict(
        [(
            'TEST',
            '.../yeee'
        ), (
            'THISIS',
            '.../a/test'
        ), (
            'YOLO',
            '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
        )])



# Generated at 2022-06-12 07:30:39.007125
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = """TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"""

    env = load_env_file(content.splitlines())

    assert env["TEST"]
    assert env["TEST"].endswith("/yeee-")
    assert env["THISIS"]
    assert env["THISIS"].endswith("/a/test")

# Generated at 2022-06-12 07:30:47.913269
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # parse_env_file_contents should return "key", "value" tuples for each line in the file.
    lines = [
        'DATABASE_URL=sqlite:///app.db\n',
        '# this line is a comment\n',
        'MAIL_SERVER=smtp.gmail.com\n',
        'MAIL_PORT=587\n',
        'MAIL_USE_TLS=1\n',
        'MAIL_USERNAME=you@gmail.com\n',
        'MAIL_PASSWORD=awesomepassword\n',
        'MAILTO=you@gmail.com\n',
        'SENDER=you@gmail.com\n',
    ]

    parsed_lines = parse_env_file_contents(lines)
    parsed_lines = list

# Generated at 2022-06-12 07:30:56.487997
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = list(parse_env_file_contents(lines))
    assert isinstance(result, list)
    assert isinstance(result[0], tuple)
    assert result[0][0] == 'TEST'
    assert result[0][1] == '${HOME}/yeee'
    assert result[1][0] == 'THISIS'
    assert result[1][1] == '~/a/test'
    assert result[2][0] == 'YOLO'

# Generated at 2022-06-12 07:31:02.415522
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    file_contents = io.StringIO('\n'.join(lines))

    assert list(parse_env_file_contents(file_contents)) == list(parse_env_file_contents(lines))



# Generated at 2022-06-12 07:31:03.942800
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert isinstance(parse_env_file_contents(), collections.abc.Generator)



# Generated at 2022-06-12 07:31:07.053485
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    d = list(parse_env_file_contents(['TEST=${HOME}/test', 'BEGINNING_SPACE = example']))
    assert d == [('TEST', '.../test'), ('BEGINNING_SPACE', 'example')]



# Generated at 2022-06-12 07:31:14.873445
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    compare = {
        'TEST': '${HOME}/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    result = dict(parse_env_file_contents(lines))

    for k, v in compare.items():
        assert compare[k] == result[k]

# Generated at 2022-06-12 07:31:24.432365
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:31:51.010124
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import cStringIO

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    f = cStringIO.StringIO("\n".join(lines))
    values = parse_env_file_contents(f)

    s = [x[1] for x in values]
    assert s == [
        '${HOME}/yeee',
        '~/a/test',
        '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    for k, v in values:
        assert '$' not in expand(v)



# Generated at 2022-06-12 07:31:59.407718
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = parse_env_file_contents(lines)
    expected = [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for key, value in parsed:
        assert (key, value) in expected

# Generated at 2022-06-12 07:32:06.413782
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # xfail
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines)
    assert ret == collections.OrderedDict([('TEST', os.path.join(os.environ['HOME'], 'yeee')),
                                           ('THISIS', os.path.join(os.environ['HOME'], 'a', 'test')),
                                           ('YOLO', os.path.join(os.environ['HOME'], 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

# Generated at 2022-06-12 07:32:08.127397
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:32:14.053999
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'EMPTY=', 'BLANK=']
    parsed = parse_env_file_contents(lines)
    print(parsed)



# Generated at 2022-06-12 07:32:14.876586
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass



# Generated at 2022-06-12 07:32:18.718497
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:32:26.366433
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    env = load_env_file(lines, write_environ=None)

    assert env == {
        'TEST': os.path.expanduser('${HOME}/yeee'),
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-12 07:32:32.666283
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', os.environ['HOME'] + '/yeee'),
        ('THISIS', os.environ['HOME'] + '/a/test'),
        ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-12 07:32:40.813340
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]