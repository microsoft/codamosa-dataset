

# Generated at 2022-06-12 07:23:04.824661
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}



# Generated at 2022-06-12 07:23:13.488546
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test for function parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert list(env) == expected


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:23:20.384304
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> list(parse_env_file_contents(lines))
    [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """



# Generated at 2022-06-12 07:23:28.458566
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_file = io.StringIO('\n'.join(lines))

    expected_result = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert list(parse_env_file_contents(env_file)) == expected_result
    assert list(parse_env_file_contents(lines)) == expected_result



# Generated at 2022-06-12 07:23:39.936268
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    m = load_env_file(lines, write_environ=dict())

    assert expand(m['TEST']).startswith('/home/')
    assert expand(m['TEST']) == expand(m['TEST'])
    assert expand(m['TEST']).endswith('/yeee-')

    assert expand(m['THISIS']).startswith('/home/')
    assert expand(m['THISIS']).endswith('/a/test')

    assert expand(m['YOLO']).startswith('/home/')

# Generated at 2022-06-12 07:23:47.699364
# Unit test for function load_env_file
def test_load_env_file():
    import io

    assert load_env_file(io.StringIO("TEST=${HOME}/yeee-$PATH")) == collections.OrderedDict(
        [
            ("TEST", expand("${HOME}/yeee-$PATH")),
        ])

    assert load_env_file(io.StringIO("TEST='${HOME}/yeee-$PATH'")) == collections.OrderedDict(
        [
            ("TEST", expand("${HOME}/yeee-$PATH")),
        ])

    assert load_env_file(io.StringIO('TEST="${HOME}/yeee-$PATH"')) == collections.OrderedDict(
        [
            ("TEST", expand("${HOME}/yeee-$PATH")),
        ])


# Generated at 2022-06-12 07:23:51.109112
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)

    assert True

# Generated at 2022-06-12 07:23:58.748894
# Unit test for function load_env_file

# Generated at 2022-06-12 07:24:03.598500
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(list(parse_env_file_contents(lines)))



# Generated at 2022-06-12 07:24:09.413010
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """
    pass



# Generated at 2022-06-12 07:24:20.556418
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from dataclasses import dataclass
    from typing import Tuple
    from itertools import tee

    @dataclass
    class TestCase:
        lines: Tuple[str, ...]
        expected: Tuple[Tuple[str, str], ...]


# Generated at 2022-06-12 07:24:28.783288
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [('TEST', '.../yeee'),
         ('THISIS', '.../a/test'),
         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:24:34.264590
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=[
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ])) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-12 07:24:43.192651
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    with io.StringIO("\n".join(lines)) as f:
        assert list(parse_env_file_contents(f)) == [
            ("TEST", "${HOME}/yeee-$PATH"),
            ("THISIS", "~/a/test"),
            ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
        ]



# Generated at 2022-06-12 07:24:48.504229
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_vars = parse_env_file_contents(lines)
    lst = list(env_vars)
    assert len(lst) == 3
    assert lst[1] == ('THISIS', '~/a/test')



# Generated at 2022-06-12 07:24:56.297257
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    orders = [(x, y) for x, y in parse_env_file_contents(lines)]
    assert orders == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-12 07:25:03.096133
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(result) == expected


# Generated at 2022-06-12 07:25:10.293193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

# Generated at 2022-06-12 07:25:16.348875
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = list()

    lines.append('TEST=${HOME}/yeee')
    lines.append('THISIS=~/a/test')
    lines.append('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    values = parse_env_file_contents(lines)

    for key, value in values:
        print('{0} = {1}'.format(key, value))



# Generated at 2022-06-12 07:25:21.250349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:25:29.273322
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:25:32.910738
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:25:40.997295
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    values = dict(parse_env_file_contents(lines))
    h = expand('~')

    assert values['TEST'] == (h + '/yeee')
    assert values['THISIS'] == (h + '/a/test')
    assert values['YOLO'] == (h + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:25:49.992463
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:25:59.604499
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Create a sequence of string that resembles an env file
    content = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Start the actual unit test
    for key, val in parse_env_file_contents(content):
        if key == 'TEST':
            assert val == os.path.expanduser('~/yeee-%s' % os.environ['PATH']), 'Expanding $PATH failed'
        elif key == 'THISIS':
            assert val == os.path.expanduser('~/a/test')

# Generated at 2022-06-12 07:26:07.453503
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-12 07:26:16.625499
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Testing a normal parse
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())

    assert 'TEST' in env
    assert 'THISIS' in env
    assert 'YOLO' in env

    # The following tests should be run on a case-sensitive operating system, such as Linux
    if 'PATH' in os.environ:
        assert 'path' not in env
        assert 'PATH' in env

    if 'Home' in os.environ:
        assert 'home' not in env
        assert 'Home' in env

# Generated at 2022-06-12 07:26:22.187228
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("test_parse_env_file_contents")
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(dict(parse_env_file_contents(lines)))



# Generated at 2022-06-12 07:26:29.485525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Checks that if we can parse the contents of an env file, successfully.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:26:36.202008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = load_env_file(lines, write_environ=dict())
    assert output == collections.OrderedDict([('TEST', '.../yeee'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO',
                                               '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:26:49.318987
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        "THISISf='~/a/test'",
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        '# hello there',
        '',
        '   '
    ]

    env_vars = parse_env_file_contents(lines)

    assert next(env_vars) == ('TEST', os.path.expanduser(os.path.expandvars("${HOME}/yeee-$PATH")))
    assert next(env_vars) == ("THISISf", '~/a/test')

# Generated at 2022-06-12 07:26:51.105542
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    _test_parse_env_file_contents_example()
    _test_parse_env_file_contents()



# Generated at 2022-06-12 07:26:56.085455
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys
    import io

    # Redirect stdout and run test
    orig_stdout, sys.stdout = sys.stdout, io.StringIO()
    test_parse_env_file_contents_()
    assert sys.stdout.getvalue() == '.../yeee\n.../a/test\n.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n'

    # Restore stdout
    sys.stdout = orig_stdout



# Generated at 2022-06-12 07:27:05.407236
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    inp = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = list(parse_env_file_contents(inp))
    assert len(out) == 3
    print(out)
    assert out[0][0] == 'TEST'
    assert out[0][1].endswith('/yeee')
    assert out[1][0] == 'THISIS'
    assert out[1][1].endswith('/a/test')
    assert out[2][0] == 'YOLO'

# Generated at 2022-06-12 07:27:11.918554
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))
    [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """



# Generated at 2022-06-12 07:27:22.609926
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    data = [
        ('SIMPLE=value', 'SIMPLE', 'value'),
        ('QUOTE="value"', 'QUOTE', 'value'),
        ('DQUOTE="value"', 'DQUOTE', 'value'),
        ('ESCAPE="value\\t"', 'ESCAPE', 'value\t'),
        ('NOQUOTE=value', 'NOQUOTE', 'value'),
        ('SPACED =   value   ', 'SPACED', 'value'),
        ('SINGLEQUOTE=\'value\'' , 'SINGLEQUOTE', 'value'),
    ]

    for line, key, val in data:
        assert next(parse_env_file_contents([line])) == (key, val)



# Generated at 2022-06-12 07:27:29.293627
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test a normal env file
    lines = ['TEST=test', 'HOME=/home', 'TEST2="test2"']
    result = parse_env_file_contents(lines)

    assert next(result) == ('TEST', 'test')
    assert next(result) == ('HOME', '/home')
    assert next(result) == ('TEST2', 'test2')

    # test file with nested quotes
    lines = ['TEST="test"', 'HOME=/home', 'TEST2="test2"']
    result = parse_env_file_contents(lines)
    assert next(result) == ('TEST', 'test')

    # test file with single quotes
    lines = ['TEST="test"', 'HOME=/home', "TEST2='test2'"]
    result = parse_env_file_cont

# Generated at 2022-06-12 07:27:34.745468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:27:41.332062
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert '$' not in result['YOLO']
    assert 'HOME' in result['TEST']
    result = load_env_file(lines, write_environ=dict())
    assert 'NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' not in result['YOLO']

# Generated at 2022-06-12 07:27:42.474857
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:27:47.896334
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO
    from doctest import testmod

    # Run doctests
    testmod(name='envyaml.envyaml',
            globs={'load_env_file': load_env_file,
                   'lines': StringIO(''),
                   'write_environ': None})



# Generated at 2022-06-12 07:27:57.922637
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = list(parse_env_file_contents(lines))
    assert data[0][0] == 'TEST'
    assert data[0][1] == '${HOME}/yeee'
    assert data[1][0] == 'THISIS'
    assert data[1][1] == '~/a/test'
    assert data[2][0] == 'YOLO'
    assert data[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:28:03.815548
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = list(parse_env_file_contents(test_lines))
    assert res == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:28:07.690135
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:28:12.662204
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:28:21.701488
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def test_case(env_file_contents, expected_dict):
        parsed_dict = collections.OrderedDict(parse_env_file_contents(lines=env_file_contents))
        assert parsed_dict == expected_dict

    # Single line
    test_case([
        'TEST=${HOME}/yeee',
    ], {
        'TEST': expand(os.path.join('${HOME}', 'yeee')),
    })

    # Single line with a comment
    test_case([
        'TEST=${HOME}/yeee # test',
    ], {
        'TEST': expand(os.path.join('${HOME}', 'yeee')),
    })

    # Two lines

# Generated at 2022-06-12 07:28:26.886625
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    lines = ['TEST=${HOME}/yeee', 'THISIS="~/a/test"', 'YOLO=~/swaggins']
    load_env_file(lines, write_environ=dict())

    assert True

# Generated at 2022-06-12 07:28:35.331197
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:28:42.230946
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with a few examples, testing both single and double quotes (as well as no quotes)
    test_values = [
        'FOO=first',
        'BAR=1',
        'BAZ=2',
        'QUX=3',
        'QUUX=hello world',
        'CORGE=\'hello world\'',
        'GRAULT="hello world"',
        'GARPLY=\'hello\tworld\'',
        'WALDO="hello\tworld"',
    ]

    result = parse_env_file_contents(test_values)


# Generated at 2022-06-12 07:28:52.394880
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test that comments are ignored
    env_vars = list(parse_env_file_contents(['ENV_VAR=42', '# Comment']))
    assert len(env_vars) == 1

    # Test that parsing works for a single line
    env_vars = list(parse_env_file_contents(['ENV_VAR=42']))
    assert len(env_vars) == 1
    assert env_vars[0] == ('ENV_VAR', '42')

    # Test that parsing works without trimming comments
    env_vars = list(parse_env_file_contents(['ENV_VAR=42# Comment']))
    assert len(env_vars) == 1
    assert env_vars[0] == ('ENV_VAR', '42# Comment')

# Generated at 2022-06-12 07:29:01.921882
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = collections.OrderedDict(parse_env_file_contents(lines))

    assert len(results.keys()) == 3

    assert results['TEST'] == '${HOME}/yeee'
    assert results['THISIS'] == '~/a/test'
    assert results['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:29:09.566401
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests function parse_env_file_contents.
    """

    # Test passing in files
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = load_env_file(lines, write_environ=dict())


# Generated at 2022-06-12 07:29:18.276567
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict([
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert expected == actual



# Generated at 2022-06-12 07:29:27.772194
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from unittest import TestCase

    class Test(TestCase):
        def test_something(self):
            lines = [
                "TEST=${HOME}/yeee-$PATH",
                "THISIS=~/a/test",
                "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
            ]

            result = load_env_file(lines, write_environ=dict())

            expected = collections.OrderedDict(
                [
                    ("TEST", "..."),
                    ("THISIS", "..."),
                    ("YOLO", "..."),
                ]
            )

            self.assertEqual(result, expected)

    test = Test("test_something")
    test.test_something()

# Generated at 2022-06-12 07:29:37.847131
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests whether the parse_env_file_contents function is robust, and can parse
    a file that contains regular quoted and unquoted variables, as well as
    variables which are not substituted. Environ is left untouched, so we don't
    need to worry about cleanup.

    """
    tmp_file = '/tmp/test.env'
    with open(tmp_file, 'w') as f:
        f.write('''
            TEST=${HOME}/yeee-$PATH
            THISIS=~/a/test
            YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        ''')
    parse_env_file_contents(open(tmp_file))



# Generated at 2022-06-12 07:29:39.647320
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:29:46.729982
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    r"""
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-12 07:29:53.054303
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:29:58.638655
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at 0x...>
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        print(k, v)



# Generated at 2022-06-12 07:30:09.026561
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import collections

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    file_obj = io.StringIO(''.join(lines))
    values = parse_env_file_contents(file_obj)
    returned = collections.OrderedDict(values)


# Generated at 2022-06-12 07:30:24.850289
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """\
TEST=${HOME}/yeee-$PATH
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
THISIS=~/a/test
""".splitlines()

    env: collections.OrderedDict = load_env_file(lines)

    assert list(env.keys()) == ['TEST', 'YOLO', 'THISIS']
    assert env['TEST'] == os.environ['HOME'] + '/yeee-' + os.environ['PATH']



# Generated at 2022-06-12 07:30:33.948670
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=singin/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    contents = parse_env_file_contents(lines)

    env_dict = collections.OrderedDict(contents)

    assert env_dict['TEST'] == '${HOME}/yeee'
    assert env_dict['THISIS'] == '~/a/test'
    assert env_dict['YOLO'] == 'singin/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-12 07:30:37.172596
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:30:45.786391
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Clean environment so unit test is reliable
    os.environ.clear()

    os.environ.setdefault('HOME', '.')
    os.environ.setdefault('PATH', '.')
    os.environ.setdefault('PWD', '.')

    lines = [
        'TEST=${HOME}/yeee-${PATH}',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    results = load_env_file(lines)

    assert results == {}

# Generated at 2022-06-12 07:30:50.960867
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import sys
    sys.stdout.write(
        'Found %s expected matches in parsing example.env:\n' % (
            len(list(parse_env_file_contents(io.open('example.env', 'r'))))
        )
    )

if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:30:59.930610
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v

    assert changes == collections.OrderedDict([('TEST', '.../yeee'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:31:07.246120
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    results = list(parse_env_file_contents(lines))

    assert results == [
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]



# Generated at 2022-06-12 07:31:13.871810
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    expected = {'TEST': build_path('yeee'), 'THISIS': build_path('a', 'test'), 'YOLO': build_path('swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}
    assert result == expected

# Generated at 2022-06-12 07:31:17.758162
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert len(list(values)) == 3



# Generated at 2022-06-12 07:31:26.870326
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = parse_env_file_contents(lines)
    for key, val in lines:
        if key == 'TEST':
            assert val == os.environ['HOME'] + '/yeee'
        elif key == 'THISIS':
            assert val == os.environ['HOME'] + '/a/test'
        elif key == 'YOLO':
            assert val == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-12 07:31:49.490692
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected_output = [('TEST', '.../yeee'),
                       ('THISIS', '.../a/test'),
                       ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    input_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(input_lines)) == expected_output



# Generated at 2022-06-12 07:31:53.386943
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert len(list(result)) == 3



# Generated at 2022-06-12 07:32:02.708499
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests for parse_env_file_contents function.
    """
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    values = parse_env_file_contents(lines)

    expected_output = (
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )

    assert tuple(values) == expected_output

# Generated at 2022-06-12 07:32:13.523313
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test some basic values
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'PATH=yee'])) == [('TEST', '~/yeee'), ('PATH', 'yee')]

    # Test removal of double quotes
    assert list(parse_env_file_contents(['TEST="hello"'])) == [('TEST', 'hello')]

    # Test removal of single quotes
    assert list(parse_env_file_contents(['TEST=\'hello\''])) == [('TEST', 'hello')]

    # Test expanding of path variables

# Generated at 2022-06-12 07:32:22.026454
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    tmp_file = tempfile.NamedTemporaryFile('w', delete=False)

# Generated at 2022-06-12 07:32:28.450214
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-12 07:32:34.293911
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_file_contents = """
    TEST=$HOME/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    values = parse_env_file_contents(env_file_contents.split('\n'))
    # print(values)
    assert values.__next__() == ('TEST', os.environ.get('HOME') + '/yeee')
    assert values.__next__() == ('THISIS', os.environ.get('HOME') + '/a/test')

# Generated at 2022-06-12 07:32:46.237306
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test empty input
    lines = ''

    # Should return None
    assert next(parse_env_file_contents(lines)) is None

    # Test multiple lines
    lines = '''
# This is a comment
VAR=value
ANOTHER=value
'''

    # Should return a generator
    result = parse_env_file_contents(lines)

    # Should return a tuple of arguments
    assert next(result) == ('VAR', 'value')
    assert next(result) == ('ANOTHER', 'value')

    # Should return None when there's no more arguments
    assert next(result) is None

    # Test single line
    lines = 'VAR=value'

    # Should return a generator
    result = parse_env_file_contents(lines)

    # Should return a tuple of arguments

# Generated at 2022-06-12 07:32:53.666363
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:32:55.341814
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # TODO: Load the env file from test data directory.
    pass