

# Generated at 2022-06-12 07:23:05.928401
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(test_lines)
    expected_result = [
        ('TEST', os.path.expanduser(os.environ['HOME']) + '/yeee'),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser(
            '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
        ]


# Generated at 2022-06-12 07:23:17.333912
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines, write_environ=dict())
    assert ret['TEST'] == expand('${HOME}/yeee')
    assert ret['THISIS'] == expand('~/a/test')
    assert ret['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    # Test 2

# Generated at 2022-06-12 07:23:18.737957
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:23:26.641422
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ret = collections.OrderedDict(parse_env_file_contents(lines))

    assert ret == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:23:35.877692
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', os.environ['HOME'] + '/yeee'), ('THISIS', os.environ['HOME'] + '/a/test'), ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:23:41.842312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = dict(parse_env_file_contents(lines))
    assert ret['TEST'] == expand(lines[0].split('=')[1])
    assert ret['THISIS'] == expand(lines[1].split('=')[1])
    assert ret['YOLO'] == expand(lines[2].split('=')[1])



# Generated at 2022-06-12 07:23:48.347872
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest
    # unittest is used because the doctest results can vary based on the operating system.
    test_values = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_values = [['TEST', '${HOME}/yeee-$PATH'], ['THISIS', '~/a/test'], ['YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']]


# Generated at 2022-06-12 07:23:57.088615
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "SOME_VAR=test",
        "SOME_PATH=$SOME_VAR/test",
        "SOME_PATH2=$SOME_PATH/test2",
        "QUOTED_PATH='$SOME_PATH/test3'",
        "SOME_SPACE='$SOME_VAR/test that has spaces'",
        'SOME_QUOTES="$SOME_VAR/test that has spaces"',
        'SOME_BACKSLASH=\\$SOME_VAR/test',
        "SHEBANG=#!/bin/sh",
    ]

    values = parse_env_file_contents(lines)
    values = dict(values)

    print("values =", values)


# Generated at 2022-06-12 07:24:07.267423
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    load_env_file(lines, write_environ=environ)

# Generated at 2022-06-12 07:24:16.292446
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    output = parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    expected = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(output) == expected

# Generated at 2022-06-12 07:24:19.148488
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:24:23.636283
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO
    from pprint import pprint

    with open("tests/sample.env") as f:
        sample = f.read()
    lines = StringIO(sample)

    for k, v in parse_env_file_contents(lines):
        pprint((k, v))
    return



# Generated at 2022-06-12 07:24:33.518100
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:24:37.115390
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:24:46.950388
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=a/b'])) == [('TEST', 'a/b')]
    assert list(parse_env_file_contents(['TEST=a/b', 'TEST2=a/b'])) == [('TEST', 'a/b'), ('TEST2', 'a/b')]
    assert list(parse_env_file_contents(['TEST=\\n'])) == [('TEST', '\n')]
    assert list(parse_env_file_contents(['TEST="a/b"'])) == [('TEST', 'a/b')]
    assert list(parse_env_file_contents(['TEST="a/b', 'more"'])) == [('TEST', 'a/b more')]
   

# Generated at 2022-06-12 07:24:52.619090
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Example
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert os.environ["TEST"] == "~/yeee-~/foo:~/bar:~/baz"
    assert os.environ["THISIS"] == "~/a/test"
    assert os.environ["YOLO"] == "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-12 07:24:58.311492
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == {'TEST': '.../yeee',
                                                          'THISIS': '.../a/test',
                                                          'YOLO':
                                                          '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:25:05.982174
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Sanity unit test for function parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), (
        'YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:25:10.711938
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:25:15.171214
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # This test assumes that HOME is set.
    input_data = {
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }
    expected_data = {
        'TEST': os.path.join(os.environ['HOME'], 'yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }
    actual = parse_env_file_contents(input_data)
    rows = list(actual)
    assert rows == list(expected_data.items())

# Generated at 2022-06-12 07:25:27.421139
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .__test_utils__ import unittest_stringio
    from .__test_utils__ import unittest_file_contents


# Generated at 2022-06-12 07:25:34.922457
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # lines = ['TEST=${HOME}/yeee-$PATH']

    res = parse_env_file_contents(lines)

    import pprint
    pprint.pprint(list(res))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:25:41.775465
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env_file = parse_env_file_contents(lines)

    # parse_env_file_contents returns a generator.
    # Envs are returned in same order as in file.
    assert next(env_file) == ("TEST", os.path.expanduser("~/yeee"))

    # Current directory
    assert os.path.expanduser("~") == os.getcwd()

    # Misc.
    assert "~" == "~"
    # This returns False due to that the env file is evaluated in load_env_file instead of parse_env_

# Generated at 2022-06-12 07:25:47.547409
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-12 07:25:52.523948
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('\n{test} {function}\n'.format(test=__file__, function=parse_env_file_contents.__name__))

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)

    for k, v in data:
        print('{k}={v}'.format(k=k, v=v))



# Generated at 2022-06-12 07:25:56.961728
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    print(load_env_file(lines, write_environ=dict()))

# Generated at 2022-06-12 07:26:01.672144
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:26:08.711383
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee')),
                                                    ('THISIS', expand('~/a/test')),
                                                    ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:26:17.205965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    test_dict = {}
    changes = load_env_file(lines, write_environ=test_dict)

    assert len(changes) == 3
    assert changes["TEST"] == os.path.expanduser("~/yeee-") + os.environ["PATH"]
    assert changes["THISIS"] == os.path.expanduser("~/a/test")

# Generated at 2022-06-12 07:26:25.656857
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    t1 = """
# This is a comment
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST

    """
    expect = dict(parse_env_file_contents(t1.split("\n")))
    assert len(expect.keys()) == 3
    assert "TEST" in expect.keys()
    assert "THISIS" in expect.keys()
    assert "YOLO" in expect.keys()
    assert "PATH" not in expect.keys()



# Generated at 2022-06-12 07:26:34.161075
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> for k, v in parse_env_file_contents(lines): print(k, v)
    TEST .../yeee
    THISIS .../a/test
    YOLO .../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    pass



# Generated at 2022-06-12 07:26:45.013662
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from nose.tools import assert_equal
    from nose.tools import assert_true

    tests = [("TEST=${HOME}/yeee-$PATH", "TEST", "${HOME}/yeee-$PATH"),
             ("THISIS=~/a/test", "THISIS", "~/a/test"),
             ("YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", "YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]

    for line, expected_key, expected_val in tests:
        key, val = next(parse_env_file_contents([line]))

        assert_equal(expected_key, key)
        assert_equal(expected_val, val)

# Generated at 2022-06-12 07:26:52.431514
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    # OrderedDict([('TEST', '.../yeee'),
    #          ('THISIS', '.../a/test'),
    #          ('YOLO',
    #           '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:26:57.830521
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        test[k] = v

    ref = collections.OrderedDict(
        [('TEST', '.../yeee'),
         ('THISIS', '.../a/test'),
         ('YOLO',
          '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert ref == test

# Generated at 2022-06-12 07:27:05.735583
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result_1 = parse_env_file_contents(lines)
    result_2 = [('TEST', '${HOME}/yeee-${PATH}'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Compare the two objects
    assert [i for i in result_1] == result_2



# Generated at 2022-06-12 07:27:15.851298
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Valid lines
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '${HOME}/yeee'),
                                                                           ('THISIS', '~/a/test'),
                                                                           ('YOLO',
                                                                            '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # Single line comment

# Generated at 2022-06-12 07:27:23.980684
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    doc_lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    env = load_env_file(doc_lines, write_environ=dict())

    for i, (k, v) in enumerate(parse_env_file_contents(doc_lines)):
        assert k == list(env.keys())[i]
        assert v == env[k]

# Generated at 2022-06-12 07:27:25.141162
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:27:29.119607
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)

# Generated at 2022-06-12 07:27:38.401355
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    try:
        from nose.tools import assert_equal

        assert_equal(list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])), [
            ('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    except ImportError:
        print('Error: Nose not found')

# Generated at 2022-06-12 07:27:49.580020
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """
    d = load_env_file(lines.splitlines())
    assert(str(d)) == """OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])"""



# Generated at 2022-06-12 07:27:56.358000
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:28:04.308827
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:28:11.201961
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    test_cases = [
        ('A=A', 'A', 'A'),
        ('B=BV', 'B', 'BV'),
        ('C=CVAL', 'C', 'CVAL'),
        ('D', None, None),
        ('E=', 'E', ''),
    ]

    for case in test_cases:
        if case[1] is not None:
            k, v = next(parse_env_file_contents([case[0]]))
            assert k == case[1]
            assert v == case[2]
        else:
            with pytest.raises(StopIteration) as excinfo:
                next(parse_env_file_contents([case[0]]))

            # Check that the exception raised is a StopIteration
            assert excinfo.type is StopIter

# Generated at 2022-06-12 07:28:21.173619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test parse_env_file_contents.
    From honcho.
    """
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    expected = collections.OrderedDict([
        ("TEST", os.path.expandvars("${HOME}/yeee")),
        ("THISIS", os.path.expanduser("~/a/test")),
        ("YOLO", os.path.expanduser("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ])


# Generated at 2022-06-12 07:28:25.723285
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
    ]

    assert dict(parse_env_file_contents(lines)) == {
        'TEST': os.path.expanduser('${HOME}/yeee'),
        'THISIS': os.path.expanduser('~/a/test'),
    }

# Generated at 2022-06-12 07:28:37.087765
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def test_parse(lines, results):
        parsed = list(parse_env_file_contents(lines))

        assert parsed == results, "Parsed lines do not match"


# Generated at 2022-06-12 07:28:37.753020
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:28:43.775348
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ('TEST=$HOME/yeee', 'THIS=IS_A_TEST', 'YOLO=$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    actual = list(parse_env_file_contents(lines))

    assert [('TEST', '.../yeee'), ('THIS', 'IS_A_TEST'), ('YOLO', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')] == actual

    lines = ('TEST=$HOME/yeee', 'THIS=IS_A_TEST', 'YOLO=$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'SPACE=~/some space')
    actual = list(parse_env_file_contents(lines))


# Generated at 2022-06-12 07:28:51.131420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

# Generated at 2022-06-12 07:29:08.608267
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import sys


# Generated at 2022-06-12 07:29:16.690409
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-12 07:29:21.679809
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # also expand user, expand env
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        assert k in ['TEST', 'THISIS', 'YOLO']
        assert re.match(r'\A\~|\$', v) is None

# Generated at 2022-06-12 07:29:31.687135
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        d[k] = v

    assert d == collections.OrderedDict(
        [
            ('TEST', os.environ['HOME'] + '/yeee'),
            ('THISIS', os.environ['HOME'] + '/a/test'),
            ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        ]
    )



# Generated at 2022-06-12 07:29:40.891441
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_contents = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        "#",
    ]

    for item in list(parse_env_file_contents(file_contents)):
        assert item[0] in ["TEST", "THISIS", "YOLO"]
        if item[0] == "TEST":
            assert item[1] == f"{os.environ['HOME']}/yeee"
        if item[0] == "THISIS":
            assert item[1] == f"{os.environ['HOME']}/a/test"

# Generated at 2022-06-12 07:29:47.848500
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Plus a couple of unit tests
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_dict = collections.OrderedDict(parse_env_file_contents(lines))
    assert test_dict['TEST'] == os.path.join(expand('${HOME}'), 'yeee')
    assert test_dict['THISIS'] == os.path.join(expand('~'), 'a', 'test')
    assert test_dict['YOLO'] == os.path.join(expand('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:29:57.002045
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines_list = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_lines_generator = parse_env_file_contents(test_lines_list)
    assert next(test_lines_generator) == ('TEST', '${HOME}/yeee')
    assert next(test_lines_generator) == ('THISIS', '~/a/test')
    assert next(test_lines_generator) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:30:06.293914
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    o = parse_env_file_contents(lines)

    for i, (k, v) in enumerate(o):
        assert k, v == expected[i]



# Generated at 2022-06-12 07:30:13.966785
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test parse_env_file_contents.
    """
    import sys
    import tempfile

    def tp(content: str) -> typing.List[str]:
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'a.env')
            with open(p, 'a') as f:
                f.write(content)
            return list(open(p, 'r'))

    lines = [
        'HOMEDIR="$HOME"',
        'HOMEDIR2="$HOMEDIR"',
        'TEST_ENV_VAR=testing\n',
    ]
    result = parse_env_file_contents(lines)

# Generated at 2022-06-12 07:30:23.353597
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        v = expand(v)

        changes[k] = v

    assert changes == collections.OrderedDict([
        ('TEST', f'{HOME}/yeee-{PATH}'),
        ('THISIS', f'{HOME}/a/test'),
        ('YOLO', f'{HOME}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])


# Unit

# Generated at 2022-06-12 07:30:48.273791
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == \
           collections.OrderedDict([('TEST', '.../yeee'),
                                    ('THISIS', '.../a/test'),
                                    ('YOLO',
                                     '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:30:53.746342
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):

        def test_parse_env_file_contents(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            load_env_file(lines, write_environ=dict())

    unittest.main()

# Generated at 2022-06-12 07:30:57.484539
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)



# Generated at 2022-06-12 07:31:04.772908
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict((('TEST', '~/yeee-~/:~/'), ('THISIS', '~/a/test'), ('YOLO', 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))

    assert dict(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-12 07:31:09.325433
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Returns a generator
    assert parse_env_file_contents(lines)

    # Returns an OrderedDict
    assert load_env_file(lines)



# Generated at 2022-06-12 07:31:15.371008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    results = parse_env_file_contents(lines)

    print()
    for r in results:
        print('{} = {}'.format(*r))


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:31:24.935600
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    if typing.TYPE_CHECKING:
        with open(r'..\data\test.env') as f:
            lines = f.readlines()
    else:
        with open(r'../data/test.env') as f:
            lines = f.readlines()

    pairs = parse_env_file_contents(lines)

    assert pairs == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ('TEST2', 'th=is not a key=value pair'),
    ]

    # test with empty lines

# Generated at 2022-06-12 07:31:36.582180
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import re
    import os

    from dsk.base.path_helper import PathHelper

    from dsk.base.cmds.bash.bash_to_python_converter import B2PC


# Generated at 2022-06-12 07:31:44.731468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest

    class ParseEnvFileContentsTests(unittest.TestCase):
        def test_parse_env_file_contents_parses_valid_lines(self):
            lines = io.StringIO("foo=bar\nspam=eggs")
            values = parse_env_file_contents(lines)
            self.assertEqual(dict(values), {"foo": "bar", "spam": "eggs"})

        def test_parse_env_file_contents_discards_empty_lines(self):
            lines = io.StringIO("\n\nfoo=bar\n\nspam=eggs\n\n")
            values = parse_env_file_contents(lines)

# Generated at 2022-06-12 07:31:48.749454
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = list(parse_env_file_contents(lines))
    assert len(d) == len(lines)



# Generated at 2022-06-12 07:32:27.296942
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    for k, v in parse_env_file_contents(lines):
        pass



# Generated at 2022-06-12 07:32:33.333826
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:32:42.453390
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = list(parse_env_file_contents(lines))
    assert parsed == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:32:51.704049
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:32:57.173891
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == dict(TEST='${HOME}/yeee', THISIS='~/a/test', YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

