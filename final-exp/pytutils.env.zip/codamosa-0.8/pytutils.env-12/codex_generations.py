

# Generated at 2022-06-12 07:23:04.934144
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    actual = load_env_file(lines)

    assert actual == expected



# Generated at 2022-06-12 07:23:16.330889
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Put the test cases into a dict
    dict = {
        # "input": expected output
        'THISIS=test': ('THISIS', 'test'),
        'YOLO=test2': ('YOLO', 'test2'),
        'THISIS=test test2': ('THISIS', 'test test2'),
        'THISIS="test test2"': ('THISIS', 'test test2'),
        "THISIS='test test2'": ('THISIS', 'test test2'),
        'THISIS=test\\ test2': ('THISIS', 'test test2'),
        'THISIS="test\\ test2\\"': ('THISIS', 'test test2"'),
        "THISIS='test\\ test2\\'": ('THISIS', "test test2'")
    }

    # Loop over the test cases and compare the result of the function

# Generated at 2022-06-12 07:23:21.964675
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        '# A comment',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    result = load_env_file(lines, write_environ=dict())

    assert result == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-12 07:23:27.688163
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:23:37.558056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    items = parse_env_file_contents(['TEST=${HOME}/yeee-${PATH}', 'PEPE=hola', 'PERRO=${HOME}/perros/${NO_EXISTE}'])
    i = next(items)
    assert i[0] == 'TEST'
    assert re.search(r'.../.../yeee-...:...', i[1]) is not None
    assert next(items)[1] == 'hola'
    assert next(items)[1] == '.../perros/${NO_EXISTE}'
    assert next(items, None) is None



# Generated at 2022-06-12 07:23:46.787386
# Unit test for function load_env_file
def test_load_env_file():
    # pylint: disable=missing-docstring,expression-not-assigned,unused-variable,singleton-comparison,unnecessary-lambda
    from contextlib import redirect_stdout
    import io
    import tempfile

    # Check that the output matches the expected output.
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-12 07:23:54.540669
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)
    res = ""
    for line in contents:
        res += str(line)
    assert res == "('TEST', '.../yeee')('THISIS', '.../a/test')('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')"



# Generated at 2022-06-12 07:24:03.913093
# Unit test for function load_env_file
def test_load_env_file():
    print("load_env_file")
    lines = ["TEST=$HOME/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    environ = load_env_file(lines)
    assert environ == collections.OrderedDict([("TEST", expand("$HOME/yeee-$PATH")), ("THISIS", expand("~/a/test")), ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))])



# Generated at 2022-06-12 07:24:07.408065
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:24:18.803596
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'TEST_NESTED_VAR=${HOME}/yeee-${HOME}']
    parsed_vals = parse_env_file_contents(lines)

    assert parsed_vals.__next__() == ('TEST', os.path.expanduser('~/yeee'))
    assert parsed_vals.__next__() == ('THISIS', os.path.expanduser('~/a/test'))

# Generated at 2022-06-12 07:24:28.873954
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(contents)
    assert list(values) == [
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]



# Generated at 2022-06-12 07:24:35.520626
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:24:45.886903
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test function parse_env_file_contents

    >>> lines = ['TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:24:51.583772
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_dict = load_env_file(lines, write_environ=dict())

    assert test_dict['TEST'] == expand('$HOME/yeee')
    assert test_dict['THISIS'] == expand('~/a/test')
    assert test_dict['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:24:58.821040
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import pathlib

    with tempfile.TemporaryDirectory() as dirpath:
        filepath = pathlib.Path(dirpath) / 'test.env'

        filepath.touch()
        with filepath.open('w') as handle:
            handle.writelines((
                    'TEST=${HOME}/yeee',
                    'THISIS=~/a/test',
                    'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
            ))


# Generated at 2022-06-12 07:25:05.489779
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import collections
    import io

    import pytest

    data = """
    SOME_VAR=${HOME}
    OTHER_VAR=~/some/path
    STRING_VAR="Hello World"
    """.strip()

    expected = collections.OrderedDict([('SOME_VAR', '...'),
                                        ('OTHER_VAR', '...'),
                                        ('STRING_VAR', 'Hello World')])

    lines = io.StringIO(data)
    assert expected == collections.OrderedDict(parse_env_file_contents(lines))



# Generated at 2022-06-12 07:25:16.111984
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert isinstance(parse_env_file_contents(lines), typing.Generator)

    values = tuple(parse_env_file_contents(lines))
    assert len(values) == 3
    assert isinstance(values, tuple)
    assert values[0] == ('TEST', '.../yeee')
    assert values[1] == ('THISIS', '.../a/test')
    assert values[2] == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-12 07:25:21.358564
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import difflib
    import io

    lines = """
    A=maybe
    B="some \"strings\""
    C='maybe not'
    D=$C
    """

    parsed_values = {}

    for k, v in parse_env_file_contents(lines.split('\n')):
        parsed_values[k] = v

    assert parsed_values == {'A': 'maybe', 'B': 'some "strings"', 'C': 'maybe not', 'D': 'maybe not'}



# Generated at 2022-06-12 07:25:29.508815
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-12 07:25:39.320984
# Unit test for function load_env_file
def test_load_env_file():
    # import sys
    #  print(sys.__stdout__)

    out = io.StringIO()

    env = load_env_file("""
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """ )

    assert env["TEST"] == expand("${HOME}/yeee-$PATH")
    assert env["THISIS"] == expand("~/a/test")
    assert env["YOLO"] == expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-12 07:25:49.529509
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ret = load_env_file(lines, write_environ=None)

    assert ret == collections.OrderedDict([('TEST', '.../yeee'),
                                           ('THISIS', '.../a/test'),
                                           ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:25:59.003432
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import logging
    import sys

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

    contents = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    logger = logging.getLogger(__name__)

    logger.debug('Contents loaded:\n%s', '\n'.join(contents))

    logger.debug('Results:')

    for k, v in parse_env_file_contents(contents):
        logger.debug('-- %s -> %s', k, v)

    logger.debug('OK.')



# Generated at 2022-06-12 07:26:07.881329
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    env = load_env_file(lines, write_environ=dict())
    assert env == {
        'TEST': '{HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-12 07:26:15.239344
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from . import test_env_file_contents

    pairs = list(parse_env_file_contents(test_env_file_contents.contents))

    assert pairs[0] == ('TEST', '.../.../yeee-...:...')
    assert pairs[1] == ('THISIS', '.../a/test')
    assert pairs[2] == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:26:22.463874
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=$HOME', 'THISIS=~/a/test', 'YOLO=@/swaggins/?NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == \
        [('TEST', '.../...'), ('THISIS', '.../a/test'), ('YOLO', '@/swaggins/?NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:26:28.437939
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) \
        == [('TEST', expand(expand('${HOME}/yeee-$PATH'))), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:26:36.203267
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    data = """
# This is a comment
export TEST=${HOME}/yeee-$PATH

# Another comment
THISIS=~/a/test

YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    result = parse_env_file_contents(data.split('\n'))

    expected = [('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    for i, tup in enumerate(result):
        assert tup == expected[i]

# Generated at 2022-06-12 07:26:45.791672
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def test_load_env_file():
        env_file = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        environ = load_env_file(env_file, write_environ=dict())

        assert environ['TEST'] == '~/yeee'
        assert environ['THISIS'] == '~/a/test'
        assert environ['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    test_load_env_file()

# Generated at 2022-06-12 07:26:53.114432
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ={}) == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                                            ('THISIS', '.../a/test'),
                                                            ('YOLO',
                                                             '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:27:01.294410
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test method for parse_env_file_content
    """
    print()
    print("test_parse_env_file_contents")
    print()

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)
    print(contents)

    changes = load_env_file(lines, write_environ=dict())
    print(changes)



# Generated at 2022-06-12 07:27:08.105572
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert dict([t for t in values]) == {
        'TEST': os.sep.join([os.environ['HOME'], 'yeee']),
        'THISIS': os.sep.join([os.environ['HOME'], 'a', 'test']),
        'YOLO': os.sep.join([os.environ['HOME'], 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    }



# Generated at 2022-06-12 07:27:13.953464
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    for k, v in values:
        k == 'TEST' or k == 'THISIS' or k == 'YOLO'

    assert(k == 'YOLO')

# Generated at 2022-06-12 07:27:25.030390
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert str(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == "[('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]"

# Generated at 2022-06-12 07:27:30.277313
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    data = list(parse_env_file_contents(lines))

    assert len(data) == 3, data

# Generated at 2022-06-12 07:27:39.818556
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_data = [
        ('THISIS=~/a/test', 'THISIS', '~/a/test'),
        ('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ('TEST=${HOME}/yeee', 'TEST', '${HOME}/yeee'),
    ]
    for test_input, expected_key, expected_value in test_data:
        actual_result = parse_env_file_contents([test_input])
        actual_key, actual_value = list(actual_result)[0]
        assert expected_key == actual_key
        assert expected_value == actual_value

# Generated at 2022-06-12 07:27:49.050008
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input_ = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    output = {}

    for k, v in parse_env_file_contents(input_):
        output[k] = v

    expected_output = {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

    if output != expected_output:
        raise AssertionError('Failed to parse environment file')



# Generated at 2022-06-12 07:27:54.471571
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    for k, v in parse_env_file_contents(lines):
        assert len(k) > 0
        assert len(v) > 0



# Generated at 2022-06-12 07:27:55.718097
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-12 07:28:00.328310
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:28:09.687841
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    expected_changes = collections.OrderedDict([
        ('TEST', f'{os.path.expanduser("~")}/yeee'),
        ('THISIS', f'{os.path.expanduser("~")}/a/test'),
        ('YOLO', f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    changes = parse_env_file_contents(lines)


# Generated at 2022-06-12 07:28:19.651932
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> from pprint import pprint as pp
    >>> out = list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))
    >>> print(out)
    [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """

# Generated at 2022-06-12 07:28:22.629836
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:28:28.680018
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:28:38.753993
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    rv = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict([('TEST', os.path.expanduser('~') + '/yeee'),
                                        ('THISIS', os.path.expanduser('~/a/test')),
                                        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    assert rv == expected



# Generated at 2022-06-12 07:28:49.029273
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    lines = parse_env_file_contents(lines)

    result = list()

    for k, v in lines:
        result.append((k, v))

    assert result == [
        ("TEST", "{}/yeee-{}".format(expand("${HOME}"), expand("${PATH}"))),
        ("THISIS", expand("~/a/test")),
        ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ]



# Generated at 2022-06-12 07:28:57.246852
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = '''
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
'''
    values = parse_env_file_contents(lines.split('\n'))
    expected = (
        ('TEST', f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )

# Generated at 2022-06-12 07:29:05.719793
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    envs = parse_env_file_contents(lines)

    results = collections.OrderedDict()
    for k, v in envs:
        results[k] = v

    assert results['TEST'] == os.path.join(os.environ['HOME'], 'yeee')
    assert results['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-12 07:29:09.536228
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ret = parse_env_file_contents(lines)

    assert len(list(ret)) == 3



# Generated at 2022-06-12 07:29:10.995525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:29:14.818456
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:29:18.921333
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env = ['NOTANENV', 'TEST=yeee', 'TEST2=${TEST}-hooo']

    parsed = parse_env_file_contents(env)
    assert len(list(parsed)) == 2



# Generated at 2022-06-12 07:29:29.014655
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:29:37.005366
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = list(parse_env_file_contents(lines))

    assert values == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:29:43.165586
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    results = list(parse_env_file_contents(lines))
    assert len(results) == 3
    assert every(lambda x: x[0] in ['TEST', 'THISIS', 'YOLO'], results)
    assert any(lambda x: x[0] == 'TEST' and x[1].endswith('/yeee'), results)
    assert any(lambda x: x[0] == 'THISIS' and x[1].endswith('a/test'), results)

# Generated at 2022-06-12 07:29:53.988385
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    output = load_env_file(lines)

    assert output['TEST'] == os.environ['HOME'] + '/yeee'
    assert output['THISIS'] == os.environ['HOME'] + '/a/test'
    assert output['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:30:05.262528
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['FOO=foo', 'BAR="bar"', 'BAZ=\'baz\''])) == [('FOO', 'foo'), ('BAR', 'bar'), ('BAZ', 'baz')]
    assert list(parse_env_file_contents(['FOO=foo', 'BAR="bar"', 'BAZ=\'baz\''])) == [('FOO', 'foo'), ('BAR', 'bar'), ('BAZ', 'baz')]
    assert list(parse_env_file_contents(['FOO=foo', 'BAR="b\nr"', 'BAZ="b\\az"'])) == [('FOO', 'foo'), ('BAR', 'b\nr'), ('BAZ', 'b\\az')]

# Generated at 2022-06-12 07:30:13.278952
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'MULTILINE=value\\nvalue2']

    d = collections.OrderedDict(parse_env_file_contents(lines))

    assert 'TEST' in d
    assert d['TEST'] == '.../.../yeee-...:...'

    assert 'THISIS' in d
    assert d['THISIS'] == '.../a/test'

    assert 'YOLO' in d
    assert d['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-12 07:30:21.809501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    odict = collections.OrderedDict()
    for key, value in parse_env_file_contents(lines):
        odict[key] = value

    assert odict == {
        'TEST': os.environ['HOME'] + '/yeee',
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }



# Generated at 2022-06-12 07:30:32.229631
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:30:36.798282
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = parse_env_file_contents(lines)
    for key, val in ret:
        assert os.path.isabs(val), val



# Generated at 2022-06-12 07:30:44.849908
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())  # No exception thrown



# Generated at 2022-06-12 07:30:53.209006
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_result = OrderedDict([('TEST', '${HOME}/yeee-$PATH'),
                                   ('THISIS', '~/a/test'),
                                   ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    results = OrderedDict(parse_env_file_contents(lines))

    assert results == expected_result



# Generated at 2022-06-12 07:31:02.666525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:31:09.209940
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> dict(parse_env_file_contents(lines))
    {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    """
    pass



# Generated at 2022-06-12 07:31:15.838408
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)
    assert res == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:31:22.032692
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    A_TEST_FILE = """TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    import unittest

    class TestFile(unittest.TestCase):
        def test_check_file_parser(self):
            res = {k: v for k, v in parse_env_file_contents(A_TEST_FILE.split('\n'))}
            assert 'TEST' in res
            assert res['TEST'] == '${HOME}/yeee'
            assert 'THISIS' in res
            assert res['THISIS'] == '~/a/test'
            assert 'YOLO' in res

# Generated at 2022-06-12 07:31:29.198976
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    import unittest

    class TestEnvFile(unittest.TestCase):
        def test_parse_env_file_contents(self):
            self.assertEqual(list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test',
                                                           'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])),
                                 [('TEST', '.../yeee'), ('THISIS', '.../a/test'),
                                  ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    return TestEnvFile('test_parse_env_file_contents')



# Generated at 2022-06-12 07:31:37.944058
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-12 07:31:45.497056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    results = load_env_file(lines, None)
    expected = collections.OrderedDict(
        [("TEST", os.path.join(os.getenv("HOME"), "yeee")), ("THISIS", os.path.join(os.getenv("HOME"), "a/test")), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]
    )

    assert results == expected



# Generated at 2022-06-12 07:31:52.983028
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.join(os.environ['HOME'], 'yeee')),
        ('THISIS', os.path.join(os.environ['HOME'], 'a/test')),
        ('YOLO', os.path.join(os.environ['HOME'], 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]



# Generated at 2022-06-12 07:32:01.682998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    gen = parse_env_file_contents(lines)

    assert len(lines) == len(list(gen))



# Generated at 2022-06-12 07:32:05.358592
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    s = StringIO("""
    TEST=${HOME}
    TEST2='~/test'
    TEST3="~/test/${PATH}"
    """)

    result = parse_env_file_contents(lines=s.readlines())

    assert result == [('TEST', '...'), ('TEST2', '~/test'), ('TEST3', '~/test/...')]

# Generated at 2022-06-12 07:32:15.623528
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path
    from argparse import Namespace
    from .misc import mktemp

    # Using the test data file instead of the actual data file
    # to maintain the "data" directory clean
    data_file = Path(__file__).parent / "test.env"
    data_str = data_file.read_text()

    # Assert everything works as expected
    kv_pairs = list(parse_env_file_contents([line for line in data_str.splitlines()]))
    assert kv_pairs == [('TEST', '${HOME}/yeee-$PATH'),
                        ('THISIS', '~/a/test'),
                        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-12 07:32:24.406216
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)

    import sys
    home, path = os.path.expanduser('~'), os.getenv('PATH')

    assert next(result) == ('TEST', os.path.join(home, 'yeee'))
    assert next(result) == ('THISIS', os.path.join(home, 'a', 'test'))
    assert next(result) == ('YOLO', os.path.join(home, 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-12 07:32:29.811906
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    path = os.path.abspath(os.path.join(os.path.join(__file__, os.pardir), 'test.env'))

    with open(path, 'r') as f:
        lines = f.read().splitlines()

    expected = {  # key, value
        'TEST': ('/home/user/yeee', '/home/user/yeee'),
        'THISIS': ('~/a/test', '/home/user/a/test'),
        'YOLO': ('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }


# Generated at 2022-06-12 07:32:31.019116
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-12 07:32:41.681784
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = collections.OrderedDict()

    for k, v in parse_env_file_contents(lines):
        v = expand(v)
        changes[k] = v

    assert changes == collections.OrderedDict([('TEST', '.../yeee'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO',
                                                '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:32:51.216755
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    result = load_env_file(lines, write_environ=None)
    assert len(result) == 3
    assert result['TEST'] == '{}/yeee-{}'.format(os.environ['HOME'], os.environ['PATH'])
    assert result['THISIS'] == '{}/a/test'.format(os.environ['HOME'])

# Generated at 2022-06-12 07:32:56.139371
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        print('%s="%s"' % (k, v))

