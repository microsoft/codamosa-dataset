

# Generated at 2022-06-12 07:23:05.564815
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:23:16.975009
# Unit test for function load_env_file
def test_load_env_file():
    # Example env file with comments, etc.
    # https://docs.docker.com/compose/env-file/
    lines = [
        '# This is a comment',
        '#COMMENT=comment',
        'HOME=/root',
        "PATH=${HOME}/.local/bin:${PATH}",
        "SHELL=/bin/bash",
    ]
    load_env_file(lines)

    # No write_environ specified
    lines = [
        'HELLO=world',
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    changes = load_env_file(lines)

# Generated at 2022-06-12 07:23:22.906093
# Unit test for function load_env_file
def test_load_env_file():
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        f.flush()
        load_env_file([f.name], write_environ=dict())



# Generated at 2022-06-12 07:23:33.277586
# Unit test for function load_env_file

# Generated at 2022-06-12 07:23:40.001259
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == \
           [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:23:47.724367
# Unit test for function load_env_file
def test_load_env_file():
    env_file_contents = """# Test comment line
TEST=${HOME}/yeee-$PATH
YOLO=${HOME}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
THISIS=~/a/test
"""

    # test
    env_map = load_env_file(env_file_contents.splitlines())

    assert env_map["TEST"] != "$${HOME}/yeee-$PATH"
    assert env_map["TEST"] != "${HOME}/yeee-$PATH"
    assert env_map["TEST"] != "${HOME}/yeee-$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    assert env_map["TEST"] != "${HOME}/yeee-"

# Generated at 2022-06-12 07:23:50.072084
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-12 07:23:51.022094
# Unit test for function load_env_file
def test_load_env_file():
    pass



# Generated at 2022-06-12 07:23:58.704199
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import pytest
    from xonsh.environ import Env  # type: ignore

    env = Env(VAR="TEST")

    # Test that empty file is handled
    lines = io.StringIO()
    values = load_env_file(lines, env)
    assert len(values) == 0

    # Test that comments are handled
    lines = io.StringIO("# TEST=a\n")
    values = load_env_file(lines, env)
    assert len(values) == 0

    # Test that variables are correctly set
    lines = io.StringIO("TEST=a\n")
    values = load_env_file(lines, env)
    assert len(values) == 1
    assert env["TEST"] == "a"

    # Test that existing variables are overridden
    lines

# Generated at 2022-06-12 07:24:01.584521
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:24:09.842715
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents
    """

    cases = (
        ("TEST=~/yeee",          "TEST", "~/yeee"),
        ("TEST=${HOME}/yeee",    "TEST", "${HOME}/yeee"),
        ("THISIS=~/a/test",      "THISIS", "~/a/test"),
        ("YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", "YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    )

    for case, expected_key, expected_value in cases:

        actual = next(parse_env_file_contents([case]))


# Generated at 2022-06-12 07:24:14.894902
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:24:22.338315
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()

    load_env_file(lines, write_environ=environ)

    assert environ['TEST'] == '%s/yeee-%s:%s' % (os.environ.get('HOME'), os.environ.get('PATH'), os.environ.get('PATH'))
    assert environ['THISIS'] == '%s/a/test' % (os.environ.get('HOME'))

# Generated at 2022-06-12 07:24:32.749290
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)


# Generated at 2022-06-12 07:24:34.766640
# Unit test for function load_env_file
def test_load_env_file():
    pass


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-12 07:24:43.192308
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    values = parse_env_file_contents(lines)

    assert list(values) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-12 07:24:48.749853
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    content = 'TEST=${HOME}/yeee-$PATH\n' 'THISIS=~/a/test\n' 'NONE="$NONE"\n'
    output = parse_env_file_contents(io.StringIO(content))

    assert next(output) == ('TEST', expand('${HOME}/yeee-$PATH'))
    assert next(output) == ('THISIS', expand('~/a/test'))
    assert next(output) == ('NONE', expand('"$NONE"'))



# Generated at 2022-06-12 07:24:52.739610
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-12 07:24:58.174699
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee',
                                                    'THISIS': '~/a/test',
                                                    'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:25:05.139948
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = parse_env_file_contents(lines)
    expected = (
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )
    assert actual == expected

# Generated at 2022-06-12 07:25:16.622302
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Should return SEXP = "true"
    string = 'SEXP=true'
    assert list(parse_env_file_contents([string])) == [('SEXP', 'true')]

    # Should return SEXP = "true" and PATH = "/usr/bin:$PATH"
    string = 'SEXP=true\nPATH=/usr/bin:$PATH'
    assert list(parse_env_file_contents([string])) == [('SEXP', 'true'), ('PATH', '/usr/bin:$PATH')]

    # Should return SEXP = "true" and PATH = "/usr/bin:$PATH"
    string = 'SEXP=true\nPATH=/usr/bin:$PATH\n'

# Generated at 2022-06-12 07:25:21.229858
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import StringIO
    lines = StringIO.StringIO("""
        # testing comments
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """)
    env_dict = load_env_file(lines)
    assert env_dict['TEST'].startswith('/')
    assert env_dict['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:25:31.091231
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print('Testing function parse_env_file_contents ...', file=sys.stderr)
    assert 'PATH=/usr/bin' in list(parse_env_file_contents(['PATH=/usr/bin']))
    assert ('PATH', '/usr/bin') in list(parse_env_file_contents(['PATH=/usr/bin']))
    assert ('PATH', '/usr/bin') in list(parse_env_file_contents(['PATH=/usr/bin\n']))
    assert ('PATH', '/usr/bin') in list(parse_env_file_contents([' PATH=/usr/bin']))
    assert ('PATH', '/usr/bin') in list(parse_env_file_contents(['PATH =/usr/bin']))

# Generated at 2022-06-12 07:25:39.501981
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert type(result) == collections.abc.Generator
    assert list(result) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:25:47.185856
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Parse File 1
    file1_lines = ['# comment',
                   '',
                   'export TEST=${HOME}/yeee',
                   '  # comment',
                   '  THING=hi  ',
                   'UNQUOTED=foo\n']
    result = parse_env_file_contents(file1_lines)

    expected = [('TEST', '.../yeee'),
                ('THING', 'hi'),
                ('UNQUOTED', 'foo\n')]

    _test_env_file_values1(result, expected)

    # Parse File 2
    file2_lines = ['# comment',
                   '',
                   'export TEST=${HOME}/yeee',
                   '  # comment',
                   '  THING=hi  ',
                   'UNQUOTED=foo']

# Generated at 2022-06-12 07:25:53.709998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    args = parse_env_file_contents(lines)

    assert args.__next__() == ('TEST', f'{os.path.expanduser("~")}/yeee-{os.environ["PATH"]}')
    assert args.__next__() == ('THISIS', os.path.expanduser('~/a/test'))
    assert args.__next__() == ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-12 07:26:01.409703
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee-${PATH}",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        "LOL=True",
        "SOMETHING=",
    ]

    r = load_env_file(lines, {})

    assert r == {
        "TEST": "{HOME}/yeee-{PATH}",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        "LOL": "True",
        "SOMETHING": "",
    }



# Generated at 2022-06-12 07:26:11.074775
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    actual = parse_env_file_contents(lines)

    for (expected_key, expected_value), (actual_key, actual_value) in zip(expected, actual):
        assert expected_key == actual_key
        assert expected_value == actual_value



# Generated at 2022-06-12 07:26:15.609362
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    for k, v in parse_env_file_contents(lines):
        assert '$' not in v, v



# Generated at 2022-06-12 07:26:24.541030
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """
TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
""".splitlines()

    for k, v in parse_env_file_contents(lines):
        if k == "TEST":
            assert v.endswith("yeee")
        elif k == "THISIS":
            assert v.endswith("test")
        elif k == "YOLO":
            assert v.endswith("swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

# Generated at 2022-06-12 07:26:35.574420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines_1 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_1 = parse_env_file_contents(lines_1)
    assert parsed_1 == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-12 07:26:46.100071
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest.mock

    with unittest.mock.patch('sys.stdout', new_callable=io.StringIO) as fake_output:
        env_file_lines = ['VAR1=value1', 'VAR2=value2', 'VAR3=value3', ]
        parse_results = parse_env_file_contents(env_file_lines)

        assert parse_results is not None
        assert fake_output.getvalue() == ''

    with unittest.mock.patch('sys.stdout', new_callable=io.StringIO) as fake_output:
        env_file_lines = ['VAR1=value1', 'VAR2=value2', 'VAR3=value3', ]

# Generated at 2022-06-12 07:26:54.738358
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest


# Generated at 2022-06-12 07:27:00.706093
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=None)
    return True



# Generated at 2022-06-12 07:27:04.007877
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:27:07.788362
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:27:16.316027
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [
            ('TEST', '~/yeee'),
            ('THISIS', '~/a/test'),
            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ]
    )


test_parse_env_file_contents()

# Generated at 2022-06-12 07:27:25.357036
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)

    res = list(res)
    assert len(res) == 3
    assert res[1][1].endswith('a/test')
    assert '$' not in res[2][1]
    assert res[2][1].endswith('swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-12 07:27:31.410683
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:27:40.386181
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = list(parse_env_file_contents(lines))
    assert len(results) == 3
    assert results[0][0] == 'TEST'
    assert results[0][1] == '${HOME}/yeee'
    assert results[1][0] == 'THISIS'
    assert results[1][1] == '~/a/test'
    assert results[2][0] == 'YOLO'
    assert results[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


#

# Generated at 2022-06-12 07:27:51.841866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert dict(parse_env_file_contents(lines)) == dict(
        TEST='${HOME}/yeee', THISIS='~/a/test', YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-12 07:28:01.521987
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    source = io.StringIO(
        """
TEST = ${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
""")
    dest = {}

    load_env_file(source, dest)

    assert dest == {
        "TEST": "~/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }

    dest = {}

    load_env_file([
        "TEST = ",
        "THISIS='~/a/test'",
        "YOLO=yolo",
    ], dest)


# Generated at 2022-06-12 07:28:10.193850
# Unit test for function parse_env_file_contents

# Generated at 2022-06-12 07:28:20.935742
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Unit test for function parse_env_file_contents"""

    # A simple line (see documentation for this function)
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee"])) == [("TEST", expand("${HOME}/yeee"))]

    # Additional tests
    test_strings = ["TEST='${HOME}/${PATH}'",
                    'THISIS="~/a/test"',
                    "THISALSO=${HOME}/this/is/a/test",
                    "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

# Generated at 2022-06-12 07:28:26.886287
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n']

    parsed_values = sorted(parse_env_file_contents(lines))

    assert parsed_values == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-12 07:28:37.695749
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    print("values: {!r}".format(values))

    values = collections.OrderedDict(values)

    # Split the full path into a list of components
    splits = [
        os.path.abspath(v).split("/") for v in values.values()
    ]

    # Collect the number of components in the first path
    len_path = len(splits[0])

    # Check that each path has the same number of components
    print("len_path: {!r}".format(len_path))
   

# Generated at 2022-06-12 07:28:43.516176
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert 'TEST' in result
    assert 'THISIS' in result
    assert 'YOLO' in result

    # Check that lines with blank keys are discarded
    lines = ['=value', 'YOLO=value']
    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert len(result) == 1
    assert 'YOLO' in result

    # Check that lines with commented keys are discarded

# Generated at 2022-06-12 07:28:48.684286
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file = 'tests/test_env_file'
    with open(file) as fp:
        vals = parse_env_file_contents(fp)

        for k, v in vals:
            print('%s: %s' % (k, v))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:28:56.373533
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    $ pytest test_parse_env_file_contents.py --cov . --cov-report term-missing
    """
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = load_env_file(lines, write_environ=dict())

    assert d['TEST'] == os.path.normpath(os.environ['HOME'] + '/yeee')
    assert d['THISIS'] == os.path.normpath(os.environ['HOME'] + '/a/test')

# Generated at 2022-06-12 07:28:59.623322
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-12 07:29:04.667229
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test'])) == {'TEST': '.../yeee', 'THISIS': '.../a/test'}



# Generated at 2022-06-12 07:29:09.796402
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:29:14.686697
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input_text = "TEST=${HOME}/yeee-$PATH THISIS=~/a/test YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    lines = input_text.splitlines()
    load_env_file(lines, write_environ=None)



# Generated at 2022-06-12 07:29:21.246495
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert collections.OrderedDict(values) == collections.OrderedDict({
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    })



# Generated at 2022-06-12 07:29:28.877640
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from hypothesis import given, settings, Verbosity
    from hypothesis import strategies as st

    @given(st.lists(st.text()))
    @settings(verbosity=Verbosity.verbose, deadline=None)
    def test_parse_env_file_contents_invariant(value):
        assert list(parse_env_file_contents(value)) == list(parse_env_file_contents(iter(value)))

    for function in (test_parse_env_file_contents_invariant,):
        try:
            function()
        except RecursionError as e:
            print(e)

# Generated at 2022-06-12 07:29:37.209339
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-12 07:29:38.877225
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:29:43.044741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(
        name="parse_env_file_contents",
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE
    )



# Generated at 2022-06-12 07:29:54.084849
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io


# Generated at 2022-06-12 07:30:03.578169
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': os.getenv('HOME') + '/yeee',
        'THISIS': os.path.expanduser('~') + '/a/test',
        'YOLO': os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-12 07:30:14.472894
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = """TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""".split("\n")

    result = load_env_file(contents, write_environ=None)

    assert len(result) == 3
    assert result["TEST"] == os.path.expandvars("${HOME}/yeee")
    assert result["THISIS"] == os.path.expandvars("~/a/test")
    assert result["YOLO"] == os.path.expandvars("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")



# Generated at 2022-06-12 07:30:21.135827
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> list(parse_env_file_contents(lines))
    [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """
    pass



# Generated at 2022-06-12 07:30:28.577488
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    got = parse_env_file_contents(lines)

    assert ('TEST', '${HOME}/yeee-$PATH') in got
    assert ('THISIS', '~/a/test') in got
    assert ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in got



# Generated at 2022-06-12 07:30:37.104562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = load_env_file(lines, write_environ=dict())
    assert actual == {
        'TEST': '{}/yeee'.format(expand('${HOME}')),
        'THISIS': '{}/a/test'.format(expand('$HOME')),
        'YOLO': '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(expand('$HOME')),
    }

# Generated at 2022-06-12 07:30:41.231771
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-12 07:30:47.631203
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines) == collections.OrderedDict([('TEST', '.../yeee'),
                                                             ('THISIS', '.../a/test'),
                                                             ('YOLO',
                                                              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-12 07:30:54.490531
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Arrange
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # Act
    parse = list(parse_env_file_contents(lines))
    # Assert
    assert parse == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:31:01.377414
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    assert list(result) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:31:10.488251
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import textwrap

    # The output of this function is consumed by a generator - so in order to
    # confirm the output, we need to iterate the generator and record its
    # output.
    output = collections.OrderedDict(parse_env_file_contents(textwrap.dedent('''
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    ''').splitlines()))


# Generated at 2022-06-12 07:31:18.713500
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=dict())

    # Make sure they're in the right order
    assert tuple(values.keys()) == ('TEST', 'THISIS', 'YOLO')

    # Make sure nothing is actually altered
    assert tuple(values.values()) == (
        expand('${HOME}/yeee-$PATH'),
        expand('~/a/test'),
        expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    )



# Generated at 2022-06-12 07:31:36.770981
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert actual == expected

# Generated at 2022-06-12 07:31:44.905449
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = ['TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test',
                  'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    c = dict(parse_env_file_contents(test_lines))

    assert c['TEST'] == os.path.expanduser('~') + "/yeee-" + os.environ['PATH']
    assert c['THISIS'] == os.path.expanduser('~') + "/a/test"
    assert c['YOLO'] == os.path.expanduser(
        '~') + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-12 07:31:51.703987
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = parse_env_file_contents(lines)

    tuples = list(parsed)
    assert tuples[0] == ('TEST', '${HOME}/yeee')
    assert tuples[1] == ('THISIS', '~/a/test')
    assert tuples[2] == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-12 07:32:02.057238
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()
    environ = dict()
    for k, v in values:
        v = expand(v)

        changes[k] = v

        environ[k] = v


# Generated at 2022-06-12 07:32:12.965141
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = collections.OrderedDict(parse_env_file_contents(lines))

    assert res == {
        'TEST': '{HOME}/yeee'.format(HOME=os.environ['HOME']),
        'THISIS': '{HOME}/a/test'.format(HOME=os.environ['HOME']),
        'YOLO': '{HOME}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(HOME=os.environ['HOME'])
    }



# Generated at 2022-06-12 07:32:21.871293
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = '''
    HELLO_WORLD='This job is crazy!'
    THIS_IS_A_VARIABLE=${THIS_IS_A_VARIABLE}
    TESTER="asdf"
    LONG="asdf\\
        sdf
        asdf"
    LONG2="asdf\\\\"
    '''

    values = parse_env_file_contents(contents.split('\n'))
    print(values)

# Generated at 2022-06-12 07:32:30.375394
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_file_lines = ["NONEXISTENT_VAR_THAT_DOES_NOT_EXIST=${HOME}/swaggins",
                      "TEST=${HOME}/yeee-$PATH",
                      "THISIS=~/a/test",
                      "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    environ = {'HOME': os.path.expanduser('~'), 'PATH': ':'.join(os.environ['PATH'].split(':'))}


# Generated at 2022-06-12 07:32:41.692760
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = list(parse_env_file_contents(contents))

    assert ret[0][0] == 'TEST'
    assert ret[0][1] == '${HOME}/yeee'

    assert ret[1][0] == 'THISIS'
    assert ret[1][1] == '~/a/test'

    assert ret[2][0] == 'YOLO'
    assert ret[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:32:50.134651
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST="${HOME}/yeee"', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = collections.OrderedDict(parse_env_file_contents(lines))
    assert len(d) == 3
    assert d["TEST"] == "${HOME}/yeee"
    assert d["THISIS"] == "~/a/test"
    assert d["YOLO"] == "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-12 07:32:58.207179
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert isinstance(result, collections.Generator)
    assert list(result) == expected

    # Test escapes
    lines = ['TEST="\nswag"', 'YOLO=\'\nswag\'']
    result = parse_env_file_contents(lines)
