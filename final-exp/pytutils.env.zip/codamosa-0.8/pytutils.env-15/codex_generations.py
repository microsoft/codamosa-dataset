

# Generated at 2022-06-12 07:23:05.012712
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from sys import platform
    from os import environ
    from tempfile import TemporaryDirectory

    from . import shell

    with TemporaryDirectory() as dirname:
        env_file = os.path.join(dirname, 'environment')
        # shell.env is platform specific and therefore only works on one platform per time:
        if platform == 'win32':
            shell.env.set('TEST_KEY1', 'TEST_VALUE1', env_file)
            shell.env.set('TEST_KEY2', 'TEST_VALUE2', env_file)
            shell.env.set('TEST_KEY3', 'TEST_VALUE3', env_file)

            # At kill level 0 ...
            with open(env_file, 'rt') as file:
                lines = [line.strip() for line in file]

# Generated at 2022-06-12 07:23:14.425371
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    file_data = 'TEST=${HOME}/yeee-$PATH\n\
        THISIS=~/a/test\n\
        # this is a comment\n\
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    with open(os.path.join(os.path.dirname(__file__), 'test.env'), 'r') as fp:
        assert parse_env_file_contents(fp) == parse_env_file_contents(file_data.split())
    print('passed')


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-12 07:23:20.483393
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:23:27.407495
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    assert result == collections.OrderedDict((
        ('TEST', '.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ))



# Generated at 2022-06-12 07:23:39.186963
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    target_dict = {'TEST': os.path.expanduser('~/yeee-{}'.format(os.environ['PATH'])),
                   'THISIS': os.path.expanduser('~/a/test'),
                   'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}

    result_dict = load_env_file(lines, write_environ=dict())

    assert result_dict == target_dict



# Generated at 2022-06-12 07:23:47.316345
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest
    from io import StringIO

    class TestCase(unittest.TestCase):
        def test_parse(self):
            expected = {'TEST': '${HOME}/yeee-$PATH', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
            test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            actual = collections.OrderedDict(parse_env_file_contents(test_lines))
            self.assertEqual(actual, expected)

            test_lines_

# Generated at 2022-06-12 07:23:52.247814
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-12 07:23:59.371900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest

    class TestParseEnvFileContents(unittest.TestCase):
        def test_parse_env_file_contents(self):
            parsed = parse_env_file_contents([
                'TEST=${HOME}/yeee',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
            ])

            self.assertEqual(parsed, [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), (
                'YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-12 07:24:02.206481
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import doctest

    os.environ["HOME"] = "."
    os.environ["PATH"] = "."

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:24:04.440560
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)



# Generated at 2022-06-12 07:24:10.901640
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert isinstance(values, collections.Iterable)

    expected_values = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    for expected_key, expected_value in expected_values:
        actual_key, actual_value = next(values)

        assert actual_key == expected_key

# Generated at 2022-06-12 07:24:20.555549
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = ['TEST=' + getcwd() + '/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list

# Generated at 2022-06-12 07:24:30.977311
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    output = dict(parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))
    test_data = dict()
    test_data['TEST'] = '.../.../yeee-...:...'
    test_data['THISIS'] = '.../a/test'
    test_data['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    assert output == test_data
    assert 'YOLO' in output
    assert 'EXAMPLE' not in output



# Generated at 2022-06-12 07:24:38.854355
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from tests.utils import check_parse_env_file_contents_lines
    import textwrap

# Generated at 2022-06-12 07:24:46.615080
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
                         write_environ=dict()) == collections.OrderedDict(
        [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'),
         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-12 07:24:52.276918
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    output = parse_env_file_contents(lines)
    assert next(output) == ("TEST", expand("${HOME}/yeee"))
    assert next(output) == ("THISIS", expand("~/a/test"))
    assert next(output) == ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))



# Generated at 2022-06-12 07:24:55.799158
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:25:02.800654
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = parse_env_file_contents(lines)
    assert list(env) == [('TEST', expand('${HOME}/yeee-$PATH')),
                         ('THISIS', expand('~/a/test')),
                         ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:25:13.525877
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    sys.path.insert(0, './')
    from utils import load_env_file
    import os

    lines = ['TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines)

    assert changes['TEST'] == '{}/yeee-'.format(os.path.expanduser('~')) + os.getenv('PATH')
    assert changes['THISIS'] == os.path.expanduser('~') + '/a/test'

# Generated at 2022-06-12 07:25:19.225364
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict()) == {'TEST': '.../yeee', 'THISIS': '.../a/test',
                                                   'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-12 07:25:21.305272
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:25:31.135549
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    args = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    kvsrc = parse_env_file_contents(args)

    kvmap = collections.OrderedDict()
    for k, v in kvsrc:
        kvmap[k] = v

    assert len(kvmap) == 3
    assert kvmap["TEST"] == os.path.join(os.path.expanduser("~"), "yeee")
    assert kvmap["THISIS"] == os.path.join(os.path.expanduser("~"), "a/test")

# Generated at 2022-06-12 07:25:39.288783
# Unit test for function load_env_file
def test_load_env_file():
    import imp
    import os

    f = None
    try:
        f, filename, desc = imp.find_module('honcho.environ')
        module = imp.load_module('honcho.environ', f, filename, desc)
        assert module.load_env_file == load_env_file
    finally:
        if f is not None:
            f.close()
    try:
        from honcho.environ import load_env_file
        assert load_env_file == load_env_file
    except ImportError:
        print("Function honcho.environ.load_env_file not found.")

    # Test assertions
    assert 0



# Generated at 2022-06-12 07:25:47.004655
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee-$PATH", " THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [
        ("TEST", ".../.../yeee-...:..."),
        ("THISIS", ".../a/test"),
        ("YOLO", ".../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]


# Generated at 2022-06-12 07:25:48.157335
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:25:57.859552
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
             'NEXT=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
                                                    ('NEXT', '/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin')]


#

# Generated at 2022-06-12 07:26:02.079241
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_file_contents = [
        '# Hello world',
        'TEST=1234',
        'BLA=5678',
        'FOO="bla"',
        'BAR="bla \\"bla"',
        "X='y'",
    ]

    assert list(parse_env_file_contents(test_file_contents)) == [
        ('TEST', '1234'),
        ('BLA', '5678'),
        ('FOO', 'bla'),
        ('BAR', 'bla "bla'),
        ('X', 'y'),
    ]



# Generated at 2022-06-12 07:26:11.306937
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    f = tempfile.NamedTemporaryFile(mode='w', delete=False)
    w = f.write
    w('# First line\n')
    w('# This should not appear in final output\n')
    w('\n')
    w('\n')
    w('\n')
    w('# inlined comment\n')
    w('# inlined comment\n')
    w('\n')
    w('简体中文=中文\n')
    w('TEST=${HOME}/yeee\n')
    w('THISIS=~/a/test\n')
    w('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')

# Generated at 2022-06-12 07:26:12.380461
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:26:17.295194
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-12 07:26:26.663848
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-12 07:26:35.109648
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Put loaded variables in os.environ.
    for k, v in parse_env_file_contents(lines):
        os.environ[k] = v

    assert os.environ['TEST'] == '.../yeee'
    assert os.environ['THISIS'] == '.../a/test'
    assert os.environ['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:26:42.823627
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    dat = collections.OrderedDict(values)

    assert dat['TEST'] == '~/yeee'
    assert dat['THISIS'] == '~/a/test'
    assert dat['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:26:52.902631
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        "YOLO='~/swaggins/'",
        'YOLO2="$PATH:$HOME"',
        'THIS_THAT=${HOME}',
        'FOO="BAR"',
        'SOME_URL="https://foo?x=y&z=$FOO"',
    ]

    test_result = load_env_file(lines)

    assert test_result.get('TEST') == '~/yeee'
    assert test_result.get('THISIS') == '~/a/test'
    assert test_result.get('YOLO') == '~/swaggins/'

# Generated at 2022-06-12 07:26:58.076251
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = collections.OrderedDict(parse_env_file_contents(lines))
    assert d['TEST'] == os.environ['HOME'] + '/yeee'
    assert d['THISIS'] == os.environ['HOME'] + '/a/test'
    assert d['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-12 07:27:04.767707
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == iter([
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-12 07:27:13.328628
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    for i, res in enumerate(results):
        expected_key, expected_value = expected[i]
        assert res[0] == expected_key
        assert res[1] == expected_value



# Generated at 2022-06-12 07:27:24.723294
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()  # type: typing.MutableMapping

    changes = load_env_file(lines, write_environ=write_environ)

    assert changes == {
        'TEST': os.getenv('HOME') + '/yeee-' + os.getenv('PATH'),
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

    assert write_

# Generated at 2022-06-12 07:27:33.084113
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'),
                                                    ('THISIS', '.../a/test'),
                                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-12 07:27:41.233465
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    with tempfile.TemporaryFile(mode='w+') as fp:
        fp.write('''TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST''')
        fp.seek(0)

        results = list(parse_env_file_contents(lines=[line.strip() for line in fp.readlines()]))
        assert len(results) == 3
        assert results[0][0] == 'TEST'
        assert results[0][1] == expand('${HOME}/yeee')
        assert results[1][0] == 'THISIS'
        assert results[1][1] == expand('~/a/test')
       