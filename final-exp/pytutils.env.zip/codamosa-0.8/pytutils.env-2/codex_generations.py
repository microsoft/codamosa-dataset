

# Generated at 2022-06-12 07:23:09.840661
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]



# Generated at 2022-06-12 07:23:13.165995
# Unit test for function load_env_file
def test_load_env_file():
    lines = ["LOGNAME=foobar", "FRUIT=apple", "RANDOM=42", "HELLO=\"I said \\\"hello\\\".\""]
    t = load_env_file(lines, write_environ=None)

    assert t["LOGNAME"] == "foobar"
    assert t["FRUIT"] == "apple"
    assert t["RANDOM"] == "42"
    assert t["HELLO"] == 'I said "hello".'


if __name__ == "__main__":
    import sys

    sys.exit(test_load_env_file())

# Generated at 2022-06-12 07:23:21.009741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = parse_env_file_contents(lines)

    assert os.environ["HOME"] in next(environ)[1]
    assert os.path.join(os.environ["HOME"], "a", "test") == next(environ)[1]
    assert os.path.join(os.environ["HOME"], "swaggins", "$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST") == next(environ)[1]



# Generated at 2022-06-12 07:23:25.446390
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-12 07:23:37.000165
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env = load_env_file(["TEST=$PATH"])
    assert len(env) == 1
    assert "TEST" in env
    assert env["TEST"] == os.environ["PATH"]

    env = load_env_file(["TEST=foo$PATH=bar"])
    assert len(env) == 1
    assert "TEST" in env
    assert env["TEST"] == "foo$PATH=bar"

    env = load_env_file(["TEST='$PATH'"])
    assert len(env) == 1
    assert "TEST" in env
    assert env["TEST"] == "$PATH"

    env = load_env_file(["TEST='$PATH'", "TEST2=$TEST"])
    assert len(env) == 2
    assert "TEST" in env

# Generated at 2022-06-12 07:23:43.365655
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert isinstance(result, collections.OrderedDict)
    assert len(result) == 3
    for key, value in result.items():
        assert isinstance(key, str)
        assert key in ['TEST', 'THISIS', 'YOLO']
        assert isinstance(value, str)
        if key == 'TEST':
            assert value.startswith(os.path.expanduser('~'))

# Generated at 2022-06-12 07:23:53.490172
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # The first test case
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for line in lines:
        m1 = re.match(r'\A([A-Za-z_0-9]+)=(.*)\Z', line)
        if m1:
            key, val = m1.group(1), m1.group(2)

        m2 = re.match(r"\A'(.*)'\Z", val)
        if m2:
            val = m2.group(1)

        m3 = re.match(r'\A"(.*)"\Z', val)

# Generated at 2022-06-12 07:23:59.974029
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:24:01.190941
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:24:08.639254
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    assert next(result) == ('TEST', '${HOME}/yeee')
    assert next(result) == ('THISIS', '~/a/test')
    assert next(result) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    with pytest.raises(StopIteration):
        next(result)

