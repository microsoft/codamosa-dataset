

# Generated at 2022-06-25 23:27:34.322150
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(None).to_lazy(), Lazy)
    assert isinstance(Left(None), Either)



# Generated at 2022-06-25 23:27:36.605482
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    right_0 = Right(var_0)
    left_0.__eq__()


# Generated at 2022-06-25 23:27:41.053941
# Unit test for method case of class Either
def test_Either_case():
    error_handler = lambda error: 1
    success_handler = lambda success: 0
    left_0 = Left(None)
    assert left_0.case(error_handler, success_handler) == 1
    right_0 = Right(None)
    assert right_0.case(error_handler, success_handler) == 0



# Generated at 2022-06-25 23:27:50.788332
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    var_2 = None
    left_2 = Left(var_2)
    var_3 = None
    left_3 = Left(var_3)

    assert left_0 == left_0
    assert left_0 == left_1
    assert left_0 == left_2
    assert left_0 == left_3

    var_4 = None
    right_0 = Right(var_4)
    var_5 = None
    right_1 = Right(var_5)
    var_6 = None
    right_2 = Right(var_6)
    var_7 = None
    right_3 = Right(var_7)

    assert right_0 == right

# Generated at 2022-06-25 23:27:54.292500
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    var_1 = None
    left_0 = Left(var_0)
    left_1 = Left(var_1)
    test_0 = left_0 == left_1
    assert test_0


# Generated at 2022-06-25 23:27:59.779143
# Unit test for method case of class Either
def test_Either_case():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.case(lambda x : x, lambda x : x)
    assert var_1 == var_0

    var_2 = None
    right_0 = Right(var_2)
    var_3 = right_0.case(lambda x : x, lambda x : x)
    assert var_3 == var_2



# Generated at 2022-06-25 23:28:10.528696
# Unit test for method case of class Either
def test_Either_case():
    # Test 1
    var_1: int = None
    left_1: Either[int] = Left(var_1)
    var_2: int = None
    success_2: Callable[[int], int] = lambda x: x
    var_3 = left_1.case(lambda x: x, success_2)
    assert isinstance(var_3, int)
    assert var_3 == var_1, 'Assertion error: %s' % var_3
    # Test 2
    var_4: int = None
    left_4: Either[int] = Left(var_4)
    var_5: int = None
    error_5: Callable[[int], int] = lambda x: x
    var_6 = left_4.case(error_5, lambda x: x)

# Generated at 2022-06-25 23:28:16.154558
# Unit test for method case of class Either
def test_Either_case():
    def error_0(var_0):
        return var_0

    def success_0(var_0):
        return var_0

    right_0 = Right('Success')
    assert right_0.case(error_0, success_0) == 'Success'

    left_0 = Left('Failure')
    assert left_0.case(error_0, success_0) == 'Failure'



# Generated at 2022-06-25 23:28:24.364065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    var_0 = None

    var_1 = [var_0]
    left_0 = Left(var_1)
    left_1 = left_0.to_lazy()

    assert isinstance(left_1, Box)

    left_2 = left_0.to_box()
    assert isinstance(left_2, Box)

    left_3 = left_0.to_try()
    assert isinstance(left_3, Try)

    left_4 = left_0.to_maybe()
    assert isinstance(left_4, Maybe)

    left_5 = left_0.to_validation()
    assert isinstance

# Generated at 2022-06-25 23:28:35.467235
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def test_case_Left_Left():
        var_0 = None
        left_0 = Left(var_0)
        assert left_0 == left_0

    def test_case_Left_Right():
        var_0 = None
        left_0 = Left(var_0)
        right_0 = Right(var_0)
        assert left_0 != right_0

    def test_case_Left_Left_Equal_value():
        var_0 = None
        left_0 = Left(var_0)
        left_1 = Left(var_0)
        assert left_0 == left_1

    def test_case_Right_Right():
        var_0 = None
        right_0 = Right(var_0)
        assert right_0 == right_0


# Generated at 2022-06-25 23:28:39.853948
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)

    actual = right_0.to_lazy()

    expected = isinstance(actual, Lazy)
    assert expected is True


# Generated at 2022-06-25 23:28:44.335442
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    var_1 = True
    var_2 = not var_1
    assert left_0.to_lazy() == Lazy(var_0)
    var_0 = None
    right_0 = Right(var_0)
    var_1 = True
    var_2 = not var_1
    assert right_0.to_lazy() == Lazy(var_0)


# Generated at 2022-06-25 23:28:45.898079
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_1 = Right(var_0)


# Generated at 2022-06-25 23:28:48.207222
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().force() == 1
    assert Right(1).to_lazy().force() == 1



# Generated at 2022-06-25 23:28:52.903576
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    left_lazy_0 = left_0.to_lazy()
    var_1 = None
    right_0 = Right(var_1)
    right_lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:29:03.174652
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    assert isinstance(var_1, Lazy)
    var_2 = None
    left_1 = Left(var_2)
    var_3 = left_1.to_lazy()
    assert isinstance(var_3, Lazy)
    var_4 = None
    right_0 = Right(var_4)
    var_5 = right_0.to_lazy()
    assert isinstance(var_5, Lazy)
    var_6 = None
    right_1 = Right(var_6)
    var_7 = right_1.to_lazy()
    assert isinstance(var_7, Lazy)


# Generated at 2022-06-25 23:29:06.755719
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    var_1 = None
    left_1 = Left(var_1)
    lazy_var_2 = None
    lazy_1 = left_1.to_lazy()
    assert isinstance(lazy_1, lazy.Lazy)
    assert lazy_1.value() is var_1


# Generated at 2022-06-25 23:29:08.516051
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    expected_0 = 42
    actual_0 = Right(expected_0).to_lazy().value
    assert expected_0 == actual_0


# Generated at 2022-06-25 23:29:16.836517
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0 == Lazy(lambda: None)
    var_1 = 'ASCII'
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1 == Lazy(lambda: 'ASCII')


# Generated at 2022-06-25 23:29:20.816914
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for exception
    var_0 = None
    left_0 = Left(var_0)
    assert Exception == type(left_0.to_lazy().get_value())
    var_1 = 5
    right_0 = Right(var_1)
    assert 5 == right_0.to_lazy().get_value()



# Generated at 2022-06-25 23:29:26.238356
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = lazy_0.value()
    assert var_1 is var_0


# Generated at 2022-06-25 23:29:36.623569
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = left_0.to_lazy()
    var_3 = left_0.to_lazy()
    var_4 = left_0.to_lazy()
    var_5 = left_0.to_lazy()
    var_6 = left_0.to_lazy()
    var_7 = left_0.to_lazy()
    var_8 = left_0.to_lazy()
    var_9 = left_0.to_lazy()
    var_10 = left_0.to_lazy()
    var_11 = left_0.to_lazy()
    var_12 = left_0.to_lazy()


# Generated at 2022-06-25 23:29:41.729845
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(1)
    var_1 = var_0.to_lazy()
    var_2 = var_1.__call__()
    assert var_2 == 1

    var_3 = Right(1)
    var_4 = var_3.to_lazy()
    var_5 = var_4.__call__()
    assert var_5 == 1



# Generated at 2022-06-25 23:29:44.103173
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == left_0.value


# Generated at 2022-06-25 23:29:47.713972
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.function
    # Test case 1
    var_0 = None
    either_0 = Left(var_0)
    var_1 = right(either_0)
    var_2 = right(either_0)
    var_3 = Either.to_lazy(either_0)


# Generated at 2022-06-25 23:29:52.872095
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)

    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:56.279577
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    # lazy_val = left_0.to_lazy()
    # var_1 = lazy_val.get()


# Generated at 2022-06-25 23:29:59.986310
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = True
    right = Right(var_1)
    var_2 = lambda: var_1
    lazy = right.to_lazy()
    var_3 = var_2()
    var_4 = lazy()


# Generated at 2022-06-25 23:30:03.679038
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_2 = 3
    right_2 = Right(var_2)
    lazy_2 = right_2.to_lazy()
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.value == var_2


# Generated at 2022-06-25 23:30:06.405194
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    expected = Lazy(lambda: 1)
    assert Right(1).to_lazy() == expected



# Generated at 2022-06-25 23:30:11.044029
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:30:12.795608
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0 is not None


# Generated at 2022-06-25 23:30:14.066607
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = Right(var_0)
    var_2 = Lazy(lambda :var_0)



# Generated at 2022-06-25 23:30:19.880090
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    var_2 = None
    lazy_0 = var_2.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0, Right)
    assert lazy_0.value == var_2


# Generated at 2022-06-25 23:30:30.194576
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 3
    var_1 = None
    var_2 = 'test_string'
    var_3 = '101'

    right_0 = Right(var_0)
    right_1 = Right(var_1)
    right_2 = Right(var_2)
    right_3 = Right(var_3)
    right_4 = right_2.to_lazy()

    left_0 = Left(var_0)
    left_1 = Left(var_1)
    left_2 = Left(var_2)
    left_3 = Left(var_3)
    left_4 = left_2.to_lazy()

    assert right_0.to_lazy() == var_0
    assert right_1.to_lazy() == var_1
    assert right_2.to

# Generated at 2022-06-25 23:30:31.864163
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # lambda f: f(),
    #lambda f: f()
    func = lambda f: f()

    var_0 = Either.case(func, func)
    return var_0


# Generated at 2022-06-25 23:30:34.436141
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Lazy(lambda: 1)
    left_0 = Left(var_0)
    assert left_0.to_lazy() == var_0
    var_1 = 1
    right_0 = Right(var_1)
    assert right_0.to_lazy() == var_0


# Generated at 2022-06-25 23:30:37.148298
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = left_0.to_lazy()
    assert var_1 == var_2


# Generated at 2022-06-25 23:30:41.515287
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = "Test"
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()

    # Unit test for method __eq__ of class Either
    var_2 = var_0 == var_1.value()


# Generated at 2022-06-25 23:30:45.595135
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Constructor of class Either with argument value
    left_0 = None
    either_0 = Either(left_0)

    # Dispatch call of method to_lazy on Either with argument either_0
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:30:50.809419
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda f: f()
    var_1 = Either(1).to_lazy()
    var_2 = var_0(var_1)
    assert var_2 == 1


# Generated at 2022-06-25 23:30:54.347411
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(1)
    var_1 = var_0.to_lazy()
    var_2 = var_1.map(lambda x: x + 2)
    var_3 = var_2.value()
    assert var_3 == 3


# Generated at 2022-06-25 23:30:58.698875
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    try:
        var_0 = Left(0)
    except Exception as exception:
        print('Exception: ' + str(exception))
    else:
        if str(type(var_0.to_lazy())) != "<class 'pymonet.lazy.Lazy'>":
            raise Exception('Expected <class \'pymonet.lazy.Lazy\'>, but got ' + str(type(var_0.to_lazy())))

# Generated at 2022-06-25 23:31:02.830766
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(str(1))
    var_0 = var_0.to_lazy()
    assert var_0.realize() == '1'


# Generated at 2022-06-25 23:31:05.679444
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Left(0).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 0
    result = Right(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 1


# Generated at 2022-06-25 23:31:09.135203
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    mock_class = Left('mock_value')
    mock_class.to_lazy = lambda self: self.value
    assert mock_class.to_lazy() == 'mock_value'


# Generated at 2022-06-25 23:31:13.391084
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = 5
    var_2 = Either.Left(var_1)
    test_case_0()
    var_3 = var_2.to_lazy()
    assert isinstance(var_3, Either.Right)


# Generated at 2022-06-25 23:31:17.224081
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    res_0 = Right(1).to_lazy()
    res_1 = Left(1).to_lazy()

    assert res_0() == 1
    assert res_1() == 1


# Generated at 2022-06-25 23:31:20.800083
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result_0: Lazy[int] = Left('Error').to_lazy()
    result_1: Lazy[int] = Right(10).to_lazy()


# Generated at 2022-06-25 23:31:27.749983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_cases = [
        {
            "input": {
                "value": str,
            },
            "output": {
                "value": str,
            },
            "assertion": test_case_0
        }
    ]


# Generated at 2022-06-25 23:31:36.179232
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda f: f()
    var_1 = var_0(lambda: Left(None)).to_lazy()
    assert var_1.value() == None


# Generated at 2022-06-25 23:31:46.244316
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:31:51.429932
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    expected = Lazy(lambda: 42)

    val_0 = Either.of(42)
    actual_0 = val_0.to_lazy()
    assert actual_0 == expected, actual_0
    assert type(actual_0) == Lazy
    assert val_0 == val_0.to_lazy().evaluate()


# Generated at 2022-06-25 23:31:55.063199
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test method to_lazy of class Either
    """
    assert isinstance(Left(2).to_lazy(), Lazy)
    assert isinstance(Right(2).to_lazy(), Lazy)


# Generated at 2022-06-25 23:31:57.614574
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = lambda f: f()
    var_2 = var_1(lambda: Right(123).to_lazy())
    assert var_2 == Right(123).value



# Generated at 2022-06-25 23:32:01.786306
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        var_0 = Either.to_lazy(Right(5))
        var_1 = var_0()
        var_2 = 5
        assert var_1 == var_2
    test_case_0()


# Generated at 2022-06-25 23:32:03.318275
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(1)
    var_1 = test_case_0()


# Generated at 2022-06-25 23:32:05.520315
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    f = lambda: 1
    var_0 = Right(f).to_lazy()
    assert var_0.is_lazy() == True


# Generated at 2022-06-25 23:32:09.288815
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test a value of type 'Left[int]'
    x = 1
    y = Either[int].to_lazy(x)
    assert y.value() == x
    # Test a value of type 'Right[int]'
    x = 1
    y = Either[int].to_lazy(x)
    assert y.value() == x



# Generated at 2022-06-25 23:32:12.017602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda f: f()
    var_1 = Either(var_0)
    var_2 = var_1.to_lazy()
    var_3 = var_2.value()
    var_3


# Generated at 2022-06-25 23:32:24.067408
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:32:32.300545
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def to_lazy_None() -> None:
        var_0 = None
        var_1 = Left(var_0).to_lazy()
        assert isinstance(var_1, Lazy)
        var_2 = var_1.value()
        assert var_0 is var_2
        var_3 = Right(var_0).to_lazy()
        assert isinstance(var_3, Lazy)
        var_4 = var_3.value()
        assert var_0 is var_4
    def to_lazy_Bool() -> None:
        var_0 = True
        var_1 = Left(var_0).to_lazy()
        assert isinstance(var_1, Lazy)
        var_2 = var_1.value()
        assert var_0 is var_2
        var

# Generated at 2022-06-25 23:32:39.829866
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test case 0
    try:
        # Test case 0
        either_test_0 = Right(test_case_0)
        # Test case 0: successful
        assert(either_test_0.to_lazy().value() == either_test_0.value)
    except:
        # Test case 0: failed
        assert(False)

    # Test case 1
    try:
        # Test case 1
        either_test_1 = Left(test_case_0)
        # Test case 1: successful
        assert(either_test_1.to_lazy().value() == either_test_1.value)
    except:
        # Test case 1: failed
        assert(False)


# Generated at 2022-06-25 23:32:42.214833
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    either = Right(1)
    # When
    result = either.to_lazy()
    # Then
    assert 1 == result.get()


# Generated at 2022-06-25 23:32:47.494141
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Either.to_lazy(Right(callable))
    var_1 = Right.to_lazy()
    is_instance(var_0, Lazy)
    is_instance(var_1, Lazy)
    # TODO: not checked type of value, because it is not restored during test
    str(var_1) == str(var_0)


# Generated at 2022-06-25 23:32:52.514502
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda: 1
    a_0 = Right(var_0)
    var_1 = var_0()
    b_1 = a_0.to_lazy()
    var_2 = b_1()
    c_0 = var_1 == var_2

    if c_0:
        print("test_Either_to_lazy Test 1 passed")
    else:
        print("test_Either_to_lazy Test 1 failed")


# Generated at 2022-06-25 23:32:56.030430
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test error case
    var_0 = Left(1).to_lazy()
    var_1 = var_0()

    # Test success case
    var_2 = Right(1).to_lazy()
    var_3 = var_2()



# Generated at 2022-06-25 23:32:57.709565
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-25 23:33:01.532362
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert_that(Right(5).to_lazy(), instance_of(Lazy))
    assert_that(Right(5).to_lazy().value(), equal_to(5))
    assert_that(Left(6).to_lazy(), instance_of(Lazy))
    assert_that(Left(6).to_lazy().value(), equal_to(6))


# Generated at 2022-06-25 23:33:04.452407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    monad_0 = Right(lambda var_0: var_0)
    monad_1 = monad_0.to_lazy()

    assert monad_1.value == monad_0.value


# Generated at 2022-06-25 23:33:18.208583
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = None
    either_1 = Right(var_1)
    res_1 = either_1.to_lazy()
    var_2 = None
    either_2 = Left(var_2)
    res_2 = either_2.to_lazy()


# Generated at 2022-06-25 23:33:21.443343
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()

    var_0 = 42
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:24.519280
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = object()
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert type(lazy_0) is Lazy
    # And var_0 = lazy_0.value()


# Generated at 2022-06-25 23:33:25.927383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    box_1 = Right(10)
    lazy_1 = box_1.to_lazy()



# Generated at 2022-06-25 23:33:29.088597
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(None).to_lazy(), Lazy)
    assert isinstance(Left(123).to_lazy(), Lazy)
    assert isinstance(Right(None).to_lazy(), Lazy)
    assert isinstance(Right(123).to_lazy(), Lazy)


# Generated at 2022-06-25 23:33:29.919001
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass

# Generated at 2022-06-25 23:33:34.214188
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    var_0 = Maybe.just(4)
    var_1 = Right(var_0)
    var_2 = var_1.to_lazy()
    assert var_2.force() == var_0

    var_0 = Try(4, True)
    var_1 = Right(var_0)
    var_2 = var_1.to_lazy()
    assert var_2.force() == var_0

    var_0 = Box(4)
    var_1 = Right(var_0)
    var_2 = var_1.to_lazy()
    assert var_2.force() == var_0


# Generated at 2022-06-25 23:33:41.072500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    Left.to_lazy = Left.to_lazy
    Right.to_lazy = Right.to_lazy
    var_1 = None
    left_1 = Left(var_1)
    var_1 = 1
    right_0 = Right(var_1)
    var_0 = 1
    var_1 = None
    left_0 = Left(var_1)
    var_0 = 2
    var_1 = right_0
    right_0 = Right(var_1)
    var_0 = left_1
    var_1 = right_0
    assert var_0.to_lazy() == var_1.to_lazy()
    var_0 = right_0.to_lazy()
    var_0 = left_0
    var_1 = right_0
    assert var_

# Generated at 2022-06-25 23:33:43.677188
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_2 = "abdc"
    left_2 = Left(var_2)
    var_3 = left_2.to_lazy()
    var_4 = var_3.get()
    assert var_4 == var_2

# Generated at 2022-06-25 23:33:45.755985
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    # Test
    assert False



# Generated at 2022-06-25 23:34:11.286882
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:34:13.935043
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(None)
    left_0 = Left(var_0)


# Generated at 2022-06-25 23:34:20.064590
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test method to_lazy of class Either

    :returns: PAss or FAIL
    :rtype: String
    """
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    either_0_lazy = left_0.to_lazy()
    assert isinstance(either_0_lazy, Lazy)
    assert either_0_lazy.value == var_0

    var_1 = None
    right_0 = Right(var_1)
    either_1_lazy = right_0.to_lazy()
    assert isinstance(either_1_lazy, Lazy)
    assert either_1_lazy.value == var_1



# Generated at 2022-06-25 23:34:22.340140
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Either(2).to_lazy()


# Generated at 2022-06-25 23:34:32.210527
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    var_1 = Right(var_0)
    var_2 = Lazy(lambda: var_0)
    var_3 = var_1.to_lazy()
    var_4 = var_2 == var_3
    var_5 = assert_(var_4)
    var_6 = Left(var_0)
    var_7 = var_6.to_lazy()
    var_8 = var_7 == var_3
    var_9 = assert_(var_8)
    var_10 = None
    var_11 = var_10
    return var_11


# Generated at 2022-06-25 23:34:37.524731
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value_0 = 42
    var_0 = Right(value_0)
    var_1 = var_0.to_lazy()
    var_2 = var_1.evaluate()
    var_3 = var_2 == value_0
    assert var_3


# Generated at 2022-06-25 23:34:42.332311
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0).to_lazy()
    var_1 = [None]
    left_1 = Left(var_1).to_lazy()

    var_2 = None
    right_0 = Right(var_2).to_lazy()
    var_3 = [None]
    right_1 = Right(var_3).to_lazy()



# Generated at 2022-06-25 23:34:44.065515
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:34:53.301945
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.exceptions import LazyException
    from tests.utils import assert_equals

    var_0 = 1
    right_0 = Right(var_0)
    lazy = right_0.to_lazy()

    assert_equals(lazy, Lazy(lambda: 1))
    try:
        lazy.get()
    except LazyException as e:
        assert_equals(str(e), "Left cannot be evaluated.")

    var_1 = 1
    left_0 = Left(var_1)
    lazy = left_0.to_lazy()

    assert_equals(lazy, Lazy(lambda: 1))

# Generated at 2022-06-25 23:34:59.317751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(None)
    result_0 = right_0.to_lazy()
    assert result_0.is_looked is False
    assert result_0.is_error is False
    assert result_0.value is None
    var_0 = None
    left_0 = Left(var_0)
    result_1 = left_0.to_lazy()
    assert result_1.value is None
    assert result_1.is_error is False
    assert result_1.is_looked is False


# Generated at 2022-06-25 23:35:57.857218
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    left_0 = Left(var_0)
    right_0 = Right(var_1)
    var_2 = left_0.to_lazy()
    var_3 = right_0.to_lazy()


# Generated at 2022-06-25 23:36:02.072899
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    val_0 = left_0.to_lazy()
    str_0 = str(val_0)
    assert str_0 == 'Lazy(None)'

    right_0 = Right(5)
    val_1 = right_0.to_lazy()
    str_1 = str(val_1)
    assert str_1 == 'Lazy(5)'


# Generated at 2022-06-25 23:36:04.457603
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = None
    var_1.resolve(var_2)


# Generated at 2022-06-25 23:36:06.443951
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy() == Lazy(lambda: None)
    assert Right(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:36:09.014088
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 1
    either_0 = Either(var_0)

    var_1 = either_0.to_lazy()
    var_2 = var_1.value()

    assert var_0 == var_2


# Generated at 2022-06-25 23:36:13.840580
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    var_1 = None
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert isinstance(lazy_1, Lazy)


# Generated at 2022-06-25 23:36:22.593380
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box

    from pymonet.lazy import Lazy

    from pymonet.monad_try import Try

    either: Either[int] = Right(0)
    lazy = either.to_lazy()
    assert lazy == Lazy(lambda: 0)
    box: Box[int] = Box(0)
    lazy = box.to_lazy()
    assert lazy == Lazy(lambda: 0)
    try_0: Try[int] = Try(0)
    lazy = try_0.to_lazy()
    assert lazy == Lazy(lambda: 0)
    box_0: Box[int] = Box(0)
    lazy_0 = box_0.to_lazy()
    assert lazy_0 == Lazy(lambda: 0)


# Generated at 2022-06-25 23:36:26.524046
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(lambda: None)

    var_1 = 1
    right_0 = Right(var_1)
    assert right_0.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:36:32.159324
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left_0 = Left(None)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0 == Lazy(lambda: None)

    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0 == Lazy(lambda: None)



# Generated at 2022-06-25 23:36:36.844503
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    val_0 = None
    right_0 = Right(val_0)
    lazy_0 = right_0.to_lazy()
    var_3 = None
    val_1 = None
    left_0 = Left(val_1)
    lazy_1 = left_0.to_lazy()
