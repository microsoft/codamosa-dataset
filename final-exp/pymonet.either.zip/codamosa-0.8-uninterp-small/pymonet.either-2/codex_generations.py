

# Generated at 2022-06-25 23:27:28.150247
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = 1
    var_1 = 1
    either_0 = Right(var_0)
    either_1 = Right(var_1)
    assert either_0 != either_1


# Generated at 2022-06-25 23:27:29.945947
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = Right(None)
    var_1 = None
    instance = var_0
    var_2 = instance.__eq__(var_1)
    assert var_2 is False



# Generated at 2022-06-25 23:27:33.459745
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = Left(None)
    var_1 = Left(1)
    var_2 = Right(None)
    var_3 = Right(1)
    assert var_0 == var_1
    assert not (var_0 == var_2)
    assert not (var_0 == var_3)
    assert var_2 == var_3


# Generated at 2022-06-25 23:27:42.550175
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    var_1 = None
    var_2 = Right(var_0)
    var_3 = Right(var_0)
    var_4 = Right(var_1)
    var_5 = None
    var_6 = Right(var_5)
    var_7 = None
    var_8 = None
    var_9 = Right(var_8)
    var_10 = Left(var_8)
    res_0 = var_2 == var_3
    res_1 = var_2 == var_4
    res_2 = var_2 == var_6
    res_3 = var_2 == var_9
    res_4 = var_2 == var_10
    res_5 = var_9 == var_10


# Generated at 2022-06-25 23:27:51.567927
# Unit test for method case of class Either
def test_Either_case():

    def if_left_pass(var_0):
        return "Left"

    def if_right_pass(var_0):
        return "Right"

    var_0 = None
    right_0 = Right(var_0)

    var_1 = ""
    left_0 = Left(var_1)

    assert left_0.case(if_left_pass, if_right_pass) == "Left"
    assert left_0.case(if_left_pass, if_right_pass) != "Right"

    assert right_0.case(if_left_pass, if_right_pass) != "Left"
    assert right_0.case(if_left_pass, if_right_pass) == "Right"



# Generated at 2022-06-25 23:27:53.843820
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    result = Right(0) == Right(1)
    assert isinstance(result, bool)


# Generated at 2022-06-25 23:27:57.970275
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    assert left_0 != right_0


# Generated at 2022-06-25 23:28:01.113036
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    right_0 = Right(var_0)
    to_lazy_0 = right_0.to_lazy()
    lazy_0 = Lazy.of(lambda: var_0)
    assert to_lazy_0 == lazy_0


# Generated at 2022-06-25 23:28:03.184669
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right_0 = Right(None)
    right_1 = Right(None)

    assert right_0 == right_1


# Generated at 2022-06-25 23:28:11.977016
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    right_0 = Right(var_0)
    right_1 = Right(var_0)
    assert right_0 == right_1
    assert right_1 == right_0
    right_1 = Right(var_0)
    right_1._value = "right 1"
    assert not(right_0 == right_1)
    assert not(right_1 == right_0)
    var_0 = None
    left_0 = Left(var_0)
    left_1 = Left(var_0)
    left_1._value = "left 1"
    assert not(left_0 == left_1)
    assert not(left_1 == left_0)


# Generated at 2022-06-25 23:28:17.851544
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    either_0 = Either(var_0)
    var_1 = either_0.to_lazy()
    var_2 = var_1.value()
    var_3 = None
    assert var_2 == var_3


# Generated at 2022-06-25 23:28:19.996642
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func_0():
        return str()

    var_0 = func_0()
    var_1 = Either.to_lazy(var_0)

# Generated at 2022-06-25 23:28:22.967016
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()
    var_2 = var_1.value
    var_3 = var_2()
    var_4 = var_3 == None


# Generated at 2022-06-25 23:28:26.560526
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left_0 = Left(2)
    left_1 = Lazy(lambda: left_0.value)
    assert left_0.to_lazy() == left_1


# Generated at 2022-06-25 23:28:29.751797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0: Either[int] = Right(3)
    var_1: Either[int] = var_0.to_lazy()


# Generated at 2022-06-25 23:28:31.922980
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:28:35.636647
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()
    var_2 = right_0.to_lazy()
    assert (
        (var_1 == var_2))


# Generated at 2022-06-25 23:28:36.778531
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0: Either[int] = Right(3)
    var_1: Lazy[int] = var_0.to_lazy()


# Generated at 2022-06-25 23:28:44.098535
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test for method to_lazy of class Either
    """
    from pymonet.lazy import Lazy

    def test_case_0():
        var_0 = None
        right_0 = Right(var_0)
        val_0 = right_0.to_lazy()
        assert isinstance(val_0, Lazy)

    def test_case_1():
        var_0 = None
        right_1 = Right(var_0)
        val_0 = right_1.to_lazy()
        val_1 = val_0.value
        assert val_1 == var_0

    def test_case_2():
        var_0 = None
        right_2 = Right(var_0)
        val_0 = right_2.to_lazy()

# Generated at 2022-06-25 23:28:46.861130
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    result = right_0.to_lazy()
    assert isinstance(result, Lazy)


# Generated at 2022-06-25 23:28:52.954368
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = 1
    right_1 = Right(var_1)
    right_1.to_lazy()


# Generated at 2022-06-25 23:28:58.630763
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    either_0 = Left(var_0)
    var_1 = either_0.to_lazy()
    assert var_1.value() == None
    right_0 = Right(var_0)
    var_2 = right_0.to_lazy()
    assert var_2.value() == None


# Generated at 2022-06-25 23:29:02.802524
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Run test for method to_lazy of class Either
    """
    # Constructor call
    var_0 = None
    right_0 = Right(var_0)
    # Method call
    either_0 = right_0.to_lazy()
    assert either_0.is_instance_of(Lazy)


# Generated at 2022-06-25 23:29:07.287602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    assert var_1.__class__.__name__ == 'Lazy'

    var_2 = None
    right_0 = Right(var_2)
    var_3 = right_0.to_lazy()
    assert var_3.__class__.__name__ == 'Lazy'



# Generated at 2022-06-25 23:29:14.805410
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    ret_1 = right_0.to_lazy()
    assert_true(ret_1 is not None, 'assertion failed: ret_1 is not None')


# Generated at 2022-06-25 23:29:17.289799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # left = Left({'a': 1})
    right = Right(2)
    lazy = right.to_lazy()
    assert lazy() == 2


# Generated at 2022-06-25 23:29:22.047827
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import *
    int_0: int = 0
    right_0: Either[int] = Right(int_0)
    lazy_0: Lazy[int] = right_0.to_lazy()
    int_1: int = lazy_0.get()
    bool_0: bool = int_1 == int_0
    assert bool_0 is True


# Generated at 2022-06-25 23:29:24.814030
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = Right(var_0)
    var_1 = var_1.to_lazy()


# Generated at 2022-06-25 23:29:32.041895
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Initialize a new Maybe[A] instance with None value
    # var_1 = Maybe.nothing()
    # Assert that Maybe is already resolved as successful
    # assert var_1.is_just() == False
    # Apply map function to value of var_1
    # var_2 = var_1.map(lambda x: x + 2)
    # Check in consistent order if var_2 is empty
    # assert var_2.is_just() == False
    pass


# Generated at 2022-06-25 23:29:36.741268
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    var_1 = None
    left_0 = Left(var_1)
    lazy_1 = left_0.to_lazy()
    assert isinstance(lazy_1, Lazy)


# Generated at 2022-06-25 23:29:48.652826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().get() == 1
    assert Right(0.0).to_lazy().get() == 0.0
    assert Right(True).to_lazy().get() == True
    assert Right('true').to_lazy().get() == 'true'
    assert Right(()).to_lazy().get() == ()
    assert Right([]).to_lazy().get() == []
    assert Right([1,2,3]).to_lazy().get() == [1,2,3]
    assert Right({}).to_lazy().get() == {}
    assert Right({'a':1, 'b':2}).to_lazy().get() == {'a':1, 'b':2}


# Generated at 2022-06-25 23:29:51.818441
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = Right((lambda: None))
    var_3 = var_2.value()
    assert var_3 == None


# Generated at 2022-06-25 23:30:01.721686
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    input0 = Either[(None)][None](None)
    expected_output = None
    actual_output = input0.to_lazy().force()
    assert actual_output == expected_output

    input0 = Either[(None)][None](None)
    expected_output = None
    actual_output = input0.to_lazy().force()
    assert actual_output == expected_output

    input0 = Either[(None)][None](None)
    expected_output = None
    actual_output = input0.to_lazy().force()
    assert actual_output == expected_output

    input0 = Either[(None)][None](None)
    expected_output = None
    actual_output = input0.to_lazy().force()
    assert actual_output == expected_output


# Generated at 2022-06-25 23:30:03.841333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()
    pass


# Generated at 2022-06-25 23:30:08.248087
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    var_1 = Lazy(lambda: var_0)
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert var_1 == lazy_0


# Generated at 2022-06-25 23:30:14.466146
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Right('abc').to_lazy() == Lazy(lambda: 'abc')
    assert Right([]).to_lazy() == Lazy(lambda: [])
    assert Right({}).to_lazy() == Lazy(lambda: {})
    assert Right('').to_lazy() == Lazy(lambda: '')
    assert Right((1, 2, 3)).to_lazy() == Lazy(lambda: (1, 2, 3))
    assert Right(set()).to_lazy() == Lazy(lambda: set())
    assert Right(frozenset()).to_lazy() == Lazy(lambda: frozenset())

# Generated at 2022-06-25 23:30:20.671049
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for method to_lazy of class Either
    var_0 = None
    right_0 = Right(var_0)
    actual_0 = right_0.to_lazy()
    expected_0 = Lazy(lambda : var_0)
    assert_0 = assert_equals(actual_0, expected_0)
    if not assert_0:
        raise AssertionError(format_err_msg(assert_0.message, expected_0, actual_0))



# Generated at 2022-06-25 23:30:22.466473
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Either(None).to_lazy()
    right_0.value()



# Generated at 2022-06-25 23:30:24.361073
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    _input = 42
    _maybe = Right(_input).to_lazy()
    assert _maybe.value() == _input



# Generated at 2022-06-25 23:30:27.810119
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 'x'
    right_0 = Right(var_0)
    assert right_0.to_lazy().eval() == var_0


# Generated at 2022-06-25 23:30:42.080982
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    assert right_0.to_lazy() == Lazy(lambda: var_0)
    var_1 = None
    left_0 = Left(var_1)
    assert left_0.to_lazy() == Lazy(lambda: var_1)
    var_2 = None
    left_1 = Left(var_2)
    assert left_1.to_lazy() == Lazy(lambda: var_2)


# Generated at 2022-06-25 23:30:52.342140
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

    test_cases = [
        {
            "name": "empty_object",
            "inputs": [var_0],
            "expected": None
        },
        {
            "name": "object_with_non_empty_attributes",
            "inputs": [var_1],
            "expected": None
        },
        {
            "name": "non_empty_object",
            "inputs": [var_2],
            "expected": None
        },
        {
            "name": "non_empty_object",
            "inputs": [var_3],
            "expected": None
        }
    ]


# Generated at 2022-06-25 23:30:53.233701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert False == True



# Generated at 2022-06-25 23:30:55.021945
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = True
    right_0 = Right(var_0)
    right_0_to_lazy = right_0.to_lazy()

    assert right_0_to_lazy.value() == right_0.value



# Generated at 2022-06-25 23:30:56.491016
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(1)
    left = Left('msg')
    assert right.to_lazy().evaluate() == 1
    assert left.to_lazy().evaluate() == 'msg'


# Generated at 2022-06-25 23:31:02.417789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        var_0 = None
        right_0 = Right(var_0)
        var_1 = right_0.to_lazy()
        var_2 = var_1.get()
        assert var_2 == var_0


# Generated at 2022-06-25 23:31:08.879921
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None

    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(var_0)
    right_0 = Right(var_1)
    assert right_0.to_lazy() == Lazy(var_1)



# Generated at 2022-06-25 23:31:10.733867
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:14.444474
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)

    assert right_0.to_lazy() == Lazy(lambda:None)


# Generated at 2022-06-25 23:31:17.781130
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Either.case(error(None), success(None))

    assert right.to_lazy().force() is right.to_lazy().force()


# Generated at 2022-06-25 23:31:37.371014
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 1
    result_0 = Lazy(lambda: var_0)
    right_0 = Right(var_0)
    result_1 = right_0.to_lazy()

    assert result_1 == result_0, 'assert #0 of test_Either_to_lazy failed'


# Generated at 2022-06-25 23:31:46.892000
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    var_0 = None
    var_1 = None
    var_2 = None  # type: TypeVar

    def error(var_2): return var_2

    def success(var_2): return var_2

    var_3 = Left(var_0)
    assert isinstance(var_3, Either)
    var_4 = var_3.case(error, success)
    var_5 = var_3.to_box()
    assert isinstance(var_5, Box)
    var_6 = var_3.to_try()
    assert isinstance(var_6, Try)
    var_7 = var_3.to_lazy()
    assert isinstance(var_7, Lazy)
    var_

# Generated at 2022-06-25 23:31:52.247992
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy), "Assert instance"
    assert callable(lazy_0.value), "Assert function"


# Generated at 2022-06-25 23:32:00.519096
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left_0 = Left(None)
    lazy_0 = left_0.to_lazy()
    var_0 = lazy_0.value()
    assert var_0 is None
    var_1 = isinstance(lazy_0, Lazy)
    assert var_1 is True
    right_0 = Right(None)
    lazy_1 = right_0.to_lazy()
    var_2 = lazy_1.value()
    assert var_2 is None
    var_3 = isinstance(lazy_1, Lazy)
    assert var_3 is True


# Generated at 2022-06-25 23:32:06.389964
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    var_0 = None
    # Test 0
    right_0 = Right(var_0)
    t_0 = right_0.to_lazy()
    # Test 1
    var_1 = None
    right_1 = Right(var_1)
    t_1 = right_1.to_lazy()
    # Test 2
    var_2 = None
    right_2 = Right(var_2)
    t_2 = right_2.to_lazy()


# Generated at 2022-06-25 23:32:14.429852
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    right_1 = right_0.to_lazy()
    assert right_1.value() == var_0
    var_2 = '0'
    right_2 = Right(var_2)
    right_3 = right_2.to_lazy()
    assert right_3.value() == var_2
    var_4 = 0
    right_4 = Right(var_4)
    right_5 = right_4.to_lazy()
    assert right_5.value() == var_4
    var_6 = []
    right_6 = Right(var_6)
    right_7 = right_6.to_lazy()
    assert right_7.value() == var_6
    var_8 = True
    right

# Generated at 2022-06-25 23:32:17.811449
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 5
    var_1 = None
    var_1 = Right(var_1)
    var_2 = Right(var_0)
    var_2 = var_1.to_lazy()
    var_1 = 2
    var_2 = var_1 + var_0


# Generated at 2022-06-25 23:32:20.929254
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var = None
    right_0 = Right(var)
    res = right_0.to_lazy()

    assert isinstance(res, Lazy)
    assert res.value() == var


# Generated at 2022-06-25 23:32:25.441968
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.__class__ is Lazy

    right_0 = Right(var_1)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.__class__ is Lazy


# Generated at 2022-06-25 23:32:30.036505
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    var_0 = None

    right_0 = Right(var_0)
    assert right_0.to_lazy().eval() == var_0
    left_0 = Left(var_0)
    assert left_0.to_lazy().eval() == var_0



# Generated at 2022-06-25 23:33:01.526958
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy().get() is None
    assert Right(None).to_lazy().get() is None
    assert Left(2).to_lazy().get() == 2
    assert Right(2).to_lazy().get() == 2


# Generated at 2022-06-25 23:33:03.067390
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:11.305157
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    def suppler() -> str:
        return "abc"
    # Make Lazy with no argument and check result
    lazy_0 = Lazy()
    assert lazy_0 == Lazy(None)
    # Make Lazy with no argument and check result
    lazy_1 = Lazy()
    assert lazy_1 == Lazy(None)
    # Make Lazy with no argument and check result
    lazy_2 = Lazy()
    assert lazy_2 == Lazy(None)
    # Make Lazy with no argument and check result
    lazy_3 = Lazy()
    assert lazy_3 == Lazy(None)
    # Make Lazy with no argument and check result
    lazy_4 = Lazy()

# Generated at 2022-06-25 23:33:14.497146
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0: Either[U] = Right(2)
    var_1 = var_0.to_lazy()

    var_2: Either[int] = var_1.value()


# Generated at 2022-06-25 23:33:22.437451
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 1
    var_1 = 2
    var_2 = 1 + var_0
    var_3 = var_1 + var_2
    var_4 = var_3 + var_0
    var_5 = var_4 + var_2
    var_6 = var_5 + var_3
    var_7 = var_6 + var_2
    var_8 = var_7 + 2
    var_9 = var_8 + var_7
    var_10 = var_9 + var_8
    var_11 = var_10 + var_9
    var_12 = var_11 + var_1
    var_13 = var_12 + var_11
    var_14 = var_13 + var_7
    var_15 = var_14 + var_12
    var_16 = var_

# Generated at 2022-06-25 23:33:24.963447
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy.
    """

    # T|F
    right_0 = Right(False)
    lazy_0 = right_0.to_lazy()



# Generated at 2022-06-25 23:33:28.117272
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(0)
    assert var_0.to_lazy().map(lambda x: x + 1).get() == 1
    var_1 = Left(0)
    assert var_1.to_lazy().map(lambda x: x + 1).get() == 0


# Generated at 2022-06-25 23:33:30.743084
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    instance = Either(1)
    lazy_instance = Lazy(lambda: 1)
    assert instance.to_lazy() == lazy_instance



# Generated at 2022-06-25 23:33:32.349812
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    result_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:38.572131
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert(Right(0).to_lazy() == Lazy(lambda: 0))
    assert(Right([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3]))
    assert(Right((1, 2, 3)).to_lazy() == Lazy(lambda: (1, 2, 3)))
    assert(Right(None).to_lazy() == Lazy(lambda: None))
    assert(Right({1, 2, 3}).to_lazy() == Lazy(lambda: {1, 2, 3}))

# Generated at 2022-06-25 23:34:48.673115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(42)
    assert right_0.to_lazy().value() == 42

    left_0 = Left("42")
    assert left_0.to_lazy().value() == "42"



# Generated at 2022-06-25 23:34:55.302965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    print(lazy_0())
    var_1 = None
    left_0 = Left(var_1)
    lazy_1 = left_0.to_lazy()
    print(lazy_1())



# Generated at 2022-06-25 23:34:57.941633
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Lazy(lambda: None)
    var_2 = Right(var_0).to_lazy()
    assert var_2.force() is None


# Generated at 2022-06-25 23:35:00.698688
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        var_0 = None
        right_0 = Right(var_0)
        var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:35:04.822951
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test when Either is Left
    var_1 = None
    left_0 = Left(var_1)
    assert left_0.to_lazy() == Lazy(None)

    # Test when Either is Right
    var_2 = None
    right_0 = Right(var_2)
    assert right_0.to_lazy() == Lazy(None)


# Generated at 2022-06-25 23:35:08.064869
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy

    assert (Right([1])).to_lazy().value() == [1]
    assert (Left([2])).to_lazy().value() == [2]
    assert Right(Lazy(lambda: 5)).to_lazy().value() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:35:09.492341
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:35:14.285997
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    result_0 = left_0.to_lazy()
    var_1 = "Failed"
    right_0 = Right(var_1)
    result_1 = right_0.to_lazy()
    var_2 = "passed"
    left_1 = Left(var_2)
    result_2 = left_1.to_lazy()
    var_3 = "passed"
    right_1 = Right(var_3)
    result_3 = right_1.to_lazy()


# Generated at 2022-06-25 23:35:17.418521
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    lazy_0.is_instance_of(Lazy)


# Generated at 2022-06-25 23:35:19.039253
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)

    var_1 = right_0.to_lazy()
