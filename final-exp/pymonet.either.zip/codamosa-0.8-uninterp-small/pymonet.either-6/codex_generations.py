

# Generated at 2022-06-25 23:27:38.259956
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = Left(int_0)
    right_0 = Right(int_0)
    right_1 = Right(int_0)

    assert left_0.__eq__(left_1)
    assert not left_0.__eq__(right_0)
    assert right_0.__eq__(right_1)
    assert not right_0.__eq__(left_0)


# Generated at 2022-06-25 23:27:41.296331
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.force() == int_0


# Generated at 2022-06-25 23:27:50.965702
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = -2487
    left_1 = Left(int_1)
    assert left_0.__eq__(left_1) is True
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = -2487
    right_1 = Right(int_1)
    assert left_0.__eq__(right_1) is False
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = -2487
    right_1 = Right(int_1)
    assert right_1.__eq__(left_0) is False
    int_0 = -2487
    right_0 = Right(int_0)
   

# Generated at 2022-06-25 23:27:58.979706
# Unit test for method case of class Either
def test_Either_case():
    """
    :returns: True if method is successful and False if not
    :rtype: Bool
    """
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = -897
    right_0 = Right(int_1)
    int_2 = 1871
    func_0 = lambda x: x + int_2
    int_3 = int_0 + int_2
    int_4 = int_1 + int_2
    bool_0 = left_0.case(func_0, func_0) == int_3 and\
        right_0.case(func_0, func_0) == int_4
    return bool_0


# Generated at 2022-06-25 23:28:10.528858
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = 1778
    left_0 = Left(int_0)
    int_1 = -1885
    left_1 = Left(int_1)
    int_2 = -1962
    left_2 = Left(int_2)
    assert left_1 == left_2
    int_3 = 2094
    right_0 = Right(int_3)
    int_4 = 456
    right_1 = Right(int_4)
    int_5 = 1645
    right_2 = Right(int_5)
    assert right_0 != right_1
    assert right_1 != right_2
    int_6 = -113
    either_0 = Right(int_6)
    int_7 = -1863
    either_1 = Left(int_7)

# Generated at 2022-06-25 23:28:17.153781
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = -2487
    left_1 = Left(int_1)
    bool_0 = left_0.__eq__(left_1)
    int_2 = -2487
    left_2 = Left(int_2)
    bool_1 = left_1.__eq__(left_2)
    assert bool_0 == True
    assert bool_1 == True


# Generated at 2022-06-25 23:28:26.031002
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = left_0

    assert left_0.__eq__(left_1) is True

    left_1 = Left(int_0)

    assert left_0.__eq__(left_1) is True

    int_1 = 4046
    left_1 = Left(int_1)

    assert left_0.__eq__(left_1) is False

    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = left_0

    assert left_0.__eq__(left_1) is True

    left_1 = Right(int_0)

    assert left_0.__eq__(left_1) is False



# Generated at 2022-06-25 23:28:29.711548
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    right_0 = Right(int_0)
    right_1 = Right(int_0)
    assert right_0 == right_1


# Generated at 2022-06-25 23:28:32.527843
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = Left(int_0)
    assert left_0 == left_1


# Generated at 2022-06-25 23:28:37.428841
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_maybe import Maybe
    int_0 = 962
    right_0 = Right(int_0)
    right_1 = right_0
    assert right_0.__eq__(right_1)
    right_2 = Maybe.just(int_0)
    assert not right_0.__eq__(right_2)



# Generated at 2022-06-25 23:28:42.293917
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 2487
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0() == int_0


# Generated at 2022-06-25 23:28:45.007002
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Right(2).to_lazy()


# Generated at 2022-06-25 23:28:47.859760
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0._value() == int_0


# Generated at 2022-06-25 23:28:51.351069
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -1160
    right_0 = Right(int_0)
    int_1 = right_0.to_lazy()
    assert int_1.get() == -1160


# Generated at 2022-06-25 23:28:55.511013
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = -2487
    left_0 = Left(int_0)
    res_0 = left_0.to_lazy()
    assert res_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:28:59.542668
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()

    lazy_1 = lazy_0.bind(lambda e: e)

    assert int_0 == lazy_1()



# Generated at 2022-06-25 23:29:03.374291
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    right_0 = Right(int_0)
    lazy_1 = right_0.to_lazy()
    int_1 = lazy_1.get()
    int_2 = lazy_1.get()
    assert int_1 == int_2


# Generated at 2022-06-25 23:29:03.888516
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:29:10.518017
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    right_0 = Right(int_0)
    assert right_0.to_lazy() == Lazy(lambda: int_0)
    int_1 = -2374
    right_1 = Right(int_1)
    assert right_1.to_lazy() != Lazy(lambda: int_1)
    assert right_1.to_lazy().get() != right_0.to_lazy().get()
    assert right_0.to_lazy().get() == int_0
    assert right_1.to_lazy().get() == int_1
    str_0 = 's'
    right_2 = Right(str_0)
    assert right_2.to_lazy() == Lazy(lambda: str_0)
    assert right_2.to_

# Generated at 2022-06-25 23:29:13.985394
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 42
    right_0 = Right(int_0)
    result_0 = right_0.to_lazy()
    lazy_0 = result_0.value
    result_1 = lazy_0()
    assert result_1 == int_0


# Generated at 2022-06-25 23:29:23.697062
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_maybe import Nothing
    from pymonet.monad_try import Try, Failure
    from pymonet.validation import Validation, Failure as ValidationFailure
    int_0 = -2487
    left_0 = Left(int_0)
    right_0 = Right(int_0)
    lazy_0 = Lazy(lambda: int_0)
    box_0 = Box(int_0)
    maybe_0 = Maybe(int_0)
    nothing_0 = Nothing()
    try_0 = Try(int_0)
    try_failure_0 = Try(int_0, is_success=False)

# Generated at 2022-06-25 23:29:31.904489
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    test_value_0 = left_0.to_lazy()
    expected_0 = Lazy(int_0)
    assert test_value_0 == expected_0
    int_1 = -12385
    right_1 = Right(int_1)
    test_value_1 = right_1.to_lazy()
    expected_1 = Lazy(int_1)
    assert test_value_1 == expected_1


# Generated at 2022-06-25 23:29:35.310752
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 50
    right_0 = Right(int_0)
    from pymonet.lazy import Lazy
    lazy_0 = right_0.to_lazy()
    assert lazy_0 == Lazy(lambda: int_0)



# Generated at 2022-06-25 23:29:37.463540
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()



# Generated at 2022-06-25 23:29:40.582485
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = left_0.to_lazy()
    assert left_1.value() == int_0



# Generated at 2022-06-25 23:29:48.652557
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given a value of type Integer
    int_0 = 10
    # And an instance of class Right having that value
    right_0 = Right(int_0)
    # And an instance of class Left having that value
    left_0 = Left(int_0)

    # When I call to_lazy on right_0
    lazy_0 = right_0.to_lazy()
    # And I call to_lazy on left_0
    lazy_1 = left_0.to_lazy()

    # Then lazy_0.value() is int_0
    assert lazy_0.value() == int_0
    # And lazy_1.value() is int_0
    assert lazy_1.value() == int_0



# Generated at 2022-06-25 23:29:50.589826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -19935
    right_0 = Right(int_0)

    assert right_0.to_lazy().value() == int_0



# Generated at 2022-06-25 23:29:54.807176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # try to convert Right(int) to Lazy[int]
    int_0 = 7
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == int_0, "to_lazy method of Either is broken"


# Generated at 2022-06-25 23:30:04.758957
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Either

    int_k = 2345
    int_l = -2345
    maybe_int_k = Either.Right(int_k)
    maybe_int_l = Either.Right(int_l)
    lazy_int_k = Either.Right(int_k).to_lazy()

    assert isinstance(maybe_int_k, Either)
    assert isinstance(maybe_int_k, Either.Right)
    assert isinstance(maybe_int_l, Either)
    assert isinstance(maybe_int_l, Either.Right)
    assert isinstance(lazy_int_k, Lazy)
    assert lazy_int_k.evaluate() == int_k

# Generated at 2022-06-25 23:30:07.752741
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    maybe_0 = left_0.to_lazy()
    assert hasattr(maybe_0, 'get_value')

# Generated at 2022-06-25 23:30:15.302163
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as Lazy
    int_0 = 949
    str_0 = "test"
    str_1 = "test"
    left_0 = Left(int_0)
    right_0 = Right(str_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy.Lazy)
    assert lazy_0.evaluate() == int_0
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy.Lazy)
    assert lazy_0.evaluate() == str_1


# Generated at 2022-06-25 23:30:18.826703
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == left_0.value


# Generated at 2022-06-25 23:30:27.960524
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0: Lazy[Callable[[Any], Any]] = left_0.to_lazy()
    assert lazy_0.is_lazy() is True
    int_1 = lazy_0.evaluate()
    assert int_0 == int_1
    int_2 = 1837
    right_0 = Right(int_2)
    lazy_1: Lazy[Callable[[Any], Any]] = right_0.to_lazy()
    assert lazy_1.is_lazy() is True
    int_3: int = lazy_1.evaluate()
    assert int_3 == int_2



# Generated at 2022-06-25 23:30:31.392527
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)

    laz = left_0.to_lazy()

    assert isinstance(laz, Lazy)
    assert laz.run(0) is int_0



# Generated at 2022-06-25 23:30:37.595245
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    b1 = Lazy(lambda: 5)
    b2 = Right(b1)

    # When
    res1 = b2.to_lazy()

    # Then
    res1.is_instance_of(Lazy)
    res1.is_instance_of(Either)
    res1.value().get_value() == 5

    # Given
    b3 = Lazy(lambda: 10)
    b4 = Left(b3)

    # When
    res2 = b4.to_lazy()

    # Then
    res2.is_instance_of(Lazy)
    res2.is_instance_of(Either)
    res2.value().get_value() == 10


# Generated at 2022-06-25 23:30:41.298321
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    lazy_0.force()


# Generated at 2022-06-25 23:30:51.268290
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test 1
    int_0 = -2487
    left_0 = Left(int_0)
    assert isinstance(left_0.to_lazy(), Lazy)
    # Test 2
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == int_0
    # Test 3
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.is_resolved() == False
    # Test 4
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()

# Generated at 2022-06-25 23:30:54.797915
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.__class__ is Lazy
    assert lazy_0() is left_0.value


# Generated at 2022-06-25 23:31:03.413795
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    int_0 = 10
    int_1 = 24
    right_0 = Right(int_0)
    right_1 = Right(int_1)
    lazy_0 = right_0.to_lazy()
    lazy_1 = right_1.to_lazy()
    expected_0 = Lazy(lambda: int_0)
    expected_1 = Lazy(lambda: int_1)
    success_0 = lazy_0 == expected_0
    success_1 = lazy_1 == expected_1
    assert success_0 and success_1


# Generated at 2022-06-25 23:31:09.065713
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Transform Either to Lazy
    """
    from pymonet.lazy import Lazy

    int_0 = -2487
    right_0 = Right(int_0)

    assert right_0.__eq__(right_0.to_lazy().force())
    assert right_0.is_right() == right_0.to_lazy().force().is_right()
    assert right_0.__eq__(right_0.to_lazy().force())
    assert right_0.is_right() == right_0.to_lazy().force().is_right()
    assert right_0.__eq__(right_0.to_lazy().force())
    assert right_0.is_right() == right_0.to_lazy().force().is_right()

# Generated at 2022-06-25 23:31:16.857113
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    int_0 = 12
    either_0 = Left(int_0)
    # Call
    result = either_0.to_lazy()
    # Assertions
    assert isinstance(result, Callable)
    assert isinstance(result(), int)
    assert result() == int_0
    # Cleanup
    del either_0
    del result


# Generated at 2022-06-25 23:31:21.629624
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Tests for method to_lazy of class Either
    def test_case_0():
        int_0 = -2487
        left_0 = Left(int_0)
        lazy_0 = left_0.to_lazy()
        assert lazy_0.value() == left_0.value
    test_case_0()



# Generated at 2022-06-25 23:31:30.205114
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        int_0 = -3491
        left_0 = Left(int_0)
        lazy_0 = left_0.to_lazy()
        assert lazy_0.value() == int_0, "Expect int_0 to be int_0"
        int_1 = -2408
        right_0 = Right(int_1)
        lazy_1 = right_0.to_lazy()
        assert lazy_1.value() == int_1, "Expect int_1 to be int_1"
    test_case_0()



# Generated at 2022-06-25 23:31:37.015317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def double_int(int_0: int) -> int:
        return int_0 * 2

    int_0 = -2487
    left_0 = Left(int_0)
    left_1 = left_0.to_lazy()
    assert(isinstance(left_1, Lazy))
    assert(left_1.map(double_int).value() == int_0)


# Generated at 2022-06-25 23:31:46.735364
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    expected_0 = Lazy(lambda: int_0)
    actual_0 = left_0.to_lazy()
    assert expected_0 == actual_0
    tuple_0 = (0, (1, None, 2))
    tuple_1 = (tuple_0, (-1,))
    tuple_2 = (tuple_1, ((0, -1),))
    tuple_3 = (tuple_2, (-1,))
    tuple_4 = (tuple_3, (None, (1, (-1,), (1, None, 2))))
    tuple_5 = (tuple_4, (2, (None, (0, -1))))
    tuple_6 = (tuple_5, ((0, -1),))

# Generated at 2022-06-25 23:31:54.893798
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 5
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy), "should be Lazy"
    assert callable(lazy_0.get_value), "should be callable"
    assert lazy_0.get_value() == int_0, "should be same value as in Either"
    assert not lazy_0.is_evaluated, "should be not evaluated"


# Generated at 2022-06-25 23:32:02.478466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    lazy_1 = Right(int_0).to_lazy()
    assert lazy_0.is_computed == False
    lazy_0.value
    assert lazy_0.value == int_0
    assert lazy_0.is_computed == True
    assert lazy_1.is_computed == False
    lazy_1.value
    assert lazy_1.value == int_0
    assert lazy_1.is_computed == True




# Generated at 2022-06-25 23:32:10.144521
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 2487
    int_1 = -2487
    left_0 = Left(int_0)
    left_1 = Left(int_1)
    right_0 = Right(int_0)
    right_1 = Right(int_1)
    var_0 = right_0.to_lazy()
    var_1 = right_0.to_lazy()
    var_2 = left_1.to_lazy()
    var_3 = left_1.to_lazy()
    var_4 = right_0.to_lazy()
    var_5 = left_1.to_lazy()
    var_6 = right_0.to_lazy()
    var_7 = left_1.to_lazy()
    var_8 = left_1.to_lazy()

# Generated at 2022-06-25 23:32:18.261941
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 487
    left_0: Either[int, str] = Left(int_0)
    lazy_left_0: Lazy[Callable[[], int]] = left_0.to_lazy()
    int_1 = lazy_left_0.unwrap()()
    int_2 = int_0
    assert int_1 == int_2
    str_0 = "***"
    right_0: Either[int, str] = Right(str_0)
    lazy_right_0: Lazy[Callable[[], str]] = right_0.to_lazy()
    int_3 = lazy_right_0.unwrap()()
    int_4 = str_0
    assert int_3 == int_4



# Generated at 2022-06-25 23:32:21.945352
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 8117
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    lazy_0_result = lazy_0.get()
    assert int_0 == lazy_0_result


# Generated at 2022-06-25 23:32:31.725337
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def to_lazy(arg0):
        if isinstance(arg0, Either):
            instance = arg0.to_lazy()
            return arg0
        else:
            return either_0
    _0_Left_bool = True
    if (isinstance(either_0, Left) == _0_Left_bool):
        return either_0.to_lazy()
    else:
        return either_0


# Generated at 2022-06-25 23:32:36.147076
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -2487
    left_0 = Left(int_0)
    assert isinstance(left_0.to_lazy(), Lazy)

    float_0 = float(9317.0)
    right_0 = Right(float_0)
    assert isinstance(right_0.to_lazy(), Lazy)


# Generated at 2022-06-25 23:32:45.544668
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    lazy_0.get()
    lazy_0.is_computed()
    int_1 = -2487
    maybe_0 = Maybe.just(int_1)
    maybe_1 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    lazy_1.is_computed()
    int_2 = -2487
    right_0 = Right(int_2)
    lazy_2 = right_0.to_lazy()
    lazy_2.is_computed()
    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.to_lazy()
    lazy_3 = maybe_3

# Generated at 2022-06-25 23:32:47.255368
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    either_0 = Either(int_0)


# Generated at 2022-06-25 23:32:49.363835
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:32:52.476677
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:32:58.368977
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    monad_0_maybe = Either.to_lazy(Maybe.just(Lazy(lambda: 24)))
    monad_0_try = Either.to_lazy(Try(None, is_success=False))

    assert monad_0_maybe.value() == 24
    assert monad_0_try.value().is_failure()



# Generated at 2022-06-25 23:33:00.695162
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.force() == int_0


# Generated at 2022-06-25 23:33:02.851250
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Right(4).to_lazy()
    assert result == Lazy(lambda: 4)

    result = Left(4).to_lazy()
    assert result == Lazy(lambda: 4)


# Generated at 2022-06-25 23:33:11.032506
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.evaluate() == int_0
    assert isinstance(lazy_0, type(left_0.to_lazy()))
    assert lazy_0 == left_0.to_lazy()
    float_1 = -2.74859122
    str_0 = 'foo'
    right_0 = Right(float_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.evaluate() == float_1
    assert isinstance(lazy_1, type(right_0.to_lazy()))
    assert lazy_1 == right_0.to_lazy()
    right_1 = Right(str_0)

# Generated at 2022-06-25 23:33:19.849670
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    n = 0
    f = lambda: n
    l = Lazy(f)
    l.__str__() == 'Lazy<Function to be called>'
    l.__repr__() == 'Lazy<Function to be called>'
    l.value == 0
    n = 1
    l.value == 1


# Generated at 2022-06-25 23:33:25.889488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Left(bool_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.map(bool_0)
    str_0 = lazy_1.value()
    assert str_0 == bool_0
    bool_1 = False
    either_1 = Right(bool_1)
    lazy_2 = either_1.to_lazy()
    lazy_3 = lazy_2.map(bool_1)
    str_1 = lazy_3.value()
    assert str_1 == bool_1


# Generated at 2022-06-25 23:33:31.143434
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    right_value = 1
    right = Right(right_value)

    # When
    lazy_from_right = right.to_lazy()

    # Then
    assert lazy_from_right.value() == right_value

    # Given
    left_value = 3
    left = Left(left_value)

    # When
    lazy_from_left = left.to_lazy()

    # Then
    assert lazy_from_left.value() == left_value



# Generated at 2022-06-25 23:33:33.606057
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(True).to_lazy() == Lazy(lambda: True)
    assert Left(True).to_lazy() == Lazy(lambda: True)



# Generated at 2022-06-25 23:33:34.960109
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    print(bool_0)



# Generated at 2022-06-25 23:33:38.329210
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # int -> str
    func = lambda x: str(x)
    # create Either with int
    either = Right(10)
    try:
        # call to_lazy method
        lazy = either.to_lazy()
        # check lazy is Lazy
        assert isinstance(lazy, Lazy)
        # check lazy contain function which return 10
        assert lazy.force() == 10
        bool_0 = True
    except:
        bool_0 = False
    # assert bool_0 == True
    assert bool_0


# Generated at 2022-06-25 23:33:39.804894
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1



# Generated at 2022-06-25 23:33:41.529513
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy() == Lazy(lambda: 5)

    assert Left(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-25 23:33:45.195752
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Case 1: when either is right
    right_0 = Right(3)
    assert right_0.to_lazy() == Lazy(lambda: right_0.value)

    # Case 2: when either is left
    left_0 = Left(5)
    assert left_0.to_lazy() == Lazy(lambda: left_0.value)


# Generated at 2022-06-25 23:33:47.261380
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(3).to_lazy().value() == 3
    assert Right(3).to_lazy().value() == 3


# Generated at 2022-06-25 23:34:03.606651
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print("Case 0")
    from pymonet.lazy import Lazy

    lazy = Right(42).to_lazy()
    assert(lazy == Lazy(lambda: 42))
    print("OK")



# Generated at 2022-06-25 23:34:13.849601
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda x: x
    g = lambda x: x + 1
    h = lambda x: x * x

    assert isinstance(Right(f).to_lazy(), Lazy)
    assert Right(f).to_lazy().value() == f
    assert isinstance(Right(Right(g)).to_lazy(), Lazy)
    assert Right(Right(g)).to_lazy().value() == g
    assert isinstance(Right(Right(Right(h))).to_lazy(), Lazy)
    assert Right(Right(Right(h))).to_lazy().value() == h
    assert isinstance(Left(f).to_lazy(), Lazy)
    assert Left(f).to_lazy().value() == f

# Generated at 2022-06-25 23:34:20.212911
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    value_0 = "Hello"
    value_1 = "World"
    value_2 = "!!!"
    value_3 = Lazy(lambda: value_0 + " " + value_1 + value_2).value()
    value_4 = Right(value_0).to_lazy().value() + " " +\
        Right(value_1).to_lazy().value() +\
        Right(value_2).to_lazy().value()
    value_5 = Left(value_0).to_lazy().value() + " " +\
        Left(value_1).to_lazy().value() +\
        Left(value_2).to_lazy().value()
    assert value_3 == value_4
    assert value_3 == value_5


# Generated at 2022-06-25 23:34:23.382189
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = isinstance(Left(1).to_lazy(), Lazy)
    bool_1 = isinstance(Right(1).to_lazy(), Lazy)
    assert(bool_0 and bool_1)


# Generated at 2022-06-25 23:34:27.065624
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Empty
    assert Left('error').to_lazy().get_value() == 'error'
    assert Right('value').to_lazy().get_value() == 'value'


# Generated at 2022-06-25 23:34:34.110611
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    bool_1 = False
    box = Box(bool_0)
    bool_2 = bool_1
    if to_lazy is not None:
        bool_2 = isinstance(to_lazy, Lazy)
    bool_3 = bool_1
    if to_lazy is not None:
        bool_3 = (to_lazy.get() == bool_0)
    bool_4 = bool_2 and bool_3
    bool_5 = bool_4
    return bool_5


# Generated at 2022-06-25 23:34:43.396971
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def test_success(n: int) -> bool:
        bool_0 = isinstance(Right(1).to_lazy(), Lazy)
        bool_1 = Right(1).to_lazy().evaluate() == 1
        bool_2 = Right(2).to_lazy().evaluate() == 2
        bool_3 = Right(3).to_lazy().evaluate() == 3
        bool_4 = Right(4).to_lazy().evaluate() == 4

        return bool_0 and bool_1 and bool_2 and bool_3 and bool_4

    def test_fail(n: int) -> bool:
        bool_0 = isinstance(Left(1).to_lazy(), Lazy)
        bool_1 = Left(1).to_lazy().evaluate() == 1


# Generated at 2022-06-25 23:34:47.739547
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test 0
    assert Either(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:34:50.845537
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True


# Generated at 2022-06-25 23:34:53.754466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)


# Generated at 2022-06-25 23:35:22.671704
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 0
    int_1 = 1
    error_0 = Left(int_0)

    def error_handler(value): return int_1

    def success_handler(value): return value

    result_0 = error_0.case(error_handler, success_handler)

    print(result_0)

# Generated at 2022-06-25 23:35:30.125262
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Set up test cases
    def _case_0():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1

    def _case_1():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1

    def _case_2():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1

    def _case_3():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1

    def _case_4():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1

    def _case_5():
        bool_0 = True
        bool_1 = True
        return bool_0 and bool_1



# Generated at 2022-06-25 23:35:37.845983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Either can transform to Lazy
    def test_case_0():
        # prepare
        from random import randint
        from pymonet.lazy import Lazy
        from pymonet.either import Either, Right, Left
        from typing import Callable, Any

        # prepare
        a = randint(0, 100)
        b = randint(0, 100)
        lazy_int_0 = Lazy(lambda: a)
        # do
        either_0 = Either(lazy_int_0)
        either_1 = Either(int)
        lazy_int_1 = either_0.to_lazy()
        lazy_int_2 = either_1.to_lazy()

        def func_0() -> Callable[[Any], Any]:
            return int


# Generated at 2022-06-25 23:35:39.515471
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    _lazy_0 = Right(1).to_lazy()
    _lazy_0.value()


# Generated at 2022-06-25 23:35:41.748335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_value = 1
    right_0 = Right(test_value)

    result_0 = right_0.to_lazy()
    assert result_0.value() == test_value


# Generated at 2022-06-25 23:35:43.262202
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Left(1).to_lazy()
    assert result == Lazy(lambda: 1)


# Generated at 2022-06-25 23:35:45.612867
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().get_value() == 1
    assert Left(1).to_lazy().get_value() == 1


# Generated at 2022-06-25 23:35:47.437333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value_0 = Either.to_lazy(Either(2))

    assert isinstance(value_0, Lazy)
    assert value_0.value() == 2


# Generated at 2022-06-25 23:35:50.263560
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e = Right(1)
    l = e.to_lazy()
    assert l() == 1
    e = Left(0)
    l = e.to_lazy()
    assert l() == 0


# Generated at 2022-06-25 23:35:51.953762
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(0).to_lazy().value() == 0
    assert Left(0).to_lazy().value() == 0


# Generated at 2022-06-25 23:36:17.931793
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Right('test').to_lazy()
    expected = 'test'
    assert result == expected

# Generated at 2022-06-25 23:36:24.801357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Local settings
    from pymonet.lazy import Lazy
    int_0 = -2487
    # Right case
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    # Verify type
    assert isinstance(lazy_0, Lazy)
    # Verify value
    assert lazy_0.value() == int_0
    # Left case
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:36:29.600096
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -2487
    left_0 = Left(int_0)
    assert left_0.to_lazy() == Lazy(lambda: int_0)
    int_1 = -1590
    right_0 = Right(int_1)
    assert right_0.to_lazy() == Lazy(lambda: int_1)


# Generated at 2022-06-25 23:36:35.964044
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    int_1 = -1045
    left_1 = Left(int_1)
    lazy_1 = left_1.to_lazy()
    int_2 = -1106
    left_2 = Left(int_2)
    lazy_2 = left_2.to_lazy()
    assert lazy_0.value() == int_0
    assert lazy_1.value() == int_1
    assert lazy_2.value() == int_2


# Generated at 2022-06-25 23:36:43.626393
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for Left, value is int
    int_0 = -2487
    left_0 = Left(int_0)
    from pymonet.lazy import Lazy
    Lazy_0 = Lazy()
    Lazy_1 = left_0.to_lazy()
    assert Lazy_0.equals(Lazy_1) is True
    # Test for Left, value is str
    str_0 = "jhgfjsdgfjkhsdkgvdfg"
    left_1 = Left(str_0)
    Lazy_2 = left_1.to_lazy()
    assert Lazy_0.equals(Lazy_2) is True
    # Test for Left, value is bool
    bool_0 = False
    left_2 = Left(bool_0)
    Lazy

# Generated at 2022-06-25 23:36:48.339211
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    int_1 = 1803
    left_1 = Left(int_1)
    either_0 = left_0
    lazy_0 = either_0.to_lazy()
    boolean_0 = lazy_0.is_strict()
    assert boolean_0



# Generated at 2022-06-25 23:36:52.146100
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 5333
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.force() == int_0


# Generated at 2022-06-25 23:36:54.975453
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert callable(lazy_0.value)
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:37:00.766185
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -2487
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()

    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:37:08.891932
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.validation_failure import Failure

    _try_0 = Try[int](42)
    _try_1 = Try[float]((lambda: 2.0))
    _lazy_0 = Lazy[int](lambda: 42)
    _maybe_0 = Maybe[int](42)
    _box_0: Box[int] = Box(42)
    _validation_0 = Validation.success[int](42)
    _validation_1 = Validation.fail[Failure[int]]([Failure(42)])
