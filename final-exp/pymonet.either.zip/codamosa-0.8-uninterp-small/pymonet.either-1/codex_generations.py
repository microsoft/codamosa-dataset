

# Generated at 2022-06-25 23:27:33.712084
# Unit test for method case of class Either
def test_Either_case():
    int_0 = 3
    either_1 = Right(int_0)
    either_2 = Left(int_0)
    assert either_1.case(lambda y: y, lambda y: y) == 3
    assert either_2.case(lambda y: y, lambda y: y) == 3


# Generated at 2022-06-25 23:27:43.083990
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = -3416.2
    float_1 = -1416.2
    float_2 = -3416.2
    float_3 = -3415.2
    left_0 = Left(float_1)
    left_1 = Left(float_1)
    left_2 = Left(float_2)
    left_3 = Left(float_3)
    right_0 = Right(float_1)
    right_1 = Right(float_1)
    right_2 = Right(float_2)
    right_3 = Right(float_3)
    assert left_0 == left_0
    assert left_0 != left_1
    assert left_0 != left_2
    #assert left_0 != left_3
    assert left_0 != right_0
    assert left_0 != right_

# Generated at 2022-06-25 23:27:50.654551
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = -3416.2
    either_0 = Either(float_0)
    either_1 = Either(float_0)
    assert either_0 == either_1
    float_1 = 7791.1
    either_2 = Either(float_1)
    assert either_0 != either_2
    float_2 = -7906.6
    either_3 = Either(float_2)
    assert either_0 != either_3
    int_0 = -24654
    either_4 = Either(int_0)
    assert either_0 != either_4


# Generated at 2022-06-25 23:27:54.172128
# Unit test for method case of class Either
def test_Either_case():
    assert Either(0).case(error=lambda x: x / 0, success=lambda x: x + 1) == 1
    assert Either(0).case(error=lambda x: x + 1, success=lambda x: x / 0) == 1


# Generated at 2022-06-25 23:28:01.527210
# Unit test for method case of class Either
def test_Either_case():
    float_0 = -3416.2
    either_0 = Either(float_0)

    int_0 = 12
    either_1 = Either(int_0)

    either_2 = Right(either_0.value)

    str_0 = "ywHcwi26bk"
    str_1 = "e6PX2YiFzj"
    str_2 = "5i51bt36hG"
    str_3 = "kNXl1fNtIQ"
    str_4 = "ywHcwi26bk"
    str_5 = "e6PX2YiFzj"


    str_6 = "ywHcwi26bk"
    str_7 = "e6PX2YiFzj"

# Generated at 2022-06-25 23:28:06.077743
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = -3416.2
    either_0 = Left(float_0)
    either_1 = Right(either_0.value)
    right_0 = True
    right_1 = either_0 == either_1
    assert right_0 == right_1


# Generated at 2022-06-25 23:28:17.235539
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Left(3) == Left(3)
    assert Left(3) != Right(3)
    assert Right(3) == Right(3)

    assert Left(Try(4)).to_try() == Left(4).to_try()
    assert Right(Try(4)).to_try() == Right(4).to_try()

    assert Left(Box(4)).to_box() == Left(4).to_box()
    assert Right(Box(4)).to_box() == Right(4).to_box()

    assert Left(Lazy(lambda: 4)).to_lazy() == Left

# Generated at 2022-06-25 23:28:19.027615
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either.right(23.89)
    assert either_0.to_lazy().value() == 23.89
    either_1 = Either.left(23.89)
    assert either_1.to_lazy().value() == 23.89



# Generated at 2022-06-25 23:28:21.754703
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = -3416.2
    either_0 = Either(float_0)
    either_1 = Either(float_0)
    bool_0 = either_0 == either_1
    assert bool_0 is True


# Generated at 2022-06-25 23:28:32.251441
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    float_0 = -3416.2
    either_0 = Either(float_0)
    either_1 = Right(either_0)
    either_2 = Left(either_1)
    either_3 = Left(either_0)
    float_1 = either_1.case(error=lambda x: x, success=lambda x: float(x))
    float_2 = either_2.case(error=lambda x: x, success=lambda x: float(x))
    float_3 = either_3.case(error=lambda x: x, success=lambda x: float(x))

# Generated at 2022-06-25 23:28:40.553884
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right, Either

    float_0 = 23.89
    left_0 = Left(float_0)
    right_0 = Right(float_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == float_0
    lazy_1  = left_0.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == float_0


# Generated at 2022-06-25 23:28:41.359791
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:28:45.658965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    try_0 = Try(23.89, is_success=True)

    either_0 = Either(try_0)

    try_1 = try_0.to_lazy()

    assert either_0.value == try_1


# Generated at 2022-06-25 23:28:51.565152
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Case: Either successful
    float_0 = 23.89
    right_0 = Right(float_0)

    assert right_0.to_lazy().value() == float_0

    # Case: Either unsuccessful
    str_0 = 'string'
    left_0 = Left(str_0)

    assert left_0.to_lazy().value() == str_0


# Generated at 2022-06-25 23:28:55.344474
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 23.89

    # Right
    assert Right(float_0).to_lazy().get() == float_0

    # Left
    assert Left(float_0).to_lazy().get() == float_0


# Generated at 2022-06-25 23:29:00.412933
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(0).to_lazy() == Lazy(lambda: 0)
    assert Left(1.72).to_lazy() == Lazy(lambda: 1.72)
    assert Right(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-25 23:29:07.422271
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    failure_0 = Left(23.89)
    lazy_0 = failure_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    # Assert type of value stored in lazy is function
    assert callable(lazy_0.value)

    success_0 = Right(3)
    lazy_1 = success_0.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert callable(lazy_1.value)

    assert lazy_0.value() == 23.89
    assert lazy_1.value() == 3



# Generated at 2022-06-25 23:29:15.643929
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def send_email():
        return 'Email sent to user'

    either_right_send_email = Right(send_email)
    lazy_send_email = either_right_send_email.to_lazy()
    # Check if lazy returns expected value
    assert lazy_send_email.evaluate() == send_email()


# Generated at 2022-06-25 23:29:18.369468
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = Right(43)
    assert value.to_lazy().value() == value.value

    value = Left(43)
    assert value.to_lazy().value() == value.value



# Generated at 2022-06-25 23:29:20.555838
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(23.89).to_lazy().value() == 23.89
    assert Left(23.89).to_lazy().value() == 23.89


# Generated at 2022-06-25 23:29:25.759791
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    t = Try(42)
    lazy = t.to_lazy()
    assert lazy == Lazy(lambda: 42)


# Generated at 2022-06-25 23:29:29.780348
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    lazy_0.get_value()


# Generated at 2022-06-25 23:29:39.258937
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Create new float_0 with value -3416.2, and float_1 with value -0.0, float_2 with value 56.66
    float_0 = -3416.2
    float_1 = -0.0
    float_2 = 56.66

    # Create new Either with value float_0 and float_2
    either_0 = Either(float_0)
    either_1 = Either(float_1)
    either_2 = Either(float_2)

    # Create new Lazy with lambda function returning float_0, float_1 and float_2
    lazy_0 = Either(float_0).to_lazy()
    lazy_1 = Either(float_1).to_lazy()
    lazy_2 = Either(float_2).to_lazy()

    # Check if lazy_0, lazy_

# Generated at 2022-06-25 23:29:40.888918
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5.5).to_lazy() == Lazy(lambda: 5.5)


# Generated at 2022-06-25 23:29:44.277432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)

    lazy_0 = either_0.to_lazy()
    bool_0 = lazy_0.is_computed()
    assert bool_0


# Generated at 2022-06-25 23:29:46.538067
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    number = 0xFF
    either = Either(number)
    lazy = either.to_lazy()
    assert number == lazy.run()


# Generated at 2022-06-25 23:29:51.561848
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    float_0 = -3416.2
    try_0 = Try(float_0, is_success=False)
    lazy_0 = Lazy(lambda: float_0)
    box_0 = Box(float_0)
    maybe_0 = Maybe.nothing()
    validation_0 = Validation.fail([float_0])

    either_0 = Either.to_lazy(float_0)
    assert type(either_0) == Left
    assert either_0.to_lazy() == Lazy(lambda: float_0)

# Generated at 2022-06-25 23:29:54.317892
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either_0 = Either(float())
    result_0 = either_0.to_lazy()
    assert isinstance(result_0, Lazy)


# Generated at 2022-06-25 23:29:58.057222
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        str_0 = '5'
        either_0 = Either(str_0)
        lazy_0 = either_0.to_lazy()
        assert lazy_0.value() == str_0

# Generated at 2022-06-25 23:30:04.438868
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from nose_parameterized import parameterized

    @parameterized.expand([
        (Either(2.1), Lazy(lambda: 2.1)),
        (Left(2.1), Lazy(lambda: 2.1)),
        (Right(12.6), Lazy(lambda: 12.6))
    ])
    def test_Either_to_lazy(either, expected_lazy):
        assert(either.to_lazy() == expected_lazy)


# Generated at 2022-06-25 23:30:10.777609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Create test dict
    dict_test = {
        'test': 'test'
    }

    # Create instance of Either
    either_0 = Either(dict_test)

    # Create instance of Lazy
    lazy_0 = either_0.to_lazy()

    # Test call of function in Lazy
    assert lazy_0.value() == dict_test


# Generated at 2022-06-25 23:30:13.276315
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = -3416.2
    lazy_0 = Either(float_0).to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:30:17.883460
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Unit test for method to_lazy of class Either with Right
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: "abc")
    either_0 = Either(lazy_0)

    lazy_1 = either_0.to_lazy()

    assert lazy_1.call() == lazy_0.call()



# Generated at 2022-06-25 23:30:21.789117
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 15
    either_0 = Either(int_0)
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: int_0)
    Assert.equals(lazy_0, either_0.to_lazy())


# Generated at 2022-06-25 23:30:25.016195
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Expected value: Lazy(<function <lambda> at 0x7ff42ce25400>)
    either_0 = Either(2.75)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:30:28.501383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(0.2)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.resolve() == 0.2


# Generated at 2022-06-25 23:30:36.190324
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def get_value(value):
        return value

    either_float_0 = Either(3.14)
    lazy_either_float_0 = either_float_0.to_lazy()
    assert isinstance(lazy_either_float_0, Lazy)
    assert lazy_either_float_0.value == get_value(either_float_0.value)

    either_str_0 = Either('I love python')
    lazy_either_str_0 = either_str_0.to_lazy()
    assert isinstance(lazy_either_str_0, Lazy)
    assert lazy_either_str_0.value == get_value(either_str_0.value)


# Generated at 2022-06-25 23:30:38.308328
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    try:
        Either.to_lazy()
    except NotImplementedError as e:
        assert str(e) == "Method not Created"



# Generated at 2022-06-25 23:30:42.496065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    lazy_0 = Either(float_0).to_lazy()
    float_1 = lazy_0.empty().value
    assert float_0 == float_1


# Generated at 2022-06-25 23:30:45.789149
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert float_0 == lazy_0.value()


# Generated at 2022-06-25 23:30:56.753938
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    either_float_0 = Either(13.0)

    lazy_0 = either_float_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 13.0

    either_float_1 = Either(13.0)

    lazy_1 = either_float_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == 13.0



# Generated at 2022-06-25 23:31:02.517499
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    string_0 = "abc"
    either_0 = Either(string_0)
    # Exercise
    result = either_0.to_lazy()
    # Verify
    assert result.value() == string_0


# Generated at 2022-06-25 23:31:09.923137
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    value_0 = 'test_Either_to_lazy.value_0'
    either_0 = Either(value_0)
    monad_0 = either_0.to_lazy()
    assert monad_0 == Lazy(lambda: value_0)
    assert monad_0.get() == value_0
    # Test if this is really lazy
    assert isinstance(monad_0, Lazy)



# Generated at 2022-06-25 23:31:14.626445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 45.5
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.eval()
    assert lazy_1 == float_0

# Generated at 2022-06-25 23:31:17.893567
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:31:28.653192
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert callable(lazy_0.value)
    assert lazy_0.value() == float_0
    bool_0 = bool(lazy_0)
    assert bool_0 is True
    lazy_0.force()
    bool_1 = bool(lazy_0)
    assert bool_1 is True
    int_0 = hash(lazy_0)
    assert int_0 == 764300894
    str_0 = repr(lazy_0)
    assert str_0 == 'Lazy(3694335912)'


# Generated at 2022-06-25 23:31:35.638587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -2219.68
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = float_0
    assert float_1 == lazy_0.value()
    float_2 = float_0
    either_1 = Either(float_2)
    lazy_1 = either_1.to_lazy()
    float_3 = float_0
    assert float_3 == lazy_1.value()
    float_4 = float_0
    either_2 = Either(float_4)
    lazy_2 = either_2.to_lazy()
    float_5 = float_0
    assert float_5 == lazy_2.value()
    float_6 = float_0
    either_3 = Either(float_6)
    lazy

# Generated at 2022-06-25 23:31:38.673791
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy = Lazy(lambda: 3.2)
    either = lazy.to_either()
    assert either.to_lazy() == lazy


# Generated at 2022-06-25 23:31:45.513503
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.value
    assert float_1 == float_0


# Generated at 2022-06-25 23:31:56.287479
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = -3416.2
    float_1 = -636.81
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    result = lazy_0.value()

    if not isinstance(lazy_0, Lazy):
        raise AssertionError('Expected result to be instance of Lazy, but got {}'.format(type(lazy_0)))

    assert isinstance(lazy_0, Lazy)
    assert result == (-3416.2, )

    either_1 = Either(float_1)
    lazy_1 = either_1.to_lazy()
    result = lazy_1.value()

    assert isinstance(lazy_1, Lazy)

# Generated at 2022-06-25 23:32:06.252821
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    float_1 = float_0
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_2 = lazy_0.value
    assert_close(float_1, float_2)
    float_3 = lazy_0.value
    assert_close(float_1, float_3)



# Generated at 2022-06-25 23:32:08.262569
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 261.65
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == either_0.value


# Generated at 2022-06-25 23:32:14.469213
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    from pymonet.validation import Validation

    int_0 = 13847
    either_0 = Either(int_0)

    either_1 = either_0.to_lazy()

    assert(type(either_1) is Lazy)
    assert(either_1.value is not int_0)
    assert(either_1.value() is int_0)
    either_1.value = None
    assert(either_1.is_memoized is False)



# Generated at 2022-06-25 23:32:18.149466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1.5e-9
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == float_0


# Generated at 2022-06-25 23:32:21.545344
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 100.0
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.value()

    assert float_0 == float_1


# Generated at 2022-06-25 23:32:25.174205
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_lazy import Lazy
    def func_x():
        return 15
    def func_y():
        return 15
    assert Either(func_x).to_lazy().get_value() == Lazy(func_y).get_value()


# Generated at 2022-06-25 23:32:30.599092
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_1 = Either(float_0)
    lazy_0 = either_1.to_lazy()
    assert(lazy_0.__str__() == "Lazy(function)")
    float_1 = float_0 + float_0
    assert(lazy_0.value == float_0)
    float_2 = float_1
    float_1 = float_2 + float_1
    float_2 = float_2 + float_2


# Generated at 2022-06-25 23:32:33.871667
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    either_0 = Either(929.0)
    lazy_1 = either_0.to_lazy()
    assert lazy_1.value() == 929.0
    assert isinstance(lazy_1, Lazy)


# Generated at 2022-06-25 23:32:42.723295
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Case 1:
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == float_0

    # Case 2:
    either_1 = Right(0.0)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.value() == 0.0

    # Case 3:
    str_0 = 'test'
    either_2 = Left(str_0)
    lazy_2 = either_2.to_lazy()
    assert lazy_2.value() == str_0

    # Case 4:
    double_0 = -0.493513376928
    either_3 = Right(double_0)
    lazy_3 = either_3

# Generated at 2022-06-25 23:32:45.914411
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = 42
    either = Either(value)
    lazy = either.to_lazy()
    assert lazy.get() == value


# Generated at 2022-06-25 23:33:05.821397
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(num: int) -> int:
        return num + 1
    def mult(num: int) -> int:
        return num * 2
    
    int_0: int = 5
    either_0: Either[int] = Either(int_0)
    lazy_0: Lazy[Callable[[], int]] = either_0.to_lazy()
    assert lazy_0.fold(add, mult) == 10



# Generated at 2022-06-25 23:33:08.904592
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    assert Either(Box(124)) == Either(124).to_lazy()
    assert Either(Lazy(lambda: 124)) == Either(124).to_lazy()


# Generated at 2022-06-25 23:33:11.971579
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == float_0


# Generated at 2022-06-25 23:33:17.445846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_0 = u"𝗵𝗮𝗽𝗽𝘆"
    either_0 = Either(string_0)

    # Call Either.to_lazy()
    lazy_0 = either_0.to_lazy()

    # Check lazy_0 content
    assert lazy_0.value.is_function()
    assert lazy_0.value.call().is_string(string_0)


# Generated at 2022-06-25 23:33:18.874426
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    case_0 = Either(2)
    either_0 = case_0.to_lazy()


# Generated at 2022-06-25 23:33:21.232209
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -1844
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:33:24.297408
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.get_value()
    assert float_0 == float_1


# Generated at 2022-06-25 23:33:26.276082
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Either(1)

    assert either.to_lazy().value() == either.value
    assert either.to_lazy().value() == 1


# Generated at 2022-06-25 23:33:28.862946
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.get() == float_0



# Generated at 2022-06-25 23:33:30.890389
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(5.49)
    assert either_0.to_lazy().value() == 5.49


# Generated at 2022-06-25 23:34:16.157114
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda : float_0)
    lazy_1 = either_0.to_lazy()
    assert lazy_0 == lazy_1
    string_0 = 'WKz8)v<9'
    either_1 = Either(string_0)
    lazy_2 = Lazy(lambda : string_0)
    lazy_3 = either_1.to_lazy()
    assert lazy_2 == lazy_3


# Generated at 2022-06-25 23:34:24.977460
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    return
    float_0 = 14.824584382161268
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: float_0)


# Generated at 2022-06-25 23:34:31.851538
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    result = Lazy(lambda: 1).map(add1).to_maybe().\
        map(add1).map(add1).map(add1).bind(add2).map(add1).value()
    assert(result == 7)



# Generated at 2022-06-25 23:34:37.816796
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = -2713.83
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: float_0)


# Generated at 2022-06-25 23:34:40.660010
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Either(1)
    right_0_lazy = right_0.to_lazy()
    right_0_value = right_0_lazy.value()
    assert right_0_value == 1


# Generated at 2022-06-25 23:34:48.094872
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Either[A](A) -> Lazy[A]
    test_cases = [
        [Right(0), Lazy(lambda: 0)],
        [Left(0), Lazy(lambda: 0)]
    ]
    for test_case in test_cases:
        assert test_case[0].to_lazy() == test_case[1],\
            f'Expected {test_case[1]} but got {test_case[0].to_lazy()}'


# Generated at 2022-06-25 23:34:54.225550
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = -1880.42
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: float_0)



# Generated at 2022-06-25 23:34:56.843527
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Lazy(lambda: 4)
    either = Either(4)
    assert either.to_lazy() == lazy


# Generated at 2022-06-25 23:34:59.775980
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)

    value0 = either_0.to_lazy()

    print(value0)
    assert value0 == Lazy(lambda: -3416.2)



# Generated at 2022-06-25 23:35:03.867870
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    maybe_0 = lazy_0.force()

    assert lazy_0.is_lazy()
    assert hasattr(lazy_0, "value")
    assert lazy_0.value is None
    assert maybe_0 is None



# Generated at 2022-06-25 23:36:30.269527
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _two():
        return 2

    def f():
        return Either.of(3)

    assert _two() == f().to_lazy()()


# Generated at 2022-06-25 23:36:38.199699
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test 1, Left
    try:
        # ARRANGE #
        float_0 = -3416.2
        either_0 = Left(float_0)
        # ACT #
        lazy_0 = either_0.to_lazy()
        # ASSERT #
        assert lazy_0.memo == float_0
        assert lazy_0(None) == float_0
    except Exception as e:
        if e is ZeroDivisionError:
            raise Exception
        else:
            raise AssertionError("Unexpected exception was thrown")
    else:
        pass
    # Test 2, Right

# Generated at 2022-06-25 23:36:40.110337
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result_expected = Lazy(lambda: 4)
    result_received = Either.to_lazy(4)
    assert result_received == result_expected



# Generated at 2022-06-25 23:36:48.784498
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left
    from pymonet.lazy_test import correct_lazy_return_value

    for value in [43.45, 12, 'azb', [1, 2], (1, 2), {'a': 0}, set([1, 2])]:
        either = Right(value)
        lazy = either.to_lazy()
        assert isinstance(lazy, Lazy)
        assert isinstance(either.to_lazy(), Lazy)
        assert both_monads_have_equal_values(either, lazy)
        assert correct_lazy_return_value(lazy, value)


# Generated at 2022-06-25 23:36:52.679066
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for class Either
    float_0 = 34.46
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value == float_0


# Generated at 2022-06-25 23:37:03.574920
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.__class__ == Lazy
    assert lazy_0.value() == float_0
    str_0 = ':5B57'
    either_1 = Either(str_0)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.__class__ == Lazy
    assert lazy_1.value() == str_0
    int_0 = -1165485874
    either_2 = Either(int_0)
    lazy_2 = either_2.to_lazy()
    assert lazy_2.__class__ == Lazy
    assert lazy_2.value() == int_0

# Generated at 2022-06-25 23:37:09.622432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.state import State
    from pymonet.lazy import Lazy
    from pymonet.string import String
    from pymonet.list import List

    float_0 = 5654.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()

    assert lazy_0.get() == float_0
    assert lazy_0.get() is float_0


# Generated at 2022-06-25 23:37:15.539153
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    float_0 = -3416.2
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    if isinstance(lazy_0, Lazy):
        if lazy_0.value() == float_0:
            str_0 = '-3416.2'
            either_1 = Either(str_0)
            lazy_1 = either_1.to_lazy()
            if isinstance(lazy_1, Lazy):
                if lazy_1.value() == str_0:
                    int_0 = 35469


# Generated at 2022-06-25 23:37:18.313737
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    assert Lazy(Box(4).value) == (Box(4).to_lazy())
    assert Lazy(Box('asdasd').value) == (Box('asdasd').to_lazy())



# Generated at 2022-06-25 23:37:29.534575
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Create new instance of Either with different value
    string_0 = '0123456789'
    either_0 = Either(string_0)

    # Create new instance of Lazy expected as result of calling either_0.to_lazy()
    lazy_0 = Lazy(lambda: string_0)

    # assert either_0.to_lazy() == lazy_0
    assert either_0.to_lazy().value() == lazy_0.value()

