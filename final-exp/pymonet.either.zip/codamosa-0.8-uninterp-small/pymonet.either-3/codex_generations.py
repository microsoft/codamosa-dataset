

# Generated at 2022-06-25 23:27:35.438254
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = False
    right_0 = Right(bool_0)
    right_1 = Right(bool_0)
    bool_1 = right_0 == right_1
    assert bool_1 == True


# Generated at 2022-06-25 23:27:45.032697
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = False
    str_0 = 'true'
    str_1 = 'false'
    left_0 = Left(bool_0)
    left_1 = Left(str_0)
    left_2 = Left(str_1)
    left_3 = Left(bool_0)
    left_4 = Left(str_1)
    right_0 = Right(bool_0)
    right_1 = Right(str_0)
    right_2 = Right(str_1)
    right_3 = Right(bool_0)
    right_4 = Right(str_1)
    assert left_0 == left_3
    assert not left_0 == left_1
    assert not left_0 == left_2
    assert not left_0 == left_4
    assert left_1 == left_2
   

# Generated at 2022-06-25 23:27:54.091112
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert isinstance(Right(42), Either)
    assert Right(42).__eq__(Right(42))
    expect_result = False
    actual_result = Right(42).__eq__(42)
    assert expect_result == actual_result
    expect_result = False
    actual_result = Right(42).__eq__(False)
    assert expect_result == actual_result
    expect_result = False
    actual_result = Right(42).__eq__(Left(42))
    assert expect_result == actual_result
    expect_result = False
    actual_result = Right(42).__eq__(Right(42.0))
    assert expect_result == actual_result



# Generated at 2022-06-25 23:27:59.451437
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = False
    right_0 = Right(bool_0)
    right_1 = Right(bool_0)
    left_0 = Left(bool_0)
    assert right_0 == right_1
    assert not right_0 == left_0
    assert not right_0 == right_0.value
    assert not right_1 == left_0
    assert not right_1 == right_1.value


# Generated at 2022-06-25 23:28:06.632681
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right_0 = Right(0)
    right_1 = Right(0)
    assert right_0 == right_1
    assert right_0 != Right(1)
    assert right_0 != Left(0)
    left_0 = Left(0)
    left_1 = Left(0)
    assert left_0 == left_1
    assert left_0 != Left(1)
    assert left_0 != Right(0)


# Generated at 2022-06-25 23:28:11.245564
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = True
    right_0 = Right(bool_0)
    right_1 = Right(bool_0)
    right_1 = right_0
    right_0 = right_1
    right_1 = right_0
    assert right_0 == right_1


# Generated at 2022-06-25 23:28:15.773013
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 3
    left_0 = Left(int_0)
    assert left_0.to_lazy() != None
    assert left_0.to_lazy().force() == 3
    assert left_0.to_lazy().is_instance(Left)


# Generated at 2022-06-25 23:28:21.192872
# Unit test for method case of class Either
def test_Either_case():
    bool_0 = True
    left_0 = Left(bool_0)
    bool_1 = False
    left_1 = Left(bool_1)
    left_0.case(lambda value: bool_1, lambda value: bool_0)
    bool_2 = False
    right_0 = Right(bool_2)
    bool_3 = True
    right_1 = Right(bool_3)
    right_0.case(lambda value: bool_0, lambda value: bool_1)


# Generated at 2022-06-25 23:28:26.314091
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = test_Left_map_0()
    left_1 = test_Left_map_0()
    right_0 = test_Right_map_0()
    left_1_clone = Left(left_1.value)
    left_0_clone = Left(left_0.value)
    left_0_not = Left(not left_0.value)
    right_0_clone = Right(right_0.value)
    assert left_1 == left_1_clone
    assert left_0 == left_0_clone
    assert not left_0 == left_1
    assert not left_0 == left_0_not
    assert not left_0 == left_0_not
    assert not left_0 == right_0
    assert not left_1 == right_0_clone


# Generated at 2022-06-25 23:28:28.731053
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(None)
    right_1 = right_0.to_lazy()



# Generated at 2022-06-25 23:28:33.613081
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_0 = Right(True).to_lazy()
    assert True == lazy_0.value()


# Generated at 2022-06-25 23:28:42.326930
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    bool_0 = False
    right_0 = Right(bool_0)
    assert right_0.to_lazy() == Lazy(lambda: bool_0)
    bool_1 = False
    right_1 = Right(bool_1)
    assert right_1.to_lazy() == Lazy(lambda: bool_1)
    bool_2 = False
    right_2 = Right(bool_2)
    assert right_2.to_lazy() == Lazy(lambda: bool_2)
    box_0 = Box(None)
    assert right_2.to_lazy().bind(lambda: box_0) == Lazy(lambda: box_0)
   

# Generated at 2022-06-25 23:28:46.817626
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(0)
    right_0_lazy = right_0.to_lazy()
    assert callable(right_0_lazy.evaluate)
    assert right_0_lazy.evaluate() is 0
    assert not right_0_lazy.is_memoized()


# Generated at 2022-06-25 23:28:49.370244
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(0)
    assert right_0.to_lazy().value() == 0, "AssertionError"


# Generated at 2022-06-25 23:28:51.822866
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)

    lazy = right_0.to_lazy()


# Generated at 2022-06-25 23:29:02.303158
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    int_0 = 0
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert (lazy_0.value() == int_0)

    int_1 = 1
    left_1 = Left(int_1)
    lazy_1 = left_1.to_lazy()
    assert (lazy_1.value() == int_1)

    int_2 = 2
    left_2 = Left(int_2)
    lazy_2 = left_2.to_lazy()
    assert (lazy_2.value() == int_2)

    int_3 = 3
    left_3 = Left(int_3)
    lazy_3 = left_3.to_lazy()
    assert (lazy_3.value() == int_3)

# Generated at 2022-06-25 23:29:03.495911
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    mock = Right(True)
    assert mock.to_lazy().force() == True

# Generated at 2022-06-25 23:29:10.292735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    def function_0():
        number_0 = 123
        bool_0 = True
        try_0 = Try(function_1(number_0, bool_0))
        string_0 = 'a'
        string_1 = '1'
        return Either.Right(function_2(string_0, string_1, try_0))
    def function_1(number_0, bool_0):
        if(bool_0):
            exception_0 = Exception(number_0)
            raise exception_0
        number_1 = ord('a')
        return number_0 + number_1
    def function_2(string_0, string_1, try_0):
        string

# Generated at 2022-06-25 23:29:13.533690
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.functor import Functor

    value_0 = 'test_Either_to_lazy'
    either_0 = Right(value_0)
    lazy_0 = either_0.to_lazy()
    value_1 = lazy_0.value()
    assert value_1 == value_0
    value_2 = bool(value_1)
    bool_0 = bool(either_0.bind(lambda value: Lazy(lambda: value)))



# Generated at 2022-06-25 23:29:19.338317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Check that to_lazy convert Right to lazy
    right_0 = Right(True)
    result = right_0.to_lazy()
    assert result == Lazy(right_0.value)
    # Check that to_lazy convert Left to lazy
    left_0 = Left(None)
    result = left_0.to_lazy()
    assert result == Lazy(left_0.value)



# Generated at 2022-06-25 23:29:33.491101
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    To test method to_lazy of class Either we will create different instances of Right and Left,
    transform them to Lazy and check if the result contains expected value
    """
    bool_0 = False
    right_0 = Right(bool_0)
    result_0 = right_0.to_lazy()
    expected_0 = Lazy(lambda: bool_0)
    assert result_0 == expected_0
    bool_1 = True
    right_1 = Right(bool_1)
    result_1 = right_1.to_lazy()
    expected_1 = Lazy(lambda: bool_1)
    assert result_1 == expected_1
    int_0 = 0
    right_2 = Right(int_0)
    result_2 = right_2.to_lazy()
    expected_2

# Generated at 2022-06-25 23:29:41.573168
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    bool_0 = True
    either_0 = Either(bool_0)
    box_0 = Box(bool_0)
    lazy_0 = Lazy(lambda: bool_0)

    either_1 = either_0.to_lazy()
    assert either_1 is lazy_0

    either_2 = either_0.to_lazy()
    assert either_2 is lazy_0

    box_1 = box_0.to_lazy()
    assert box_1 is lazy_0

    box_2 = box_0.to_lazy()
    assert box_2 is lazy_0


# Generated at 2022-06-25 23:29:43.645304
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:29:52.092294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_list = [10, 5]
    test_int = 5
    test_str = '5'
    test_dict = {'555': '555'}

    left_0 = Left(test_list)
    left_0_lazy = left_0.to_lazy()

    assert(bool(left_0_lazy.get()) == bool(test_list))
    assert(left_0_lazy.get() == test_list)

    right_0 = Right(test_list)
    right_0_lazy = right_0.to_lazy()

    assert(bool(right_0_lazy.get()) == bool(test_list))
    assert(right_0_lazy.get() == test_list)

    left_1 = Left(test_int)
    left_1_l

# Generated at 2022-06-25 23:29:55.165754
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    success_0 = lazy_0.get()
    assert success_0 == bool_0


# Generated at 2022-06-25 23:29:57.544602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-25 23:29:58.492171
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:30:02.279205
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    # Test of method to_lazy of class Either with argument None
    right_0 = Right(bool_0).to_lazy()
    # Test of method to_lazy of class Either with argument None
    left_0 = Left(bool_0).to_lazy()


# Generated at 2022-06-25 23:30:05.560023
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = Lazy(lambda: 1)
    assert Right(1).to_lazy() == value
    assert Left(1).to_lazy() == value


# Generated at 2022-06-25 23:30:09.148307
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    right_0 = Right(bool_0)
    maybe_0 = right_0.to_lazy()
    # maybe_0 = Just(bool_0)
    assert maybe_0.value == bool_0



# Generated at 2022-06-25 23:30:17.253718
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange
    test_data = True
    right_0 = Right(test_data)

    # Act
    lazy_0 = right_0.to_lazy()
    data_0 = lazy_0.value

    # Assert
    assert data_0 == test_data


# Generated at 2022-06-25 23:30:19.712322
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Assert that to_lazy of instance of class Either is instance of class Lazy at least
    assert isinstance(Right(True).to_lazy(), Lazy)


# Generated at 2022-06-25 23:30:20.915476
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(either_0.to_lazy() == lazy_0)



# Generated at 2022-06-25 23:30:24.691970
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    func_0 = lambda *_: True
    lazy_0 = func_0()
    right_0 = Right(lazy_0)
    try:
        assert right_0.to_lazy()
    except AssertionError:
        raise AssertionError('Not failed when expected')


# Generated at 2022-06-25 23:30:28.173551
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Pass
    assert Left(False).to_lazy().force() == False

    # Pass
    assert Right(False).to_lazy().force() == False


# Generated at 2022-06-25 23:30:36.189598
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    bool_0 = False
    right_0 = Right(bool_0)
    value_0 = right_0.to_lazy()
    assert isinstance(value_0, Lazy)
    assert value_0.value() == bool_0
    bool_1 = True
    right_1 = Right(bool_1)
    value_1 = right_1.to_lazy()
    assert isinstance(value_1, Lazy)
    assert value_1.value() == bool_1
    str_0 = 'f'
    right_2 = Right(str_0)
    value_2 = right_2.to_lazy()
    assert isinstance(value_2, Lazy)
    assert value_2

# Generated at 2022-06-25 23:30:38.623792
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.get()


# Generated at 2022-06-25 23:30:46.710204
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    assert bool_0 == (Right(bool_0).to_lazy()).invoke()
    str_0 = "test"
    assert str_0 == (Right(str_0).to_lazy()).invoke()
    bool_0 = True
    assert bool_0 == (Right(bool_0).to_lazy()).invoke()
    bool_0 = False
    bool_1 = False
    assert bool_0 == (Right(bool_0).to_lazy()).invoke()


# Generated at 2022-06-25 23:30:49.507764
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_0 = "abc"
    left_0 = Left(string_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == string_0


# Generated at 2022-06-25 23:30:52.382017
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(True)
    lazy_0 = right_0.to_lazy()
    result_0 = lazy_0.get()
    assert result_0 == True


# Generated at 2022-06-25 23:31:06.477741
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(0)
    lazy_0 = right_0.to_lazy()
    b = lazy_0.value()
    if b != 0:
        raise Exception('Expected:' + str(0) + ' but was:' + str(b))


# Generated at 2022-06-25 23:31:09.222998
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(243)
    maybe_0 = right_0.to_lazy()
    assert maybe_0.resolve() == 243


# Generated at 2022-06-25 23:31:14.234632
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def function_0():
        return 'str'
    str_0 = function_0()
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    string_0 = lazy_0.value()
    assert string_0 == str_0


# Generated at 2022-06-25 23:31:18.435751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    either_0 = Right(bool_0)
    lazy_0 = either_0.to_lazy()
    bool_1 = lazy_0.value
    assert bool_1 is bool_0



# Generated at 2022-06-25 23:31:27.414738
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(0).to_lazy() == Right(0).to_lazy()
    assert Right(0).to_lazy() != Left(0).to_lazy()
    assert Right(0).to_lazy() != Lazy(lambda: 0)
    assert Right(0).to_lazy() == Lazy(lambda: 0)
    assert Left(0).to_lazy() == Left(0).to_lazy()
    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Left(0).to_lazy() != Lazy(lambda: 1)

# Generated at 2022-06-25 23:31:30.524475
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either

    # Test Either to Lazy
    assert Either(True).to_lazy() == Lazy(lambda: True), 'Either to Lazy'



# Generated at 2022-06-25 23:31:34.111293
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == Lazy(lambda: 1).value()
    assert Left(1).to_lazy().value() == Lazy(lambda: 1).value()


# Generated at 2022-06-25 23:31:40.796723
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    # Create instance of class Right
    right_0 = Right(3.0)
    # Create instance of class Lazy
    lazy_0 = right_0.to_lazy()
    # Create instance of class Lazy
    lazy_1 = right_0.to_lazy()
    # Create instance of class Lazy
    lazy_2 = right_0.to_lazy()



# Generated at 2022-06-25 23:31:44.954957
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 2
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()

# Generated at 2022-06-25 23:31:48.739337
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    left_0 = Left(bool_0)
    result = left_0.to_lazy()
    assert result.value() == bool_0


# Generated at 2022-06-25 23:32:10.220064
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(10).to_lazy().run() == 10
    assert Either("hello world").to_lazy().run() == "hello world"
    assert Either([True, False, True]).to_lazy().run() == [True, False, True]
    assert Either({"key0": "value0", "key1": "value1"}).to_lazy().run() == {"key0": "value0", "key1": "value1"}



# Generated at 2022-06-25 23:32:11.946533
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(True).to_lazy().run()
    assert not Left(True).to_lazy().run()



# Generated at 2022-06-25 23:32:21.106215
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0).to_lazy()
    bool_1 = bool_0
    mock_1 = Mock()
    mock_1.case = Mock(side_effect=right_0.case)
    assert mock_1.case("error", "success") == bool_1
    bool_2 = bool_0
    mock_2 = Mock()
    mock_2.ap = Mock(side_effect=right_0.ap)
    assert mock_2.ap("monad") == bool_2
    bool_3 = bool_0
    mock_3 = Mock()
    mock_3.to_box = Mock(side_effect=right_0.to_box)
    assert mock_3.to_box() == bool_3
    bool_4 = bool_0
    mock

# Generated at 2022-06-25 23:32:28.188678
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Assert the result of calling to_lazy method on Right(False) is Lazy(False)
    bool_0 = False
    right_0 = Right(bool_0)
    left_0 = Left(bool_0)
    bool_1 = bool_0
    bool_2 = bool_0
    compare_0 = right_0.to_lazy()
    assert compare_0.value() == bool_1
    # Assert the result of calling to_lazy method on Left(False) is Lazy(False)
    compare_1 = left_0.to_lazy()
    assert compare_1.value() == bool_2



# Generated at 2022-06-25 23:32:36.524882
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.get() == bool_0
    lazy_1 = Right(bool_0).to_lazy()
    assert __name__ == '__main__'
    lazy_2 = right_0.to_lazy()
    assert lazy_2.get() == bool_0
    bool_1 = True
    right_1 = Right(bool_1)
    lazy_3 = right_1.to_lazy()
    assert lazy_3.get() == bool_1
    assert right_1.to_lazy().get() == bool_1
    bool_2 = bool(0)
    right_2 = Right(bool_2)
    lazy_4 = right_2

# Generated at 2022-06-25 23:32:40.458065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    assert type(lazy_0) is Lazy
    assert callable(lazy_0.get_value)
    assert lazy_0.get_value() is bool_0



# Generated at 2022-06-25 23:32:42.837737
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(5)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == 5


# Generated at 2022-06-25 23:32:46.855598
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Input parameters
    right_0 = Right(True)

    # Expected result
    expected = right_0.to_lazy()

    # Computation
    result = right_0.to_lazy()

    # Assertion
    assert expected == result


# Generated at 2022-06-25 23:32:49.597152
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    result = lazy_0.value()
    assert result == bool_0


# Generated at 2022-06-25 23:32:51.098347
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Right(1)
    lazy = Lazy(lambda: 1)
    assert either.to_lazy() == lazy

# Generated at 2022-06-25 23:33:35.187367
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    try:
        assert_equals(Lazy(lambda: True), Right(True).to_lazy())
        assert_equals(Lazy(lambda: 'ho!'), Right('ho!').to_lazy())
        assert_equals(Lazy(lambda: 0), Right(0).to_lazy())
        assert_equals(Lazy(lambda: []), Right([]).to_lazy())
        assert_equals(Lazy(lambda: {}), Right({}).to_lazy())
        assert_equals(Lazy(lambda: (1, 2, 3)), Right((1, 2, 3)).to_lazy())
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 23:33:39.117558
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    left_0 = Left(None)
    assert left_0.to_lazy() == Lazy(lambda: None)
    right_0 = Right(None)
    assert right_0.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-25 23:33:42.074099
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def get_val() -> int:
        return 15

    either_0 = Right(get_val)
    lazy_0 = Lazy(get_val)

    assert either_0.to_lazy() == lazy_0, 'Assert error for Either.to_lazy'



# Generated at 2022-06-25 23:33:44.128471
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.Right(10).to_lazy().is_lazy()
    assert Either.Left(10).to_lazy().is_lazy()


# Generated at 2022-06-25 23:33:46.470875
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True

    # Test for class Right
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()

    assert lazy_0.value() == bool_0


# Generated at 2022-06-25 23:33:47.948066
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()



# Generated at 2022-06-25 23:33:52.160086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def f_0():
        bool_0 = True
        left_0 = Left(bool_0)
        lazy_0 = left_0.to_lazy()
        lazy_1 = lazy_0.map(f_0)
        return lazy_1

    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()
    lazy_1 = lazy_0.map(f_0)


# Generated at 2022-06-25 23:33:53.864478
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Left(2).to_lazy().unbox() == 2)
    assert(Right(2).to_lazy().unbox() == 2)


# Generated at 2022-06-25 23:33:55.823471
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def bool_0():
        return True
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:57.401515
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    x = True
    right_0 = Right(x)
    right_0_lazy = right_0.to_lazy()


# Generated at 2022-06-25 23:35:20.108138
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()

    # Assert lazy_0.value() == bool_0
    assert lazy_0.value() == bool_0
    return bool_0



# Generated at 2022-06-25 23:35:21.560494
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(1)
    lazy = right.to_lazy()
    value = lazy.value()

    assert value == 1
#

# Generated at 2022-06-25 23:35:23.383358
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    left_0 = Left(bool_0)
    bool_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:35:25.067735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    return_value = right_0.to_lazy()


# Generated at 2022-06-25 23:35:29.011947
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    def function_0():
        return 0

    expected_0 = Lazy(function_0)
    box = Box(function_0)
    actual_0 = Either.left(box).to_lazy()
    assert expected_0 == actual_0


# Generated at 2022-06-25 23:35:32.339731
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy = right_0.to_lazy()
    assert bool_0 == lazy.value()
    bool_0 = True
    right_0 = Right(bool_0)
    lazy = right_0.to_lazy()
    assert bool_0 == lazy.value()


# Generated at 2022-06-25 23:35:33.768190
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:35:41.146651
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f(b: bool) -> bool:
        return not b

    left = Left(bool)
    right = Right(bool)

    left_lazy = left.to_lazy()
    assert callable(left_lazy.evaluate())
    assert not callable(left_lazy.value)
    assert left_lazy.value == bool

    right_lazy = right.to_lazy()
    assert callable(right_lazy.evaluate())
    assert not callable(right_lazy.value)
    assert right_lazy.value == bool

    map_lazy = right_lazy.map(f)
    assert callable(map_lazy.evaluate())
    assert not callable(map_lazy.value)
    assert map_lazy.value == f



# Generated at 2022-06-25 23:35:42.721871
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = False
    right_0 = Right(bool_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:35:47.725488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyExecutionError
    from pymonet.either import Right
    from pymonet.either import Left
    val = Right(10)
    expected = Lazy(lambda : 10)
    assert val.to_lazy() == expected
    val = Left(10)
    expected = Lazy(lambda : 10)
    assert val.to_lazy() == expected
