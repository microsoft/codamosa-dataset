

# Generated at 2022-06-25 23:27:34.557343
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    assert left_0 == left_0


# Generated at 2022-06-25 23:27:43.287036
# Unit test for method case of class Either
def test_Either_case():

    # Case 1: Check if method return right value

    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '

    right_0 = Right(str_0)

    assert right_0.case(lambda _: None, lambda value: value == str_0)

    # Case 2: Check if method return left value

    left_0 = Left(str_0)

    assert left_0.case(lambda value: value == str_0, lambda _: None)



# Generated at 2022-06-25 23:27:49.443353
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left(False)
    left_1 = Left(True)
    right_0 = Right(left_0)
    left_2 = Left(left_0)
    assert left_0 != left_1
    assert left_0 != right_0
    assert left_0 != left_2
    left_3 = Left(left_0)
    assert left_0 == left_3
    assert left_0 != False
    assert left_0 != 0
    assert left_0 != None


# Generated at 2022-06-25 23:27:56.082899
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)

    assert left_0.to_lazy().f() == (left_0.value)

test_case_0()
test_Either_to_lazy()

# Generated at 2022-06-25 23:28:00.320338
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Right(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(2)
    assert Left(1) != Left(2)
    assert Left(1) != 2


# Generated at 2022-06-25 23:28:10.570650
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    bool_0 = bool(str_0)
    bool_1 = bool(str_0)
    either_0 = Either(str_0)
    either_1 = Either(str_0)
    either_2 = Either(str_0)
    either_0 = Left(str_0)
    either_1 = Left(str_0)
    either_0 = Right(str_0)
    either_0 = Right(str_0)
    assert either_0 == either_

# Generated at 2022-06-25 23:28:20.171227
# Unit test for method case of class Either
def test_Either_case():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    str_1 = 'hello'
    str_2 = 'hello'

# Generated at 2022-06-25 23:28:30.289937
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    left_0 = Left(str_0)
    val_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '

# Generated at 2022-06-25 23:28:37.819455
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.isinstanceof(cls=Lazy) == True
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:28:45.130725
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # assert_equal(((Left('foo') == Left('foo')) == True), True, 'test_Either___eq__: Left')
    # assert_equal(((Right(6) == Right(6)) == True), True, 'test_Either___eq__: Right')
    # assert_equal(((Right('foo') == 1) == False), True, 'test_Either___eq__: not same type')
    # assert_equal(((Right(6) == Right('foo')) == False), True, 'test_Either___eq__: Right and Left')
    # assert_equal(((Left(42) == Left(42)) == True), True, 'test_Either___eq__: Left')
    assert (True == True), 'test_Either___eq__: True'



# Generated at 2022-06-25 23:28:58.197880
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n    '
    str_1 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n    '
    test_case_0 = Either.__eq__(Left(str_0), Left(str_1))
    assert test_case_0

# Generated at 2022-06-25 23:29:06.935752
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    str_1 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    right_1 = Right(str_1)
    assert right_0 == right_1

# Generated at 2022-06-25 23:29:16.942209
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    left_0 = Left(str_0)
    assert right_0 == right_0
    assert not right_0 == left_0
    assert left_0 == left_0
    assert not left_0 == right_0
    assert right_0 == Right(str_0)
    assert left_0 == Left(str_0)
    assert not left_0 == Right(str_0)

# Generated at 2022-06-25 23:29:21.277392
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_1 = 'test'
    right_0 = Right(string_1)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == string_1
    left_0 = Left(string_1)
    lazy_1 = left_0.to_lazy()
    assert lazy_1.value() == string_1


# Generated at 2022-06-25 23:29:33.312720
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left('')
    right_0 = Right('')
    assert (left_0 == right_0) == False
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    str_1 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '

# Generated at 2022-06-25 23:29:42.356665
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    str_1 = '\n    Applies the function inside the Either[A] structure to another applicative type.\n\n    :param applicative: applicative contains function\n    :type applicative: Either[B]\n    :returns: new Either with result of contains function\n    :rtype: Either[A(B)]\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    assert left_0 == left_

# Generated at 2022-06-25 23:29:44.737960
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Left(0).to_lazy().value() == 0)
    assert(Right(1).to_lazy().value() == 1)


# Generated at 2022-06-25 23:29:52.221907
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (Right('test').__eq__(Right('test')) == True)
    assert (Right('test').__eq__(Right('test_1')) == False)
    assert (Right('test').__eq__(Left('test')) == False)
    assert (Right('test').__eq__(Left('test_1')) == False)
    assert (Left('test').__eq__(Left('test')) == True)
    assert (Left('test').__eq__(Left('test_1')) == False)
    assert (Left('test').__eq__(Right('test')) == False)
    assert (Left('test').__eq__(Right('test_1')) == False)


# Generated at 2022-06-25 23:29:58.834873
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    assert left_0 == left_1


# Generated at 2022-06-25 23:30:08.409239
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    left_2 = Left(str_0)
    left_3 = left_1

# Generated at 2022-06-25 23:30:12.877919
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    f = lambda: 3
    lazy_0 = Lazy(f)
    maybe_0 = Maybe.just(1)
    assert lazy_0 == maybe_0.to_lazy()


# Generated at 2022-06-25 23:30:15.601901
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Check with empty string
    str_lazy_0 = '\n        Transform Either to Try.\n\n        :returns: Lazy monad with function returning previous value\n        :rtype: Lazy[Function() -> A]\n        '
    right_0 = Right(str_lazy_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:30:17.296125
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # In place not successful test
    # In place successful test
    pass


# Generated at 2022-06-25 23:30:27.443047
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Applies the function inside the Either[A] structure to another applicative type.\n\n        :param applicative: applicative contains function\n        :type applicative: Either[B]\n        :returns: new Either with result of contains function\n        :rtype: Either[A(B)]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.is_instance_of(object_0=Lazy)
    assert lazy_0.value == str_0
    int_0 = 1
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.is_instance_of(object_0=Lazy)

# Generated at 2022-06-25 23:30:28.591179
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert str(Right(1).to_lazy()) == "Lazy<function>"
    assert str(Left(1).to_lazy()) == "Lazy<function>"


# Generated at 2022-06-25 23:30:36.025298
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.resolve() == str_0
    str_1 = 'resolve'
    right_0 = Right(str_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.resolve() == str_1


# Generated at 2022-06-25 23:30:45.545356
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    bool_0 = weak_eq(lazy_0, Lazy(str_0))
    # AssertionError:

    int_0 = 0

    # AssertionError:
    # int_0 = 1


# Generated at 2022-06-25 23:30:54.631335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left_0 = Left(1)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.is_instance_of(Lazy)
    assert lazy_0.is_instance_of(Either)
    assert lazy_0.is_instance_of(Left)
    assert lazy_0 == Lazy(lambda: 1)

    right_0 = Right(2)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.is_instance_of(Lazy)
    assert lazy_1.is_instance_of(Either)
    assert lazy_1.is_instance_of(Right)
    assert lazy_1 == Lazy(lambda: 2)


# Generated at 2022-06-25 23:30:58.670065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)


# Generated at 2022-06-25 23:31:06.680775
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_1 = Left(str_0)

    def apply():
        def test(x):
            return x
        return test(left_1)

    lazy_0 = left_1.to_lazy()

    assert lazy_0.value() == apply()


# Generated at 2022-06-25 23:31:17.464524
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:31:28.041422
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() is str_0
    assert lazy_0.is_forced is True
    bool_0 = True
    bool_1 = True
    assert lazy_0.is_forced is bool_0
    assert lazy_0.is_forced is bool_1


# Generated at 2022-06-25 23:31:33.387963
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)

    assert left_0.to_lazy() == Lazy(lambda: str_0)



# Generated at 2022-06-25 23:31:40.848888
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Right('\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ')
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: left_0.value)
    assert left_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:31:50.428132
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)

    expected_value = str_0
    lazy_0 = left_0.to_lazy()

    result_value = lazy_0.value()

    assert result_value == expected_value


# Generated at 2022-06-25 23:31:59.850266
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left('\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ')
    lazy_0 = left_0.to_lazy()
    lazy_1 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_1, Lazy)
    assert lazy_0.value() == left_0.value
    assert lazy_1.value() == right_0.value


# Generated at 2022-06-25 23:32:06.668890
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    res_0 = left_0.to_lazy()

    assert res_0.value() == str_0
    assert type(res_0) == type(Left.to_lazy(left_0))



# Generated at 2022-06-25 23:32:13.374206
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    box_0 = left_0.to_lazy().to_box()
    assert lazy_0.equal(box_0)


# Generated at 2022-06-25 23:32:22.784086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)

    from pymonet.lazy import Lazy

    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.__repr__() == 'Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x7f1cbea96158>)'
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:32:28.766520
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(1)
    lazy_0 = right_0.to_lazy()
    lazy_1 = right_0.to_lazy()
    assert lazy_0.value() == 1
    assert lazy_0.value() == lazy_1.value()
    left_0 = Left(1)
    lazy_0 = left_0.to_lazy()
    lazy_1 = left_0.to_lazy()
    assert lazy_0.value() == 1
    assert lazy_0.value() == lazy_1.value()


# Generated at 2022-06-25 23:32:42.956017
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right('a').to_lazy(), Lazy)
    assert Left(1).to_lazy().evaluate() == Left(1)
    assert Left('a').to_lazy().evaluate() == Left('a')
    assert Right(1).to_lazy().evaluate() == Right(1)
    assert Right(6.0).to_lazy().evaluate() == Right(6.0)
    assert Right('a').to_lazy().evaluate() == Right('a')


# Generated at 2022-06-25 23:32:51.834966
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left('\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ')
    lazy = left_0.to_lazy()

    assert lazy() == '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '


# Generated at 2022-06-25 23:32:58.020436
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    right_1 = right_0.to_lazy()
    assert right_1.evaluate() == right_0.value


# Generated at 2022-06-25 23:33:03.593116
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from functools import partial

    # to_lazy
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.evaluate() is str_0

# Generated at 2022-06-25 23:33:11.971671
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: Box(1))
    lazy_1 = lazy_0.to_lazy()

    try_0 = Try(1)
    try_1 = try_0.to_lazy()

    validation_0 = Validation.success(1)
    validation_1 = validation_0.to_lazy()

    right_0 = Right(1).to_lazy()

    # Test Case 1
    # AssertionError: Right(1) != Lazy(<function <lambda> at 0x7f7c6b890400>)
    assert right_0 == Lazy(lambda: 1)



# Generated at 2022-06-25 23:33:20.848275
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    str_1 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '

# Generated at 2022-06-25 23:33:25.963825
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    either_0 = Right(str_0)
    assert isinstance(either_0.to_lazy(), type((lambda f: f)()))


# Generated at 2022-06-25 23:33:31.781344
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    exception_0 = Exception('This is exception')

    assert left_0.to_lazy()
    assert left_0.to_lazy().value().value == str_0


# Generated at 2022-06-25 23:33:37.752420
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_left_0 = left_0.to_lazy()

    # The method is invoked with 0 arguments (but 1 expected)
    assert(lazy_left_0.evaluate() == str_0)


# Generated at 2022-06-25 23:33:41.713846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:34:07.535931
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right = Right(str_0)
    assert right.to_lazy().value() == str_0
    left = Left(str_0)
    assert left.to_lazy().value() == str_0



# Generated at 2022-06-25 23:34:15.184547
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)

    lazy_0 = left_0.to_lazy()
    test_value_0 = lazy_0.value()
    assert str_0 == test_value_0


# Generated at 2022-06-25 23:34:24.994450
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda : 42).to_maybe().to_lazy()
    lazy_1 = Lazy(lambda : 42).to_maybe().to_validation().to_lazy()
    lazy_2 = Lazy(lambda : 42).to_maybe().to_box().to_lazy()
    lazy_3 = Lazy(lambda : 42).to_maybe().to_try().to_lazy()
    lazy_4 = Lazy(lambda : 42).to_lazy()


# Generated at 2022-06-25 23:34:26.292487
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:34:35.421336
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either.__new__(Either)
    either_0.value = Left(None)
    lazy_0 = either_0.to_lazy()
    str_0 = '\n        Maps function to the value of Either and returns new Either with it.\n\n        :param mapper: function to apply to Either value\n        :type mapper: Function(A) -> B\n        :returns: new Either with result of mapper\n        :rtype: Either[B]\n        '
    either_1 = Either.__new__(Either)
    either_1.value = Right(str_0)
    lazy_1 = either_1.to_lazy()
    tuple_0 = (lazy_0, lazy_1)


# Generated at 2022-06-25 23:34:37.867321
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-25 23:34:45.004654
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take 2 functions call only one of then with either value and return her result.\n\n        :params error: function to call when Either is Left\n        :type error: Function(A) -> B\n        :params success: function to call when Either is Right\n        :type success: Function(A) -> B\n        :returns: result of success handler when Eihter is Right, result of error handler when Eihter is Left\n        :rtpye: B\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert [lazy_0.value()] == [str_0]



# Generated at 2022-06-25 23:34:50.103924
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right('abracadabra').to_lazy().value == 'abracadabra'
    assert Left([1, 2, 3]).to_lazy().value == [1, 2, 3]


# Generated at 2022-06-25 23:34:59.451806
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    int_0 = 69
    _list_0 = [str_0, int_0]
    _list_1 = []
    _list_2 = [str_0]
    _list_3 = [int_0]
    _list_4 = [_list_0, _list_1, _list_2, _list_3]
    assert __lazy(_list_4) == _list_4


# Generated at 2022-06-25 23:35:03.552833
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)


# Generated at 2022-06-25 23:35:50.649438
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    result_0 = lazy_0.value()
    assert result_0 == str_0


# Generated at 2022-06-25 23:35:55.705622
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    assert left_0.to_lazy().is_instance_of(str_0)
    pass

# Generated at 2022-06-25 23:36:03.081472
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value == str_0
    assert lazy_0.is_delayed
    assert lazy_0.is_forced is False
    right_0 = Right(lazy_0)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.value == lazy_0
    assert lazy_1.is_delayed
    assert lazy

# Generated at 2022-06-25 23:36:09.891433
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    box_0 = Left('\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ').to_lazy()
    assert box_0.get() == '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '


# Generated at 2022-06-25 23:36:17.838599
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left("\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ")
    test_0 = left_0.to_lazy()
    assert test_0.force() == "\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        ", 'Error in method to_lazy of class Either'
   

# Generated at 2022-06-25 23:36:26.555913
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    str_1 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_1)
    # Act


# Generated at 2022-06-25 23:36:31.090758
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)


# Generated at 2022-06-25 23:36:36.668200
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    lazy_0_get = lazy_0.get()


# Generated at 2022-06-25 23:36:40.974025
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n        Take mapper function and returns result of them called with Right value.\n\n        :param mapper: function to apply on Right value\n        :type mapper: Function(A) -> Either[B]\n        :returns: result of mapper\n        :rtype: Either[B]\n        '
    right_0 = Right(str_0)
    assert right_0.to_lazy().get() == str_0


# Generated at 2022-06-25 23:36:43.599216
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'Hello'
    right_0 = Right(str_0)
    lazy = right_0.to_lazy()
    value = lazy.value()
    assert value == str_0
