

# Generated at 2022-06-25 23:27:35.749822
# Unit test for method case of class Either
def test_Either_case():
    int_0 = -3879
    either_0 = Either(int_0)
    var_0 = either_0.case(None, None)
    var_1 = either_0.case(None, None)
    assert var_0 == var_1


# Generated at 2022-06-25 23:27:39.197763
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = 5079
    either_0 = Either(int_0)
    either_1 = Either(int_0)
    assert either_1 == either_0, "expected %s got %s" % (either_1, either_0)


# Generated at 2022-06-25 23:27:43.668709
# Unit test for method case of class Either
def test_Either_case():
    int_0 = -3879
    either_0 = Either(int_0)
    def int_1(arg_0):
        return arg_0
    def int_2(arg_0):
        return arg_0

    var_0 = either_0.case(int_1, int_2)


# Generated at 2022-06-25 23:27:53.886516
# Unit test for method case of class Either
def test_Either_case():
    int_0 = -3879
    either_0 = Either(int_0)

# Generated at 2022-06-25 23:27:57.008972
# Unit test for method case of class Either
def test_Either_case():
    int_0 = -2
    either_0 = Right(int_0)
    var_0 = either_0.case(_.add(1), _.add(1))



# Generated at 2022-06-25 23:27:59.838564
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-25 23:28:03.835846
# Unit test for method case of class Either
def test_Either_case():
    def success(x):
        return x + 1

    def error(x):
        return x - 1

    val = Either(1).case(error, success)
    assert val == 2, 'Failed for for method case of class Either'



# Generated at 2022-06-25 23:28:07.804367
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # create instance of class Either
    either = Either("init_value")

    # create instance of class Either
    another_either = Either("init_value")

    # result of comparison between two instances of class Either
    result = either == another_either


# Generated at 2022-06-25 23:28:11.836583
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Only for Cython function for set is_left and is_right properties"""
    from pymonet.lazy import Lazy

    assert Right(43).to_lazy() == Lazy(lambda: 43)
    assert Left(-5).to_lazy() == Lazy(lambda: -5)



# Generated at 2022-06-25 23:28:20.201649
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = 810
    either_0 = Either(int_0)
    either_1 = Either(int_0)
    either_2 = Either(int_0)
    either_3 = Either(int_0)
    either_4 = Either(int_0)
    boolean_0 = either_0.__eq__(either_4)
    boolean_1 = either_3.__eq__(either_1)
    boolean_2 = either_2.__eq__(either_4)
    boolean_3 = either_0.__eq__(either_3)
    assert (boolean_0 == boolean_1 == boolean_2 == boolean_3 == True)


# Generated at 2022-06-25 23:28:23.780335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2447
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value == int_0


# Generated at 2022-06-25 23:28:27.752586
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()

    assert lazy_0.value() == int_0

# Generated at 2022-06-25 23:28:34.467137
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def _plus(a, b):
        return a + b
    from functools import partial

    int_0 = -3879
    int_1 = 56462
    either_0 = Either(int_0)
    lazy_0 = Lazy(partial(_plus, int_1))
    lazy_1 = either_0.to_lazy().ap(lazy_0)
    assert lazy_1.get() == (int_0 + int_1)


# Generated at 2022-06-25 23:28:37.774559
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    test_result = Lazy(lambda: 42)
    assert test_result == Right(42).to_lazy()
    assert test_result == Left(42).to_lazy()


# Generated at 2022-06-25 23:28:38.778131
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)


# Generated at 2022-06-25 23:28:42.058525
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    return test_case_0().is_right() == Lazy(lambda: test_case_0().value).is_nothing() and\
        test_case_0().is_left() == Lazy(lambda: test_case_0().value).is_just()


# Generated at 2022-06-25 23:28:48.150440
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_1 = -881
    int_2 = 300
    either_1 = Either(int_1)
    either_2 = Either(int_2)

    lazy_1 = either_1.to_lazy()
    lazy_2 = either_2.to_lazy()

    assert lazy_1.get() == either_1.value
    assert lazy_2.get() == either_2.value



# Generated at 2022-06-25 23:28:59.376008
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    
    # Case 0
    maybe_0 = Maybe.just(10)
    try_0 = Try.success(10)
    lazy_0 = Lazy(lambda: 10)
    box_0 = Box(10)
    either_0 = Right(box_0)
    actual_0 = either_0.to_lazy()
    expected_0 = lazy_0
    print("Expected:", expected_0)
    print("Actual  :", actual_0)
    assert expected_0 == actual_0
    
    # Case 1
    maybe_0 = Maybe.just(10)
    try_0 = Try.failure(10)
    lazy_0 = Lazy(lambda: 10)
    box_0 = Box(10)
    either_0 = Left(box_0)
    actual_0 = either_

# Generated at 2022-06-25 23:29:04.118437
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from unittest import TestCase

    class TestEitherToLazy(TestCase):
        def test_0(self):
            either_0 = Either(4)
            lazy_0 = Lazy(lambda: 4)
            self.assertEqual(either_0.to_lazy(), lazy_0)


# Generated at 2022-06-25 23:29:06.464054
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:13.081796
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(42).to_lazy() == Lazy(lambda: 42)
    assert Right(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-25 23:29:21.941476
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_collection import LazyList
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0, LazyList)
    assert isinstance(lazy_0, Box)
    assert isinstance(lazy_0, Try)
    assert isinstance(lazy_0, Maybe)
    assert isinstance(lazy_0, Validation)

# Generated at 2022-06-25 23:29:25.206208
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    input = Either(3879)
    expected_output = 3879
    actual_output = input.to_lazy().force()
    assert actual_output == expected_output


# Generated at 2022-06-25 23:29:31.998530
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _assert(expected, result):
        assert expected == result

    def _assert_function(value):
        return value ** 2

    def _assert_result(value):
        return value ** 3

    box_0 = Right(2)
    lazy_0 = box_0.to_lazy()
    result_0 = lazy_0.get_value(_assert_function)

    _assert(result_0, 4)


# Generated at 2022-06-25 23:29:34.426088
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)

    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:29:37.222500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_1 = 2889
    either_1 = Either(int_1)
    lazy_2 = either_1.to_lazy()
    value_3 = lazy_2.force()

    assert(value_3 == int_1)

# Generated at 2022-06-25 23:29:41.350044
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    integer_0 = -3569
    either_0 = Either(integer_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: integer_0)



# Generated at 2022-06-25 23:29:43.729853
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Initialization
    int_0 = -61
    either_0 = Either(int_0)
    either_0.to_lazy()


# Generated at 2022-06-25 23:29:47.676621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0 == Lazy)
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:29:50.280987
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 25869
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    value_0 = lazy_0.get()
    assert value_0 == int_0



# Generated at 2022-06-25 23:29:55.288786
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = Lazy(lambda: int_0)

    # When
    lazy_1 = either_0.to_lazy()

    # Then
    assert lazy_1 == lazy_0


# Generated at 2022-06-25 23:29:58.708554
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.force() == int_0


# Generated at 2022-06-25 23:30:02.790527
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.isinstance(Lazy)

# Generated at 2022-06-25 23:30:07.268361
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print("\nRunning test_Either_to_lazy")
    from pymonet.monad_either import Left, Right
    from pymonet.lazy import Lazy

    assert Left("").to_lazy() == Lazy(lambda: "")
    assert Right("").to_lazy() == Lazy(lambda: "")


# Generated at 2022-06-25 23:30:13.018846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.__repr__() == "Lazy(<function Either.<locals>.<lambda> at 0x7f5e5cab57b8>)"
    assert lazy_0.__str__() == "Lazy(<function Either.<locals>.<lambda> at 0x7f5e5cab57b8>)"
    lazy_1 = lazy_0.map(int)
    assert lazy_1.__repr__() == "Lazy(<function Either.<locals>.<lambda> at 0x7f5e5cab57b8>)"

# Generated at 2022-06-25 23:30:17.970446
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    bool_0 = lazy_0.is_completed()
    bool_1 = lazy_0 is either_0
    bool_2 = bool_0
    assert lazy_0 is either_0
    assert bool_1
    assert bool_2



# Generated at 2022-06-25 23:30:20.630317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() is int_0



# Generated at 2022-06-25 23:30:23.428725
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0



# Generated at 2022-06-25 23:30:33.500238
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    int_1 = -3879
    right_1 = Right(int_1)
    lazy_1 = right_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.get_value() == int_1

    str_1 = "Fdsfdsdsf"
    right_2 = Right(str_1)
    lazy_2 = right_2.to_lazy()
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.get_value() == str_1


# Generated at 2022-06-25 23:30:36.265897
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = "hi"
    either_0 = Right(str_0)
    lazy_0 = either_0.to_lazy()
    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.take() == str_0)


# Generated at 2022-06-25 23:30:45.047676
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    bool_0 = isinstance(lazy_0, Lazy)
    int_1 = lazy_0.value()

    assert int_1 == int_0
    assert bool_0


# Generated at 2022-06-25 23:30:49.168095
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 3829
    result = Lazy(lambda: int_0)

    either_0 = Either(int_0)
    assert result == either_0.to_lazy(), 'assert #1 in test_Either_to_lazy()'



# Generated at 2022-06-25 23:30:52.731230
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -1
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-25 23:30:57.452651
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Right(27).to_lazy() == Lazy(lambda: 27)
    assert Right(None).to_lazy() == Lazy(lambda: None)
    assert Right({}).to_lazy() == Lazy(lambda: {})
    assert Right(set()).to_lazy() == Lazy(lambda: set())


# Generated at 2022-06-25 23:31:07.452797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test to_lazy method of class Either"""
    def int_is_positive(i: int) -> bool:
        return i > 0

    maybe_int: Maybe[int] = Maybe(0)
    lazy_int: Lazy[int] = maybe_int.to_lazy()
    try_int: Try[int] = maybe_int.to_try()

    assert lazy_int.is_right is True
    assert try_int.is_success is True

    maybe_float: Maybe[float] = Maybe(-0.1)
    lazy_float: Lazy[float] = maybe_float.to_lazy()
    try_float: Try[float] = maybe_float.to_try()

    assert lazy_float.is_right is False
    assert try_float.is_success is False

# Unit test

# Generated at 2022-06-25 23:31:09.923626
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    assert either_0.to_lazy() == int_0


# Generated at 2022-06-25 23:31:14.608976
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    int_1 = lazy_0.value.call()
    assert int_0 == int_1


# Generated at 2022-06-25 23:31:26.812572
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    test_case_0 = -3879
    test_case_1 = lambda: -3879

    either_0 = Left(test_case_0)
    either_1 = Left(test_case_1)
    either_2 = Right(test_case_0)
    either_3 = Right(test_case_1)

    assert isinstance(either_0.to_lazy(), Lazy)
    assert either_0.to_lazy().future is None
    assert either_1.to_lazy().future() == either_1.value
    assert isinstance(either_2.to_lazy(), Lazy)

# Generated at 2022-06-25 23:31:29.421377
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)

    lazy_0 = either_0.to_lazy()

    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:31:33.845567
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def to_lazy_primitive(value: int) -> int:
        return value

    int_0 = -3879
    either_0 = Right(int_0)

    value_0 = either_0.to_lazy()
    assert callable(value_0.value)

    assert int_0 == to_lazy_primitive(int_0)
    assert int_0 == value_0.value()


# Generated at 2022-06-25 23:31:44.449345
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    assert either_0.to_lazy() == Lazy(either_0.value)


# Generated at 2022-06-25 23:31:55.623070
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -498123904
    either_0 = Left(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0
    int_1 = -1367
    either_1 = Left(int_1)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.value() == int_1
    int_2 = -498123904
    either_2 = Left(int_2)
    lazy_2 = either_2.to_lazy()
    assert lazy_2.value() == int_2
    int_3 = 2839
    either_3 = Right(int_3)
    lazy_3 = either_3.to_lazy()
    assert lazy_3.value() == int_3


# Generated at 2022-06-25 23:31:59.217445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    right_0 = Either(int_0)
    lazy_0 = right_0.to_lazy()
    int_1 = lazy_0.value
    assert int_1 == int_0



# Generated at 2022-06-25 23:32:01.355463
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 5
    either_0 = Either(int_0)
    assert either_0.to_lazy() == Lazy(lambda: int_0)



# Generated at 2022-06-25 23:32:04.145294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    lazy_0 = Either(int_0).to_lazy()
    int_1 = lazy_0.box().value
    assert int_0 == int_1


# Generated at 2022-06-25 23:32:07.499178
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import lazy

    int_0 = -935
    int_1 = 935
    either_0 = Either(int_0)
    assert either_0.to_lazy().f == lazy(either_0.to_lazy().f)


# Generated at 2022-06-25 23:32:12.744488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    either_0 = Either(int)
    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_type_of(int)
    assert lazy_0.value is int

    either_1 = Either(Lazy)
    lazy_1 = either_1.to_lazy()

    assert isinstance(lazy_1, Lazy)
    assert lazy_1.is_type_of(Lazy)
    assert lazy_1.value is Lazy

    either_2 = Either(Lazy[int])
    lazy_2 = either_2.to_lazy()

    assert isinstance(lazy_2, Lazy)
    assert lazy_

# Generated at 2022-06-25 23:32:17.148645
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    number_0 = -9354
    either_0 = Right(number_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = Lazy(lambda: number_0)

    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:32:20.308318
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:32:27.011121
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    is_instance(lazy_0.value, Lazy)
    assert lazy_0.value.is_instance_of[Lazy]
    assert lazy_0 == Lazy(lambda: int_0)
    int_1 = -2683
    either_1 = Either(int_1)
    lazy_1 = either_1.to_lazy()
    assert lazy_1 == Lazy(lambda: int_1)


# Generated at 2022-06-25 23:32:41.596306
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.utils import identity
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = Lazy(lambda: identity(int_0))
    assert either_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:32:49.755565
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0
    int_1 = 763
    str_0 = 'This is a test'
    either_1 = Either(int_1)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.value() == int_1
    either_2 = Either(str_0)
    lazy_2 = either_2.to_lazy()
    assert lazy_2.value() == str_0


# Generated at 2022-06-25 23:32:52.274744
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    int = -3879
    either = Either(int)
    assert either.to_lazy() == Lazy(lambda: int)


# Generated at 2022-06-25 23:32:55.120999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -50
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.eval() == int_0


# Generated at 2022-06-25 23:32:58.329143
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(either_0.value)



# Generated at 2022-06-25 23:33:05.078232
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Case 0
    # noinspection PyTypeChecker
    either_0 = Either(int)
    # noinspection PyTypeChecker
    lazy_0 = either_0.to_lazy()
    boolean_0 = isinstance(lazy_0, Lazy)

    assert_true(boolean_0)

    # Case 1
    # noinspection PyTypeChecker
    either_1 = Either(int)
    # noinspection PyTypeChecker
    lazy_1 = either_1.to_lazy()
    boolean_1 = isinstance(lazy_1, Lazy)

    assert_true(boolean_1)

    # Case 2
    # noinspection PyTypeChecker
    either_2 = Either(int)
    # noinspection PyTypeChecker
    lazy_2 = either_2

# Generated at 2022-06-25 23:33:06.528121
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Either(42)
    assert either.to_lazy().evaluate() == 42



# Generated at 2022-06-25 23:33:09.311117
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    int_1 = lazy_0.value()
    assert int_0 == int_1


# Generated at 2022-06-25 23:33:13.022347
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    str_0 = str(lazy_0)
    str_1 = "Lazy object"
    assert str_0 == str_1



# Generated at 2022-06-25 23:33:17.560361
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    either_0 = Either(Lazy(lambda: 1))
    either_1 = either_0.to_lazy()
    assert str(either_1) == str(either_0)
    assert either_0.value.value() == either_1.value.value()


# Generated at 2022-06-25 23:33:46.701141
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Lazy(lambda: 10)
    assert Lazy(lambda: 10) != Lazy(lambda: 11)
    assert Lazy(lambda: 10) != Lazy(lambda: None)
    assert Lazy(lambda: 10) != 10
    assert Lazy(lambda: 10) != Maybe(10)
    assert Lazy(lambda: 10) != Box(10)
    assert Lazy(lambda: 10) != Try.success(10)



# Generated at 2022-06-25 23:33:50.285302
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Scenario 0.
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert(lazy_0.value() == int_0) and\
        (isinstance(lazy_0, Either) == False) and\
        (isinstance(lazy_0, lazy.Lazy) == True)

# Generated at 2022-06-25 23:33:53.358603
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -4848
    either_0 = Either(int_0)
    val_0 = either_0.to_lazy()
    lazy_0 = val_0
    list_0 = []
    lazy_0.evaluate(list_0)
    if list_0[0] is not int_0:
        fail


# Generated at 2022-06-25 23:33:59.276834
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test with valid data
    # Test with valid data
    int_0 = -3879

    either_0 = Either(int_0)

    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)

    assert lazy_0.get() == -3879
    # Test with valid data
    # Test with valid data
    str_0 = 'test'


    either_0 = Either(str_0)

    lazy_0 = either_0.to_lazy()

    assert lazy_0.get() == 'test'

# Generated at 2022-06-25 23:34:07.301956
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 2594
    either_0 = Left(int_0)
    result_0 = either_0.to_lazy()
    assert isinstance(result_0, Lazy), 'Expected Lazy, but got %s' % type(result_0)
    from pymonet.lazy import Lazy

    str_0 = 'gvh'
    either_1 = Either(str_0)
    result_1 = either_1.to_lazy()
    assert isinstance(result_1, Lazy), 'Expected Lazy, but got %s' % type(result_1)

# Generated at 2022-06-25 23:34:16.985137
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    class Test0(unittest.TestCase):
        def test0(self):
            either_0 = Either(79)
            self.assertEqual(either_0.to_lazy().force(), 79)
        def test1(self):
            either_0 = Either("")
            self.assertEqual(either_0.to_lazy().force(), "")
        def test2(self):
            either_0 = Either(False)
            self.assertEqual(either_0.to_lazy().force(), False)
        def test3(self):
            either_0 = Either("")
            self.assertEqual(either_0.to_lazy().force(), "")
        def test4(self):
            either_0 = Either("")

# Generated at 2022-06-25 23:34:25.019700
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    right_0 = Right(8869)
    maybe_0 = right_0.to_lazy()
    assert isinstance(maybe_0, Lazy)
    assert maybe_0.get_value() == 8869


# Generated at 2022-06-25 23:34:30.177348
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:34:37.772278
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Create instance of Right
    int_0 = 111
    either_0 = Right(int_0)

    # Get result of method
    lazy_0 = either_0.to_lazy()

    # Check type of resul
    assert type(lazy_0) == Lazy

    # Check value of result
    assert lazy_0.force() == 111


# Generated at 2022-06-25 23:34:42.225035
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Case Left(value: Any)
    left_0 = Left(722)
    assert left_0.to_lazy() == Lazy(lambda: 722)

    # Case Right(value: Any)
    right_0 = Right(17815)
    assert right_0.to_lazy() == Lazy(lambda: 17815)



# Generated at 2022-06-25 23:35:07.518339
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 43929
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()

    print(lazy_0.value())


# Generated at 2022-06-25 23:35:10.127674
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = Lazy(lambda: int_0)
    assert either_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:35:17.502847
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_Left_to_lazy():
        int_0 = -3879
        left_0 = Left(int_0)
        to_lazy_0 = left_0.to_lazy()
        assert isinstance(to_lazy_0, Lazy)
        assert callable(to_lazy_0.value)
        assert to_lazy_0.value() == int_0

    def test_Right_to_lazy():
        int_0 = -13838
        right_0 = Right(int_0)
        to_lazy_0 = right_0.to_lazy()
        assert isinstance(to_lazy_0, Lazy)
        assert callable(to_lazy_0.value)
        assert to_lazy_0.value() == int_0

    test_

# Generated at 2022-06-25 23:35:20.141033
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -245
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    int_1 = lazy_0.value
    assert int_0 == int_1


# Generated at 2022-06-25 23:35:22.765637
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 0

    e_0 = Either(int_0)
    e_1 = e_0.to_lazy()

    assert e_0.value == e_1.value(), "Invalid test value"



# Generated at 2022-06-25 23:35:27.088614
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    int_0 = 2779
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()

    # Lazy(<function <lambda> at 0x10a73ff50>)
    # Box(2779)
    assert lazy_0 == Lazy(lambda: int_0) and lazy_0.value() == Box(int_0)


# Generated at 2022-06-25 23:35:32.760628
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # type: () -> None

    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert(callable(lazy_0.value))
    assert(either_0.value != lazy_0.value())
    lazy_1 = either_0.map(None).to_lazy()
    assert(callable(lazy_1.value))
    assert(lazy_1.value() == either_0.value)
    assert(lazy_1.value())


# Generated at 2022-06-25 23:35:36.151062
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value_0 = -88
    either = Either.__init__()
    from pymonet.lazy import Lazy
    lazy = Lazy
    lazy_0 = either.to_lazy()
    assert lazy_0 == Lazy(lambda: value_0)


# Generated at 2022-06-25 23:35:38.795229
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 100
    either_0 = Either(int_0)

    result = either_0.to_lazy()

    assert isinstance(result, Lazy)
    assert result.value == int_0



# Generated at 2022-06-25 23:35:46.643498
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    int_0 = -3879
    either_0 = Either(int_0)
    def test_func_0(int_0):
        return either_0.to_lazy().value
    assert type(test_func_0(int_0))==int, "AssertionError: expected {}, found {}".format(type(test_func_0(int_0)), type(int))
    assert test_func_0(int_0)==-3879, "AssertionError: expected {}, found {}".format(test_func_0(int_0), -3879)
    boolean_0 = True
    either_1 = Either(boolean_0)
    lazy_0 = either_1.to_lazy()

# Generated at 2022-06-25 23:36:40.752034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    expected = Lazy(lambda: 5)
    int_0 = 5
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == expected


# Generated at 2022-06-25 23:36:43.599157
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -2
    either_0 = Right(int_0)
    val_0 = either_0.to_lazy()
    val_1 = val_0.get()
    assert val_1 == int_0


# Generated at 2022-06-25 23:36:46.728265
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == int_0

# Unit test method map at class Either

# Generated at 2022-06-25 23:36:49.334446
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(int())
    lazy_0 = either_0.to_lazy()
    assert lazy_0.is_instance_of(Either)


# Generated at 2022-06-25 23:36:51.623137
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(79428020)
    lazy = either_0.to_lazy()


# Generated at 2022-06-25 23:36:55.610116
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    error_msg = "Either.to_lazy is broken."

    int_0 = -3879
    either_0 = Either(int_0)
    result_0 = either_0.to_lazy()

    from pymonet.lazy import Lazy

    expected_0 = Lazy(lambda: int_0)
    assert result_0 == expected_0, error_msg


# Generated at 2022-06-25 23:37:02.210634
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 300
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.call() == int_0


# Generated at 2022-06-25 23:37:04.376150
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = -3879
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:37:07.750913
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -4358
    e = Either(int_0)
    lazy = e.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.__val__() == int_0

# Complexity: O(1)

# Generated at 2022-06-25 23:37:10.395110
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = -2457
    either_0 = Either(int_0)
    lazy_0 = Lazy(lambda: int_0)
    lazy_1 = either_0.to_lazy()

    assert lazy_0 == lazy_1
