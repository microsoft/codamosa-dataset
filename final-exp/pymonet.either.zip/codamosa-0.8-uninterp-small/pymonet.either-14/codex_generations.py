

# Generated at 2022-06-25 23:27:33.489271
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Unit test for method __eq__ of class Either
    # local_var_0 is a instance of Either[Any]
    local_var_0 = Either(None)
    local_var_1 = Either(10.0)

    assert local_var_0 == local_var_1



# Generated at 2022-06-25 23:27:37.852812
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = None
    left_0 = Left(var_1)
    var_2 = None
    left_1 = Left(var_2)
    var_3 = None
    right_1 = Right(var_3)

    assert left_0 == left_1


# Generated at 2022-06-25 23:27:44.351314
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    var_2 = None
    left_2 = Left(var_2)
    var_3 = None
    left_3 = Left(var_3)
    assert left_0 == left_3
    assert left_1 == left_3
    assert left_3 == left_3
    assert left_1 == left_2
    assert left_0 == left_1


# Generated at 2022-06-25 23:27:54.565264
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    left_0 = Left(var_0)
    left_1 = Left(var_1)
    left_2 = Left(var_2)
    left_3 = Left(var_3)
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    right_0 = Right(var_4)
    right_1 = Right(var_5)
    right_2 = Right(var_6)
    right_3 = Right(var_7)
    assert (left_0 == left_1)
    assert (left_0 == left_2)
    assert (left_0 == left_3)
    assert (left_1 == left_0)

# Generated at 2022-06-25 23:28:00.411393
# Unit test for method case of class Either
def test_Either_case():
    # Init value
    var_0 = None
    left_0 = Left(var_0)

    # verify case returns result of error handler
    assert left_0.case(
        error=lambda var_0: var_0 is None,
        success=lambda var_0: False
    )

    # Init value
    var_1 = None
    right_1 = Right(var_1)

    # verify case returns result of success handler
    assert right_1.case(
        error=lambda var_1: False,
        success=lambda var_1: var_1 is None
    )



# Generated at 2022-06-25 23:28:02.802521
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:28:06.513272
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    left_1 = Left(var_0)
    left_2 = left_0 == left_1
    assert left_2 == True


# Generated at 2022-06-25 23:28:11.254251
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    assert left_0 == left_1
    var_2 = None
    right_0 = Right(var_2)
    var_3 = None
    right_1 = Right(var_3)
    assert right_0 == right_1
    assert not (right_0 == left_1)
    assert not (left_0 == right_1)
    var_4 = None
    var_5 = None
    left_2 = Left(var_4)
    var_6 = None
    var_7 = None
    right_2 = Right(var_5)
    assert not (left_2 == right_2)
    assert not (right_2 == left_2)

# Generated at 2022-06-25 23:28:13.979507
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    right_0 = Right(var_0)
    assert left_0 != right_0, "Expected true"


# Generated at 2022-06-25 23:28:22.895130
# Unit test for method case of class Either
def test_Either_case():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = "must be called"
    left_1 = Left(var_1)
    var_2 = "must not be called"
    left_2 = Left(var_2)
    var_3 = lambda x: left_2
    error_0 = var_3
    assert error_0(var_1) is left_2
    var_4 = lambda x: left_0
    success_0 = var_4
    assert success_0(var_1) is left_0
    var_5 = left_1.case(error_0, success_0)
    assert var_5 is left_2
    left_3 = Left(var_1)
    var_6 = left_3.case(error_0, success_0)

# Generated at 2022-06-25 23:28:28.392735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_0 = right_0.to_lazy()
    var_1 = var_0.evaluate()


# Generated at 2022-06-25 23:28:30.506506
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:28:36.588175
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = 20
    right_0 = Right(var_2)
    var_3 = right_0.to_lazy()
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None


# Generated at 2022-06-25 23:28:39.166549
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 0
    right_0 = Left(var_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.evaluate() == 0


# Generated at 2022-06-25 23:28:40.747790
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = "a"
    right_0 = Right(var_0)
    assert right_0.to_lazy().value() == "a"



# Generated at 2022-06-25 23:28:42.176740
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Right(1)
    assert either.to_lazy().value() == 1



# Generated at 2022-06-25 23:28:44.156502
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.__init__ is Either.to_lazy


# Generated at 2022-06-25 23:28:46.058829
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Input arguments
    var_0 = (Left(3))

    # Output arguments
    var_0.to_lazy().value()


# Generated at 2022-06-25 23:28:51.667176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = 1
    right_1 = Right(var_1)
    assert right_1.to_lazy() == Lazy(lambda: 1)

    var_2 = lambda x: x
    right_2 = Right(var_2)
    assert right_2.to_lazy() == Lazy(lambda: lambda x: x)


# Generated at 2022-06-25 23:29:02.177969
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    maybe_1 = lazy_0.get()
    var_1 = None
    maybe_2 = Maybe.just(var_1)
    var_2 = Maybe.is_match(maybe_1, maybe_2)
    var_3 = None
    if (var_2 == var_3):
        var_4 = None
    else:
        var_4 = Maybe.is_match(None, maybe_1)
    var_5 = None
    if (var_4 == var_5):
        var_6 = None
    else:
        var_6 = None
    var_7 = None
    if (var_6 == var_7):
        var_8 = None
   

# Generated at 2022-06-25 23:29:05.687065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 1
    right_0 = Right(var_0)

    res_0 = right_0.to_lazy()

    assert res_0 == right_0


# Generated at 2022-06-25 23:29:12.664472
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:17.168256
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Tests if the result is a lambda function
    def test_result():
        var_0 = None
        right_0 = Right(var_0)
        result = right_0.to_lazy()
        if not callable(result.value):
            raise Exception('Result should be a lambda function')
    test_result()


# Generated at 2022-06-25 23:29:18.890358
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    args_0 = Left([])

    # Copy var_0 to var_1
    var_1 = args_0

    # Call method to_lazy with args: ()
    result_1 = var_1.to_lazy()

    # Assert result_1 == ()
    pass


# Generated at 2022-06-25 23:29:23.373268
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    var_1 = None
    left_1 = Left(var_1)
    lazy_1 = left_1.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:29:26.342148
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 2
    right_0 = Right(var_0)
    lazy = right_0.to_lazy()
    assert lazy.resolve() == 2


# Generated at 2022-06-25 23:29:31.856105
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    var_0 = 'test_string_value'
    right_0 = Right(var_0)
    expected_result = var_0
    
    # Execute
    result = right_0.to_lazy()
    
    # Verify
    assert result.value() == expected_result


# Generated at 2022-06-25 23:29:34.945022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Right(1)
    var_1 = Lazy(lambda: 1)
    assert var_0.to_lazy() == var_1


# Generated at 2022-06-25 23:29:44.195070
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()

    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.value() is None)

    var_0 = 'abc'
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()

    assert(isinstance(lazy_0, Lazy))
    assert(lazy_0.value() is 'abc')

    var_0 = 5
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()

    assert(isinstance(lazy_0, Lazy))

# Generated at 2022-06-25 23:29:48.728558
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = 1
    left_0 = Left(var_0)
    right_0 = Right(var_1)
    test_0 = right_0.to_lazy()
    assert test_0.value() == var_1
    test_1 = left_0.to_lazy()
    assert test_1.value() == var_0


# Generated at 2022-06-25 23:29:55.578335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = lambda x: x + 1
    left_0 = Left(var_0)

    var_1 = left_0.to_lazy()
    assert isinstance(var_1, Lazy)

    var_2 = var_1.eval()
    assert var_2 == var_0


# Generated at 2022-06-25 23:30:01.173278
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    except_to_lazy = None

    left_0 = Left(0)
    to_lazy_0 = left_0.to_lazy().value
    assert to_lazy_0() == 0

    right_0 = Right(0)
    to_lazy_1 = right_0.to_lazy().value
    assert to_lazy_1() == 0



# Generated at 2022-06-25 23:30:03.354582
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:30:07.148187
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = Lazy(lambda: var_0)
    assert left_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:30:11.003685
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Definition of var 'left_0'
    var_0 = None
    # Declaration of var 'left_0'
    left_0 = Left(var_0)
    # Call to method 'to_lazy'

# Generated at 2022-06-25 23:30:15.418315
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    test_value_0 = left_0.to_lazy()
    assert(isinstance(test_value_0, Lazy))
    test_value_1 = right_0.to_lazy()
    assert(isinstance(test_value_1, Lazy))



# Generated at 2022-06-25 23:30:18.252407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    result = left_0.to_lazy()
    assert result  # TODO not implemented



# Generated at 2022-06-25 23:30:22.809214
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() is None
    var_1 = 2
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.value() is 2


# Generated at 2022-06-25 23:30:25.550267
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy = left_0.to_lazy()
    assert lazy.value() is left_0


# Generated at 2022-06-25 23:30:28.502079
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:30:36.432182
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_10 = Left(None)
    var_11 = Right(1)
    var_12 = var_10.to_lazy()
    var_13 = var_12.get()
    var_14 = var_11.to_lazy()
    var_15 = var_14.get()
    assert var_13 == None
    assert var_15 == 1


# Generated at 2022-06-25 23:30:40.361404
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Input parameters
    var_0 = None
    left_0 = Left(var_0)
    # Output parameters
    out_0 = left_0.to_lazy()
    assert isinstance(out_0, Lazy)


# Generated at 2022-06-25 23:30:47.591168
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = lambda: var_0
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_2 = lazy_0.get()
    var_3 = var_2()
    assert var_3 == var_0
    var_4 = right_0.to_lazy()
    var_5 = var_4.get()
    var_6 = var_5()
    assert var_6 == var_0


# Generated at 2022-06-25 23:30:52.256713
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_0 = Lazy(lambda: 'abc')
    either_0 = Right(lazy_0)
    var_0 = either_0.to_lazy()
    var_1 = var_0.map(lambda a: a.to_string())
    var_2 = var_1.get()
    var_2.should.be.equal('abc')


# Generated at 2022-06-25 23:30:58.174098
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_19 = 1
    left_19 = Left(var_19)
    lazy_19 = left_19.to_lazy()
    test_assert(isinstance(lazy_19, Lazy), True)

    var_20 = 1
    right_20 = Right(var_20)
    lazy_20 = right_20.to_lazy()
    test_assert(isinstance(lazy_20, Lazy), True)
    test_assert(lazy_20.value(), 1)



# Generated at 2022-06-25 23:31:06.335477
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    boolean_0 = lazy_0.is_forced()
    var_1 = None
    left_1 = Left(var_1)
    lazy_1 = left_1.to_lazy()
    boolean_1 = lazy_1.is_forced()
    assert not boolean_1 and not boolean_0, 'Expected: %s and %s, but got %s and %s' % (False, False, boolean_0, boolean_1)


# Generated at 2022-06-25 23:31:07.325308
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    return


# Generated at 2022-06-25 23:31:10.168600
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    either_0 = Left(var_0)
    value_0 = either_0.to_lazy()
    assert value_0.value == var_0


# Generated at 2022-06-25 23:31:18.917256
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    left_0.to_lazy()
    left_1 = Left(None)
    left_1.to_lazy()
    left_2 = Left(None)
    left_2.to_lazy()
    left_3 = Left(None)
    left_3.to_lazy()
    left_4 = Left(None)
    left_4.to_lazy()
    left_5 = Left(None)
    left_5.to_lazy()
    left_6 = Left(None)
    left_6.to_lazy()
    left_7 = Left(None)
    left_7.to_lazy()
    left_8 = Left(None)
    left_8.to_lazy()
    left_9 = Left(None)


# Generated at 2022-06-25 23:31:22.595281
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:31:35.719154
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left("part")
    right = Right("part")
    left_lazy = left.to_lazy()
    right_lazy = right.to_lazy()

    assert left.value == left_lazy.value()
    assert right.value == right_lazy.value()



# Generated at 2022-06-25 23:31:42.124224
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    val_0 = "text"
    left_0 = Left(val_0)
    assert left_0.to_lazy() == Lazy(lambda: val_0)

    val_1 = "text"
    right_1 = Right(val_1)
    assert right_1.to_lazy() == Lazy(lambda: val_1)


# Generated at 2022-06-25 23:31:54.081920
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy().value()
    var_2 = None
    var_3 = var_2
    assert var_1 == var_3

    var_0 = (1, 2, 3)
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy().value()
    var_2 = (1, 2, 3)
    var_3 = var_2
    assert var_1 == var_3

    var_0 = "This is a string"
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy().value()
    var_2 = "This is a string"
    var_3 = var_2
   

# Generated at 2022-06-25 23:32:03.687445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print('test_Either_to_lazy')
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1).eval() == 1
    assert Lazy(lambda: Box(1)).eval() == Box(1)
    assert Lazy(lambda: Try(1)).eval() == Try(1)
    assert Lazy(lambda: Try.raise_error(1)).eval() == Try.raise_error(1)
    assert Lazy(lambda: Maybe(1)).eval() == Maybe(1)
    assert Lazy(lambda: Maybe.nothing()).eval() == Maybe.nothing()

# Generated at 2022-06-25 23:32:07.974022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(1)
    var_1 = var_0.to_lazy()
    var_2 = var_1.value()
    var_3 = left(var_2)

    var_4 = Left(1)
    var_5 = var_4.to_lazy()
    var_6 = var_5.value()
    var_7 = left(var_6)



# Generated at 2022-06-25 23:32:10.946266
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    either_0 = Left(var_0)
    lazy_0 = either_0.to_lazy()
    str_0 = lazy_0.get()
    assert type(str_0) is str


# Generated at 2022-06-25 23:32:16.836325
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()

    assert lazy_0.is_equal_to(Lazy(lambda: var_0))

    var_1 = None
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()

    assert lazy_1.is_equal_to(Lazy(lambda: var_1))


# Generated at 2022-06-25 23:32:22.327314
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)

    assert left_0.case(
        error=lambda a: 1,
        success=lambda a: 2
    ) == 1

    assert right_0.case(
        error=lambda a: 1,
        success=lambda a: 2
    ) == 2



# Generated at 2022-06-25 23:32:24.142662
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:28.491233
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    # it can be resolved multiple times
    var_0 = 1
    right_0 = Right(var_0)
    lazy_var_0 = right_0.to_lazy()

    def func_0():
        return var_0

    func_0()
    assert lazy.Lazy(func_0) == lazy_var_0


# Generated at 2022-06-25 23:32:55.391417
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:32:58.960436
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(1)
    var_1 = Right(1)
    var_2 = var_1.to_lazy()
    var_3 = var_2.get()
    var_4 = var_0.to_lazy()
    var_5 = var_4.get()


# Generated at 2022-06-25 23:33:02.384472
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def var_0():
        return 0

    @decorator_0
    def var_1():
        return 0

    var_2 = Lazy(var_0)

    # Invoke method to_lazy
    Either.to_lazy(var_2)



# Generated at 2022-06-25 23:33:07.232424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left("")
    expected_result_0 = Lazy(lambda: "")
    actual_result_0 = var_0.to_lazy()
    assert expected_result_0 == actual_result_0
    var_1 = Right("")
    expected_result_1 = Lazy(lambda: "")
    actual_result_1 = var_1.to_lazy()
    assert expected_result_1 == actual_result_1


# Generated at 2022-06-25 23:33:14.288929
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy()
    var_1 = float("nan")
    left_1 = Left(var_1)
    assert left_1.to_lazy()
    var_2 = float("nan")
    right_2 = Right(var_2)
    assert right_2.to_lazy()
    var_3 = "WEWQ"
    right_3 = Right(var_3)
    assert right_3.to_lazy()


# Generated at 2022-06-25 23:33:18.391782
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Lazy(lambda: 2)
    right_0 = Right(var_0)
    result_0 = right_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert not (result_0 is var_0)
    assert result_0.force() == 2


# Generated at 2022-06-25 23:33:23.599281
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_3 = None
    left_3 = Left(var_3)
    lazy_3 = left_3.to_lazy()
    assert hasattr(lazy_3, 'value')
    assert lazy_3.value() == var_3
    var_4 = None
    right_4 = Right(var_4)
    lazy_4 = right_4.to_lazy()
    assert hasattr(lazy_4, 'value')
    assert lazy_4.value() == var_4


# Generated at 2022-06-25 23:33:26.455838
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    class_0 = left_0.to_lazy()
    class_1 = left_0.to_lazy()
    assert class_0.value == class_1.value


# Generated at 2022-06-25 23:33:32.521617
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def callback() -> int:
        return 10
    var_0 = Lazy(callback)
    from pymonet.either import Either
    var_1 = Either(var_0)
    var_2 = var_1.to_lazy()
    var_3 = Lazy
    var_4 = isinstance(var_2, var_3)
    var_5 = None
    var_6 = var_2.value
    var_7 = var_6()
    assert var_7 == 10, "test_Either_to_lazy failed"



# Generated at 2022-06-25 23:33:35.468184
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Lazy(lambda: 1)
    left_0 = Left(var_0)
    right_0 = Right(var_0)
    assert left_0.to_lazy() == right_0.to_lazy() == var_0


# Generated at 2022-06-25 23:34:22.748664
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:34:33.876754
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_Either_to_lazy_0():
        var_0 = True
        right_0 = Right(var_0)
        ret_0 = right_0.to_lazy()
        ret_1 = ret_0.value()
        assert ret_1 is var_0

    def test_Either_to_lazy_1():
        var_0 = None
        left_0 = Left(var_0)
        ret_0 = left_0.to_lazy()
        ret_1 = ret_0.value()
        assert ret_1 is var_0

    def test_Either_to_lazy_2():
        var_0 = None
        left_0 = Right(var_0)
        ret_0 = left_0.to_lazy()
        ret_1 = ret_0.value()

# Generated at 2022-06-25 23:34:43.261485
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)

    var_1 = left_0.to_lazy()

    var_2 = None
    assert var_1.value == var_2

    var_3 = True
    var_4 = True

    if var_3:
        var_4 = False

    var_5 = True

    if var_4:
        var_5 = False

    var_6 = False

    if var_5:
        var_6 = True

    if var_6:
        var_7 = None
    else:
        var_8 = None
        var_9 = 1

        if var_8:
            var_9 = 2

        if var_8:
            var_9 = 3

        var_10 = 1
        var_11 = True
        var

# Generated at 2022-06-25 23:34:49.896456
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(None)
    var_1 = var_0.to_lazy()
    var_2 = var_1.value()
    var_3 = Right(None)
    var_4 = var_3.to_lazy()
    var_5 = var_4.value()
    assert var_2 == None
    assert var_5 == None


# Generated at 2022-06-25 23:34:53.154259
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(lambda : var_0)


# Generated at 2022-06-25 23:34:55.514908
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()



# Generated at 2022-06-25 23:34:57.835282
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 1
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    lazy_0.to_box()


# Generated at 2022-06-25 23:35:03.010964
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left = Left(var_0)
    lazy = left.to_lazy()
    assert lazy.valuethunk() is None, '<lazy>.valuethunk() is None'
    var_1 = '123456789'
    right = Right(var_1)
    lazy_1 = right.to_lazy()
    assert lazy_1.valuethunk() == '123456789', '<lazy>.valuethunk() == "123456789"'



# Generated at 2022-06-25 23:35:07.577833
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = lazy_0.evaluate()
    assert var_1 is None
    var_2 = 'a'
    right_0 = Right(var_2)
    lazy_1 = right_0.to_lazy()
    var_3 = lazy_1.evaluate()
    assert var_3 == 'a'


# Generated at 2022-06-25 23:35:08.788181
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(5)
    var_1 = var_0.to_lazy()


# Generated at 2022-06-25 23:36:45.680483
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy().value() == None


# Generated at 2022-06-25 23:36:47.403458
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Either.to_lazy(Right(0))


# Generated at 2022-06-25 23:36:50.845946
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()

# Generated at 2022-06-25 23:36:54.595234
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert not lazy_0.is_evaluated()
    result_0 = lazy_0.eval()
    assert var_0 is result_0



# Generated at 2022-06-25 23:37:00.389745
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Case 1
    var_1 = None
    assert Left(var_1).to_lazy() == Lazy(lambda: var_1)

    # Case 2
    var_2 = None
    assert Right(var_2).to_lazy() == Lazy(lambda: var_2)



# Generated at 2022-06-25 23:37:03.803965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    left_0 = Left(var_0)
    left_1 = left_0.to_lazy()
    value = left_1.value()
    out = value
    assert out == var_0


# Generated at 2022-06-25 23:37:05.989162
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 3
    right_0 = Right(var_0)


# Generated at 2022-06-25 23:37:07.830663
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('0').to_lazy().map(lambda x: x).value() == '0'
    assert Right('0').to_lazy().map(lambda x: x).value() == '0'


# Generated at 2022-06-25 23:37:09.753452
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test case 0
    var_0 = None
    right_0 = Right(var_0)
    assert right_0.to_lazy().value() == var_0


# Generated at 2022-06-25 23:37:12.885549
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    assert var_1 is not None
