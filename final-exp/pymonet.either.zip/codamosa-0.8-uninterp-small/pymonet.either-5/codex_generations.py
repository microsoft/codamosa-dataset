

# Generated at 2022-06-25 23:27:37.513922
# Unit test for method case of class Either
def test_Either_case():
    assert isinstance(Left(1).case(lambda x: x * 2, lambda x: x + 2), int)
    assert Left(1).case(lambda x: x * 2, lambda x: x + 2) == 2
    assert isinstance(Right(1).case(lambda x: x * 2, lambda x: x + 2), int)
    assert Right(1).case(lambda x: x * 2, lambda x: x + 2) == 3



# Generated at 2022-06-25 23:27:47.076057
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    float_0 = 617.0
    right_0 = Right(float_0)
    right_1 = Right(float_0)
    left_0 = Left(float_0)
    box_0 = Box(float_0)
    try_0 = Try(float_0)
    lazy_0 = Lazy(lambda: float_0)
    maybe_0 = Maybe(float_0)
    validation_0 = Validation(float_0)
    assert right_0 == right_1
    assert right_0 != right_1
    assert right_0 == left_0

# Generated at 2022-06-25 23:27:56.691515
# Unit test for method case of class Either
def test_Either_case():
    float_0 = 7.0
    left_0 = Left(float_0)

# Generated at 2022-06-25 23:28:05.116535
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 617.0
    float_1 = 1.618
    right_0 = Right(float_0)
    right_1 = Right(float_0)
    assert right_0 == right_1
    right_0 = Right(float_0)
    right_1 = Left(float_1)
    assert (not right_0 == right_1)
    right_0 = Right(float_0)
    right_1 = Right(float_1)
    assert (not right_0 == right_1)
    right_0 = Left(float_0)
    right_1 = Left(float_1)
    assert (not right_0 == right_1)
    right_0 = Left(float_1)
    right_1 = Left(float_1)
    assert right_0 == right_1



# Generated at 2022-06-25 23:28:13.077069
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 617.0
    right_0 = Right(float_0)
    right_1 = right_0
    right_2 = right_0.to_lazy()
    right_2 = right_2.force()
    assert right_0 == right_1
    assert right_1 == right_0
    assert right_0 == right_2
    assert right_2 == right_0
    assert not (right_0 == float_0)


# Generated at 2022-06-25 23:28:22.203690
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # (1 == 2) == False
    assert not (1 == 2)
    # (2 == 2) or (2 != 2) == True
    assert (2 == 2) or (2 != 2)
    # (1 != 2) == True
    assert (1 != 2)
    # (1 == 1) or False == True
    assert (1 == 1) or False
    # (2 == 2) or (2 != 2) == True
    assert (2 == 2) or (2 != 2)
    # (1 == 2) == False
    assert not (1 == 2)
    # (1 != 2) == True
    assert (1 != 2)
    # (2 == 2) or (2 != 2) == True
    assert (2 == 2) or (2 != 2)
    # (1 != 1) == False

# Generated at 2022-06-25 23:28:26.911139
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 617.0
    float_1 = 61.7
    int_0 = 617
    left_0 = Left(float_0)
    left_1 = Left(float_1)
    left_2 = Left(int_0)
    left_3 = Left(float_0)
    right_0 = Right(float_0)
    right_1 = Right(float_1)
    right_2 = Right(int_0)
    right_3 = Right(float_0)
    assert left_0.__eq__(left_0)
    assert left_0.__eq__(left_1)
    assert left_0.__eq__(left_2)
    assert left_0.__eq__(left_3)
    assert left_0.__eq__(right_0)
   

# Generated at 2022-06-25 23:28:32.381015
# Unit test for method case of class Either
def test_Either_case():
    def funcA(a: int, b: str) -> bool:
        return True

    def funcB(a, b) -> bool:
        return False

    # Integer right
    right = Right(1)
    assert right.case(funcA, funcB)

    # String left
    left = Left("str")
    assert not left.case(funcA, funcB)


# Generated at 2022-06-25 23:28:41.471971
# Unit test for method case of class Either
def test_Either_case():
    str_0 = 'cba'
    list_0 = [str_0]
    str_1 = 'abc'
    tuple_0 = (str_0, str_1)
    left_0 = Left(tuple_0)
    left_1 = left_0.case(lambda str_0: str_0, lambda str_1: list_0)
    float_0 = 617.0
    float_1 = 763.0
    float_2 = float_1 * float_1
    float_3 = float_2 + float_2
    float_4 = float_3 * float_1
    float_5 = float_0 - float_4
    float_6 = float_0 + float_1
    float_7 = float_5 + float_6
    float_8 = float_6 + float_6


# Generated at 2022-06-25 23:28:46.610334
# Unit test for method case of class Either
def test_Either_case():
    def left_0():
        return Left(1)

    def right_0():
        return Right(2)

    assert left_0().case(error=lambda x: x * x, success=lambda x: x - x) == 1

    assert right_0().case(error=lambda x: x * x, success=lambda x: x - x) == 0



# Generated at 2022-06-25 23:28:53.575595
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 589.0
    int_0 = 838
    lazy_0 = Lazy(float_0, int_0)
    either_0 = Either(float_0, int_0)
    lazy_1 = either_0.to_lazy()
    assert(lazy_0 == lazy_1)


# Generated at 2022-06-25 23:28:57.250829
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return Right(0)

    lazy = func().to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == Right(0)



# Generated at 2022-06-25 23:29:01.016785
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 2.0
    right_0 = Right(float_0)
    lazy_0 = right_0.to_lazy()
    float_1 = lazy_0.value()
    assert_equals(float_1, float_0)


# Generated at 2022-06-25 23:29:02.119234
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:29:09.423803
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print('Unit test for method to_lazy of class Either')
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right_0 = Right(var_0)
    right

# Generated at 2022-06-25 23:29:12.848016
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_1 = Right(0)
    var_0 = right_1.to_lazy()


# Generated at 2022-06-25 23:29:15.883023
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'foobar'
    right_0 = Right(str_0)
    # AssertionError: assert (False is True)
    assert right_0.to_lazy() is None


# Generated at 2022-06-25 23:29:18.639227
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
  float_0 = 0.0
  right_0 = Right(float_0)
  var_0 = right_0.to_lazy()
  assert var_0.value == float_0


# Generated at 2022-06-25 23:29:22.432297
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
    assert(isinstance(var_0, Lazy))


# Generated at 2022-06-25 23:29:24.235069
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert not 'to_lazy' in dir(Either)


# Generated at 2022-06-25 23:29:31.144296
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def test_case_0():
        float_0 = 617.0
        right_0 = Right(float_0)
        var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:29:38.487492
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()

    float_1 = 516.0
    right_1 = Right(float_1)
    var_1 = right_1.to_lazy()

    float_2 = 255.0
    right_2 = Right(float_2)
    var_2 = right_2.to_lazy()

    float_3 = 891.0
    right_3 = Right(float_3)
    var_3 = right_3.to_lazy()



# Generated at 2022-06-25 23:29:41.099948
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:29:43.853643
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 27
    right_0 = Right(int_0)
    var_0 = right_0.to_lazy()
    assert var_0.value() == int_0



# Generated at 2022-06-25 23:29:47.469982
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given:
    float_0 = 52933.52
    right_0 = Right(float_0)
    # When:
    var_0 = right_0.to_lazy()
    # Then:
    assert var_0.function() == right_0.value


# Generated at 2022-06-25 23:29:50.708868
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    left = Left(617.0)
    assert left.to_lazy() == Lazy(lambda : 617.0)
    right = Right(617.0)
    assert right.to_lazy() == Lazy(lambda : 617.0)


# Generated at 2022-06-25 23:30:00.677578
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 12.0
    float_1 = -3.0
    float_2 = 4.0
    float_3 = -5.0

    var_0 = Right(float_0)
    var_0 = var_0.to_lazy()

    var_1 = Right(float_1)
    var_1 = var_1.to_lazy()

    var_2 = Right(float_2)
    var_2 = var_2.to_lazy()
    var_3 = Right(float_3)
    var_3 = var_3.to_lazy()

    float_4 = var_0.value()
    float_5 = float_0 / float_4

    float_6 = var_1.value()
    float_7 = float_1 / float_6

    float_

# Generated at 2022-06-25 23:30:02.951013
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test with an empty list
    list_0 = []
    right_0 = Right(list_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:30:05.600096
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:30:08.527204
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test with Right
    value = "string"
    either = Right(value)

    # Check, that lazy has the same value
    assert either.to_lazy().value() == value


# Generated at 2022-06-25 23:30:24.278069
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    try:
        from inspect import signature
        from pymonet.function import curry
        from pymonet.lazy import Lazy
        from pymonet.box import Box
    except ImportError:
        print('ImportError: No module named {0}'.format('x'))
    else:
        # Test of static method to_lazy of class Either:
        # Insufficient number of arguments, expected 1
        try:
            Right.to_lazy()
        except TypeError:
            pass
        else:
            raise AssertionError
        # Too many positional arguments, expected 1
        try:
            Right.to_lazy(835, 1761)
        except TypeError:
            pass
        else:
            raise AssertionError
        # Right
        float_0 = 722.0
        right_0 = Right

# Generated at 2022-06-25 23:30:28.087954
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(1231)
    lazy_0 = var_0.to_lazy()
    var_1 = Right(1231)
    lazy_0 = var_1.to_lazy()


# Generated at 2022-06-25 23:30:36.137132
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    var_0 = left_0.to_lazy()
    maybe_0 = Maybe.just(279)
    right_0 = Right(maybe_0)
    right_1 = right_0.to_maybe()
    right_2 = Right(right_1)
    var_1 = right_2.to_lazy()
    str_0 = "AjRm{x6E"
    str_1 = "B!"
    left_1 = Left(str_1)
    left_2 = left_1.to_maybe()
    left_3 = Left(left_2)
    left_4 = left_3.ap(right_2)
    left_5 = left_3.ap(left_4)
    left_6 = Left(left_5)
    var

# Generated at 2022-06-25 23:30:41.123483
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -8.0
    either_0 = Left(float_0)
    lazy_0 = either_0.to_lazy()
    boolean_0 = lazy_0.is_lazy()
    var_0 = lazy_0.value()
    boolean_1 = lazy_0.is_lazy()



# Generated at 2022-06-25 23:30:42.032759
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:30:47.447807
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # create new Right
    var_0 = Right(617.0)
    # check if function to_lazy return result of expected type
    assert isinstance(var_0.to_lazy(), Lazy)
    # check if function to_lazy return result with expected value
    assert var_0.to_lazy().eval() == 617.0


# Generated at 2022-06-25 23:30:50.851040
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    tuple_0 = Tuple(None, None)
    left_0 = Left(tuple_0)
    left_1 = left_0.to_lazy()
func_0 = func_0 = left_1.value

# Generated at 2022-06-25 23:30:56.019342
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
    var_1 = var_0.map(lambda v: v + 1.0)
    int_0 = 1
    var_1 = var_1.bind(lambda v: Maybe.just(int_0) if int_0 == v else Maybe.nothing())


# Generated at 2022-06-25 23:30:56.588826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:31:02.218281
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    r = right_0.to_lazy()
    assert isinstance(r, Lazy)
    assert r.evaluate() == float_0


# Generated at 2022-06-25 23:31:18.225887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:20.840302
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:25.659195
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    lazy_0 = right_0.to_lazy()
    assert(lazy_0.value() == float_0)


# Generated at 2022-06-25 23:31:33.904403
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:31:40.409460
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func_0(arg_0):
        return arg_0

    float_0 = 12581.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
    var_1 = var_0.map(func_0)
    var_2 = var_1.get()
    var_3 = var_0.get()
    assert(var_2 == var_3 == float_0)


# Generated at 2022-06-25 23:31:50.022637
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = "1"
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = str(lazy_0.value())
    assert str_1 == "1"
    str_2 = str(lazy_0.value())
    assert str_2 == "1"
    str_3 = str(lazy_0.value())
    assert str_3 == "1"
    str_4 = str(lazy_0.value())
    assert str_4 == "1"


# Generated at 2022-06-25 23:32:00.125362
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Unit test for method __init__ of class Left
    def test_Left_init():

        def test_case_0():
            string_0 = 'Success on monad'
            left_0 = Left(string_0)

        test_case_0()

    test_Left_init()

    # Unit test for method __init__ of class Right
    def test_Right_init():

        def test_case_0():
            string_0 = 'Success on monad'
            right_0 = Right(string_0)

        test_case_0()

    test_Right_init()

    # Unit test for method __eq__ of class Left
    def test_Left_eq():

        def test_case_0():
            string_0 = 'Success on monad'
            left_0 = Left(string_0)
            left

# Generated at 2022-06-25 23:32:02.728713
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:05.559688
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_0 = "pyt"
    right_1 = Right(string_0)
    var_1 = right_1.to_lazy()
    string_1 = var_1.value()
    assert string_1 == "pyt"


# Generated at 2022-06-25 23:32:07.901443
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 762
    right_0 = Right(int_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:32:37.121471
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    a_var = - 10.0
    a_Either = Right(a_var)
    a_lazy = a_Either.to_lazy()
    a_var_1 = a_lazy.get()



# Generated at 2022-06-25 23:32:39.254918
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 68.670
    right_0 = Right(float_0)
    result_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:44.001058
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 14.06
    right_0 = Right(float_0)
    var_0 = right_0.case(lambda v: v + 100, lambda v: v * 5)
    var_1 = right_0.to_lazy()
    var_2 = var_1.map(lambda v: v * 5).force()
    return var_0 == var_2


# Generated at 2022-06-25 23:32:47.091763
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:48.937209
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 10.0
    right_0 = Right(value)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:51.058100
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:53.550461
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 42
    either = Right(value)
    lazy = either.to_lazy()
    assert callable(lazy.value)
    assert lazy.value() == value


# Generated at 2022-06-25 23:32:57.784678
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    integer_0 = Box(-748)
    lazy_0 = integer_0.to_lazy()
    integer_1 = Lazy(lambda: (integer_0.value))
    var_0 = integer_1 == lazy_0


# Generated at 2022-06-25 23:32:59.521354
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(617.0).to_lazy() == Lazy(lambda: 617.0).to_lazy()


# Generated at 2022-06-25 23:33:05.815261
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_1():
        int_0 = 906
        left_0 = Left(int_0)
        var_0 = left_0.to_lazy()
        var_1 = var_0.unbox()
    #
    def test_case_2():
        str_0 = '608173'
        right_0 = Right(str_0)
        var_0 = right_0.to_lazy()
        var_1 = var_0.unbox()
    #
    def test_case_3():
        int_0 = 849
        left_0 = Left(int_0)
        var_0 = left_0.to_lazy()
        var_1 = var_0.unbox()
    #
    def test_case_4():
        list_0 = [0]

# Generated at 2022-06-25 23:34:06.440432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:34:09.632898
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
    var_0 = right_0.to_try()


# Generated at 2022-06-25 23:34:18.397658
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from random import randint
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()


# Generated at 2022-06-25 23:34:21.838035
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:34:32.939682
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    float_0 = 617.0
    right_0 = Right(float_0)
    lazy_0 = right_0.to_lazy()
    var_0 = lazy_0.map(lambda x: x * float_0)
    var_1 = lazy_0.bind(lambda x: Try.just(x * float_0))
    var_2 = lazy_0.ap(Lazy.pure(lambda x: x * float_0))
    var_3 = lazy_0.to_maybe()
    var_4 = lazy_0.to_try()
    var_5 = lazy_0.to_either()


# Generated at 2022-06-25 23:34:36.924346
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    initial_value = 617.0
    function = lambda: initial_value
    either_123 = Right(function())
    assert isinstance(either_123.to_lazy(), Lazy)



# Generated at 2022-06-25 23:34:45.229767
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    float_1 = 3.14
    float_2 = 0.0
    float_3 = 0.0
    str_0 = 'test string'
    left_0 = Either.left(str_0)
    left_1 = left_0.to_lazy()
    assert left_1.value() == str_0
    left_2 = Either.left(float_2)
    left_3 = left_2.to_lazy()
    assert left_3.value() == float_2
    left_4 = Either.left(float_3)
    left_5 = left_4.to_lazy()
    assert left_5.value() == float_3
    right_0 = Either.right(float_1)
    right_1 = right_0.to_l

# Generated at 2022-06-25 23:34:48.423214
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass



# Generated at 2022-06-25 23:34:59.419283
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_1 = 33.0
    left_0 = Left(float_1)
    var_0 = left_0.to_lazy()
    bool_0 = var_0.is_value_present()
    bool_1 = True
    assert bool_0 == bool_1

    float_2 = 617.0
    right_0 = Right(float_2)
    var_1 = right_0.to_lazy()
    var_2 = var_1.get()
    float_3 = var_2
    assert float_3 == float_2

    float_4 = 617.0
    right_1 = Right(float_4)
    var_3 = right_1.to_lazy()
    var_4 = var_3.is_value_present()
    bool_2 = var_4


# Generated at 2022-06-25 23:35:01.672466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_6 = Right(6)
    var_7 = var_6.to_lazy()
    var_8 = var_7.value()
    assert var_8==6

# Generated at 2022-06-25 23:37:28.370100
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    int_0 = 617
    try_0 = Try(int_0)

    assert Lazy(lambda: int_0) == try_0.to_lazy()
    assert try_0 == Lazy(lambda: int_0).to_try()
test_Either_to_lazy()


# Generated at 2022-06-25 23:37:30.178616
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 617.0
    right_0 = Right(float_0)
    var_0 = right_0.to_lazy()
