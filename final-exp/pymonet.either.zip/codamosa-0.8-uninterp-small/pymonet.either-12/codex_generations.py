

# Generated at 2022-06-25 23:27:33.306644
# Unit test for method case of class Either
def test_Either_case():
    object_0 = module_0.object()
    assert Right(object_0).case(lambda _: _, lambda _: _) == object_0
    assert Left(object_0).case(lambda _: _, lambda _: _) == object_0
    assert Right(object_0).case(lambda _: _, lambda _: _) == object_0, 'assertion #3'


# Generated at 2022-06-25 23:27:37.038121
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy
    pymonet.lazy = reload(pymonet.lazy)
    left_0 = Left(int)
    lazy_0 = left_0.to_lazy()
    int_0 = lazy_0.value
    assert int_0 == int


# Generated at 2022-06-25 23:27:39.032672
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left(object())
    left_1 = Left(object())
    assert left_0 == left_1


# Generated at 2022-06-25 23:27:43.164781
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    box = Box(object())
    result = box.to_either().to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() is box.value


# Generated at 2022-06-25 23:27:46.692733
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    right_1 = Right(object_0)
    assert right_0 == right_1
    left_0 = Left(object_0)
    assert left_0 != right_0


# Generated at 2022-06-25 23:27:48.740208
# Unit test for method case of class Either
def test_Either_case():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    right_0 = Right(object_0)


# Generated at 2022-06-25 23:27:53.116722
# Unit test for method case of class Either
def test_Either_case():
    object_0 = module_0.object()
    string_0 = module_0.str()
    left_0 = Left(object_0)
    left_0.case(object_0, string_0)

import pymonet.monad_try as module_1


# Generated at 2022-06-25 23:27:56.723575
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == object_0


# Generated at 2022-06-25 23:27:58.758585
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either[int](3) == Either[int](3), 'assert failed'
    assert Either[object](object()) == Either[object](object()), 'assert failed'


# Generated at 2022-06-25 23:28:05.545090
# Unit test for method case of class Either
def test_Either_case():
    object_0 = module_0.object()
    result_0 = Right(1).case(lambda x: "no", lambda x: "yes")
    assert result_0 == "yes"
    result_1 = Left(1).case(lambda x: "no", lambda x: "yes")
    assert result_1 == "no"


# Generated at 2022-06-25 23:28:11.333530
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = Right(var_1)
    var_2 = Right(var_1)
    assert var_0 == var_2


# Generated at 2022-06-25 23:28:17.195088
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def fun_0():
        var_0 = object()
        var_1 = Either.Left(var_0)
        var_2 = var_1.to_lazy()
    fun_0()

    def fun_1():
        var_0 = object()
        var_1 = Either.Right(var_0)
        var_2 = var_1.to_lazy()
    fun_1()


# Generated at 2022-06-25 23:28:26.077638
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    # check if all of them are equal
    assert Left(var_0).__eq__(Left(var_0))
    assert not Left(var_0).__eq__(Left((var_0)))
    assert not Left(var_0).__eq__(var_0)
    assert not Left(var_0).__eq__(var_0)
    assert not Left(var_0).__eq__(None)
    assert Right(var_0).__eq__(Right(var_0))
    assert not Right(var_0).__eq__(Right(var_0))
    assert not Right(var_0).__eq__(var_0)
    assert not Right(var_0).__eq__(var_0)
    assert not Right(var_0).__eq__(None)


# Generated at 2022-06-25 23:28:29.422737
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right_1 = Right(object())
    right_2 = Right(object())
    assert right_1 == right_1
    assert right_1 != right_2


# Generated at 2022-06-25 23:28:34.879974
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test __eq__ of class Either
    """
    var_0 = Either(object())
    var_1 = Either(object())
    var_2 = Either(object())
    var_3 = object()
    var_4 = object()
    assert var_0 == var_1
    assert not (var_1 == var_2)
    assert not (var_2 == var_3)
    assert var_0 == var_4

# Generated at 2022-06-25 23:28:40.283003
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = Right(object())
    var_1 = Left(object())
    var_2 = Right(object())
    var_3 = var_0 == var_1
    var_4 = var_0 == var_2
    var_5 = var_1 == var_0
    var_6 = var_1 == var_2
    var_7 = var_2 == var_0
    var_8 = var_2 == var_1


# Generated at 2022-06-25 23:28:50.788302
# Unit test for method __eq__ of class Either

# Generated at 2022-06-25 23:28:58.906296
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # 1. Create instance of class 'Either' with the parameters: value
    var_0 = Either(object)

    # 2. Create instance of class 'Either' with the parameters: value
    var_1 = Either(object)

    # 3. Call method '__eq__' of class Either with the parameter: other
    var_2 = var_0.__eq__(var_1)

    # 4. Check if the value of var_2 is equal to the expected value
    if var_2 is not True:
        raise Exception("AssertionError")


# Generated at 2022-06-25 23:29:04.324602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Left(object())
    var_0.to_lazy() is Lazy(lambda: var_0.value)
    var_0 = Right(object())
    var_0.to_lazy() is Lazy(lambda: var_0.value)
    var_0 = Left(object())
    var_0.to_lazy() is Lazy(lambda: var_0.value)
    return


# Generated at 2022-06-25 23:29:14.907906
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()
    var_8 = object()
    var_9 = object()
    var_10 = object()
    var_11 = object()
    var_12 = object()
    var_13 = object()
    var_14 = object()
    var_15 = object()
    var_16 = object()
    var_17 = object()
    var_18 = object()
    var_19 = object()
    var_20 = object()
    var_21 = object()
    var_22 = object()
    var_23 = object()
    var_24 = object()

# Generated at 2022-06-25 23:29:19.285796
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = object()
    assert Left(var_0).to_lazy()._value() == var_0
    assert Right(var_0).to_lazy()._value() == var_0


# Generated at 2022-06-25 23:29:21.486162
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy()._factory() == 1
    assert Left(1).to_lazy()._factory() == 1


# Generated at 2022-06-25 23:29:26.544288
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = object()
    var_1 = Right(var_0)
    var_2 = var_1.to_lazy()
    assert isinstance(var_2, Either)
    var_3 = var_2.value()
    assert var_3 == var_0


# Generated at 2022-06-25 23:29:36.901559
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(object())
    var_1 = var_0.to_lazy()
    var_2 = var_1.value()
    assert var_2 == var_0.value
    assert var_0.to_lazy() == var_0.to_lazy()
    assert var_0.to_lazy() != Either(object()).to_lazy()

    var_3 = Left(object())
    var_4 = var_3.to_lazy()
    var_5 = var_4.value()
    assert var_5 == var_3.value
    assert var_3.to_lazy() == var_3.to_lazy()
    assert var_3.to_lazy() != Either(object()).to_lazy()



# Generated at 2022-06-25 23:29:40.318927
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    tmp0 = None
    tmp1 = Right(tmp0)
    tmp2 = tmp1.to_lazy()
    assert tmp2.is_defined()
    tmp3 = tmp2.get()
    assert tmp3 == tmp0


# Generated at 2022-06-25 23:29:47.469780
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        """
        Left(1).to_lazy() == Lazy(lambda: 1)
        """
        from pymonet.lazy import Lazy
        assert Left(1).to_lazy() == Lazy(lambda: 1)

    def test_case_1():
        """
        Right(1).to_lazy() == Lazy(lambda: 1)
        """
        from pymonet.lazy import Lazy
        assert Right(1).to_lazy() == Lazy(lambda: 1)

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 23:29:52.715199
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    var_10 = object()

    # When
    var_20 = Right(var_10).to_lazy()

    # Then
    var_21 = var_20.force()
    var_22 = isinstance(var_20, Right)
    var_23 = var_21.is_right()
    var_24 = var_21.is_left()
    var_25 = var_21 == var_10
    var_30 = Left(var_10).to_lazy()
    var_31 = var_30.force()
    var_32 = isinstance(var_30, Left)
    var_33 = var_31.is_right()
    var_34 = var_31.is_left()
    var_35 = var_31 == var_10



# Generated at 2022-06-25 23:29:56.028153
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = object()
    var_1 = Left(var_0)
    var_2 = var_1.to_lazy()
    var_3 = var_2.value()
    assert(var_3 == var_0)


# Generated at 2022-06-25 23:30:00.488260
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    var_0 = object()

    # When
    var_1 = Left(var_0)
    var_2 = var_1.to_lazy()
    var_3 = var_2.get()

    # Then
    assert var_0 == var_3


# Generated at 2022-06-25 23:30:05.219535
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(object())
    var_1 = Left(object())
    var_2 = var_0.to_lazy()
    assert var_2.is_lazy(var_0.value)
    var_3 = var_1.to_lazy()
    assert var_3.is_lazy(var_1.value)


# Generated at 2022-06-25 23:30:14.699139
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func_0(var_0: object) -> object:
        return var_0
    var_0 = func_0(object())
    assert var_0 == object()
    assert var_0 == object()
    var_1 = Right(var_0)
    var_2 = var_1.to_lazy()
    assert callable(var_2.value)
    assert var_2.value() == var_0
    var_1 = Left(var_0)
    var_2 = var_1.to_lazy()
    assert callable(var_2.value)
    assert var_2.value() == var_0


# Generated at 2022-06-25 23:30:23.869592
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = object()
    #test for class Left
    var_1 = Left(var_0)
    var_2 = var_1.to_lazy()
    var_3 = var_2.get()
    var_4 = var_3 == var_0
    if var_4:
        var_5 = True
    else:
        var_5 = False
    assert var_5
    #test for class Right
    var_6 = Right(var_0)
    var_7 = var_6.to_lazy()
    var_8 = var_7.get()
    var_9 = var_8 == var_0
    if var_9:
        var_10 = True
    else:
        var_10 = False
    assert var_10


# Generated at 2022-06-25 23:30:27.146818
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # The following line will fail because types are not compatible
    var_0 = object()
    assert var_0.to_lazy().call() == var_0


# Generated at 2022-06-25 23:30:30.163923
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    either_0 = Right(object())

    # when
    function = either_0.to_lazy().value

    # then
    var_0 = object()



# Generated at 2022-06-25 23:30:34.532139
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(object())
    var_1 = var_0.to_lazy()
    assert type(var_1) == type(var_0.to_lazy())
    var_0 = Right(object())
    var_1 = var_0.to_lazy()
    assert type(var_1) == type(var_0.to_lazy())


# Generated at 2022-06-25 23:30:38.227192
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    prev_value = object()
    var_0 = Right(prev_value)
    result = var_0.to_lazy()
    assert result.value() == prev_value
    var_1 = Left(prev_value)
    result = var_1.to_lazy()
    assert result.value() == prev_value


# Generated at 2022-06-25 23:30:43.249011
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_option import Option
    from pymonet.lazy import Lazy
    assert isinstance(Either(Option.nothing()).to_lazy(), Lazy)
    assert isinstance(Either(Option.just(var_0)).to_lazy(), Lazy)


# Generated at 2022-06-25 23:30:53.234252
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

# Generated at 2022-06-25 23:31:01.629131
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Only Lazy is resolved on evaluation"""
    def _test_case_0():
        var_0 = object()
        var_1 = object()
        var_2 = object()

        # Check if Lazy is resolved on evaluation
        var_3 = Right(var_0).to_lazy()
        var_4 = Left(var_1).to_lazy()
        var_5 = Either(var_2).to_lazy()
        if var_0 != var_3.value() or var_1 != var_4.value() or var_2 != var_5.value():
            # All Lazy are resolved on evaluation
            raise AssertionError

        # Check if Box is resolved on evaluation
        var_3 = Right(var_0).to_box()
        var_4 = Left(var_1).to_box

# Generated at 2022-06-25 23:31:03.731547
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup object to test
    var_0 = Right(None)

    # Assert
    assert var_0.to_lazy()


# Generated at 2022-06-25 23:31:07.782371
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    module_0.test_case_0()

# Generated at 2022-06-25 23:31:14.608879
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_0 = right_0.to_lazy()

    # The following assertions could be written as
    # assert isinstance(lazy_0, <classname>)
    # but this form is used to work around a bug in Python 2.7
    assert isinstance(lazy_0, module_0.type(Lazy[object_0]))


# Generated at 2022-06-25 23:31:17.892646
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:31:20.261428
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()

# Generated at 2022-06-25 23:31:22.475124
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:26.724248
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:31:29.657915
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_1 = module_0.object()
    left_1 = Left(object_1)
    lazy_0 = left_1.to_lazy()
    module_0.bool(lazy_0)


# Generated at 2022-06-25 23:31:32.121001
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    _lambda_0 = lambda: Right(1)
    assert Lazy(_lambda_0) == _lambda_0().to_lazy()


# Generated at 2022-06-25 23:31:35.607529
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    right_1 = right_0.to_lazy()
    module_0.assertEqual(right_0.value, right_1.value())

# Generated at 2022-06-25 23:31:43.943967
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Right(None)
    for object_0 in (either_0,):
        object_1 = object_0.to_lazy()
        assert isinstance(object_1, (Lazy,))
        assert (object_1().value == object_0.value)
    either_0 = Left(None)
    for object_0 in (either_0,):
        object_1 = object_0.to_lazy()
        assert isinstance(object_1, (Lazy,))
        assert (object_1().value == object_0.value)


# Generated at 2022-06-25 23:31:57.000443
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    class TestLazy(Lazy):
        def __init__(self, value):
            self.value = value
            def _func():
                return value
            Lazy.__init__(self,_func)
        
        def __eq__(self,other):
            return self.value == other.value
        
    right_0 = Right(module_0.list)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, TestLazy)
    assert lazy_0 == TestLazy(module_0.list)
    

# Generated at 2022-06-25 23:31:59.891054
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)

    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:32:03.105789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = object()
  
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.get() == left_0.value


# Generated at 2022-06-25 23:32:07.755253
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    value_0 = lazy_0.value
    object_1 = module_0.object()
    right_0 = Right(object_1)
    lazy_1 = right_0.to_lazy()
    value_1 = lazy_1.value


# Generated at 2022-06-25 23:32:12.316905
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def function_0():
        return 2
    lazy_0 = Lazy(function_0)
    type_0 = type(lazy_0)
    right_0 = Right(function_0)
    left_0 = Left(function_0)
    lazy_1 = left_0.to_lazy()
    lazy_2 = right_0.to_lazy()
    assert type_0 == type(lazy_1)
    assert type_0 == type(lazy_2)
    assert lazy_0 == lazy_1
    assert lazy_0 == lazy_2
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:32:14.819869
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:32:21.655957
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    # 
    lazy_0 = right_0.to_lazy()
    test_assertion_0 = lazy_0.is_lazy()
    test_assertion_1 = lazy_0.resolve() == object_0
    left_0 = Left(object_0)
    lazy_1 = left_0.to_lazy()
    test_assertion_2 = lazy_1.is_lazy()
    test_assertion_3 = lazy_1.resolve() == object_0


# Generated at 2022-06-25 23:32:25.288309
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    object_1 = module_0.object()
    right_0 = Right(object_1)

    left_1 = left_0.to_lazy()

    assert left_1


# Generated at 2022-06-25 23:32:28.727729
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    
    object_0 = test_case_0()
    result_0 = object_0.to_lazy()
    module_0.test.test({test_case_0.__name__}, result_0)

test_Either_to_lazy()
import builtins as module_0


# Generated at 2022-06-25 23:32:30.976283
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 'test'

    right = Right(value)
    lazy = right.to_lazy()

    assert value == lazy.value()


# Generated at 2022-06-25 23:32:47.930772
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()

    left_0 = Left(object_0)
    lazy_2 = left_0.to_lazy()
    test_2 = lazy_2.eval()
    # AssertionError: <object object at 0x7f9301b5c3d0> != <object object at 0x7f9301b5c3d0>
    assert test_2 == object_0


# Generated at 2022-06-25 23:32:56.523052
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: Assertion

# Generated at 2022-06-25 23:32:58.798683
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(1)
    lazy_0 = right_0.to_lazy()

    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:33:01.084100
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == object_0


# Generated at 2022-06-25 23:33:03.495362
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    either_0 = Left(object_0)
    either_1 = either_0.to_lazy()
    assert either_1.value() == object_0


# Generated at 2022-06-25 23:33:06.154372
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0 == Lazy(lambda: object_0)


# Generated at 2022-06-25 23:33:12.400383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_0 = right_0.to_lazy()
    assert (lazy_0.value() == object_0)
    object_1 = module_0.object()
    left_0 = Left(object_1)
    lazy_1 = left_0.to_lazy()
    assert (lazy_1.value() == object_1)


if __name__ == "__main__":
    test_case_0()
    test_Either_to_lazy()

# Generated at 2022-06-25 23:33:15.196176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:33:18.354496
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # builtins (type): module
    object_0 = module_0.object()
    either_0 = Right(object_0)
    # left_0 = Left(object_0)
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:33:20.438166
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()



# Generated at 2022-06-25 23:33:50.489744
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    right_1 = right_0.to_lazy()
    left_0 = Left(object_0)
    left_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:33:53.797775
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Unit test for class Either.Left
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()
    lazy_1 = Lazy(lambda: object_0)
    assert lazy_0 == lazy_1

test_Either_to_lazy()



# Generated at 2022-06-25 23:33:57.627380
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad import is_monad
    from pymonet.lazy import Lazy

    assert is_monad(Left(None).to_lazy())
    assert is_monad(Right(None).to_lazy())

    assert Right(None).to_lazy().f() == None
    assert Left(None).to_lazy().f() == None


# Generated at 2022-06-25 23:34:05.768279
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, module_0.Lazy)
    lazy_0 = lazy_0.call()
    assert lazy_0 is object_0
    left_0 = Left(object_0)
    lazy_1 = left_0.to_lazy()
    assert isinstance(lazy_1, module_0.Lazy)
    lazy_1 = lazy_1.call()
    assert lazy_1 is object_0


# Generated at 2022-06-25 23:34:15.602529
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    assert isinstance(left_0.to_lazy(), module_0.lazy.Lazy)
    assert isinstance(left_0.to_lazy().get_value(), module_0.function)
    assert callable(left_0.to_lazy().get_value())
    assert module_0.isinstance(left_0.to_lazy().get_value()(), module_0.object)
    assert left_0.to_lazy().get_value()() == object_0
    left_0 = Right(object_0)
    assert isinstance(left_0.to_lazy(), module_0.lazy.Lazy)

# Generated at 2022-06-25 23:34:21.728485
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    either_0 = Right(object_0)
    either_0.to_lazy()


# Generated at 2022-06-25 23:34:29.138166
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert (isinstance(Left(10).to_lazy(), type(Lazy(lambda: 10)))) == True
    assert (isinstance(Left(10).to_lazy(), type(Lazy(lambda: "abcd")))) == False
    assert (isinstance(Right(10).to_lazy(), type(Lazy(lambda: 10)))) == True
    assert (isinstance(Right(10).to_lazy(), type(Lazy(lambda: "abcd")))) == False


# Generated at 2022-06-25 23:34:41.584854
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    object_1 = module_0.object()
    object_2 = module_0.object()
    object_3 = module_0.object()
    object_4 = module_0.object()
    object_5 = module_0.object()
    object_6 = module_0.object()
    object_7 = module_0.object()
    object_8 = module_0.object()
    object_9 = module_0.object()
    object_10 = module_0.object()
    object_11 = module_0.object()
    object_12 = module_0.object()
    object_13 = module_0.object()
    object_14 = module_0.object()
    object_15 = module_0.object()
    object_16 = module_

# Generated at 2022-06-25 23:34:44.181455
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    right_0 = Right(object_0)
    lazy_0 = right_0.to_lazy()
    assert(lazy_0.evaluate() == object_0)


# Generated at 2022-06-25 23:34:47.926238
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    func_0 = Either.to_lazy
    right_0 = Right(func_0)


# Generated at 2022-06-25 23:35:51.654951
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:35:56.744773
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    object_0 = module_0.object()
    function_0 = module_0.function()
    right_0 = Right(object_0)
    result_0 = right_0.to_lazy()
    assert isinstance(result_0, Lazy)

    module_0.classmethod()(result_0)
    result_1 = result_0.get()
    assert result_1 == object_0


# Generated at 2022-06-25 23:36:01.072445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    u_0 = Either(None)
    assert isinstance(u_0.to_lazy(), Lazy)

from pymonet.lazy import Lazy
from pymonet.monad_try import Try
from pymonet.box import Box
from pymonet.validation import Validation
from pymonet.maybe import Maybe

from pymonet.monad import Monad
from pymonet.monad_transformer import MonadTransformer

# Generated at 2022-06-25 23:36:05.371284
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # left_0 should be Left(object)
    object_0 = module_0.object()
    left_0 = Left(object_0)
    # lazy_0 should be Lazy(function)
    lazy_0 = left_0.to_lazy()
    # lazy_1 should be Lazy(function)
    lazy_1 = Right(object_0).to_lazy()

import builtins as module_0

from pymonet.disjunction import Either


# Generated at 2022-06-25 23:36:06.866983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result_0 = Left(0).to_lazy().value()
    assert result_0 == 0


# Generated at 2022-06-25 23:36:08.877042
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left = Left(2)

    assert left.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-25 23:36:12.155748
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    try:
        value = 2
        monad = Either.to_lazy(value)

        assert (type(monad) == Lazy)
        assert (2 == monad.get_value())
    except BaseException as e:
        assert (False), str(e)

# Generated at 2022-06-25 23:36:15.534620
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = Either.__init__(object)
    left_0 = Left(object_0)
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: object_0)
    call_0 = left_0.to_lazy()
    return call_0


# Generated at 2022-06-25 23:36:24.258138
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    object_1 = module_0.object()
    object_2 = module_0.object()
    object_3 = module_0.object()
    object_4 = module_0.object()
    object_5 = module_0.object()
    object_6 = module_0.object()
    object_7 = module_0.object()
    object_8 = module_0.object()
    object_9 = module_0.object()
    object_10 = module_0.object()
    object_11 = module_0.object()
    object_12 = module_0.object()
    object_13 = module_0.object()
    object_14 = module_0.object()
    object_15 = module_

# Generated at 2022-06-25 23:36:26.666708
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    object_0 = module_0.object()
    left_0 = Left(object_0)
    object_1 = left_0.to_lazy().value()
    assert object_0 is object_1
