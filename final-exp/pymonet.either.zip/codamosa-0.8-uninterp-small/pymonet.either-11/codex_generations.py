

# Generated at 2022-06-25 23:27:35.575049
# Unit test for method case of class Either
def test_Either_case():

    def error_case(dict_arg: dict):
        return dict_arg['key_0']

    def success_case(dict_arg: dict):
        dict_arg.update(
            {
                'key_0': 'value_0'
            }
        )
        return dict_arg

    dict_0 = {
        'key_0': 'value_0',
        'key_1': 'value_1'
    }

    left_0 = Left(dict_0)

    either_0 = Either(left_0)

    assert either_0.case(
        error=error_case,
        success=success_case
    ) == dict_0['key_0']

    return


# Generated at 2022-06-25 23:27:39.602149
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    # Test 1
    result = Either(1) == Either(1)
    assert result is True

    # Test 2
    result = Either(1) == Either(2)
    assert result is False

    # Test 3
    result = Either(1) == None
    assert result is False


# Generated at 2022-06-25 23:27:46.475166
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_0['a'] = 'b'
    dict_1['a'] = 'c'
    dict_2 = {}
    dict_2['a'] = 'b'
    right_0 = Right(dict_1)
    right_1 = Right(dict_1)
    assert (right_0 == right_0)
    left_0 = Left(dict_0)
    left_1 = Left(dict_2)
    assert (left_0 == left_0)
    assert (left_0 == left_1)

# Generated at 2022-06-25 23:27:53.713206
# Unit test for method case of class Either
def test_Either_case():
    test_value_0 = Either(Right(None))
    test_value_1 = Either(Left(None))
    test_value_1.case(error=lambda x: None, success=lambda x: None)
    test_value_2 = Either(Right(None))
    test_value_2.case(error=lambda x: None, success=lambda x: None)
    test_value_3 = Either(Left(None))
    test_value_3.case(error=lambda x: None, success=lambda x: None)


# Generated at 2022-06-25 23:28:01.529562
# Unit test for method case of class Either
def test_Either_case():
    dict_0 = None
    left_0 = Left(dict_0)
    either_0 = Either(left_0)
    error_handler = (lambda x_0: str)
    success_handler = (lambda x_0: str)
    value_1 = either_0.case(error_handler, success_handler)
    assert value_1 is not None
    assert value_1 == str

    dict_0 = None
    right_0 = Right(dict_0)
    either_1 = Either(right_0)
    error_handler = (lambda x_0: str)
    success_handler = (lambda x_0: str)
    value_1 = either_1.case(error_handler, success_handler)
    assert value_1 is not None
    assert value_1 == str



# Generated at 2022-06-25 23:28:05.057486
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Init class instance
    dict_0 = None
    left_0 = Left(dict_0)
    either_0 = Either(left_0)

    # Test pure functionality
    assert either_0 == either_0



# Generated at 2022-06-25 23:28:09.775003
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    dict_0 = None
    left_0 = Left(dict_0)
    either_0 = Either(left_0)

    assert either_0 == left_0


# Generated at 2022-06-25 23:28:15.783904
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # A: 256, B: 7, Z: 256
    dict_0 = None
    left_0 = Left(dict_0)
    either_0 = Either(left_0)

    # A: 7, B: 35, Z: 7
    int_0 = 7
    right_0 = Right(int_0)
    either_1 = Either(right_0)

    assert either_0._eq_(either_1) is False


# Generated at 2022-06-25 23:28:24.059697
# Unit test for method case of class Either
def test_Either_case():
    dict_0 = None
    dict_1 = {'foo': 'bar'}
    list_0 = [0, 1, 2, 3, 4]
    str_0 = 'eyJmb28iOiJiYXIiLCJiYXIiOiJmb28ifQ=='
    str_1 = 'test'
    left_0 = Left(str_0)
    right_0 = Right(dict_0)
    list_1 = [dict_1, dict_1, dict_1]
    assert right_0.case(lambda a: str(a), lambda b: list_1) == list_1

# Generated at 2022-06-25 23:28:28.814980
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left(7)
    left_1 = Left(2)
    right_0 = Right(9)
    right_1 = Right(8)
    assert left_0 == left_1
    assert right_0 == right_1


# Generated at 2022-06-25 23:28:32.876491
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-25 23:28:41.822357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    # Case: Right(box)
    lazy_0 = Right(Box(True)).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value()
    # Case: Left(box)
    lazy_1 = Left(Box(False)).to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() is False
    # Case: Right(try)
    lazy_2 = Right(Try(True, True)).to_lazy()
    assert isinstance(lazy_2, Lazy)


# Generated at 2022-06-25 23:28:45.171050
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    expected_result = 'foo'
    error_0 = expected_result
    left_0 = Left(error_0)
    assert left_0.to_lazy().value() == expected_result


# Generated at 2022-06-25 23:28:49.080086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    lazy_0 = left_0.to_lazy()

    right_0 = Right(None)
    lazy_1 = right_0.to_lazy()

    assert lazy_0, lazy_1


# Generated at 2022-06-25 23:29:00.021357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_1 = 1
    var_2 = 2
    right_1 = Right(var_1)
    lazy_1 = right_1.to_lazy()
    assert type(lazy_1) == Lazy
    assert lazy_1.value() == right_1.value
    right_2 = Right(var_2)
    assert right_2.to_lazy() != right_1.to_lazy()
    assert lazy_1.value() == right_1.value
    left_1 = Left(var_1)
    lazy_2 = left_1.to_lazy()
    assert type(lazy_2) == Lazy
    assert lazy_2.value() == left_1.value
    left_2 = Left(var_2)

# Generated at 2022-06-25 23:29:00.927017
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:29:03.650333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    result = left_0.to_lazy()
    assert result != None
    assert result.value != None
    assert result.value() == None


# Generated at 2022-06-25 23:29:10.385480
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = True
    var_2 = True
    right_0 = Right(var_2)
    var_3 = None
    var_4 = True
    var_5 = True
    right_1 = Right(var_5)
    var_6 = None
    var_7 = True
    var_8 = True
    right_2 = Right(var_8)
    var_9 = None
    var_10 = True
    var_11 = True
    right_3 = Right(var_11)
    var_12 = None
    var_13 = True
    var_14 = True
    right_4 = Right(var_14)
    var_15 = None
    var_16 = True
    var_17 = True
    right_5 = Right(var_17)
   

# Generated at 2022-06-25 23:29:13.042057
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left([1, 2, 3])
    lazy = left.to_lazy()
    assert lazy.value() == [1, 2, 3]


# Generated at 2022-06-25 23:29:18.915245
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.monad_try
    pymonet.monad_try.test_Try_to_lazy()
    import pymonet.box
    pymonet.box.test_Box_to_lazy()
    import pymonet.maybe
    pymonet.maybe.test_Maybe_to_lazy()
    import pymonet.validation
    pymonet.validation.test_Validation_to_lazy()


# Generated at 2022-06-25 23:29:32.815828
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = ['H']
    var_1 = []
    var_2 = ['e']
    var_3 = ['y']
    var_4 = [',']
    var_5 = ['', '', '', 'How', '', '', 'How', '', '', 'How', '', '', 'How']
    var_6 = ['H']
    var_7 = ['e']
    var_8 = ['y']
    var_9 = [',', 'How']
    var_10 = ['How']
    var_11 = ['How', 'Hey', 'How']
    var_12 = ['He', 'He']
    var_13 = ['How', 'Hey', 'How', 'Hey']
    var_14 = ['How', 'Hey', 'How']

# Generated at 2022-06-25 23:29:39.849649
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Unit test for method to_lazy of class Left
    left_0 = None
    var_0 = Left(left_0)
    var_1 = var_0.to_lazy()
    var_2 = var_1.eval()
    assert var_2 == left_0
    # Unit test for method to_lazy of class Right
    right_0 = None
    var_0 = Right(right_0)
    var_1 = var_0.to_lazy()
    var_2 = var_1.eval()
    assert var_2 == right_0


# Generated at 2022-06-25 23:29:43.933886
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(10)
    var_1 = var_0.to_lazy()
    assert(var_1.value() == 10)
    var_2 = Left(10)
    var_3 = var_2.to_lazy()
    assert(var_3.value() == 10)


# Generated at 2022-06-25 23:29:46.532659
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(1)
    var_1 = var_0.to_lazy()
    var_2 = var_1.is_lazy()
    assert var_2 == True


# Generated at 2022-06-25 23:29:51.346629
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    expected_0 = Lazy.unit(var_0)
    actual_0 = left_0.to_lazy()
    assert actual_0 == expected_0

    var_1 = None
    right_1 = Right(var_1)
    expected_1 = Lazy.unit(var_1)
    actual_1 = right_1.to_lazy()
    assert actual_1 == expected_1



# Generated at 2022-06-25 23:30:01.390213
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try, Failure, Success
    from pymonet.box import Box
    from pymonet.validation import Validation

    right_0 = Right(3)
    equals_0 = right_0.to_lazy()
    assert equals_0 == Lazy(lambda: 3)
    right_1 = Right(10)
    equals_1 = right_1.to_lazy()
    assert equals_1 == Lazy(lambda: 10)
    left_0 = Right(10)
    equals_2 = left_0.to_lazy()
    assert equals_2 == Lazy(lambda: 10)
    left_1 = Left(False)
    equals_3 = left_1.to_lazy()
    assert equals_3 == Lazy(lambda: False)
    left_2

# Generated at 2022-06-25 23:30:04.841419
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().eval() == 2
    assert Right(1).to_lazy().map(lambda x: x - 1).eval() == 0
    assert Left(2).to_lazy().map(lambda x: x - 1).eval() == 2


# Generated at 2022-06-25 23:30:08.487965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = lazy_0.value()
    var_2 = None
    assert var_1 == var_2


# Generated at 2022-06-25 23:30:13.464317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 5
    left_0 = Left(var_0)
    assert left_0.to_lazy().value() == var_0
    assert left_0.to_lazy() == Lazy(lambda: var_0)

    var_0 = 10
    right_0 = Right(var_0)
    assert right_0.to_lazy().value() == var_0
    assert right_0.to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:30:15.538523
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)

    assert left_0.to_lazy().value() == var_0


# Generated at 2022-06-25 23:30:20.385168
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right("")
    ret_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:30:23.868275
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    method_name = 'Either.to_lazy'
    try:
        right = Right(None)
        right.to_lazy()
    except Exception as e:
        print('Failed to call method %s' % method_name)
        raise e



# Generated at 2022-06-25 23:30:24.733662
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    pass



# Generated at 2022-06-25 23:30:28.540738
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.validation import Validation

    lazy_0 = Left(1).to_lazy()
    lazy_1 = lazy_0.value()

    # return Validation.success(result)



# Generated at 2022-06-25 23:30:32.578188
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = "abcd"
    var_1 = "abcd"
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    try:
        assert lazy_0.value() == var_1
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 23:30:40.732621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left('dummy')
    right_0 = right_0.to_lazy()
    right_0 = right_0.to_lazy()
    right_1 = left_0.to_lazy()
    right_1 = right_0.to_lazy()
    left_1 = left_0.to_lazy()
    right_2 = left_1.to_lazy()
    right_2 = left_0.to_lazy()
    left_2 = right_0.to_lazy()
    left_2 = left_0.to_lazy()
    return left_2.to_lazy().to_lazy().to_lazy().to_lazy()


# Generated at 2022-06-25 23:30:47.924462
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    either_0 = Right(var_0)
    either_1 = Left(var_0)
    var_1 = either_0.to_lazy()
    var_2 = either_1.to_lazy()
    assert isinstance(var_1, Lazy)
    assert isinstance(var_2, Lazy)
    assert var_1.to_val() == var_0
    assert var_2.to_val() == var_0


# Generated at 2022-06-25 23:30:49.915350
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(None).ap(Maybe.nothing()).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:30:58.405967
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Test 0
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0 == Lazy(lambda: left_0.value)

    # Test 1
    var_1 = Box(1)
    right_1 = Right(var_1)
    lazy_1 = right_1.to_lazy()
    assert lazy_1 == Lazy(lambda: right_1.value)

    # Test 2
    var_2 = Try(1, True)
    right_2 = Right(var_2)
    lazy_2 = right_2.to_lazy()
    assert lazy

# Generated at 2022-06-25 23:31:02.110864
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)

    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:14.612818
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    right_0 = Right(var_2)
    var_7 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:18.748639
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:31:29.702231
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    
    # create a Left with an integer and transform it to a Lazy
    var_1 = 1
    left_1 = Left(var_1)
    var_1_lazy = left_1.to_lazy()
    assert isinstance(var_1_lazy, Lazy)
    assert var_1_lazy.get() == var_1
    
    # create a Right with an integer and transform it to a Lazy
    right_1 = Right(var_1)
    var_1_lazy = right_1.to_lazy()
    assert isinstance(var_1_lazy, Lazy)
    assert var_1_lazy.get() == var_1
    
    # create a Left with a string and transform it to a Lazy
    var

# Generated at 2022-06-25 23:31:36.261772
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.eval() == var_0
    var_1 = None
    left_0 = Left(var_1)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.eval() == var_1
    tuple_4 = (0, 1)
    right_1 = Right(tuple_4)
    lazy_1 = right_1.to_lazy()
    assert lazy_1.eval() == tuple_4
    tuple_5 = (0, 1)
    left_1 = Left(tuple_5)
    lazy_1 = left_1.to_lazy()
    assert lazy_1.eval() == tuple_5
   

# Generated at 2022-06-25 23:31:41.381015
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = "lazy"
    case_0 = Right(var_0).to_lazy()
    var_1 = "lazy"
    expected_0 = var_1
    result_0 = case_0.eval()
    assert result_0 == expected_0


# Generated at 2022-06-25 23:31:45.272696
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test to_lazy."""
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()


# Generated at 2022-06-25 23:31:46.363583
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:31:51.840616
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet import Lazy as LazyClass
    var_0 = None
    either_0 = Left(var_0)
    lazy_0 = Lazy(lambda: either_0.value)
    lazy_1 = either_0.to_lazy()
    assert lazy_1 == lazy_0


# Generated at 2022-06-25 23:31:55.150438
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(10)
    assert right.to_lazy().force() == 10

    left = Left('123')
    assert left.to_lazy().force() == '123'



# Generated at 2022-06-25 23:31:57.041147
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_9 = right_0.to_lazy()



# Generated at 2022-06-25 23:32:13.037983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Right(0)    # type: Either[int]
    instance_0 = var_0.to_lazy()    # type: Lazy[int]
    assert instance_0.value() is 0


# Generated at 2022-06-25 23:32:15.208850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result_0 = None
    left_0 = Left(result_0)
    result_1 = left_0.to_lazy()


# Generated at 2022-06-25 23:32:24.180959
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad_try import Try
    from pymonet.box import Box

    box_1 = Box(Lazy(lambda: 5))
    try_1 = Try(Lazy(lambda: 5))
    lazy_1 = Lazy(lambda: 5)
    ones = (1, 1, 1)
    some_collection = iter(ones)

    functor = Functor(box_1)

    # Test with try
    try_1.to_lazy().value()

    # Test with box
    box_1.to_lazy().value()

    # Test with lazy
    lazy_1.to_lazy()

    # Test with functor
    functor.to_lazy().value()

    #

# Generated at 2022-06-25 23:32:32.442651
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right
    from pymonet.maybe import Maybe, Just, Nothing

    value_0 = 35
    left_0 = Left(value_0)
    result_0 = left_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0() == value_0

    value_1 = None
    right_0 = Right(value_1)
    result_1 = right_0.to_lazy()
    assert isinstance(result_1, Lazy)
    assert result_1() == value_1

    value_2 = []
    left_1 = Left(value_2)
    result_2 = left_1.to_lazy()

# Generated at 2022-06-25 23:32:41.203218
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = type('var_0', (), {'to_lazy': lambda self: Lazy(lambda: None)})()
    obj_0 = Either(var_0)
    var_1 = obj_0.to_lazy()
    var_1.force()
    var_0 = type('var_0', (), {'to_lazy': lambda self: Lazy(lambda: None)})()
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_1.force()
    var_0 = type('var_0', (), {'to_lazy': lambda self: Lazy(lambda: None)})()
    right_0 = Right(var_0)

# Generated at 2022-06-25 23:32:45.331555
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = None
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()



# Generated at 2022-06-25 23:32:50.191850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = Lazy(1)
    right_0 = Right(var_1)
    assert left_0.to_lazy() == Lazy(var_0), "Assertion error: option: 0"
    assert right_0.to_lazy() == Lazy(1), "Assertion error: option: 1"


# Generated at 2022-06-25 23:32:55.087686
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_1 = 0
    right_0 = Right(var_1)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == var_1
    var_2 = 0
    left_1 = Left(var_2)
    lazy_1 = left_1.to_lazy()
    assert lazy_1.value() == var_2


# Generated at 2022-06-25 23:32:57.406999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 4
    right_0 = Right(var_0)

    assert right_0.to_lazy().value() == var_0


# Generated at 2022-06-25 23:32:58.787986
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Left(var_0)
    var_1 = Right(var_1)
    var_2 = var_1.to_lazy()
    var_3 = var_0.to_lazy()


# Generated at 2022-06-25 23:33:33.893734
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Tests for to_lazy method of class Either.

    """
    from pymonet.lazy import Lazy

    var_0 = 5
    left = Left(var_0)
    left_to_lazy = left.to_lazy()
    assert isinstance(left_to_lazy, Lazy)
    left_to_lazy_val = left_to_lazy.value()
    assert isinstance(left_to_lazy_val, Left)
    assert left_to_lazy_val.value == var_0
    right = Right(var_0)
    right_to_lazy = right.to_lazy()
    assert isinstance(right_to_lazy, Lazy)
    right_to_lazy_val = right_to_lazy.value()

# Generated at 2022-06-25 23:33:35.473749
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    result_0 = Left(var_0).to_lazy()
    assert callable(result_0.value)
    assert result_0.value() == None


# Generated at 2022-06-25 23:33:36.506826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(1)
    var_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:39.152126
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = lazy_0.run()
    assert left_0.value is var_1


# Generated at 2022-06-25 23:33:43.144143
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    var_2 = None
    left_1 = left_0.to_lazy()
    assert (left_1.value() == var_0)
    var_3 = None
    right_1 = right_0.to_lazy()
    assert (right_1.value() == var_1)


# Generated at 2022-06-25 23:33:47.884093
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Call method to_lazy
    to_lazy = None
    right_0 = Right(to_lazy)
    first_lazy = right_0.to_lazy()
    if not isinstance(first_lazy, Lazy):
        raise AssertionError(
            'Expected Lazy but got {first_lazy}'.format(
                first_lazy=first_lazy
            )
        )


# Generated at 2022-06-25 23:33:50.723366
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print('test for method to_lazy of class Either')
    var_0 = None
    left_0 = Left(var_0)
    from pymonet.lazy import Lazy
    
    assert isinstance(left_0.to_lazy(), Lazy)
    print('test passed')


# Generated at 2022-06-25 23:33:52.768792
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = 7
    right_0 = Right(var_0)
    assert right_0.to_lazy().eval() is var_0



# Generated at 2022-06-25 23:33:56.777590
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy().evaluate() is None
    assert Right(None).to_lazy().evaluate() is None
    assert Left(True).to_lazy().evaluate() is True
    assert Right("a").to_lazy().evaluate() == "a"
    assert Left(FunctionType).to_lazy().evaluate() == FunctionType
    assert Right(lambda: None).to_lazy().evaluate()() is None



# Generated at 2022-06-25 23:34:01.599402
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = Lazy(lambda: 1)
    left_0 = Left(var_0)
    right_0 = Right(var_0)
    # Testing of value preservation
    assert left_0.to_lazy() == right_0.to_lazy()



# Generated at 2022-06-25 23:35:06.393018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)

    assert Left(10).to_lazy().value() == 10
    assert Right(10).to_lazy().value() == 10

    assert Left(Box(10)).to_lazy().box().value() == 10
    assert Right(Box(10)).to_lazy().box().value() == 10

    assert Left(Try(10)).to_lazy().to_try() == Try(10, is_success=False)

# Generated at 2022-06-25 23:35:12.806603
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Create instance of Lazy
    var_0 = Lazy(lambda: print(5))
    # Call method to_lazy of class Either
    var_1 = var_0.to_lazy()
    # Assert objects are equal
    assert var_0 == var_1
    # Create instance of Lazy
    var_2 = Lazy(lambda: print(4))
    # Call method to_lazy of class Either
    var_3 = var_2.to_lazy()
    # Assert objects are equal
    assert var_2 == var_3
    # Create instance of Either
    var_4 = Either(4)
    # Call method to_lazy of class Either
    var_5 = var_4.to_lazy()
    # Assert objects are not equal
    assert var_4 != var_5


# Generated at 2022-06-25 23:35:18.733599
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = ""
    var_1 = False
    left_0 = Left(var_0)
    right_0 = Right(var_1)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value == var_0
    lazy_1 = right_0.to_lazy()
    assert lazy_1.value == var_1
    assert left_0.case(lambda value: value, lambda value: value) == var_0
    assert right_0.case(lambda value: value, lambda value: value) == var_1


# Generated at 2022-06-25 23:35:20.448464
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_2 = left_0.to_lazy()


# Generated at 2022-06-25 23:35:26.931033
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Unit test for method to_lazy of class Left
    def test_Left_to_lazy():
        var_0 = None
        left_0 = Left(var_0)
        lazy = left_0.to_lazy()
        res_0 = lazy()
        assert res_0 == var_0

    # Unit test for method to_lazy of class Right
    def test_Right_to_lazy():
        var_0 = None
        right_0 = Right(var_0)
        lazy = right_0.to_lazy()
        res_0 = lazy()
        assert res_0 == var_0

    test_Left_to_lazy()
    test_Right_to_lazy()


# Generated at 2022-06-25 23:35:31.347918
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)

    var_1 = None
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert isinstance(lazy_1, Lazy)


# Generated at 2022-06-25 23:35:36.725811
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Failure case with one parameter
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    validation_0 = left_0.to_lazy()
    assert var_1 == validation_0.to_list()
    # Failure case with two parameters
    var_2 = None
    right_0 = Right(var_2)
    var_3 = None
    validation_1 = right_0.to_lazy()
    assert var_3 == validation_1.to_list()


# Generated at 2022-06-25 23:35:39.157452
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    val = 10
    var_0 = val
    right_0 = Right(var_0)
    assert right_0.to_lazy().value() == right_0.value


# Generated at 2022-06-25 23:35:44.816061
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Check base case
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    assert var_1.value() == var_0,\
        "The either value wasn't equal to the expected result"
    # Check second case
    right_1 = Right(var_0)
    var_2 = right_1.to_lazy()
    assert var_2.value() == var_0,\
        "The either value wasn't equal to the expected result"


# Generated at 2022-06-25 23:35:50.902687
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Create a instance of class 'Either'
    var_0 = None
    var_1 = Lazy(id, var_0)
    var_2 = 'value'
    var_3 = Lazy(lambda: var_2, var_0)
    var_4 = Left(var_2)
    var_5 = var_4.to_lazy()
    assert var_5 == var_1
    var_6 = Right(var_2)
    var_7 = var_6.to_lazy()
    assert var_7 == var_3
