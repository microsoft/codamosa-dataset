

# Generated at 2022-06-25 23:27:39.075773
# Unit test for method case of class Either
def test_Either_case():
    float_0 = 1594.3
    either_0 = Either(float_0)
    string_0 = 'qEqhF'
    list_0 = [1, 2, 3, 4, 5]
    # Either.case - test case 0
    either_0.case(error=lambda arg_0: arg_0, success=lambda arg_0: arg_0)
    # Either.case - test case 1
    either_0.case(error=lambda arg_0: arg_0, success=lambda arg_0: arg_0)


# Generated at 2022-06-25 23:27:48.697427
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    from decimal import Decimal
    # int 0
    int_0 = 0
    # int 1
    int_1 = 1
    # bool True
    bool_True = True
    # bool False
    bool_False = False

    # Either[int] 0
    either_int_0 = Either(int_0)
    # Either[int] 1
    either_int_1 = Either(int_1)
    # Either[bool] True
    either_bool_True = Either(bool_True)
    # Either[bool] False
    either_bool_False = Either(bool_False)

    # Assertion error
    # either_int_0 == either_int_1
    # Assertion error
    # either_int_0 == either_bool_True
    # Assertion error
    # either_int_0

# Generated at 2022-06-25 23:27:52.705664
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    float_1 = float_0
    either_0 = Either(float_0)
    either_1 = Either(float_1)
    assert either_0 == either_1


# Generated at 2022-06-25 23:27:54.910087
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_value = 5
    expected = Either(int_value).to_lazy().eval()
    actual = int_value
    assert actual == expected



# Generated at 2022-06-25 23:28:01.527247
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    float_1 = 1594.3
    float_2 = 1594.3
    float_3 = 1594.3
    float_4 = 1594.3
    float_5 = 1594.3
    float_6 = 1594.3
    float_7 = 1594.3
    float_8 = 1594.3
    float_9 = 1594.3

    either_0 = Either(float_0)
    either_1 = Either(float_1)
    either_2 = Either(float_2)
    either_3 = Either(float_3)
    either_4 = Left(float_4)
    either_5 = Right(float_5)
    either_6 = Either(float_6)
    either_7 = Either(float_7)
    either_

# Generated at 2022-06-25 23:28:07.631266
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    either_0 = Either(float_0)
    either_1 = Either(float_0)
    either_2 = Either(float_0)
    assert either_0 == either_1
    assert not either_0 == either_2
    assert not either_1 == either_2
    assert either_0 == either_0
    assert not either_1 == either_0
    assert either_2 == either_2


# Generated at 2022-06-25 23:28:12.738206
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 2.4824251099757985
    either_0 = Either(float_0)
    bool_0 = either_0.__eq__(either_0)
    bool_1 = either_0.__eq__(either_0)
    bool_2 = either_0.__eq__(either_0)
    assert bool_2 == bool_1 == bool_0


# Generated at 2022-06-25 23:28:17.428863
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    try:
        assert lazy_0.get() == float_0
    except AssertionError:
        raise AssertionError('method Either to_lazy failed')


# Generated at 2022-06-25 23:28:25.289449
# Unit test for method case of class Either
def test_Either_case():
    description = "Either.case() should call success function when Either is Right."
    either_0 = Right(37)
    success_function_0 = lambda x: x + 12
    error_function_0 = lambda x: x * 2
    expected_0 = 49
    actual_0 = either_0.case(error_function_0, success_function_0)
    assert expected_0 == actual_0, description

    description = "Either.case() should call error function when Either is Left."
    either_1 = Left(37)
    expected_1 = 74
    actual_1 = either_1.case(error_function_0, success_function_0)
    assert expected_1 == actual_1, description


# Generated at 2022-06-25 23:28:29.670902
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    string_0 = 'R'
    either_0 = Either(string_0)
    assert either_0 == either_0
    string_1 = 'a'
    either_1 = Either(string_1)
    assert not either_0 == either_1


# Generated at 2022-06-25 23:28:34.001047
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert float_0 == lazy_0.value()


# Generated at 2022-06-25 23:28:36.970291
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = "value"
    either = Either(value)
    either_lazy = either.to_lazy()
    assert isinstance(either_lazy, Lazy)
    assert either_lazy() == value

# Generated at 2022-06-25 23:28:42.953679
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    either_0 = Either(float_0)
    float_1 = 1354.8
    either_1 = Either(float_1)
    float_2 = 1354.8
    either_2 = Either(float_0)
    float_3 = 1354.8
    either_3 = Either(float_3)
    assert either_0.__eq__(either_1) == False
    assert either_0.__eq__(either_2) == False
    assert either_2.__eq__(either_3) == True



# Generated at 2022-06-25 23:28:52.514281
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    input_value = Box(2.0)
    expected_output_value = Box(4.0)

    either_0 = Either(input_value)
    lazy_0 = either_0.to_lazy()
    monad_0 = lazy_0.force()
    value_0 = monad_0.value

    is_passed = value_0 == expected_output_value

    return is_passed
    


# Generated at 2022-06-25 23:28:58.320380
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    float_1 = float_0
    assert isinstance(float_0, float)
    either_0 = Either(float_0)
    either_1 = Either(float_1)
    assert either_0 == either_1
    double_0 = -16.0
    either_2 = Either(double_0)
    assert either_0 != either_2


# Generated at 2022-06-25 23:29:01.926961
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    float_0 = 1594.3
    either_0 = Either(float_0)
    either_1 = Either(float_0)
    bool_0 = either_0.__eq__(either_1)
    assert bool_0 == True



# Generated at 2022-06-25 23:29:05.010049
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = Lazy(lambda: float_0)
    assert either_0.to_lazy() == lazy_0



# Generated at 2022-06-25 23:29:07.816609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    lu.eval_to_true(lambda: lazy_0.value() == float_0)



# Generated at 2022-06-25 23:29:11.097463
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either(5.5).to_lazy() == Lazy(lambda: 5.5)
    assert Either('hello').to_lazy() == Lazy(lambda: 'hello')
    assert Either(Left(5)).to_lazy() == Lazy(lambda: Left(5))
    assert Either(Right(5)).to_lazy() == Lazy(lambda: Right(5))


# Generated at 2022-06-25 23:29:15.678781
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """Unit test for method __eq__ of class Either"""
    left_0 = Either.Left(1594.3)
    assert left_0 == Either.Left(1594.3)
    assert left_0 != Either.Right(1594.3)
    right_0 = Either.Right(1594.3)
    assert right_0 == Either.Right(1594.3)
    assert right_0 != Either.Left(1594.3)


# Generated at 2022-06-25 23:29:24.500517
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    right_2 = Either(2)
    lazy_right_2 = right_2.to_lazy()
    lazy_right_2_value = lazy_right_2.case(
        lambda: 'empty',
        lambda value: value
    )
    assert lazy_right_2_value == 2, 'Error in creating lazy right'
    left_2 = Either(-2)
    lazy_left_2 = left_2.to_lazy()
    lazy_left_2_value = lazy_left_2.case(
        lambda: 'empty',
        lambda value: value
    )
    assert lazy_left_2_value == -2, 'Error in creating lazy left'
    assert isinstance(right_2.to_lazy(), Lazy), 'Error in creating lazy'


# Generated at 2022-06-25 23:29:35.353045
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try

    float_0 = 1594.3
    float_1 = 2254.8
    float_2 = 125.4
    float_3 = 951.6
    float_4 = 1390.2
    float_5 = 1518.6

    either_0 = Either(float_0)
    either_1 = Either(float_1)
    either_2 = Either(float_2)
    either_3 = Either(float_3)
    either_4 = Either(float_4)
    either_5 = Either(float_5)

    float_6 = float_0 + float_1
    float_7 = float_

# Generated at 2022-06-25 23:29:37.503875
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_0():
        float_0 = 48.1
        either_0 = Either(float_0)
        assert either_0.to_lazy().value() == float_0

# Generated at 2022-06-25 23:29:39.510458
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(11516.9).to_lazy() == Lazy(11516.9)


# Generated at 2022-06-25 23:29:43.644250
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    float_1 = float_0 / float_0
    either_0 = Right(float_1)
    lazy_0 = either_0.to_lazy()
    float_2 = lazy_0.get()
    assert_true(equals(float_1, float_2))


# Generated at 2022-06-25 23:29:47.914654
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    right_either_0 = Either(4.6)

    # Invocation
    result = right_either_0.to_lazy()

    # Verification
    from pymonet.lazy import Lazy
    assert isinstance(result, Lazy)
    assert result.evaluate() == 4.6

    # Cleanup - none necessary


# Generated at 2022-06-25 23:29:52.889384
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Right, Left

    integer_0 = 100
    either_0 = Either(integer_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)

    integer_1 = -5000
    either_1 = Right(integer_1)
    lazy_1 = either_1.to_lazy()
    assert isinstance(lazy_1, Lazy)

    string_0 = "test"
    either_2 = Left(string_0)
    lazy_2 = either_2.to_lazy()
    assert isinstance(lazy_2, Lazy)



# Generated at 2022-06-25 23:29:56.601791
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)

    lazy_0 = either_0.to_lazy()

    if float_0 != lazy_0.get():
        raise Exception("Error: test_Either_to_lazy")
# end



# Generated at 2022-06-25 23:30:06.489681
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box

    # This test will be raise TypeError because to_lazy() have not implemented yet
    # And this is not good way of testing
    float_0 = 1594.3
    float_1 = 3345.566
    box_0 = Box(float_0)
    either_0 = Either.to_lazy(box_0)
    float_2 = float_0 * float_0 * float_0 * float_0
    float_3 = either_0.value()
    assert float_3 == float_2

    box_1 = Box(float_1)
    either_1 = Either.to_lazy(box_1)
    float_4 = float_1 * float_1 * float_1 * float_1
    float_5 = either_1.value()
    assert float

# Generated at 2022-06-25 23:30:11.149853
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    try:
        value = "123"
        either_0 = Either(value)
        lazy_0 = either_0.to_lazy()
        assert isinstance(lazy_0, Lazy)
    except AssertionError:
        print("test_Either_to_lazy failed")
        return 1
    return 0


# Generated at 2022-06-25 23:30:16.406801
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = -0.0004339400629724025
    either_0 = Either(float_0)

    assert either_0.to_lazy().value() == -0.0004339400629724025


# Generated at 2022-06-25 23:30:26.589674
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import  Box
    float_0 = 1594.3
    float_1 = float_0
    either_0 = Either(float_1)
    lazy_0 = Lazy(lambda: float_1)
    box_0 = Box(float_1)
    lazy_1 = either_0.to_lazy()
    assert lazy_0 == lazy_1
    assert not (lazy_0 != lazy_1)
    assert lazy_0 is not lazy_1
    lazy_2 = box_0.to_lazy()
    assert lazy_2 == lazy_0
    assert not (lazy_2 != lazy_0)
    assert lazy_2 is not lazy_0
    lazy_3 = lazy_2
    assert lazy_2 is lazy_3

# Generated at 2022-06-25 23:30:35.447276
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(0)
    assert 0 == either_0.to_lazy().value()
    either_1 = Either(1)
    assert 1 == either_1.to_lazy().value()
    either_2 = Either(2)
    assert 2 == either_2.to_lazy().value()
    either_3 = Either(3)
    assert 3 == either_3.to_lazy().value()
    either_4 = Either(4)
    assert 4 == either_4.to_lazy().value()
    either_5 = Either(5)
    assert 5 == either_5.to_lazy().value()
    either_6 = Either(6)
    assert 6 == either_6.to_lazy().value()
    either_7 = Either(7)
    assert 7 == either_7

# Generated at 2022-06-25 23:30:38.184445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    try:
        either_0.to_lazy()
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-25 23:30:42.282103
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    x = 5
    either_right = Right(x)
    assert either_right.to_lazy().force() == x

    either_left = Left(x)
    assert either_left.to_lazy().force() == x


# Generated at 2022-06-25 23:30:45.595260
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_ = Either(float_0)
    lazy = either_.to_lazy()
    assert lazy.value() == float_0


# Generated at 2022-06-25 23:30:55.003893
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_either import Either, Left, Right

    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    int_0 = 658
    lazy_0 = Lazy(lambda: int_0)
    either_0 = Either(lazy_0)

    lazy_1 = either_0.to_lazy()
    assert lazy_1.is_equal(lazy_0) is True
    int_1 = lazy_1.get()
    assert int_1 == int_0

    box_0 = either_0.to_box()
    assert box_0.is_equal(Box(lazy_0)) is True



# Generated at 2022-06-25 23:31:01.523931
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def func():
        str_new = 'abc'
        return str_new
    either_0 = Either('abc')
    lazy_0 = either_0.to_lazy()
    # Assert that lazy_0 is instance of Lazy
    assert isinstance(lazy_0, Lazy)
    # Assert that lazy_0 wraps func
    assert lazy_0.value() == func()


# Generated at 2022-06-25 23:31:05.891889
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_lazy_0 = Either(1594.3).to_lazy()
    bool_lazy_0 = (float_lazy_0.value == 1594.3)
    bool_lazy_1 = (float_lazy_0.value == 1594.3)
    return bool_lazy_1 is not bool_lazy_0

# Test for method bind of class Either

# Generated at 2022-06-25 23:31:10.570115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1731.5
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    str_0 = lazy_0.map(lambda x: str(x))
    str_1 = str_0.get()
    assert '1731.5' == str_1



# Generated at 2022-06-25 23:31:14.168462
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass

# Generated at 2022-06-25 23:31:18.382428
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either.right(float_0)
    lazy = either_0.to_lazy()

    assert lazy == lazy
    assert lazy.value() == float_0


# Generated at 2022-06-25 23:31:22.635207
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    int_0 = 1592
    either_0 = Either(int_0)

    either_0.to_lazy()

    str_0 = 'zcWe1U6G'
    either_1 = Either(str_0)

    either_1.to_lazy()



# Generated at 2022-06-25 23:31:31.086454
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import unittest
    from pymonet.lazy import Lazy

    class EitherToLazyTest(unittest.TestCase):
        def test_left_to_lazy_0(self):
            self.assertEqual(Left(1594.3).to_lazy(), Lazy(lambda: 1594.3))

        def test_right_to_lazy_0(self):
            self.assertEqual(Right(1594.3).to_lazy(), Lazy(lambda: 1594.3))

    unittest.main()


# Generated at 2022-06-25 23:31:34.425094
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Either(0).to_lazy(), Lazy)
    assert Either(0).to_lazy().get() == 0


# Generated at 2022-06-25 23:31:37.647961
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_1 = 1594.3
    either_1 = Either(float_1)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.resolve() == float_1


# Generated at 2022-06-25 23:31:43.085905
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def print_lazy():
        print("lazy")

    lazy_0 = Lazy(print_lazy)
    either_0 = Either(lazy_0)
    lazy = either_0.to_lazy()
    assert(lazy == lazy_0)

# Generated at 2022-06-25 23:31:54.727680
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 977.587243
    either_0 = Either.Right(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.value()
    assert float_0 == float_1

    float_2 = 80.0
    either_1 = Either.Right(float_2)
    lazy_1 = either_1.to_lazy()
    float_3 = lazy_1.value()
    assert float_2 == float_3

    float_4 = 938.529
    either_2 = Either.Right(float_4)
    lazy_2 = either_2.to_lazy()
    float_5 = lazy_2.value()
    assert float_4 == float_5

    float_6 = 0.0

# Generated at 2022-06-25 23:31:59.337174
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.is_memoized is False
    float_0_1 = lazy_0.value
    assert float_0_1 == float_0


# Generated at 2022-06-25 23:32:04.514602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    str_0 = "lazy"

    # test for method ap of class Either
    def compare_0(either: Either[float]):
        lazy_0 = either.to_lazy()
        str_1 = lazy_0.call()
        assert str_1 == str_0

    compare_0(either_0)


# Generated at 2022-06-25 23:32:10.264885
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    float_1 = float_0 * float_0
    either_0 = Either(float_0)
    either_1 = either_0.to_lazy()
    float_2 = either_1.value()
    assert float_1 == float_2


# Generated at 2022-06-25 23:32:12.894701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 1294
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    int_2 = lazy_0.get()
    assert int_0 == int_2


# Generated at 2022-06-25 23:32:17.305693
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    float_0 = 1594.3
    to_lazy = Either.to_lazy
    # When
    either_0 = Either(float_0)
    lazy_0 = to_lazy(either_0)
    lazy_0_value = lazy_0.value
    # Then
    assert lazy_0_value() == float_0


# Generated at 2022-06-25 23:32:26.254354
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    from pymonet.either import Left, Right

    string_0 = 'test string'
    lazy_0 = Right(string_0).to_lazy()
    lazy_bool_0 = isinstance(lazy_0, Lazy)
    assert lazy_bool_0

    lazy_1 = lazy_0.evaluate()
    lazy_bool_1 = isinstance(lazy_1, str)
    assert lazy_bool_1

    string_1 = 'test string 0'
    lazy_2 = Left(string_1).to_lazy()
    lazy_bool_2 = isinstance(lazy_2, Lazy)
    assert lazy_bool_2

    lazy_3 = lazy_2.evaluate()

# Generated at 2022-06-25 23:32:29.065556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert_equals(lazy_0.eval(), 1594.3)



# Generated at 2022-06-25 23:32:31.961625
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor_interface import Functor

    assert Functor.laws_identity(Either.to_lazy, Lazy(lambda: None))



# Generated at 2022-06-25 23:32:33.391903
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(23.0).to_lazy().eval() == 23.0



# Generated at 2022-06-25 23:32:35.591630
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)

    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:32:41.016003
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 3.2
    float_1 = 16.7
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_2 = Lazy(lambda : float_1).value
    float_3 = lazy_0.value
    assert float_3 == float_0
    assert float_3 != float_1
    assert float_2 == float_1


# Generated at 2022-06-25 23:32:43.429813
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_0 = "string"
    either_0 = Either(string_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == string_0


# Generated at 2022-06-25 23:32:50.746985
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert callable(lazy_0.value)


# Generated at 2022-06-25 23:32:54.921102
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Case of success
    assert isinstance(Left(0).to_lazy(), Lazy)
    assert Left(0).to_lazy().force() == 0
    # Case of failure
    assert isinstance(Right(0).to_lazy(), Lazy)
    assert Right(0).to_lazy().force() == 0


# Generated at 2022-06-25 23:33:00.583269
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1593.3314
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = float_0 * float_0
    assert lazy_0.value() == float_1
    float_2 = float_1 + float_1
    float_3 = float_2 + float_2
    float_4 = float_1 + float_1
    assert lazy_0.value() == float_4

# Box for method case of class Either

# Generated at 2022-06-25 23:33:03.635764
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    either_0 = Either(int)
    either_0_to_lazy = either_0.to_lazy()
    assert str(either_0_to_lazy) == "Lazy(<lambda>)"
    assert int(either_0_to_lazy) == int



# Generated at 2022-06-25 23:33:08.017217
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    string_0 = "1"
    either_0 = Either(string_0)
    either_0_to_lazy = either_0.to_lazy()

    string_1 = "2"
    either_1 = Either(string_1)
    either_1_to_lazy = either_1.to_lazy()

    assert either_0_to_lazy != either_1_to_lazy



# Generated at 2022-06-25 23:33:11.931536
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(0)
    right_1 = right_0.to_lazy()
    assert right_1.get() == 0
    left_0 = Left(1)
    left_1 = left_0.to_lazy()
    assert left_1.get() == 1


# Generated at 2022-06-25 23:33:18.319025
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1433.099
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.evaluate() == float_0
    int_0 = 1433
    either_1 = Either(int_0)
    lazy_1 = either_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.evaluate() == int_0



# Generated at 2022-06-25 23:33:24.114394
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    # Right[A] case
    assert Right(3.14).to_lazy() == Lazy(lambda: 3.14)
    # Left[A] case
    assert Left(Maybe.nothing()).to_lazy() == Lazy(lambda: Maybe.nothing())
    assert Left(Try.from_error(Exception)).to_lazy() == Lazy(lambda: Try.from_error(Exception))



# Generated at 2022-06-25 23:33:26.386886
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    maybe_0 = Either((-11.5))
    maybe_1 = maybe_0.to_lazy()

# Generated at 2022-06-25 23:33:30.182418
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    float_0 = 1594.3
    either_0 = Either(float_0)
    float_1 = float_0
    expected_result = float_1

    # Exercise
    actual_result = either_0.to_lazy().value()

    # Verify
    assert actual_result == expected_result


# Generated at 2022-06-25 23:33:45.494287
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    either_0 = Either(12.0)
    
    # Invoke the tested method
    result_0 = either_0.to_lazy()
    
    # Verify the results
    assert result_0 is not None
    assert isinstance(result_0, Lazy)


# Generated at 2022-06-25 23:33:47.545572
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1.0
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value == 1.0


# Generated at 2022-06-25 23:33:49.575018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == float_0


# Generated at 2022-06-25 23:33:52.194022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)

    lazy_0 = either_0.to_lazy()
    result_0 = lazy_0.get()

    assert result_0 == float_0


# Generated at 2022-06-25 23:33:55.907978
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either.Right(float_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = either_0.to_lazy()
    result = lazy_0.box()
    result = lazy_1.box()
    assert result.is_success()
    assert result.value == float_0


# Generated at 2022-06-25 23:33:59.317195
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 46.72
    right_0 = Either(float_0)
    lazy_0 = right_0.to_lazy()
    # AssertionError: Expected 46.72, but got 4.4
    assert lazy_0.value() == float_0


# Generated at 2022-06-25 23:34:09.305600
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, lazy

    @lazy
    def l_add(x: int, y: int) -> int:
        return x + y

    def l_fib(x: int) -> int:
        return 0 if x <= 2 else l_fib(x - 1) + l_fib(x - 2)

    #
    # Either.to_lazy test
    #

    int_0 = 2
    either_0 = Either(int_0)
    either_1 = either_0.to_lazy()

    assert isinstance(either_1, Lazy)
    assert either_1.value() == int_0

    either_2 = Either(int_0).to_lazy()
    either_3 = Either(int_0).to_lazy()

    assert either

# Generated at 2022-06-25 23:34:16.746488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    float_1 = float_0
    either_0 = Right(float_1)
    assert either_0.to_lazy().value() == float_0
    str_0 = "Rtgb;,pfglmhv;fdt{]|\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f"
    either_1 = Left(str_0)
    assert either_1.to_lazy().value() == str_0

# Generated at 2022-06-25 23:34:25.319130
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 13
    either_0 = Either(int_0)

    from pymonet.lazy import Lazy

    lazy_0 = either_0.to_lazy()

    assert lazy_0.__class__ == Lazy
    assert lazy_0.value() == int_0


# Generated at 2022-06-25 23:34:29.675416
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1765.1
    either_0 = Either(float_0)

    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.evaluate()

    assert float_0 == float_1



# Generated at 2022-06-25 23:34:55.111026
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    float_1 = lazy_0.value()
    return float_0 == float_1



# Generated at 2022-06-25 23:34:57.252176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 1594.3
    either = Either(value)
    lazy = either.to_lazy()
    assert lazy.value == value


# Generated at 2022-06-25 23:35:05.518876
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 0.0
    float_1 = 1.0
    float_2 = 2.0
    float_3 = 3.0
    float_4 = 4.0
    float_5 = 5.0
    float_6 = 6.0
    float_7 = 7.0
    float_8 = 8.0
    float_9 = 9.0
    float_10 = 10.0
    float_11 = 11.0
    float_12 = 12.0
    string_0 = "abc"
    string_1 = "xyz"
    either_0 = Either(float_0)
    either_1 = Either(string_0)
    # Call method to_lazy on Either
    result_lazy_0: Lazy[Callable[..., float]] = either_0.to_lazy()

# Generated at 2022-06-25 23:35:08.036430
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert (isinstance(lazy_0, Lazy))
    assert (lazy_0.value == float_0)



# Generated at 2022-06-25 23:35:10.661579
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 123
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    str_0 = "S"
    str_1 = str_0
    assert str_1 == str_0


# Generated at 2022-06-25 23:35:18.178681
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def to_lazy():
        """
        Transform Either to Try.

        :returns: Lazy monad with function returning previous value
        :rtype: Lazy[Function() -> A]
        """
        from pymonet.lazy import Lazy

        return Lazy(lambda: self.value)

    left_0 = Left(54)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    lazy_1 = Lazy(lambda: 54)
    assert lazy_0 == lazy_1
    right_0 = Right(32)
    lazy_2 = right_0.to_lazy()
    assert isinstance(lazy_2, Lazy)
    lazy_3 = Lazy(lambda: 32)

# Generated at 2022-06-25 23:35:21.002293
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def either_to_lazy_0():
        int_0 = -2623
        either_0 = Either(int_0)
        assert either_0.to_lazy().evaluate().value == int_0

    either_to_lazy_0()


# Generated at 2022-06-25 23:35:28.669436
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    float_0 = 1142.5
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == float_0, 'Expected "assert lazy_0.value() == float_0" to be true'
    str_0 = 'nW8o9p'
    either_1 = Either(str_0)
    lazy_0 = either_1.to_lazy()
    assert lazy_0.value() == str_0, 'Expected "assert lazy_0.value() == str_0" to be true'
    tuple_0 = (121, (8.0, 59.0, 32.0), '&', 35)
    either_2 = Either(tuple_0)
    lazy_0 = either_2.to_lazy

# Generated at 2022-06-25 23:35:31.544530
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1594.3
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()

    result = Lazy(lambda: float_0)
    assert lazy_0 == result



# Generated at 2022-06-25 23:35:34.763930
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.0
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == float_0


# Generated at 2022-06-25 23:36:29.529184
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    assert either_0.to_lazy() == Lazy(lambda: 1594.3)



# Generated at 2022-06-25 23:36:34.438403
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 1594.3
    either_0 = Either(float_0)

    assert isinstance(either_0.to_lazy(), Lazy)
    assert type(either_0.to_lazy()) == Lazy
    assert either_0.to_lazy() == Lazy(lambda: float_0)
    assert float_0 == either_0.to_lazy().get()


# Generated at 2022-06-25 23:36:39.703484
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_string_0 = Either('test')
    #{'either_string_0': Either[str]}
    lazy_string_0 = either_string_0.to_lazy()
    #{'lazy_string_0': Lazy[str]}
    string_0 = lazy_string_0.value
    #{'either_string_0': Either[str], 'lazy_string_0': Lazy[str], 'string_0': str}
    assert string_0 == 'test', "AssertionError: "


# Generated at 2022-06-25 23:36:42.611405
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)
    result = either_0.to_lazy()
    lazy_0 = Lazy(lambda: float_0)
    assert lazy_0 == result


# Generated at 2022-06-25 23:36:44.585634
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:36:49.388708
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_0 = Maybe.just(1)
    either_0 = maybe_0.to_either('empty')
    lazy_0 = either_0.to_lazy()
    assert lazy_0 == Lazy(lambda: 1)



# Generated at 2022-06-25 23:36:53.023467
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Either(80.5).to_lazy()
    lazy_1 = Lazy(lambda: 80.5)
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:36:56.138074
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Either(float_0)

    from pymonet.lazy import Lazy

    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == float_0


# Generated at 2022-06-25 23:37:02.008009
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    float_0 = 1594.3
    either_0 = Right(float_0)
    lazy_0 = either_0.to_lazy()

    assert lazy_0.value() == float_0



# Generated at 2022-06-25 23:37:03.571236
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 1
    either = Either(value)
    assert either.to_lazy() == Lazy(lambda: value)