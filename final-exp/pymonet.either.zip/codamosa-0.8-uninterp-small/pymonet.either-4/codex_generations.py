

# Generated at 2022-06-25 23:27:36.370478
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    int_0 = 18
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()


# Generated at 2022-06-25 23:27:43.996705
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = 'l\x1d\x8dv%r\x13\x9e\x15U6\x0e4{\x02>|\x12\x16\x04'
    either_0 = Right(str_0)
    either_1 = Left('f\x0c\x05\x14\x1b\x16\x1bi\x1d\x0e\x0c>\x16')
    assert either_0 == either_0
    assert either_1 == either_1
    assert not either_0 == either_1
    assert not either_1 == either_0


# Generated at 2022-06-25 23:27:49.049327
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    right_1 = Right(str_0)
    assert right_0 == right_1
    str_1 = 'a\nTl4FKRW\x0c'
    right_2 = Right(str_1)
    assert right_0 != right_2



# Generated at 2022-06-25 23:27:53.031336
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    right_0_lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:27:59.354466
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    left_0 = Left(str_0)
    assert right_0.__eq__(left_0) == False, '__eq__ of Either failed'
    assert left_0.__eq__(right_0) == False, '__eq__ of Either failed'
    assert right_0.__eq__(right_0) == True, '__eq__ of Either failed'
    assert left_0.__eq__(left_0) == True, '__eq__ of Either failed'


# Generated at 2022-06-25 23:28:05.545319
# Unit test for method case of class Either
def test_Either_case():
    left_0 = Left(7)
    int_0 = left_0.case(lambda arg: arg // arg, lambda arg: arg * arg)
    int_1 = Left(20).case(lambda arg: arg ** 2, lambda arg: arg)
    assert int_0 == 49
    assert int_1 == 400


# Generated at 2022-06-25 23:28:17.274390
# Unit test for method case of class Either
def test_Either_case():
    str_0 = '5Ft\n9XW\x0c'
    left_0 = Left(str_0)
    assert left_0.case(lambda x: str(x), lambda x: str(x)) == '5Ft\n9XW\x0c'

    str_0 = '1S\n_\x0c'
    right_0 = Right(str_0)
    assert right_0.case(lambda x: str(x), lambda x: str(x)) == '1S\n_\x0c'

    str_0 = '\n\x0c'
    right_0 = Right(str_0)
    assert right_0.case(lambda x: bool(x), lambda x: bool(x)) == bool('\n\x0c')


# Generated at 2022-06-25 23:28:25.814303
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right_0 = Right('A\x07F&\n\x13\x15')
    right_1 = Right('A\x07F&\n\x13\x15')
    assert right_0 == right_1
    int_0 = -10
    left_0 = Left(int_0)
    left_1 = Left(int_0)
    assert left_0 == left_1
    int_1 = -3
    left_2 = Left(int_1)
    assert not left_0 == left_2
    assert not left_1 == right_0
    assert not right_0 == left_1
    right_2 = Right('{\x18J\x05\r\r')
    assert not right_1 == right_2


# Generated at 2022-06-25 23:28:36.409667
# Unit test for method case of class Either
def test_Either_case():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    def fnc_0(arg_1: str) -> str:
        return arg_1
    def fnc_1(arg_1: str) -> str:
        return arg_1
    str_1 = right_0.case(fnc_0, fnc_1)
    str_2 = 'a\nTl4FKRW\x0c'
    assert str_1 == str_2
    str_0 = 'a\nTl4FKRW\x0c'
    left_0 = Left(str_0)
    def fnc_0(arg_1: str) -> str:
        return arg_1

# Generated at 2022-06-25 23:28:41.208632
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'j\nq\x0cC\x1f'
    either_0 = Either(str_0)
    lazy_0 = either_0.to_lazy()
    str_1 = '#\x1f\x0b\x0c'
    str_2 = 'j\nq\x0cC\x1f'
    assert lazy_0.value == str_1


# Generated at 2022-06-25 23:28:47.102248
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Return value of method to_lazy
    actual = None

    # Expected value
    expected = None

    # Call method to_lazy
    actual = None.to_lazy()

    # Method must return expected value
    assert actual == expected, f'Excepted {expected}, got {actual}'


# Generated at 2022-06-25 23:28:51.566089
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:28:59.498432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test case 0
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0 == Lazy(lambda: str_0)
    # Test case 1
    l_0 = [123, 'abc', None, 'xyz']
    left_0 = Left(l_0)
    lazy_1 = left_0.to_lazy()
    assert lazy_1 == Lazy(lambda: l_0)


# Generated at 2022-06-25 23:29:02.971161
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:29:06.278880
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    result_0 = right_0.to_lazy()
    assert type(result_0) is Lazy
    assert result_0.value == str_0


# Generated at 2022-06-25 23:29:11.780493
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    assert right_0.case(error=lambda v: v.__class__.__name__, success=lambda v: 'right') == 'right'
    assert right_0.to_box().case(error=lambda v: v.__class__.__name__, success=lambda v: v) == str_0
    assert right_0.to_try().case(error=lambda v: v.__class__.__name__, success=lambda v: 'right') == 'right'
    assert right_0.to_lazy().value().case(error=lambda v: v.__class__.__name__, success=lambda v: v) == str_0


# Generated at 2022-06-25 23:29:17.167586
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    try:
        a = Right("test_Either_to_lazy")
        l = a.to_lazy()
        print("test_Either_to_lazy(): value = " + l.get())
        assert(l.get() == "test_Either_to_lazy")
    except Exception:
        print("Error in test_Either_to_lazy.")
        raise


# Generated at 2022-06-25 23:29:19.444673
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    result_0 = Right(str_0).to_lazy()


# Generated at 2022-06-25 23:29:22.837119
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)

    str_1 = right_0.to_lazy().value()

    assert str_1 == 'a\nTl4FKRW\x0c'


# Generated at 2022-06-25 23:29:29.729271
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    list_0 = ['\x02', '\x0b', '\x10', '\x1a', '\xdc', '\xf9', '\x1b', '\xfa', '\x02', '\x81', '\x00']
    right_1 = Right(list_0)
    assert right_1.to_lazy() == Lazy(lambda: list_0)


# Generated at 2022-06-25 23:29:34.546691
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-25 23:29:43.770579
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    class TestException(Exception):
        pass

    str_0 = '2\r\x0c\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    right_0 = Right(str_0)
    class_0 = right_0.to_lazy()
    class_1 = right_0.to_lazy()

# Generated at 2022-06-25 23:29:47.044306
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_1 = 'a\nTl4FKRW\x0c'
    right_1 = Right(str_1)
    lazy_0 = right_1.to_lazy()
    assert lazy_0.value == str_1


# Generated at 2022-06-25 23:29:55.660358
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    lazy_0.is_forced()
    lazy_0.evaluate()
    str_1 = 'a\nTl4FKRW\x0c'
    str_2 = 'a\nTl4FKRW\x0c'
    right_1 = Right(str_1)
    right_2 = right_1.map(lambda x_1: str_2)
    lazy_1 = right_2.to_lazy()
    lazy_1.is_forced()
    lazy_1.evaluate()
    str_3 = 'a\nTl4FKRW\x0c'

# Generated at 2022-06-25 23:29:59.092297
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '!\r\x0cx'
    left_0 = Left(str_0)
    Lazy = left_0.to_lazy()
    Lazy.value()


# Generated at 2022-06-25 23:30:02.513797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_option import Option

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:30:03.721154
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert str_0 == Right(str_0).to_lazy()


# Generated at 2022-06-25 23:30:12.659021
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    string_0 = 'a\nTl4FKRW\x0c'
    lazy_0 = right_0.to_lazy()
    string_1 = lazy_0.value()
    assert string_1 == string_0
    str_1 = 'pN4wee5>'
    right_1 = Right(str_1)
    lazy_1 = right_1.to_lazy()
    string_2 = lazy_1.value()
    assert string_2 == str_1
    str_2 = '\nB_sCPbQq3'
    right_2 = Right(str_2)
    lazy_2 = right_2.to_lazy()
   

# Generated at 2022-06-25 23:30:14.728580
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'hNuftKj\n'
    right_0 = Right(str_0)

    lazy_0 = right_0.to_lazy()
    result = lazy_0.evaluate()
    assert result == str_0


# Generated at 2022-06-25 23:30:20.260835
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('\x00\x0c\x1f\x1f\x0e').to_lazy() == Lazy(lambda: '\x00\x0c\x1f\x1f\x0e')
    str_0 = '\t'
    assert Right(str_0).to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:30:31.633438
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)

    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.get()

    assert str_0 == str_1

    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.get()

    assert str_0 == str_1

    str_0 = 'q3Q\x1b\x06\x065\x1f\x7fG\x04'
    right_0 = Right(str_0)

    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.get()

    assert str_0 == str_1

    lazy_0 = right_0.to

# Generated at 2022-06-25 23:30:33.688290
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.value == str_0


# Generated at 2022-06-25 23:30:35.678941
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:30:38.464373
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:30:47.877555
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_0 == str_1
    str_2 = '\x1f\x1eR\x1a\x17\x00X\x0c'
    left_0 = Left(str_2)
    lazy_1 = left_0.to_lazy()
    str_3 = lazy_1.value()
    assert str_2 == str_3


# Generated at 2022-06-25 23:30:53.191297
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()

    try:
        assert str_0 == lazy_0.force()
    except AssertionError as e:
        print('Received assertion error, expected {0} but received {1}'.format(str_0, lazy_0.force()))


# Generated at 2022-06-25 23:31:03.407764
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:31:10.248532
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '3=f\x0e\x7f\x18\x04\x1a\x1f\x12'
    right_0 = Right(str_0)
    # Check that method returns Lazy monad
    # Check that method returns Lazy monad with resolved function with previous value
    assert isinstance(right_0.to_lazy(), Lazy) and\
        isinstance(right_0.to_lazy().value(), str_0)


# Generated at 2022-06-25 23:31:16.175761
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func_0(func):
        str_0 = 'a\nTl4FKRW\x0c'
        def func_1():
            int_0 = 3
            str_1 = 'a\nTl4FKRW\x0c'
            int_1 = func(str_1, int_0)
            return int_1
        left_0 = Left(func_1)


# Generated at 2022-06-25 23:31:24.424089
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = ''
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    int_0 = lazy_0.get_value()
    left_1 = Left(int_0)
    str_1 = '\nV R'
    right_0 = Right(str_1)
    lazy_1 = right_0.to_lazy()
    str_2 = lazy_1.get_value()
    right_1 = Right(str_2)



# Generated at 2022-06-25 23:31:29.058154
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    def t_case_0(obj_0):
        assert obj_0 is right_0

    right_0.to_lazy()


# Generated at 2022-06-25 23:31:32.152845
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '~}Hv!8=\x0c'
    right_0 = Right(str_0)
    assert right_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:31:43.477723
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\x0b|>\x15aH\x13\x1b\x0b\x11\x1d\x1f\x1c'
    str_1 = '\x0b|>\x15aH\x13\x1b\x0b\x11\x1d\x1f\x1c'
    str_2 = 's\x1c\x1c\x1d\x1e'
    int_0 = 1685
    str_3 = '\x0b|>\x15aH\x13\x1b\x0b\x11\x1d\x1f\x1c'

# Generated at 2022-06-25 23:31:46.213388
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert unit_test_Either_to_lazy(Left, Right)

# Unit testing helper function for method to_lazy of class Either

# Generated at 2022-06-25 23:31:51.388025
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert 'a\nTl4FKRW\x0c' == Right('a\nTl4FKRW\x0c').to_lazy().value()
    assert 'a\nTl4FKRW\x0c' == Left('a\nTl4FKRW\x0c').to_lazy().value()


# Generated at 2022-06-25 23:32:01.355364
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n\x1dw\x14\x1a\n\x0e\x1d\x15\n\x12\x1c\x1a\x16\x1d'
    either_0 = Right(str_0)
    lazy_0 = either_0.to_lazy()

# Generated at 2022-06-25 23:32:04.145677
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    t_0 = Right('a\nTl4FKRW\x0c')
    t_1 = t_0.to_lazy()
    assert callable(t_1.value)


# Generated at 2022-06-25 23:32:06.415148
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    either_0 = right_0

    # Test for method to_lazy of class Either
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == either_0.value

# Generated at 2022-06-25 23:32:11.019557
# Unit test for method to_lazy of class Either
def test_Either_to_lazy(): 
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    assert right_0.to_lazy().value() == str_0
    str_1 = '#\x1ftB\x0b\x16^\x05\x18'
    left_0 = Left(str_1)
    assert left_0.to_lazy().value() == str_1


# Generated at 2022-06-25 23:32:20.197133
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    str_0 = 'a\nTl4FKRW\x0c'
    str_1 = 'a\nTl4FKRW\x0c'
    str_2 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    right_1 = Right(str_1)
    right_2 = Right(str_2)
    assert right_0.to_lazy() == Lazy(lambda: str_0)
    assert right_1.to_lazy() == Lazy(lambda: str_1)
    assert right_2.to_lazy() == Lazy(lambda: str_2)


# Generated at 2022-06-25 23:32:30.374672
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\x00\r\r\rq\x19\x12\x00\x15(\x0f\x0f\x06\x0c\x17\x17\x06\x05\x16\x19\x1e\x01\x0c\x1b\x0b\x1f\x1c\x18\x1f\x0f\x11\x19\x1c\x07\x10\x19\x08\x05b\x00'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert lazy_0.evaluate() == str_0


# Generated at 2022-06-25 23:32:38.575218
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    sequence_0 = sequence({'0': 0, '1': 1, '2': 2, '3': 3})
    sequence_1 = sequence_0.to_lazy()
    err_0 = Left(sequence_0)
    err_1 = err_0.to_lazy()
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    right_1 = right_0.to_lazy()
    str_1 = 'h\x1d\x1a\x1e\x17\x0ei\x10\r'
    right_2 = right_1
    right_2 = right_1.to_lazy()
    right_3 = Right(str_1)
    right_4 = right_3.to_lazy

# Generated at 2022-06-25 23:32:42.488109
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\x12\x18\x0b/}#y"\x1a'
    right_0 = Right(str_0)
    assert right_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:32:46.508407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # init
    right_0 = Right('value')

    # action
    lazy_0 = right_0.to_lazy()
    lazy_1 = lazy_0.force()

    # assert
    assert lazy_1 == 'value'


# Generated at 2022-06-25 23:32:55.127867
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '8wy\rP\x13@\x12\x0b\t\r\t\r'
    right_0 = Right(str_0)
    str_1 = '\x0c\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b'
    right_1 = Right(str_1)
    str_2 = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
    right_2 = Right(str_2)

# Generated at 2022-06-25 23:33:02.215507
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    left_0 = Left(str_0)
    result_0 = left_0.to_lazy()
    assert isinstance(result_0, Either)
    assert result_0 is not left_0
    result_0 = left_0.to_lazy()
    assert isinstance(result_0, Either)
    assert result_0 is not left_0
    assert left_0.to_lazy() == left_0.to_lazy()
    right_0 = Right(str_0)
    assert right_0.to_lazy() == right_0.to_lazy()



# Generated at 2022-06-25 23:33:03.350821
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    assert not True



# Generated at 2022-06-25 23:33:10.679893
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test on string
    str_0 = 'M\x1a\x18JL\nDM\x0e\x16PJ\x04@\x16\x1a\x18\x16\x14\x11\x1c\x18\x1b'
    right_0 = Right(str_0)
    result_0 = right_0.to_lazy()
    assert result_0.force() == str_0

    # Test on integer
    int_0 = -1528963381
    either_0 = Left(int_0)
    result_1 = either_0.to_lazy()
    assert result_1.force() == int_0


# Generated at 2022-06-25 23:33:14.860076
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(None).to_lazy().strict() is None
    assert Either('a').to_lazy().strict() == 'a'
    assert Either(1).to_lazy().strict() == 1
    assert Either(True).to_lazy().strict() is True


# Generated at 2022-06-25 23:33:17.137391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'YTJO\r'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()

# Generated at 2022-06-25 23:33:26.419728
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_iterable import LazyIterable
    int_0 = 0
    lazy_1 = Right(int_0).to_lazy()
    lazy_2 = Right(int_0).to_lazy()
    assert lazy_1 == lazy_2


# Generated at 2022-06-25 23:33:31.675521
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for class Right
    str_0 = 'b\n+"8W!\x14=w5'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()()
    assert lazy_0 == str_0
    # Test for class Left
    bool_0 = True
    left_0 = Left(bool_0)
    lazy_0 = left_0.to_lazy()()
    assert lazy_0 == bool_0


# Generated at 2022-06-25 23:33:36.701556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    def_0 = Right(str_0)
    def_1 = def_0.to_lazy()
    check_0 = def_1.eval()
    if check_0 != str_0:
        raise AssertionError('to_lazy fails')
    def_2 = def_0.ap(Right(lambda x: x.upper()))
    check_1 = def_2.value
    if check_1 != str_0.upper():
        raise AssertionError('to_lazy fails')
    return True


# Generated at 2022-06-25 23:33:41.745607
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    # Right
    right_0 = Right(str_0)
    # Lazy
    lazy_0 = right_0.to_lazy()
    lazy_0_value = lazy_0.value
    assert (lazy_0_value() == str_0)
    lazy_0_value_callable = lazy_0_value
    lazy_0_value_result = lazy_0_value_callable()
    assert (lazy_0_value_result == str_0)


# Generated at 2022-06-25 23:33:48.824041
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n5\x1f\x15\x0b'
    int_0 = 10
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.get() == str_0
    left_1 = Left(str_0)
    lazy_0 = left_1.to_lazy()
    assert lazy_0.get() == str_0
    right_0 = Right(int_0)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.get() == int_0
    left_2 = Left(int_0)
    lazy_2 = left_2.to_lazy()
    assert lazy_2.get() == int_0

# Generated at 2022-06-25 23:33:55.792899
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import io
    import sys
    import unittest

    class TestToLazy(unittest.TestCase):
        def test_0(self):
            str_0 = 'p\n'
            right_0 = Right(str_0)
            lazy_0 = right_0.to_lazy()
            self.assertEqual(isinstance(lazy_0, Lazy), True)
            str_1 = 'p\n'
            self.assertEqual(lazy_0.value(), str_1)


# Generated at 2022-06-25 23:33:58.208990
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'S\t9\x16'
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.get() == str_0



# Generated at 2022-06-25 23:34:03.043107
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_0 == str_1


# Generated at 2022-06-25 23:34:10.770855
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def str_0():
        return 'a\nTl4FKRW\x0c'

    right_0 = Right(str_0)
    right_1 = right_0.to_lazy()
    assert isinstance(right_1, Lazy)
    assert right_1.is_memoized() is False
    assert right_1.is_forced() is False
    assert right_1.value() == 'a\nTl4FKRW\x0c'
    assert right_1.is_memoized() is True
    assert right_1.is_forced() is True


# Generated at 2022-06-25 23:34:19.085467
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = ' '
    right_0 = Right(str_0)
    str_1 = '9dH|>'
    right_1 = Right(str_1)
    tuple_0 = (right_0, right_1)
    list_0 = [right_0, right_1]
    list_1 = []
    list_2 = [right_1, right_0]
    list_3 = ['\x0f', right_0, right_1, 'N-\t', right_0, right_0, right_1, right_0, right_0, right_1, right_1, right_0, right_0, right_1, right_0, right_1, right_1, right_1, right_1, right_1, right_1]

# Generated at 2022-06-25 23:34:35.256044
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 1599164024
    left_0 = Left(int_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:34:39.732590
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    num_1 = -6
    left_0 = Left(num_1)
    str_0 = 'Tl4FKRW\x0c'
    left_1 = Left(str_0)
    lazy_0 = left_1.to_lazy()
    int_0 = lazy_0.force()


# Generated at 2022-06-25 23:34:42.743376
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'b\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    lazy_1 = lazy_0.memoize()


# Generated at 2022-06-25 23:34:52.530468
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy

# Generated at 2022-06-25 23:34:55.945550
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'trung'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    result = lazy_0.value()
    assert 'trung' == result


# Generated at 2022-06-25 23:34:57.043945
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(3).to_lazy(), Lazy)


# Generated at 2022-06-25 23:35:01.169983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyType

    res = Lazy[LazyType](lambda: 'a\nTl4FKRW\x0c')
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    assert right_0.to_lazy() == res


# Generated at 2022-06-25 23:35:08.288977
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '/\n'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    lazy_0.force()
    assert lazy_0 == right_0

# Generated at 2022-06-25 23:35:14.342158
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    int_0 = -341261794
    success_0 = Right(int_0)
    str_1 = 'b\nTl4FKRW\x0c'
    right_0 = Right(str_1)
    lazy_0 = right_0.to_lazy()
    str_2 = 'd\nTl4FKRW\x0c'
    int_1 = 0x0
    lazy_1 = lazy_0
    lazy_1.value = str_2
    int_2 = 0x0
    lazy_2 = lazy_0
    lazy_2.value = int_1
    function_0 = lambda : Right(0x0)


# Generated at 2022-06-25 23:35:22.850311
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'XDP\x10\x00\x04\x00\x00\x00\x00\x06'
    either_0 = Left(str_0)
    boolean_0 = either_0.is_right()
    boolean_1 = either_0.is_left()
    maybe_0 = either_0.to_maybe()
    lazy_0 = either_0.to_lazy()
    str_1 = 'f!\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    either_1 = Left(str_1)
    boolean_2 = either_1

# Generated at 2022-06-25 23:35:53.054341
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_1 == str_0


# Generated at 2022-06-25 23:35:56.642672
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    str_1 = 'a\nTl4FKRW\x0c'
    left_0 = Left(str_1)



# Generated at 2022-06-25 23:35:58.192568
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()


# Generated at 2022-06-25 23:36:02.981665
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    int_0 = -957178869
    true_0 = True
    left_0 = Left(true_0)
    test_0 = left_0.to_lazy()
    bool_0 = True
    test_1 = left_0.to_lazy()
    right_0 = Right(str_0)
    test_2 = right_0.to_lazy()
    None


# Generated at 2022-06-25 23:36:06.103761
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.value()
    assert (str_1 == 'a\nTl4FKRW\x0c')


# Generated at 2022-06-25 23:36:07.887735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '|$o|2'
    right_0 = Either.Right(str_0)


# Generated at 2022-06-25 23:36:11.487512
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'p\x17o\x1c\x1aSy`\x0e\x03\x16\x10\x0e\x1b'
    right_0 = Right(str_0)
    assert right_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:36:14.602088
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'Ab3yPIG\x0c'
    int_0 = 0
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert None is lazy_0.eval()


# Generated at 2022-06-25 23:36:18.176502
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_1 == 'a\nTl4FKRW\x0c'


# Generated at 2022-06-25 23:36:22.132598
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'a\nTl4FKRW\x0c'
    right_0 = Right(str_0)
    str_1 = right_0.to_lazy().value()
    assert str_1 == str_0


# Generated at 2022-06-25 23:37:26.806836
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_1 = 'a\nTl4FKRW\x0c'
    right_1 = Right(str_1)
    result_2 = right_1.to_lazy()
    assert result_2.get() == str_1


# Generated at 2022-06-25 23:37:30.107220
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '`\x1dq>F\nU6@'
    right_0 = Right(str_0)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
