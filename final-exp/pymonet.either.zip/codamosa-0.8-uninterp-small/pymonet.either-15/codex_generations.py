

# Generated at 2022-06-25 23:27:32.716801
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    assert left_0 != right_0, 'left_0 != right_0'


# Generated at 2022-06-25 23:27:42.295713
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    assert left_0 == left_1
    var_2 = None
    right_0 = Right(var_2)
    var_3 = None
    right_1 = Right(var_3)
    assert right_0 == right_1
    var_4 = None
    left_2 = Left(var_4)
    var_5 = None
    right_2 = Right(var_5)
    assert not left_2 == right_2
    var_6 = None
    right_3 = Right(var_6)
    var_7 = None
    left_3 = Left(var_7)
    assert not right_3 == left_3


# Generated at 2022-06-25 23:27:44.917278
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_case = Either(0) == Either(0)
    right_case = Either(1) == Either(1)

    assert left_case
    assert right_case
    

# Generated at 2022-06-25 23:27:54.910279
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """

    Unit test for method __eq__ of class Either

    """

    var_0 = None
    left_0 = Left(var_0)
    var_0 = None
    left_1 = Left(var_0)
    assert left_0 == left_1
    var_1 = None
    left_0 = Left(var_1)
    assert not left_0 == left_1
    var_0 = None
    right_0 = Right(var_0)
    var_0 = None
    right_1 = Right(var_0)
    assert right_0 == right_1
    var_1 = None
    right_0 = Right(var_1)
    assert not right_0 == right_1
    assert not left_0 == right_0
    assert right_0 == right_0

# Unit test

# Generated at 2022-06-25 23:28:01.527372
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test of to_lazy method of class Either

    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try


    var_0 = None
    var_1 = None
    var_2 = None
    left_0 = Left(var_0)
    right_0 = Right(var_1)
    left_1 = Left(var_1)
    right_1 = Right(var_2)
    try_0 = Try.just(var_0)
    try_1 = Try.nothing(var_1)
    try_2 = Try.run(var_2, var_0)
    lazy_0 = Lazy(var_0)
    lazy_1 = Lazy(var_1)
    left_0.to_lazy()
    right

# Generated at 2022-06-25 23:28:07.012461
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    func_box = Box(lambda x: x)
    lazy_0 = Right(func_box).to_lazy()

    lazy_1 = Left(func_box).to_lazy()

    try_0 = Try(func_box)


# Generated at 2022-06-25 23:28:11.287851
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    var_0 = None
    left_0 = Left(var_0)

    def lambda_0():
        return var_0
    monad_0 = left_0.to_lazy()
    assert isinstance(monad_0, Lazy), 'Wrong type returned by Either.to_lazy'
    assert monad_0.value == lambda_0(), 'Wrong value returned by Either.to_lazy'

    var_1 = Maybe.just('test_Maybe_value')
    right_0 = Right(var_1)

    def lambda_1():
        return var_1
    monad_1 = right_0

# Generated at 2022-06-25 23:28:20.727946
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    assert left_0.__eq__(left_1) == True
    assert left_0.__eq__(None) == False
    assert left_0.__eq__(var_0) == False
    var_0 = None
    left_0 = Left(var_0)
    var_1 = 'A'
    right_1 = Right(var_1)
    assert left_0.__eq__(right_1) == False
    assert left_0.__eq__(None) == False
    assert left_0.__eq__(var_0) == False
    var_0 = 'B'
    right_0 = Right(var_0)
    var

# Generated at 2022-06-25 23:28:22.554002
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = None
    left_1 = Left(var_1)
    assert left_1 == left_0


# Generated at 2022-06-25 23:28:33.255462
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = 13.7
    left_1 = Left(var_1)
    var_2 = 0
    left_2 = Left(var_2)
    var_3 = "str"
    left_3 = Left(var_3)
    var_4 = "test"
    left_4 = Left(var_4)
    var_5 = "1"
    right_0 = Right(var_5)
    var_6 = 3
    right_1 = Right(var_6)
    var_7 = (-9.0)
    right_2 = Right(var_7)
    var_8 = (2.0)
    right_3 = Right(var_8)

# Generated at 2022-06-25 23:28:39.931786
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda x: x
    var_1 = lambda x: x
    var_2 = Right(var_0)
    var_3 = var_2.to_lazy()
    var_4 = var_3.map(var_1)
    var_5 = var_4()
    assert var_5 == var_1(var_0)


# Generated at 2022-06-25 23:28:41.953115
# Unit test for method case of class Either
def test_Either_case():
    assert Either(4).case(lambda x: -x, var_0) == 4
    assert Either(-4).case(var_0, lambda x: -x) == 4


# Generated at 2022-06-25 23:28:47.101261
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = lambda x: x
    var_1 = lambda x: x
    var_2 = Right(1)
    var_3 = Left(1)
    var_4 = var_2.to_lazy()
    assert var_4.value() == 1
    var_5 = var_3.to_lazy()
    assert var_5.value() == 1

# Generated at 2022-06-25 23:28:55.511285
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x * 2, lambda x: x * 3) == 2
    assert Left(1).case(var_0, lambda x: x * 3) == 2
    assert Left(1).case(var_0, var_0) == 2
    assert Right(1).case(lambda x: x * 2, lambda x: x * 3) == 3
    assert Right(1).case(var_0, lambda x: x * 3) == 3
    assert Right(1).case(var_0, var_0) == 3


# Generated at 2022-06-25 23:29:05.011281
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.monad_validation import MonadValidation
    from pymonet.monad_lazy import MonadLazy

    import unittest

    class TestCase(unittest.TestCase):
        def test_0(self):
            var_0 = Left(5)
            var_1 = var_0.case(lambda x: x + 1, lambda x: x - 1)

# Generated at 2022-06-25 23:29:10.091134
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(lambda x: x * x, lambda x: x) == 5
    assert Right(5).case(lambda x: x * x, lambda x: x) == 5


# Generated at 2022-06-25 23:29:16.451079
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    val_0 = Either(1)
    val_1 = Either('ab')
    val_2 = Lazy(lambda: 1)
    val_3 = Lazy(lambda: 'ab')
    assert val_0.to_lazy() == val_2
    assert val_1.to_lazy() == val_3


# Generated at 2022-06-25 23:29:17.425280
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert 1 == 1


# Generated at 2022-06-25 23:29:21.027061
# Unit test for method case of class Either
def test_Either_case():
    is_error = True
    is_success = True
    test_value = 5
    et = Right(test_value)
    error = lambda x: is_error
    success = lambda x: is_success

    res = et.case(error, success)

    assert is_success == res


# Generated at 2022-06-25 23:29:33.070721
# Unit test for method case of class Either
def test_Either_case():
    var_0 = lambda x: x
    var_1 = lambda var_2, var_3: (var_2, var_3)

    # Case 0
    try:
        var_4 = Right(1)
        var_4.case(lambda _: 0)
        var_4.case(lambda _: 0, var_0)
    except Exception:
        var_5 = False
    else:
        var_5 = var_1(var_4.case(lambda _: 0), var_4.case(lambda _: 0, var_0))

    # Case 1
    try:
        var_6 = Left(1)
        var_6.case(var_0)
        var_6.case(var_0, lambda _: 0)
    except Exception:
        var_7 = False

# Generated at 2022-06-25 23:29:37.343252
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Box(None)
    var_1 = Box(var_0)
    var_2 = Functor.map(var_1, lambda var_3: func_2(var_3))


# Generated at 2022-06-25 23:29:40.805266
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)

# Generated at 2022-06-25 23:29:44.531395
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_x = 'x'
    right_x = Right(var_x)
    var_lazy_x = right_x.to_lazy()
    assert var_lazy_x.value() == var_x
    assert var_lazy_x.is_lazy() == True


# Generated at 2022-06-25 23:29:47.793732
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:56.482399
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy().to_maybe() == Maybe.just(3)
    assert Right(3).to_lazy().to_try() == Try(3, is_success=True)
    assert Right(3).to_lazy().to_box() == Box(3)
    assert Right(3).to_lazy().to_box().to_maybe() == Maybe.just(3)
    assert Right(3).to_lazy().to_box().to

# Generated at 2022-06-25 23:29:58.149138
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_case_0()

# Generated at 2022-06-25 23:30:00.488528
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    if isinstance(var_0, Either):
        var_1 = var_0.to_lazy()


# Generated at 2022-06-25 23:30:02.475166
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1


# Generated at 2022-06-25 23:30:08.489407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    boolean_0 = lazy_0.is_value_created()
    var_1 = None
    left_1 = Left(var_1)
    lazy_1 = left_1.to_lazy()
    boolean_1 = lazy_1.is_value_created()
    assert boolean_0 == boolean_1


# Generated at 2022-06-25 23:30:11.839893
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    result_0 = Left(var_0).to_lazy()

    def wrapper_0(_):
        return result_0.value()

    var_1 = wrapper_0(result_0)
    assert var_1 is None
    var_2 = True
    assert var_2

# Generated at 2022-06-25 23:30:19.504885
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Lazy(lambda: 'HelloWorld')
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()
    var_2 = var_1.value()
    assert var_2 == 'HelloWorld'



# Generated at 2022-06-25 23:30:24.650654
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = ""
    left_0 = Left(var_0)
    var_1 = None
    right_0 = Right(var_1)
    lazy_0 = right_0.to_lazy()
    # Check that result of method to_lazy of class Either is instance of class Lazy
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == var_1



# Generated at 2022-06-25 23:30:30.683043
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 0
    var_1 = 1
    var_2 = 2
    for var_3 in range(0, 10):
        left_1 = Left(var_3)
        assert left_1.to_lazy().value() == var_3
        right_0 = Right(var_3)
        assert right_0.to_lazy().value() == var_3


# Generated at 2022-06-25 23:30:34.599175
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    left_0 = Left(var_0)
    right_0 = Right(var_1)
    # Success
    test_0 = left_0.to_lazy()
    assert test_0.value() == var_0
    # Success
    test_1 = right_0.to_lazy()
    assert test_1.value() == var_1


# Generated at 2022-06-25 23:30:44.948583
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, _is_lazy
    from pymonet.either import Right, Left
    from pymonet.tools import is_function
    from random import randint
    from pymonet.box import Box

    # Check if method to_lazy of class Either is implemented
    left_0_1 = Left(Box(None))
    lazy_0_1 = left_0_1.to_lazy()
    assert _is_lazy(lazy_0_1)
    assert is_function(lazy_0_1.f)

    # Check if method to_lazy of class Either is implemented
    right_0_2 = Right(Box(None))
    lazy_0_2 = right_0_2.to_lazy()

# Generated at 2022-06-25 23:30:47.638891
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy().value() == None



# Generated at 2022-06-25 23:30:51.348443
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == var_0


# Generated at 2022-06-25 23:30:53.308767
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0 is not None
    lazy_1 = lazy_0.bind(lambda x: x)
    assert lazy_1 is not None
    var_1 = lazy_1.value()
    assert var_1 == var_0


# Generated at 2022-06-25 23:30:56.486537
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    expected_0 = Lazy(lambda: None)

    assert left_0.to_lazy() == expected_0


# Generated at 2022-06-25 23:31:06.932276
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    box_0 = Box(5)
    validation_0 = Validation.success(5)
    either_0 = Either(5)
    lazy_0 = Lazy(5)
    try_0 = Try(5, is_success=True)
    maybe_0 = Maybe.nothing()

    assert either_0.to_lazy() == lazy_0
    assert either_0.to_lazy() != try_0
    assert either_0.to_lazy() != maybe_0
    assert either_0.to_lazy() != Validation

# Generated at 2022-06-25 23:31:17.698653
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    maybe_0 = left_0.to_maybe()
    var_1 = Maybe.just(None)
    assert maybe_0 == var_1


# Generated at 2022-06-25 23:31:20.464792
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 2
    right_0 = Right(var_0)
    assert right_0.to_lazy().value() == right_0.value


# Generated at 2022-06-25 23:31:28.410216
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    var_1 = Right(var_0)
    assert var_1.to_lazy() == Lazy(lambda: None)
    var_2 = Left(var_0)
    assert var_2.to_lazy() == Lazy(lambda: None)

if __name__ == '__main__':
    import sys
    import pymonet.instances
    pymonet.instances.configure(sys.modules[__name__], globals())

# Generated at 2022-06-25 23:31:31.124756
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    result_0 = left_0.to_lazy()
    assert type(result_0) is Lazy


# Generated at 2022-06-25 23:31:42.536516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Input:
    left_0 = Left(0)
    right_1 = Right(1)
    right_2 = Right(2)
    right_3 = Right(3)
    right_4 = Right(4)
    right_5 = Right(5)
    right_6 = Right(6)
    right_7 = Right(7)
    right_8 = Right(8)
    right_9 = Right(9)
    right_10 = Right(10)

    # Output:
    lazy_left_0 = left_0.to_lazy()
    lazy_right_1 = right_1.to_lazy()
    lazy_right_2 = right_2.to_lazy()
    lazy_right_3 = right_3.to_lazy()

# Generated at 2022-06-25 23:31:46.729750
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = 5
    right_0 = Right(var_0)
    assert right_0.to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:31:57.251144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # <Left[T](T value)>.to_lazy() <Right[T](T value)>.to_lazy()
    def check_to_lazy(actual, expected, message=None):
        if message is None:
            message = "(actual: {}) != (expected: {})".format(actual, expected)
        assert actual == expected, message

    # T is int
    var_0 = 0
    left_0 = Left(var_0)
    right_0 = Right(var_0)
    left_0_lazy_0 = left_0.to_lazy()
    right_0_lazy_0 = right_0.to_lazy()

# Generated at 2022-06-25 23:32:06.707060
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    assert Left('test').to_lazy() == Lazy(lambda: 'test')
    assert Left(Box('test')).to_lazy() == Lazy(lambda: Box('test'))
    assert Left(Lazy(lambda: 'test')).to_lazy() == Lazy(lambda: Lazy(lambda: 'test'))
    assert Left(Try('test')).to_lazy() == Lazy(lambda: Try('test'))
    assert Left(Maybe.just('test')).to_lazy() == Lazy(lambda: Maybe.just('test'))

# Generated at 2022-06-25 23:32:10.409983
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = None
    left_0 = Left(var_0)
    test_expression_0 = left_0.to_lazy()
    if Lazy(lambda: var_0) != test_expression_0:
        raise AssertionError("test_Either_to_lazy")


# Generated at 2022-06-25 23:32:19.527786
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    var_1 = None
    either_0 = Either(var_0)
    either_1 = Either(var_1)
    lazy_0 = either_0.to_lazy()
    lazy_1 = either_1.to_lazy()
    var_2 = True
    var_3 = False
    test_0 = lazy_0.is_type_of()
    test_1 = lazy_1.is_type_of()
    test_2 = lazy_0 == var_0
    test_3 = lazy_1 == var_1
    test_4 = Lazy(var_0).is_type_of()
    test_5 = Lazy(var_1).is_type_of()
    assert test_0 != var_2

# Generated at 2022-06-25 23:32:34.346852
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:32:37.914979
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    generic_test_method(lambda: left_0.value, lazy_0.value)


# Generated at 2022-06-25 23:32:42.761556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Either.Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value == var_0
    var_1 = None
    right_0 = Either.Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.value == var_1


# Generated at 2022-06-25 23:32:48.356508
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == None
    var_1 = u'\u1130'
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.value() == u'\u1130'


# Generated at 2022-06-25 23:32:53.800196
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Either(5).to_lazy() == Lazy(lambda: 5))
    assert(Either('a').to_lazy() == Lazy(lambda: 'a'))
    assert(Either({'a': 5}).to_lazy() == Lazy(lambda: {'a': 5}))
    assert(Either(True).to_lazy() == Lazy(lambda: True))
    assert(Either(False).to_lazy() == Lazy(lambda: False))


# Generated at 2022-06-25 23:32:56.176008
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy


    def func():
        return 1


    assert Right(func).to_lazy() == Lazy(func)



# Generated at 2022-06-25 23:32:59.710429
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = None
    right_0 = Right(var_2)
    var_3 = right_0.to_lazy()


# Generated at 2022-06-25 23:33:01.424365
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:33:06.891617
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    var_0 = 1
    try_var_0 = Try(var_0, is_success=True)
    validation_var_0 = Validation.success(var_0)
    box_var_0 = Box(var_0)
    maybe_var_0 = Maybe.just(var_0)
    lazy_var_0 = Lazy(lambda: var_0)
    assert lazy_var_0.get() == var_0
    assert lazy_var_0.map(lambda x: x * 2 + 1).get() == var_0 * 2 + 1
    assert lazy_var_

# Generated at 2022-06-25 23:33:08.475657
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = Right(7)
    var_1 = var_0.to_lazy()



# Generated at 2022-06-25 23:33:39.279751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    func_0 = left_0.to_lazy()
    func_1 = func_0.value

    func_2 = func_1()

    assert func_2 is var_0


# Generated at 2022-06-25 23:33:41.464320
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    test_box_0 = Right(var_0).to_lazy()
    var_1 = None
    test_box_0 = Left(var_1).to_lazy()


# Generated at 2022-06-25 23:33:44.860677
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(lambda: var_0)
    var_0 = None
    right_0 = Right(var_0)
    assert right_0.to_lazy() == Lazy(lambda: var_0)


# Generated at 2022-06-25 23:33:48.753348
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()

    assert lazy_0.is_instance_of(Lazy)
    var_0 = 'test'
    right_0 = Right(var_0)
    lazy_0 = right_0.to_lazy()

    assert lazy_0.is_instance_of(Lazy)


# Generated at 2022-06-25 23:33:52.922383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Either.to_lazy()

    :returns: Lazy monad with function returning previous value
    :rtype: Lazy[Function() -> A]
    """
    var_0 = None
    left_0 = Left(var_0)
    right_0 = right(var_0)
    assert left_0.to_lazy().force() == var_0
    assert right_0.to_lazy().force() == var_0


# Generated at 2022-06-25 23:33:55.639195
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    right_0 = Right(var_0)
    var_1 = right_0.to_lazy()
    left_0 = Left(var_0)
    var_2 = left_0.to_lazy()


# Generated at 2022-06-25 23:33:59.318950
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = 'a'
    left_0 = Left(var_0)
    assert left_0.to_lazy() == Lazy(var_0)
    var_1 = 'a'
    right_0 = Right(var_1)
    assert right_0.to_lazy() == Lazy(var_1)


# Generated at 2022-06-25 23:34:05.792815
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(2).to_lazy(), Lazy)
    assert Left(2).to_lazy().value() == 2
    assert isinstance(Right(3).to_lazy(), Lazy)
    assert Right(3).to_lazy().value() == 3
    assert Left("hallo").to_lazy().value() == "hallo"
    assert Right("hallo").to_lazy().value() == "hallo"

# Generated at 2022-06-25 23:34:10.975528
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Assert for method to_lazy of class Either
    """
    # Test # 1
    var_0 = None
    left_0 = Left(var_0)
    assert left_0.to_lazy().get() is None

    # Test # 3
    var_3 = 2
    right_3 = Right(var_3)
    assert right_3.to_lazy().get() == 2


# Generated at 2022-06-25 23:34:19.214397
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    var_0 = None
    lazy_0 = Either(Try(var_0, is_success=False)).to_lazy()
    isinstance(lazy_0.value(), Try)
    Maybe.of(lazy_0.value()).is_just().is_false()
    Either(Try(var_0, is_success=True)).to_lazy().value().is_success()

    var_0 = None
    lazy_0 = Either(Lazy(var_0)).to_lazy()
    isinstance(lazy_0.value(), Lazy)


# Generated at 2022-06-25 23:35:21.554608
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    success = lazy_0.value()
    failure = lazy_0.value()
    assert isinstance(failure, NoneType)


# Generated at 2022-06-25 23:35:29.352850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad_try import Success

# Generated at 2022-06-25 23:35:32.638902
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    var_0 = None
    left_0 = Left(var_0)

    # Test
    _optional_0 = left_0.to_lazy()

    # Verification
    from pymonet.lazy import Lazy
    assert _optional_0 is not None
    assert isinstance(_optional_0, Lazy)



# Generated at 2022-06-25 23:35:36.977424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy
    var_0 = pymonet.lazy.Lazy(lambda: None)
    left_0 = Left(var_0)
    left_0.to_lazy()
    var_1 = pymonet.lazy.Lazy(lambda: None)
    right_0 = Right(var_1)
    right_0.to_lazy()


# Generated at 2022-06-25 23:35:39.971169
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    var_1 = 1
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()

# Generated at 2022-06-25 23:35:43.500371
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Lazy(lambda: 'test')
    left_0 = Left(var_0)
    var_1 = left_0.to_lazy()
    var_2 = var_1.force()
    assert var_2 == 'test'


# Generated at 2022-06-25 23:35:45.577590
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        var_0 = None
        left_0 = Left(var_0)


# Generated at 2022-06-25 23:35:52.101070
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # TypeError: unbound method to_lazy() must be called with Either instance as first argument (got NoneType instance instead)
    """
    try:
        Either.to_lazy(None)
        assert False
    except TypeError:
        assert True
    """
    try:
        left = Left(lambda x: x + 1)
        left.to_lazy()
        assert False
    except AttributeError:
        assert True

    right = Right(lambda x: x + 1)
    assert isinstance(right.to_lazy(), Lazy)
    assert right.to_lazy().value() == (lambda x: x + 1)


# Generated at 2022-06-25 23:35:53.824035
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    right = Right(1)

    assert right.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:35:59.443862
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    var_0 = None
    left_0 = Left(var_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.is_right()
    assert lazy_0.value() == var_0

    var_1 = None
    right_0 = Right(var_1)
    lazy_1 = right_0.to_lazy()
    assert lazy_1.is_right()
    assert lazy_1.value() == var_1
