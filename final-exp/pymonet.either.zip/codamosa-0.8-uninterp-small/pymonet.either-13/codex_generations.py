

# Generated at 2022-06-25 23:27:41.349226
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    assert left_0 == left_0, "AssertionError: 'Left(str_0) == left_0'"


# Generated at 2022-06-25 23:27:45.035432
# Unit test for method case of class Either
def test_Either_case():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)

# Generated at 2022-06-25 23:27:55.022197
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_1 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_1)

# Generated at 2022-06-25 23:28:01.483436
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    string_ = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    assert Right(string_) == Right(string_)
    assert Right(string_) != Left(string_)
    assert Left(string_) == Left(string_)
    assert Left(string_) != Right(string_)


# Generated at 2022-06-25 23:28:06.672324
# Unit test for method case of class Either
def test_Either_case():
    one = 1
    two = 2
    left = Left(one)
    right = Right(two)
    assert left.case(success=lambda x: x + 1,
                     error=lambda x: x + 1) == one + 1
    assert right.case(success=lambda x: x + 1,
                      error=lambda x: x + 1) == two + 1


# Generated at 2022-06-25 23:28:10.486345
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    left_0 = Left(str(123))
    success_0: Lazy[int] = left_0.to_lazy()
    assert success_0.eval() == 123


# Generated at 2022-06-25 23:28:19.700843
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    right_0 = right_0.__eq__(left_0) == left_0.__eq__(right_0)


# Generated at 2022-06-25 23:28:25.985825
# Unit test for method case of class Either
def test_Either_case():
    assert Left(2).case(
        lambda v: 'this is Left with value: {0}'.format(v),
        lambda v: 'this is Right with value: {0}'.format(v)
    ) == 'this is Left with value: 2'
    assert Right(2).case(
        lambda v: 'this is Left with value: {0}'.format(v),
        lambda v: 'this is Right with value: {0}'.format(v)
    ) == 'this is Right with value: 2'



# Generated at 2022-06-25 23:28:35.424259
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.lazy import Lazy

    def check_len(str_0) -> bool: return len(str_0) < 3

    def get_short_str(str_0): return f'{str_0} is too short'

    def get_long_str(str_0): return f'{str_0} is too long'

    short_str = 'oh'
    long_str = 'Yes'

    assert Right.case(check_len(short_str), get_short_str, get_long_str) == 'oh is too short'


if __name__ == "__main__":
    test_Either_case()
    test_lazy_map()
    test_lazy_bind()

# Generated at 2022-06-25 23:28:43.377163
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert (Left(1) == Left(1))
    assert (Left(1) != Left(2))
    assert (Right(1) == Right(1))
    assert (Right(1) != Right(2))

    assert (Left(1).case(lambda x: x, lambda x: x == 1) == 1)
    assert (Left(1).case(lambda x: not x, lambda x: x == 1) == True)
    assert (Right(1).case(lambda x: x == 1, lambda x: x) == 1)

# Generated at 2022-06-25 23:28:53.147420
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    print('test_Either___eq__')

    maybe_0 = Maybe(0)
    maybe_1 = Maybe(None)
    maybe_2 = Maybe(3)
    maybe_3 = Maybe.nothing()

    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1
    assert maybe_2 == maybe_2
    assert maybe_3 == maybe_3
    assert maybe_0 is not maybe_2
    assert maybe_2 is not maybe_3
    assert maybe_3 is not maybe_0
    assert maybe_1 is not maybe_3


# Generated at 2022-06-25 23:29:03.374464
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)

# Generated at 2022-06-25 23:29:03.903508
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    test_case_0()


# Generated at 2022-06-25 23:29:10.153136
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    assert left_0 == left_1


# Generated at 2022-06-25 23:29:17.181325
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left(25)
    left_1 = Left(25)
    assert left_0 == left_1
    left_2 = Left(64)
    assert left_0 != left_2
    left_3 = Right(64)
    assert left_2 != left_3

# Generated at 2022-06-25 23:29:23.143861
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    eq = Either.__eq__
    # ~ str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    # ~ left_0 = Left(eq)
    # ~ left_1 = Left(str_0)
    # ~ right_0 = Right(eq)
    # ~ right_1 = Right(str_0

# Generated at 2022-06-25 23:29:34.467041
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    right_0 = Right(str_0)
    right_1 = Right(str_0)
    # Asserts equality of two instances of class Either


# Generated at 2022-06-25 23:29:43.690109
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)

    assert left_0 == left_1


# Generated at 2022-06-25 23:29:51.818828
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    left_0 = Left(1)
    right_0 = Right(1)
    assert left_0 == left_0
    assert right_0 == right_0
    assert left_0 != right_0
    assert right_0 != left_0
    assert left_0 != Box(1)
    assert right_0 != Box(1)
    assert left_0 != Try(1, is_success=False)
    assert right_0 != Try(1, is_success=True)
    assert left_0 != Lazy(lambda: 1)
    assert right_0 != Lazy(lambda: 1)



# Generated at 2022-06-25 23:30:00.956389
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    assert left_0 == left_1


# Generated at 2022-06-25 23:30:05.725632
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != None


# Generated at 2022-06-25 23:30:14.002663
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    right_0 = Right(str_0)
    assert left_0 == left_0
    assert not left_0 == right_0
    assert not right_0 == left_0
    assert right_0

# Generated at 2022-06-25 23:30:22.809261
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)

    assert left_0 == left_1


# Generated at 2022-06-25 23:30:32.771916
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left('\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    ')
    lazy_0 = left_0.to_lazy()

# Generated at 2022-06-25 23:30:41.732276
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = Left(str_0)
    assert left_0 != left_1
    assert_eq(left_0 == left_1, False)
    str_2 = 'I love you'


# Generated at 2022-06-25 23:30:51.348253
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    right_0 = Left(str_0)
    eq_0 = left_0 == right_0
    assert eq_0 is True


# Generated at 2022-06-25 23:30:58.468572
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    assert left_0 == left_0


# Generated at 2022-06-25 23:31:07.010952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Initializing instances of class
    right_0 = Right(0)
    left_0 = Left(49)
    left_1 = Left('\n    Generating list of prime numbers.\n\n    :param count: the number of prime numbers to create\n    :type count: int\n    :returns: list of prime numbers\n    :rtype: List[int]\n    ')
    # Initializing call to method
    lazy_0 = left_0.to_lazy()
    # Asserting results of call
    from pymonet.lazy import Lazy
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 49


# Generated at 2022-06-25 23:31:09.757976
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert True is Right(True) == Right(True)
    assert True is Left(False) == Left(False)
    assert True is Left(1) == Left(1)


# Generated at 2022-06-25 23:31:11.246515
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    a = Right("fun")
    b = Right("fun")
    assert a == b



# Generated at 2022-06-25 23:31:17.698788
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(1)
    assert left.to_lazy().value() == 1

    right = Right(2)
    assert right.to_lazy().value() == 2
    
test_Either_to_lazy()


# Generated at 2022-06-25 23:31:28.532532
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0.value(), str)

# Generated at 2022-06-25 23:31:35.613320
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = left_0.to_lazy()
    assert left_1.value() == str_0
    str_1 = 'a'
    left_2 = Left(str_1)


# Generated at 2022-06-25 23:31:43.011093
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left = Left(str_0)
    lazy = left.to_lazy()
    assert lazy.value() == str_0


# Generated at 2022-06-25 23:31:52.760802
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_0.to_lazy()


# Generated at 2022-06-25 23:32:02.270283
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    maybe_0 = Maybe.just(str_0)
    right_0 = Right(maybe_0)
    right_0.to_lazy()


# Generated at 2022-06-25 23:32:10.017314
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test 0
    # Constructor
    left_0 = Left(lambda x: x + 1)

    # Unit test for property value of class Either
    assert left_0.value(5) == 6

    # Unit test for method to_lazy of class Either
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == left_0.value

    # Test 1
    # Constructor
    right_0 = Right(lambda x: x + 1)

    # Unit test for property value of class Either
    assert right_0.value(5) == 6

    # Unit test for method to_lazy of class Either
    lazy_1 = right_0.to_lazy()

# Generated at 2022-06-25 23:32:18.412401
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    str_1 = lazy_0.value()

# Generated at 2022-06-25 23:32:27.471055
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    print('Test for Either to_lazy method')
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: str_0)

# Generated at 2022-06-25 23:32:35.835685
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left__lazy_0 = left_0.to_lazy()
    lazy_to_lazy_0 = lambda: len(left__lazy_0.value())

# Generated at 2022-06-25 23:32:46.739627
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Check conversion of Left to Lazy
    lazy_0 = Left(Box([])).to_lazy()
    assert isinstance(lazy_0, Lazy)
    try_0 = lazy_0.value()
    assert isinstance(try_0, Try)
    assert isinstance(try_0.get(), Box)
    assert try_0.is_success() == False
    assert try_0.value == []

    # Check conversion of Right to Lazy
    lazy_0 = Right(Try(Box(1))).to_lazy()
    assert isinstance(lazy_0, Lazy)
    try_0 = lazy

# Generated at 2022-06-25 23:32:49.521897
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Right
    assert Right(5).to_lazy() == Lazy(lambda: 5)

    # Left
    assert Left(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-25 23:32:52.314669
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    source = Either(str_0)

    lazy: Lazy[str] = source.to_lazy()

    expected = Lazy(str_0)

    assert lazy == expected


# Generated at 2022-06-25 23:32:53.910665
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    A = Either(0)
    assert A.to_lazy().force() == 0


# Generated at 2022-06-25 23:32:56.254007
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 23:33:01.532573
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def curry_0(x):
        def curry_1(y):
            return x + y
        return curry_1
    to_lazy_0 = curry_0('ab')('cd').to_lazy()
    assert to_lazy_0() == 'abcd'
    to_lazy_0 = curry_0('abcd')('ef').to_lazy()
    assert to_lazy_0() == 'abcdef'
test_Either_to_lazy()


# Generated at 2022-06-25 23:33:03.566524
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left("error").to_lazy() == None
    assert Right("success").to_lazy() == None


# Generated at 2022-06-25 23:33:10.601018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Define parameters for test case
    test_case_str = 'Test, when Either is Left'
    expected_value = 4
    iterable = [1, 2, 3, 4, 5]
    func = lambda x: x > 3
    mapper = lambda x: [x]

    # Define Either to test
    either_0 = Left(iterable)

    # Define Lazy to test
    lazy_0 = either_0.to_lazy()

    # Define Maybe to test
    maybe_0 = lazy_0.filter(func).map(mapper)

    # Check
    assert maybe_0.is_nothing(), test_case_str



# Generated at 2022-06-25 23:33:14.741375
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert hasattr(Right(10), 'to_lazy')
    assert hasattr(Left(10), 'to_lazy')
    
    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)


# Generated at 2022-06-25 23:33:19.392461
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test 0:
    # Check that method returns Lazy
    result = Left(1).to_lazy()
    assert isinstance(result, Lazy), 'Incorrect type for Either.to_lazy() method.'
    # Test 1:
    # Check that method returns Lazy
    result = Right(1).to_lazy()
    assert isinstance(result, Lazy), 'Incorrect type for Either.to_lazy() method.'


# Generated at 2022-06-25 23:33:24.371415
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_0():
        assert Right(1).to_lazy().value() == 1

    def test_case_1():
        assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-25 23:33:26.347591
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(str_0).to_lazy().value() == str_0
    assert Right(str_0).to_lazy().value() == str_0


# Generated at 2022-06-25 23:33:28.639144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe

    assert Maybe.just(7).to_lazy().value() == 7
    assert Maybe.nothing().to_lazy().value() == None


# Generated at 2022-06-25 23:33:31.536737
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:33:32.285933
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:33:34.125269
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(1)).run() == 1
    assert Either.to_lazy(Left(None)).run() == None


# Generated at 2022-06-25 23:33:36.121877
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')

# Generated at 2022-06-25 23:33:37.966629
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    function = test_case_0()
    lazy = Either(function).to_lazy()
    assert lazy.value() == function


# Generated at 2022-06-25 23:33:39.720876
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('Error').to_lazy() == Lazy(lambda: 'Error')
    assert Right('').to_lazy() == Lazy(lambda: '')


# Generated at 2022-06-25 23:33:41.933230
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-25 23:33:51.700969
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("left").to_lazy() == Lazy(lambda: "left")
    assert Right("right").to_lazy() == Lazy(lambda: "right")
    assert Right(123).to_lazy() == Lazy(lambda: 123)
    assert Left([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Left({1, 2, 3}).to_lazy() == Lazy(lambda: {1, 2, 3})
    assert Right(Lazy(lambda: "lazy")).to_lazy() == Lazy(lambda: Lazy(lambda: "lazy"))
    assert Right(Right("right")).to_lazy() == Lazy(lambda: Right("right"))


# Generated at 2022-06-25 23:33:53.200465
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    to_lazy_0 = Right(10).to_lazy()
    assert to_lazy_0.force() == 10


# Generated at 2022-06-25 23:34:01.978407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(42)
    assert right_0.to_lazy() == Lazy(lambda: 42), "Assertion error: Wrong Lazy"
    right_1 = Right(None)
    assert right_1.to_lazy() == Lazy(lambda: None), "Assertion error: Wrong Lazy"

# Generated at 2022-06-25 23:34:10.458424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    assert left_0.to_lazy().get() == str_0
# End of unit test

# Generated at 2022-06-25 23:34:14.717955
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("Hello World!").to_lazy() == Lazy(lambda: "Hello World!")
    assert Right("Hello World!").to_lazy() == Lazy(lambda: "Hello World!")



# Generated at 2022-06-25 23:34:20.621677
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    assert left_0.to_lazy().value() == str_0
    str_1 = 'No dependencies, only one function for execute this function.'
    right_0 = Right(str_1)
   

# Generated at 2022-06-25 23:34:24.122213
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    t0 = Left(0)
    t1 = Right(1)
    t0 = t0.to_lazy()
    t1 = t1.to_lazy()
    assert t0.to_box().value == 0
    assert t1.to_box().value == 1


# Generated at 2022-06-25 23:34:28.107910
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left('\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    ')
    lazy_0 = left_0.to_lazy()
    assert lazy_0.get().startswith('\n    ')



# Generated at 2022-06-25 23:34:32.214474
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(None)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:34:34.170951
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:34:49.297449
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)

# Generated at 2022-06-25 23:34:58.414525
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    assert left_0 == left_0.to_lazy().eval()


# Generated at 2022-06-25 23:35:06.452617
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left({
        'key_0': 'value_0',
        'key_1': 'value_1',
    })
    assert isinstance(left_0, Left)
    lazy_0 = left_0.to_lazy()
    assert isinstance(lazy_0, Any)
    lazy_0 = lazy_0.map(lambda value_0: list(value_0.values())[0])
    assert lazy_0.unwrap() == 'value_0'
    right_0 = Right({
        'key_0': 'value_0',
        'key_1': 'value_1',
    })
    assert isinstance(right_0, Right)
    lazy_0 = right_0.to_lazy()
    assert isinstance(lazy_0, Any)

# Generated at 2022-06-25 23:35:08.288086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def identity(x): return x
    assert identity(Right(10).to_lazy().value()) == 10
    assert identity(Left('A').to_lazy().value()) == 'A'


# Generated at 2022-06-25 23:35:14.558274
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '

# Generated at 2022-06-25 23:35:15.362875
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass

# Generated at 2022-06-25 23:35:22.822169
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()


# Generated at 2022-06-25 23:35:29.760034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)

    assert left_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-25 23:35:37.387115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_0_to_lazy = left_0.to_lazy()
    # ValueError: call of non-function (type str)
    # assert left_0_to_lazy() == str

# Generated at 2022-06-25 23:35:45.264012
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    result = left_0.to_lazy()


# Generated at 2022-06-25 23:35:59.783114
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left('test')
    right = Right('test')

    assert isinstance(left.to_lazy(), Lazy) and left.to_lazy().value().value == left.value
    assert isinstance(right.to_lazy(), Lazy) and right.to_lazy().value().value == right.value


# Generated at 2022-06-25 23:36:02.576677
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(42)
    assert right_0.to_lazy() == Lazy(lambda: 42)
    left_0 = Left('c1')
    assert left_0.to_lazy() == Lazy(lambda: 'c1')


# Generated at 2022-06-25 23:36:09.961319
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()
    assert lazy_0.value() == str_0

# Generated at 2022-06-25 23:36:17.931928
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)

    # Unit test for method Lazy.force of class Either

# Generated at 2022-06-25 23:36:20.720751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(0).to_lazy().get() == 0
    assert Right(0).to_lazy().get() == 0


# Generated at 2022-06-25 23:36:24.667424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try_0 = Try(6 + 2)
    either_0 = try_0.to_either()
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == 8



# Generated at 2022-06-25 23:36:33.290343
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    left_1 = left_0.to_lazy()
    left_2 = left_1.value()
    assert left_2 == str_0


# Generated at 2022-06-25 23:36:40.716226
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_1():
        right_0 = Right('\n    Apply f on m\n\n    :param f: function to apply on m\n    :type f: Function\n    :param m: value to apply on f\n    :type m: A\n    :returns: result of apply f on m\n    :rtype: A\n    ')


# Generated at 2022-06-25 23:36:49.718106
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '
    left_0 = Left(str_0)
    lazy_0 = left_0.to_lazy()

# Generated at 2022-06-25 23:36:50.888958
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-25 23:37:25.940664
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = '\n    Function for return function depended on first function argument\n    cond get list of two-item tuples,\n    first is condition_function, second is execute_function.\n    Returns this execute_function witch first condition_function return truly value.\n\n    :param condition_list: list of two-item tuples (condition_function, execute_function)\n    :type condition_list: List[(Function, Function)]\n    :returns: Returns this execute_function witch first condition_function return truly value\n    :rtype: Function\n    '

    assert isinstance(Left(str_0).to_lazy().force(), str)


# Generated at 2022-06-25 23:37:30.155106
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right(1)
    var_0 = right_0.to_lazy()
    assert  isinstance(var_0, Lazy)
    assert var_0() == 1
    left_0 = Left('')
    var_1 = left_0.to_lazy()
    assert  isinstance(var_1, Lazy)
    assert var_1() == ''

