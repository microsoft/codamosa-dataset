

# Generated at 2022-06-25 23:27:34.056302
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Right(bool_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0(bool_0)

    str_0 = "test"
    either_1 = Left(str_0)
    lazy_1 = either_1.to_lazy()
    assert lazy_1(str_0)


# Generated at 2022-06-25 23:27:36.350147
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert (Left(2).to_lazy().run() == 2)
    assert (Right(2).to_lazy().run() == 2)


# Generated at 2022-06-25 23:27:37.975079
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = True

    assert Either(bool_0).__eq__(Either(bool_0))


# Generated at 2022-06-25 23:27:41.348600
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = True
    either_0 = Either(bool_0)
    bool_1 = True
    either_1 = Either(bool_1)
    any_0 = either_0.__eq__(either_1)


# Generated at 2022-06-25 23:27:51.008522
# Unit test for method case of class Either
def test_Either_case():
    value_0 = 'a'
    either_0 = Either.Right(value_0)
    value_1 = 'a'
    either_1 = Either.Left(value_1)
    value_2 = 'a'
    either_2 = Either.Right(value_2)
    value_3 = 'a'
    either_3 = Either.Left(value_3)
    value_4 = 'a'
    either_4 = Either.Right(value_4)
    value_5 = 'a'
    either_5 = Either.Left(value_5)
    def func_0(arg_0):
        return arg_0
    def func_1(arg_0):
        return arg_0
    def func_2(arg_0):
        return arg_0

# Generated at 2022-06-25 23:27:56.868589
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = True
    bool_1 = False
    either_0 = Either(bool_1)
    assert either_0.__eq__(either_0) == True
    bool_2 = True
    either_1 = Either(bool_2)
    either_2 = Either(bool_2)
    either_2 = Either(bool_1)
    assert either_1.__eq__(either_2) == False
    assert either_2.__eq__(either_1) == False



# Generated at 2022-06-25 23:27:59.187591
# Unit test for method case of class Either
def test_Either_case():
    either_0 = Left(1)
    assert either_0 == either_0.case(lambda p_0: Left(p_0), lambda p_1: Right(p_1))



# Generated at 2022-06-25 23:28:03.835805
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    bool_0 = True
    either_0 = Either(bool_0)
    bool_1 = True
    either_1 = Either(bool_1)
    assert either_0.__eq__(either_1) is False


# Generated at 2022-06-25 23:28:09.122284
# Unit test for method case of class Either
def test_Either_case():
    left_0 = Left(20)
    left_1 = (lambda a: a + 100)(left_0.case(lambda a: 2, lambda a: a + 10))
    assert left_1 == 102

    right_0 = Right(20)
    right_1 = right_0.case(lambda a: 2, lambda a: a + 10)
    assert right_1 == 30



# Generated at 2022-06-25 23:28:18.210357
# Unit test for method case of class Either
def test_Either_case():
    test_case_0()
    from collections.abc import Callable
    from typing import Any

    def func_0(x: Any) -> Any:
        return x
    def func_1(x: Any) -> Any:
        return x
    def func_2(x: Any) -> Any:
        return x
    def func_3(x: Any) -> Any:
        return x
    right_0 = Right("")
    error_0 = right_0.case(func_0, func_1)
    right_1 = right_0.case(func_2, func_3)
    left_0 = Left("")
    val_0 = left_0.case(func_2, func_3)



# Generated at 2022-06-25 23:28:22.898182
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 0
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.map(lambda x: x)
    lazy_1.force()


# Generated at 2022-06-25 23:28:26.116810
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_value = Either(1)

    expected_value = Either(1)

    result = test_value.to_lazy()

    assert result.value() == expected_value.value


# Generated at 2022-06-25 23:28:30.463940
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = Either(True)
    lazy_0 = bool_0.to_lazy() # lazy_0 = Lazy(lambda: True)
    assert lazy_0.force() is True


# Generated at 2022-06-25 23:28:33.798658
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda x: x
    r = Either(f)
    res = r.to_lazy()
    assert isinstance(res, Lazy)
    assert res() == f


# Generated at 2022-06-25 23:28:38.472767
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Generates or load test data
    right_0 = Right(True)
    right_1 = Right(True)

    # Execute method under tested to obtain the result
    result_0 = right_0.to_lazy()
    result_1 = right_1.to_lazy()

    # Check assertion
    assert result_0 == result_1



# Generated at 2022-06-25 23:28:46.780377
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for class Either
    bool_0 = True
    either_0 = Either(bool_0)

    lazy_0 = either_0.to_lazy()
    lazy_0 = lazy_0.map(lambda x: x + 1)
    assert lazy_0.value() == 2

    bool_1 = True
    either_0 = Either(bool_1)

    lazy_0 = either_0.to_lazy()
    lazy_0 = lazy_0.filter(lambda x: x < 1)
    assert lazy_0.value() == True

    bool_3 = True
    either_0 = Either(bool_3)

    lazy_0 = either_0.to_lazy()
    value_0 = lazy_0.flat_map(lambda x: lazy_0.map(lambda x: x))

# Generated at 2022-06-25 23:28:50.218543
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.get_value() == bool_0


# Generated at 2022-06-25 23:28:53.394263
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    try:
        either_0.to_lazy()
    except AttributeError:
        pass



# Generated at 2022-06-25 23:28:59.711300
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either_0 = Left(['!string'])
    maybe_0 = Lazy(lambda: ['!string'])

    either_1 = Right('!string')
    maybe_1 = Lazy(lambda: '!string')

    assert either_0.to_lazy() == maybe_0
    assert either_1.to_lazy() == maybe_1


# Generated at 2022-06-25 23:29:04.117097
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Hello'
    either_0 = Either(str_0)

    lazy_0 = either_0.to_lazy()
    res_0 = lazy_0.value()

    assert str_0 == res_0
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:29:15.147949
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    either_0 = Either(bool_0)

    lazy_0 = Lazy(lambda: bool_0)
    lazy_1 = either_0.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:29:16.783719
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    passing = Either(lambda: 'passing')
    passing.to_lazy()


# Generated at 2022-06-25 23:29:24.345816
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def compare(int_0):
        return int_0 > 0
    def assert_equal(int_0, int_1):
        return int_0 == int_1
    def int_factory(int_0, int_1):
        return int_1
    def int_factory2(int_0):
        return int_0

    bool_0 = False
    either_0 = Either.from_value(bool_0)
    lazy_0 = either_0.to_lazy()

    assert_equal(lazy_0.is_forced(), False)

    bool_1 = lazy_0.get()

    assert_equal(lazy_0.is_forced(), True)

    int_0 = int_factory2(bool_1)

    assert_equal(compare(int_0), False)

   

# Generated at 2022-06-25 23:29:30.974434
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functors import Func

    from pymonet.functors import Func
    from pymonet.monad_try import Try

    result = Func(lambda i: Either(i)).to_lazy()(1)
    assert result == Func(Lazy(lambda i: Try(i))).to_lazy()(1)


# Generated at 2022-06-25 23:29:33.858628
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = Either.to_lazy
    bool_1 = Either(True)
    bool_2 = bool_1.to_lazy()
    bool_3 = bool_2.value()


# Generated at 2022-06-25 23:29:36.662866
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    number_0 = 1
    either_0 = Either(number_0)
    lazy_0 = either_0.to_lazy()
    assert None is not lazy_0.value
    assert number_0 == lazy_0.value()


# Generated at 2022-06-25 23:29:40.759584
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    either_0 = Either(bool_0)

    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.evaluate()


# Generated at 2022-06-25 23:29:49.405998
# Unit test for method to_lazy of class Either

# Generated at 2022-06-25 23:29:54.487898
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test of method to_lazy with value type float
    float_0 = float(0.0)
    either_0 = Either(float_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.__class__.__name__ == 'Lazy'
    assert lazy_0.get_value() == float_0
    # Test of method to_lazy with value type list
    list_0 = ['0']
    either_1 = Either(list_0)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.__class__.__name__ == 'Lazy'
    assert lazy_1.get_value() == list_0
    # Test of method to_lazy with value type set
    set_0 = set('0')
    either_2

# Generated at 2022-06-25 23:29:58.918019
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(1)
    right = Right(2)

    left_lazy = left.to_lazy()
    right_lazy = right.to_lazy()

    assert left_lazy.get() == 1
    assert right_lazy.get() == 2


# Generated at 2022-06-25 23:30:07.512966
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_str_0 = Left('str_0')
    lazy_str_0 = either_str_0.to_lazy()
    str_0 = lazy_str_0.value
    assert str_0 is either_str_0.value


# Generated at 2022-06-25 23:30:10.326874
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    either_1 = either_0.to_lazy()
    # test if both monad are equals
    assert either_0 == either_1


# Generated at 2022-06-25 23:30:15.932387
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.execute() is bool_0

    try_0 = Try(float("asdsad"))
    assert isinstance(try_0.to_lazy(), Lazy)
    assert try_0.to_lazy().execute() is None



# Generated at 2022-06-25 23:30:19.584699
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    take Either[A] and transform to Lazy[B]
    :return:
    """
    assert (
        Right(10).to_lazy() ==
        Lazy(lambda: 10))


# Generated at 2022-06-25 23:30:21.700696
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:30:31.792780
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.validation import Validation

    value = 1

    either_lazy = Either(value).to_lazy()
    assert either_lazy.value() == value

    either_box = Either(value).to_box()
    assert either_box.value == value

    either_try = Either(value).to_try()
    assert either_try.value == value
    assert either_try.is_success == value

    either_maybe = Either(value).to_maybe()
    assert either_maybe.value == value

    either_validation = Either(value).to_validation()

# Generated at 2022-06-25 23:30:37.271986
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right

    lazy_0 = Lazy(lambda: True)
    both_0 = Either(True)
    either_0 = Left(True)
    either_1 = Right(False)

    ret_0 = both_0.to_lazy()
    ret_1 = either_0.to_lazy()
    ret_2 = either_1.to_lazy()

    assert ret_0.value() == True
    assert ret_1.value() == True
    assert ret_2.value() == False


# Generated at 2022-06-25 23:30:42.044467
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_case_1():
        either_0 = Either(True)
        lazy_0 = either_0.to_lazy()
        bool_0 = lazy_0.value()
        unit_test.assert_true(bool_0)
    test_case_1()



# Generated at 2022-06-25 23:30:45.394009
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.__value__ == 1


# Generated at 2022-06-25 23:30:49.763854
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.map(lambda it_0: not it_0)
    bool_1 = lazy_1.get()
    assert not bool_0 == bool_1



# Generated at 2022-06-25 23:31:05.679887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    either_0 = Right("a")
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval() == "a"

    either_1 = Left(2)
    lazy_1 = either_1.to_lazy()
    assert lazy_1.eval() == 2


# Generated at 2022-06-25 23:31:09.135811
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    either_1 = either_0.to_lazy()
    assert either_1.value() == True


# Generated at 2022-06-25 23:31:14.148161
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    either_0 = Either(bool_0)

    lazy_1 = either_0.to_lazy()

    assert isinstance(lazy_1, Lazy)
    assert lazy_1.get() is bool_0


# Generated at 2022-06-25 23:31:17.469074
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = 'test'
    either_0 = Either(str_0)
    lazy_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:31:20.303701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_inner():
        bool_0 = True
        either_0 = Either(bool_0)

        either_0 = either_0.to_lazy()


# Generated at 2022-06-25 23:31:26.548016
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    try_0 = Try(10)
    either_0 = try_0.to_either()
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == 10
    lazy_1 = either_0.to_lazy()
    assert lazy_0 is lazy_1



# Generated at 2022-06-25 23:31:28.451323
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    either_0.to_lazy()



# Generated at 2022-06-25 23:31:30.859780
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right_0 = Right('test_Either_to_lazy_right_0')

    assert right_0.to_lazy().evaluate() == right_0.value


# Generated at 2022-06-25 23:31:35.285769
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.compute() is bool_0


# Generated at 2022-06-25 23:31:38.632909
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    if hasattr(Either, 'to_lazy') and callable(getattr(Either, 'to_lazy')):
        instance_0 = Left(bool)
        int_0 = instance_0.to_lazy()
        assert isinstance(int_0, Lazy)
        assert not isinstance(int_0, Right)
        assert not isinstance(int_0, Left)
        assert not isinstance(int_0, Either)
        assert not isinstance(int_0, Fn)
        str_0 = instance_0.to_lazy().get()
        assert isinstance(str_0, bool)



# Generated at 2022-06-25 23:31:58.587840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    int_0 = 10
    int_100 = 100

    #
    # Given
    #
    either_10 = Right(int_0)
    either_fail_10 = Left(int_0)
    #
    # When
    #
    result_10 = either_10.to_lazy()
    result_fail_10 = either_fail_10.to_lazy()
    lazy_10 = result_10.eval()
    lazy_fail_10 = result_fail_10.eval()
    #
    # Then
    #
    assert lazy_10 == int_0
    assert lazy_fail_10 == int_0

    #
    # Given
    #
    maybe

# Generated at 2022-06-25 23:32:02.436247
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    int_1 = 10
    value = Right(int_1)
    print(type(value))
    print(type(value.value))

    # Exercise operation
    result = value.to_lazy()

    # Verify outcome
    assert result.value() == int_1


# Generated at 2022-06-25 23:32:03.980694
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    success = Right(10)
    assert success.to_lazy().get() == 10



# Generated at 2022-06-25 23:32:08.008384
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left_0 = Left(10)
    from pymonet.lazy import Lazy

    result_0 = left_0.to_lazy()
    result_1 = Lazy(lambda: 10)

    assert result_0 == result_1
    assert isinstance(result_0, Lazy)

    from pymonet.lazy import Lazy

    right_0 = Right(Lazy(lambda: 10))
    Lazy_0 = Lazy(lambda: 10)

    result_0 = right_0.to_lazy()

    assert result_0 == Lazy_0


# Generated at 2022-06-25 23:32:16.644972
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest
    from pymonet.lazy import Lazy
    from pymonet.try_ import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.box import Box


# Generated at 2022-06-25 23:32:24.699002
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Case 0
    # Call to_lazy with Left
    # Expected result: Lazy[Function() -> 10]
    int_0 = 10
    either_0_0 = Left(int_0)
    either_0_1 = either_0_0.to_lazy()
    assert either_0_1.get() == int_0
    # Case 1
    # Call to_lazy with Right
    # Expected result: Lazy[Function() -> 10]
    either_1_0 = Right(int_0)
    either_1_1 = either_1_0.to_lazy()
    assert either_1_1.get() == int_0


# Generated at 2022-06-25 23:32:32.297466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test case: Either with integer value
    int_0 = 50
    assert type(Left(int_0).to_lazy()) == Lazy
    assert type(Right(int_0).to_lazy()) == Lazy
    # Test case: Either with string value
    string_0 = 'string_0'
    assert type(Left(string_0).to_lazy()) == Lazy
    assert type(Right(string_0).to_lazy()) == Lazy
    # Test case: Either with list value
    list_0 = [1, 2, 3]
    assert type(Left(list_0).to_lazy()) == Lazy
    assert type(Right(list_0).to_lazy()) == Lazy


# Generated at 2022-06-25 23:32:37.688652
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    int_0 = 10
    int_1 = 12

    either_int_0 = Right(int_0)
    either_int_1 = Left(int_1)

    lazy_int_0 = either_int_0.to_lazy()
    lazy_int_1 = either_int_1.to_lazy()

    assert lazy_int_0.get() == int_0
    assert lazy_int_1.get() == int_1


# Generated at 2022-06-25 23:32:41.937063
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange
    int_0: Either[int] = Right(10)

    # Act
    lazy_0 = int_0.to_lazy()

    # Assert
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == 10
    assert lazy_0.get() == 10


# Generated at 2022-06-25 23:32:45.760906
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    int_0 = 10

    either = Right(int_0)

    assert either.to_lazy().force() == int_0

    either = Left(int_0)

    assert either.to_lazy().force() == int_0


# Generated at 2022-06-25 23:32:58.757062
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0() == bool_0


# Generated at 2022-06-25 23:33:01.637587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """assert condition with asserts"""
    value = 'is lazy'
    either_0 = Either(value)
    lzy = either_0.to_lazy()
    assert lzy.value() == value
    assert lzy.is_strict() is False


# Generated at 2022-06-25 23:33:03.643131
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Either(Lazy(lambda: True)).to_lazy()


# Generated at 2022-06-25 23:33:05.354854
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 10
    either = Either(value)
    lazy = either.to_lazy()
    assert lazy.value() == value

# Generated at 2022-06-25 23:33:07.339521
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(1)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.evaluate() == 1



# Generated at 2022-06-25 23:33:10.798236
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    number = 42
    either_0 = Right(number)

    lazy_0: Lazy[int] = either_0.to_lazy()
    assert number == lazy_0.get()



# Generated at 2022-06-25 23:33:14.619354
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)

    lazy_0: Lazy = either_0.to_lazy()
    actual_0: bool = lazy_0.value()

    assert bool_0 == actual_0


# Generated at 2022-06-25 23:33:22.540203
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def function_0(param_0, param_1, param_2):
        return param_0 * param_1 * param_2

    int_0 = int(str_0, base=10)
    int_1 = int(str_1, base=10)
    int_2 = int(str_2, base=10)
    int_3 = int(str_3, base=10)
    int_4 = int(str_4, base=10)
    int_5 = int(str_5, base=10)
    int_6 = int(str_6, base=10)
    int_7 = int(str_7, base=10)
    int_8 = int(str_8, base=10)
    int_9 = int(str_9, base=10)
    either_0 = Either

# Generated at 2022-06-25 23:33:25.373488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    s = "unit test"
    either_1 = Either(s)
    lazy_0 = either_1.to_lazy()
    str_0 = lazy_0.value
    assert str_0 == s



# Generated at 2022-06-25 23:33:30.335232
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either_0 = Either(5)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 5

    either_1 = Either(5)
    lazy_1 = either_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == 5


# Generated at 2022-06-25 23:33:56.943613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)

    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.get()
    assert lazy_1 == bool_0


# Generated at 2022-06-25 23:34:02.652239
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    add1 = lambda x: x + 1
    from pymonet.lazy import Lazy
    from pymonet.future import Future
    from pymonet import Lazy, Future
    from pymonet.monad_future import Future

    assert Lazy(lambda: 'str') == Either('str').to_lazy()
    assert Future(lambda: 1) == Either(1).to_future()


# Generated at 2022-06-25 23:34:06.974846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either(46)
    lazy_0 = either_0.to_lazy()
    bool_0 = lazy_0.has_value
    bool_1 = lazy_0.is_forced
    int_0 = lazy_0.get_value
    assert bool_0
    assert not bool_1
    assert int_0 == 46

# Generated at 2022-06-25 23:34:08.750903
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Either(True).to_lazy()
    assert Lazy(lambda: True) == result


# Generated at 2022-06-25 23:34:17.873966
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    # Create Lazy container with True
    lazy_0 = Lazy(lambda: True)
    # Create Lazy container with Lazy container
    lazy_1 = Lazy(lambda: lazy_0)
    # Create  Box container with True
    box_0 = Box(True)
    # Create  Box container with Box container
    box_1 = Box(box_0)
    # Create  Maybe container with True
    maybe_0 = Maybe.just(True)
    # Create  Maybe container with Maybe container
    maybe_1 = Maybe.just(maybe_0)
    # Create  Try container with True

# Generated at 2022-06-25 23:34:26.204543
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value_0 = Right(3)
    assert value_0.to_lazy().value() == 3
    value_1 = Left(3)
    assert value_1.to_lazy().value() == 3
    value_2 = Right(3)
    assert value_2.to_lazy().value() == 3
    value_3 = Left(3)
    assert value_3.to_lazy().value() == 3
    value_4 = Right(None)
    assert value_4.to_lazy().value() is None
    value_5 = Left(None)
    assert value_5.to_lazy().value() is None
    value_6 = Right(3)
    assert value_6.to_lazy().value() == 3

# Generated at 2022-06-25 23:34:29.898594
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    maybe_0 = Either(None)
    maybe_1 = maybe_0.to_lazy()
    assert maybe_1 == Lazy(lambda: None)


# Generated at 2022-06-25 23:34:33.612391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_0 = Either('Either_0')
    either_0.to_lazy()


# Generated at 2022-06-25 23:34:38.044967
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    right_0 = Right(None)
    right_1 = right_0

    # Invocation
    lazy_0 = right_1.to_lazy()

    # Verification
    assert(isinstance(lazy_0, Lazy))



# Generated at 2022-06-25 23:34:39.570877
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Either(True) is Right
    assert Either(True).to_lazy().force() == True


# Generated at 2022-06-25 23:35:31.544099
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_0 = Lazy(lambda: int_0)

    # Test function containing call method
    def call_method_Maybe(foo: Lazy[int]) -> Lazy[int]:
        # Call to to_lazy method
        return foo.to_lazy()
    # Assert
    call_method_Maybe(lazy_0)


# Generated at 2022-06-25 23:35:34.213450
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.value() == True


# Generated at 2022-06-25 23:35:36.593067
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    str_0 = "Hi"
    either_0 = Either(str_0)
    lazy_0 = either_0.to_lazy()
    str_1 = lazy_0.force()
    assert str_1 == str_0


# Generated at 2022-06-25 23:35:44.250613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry
    from pymonet.monad_maybe import MonadMaybe
    from pymonet.monad_lazy import MonadLazy
    from pymonet.monad_validation import MonadValidation

    def check_class_methods(instance_of, functor_class, applicative_class, monad_class):
        assert isinstance(instance_of, functor_class)

# Generated at 2022-06-25 23:35:46.846544
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:35:48.978350
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    int_0 = 20
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
    result_0 = lazy_0.get()
    assert result_0 == int_0


# Generated at 2022-06-25 23:35:52.186554
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    bool_1 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    assert lazy_0.get() == bool_1


# Generated at 2022-06-25 23:35:55.178768
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    bool_0 = True
    either_0 = Either(bool_0)
    lazy_0 = either_0.to_lazy()
    lazy_1 = lazy_0.bind(lambda unit: lazy_0)


# Generated at 2022-06-25 23:36:02.676398
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    string_0 = 'string_0'
    bool_0 = True

    either_0 = Either(string_0)
    lazy_0 = Lazy(lambda: string_0)
    box_0 = Box(string_0)
    try_0 = Try(string_0, True)
    validation_0 = Validation.success(string_0)

    result_0 = either_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert lazy_0 == result_0,\
        '''either_0 should be lazy_0'''



# Generated at 2022-06-25 23:36:05.026587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Tests for either.

    :return:
    """
    int_0 = 0
    either_0 = Either(int_0)
    lazy_0 = either_0.to_lazy()
