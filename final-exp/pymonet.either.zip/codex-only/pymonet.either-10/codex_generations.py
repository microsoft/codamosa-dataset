

# Generated at 2022-06-23 23:53:50.860314
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(10).is_right()
    assert Left(10).is_right() is False


# Generated at 2022-06-23 23:53:59.373024
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    def result_function(number):
        if number == 0:
            raise Exception("Whoops, something happened")
        return number

    assert Right(0).to_try() == Try(0, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left("test").to_try() == Try("test", is_success=False)
    assert Right(0).to_try().case(success=lambda x: x / 0) == Try("Whoops, something happened", is_success=False)

# Generated at 2022-06-23 23:54:03.372554
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-23 23:54:07.801260
# Unit test for constructor of class Either
def test_Either():
    assert Left(1).value == 1
    assert Right(1).value == 1
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:54:17.216121
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Left

    assert Left(5).bind(maybe_mapper) == Left(5)
    assert Left(5).bind(try_mapper) == Left(5)
    assert Left(5).bind(lazy_mapper) == Left(5)
    assert Left(5).bind(box_mapper) == Left(5)
    assert Left(5).bind(validation_mapper) == Left(5)



# Generated at 2022-06-23 23:54:21.016032
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe().is_just() == True
    assert Right(1).to_maybe().is_nothing() == False
    assert Right(1).to_maybe().get() == 1


# Generated at 2022-06-23 23:54:25.335103
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:54:31.965428
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Either.Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:54:34.730145
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    left = Left(10)
    assert Maybe.nothing() == left.to_maybe()


# Generated at 2022-06-23 23:54:37.083064
# Unit test for method map of class Left
def test_Left_map():
    assert Left("x").map(id) == Left("x")


# Generated at 2022-06-23 23:54:40.348449
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Unit test for method to_validation of class Left
    """
    from pymonet.validation import Validation

    either = Left(0)
    assert either.to_validation() == Validation.fail([0])


# Generated at 2022-06-23 23:54:41.183161
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-23 23:54:48.179400
# Unit test for method bind of class Right
def test_Right_bind():
    """
    This is unit tests for method bind of class Right.

    """
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    def result(value) -> Try[int]:
        return Try(value * 3)

    right = Right(3)
    assert right.bind(result) == Try(9)
    right = Right(3).bind(lambda x: List.unit(x * 3))
    assert right == List(9)

# Generated at 2022-06-23 23:54:54.686725
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from keyword import iskeyword

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either("some_value").to_lazy() == Lazy(lambda: "some_value")
    assert Either(iskeyword).to_lazy() == Lazy(lambda: iskeyword)
    assert Left("some_value").to_lazy() == Lazy(lambda: "some_value")
    assert Right("some_value").to_lazy() == Lazy(lambda: "some_value")


# Generated at 2022-06-23 23:54:56.067327
# Unit test for method is_left of class Right
def test_Right_is_left():
    a = Either.right(1)
    assert a.is_left() is False



# Generated at 2022-06-23 23:54:57.277660
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:55:04.084205
# Unit test for method case of class Either
def test_Either_case():
    assert Left(10).case(lambda a: a + 5, lambda b: b + 5) == 15
    assert Right(5).case(lambda a: a + 5, lambda b: b + 5) == 10
    assert isinstance(Left(False).case(lambda a: a + 5, lambda b: b + 5), int)
    assert isinstance(Right(5).case(lambda a: a + 5, lambda b: b + 5), int)
    assert isinstance(Left(False).case(lambda a: a + "Eleven", lambda b: b + "Ten"), str)
    assert isinstance(Right(5).case(lambda a: a + "Eleven", lambda b: b + "Ten"), str)

    assert Left(2).case(lambda a: a + 5, lambda b: b + 5) == 7

# Generated at 2022-06-23 23:55:06.842586
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:55:10.156426
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)
    right = Right(1)

    assert left.to_validation() == Validation.fail([1])
    assert right.to_validation() == Validation.suc

# Generated at 2022-06-23 23:55:11.918814
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda a: a + 1) == Left(1)


# Generated at 2022-06-23 23:55:13.317194
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(2).is_left()


# Generated at 2022-06-23 23:55:20.016805
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == False
    assert Either(1).is_left() == False
    assert Right(1).is_right() == True
    assert Right(1).is_left() == False
    assert Left(1).is_right() == False
    assert Left(1).is_left() == True



# Generated at 2022-06-23 23:55:23.936342
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()



# Generated at 2022-06-23 23:55:27.795595
# Unit test for method case of class Either
def test_Either_case():
    assert Either(4).case(lambda l: l * l, lambda r: r * r) == \
        Left(4).case(lambda l: l * l, lambda r: r * r) == \
        Right(4).case(lambda l: l * l, lambda r: r * r) == 16


# Generated at 2022-06-23 23:55:29.305819
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(0).is_right()
    assert not Left(0).is_right()


# Generated at 2022-06-23 23:55:31.096388
# Unit test for method bind of class Left
def test_Left_bind():
    assert False == Left(RuntimeError("Failed")).bind(lambda x: False).is_right()


# Generated at 2022-06-23 23:55:32.695065
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(3).is_right() == False
    assert Right(3).is_right() == True



# Generated at 2022-06-23 23:55:36.953592
# Unit test for method map of class Right
def test_Right_map():
    # Given
    initial_value = 'a'
    mapper = lambda x: x.upper()
    expected = 'A'
    # When
    actual = Right(initial_value).map(mapper)
    # Then
    assert expected == actual.value


# Generated at 2022-06-23 23:55:38.575755
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x ** 2) == Right(4)



# Generated at 2022-06-23 23:55:40.168860
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() is False


# Generated at 2022-06-23 23:55:50.795075
# Unit test for method ap of class Either
def test_Either_ap():
    from unittest.mock import MagicMock
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def add3(x):
        return x + 3

    assert Left(2).ap(Left(4)) == Left(2)
    assert Right(2).ap(Right(add3)) == Right(5)
    assert Right(2).ap(Left(4)) == Left(4)
    assert Left(2).ap(Right(add3)) == Left(2)
    assert Right(2).ap(Box(add3)) == Right(5)
    assert Left(2).ap(Box(add3)) == Left(2)
    assert Right(2).ap(Lazy(lambda: add3)) == Right(5)
    assert Left(2).ap(Lazy(lambda: add3))

# Generated at 2022-06-23 23:55:57.411071
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(10).to_try() == Try.fail(10)
    assert Left('10').to_try() == Try.fail('10')
    assert Left(None).to_try() == Try.fail(None)
    assert Right(10).to_try() == Try.success(10)
    assert Right('10').to_try() == Try.success('10')
    assert Right(None).to_try() == Try.success(None)



# Generated at 2022-06-23 23:56:01.173287
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-23 23:56:12.217510
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    Right(Box(lambda x: x + 1)).ap(Right(5)) == Right(6)
    Right(Lazy(lambda x: x + 1)).ap(Right(5)) == Right(6)
    Right(Try(lambda x: x + 1)).ap(Right(5)) == Right(6)
    Right(Maybe(lambda x: x + 1)).ap(Right(5)) == Right(6)
    Right(Validation(lambda x: x + 1)).ap(Right(5)) == Right(6)


# Generated at 2022-06-23 23:56:15.085719
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.test_utils import assert_true, assert_false

    assert_true(Right(True).is_right())
    assert_false(Right(False).is_right())



# Generated at 2022-06-23 23:56:17.302296
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(3).to_try() == Try(3, is_success=True)
    assert Left("error").to_try() == Try("error", is_success=False)


# Generated at 2022-06-23 23:56:20.605325
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda _: 0, lambda x: x) == 1
    assert Left(1).case(lambda x: x, lambda _: 0) == 1


# Generated at 2022-06-23 23:56:21.775482
# Unit test for constructor of class Left
def test_Left():
    assert isinstance(Left(1), Left)



# Generated at 2022-06-23 23:56:25.529966
# Unit test for constructor of class Either
def test_Either():
    assert Left("test") == Left("test")
    assert Right("test") == Right("test")
    assert Left("test") != Right("test")
    assert Left("test") != "test"


# Generated at 2022-06-23 23:56:26.773744
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-23 23:56:28.533390
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(42).to_validation() == Validation.fail([42])


# Generated at 2022-06-23 23:56:30.786768
# Unit test for method map of class Left
def test_Left_map():
    test_value = 3
    value_to_map = 2
    result = Left(test_value).map(lambda val: val + value_to_map)
    assert isinstance(result, Left)
    assert result.value == test_value


# Generated at 2022-06-23 23:56:32.978963
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-23 23:56:36.213535
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) == Left([1])
    assert Left(1) != Left([2])
    assert Left('string') == Left('string')



# Generated at 2022-06-23 23:56:40.310994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Left(1)) == Left(1).to_lazy()
    assert Either.to_lazy(Right(1)) == Right(1).to_lazy()



# Generated at 2022-06-23 23:56:42.023567
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe().is_nothing()



# Generated at 2022-06-23 23:56:49.879341
# Unit test for method bind of class Right
def test_Right_bind():
    r = Right(1)

    f = lambda x: Right(x + 1)
    g = lambda err: Right(err)

    bound = r.case(g, f)
    assert isinstance(bound, Right)
    assert bound.value == 2

    mapper = lambda x: Left(x + 2)
    bound = r.case(g, mapper)
    assert isinstance(bound, Left)
    assert bound.value == 3



# Generated at 2022-06-23 23:56:53.121219
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)



# Generated at 2022-06-23 23:56:55.870768
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(2).to_validation().is_success()
    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:56:56.986761
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(10)
    assert right.to_validation() == Validation.success(10)

# Generated at 2022-06-23 23:57:01.393480
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    left = Left(1)
    expected = Validation.fail([1])
    actual = left.to_validation()
    assert actual == expected



# Generated at 2022-06-23 23:57:03.032848
# Unit test for method is_right of class Left
def test_Left_is_right():
    expected = False
    actual = Left(1).is_right()
    assert actual == expected



# Generated at 2022-06-23 23:57:04.638142
# Unit test for constructor of class Either
def test_Either():
    assert not callable(Either)
    assert callable(Left)
    assert callable(Right)



# Generated at 2022-06-23 23:57:06.146330
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:57:11.129654
# Unit test for method ap of class Left
def test_Left_ap():
    """Unit test for method ap of class Left"""

    def success(value: int) -> Either[int]:
        return Right(value)

    assert Left(1).ap(success(10)) == Left(1)



# Generated at 2022-06-23 23:57:12.630348
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:57:22.273144
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def test_equal_Left_Left():
        assert Left(12) == Left(12)

    def test_equal_Right_Right():
        assert Right(12) == Right(12)

    def test_not_equal_Right_Left():
        assert not Right(12) == Left(12)

    def test_not_equal_Left_Right():
        assert not Left(12) == Right(12)

    def test_not_equal_Right_Right():
        assert not Right(12) == Right(13)

    def test_not_equal_Left_Left():
        assert not Left(12) == Left(13)

    test_equal_Left_Left()
    test_equal_Right_Right()
    test_not_equal_Left_Left()
    test_not_equal_Right_Right()
    test_not_

# Generated at 2022-06-23 23:57:25.323713
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(2).to_try() == Try(2, is_success=True)
    assert Left(2).to_try() == Try(2, is_success=False)


# Generated at 2022-06-23 23:57:25.905362
# Unit test for constructor of class Either
def test_Either():
    assert Either(None) is not None

# Generated at 2022-06-23 23:57:27.690167
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 4)) == Right(5)



# Generated at 2022-06-23 23:57:29.563881
# Unit test for method is_left of class Left
def test_Left_is_left():
    # given
    value = 'value'
    left = Left(value)
    # then
    assert left.is_left()


# Generated at 2022-06-23 23:57:32.592730
# Unit test for method case of class Either
def test_Either_case():
    """
    Test case method`
    """
    assert Right(1).case(
        success=lambda v: str(v),
        error=lambda v: None
    ) == '1'
    assert Left(1).case(
        success=lambda v: str(v),
        error=lambda v: None
    ) is None

# Generated at 2022-06-23 23:57:36.440200
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation([1])


# Generated at 2022-06-23 23:57:44.867011
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.either import Either
    from pymonet.either import Left
    from pymonet.either import Right

    assert Either(4).case(
        error=lambda x: True,
        success=lambda x: False) == False

    assert Either('string').case(
        error=lambda x: x.upper(),
        success=lambda x: x.lower()) == 'string'

    assert Left('error').case(
        error=lambda x: x.upper(),
        success=lambda x: x.lower()) == 'ERROR'

    assert Right('success').case(
        error=lambda x: x.upper(),
        success=lambda x: x.lower()) == 'success'



# Generated at 2022-06-23 23:57:48.215969
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(1)
    result = left.to_validation()

    assert result == Validation.fail([1])



# Generated at 2022-06-23 23:57:51.754268
# Unit test for method is_left of class Right
def test_Right_is_left():
    right_value = Right(5)
    assert right_value.is_left() is False



# Generated at 2022-06-23 23:57:56.672675
# Unit test for method ap of class Either
def test_Either_ap():
    class Applicative():
        def __init__(self, value: str):
            self.value = value

        def map(self, mapper: Callable[[str], str]) -> str:
            return mapper(self.value)

    assert Either.ap(Right(2), Applicative('abs')) == 'bbs'
    assert Either.ap(Left(2), Applicative('abs')) == 2


# Generated at 2022-06-23 23:57:59.050325
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x * 2) == Right(2)



# Generated at 2022-06-23 23:58:00.678843
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('test').is_right() == False, 'Should be false'


# Generated at 2022-06-23 23:58:02.524142
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(8).bind(lambda x: Right(x)) == Left(8)


# Generated at 2022-06-23 23:58:04.030883
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()
    assert not Left(None).is_right()



# Generated at 2022-06-23 23:58:09.803465
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left.ap(Left(1), Left(1)) == Left(1)
    assert Left.ap(Left(2), Left('a')) == Left(2)
    assert Right.ap(Right(1), Right(1)) == Right(1)
    assert Right.ap(Right('a'), Right('a')) == Right('a')
    assert Right.ap(Right('b'), Right('a')) == Right('b')
    assert Right.ap(Right(None), Right('a')) == Right(None)
    assert Right.ap(Right([]), Right('a')) == Right([])
    assert Right.ap(Right({}), Right('a')) == Right({})
    assert Right.ap(Right(1), Right(1)) == Right(1)



# Generated at 2022-06-23 23:58:13.651265
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:58:17.614332
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Left("Error").to_maybe() == Maybe.nothing(),\
        f"Left: Value of instance of Either is {Left('Error').value}, "\
        f"expected either True or False."


# Generated at 2022-06-23 23:58:22.416931
# Unit test for method is_right of class Left
def test_Left_is_right():
    # GIVEN: left either
    left = Left(5)

    # WHEN: We check if left is right
    result = left.is_right()

    # THEN: False is returned
    assert not result


# Generated at 2022-06-23 23:58:33.683374
# Unit test for method ap of class Either
def test_Either_ap():
    def add_two(n):
        return n + 2

    assert Right(add_two).ap(Either.right(2)) == Either.right(4)
    assert Right(add_two).ap(Either.left(Exception('Wrong value type'))) == Either.left(Exception())
    assert Right(add_two).ap(Either.left('Wrong value type')) == Either.left('Wrong value type')
    assert Left('Wrong value type').ap(Either.right(2)) == Either.left('Wrong value type')
    assert Left('Wrong value type').ap(Either.left(Exception('Wrong value type'))) == Either.left('Wrong value type')
    assert Left('Wrong value type').ap(Either.left('Wrong value type')) == Either.left('Wrong value type')


# Generated at 2022-06-23 23:58:35.495187
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(1)
    assert maybe == left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:58:36.675490
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(5).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:58:38.896118
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Right(10).to_maybe(), Maybe)
    assert Right(10).to_maybe().value == 10


# Generated at 2022-06-23 23:58:45.098985
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert(Either(2).to_box() == Either(2).to_box())
    assert(Either(2).to_box() != Either(3).to_box())


# Generated at 2022-06-23 23:58:46.961247
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x+1) == Left(1)


# Generated at 2022-06-23 23:58:52.929335
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Nothing

    monad = Left('value')
    assert monad.to_maybe() == Nothing()



# Generated at 2022-06-23 23:58:54.100549
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-23 23:58:56.778678
# Unit test for method case of class Either
def test_Either_case():
    assert Either.case(Left(1), lambda x: x+1, lambda x: x*3) == 2
    assert Either.case(Right(1), lambda x: x+1, lambda x: x*3) == 3


# Generated at 2022-06-23 23:59:01.204690
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from pymonet.validation import Validation

    class TestRightToValidation(unittest.TestCase):
        def test(self):
            val = Right(5).to_validation()
            self.assertEqual(Validation.success(5), val)

    unittest.main()


# Generated at 2022-06-23 23:59:05.363875
# Unit test for constructor of class Right
def test_Right():
    assert Right(4) == Right(4)


# Generated at 2022-06-23 23:59:07.245554
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-23 23:59:10.919134
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    box = Box(99)
    assert Right(42).to_box() == Box(42)
    assert Right(42).to_box() != box
    assert Left(42).to_box() == Box(42)
    assert Left(42).to_box() != box


# Generated at 2022-06-23 23:59:17.745831
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda _: None) == 2
    assert Left(1).case(lambda _: None, lambda _: 1) is None
    assert Right(1).case(lambda _: None, lambda x: x + 1) == 2
    assert Right(1).case(lambda _: None, lambda _: 1) == 1


# Generated at 2022-06-23 23:59:30.004028
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad import Monad

    def test_case_with_Left():
        @Monad.case
        def error_handler(value):
            # type: (int) -> float
            return float(value)
        @Monad.case
        def success_handler(value):
            # type: (int) -> float
            return float(value) + 1
        assert Left(1).case(error_handler, success_handler) == 1.0
    def test_case_with_Right():
        @Monad.case
        def error_handler(value):
            # type: (int) -> float
            return float(value)
        @Monad.case
        def success_handler(value):
            # type: (int) -> float
            return float(value) + 1

# Generated at 2022-06-23 23:59:32.559515
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x**2)) == Left(2)
    assert Left(2).bind(lambda x: Left(x**2)) == Left(2)



# Generated at 2022-06-23 23:59:36.818114
# Unit test for method __eq__ of class Either
def test_Either___eq__():  # ignore:C901
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)


# Generated at 2022-06-23 23:59:39.880259
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)


# Generated at 2022-06-23 23:59:41.232420
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:59:43.675929
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right() == True


# Generated at 2022-06-23 23:59:45.919066
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(2)
    assert right.to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:59:50.304439
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:59:53.459508
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    assert Right(1).to_try() == Success(1)
    assert Left(1).to_try() == Failure(1)


# Generated at 2022-06-23 23:59:56.848809
# Unit test for method to_try of class Either
def test_Either_to_try():

    assert Either(None).to_try() == None
    assert Either(42).to_try() == 42

# Generated at 2022-06-23 23:59:58.059903
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-24 00:00:01.002870
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1)


# Generated at 2022-06-24 00:00:02.193929
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('error').to_maybe().is_nothing()



# Generated at 2022-06-24 00:00:04.937415
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(10).is_right() is False
    assert Either(10).is_left() is True

    assert Left(10).is_right() is False
    assert Left(10).is_left() is True

    assert Right(10).is_right() is True
    assert Right(10).is_left() is False



# Generated at 2022-06-24 00:00:05.835782
# Unit test for constructor of class Left
def test_Left():
    a = Left(3)

    assert a.value == 3


# Generated at 2022-06-24 00:00:10.921795
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Test Left to_validation method
    """
    from pymonet.validation import Validation
    assert str(Left(1).to_validation()) == str(Validation.fail([1]))



# Generated at 2022-06-24 00:00:12.177504
# Unit test for method is_left of class Right
def test_Right_is_left():
    r: Right[int] = Right(2)
    assert r.is_left() == False



# Generated at 2022-06-24 00:00:14.108418
# Unit test for constructor of class Left
def test_Left():
    actual = Left(0)
    expected = Left(0)
    assert actual == expected


# Generated at 2022-06-24 00:00:18.496295
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    x = Left("error")
    assert x.to_validation() == Validation.fail(['error'])

# Generated at 2022-06-24 00:00:20.271572
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_try import Try

    assert isinstance(Left(1).bind(lambda _: Try(1)), Left)



# Generated at 2022-06-24 00:00:24.657697
# Unit test for constructor of class Right
def test_Right():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert isinstance(Either.pure(5), Right)
    assert isinstance(Either.pure(5).to_maybe(), Maybe)
    assert isinstance(Either.pure(5).to_validation(), Validation)
    assert isinstance(Either.pure(5).to_try(), Try)



# Generated at 2022-06-24 00:00:25.705894
# Unit test for method map of class Left
def test_Left_map():
    left = Left(None)

    def mapper(value):
        return 2

    assert left.map(mapper) == Left(None)

# Generated at 2022-06-24 00:00:29.180619
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Bind method of Right instance with error and success functions.

    """
    right = Right(10)
    value = right\
        .bind(lambda i: Right(i + 10))\
        .bind(lambda i: Right(i + 20))\
        .bind(lambda _: Left(1))\
        .bind(lambda i: Right(i + 30))\
        .bind(lambda i: Left(i + 10))\
        .value
    assert value == 1



# Generated at 2022-06-24 00:00:34.571978
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.maybe import Maybe

    result = Left(1).map(lambda x: x + 1)

    assert isinstance(result, Left)
    assert result.value == 1

    result = Left(1).map(Maybe.just)
    assert isinstance(result, Left)
    assert result.value == 1



# Generated at 2022-06-24 00:00:37.233783
# Unit test for constructor of class Either
def test_Either():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)



# Generated at 2022-06-24 00:00:38.555402
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:00:41.029383
# Unit test for method is_right of class Either
def test_Either_is_right():
    right = Right(10)
    assert right.is_right()

    left = Left(10)
    assert not left.is_right()



# Generated at 2022-06-24 00:00:43.579961
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    left = Left(None)
    assert left.ap(Box(lambda x: x)) == left



# Generated at 2022-06-24 00:00:46.511577
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-24 00:00:47.817793
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:00:54.026028
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.box import Box

    assert Left(1).map(lambda x: 2*x) == Left(1)
    assert Left(1).map(lambda x: Box(2*x)) == Left(1)
    assert Left(1).map(lambda x: [2*x]) == Left(1)


# Generated at 2022-06-24 00:00:56.028751
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).map(lambda x: x) == Left(1)


# Generated at 2022-06-24 00:00:57.908569
# Unit test for method map of class Left
def test_Left_map():
    error = "error"
    either = Left(error)
    new_either = either.map(lambda _: "success")
    assert new_either == Left(error)


# Generated at 2022-06-24 00:00:59.537113
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right() == True


# Generated at 2022-06-24 00:01:02.834467
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(Left('error')).to_try() == Try('error', False)
    assert Either(Right('OK')).to_try() == Try('OK', True)


# Generated at 2022-06-24 00:01:04.628510
# Unit test for method map of class Right
def test_Right_map():
    assert Right(0).map(lambda x: x + 1) == Right(1)



# Generated at 2022-06-24 00:01:10.432369
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> Right(lambda x: x + 1).ap(Right(1))
    Right(2)
    >>> Right(lambda x: x + 1).ap(Left("Error"))
    Left("Error")
    >>> Left("Error").ap(Right(1))
    Left("Error")
    >>> Left("Error").ap(Left("Error 2"))
    Left("Error")
    """
    pass

# Generated at 2022-06-24 00:01:11.731588
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-24 00:01:13.216821
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(1).is_right()
    assert Right(1).is_right()


# Generated at 2022-06-24 00:01:18.094117
# Unit test for method ap of class Either
def test_Either_ap():
    succ = Right(lambda x: x + 1)
    fail = Left('some error')
    assert succ.ap(Right(1)) == Right(2)
    assert fail.ap(Right(1)) == Left('some error')
    assert succ.ap(fail) == Left('some error')

# Generated at 2022-06-24 00:01:19.155708
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(2).is_left() is False



# Generated at 2022-06-24 00:01:26.420262
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation


# Generated at 2022-06-24 00:01:31.243776
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(10).to_try() == Try(10)
    assert Left(10).to_try() == Try(10, False)


# Generated at 2022-06-24 00:01:35.448970
# Unit test for method bind of class Left
def test_Left_bind():
    # Create new instance of Left monad with value
    left = Left(10)

    # Create dummy mapper function
    def mapper(x):
        return x + 1

    assert left.bind(mapper) == left


# Generated at 2022-06-24 00:01:39.350068
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyMonad
    from pymonet.monad_maybe import Maybe

    assert Either(Maybe.nothing()).to_lazy() == Lazy(None)
    assert Either(Maybe.just(42)).to_lazy() == Lazy(42)



# Generated at 2022-06-24 00:01:41.113135
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().get() == 2
    assert Left(2).to_lazy().get() == 2


# Generated at 2022-06-24 00:01:45.575821
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Right(1)) == Either.to_try(Right('2'))
    assert not Either.to_try(Right(1)) == Either.to_try(Left(2))
    assert not Either.to_try(Left(1)) == Either.to_try(Right('2'))
    assert Either.to_try(Left(1)) == Either.to_try(Left(2))


# Generated at 2022-06-24 00:01:51.267733
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Either.to_lazy(Right(10)), Lazy)
    assert isinstance(Either.to_lazy(Left(10)), Lazy)
    assert Either.to_lazy(Right(10)).is_resolved is True
    assert Either.to_lazy(Left(10)).is_resolved is True


# Generated at 2022-06-24 00:01:53.175272
# Unit test for method is_left of class Right
def test_Right_is_left():
    value = "test"
    either = Right(value)
    assert not either.is_left()


# Generated at 2022-06-24 00:01:54.529096
# Unit test for constructor of class Right
def test_Right():
    r = Right(1)
    assert r == Right(1)


# Generated at 2022-06-24 00:01:56.583681
# Unit test for constructor of class Left
def test_Left():
    left = Left(12)
    assert left.value == 12


# Generated at 2022-06-24 00:01:58.486955
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:02:02.810408
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right("something") == Right("something")
    assert Left("something") == Left("something")
    assert not Left("something") == Right("something")
    assert not Left("something1") == Left("something2")
    assert not Right("something1") == Right("something2")



# Generated at 2022-06-24 00:02:04.479428
# Unit test for method map of class Right
def test_Right_map():
    """
    Tests map method of class Right.
    """
    right = Right(1)
    assert right.map(lambda x: str(x)) == Right('1')


# Unit tests for method case of class Either

# Generated at 2022-06-24 00:02:06.089557
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:02:07.192695
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() == False
test_Left_is_right()


# Generated at 2022-06-24 00:02:12.046254
# Unit test for method case of class Either
def test_Either_case():
    """Test for method case of class Either"""
    assert Right(1).case(lambda error: 0, lambda success: success) == 1
    assert Left(1).case(lambda error: 0, lambda success: success) == 0


# Generated at 2022-06-24 00:02:13.330482
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(10).bind(lambda x: Right(x)) == Left(10)



# Generated at 2022-06-24 00:02:14.893573
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:02:18.018775
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """Test behaviour of to_maybe method on Left class."""
    val = 'hello'
    e = Left(val)
    assert e.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:02:19.571971
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1)



# Generated at 2022-06-24 00:02:21.052958
# Unit test for constructor of class Right
def test_Right():
    right = Right(True)
    assert right.value == True


# Generated at 2022-06-24 00:02:23.483972
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    import pytest

    from pymonet.maybe import Maybe

    assert (Maybe.just(42).equals(Right(42).to_maybe()))



# Generated at 2022-06-24 00:02:24.752120
# Unit test for constructor of class Either
def test_Either():
    # Ensure that Left keep value
    assert Either(1) == Either(1)
    # Ensure that Right keep value
    assert Either(1) == Either(1)


# Generated at 2022-06-24 00:02:25.810737
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)



# Generated at 2022-06-24 00:02:27.603468
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("1").is_right() is True
    assert Right(1).is_right() is True
    assert Right(True).is_right() is True



# Generated at 2022-06-24 00:02:30.551786
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(2).to_box() == Box(2)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-24 00:02:32.299631
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-24 00:02:39.968010
# Unit test for method ap of class Either
def test_Either_ap():
    # Arrange
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def plus1(x: int) -> int:
        return x + 1

    def plus2(x: int) -> int:
        return x + 2

    def plus3(x: int) -> int:
        return x + 3

    either = Right(plus1)
    lazy_right = Lazy(lambda: Right(plus2))
    lazy_left = Lazy(lambda: Left(plus3))
    validation_left = Validation.fail(4)
    try_left = Try(4, is_success=False)

    # Act
    result0 = either.ap(Right(1))
    result1 = either.ap(lazy_right)

# Generated at 2022-06-24 00:02:42.682472
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(8).to_box() == Box(8)
    assert Right(8).to_box() == Box(8)



# Generated at 2022-06-24 00:02:44.936943
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:02:46.464489
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).case(
        error=lambda x: x,
        success=lambda x: x) == 1



# Generated at 2022-06-24 00:02:48.226099
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) == 1
    assert Right(1) != "1"



# Generated at 2022-06-24 00:02:53.160044
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Test for method to_box of class Either"""
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert(Left('Error').to_box() == Box('Error'))
    assert(Right('Value').to_box() == Box('Value'))



# Generated at 2022-06-24 00:02:57.628455
# Unit test for constructor of class Right
def test_Right():
    assert Right(5).map(lambda x: x * 2).bind(lambda x: x / 2) == 5
    assert Right(5).to_maybe().bind(lambda x: x / 2) == 2.5



# Generated at 2022-06-24 00:02:59.561269
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False



# Generated at 2022-06-24 00:03:00.795982
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-24 00:03:02.827692
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Either(1).is_right()
    assert Either(1).is_left()



# Generated at 2022-06-24 00:03:03.896824
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:03:07.361787
# Unit test for method case of class Either
def test_Either_case():
    assert Right(2).case(lambda a: a, lambda a: 2 * a) == 4
    assert Left(2).case(lambda a: a, lambda a: 2 * a) == 2



# Generated at 2022-06-24 00:03:09.141850
# Unit test for constructor of class Right
def test_Right():
    result = Right(1).value
    expected = 1
    assert(result == expected)


# Generated at 2022-06-24 00:03:11.547357
# Unit test for constructor of class Left
def test_Left():
    l = Left(1)
    assert l.value == 1
    assert l.is_left()
    assert not l.is_right()


# Generated at 2022-06-24 00:03:17.972490
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True
    assert Left("abc").is_left() is True
    assert Left([1, 2, 3]).is_left() is True
    assert Left({'a': 1, 'b': 2}).is_left() is True
    assert Left("abc").is_left() is True
    assert Left(1).is_right() is False
    assert Left("abc").is_right() is False
    assert Left([1, 2, 3]).is_right() is False
    assert Left({'a': 1, 'b': 2}).is_right() is False
    assert Left("abc").is_right() is False


# Generated at 2022-06-24 00:03:19.964526
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:21.269523
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-24 00:03:23.041640
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-24 00:03:26.450114
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-24 00:03:27.849959
# Unit test for constructor of class Either
def test_Either():
    assert Either('qwerty').value == 'qwerty'


# Generated at 2022-06-24 00:03:28.943591
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(10)

    assert right.to_maybe() == (10, True)


# Generated at 2022-06-24 00:03:31.111332
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)


# Generated at 2022-06-24 00:03:33.500516
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-24 00:03:37.810619
# Unit test for constructor of class Left
def test_Left():
    assert Left(True) is Left(True)
    assert Left(False) == Left(False)
    assert Left(None) != Left(True)
    assert Left(None) != Left(False)
    assert Left(None) != Right('something')


# Generated at 2022-06-24 00:03:38.993865
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, True)
    assert Left(1).to_try() == Try(1, False)

# Generated at 2022-06-24 00:03:42.276845
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    # Given
    left = Left('error')
    # When
    validation = left.to_validation()
    # Then
    assert validation == Validation.fail(['error'])



# Generated at 2022-06-24 00:03:45.172927
# Unit test for method to_box of class Either
def test_Either_to_box():
    box = either_int_5.to_box()

    assert box.value == 5
    assert isinstance(box, Either)
    assert isinstance(box, Right)
    assert not isinstance(box, Left)


# Generated at 2022-06-24 00:03:50.326752
# Unit test for method map of class Left
def test_Left_map():
    left = Left(0)
    assert isinstance(left.map(lambda x: x + 1), Left)
    assert left.map(lambda x: x + 1) == Left(0)

