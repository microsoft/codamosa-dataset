

# Generated at 2022-06-23 23:53:52.642810
# Unit test for method map of class Left
def test_Left_map():
    assert Left(None).map(lambda x: x) == Left(None)


# Unit tests for method bind of class Left

# Generated at 2022-06-23 23:53:53.879430
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(4).to_box() == Box(4)
    assert Left(4).to_box() == Box(4)



# Generated at 2022-06-23 23:53:57.288993
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(0) == Left(0)
    assert Left(0) != Left(1)
    assert Right(0) == Right(0)
    assert Right(0) != Right(1)
    assert Right(0) != Left(0)



# Generated at 2022-06-23 23:54:03.654242
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def square(x):
        return x ** 2

    def double(x):
        return x * 2

    assert Right(square).ap(Left(6)) == Left(6)
    assert Right(square).ap(Right(6)) == Right(36)
    assert (Right(square).ap(Box(6)) == Right(36)).unbox()
    assert Right(square).ap(Lazy(lambda: 6)).get() == 36

    assert Right(double).ap(Left(6)) == Left(6)
    assert Right(double).ap(Right(6)) == Right(12)
    assert (Right(double).ap(Box(6)) == Right(12)).unbox()

# Generated at 2022-06-23 23:54:08.075800
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(True) == Left(True)
    assert Left(False) == Left(False)
    assert Right(True) == Right(True)
    assert Left(False) != Right(True)


# Generated at 2022-06-23 23:54:10.735685
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    expected_result = True
    # When 
    result = (Left(True) == Left(True))
    # Then
    assert expected_result == result, "Should be equal"


# Generated at 2022-06-23 23:54:12.198676
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(5).ap(5) == Left(5)



# Generated at 2022-06-23 23:54:14.644679
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(10).is_left(), (
        'Should be True')


# Generated at 2022-06-23 23:54:17.966930
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)



# Generated at 2022-06-23 23:54:22.042139
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(None).to_validation() == Validation.success(None),\
        'Should return successful validation monad'
    assert Right(1).to_validation() == Validation.success(1),\
        'Should return successful validation monad with previous value'



# Generated at 2022-06-23 23:54:24.539039
# Unit test for method case of class Either
def test_Either_case():
    assert isinstance(Right(10).case(lambda x: x/0, lambda x: 2 * x), int)
    assert isinstance(Left(10).case(lambda x: x/0, lambda x: 2 * x), int)



# Generated at 2022-06-23 23:54:31.692530
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')

    assert left.is_left() is True



# Generated at 2022-06-23 23:54:34.343562
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(5).to_box() == Box(5)
    assert Right(5).to_box() == Box(5)


# Generated at 2022-06-23 23:54:40.178225
# Unit test for method case of class Either
def test_Either_case():
    # Given
    left = Left('123')
    right = Right('123')

    # When
    errored = left.case(lambda x: 'error', lambda x: 'success')
    successed = right.case(lambda x: 'error', lambda x: 'success')

    # Then
    assert errored == 'error'
    assert successed == 'success'



# Generated at 2022-06-23 23:54:41.335044
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:54:47.032930
# Unit test for method bind of class Right
def test_Right_bind():
    @add_in_left_and
    def add_one(x: int) -> Either[int]:
        return Right(x + 1)

    x = Right(3)
    y = x.bind(add_one).bind(add_one)
    assert y.value == 5


# Generated at 2022-06-23 23:54:48.815680
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    assert right.map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:54:50.737465
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == Validation.fail(['error'])



# Generated at 2022-06-23 23:54:56.777321
# Unit test for method map of class Right
def test_Right_map():
    # Given
    right = Right(2)
    mapper = lambda x: x + 1

    # When
    right = right.map(mapper)

    # Then
    assert right == Right(3)



# Generated at 2022-06-23 23:54:58.056095
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Right(1).to_maybe(), Maybe)
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:55:03.489059
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-23 23:55:04.733910
# Unit test for constructor of class Left
def test_Left():
    left = Left('error')
    assert left.value == 'error'


# Generated at 2022-06-23 23:55:07.541736
# Unit test for constructor of class Left
def test_Left():
    assert Left(3) == Left(3)


# Generated at 2022-06-23 23:55:09.177393
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right()


# Generated at 2022-06-23 23:55:11.327953
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.just(2) == Right(2).to_maybe()


# Generated at 2022-06-23 23:55:15.538280
# Unit test for method ap of class Either
def test_Either_ap():
    def double(x):
        return x * x

    assert Right(double).ap(Right(5)) == Right(25)
    assert Right(double).ap(Left("Left")) == Left("Left")
    assert Left("Left").ap(Left("Left")) == Left("Left")
    assert Left("Left").ap(Right(5)) == Left("Left")

# Generated at 2022-06-23 23:55:16.758397
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(1)) == Left(1)

# Generated at 2022-06-23 23:55:24.987319
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    value = Box(1)
    assert Either(value).to_lazy() == Lazy(lambda: value)
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either("Hello").to_lazy() == Lazy(lambda: "Hello")
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(True).to_lazy() == Lazy(lambda: True)
    assert Either(False).to_lazy() == Lazy(lambda: False)
    assert Either(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-23 23:55:29.005323
# Unit test for method case of class Either
def test_Either_case():
    def error(value):
        return "Error " + str(value)

    def success(value):
        return "Success " + str(value)

    # Test for class Left
    left = Left('Left')
    assert left.case(error, success) == 'Error Left'

    # Test for class Right
    right = Right('Right')
    assert right.case(error, success) == 'Success Right'

# Generated at 2022-06-23 23:55:30.845875
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: x + 2) == Left(1)



# Generated at 2022-06-23 23:55:32.504081
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left("error").ap(Right("value")) == Left("error")

# Generated at 2022-06-23 23:55:36.406822
# Unit test for method map of class Right
def test_Right_map():
    assert Right(5).map(lambda num: num + 10) == Right(15)


# Generated at 2022-06-23 23:55:39.119278
# Unit test for method bind of class Left
def test_Left_bind():
    # given
    val = Left(None)

    # when
    result = val.bind(lambda x: Right(x))

    # then
    assert result == Left(None)



# Generated at 2022-06-23 23:55:44.629519
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    right = Right("success")
    assert right.to_try() == Try("success")

    left = Left("failed")
    assert left.to_try() == Try(exception="failed", is_success=False)



# Generated at 2022-06-23 23:55:47.185869
# Unit test for method map of class Left
def test_Left_map():
    # Given
    left = Left(3)

    # When
    result = left.map(lambda x: 2 * x)

    # Then
    assert left == result



# Generated at 2022-06-23 23:55:49.797098
# Unit test for constructor of class Left
def test_Left():
    left = Left('test')
    assert left.is_left() is True
    assert left.is_right() is False
    assert left.value == 'test'



# Generated at 2022-06-23 23:55:50.777534
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3


# Generated at 2022-06-23 23:55:56.512691
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    right = Right(2)
    left_func = Left(lambda x: x * 2)
    right_func = Right(lambda x: x * 2)
    assert left.ap(left_func) == left
    assert left.ap(right_func) == left
    assert right.ap(left_func) == left
    assert right.ap(right_func) == Right(4)


# Generated at 2022-06-23 23:55:57.558938
# Unit test for constructor of class Left
def test_Left():
    assert Left('Failure!') == Left('Failure!')



# Generated at 2022-06-23 23:56:01.185165
# Unit test for constructor of class Left
def test_Left():
    left = Left(5)
    assert left.value == 5


# Generated at 2022-06-23 23:56:04.207965
# Unit test for method is_right of class Left
def test_Left_is_right():
    def is_right(any: Any) -> bool:
        return isinstance(any, Right)
    assert not Left(5).is_right()


# Generated at 2022-06-23 23:56:05.829109
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False



# Generated at 2022-06-23 23:56:07.362065
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:56:13.541678
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test bind method of Right class.

    Test with function which return Right and function which return Left.
    """
    right_value = Right('t')
    right_result = right_value.bind(lambda x: Right(x + 'r'))
    assert right_result == Right('tr')
    right_result = right_value.bind(lambda x: Left(x + 'r'))
    assert right_result == Left('tr')



# Generated at 2022-06-23 23:56:14.083000
# Unit test for constructor of class Left
def test_Left():
    assert Left(4) == Left(4)

# Generated at 2022-06-23 23:56:15.104781
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda v: Right(v + 1)) == 1


# Generated at 2022-06-23 23:56:16.191099
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()

# Generated at 2022-06-23 23:56:17.234321
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-23 23:56:18.545143
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False

# Generated at 2022-06-23 23:56:23.477599
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(5).bind(lambda x: Right(x+1)) == Right(6)
    assert Right(5).bind(lambda x: Right(x-1)) == Right(4)
    assert Right(5).bind(lambda x: Right(x*2)) == Right(10)
    assert Right(5).bind(lambda x: Right(x/2)) == Right(2.5)


# Generated at 2022-06-23 23:56:25.650897
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-23 23:56:26.954797
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(0).to_maybe() == Maybe(0)
assert Right(0).to_maybe() == Maybe.just(0)



# Generated at 2022-06-23 23:56:33.936434
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left('value')
    right1 = Right('value')
    left2 = Left('value')
    right2 = Right('value')

    assert left1.__eq__(left1)
    assert left1.__eq__(left2)
    assert not left1.__eq__(right1)
    assert not left1.__eq__(right2)
    assert not left1.__eq__('value')
    assert not left1.__eq__(1)
    assert not left1.__eq__({'value': 'value'})
    assert not left1.__eq__(['value'])
    assert not left1.__eq__((1, 'value'))

    assert right1.__eq__(right1)
    assert right1.__eq__(right2)
    assert not right1.__

# Generated at 2022-06-23 23:56:38.829395
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(None).is_right()



# Generated at 2022-06-23 23:56:40.115511
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left()



# Generated at 2022-06-23 23:56:42.095126
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_error import raise_error
    from pymonet.monad_error import MonadError

    @MonadError(raise_error)
    def function(x):
        return x

    assert Left(0).bind(function) == Left(0)


# Generated at 2022-06-23 23:56:50.510724
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_list import List

    assert Left(1).bind(lambda x: List([x])) == List([1])
    assert Left(1).bind(lambda x: List([])) == List([])
    assert Left(1).bind(lambda x: List([x ** 2, x ** 2])) == List([1])
    assert Left(1).bind([]) == List([])
    assert Left(1).bind([2, 3]) == List([2, 3])


# Generated at 2022-06-23 23:56:53.791104
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2).value == 4


# Generated at 2022-06-23 23:56:56.198763
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either = Right(123)
    assert either.to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-23 23:56:57.995190
# Unit test for constructor of class Right
def test_Right():
    right_instance = Right(1)

    assert right_instance
    assert right_instance.value == 1
    assert right_instance.is_right()
    assert not right_instance.is_left()


# Generated at 2022-06-23 23:57:04.638544
# Unit test for constructor of class Either
def test_Either():
    # Check constructors of Right
    assert Right(3) == Right(3)
    assert Right(3) is not Right(3)
    assert Right(3) != Left(3)
    assert not (Right(3) != Right(3))
    # Check constructors of Left
    assert Left(4) == Left(4)
    assert Left(4) is not Left(4)
    assert Left(4) != Right(4)
    assert not (Left(4) != Left(4))



# Generated at 2022-06-23 23:57:08.209477
# Unit test for method is_left of class Right
def test_Right_is_left():

    def test() -> None:
        assert Right(1).is_left() == False
        print('Test of method "is_left" of class Right passed.')

    test()


# Generated at 2022-06-23 23:57:10.895875
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not isinstance(Left('test').is_right(), bool)


# Generated at 2022-06-23 23:57:12.366067
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-23 23:57:15.315001
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right('ok').to_validation() == Validation.success('ok')
    assert Right('ok').to_validation().is_success()


# Generated at 2022-06-23 23:57:17.288443
# Unit test for method map of class Left
def test_Left_map():
    val = Left('foo')
    assert Left('foo').map(lambda x: x[0]) == val



# Generated at 2022-06-23 23:57:22.828372
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    validation = Left(5).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.value == [5]


# Generated at 2022-06-23 23:57:24.720973
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(2)
    assert left.is_right() == False


# Generated at 2022-06-23 23:57:26.813019
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([1]).equals(Left(1).to_validation())


# Generated at 2022-06-23 23:57:28.881676
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(3).to_validation() == Validation.fail([3])

# Generated at 2022-06-23 23:57:31.513664
# Unit test for method to_box of class Either
def test_Either_to_box():
    result = Right(1).to_box()
    expected = Box(1)
    assert result == expected

    result = Left(1).to_box()
    expected = Box(1)
    assert result == expected


# Generated at 2022-06-23 23:57:44.015773
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Either(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Left('something is wrong') != Left(1)
    assert Left(1) != Right(1)
    assert Left('something is wrong') != Right(1)
    assert Left('something is wrong') != Right(1)
    assert Right(1) != Try(1)
    assert Left(1) != Box(1)
    assert Right(1) != Lazy(lambda: 1)
   

# Generated at 2022-06-23 23:57:45.960501
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    actual = Left('test')
    expected = 'failed'

    assert actual.to_validation().case(
        success=lambda _: 'success',
        error=lambda _: 'failed'
    ) == expected


# Generated at 2022-06-23 23:57:48.960270
# Unit test for method ap of class Left
def test_Left_ap():
    left_value = "error"
    left_either = Left(left_value)

    right_value = lambda value: value
    right_either = Right(right_value)

    assert left_either.ap(right_either) == left_either
# ---



# Generated at 2022-06-23 23:57:53.798209
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)


# Generated at 2022-06-23 23:57:55.354745
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda v: v + 1) == Left(1)



# Generated at 2022-06-23 23:57:59.945721
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)

    assert right == right.map(lambda value: value)

    assert right == right.map(lambda _: 3)



# Generated at 2022-06-23 23:58:03.908166
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Test function."""
    left = Left(123)
    right = Right(123)

    assert left.to_try().is_success() is False
    assert left.to_try().value == 123
    assert right.to_try().is_success() is True
    assert right.to_try().value == 123

# Generated at 2022-06-23 23:58:06.228916
# Unit test for method is_left of class Left
def test_Left_is_left():
    from hypothesis import given
    from hypothesis.strategies import text, integers
    from monads.pymonet.monad_try import Try

    @given(text())
    def test_is_left_returns_true(value):
        assert Left(value).is_left() is True



# Generated at 2022-06-23 23:58:11.499216
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    either_value = Either(Maybe.just('test'))
    assert isinstance(either_value.to_lazy(), Lazy)
    assert either_value.to_lazy().value() == Maybe.just('test')



# Generated at 2022-06-23 23:58:20.583560
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Transform Either to Lazy.

    :returns: Lazy monad with function returning previous value
    :rtype: Lazy[Function() -> A]
    """
    from pymonet.lazy import Lazy
    import pytest

    assert Lazy(lambda: 'boom') == Right('boom').to_lazy()
    assert Lazy(lambda: 'boom') != Left('boom').to_lazy()
    assert Lazy(lambda: 'boom') != Lazy(lambda: 'bam')
    with pytest.raises(TypeError):
        Left('boom').to_lazy() == Left(123)
    with pytest.raises(TypeError):
        Left('boom').to_lazy() == 'boom'

# Generated at 2022-06-23 23:58:29.468575
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(0).is_left() == False
    assert Right(True).is_left() == False
    assert Right(None).is_left() == False
    assert Right([1, 2, 3]).is_left() == False
    assert Right({'foo': 1, 'bar': 2}).is_left() == False
    assert Right(3.14).is_left() == False
    assert Right('anytext').is_left() == False
    assert Right(('tuple', 2)).is_left() == False
    assert Right('some string').is_left() == False

# Generated at 2022-06-23 23:58:31.244654
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right('test').is_right() is True
    assert Left('test').is_right() is False



# Generated at 2022-06-23 23:58:33.452075
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right() == True
    assert Right("42").is_right() == True
    assert Right(42.42).is_right() == True



# Generated at 2022-06-23 23:58:34.971407
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right('foo').to_validation() == Validation.success('foo')


# Generated at 2022-06-23 23:58:36.097951
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(None).is_right()


# Generated at 2022-06-23 23:58:38.983237
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Tests for method bind of class Right.

    :returns: None
    :rtype: None
    """
    assert Right(12).bind(lambda x: Right(x + 15)) == Right(27)


# Generated at 2022-06-23 23:58:41.561021
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(5)
    assert left.is_right() is False


# Generated at 2022-06-23 23:58:42.633560
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() == False


# Generated at 2022-06-23 23:58:46.710745
# Unit test for method ap of class Left
def test_Left_ap():
    def fn(a):
        return a + 1

    assert Left(1).ap(Left(fn)) == Left(fn)
    assert Right(1).ap(Right(fn)) == Right(fn(1))
    assert Left(1).ap(Right(fn)) == Left(fn)



# Generated at 2022-06-23 23:58:52.668158
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    error = Exception('some error')
    left = Left(error)
    expected = Validation.fail([error])
    # When
    result = left.to_validation()
    # Then
    assert repr(expected) == repr(result)
    assert expected == result

# Generated at 2022-06-23 23:58:56.345349
# Unit test for method case of class Either
def test_Either_case():
    left = Left('error')
    right = Right('success')
    left_result = left.case(lambda x: x, lambda x: x)
    right_result = right.case(lambda x: x, lambda x: x)
    assert left_result == 'error'
    assert right_result == 'success'



# Generated at 2022-06-23 23:58:58.828955
# Unit test for constructor of class Left
def test_Left():
    # when
    left = Left(1)

    # then
    assert left.case(lambda val: val, lambda val: val + 1) == 1
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-23 23:59:03.191355
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Try(1, True)
    assert Either(1).to_try() != Try(1, False)
    assert Either(None).to_try() != Try(1, True)
    assert Either(None).to_try() == Try(None, False)


# Generated at 2022-06-23 23:59:06.452632
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)



# Generated at 2022-06-23 23:59:07.699282
# Unit test for constructor of class Right
def test_Right():
    assert Right("foo").value == "foo"



# Generated at 2022-06-23 23:59:10.506071
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Right(1) == Right(1))
    assert(Left(1) == Left(1))
    assert(Right(1) != Left(1))
    assert(Left(1) != Right(1))



# Generated at 2022-06-23 23:59:12.925038
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)

    assert Left(1) != Right(2)
    assert Right(1) != Left(2)

    assert Left(1) != 1
    assert Right(1) != 1

    assert Left(1) != None
    assert Right(1) != None


# Generated at 2022-06-23 23:59:17.192632
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Test to_maybe method of class Either.
    """
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:59:20.624743
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    >>> from pymonet.either import Left
    >>> test = Left(10)
    >>> test.to_validation()
    ☐ [10]
    """



# Generated at 2022-06-23 23:59:22.739320
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation([], 1)


# Generated at 2022-06-23 23:59:24.875904
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:59:27.752836
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(42).to_validation() == Validation.fail([42])


# Generated at 2022-06-23 23:59:32.462124
# Unit test for method case of class Either
def test_Either_case():
    assert Right(7).case(
        error=lambda value: 0,
        success=lambda value: value
    ) == 7

    assert Left(7).case(
        error=lambda value: 0,
        success=lambda value: value
    ) == 0



# Generated at 2022-06-23 23:59:35.258660
# Unit test for constructor of class Left
def test_Left():
    same_left = Left(5)
    same_left_2 = Left(5)
    other_left = Left(2)

    assert same_left == same_left_2
    assert same_left != other_left



# Generated at 2022-06-23 23:59:37.209687
# Unit test for constructor of class Left
def test_Left():
    """
    :returns: Left instance with value True
    :rtype: Left[Boolean]
    """
    return Left(True)


# Generated at 2022-06-23 23:59:43.463380
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.option import Option
    from pymonet.box import Box

    def inc(x: int) -> int:
        return x + 1

    def to_maybe(x: int) -> Option[int]:
        from pymonet.option import Option

        return Option.just(x + 1)

    def to_option_from_box(x: int) -> Box[Option[int]]:
        import pymonet.option as option
        from pymonet.box import Box

        return Box(option.Option.just(x + 1))

    def to_box(x: int) -> Box[int]:
        from pymonet.box import Box

        return Box(x + 1)

    def no_op(x: int) -> int:
        return x


# Generated at 2022-06-23 23:59:44.901852
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-23 23:59:48.810662
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1) == Left(1)
    assert Left('some').map(lambda x: x) == Left('some')
    assert Left(1).map(lambda x: x) == Left(1)
    assert Left(1).map(lambda x: x**2) == Left(1)
    assert Left(1).map(lambda x: None) == Left(1)
    assert Left(1).map(lambda x: x) == Left(1)
    assert Left(1).map(lambda x: x).value == 1
    assert Left(1).map(lambda x: x) != Left(2)


# Generated at 2022-06-23 23:59:52.659006
# Unit test for method to_box of class Either
def test_Either_to_box():
    # Test for class Left
    assert isinstance(Left("error").to_box(), Box)
    # Test for class Right
    assert isinstance(Right("ok").to_box(), Box)
    assert Right("ok").to_box().value == "ok"


# Generated at 2022-06-23 23:59:57.439017
# Unit test for method is_left of class Right
def test_Right_is_left():
    # Arrange
    test = Right(1)
    # Act
    result = test.is_left()
    # Assert
    assert result == False


# Generated at 2022-06-24 00:00:00.719981
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left('value').to_lazy() == Lazy(lambda: 'value')
    assert Right('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-24 00:00:04.117391
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) != 1
    assert Either(1) != Either(2)
    assert Either(1) != Left(2)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-24 00:00:04.937602
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left()


# Generated at 2022-06-24 00:00:09.042753
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation

    assert Either.case(Left(1), lambda x: x+2, lambda y: y-2) == 3
    assert Either.case(Right(1), lambda x: x+2, lambda y: y-2) == -1

    #Testing validation applicative
    assert Validation.success('Hello').case(lambda _: 'Nothing', lambda o: o) == 'Hello'



# Generated at 2022-06-24 00:00:11.695076
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)

    assert left.is_left(), 'is_left should return True'


# Generated at 2022-06-24 00:00:13.598646
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(int) == left



# Generated at 2022-06-24 00:00:18.040971
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(0)
    assert left.to_maybe() == pymonet.maybe.Maybe.nothing()


# Generated at 2022-06-24 00:00:19.061699
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("error").is_left()



# Generated at 2022-06-24 00:00:20.380141
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right(1).is_right()
    assert not Right(1).is_left()



# Generated at 2022-06-24 00:00:21.980451
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(s: str) -> Either[str]:
        return Right(s)

    right_value = Right('right')

    assert right_value.bind(mapper) == Right('right')



# Generated at 2022-06-24 00:00:25.195742
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(None) != Either(None), 'Should be different'


# Generated at 2022-06-24 00:00:26.261560
# Unit test for method is_left of class Left
def test_Left_is_left():
    a = Left(1)
    assert a.is_left()



# Generated at 2022-06-24 00:00:27.593346
# Unit test for method map of class Left
def test_Left_map():
    # upper case unit test
    assert Left('i').map(lambda i: i.upper()) == Left('i')



# Generated at 2022-06-24 00:00:34.421616
# Unit test for method map of class Left
def test_Left_map():
    left = Left('A')
    new_left = left.map(lambda x: x + 'B')

    assert left == new_left
    assert left.is_left() == new_left.is_left()
    assert left.is_right() == new_left.is_right()
    assert left.value == new_left.value


# Generated at 2022-06-24 00:00:39.736728
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)



# Generated at 2022-06-24 00:00:40.663035
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).case(lambda x: 'error', lambda x: 'success') == 'success'


# Generated at 2022-06-24 00:00:44.027476
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Right(1).to_maybe(), Maybe)
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:00:46.511638
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x << 2) == Left(1)


# Generated at 2022-06-24 00:00:47.223632
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() == True



# Generated at 2022-06-24 00:00:48.350707
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right('a').is_left()



# Generated at 2022-06-24 00:00:50.975691
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(42)

    result = left.to_maybe()

    assert result.is_nothing()


# Generated at 2022-06-24 00:00:52.847483
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(100).to_validation() == Validation.fail([100])



# Generated at 2022-06-24 00:00:55.101989
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(2).to_box() == Box(2)
    assert Left([2]).to_box() == Box([2])


# Generated at 2022-06-24 00:00:56.210969
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("Value").is_left() is True


# Generated at 2022-06-24 00:00:58.020603
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left('error').ap(Right(lambda x: x+1)) == Left('error')
    assert Right(1).ap(Right(lambda x: x+1)) == Right(2)

# Generated at 2022-06-24 00:01:00.188697
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    result = left.bind(lambda value: Right(value * 2))

    assert left.value == 1
    assert isinstance(result, Left)
    assert result.value == 1


# Generated at 2022-06-24 00:01:04.031036
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.builder import Builder

    def doubled(x):
        return x * 2

    assert Right(Builder(doubled)).ap(Box(3)) == Right(6)
    assert Left(Builder(doubled)).ap(Box(3)) == Left(Builder(doubled))
    assert Right(Builder(doubled)).ap(Left(Box(3))) == Left(Builder(doubled))

# Generated at 2022-06-24 00:01:05.855673
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('error').is_left() == True


# Generated at 2022-06-24 00:01:07.662192
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(lambda x: x + 1, lambda x: x * 2) == 6
    assert Right(5).case(lambda x: x + 1, lambda x: x * 2) == 10



# Generated at 2022-06-24 00:01:11.647973
# Unit test for method map of class Left
def test_Left_map():
    left = Left(2)

    assert left.map(lambda x: x * 2) == left
    assert left.map(lambda x: x * 2) == Left(2)
    assert left.map(lambda x: x + 1) == Left(2)
    assert left.map(Exception) == left


# Generated at 2022-06-24 00:01:12.832698
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(10).is_right() == None



# Generated at 2022-06-24 00:01:16.238755
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda x: x * 2) == Right(6)


# Generated at 2022-06-24 00:01:18.628763
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(3).to_box() == Box(3)
    assert Right(3).to_box() == Box(3)



# Generated at 2022-06-24 00:01:20.547843
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    either = Left("failed")

    assert either.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:21.402369
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-24 00:01:22.863310
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:01:24.066112
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('Some value').is_left()



# Generated at 2022-06-24 00:01:27.807539
# Unit test for constructor of class Right
def test_Right():
    """Test construction of Right monad."""
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)



# Generated at 2022-06-24 00:01:31.582491
# Unit test for constructor of class Left
def test_Left():
    value = 'something went wrong'
    left = Left(value)
    assert left.value == value
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-24 00:01:35.784858
# Unit test for method is_right of class Right
def test_Right_is_right():
    value = 'sth'
    either = Right(value)
    assert type(either) is Right
    assert either == Right(value)
    assert either == either
    assert either.is_right()
    assert not either.is_left()


# Generated at 2022-06-24 00:01:37.239443
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True



# Generated at 2022-06-24 00:01:39.515236
# Unit test for method to_box of class Either
def test_Either_to_box():
    maybe = Right(10).to_box()
    assert isinstance(maybe, Box)
    assert maybe.value == 10
    assert maybe.value == 10



# Generated at 2022-06-24 00:01:40.607269
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(5)
    assert right.bind(lambda v: Right(v*5)) == Right(25)

# Generated at 2022-06-24 00:01:43.028433
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == False
    assert Either('a').is_right() == False
    assert Either([1, 2, 3]).is_right() == False


# Generated at 2022-06-24 00:01:45.403191
# Unit test for method case of class Either
def test_Either_case():
    assert Left('message').case(lambda i: str(i), lambda i: i) == 'message'
    assert Right(1).case(lambda i: str(i), lambda i: i) == 1


# Generated at 2022-06-24 00:01:47.286727
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left('error').bind(lambda x: Right(x)) == Left('error')


# Generated at 2022-06-24 00:01:49.996208
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is None
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:01:52.088832
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('error')
    assert left.bind(lambda _: 'success') == left



# Generated at 2022-06-24 00:01:56.029058
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Right(5).to_lazy()

    test.assert_equals(5, result.get())

    result = Left("error").to_lazy()

    test.assert_equals("error", result.get())

# Generated at 2022-06-24 00:01:57.978034
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() == True
    assert Left(None).is_right() == False


# Generated at 2022-06-24 00:02:03.450221
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.box import Box

    def success(value):
        return value ** 2

    def error(value):
        return value ** 3

    left = Left("error")
    assert left.ap(Box(success)) == left
    assert left.ap(Box(error)) == left
    assert left.ap("error") == left


# Generated at 2022-06-24 00:02:05.603812
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1).bind(lambda x: Right(x + 1))
    assert right.value == 2
    assert right.is_right()


# Generated at 2022-06-24 00:02:07.952752
# Unit test for method map of class Left
def test_Left_map():
    # Test without function
    assert Left(1).map(None) == Left(1)

    # Test with function
    assert Left(1).map(lambda a: a + 1) == Left(1)



# Generated at 2022-06-24 00:02:10.763977
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left(), "Right cannot be left"


# Generated at 2022-06-24 00:02:13.788195
# Unit test for constructor of class Either
def test_Either():
    # when:
    a = Either(3)
    # then:
    assert a.case(lambda e: e + 5, lambda b: b + 5) == 8
    assert isinstance(a, Either)

# Generated at 2022-06-24 00:02:16.146710
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert isinstance(Left(5).to_lazy(), Lazy) == True
    assert isinstance(Right(5).to_lazy(), Lazy) == True



# Generated at 2022-06-24 00:02:17.598126
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(3).ap(Right(None)) == Left(3)


# Generated at 2022-06-24 00:02:26.668789
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.functor import Functor
    from pymonet.typeclass import implement_for

    @implement_for(Either)
    class FunctorEither(Functor):
        """Functor for Either"""

        def map(self, mapper: Callable[[T], U]) -> Either[U]:
            """
            Take mapper function and return new instance of Either with mapped value.

            :param value: value to map
            :type value: Either[A]
            :param mapper: function to apply on Either value
            :type mapper: Function(A) -> B
            :returns: new Either with result of mapper
            :rtype: Either[B]
            """
            return self.case(lambda x: Left(x), lambda x: Right(mapper(x)))


# Generated at 2022-06-24 00:02:27.575900
# Unit test for method is_right of class Right
def test_Right_is_right():
    assertion = Right(1)
    assert assertion.is_right() is True



# Generated at 2022-06-24 00:02:32.933699
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    try_right = Try(lambda: 0)
    try_left = Try(lambda: 1 / 0)

    assert either_right.to_try() is try_right
    assert either_left.to_try() is try_left



# Generated at 2022-06-24 00:02:35.966064
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Left(1).to_validation(), Validation)


# Generated at 2022-06-24 00:02:40.946194
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    validation = Right(3).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.value == 3

# Generated at 2022-06-24 00:02:42.482929
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(2).is_right() is False



# Generated at 2022-06-24 00:02:45.388450
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x * 2) == 2
    assert Right(1).case(lambda x: x + 1, lambda x: x * 2) == 2



# Generated at 2022-06-24 00:02:50.746702
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try

    assert Right(20).bind(lambda value: Left('Error')) == Left('Error')
    assert Right(20).bind(lambda value: Try(value * 10)) == Try(200)
    assert Right(20).bind(lambda value: Right(value * 10)) == Right(200)
    assert Right(20).bind(lambda value: Try(lambda: value * 10)) == Try(200)



# Generated at 2022-06-24 00:02:55.368544
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    left = Left("fail")
    assert left.to_try() == Try("fail")

    right = Right("success")
    assert right.to_try() == Try("success", is_success=True)


# Generated at 2022-06-24 00:02:56.088522
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:02:57.044009
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(None)
    assert left.is_right() == False



# Generated at 2022-06-24 00:03:05.990360
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    from pymonet.io import IO

    test_list = [
        (lambda x: x + 1, Left(1), Left(1)),
        (lambda x: x + 3, Left(1), Left(1)),
        (lambda x: x + 1, IO('test'), Left('test')),
        (lambda x: x + 1, Try('test'), Left('test')),
        (lambda x: x + 1, Lazy(lambda: 1), Left(1))
    ]
    for t in test_list:
        assert t[1].ap(t[0]) == t[2]


# Generated at 2022-06-24 00:03:07.460292
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() is True


# Generated at 2022-06-24 00:03:08.824331
# Unit test for constructor of class Left
def test_Left():
    left = Left(5)
    assert left.value == 5


# Generated at 2022-06-24 00:03:12.283637
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.box import Box

    assert Box(5).is_right() == True
    assert Box(None).is_right() == True
    assert Box(5).is_right() == True
    assert Box(None).is_right() == True


# Generated at 2022-06-24 00:03:14.410096
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """Just return empty maybe"""
    from pymonet.maybe import Maybe

    assert(Left(1).to_maybe() == Maybe.nothing())



# Generated at 2022-06-24 00:03:18.474980
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    def success(item):
        assert isinstance(item, Maybe) and item.get(), "Result of to_maybe of Right should be maybe with value."

    def fail(item):
        assert item, "Result of to_maybe of wrong Either should be nothing."

    Right(1).to_maybe().case(fail, success)


# Generated at 2022-06-24 00:03:19.743449
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-24 00:03:21.415536
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 'value'
    assert Either.to_lazy(Right(value)) == Lazy(lambda: value)

# Generated at 2022-06-24 00:03:23.876258
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() == False


# Generated at 2022-06-24 00:03:30.986491
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    def double(x: int) -> int:
        return x * 2

    assert Right('hi').ap(Right(double)) == Right('hihi')
    assert Right('hi').ap(Left(double)) == Left(double)
    assert Left(double).ap(Right('hi')) == Left(double)
    assert Left(double).ap(Left(double)) == Left(double)

    assert Right('hi').ap(Box(double)) == Right('hihi')
    assert Right('hi').ap(Box(double)) == Box('hihi')



# Generated at 2022-06-24 00:03:32.962098
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x)) == Left(1)



# Generated at 2022-06-24 00:03:34.421078
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('foo').is_right() == False


# Generated at 2022-06-24 00:03:36.088962
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')
    assert left.is_left()


# Generated at 2022-06-24 00:03:39.701243
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:03:46.014902
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(None).is_right() and\
        not Left(None).is_right() and\
        Right([1, 2, 3]).is_right() and\
        not Left({1: 2}).is_right() and\
        Right('').is_right() and\
        not Left(100).is_right() and\
        Right([]).is_right() and\
        not Left((1, 2)).is_right() and\
        Right(True).is_right() and\
        not Left('aaa').is_right()



# Generated at 2022-06-24 00:03:48.603950
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x) == Left(1)

