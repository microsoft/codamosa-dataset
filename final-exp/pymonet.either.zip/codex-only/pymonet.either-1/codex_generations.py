

# Generated at 2022-06-23 23:53:50.902064
# Unit test for method map of class Right
def test_Right_map():
    right = Right(123)
    right_mapped = right.map(str)
    assert right_mapped.value == '123', f'Wrong mapping result {right_mapped.value}'
    assert not isinstance(right_mapped, Right), f'Mapper of Right should return new instance of Right'



# Generated at 2022-06-23 23:54:01.792653
# Unit test for method map of class Right
def test_Right_map():
    assert Right(23).map(lambda x: x * 2) == Right(46)
    assert Right(23).map(lambda x: x) == Right(23)
    assert Right(Right(23)).map(lambda x: x * 2) == Right(Right(46))
    assert Right(23).map(lambda x: [x]) == Right([23])
    assert Right(23).map(lambda x: Right(x)) == Right(Right(23))
    assert Right(23).map(lambda x: Left(x)) == Right(Left(23))
    assert Right(23).map(lambda x: Either.from_nullable(x)) == Right(Right(23))
    assert Right(23).map(lambda x: Either.from_nullable(None)) == Right(Left(None))



# Generated at 2022-06-23 23:54:06.314088
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(None).to_try() == Try.failure(None)
    assert Either(2).to_try() == Try.success(2)



# Generated at 2022-06-23 23:54:08.413974
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:54:09.590949
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right() == True



# Generated at 2022-06-23 23:54:11.057604
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Either(None).is_right(), bool)


# Generated at 2022-06-23 23:54:15.302677
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Right(1).bind(lambda x: Right(x + 2)) == Right(3)
    assert Right(1).bind(lambda _: Lazy(1000)) == Lazy(1000)
    assert Right(1).bind(lambda _: Maybe.just(1000)) == Maybe.just(1000)

# Generated at 2022-06-23 23:54:16.664954
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('5').is_left() is False



# Generated at 2022-06-23 23:54:19.702826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    right = Right(10)
    lazy = right.to_lazy()
    assert lazy == Lazy(lambda: right.value)



# Generated at 2022-06-23 23:54:25.215826
# Unit test for method is_right of class Right
def test_Right_is_right():
    result = Right('ok').is_right()
    assert result == True



# Generated at 2022-06-23 23:54:27.758284
# Unit test for constructor of class Left
def test_Left():
    left = Left("error")
    assert left.value == "error"



# Generated at 2022-06-23 23:54:32.128516
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(3).bind(lambda x: Right(x+1)) == Left(3)


# Generated at 2022-06-23 23:54:38.672639
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test for method to_box of class Either.

    >>> from pymonet.box import Box
    >>> from pymonet.either import Right, Left
    >>> assert(Right(Box(3)).to_box() == Box(3))
    >>> assert(Left(3).to_box() == Box(3))
    """
    pass


# Generated at 2022-06-23 23:54:41.262240
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    assert(Left(1).to_box() == Box(1))
    assert(Right(1).to_box() == Box(1))


# Generated at 2022-06-23 23:54:46.065817
# Unit test for constructor of class Right
def test_Right():
    """
    Unit test for constructor of class Right
    """
    assert Right(5) == Right(5)
    assert Right(5) != Right(4)
    assert Right(5) is not Right(5)



# Generated at 2022-06-23 23:54:56.403188
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    from pymonet.monad_maybe import Just

    # And
    def add_3(x):
        return x + 3

    # And
    def add_5(x):
        return x + 5

    # And
    def divide_5(x):
        return x / 5

    # When
    result_1 = Just(add_3).ap(Right(5))
    # Then
    assert result_1 == Right(8)

    # When
    result_2 = Just(add_3).ap(Left(5))
    # Then
    assert result_2 == Left(5)

    # When
    result_3 = Just(add_5).ap(Right(4))
    # Then
    assert result_3 == Right(9)

    # When

# Generated at 2022-06-23 23:55:06.040292
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Either.right(lambda x: x * 2).ap(Either.right(8)) == Either.right(16)
    assert Either.right(8).ap(Either.left(lambda x: x * 2)).is_left()
    assert Either.left(lambda x: x * 2).ap(Either.right(8)).is_left()
    assert Either.left(lambda x: x * 2).ap(Either.left(8)).is_left()
    assert Either.right(lambda x: x * 2).to_box().ap(Either.right(8)) == Either.right(16)
    assert Either.right(8).ap(Either.left(lambda x: x * 2).to_box()).is_left()
    assert Either

# Generated at 2022-06-23 23:55:15.932371
# Unit test for constructor of class Right
def test_Right():
    """
    Test for unit constructor of class Right

    :returns: nothing
    :rtype: nothing
    """

    assert Right(2).value == 2
    assert Right(2).case(lambda e: e, lambda s: s) == 2
    assert Right(None) == Right(None)
    assert Right(2).to_lazy().get_value() == 2
    assert Right(2).to_try().is_success()
    assert Right(2).to_box().value == 2
    assert Right(2).to_maybe().value == 2
    assert Right(2).to_validation().is_success()
    assert Right(2).to_validation().value == 2
    assert Right(2).to_validation().error == []



# Generated at 2022-06-23 23:55:17.742043
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-23 23:55:18.560822
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(None).is_right()


# Generated at 2022-06-23 23:55:25.295869
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    plus_lambda = lambda x, y: x + y
    plus_box = Box(plus_lambda)
    left = Left(3)
    right = Right(4)
    left_plus_right = left.ap(plus_box.map(lambda add: lambda x: add(x, 5)))
    right_plus_right = right.ap(plus_box.map(lambda add: lambda x: add(x, 5)))

    assert left_plus_right == Left(3)
    assert right_plus_right == Right(9)

test_Either_ap()

# Generated at 2022-06-23 23:55:27.879690
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    m = Right(2)
    assert m.to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:55:31.688498
# Unit test for constructor of class Either
def test_Either():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert issubclass(Either, Functor)
    assert issubclass(Either, Monad)
    assert issubclass(Either, Applicative)


# Generated at 2022-06-23 23:55:33.478550
# Unit test for method bind of class Left
def test_Left_bind():
    error = 'error'
    left = Left(error)
    func = lambda x: Right(x)

    assert left.bind(func) == left


# Generated at 2022-06-23 23:55:35.524486
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('example').to_maybe().is_nothing() is True


# Generated at 2022-06-23 23:55:37.614666
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert(Left(1).is_right() == False)
    assert(Right(1).is_right() == True)


# Generated at 2022-06-23 23:55:39.247061
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(3).to_maybe()


# Generated at 2022-06-23 23:55:40.792184
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:55:48.134388
# Unit test for constructor of class Left
def test_Left():
    from pymonet.funcs import identity
    from pymonet.equal import Eq

    eq = Eq()
    left = Left(1)
    assert left.case(identity, identity) == 1
    assert left.is_left()
    assert eq.compare(left.case(Left, Right), Left(1))
    assert eq.compare(left.to_try(), eq.compare(left.to_try(), Try(1, False)))


# Generated at 2022-06-23 23:55:51.834422
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.either import Left

    assert Left(10).ap(Box(lambda x: x + 1)) == Left(10)



# Generated at 2022-06-23 23:55:59.239026
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Arrange
    right_a = Right('a')
    right_b = Right('b')
    right_c = Right('a')
    left_a = Left('a')
    left_b = Left('b')
    left_c = Left('a')
    # Act
    result_01 = right_a == 'a'
    result_02 = right_a == left_a
    result_03 = right_a == right_b
    result_04 = right_a == left_b
    result_05 = right_a == right_c
    result_06 = right_a == left_c
    result_07 = left_a == 'a'
    result_08 = left_a == left_a
    result_09 = left_a == right_b
    result_10 = left_a == left_b


# Generated at 2022-06-23 23:56:03.088113
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(3).to_try() == Try(3, is_success=False)
    assert Right(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-23 23:56:05.684732
# Unit test for method bind of class Right
def test_Right_bind():
    """Testing bind function of Right class."""
    assert Right(5).bind(lambda value: Right(value + 5)) == Right(10)



# Generated at 2022-06-23 23:56:08.910979
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right("testing").to_validation() == Validation.success("testing")

test_Right_to_validation()



# Generated at 2022-06-23 23:56:12.309166
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(12) == Right(12).to_validation()
    assert Validation.fail([12]) == Left(12).to_validation()


# Generated at 2022-06-23 23:56:13.685682
# Unit test for method is_right of class Right
def test_Right_is_right():
    result = Right(1)
    assert result.is_right()


# Generated at 2022-06-23 23:56:15.692243
# Unit test for constructor of class Either
def test_Either():
    assert Left(None) == Left(None)
    assert Right(None) == Right(None)
    assert None != Right(None)
    assert Right(None) != None
    assert None != Left(None)
    assert Left(None) != None



# Generated at 2022-06-23 23:56:17.871611
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(2).is_right() == False


# Generated at 2022-06-23 23:56:20.605266
# Unit test for constructor of class Right
def test_Right():
    from pymonet.box import Box

    assert Box(42) == Right(42)



# Generated at 2022-06-23 23:56:22.904586
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.monad import Right

    left = Right(1).map(lambda x: x + 1)

    assert left.is_right()
    assert left.value == 2


# Generated at 2022-06-23 23:56:24.800288
# Unit test for constructor of class Left
def test_Left():
  assert Left(5) == Left(5)
  assert Left(5) != Left(7)


# Generated at 2022-06-23 23:56:26.037700
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(0).is_left()


# Generated at 2022-06-23 23:56:27.222682
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-23 23:56:29.456532
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe().is_nothing



# Generated at 2022-06-23 23:56:31.570432
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    v = Right(2).to_validation()
    assert isinstance(v, Validation)
    assert v.value == 2


# Generated at 2022-06-23 23:56:32.561610
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(Exception()).bind(lambda x: None) == Left(Exception())



# Generated at 2022-06-23 23:56:33.680958
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-23 23:56:38.137649
# Unit test for method case of class Either
def test_Either_case():
    """
    Test case method of Either class.

    :returns: True on success, False on failure
    :rtype: Boolean
    """

    def inc(x):
        return x + 1

    left = Left(1)
    right = Right(1)
    assert left.case(lambda x: x + 2, inc) == 3
    assert right.case(lambda x: x + 2, inc) == 2
    return True

if __name__ == "__main__":
    test_Either_case()

# Generated at 2022-06-23 23:56:40.908470
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:56:46.420952
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(3).is_left() is False



# Generated at 2022-06-23 23:56:48.392783
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    assert Left(2).to_validation() == Validation.fail([2])


# Generated at 2022-06-23 23:56:53.334096
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(1).to_try() == Try(1)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1)



# Generated at 2022-06-23 23:56:54.142881
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-23 23:56:57.606529
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (Left(1) == Left(1)) is True
    assert (Left(1) == Left(2)) is False
    assert (Right(1) == Right(1)) is True
    assert (Right(1) == Right(2)) is False
    assert (Left(1) == Right(1)) is False



# Generated at 2022-06-23 23:56:59.925015
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-23 23:57:01.306879
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-23 23:57:04.353495
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    left = Left(5)
    assert isinstance(left.to_try(), Try)

    right = Right(5)
    assert isinstance(right.to_try(), Try)



# Generated at 2022-06-23 23:57:06.310677
# Unit test for constructor of class Left
def test_Left():
    instance_of_left = Left(0)
    assert instance_of_left.value == 0



# Generated at 2022-06-23 23:57:11.719542
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    # given
    left = Left('error')
    expected = Left('error')

    # when
    result = left.ap(Box(lambda y: y + y))

    # then
    assert result == expected



# Generated at 2022-06-23 23:57:13.126630
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-23 23:57:14.074436
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:57:16.090412
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    Left(1).to_validation() == Validation.fail([1])

# Generated at 2022-06-23 23:57:19.019941
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left("not valid value").__eq__("string") is False
    assert Left("not valid value").__eq__(Left("not valid value")) is True
    assert Left("not valid value").__eq__(Right("valid value")) is False



# Generated at 2022-06-23 23:57:20.704617
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x * 2) == Right(4)
    assert Right(2).map(lambda x: x / 10) == Right(0.2)


# Generated at 2022-06-23 23:57:22.992961
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(True).to_try() == Try(True, True)
    assert Left(True).to_try() == Try(True, False)


# Generated at 2022-06-23 23:57:28.957528
# Unit test for method bind of class Right
def test_Right_bind():

    # Test with function returning Right
    def add(a):
        return Right(a + 11)

    assert Right(2).bind(add) == Right(13)

    # Test with function returning Left
    def error(a):
        return Left(a + 1)

    assert Right(2).bind(error) == Left(3)

    # Test with function retusing wrong type
    assert Right(2).bind(lambda n: "A" * n) == Left("AA")



# Generated at 2022-06-23 23:57:30.410322
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda value: Either(value + 1)) == Left(1)



# Generated at 2022-06-23 23:57:33.110493
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.assertions import assert_that

    # given
    left_monad = Left(2)

    # when
    actual = left_monad.is_left()

    # then
    assert_that(actual).is_true()


# Generated at 2022-06-23 23:57:37.540603
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:57:39.131438
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == None



# Generated at 2022-06-23 23:57:45.537778
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('Some error').to_lazy() == Lazy(lambda: 'Some error')



# Generated at 2022-06-23 23:57:50.992344
# Unit test for method case of class Either
def test_Either_case():
    # pylint: disable=R0204
    # pylint: disable=R0903
    # pylint: disable=C0103
    # pylint: disable=W0622
    # pylint: disable=C0111
    # pylint: disable=W0108
    class AB(Either):
        """
        Testing class for test case method
        """
        def __init__(self, a : bool) -> None:
            self.a = a

        def is_right(self) -> bool:
            """
            :returns: True if value is True, False if value is False
            :rtype: Bool
            """
            return self.a

    result = AB(False).case(lambda value: value, lambda value: value)
    assert result is False
    result = AB(True).case

# Generated at 2022-06-23 23:57:52.446885
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:57:53.916293
# Unit test for method ap of class Left
def test_Left_ap():
    assert isinstance(Left(1).ap(Left(2)), Left)



# Generated at 2022-06-23 23:57:58.347600
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)



# Generated at 2022-06-23 23:58:00.679483
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.value == 1
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-23 23:58:03.307878
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Left('error')) == Left('error')
    assert Right(1).bind(lambda x: Right(x)) == Right(1)



# Generated at 2022-06-23 23:58:04.176340
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:58:07.841641
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for method bind of class Right
    """
    assert Right(1).bind(lambda x: Right(x+1)) == Right(2)


# Generated at 2022-06-23 23:58:11.163761
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe, Nothing

    assert Maybe.just(1) == Right(1).to_maybe()
    assert Nothing() == Left('error').to_maybe()



# Generated at 2022-06-23 23:58:12.799493
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(3).to_box() == Box(3)
    assert Right(3).to_box() == Box(3)


# Generated at 2022-06-23 23:58:17.693130
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def test_success():
        assert Right(3) == Right(3) == Right(3)

    def test_error():
        assert Left('some error') == Left('some error')

    def test_error():
        assert not Left('some error') == Right(3)

    run_tests(test_success,
              test_success,
              test_error)



# Generated at 2022-06-23 23:58:22.837361
# Unit test for method map of class Left
def test_Left_map():
    # Given
    val = Left("left")

    # When
    result = val.map(lambda x: x + " string ")

    # Then
    assert result.value == "left"



# Generated at 2022-06-23 23:58:29.817949
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.box_test import test_Box_equals

    assert test_Box_equals(Box(10), Either(10).to_box())
    assert test_Box_equals(Box(10), Left(10).to_box())
    assert test_Box_equals(Box('test'), Right('test').to_box())


# Generated at 2022-06-23 23:58:32.276105
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    actual = Left(2).to_validation()
    expected = Validation.fail([2])

    assert actual == expected


# Generated at 2022-06-23 23:58:37.650299
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left(x + 10)) == Left(12)
    assert Right(2).bind(lambda x: Right(x + 10)) == Right(12)



# Generated at 2022-06-23 23:58:38.986040
# Unit test for method map of class Right
def test_Right_map():
    assert Right("foo").map(lambda value: value.upper()).value == "FOO"



# Generated at 2022-06-23 23:58:46.396631
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        return x + 2

    def multiply(x):
        return x * 2

    a = Right(1)
    b = Left(1)

    assert a.map(add).ap(Right(add)).value == 5
    assert a.map(add).ap(Left(1)).value == 1
    assert b.map(add).ap(Right(add)).is_left() is True
    assert b.map(add).ap(Left(1)).is_left() is True

    assert a.map(multiply).ap(Right(add)).value == 4
    assert a.map(multiply).ap(Left(1)).value == 1
    assert b.map(multiply).ap(Right(add)).is_left() is True

# Generated at 2022-06-23 23:58:53.955602
# Unit test for constructor of class Either
def test_Either():
    """Test to create Either"""
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Either(2) == Either(2)
    assert Left(2).ap(Box(lambda x: x * x)) == Left(2)
    assert Left(2).ap(Try(lambda x: x * x, is_success=True)) == Left(2)
    assert Left(2).ap(Lazy(lambda: lambda x: x * x)) == Left(2)
    assert Left(2).to_lazy().value() == 2
    assert Left(2).to_try().is_success is False
    assert Left(2).to_box().value is 2
    assert Left(2).to_maybe().is_nothing is True

# Generated at 2022-06-23 23:58:56.640726
# Unit test for method case of class Either
def test_Either_case():
    result = Left(0).case(lambda err: 1, lambda res: 2)
    assert result == 1

    result = Right(3).case(lambda err: 1, lambda res: 2)
    assert result == 3



# Generated at 2022-06-23 23:58:58.093306
# Unit test for constructor of class Right
def test_Right():
    """
    >>> right = Right(1)
    >>> right.value
    1
    """



# Generated at 2022-06-23 23:59:01.502741
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(1).ap(Right(1)) == Left(1)
    assert Left(1).ap(Left(1)) == Left(1)

    def my_mapper(x):
        return x * 2

    assert Right(1).ap(Right(my_mapper)) == Right(2)
    assert Right(1).ap(Left(my_mapper)) == Left(my_mapper)


# Generated at 2022-06-23 23:59:07.657061
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    lazy = Lazy(lambda: Right(1).value)

    assert Right(1).to_lazy() == lazy
    assert Left(1).to_lazy() == lazy

# Generated at 2022-06-23 23:59:10.197882
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(4) == Right(4)
    assert Left(-1) != Left(-1)
    assert Left(-1) != Right(4)
    assert Right(4) != Left(-1)



# Generated at 2022-06-23 23:59:13.927489
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    result = Left('123').to_maybe()
    assert result == Maybe.nothing()


# Generated at 2022-06-23 23:59:16.922174
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1).to_maybe()
    assert isinstance(right, Maybe)
    assert right.is_just()
    assert right.value == 1


# Generated at 2022-06-23 23:59:25.139953
# Unit test for method case of class Either
def test_Either_case():
    left_either = Either(Left(1))
    assert left_either.case(lambda x: x, lambda x: x) == 1
    right_either = Either(Right(1))
    assert right_either.case(lambda x: x, lambda x: x) == 1
    assert Either(Right(1)).case(lambda x: x, lambda x: x) == 1
    assert Either(Left(1)).case(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-23 23:59:27.592081
# Unit test for constructor of class Left
def test_Left():
    left = Left('left value')
    assert left.value == 'left value'



# Generated at 2022-06-23 23:59:30.176285
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left('error').to_box().value == 'error'
    assert Right(10).to_box().value == 10


# Generated at 2022-06-23 23:59:32.134098
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    msg = 'msg'
    error = Left(msg)
    assert error.to_validation() == Validation.fail([msg])


# Generated at 2022-06-23 23:59:33.591344
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-23 23:59:35.104691
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('error').is_right() is False
    assert Right('value').is_right() is True


# Generated at 2022-06-23 23:59:36.299384
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right() is True


# Generated at 2022-06-23 23:59:37.636970
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True



# Generated at 2022-06-23 23:59:40.862486
# Unit test for method is_right of class Right
def test_Right_is_right():
    from hypothesis import given
    import hypothesis.strategies as st

    @given(st.one_of(st.integers(), st.text(), st.lists(st.one_of(st.integers(), st.text()))))
    def test_should_return_true(value):
        assert Right(value).is_right()



# Generated at 2022-06-23 23:59:43.215737
# Unit test for method bind of class Left
def test_Left_bind():
    """
    Test bind method for Left monad.

    :returns: (result, message)
    :rtype: Boolean, String
    """
    result = Left(2).bind(lambda x: Right(x + 1)) == Left(2)

    message = "Left bind method is correct"
    return result, message


# Generated at 2022-06-23 23:59:46.224285
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert not (Left(1) == None)
    assert not (Left(1) == Right(1))

    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))
    assert not (Right(1) == None)
    assert not (Right(1) == Left(1))



# Generated at 2022-06-23 23:59:51.190866
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    result = Left("error").to_maybe()

    assert isinstance(result, Maybe)
    assert result.is_nothing()


# Generated at 2022-06-23 23:59:57.182095
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Left(1)) == Left(2)
    assert Left(2).ap(Right(1)) == Left(2)


# Generated at 2022-06-23 23:59:58.452365
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-24 00:00:04.106621
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x + 2).ap(Left(1)) == Left(1)



# Generated at 2022-06-24 00:00:09.739008
# Unit test for method map of class Right
def test_Right_map():
    right = Right(100)
    assert right.map(lambda x: x + 600) == Right(700)
    assert right.map(lambda x: x * 10) == Right(1000)
    assert right.map(lambda x: x).map(lambda x: x) == Right(100)


# Generated at 2022-06-24 00:00:10.996372
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(2)
    assert right.is_right()



# Generated at 2022-06-24 00:00:12.449219
# Unit test for method map of class Right
def test_Right_map():
    right = Right(3)

    assert right.map(lambda x: x + 2) == Right(5)



# Generated at 2022-06-24 00:00:14.070832
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('test').is_right() is False



# Generated at 2022-06-24 00:00:20.553301
# Unit test for method ap of class Either
def test_Either_ap():
    print('unit test for method ap of class Either')

    def add_one(x):
        return x + 1

    assert Left(1).ap(Right(add_one)) == Left(1)
    assert Right(1).ap(Right(add_one)) == Right(2)
    assert Right(1).ap(Left(add_one)) == Left(add_one)
    print('pass')

# Generated at 2022-06-24 00:00:21.600517
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False


# Generated at 2022-06-24 00:00:26.125096
# Unit test for method case of class Either
def test_Either_case():
    def _error(v: int) -> int:
        return v + 1

    def _success(v: int) -> int:
        return v * 2

    assert (Left(1).case(_error, _success)) == 2
    assert (Right(1).case(_error, _success)) == 2


# Generated at 2022-06-24 00:00:27.276324
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:00:32.689917
# Unit test for method ap of class Left
def test_Left_ap():
    value = 'test'
    result = Left(value).ap(Left(value))

    expected = Left(value)
    actual = result

    assert expected == actual


# Generated at 2022-06-24 00:00:37.124297
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)
    assert Right([1, 2]).to_validation() == Validation.success([1, 2])
    assert Right((1, 2)).to_validation() == Validation.success((1, 2))
    assert Right({1: 2}).to_validation() == Validation.success({1: 2})
    assert Right(1.0).to_validation() == Validation.success(1.0)



# Generated at 2022-06-24 00:00:38.471918
# Unit test for constructor of class Right
def test_Right():
    assert Right('value')
    assert Right('value').is_right()



# Generated at 2022-06-24 00:00:39.719536
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(0).is_left()



# Generated at 2022-06-24 00:00:42.278047
# Unit test for method map of class Right
def test_Right_map():
    print('============')
    print('Right.map()')
    print('============')

    def f(x):
        return x+1

    def g(x):
        return x*x

    either = Right(2).map(f).map(g)
    print(f'right.map(f).map(g) = {either}')
    assert either == Right(9)



# Generated at 2022-06-24 00:00:44.124701
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')

    assert left.is_left(), 'Left must be left'


# Generated at 2022-06-24 00:00:46.229302
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("something").is_left()


# Generated at 2022-06-24 00:00:46.957186
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert (Right(1).is_right() == True)


# Generated at 2022-06-24 00:00:48.570130
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() == False


# Generated at 2022-06-24 00:00:51.441415
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left('error') == Left('error')
    assert Left(3) != Right(3)
    assert Right('error') != Left('error')


# Generated at 2022-06-24 00:00:59.344741
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Left(1) == Lazy(lambda: 1)
    assert Left(1) == Try(1)
    assert Left(1) == Box(1)

    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Right(1) == Lazy(lambda: 1)
    assert Right(1) == Try(1)
    assert Right(1) == Box(1)

    assert Left(1) != Left(2)
    assert Left(1) != Right(2)
    assert Left(1) != Lazy(lambda: 2)

# Generated at 2022-06-24 00:01:00.885423
# Unit test for method is_left of class Left
def test_Left_is_left():
    """
    Left is_left
    """
    assert Left('Error').is_left()


# Generated at 2022-06-24 00:01:06.682259
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    assert(Left(2) == Left(2))
    assert(not(Left(1) == Left(2)))
    assert(not(Left(2) == Left(1)))
    assert(not(Left(1) == Right(1)))
    assert(not(Right(1) == Left(1)))
    assert(Right(2) == Right(2))
    assert(not(Right(1) == Right(2)))
    assert(not(Right(2) == Right(1)))



# Generated at 2022-06-24 00:01:11.743696
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    try1 = Either.case(Try(None, False), Try(1, True))  # type: Try[None]
    try2 = Either.case(Try(None, False), Try(1, True))  # type: Try[int]

    assert try1.to_try() == try2.to_try()

# Generated at 2022-06-24 00:01:14.122092
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:18.045402
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Right(1).to_maybe() == Just(1)
    assert Right(None).to_maybe() == Just(None)


# Generated at 2022-06-24 00:01:22.338479
# Unit test for method ap of class Either
def test_Either_ap():
    # Left ap
    assert Left(2).ap(Left(2)) == Left(2)
    assert Left(2).ap(Right(2)) == Left(2)

    # Right ap
    assert Right(lambda x: 2 * x).ap(Left(2)) == Left(2)
    assert Right(lambda x: 2 * x).ap(Right(2)) == Right(4)


# Generated at 2022-06-24 00:01:24.957897
# Unit test for method case of class Either
def test_Either_case():
    right = Right('right')
    assert right.case(lambda x: 'left', lambda y: 'right') is 'right'

    right = Left('left')
    assert right.case(lambda x: 'left', lambda y: 'right') is 'left'


# Generated at 2022-06-24 00:01:31.200221
# Unit test for method case of class Either
def test_Either_case():
    """
    Check basic function of case method.
    """
    assert Right(2).case(
        lambda _: 0,
        lambda x: x
    ) == 2

    assert Left(2).case(
        lambda x: x,
        lambda _: 0
    ) == 2



# Generated at 2022-06-24 00:01:34.278833
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(1)

    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:01:37.598859
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    test_any = 'test any value of Either'

    test_either = Left(test_any)

    assert test_either.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:01:40.561566
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Try(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-24 00:01:41.849545
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-24 00:01:47.404235
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Comparing equal Eithers
    left1 = Left('a')
    left2 = Left('a')
    right1 = Right('b')
    right2 = Right('b')

    assert left1 == left2
    assert right1 == right2

    # Comparing different Eithers
    assert left1 != right1
    assert right1 != left1

    # Comparing with other types
    assert left1 != 'a'
    assert left1 != Try.success('a')
    assert left1 != Validation.fail('a')



# Generated at 2022-06-24 00:01:48.849461
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right('a').is_left()



# Generated at 2022-06-24 00:01:50.789629
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-24 00:01:52.515617
# Unit test for method map of class Left
def test_Left_map():
    left = Left('6')

    mapped_left = left.map(lambda x: int(x))

    assert isinstance(mapped_left, Left)
    assert mapped_left == left



# Generated at 2022-06-24 00:01:57.003245
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.functor import Functor

    class Error(Functor):
        """Error functor"""

        def __init__(self, message: str) -> None:
            self.message = message

        def map(self, *args, **kwargs):
            return self

        def __eq__(self, other):
            return isinstance(other, Error) and\
                self.message == other.message

        def __repr__(self):
            return 'Error({})'.format(self.message)

    assert Left(Error('message')).to_try() == Try(Error('message'))
    assert Right(1).to_try() == Try(1)


# Generated at 2022-06-24 00:02:01.696781
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_maybe import Maybe

    left = Left(Maybe.nothing())
    validation = left.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.errors == [Maybe.nothing()]



# Generated at 2022-06-24 00:02:09.710045
# Unit test for method ap of class Either
def test_Either_ap():
    """Unit test for method ap of class Either"""

    from pymonet.either import Right
    from pymonet.list import List, Nil
    from pymonet.function import Function
    from pymonet.box import Box

    # TODO: bug with Maybe
    # test_maybe_ap()

    def handle_either(either: Either) -> str:
        """
        Take either monad and return value of it.

        :returns: value of mapper
        :rtype: str
        """
        return either.case(
            lambda _: 'Fail',
            lambda _: 'Success'
        )

    # Test for Either wrapped with List

# Generated at 2022-06-24 00:02:11.762882
# Unit test for constructor of class Left
def test_Left():
    assert isinstance(Left(1), Left)
    assert Left(1).value == 1



# Generated at 2022-06-24 00:02:14.656631
# Unit test for method map of class Right
def test_Right_map():
    value = Either.right(1)
    result = value.map(lambda x: x + 1)
    assert result == Either.right(2)



# Generated at 2022-06-24 00:02:16.584260
# Unit test for method is_right of class Right
def test_Right_is_right():
    actual = Right(1).is_right()
    expected = True
    assert actual == expected


# Generated at 2022-06-24 00:02:19.309898
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    import pytest
    from pymonet.validation import Validation

    right = Right(5)
    assert right.to_validation() == Validation.success(5)


# Generated at 2022-06-24 00:02:21.637370
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    result = Left("error").to_maybe()
    assert result == Maybe.nothing()



# Generated at 2022-06-24 00:02:27.284397
# Unit test for method map of class Right
def test_Right_map():
    """Test map method of Right class"""

    # givens
    right_value = Right(3)
    mapper_function = lambda x: x * 2

    # when
    right_mapped = right_value.map(mapper_function)

    # then
    assert not right_value is right_mapped  # the original instance is unmodified
    assert right_mapped.is_right()  # resulting instance is a success value
    assert right_mapped.value == 6  # result of function applied on original value



# Generated at 2022-06-24 00:02:31.228410
# Unit test for method case of class Either
def test_Either_case():
    assert Left("Error").case(lambda value: value, lambda value: value) == "Error"
    assert Right("Success").case(lambda value: value, lambda value: value) == "Success"


# Generated at 2022-06-24 00:02:35.203433
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)
    assert Left(2) != Right(2)


# Generated at 2022-06-24 00:02:36.948777
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(10)
    assert not left.is_right()


# Generated at 2022-06-24 00:02:40.768109
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x).ap(Left(2)) == Left(lambda x: x)

# Generated at 2022-06-24 00:02:43.888550
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-24 00:02:49.967463
# Unit test for method case of class Either
def test_Either_case():
    """
    Test for Either case method.
    """
    def add_left(x: int):
        return x + 2

    def add_right(x: int):
        return x * 3

    assert Right(2).case(add_left, add_right) == 6
    assert Left(2).case(add_left, add_right) == 4



# Generated at 2022-06-24 00:02:52.512750
# Unit test for method bind of class Right
def test_Right_bind():
    actual = Right(1).bind(lambda x: Right(x * 2))
    expected = Right(2)

    assert actual == expected



# Generated at 2022-06-24 00:02:56.139921
# Unit test for constructor of class Either
def test_Either():
    from pymonet.tests.helpers import singleton

    assert singleton(Either, 'foo') == singleton(Left, 'foo')
    assert singleton(Either, 'foo') == singleton(Right, 'foo')



# Generated at 2022-06-24 00:02:58.260103
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:02:59.945497
# Unit test for method map of class Left
def test_Left_map():
        left = Left(1)
        assert left == left.map(lambda x: x + 1)


# Generated at 2022-06-24 00:03:01.502503
# Unit test for method map of class Left
def test_Left_map():
    assert Left(25).map(lambda x: x + 1) == Left(25)



# Generated at 2022-06-24 00:03:04.080743
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left('bad stuff')
    assert not left.is_right()

    right = Right('good stuff')
    assert right.is_right()



# Generated at 2022-06-24 00:03:06.635822
# Unit test for method bind of class Right
def test_Right_bind():
    result = Right(1).bind(lambda x: Right(x + 1))
    assert result == Right(2)



# Generated at 2022-06-24 00:03:09.277734
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-24 00:03:10.990807
# Unit test for constructor of class Left
def test_Left():
    msg = "test"
    left = Left(msg)

    assert left.value == msg


# Generated at 2022-06-24 00:03:13.246455
# Unit test for method is_right of class Left
def test_Left_is_right():

    assert(is_instance(Left(1), Either))
    assert(not Left(1).is_right())



# Generated at 2022-06-24 00:03:15.025351
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:03:17.095188
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(6).to_lazy() == Lazy(lambda: 6)
    assert Left(6).to_lazy() == Lazy(lambda: 6)



# Generated at 2022-06-24 00:03:18.994923
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2), "Method map doesn't work properly"



# Generated at 2022-06-24 00:03:21.735117
# Unit test for method to_try of class Either
def test_Either_to_try():
    a = Either.Right(42)
    b = Either.Left('error')

    assert a.to_try().is_success()
    assert b.to_try().is_failure()


# Generated at 2022-06-24 00:03:26.449863
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left("failure").to_lazy() == Lazy(lambda: "failure")

# Generated at 2022-06-24 00:03:26.867628
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)

# Generated at 2022-06-24 00:03:32.132334
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test that method __eq__ of class Either returns proper result.

    :rtype: None
    """
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert not Left(1) == Right(2)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)
    assert not Right(1) == Left(2)


# Test for method case of class Either

# Generated at 2022-06-24 00:03:33.713040
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-24 00:03:35.383784
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("foo").is_right() is True


# Generated at 2022-06-24 00:03:39.754745
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.either import Right

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)



# Generated at 2022-06-24 00:03:45.031436
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test for method to_box.

    :returns: tuple with test name and test results
    :rtype: (String, [Boolean])
    """
    from pymonet.box import Box

    results = [
        Box('') == Left('').to_box(),
        Box(1) == Right(1).to_box()
    ]

    return 'test_Either_to_box', results



# Generated at 2022-06-24 00:03:48.379566
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(1).is_right()
    assert Right(1).is_right()
