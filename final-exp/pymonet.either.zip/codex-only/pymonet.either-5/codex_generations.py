

# Generated at 2022-06-23 23:53:54.323761
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1)
    assert right.to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:53:55.495125
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('error').is_left() is True



# Generated at 2022-06-23 23:53:57.132417
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:53:58.758609
# Unit test for constructor of class Either
def test_Either():
    with pytest.raises(TypeError):
        Either()  # type: ignore



# Generated at 2022-06-23 23:54:01.230316
# Unit test for constructor of class Either
def test_Either():
    """
    >>> from pymonet.either import Either
    >>> Either(1)
    Either(1)
    """


# Generated at 2022-06-23 23:54:07.756420
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda v: v ** 2) == Left(2)
    assert Left(2).map(lambda v: v + 2) == Left(2)
    assert Left(None).map(lambda v: v + 2) == Left(None)
    assert Left(False).map(lambda v: None if v else [1, 2]) == Left(False)



# Generated at 2022-06-23 23:54:10.025683
# Unit test for method case of class Either
def test_Either_case():
    assert Left(2).case(lambda x: x + 1, lambda x: x + 2) == 3
    assert Right(2).case(lambda x: x + 1, lambda x: x + 2) == 4


# Generated at 2022-06-23 23:54:12.400125
# Unit test for method bind of class Right
def test_Right_bind():
    def fn(x):
        return Right(2 * x)

    assert Right(3).bind(fn) == Right(6)



# Generated at 2022-06-23 23:54:18.675912
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Test ap method of Either monad.
    """
    assert Right(5).ap(Right(lambda x: x + 2)) == Right(7)



# Generated at 2022-06-23 23:54:21.221000
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(2)



# Generated at 2022-06-23 23:54:22.614067
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x**2) == Left(1)


# Generated at 2022-06-23 23:54:25.469427
# Unit test for method case of class Either
def test_Either_case():
    def error_handler(error): return 'error handler'
    def success_handler(success): return 'success handler'

    assert Right(1).case(error_handler, success_handler) == 'success handler'
    assert Left(1).case(error_handler, success_handler) == 'error handler'


# Generated at 2022-06-23 23:54:32.714240
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(True).is_right() == False
    assert Left(False).is_right() == False
    assert Right(True).is_right() == True
    assert Right(False).is_right() == True


# Generated at 2022-06-23 23:54:34.912459
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 1) == Right(3)



# Generated at 2022-06-23 23:54:39.826947
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    excepted_left = Left(5)
    mapper = lambda x: Right(x * 10)

    # When: Call method bind
    binded_result = excepted_left.bind(mapper)

    # Then:
    assert binded_result == Left(5)



# Generated at 2022-06-23 23:54:46.961192
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1)
    left = right.bind(lambda value: Left(value))
    assert left.is_left()
    assert isinstance(left, Either)
    assert isinstance(left, Left)
    assert left.value == 1
    right = right.bind(lambda value: Right(value))
    assert right.is_right()
    assert isinstance(right, Either)
    assert isinstance(right, Right)
    assert right.value == 1



# Generated at 2022-06-23 23:54:49.724247
# Unit test for method bind of class Right
def test_Right_bind():
    right_monad = Right(1)
    right_monad_result = right_monad.bind(lambda x: Right(x * 2))
    assert isinstance(right_monad_result, Right)
    assert right_monad_result.value == 2


# Generated at 2022-06-23 23:54:52.487834
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Either(1).is_right(), bool)


# Generated at 2022-06-23 23:54:53.784673
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-23 23:54:54.758104
# Unit test for method bind of class Right
def test_Right_bind():
    """Test Right bind."""
    from pymonet.functions import identity

    assert Right(1).bind(identity) == 1

# Generated at 2022-06-23 23:54:56.131826
# Unit test for method to_box of class Either
def test_Either_to_box():
    """ Unit test for method to_box of class Either """

    assert Either(1).to_box().is_just()
    assert Either(1).to_box().unbox() == 1



# Generated at 2022-06-23 23:55:02.290381
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-23 23:55:04.187039
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(5)
    assert left.to_validation() == Validation.fail([5])


# Generated at 2022-06-23 23:55:08.829068
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(lambda x: x)
    # When
    result = left.bind(lambda x: x(5))
    # Then
    assert result == left


# Generated at 2022-06-23 23:55:11.776031
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)

# Generated at 2022-06-23 23:55:14.605168
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Left(20)) == Try(20, is_success=False)
    assert Either.to_try(Right(20)) == Try(20, is_success=True)


# Generated at 2022-06-23 23:55:16.156999
# Unit test for method map of class Left
def test_Left_map():
    assert Left(5).map(lambda x: x * 2) == Left(5)



# Generated at 2022-06-23 23:55:18.523147
# Unit test for method to_box of class Either
def test_Either_to_box():
    left = Either.left(None)
    right = Either.right(None)

    assert left.to_box().is_empty()
    assert right.to_box().is_full()


# Generated at 2022-06-23 23:55:20.121908
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right
    assert Right(False).is_right



# Generated at 2022-06-23 23:55:25.343001
# Unit test for constructor of class Right
def test_Right():
    assert(Right(1) == Right(1))
    assert(Right(1) != Left(1))
    assert(Right(1).is_right())
    assert(not Right(1).is_left())
    assert(str(Right(1)) == 'Right(1)')
    assert(Right(1).value == 1)


# Generated at 2022-06-23 23:55:28.518064
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(2).to_validation().is_success()
    assert not Right(2).to_validation().is_failure()
    try:
        assert Right(2).to_validation().get == 2
    except AssertionError:
        raise


# Generated at 2022-06-23 23:55:29.748377
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:55:32.871821
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Right(1) == Right(2)

test_Either___eq__()

# Generated at 2022-06-23 23:55:36.412676
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right('a').to_maybe() == Maybe.just('a')


# Generated at 2022-06-23 23:55:38.047249
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left("value")
    assert left.bind(lambda x: Right("mapper")) == left


# Generated at 2022-06-23 23:55:40.002253
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().f() == 1
    assert Right(2).to_lazy().f() == 2


# Generated at 2022-06-23 23:55:40.871115
# Unit test for method to_try of class Either
def test_Either_to_try():
    pass



# Generated at 2022-06-23 23:55:43.287071
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:55:46.794092
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Left('something bad happened').to_box() == Box(None)
    assert Right('something happened').to_box() == Box('something happened')


# Generated at 2022-06-23 23:55:49.265371
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(1)
    validation = right.to_validation()
    assert validation.value == 1
    assert validation.errors == []


# Generated at 2022-06-23 23:55:54.761729
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert isinstance(Right(None).is_right(), bool)


# Generated at 2022-06-23 23:55:56.257256
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(2).is_left()


# Generated at 2022-06-23 23:55:58.899804
# Unit test for method is_right of class Either
def test_Either_is_right():
    some = Right(10)
    none = Left(None)
    assert(some.is_right() is True)
    assert(none.is_right() is False)



# Generated at 2022-06-23 23:56:01.341122
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Right(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-23 23:56:03.916503
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:56:09.651940
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(50)
    assert right.is_right() is True


# Generated at 2022-06-23 23:56:15.246869
# Unit test for method bind of class Right
def test_Right_bind():
    def add_one(val: int) -> int:
        return val + 1

    def create_right(val: int) -> Either:
        return Right(val)

    assert Right(1).bind(add_one) == 2
    assert Right(1).bind(create_right) == Right(1)


# Generated at 2022-06-23 23:56:16.311684
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(2)

    assert False == left.is_right()


# Generated at 2022-06-23 23:56:20.147712
# Unit test for constructor of class Right
def test_Right():
    assert Right(True)
    assert Right(True) == Right(True)
    assert Right(False) != Right(True)
    assert Right(True) != Left(True)
    assert Right(False) != Left(False)
    assert Right(True) == Right(True)
    assert Right(False) == Right(False)
    assert Right(1) == Right(1)
    assert Right(2) == Right(2)
    assert Right(1) != Right(2)
    assert Right(2) != Right(1)


# Generated at 2022-06-23 23:56:21.435975
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:56:23.964255
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Right's bind should return right instance with the same value.
    """
    a = Right(5)
    b = a.bind(lambda x: x)
    assert isinstance(b, Right)
    assert b.value == 5



# Generated at 2022-06-23 23:56:25.701397
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda arg: arg + 1) == Left(1)



# Generated at 2022-06-23 23:56:27.578908
# Unit test for method bind of class Left
def test_Left_bind():
    val = Left(1)
    assert val.bind(lambda x: Right(x + 1)) == Left(1)



# Generated at 2022-06-23 23:56:30.106294
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    def _add(x):
        return x + 1

    # When
    result = Right(1).ap(Right(_add))

    # Then
    assert result == Right(2)



# Generated at 2022-06-23 23:56:30.960692
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(10).is_right() == False
    assert Right(10).is_right() == True


# Generated at 2022-06-23 23:56:32.956776
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Unit test for method __eq__ of class Either.
    """
    # return None
    return None


# Generated at 2022-06-23 23:56:36.976945
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right

    assert Lazy(lambda: 666) == Either(666).to_lazy()
    assert Lazy(lambda: 'math') == Left('math').to_lazy()
    assert Lazy(lambda: 666) == Right(666).to_lazy()



# Generated at 2022-06-23 23:56:39.262769
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: x + 1) == Left(3)



# Generated at 2022-06-23 23:56:40.908243
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)

    assert left.bind(lambda x: Right(1)) == left


# Generated at 2022-06-23 23:56:46.620744
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x * 2)) == Left(1)



# Generated at 2022-06-23 23:56:48.365545
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: 2 * x)) == Left(1)
    assert Left(1).ap(Right(lambda x: 2 * x)) == Left(1)

# Generated at 2022-06-23 23:56:50.164189
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    import pytest

    from pymonet.maybe import Maybe

    assert Maybe.just(2) == Right(2).to_maybe()



# Generated at 2022-06-23 23:56:52.135192
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.box import Box

    assert Right(3).map(lambda x: x + 1) == Right(4)
    assert Right(3).map(Box) == Right(Box(3))



# Generated at 2022-06-23 23:56:54.497472
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([5]) == Left(5).to_validation()



# Generated at 2022-06-23 23:56:55.803425
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(10).to_box() == Box(10)
    assert Right(10).to_box() == Box(10)

# Generated at 2022-06-23 23:57:00.199864
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)

    assert left.is_right() is False
    assert left.is_left() is True
    assert left.case(len, str) == 1
    assert left.ap(Left(2)) == Left(2)
    assert left.to_box().is_some() is False
    assert left.to_try().is_success() is False
    assert left.to_maybe().is_some() is False
    assert left.to_validation().is_failure() is True


# Generated at 2022-06-23 23:57:02.001603
# Unit test for method is_right of class Either
def test_Either_is_right():
    """Test method is_right of class Either."""
    assert Either(1).is_right() is False


# Generated at 2022-06-23 23:57:03.245425
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)
    assert left.value == 1
    assert right.value == 1


# Generated at 2022-06-23 23:57:11.719321
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.functor import Functor
    from pymonet.box import Box
    r = Left(5)
    f1 = Functor(Box)
    f2 = Functor(Box)
    f3 = Functor(Box)
    assert f1.map(r.value, lambda x: x + 1).value() == (6)
    assert f2.map(r.value, lambda x: x ** 2).value() == (25)
    assert f3.map(r.value, lambda x: x ** 3).value() == (125)



# Generated at 2022-06-23 23:57:12.374856
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Eith

# Generated at 2022-06-23 23:57:15.723600
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(2).to_validation() == Validation.fail([2])
    assert Left([1, 2, 3]).to_validation() == Validation.fail([[1, 2, 3]])



# Generated at 2022-06-23 23:57:17.247203
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(2)

    assert left.is_left()


# Generated at 2022-06-23 23:57:21.816767
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:57:26.714261
# Unit test for method bind of class Left
def test_Left_bind():
    """
    Unit test for bind function of Left class.


    """
    # pylint: disable=import-outside-toplevel
    import pytest

    left = Left(None)
    right = right = Right(None)

    def mapper(value: object) -> Either:
        return right

    assert left.bind(mapper) == left



# Generated at 2022-06-23 23:57:29.123498
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    right = Right(1)
    assert right.to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:57:33.274813
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right() is True
    assert Right("").is_right() is True
    assert Right([]).is_right() is True
    assert Right({}).is_right() is True
    assert Right(()).is_right() is True
    assert Right(True).is_right() is True
    assert Right(None).is_right() is True
    assert Right(Exception).is_right() is True
    assert Right(Exception("")) is True


# Generated at 2022-06-23 23:57:37.291849
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(5).to_lazy().value() == 5
    assert Left(5).to_lazy().value() == 5



# Generated at 2022-06-23 23:57:40.901700
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left('Left') == Left('Left')
    assert Right(1) != Left('Left')
    assert Left('Left') != Right(1)



# Generated at 2022-06-23 23:57:42.731279
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(5) != Right(5)

# Generated at 2022-06-23 23:57:46.067259
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Right(10).is_right(), bool) and Right(10).is_right()
    assert isinstance(Left(10).is_right(), bool) and not Left(10).is_right()


# Generated at 2022-06-23 23:57:47.824508
# Unit test for method map of class Left
def test_Left_map():
    assert isinstance(Left(1).map(lambda x: x + 2), Left)


# Generated at 2022-06-23 23:57:52.866831
# Unit test for method map of class Left
def test_Left_map():
    to_square = lambda x: x ** 2
    left_value = Left(5)
    assert left_value.map(to_square) == Left(5)
    assert left_value.value == 5


# Generated at 2022-06-23 23:57:55.616811
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(9)
    assert left.bind(lambda val: assert_equal(val, 9)) is left

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:57:59.903492
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-23 23:58:02.900343
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(5)
    left.bind(lambda x: Left(x))

    # When
    result = left.value

    # Then
    assert result == 5


# Generated at 2022-06-23 23:58:04.070390
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left("error").ap(Left("error2")) == Left("error")

# Generated at 2022-06-23 23:58:06.094098
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right("test").to_maybe() == Maybe.just("test")


# Generated at 2022-06-23 23:58:09.775562
# Unit test for constructor of class Left
def test_Left():
    left = Left(2)
    assert left.value == 2
    assert left.is_right() is False
    assert left.is_left() is True



# Generated at 2022-06-23 23:58:18.038422
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(Error.from_exception(Exception('Message'))).to_try() == Try.fail(Exception('Message'))
    assert Left(Error.from_exception(Exception('Message'))).to_try() == Try.fail(Exception('Message'))
    assert Right('value').to_try() == Try.success('value')
    assert Right('value').to_try() == Try.success('value')



# Generated at 2022-06-23 23:58:22.001030
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(2).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:58:23.829728
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(4).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:58:26.866515
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x + 1) == Left(2)


# Generated at 2022-06-23 23:58:30.445324
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    assert Right(2).ap(Box(lambda x: x + 2)) == Right(4)
    assert Left("error").ap(Box(lambda x: x + 2)) == Left("error")


# Generated at 2022-06-23 23:58:32.485901
# Unit test for method is_left of class Left
def test_Left_is_left():
    x = Left(1)
    assert x.is_left() is True
    assert x.is_right() is False


# Generated at 2022-06-23 23:58:36.170695
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(12)

    assert left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:58:37.131358
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-23 23:58:39.021901
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(2)
    result = left.is_right()
    expected = False
    assert expected == result



# Generated at 2022-06-23 23:58:45.168788
# Unit test for constructor of class Either
def test_Either():
    """
    :returns: True if no raises any exception
    :rtype: Boolean
    """
    def test_Either_1():
        """
        :returns: True if no raises any exception
        :rtype: Boolean
        """
        return Left(5)

    def test_Either_2():
        """
        :returns: True if no raises any exception
        :rtype: Boolean
        """
        return Right(5)
    return test_Either_1() and test_Either_2()



# Generated at 2022-06-23 23:58:47.382330
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(123).to_box() == Box(123)
    assert Right(123).to_box() == Box(123)


# Generated at 2022-06-23 23:58:52.710014
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left('aaa')

    assert(left.to_validation() == Validation.fail(['aaa']))



# Generated at 2022-06-23 23:58:58.397675
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) is not Either(1)
    assert Either(1) == Left(1)
    assert Either(1) is not Left(1)
    assert Either(1) == Right(1)
    assert Either(1) is not Right(1)
    assert Either(1).__str__() == "Either(1)"
    assert Either(1).__repr__() == "Either(1)"
    assert Either(1).case(_, _)(lambda x: x)(lambda x: x) == 1


# Generated at 2022-06-23 23:59:00.771197
# Unit test for method is_right of class Left
def test_Left_is_right():
    left_fixture = Left(1)

    assert left_fixture.is_right() == False


# Generated at 2022-06-23 23:59:06.412893
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Success, SuccessfulFunc, Validation

    success = Validation(SuccessfulFunc())

    assert Right(success).to_validation() == Success(success)

# Generated at 2022-06-23 23:59:08.599153
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    either = left.map(lambda value: value + 2)

    assert isinstance(either, Left)
    assert either == left


# Generated at 2022-06-23 23:59:10.786144
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    right_value = Right('some_value')
    validation_result = right_value.to_validation()
    assert isinstance(validation_result, Validation), 'Invalid type of result'
    assert validation_result == Validation.success('some_value')


# Generated at 2022-06-23 23:59:11.990287
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().evaluate() == 1
    assert Right(2).to_lazy().evaluate() == 2


# Generated at 2022-06-23 23:59:14.220703
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right('abc').to_maybe() == Maybe.just('abc')


# Generated at 2022-06-23 23:59:16.378709
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:59:19.553048
# Unit test for constructor of class Either
def test_Either():
    assert Right(10) == Right(10)
    assert Left(10) == Left(10)
    assert Right(10) != Right(20)
    assert Left(10) != Left(20)


# Generated at 2022-06-23 23:59:20.322110
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(10).bind(_ * 2) == Left(10)


# Generated at 2022-06-23 23:59:21.869591
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(3).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:59:28.149159
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for method bind of class Right.

    Asserts:
        Right[A].bind(Function(A) -> Either[B]) -> Either[B]
    """
    from pymonet.monad_try import Try

    x = Right(1)
    assert x.bind(lambda y: Try(y, is_success=True)) == Try(1, True)

# Generated at 2022-06-23 23:59:33.194080
# Unit test for method case of class Either
def test_Either_case():

    def right_success(value):
        return value.upper()

    def left_fail(value):
        return value.upper()

    assert Right(1).case(left_fail, right_success) == 1
    assert Left(1).case(left_fail, right_success) == 1



# Generated at 2022-06-23 23:59:35.046110
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda v: v+1) == Right(2)


# Generated at 2022-06-23 23:59:38.211955
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.maybe import Maybe

    assert Maybe(1).map(lambda x: x + 1).to_either().is_right()
    assert Maybe(None).map(lambda x: 1 / 0).to_either().is_right() is False


# Generated at 2022-06-23 23:59:40.235819
# Unit test for constructor of class Either
def test_Either():
    """
    Test constructor of class Either

    >>> import pymonet.either as E
    >>> e = E.Either(True)
    >>> isinstance(e, E.Left)
    True
    """



# Generated at 2022-06-23 23:59:44.571526
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([1, 2, 3]) == Left(1).to_validation()



# Generated at 2022-06-23 23:59:47.030399
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Test method to_validation of class Right

    >>> right_validation = Right('test').to_validation()
    >>> right_validation.is_success()
    True
    >>> right_validation.get_value()
    'test'
    """
    pass

# Generated at 2022-06-23 23:59:50.428676
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(5)

    assert left.is_right() == False


# Generated at 2022-06-23 23:59:52.173000
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)



# Generated at 2022-06-23 23:59:57.060344
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:00:00.715529
# Unit test for method is_left of class Right
def test_Right_is_left():
    # Given
    right = Right('right')

    # When
    result = right.is_left()

    # Then
    assert not isinstance(result, bool), 'Result must be boolean'
    assert not result, 'Right must not be Left'



# Generated at 2022-06-24 00:00:08.207604
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Either(1)
    assert Right(1).value == 1
    assert Right(None).value is None
    assert Right(1).is_right() is True
    assert Right(1).is_left() is False
    assert Right(1).bind(lambda v: Right(v + 1)).value == 2
    assert Right(1).map(lambda v: v + 1).value == 2
    assert Right(1).ap(Right(lambda v: v + 1)).value == 2
    assert Right(1).to_box().value == 1
    assert Right(1).to_try().value == 1
    assert Right(1).to_lazy().value() == 1
    assert Right(1).to_maybe().value == 1
    assert Right(None).to_maybe().value is None
    assert Right(1).to_

# Generated at 2022-06-24 00:00:09.204873
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)

# Generated at 2022-06-24 00:00:10.382917
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() == False


# Generated at 2022-06-24 00:00:12.721899
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert isinstance(Left(None), Either) is True, "Left it's not subclass of Either"
    assert Left(None).is_left() is True, "Left is not left"



# Generated at 2022-06-24 00:00:16.081613
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.instance.functor import FunctorInstance

    def mapper(a) -> 'Either[int]':
        return Right(a + 1)

    left = Left(1)
    result = left.bind(mapper)
    assert result == left



# Generated at 2022-06-24 00:00:18.271100
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left("left")
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-24 00:00:19.432734
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-24 00:00:24.236586
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(3).to_validation() == Validation([3], [])


# Generated at 2022-06-24 00:00:25.390563
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Left(lambda x: x ** 2)) == Left(2)



# Generated at 2022-06-24 00:00:28.458420
# Unit test for method ap of class Either
def test_Either_ap():
    assert (Left(1).ap(Left(lambda x: x + 2)) == Left(1))
    assert (Left(1).ap(Right(lambda x: x + 2)) == Left(1))
    assert (Right(1).ap(Left(lambda x: x + 2)) == Left(2))
    assert (Right(1).ap(Right(lambda x: x + 2)) == Right(3))



# Generated at 2022-06-24 00:00:31.806091
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1)

    assert right.to_maybe() == 1

# Generated at 2022-06-24 00:00:33.348601
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(2)
    assert right.to_validation() == Validation.success(2)



# Generated at 2022-06-24 00:00:35.423162
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x)) == Left(2)
    assert Left(2).bind(lambda x: Left(x)) == Left(2)



# Generated at 2022-06-24 00:00:38.761862
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    error = ['error']
    left = Left(error)

    # When
    result = left.to_validation()

    # Then
    assert result.is_fail()
    assert result.failure == error


# Generated at 2022-06-24 00:00:43.042101
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left

    result = Left('Error')
    assert result.to_validation() == Validation.fail(['Error'])


# Generated at 2022-06-24 00:00:48.446238
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Left(1).to_box() == Box(1)
    assert Left(1).to_box().is_empty() is True
    assert Right(2).to_box() == Box(2)
    assert Right(2).to_box().is_empty() is False

# Generated at 2022-06-24 00:00:55.401408
# Unit test for method ap of class Either
def test_Either_ap():
    left = Either.left('error')
    right = Either.right(1)
    assert left.ap(Either.left('error')) == Either.left('error')
    assert left.ap(Either.right(1)) == Either.left('error')
    assert right.ap(Either.left('error')) == Either.left('error')
    assert right.ap(Either.right(lambda x: x*2)) == Either.right(2)


# Generated at 2022-06-24 00:00:56.729314
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True



# Generated at 2022-06-24 00:00:59.194480
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-24 00:01:02.346227
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.validation import Validation

    assert Left('').ap(Validation.fail('')) == Left('')


# Generated at 2022-06-24 00:01:10.711563
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(10).to_try() == Try(10, is_success=True)
    assert Either(10).to_try() == Try(10, is_success=True)
    assert Either([10]).to_try() == Try([10], is_success=True)
    assert Either(Exception()).to_try() == Try(Exception(), is_success=False)
    assert Either(Exception()).to_try() == Try(Exception(), is_success=False)
    assert Either([Exception()]).to_try() == Try([Exception()], is_success=False)



# Generated at 2022-06-24 00:01:15.242328
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    value = 12
    assert Left(value).to_validation() == Validation.fail([value])


# Generated at 2022-06-24 00:01:16.875162
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:01:18.130537
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x + 1) == Left(2)



# Generated at 2022-06-24 00:01:19.416784
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('').is_right() is False


# Generated at 2022-06-24 00:01:20.983569
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda x: x + '1') == Left('error')


# Generated at 2022-06-24 00:01:24.105583
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either(5).map(lambda x: x + 2).to_lazy() == Lazy(lambda: 7)


# Generated at 2022-06-24 00:01:30.084100
# Unit test for method map of class Right
def test_Right_map():
    from math import sqrt
    from pymonet.maybe import Maybe

    assert Right(4).map(lambda x: sqrt(x)) == Right(2)
    assert Right(4).map(lambda x: Maybe.just(sqrt(x))) == Maybe.just(2)



# Generated at 2022-06-24 00:01:31.581787
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:35.016717
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)


# Generated at 2022-06-24 00:01:36.752339
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.nothing() == Left(0).to_maybe()


# Generated at 2022-06-24 00:01:37.569833
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right("something").is_left()



# Generated at 2022-06-24 00:01:39.196650
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(None).to_maybe()

# Generated at 2022-06-24 00:01:41.836228
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3
    assert Right('string') == Right('string')
    assert Right([1, 2, 3]) == Right([1, 2, 3])
    assert Right(1) == Right(1)



# Generated at 2022-06-24 00:01:45.671343
# Unit test for constructor of class Either
def test_Either():
    assert Left(True) == Left(True)
    assert Left(False) != Left(True)
    assert Right(True) == Right(True)
    assert Right(False) != Right(True)
    assert Right(True) != Left(True)
    assert Right(False) != Left(True)
    assert Left(True) != Right(True)
    assert Left(False) != Right(True)
    assert Left(0) != Right(0)



# Generated at 2022-06-24 00:01:48.285268
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right('Right').to_box() == Box('Right')
    assert Left('Left').to_box() == Box('Left')



# Generated at 2022-06-24 00:01:53.958350
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    test for method to_try of class Either
    """
    from pymonet.monad_try import Try

    assert Either(None).to_try() is Try.nothing()
    assert Left(None).to_try() is Try.nothing()
    assert Either(1).to_try() is Try.just(1)
    assert Right(1).to_try() is Try.just(1)


# Generated at 2022-06-24 00:01:56.858983
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert (Right(3).to_validation() == Validation((True, 3, [])))

# Generated at 2022-06-24 00:01:59.209510
# Unit test for method bind of class Left
def test_Left_bind():
    fn = lambda x: Right(x * 2)
    left = Left(2)
    assert left.bind(fn) == left



# Generated at 2022-06-24 00:02:01.737564
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(5).to_box() == Box(5)
    assert Left(5).to_box() == Box(5)


# Generated at 2022-06-24 00:02:03.640518
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda val: Left(val + 10)) == Left(1)
    assert Left(1).bind(lambda val: Right(val + 10)) == Left(1)


# Generated at 2022-06-24 00:02:05.993336
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Unit test for method to_maybe of class Left
    """

    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(None).to_maybe()


# Generated at 2022-06-24 00:02:07.619550
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    pass
    """
    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-24 00:02:10.764545
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x * 2) == Right(2)



# Generated at 2022-06-24 00:02:11.855331
# Unit test for constructor of class Right
def test_Right():
    right_value = Right(1)
    assert right_value.value == 1



# Generated at 2022-06-24 00:02:13.788637
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x * x) == Right(4)



# Generated at 2022-06-24 00:02:15.218058
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('Python').is_left() == False


# Generated at 2022-06-24 00:02:16.792761
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() is False



# Generated at 2022-06-24 00:02:18.434522
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left("error")

    assert left.to_validation() == Validation.fail(["error"])



# Generated at 2022-06-24 00:02:19.203577
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("test").is_left()



# Generated at 2022-06-24 00:02:23.608933
# Unit test for constructor of class Either
def test_Either():
    assert Left("left") == Left("left")

    assert Left("left").case(lambda e: e, lambda s: s) == "left"
    assert Right("right").case(lambda e: e, lambda s: s) == "right"

    assert isinstance(Left("left"), Left)
    assert isinstance(Right("right"), Right)


# Generated at 2022-06-24 00:02:25.491314
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either.is_right(Right(3))
    assert not Either.is_right(Left(3))


# Generated at 2022-06-24 00:02:26.850769
# Unit test for constructor of class Left
def test_Left():
    """Test constructor of class Left"""
    assert Left(1) == Left(1)



# Generated at 2022-06-24 00:02:28.513257
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-24 00:02:31.888167
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right('value')
    result = right.bind(lambda x: Either.right(x + 1))
    assert result == Right(1)



# Generated at 2022-06-24 00:02:38.442034
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(2)

    # Test for Equals of two monads
    assert Right(1).to_try() == Right(1).to_try()
    assert Left(1).to_try() != Right(1).to_try()

    # Test for Equals of monad and other type
    assert Right(1).to_try() != 0
    assert Left(1).to_try() != 0



# Generated at 2022-06-24 00:02:41.778170
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(2).is_right() == True


# Generated at 2022-06-24 00:02:43.842142
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(0).bind(lambda x: Right(x + 1)) == Left(0)



# Generated at 2022-06-24 00:02:48.524901
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet import Lazy
    from pymonet.either import Either, Left, Right

    assert Either(None) == Either(None)
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)

    assert Right(10) != Left('error')
    assert Left(10) != Right('error')
    assert Right(10) != 10
    assert Left(10) != "Hello"

    assert Left(Lazy(lambda: (10))) == Left(Lazy(lambda: (10)))
    assert Right(Lazy(lambda: (10))) == Right(Lazy(lambda: (10)))



# Generated at 2022-06-24 00:02:53.163875
# Unit test for method ap of class Left
def test_Left_ap():
    """
    Test ap method on Left class.

    :returns: True if test passes, raise AssertionError otherwise
    :rtype: Boolean
    """
    assert Left([]).ap(Left([])) == Left([])
    return True


# Generated at 2022-06-24 00:02:56.656622
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right('test').to_maybe() == Maybe.just('test')



# Generated at 2022-06-24 00:03:00.208131
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Test Default Either to Try monad
    """
    assert Either.to_try(Right(True)) == Try(True, is_success=True)
    assert Either.to_try(Left(False)) == Try(False, is_success=False)


# Generated at 2022-06-24 00:03:04.319257
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def bind_function(value):
        return Maybe.just(Try(2))

    right_value = Right(1)
    right_value_after_bind = right_value.bind(bind_function)
    assert right_value_after_bind == Maybe.just(Try(2))

# Generated at 2022-06-24 00:03:12.368500
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()
    x = Right(1)
    assert x.is_right()
    x = Right(1.5)
    assert x.is_right()
    x = Right(1 + 5j)
    assert x.is_right()
    x = Right("test")
    assert x.is_right()
    x = Right([1, 2, 3])
    assert x.is_right()
    x = Right((1, 2, 3))
    assert x.is_right()
    x = Right({'a': 1, 'b': 2})
    assert x.is_right()



# Generated at 2022-06-24 00:03:18.258333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    box = Box(42)
    try_ = Try(42)
    either = Right(42)

    assert any(isinstance(element, Lazy) for element in [box.to_lazy(), try_.to_lazy(), either.to_lazy()])
    assert all(element.value() == 42 for element in [box.to_lazy(), try_.to_lazy(), either.to_lazy()])



# Generated at 2022-06-24 00:03:22.050659
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Test method to_validation of class Left.

    :returns: True if test passed
    :rtype: boolean
    """

    from pymonet.validation import Validation

    left = Left(1)
    assert left.to_validation() == Validation.fail([1])



# Generated at 2022-06-24 00:03:25.956117
# Unit test for constructor of class Right
def test_Right():
    """
    Test constructor of class Right

    >>> test_Right()
    Right(2)
    """
    return Right(2)



# Generated at 2022-06-24 00:03:27.348524
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(10).is_right()


# Generated at 2022-06-24 00:03:28.614500
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == False


# Generated at 2022-06-24 00:03:29.762461
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(2).is_left() == False


# Generated at 2022-06-24 00:03:32.611996
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(42).to_box().value == 42
    assert Left(42).to_box().value == 42


# Generated at 2022-06-24 00:03:35.985937
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_try import Try

    def mapper(_):
        return Try(1, True)

    assert Left('I am error').bind(mapper) == Left('I am error')



# Generated at 2022-06-24 00:03:45.532689
# Unit test for constructor of class Right
def test_Right():
    assert isinstance(Right(3).ap(Right(lambda x: x * 2)), Right)
    assert Right(3) == Right(3)
    assert str(Right(3)) == "Right(3)"
    assert repr(Right(3)) == "Right(3)"
    assert Right(3).bind(lambda x: Right(x * 2)) == Right(6)
    assert Right(3).case(
        lambda _: None, lambda a: a * 2) == 6
    assert Right(3).ap(Right(lambda x: x * 2)).is_right()
    assert Right(3).to_try().is_success()
    assert Right(3).to_lazy().get_value() == 3
    assert Right(3).to_maybe().is_just()
    assert Right(3).to_validation().is_success()


# Generated at 2022-06-24 00:03:52.368247
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    # GIVEN Successful value
    right_value = Right(5)

    # WHEN to_maybe is called
    result = right_value.to_maybe()

    # THEN result is Maybe with Right value
    assert isinstance(result, Maybe)
    assert result.is_just()
    assert isinstance(result.value, int)
    assert result.value == 5

