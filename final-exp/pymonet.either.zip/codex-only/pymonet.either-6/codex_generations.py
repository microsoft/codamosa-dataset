

# Generated at 2022-06-23 23:53:51.409306
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(5).to_validation() == Validation.fail([5])



# Generated at 2022-06-23 23:53:55.523192
# Unit test for constructor of class Right
def test_Right():
    # Given
    _value = 123
    # When
    _right = Right(_value)
    # Then
    assert _right.value == _value


# Generated at 2022-06-23 23:53:59.728567
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    >>> right = Either.right(1)
    >>> right
    Either.Right(value=1)
    >>> right.to_box()
    Box(1)
    >>> left = Either.left(2)
    >>> left
    Either.Left(value=2)
    >>> left.to_box()
    Box(2)
    """
    pass



# Generated at 2022-06-23 23:54:01.240342
# Unit test for constructor of class Either
def test_Either():
    from pymonet.test_util import assert_equals

    assert_equals(Left('value'), Left('value'))

# Generated at 2022-06-23 23:54:03.538895
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    unit = Left(0)
    assert unit.to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:54:08.959820
# Unit test for method case of class Either
def test_Either_case():
    """
    Test if after calling case method of Left monad with the same fst and snd args
    the result will be the same as the result of fst.
    """
    # fst == snd
    assert Left(10).case(lambda value: value, lambda value: value) == 10



# Generated at 2022-06-23 23:54:11.044118
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:54:13.611439
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(0).is_left() is False, 'is_left() method of Right class return True'


# Generated at 2022-06-23 23:54:16.665101
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:54:18.893379
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    result = Right(2).to_validation()
    assert result == Validation.success(2)

# Generated at 2022-06-23 23:54:25.237597
# Unit test for method map of class Left
def test_Left_map():
    assert Left(10).map(lambda x: x).value == 10



# Generated at 2022-06-23 23:54:28.299966
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left("error")
    right = Right(lambda x: x)

    assert(left.ap(right) == left)



# Generated at 2022-06-23 23:54:29.759263
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3
    assert type(Right(3)) == Right


# Generated at 2022-06-23 23:54:31.210029
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True


# Generated at 2022-06-23 23:54:33.557278
# Unit test for method map of class Right
def test_Right_map():
    def g(x): return x + 1
    assert Right(1).map(g) == Right(2)



# Generated at 2022-06-23 23:54:35.581323
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:54:36.210063
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left("left").ap(Right("right")) == Left("left")


# Generated at 2022-06-23 23:54:39.177841
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(3).to_try() == Try(3, False)
    assert Right(3).to_try() == Try(3, True)


# Generated at 2022-06-23 23:54:40.577003
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(1)

    # When
    result = left.bind(lambda x: Right(x + 2))

    # Then
    assert result == Left(1)



# Generated at 2022-06-23 23:54:42.075898
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Either.Right(1).is_right() is True


# Generated at 2022-06-23 23:54:45.737940
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x) == Left(1)



# Generated at 2022-06-23 23:54:49.919932
# Unit test for constructor of class Left
def test_Left():
    # Given
    value = 2

    # When
    left = Left(value)

    # Then
    assert left.is_left() is True
    assert left.is_right() is False
    assert left.bind(lambda x: x) == value
    assert left.to_maybe() == Maybe.nothing()
    assert left.to_validation() == Validation.fail([value])



# Generated at 2022-06-23 23:54:51.140877
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-23 23:55:00.078330
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Left(1).ap(Lazy(lambda: 2)) == Left(1)
    assert Left(1).ap(Try(2)) == Left(1)
    assert Left(1).ap(Box(2)) == Left(1)
    assert Left(1).ap(Left(2)) == Left(1)
    assert Left(1).ap(Right(2)) == Left(1)
    assert Left(1).ap(Maybe.just(2)) == Left(1)
    assert Left(1).ap(Maybe.nothing()) == Left(1)

# Generated at 2022-06-23 23:55:02.955619
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda _: 2, lambda x: x) == 1
    assert Left('error').case(lambda x: x, lambda _: 2) == 'error'
    assert Right('right').case(lambda x: x, lambda x: x) == 'right'



# Generated at 2022-06-23 23:55:04.958140
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe, MaybeType

    assert Maybe.just(1) == Right(1).to_maybe()


# Generated at 2022-06-23 23:55:08.139458
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right is not None
    assert right.value == 1


# Generated at 2022-06-23 23:55:09.230141
# Unit test for constructor of class Left
def test_Left():
    assert isinstance(Left(None), Either)

# Generated at 2022-06-23 23:55:11.776738
# Unit test for method map of class Right
def test_Right_map():
    test_value = Right(2)
    result = test_value.map(lambda x: x + 2)
    assert result == Right(4)



# Generated at 2022-06-23 23:55:13.573584
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:55:14.483132
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)


# Generated at 2022-06-23 23:55:16.049323
# Unit test for method bind of class Left
def test_Left_bind():
    """Test bind method of class Left"""
    assert Left(1).bind(lambda u: u) == 1


# Generated at 2022-06-23 23:55:17.006086
# Unit test for constructor of class Left
def test_Left():
    instance = Left("test")
    assert isinstance(instance, Either)


# Generated at 2022-06-23 23:55:18.875321
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(123)
    assert left.bind(lambda value: Left(value)) == Left(123)



# Generated at 2022-06-23 23:55:20.514999
# Unit test for constructor of class Left
def test_Left():
    assert(Left(1).case(error=identity, success=const(2)) == 1)


# Generated at 2022-06-23 23:55:23.982939
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('message').to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:55:26.023921
# Unit test for method bind of class Right
def test_Right_bind():
    def add_one(value):
        return value + 1


    right = Right(1)
    assert right.bind(add_one) == 2



# Generated at 2022-06-23 23:55:28.853407
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(100).to_lazy() == Lazy(lambda: 100)
    assert Right(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-23 23:55:32.025494
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Box(3).to_either().to_box() == Box(3)
    assert Box(3).to_either().to_box().to_either() == Right(3)


# Generated at 2022-06-23 23:55:34.794286
# Unit test for constructor of class Either
def test_Either():
    def create_new_instance() -> None:
        Either(10)

    assert_raises(TypeError, create_new_instance)


# Generated at 2022-06-23 23:55:36.842565
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('123') == Left('123')
    assert Right(123) == Right(123)
    assert Left('123') != Right('123')

# Generated at 2022-06-23 23:55:40.501618
# Unit test for constructor of class Right
def test_Right():
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Right(Box(1)) == Right(Box(1))
    assert Right(Box(1)) != Left(Box(1))
    assert Right(Box(1)) != Right(Box(2))


# Generated at 2022-06-23 23:55:44.141833
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    val = Left("Error").to_validation()

    assert val == Validation.fail(["Error"])


# Generated at 2022-06-23 23:55:46.480512
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    e = Right(1)
    assert e.to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:55:48.684099
# Unit test for method map of class Right
def test_Right_map():
    mapper = lambda value: value * 2
    assert Right(2).map(mapper) == Right(4)


# Generated at 2022-06-23 23:55:50.873033
# Unit test for method is_right of class Right
def test_Right_is_right():
    either = Right(3)
    assert either.is_right()


# Generated at 2022-06-23 23:55:54.162840
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right1 = Right('a')
    right2 = Right('a')
    left1 = Left(3)
    left2 = Left(3)
    assert right1 == right2
    assert left1 == left2


# Generated at 2022-06-23 23:55:58.079952
# Unit test for method map of class Right
def test_Right_map():
    assert Right(10).map(lambda x: x + 2) == Right(12)
    assert not Right(10).map(lambda x: x + 2) == Right(10)
    assert Right(10).map(lambda x: x + 2).value == 12


# Generated at 2022-06-23 23:56:01.358346
# Unit test for method map of class Left
def test_Left_map():
    assert Left('a').map(lambda value: value + 'b') == Left('a')



# Generated at 2022-06-23 23:56:03.916339
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-23 23:56:05.515130
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('').is_right()


# Generated at 2022-06-23 23:56:10.426205
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """Test Right.to_maybe method"""
    from pymonet.maybe import Maybe

    value = "foo"
    e = Right(value)
    assert e.to_maybe() == Maybe.just(value)



# Generated at 2022-06-23 23:56:11.428422
# Unit test for method is_right of class Left
def test_Left_is_right():

    assert Left('test').is_right() is False


# Generated at 2022-06-23 23:56:12.832517
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(None).is_right() is True


# Generated at 2022-06-23 23:56:14.218020
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:56:15.349019
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left("test").is_right()


# Generated at 2022-06-23 23:56:17.884915
# Unit test for constructor of class Either
def test_Either():
    """Assert that Either is abstrat class."""
    with pytest.raises(TypeError):
        Left(None)
    with pytest.raises(TypeError):
        Right(None)



# Generated at 2022-06-23 23:56:24.818726
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(3).__eq__(Left(3))
    assert Left(3).__eq__(Left('3'))
    assert not Left(3).__eq__(None)
    assert not Left(3).__eq__(Right(None))
    assert not Left(3).__eq__(Right(3))
    assert Right(3).__eq__(Right(3))
    assert Right(3).__eq__(Right('3'))
    assert not Right(3).__eq__(None)
    assert not Right(3).__eq__(Left(3))
    assert Right(3).__eq__(Right(3))



# Generated at 2022-06-23 23:56:27.105645
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(3) == Left(3)
    assert Right(3) == Right(3)
    assert not Right(3) == Left(3)
    assert not Left(3) == Right(3)
    assert not Left(1) == Left(2)
    assert not Right(1) == Right(2)

# Generated at 2022-06-23 23:56:28.869102
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(10).to_validation() == Validation.fail([10])


# Generated at 2022-06-23 23:56:29.918609
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:56:33.398817
# Unit test for method ap of class Either
def test_Either_ap():
    import pytest

    # Test Left ap
    x = Left("error")
    y = Left("error")

    def f(z):
        return z.upper()

    x.ap(f) == x

    # Test Right ap
    x = Right("right")

    x.ap(f) == Right("RIGHT")

    # Test Right ap with Left monad
    x = Right("right")
    y = Left("error")

    x.ap(y) == Left("error")

# Generated at 2022-06-23 23:56:37.985556
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Unit tests for to_try method

    :returns: result of tests
    :rtype: Boolean
    """
    from pymonet.try_monad import Try
    right = Right(1)
    left = Left(0)

    assert right.to_try() == Try(1)
    assert right.to_try().is_success
    assert left.to_try() == Try(0, is_success=False)
    assert not left.to_try().is_success

    return True



# Generated at 2022-06-23 23:56:40.116580
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)



# Generated at 2022-06-23 23:56:45.126318
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Right(Box(Lazy(lambda: 1))).to_lazy() == Lazy(lambda: Box(Lazy(lambda: 1)))
    assert Left(Box(Lazy(lambda: 1))).to_lazy() == Lazy(lambda: Box(Lazy(lambda: 1)))


# Generated at 2022-06-23 23:56:46.065431
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(4).is_left()



# Generated at 2022-06-23 23:56:47.343268
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(True).is_left() is False

# Generated at 2022-06-23 23:56:49.643572
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:56:51.190381
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either"""
    assert Either('hi').case(lambda e: e, lambda s: s) == 'hi'



# Generated at 2022-06-23 23:56:55.167323
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-23 23:57:00.008509
# Unit test for constructor of class Either
def test_Either():
    assert Either('test') == Left('test')
    assert Either('test') != Right('test')



# Generated at 2022-06-23 23:57:03.656342
# Unit test for method ap of class Either
def test_Either_ap():
    success = Right(lambda x: x + 1)
    assert success.ap(Right(1)) == Right(2)
    error = Left('e')
    assert error.ap(Right(1)) == Left('e')
    assert error.ap(Left('a')) == Left('e')

# Generated at 2022-06-23 23:57:05.214701
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:57:07.184139
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)

# Generated at 2022-06-23 23:57:11.032933
# Unit test for method map of class Left
def test_Left_map():
    assert Left(None).map(lambda x: x).case(lambda left: left, lambda right: right) is None


# Generated at 2022-06-23 23:57:12.932455
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: [x]) == Left(2)



# Generated at 2022-06-23 23:57:14.554901
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:57:20.472480
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(5).ap(Either(1)) == Left(5)
    assert Right(5).ap(Either(1)) == Right(1)
    assert Left(5).ap(Left(4)) == Left(5)
    assert Right(5).ap(Left(4)) == Left(4)
    assert Left(5).ap(Right(4)) == Left(5)
    assert Right(5).ap(Right(4)) == Right(4)


# Generated at 2022-06-23 23:57:22.460921
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False



# Generated at 2022-06-23 23:57:28.878025
# Unit test for method case of class Either
def test_Either_case():
    # Given
    expected_error_value = 1
    expected_success_value = 2

    error_handler = lambda val: expected_error_value
    success_handler = lambda val: expected_success_value

    left = Left(expected_error_value)
    right = Right(expected_error_value)

    # Then
    assert left.case(error_handler, success_handler) == expected_error_value
    assert right.case(error_handler, success_handler) == expected_success_value


# Generated at 2022-06-23 23:57:30.197798
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(5)
    maybe = right.to_maybe()

    assert maybe.is_just()
    assert maybe.value == 5


# Generated at 2022-06-23 23:57:31.396856
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.either import Left
    assert Left("message").is_left(), "Left is not left"


# Generated at 2022-06-23 23:57:34.076643
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Test case for is_right method of class Either
    """
    assert not Left(1).is_right(), "Left is not Right"
    assert Right(2).is_right(), "Right is right"

# Generated at 2022-06-23 23:57:35.524906
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(4).ap(Left("error")) == Left(4)



# Generated at 2022-06-23 23:57:37.418262
# Unit test for method to_try of class Either
def test_Either_to_try():
    e1 = Either.of('I am success')
    assert e1.to_try().is_success

    e2 = Either.from_error('I am error')
    assert not e2.to_try().is_success



# Generated at 2022-06-23 23:57:40.230949
# Unit test for method map of class Right
def test_Right_map():

    def add(x):
        return x + 1

    assert Right(1).map(add) == Right(2)



# Generated at 2022-06-23 23:57:49.312711
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    left = Left(5)
    assert left.ap(Lazy(lambda: Box(6))).value == left.value, \
        'Wrong result of Either.Left.ap with Box'

    assert left.ap(Try(5, is_success=True)).value == left.value, \
        'Wrong result of Either.Left.ap with Try'

    assert left.ap(Lazy(lambda: 5)).value == left.value, \
        'Wrong result of Either.Left.ap with Lazy'



# Generated at 2022-06-23 23:57:53.415172
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_list import List

    result = Left(-1).bind(lambda x: List([x, x+1, x+2]))
    assert isinstance(result, Left)
    assert result.value == -1


# Generated at 2022-06-23 23:57:55.843752
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(3).to_lazy().value() == 3
    assert Right(3).to_lazy().value() == 3


# Generated at 2022-06-23 23:57:57.692529
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_try import Try

    assert isinstance(Try(None).to_either(), Right) and Try(None).to_either().is_right()


# Generated at 2022-06-23 23:57:58.886475
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    result = Left(2).to_maybe()

    assert result == 0


# Generated at 2022-06-23 23:58:02.147661
# Unit test for constructor of class Left
def test_Left():
    assert Left('hello').case(str, lambda x: 'fail') == 'hello'
    assert Left('hello').case(str, len) == 5
    assert Left('hello').case(len, str) == 5


# Generated at 2022-06-23 23:58:08.264818
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(value: str) -> Left[int]:
        """
        Map string to integer

        :param value: value to convert
        :type value: String
        :returns: converted value
        :rtype: Left[Integer]
        """
        return Left(int(value))

    assert Right("1").bind(mapper) == Left(1)



# Generated at 2022-06-23 23:58:11.983310
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(1)) == Right(2)
    assert Left(lambda x: x).ap(Right(1)) == Left(lambda x: x)
    assert Left(lambda x: x).ap(Left(1)) == Left(lambda x: x)

# Generated at 2022-06-23 23:58:16.598391
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Test that is_right method returns True when Either is Right, False in other case.

    :returns: True if Either is Right, False in other case
    :rtype: Boolean
    """
    assert Right(1).is_right()
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:58:22.016321
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Either(Exception()).to_try() == Try(Exception(), False)
    assert Either(1).to_try() == Try(1, True)


# Generated at 2022-06-23 23:58:24.071156
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:58:26.116184
# Unit test for constructor of class Either
def test_Either():
    assert Either(None) is None


# Generated at 2022-06-23 23:58:27.513611
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert(Right(1).is_left() == False)


# Generated at 2022-06-23 23:58:29.865064
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(42) == Right(42).to_maybe()



# Generated at 2022-06-23 23:58:31.618683
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left('error').is_right()
    assert Right('value').is_right()


# Generated at 2022-06-23 23:58:37.619597
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from test_helper import assert_equality

    assert_equality(Left('a'), Left('a'))
    assert_equality(Right(1), Right(1))
    assert_equality(Right('a'), Right('a'))
    assert_equality(Left('a'), Left('a'))



# Generated at 2022-06-23 23:58:38.702079
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(42).to_validation() == Validation.success(42)

# Generated at 2022-06-23 23:58:41.113712
# Unit test for method map of class Right
def test_Right_map():
    def f(x: int) -> int:
        return x ** 2

    assert Right(1).map(f) == Right(1)
    assert Right(2).map(f) == Right(4)


# Generated at 2022-06-23 23:58:42.262659
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:58:47.708657
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.validation import Validation
    from pymonet.either import Left
    from pymonet.box import Box

    left = Left('Oops')
    validator = Validation.success
    validator_on_left = validator(left)
    assert validator_on_left == validator  # Check if both lefts have the same reference
    validator_on_left = validator(Box('Oops'))
    assert validator_on_left == validator  # Check if both lefts have the same reference

if __name__ == '__main__':
    test_Left_ap()
    print("Everything passed")

# Generated at 2022-06-23 23:58:49.058519
# Unit test for method is_left of class Left
def test_Left_is_left():
    """
    Unit test for method is_left of class Left
    """
    assert Left(True).is_left() == True



# Generated at 2022-06-23 23:58:57.763709
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success as ValidationSuccess
    from pymonet.validation import Fail as ValidationFail

    assert Right("lala").to_validation() == Validation("lala", [])
    assert Right("lala").to_validation() == ValidationSuccess("lala")
    assert Right("lala").to_validation() != Validation("lala", ["lola"])
    assert Right("lala").to_validation() != ValidationSuccess("lala", ["lola"])
    assert Right("lala").to_validation() != Left("lala")
    assert Right("lala").to_validation() != ValidationFail(["lala"])


# Generated at 2022-06-23 23:58:59.317774
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).is_left()
    assert Left(1).map(lambda other: other + 2) == Left(1)


# Generated at 2022-06-23 23:59:04.152112
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either(Box(5)).to_box() == Box(Box(5))
    assert Either(5).to_box() == Box(5)
    assert Either(None).to_box() == Box(None)
    assert Either(None).to_box() == Either(5).to_box()
    assert Either(None).to_box() == Either(Box(5)).to_box()
    assert Either(None).to_box() == Either(None).to_box()
    assert Either(Box(None)).to_box() == Either(Box(5)).to_box()
    assert Either(Box(None)).to_box() == Either(Box(None)).to_box()

# Generated at 2022-06-23 23:59:07.087750
# Unit test for method map of class Right
def test_Right_map():
    assert Right('2').map(int) == Right(2)



# Generated at 2022-06-23 23:59:09.614970
# Unit test for method bind of class Right
def test_Right_bind():
    assert (Right(1).bind(lambda x: Left(x + 1))) == Left(2)
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)


# Generated at 2022-06-23 23:59:14.225107
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('123').is_left()



# Generated at 2022-06-23 23:59:26.282716
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    # monad = Either[Int]
    monad = Right(5)
    # applicative = Either[Functor[Int, Int]]
    applicative = Right(Functor(lambda x: x * 2))

    result = monad.ap(applicative)

    assert isinstance(monad, Either)
    assert isinstance(applicative, Either)
    assert isinstance(result, Either)
    assert isinstance(result, Right)
    assert result.value == 10

    # monad = Either[Int]
    monad = Right(5)
    # applicative = Either[Functor[Int, Int]]

# Generated at 2022-06-23 23:59:28.906655
# Unit test for method map of class Right
def test_Right_map():
    actual = Right(1).map(lambda x: x + 1)
    expected = Right(2)
    assert actual == expected



# Generated at 2022-06-23 23:59:31.844080
# Unit test for constructor of class Either
def test_Either():
    # type: () -> None
    assert (Left(1)).value == 1
    assert (Right(2)).value == 2



# Generated at 2022-06-23 23:59:36.463423
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either(1).to_box() == Box(1)
    assert Either(1).left().to_box() == Box(1)
    assert Either('1').left().to_box() == Box('1')
    assert Either('asd').right().to_box() == Box('asd')
    assert Either(1).right().to_box() == Box(1)



# Generated at 2022-06-23 23:59:38.054085
# Unit test for method map of class Left
def test_Left_map():
    assert Left("some error").map(lambda value: "some success") == Left("some error")


# Generated at 2022-06-23 23:59:44.692598
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)
    assert Right(2) != Left(2)


# Generated at 2022-06-23 23:59:45.794966
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(10).is_right() == True


# Generated at 2022-06-23 23:59:51.936909
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(error=lambda a: a + 1, success=lambda b: b + 1) == 2
    assert Left(2).case(error=lambda a: a + 1, success=lambda b: b + 1) == 3


# Generated at 2022-06-23 23:59:58.014935
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(0).to_try() == Try(0, is_success=False)
    assert Right('text').to_try() == Try('text', is_success=True)



# Generated at 2022-06-24 00:00:00.190836
# Unit test for constructor of class Right
def test_Right():
    assert Right(4).value == 4
    assert Right('4').value == '4'
    assert Right(4) == Right(4)



# Generated at 2022-06-24 00:00:01.767484
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(10).is_right() == False
    assert Right(10).is_right() == True


# Generated at 2022-06-24 00:00:02.888527
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(2).is_right() == True
    assert Left(2).is_right() == False


# Generated at 2022-06-24 00:00:04.664416
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box().get() == 1
    assert Left(1).to_box().get() == 1


# Generated at 2022-06-24 00:00:06.082929
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:00:07.174183
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right("world").to_validation() == Validation("world")


# Generated at 2022-06-24 00:00:09.204898
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)

# Generated at 2022-06-24 00:00:11.607900
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either."""
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-24 00:00:12.764042
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-24 00:00:15.594408
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(5)

    result = right.to_maybe()

    assert isinstance(result, Maybe)
    assert result == Maybe.just(5)



# Generated at 2022-06-24 00:00:18.192689
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(None).bind(lambda x: x) == Left(None)


# Generated at 2022-06-24 00:00:19.465081
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() == True


# Generated at 2022-06-24 00:00:20.517783
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(42).is_right() == True
    assert Left(42).is_right() == False


# Generated at 2022-06-24 00:00:28.287887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Either.to_lazy(Either.right(5))
    assert Lazy(lambda: 5) == Either.to_lazy(Either.left(5))
    assert Lazy(lambda: 5) == Either.to_lazy(Either.right(5))
    assert Lazy(lambda: 5) == Either.to_lazy(Either.left(5))


# Generated at 2022-06-24 00:00:32.436268
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    right = right.bind(lambda x: Left(x + 1))
    assert(left == right)

# Generated at 2022-06-24 00:00:34.071366
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:00:39.626491
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Check that Left[A] converted to failed Try
    assert Left(1).to_try() == Try.failed(1)

    # Check that Right[A] converted to successfull Try
    assert Right(1).to_try() == Try.success(1)


# Generated at 2022-06-24 00:00:42.170743
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:00:47.049642
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(2)
    assert Right(1) != Left(2)

# Generated at 2022-06-24 00:00:50.612541
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(
        error=lambda x: x + 1,
        success=lambda x: x + 2) == 6

    assert Right(5).case(
        error=lambda x: x + 1,
        success=lambda x: x + 2) == 7



# Generated at 2022-06-24 00:00:55.350602
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(5).to_box() == Box(5)
    assert Either('some value').to_box() == Box('some value')
    assert Either(4.5).to_box() == Box(4.5)
    assert Either(None).to_box() == Box(None)
    assert Either(True).to_box() == Box(True)
    assert Either(False).to_box() == Box(False)


# Generated at 2022-06-24 00:00:57.626715
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test if Right.bind raise exception with left argument.
    """
    assert Right(1).bind(lambda x: Left(x)) == Left(1)

# Generated at 2022-06-24 00:00:59.321452
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(5).is_right() == None


# Generated at 2022-06-24 00:01:00.846846
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(2).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:02.255989
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1, 'Right value is incorrect'



# Generated at 2022-06-24 00:01:05.657035
# Unit test for method ap of class Either
def test_Either_ap():
    # arrange
    value = 5

    # act
    result = Either(2).ap(Either(lambda x: x * x))
    result_with_wrong_type = Either(2).ap(Either(5))

    # assert
    assert result == Right(4)
    assert result_with_wrong_type == Left(5)



# Generated at 2022-06-24 00:01:07.650833
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left('left value')
    assert left.is_right() == False


# Generated at 2022-06-24 00:01:09.813114
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.is_right()
    assert not right.is_left()


# Generated at 2022-06-24 00:01:10.678418
# Unit test for constructor of class Left
def test_Left():
    assert Left("Error").value == "Error"


# Generated at 2022-06-24 00:01:14.353701
# Unit test for method ap of class Either
def test_Either_ap():
    left = Left(1)
    right = Right(lambda x: x * x)
    assert left.ap(left) == Left(1)
    assert left.ap(right) == Left(1)
    assert right.ap(left) == Left(1)
    assert right.ap(right) == Right(1)



# Generated at 2022-06-24 00:01:16.019160
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1)\
        .bind(lambda x: Right(x+1))\
        .bind(lambda x: Right(x+1)) == Right(2)



# Generated at 2022-06-24 00:01:17.306648
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe, Nothing
    assert Left("").to_maybe() == Nothing()


# Generated at 2022-06-24 00:01:18.989854
# Unit test for constructor of class Left
def test_Left():

    left = Left("error message")
    assert left.value == "error message"



# Generated at 2022-06-24 00:01:19.789261
# Unit test for constructor of class Either
def test_Either():
    assert Either(2)



# Generated at 2022-06-24 00:01:21.020164
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: x * 2) == 2



# Generated at 2022-06-24 00:01:22.123069
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('Value').is_left() is False


# Generated at 2022-06-24 00:01:24.508678
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """Should return failed Validation with value from Left"""
    from pymonet.validation import Validation

    actual = Left(1).to_validation()
    expected = Validation.fail([1])

    assert actual == expected


# Generated at 2022-06-24 00:01:26.493192
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(10).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:30.524583
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right("something").to_validation() == Validation.success("something")


# Generated at 2022-06-24 00:01:34.408865
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)

# Generated at 2022-06-24 00:01:42.982904
# Unit test for method ap of class Either
def test_Either_ap():
    # Arrange
    mapper = lambda x: x + 1
    def mapper_in_mapper(x):
        def inner_mapper(y):
            return x + y
        return inner_mapper
    monad1 = Right(1)
    monad2 = Left(1)
    monad3 = Right(mapper)
    monad4 = Left(mapper)
    monad5 = Right(mapper_in_mapper)
    monad6 = Left(mapper_in_mapper)
    # Act
    result1 = monad1.ap(monad1)
    result2 = monad2.ap(monad2)
    result3 = monad1.ap(monad3)
    result4 = monad3.ap(monad1)
    result5 = monad1.ap

# Generated at 2022-06-24 00:01:44.864512
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() is Validation.fail([1])



# Generated at 2022-06-24 00:01:46.657769
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-24 00:01:50.642830
# Unit test for method map of class Left
def test_Left_map():
    initial_value = [1, 2, 3]
    expected_value = initial_value
    left = Left(initial_value)
    mapped = left.map(lambda x: x)

    assert mapped.__class__ == Left
    assert mapped.value == expected_value


# Generated at 2022-06-24 00:02:01.036014
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.either import Left, Right

    result = Left(5)
    expected = Left(5)
    assert result == expected

    result = Right(5).ap(Right(lambda x: x + 5))
    expected = Right(10)
    assert result == expected

    result = Right(10).ap(Left(lambda x: x + 5))
    expected = Left(lambda x: x + 5)
    assert result == expected

    result = Left(lambda x: x + 5).ap(Right(10))
    expected = Left(lambda x: x + 5)
    assert result == expected

    result = Left(lambda x: x + 5).ap(Left(10))
    expected = Left(lambda x: x + 5)
    assert result == expected

# Generated at 2022-06-24 00:02:03.659630
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) == Right(1) is False
    assert Left(1) == None is False


# Generated at 2022-06-24 00:02:11.123759
# Unit test for method to_try of class Either
def test_Either_to_try():
    right = Right('right')
    assert right.to_try() == Try('right', True)
    assert isinstance(right.to_try(), Try)
    assert isinstance(right.to_try().value, str)

    left = Left('left')
    assert left.to_try() == Try('left', False)
    assert isinstance(left.to_try(), Try)
    assert isinstance(left.to_try().value, str)



# Generated at 2022-06-24 00:02:13.798486
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert not Either(1) == Either(2)
    assert not Either(1) == Either(2.0)



# Generated at 2022-06-24 00:02:14.630579
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-24 00:02:19.107486
# Unit test for constructor of class Left
def test_Left():
    """Assert that instance of Left have correct value"""
    some_value = 1
    assert Left(some_value).value == some_value
    assert Left(some_value).is_left() == True
    assert Left(some_value) == Left(some_value)
    assert Left(some_value) is not Left(some_value)


# Generated at 2022-06-24 00:02:21.771064
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left([]) == Left([]).to_maybe().bind(
        lambda x: Left([]) if x == None else Right([])
    ).to_either()


# Generated at 2022-06-24 00:02:23.058043
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1



# Generated at 2022-06-24 00:02:24.915038
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) == Left(1)
    assert Left(1) != Right(2)


# Generated at 2022-06-24 00:02:30.489945
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(1) != None
    assert Right(None) == Right(None)
    assert Right(None) != Right(1)
    assert Right(1) == Right(1)
    assert Right(True) == Right(True)
    assert Right(True) != Right(False)
    assert Right(False) == Right(False)
    assert Right(False) != Right(True)
    assert Right([]) == Right([])
    assert Right([1, 2]) == Right([1, 2])
    assert Right([1, 2]) != Right([2, 1])
    assert Right(['a', 'b']) == Right(['a', 'b'])

# Generated at 2022-06-24 00:02:34.744851
# Unit test for constructor of class Left
def test_Left():
    # Given
    e = Left(5)
    # Then
    assert e.value == 5
    assert isinstance(e, Left)
    assert isinstance(e, Either)



# Generated at 2022-06-24 00:02:37.194993
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Right(1)) == Try(1, is_success=True)
    assert Either.to_try(Left(1)) == Try(1, is_success=False)


# Generated at 2022-06-24 00:02:42.767523
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x - 1)) == Right(0)
    assert Right(1).bind(lambda x: Left([x, x + 1])) == Left([1, 2])


# Generated at 2022-06-24 00:02:48.479623
# Unit test for method ap of class Left
def test_Left_ap():
    """
    Test that ap return Left
    """
    from pymonet.box import Box

    assert Left(1).ap(Box(lambda x: x)) == Left(1)


# Generated at 2022-06-24 00:02:53.470515
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test method to_box of class Either.

    :returns: None
    :rtype: None
    """
    from pymonet.box import Box

    assert Right(5).to_box() == Box(5)
    assert Left(5).to_box() == Box(5)



# Generated at 2022-06-24 00:02:55.366661
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() == True
    assert Left(1).is_right() == False


# Generated at 2022-06-24 00:03:06.166911
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Left(1) == Left(1).ap(Lazy(lambda: 1))
    assert Right(2) == Right(2).ap(Box(2))
    assert Left(1) == Left(1).ap(Try(1))
    assert Right(2) == Right(2).ap(Try(2, is_success=True))
    assert Left(1) == Left(1).ap(Either.unit(1))
    assert Right(2) == Right(2).ap(Either.unit(2))
    assert Left(1) == Right(1).ap(Left(1))
    assert Right(2) == Right(2).ap(Right(2))

# Generated at 2022-06-24 00:03:07.662204
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()



# Generated at 2022-06-24 00:03:09.735841
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    result = left.ap(Right(lambda x: x + 2))
    assert result == Left(1)



# Generated at 2022-06-24 00:03:12.114068
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Right(1).is_right() is True
    assert Right(1).is_left() is False


# Generated at 2022-06-24 00:03:13.773916
# Unit test for method map of class Right
def test_Right_map():
    def f(x):
        return x + 1
    assert Right(1).map(f).value == 2


# Generated at 2022-06-24 00:03:15.353341
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left("Error").is_right() is False
    assert Right("Success").is_right() is True


# Generated at 2022-06-24 00:03:16.510547
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert None == Right(None).is_left()


# Generated at 2022-06-24 00:03:17.491106
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left("test").is_right() is False


# Generated at 2022-06-24 00:03:22.978617
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Test for method ap
    """
    from pymonet.box import Box
    def pow_2(number):
        return number**2

    def right(value):
        return Right(value)

    def mul_2(number):
        return number * 2

    box_pow_2 = Box(pow_2)

    number = 2
    result1 = Right(number).map(pow_2)
    assert str(result1) == 'Right(4)'
    result2 = Right(number).ap(box_pow_2)
    assert str(result2) == 'Right(4)'

    box_mul_2 = Box(mul_2)
    result3 = Right(number).ap(box_mul_2)
    assert str(result3) == 'Right(4)'

#

# Generated at 2022-06-24 00:03:26.449835
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)



# Generated at 2022-06-24 00:03:33.325796
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    box_right_chance = Either.Right(Box(99)).to_box()
    assert isinstance(box_right_chance, Box)
    assert box_right_chance.value == 99

    box_left_chance = Either.Left(Box(5)).to_box()
    assert isinstance(box_left_chance, Box)
    assert box_left_chance.value == 5

    try_right_chance = Either.Right(Try(99)).to_box()
    assert isinstance(try_right_chance, Box)
    assert try_right_chance.value == 99

    try_left_chance = Either.Left(Try(5)).to_box()
    assert isinstance(try_left_chance, Box)
    assert try_

# Generated at 2022-06-24 00:03:35.435380
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1, 1)
    assert left.is_right() == False


# Generated at 2022-06-24 00:03:39.485382
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(
        lambda value: value + 3,
        lambda value: value * 2
    ) == 8

    assert Right(5).case(
        lambda value: value + 3,
        lambda value: value * 2
    ) == 10



# Generated at 2022-06-24 00:03:41.999354
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    assert Left(0).to_box() == Box(0)
    assert Right(1).to_box() == Box(1)


# Generated at 2022-06-24 00:03:45.746609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    from pymonet.lazy import Lazy
    either_left = Left(1)
    either_right = Right(2)

    # Then
    assert either_left.to_lazy() == Lazy(lambda: 1)
    assert either_right.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-24 00:03:51.866110
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)

    assert Right(2) != Left(2)
    assert Left(2) != Right(2)
