

# Generated at 2022-06-23 23:53:48.777977
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')
    assert left.is_left() == True


# Generated at 2022-06-23 23:53:50.384911
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:53:57.130697
# Unit test for method map of class Left
def test_Left_map():
    # Arrange
    left_either = Left('test_value')

    # Act
    mapped_left_either = left_either.map(lambda value: value.upper())

    # Assert
    assert left_either.value == mapped_left_either.value
    assert mapped_left_either == Left('test_value')



# Generated at 2022-06-23 23:54:01.124374
# Unit test for method ap of class Either
def test_Either_ap():
    mapper = lambda x: x ** 2
    either = Left(2).ap(Right(mapper))
    assert either == Left(2)

    either = Right(2).ap(Left(mapper))
    assert either == Left(mapper)

    either = Right(2).ap(Right(mapper))
    assert either == Right(4)


# Generated at 2022-06-23 23:54:03.373177
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:54:06.207169
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)



# Generated at 2022-06-23 23:54:07.975564
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right.to_validation(Right(1)) == Validation.success(1)



# Generated at 2022-06-23 23:54:09.560890
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left('error').to_validation() == Left('error').to_validation()


# Generated at 2022-06-23 23:54:11.611572
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(True).is_left() == True, "Left.is_left() returned wrong value"


# Generated at 2022-06-23 23:54:14.850820
# Unit test for method map of class Left
def test_Left_map():
    # given
    left = Left(5)

    # when
    result = left.map(lambda x: x + 2)

    # then
    assert result == left


# Generated at 2022-06-23 23:54:17.398358
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(4).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:54:19.755254
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(1)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:54:27.969413
# Unit test for method to_box of class Either
def test_Either_to_box():
    import pytest

    assert Left('fail').to_box() == Box('fail')
    assert Right('success').to_box() == Box('success')
    with pytest.raises(TypeError):
        Right(1) == 'str'
    assert Left('fail') == Left('fail')
    assert Right('success') == Right('success')
    assert Left('fail') != Right('success')
    assert Right('success') != Left('fail')


# Generated at 2022-06-23 23:54:34.498289
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import class_functor

    assert Either.ap(class_functor.add_one(Left(1)), class_functor.add_one(Right(1))) == Left(1)
    assert Either.ap(class_functor.add_one(Right(1)), class_functor.add_one(Left(1))) == Left(1)
    assert Either.ap(class_functor.add_one(Right(1)), class_functor.add_one(Right(1))) == Right(3)



# Generated at 2022-06-23 23:54:38.472972
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:54:39.784505
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(5).is_left()


# Generated at 2022-06-23 23:54:41.719880
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Right(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:54:46.412756
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    import pytest

    left = Left(1)
    box = Box(lambda x: x + 1)
    assert left.ap(box) == Left(1)



# Generated at 2022-06-23 23:54:48.682485
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(10)

    result = left.to_maybe()

    assert isinstance(result, Maybe)
    assert result == Maybe.nothing()



# Generated at 2022-06-23 23:54:50.319120
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda x: x) == Left('error')


# Generated at 2022-06-23 23:54:53.111682
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Case when Left transform to Maybe
    """
    # When
    instance = Left(Exception())

    # Then
    assert instance.to_maybe() == Maybe.nothing(), 'Should return Maybe.nothing()'



# Generated at 2022-06-23 23:54:59.499507
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> Just(2).ap(Just(lambda x: x + 2)) == Just(4)
    True
    >>> Just(2).ap(Nothing()) == Nothing()
    True
    >>> Nothing().ap(Just(lambda x: x + 2)) == Nothing()
    True
    >>> Nothing().ap(Nothing()) == Nothing()
    True
    >>> Right(2).ap(Right(lambda x: x + 2)) == Right(4)
    True
    >>> Right(2).ap(Left(4)) == Left(4)
    True
    >>> Left(4).ap(Right(lambda x: x + 2)) == Left(4)
    True
    >>> Left(4).ap(Left(2)) == Left(4)
    True
    """
    pass

# Generated at 2022-06-23 23:55:02.386291
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right()


# Generated at 2022-06-23 23:55:03.696562
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert (Right(1)).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:55:08.082483
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Right(x * 2)) == Right(4)
    assert Right("foo").bind(lambda x: Right(x + "o")) == Right("fooo")



# Generated at 2022-06-23 23:55:10.379304
# Unit test for method map of class Right
def test_Right_map():
    actual = Right(42).map(lambda x: x + 1)
    expected = 43
    assert actual.value == expected



# Generated at 2022-06-23 23:55:12.961338
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1) == Right(1).to_box().to_either()
    assert Left('error') == Left('error').to_box().to_either()

# Generated at 2022-06-23 23:55:14.133056
# Unit test for method map of class Right
def test_Right_map():
    assert Right(4).map(lambda x: x * 2) == Right(8)



# Generated at 2022-06-23 23:55:23.284522
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Left(1).case(lambda x: x, lambda x: x) == 1
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).to_box() == Box(1)
    assert Left(1).to_try() == Try(1, False)
    assert Left(1).to_lazy().force() == 1


# Generated at 2022-06-23 23:55:25.227083
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either[int](1).to_lazy() == Lazy[int](1)


# Generated at 2022-06-23 23:55:27.064878
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(3).is_right()



# Generated at 2022-06-23 23:55:31.856718
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() == True
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:55:33.477512
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:55:37.132193
# Unit test for method map of class Right
def test_Right_map():
    # When
    right = Right(4)
    result = right.map(lambda x: x + 1)
    # Then
    assert result.value == 5
    assert result.is_right()



# Generated at 2022-06-23 23:55:44.222423
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Test for method ap of class Either
    """
    from pymonet.functor import Functor
    from pymonet import functor_extensions

    class U(Either[int]):
        def __init__(self):
            super(U, self).__init__(1)

    class V(Either[int]):
        def __init__(self):
            super(V, self).__init__(2)

    class W(Functor[int], Either[Callable[int, int]]):
        def __init__(self):
            super(W, self).__init__(lambda x: x + 2)

    assert functor_extensions.ap(U(), W()) == 4

# Generated at 2022-06-23 23:55:48.405799
# Unit test for method case of class Either
def test_Either_case():
    # Test when either is left
    left: Either[int] = Left(1)
    assert left.case(lambda v: v, lambda v: v) == 1
    # Test when either is right
    right: Either[int] = Right(1)
    assert right.case(lambda _: 0, lambda v: v) == 1
    assert left != right
    assert left == Left(1)
    assert left.__eq__("asasd") == False
    assert left.is_left()
    assert not left.is_right()

# Generated at 2022-06-23 23:55:50.219091
# Unit test for constructor of class Left
def test_Left():
    pass



# Generated at 2022-06-23 23:55:54.699621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(x):
        # type: (int) -> int
        return x + x

    def gt10(x):
        # type: (int) -> int
        return x > 10

    assert Either(1).to_lazy().bind(add).bind(gt10).value() == False
    assert Either(2).to_lazy().bind(add).bind(gt10).value() == True



# Generated at 2022-06-23 23:56:01.684391
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> def f(x): return x + 5
    >>> print(Right(f).ap(Right(2)))
    Right(7)
    >>> print(Right(f).ap(Left(15)))
    Left(15)
    >>> print(Left('f()').ap(Right(2)))
    Left('f()')
    >>> print(Left('f()').ap(Left(15)))
    Left(15)
    """
    pass



# Generated at 2022-06-23 23:56:03.746274
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    either = Right(1)

    assert either.to_validation() == Either.to_validation(either)

# Generated at 2022-06-23 23:56:06.673906
# Unit test for method is_right of class Left
def test_Left_is_right():
    # Setup
    left = Left('pymonet')
    # Exercise
    result = left.is_right()
    # Verify
    assert result == False


# Generated at 2022-06-23 23:56:09.003775
# Unit test for constructor of class Left
def test_Left():
    assert Left(_) == Left(_)
    assert Left(_) is not Left(_)
    assert Left(_) != Right(_)



# Generated at 2022-06-23 23:56:10.079679
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:56:13.830526
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    first = Either(1)
    second = Either('test')

    assert first.to_try() == Try(1, True)
    assert second.to_try() == Try('test', False)


# Generated at 2022-06-23 23:56:14.504768
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:56:15.330500
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(2)
    assert right.to_maybe() == Maybe.just(2)

# Generated at 2022-06-23 23:56:16.524466
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:56:17.691231
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 2) == Right(3)


# Generated at 2022-06-23 23:56:23.567482
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> from pymonet.either import Left, Right
    >>> def add_one(x): return x + 1
    >>> Right(1).ap(Right(add_one))
    Right(2)
    >>> Left([123]).ap(Right(add_one))
    Left([123])
    >>> Right(1).ap(Left([123]))
    Left([123])
    >>> Left([123]).ap(Left([123]))
    Left([123])
    """
    pass

# Generated at 2022-06-23 23:56:26.450093
# Unit test for method is_right of class Either
def test_Either_is_right():
    check = either_test_helper(right=True)
    assert check(Left(1)).is_right() == False
    assert check(Right(1)).is_right() == True

# Generated at 2022-06-23 23:56:27.477139
# Unit test for method is_right of class Right
def test_Right_is_right():
    either_right = Right(1)

    assert either_right.is_right() == True


# Generated at 2022-06-23 23:56:33.357766
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda v: v + 1) == Right(4)
    assert Right('3').map(lambda v: int(v) + 1) == Right(4)


# Generated at 2022-06-23 23:56:35.872662
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(10)
    right = Right(10)

    assert not left.is_right()
    assert right.is_right()



# Generated at 2022-06-23 23:56:43.293954
# Unit test for method bind of class Right
def test_Right_bind():
    to_either = lambda x: Right(x)
    assert to_either('a').bind(lambda x: Right(x + 'b')) == Right('ab')
    assert to_either('a').bind(lambda x: Left(x + 'b')) == Left('ab')
    assert to_either('a').bind(lambda x: to_either(x + 'b')) == Right('ab')



# Generated at 2022-06-23 23:56:47.607582
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    a = Left(1)
    b = Right(2)

    c = a.to_lazy()
    d = b.to_lazy()

    assert c.value() == a.value
    assert d.value() == b.value


# Generated at 2022-06-23 23:56:51.400277
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    def test_right(value: Any) -> Maybe:
        right = Right(value)
        return right.to_maybe()

    assert test_right(2) == Maybe.just(2)
    assert test_right(None) == Maybe.just(None)
    assert test_right('foo') == Maybe.just('foo')



# Generated at 2022-06-23 23:56:54.330411
# Unit test for method case of class Either
def test_Either_case():
    def error_handler(error):
        return str(error)
    def success_handler(value):
        return int(value)

    assert Right(1).case(error_handler, success_handler) == 1
    assert Left("1").case(error_handler, success_handler) == '1'
    assert Right("1").case(error_handler, success_handler) == 1


# Generated at 2022-06-23 23:56:56.062156
# Unit test for constructor of class Right
def test_Right():
    instance = Right(2)
    assert instance.value == 2
    assert instance.is_right()


# Generated at 2022-06-23 23:57:03.033077
# Unit test for constructor of class Either
def test_Either():
    # Failed test is ok for Eitheres with different values
    assert Either('a') == Either('a')
    assert Either('a') != Either('b')
    assert not Either('a') != Either('a')
    assert not Either('a') == Either('b')

    assert Either(1) != Either('a')
    assert not Either(1) == Either('a')


# Generated at 2022-06-23 23:57:04.152406
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:57:09.446123
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    class A:
        pass

    class B:
        pass

    def mapper(x: T) -> Either[U]:
        return Validation.success(B())

    assert Right(A()).bind(mapper) == Validation.success(B())



# Generated at 2022-06-23 23:57:12.205823
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(20), Either)
    assert isinstance(Right(20), Either)


# Generated at 2022-06-23 23:57:14.603476
# Unit test for method ap of class Left
def test_Left_ap():
    applicative = Either(lambda x: x * 2)
    assert Left(3).ap(applicative) == Left(3)


# Generated at 2022-06-23 23:57:16.192661
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(3).is_right() is False


# Generated at 2022-06-23 23:57:20.176568
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()
    assert Left('a').to_maybe() == Maybe.nothing()
    assert Left([1, 2, 3]).to_maybe() == Maybe.nothing()
    assert Left({'abc': 123}).to_maybe() == Maybe.nothing()
    assert Left(Maybe.just([1, 2, 3])).to_maybe() == Maybe.nothing()
    assert Left(Maybe.just({'abc': 123})).to_maybe() == Maybe.nothing()
    assert Left(Maybe.nothing()).to_maybe() == Maybe.nothing()
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:57:21.992883
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:57:26.532548
# Unit test for constructor of class Left
def test_Left():
    value = 'Some value'
    left_either = Left(value)
    assert left_either.value == value, 'Not expected value of Left'
    assert left_either.is_right() is False, 'Value of Left should be not Right'
    assert left_either.is_left() is True, 'Value of Left should be Left'


# Generated at 2022-06-23 23:57:29.913397
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    import pytest

    right = Right("right")
    validation = right.to_validation()
    assert validation.is_success()
    assert right.value == validation.value
    assert right.is_right() == validation.is_success()


# Generated at 2022-06-23 23:57:30.883980
# Unit test for method bind of class Right
def test_Right_bind():
    assert 1 == Right(12).bind(lambda x: x // 12)



# Generated at 2022-06-23 23:57:33.586612
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(
        error=lambda x: 'left',
        success=lambda x: 'right'
    ) == 'left'

    assert Right(1).case(
        error=lambda x: 'left',
        success=lambda x: 'right'
    ) == 'right'



# Generated at 2022-06-23 23:57:36.541011
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-23 23:57:40.943672
# Unit test for constructor of class Right
def test_Right():
    assert Right(True).value
    assert Right(False).value is False
    assert Right([]).value == []
    assert Right([1]).value == [1]
    assert Right([1, 2, 3]).value == [1, 2, 3]



# Generated at 2022-06-23 23:57:43.078535
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(2)
    assert Left(2).to_lazy() == Lazy(2)

# Generated at 2022-06-23 23:57:44.161066
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:57:47.265217
# Unit test for method map of class Left
def test_Left_map():
    # given
    def increment(x: int) -> int:
        return x + 1

    # when
    result = Left(5).map(increment)

    # then
    assert result == Left(5)



# Generated at 2022-06-23 23:57:50.796236
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(10).is_right() is True

# Generated at 2022-06-23 23:57:54.620772
# Unit test for constructor of class Left
def test_Left():
    assert Left(2) == Left(2)
    assert Left('abc') == Left('abc')
    assert Left(None).is_left()
    assert not Left(None).is_right()
    assert Left(3).bind(lambda x: x) == Left(3)



# Generated at 2022-06-23 23:57:58.886428
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x * 2) == Left(2)



# Generated at 2022-06-23 23:58:00.426785
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('a').is_right() is False
    assert Right('a').is_right() is True



# Generated at 2022-06-23 23:58:06.165710
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    left = Left(lambda x: x)
    assert left.ap(Try(2)) == Left(lambda x: x)
    assert left.ap(Box(2)) == Left(lambda x: x)
    assert left.ap(Lazy(lambda: 2)) == Left(lambda x: x)
    assert left.ap(Left(2)) == Left(lambda x: x)


# Generated at 2022-06-23 23:58:08.832254
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(5).to_validation() == Validation.success(5)



# Generated at 2022-06-23 23:58:13.911516
# Unit test for method bind of class Left
def test_Left_bind():
    assert(Left(1).bind(lambda x: Right(x + 1)) == Left(1))


# Generated at 2022-06-23 23:58:16.502436
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    # given:
    value = 1
    right = Right(value)

    # expect:
    assert right.to_maybe() == Maybe.just(value)


# Generated at 2022-06-23 23:58:21.871927
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('one').is_right()



# Generated at 2022-06-23 23:58:24.344734
# Unit test for method to_try of class Either
def test_Either_to_try():
    def f(x):
        return x + 1

    class RaiseError(Exception):
        pass

    assert Right(1).to_try().map(f).value == 2
    assert Left(RaiseError()).to_try().map(f).value == None

# Generated at 2022-06-23 23:58:29.526871
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:58:38.097785
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    def add(a, b):
        return a + b

    func = Lazy(lambda: (Box(1), Box(2))).map(lambda t: add(t[0].value, t[1].value))

    def add_ap(a):
        return a + 3

    assert func.ap(Box(add_ap)).value == 6

    func_op = Lazy(lambda: (Box(1), Box(2))).map(lambda t: add(t[0].value, t[1].value)).map(lambda a: -a)

    def mul(a, b):
        return a * b

    def op(a):
        return -a

    assert func_op.ap(Box(op)).value == -3

# Generated at 2022-06-23 23:58:41.560667
# Unit test for constructor of class Either
def test_Either():
    assert Left('left') == Left('left')
    assert Left('left') != Right('left')
    assert Right('right') == Right('right')
    assert Right('right') != Left('right')



# Generated at 2022-06-23 23:58:43.772714
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1).map(lambda x: x+1)

    assert right.value == 2
    assert right.is_right() == True
    assert right.is_left() == False



# Generated at 2022-06-23 23:58:46.365096
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import mapping
    from pymonet.box import Box

    assert (Right(lambda x: x+5)
        .ap(Right(10))
        .bind(lambda x: Box(x)).value == 15), "Either ap method failed"

# Generated at 2022-06-23 23:58:48.534936
# Unit test for method case of class Either
def test_Either_case():
    assert Either(None).case(lambda _: 1, lambda _: 2) == 2
    assert Either(None).case(lambda _: 1, lambda _: 2) != 3


# Generated at 2022-06-23 23:58:49.654050
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x * 2) == Right(4)



# Generated at 2022-06-23 23:58:52.509031
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(5).bind(lambda x: Left("A")) == Left("A")
    assert Right("B").bind(lambda x: Left(x.lower())) == Left("b")
    assert Right("C").bind(lambda x: Right("D")) == Right("D")
    assert Right("E").bind(lambda x: Right(x.lower())) == Right("e")



# Generated at 2022-06-23 23:58:55.008566
# Unit test for method map of class Right
def test_Right_map():
    func = Right(lambda x: x ** 2)
    assert func.map(lambda x: x(2)) == Right(4)
    assert func.map(lambda x: x(3)) == Right(9)

# Generated at 2022-06-23 23:58:56.161188
# Unit test for method is_left of class Right
def test_Right_is_left():
    e = Right(5)
    assert not e.is_left()


# Generated at 2022-06-23 23:58:57.031150
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False



# Generated at 2022-06-23 23:58:58.742768
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(10)

    assert right.to_maybe() == Maybe.just(10)

# Generated at 2022-06-23 23:59:01.354682
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Try(5).to_lazy() == Lazy(lambda: 5)
    assert Try(5, is_success=False).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-23 23:59:05.849943
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() is False
    assert Right(None).is_right() is True


# Generated at 2022-06-23 23:59:08.674453
# Unit test for method map of class Left
def test_Left_map():
    # Given
    e = Left(5)

    # When
    actual = e.map(lambda n: n * n)

    # Then
    assert actual == Left(5)
    assert actual.value == 5



# Generated at 2022-06-23 23:59:15.470725
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    right: Either[int] = Right(2)
    mapper: Callable[[int], int] = lambda x: x + 2
    expected: Either[int] = Right(4)
    # When
    result: Either[int] = right.bind(mapper)
    # Then
    assert result == expected



# Generated at 2022-06-23 23:59:17.859421
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left("Error").to_box() == Box("Error")


# Generated at 2022-06-23 23:59:20.354093
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:59:26.528331
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    # GIVEN: Left with value
    left = Left(1)

    # WHEN: Call method to_validation
    result = left.to_validation()

    # THEN: Result is failed Validation
    assert isinstance(result, Validation) and result.is_fail() and result.value == [1]


# Generated at 2022-06-23 23:59:28.149119
# Unit test for constructor of class Either
def test_Either():
    result = Left(1)
    assert result.value == 1


# Generated at 2022-06-23 23:59:32.006053
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(5).bind(lambda x: Right(x + 4)) == Right(9)
    assert Right(5).bind(lambda x: Left(x + 4)) == Left(9)


# Generated at 2022-06-23 23:59:33.115766
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Either(True).is_left()


# Generated at 2022-06-23 23:59:34.409790
# Unit test for constructor of class Right
def test_Right():
    assert Right('value') == Right('value')



# Generated at 2022-06-23 23:59:37.332465
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    maybe = Right('test value').to_maybe()
    assert isinstance(maybe, Maybe)
    assert maybe.equals(Maybe.just('test value'))


# Generated at 2022-06-23 23:59:40.428630
# Unit test for method ap of class Either
def test_Either_ap():

    from pymonet.maybe import Maybe

    def add(a, b):
        return a + b

    assert Left(2).ap(Maybe.just(2)) == Left(2)
    assert Right(2).ap(Maybe.just(2)) == Right(4)
    assert Right(2).ap(Maybe.nothing()) == Right(None)

# Generated at 2022-06-23 23:59:44.264378
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)

# Generated at 2022-06-23 23:59:45.451594
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-23 23:59:52.365738
# Unit test for method case of class Either
def test_Either_case():
    """
    The case method takes 2 functions and apply the first one if value is left or the second one if value is right.

    >>> Left('Oh no').case(lambda value: 'Error: {}'.format(value), lambda value: 'Success: {}'.format(value))
    'Error: Oh no'
    >>> Right('Hello world').case(lambda value: 'Error: {}'.format(value), lambda value: 'Success: {}'.format(value))
    'Success: Hello world'
    """
    pass



# Generated at 2022-06-23 23:59:57.055060
# Unit test for method is_right of class Right
def test_Right_is_right():
    """
    Unit test for method is_right of class Right.

    """
    assert Right(5).is_right()


# Generated at 2022-06-24 00:00:03.349064
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.monad_try import Try

    left_a = Left("An error occured")
    assert left_a.map(lambda x: x+1) == Left("An error occured")

    right_a = Right(1)
    assert right_a.map(lambda x: x+1) == Right(2)

    right_a_map_to_maybe = right_a.map(lambda x: x+1).to_maybe()
    assert right_a_map_to_maybe == Try(lambda: Just(2)).unsafe_get_value()


# Generated at 2022-06-24 00:00:05.967900
# Unit test for method case of class Either
def test_Either_case():
    error_handler = lambda value: 1
    success_handler = lambda value: 0
    assert Left(0).case(error_handler, success_handler) == 1
    assert Right(0).case(error_handler, success_handler) == 0



# Generated at 2022-06-24 00:00:07.331112
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Left('some error') == Left('some error')


# Generated at 2022-06-24 00:00:07.852312
# Unit test for method ap of class Left
def test_Left_ap():
    pass

# Generated at 2022-06-24 00:00:10.380226
# Unit test for method is_right of class Right
def test_Right_is_right():
    value = 'foo'
    right: Either[str] = Right(value)
    assert isinstance(right, Either)
    assert isinstance(right, Right)
    assert not isinstance(right, Left)
    assert right.is_right()
    assert not right.is_left()



# Generated at 2022-06-24 00:00:11.754065
# Unit test for method is_left of class Right
def test_Right_is_left():
    _r = Right(1)
    assert _r.is_left() == False


# Generated at 2022-06-24 00:00:12.877875
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(""), Either)



# Generated at 2022-06-24 00:00:16.781339
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try

    def f(value):
        if value % 2 == 0:
            return Right(value)
        else:
            return Left(value)

    f(4).bind(f).bind(f).case(
        lambda value: print(value),
        lambda value: print('Success with: %i' % value))
    f(5).bind(f).bind(f).case(
        lambda value: print(value),
        lambda value: print('Success with: %i' % value))


if __name__ == '__main__':
    test_Right_bind()

# Generated at 2022-06-24 00:00:24.658038
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Right(lambda a: a + 1).ap(Right(1)) == Right(2)
    assert Right(lambda a: a + 1).ap(Left(1)) == Left(1)

    assert Right(lambda a: a + 1).ap(Either.to_either(Lazy(lambda: 1))) == Right(2)
    assert Right(lambda a: a + 1).ap(Either.to_either(Lazy(lambda: None))) == Left(None)

    assert Right(lambda a: a + 1).ap(Either.to_either(Validation.success(1))) == Right(2)
    assert Right(lambda a: a + 1).ap(Either.to_either(Validation.fail([1]))) == Left(1)


# Generated at 2022-06-24 00:00:30.062502
# Unit test for method case of class Either
def test_Either_case():
    """
    Case test.
    """
    def test_case(either: Either[T], success_func: Callable[[T], U], error_func: Callable[[T], U]) -> bool:
        """
        Take Either, error function and success function and call one of them with Either value.

        :param either: Either monad
        :type either: Either[A]
        :param error_func: Error handler
        :type error_func: Function(A) -> B
        :param success_func: Success handler
        :type success_func: Function(A) -> B
        :returns: True if Either is Left, call error_func and check result, True if Either is Right, call success_func
                  and check result
        :rtype: Boolean
        """

# Generated at 2022-06-24 00:00:31.939475
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('some value').is_left() == False


# Generated at 2022-06-24 00:00:33.143210
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(Any).is_left()


# Generated at 2022-06-24 00:00:34.722259
# Unit test for constructor of class Either
def test_Either():
    """Unit test of Either constructor"""
    val = Either(5)
    assert val


# Generated at 2022-06-24 00:00:44.076281
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import Lazy

    assert Right(2).ap(Lazy(lambda: lambda x: x + 1)) == Right(3)
    assert Left(2).ap(Lazy(lambda: lambda x: x + 1)) == Left(2)
    assert Right(2).ap(Lazy(lambda: Left(1))) == Left(1)
    assert Left(2).ap(Lazy(lambda: Left(1))) == Left(1)
    assert Right(2).ap(Lazy(lambda: Right(1))) == Right(1)
    assert Left(2).ap(Lazy(lambda: Right(1))) == Left(2)


# Generated at 2022-06-24 00:00:48.652346
# Unit test for method case of class Either
def test_Either_case():
    # Uncomment to see failure message
    # print(Either(1).case(lambda _: 2, lambda _: 15))
    assert Either(1).case(lambda _: 2, lambda _: 15) == 15
    assert Either(2).case(lambda _: 2, lambda _: 15) == 2



# Generated at 2022-06-24 00:00:52.482104
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    left = Left(2)
    assert left.ap(Box(lambda x: x + 3)).value == 5
    assert left.ap(Try(lambda x: x + 3)).is_fail()



# Generated at 2022-06-24 00:00:53.333859
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1



# Generated at 2022-06-24 00:00:54.729253
# Unit test for method map of class Left
def test_Left_map():
    either = Left(122).map(lambda x: x + 1)
    assert either == Left(122)


# Generated at 2022-06-24 00:00:57.006676
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-24 00:00:59.445516
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)


# Generated at 2022-06-24 00:01:01.279563
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(4).to_box() == Box(4)
    assert Left('hi').to_box() == Box('hi')


# Generated at 2022-06-24 00:01:02.690673
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(10)
    mapper = lambda x: Right(x + 1)
    assert left.bind(mapper) == left

# Generated at 2022-06-24 00:01:03.801844
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(5).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:09.470536
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x).value == 1
    assert Right(1).map(lambda x: x + 1).value == 2
    assert Right(1).map(lambda x: []).value == []
    assert Right(1).map(lambda x: [[]]).value == [[]]
    assert Right(1).map(lambda x: 2).value == 2



# Generated at 2022-06-24 00:01:12.564062
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-24 00:01:16.059961
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Test for equality between instances of class Left

# Generated at 2022-06-24 00:01:17.845731
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def h():
        return 2

    assert Either(1).to_lazy() == Either(2).to_lazy().map(h)



# Generated at 2022-06-24 00:01:19.753625
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    box = Either(10).to_box()
    assert isinstance(box, Box)
    assert box == Box(10)


# Generated at 2022-06-24 00:01:22.198995
# Unit test for method is_right of class Either
def test_Either_is_right():
    def test(left_or_right):
        assert left_or_right.is_right() == (not (isinstance(left_or_right, Left)))

    test(Left(1))
    test(Right(1))

# Generated at 2022-06-24 00:01:23.356097
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right()


# Generated at 2022-06-24 00:01:25.054584
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:01:28.517234
# Unit test for method map of class Right
def test_Right_map():
    right = Right(50)
    assert right.map(lambda x: x * 2) == Right(100)



# Generated at 2022-06-24 00:01:36.498556
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Test Either.to_box() method. Convert Either to Box"""
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)

    assert Left(Lazy(lambda: 1)).to_box() == Box(Lazy(lambda: 1))
    assert Right(Lazy(lambda: 1)).to_box() == Box(Lazy(lambda: 1))

    assert Left(Try(1)).to_box() == Box(Try(1))
    assert Right(Try(1)).to_box() == Box(Try(1))


# Generated at 2022-06-24 00:01:38.978588
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('some') == Left('some').ap(Left(lambda x: x))
    assert Left('left') == Left('left').ap(Right((lambda x: x)))


# Generated at 2022-06-24 00:01:40.116956
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right('a').to_box() == Box('a')
    assert Left('a').to_box() == Box('a')


# Generated at 2022-06-24 00:01:41.390047
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)

    assert left.to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:01:43.705362
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-24 00:01:46.081401
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-24 00:01:47.506164
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()


# Generated at 2022-06-24 00:01:51.627238
# Unit test for constructor of class Left
def test_Left():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == \
        Validation.fail(['error'])
    
    assert Left('error').case(lambda _: 'result', lambda _: 'error') == 'result'


# Generated at 2022-06-24 00:01:53.077490
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-24 00:02:03.912508
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    left = Left(3)
    assert left.ap(Box(lambda a: a*2)) == Box(3)
    assert left.ap(Try(lambda a: a*2)) == Try(3, is_success=True)
    assert left.ap(Lazy(lambda: lambda a: a*2)) == Lazy(lambda: 3)
    assert left.ap(Maybe.just(lambda a: a*2)) == Maybe.nothing()
    assert left.ap(Validation.success(lambda a: a*2)) == Validation.fail([3])

# Generated at 2022-06-24 00:02:10.992694
# Unit test for method ap of class Either
def test_Either_ap():
    value = Either.of('test')
    func = Either.of(lambda x: x.upper())

    result = func.ap(value)

    assert not result.is_right()
    assert isinstance(result, Left)
    assert result.value == 'TEST'

    value = Either.of('test')
    func = Either.of(lambda x: x.upper())

    result = value.ap(func)

    assert not result.is_right()
    assert isinstance(result, Left)
    assert result.value == 'TEST'

    value = Right.of('test')
    func = Either.of(lambda x: x.upper())

    result = func.ap(value)

    assert not result.is_right()
    assert isinstance(result, Left)
    assert result.value == 'TEST'

   

# Generated at 2022-06-24 00:02:17.082885
# Unit test for constructor of class Either
def test_Either():
    from pymonet.algebra import identity as id_
    error = Right(1)
    assert error.case(id_, id_) == 1
    error = Right(1)
    assert error.case(id_, id_) == 1
    error = Left('error')
    assert error.case(id_, id_) == 'error'
    error = Left('error')
    assert error.case(id_, id_) == 'error'

# Generated at 2022-06-24 00:02:18.785956
# Unit test for method map of class Left
def test_Left_map():
    assert Left(5).map(lambda x: 2 * x) == Left(5)

# Generated at 2022-06-24 00:02:20.198585
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Validation.success(5) == Right(5).to_validation()

# Generated at 2022-06-24 00:02:25.077111
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    # ARRANGE
    left = Left(1)
    right = Right(2)
    left2 = Left(1)

    # ACT & ASSERT
    assert left == left
    assert left != right
    assert left == left2
    assert left != None
    assert left != 1
    # ASSERT
    assert right == right
    assert right != left
    assert right != None
    assert right != 1



# Generated at 2022-06-24 00:02:27.711492
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)

    assert left.is_left() == True


# Generated at 2022-06-24 00:02:31.130888
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)

# Generated at 2022-06-24 00:02:32.347629
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-24 00:02:35.042450
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:02:40.122739
# Unit test for method map of class Right
def test_Right_map():

    def f(x):
        return x + 2

    actual = Right(2).map(f)
    expected = Right(4)

    assert actual == expected


# Generated at 2022-06-24 00:02:41.945812
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe().value is None


# Generated at 2022-06-24 00:02:44.054747
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x+1) == Right(2)


# Generated at 2022-06-24 00:02:50.305349
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.maybe import Maybe

    assert Left(10).case(
        error=lambda x: Maybe.just(x),
        success=lambda x: Maybe.nothing()
    ) == Maybe.just(10)
    assert Right(10).case(
        error=lambda x: Maybe.nothing(),
        success=lambda x: Maybe.just(x)
    ) == Maybe.just(10)


# Generated at 2022-06-24 00:02:52.771399
# Unit test for method case of class Either
def test_Either_case():
    func = lambda x: x
    result = Either(6).case(lambda x: x + x, func)
    assert result == 6



# Generated at 2022-06-24 00:02:57.836100
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy().strict(), int)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy().strict(), int)


# Generated at 2022-06-24 00:02:59.358776
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-24 00:03:02.404597
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(2).to_try() == Try(2, is_success=True)
    assert Left("error").to_try() == Try("error", is_success=False)


# Generated at 2022-06-24 00:03:06.430647
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).is_right()
    assert not (Right(1).is_left())
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-24 00:03:07.857050
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(lambda a: a*2)) == Left(1)


# Generated at 2022-06-24 00:03:15.575727
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(10) == Either(10)
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)

    assert Either(10) != Either(15)
    assert Left(10) != Left(15)
    assert Right(10) != Right(15)

    assert Either(10) != Left(10)
    assert Either(10) != Right(10)

    assert Left(10) != Either(10)
    assert Left(10) != Right(10)

    assert Right(10) != Either(10)
    assert Right(10) != Left(10)

    assert Left(10) != Right(10)
    assert Right(10) != Left(10)



# Generated at 2022-06-24 00:03:17.376550
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(value):
        return Right(value + 1)

    assert Right(1).bind(mapper) == Right(2)


# Generated at 2022-06-24 00:03:22.274098
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    from random import randint

    v1 = randint(-100, 100)
    v2 = randint(-100, 100)

    m = Maybe.just(v1)

    assert m == Right(v1).to_maybe()
    assert m != Right(0).to_maybe()
    assert m != Right(v2).to_maybe()


# Generated at 2022-06-24 00:03:30.478436
# Unit test for constructor of class Either
def test_Either():

    assert Left('error') == Left('error')
    assert Left('error') != Right('success')
    assert Left('error') != 'error'
    assert Left('error') != 2
    assert Left('error') != Left('error1')
    assert isinstance(Left('error'), Either)

    assert Right('success') == Right('success')
    assert Right('success') != Left('error')
    assert Right('success') != 'success'
    assert Right('success') != 2
    assert Right('success') != Right('success1')
    assert isinstance(Right('success'), Either)



# Generated at 2022-06-24 00:03:33.713042
# Unit test for method bind of class Left
def test_Left_bind():
    def f(val):
        raise ValueError("Left does not support any method")

    left = Left("mock")
    assert left.bind(f) == left

# Generated at 2022-06-24 00:03:35.383878
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('error').is_right()


# Generated at 2022-06-24 00:03:37.186726
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:03:45.279058
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.lazy import Lazy

    result = Right(2).bind(lambda value: Right(value + 5).bind(lambda value: Right(value ** 2)))
    result2 = Right(2).bind(
        lambda value: Right(value + 5).bind(
            lambda value: Lazy(lambda: value ** 2).to_either()))
    result3 = Right(2).bind(
        lambda value: Right(value + 5).bind(
            lambda value: Lazy(lambda: value ** 2).to_box().to_either()))
    expected = Right(49)

    assert result == expected
    assert result2 == expected
    assert result3 == expected



# Generated at 2022-06-24 00:03:50.031313
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(5).to_try() == Try(5)
    assert Right(5).to_try() == Try(5, is_success=True)

