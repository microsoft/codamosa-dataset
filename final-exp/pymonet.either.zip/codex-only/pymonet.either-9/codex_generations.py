

# Generated at 2022-06-23 23:53:47.282624
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe().is_just() and Right(1).to_maybe() == Maybe(1)



# Generated at 2022-06-23 23:53:50.789054
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left

    v = Left(10).to_validation()
    assert isinstance(v, Validation)
    assert v.is_fail()
    assert v.value == [10]



# Generated at 2022-06-23 23:53:57.618788
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    def _validation_test(input_value, expected_value):
        assert expected_value == Left(input_value).to_validation()

    _validation_test('fail1', Validation.fail(['fail1']))
    _validation_test('fail2', Validation.fail(['fail2']))


# Generated at 2022-06-23 23:53:58.951873
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('error').is_left() == True


# Generated at 2022-06-23 23:54:03.300907
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.either import Left
    from pymonet.validation import Validation

    result = Validation.fail(['error'])

    assert isinstance(Left('error').to_validation(), Validation)
    assert Left('error').to_validation() == result


# Generated at 2022-06-23 23:54:07.756295
# Unit test for constructor of class Left
def test_Left():
    assert Left('error message') == Left('error message')
    assert Left(5) == Left(5)
    assert Left(5) != Left(6)
    assert Left(5) != 5


# Generated at 2022-06-23 23:54:09.252084
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left("foo").is_right() == False
    assert Right("foo").is_right() == True


# Generated at 2022-06-23 23:54:11.015199
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(44).bind(lambda x: Right(23)) == Left(44)


# Generated at 2022-06-23 23:54:14.142089
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    val = Validation.success(1)

    assert val == Right(1).to_validation()



# Generated at 2022-06-23 23:54:16.665088
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(2).is_right() is None


# Generated at 2022-06-23 23:54:18.893598
# Unit test for method bind of class Left
def test_Left_bind():
    dummy = 'dummy'
    x = Left(dummy)
    assert x is x.bind(lambda y: y)


# Generated at 2022-06-23 23:54:22.296460
# Unit test for method bind of class Right
def test_Right_bind():
    """Test example of Right bind function"""
    result = Right(1).bind(lambda x: Right(x + 1))
    assert result == Right(2)
    assert result.is_right()
    assert not result.is_left()



# Generated at 2022-06-23 23:54:24.159436
# Unit test for constructor of class Left
def test_Left():
    left = Left('test')
    assert left.value == 'test'
    assert left.is_left() is True
    assert left.is_right() is False



# Generated at 2022-06-23 23:54:27.244659
# Unit test for constructor of class Left
def test_Left():
    assert Left(1).value == 1


# Generated at 2022-06-23 23:54:34.772821
# Unit test for method ap of class Either
def test_Either_ap():
    from fplib.function import Function
    from fplib.either import Either

    def add(x):
        return lambda y: x + y

    def div(x):
        return lambda y: x / y

    assert(Right(2).ap(Right(Function(div(2)))) == Right(1))
    assert(Right(2).ap(Right(Function(add(2)))) == Right(4))
    assert(Left(2).ap(Right(Function(div(2)))) == Left(2))
    assert(Right(2).ap(Left(Function(div(2)))) == Left(Function(div(2))))



# Generated at 2022-06-23 23:54:38.720780
# Unit test for method case of class Either
def test_Either_case():
    assert Right('success').case(lambda _: 'error', lambda e: 'success') == 'success'
    assert Left('error').case(lambda e: 'error', lambda _: 'success') == 'error'


# Generated at 2022-06-23 23:54:40.044960
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:54:42.733364
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Right(2)) == Try(2, is_success=True)
    assert Either.to_try(Left([2])) == Try([2], is_success=False)


# Generated at 2022-06-23 23:54:52.830544
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.monad_list import MonadList
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    error_handler = lambda error: error
    success_handler = lambda result: result

    left = Left(True)
    assert left.ap(Lazy(lambda: lambda x: x)).value == left
    assert left.ap(Try(error_handler)).value == left
    assert left.ap(MonadList([error_handler])).value == left
    assert left.ap(Maybe.nothing()).value == left
    assert left.ap(Box(error_handler)).value == left

# Generated at 2022-06-23 23:54:54.658921
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    either = Right(1)
    assert either.to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:54:56.589823
# Unit test for constructor of class Either
def test_Either():
    assert Left(4) == Left(4)
    assert Right(4) == Right(4)
    assert not(Left(4) == Right(4))



# Generated at 2022-06-23 23:54:59.736899
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(error=lambda x: x + 1, success=lambda x: x) == 1
    assert Left(1).case(error=lambda x: x + 1, success=lambda x: x + 2) == 1
    assert Right(1).case(error=lambda x: x + 2, success=lambda x: x + 1) == 2
    assert Right(1).case(error=lambda x: x + 2, success=lambda x: x) == 1

# Generated at 2022-06-23 23:55:02.419881
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Unit test for method to_box of class Either.

    """
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Left(8).to_box() == Box(8)
    assert Right(8).to_box() == Box(8)
    assert Left(8).to_box() == Try(8)



# Generated at 2022-06-23 23:55:04.101086
# Unit test for constructor of class Either
def test_Either():
    assert 0 == Right(0) == Left(0)
    assert 1 != Right(0)
    assert not (1 == Right(0))


# Generated at 2022-06-23 23:55:11.478237
# Unit test for method ap of class Either
def test_Either_ap():
    """Unit test for method ap of class Either."""
    # given
    class A:
        def __init__(self, value):
            self.value = value

        def __call__(self, other):
            return self.value + other.value

    eith = Right(A(3))
    # when
    result = eith.ap(Right(2))
    # then
    assert result.value == 5

# Generated at 2022-06-23 23:55:12.861928
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert isinstance(Right("Success").is_right(), bool)


# Generated at 2022-06-23 23:55:17.167365
# Unit test for constructor of class Left
def test_Left():
    left = Left(5)
    assert left.value == 5
    assert left.is_left() is True


# Generated at 2022-06-23 23:55:19.496090
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    result = Left("Error").to_validation()
    expected = Validation.fail(["Error"])

    assert expected == result


# Generated at 2022-06-23 23:55:21.980179
# Unit test for constructor of class Left
def test_Left():
    either = Left("Oops!")

    assert either
    assert isinstance(either, Either)
    assert isinstance(either, Left)
    assert not isinstance(either, Right)
    assert either.value == "Oops!"


# Generated at 2022-06-23 23:55:25.083553
# Unit test for constructor of class Right
def test_Right():
    value = 'test'
    right = Right(value)
    assert right.value == value


# Generated at 2022-06-23 23:55:27.471860
# Unit test for method ap of class Left
def test_Left_ap():
    func = lambda x: x + 1
    left = Left(5)
    assert left.ap(Right(func)) == Left(5)


# Generated at 2022-06-23 23:55:28.969895
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:55:30.805715
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:55:33.834576
# Unit test for method case of class Either
def test_Either_case():
    def success(value):
        return value
    def error(value):
        return value

    assert Right(5).case(error, success) == 5
    assert Left(2).case(error, success) == 2


# Generated at 2022-06-23 23:55:37.253984
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x * 2).ap(Left(1)) == Left(1)


# Generated at 2022-06-23 23:55:39.257826
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    square = lambda x: x * x
    assert right.map(square) == Right(1)



# Generated at 2022-06-23 23:55:40.831202
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:55:44.425146
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right([1, 2, 3]).to_maybe() == Maybe.just([1, 2, 3])


# Generated at 2022-06-23 23:55:46.141055
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) != Either(2)
    assert Either(1) != Left(1)
    assert Either(1) != Right(1)



# Generated at 2022-06-23 23:55:48.429984
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(13)
    value = left.to_maybe()
    assert value.is_nothing()



# Generated at 2022-06-23 23:55:51.353435
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation(1, [])


# Generated at 2022-06-23 23:55:54.650509
# Unit test for method ap of class Either
def test_Either_ap():
    assert (lambda x: x + 1).to_box().ap(Right(1)) == Right(2)
    assert (lambda x: x + 1).to_box().ap(Left(1)) == Left(1)



# Generated at 2022-06-23 23:55:56.559989
# Unit test for constructor of class Either
def test_Either():
    assert Left('sth') == Left('sth')
    assert Right('sth') == Right('sth')



# Generated at 2022-06-23 23:55:59.635612
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 2)) == Left(1), "Left.ap(Left(f)) should be Left(a)"
    assert Left(1).ap(Right(lambda x: x + 2)) == Left(1), "Left.ap(Right(f)) should be Left(a)"



# Generated at 2022-06-23 23:56:02.414509
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(42).to_validation() == Validation.success(42)



# Generated at 2022-06-23 23:56:05.035410
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Right(1).to_validation()



# Generated at 2022-06-23 23:56:09.798278
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(1), Left)
    assert isinstance(Left(1), Either)
    assert isinstance(Right(1), Right)
    assert isinstance(Right(1), Either)


# Generated at 2022-06-23 23:56:10.722177
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:56:12.164767
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-23 23:56:13.081567
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert (Right(5).to_validation().is_success())


# Generated at 2022-06-23 23:56:13.961021
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(str) == Right(str(1))



# Generated at 2022-06-23 23:56:15.567423
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-23 23:56:18.398886
# Unit test for method case of class Either
def test_Either_case():
    def success_handler(v):
        return v + 1

    def error_handler(v):
        return v * 2

    assert Left(1).case(error_handler, success_handler) == 2
    assert Right(1).case(error_handler, success_handler) == 2


# Generated at 2022-06-23 23:56:19.568382
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    assert Left(10).ap(Box(lambda x: x ** 2)) == Left(10)


# Generated at 2022-06-23 23:56:26.437819
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(1)) == Right(2)
    assert Right(lambda x: x + 1).ap(Left("Error")) == Left("Error")
    assert Left("Error").ap(Right(1)) == Left("Error")
    assert Left("Error").ap(Left("Err")) == Left("Error")



# Generated at 2022-06-23 23:56:29.131954
# Unit test for method case of class Either
def test_Either_case():
    error = lambda x: x * 2
    success = lambda x: x + 2
    right = Either(10)
    left = Either(10)

    assert right.case(error, success) == 12
    assert left.case(error, success) == 20

# Generated at 2022-06-23 23:56:31.030477
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    import pytest
    from pymonet.maybe import Maybe

    x = Left(2)
    assert x.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:33.961478
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1)
    assert Left(1).to_try() == Try(1, is_success=False)



# Generated at 2022-06-23 23:56:39.501042
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left([1, 2, 3, 4, 5])
    left1 = left.ap(Left(lambda x: x * 3))
    assert left1 is left

# Generated at 2022-06-23 23:56:40.426216
# Unit test for constructor of class Left
def test_Left():
    assert Left(3).value == 3


# Generated at 2022-06-23 23:56:43.330834
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    val = Right('good job')
    assert val.to_maybe().to_string() == 'Just(good job)'



# Generated at 2022-06-23 23:56:45.941237
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:56:50.784755
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    right = Right(1)
    left = Left(1)
    assert right.ap(Right(add)) == Right(2)
    assert right.ap(Right(sub)) == Right(0)

    assert right.ap(Left("msg")) == Left("msg")
    assert left.ap(right) == left

# Generated at 2022-06-23 23:56:54.777192
# Unit test for constructor of class Left
def test_Left():
    either = Left('error')
    assert either.is_left()
    assert not either.is_right()
    assert either.value == 'error'



# Generated at 2022-06-23 23:57:00.632212
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(3).is_left() and not Left('string').is_right()



# Generated at 2022-06-23 23:57:04.838042
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    left = Left('Error')
    assert left.to_box() == left
    assert left.to_box() == Box('Error')

    right = Right('Success')
    assert right.to_box() == right
    assert right.to_box() == Box('Success')



# Generated at 2022-06-23 23:57:06.355702
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:57:11.767195
# Unit test for method ap of class Either
def test_Either_ap():
    # given
    either_left = Left(1)
    either_right = Right(lambda x: x * 2)
    # when
    after_ap = either_left.ap(either_right)
    # then
    assert after_ap == Left(1)



# Generated at 2022-06-23 23:57:16.909412
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    assert Left(1) == Left(1) and Right(1) == Right(1) and not Left(1) == Right(1)
    # Ensure that Either is different class with Try
    assert Left(1) != Try(1) and Right(1) != Try(1)



# Generated at 2022-06-23 23:57:25.769068
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import Functor

    def add(x, y):
        return x + y

    def double(x):
        return x * 2

    left = Left(10)
    right = Right(10)

    left_functor = Functor(lambda x: x * 2)
    right_functor = Functor(lambda x: x + 10)

    assert left.ap(left_functor) == left
    assert right.ap(right_functor) == Functor(add)(right, right_functor)

# Generated at 2022-06-23 23:57:30.532786
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.lazy import Lazy

    assert Right(1) == Right(1)
    assert Right(None) != Right(1)

    assert Left(1) == Left(1)
    assert Left(None) != Left(1)

    assert Left(1) != Right(1)
    assert Left(None) != Right(1)

    assert Right(1) != Left(1)
    assert Right(None) != Left(1)

    assert Left(Lazy(lambda: 1)) != Left(Lazy(lambda: 1))
    assert Right(Lazy(lambda: 1)) != Right(Lazy(lambda: 1))

    # different types
    assert Right(1) != 1
    assert Lazy(lambda: 1) != Left(1)



# Generated at 2022-06-23 23:57:32.235681
# Unit test for method bind of class Left
def test_Left_bind():
    def mapper(value: str) -> Either[str]:
        return Left('not mapped')

    assert Left('test').bind(mapper) == Left('test')



# Generated at 2022-06-23 23:57:36.791074
# Unit test for constructor of class Either
def test_Either():
    left = Left('Error')
    assert left.value == 'Error'

    right = Right('Value')
    assert right.value == 'Value'


# Generated at 2022-06-23 23:57:40.034313
# Unit test for method bind of class Right
def test_Right_bind():
    result = Right("a").bind(lambda x: Right("b"))

    assert isinstance(result, Right)
    assert result.value == "b"

# Generated at 2022-06-23 23:57:43.827546
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])
    assert Left('Test').to_validation() == Validation.fail(['Test'])
    assert Left(1).to_validation().is_failure() == True
    assert Left(1).to_validation().is_success() == False


# Generated at 2022-06-23 23:57:45.226758
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:57:48.400767
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    value = Right([1, 2, 3])
    result = value.to_validation()

    assert result == Validation(True, [1, 2, 3], [])



# Generated at 2022-06-23 23:57:57.815698
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.either import Left, Right
    from pymonet.functions import curry
    from pymonet.lazy import Lazy

    double = lambda x: x * 2
    halve = lambda x: x / 2

    # test case when Either is Right
    assert Right(10).case(double, halve) == 5
    assert Right(10).case(double, halve) + 4 == 9

    # test case when Either is Left
    assert Left(10).case(double, halve) == 20
    assert Left(10).case(double, halve) + 4 == 24

    # test lazy evaluation
    assert Right(Lazy(lambda: 10)).case(double, halve).value() == 5
    assert Right(Lazy(lambda: 10)).case(double, halve).value() + 4 == 9
    assert Left

# Generated at 2022-06-23 23:57:59.969790
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda _: False, lambda _: True)
    assert not Either('error').case(lambda _: False, lambda _: True)



# Generated at 2022-06-23 23:58:00.971389
# Unit test for constructor of class Right
def test_Right():
    r = Right(3)
    assert r.value == 3


# Generated at 2022-06-23 23:58:03.893338
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test case 1
    assert Left(1).to_lazy().eval() == 1
    # Test case 2
    assert Right(1).to_lazy().eval() == 1


# Generated at 2022-06-23 23:58:05.556495
# Unit test for method ap of class Left
def test_Left_ap():
    print('test ap')
    assert Left(2).ap(Left(lambda x: x * x)) == Left(2)


# Generated at 2022-06-23 23:58:07.840415
# Unit test for constructor of class Left
def test_Left():
    assert Either.case(Left(1), lambda x: 2*x, lambda x: True) == 2



# Generated at 2022-06-23 23:58:11.426227
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either.Left(True).to_try() == Try(True, False)
    assert Either.Right(True).to_try() == Try(True, True)


# Generated at 2022-06-23 23:58:13.423445
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(10).is_right()

# Generated at 2022-06-23 23:58:15.158806
# Unit test for method map of class Left
def test_Left_map():
    assert Left(123).map(lambda x: x + 1) == Left(123)



# Generated at 2022-06-23 23:58:16.598877
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(None)
    assert left.is_left()


# Generated at 2022-06-23 23:58:22.017196
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1)
    maybe = right.to_maybe()
    assert maybe.is_just()
    assert maybe.get() == 1
    assert right.value == 1


# Generated at 2022-06-23 23:58:26.816849
# Unit test for method bind of class Left
def test_Left_bind():
    """test_Left_bind"""
    from pymonet.either import Left, Right

    left = Left("left")
    assert left.bind(lambda value: Right(value)) is left


# Generated at 2022-06-23 23:58:28.743879
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(3).to_validation() == Validation.success(3)



# Generated at 2022-06-23 23:58:31.334316
# Unit test for method map of class Right
def test_Right_map():
    right = Right(2)
    right = right.map(lambda x: x * x)
    assert isinstance(right, Right) and right.value == 4


# Generated at 2022-06-23 23:58:37.764232
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert (Left([1, 2]).to_validation() == Validation.fail([1, 2]))


# Generated at 2022-06-23 23:58:38.806998
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() == False



# Generated at 2022-06-23 23:58:42.450269
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(1).to_try() == Success(1)
    assert Success(1).to_try().is_success() == True

    assert Failure(1).to_try() == Failure(1)
    assert Failure(1).to_try().is_success() == False


# Generated at 2022-06-23 23:58:44.076596
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    assert Right(3).to_maybe() == Maybe.just(3)

# Generated at 2022-06-23 23:58:45.096490
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:58:47.630620
# Unit test for method is_right of class Either
def test_Either_is_right():
    either = Left(None)
    assert not either.is_right()
    either = Right(None)
    assert either.is_right()


# Generated at 2022-06-23 23:58:52.927379
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(None).to_lazy() == Lazy(lambda: None)
    assert Right(1).to_lazy().get() == 1
    assert Left(None).to_lazy().get() is None


# Generated at 2022-06-23 23:58:54.467564
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Left(lambda n: n)) == Left(2)
    assert Left(2).ap(Right(lambda n: n)) == Left(2)


# Generated at 2022-06-23 23:58:57.136668
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(True).to_validation() == Validation.success(True)
    assert Right(True).to_validation() == Validation.success(True)


# Generated at 2022-06-23 23:58:59.050344
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Right(x + 1)) == Right(3),\
        "Right of value 2 should bound to a lambda returning Right of value 3"

# Generated at 2022-06-23 23:59:03.281396
# Unit test for method map of class Left
def test_Left_map():
    """Test for method map of class Left"""
    value = 'value'
    left = Left(value)

    def mapper(arg: str) -> str:
        return arg + value

    assert left.map(mapper) == left
    assert left.map(mapper).value == value


# Generated at 2022-06-23 23:59:07.849138
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    monad = Right(1)

    assert monad.to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:59:12.253995
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (Either(1) == Either(2) or Right(1) == Left(1)) == False
    assert Left(1) == Left(1) == True
    assert Right(1) == Right(1) == True
    assert Left(1) == Right(1) == False
    assert Left(1) != Right(1) == True
    assert Right(1) != Left(1) == True
    assert Left(1) != Left(1) == False
    assert Right(1) != Right(1) == False



# Generated at 2022-06-23 23:59:13.713655
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:59:16.276910
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    result = Left(1).to_maybe()

    assert isinstance(result, Maybe) and result.is_nothing()


# Generated at 2022-06-23 23:59:17.756320
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:59:24.944469
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    maybe_just = Right(1).to_try()
    assert isinstance(maybe_just, Try)
    assert maybe_just.is_success() == True
    assert maybe_just.value == 1

    maybe_nothing = Left(1).to_try()
    assert isinstance(maybe_nothing, Try)
    assert maybe_nothing.is_success() == False



# Generated at 2022-06-23 23:59:30.176711
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)


# Generated at 2022-06-23 23:59:35.646085
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(10).ap(Right(lambda x: x ** 2)) == Right(100)
    assert Right(lambda x: x ** 2).ap(Left(10)) == Left(10)
    assert Right(lambda x: x ** 2).ap(Right(10)) == Right(100)
    assert Left(lambda x: x ** 2).ap(Left(10)) == Left(10)
    assert Left(lambda x: x ** 2).ap(Right(10)) == Left(10)



# Generated at 2022-06-23 23:59:37.600878
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(5)) == Lazy(5)
    assert Either.to_lazy(Left(5)) == Lazy(5)

# Generated at 2022-06-23 23:59:39.620750
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda a: a+1) == Right(2)
    assert Right(1).map(lambda a: a+1).value == 2


# Generated at 2022-06-23 23:59:44.858586
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)
    assert Right(1).bind(lambda x: Left(str(x))) == Left(str(1))


# Generated at 2022-06-23 23:59:46.589353
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Try(1, True)
    assert Either(None).to_try() == Try(None, False)


# Generated at 2022-06-23 23:59:51.236655
# Unit test for method map of class Right
def test_Right_map():
    """
    Test for method map where input value is a Right value.
    """

    assert Right(10).map(lambda x: x * 2) == Right(20)


# Generated at 2022-06-23 23:59:54.885298
# Unit test for method map of class Left
def test_Left_map():
    left_to_left = Left(0).map(lambda x: x + 10)
    left_to_left_2 = Left(0).map(lambda x: x - 10)

    assert type(left_to_left) == Left
    assert type(left_to_left_2) == Left
    assert left_to_left == left_to_left_2



# Generated at 2022-06-24 00:00:00.273451
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('')
    cases = [
        {
            'name': 'returns True',
            'expected': True,
            'actual': left.is_left()
        }
    ]

    for case in cases:
        assert case['expected'] == case['actual'], \
            f"{case['name']} \n {case['expected']} != {case['actual']}"


# Generated at 2022-06-24 00:00:04.091550
# Unit test for method map of class Left
def test_Left_map():
    instance = Left(1)

    assert instance.map(lambda x: x * x) == Left(1)


# Generated at 2022-06-24 00:00:04.972343
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(42).is_left()



# Generated at 2022-06-24 00:00:11.390863
# Unit test for method bind of class Right
def test_Right_bind():
    # given: a simple number stored in Right instance
    test_value = Right(2)

    # when: map this number in another number using bind
    result = test_value.bind(lambda x: Right(x + 2))

    # then: result is a new Right with number multiplied by 2
    assert(result == Right(4))



# Generated at 2022-06-24 00:00:12.840035
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(2)
    assert 3 == right.bind(lambda x: x + 1)



# Generated at 2022-06-24 00:00:15.101009
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    value = "Error message"
    left = Left(value)
    validation = left.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.get_error() == [value]



# Generated at 2022-06-24 00:00:17.551604
# Unit test for constructor of class Left
def test_Left():
    x = Left("value")
    assert x.value == "value"


# Generated at 2022-06-24 00:00:20.272514
# Unit test for method map of class Left
def test_Left_map():
    left_either = Left(10)
    left_either_mapped = left_either.map(str)

    assert isinstance(left_either_mapped, Left)
    assert left_either_mapped == left_either



# Generated at 2022-06-24 00:00:21.467251
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 2) == Left(1)



# Generated at 2022-06-24 00:00:26.484834
# Unit test for method map of class Right
def test_Right_map():
    def f(elem):
        return elem + 1

    value = 1
    assert Right(value).map(f) == Right(f(value))
    assert Right(value).map(f).map(abs) == Right(abs(f(value)))


# Generated at 2022-06-24 00:00:32.720883
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')



# Generated at 2022-06-24 00:00:34.646708
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box() == Box(2)
    assert Left('Some error').to_box() == Box('Some error')


# Generated at 2022-06-24 00:00:39.715765
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """Tests Left.to_validation monad transform function."""
    from pymonet.validation import Validation
    from pymonet.helpers import identity

    assert Left('Error').case(identity, identity) == Left('Error').to_validation().case(identity, identity) == Validation.fail(['Error'])


# Generated at 2022-06-24 00:00:47.281912
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    assert Right(1).map(lambda x: x + 2) == Right(3)
    assert Right(1).map(lambda x: x + None) == Right(1)
    assert Right(1).map(Maybe.just) == Right(Maybe.just(1))
    assert Right(1).map(Try.success) == Right(Try.success(1))


# Unit tests for method bind of class Right

# Generated at 2022-06-24 00:00:54.956478
# Unit test for method map of class Right
def test_Right_map():
    assert Right(10).map(lambda x: x ** 2) == Right(100)
    assert Right(10).map(lambda x: x ** 2).map(lambda x: x - 1) == Right(99)
    assert Right(10).map(lambda x: x ** 2).map(lambda x: x - 1).map(lambda x: x / 3) == Right(33)
    assert Right(10).map(lambda x: x ** 2).map(lambda x: x - 1).map(lambda x: x / 3).map(lambda x: x - 15) == Right(18)
    assert type(Right(10).map(lambda x: x ** 2)).__name__ == 'Right'


# Generated at 2022-06-24 00:00:56.365226
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: 2 * x)) == Left(1)



# Generated at 2022-06-24 00:00:58.151977
# Unit test for method bind of class Right
def test_Right_bind():
    a = Right(2)

    def double(x):
        return Right(x * 2)

    assert a.bind(double).value == 4



# Generated at 2022-06-24 00:01:00.924955
# Unit test for method map of class Left
def test_Left_map():
    # Given
    left = Left(1)

    # When
    new_left = left.map(lambda x: x)

    # Then
    assert new_left == left


# Generated at 2022-06-24 00:01:03.421171
# Unit test for constructor of class Right
def test_Right():
    right = Right('pymonet')

    assert right is not None
    assert right.value == 'pymonet'
    assert right.is_right() == True
    assert right.is_left() == False



# Generated at 2022-06-24 00:01:07.970253
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    value = 42
    result = Right(value).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.get_value() == value


# Generated at 2022-06-24 00:01:09.760726
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left("test")
    assert left.ap(Right("other")) == Left("test")


# Generated at 2022-06-24 00:01:12.485198
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test method to_lazy of class Either."""
    assert Right(3).to_lazy().force() == 3
    assert Left(3).to_lazy().force() == 3


# Generated at 2022-06-24 00:01:18.363254
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # prepare
    left = Left(0)
    right = Right(1)

    # execute
    left_eq = left.__eq__(left)
    right_eq = right.__eq__(right)

    # verify
    assert left_eq == True
    assert right_eq == True



# Generated at 2022-06-24 00:01:20.624181
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.either import Right, Left

    assert Right(1).is_right() is True
    assert Left(1).is_right() is False



# Generated at 2022-06-24 00:01:21.876438
# Unit test for method bind of class Left
def test_Left_bind():
    tester = Left("error string")

    def mapper(a):
        return Right(a)

    assert tester.bind(mapper) == Left("error string")



# Generated at 2022-06-24 00:01:23.773329
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(3)
    assert left.bind(lambda x: Right(x + 1)) == left

test_Left_bind()


# Generated at 2022-06-24 00:01:24.904637
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() == False



# Generated at 2022-06-24 00:01:30.206000
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Given
    value = "test"

    # When
    left = Left(value)
    right = Right(value)

    # Then
    assert left.is_right() == False
    assert right.is_right() == True


# Generated at 2022-06-24 00:01:34.084793
# Unit test for constructor of class Either
def test_Either():
    test_value = 'test string'
    right_test = Right(test_value)

    assert right_test.value is test_value



# Generated at 2022-06-24 00:01:37.021826
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    value = 42
    left = Left(value)
    assert left.to_validation() == Validation.fail([value])



# Generated at 2022-06-24 00:01:38.457881
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right() and\
        Right(None).is_right() and\
        not Right(False).is_right()


# Generated at 2022-06-24 00:01:43.414654
# Unit test for method case of class Either
def test_Either_case():
    """
    Test behavior of case method in class Either
    """
    def error(value: str) -> str:
        return "Error: %s" % value

    def success(value: int) -> str:
        return "Success: %s" % value

    left = Left("I'm error")
    assert left.case(success, error) == "Error: I'm error"

    right = Right(123)
    assert right.case(success, error) == "Success: 123"



# Generated at 2022-06-24 00:01:47.286316
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: Right(1))
    assert Left(True).to_lazy() == Lazy(lambda: Left(val=True))



# Generated at 2022-06-24 00:01:50.447270
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """ Unit test of method __eq__ of class Either """

    left = Left(1)
    right = Right(1)

    assert left == left
    assert right == right

    assert left != right


# Generated at 2022-06-24 00:01:54.439518
# Unit test for method map of class Right
def test_Right_map():
    a_right = Right(4)
    a_right_mapped = a_right.map(lambda x: x + 1)
    assert isinstance(a_right_mapped, Right)
    assert a_right_mapped == Right(5)


# Generated at 2022-06-24 00:01:55.260809
# Unit test for method is_right of class Right
def test_Right_is_right():
    instance = Right(1)
    assert instance.is_right()


# Generated at 2022-06-24 00:02:00.261670
# Unit test for constructor of class Right
def test_Right():
    value = 'foo'
    right = Right(value)

    assert isinstance(right, Either)
    assert right.value == value
    assert right.is_right() is True
    assert right.is_left() is False
    assert right == Right(value)
    assert right != Right('bar')
    assert right != Left(value)



# Generated at 2022-06-24 00:02:02.979207
# Unit test for method is_right of class Either
def test_Either_is_right():
    right = Right(1)
    assert right.is_right() is True
    left = Left(1)
    assert left.is_right() is False


# Generated at 2022-06-24 00:02:08.233575
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Unit test for method to_maybe of class Left

    :returns: assertion error if the test has failed, otherwise nothing
    """
    from pymonet.maybe import Maybe
    from pymonet.maybe import Just
    from pymonet.maybe import Nothing

    assert Left('error').to_maybe() == Nothing()
    assert Left('error').to_maybe() == Just(None)


# Generated at 2022-06-24 00:02:10.609115
# Unit test for method to_try of class Either
def test_Either_to_try():
    def raise_error():
        raise Exception('error')

    assert Either(1).to_try() == Try(1, is_success=True)
    assert Either(raise_error()).to_try() == Try(raise_error(), is_success=False)


# Generated at 2022-06-24 00:02:11.953992
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()


# Generated at 2022-06-24 00:02:13.486998
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('error').to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:02:17.900003
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)

    assert Left(1) == Right(1)
    assert Right(1) == Left(1)



# Generated at 2022-06-24 00:02:18.828008
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(0).is_left()


# Generated at 2022-06-24 00:02:20.584850
# Unit test for method map of class Left
def test_Left_map():
    box = Left({})
    assert(box.map(lambda a: True) == box)



# Generated at 2022-06-24 00:02:22.385674
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(ValueError('error'))
    assert left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:02:23.650039
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == None


# Generated at 2022-06-24 00:02:26.164608
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-24 00:02:29.379629
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda a: lambda a: a ** 2).ap(Right(4)) == Right(16)
    assert Right(lambda a: a ** 2).ap(Left('error!!!')) == Left('error!!!')
    assert Left('error!!!').ap(Right(lambda a: a ** 2)) == Left('error!!!')
    assert Left('error!!!').ap(Left('error!!!')) == Left('error!!!')



# Generated at 2022-06-24 00:02:35.882947
# Unit test for method ap of class Either
def test_Either_ap():
    assert Either(lambda a: a + 1).ap(Either(1)).value == 2
    assert Either(lambda a: a + 1).ap(Either(1)).is_right()
    assert Either(lambda a: a + 1).ap(Either('error')).value == 'error'
    assert Either(lambda a: a + 1).ap(Either('error')).is_left()



# Generated at 2022-06-24 00:02:41.891254
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    assert not isinstance(Either(1).to_lazy(), Either)
    assert not isinstance(Left(1).to_lazy(), Either)
    assert not isinstance(Right(1).to_lazy(), Either)

# Generated at 2022-06-24 00:02:49.465785
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1)
    assert right.bind(lambda x: Right(x + 4)) == Right(5)
    assert right.bind(lambda x: Left(x + 4)) == Left(5)

    right_ = Right(1)
    right_.bind(lambda x: Right(x + 4))
    assert right == Right(1)



# Generated at 2022-06-24 00:02:51.725149
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    value = Left.to_maybe(Left(10))
    assert value.is_nothing()


# Generated at 2022-06-24 00:02:55.192978
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    value = 1
    right = Right(value)
    result = right.to_maybe()
    expected = Maybe.just(value)

    assert result == expected



# Generated at 2022-06-24 00:02:57.257749
# Unit test for method is_right of class Either
def test_Either_is_right():
  assert not Left(3).is_right()
  assert Right(3).is_right()


# Generated at 2022-06-24 00:02:59.947852
# Unit test for constructor of class Left
def test_Left():
    left = Left(5)
    assert isinstance(left, Either)
    assert left.value == 5
    assert left.is_left()


# Generated at 2022-06-24 00:03:02.689869
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) != Right(2)
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)


# Generated at 2022-06-24 00:03:03.985673
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('Some error').to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:03:06.583046
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:03:14.602546
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Left(1).to_validation() == Validation.fail([1])
    assert Left('error').to_validation() == Validation.fail(['error'])
    assert Left(Maybe.just(1)).to_validation() == Validation.fail([1])
    assert Left(Maybe.nothing()).to_validation() == Validation.fail([None])
    assert Left(Box(1)).to_validation() == Validation.fail([1])
    assert Left(Box(None)).to_validation() == Validation.fail([None])



# Generated at 2022-06-24 00:03:17.335785
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)  # __equals__ operator
    assert Right(1) == Right(1)  # __equals__ operator
    assert not Left(1) == Right(1)  # __equals__ operator



# Generated at 2022-06-24 00:03:18.913507
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    _ = Left(None)
    assert _.to_maybe() == Maybe.just(None)



# Generated at 2022-06-24 00:03:20.184817
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('').is_right() == False



# Generated at 2022-06-24 00:03:30.841079
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Right, Left
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation


# Generated at 2022-06-24 00:03:34.122651
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(2).to_maybe() == Maybe.just(2)
    assert isinstance(Right(2).to_maybe(), Maybe)


# Generated at 2022-06-24 00:03:38.004737
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation_exception import ValidationException

    left = Left("failure")

    assert left.to_validation() == Validation.fail(["failure"])

# Generated at 2022-06-24 00:03:39.055261
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-24 00:03:43.791741
# Unit test for method to_box of class Either
def test_Either_to_box():

    # Check Lefy change to None
    left = Left(None)
    assert left.to_box().value != left.value
    assert left.to_box().value is None

    # Check Right value
    right = Right(2)
    assert right.to_box().value == right.value
    assert right.to_box().value == 2


# Generated at 2022-06-24 00:03:45.276013
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()

