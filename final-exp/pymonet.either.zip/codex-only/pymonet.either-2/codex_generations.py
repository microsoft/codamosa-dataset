

# Generated at 2022-06-23 23:53:48.850723
# Unit test for constructor of class Left
def test_Left():
    """
    Tests that value is stored correctly
    """
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)


# Generated at 2022-06-23 23:53:51.478041
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left('2').map(lambda x: int(x) + 1) == Left(2)


# Generated at 2022-06-23 23:53:52.613552
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left('value')
    assert left.is_right() is False



# Generated at 2022-06-23 23:53:54.984448
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() is False


# Generated at 2022-06-23 23:53:56.954868
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()



# Generated at 2022-06-23 23:53:58.595126
# Unit test for constructor of class Right
def test_Right():
    """
    >>> test_Right()
    pass
    """
    assert Right(3).value == 3



# Generated at 2022-06-23 23:54:01.153821
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 2)

    assert lazy == Right(2).to_lazy()
    assert lazy == Left(None).to_lazy()


# Generated at 2022-06-23 23:54:07.269862
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_test import MonadTest
    from pymonet.test_utils import assert_right

    MonadTest(Right(1)).is_right(True)
    assert_right(Right(1).is_right(), True)
    assert_right(Left('error').is_right(), False)


# Generated at 2022-06-23 23:54:08.891860
# Unit test for method map of class Left
def test_Left_map():
    assert Left(5).map(lambda x: x*x) == Left(5)


# Generated at 2022-06-23 23:54:11.918286
# Unit test for method bind of class Right
def test_Right_bind():
    """Should apply function and return result."""
    result = Right(1).bind(lambda number: Right(number + 1))

    assert isinstance(result, Right)
    assert result.value == 2



# Generated at 2022-06-23 23:54:17.069071
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda x: x + 1, lambda x: x - 2) == -1
    assert Left(1).case(lambda x: x + 1, lambda x: x - 2) == 2
    assert Left(2).case(lambda x: x + 2, lambda x: x - 3) == 4



# Generated at 2022-06-23 23:54:25.775030
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x*2, lambda x: x*2) == 2
    assert Left(1).case(lambda x: x*2, lambda x: x/1) == 2
    assert Left(3).case(lambda x: x*2, lambda x: x*2) == 6
    assert Left(3).case(lambda x: x*2, lambda x: x/1) == 6

    assert Left(3).case(lambda x: x*2, lambda x: x*2) == 6
    assert Left(2).case(lambda x: x*2, lambda x: x*2) == 4
    assert Right(3).case(lambda x: x*2, lambda x: x*2) == 6
    assert Right(2).case(lambda x: x*2, lambda x: x*2) == 4

# Generated at 2022-06-23 23:54:32.491370
# Unit test for constructor of class Left
def test_Left():
    assert Left("Left value") == Left("Left value")
    assert Left("Left value 1") != Left("Left value 2")
    assert Left("Left value").is_left() is True


# Generated at 2022-06-23 23:54:34.728925
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:54:38.280754
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    a = Right(1).to_maybe()

    assert isinstance(a, Maybe)
    assert a.is_just()
    assert a.value == 1


# Generated at 2022-06-23 23:54:40.347093
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right('success').to_validation() == Validation.success('success')


# Generated at 2022-06-23 23:54:41.657657
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)
    assert Right(5) != Right(6)
    assert Right(5) != Left(6)
    assert Right(5) != 5
    assert Right(5)


# Generated at 2022-06-23 23:54:45.832943
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left("string")
    assert left.ap(Maybe.just(lambda x: x + "Monad")) == left

# Generated at 2022-06-23 23:54:48.235900
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda a: a + 1) == Right(2)
    assert Right(1).map(lambda a: a + 1) != Left(2)



# Generated at 2022-06-23 23:54:50.911466
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    val = Right(1).to_validation()
    assert isinstance(val, Validation)
    assert val.get() == 1



# Generated at 2022-06-23 23:54:52.057325
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:54:54.795019
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1) and Left(1) == Left(1) and Left(1) != Right(2)
    assert not Left(1) == Right(2) and not Right(1) == Left(2)


# Generated at 2022-06-23 23:54:55.680475
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Validation.success(1) == Right(1).to_validation()


# Generated at 2022-06-23 23:54:57.708324
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right('right')
    assert right.to_validation().is_success() is True
    assert right.to_validation() == Validation.success('right')



# Generated at 2022-06-23 23:55:03.328731
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(lambda x: 'error', lambda x: x).__eq__('error')
    assert Right(5).case(lambda x: x, lambda x: x+1).__eq__(6)



# Generated at 2022-06-23 23:55:07.165108
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(2).map(lambda x: x + 1) == Left(2)


# Generated at 2022-06-23 23:55:08.834165
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:55:11.192438
# Unit test for method map of class Left
def test_Left_map():
    left = Left(False)
    assert left.map(lambda x: x) == left

# Unit tests for method bind of class Left

# Generated at 2022-06-23 23:55:14.115742
# Unit test for method case of class Either
def test_Either_case():
    assert Left("hello").case(lambda x: x, lambda x: x) == "hello"
    assert Right("hello").case(lambda x: x, lambda x: x) == "hello"



# Generated at 2022-06-23 23:55:18.361173
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:55:19.953881
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert(Left(1).to_maybe() == Maybe.nothing())

# Generated at 2022-06-23 23:55:24.405319
# Unit test for constructor of class Either
def test_Either():
    assert Left(5) == Left(5), "Either constructor should return Left[5] == Left[5]"
    assert Right(5) == Right(5), "Either constructor should return Right[5] == Right[5]"
    assert Left(5) != Right(5), "Either constructor should return Left[5] != Right[5]"
    assert Right(5) != Left(5), "Either constructor should return Right[5] != Left[5]"

    assert Left(5).value == 5, "Either constructor should return Left[5].value == 5"
    assert Right(5).value == 5, "Either constructor should return Right[5].value == 5"



# Generated at 2022-06-23 23:55:26.299509
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(123).is_right()
    assert not Left("fail").is_right()



# Generated at 2022-06-23 23:55:29.460066
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left('Error').to_try().is_left()
    assert Left('Error').to_try().is_success() == False
    assert Right(5).to_try().is_right()
    assert Right(5).to_try().is_success() == True

# Generated at 2022-06-23 23:55:32.270792
# Unit test for constructor of class Right
def test_Right():
    assert Right(2) == Right(2)
    assert Right(2) != Right(1)
    assert not isinstance(Right(2), Left)
    assert isinstance(Right(2), Either)


# Generated at 2022-06-23 23:55:35.059708
# Unit test for method ap of class Left
def test_Left_ap():
    def function(value):
        return value * 2
    assert Left(True).ap(Right(function)) == Left(True)


# Generated at 2022-06-23 23:55:36.413465
# Unit test for constructor of class Right
def test_Right():
    assert Right('right') == Right('right')



# Generated at 2022-06-23 23:55:38.521057
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(42).to_lazy() == Lazy(lambda: 42)
    assert Left('fail').to_lazy() == Lazy(lambda: 'fail')


# Generated at 2022-06-23 23:55:40.092113
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(8).to_maybe()


# Generated at 2022-06-23 23:55:41.810248
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:55:48.313761
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1)
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)



# Generated at 2022-06-23 23:55:50.507812
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:55:54.838385
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:55:56.312806
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(None).is_right() is None


# Generated at 2022-06-23 23:55:58.993194
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    either = Right(1)
    box = either.to_box()
    assert box == Box(1)


# Generated at 2022-06-23 23:56:01.911400
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().run() == 1
    assert Left(1).to_lazy().run() == 1


# Generated at 2022-06-23 23:56:04.499495
# Unit test for constructor of class Left
def test_Left():
    # Setup
    expected = Left(42)

    # Exercise
    actual = Left(42)

    # Verify
    assert expected == actual


# Generated at 2022-06-23 23:56:14.929240
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Given:
       - monad: Either[A]
       - function: A -> B
    When:
       - sequentially call monad.bind(f)
    Then:
       - result of the call is B
       - bound function is executed
    """
    def mapper(value: str) -> Either[int]:
        """
        Invert value
        """
        return Right(int(value) * -1)

    def test_is_str_int_convertion(value: str) -> bool:
        """
        Test if value is int convertable to str
        """
        try:
            int(value)
        except ValueError:
            return False
        return True

    error = Right(None)
    bound = error.bind(mapper)

# Generated at 2022-06-23 23:56:17.477035
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1)
    assert right.bind(lambda x: x + 1) == 2


# Generated at 2022-06-23 23:56:20.461399
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(2)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:27.730194
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left_value = Left(["Some error"])
    validation = left_value.to_validation()

    assert validation.is_valid() is False, "Validation returned by method to_validation of class Left should be invalid."
    assert validation == Validation.fail(["Some error"]), "Validation returned by method to_validation of class Left should contains previous Left value"



# Generated at 2022-06-23 23:56:29.703766
# Unit test for method case of class Either
def test_Either_case():
    assert Left(0).case(lambda v: False, lambda v: True) == False
    assert Right(0).case(lambda v: False, lambda v: True) == True


# Generated at 2022-06-23 23:56:32.579866
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda _: 'b', lambda _: 'a') == 'a'
    assert Either('a').case(lambda _: 1, lambda _: 2) == 2
    assert Either(1).case(lambda _: 1, lambda _: 2) == 1



# Generated at 2022-06-23 23:56:33.602109
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)
    assert Either('1')
    assert Either(None)



# Generated at 2022-06-23 23:56:34.441629
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('1').is_right() is True



# Generated at 2022-06-23 23:56:38.645353
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(0).is_right() == True



# Generated at 2022-06-23 23:56:39.934771
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(1).is_right())


# Generated at 2022-06-23 23:56:44.376156
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import Functor
    from pymonet.identity import Identity

    identity_functor = Identity(lambda x: x + 1)
    identity_functor.type()

    assert isinstance(identity_functor.ap(Identity(2)), Identity)



# Generated at 2022-06-23 23:56:47.183070
# Unit test for method map of class Left
def test_Left_map():
    f: Callable[[int], int] = lambda x: x * x
    assert Left(1).map(f) == Left(1)


# Generated at 2022-06-23 23:56:50.024285
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    >>> test_Right_to_maybe()
    True
    """
    from pymonet.maybe import Maybe

    right = Right(5)
    assert right.to_maybe() == Maybe.just(5)



# Generated at 2022-06-23 23:56:53.131522
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()



# Generated at 2022-06-23 23:56:54.393486
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(10)
    right = Left(20)

    assert left.ap(right) == left


# Generated at 2022-06-23 23:56:55.513724
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: x + 1) == Left(2)



# Generated at 2022-06-23 23:57:00.379413
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left("error").to_validation() == Validation.fail(["error"])


# Generated at 2022-06-23 23:57:01.824791
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')

    assert(left.is_left())



# Generated at 2022-06-23 23:57:03.413249
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('left').ap(Left('other')) == Left('other')


# Generated at 2022-06-23 23:57:04.816768
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    new = right.map(lambda x: x + 1)

    assert right.value == 1
    assert new.value == 2



# Generated at 2022-06-23 23:57:12.369641
# Unit test for method case of class Either
def test_Either_case():
    # Given
    error_handler = lambda _: 'error'
    success_handler = lambda _: 'success'
    left_either = Left(None)
    right_either = Right(None)
    # When
    left_result = left_either.case(error_handler, success_handler)
    right_result = right_either.case(error_handler, success_handler)
    # Then
    assert left_result == 'error'
    assert right_result == 'success'

# Generated at 2022-06-23 23:57:14.770190
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:57:16.401517
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True



# Generated at 2022-06-23 23:57:18.638000
# Unit test for constructor of class Either
def test_Either():
    error = Left([1, 2, 3])
    success = Right(20)
    assert error.value == [1, 2, 3]
    assert success.value == 20


# Generated at 2022-06-23 23:57:25.403777
# Unit test for method map of class Right
def test_Right_map():
    """
    Test if Right(value) returns Right(mapper(value)) after called on it when mapper is
    a function.

    :returns: nothing, raise error if test fails
    :rtype: None
    """
    from pymonet.functor import FunctorTestUtilities

    FunctorTestUtilities.functor_law_1_f(
        Right,
        callable=lambda number: number + 1,
        value=1
    )



# Generated at 2022-06-23 23:57:30.216370
# Unit test for method case of class Either
def test_Either_case():
    value = "value"
    left = Left(value)
    right = Right(value)
    assert left.case(
        error=lambda value: "error",
        success=lambda value: "success"
    ) == "error"
    assert right.case(
        error=lambda value: "error",
        success=lambda value: "success"
    ) == "success"


# Generated at 2022-06-23 23:57:32.762387
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(x):
        if x == 1:
            return Right(2)
        return Left(x)

    assert Right(1).bind(mapper) == Right(2)
    assert Right(2).bind(mapper) == Left(2)

# Generated at 2022-06-23 23:57:35.323002
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-23 23:57:38.295944
# Unit test for constructor of class Left
def test_Left():
    left = Left('some_error')
    assert left.value == 'some_error'
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-23 23:57:47.782589
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for bind method in class Right.

    :returns: True if the unit test is successfully, else returns False.
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def add2(x: int) -> int:
        return x + 2

    def add_lazy(x: int) -> Lazy[int]:
        return Lazy(lambda: x + 2)

    def add2_try(x: int) -> Try[int]:
        return Try(x + 2)

    def add2_maybe(x: int) -> Maybe[int]:
        return Maybe.just(x + 2)


# Generated at 2022-06-23 23:57:51.314644
# Unit test for constructor of class Left
def test_Left():
    assert Left('test') == Left('test')


# Generated at 2022-06-23 23:57:52.678602
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() is False


# Generated at 2022-06-23 23:57:55.469782
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:57:59.946996
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)



# Generated at 2022-06-23 23:58:02.270113
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:58:06.666682
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.lazy import Lazy

    # Define two succesive functions for case of Either
    def error(value):
        return Lazy(lambda: value ** 2)

    def success(value):
        return Lazy(lambda: value + 1)

    # Apply functions on both Eithers
    assert Left(3).case(error, success).force() == 9
    assert Right(3).case(error, success).force() == 4



# Generated at 2022-06-23 23:58:08.832256
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:58:14.556442
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:58:16.817538
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either.is_right(Left(123)) is False
    assert Either.is_right(Right(123)) is True


# Generated at 2022-06-23 23:58:23.306114
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Both are Left
    assert Left('1') == Left('1')
    assert Right(1) != Left('1')
    assert Left('1') != Right(1)
    assert Right(1) == Right(1)
    assert Right('1') != Right(1)
    assert Left(1) != Left('1')
    assert Left('1') != Right('1')


# Generated at 2022-06-23 23:58:29.468133
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(7).__eq__(Left(7)) == True
    assert Left(7).__eq__(Right(7)) == False
    assert Right(7).__eq__(Left(7)) == False
    assert Right(7).__eq__(Right(7)) == True

# Unit tests for method case of class Either

# Generated at 2022-06-23 23:58:32.649231
# Unit test for method case of class Either
def test_Either_case():
    assert\
        Right(10).case(lambda x: x + 10, lambda x: x * 2) == 20 and\
        Left(10).case(lambda x: x + 10, lambda x: x * 2) == 20



# Generated at 2022-06-23 23:58:37.471351
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert isinstance(Right(1).to_maybe(), Maybe)
    assert Right(1).to_maybe().is_just()
    assert not Right(1).to_maybe().is_nothing()
    assert Right(1).to_maybe().value() == 1


# Generated at 2022-06-23 23:58:38.733490
# Unit test for constructor of class Left
def test_Left():
    left = Left(10)
    assert left.value == 10



# Generated at 2022-06-23 23:58:48.506538
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for method bind of class Right.

    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def inc(x: int) -> int:
        return x + 1

    assert Try(1, is_success=True).bind(inc) == Try(2, is_success=True)
    assert Try(1, is_success=False).bind(inc) == Try(1, is_success=False)

    assert Lazy(lambda: 1).bind(inc) == Lazy(lambda: 2)
    assert Lazy(lambda: 1).bind(lambda: 2) == Lazy(lambda: 2)

    assert Right(1).bind(inc) == Right(2)

# Generated at 2022-06-23 23:58:51.387779
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right() == True


# Generated at 2022-06-23 23:58:53.251613
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:58:57.018017
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.box import Box

    def add(x: int) -> int:
        return x + 5

    left = Left(Box(1)).ap(Box(add))

    assert isinstance(left, Left)


# Generated at 2022-06-23 23:58:59.411184
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right([1]) != Right([1, 2])
    assert (Right(1) == Left(1)) is False
    assert (Right(1) == 1) is False


# Generated at 2022-06-23 23:59:01.138810
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-23 23:59:06.608312
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda x: x * 2) == Right(6)
    assert Right('asd').map(lambda x: x*3) == Right('asdasdasd')



# Generated at 2022-06-23 23:59:13.246074
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Test for method to_validation of class Right.

    :returns: True if it's success, False if it's failure
    :rtype: Boolean
    """
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:59:15.347478
# Unit test for method is_left of class Right
def test_Right_is_left():
    r = Right(True)
    assert r.is_left() is False


# Generated at 2022-06-23 23:59:18.968205
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'abc')
    assert Either(1).to_lazy() == lazy
    assert Either(2).to_lazy() == lazy


# Generated at 2022-06-23 23:59:20.676829
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:59:22.340713
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(10).to_validation() == Validation.fail([10])

# Generated at 2022-06-23 23:59:23.489001
# Unit test for constructor of class Right
def test_Right():
    assert Right(2).value == 2


# Generated at 2022-06-23 23:59:35.494723
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_value1 = "some value"
    left1 = Left(left_value1)
    left2 = Left(left_value1)
    left3 = Left("other value")
    left4 = Right(left_value1)
    right_value1 = "some value"
    right1 = Right(right_value1)
    right2 = Right(right_value1)
    right3 = Right("other value")
    right4 = Left(right_value1)
    assert left1 == left1
    assert left1 == left2
    assert left2 == left1
    assert left2 == left2
    assert left1 != left3
    assert left1 != left4
    assert left2 != left3
    assert left2 != left4
    assert left3 != left1
    assert left3 != left2

# Generated at 2022-06-23 23:59:39.650492
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy(Box(Right(2))).to_lazy().execute() == Lazy(Right(2)).execute()
    assert Lazy(Box(Right(3))).to_lazy().execute() == Lazy(Right(3)).execute()



# Generated at 2022-06-23 23:59:45.186534
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(error=lambda x: x * 2, success=lambda x: x + 2) == 2
    assert Right(1).case(error=lambda x: x * 2, success=lambda x: x + 2) == 3


# Generated at 2022-06-23 23:59:51.854080
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    either1 = Left(1)
    either2 = Left(1)
    assert either1 == either2

    either3 = Right(1)
    either4 = Right(1)
    assert either3 == either4

    assert either1 != either4

# Generated at 2022-06-23 23:59:58.015436
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right = Right(1)
    right1 = Right(1)
    left = Left(1)
    left1 = Left(1)
    assert right == right1
    assert left1 == left
    assert left != right
    assert left1 != right1

# Generated at 2022-06-23 23:59:59.852981
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-24 00:00:03.814251
# Unit test for method map of class Right
def test_Right_map():
    assert Right("1").map(lambda x: int(x) + 1) == Right(2)



# Generated at 2022-06-24 00:00:07.060883
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.function import Function
    from pymonet.lazy import Lazy
    assert (Either.to_lazy(Right(2)) == Lazy(Function(lambda: 2)))
    assert (Left(2).to_lazy() == Lazy(Function(lambda: 2)))


# Generated at 2022-06-24 00:00:09.989019
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(5).to_box() == Box(5)
    assert Right(5).to_box() == Box(5)

# Generated at 2022-06-24 00:00:12.435670
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1).is_left() is True
    assert Left(1).is_right() is False
    assert Left(1).value == 1



# Generated at 2022-06-24 00:00:19.702331
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Right(lambda x: x + 5).ap(Right(6)) == Right(11)
    assert Right(lambda x: x + 5).ap(Left(6)) == Left(6)
    assert Left(6).ap(Right(10)) == Left(6)
    assert Left(6).ap(Left(10)) == Left(6)

    assert Right(lambda x: x + 5).ap(Box(6)) == Right(11)
    assert Left(6).ap(Box(10)) == Left(6)
    assert Right(lambda x: x + 5).ap(Maybe.just(6)) == Right(11)
    assert Right(lambda x: x + 5).ap(Maybe.nothing()) == Right

# Generated at 2022-06-24 00:00:27.546065
# Unit test for method case of class Either
def test_Either_case():
    def success(value):
        return value + 1

    def error(value):
        return "error"

    assert Left(0).case(error, success) == 'error'
    assert Left(1).case(error, success) == 'error'
    assert Right(0).case(error, success) == 1
    assert Right(1).case(error, success) == 2


# Generated at 2022-06-24 00:00:33.030061
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Either.Right('Nice')
    lazy = maybe.to_lazy()
    assert lazy == Lazy(lambda: 'Nice')



# Generated at 2022-06-24 00:00:36.047719
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    left = Left(0)
    box = Box([0, 1, 2])
    maybe = Maybe.just("Hello")
    assert left.ap(box) == Left(0)
    assert left.ap(maybe) == Left(0)

# Generated at 2022-06-24 00:00:39.309937
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.box import Box

    value = Any()
    left = Left(value)
    assert isinstance(left.map(lambda x: Box(x)), Left)
    assert left.map(lambda x: Box(x)) == left


# Generated at 2022-06-24 00:00:42.225461
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either"""
    assert Either(2) == Either(2)
    assert Either(2) != Either('a')



# Generated at 2022-06-24 00:00:46.914506
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    # Test when mapper returns not None value
    assert Left(12).bind(lambda x: x + 12) == 12
    assert Left(12).bind(lambda x: Box(x + 12)) == 12
    assert Left(12).bind(lambda x: Try(x + 12)) == 12
    assert Left(12).bind(lambda x: Try(x + 12, is_success=True)) == 12
    assert Left(12).bind(lambda x: Validation.success(x + 12)) == 12
    assert Left(12).bind(lambda x: Validation.fail(x + 12)) == 12

    # Test when mapper return None value
    assert Left(12).bind(lambda x: None)

# Generated at 2022-06-24 00:00:49.595433
# Unit test for method case of class Either
def test_Either_case():
    def error(x):
        return x + '_error'

    def success(x):
        return x + '_success'

    assert Left(1).case(error, success) == '1_error'
    assert Right(2).case(error, success) == '2_success'


# Generated at 2022-06-24 00:00:52.287863
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('test').is_right() is False


# Generated at 2022-06-24 00:00:58.174808
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    functor = Functor(Left(5))
    try_ = Try(5, is_success=False)
    lazy = Lazy(lambda: 5)

    left = Left(5)
    assert left.ap(functor) == Left(5)
    assert left.ap(try_) == Left(5)
    assert left.ap(lazy) == Left(5)


# Generated at 2022-06-24 00:00:59.548951
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(10)
    assert left.ap(Left(lambda x: x**2)) == Left(10)



# Generated at 2022-06-24 00:01:02.167717
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(3).is_left() == False



# Generated at 2022-06-24 00:01:04.932087
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda _: 0, lambda v: v + 1) == 2
    assert Left(1).case(lambda _: 1, lambda _: 0) == 1


# Generated at 2022-06-24 00:01:13.323791
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # EITHER EQUAL TO OTHER EITHER
    assert Left(1) != Right(2)
    assert Left(1) != Left(2)
    assert Right(1) != Left(2)
    assert Right(1) != Right(2)
    # EITHER EQUAL TO OTHER LEFT
    assert Left(1) != 1
    assert Left(1) != []
    assert Left(1) != ()
    assert Left(1) != {"test": 1}
    # EITHER EQUAL TO OTHER RIGHT
    assert Right(1) != 1
    assert Right(1) != []
    assert Right(1) != ()
    assert Right(1) != {"test": 1}


# Generated at 2022-06-24 00:01:14.353595
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('test').is_left()


# Generated at 2022-06-24 00:01:17.497521
# Unit test for method bind of class Left
def test_Left_bind():
    result = Left(1).bind(lambda x: Right(x + 1))
    assert result == Left(1)



# Generated at 2022-06-24 00:01:19.159346
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:01:20.063297
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-24 00:01:23.044253
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try

    assert Try(lambda x: x + 1).ap(Right(5)) == Try(6)
    assert Try(lambda x: x + 1).ap(Left(5)) == Try(5)


# Generated at 2022-06-24 00:01:25.675199
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('a') == Left('a')
    assert Right(2) == Right(2)
    assert Right(3) != Left(3)
    assert Left(3) != Right(3)
    assert Right(3) != Right('a')
    assert Left(3) != Left('a')



# Generated at 2022-06-24 00:01:31.455566
# Unit test for method ap of class Either
def test_Either_ap():
    """Test Either.ap method"""
    from pymonet.box import Box
    assert Left('error value').ap(Box(lambda x: x*x)) == Left('error value')
    assert Right(5).ap(Box(lambda x: x*x)) == Right(25)



# Generated at 2022-06-24 00:01:38.642926
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(3).ap(Right(lambda x: x + 1)) == Left(3)
    assert Right(3).ap(Left(lambda x: x + 1)) == Left(lambda x: x + 1)
    assert Right(3).ap(Right(lambda x: x + 1)) == Right(4)

    assert Right(2).bind(lambda x: Right(x + 3)) == Right(5)
    assert Left(2).bind(lambda x: Right(x + 3)) == Left(2)

# Generated at 2022-06-24 00:01:39.837672
# Unit test for method map of class Right
def test_Right_map():
    result = Right(5).map(lambda x: x * 2)
    assert isinstance(result, Right) and\
        result == Right(10)


# Generated at 2022-06-24 00:01:41.656529
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try

    assert Left(1).ap(Try.raise_(ZeroDivisionError)) == Left(1)



# Generated at 2022-06-24 00:01:42.852638
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-24 00:01:45.007683
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    Left("error1").to_validation() == Validation.fail(["error1"])


# Generated at 2022-06-24 00:01:48.334627
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)
    assert 2 == Right(2).value



# Generated at 2022-06-24 00:01:52.487939
# Unit test for method case of class Either
def test_Either_case():
    def increment(value):
        return value + 1

    def decrement(value):
        return value - 1

    assert Right(1).case(decrement, increment) == 2
    assert Left(1).case(decrement, increment) == 0


# Generated at 2022-06-24 00:01:53.872563
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True



# Generated at 2022-06-24 00:02:01.278937
# Unit test for method case of class Either
def test_Either_case():
    """
    Unit test for method case of class Either.

    :return:
    """
    from pymonet.monad_try import Try

    try_right = Try.just(3)
    try_left = Try.raise_error('test')

    assert try_right.case(
        lambda error: True,
        lambda success: False
    ) is False
    assert try_left.case(
        lambda error: True,
        lambda success: False
    ) is True


# Generated at 2022-06-24 00:02:07.627914
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Right(2).case(Either.is_left, lambda x: x + 1) == 3
    assert Left("error").case(lambda x: x + "aaa", Either.is_right) == "erroraaa"
    assert Right("ew").case(Left.is_left, lambda x: x + "ew") == "ewew"



# Generated at 2022-06-24 00:02:12.277505
# Unit test for method case of class Either
def test_Either_case():
    assert(Left(2).case(lambda x: x + 1, lambda x: x * 2) == 3)
    assert(Right(2).case(lambda x: x + 1, lambda x: x * 2) == 4)



# Generated at 2022-06-24 00:02:15.174417
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert not Right(1) == Right(2)


# Generated at 2022-06-24 00:02:15.893943
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe().is_just()


# Generated at 2022-06-24 00:02:19.395819
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right == Right(1)
    assert right != Right(2)
    assert right != Left(2)
    assert right.value == 1
    assert right.is_right()
    assert not right.is_left()



# Generated at 2022-06-24 00:02:21.053267
# Unit test for method map of class Left
def test_Left_map():
    left: Either[int] = Left(0)
    result: Either[int] = left.map(lambda value: value + 1)
    assert result.value == 0



# Generated at 2022-06-24 00:02:22.518376
# Unit test for constructor of class Either
def test_Either():
    assert Left(10).case(lambda _: 'error', lambda _: 'success') == 'error', 'Left should return error'
    assert Right(10).case(lambda _: 'error', lambda _: 'success') == 'success', 'Right should return success'


# Generated at 2022-06-24 00:02:23.481300
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('foo').is_left()


# Generated at 2022-06-24 00:02:26.586220
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left('Error')
    validation = left.to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.value == ['Error']



# Generated at 2022-06-24 00:02:37.834302
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.list import List

    assert Maybe.just(lambda x: x + 1).ap(Either.right(3)) == Maybe.just(4)
    assert Maybe.just(lambda x: x + 1).ap(Either.right(None)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Either.left(3)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Either.left(None)) == Maybe.nothing()

    assert Validation.success(lambda x: x + 1).ap(Either.right(3)) == Validation.success(4)
    assert Val

# Generated at 2022-06-24 00:02:40.533077
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:02:45.119494
# Unit test for method bind of class Left
def test_Left_bind():
    assert isinstance(Left(1).bind(lambda x: x + 1), Left)
    assert 5 == Left(1).bind(lambda x: x + 1).value
    assert Left(1).bind(lambda x: x + 1) == Left(1).bind(lambda x: x + 1)


# Generated at 2022-06-24 00:02:51.912154
# Unit test for constructor of class Either
def test_Either():
    left = Left(5)
    right = Right(4)
    assert left == Left(5)
    assert right != Left(4)
    assert left.case(lambda x: x, lambda _: None) == 5
    assert left.case(lambda x: x, lambda _: None) == 5
    assert right.case(lambda _: None, lambda x: x) == 4
    assert left.value == 5
    assert right.value == 4
    assert left.is_left() is True
    assert left.is_right() is False
    assert right.is_left() is False
    assert right.is_right() is True



# Generated at 2022-06-24 00:02:57.742271
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from mock import Mock
    from unittest.mock import patch

    mock_object = Mock()
    mock_object.func_to_mock = Mock(return_value=0)
    with patch('pymonet.maybe.Maybe', mock_object):
        assert Left(1).to_maybe() == Maybe.nothing()
        assert mock_object.called


# Generated at 2022-06-24 00:02:59.471622
# Unit test for constructor of class Right
def test_Right():
    right: Right[int] = Right(42)

    assert right.value == 42


# Generated at 2022-06-24 00:03:05.192306
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # given
    first_right = Right(5)
    second_right = Right(5)
    first_left = Left("failed")
    second_left = Left("failed")

    # when
    actual_1 = first_right.__eq__(second_right)
    actual_2 = first_left.__eq__(second_left)
    actual_3 = first_left.__eq__(second_right)

    # then
    assert actual_1 is True
    assert actual_2 is True
    assert actual_3 is False


# Generated at 2022-06-24 00:03:06.635881
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(11).is_left()



# Generated at 2022-06-24 00:03:07.664734
# Unit test for constructor of class Left
def test_Left():
    assert(Left(2) == Left(2))

# Generated at 2022-06-24 00:03:11.001371
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.utils import identity

    assert Right(identity).ap(Left('something wrong')) == Left('something wrong')
    assert Left('something wrong').ap(Right('something right')) == Left('something wrong')
    assert Right(identity).ap(Right('something right')) == Right('something right')


# Generated at 2022-06-24 00:03:13.907877
# Unit test for method to_try of class Either
def test_Either_to_try():
    # Test Left to Try
    assert Left(2).to_try() == Try(2, is_success=False)

    # Test Right to Try
    assert Right(2).to_try() == Try(2, is_success=True)



# Generated at 2022-06-24 00:03:15.425531
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(2 * x)) == Left(2)



# Generated at 2022-06-24 00:03:18.252510
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Left(123).to_validation(), Validation), 'Transformation must be validation monad'
    assert Left(123).to_validation() == Validation.fail([123]), 'Transformation must be failed validation monad'


# Generated at 2022-06-24 00:03:19.877589
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('error').is_right() == False
    assert Right('success').is_right() == True



# Generated at 2022-06-24 00:03:22.370895
# Unit test for method case of class Either
def test_Either_case():
    """
    test if case method of Either class is correct
    """
    assert Either(4).case(lambda error: error * 2, lambda success: success * 2) == 8


# Generated at 2022-06-24 00:03:26.642784
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(None).to_maybe()
    assert Maybe.nothing() == Left('error').to_maybe()


# Generated at 2022-06-24 00:03:28.024129
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:30.082472
# Unit test for method is_left of class Left
def test_Left_is_left():
    # Setup
    expected = True

    # When
    actual = Left(1).is_left()

    # Assert
    assert expected == actual



# Generated at 2022-06-24 00:03:38.300055
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyResult

    # Test with Left
    result = Left(1).to_lazy()

    assert isinstance(result, Lazy)
    assert isinstance(result.f, LazyResult)
    assert result.f().value == 1

    # Test with Right
    result = Right(1).to_lazy()

    assert isinstance(result, Lazy)
    assert isinstance(result.f, LazyResult)
    assert result.f().value == 1



# Generated at 2022-06-24 00:03:40.375796
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:03:43.663939
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)

    left == left
    left == None
    left != right

    assert isinstance(left, Either) is True
    assert isinstance(right, Either) is True


# Generated at 2022-06-24 00:03:47.336506
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    value = 'something'
    result = Right(value).to_maybe()
    assert result == Maybe.just(value)
