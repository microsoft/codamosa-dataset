

# Generated at 2022-06-23 23:54:00.477764
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Either(2).ap(Box(lambda x: x * x)) == Box(4)
    assert Left(2).ap(Box(lambda x: x * x)) == Left(2)
    assert Either(2).ap(Try(lambda x: x * x, is_success=False)) == Try(2, is_success=False)
    assert Either(2).ap(Lazy(lambda: 3)) == Lazy(lambda: 6)
    assert Left(2).ap(Lazy(lambda: 3)) == Left(2)
    assert Left(2).ap(Try(lambda x: x * x, is_success=True)) == Left(2)


# Generated at 2022-06-23 23:54:02.274321
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(2) == Either(2)
    assert Either(2) != Either(3)


# Generated at 2022-06-23 23:54:07.279599
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(1)
    assert left.is_right() == False
    right = Right(1)
    assert right.is_right() == True


# Generated at 2022-06-23 23:54:09.716869
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)



# Generated at 2022-06-23 23:54:15.543229
# Unit test for method case of class Either
def test_Either_case():
    value = "right"
    left = Left(value)
    right = Right(value)

    def error(value: T) -> int:
        return -1

    def success(value: T) -> int:
        return 1

    assert left.case(error, success) == -1
    assert right.case(error, success) == 1



# Generated at 2022-06-23 23:54:21.283282
# Unit test for method ap of class Either
def test_Either_ap():
    """ Unit test for method ap."""
    assert Right(lambda x: x).ap(Right(5)) == Right(5)
    assert Right(lambda x: x).ap(Left('Error')) == Left('Error')
    assert Left('Some Error').ap(Right(5)) == Left('Some Error')
    assert Left('Some Error').ap(Left('Error')) == Left('Some Error')

# Generated at 2022-06-23 23:54:26.357063
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)

    # neither Left or Right
    try:
        assert Right(1) == None
        assert False
    except NotImplementedError:
        pass

    try:
        assert Left(1) == None
        assert False
    except NotImplementedError:
        pass

    try:
        assert Left(1) == Right(1)
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-23 23:54:32.933946
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.box import Box

    left = Left(1)
    actual = left.ap(Box(lambda value: value + 1))
    expected = Left(1)

    assert actual == expected



# Generated at 2022-06-23 23:54:37.281175
# Unit test for method bind of class Right
def test_Right_bind():
    def double(x):
        return 2*x

    assert Right(2).bind(double) == 4
    assert Right(2).bind(lambda x: x+1) == 3


# Generated at 2022-06-23 23:54:38.672751
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation().is_success() is False


# Generated at 2022-06-23 23:54:41.193347
# Unit test for method bind of class Right
def test_Right_bind():
    """ Unit test for bind of class Right """
    from typing import Callable
    from pymonet.either import Either, Right, Left

    f: Callable[Any, Either[Any]] = lambda value: Right(value)
    assert Right(1).bind(f) == Right(1)

    h: Callable[Any, Either[Any]] = lambda value: Left(-value)
    assert Right(1).bind(h) == Left(-1)

# Generated at 2022-06-23 23:54:44.825728
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right("test").bind(lambda x: Right("%s is test" % x)) == Right("test is test")



# Generated at 2022-06-23 23:54:46.249518
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy = Either(42).to_lazy()

    assert lazy.value() == 42

# Generated at 2022-06-23 23:54:49.561955
# Unit test for method case of class Either
def test_Either_case():
    def error_handler(e): return "error"

    def success_handler(s): return "success"

    assert Left(None).case(error_handler, success_handler) == "error"
    assert Right('value').case(error_handler, success_handler) == "success"


# Generated at 2022-06-23 23:54:52.096584
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert (Either.right(3).to_try() == Try(3))
    assert (Either.left(3).to_try().is_failure())

# Generated at 2022-06-23 23:54:55.992368
# Unit test for method to_try of class Either
def test_Either_to_try():
    try:
        raise Exception('Error')
    except Exception as e:
        error = e.args[0]
        assert Left(error).to_try().value == error
        assert Left(error).to_try().is_success == False
        assert Right(error).to_try().value == error
        assert Right(error).to_try().is_success == True

# Generated at 2022-06-23 23:54:57.050320
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('some').to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:55:03.969026
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_lazy import Lazy

    assert Right(2).ap(Box(lambda x: x + 3)) \
        == Box(5)

    assert Left('Error!!!').ap(Box(lambda x: x + 3)) \
        == Left('Error!!!')

    assert Right(2).ap(Try(lambda x: x + 3, is_success=True)) \
        == Try(5, is_success=True)

    assert Right(2).ap(Try(lambda x: x + 3, is_success=False)) \
        == Try('Error!!!', is_success=False)


# Generated at 2022-06-23 23:55:08.564832
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    def function():
        return 1
    assert Either(function()).to_lazy() == Lazy(function)


# Generated at 2022-06-23 23:55:11.920452
# Unit test for method ap of class Left
def test_Left_ap():
    left_val = Left('test_value')
    right_val = Right('test_value')
    assert left_val.ap(left_val) == left_val
    assert left_val.ap(right_val) == left_val


# Generated at 2022-06-23 23:55:13.316828
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:55:20.016556
# Unit test for method ap of class Left
def test_Left_ap():
    """
    If Right(A) is applicative contains function, that function should never be called on value of Left.
    In case of Left(A) function should never be called.
    """
    def dummy_mapper(value):
        raise SyntaxError()

    assert isinstance(Left(None).ap(Right(dummy_mapper)), Left)

# Generated at 2022-06-23 23:55:24.757946
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left_either = Left('error')
    result = left_either.to_validation()

    expected = Validation.fail(['error'])
    assert result == expected



# Generated at 2022-06-23 23:55:27.223207
# Unit test for constructor of class Left
def test_Left():
    """It should create instance of Left"""
    left = Left(1)

    assert isinstance(left, Left)
    assert left.value == 1


# Generated at 2022-06-23 23:55:32.969876
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert not(Either(1) == Either(2))
    assert not(Left(1) == Right(1))
    assert Left(1) == Left(1)
    assert Left(1) == Either(1)
    assert Right(1) == Either(1)
    assert not(Left(1) == None)



# Generated at 2022-06-23 23:55:38.132962
# Unit test for method case of class Either
def test_Either_case():
    def add(x: int) -> int: return x + 1
    def sub(x: int) -> int: return x - 1
    assert(Right(2).case(error=sub, success=add) == 3)
    assert(Left(2).case(error=sub, success=add) == 1)

# Generated at 2022-06-23 23:55:40.419607
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left('').to_box() == Box('')
    assert Right('foo').to_box() == Box('foo')



# Generated at 2022-06-23 23:55:42.367962
# Unit test for method map of class Left
def test_Left_map():
    left = Left("error")
    assert left.map(lambda _: None) == left
    assert left.map(lambda _: None) is not left



# Generated at 2022-06-23 23:55:48.706544
# Unit test for method ap of class Either
def test_Either_ap():
    # given
    one: Either[int] = Right(1)
    adding = (lambda x: lambda y: x + y)
    two: Either[int] = Right(2)
    three: Either[int] = Right(3)
    four: Either[int] = Right(4)

    # when
    one_plus_two: Either[int] = one.ap(adding.to_box())
    two_plus_three: Either[int] = two.ap(adding.to_lazy())
    three_plus_four: Either[int] = three.ap(adding.to_try())
    another_one_plus_two: Either[int] = (adding.to_either()).ap(two)

    # then
    assert one_plus_two == Right(3)

# Generated at 2022-06-23 23:55:52.401708
# Unit test for constructor of class Right
def test_Right():
    # given
    value = "good"

    # when
    result = Right(value)

    # then
    assert result.__class__ == Right
    assert result.value == value



# Generated at 2022-06-23 23:55:53.558031
# Unit test for constructor of class Left
def test_Left():
    L = Left(3)
    assert L.value == 3


# Generated at 2022-06-23 23:55:54.896340
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    maybe = Left('error value').to_maybe()

    assert maybe == Maybe.nothing()



# Generated at 2022-06-23 23:56:04.093472
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Either, Left, Right
    from pymonet.lazy import Lazy

    lazy_constant2 = Lazy(lambda: lambda x: x + 2)

    left_1 = Either('1')
    left_2 = Either('2')
    left_3 = Either('3')

    assert left_1.ap(Left('1')).value == left_1.value
    assert left_2.ap(Left('1')).value == left_2.value
    assert left_3.ap(Left('1')).value == left_3.value
    assert left_1.ap(lazy_constant2).value == left_1.value
    assert left_2.ap(lazy_constant2).value == left_2.value

# Generated at 2022-06-23 23:56:06.154968
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left([]).is_right()
    assert Right(2).is_right()



# Generated at 2022-06-23 23:56:09.086360
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x)) == Left(1)


# Generated at 2022-06-23 23:56:10.484443
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left.is_right(Left(1))


# Generated at 2022-06-23 23:56:12.202586
# Unit test for method map of class Right
def test_Right_map():
    # Test with left either
    result = Right(123).map(lambda x: 2 * x)
    assert isinstance(result, Right)
    assert result == Right(246)

# Generated at 2022-06-23 23:56:14.276851
# Unit test for method case of class Either
def test_Either_case():
    assert Left(10).case(error=lambda value: value * 2, success=lambda value: value + 10) == 20
    assert Right(10).case(error=lambda value: value * 2, success=lambda value: value + 10) == 20

# Generated at 2022-06-23 23:56:16.227448
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(1).to_box() == Box(1)
    assert Left("error").to_box() == Box("error")


# Generated at 2022-06-23 23:56:17.325521
# Unit test for constructor of class Either
def test_Either():
    either = Either(2)

    assert isinstance(either, Either)
    assert either.value == 2


# Generated at 2022-06-23 23:56:22.725818
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda x: 'error', lambda x: 'success') == 'success'
    assert Either(1).case(lambda x: 1, lambda x: 2) == 2
    assert Either('error').case(lambda x: 'error', lambda x: 'success') == 'error'
    assert Either('error').case(lambda x: 1, lambda x: 2) == 1



# Generated at 2022-06-23 23:56:25.431987
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() == False
    assert Right(None).is_right() == True



# Generated at 2022-06-23 23:56:27.020705
# Unit test for method is_left of class Right
def test_Right_is_left():
    right_class = Right(5)
    assert right_class.is_left() is False


# Generated at 2022-06-23 23:56:33.004363
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    right = Right(lambda x: x + 1)

    assert left.ap(right) == left

# Generated at 2022-06-23 23:56:34.697562
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-23 23:56:39.472473
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.either import Right

    instance = Right(1)

    assert instance.is_right()


# Generated at 2022-06-23 23:56:46.445568
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Apply on Try
    def add_one(value):
        return value + 1

    left_maybe = Try(None)
    assert left_maybe.ap(Left(1)) == Try(None)

    left_try = Try(None)
    assert left_try.ap(Left(add_one)) == Try(None)

    # Apply on Lazy
    lazy = Lazy(lambda: 1)
    assert left_try.ap(left_try) == Try(None)

    lazy = Lazy(lambda: add_one)
    assert left_try.ap(Left(1)) == Try(None)



# Generated at 2022-06-23 23:56:50.307506
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    # to_lazy return Lazy with argument 2
    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-23 23:56:53.789762
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(5).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:55.643328
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(5).to_validation() == Validation.fail([5])


# Generated at 2022-06-23 23:56:56.494908
# Unit test for constructor of class Either
def test_Either():
    assert Either is not None


# Generated at 2022-06-23 23:57:00.120771
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda a: a + 1) == Right(3)



# Generated at 2022-06-23 23:57:03.281779
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1)
    assert right.bind(lambda x: Either.left(x + 1)) == Either.left(2)
    assert right.bind(lambda x: Either.right(x + 1)) == Either.right(2)



# Generated at 2022-06-23 23:57:04.559045
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()


# Generated at 2022-06-23 23:57:05.742316
# Unit test for method is_left of class Left
def test_Left_is_left():
    result = Left(1).is_left()

    assert result == True


# Generated at 2022-06-23 23:57:07.868192
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False, 'Left.is_right() return True'


# Generated at 2022-06-23 23:57:11.464943
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:57:12.980762
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(2)) == Left(1)



# Generated at 2022-06-23 23:57:15.056570
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: x * 2) == Left(3)



# Generated at 2022-06-23 23:57:16.666872
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:57:22.052744
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == Validation.fail(['error'])


# Generated at 2022-06-23 23:57:23.982476
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(5).is_right() == True
    assert Left(5).is_right() == False

# Generated at 2022-06-23 23:57:25.735050
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert NotImplementedError == type(Either(3).is_right())



# Generated at 2022-06-23 23:57:30.850952
# Unit test for constructor of class Left
def test_Left():
    """Unit test for Left constructor."""
    assert Left('left value') == Left('left value')
    assert Left(ValueError('left')) != Left('left value')
    assert Left('left value') != Right(ValueError('right'))


# Generated at 2022-06-23 23:57:35.517118
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Assert that ap method of Either works right. It applies the function inside the Either[A] structure
    to another applicative type.
    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    result = Right(lambda x: x + 1).ap(Box(1))
    assert result == Box(2)

    result = Right(lambda x: x + 1).ap(Try(1))
    assert result == Try(2)

    result = Right(lambda x: x + 1).ap(Lazy(lambda: 1))
    assert result == Lazy(lambda: 2)


# Generated at 2022-06-23 23:57:36.692881
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(2)
    assert right.is_left() is False



# Generated at 2022-06-23 23:57:39.131256
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_list import List

    assert (List(5).ap(Right(lambda x: x * 2)) == List(10))

# Generated at 2022-06-23 23:57:43.539663
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Right(1), Either)
    assert isinstance(Right(1), Right)
    assert Right(1).value == 1
    assert isinstance(Left(1), Either)
    assert isinstance(Left(1), Left)
    assert Left(1).value == 1



# Generated at 2022-06-23 23:57:44.941395
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True

# Generated at 2022-06-23 23:57:47.542929
# Unit test for method map of class Right
def test_Right_map():
    right = Right(2)

    actual = right.map(lambda x: x + 1)
    expected = Right(3)

    assert expected == actual



# Generated at 2022-06-23 23:57:52.446922
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)
    assert Right("Hello World").map(len) == Right(11)



# Generated at 2022-06-23 23:58:04.224611
# Unit test for constructor of class Right
def test_Right():
    from pymonet.monad_maybe import Just
    from pymonet.monad_validation import Success

    assert Right(2) == Right(2)
    assert Right(3).map(lambda x: x + 2) == Right(5)
    assert Right(2).bind(lambda x: Right(x + 2)) == Right(4)
    assert Right(2).case(
        lambda x: 'it is not right',
        lambda x: 'it is right'
    ) == 'it is right'
    assert Right(3).ap(Right(lambda x: x * 2)) == Right(6)
    assert isinstance(Right(1).to_try(), Success)
    assert isinstance(Right(1).to_validation(), Success)
    assert isinstance(Right(1).to_maybe(), Just)


# Generated at 2022-06-23 23:58:07.839313
# Unit test for constructor of class Either
def test_Either():
    assert Either(10)
    assert Either(True)
    assert Either(None)
    assert Either('a')
    assert Either([])
    assert Either({})



# Generated at 2022-06-23 23:58:12.183990
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-23 23:58:13.911397
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:58:15.301965
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:58:17.044087
# Unit test for method case of class Either
def test_Either_case():
    left = Left("Hello")
    right = Right(1)

    assert left.case(lambda x: x + 1, lambda x: x * 2) == "Hello1"
    assert right.case(lambda x: x + 1, lambda x: x * 2) == 2


# Generated at 2022-06-23 23:58:22.174296
# Unit test for method to_validation of class Left
def test_Left_to_validation():

    error = Left(123)
    assert error.to_validation() == Validation.fail([123])



# Generated at 2022-06-23 23:58:26.479598
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Given
    r = Right(1)
    # When
    is_right = r.is_right()
    # Then
    assert is_right is True


# Generated at 2022-06-23 23:58:28.794104
# Unit test for method bind of class Left
def test_Left_bind():
    value = 'value'
    either = Left(value)
    assert either.bind(lambda x: Right(x)) == Left(value)



# Generated at 2022-06-23 23:58:30.252748
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(5).ap(Left(4)) == Left(5)


# Generated at 2022-06-23 23:58:32.319521
# Unit test for method ap of class Left
def test_Left_ap():
    v = Either.Left('test_fail')
    assert v.ap(Either.Right(lambda x: x * 2)) == v

# Generated at 2022-06-23 23:58:36.169433
# Unit test for constructor of class Right
def test_Right():
    assert Right("test").case(lambda x: False, lambda x: True) is True


# Generated at 2022-06-23 23:58:37.372725
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert isinstance(Right(1).is_right(), bool)



# Generated at 2022-06-23 23:58:42.964225
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try().is_success == True
    assert Right(1).to_try().is_failure == False
    assert Right(1).to_try().get() == 1
    assert Right(1).to_try().get_error() == None

    assert Left(1).to_try().is_success == False
    assert Left(1).to_try().is_failure == True
    assert Left(1).to_try().get() == None
    assert Left(1).to_try().get_error() == 1


# Generated at 2022-06-23 23:58:44.006248
# Unit test for method is_right of class Right
def test_Right_is_right():
    r = Right(True)

    assert r.is_right()



# Generated at 2022-06-23 23:58:45.560663
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right('right').to_validation() == Validation.success('right')


# Generated at 2022-06-23 23:58:47.008820
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('left').is_left()



# Generated at 2022-06-23 23:58:51.559573
# Unit test for constructor of class Left
def test_Left():
    expected_result = Left(5)
    assert expected_result == Left(5)



# Generated at 2022-06-23 23:58:54.075614
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Either(123)) == Try(123, is_success=True)
    assert Either.to_try(Either(Exception('123'))) == Try(Exception('123'), is_success=False)

# Generated at 2022-06-23 23:59:00.429292
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left("some error").bind(lambda x: Right(x + "bar")) == Left("some error")



# Generated at 2022-06-23 23:59:05.218605
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-23 23:59:07.935151
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> from pymonet.either import Left, Right
    >>> def inc(value):
    ...     return value + 1
    >>> def square(value):
    ...     return value * value
    >>> Left(1).case(error=inc, success=square)
    2
    >>> Right(1).case(error=inc, success=square)
    1
    """



# Generated at 2022-06-23 23:59:12.972850
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(90)
    assert right.to_maybe() == Maybe.just(90)


# Generated at 2022-06-23 23:59:14.406416
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-23 23:59:17.814547
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) == Either(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Either(2)



# Generated at 2022-06-23 23:59:19.283557
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(True).is_left() is False


# Generated at 2022-06-23 23:59:21.062428
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:59:22.153012
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(1).to_maybe()


# Generated at 2022-06-23 23:59:25.211022
# Unit test for constructor of class Right
def test_Right():
    right_maybe = Right(5)

    assert right_maybe.value == 5
    assert right_maybe.is_right()
    assert not right_maybe.is_left()

# Generated at 2022-06-23 23:59:36.515170
# Unit test for method is_right of class Either
def test_Either_is_right():
    def assert_method_returns_expected_value(method, expected_result):
        """
        Asserts that provided method of provided class returns expected value.

        :param method: method to test
        :type method: Function(Either) -> Boolean
        :param expected_result: expected result
        :type expected_result: Boolean
        :raises AssertionError: when method of class doesn't return expected value
        """
        from pymonet.maybe import Maybe
        assert method(Maybe.nothing()) == expected_result
        assert method(Maybe.just(1)) == expected_result

    assert_method_returns_expected_value(lambda m: m.is_right(), False)
    assert_method_returns_expected_value(lambda m: m.is_left(), True)

# Generated at 2022-06-23 23:59:38.094451
# Unit test for method ap of class Left
def test_Left_ap():
    assert ((Left('foo').ap(Left('bar')))) == (Left('foo'))


# Generated at 2022-06-23 23:59:44.018813
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(None).to_maybe() == Maybe.nothing()
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:59:45.011508
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() == False



# Generated at 2022-06-23 23:59:48.799350
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left("error")
    assert left.to_maybe() == Maybe.nothing()

# Generated at 2022-06-23 23:59:51.547374
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is False
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:59:56.319827
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:59:57.176176
# Unit test for constructor of class Left
def test_Left():
    assert Left('left')


# Generated at 2022-06-23 23:59:59.294399
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(5).to_box().is_empty()
    assert Right(5).to_box().is_full()


# Generated at 2022-06-24 00:00:09.315214
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box

    # complex types
    assert (Left(1) == Left(1)) == True
    assert (Left([1, 2]) == Left([1, 2])) == True
    assert (Left({1:'a', 2:'b'}) == Left({1:'a', 2:'b'})) == True
    assert (Left(Box(1)) == Left(Box(1))) == True

    assert (Right(1) == Right(1)) == True
    assert (Right([1, 2]) == Right([1, 2])) == True
    assert (Right({1:'a', 2:'b'}) == Right({1:'a', 2:'b'})) == True
    assert (Right(Box(1)) == Right(Box(1))) == True

    # complex types and primitive types

# Generated at 2022-06-24 00:00:11.426999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:00:18.769913
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_list import List
    from pymonet.monad_try import Try

    either = Left(lambda x: x * 2).ap(Try(2))

    if not isinstance(either, Left):
        raise AssertionError('Left.ap should return Left with same value')

    if either != Left(lambda x: x * 2):
        raise AssertionError('Left.ap should return Left with same value')

    either = Left(lambda x: x * 2).ap(List(2))

    if not isinstance(either, Left):
        raise AssertionError('Left.ap should return Left with same value')

    if either != Left(lambda x: x * 2):
        raise AssertionError('Left.ap should return Left with same value')

    either = Left('error').ap(Try(2))

# Generated at 2022-06-24 00:00:21.052852
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-24 00:00:29.299036
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1) == Left(1)
    assert Left(1).bind(lambda _: 1) == 1
    assert Left(1).bind(lambda _: Left(1)) == Left(1)
    assert Left(1).bind(lambda _: Right(1)) == Right(1)
    assert Left(1).to_box() == Box(1)
    assert Left(1).to_try() == Try(1, False)
    assert Left(1).ap(Right(lambda x: x+1)) == Left(1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:00:31.892302
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True



# Generated at 2022-06-24 00:00:33.158613
# Unit test for constructor of class Left
def test_Left():
    left = Left(123)
    assert left.value == 123
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-24 00:00:35.537965
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-24 00:00:37.631356
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(0).to_lazy().eval() == Right(0).to_lazy().eval() == 0


# Generated at 2022-06-24 00:00:39.273636
# Unit test for method is_right of class Left
def test_Left_is_right():
    from pymonet.box import Box

    assert not Box(1).is_right()



# Generated at 2022-06-24 00:00:40.708474
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(15).is_right() == True


# Generated at 2022-06-24 00:00:42.842545
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    result = left.ap(Left(2))

    assert result == left



# Generated at 2022-06-24 00:00:45.330135
# Unit test for constructor of class Right
def test_Right():
    value = Right('Right value')

    assert value.value == 'Right value'


# Generated at 2022-06-24 00:00:46.688200
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-24 00:00:49.974830
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Try(1, True)
    assert Either('A').to_try() == Try('A', True)
    assert Either(Exception()).to_try() == Try(Exception(), False)


# Generated at 2022-06-24 00:00:51.846533
# Unit test for constructor of class Left
def test_Left():
    left = Left('value')
    assert left.value == 'value'
    assert isinstance(left.value, str)


# Generated at 2022-06-24 00:00:54.591688
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    Maybe = Either(1)
    Maybe2 = Maybe.to_lazy()
    assert isinstance(Maybe2, Lazy)
    assert Maybe2.value() == 1


# Generated at 2022-06-24 00:00:57.742254
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test Either class method to_box
    """
    assert Either(1).to_box() == Box(1)
    assert Right(2).to_box() == Box(2)
    assert Left(3).to_box() == Box(3)



# Generated at 2022-06-24 00:01:00.463587
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(lambda x: x)
    applicative = Left(1)
    assert left.ap(applicative) == Left(1)


# Generated at 2022-06-24 00:01:02.181092
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert(Left(3).to_validation() == Validation.fail([3]))


# Generated at 2022-06-24 00:01:06.419479
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    left = Left(10)
    right = Right(10)

    assert right.bind(lambda x: Left(x + 1)) == Left(11)
    assert right.bind(lambda x: Right(x + 1)) == Right(11)
    assert left.bind(lambda x: Left(x + 1)) == Left(10)
    assert left.bind(lambda x: Right(x + 1)) == Left(10)



# Generated at 2022-06-24 00:01:13.699023
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """

    def check_to_lazy(e: Either, expected: bool) -> bool:
        """
        Check if Either.to_lazy method return expected result.

        :param e: Either to test
        :param expected: expected result of method to_lazy call
        :return: True if result is as expected, False otherwise
        """
        return e.to_lazy().eval() == expected

    assert check_to_lazy(Left(1), 1)
    assert check_to_lazy(Right(1), 1)



# Generated at 2022-06-24 00:01:20.147828
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + x).ap(Right(2)) == Right(4)
    assert Left(lambda x: x + x).ap(Right(2)) == Left(lambda x: x + x)
    assert Right(lambda x: x + x).ap(Left(2)) == Left(2)
    assert Left(lambda x: x + x).ap(Left(2)) == Left(lambda x: x + x)



# Generated at 2022-06-24 00:01:24.188675
# Unit test for constructor of class Either
def test_Either():
    assert Right(3) == Right(3)
    assert Left(3) == Left(3)
    assert Right(3) == Right('3')
    assert Left(3) == Left('3')
    assert Right(3) != Left(3)
    assert Left(3) != Left(4)
    assert Right(3) != Left('3')


# Generated at 2022-06-24 00:01:28.779982
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('Value').to_lazy() == Lazy(lambda: 'Value')
    assert Right('Value').to_lazy() == Lazy(lambda: 'Value')



# Generated at 2022-06-24 00:01:29.752578
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:01:32.332705
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Either(Try(1, is_success=True)).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:01:36.156477
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(4) == Right(4)
    assert Left(2) == Left(2)
    assert Right(4) != Left(4)
    assert Right({}) != Right({})
    assert Right(4) != 4


# Generated at 2022-06-24 00:01:37.951555
# Unit test for constructor of class Right
def test_Right():
    result = Right('Monad') == Right('Monad')
    assert result, 'unit test for constructor of class Right failed'

# Generated at 2022-06-24 00:01:40.466071
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    def double(value):
        return value * 2

    left_box = Left(Box(double))
    result = left_box.ap(Box(2))

    assert type(result) == Left
    assert result.value == Box(double)



# Generated at 2022-06-24 00:01:42.706795
# Unit test for method case of class Either
def test_Either_case():
    assert Right(5).case(lambda x: x, lambda x: x) == 5
    assert Left('error').case(lambda x: x, lambda x: 'success') == 'error'


# Generated at 2022-06-24 00:01:46.052526
# Unit test for method case of class Either
def test_Either_case():
    """
    Function tests Either case method.

    :returns: None
    :rtype: None
    """
    assert Left(-1).case(lambda x: x ** 2, lambda x: x ** 3) == 1
    assert Right(2).case(lambda x: x ** 2, lambda x: x ** 3) == 8



# Generated at 2022-06-24 00:01:48.652854
# Unit test for method ap of class Left
def test_Left_ap():
    value = "Hey"
    assert Left(value).ap(Left(value)).case(lambda x: x, lambda x: x) == "Hey"



# Generated at 2022-06-24 00:01:53.956069
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Right(1).to_try()
    assert Either(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-24 00:01:57.292410
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: x * 2) == Left(3)
    assert Left(3).map(None) == Left(3)



# Generated at 2022-06-24 00:01:59.663275
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(0).to_box() == Box(0)
    assert Right(0).to_box() == Box(0)


# Generated at 2022-06-24 00:02:02.436277
# Unit test for method bind of class Right
def test_Right_bind():
    expected = Right([1, 2, 3])
    actual = Right([1]).bind(lambda x: x.append(2) or x.append(3) or x)
    assert expected == actual

# Generated at 2022-06-24 00:02:03.704770
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)

    assert left.is_left()



# Generated at 2022-06-24 00:02:04.899137
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-24 00:02:06.524292
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-24 00:02:11.536234
# Unit test for method map of class Right
def test_Right_map():
    assert isinstance(Right(1).map(lambda x: x + 1), Either)
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left('hello').map(lambda x: x + ' World') == Left('hello')
    assert Right(1).map(lambda x: x + 1) == Right(2)
    assert Right('hello').map(lambda x: x + ' World') == Right('hello World')
    assert Right(1).map(lambda x: 1) == Right(1)
    assert Right('hello').map(lambda x: 'hello') == Right('hello')

# Generated at 2022-06-24 00:02:13.946710
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    res = Right("some string").to_validation()
    assert res.is_success()
    assert isinstance(res, Validation)
    assert res.get_value() == "some string"



# Generated at 2022-06-24 00:02:18.541054
# Unit test for method bind of class Left
def test_Left_bind():
    """Test bind method of Left monad"""
    def logger(value):
        def log(input_value: str) -> str:
            return input_value + " " + value
        return log

    assert logger("abc")("xyz") == logger("abc").bind(lambda x: logger(x))


# Unit tests for method bind of class Right

# Generated at 2022-06-24 00:02:20.637992
# Unit test for method bind of class Left
def test_Left_bind():
    # bind method should return the same instance of Left
    assert Left('').bind(lambda a: Right('')) == Left('')



# Generated at 2022-06-24 00:02:23.150013
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: Right(x ** 2)) == Right(9)
    assert Right(3).bind(lambda x: Left(x ** 2)) == Left(9)

# Generated at 2022-06-24 00:02:25.035492
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Right(1).to_maybe()


# Generated at 2022-06-24 00:02:28.647562
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(3).to_box() == Box(3)
    assert Left(3).to_box() == Box(3)


# Generated at 2022-06-24 00:02:30.597808
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(10).is_right() == True


# Generated at 2022-06-24 00:02:36.805441
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Given: a successful Either
    either = Right(5)

    # When: I call method to_try
    tryable = either.to_try()

    # Then: result should be successfull Try monad
    assert isinstance(tryable, Try)
    assert tryable.is_success()
    assert tryable.value == 5


# Generated at 2022-06-24 00:02:38.874424
# Unit test for method to_box of class Either
def test_Either_to_box():
    pass



# Generated at 2022-06-24 00:02:43.884213
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(error=lambda x: x + 1, success=lambda x: x * 2) == 2
    assert Right(1).case(error=lambda x: x + 1, success=lambda x: x * 2) == 2


# Generated at 2022-06-24 00:02:48.480231
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    actual = Left("error").to_validation()
    expected = Validation.fail(["error"])

    assert actual == expected

# Generated at 2022-06-24 00:02:51.166008
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Either(1)
    assert Right(1).value == 1


# Generated at 2022-06-24 00:02:55.193067
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('Some error').ap(Left(lambda x: x + '2')) == Left('Some error')
    assert Left('Some error').ap(Right(lambda x: x + '2')) == Left('Some error')


# Generated at 2022-06-24 00:03:00.396848
# Unit test for method case of class Either
def test_Either_case():
    def raise_error(value):
        raise Exception('Error when Left is not expected')

    assert Either(5).case(raise_error, lambda x: x) == 5
    assert Either(5).case(lambda x: x, raise_error) == 5

    assert Left(5).case(
        lambda value: 'error',
        lambda value: 'success'
    ) == 'error'
    assert Right(5).case(
        lambda value: 'error',
        lambda value: 'success'
    ) == 'success'



# Generated at 2022-06-24 00:03:02.503115
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:03:03.822674
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()


# Generated at 2022-06-24 00:03:06.391466
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(42).to_validation() == Validation.fail([42])


# Generated at 2022-06-24 00:03:07.871933
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("value").is_left() is True



# Generated at 2022-06-24 00:03:11.762622
# Unit test for method case of class Either
def test_Either_case():
    @functools.wraps(Right.map)
    def test_case_function(value):
        return value

    assert Right(1).case(lambda x: x, test_case_function) == 1
    assert Left(1).case(test_case_function, lambda x: x) == 1



# Generated at 2022-06-24 00:03:16.039008
# Unit test for constructor of class Either
def test_Either():
    """
    Test constructor of class Either.

    :param None:
    :type None: None
    :returns: None
    :rtype: None
    """
    err = Left('err')
    assert not err.is_right()
    assert err.value == 'err'

    success = Right(123)
    assert success.is_right()
    assert success.value == 123



# Generated at 2022-06-24 00:03:18.166520
# Unit test for constructor of class Right
def test_Right():
    right = Right("right value")
    assert right.value == "right value"
    assert right.is_right() is True
    assert right.is_left() is False



# Generated at 2022-06-24 00:03:19.438951
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(None).is_right()


# Generated at 2022-06-24 00:03:21.092264
# Unit test for method is_right of class Left
def test_Left_is_right():
    either = Left("foo")

    assert either.is_right() is False


# Generated at 2022-06-24 00:03:25.155022
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Given
    right = Right(True)

    # When
    result = right.is_right()

    # Then
    assert result is True


# Generated at 2022-06-24 00:03:27.488923
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(10).to_validation() == Validation.fail([10])


# Generated at 2022-06-24 00:03:28.736384
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(7).is_left()


# Generated at 2022-06-24 00:03:32.613123
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(Exception()).to_try() == Try(Exception(), is_success=False)
    assert Right(Exception()).to_try() == Try(Exception(), is_success=True)

# Generated at 2022-06-24 00:03:36.392908
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    right = Right(2)

    # When
    result = right.bind(lambda x: x * 2)

    # Then
    assert_that(result, equal_to(Right(4)))



# Generated at 2022-06-24 00:03:38.057454
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)

    assert right.is_right()



# Generated at 2022-06-24 00:03:46.605013
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    from pymonet.monad_list import MonadList
    from pymonet.box import Box

    # Either
    left = Left(1)

    # Either
    right = Right(lambda x: x + 1)

    # MonadTry
    failed_try = Try.failed(1)

    # MonadTry
    successful_try = Try.success(lambda x: x + 1)

    # MonadList
    empty_list = MonadList([])

    # MonadList
    full_list = MonadList([lambda x: x + 1])

    # Box
    empty_box = Box(None)

    # Box
    full_box = Box(lambda x: x + 1)

    assert left.ap(right) == Left(1)

# Generated at 2022-06-24 00:03:54.868736
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 42) == Lazy(lambda: 42) == Either(42).to_lazy() == Either(42).to_lazy()
    assert Lazy(lambda: 'Hello') == Lazy(lambda: 'Hello') == Either('Hello').to_lazy() == Either('Hello').to_lazy()
    assert Lazy(lambda: [1, 2, 3, 4, 5]) == Lazy(lambda: [1, 2, 3, 4, 5]) == Either([1, 2, 3, 4, 5]).to_lazy() == Either([1, 2, 3, 4, 5]).to_lazy()
    assert Lazy(lambda: (1, 2, 3, 4, 5)) == Lazy(lambda: (1, 2, 3, 4, 5)) == Either