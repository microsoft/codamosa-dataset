

# Generated at 2022-06-23 23:53:46.985118
# Unit test for method map of class Left
def test_Left_map():
    left = Left("error")
    assert left.map(lambda x: x) == Left("error")


# Generated at 2022-06-23 23:53:52.721587
# Unit test for method case of class Either
def test_Either_case():

    def error_handler(message):
        return "Something gone wrong: " + message

    def success_handler(number):
        return "Your order number is " + number

    case = Right("234").case(
        error=error_handler,
        success=success_handler
    )

    assert case == "Your order number is 234"

    case = Left("You are not allowed to make this order").case(
        error=error_handler,
        success=success_handler
    )

    assert case == "Something gone wrong: You are not allowed to make this order"


# Generated at 2022-06-23 23:53:58.952253
# Unit test for method case of class Either
def test_Either_case():
    left_value = Left("error").case(lambda x: "error handler: %s" % x, lambda x: "success handler: %s" % x)
    right_value = Right("success").case(lambda x: "error handler: %s" % x, lambda x: "success handler: %s" % x)
    assert left_value == "error handler: error"
    assert right_value == "success handler: success"


# Generated at 2022-06-23 23:54:09.494730
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Should apply function inside Either to applicative.
    """
    from pymonet.monad_try import Try

    result = Either.Right(lambda x: str(x)).ap(Try.just(1))
    assert result.equals(Try.just("1"))

    result = Either.Right(lambda x: str(x)).ap(Try.raise_(Exception()))
    assert result.equals(Try.raise_(Exception()))

    result = Either.Left(Exception()).ap(Try.just(1))
    assert result.equals(Try.raise_(Exception()))

    result = Either.Left(Exception()).ap(Try.raise_(Exception()))
    assert result.equals(Try.raise_(Exception()))



# Generated at 2022-06-23 23:54:12.827174
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_try import Try

    def add_one(integer):
        return Try(integer + 1, is_success=True)

    assert Left(0).bind(add_one) == Left(0)

# Generated at 2022-06-23 23:54:14.789984
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    left = Left('error')
    assert left.ap(Box(lambda x: x)) is left


# Generated at 2022-06-23 23:54:18.360297
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 2)) == Left(1)
    assert Left("error").ap(Left(lambda x: x + "2")) == Left("error")
    assert Left(1).ap(Left(lambda x: x + 2)) == Left(1)
    assert Left(1).ap(Left(lambda x: x + 2)) == Left(1)



# Generated at 2022-06-23 23:54:21.946946
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    # Given
    error = Left("error")

    # When
    maybe = error.to_maybe()

    # Then
    assert isinstance(maybe, Maybe)
    assert maybe.is_nothing()



# Generated at 2022-06-23 23:54:25.198296
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)

    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)



# Generated at 2022-06-23 23:54:31.692273
# Unit test for method is_left of class Right
def test_Right_is_left():
    value = 'value'
    right = Right(value)
    assert not right.is_left()


# Generated at 2022-06-23 23:54:36.115718
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(42).to_box() == Box(42)
    assert Left(42).to_box() == Box(42)
    assert Right(42).to_box() == Box(42)



# Generated at 2022-06-23 23:54:36.943458
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() == False
    assert Right(None).is_right() == True


# Generated at 2022-06-23 23:54:38.322026
# Unit test for method case of class Either
def test_Either_case():
    assert (Right(5).case(lambda _: False, lambda x: x == 5))
    assert not (Left(5).case(lambda _: False, lambda x: x == 5))



# Generated at 2022-06-23 23:54:41.334845
# Unit test for method to_try of class Either
def test_Either_to_try():
    expected = Try(True, True)
    actual = Right(True).to_try()
    assert expected == actual

    expected = Try(False, False)
    actual = Left(False).to_try()
    assert expected == actual

# Generated at 2022-06-23 23:54:46.744276
# Unit test for method map of class Right
def test_Right_map():
    # given
    def add1(x): return x + 1
    m = Right(10)
    # when
    result = m.map(add1)
    # then
    assert isinstance(result, Right)
    assert result.value == 11


# Generated at 2022-06-23 23:54:48.609452
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    l = Left(Box(lambda x: x))
    assert l.ap(Box(3)) == l

# Generated at 2022-06-23 23:54:50.241662
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:54:52.378213
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(None).ap(Left('a')) == Left(None)
    assert Left(None).ap(Right('a')) == Left(None)


# Generated at 2022-06-23 23:54:54.177885
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:54:59.580159
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either('1')
    assert Either('a') == Either('a')
    assert Either([1, 2, 3]) == Either([1, 2, 3])
    assert Either((1, 2, 3)) == Either((1, 2, 3))
    assert Either({'a': 1, 'b': 2}) == Either({'a': 1, 'b': 2})
    assert Either({'a', 'b'}) == Either({'a', 'b'})
    assert Either(1) != 1


# Generated at 2022-06-23 23:55:00.664122
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(None) == Right(None)



# Generated at 2022-06-23 23:55:01.892804
# Unit test for method map of class Right
def test_Right_map():
    value = Right(5)
    assert value.map(lambda x: x * 5) == Right(25)



# Generated at 2022-06-23 23:55:03.643512
# Unit test for method case of class Either
def test_Either_case():
    assert Left("error").case(error_handler, success_handler) == "error handler"
    assert Right("success").case(error_handler, success_handler) == "success handler"



# Generated at 2022-06-23 23:55:06.681191
# Unit test for constructor of class Left
def test_Left():
    maybe_error = Left(Exception('Error'))
    assert maybe_error.value == Exception('Error')


# Generated at 2022-06-23 23:55:11.146808
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    # given
    right = Right(1)
    # when
    maybe = right.to_maybe()
    # then
    assert isinstance(maybe, Maybe)
    assert maybe.is_just()
    assert maybe.value == 1


# Generated at 2022-06-23 23:55:14.726994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test case to check if Either is correctly transformed to lazy.

    :returns: None
    :rtype: None
    """
    assert (Right(5).to_lazy().value == Left(5).to_lazy().value == 5)


# Generated at 2022-06-23 23:55:16.550762
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left("error").to_lazy().value() == "error"


# Generated at 2022-06-23 23:55:17.666914
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-23 23:55:23.427172
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    Test to_maybe method of class Right
    """
    from pymonet.maybe import Maybe

    # When: I call to_maybe method of instance of class Right
    maybe = Right(u"test").to_maybe()

    # Then: I got instance of class Just, which contains the same value as instance of Right
    assert isinstance(maybe, Maybe)
    assert isinstance(maybe.value, str)
    assert maybe.value == u"test"
    assert maybe.is_just()
    assert not maybe.is_nothing()



# Generated at 2022-06-23 23:55:25.744302
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)
    assert Either('a')
    assert Either(6j)
    assert Either(None)



# Generated at 2022-06-23 23:55:35.474149
# Unit test for constructor of class Right
def test_Right():
    def bind_function(value):
        return Right(value * 2)

    right = Right(5)
    assert right.case(lambda x: 'error', lambda x: 'success') == 'success'
    assert right.value == 5
    assert right.is_right()
    assert not right.is_left()
    assert right.bind(lambda x: x * 2) == 10
    assert right.map(lambda x: x * 2) == Right(10)
    assert right.bind(lambda x: Right(x * 2)) == Right(10)
    assert right.bind(bind_function) == Right(10)
    assert right.ap(Right(lambda x: x * 2)) == Right(10)
    assert right.to_box().value.is_right()
    assert right.to_try().value == 5
    assert right

# Generated at 2022-06-23 23:55:37.583272
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:55:38.852114
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(2).to_validation() == Validation.fail([2])

# Generated at 2022-06-23 23:55:42.197901
# Unit test for method case of class Either

# Generated at 2022-06-23 23:55:48.336111
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(2) == Right(2)
    assert Right(2) != Right(3)
    assert Left(2) == Left(2)
    assert Left(2) != Left(3)
    assert Left(2) != Right(2)
    assert Right(2) != Left(2)


# Generated at 2022-06-23 23:55:53.528017
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Test to_try method of class Left
    assert Left(5).to_try() == Try(5, is_success=False)
    # Test to_try method of class Right
    assert Right(5).to_try() == Try(5, is_success=True)


# Generated at 2022-06-23 23:55:57.018871
# Unit test for method bind of class Left
def test_Left_bind():
    new_left = Left(1).bind(lambda x: Right(x))
    assert new_left == Left(1)
    assert new_left.is_left()
    assert new_left.value == 1


# Generated at 2022-06-23 23:55:58.248854
# Unit test for method bind of class Left
def test_Left_bind():
    value = 'left value'
    left = Left(value)
    assert value == left.bind(lambda x: x + '!')


# Generated at 2022-06-23 23:56:00.364125
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Right("e").to_lazy() == Lazy(lambda: "e")

# Generated at 2022-06-23 23:56:04.149028
# Unit test for method is_right of class Left
def test_Left_is_right():
    from pymonet.test_utils import assert_false
    from pymonet.test_utils import assert_true

    left = Left(True)

    assert_false(left.is_right())



# Generated at 2022-06-23 23:56:07.082859
# Unit test for constructor of class Right
def test_Right():
    # GIVEN
    value = 'test'

    # WHEN
    result = Right(value)

    # THEN
    assert(result.value == value)



# Generated at 2022-06-23 23:56:08.540780
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    import pytest

    assert Left('error').to_maybe() == Maybe.nothing()

# Generated at 2022-06-23 23:56:10.341889
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-23 23:56:12.215825
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x + 2)) == Left(2)



# Generated at 2022-06-23 23:56:13.457267
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left("a").to_validation() == Validation.fail(["a"])



# Generated at 2022-06-23 23:56:16.124060
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)


# Generated at 2022-06-23 23:56:17.257196
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left() is True
    assert Left(5).is_right() is False



# Generated at 2022-06-23 23:56:20.062210
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)



# Generated at 2022-06-23 23:56:24.288652
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(2).to_validation() == Validation.fail([2])



# Generated at 2022-06-23 23:56:25.529761
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1

# Generated at 2022-06-23 23:56:28.644283
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() != Box(2)
    assert Left(1).to_box() != Box(2)


# Generated at 2022-06-23 23:56:32.682386
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)



# Generated at 2022-06-23 23:56:33.998450
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:56:41.821037
# Unit test for method bind of class Left
def test_Left_bind():
    l = Left(1)
    assert l.bind(lambda x: Left(x + 1)) == l
    assert l.bind(lambda x: Right(x + 1)) == l
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)
    assert Left(2).bind(lambda x: Left(x + 1)) == Left(2)
    assert Left(1).bind(lambda x: Right(x + 1)).is_left()
    assert Left(2).bind(lambda x: Right(x + 1)).is_left()



# Generated at 2022-06-23 23:56:47.528355
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.spectral_test import spectral_test_foldable_functor

    def generator():
        for item in range(20):
            yield Left(item)

    spectral_test_foldable_functor(generator, 'is_left', True)


# Generated at 2022-06-23 23:56:48.774729
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(4).is_left()


# Generated at 2022-06-23 23:56:53.602782
# Unit test for constructor of class Right
def test_Right():
    assert Right(7) == Right(7)
    assert Right(7) != Right(6)


# Generated at 2022-06-23 23:56:55.758494
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)


# Generated at 2022-06-23 23:56:57.009080
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:56:58.274209
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right('a').to_maybe() == Maybe.just('a')



# Generated at 2022-06-23 23:56:59.541349
# Unit test for method is_right of class Right
def test_Right_is_right():
    value = 1
    e = Right(value)

    assert e.is_right() is True


# Generated at 2022-06-23 23:57:11.465900
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    1. Compare two Right without values
    2. Compare two Right with the same value
    3. Compare two Right with different values
    4. Compare Left without value and Right without value
    5. Compare Left without value and Right with value
    6. Compare Left with value and Right without value
    7. Compare Left and Right with the same value
    """
    # 1. Compare two Right without values
    right1 = Right(None)
    right2 = Right(None)
    assert right1 == right2

    # 2. Compare two Right with the same value
    right1 = Right(1)
    right2 = Right(1)
    assert right1 == right2

    # 3. Compare two Right with different values
    right1 = Right(1)
    right2 = Right(2)
    assert right1 != right2

    # 4.

# Generated at 2022-06-23 23:57:12.574184
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None



# Generated at 2022-06-23 23:57:14.554447
# Unit test for method is_left of class Right
def test_Right_is_left():
    """Should return False"""
    assert Right(3).is_left() is False



# Generated at 2022-06-23 23:57:16.666036
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(2).is_right() is True

# Generated at 2022-06-23 23:57:22.547051
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right('123').to_validation().case(
        success=lambda s: 'len: {}'.format(len(s)),
        error=lambda e: ''
    ) == 'len: 3'


# Generated at 2022-06-23 23:57:29.146733
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x // 2

    def subtract(x):
        return x - 1

    assert Right(4).ap(Right(add)).value == 5
    assert Left(4).ap(Right(add)).value == 4
    assert Right(4).ap(Left(add)).value == 4
    assert Left(4).ap(Left(add)).value == 4

    assert Right(4).ap(Right(multiply)).value == 8
    assert Left(4).ap(Right(multiply)).value == 4
    assert Right(4).ap(Left(multiply)).value == 4
    assert Left(4).ap(Left(multiply)).value == 4


# Generated at 2022-06-23 23:57:30.599623
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:57:31.376902
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)


# Generated at 2022-06-23 23:57:38.560409
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success
    from pymonet.validation import Fail
    def _f(): return Right(True)
    def _f2(): return Right(None)
    v1 = _f().to_validation()
    v2 = _f2().to_validation()
    assert v1 == Success(True)
    assert v2 == Success(None)

# Generated at 2022-06-23 23:57:41.898649
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 2)) == Right(3)
    assert Right(1).bind(lambda x: Left(2)) == Left(2)



# Generated at 2022-06-23 23:57:46.844260
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(lambda x: x).ap(Left("Left")) == Left("Left")
    assert Left("Left").ap(Right(1)) == Left("Left")
    assert Right(lambda x: x).ap(Left("Left")) == Left("Left")
    assert Right(lambda x: x).ap(Right(1)) == Right(1)
    assert Right(1).ap(Right(lambda x: x)) == Right(1)


# Generated at 2022-06-23 23:57:54.193934
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    add = lambda x: lambda y: x + y
    test_add_3 = Either.pure(3).ap(Either.pure(add))

    # Then
    assert test_add_3 == Right(3)

    # Given
    list_ = Either.pure([])

    # Then
    assert list_.ap(Either.pure(list_.value.append)) == Left([])

# Generated at 2022-06-23 23:57:55.285899
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.Right(1).to_try() == Try.success(1)
    assert Either.Left(1).to_try() == Try.failure(1)

# Generated at 2022-06-23 23:57:59.365251
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()


# Generated at 2022-06-23 23:58:00.678708
# Unit test for method is_right of class Left
def test_Left_is_right():
    result = Left('foo').is_right()

    assert result is False


# Generated at 2022-06-23 23:58:03.094213
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left([1, 2, 3]).to_maybe() == Maybe.nothing() is not None


# Generated at 2022-06-23 23:58:04.265785
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:58:05.842565
# Unit test for constructor of class Either
def test_Either():
    assert Either(None) is not None


# Generated at 2022-06-23 23:58:08.101001
# Unit test for constructor of class Left
def test_Left():
    # Given
    left = Left(2)

    # Then
    assert left.value == 2



# Generated at 2022-06-23 23:58:09.730470
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-23 23:58:14.361614
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation().is_success
    assert Right(1).to_validation().value == 1


# Generated at 2022-06-23 23:58:16.214057
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:58:18.664867
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right = Right(2)
    left = Left(1)
    assert right == right
    assert left == left
    assert right != left
    assert not (left == right)



# Generated at 2022-06-23 23:58:22.289825
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(6)
    assert left.bind(lambda x: Left(x + 7)) == left



# Generated at 2022-06-23 23:58:26.063159
# Unit test for method map of class Right
def test_Right_map():
    either = Right(1)
    mapper = lambda x: x + 2
    assert either.map(mapper) == Right(3)



# Generated at 2022-06-23 23:58:28.742766
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(1)
    result = right.to_validation()
    assert result.value == [1]
    assert result.is_fail() is False


# Generated at 2022-06-23 23:58:30.530497
# Unit test for method is_right of class Either
def test_Either_is_right():
    """Test method is_right of class Either"""

    left: Either[int] = Left(1)
    assert not left.is_right()

    right: Either[int] = Right(1)
    assert right.is_right()

# Generated at 2022-06-23 23:58:31.523367
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-23 23:58:36.096821
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(True).is_right() == True
    assert Left(True).is_right() == False


# Generated at 2022-06-23 23:58:38.309039
# Unit test for constructor of class Left
def test_Left():
    left = Left(42)

    assert 42 == left.value
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-23 23:58:45.885275
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    left = Left(1)
    right = Right(1)
    assert left == left
    assert right == right
    assert left.to_validation() == left.to_validation()
    assert right.to_validation() == right.to_validation()
    assert left.to_maybe() == left.to_maybe()
    assert right.to_maybe() == right.to_maybe()
    assert left.to_try() == left.to_try()
    assert right.to_try() == right.to_try()

    assert left != right
    assert left != left.to_maybe()
    assert left != left.to_validation()
    assert left != left.to

# Generated at 2022-06-23 23:58:47.294884
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(2).is_left() is False


# Generated at 2022-06-23 23:58:51.812642
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-23 23:58:59.545632
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor_monad import FunctorMonad

    result = Right(100).ap(Right(lambda x: x ** 2))
    assert isinstance(result, Right)
    assert result == Right(10000)
    result = Right(lambda x: x ** 2).ap(Left(100))
    assert isinstance(result, Left)
    assert result == Left(100)
    result = Left(lambda x: x ** 2).ap(Right(2))
    assert isinstance(result, Left)
    assert result == Left(lambda x: x ** 2)
    result = Left(lambda x: x ** 2).ap(Left(2))
    assert isinstance(result, Left)
    assert result == Left(lambda x: x ** 2)

# Generated at 2022-06-23 23:59:00.770400
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('test').is_left() == True


# Generated at 2022-06-23 23:59:05.413011
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()
    assert not Left(None).is_right()


# Generated at 2022-06-23 23:59:06.608224
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-23 23:59:09.382027
# Unit test for method bind of class Left
def test_Left_bind():
    left_mock_value = 'Mock value'
    left_mock_mapper = lambda x: 'Not called'

    assert Left(left_mock_value).bind(left_mock_mapper) == left_mock_value

# Generated at 2022-06-23 23:59:10.569783
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)


# Generated at 2022-06-23 23:59:12.014516
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(4).to_box() == Box(4)
    assert Left(4).to_box() == Box(4)


# Generated at 2022-06-23 23:59:20.128464
# Unit test for method case of class Either
def test_Either_case():
    """
    Test for Either.case method.
    """

    # Given
    def success_mapper(value):
        return "success mapper result"

    def error_mapper(value):
        return "error mapper result"

    # When
    result_1 = Right("value").case(error_mapper, success_mapper)
    result_2 = Left("value").case(error_mapper, success_mapper)

    assert result_1 == "success mapper result"
    assert result_2 == "error mapper result"


# Generated at 2022-06-23 23:59:22.739003
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(5).to_box() == Box(5)
    assert Right(5).to_box() == Box(5)


# Generated at 2022-06-23 23:59:27.090801
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(1).to_try() == Try(1, is_success=True)
    assert Either(0).to_try() == Try(0, is_success=False)



# Generated at 2022-06-23 23:59:29.134802
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-23 23:59:32.848453
# Unit test for method bind of class Right
def test_Right_bind():
    result = Right(0)\
        .bind(lambda x: Right(x + 1))\
        .bind(lambda x: Right(x * 2))

    assert result == Right(2)


# Generated at 2022-06-23 23:59:37.168179
# Unit test for method case of class Either
def test_Either_case():
    assert Left(10).case(lambda x: x + 5, lambda x: x ** 2) == 15
    assert Right(10).case(lambda x: x + 5, lambda x: x ** 2) == 100


# Generated at 2022-06-23 23:59:39.466070
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    instance = Left(2)
    # When
    result = instance.to_validation()
    # Then
    from pymonet.validation import Validation
    assert result == Validation.fail([2])



# Generated at 2022-06-23 23:59:43.804614
# Unit test for constructor of class Either
def test_Either():
    either_value = Either(1)
    assert not hasattr(either_value, 'value')


# Generated at 2022-06-23 23:59:48.019764
# Unit test for method bind of class Right
def test_Right_bind():
    r = Right(33)
    assert r.bind(lambda value: Left(value)) == Left(33)
    assert r.bind(lambda value: value) == 33
    assert r.bind(lambda value: Right(100)) == Right(100)
    assert r.bind(lambda value: (value, value + 1)) == (33, 34)
    assert r.bind(lambda value: [value]) == [33]
    assert r.bind(lambda value: {'key': value}) == {'key': 33}


# Generated at 2022-06-23 23:59:53.171967
# Unit test for method ap of class Either
def test_Either_ap():
    def add_func(x):
        return lambda y: x + y

    assert Right(1).ap(Right(2)).to_maybe().value == 3
    assert Right(add_func(1)).ap(Right(2)).to_maybe().value == 3
    assert Left(1).ap(Right(2)).to_maybe().value == 1

# Generated at 2022-06-23 23:59:56.474392
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert(Right(5).to_validation() == Validation.success(5))

# Generated at 2022-06-23 23:59:57.681433
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(None).is_right()



# Generated at 2022-06-24 00:00:01.528508
# Unit test for constructor of class Left
def test_Left():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert isinstance(Left(1), Either)
    assert isinstance(Left(1), Monad)
    assert isinstance(Left(1), Functor)
    assert Left(1).value == 1



# Generated at 2022-06-24 00:00:03.288071
# Unit test for constructor of class Left
def test_Left():
    # Given
    value = 'Some error'

    # When
    either = Left(value)

    # Then
    assert either.value == value
    assert isinstance(either, Either)
    assert isinstance(either, Left)


# Generated at 2022-06-24 00:00:05.041635
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right('test').is_left()


# Generated at 2022-06-24 00:00:08.657237
# Unit test for method bind of class Right
def test_Right_bind():
    def add_1(n: int) -> Either[str, int]:
        if type(n) is not int:
            return Left("a")
        return Right(n + 1)

    def to_string(n: int) -> Either[str, str]:
        if type(n) is not int:
            return Left("a")
        return Right("n is " + str(n))

    assert add_1(1).bind(to_string) == Right("n is 2")
    assert add_1("a").bind(to_string) == Left("a")


# Generated at 2022-06-24 00:00:10.138509
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(3)
    assert left.bind(lambda x: x + 3) == 3


# Generated at 2022-06-24 00:00:11.645802
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(2)) == Left(1)


# Generated at 2022-06-24 00:00:12.938753
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert type(Right(1).to_maybe()) is Maybe
    assert Right(1).to_maybe().value == Just(1)


# Generated at 2022-06-24 00:00:17.634651
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)


# Generated at 2022-06-24 00:00:25.515492
# Unit test for method case of class Either
def test_Either_case():
    @typechecked
    def get_value(value: int) -> int:
        """
        Take integer and return it

        :param value: value to return
        :type value: int
        :returns: given value
        :rtype: int
        """
        return value

    assert Left(2).case(get_value, get_value) == 2, \
        'case of Left with both functions returning int should return int'

    assert Left(2).case(get_value, None) == 2, \
        'case of Left with only error function returning int should return int'

    assert Left(2).case(None, get_value) == 2, \
        'case of Left with only error function returning int should return int'


# Generated at 2022-06-24 00:00:26.449620
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)

    assert not left.is_right()

# Generated at 2022-06-24 00:00:31.961278
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == Either(1).is_right()


# Generated at 2022-06-24 00:00:32.861854
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-24 00:00:34.459943
# Unit test for method is_right of class Right
def test_Right_is_right():
    """Test if is_right return True on instance of Right class."""
    assert Right(1).is_right()



# Generated at 2022-06-24 00:00:39.273661
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(False).to_lazy() == Lazy(lambda: False)
    assert Right(False).to_lazy() == Lazy(lambda: False)
    assert Left(False).to_lazy() == Lazy(lambda: False)



# Generated at 2022-06-24 00:00:41.119538
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x + 2) == Left(2)


# Generated at 2022-06-24 00:00:43.676355
# Unit test for constructor of class Either
def test_Either():
    """Unit Test for Either constructor"""

    assert Either("Success") == Right("Success")

    assert Either("Failure") == Left("Failure")



# Generated at 2022-06-24 00:00:53.605510
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Left(None).to_lazy().value() == None
    assert Left(None).to_lazy().map(lambda x: x ** 2).value() == None
    assert Left(None).to_lazy().apply(Lazy(lambda: 2)).value() == None

    assert Right(None).to_lazy().value() == None
    assert Right(1).to_lazy().map(lambda x: x ** 2).value() == 1
    assert Right(1).to_lazy().apply(Lazy(lambda: 2)).value() == 2



# Generated at 2022-06-24 00:00:55.028730
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-24 00:00:58.260932
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Unit test."""
    from pymonet.monad_try import Try
    from pymonet.functions import return_, throw

    assert return_(42).to_try() == Try(42, is_success=True)
    assert throw(42).to_try() == Try(42, is_success=False)


# Generated at 2022-06-24 00:00:59.483919
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(x):
        return Right(x * 2)

    assert bind(2, mapper) == 4

# Generated at 2022-06-24 00:01:02.773192
# Unit test for method map of class Right
def test_Right_map():
    right = Right(2)

    mapped = right.map(lambda x: x * x)

    assert isinstance(mapped, Right)
    assert mapped.value == 4


# Generated at 2022-06-24 00:01:05.030154
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x+1).ap(Right(1)) == Right(2)
    assert Right(lambda x: x+1).ap(Left(1)) == Left(1)


# Generated at 2022-06-24 00:01:06.385751
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(5).to_maybe() == Right(5).to_maybe()


# Generated at 2022-06-24 00:01:09.911716
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(2).to_try() == Try(2, is_success=False)
    assert Right(3).to_try() == Try(3, is_success=True)

# Unit tests for method to_lazy of class Either

# Generated at 2022-06-24 00:01:17.347639
# Unit test for method case of class Either
def test_Either_case():
    # pylint: disable=ungrouped-imports
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_list import List

    actual = Either(13).case(lambda x: x * 2, lambda x: x + 2)
    assert actual == 15, f'Either.case(lambda x: x * 2, lambda x: x + 2) should return 15, got {actual}'

    actual = Either('error').case(lambda x: x * 2, lambda x: x + 2)
    assert actual == 'errorerror', f'Either.case(lambda x: x * 2, lambda x: x + 2) should return errorerror, got {actual}'

   

# Generated at 2022-06-24 00:01:18.735719
# Unit test for method is_right of class Left
def test_Left_is_right():
    from hypothesis import given
    from hypothesis.strategies import integers, data

    @given(integers())
    def test_is_right(value):
        assert not Left(value).is_right()

    test_is_right()


# Generated at 2022-06-24 00:01:21.481381
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation
    case = Validation(Left(2)).case(lambda x: x * 2, lambda x: x + 2)
    assert case == 4, 'Not good result in Either.case'


# Generated at 2022-06-24 00:01:23.959795
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-24 00:01:31.011071
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right('ab').ap(Right(lambda x: x+'c')) == Right('abc')
    assert Right('ab').ap(Left('error')) == Left('error')
    assert Left('error').ap(Right(lambda x: x+'c')) == Left('error')
    assert Left('error').ap(Left('error')) == Left('error')

# Generated at 2022-06-24 00:01:33.458114
# Unit test for constructor of class Either
def test_Either():
    assert Left("Error") == Left("Error")



# Generated at 2022-06-24 00:01:37.067785
# Unit test for method map of class Right
def test_Right_map():
    # Given
    value = "My String"

    # When
    new_value = Right(value).map(lambda string: string.upper()).value

    # Then
    assert new_value == "MY STRING"
    assert isinstance(new_value, str)



# Generated at 2022-06-24 00:01:38.979872
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    validation = Right(1).to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.value == 1



# Generated at 2022-06-24 00:01:43.050205
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Test to_validation method of class Left.
    
    :returns: True if test passed, False otherwise
    :rtype: Boolean
    """
    from pymonet.validation import Validation

    value = "Some string value"
    left = Left(value)

    assert left.to_validation() == Validation.fail([value])
    return True


# Generated at 2022-06-24 00:01:45.885958
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)



# Generated at 2022-06-24 00:01:48.515368
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)


# Generated at 2022-06-24 00:01:50.043128
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:01:55.707482
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    assert Left([1, 2, 3]).ap(Try(lambda x: x, is_success=True)) == Left([1, 2, 3])
    assert Left([1, 2, 3]).ap(Try(lambda x: x, is_success=False)) == Left([1, 2, 3])


# Generated at 2022-06-24 00:02:00.213299
# Unit test for method ap of class Left
def test_Left_ap():
    # given
    functor = Left(1)
    functor2 = Left(lambda x: x + 2)
    # when
    result = functor.ap(functor2)
    # then
    assert isinstance(result, Left)
    assert result.value == 1



# Generated at 2022-06-24 00:02:03.141274
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(Try.failure(ValueError('test'))).to_lazy() == Lazy(lambda: Try.failure(ValueError('test')))


# Generated at 2022-06-24 00:02:05.330331
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-24 00:02:06.465104
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:02:11.578884
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    value = 'value'
    either = Right(value)
    validation = either.to_validation()
    assert(validation.is_success())
    assert(validation.value == value)


# Generated at 2022-06-24 00:02:15.762281
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right('string').value == 'string'
    assert Right([1, 2, 3]).value == [1, 2, 3]
    assert Right({'key': 'value'}).value == {'key': 'value'}


# Generated at 2022-06-24 00:02:18.330745
# Unit test for method is_right of class Either
def test_Either_is_right():
    # is_right on Left returns True
    assert Left("error").is_right() is False

    # is_right on Right returns True
    assert Right("value").is_right() is True

# Generated at 2022-06-24 00:02:26.345095
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    try_val = Try(42)
    right_val = Right(42)
    left_val = Left(ValueError())

    assert try_val == right_val.to_try()
    assert try_val.is_success() == right_val.to_try().is_success()
    assert try_val.is_fail() == right_val.to_try().is_fail()

    assert try_val != left_val.to_try()
    assert try_val.is_success() != left_val.to_try().is_success()
    assert try_val.is_fail() != left_val.to_try().is_fail()

# Generated at 2022-06-24 00:02:28.266029
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(None).is_left()


# Generated at 2022-06-24 00:02:30.182941
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:02:34.499534
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_try import Try

    assert Try(1, is_success=True).to_either().is_right() == Right(1).is_right()



# Generated at 2022-06-24 00:02:36.224413
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-24 00:02:38.872882
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()
    assert not Right(1).is_left()


# Generated at 2022-06-24 00:02:42.502239
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(1)
    assert right.to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:02:44.514133
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_try import Try

    assert Right(Try(1)).is_right()



# Generated at 2022-06-24 00:02:52.426736
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Either(None).is_right() == None
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True
    assert Box(1).is_right() == True
    assert Try(1).is_right() == True
    assert Try(1, is_success=False).is_right() == False
    assert Lazy(1).is_right() == None
    assert Validation.success(1).is_right() == True
    assert Validation.fail([1]).is_right() == False

# Generated at 2022-06-24 00:03:02.105403
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Test for method Either.ap
    """
    from pymonet.applicative import Applicative
    from pymonet.functor import Functor

    class MockApplicative(Applicative[str], Generic[str]):
        """Mock of Applicative class"""

        def __init__(self, value: str) -> None:
            self.value = value

        def __eq__(self, other):
            return isinstance(other, MockApplicative)\
                   and self.value == other.value

        def map(self, mapper: Callable[[str], str]):
            """Mock of method map"""
            return MockFunctor(mapper(self.value))

        def ap(self, applicative):
            """Mock method ap"""
            return MockApplicative(self.value + applicative.value)


# Generated at 2022-06-24 00:03:12.200220
# Unit test for constructor of class Either
def test_Either():
    """
    Test if constructor of class Either work correct.

    :param: -
    :returns: -
    :raises: -
    """
    from pymonet.monad_test import test_constructor
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def test() -> Either[int]:
        return Right(2)

    assert test_constructor(test, Either)

    def test() -> Either[Any]:
        return Left(2)

    assert test_constructor(test, Either)

    def test() -> Either[Any]:
        return Lazy(lambda: 2).to_either()

    assert test_constructor(test, Either)

    def test() -> Either[Any]:
        return Box(2).to

# Generated at 2022-06-24 00:03:16.360249
# Unit test for method is_right of class Left
def test_Left_is_right():
    from pymonet.type_class_templates import Eq
    from pymonet.type_class_templates import Eq

    eq_ = Eq.insert(
        int,
        lambda a, b: a == b,
        lambda a, b: a == b
    )
    assert eq_.eq(
        Either.left(1).is_right(),
        False
    )


# Generated at 2022-06-24 00:03:18.212934
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(123).to_validation() == Validation.success(123)


# Generated at 2022-06-24 00:03:20.908785
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(2).to_try() == Try(2, True)
    assert Either('error').to_try() == Try('error', False)



# Generated at 2022-06-24 00:03:26.350304
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from hypothesis import given
    from .strategies import value_strat

    @given(value_strat())
    def test_result(value):
        assert Left(value).to_validation().to_list() == [value]

    test_result()



# Generated at 2022-06-24 00:03:27.636502
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left("left")

    assert left.is_left() is True
    assert left.is_right() is False


# Generated at 2022-06-24 00:03:28.584577
# Unit test for constructor of class Left
def test_Left():
    Left(1)


# Generated at 2022-06-24 00:03:32.336346
# Unit test for method is_right of class Left
def test_Left_is_right():
    """
    Test check by value of is_right method of class Left.

    :returns: result of Test
    :rtype: Boolean
    """
    left = Left(1)

    return not left.is_right()


# Generated at 2022-06-24 00:03:36.936694
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)



# Generated at 2022-06-24 00:03:39.004606
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(None)

    assert left.is_right() == False



# Generated at 2022-06-24 00:03:40.698974
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(None)
    assert left.is_right() == False, 'not is_right'



# Generated at 2022-06-24 00:03:43.256959
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    assert Box(1) == Right(1).to_box()
    assert Box(None) == Left(1).to_box()


# Generated at 2022-06-24 00:03:48.521001
# Unit test for method map of class Left
def test_Left_map():
    left = Left("Some error")
    mapped_left = left.map(lambda x: 1 + x)

    assert isinstance(mapped_left, Left)
    assert mapped_left.value == "Some error"

