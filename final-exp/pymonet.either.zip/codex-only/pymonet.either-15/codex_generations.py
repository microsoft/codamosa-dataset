

# Generated at 2022-06-23 23:53:54.691119
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert isinstance(Left(1).to_box(), Box)
    assert isinstance(Right(1).to_box(), Box)


# Generated at 2022-06-23 23:53:58.943603
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Unit tests for method to_try of class Either"""
    # Either is successfully
    result = Right('12345').to_try()
    assert result.is_success
    assert result.value == '12345'
    # Either is not successfully
    result = Left('abcde').to_try()
    assert not result.is_success
    assert result.value == 'abcde'


# Generated at 2022-06-23 23:54:02.487380
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)


# Generated at 2022-06-23 23:54:07.417931
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    Test to_maybe method in class Right

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe

    assert Right(100).to_maybe() == Maybe.just(100)



# Generated at 2022-06-23 23:54:08.688574
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:54:10.273044
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(0)
    assert right.is_right() is True


# Generated at 2022-06-23 23:54:13.635132
# Unit test for method bind of class Left
def test_Left_bind():
    left = Either.Left(5)
    result = left.bind(lambda x: left)
    assert isinstance(result, Left[int])
    assert result == left


# Generated at 2022-06-23 23:54:17.800505
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Unit test for method to_try of class Either
    """
    assert Either.left(1).to_try() == Try(1, is_success=False)
    assert Either.right(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-23 23:54:22.209003
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.monad_test_constants import monad_test_constants, RIGHT_STRING_VALUE,\
        NIL_VALUE
    right_value = Right(monad_test_constants[RIGHT_STRING_VALUE])

    assert right_value.is_left() == False



# Generated at 2022-06-23 23:54:23.333547
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:54:25.357289
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Right(x + 1)) == Right(3)
    assert Right(2).bind(lambda x: Left((x + 1))) == Left(3)


# Generated at 2022-06-23 23:54:31.351729
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:54:34.681671
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert (Right(1).to_box() == Box(1))
    assert (Left(1).to_box() == Box(1))


# Generated at 2022-06-23 23:54:38.242244
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(1).to_box() == Box(1)
    assert Either(1).to_box().to_either() == Either(1)


# Generated at 2022-06-23 23:54:39.913000
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left('err')) == Left('err')



# Generated at 2022-06-23 23:54:41.183630
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda x: x + 1) == left


# Generated at 2022-06-23 23:54:42.632773
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(123).is_left() == False



# Generated at 2022-06-23 23:54:47.335148
# Unit test for constructor of class Either
def test_Either():
    def _either_eq_helper(left):
        assert Either(left).case(
            success=lambda _: False,
            error=lambda _: True
        )
    _either_eq_helper('error')



# Generated at 2022-06-23 23:54:49.507226
# Unit test for method is_right of class Right
def test_Right_is_right():
    """
    Assert test method for is_right method of class Right

    :returns: None
    :rtype: NoneType
    """
    assert Right(None).is_right()


# Generated at 2022-06-23 23:54:58.007824
# Unit test for method to_box of class Either
def test_Either_to_box():
    def test_Left_to_box(value) -> None:
        assert Left(value).to_box() == Box(value)

    def test_Right_to_box(value) -> None:
        assert Right(value).to_box() == Box(value)

    for value in [1, [], {}, set(), '', (), 'Hello', (1, 2), [1, 2, 3], {'a': 1}, {1}]:
        test_Left_to_box(value)
        test_Right_to_box(value)



# Generated at 2022-06-23 23:55:02.754353
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    either = Right(1)

    assert isinstance(either.to_validation(), Validation)

# Generated at 2022-06-23 23:55:08.416925
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    right_either = Right(1)

    # When
    result = right_either.to_lazy()

    # Then
    assert result.force() == 1, 'transform either to lazy should work'


# Generated at 2022-06-23 23:55:09.833350
# Unit test for constructor of class Left
def test_Left():
    assert Left("a") == Left("a")



# Generated at 2022-06-23 23:55:12.773904
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)



# Generated at 2022-06-23 23:55:16.802274
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("a").is_right() == True


# Generated at 2022-06-23 23:55:18.868570
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(10).is_right()
    assert Right(10).is_right()


# Generated at 2022-06-23 23:55:21.570177
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    left = Left(Box(1))
    right = Right(Box(2))

    assert left.to_box() == Box(1)
    assert right.to_box() == Box(2)



# Generated at 2022-06-23 23:55:31.137681
# Unit test for method case of class Either
def test_Either_case():
    value = 5
    assert Left(value).case(lambda error: error + 5, lambda success: success + 5) == 10
    assert Right(value).case(lambda error: error + 5, lambda success: success + 5) == 10
    assert Left(value).case(lambda error: Right(error + 5), lambda success: Left(success + 5)) == Left(10)
    assert Right(value).case(lambda error: Right(error + 5), lambda success: Left(success + 5)) == Left(10)
    assert Left(value).case(lambda error: 6, lambda success: 7) == 6
    assert Right(value).case(lambda error: 6, lambda success: 7) == 7


# Generated at 2022-06-23 23:55:32.743914
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Either(lambda a: a+1)) == Left(1)


# Generated at 2022-06-23 23:55:35.142852
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left("test")
    assert left.is_right() is False, "Should be False"


# Generated at 2022-06-23 23:55:36.842600
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(45).ap(Left('a')) == Left(45)


# Generated at 2022-06-23 23:55:40.500631
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_try import Try
    from pymonet.partially_applied import partially_applied

    def thrower() -> int:
        raise Exception('exception')

    assert Left('error').bind(partially_applied(Try, thrower)) == Left('error')


# Generated at 2022-06-23 23:55:42.433038
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(Error('Error')).to_box() == Box(Error('Error'))
    assert Right(10).to_box() == Box(10)


# Generated at 2022-06-23 23:55:44.354526
# Unit test for method map of class Left
def test_Left_map():
    # given
    left = Left(2)

    # when
    result = left.map(lambda x: x + 1)

    # then
    assert left == result



# Generated at 2022-06-23 23:55:46.196162
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:55:48.481341
# Unit test for method map of class Right
def test_Right_map():
    val = Right(4)
    assert str(val.map(lambda x: x * 2)) == str(Right(8))



# Generated at 2022-06-23 23:55:51.797334
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    def f(x): return x + 1
    monad = Right(1)
    assert monad.to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:55:53.530890
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-23 23:55:55.388304
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x)) == Left(2)


# Generated at 2022-06-23 23:56:04.324012
# Unit test for constructor of class Either
def test_Either():
    from pymonet.either import Left, Right
    from random import choice

    a_error_value = choice([True, None, 0, 'a', (), [], dict()])
    b_success_value = choice([True, None, 0, 'a', (), [], dict()])
    a_error = Left(a_error_value)
    b_success = Right(b_success_value)
    assert a_error.is_left() and a_error.value == a_error_value
    assert b_success.is_right() and b_success.value == b_success_value

test_Either()

# Generated at 2022-06-23 23:56:10.512444
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Check if pymonet.maybe.Maybe.nothing is returned.
    """
    from pymonet.maybe import Maybe
    from pymonet.monad_either import Left

    assert Left(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:12.003042
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left('A').to_maybe(), 'transform to Maybe'


# Generated at 2022-06-23 23:56:13.350980
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:14.150062
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right()



# Generated at 2022-06-23 23:56:19.091066
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Right('double').map(lambda x: x + x) == Right('doubledouble')
    assert Right('double').map(lambda x: Box(x)).value == Right('double').value
    assert Right('double').map(lambda x: Maybe.just(x)).value == Right('double').value
    assert Right('double').map(lambda x: Lazy(lambda: x)).value.take() == Right('double').value



# Generated at 2022-06-23 23:56:25.625034
# Unit test for constructor of class Either
def test_Either():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert Left(2) != Right(2)
    assert Left(3) != Right(3)

# Generated at 2022-06-23 23:56:27.489877
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda x: 2 * x) == Left(1)



# Generated at 2022-06-23 23:56:28.904435
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)



# Generated at 2022-06-23 23:56:32.123988
# Unit test for constructor of class Right
def test_Right():
    from pymonet.maybe import Maybe

    maybe_one = Maybe.just(1)
    assert Right(maybe_one).value.value == 1
    assert isinstance(Right(1).value, int)
    assert Right(1) != Right(2)
    assert Right(1).value == 1
    assert Right(1).value == 2



# Generated at 2022-06-23 23:56:33.937267
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    # Given
    either = Right(5)

    # When
    validation = either.to_validation()

    # Then
    assert validation.value == 5
    assert not validation.error



# Generated at 2022-06-23 23:56:39.500387
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Either(True).is_right()
    assert Right(True).is_right()
    assert not Left(False).is_right()


# Generated at 2022-06-23 23:56:43.746015
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    a = Either(1)
    b = Either(1)
    c = Either(2)
    assert a.to_lazy() == b.to_lazy()
    assert a.to_lazy() != c.to_lazy()


# Generated at 2022-06-23 23:56:46.597820
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right() is True


# Generated at 2022-06-23 23:56:47.871709
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left()



# Generated at 2022-06-23 23:56:49.114981
# Unit test for constructor of class Left
def test_Left():
    left = Left('error')
    assert left == Left('error')


# Generated at 2022-06-23 23:56:58.172446
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.validation import Validation

    # Given
    left1 = Left(Validation.fail([1, 2, 3]))
    left2 = Left(Validation.fail([1, 2, 3]))
    right1 = Right(Validation.success(1))
    right2 = Right(Validation.success(1))
    right3 = Right(Validation.success(2))

    # Then
    assert left1 == left2
    assert right1 == right2
    assert left1 != right1
    assert right1 != right3

# Generated at 2022-06-23 23:56:58.953861
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-23 23:57:01.652134
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Lazy(lambda: Box(5)) == Either(Box(5)).to_lazy()



# Generated at 2022-06-23 23:57:02.909505
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-23 23:57:12.527406
# Unit test for method to_try of class Either
def test_Either_to_try():
    # Given: Right try
    from pymonet.monad_try import Try

    try_m = Try(5)

    # When: We call method to_try
    either = try_m.to_either()
    try_ = either.to_try()

    # Then: We have same result
    assert try_m == try_

    # Given: Failure try
    try_m = Try('error', is_success=False)

    # When: We call method to_try
    either = try_m.to_either()
    try_ = either.to_try()

    # Then: We have same result
    assert try_m == try_



# Generated at 2022-06-23 23:57:15.056212
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1).bind(lambda x: Right(x + 1)) is Left(1)

# Generated at 2022-06-23 23:57:16.666260
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(10)
    assert left.is_left()


# Generated at 2022-06-23 23:57:22.140845
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)


# Generated at 2022-06-23 23:57:24.508747
# Unit test for method is_right of class Right
def test_Right_is_right():
    value = 1
    right = Right(value)
    assert right.is_right()
    assert not right.is_left()


# Generated at 2022-06-23 23:57:30.496934
# Unit test for constructor of class Either
def test_Either():
    assert Either(2) == Either(2)
    assert not Either(2) == Either(3)
    assert not Either(2) == Either("2")
    assert Either("a") == Either("a")



# Generated at 2022-06-23 23:57:31.792027
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(4).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:57:36.738619
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    def _get_left_value():
        return Left('massege')

    assert _get_left_value().to_maybe().is_nothing()



# Generated at 2022-06-23 23:57:46.229502
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not Right(1) and\
        Either(1) is not Left(1) and\
        Either(1) == Either(1) and\
        Either(1) != Either(2) and\
        Either(1) != Either('something') and\
        Either(1) != Either([1, 2])
    assert Left(1) is not Right(1) and\
        Left(1) is not Either(1) and\
        Left(1) == Left(1) and\
        Left(1) != Left(2) and\
        Left(1) != Left('Something') and\
        Left(1) != Left([1, 2]) and\
        Left(1) != Right(1)

# Generated at 2022-06-23 23:57:48.716814
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(5).to_box() == 5
    assert Right(5).to_box() == Box(5)
    assert Left(5).to_box() == Box(5)


# Generated at 2022-06-23 23:57:51.803305
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(1).is_right() and Right(1).is_right()



# Generated at 2022-06-23 23:57:52.769073
# Unit test for constructor of class Left
def test_Left():
    assert Left(1).value == 1


# Generated at 2022-06-23 23:57:54.956207
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('test').is_right() is False
    assert Right('test').is_right() is True

# Generated at 2022-06-23 23:57:58.551686
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('Left')

    assert left.is_left() == True

# Generated at 2022-06-23 23:57:59.733156
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('Left').is_left() is True


# Generated at 2022-06-23 23:58:01.970747
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1)

# Generated at 2022-06-23 23:58:04.174955
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left('error').bind(lambda x: Right(x + '+')) == Left('error')
    assert Left('error').bind(lambda x: Left(x + '+')) == Left('error')



# Generated at 2022-06-23 23:58:10.665272
# Unit test for method case of class Either
def test_Either_case():
    def success_handler(value):
        assert value == 1
        return value + 1

    def error_handler(errors):
        assert errors == [1]
        return errors[0] - 1

    Left([1]).case(error_handler, success_handler) == 0
    Right(1).case(error_handler, success_handler) == 2


# Generated at 2022-06-23 23:58:13.739437
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(3)
    assert left.is_left()



# Generated at 2022-06-23 23:58:15.115829
# Unit test for constructor of class Either
def test_Either():
    assert Either('foo') == Right('foo')



# Generated at 2022-06-23 23:58:20.142220
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.maybe import Just
    from pymonet.validation import Validation

    # case when Either is Right
    option = Right(42)
    assert option.is_left() is False
    assert option.is_right() is True
    option = option.to_maybe()
    assert isinstance(option, Just)
    assert option.value == 42
    option = option.to_validation()
    assert isinstance(option, Validation.Success)
    assert option.value == 42



# Generated at 2022-06-23 23:58:22.962446
# Unit test for method to_try of class Either
def test_Either_to_try():
    try_result = Try(100)
    right = Right(100)
    try_result_from_right = right.to_try()

    assert(right == try_result_from_right)


# Generated at 2022-06-23 23:58:25.752154
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:58:26.762073
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() == False


# Generated at 2022-06-23 23:58:27.811100
# Unit test for constructor of class Left
def test_Left():
    assert Left("test value") == Left("test value")

# Generated at 2022-06-23 23:58:32.319211
# Unit test for method ap of class Left
def test_Left_ap():
    """
    Test ap method of class Left

    Right[A] can not be applied for Left[A] and return new Left[B]
    """
    from pymonet.monad_either import Left

    left = Left('left')
    right = Left(1)
    result = left.ap(right)

    assert result == left


# Generated at 2022-06-23 23:58:41.723345
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.either import Either, Left, Right
    from pymonet.box import Box

    def multiply_by_two(number):
        return 2 * number

    assert Either.Right(2).ap(Box(multiply_by_two)) == Box(4)
    assert Either.Left(2).ap(Box(multiply_by_two)) == Box(None)
    assert Either.Right(2).ap(Left(Box(multiply_by_two))) == Box(None)
    assert Either.Left(2).ap(Left(Box(multiply_by_two))) == Box(None)


# Generated at 2022-06-23 23:58:43.042170
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Validation.success(1).__eq__(Either.right(1).to_validation())


# Generated at 2022-06-23 23:58:46.459567
# Unit test for method bind of class Left
def test_Left_bind():
    """Test docstring"""
    # Given
    expected = '1'
    monad = Left(expected)

    # When
    actual = monad.bind(str)

    # Then
    assert actual == expected



# Generated at 2022-06-23 23:58:48.806874
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    def either_to_maybe_test(either: Either):
        return either.to_maybe()

    assert maybe_validator(either_to_maybe_test)(Left(42)) == Maybe.nothing()

# Generated at 2022-06-23 23:58:51.691585
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x)) == Left(2)


# Generated at 2022-06-23 23:58:53.584752
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(123).to_validation() == Validation.success(123)


# Generated at 2022-06-23 23:58:56.275894
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:59:00.734650
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x, lambda x: x) == 1
    assert Left(1).case(lambda x: x, lambda x: x + 1) == 1
    assert Right(1).case(lambda x: x, lambda x: x) == 1
    assert Right(1).case(lambda x: x, lambda x: x + 1) == 2


# Generated at 2022-06-23 23:59:06.053362
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert (Left('I am very sad.').is_right() == False)
    assert (Right('I am very happy.').is_right() == True)

# Generated at 2022-06-23 23:59:07.408102
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(1)
    maybe = left.to_maybe()
    assert maybe != Maybe.just(1)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-23 23:59:08.710308
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)
    assert Right(1).to_validation() != Validation.fail([1])


# Generated at 2022-06-23 23:59:14.702728
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    result = Left([1, 2, 3]).to_validation()
    assert isinstance(result, Validation)
    assert result.is_fail()
    assert result.value == [1, 2, 3]



# Generated at 2022-06-23 23:59:17.285894
# Unit test for method is_right of class Left
def test_Left_is_right():
    # Setup
    left_instance = Left(5)

    # Exercise and Verify
    assert left_instance.is_right() == False


# Generated at 2022-06-23 23:59:20.189937
# Unit test for constructor of class Right
def test_Right():
    assert Right('bar') == Right('bar')
    assert Right('foo') != Right('bar')
    assert Right('foo') != Left('foo')



# Generated at 2022-06-23 23:59:32.312359
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Left(2).__eq__(Left(2))
    assert Left(2).__eq__(Left(4))
    assert Right(2).__eq__(Right(2))
    assert Right(2).__eq__(Right(4))
    assert not Left(2).__eq__(Right(2))
    assert not Left(2).__eq__(Lazy(lambda: 4))
    assert not Right(2).__eq__(Lazy(lambda: 4))
    assert not Right(2).__eq__(Try(2, True))
    assert not Right(2).__eq__(Box(2))


# Generated at 2022-06-23 23:59:36.860492
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is False
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:59:38.212263
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)


# Generated at 2022-06-23 23:59:41.153056
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Left(1).to_box()
    assert Right(1).to_box() == Right(1).to_box()
    assert Right(1).to_box() != Left(1).to_box()
    assert Left(1).to_box() != Right(1).to_box()


# Generated at 2022-06-23 23:59:42.515100
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Test not boolean result
    assert Right(100).is_right() == True
    assert Left(100).is_right() == False


# Generated at 2022-06-23 23:59:45.226372
# Unit test for constructor of class Either
def test_Either():
    assert Left('foo') == Left('foo')
    assert Right(None) == Right(None)
    assert Left('foo') != Right('foo')
    assert Right('foo') != Left('foo')

# Generated at 2022-06-23 23:59:49.880141
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(0).is_left() is False


# Generated at 2022-06-23 23:59:52.056274
# Unit test for method bind of class Right
def test_Right_bind():
    right_five = Right(5)
    assert right_five.bind(lambda x: x + 3) == 8



# Generated at 2022-06-23 23:59:56.687669
# Unit test for method map of class Left
def test_Left_map():
    assert Left(5).map(lambda x: x + 1) == Left(5)



# Generated at 2022-06-23 23:59:58.219677
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() is False
    assert Right(None).is_right() is True


# Generated at 2022-06-23 23:59:59.475321
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:00:04.069371
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-24 00:00:05.757474
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get() == 1
    assert Right(2).to_lazy().get() == 2



# Generated at 2022-06-24 00:00:07.944929
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(2).to_box() == Box(2)
    assert Left(1).to_box() == Box(1)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-24 00:00:09.490710
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False



# Generated at 2022-06-24 00:00:10.687388
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert True == Right(2).is_left()



# Generated at 2022-06-24 00:00:11.947259
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False



# Generated at 2022-06-24 00:00:14.146813
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left_value = Left(10)
    result = left_value.to_maybe()

    assert result == Maybe.nothing()



# Generated at 2022-06-24 00:00:20.006903
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(None).to_validation() == Validation.fail([None])
    assert Left('error').to_validation() == Validation.fail(['error'])
    assert Left([1, 2]).to_validation() == Validation.fail([[1, 2]])


# Generated at 2022-06-24 00:00:23.425535
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_maybe import Maybe

    either = Left(1)
    maybe = Maybe.just(lambda x: x + 5)

    assert either.ap(maybe).is_right() is False

    either = Right(2)
    maybe = Maybe.just(lambda x: x + 5)

    assert either.ap(maybe).value == 7

# Generated at 2022-06-24 00:00:24.498266
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-24 00:00:26.391289
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()
    assert not Left('a').is_left()
    assert not Left({}).is_left()
    assert Left([]).is_left()


# Generated at 2022-06-24 00:00:29.417515
# Unit test for method ap of class Left
def test_Left_ap():
    class _Either(Either[int]):
        def __init__(self, value: int) -> None:
            self.value = value
        def ap(_, applicative):
            return applicative.map(self.value)

    assert _Either(1).ap(Right(lambda x: x + 2)) == Right(3)



# Generated at 2022-06-24 00:00:31.891848
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-24 00:00:34.497762
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(123) == Left(123)
    assert Left(123) == Left(123)
    assert Right(123) == Right(123)
    assert Right(123) == Right(123)


# Generated at 2022-06-24 00:00:39.230734
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:00:41.075960
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-24 00:00:45.541758
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(True).to_box() == Box(True)
    assert Either(False).to_box() == Box(False)
    assert Either(Exception('Error message')).to_box() == Box(Exception('Error message'))


# Generated at 2022-06-24 00:00:47.637749
# Unit test for constructor of class Right
def test_Right():
    either = Right(1)
    assert isinstance(either, Either)
    assert isinstance(either, Right)
    assert either.value == 1


# Generated at 2022-06-24 00:00:48.881517
# Unit test for method bind of class Left
def test_Left_bind():
    assert(Left(4).bind(lambda x: x) == Left(4))



# Generated at 2022-06-24 00:00:50.651623
# Unit test for method map of class Left
def test_Left_map():
    assert Left(4).map(lambda x: x + 2) == Left(4)



# Generated at 2022-06-24 00:00:51.929922
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:52.643789
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-24 00:00:54.100090
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-24 00:00:56.113733
# Unit test for method map of class Right
def test_Right_map():
    assert isinstance(Right(1).map(lambda x: x + 1), Right)
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-24 00:00:58.377861
# Unit test for constructor of class Either
def test_Either():
    """Unit tests for Either monad constructor."""
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)

# Unit tests for method map of class Either

# Generated at 2022-06-24 00:00:59.974244
# Unit test for method map of class Left
def test_Left_map():
    left = Left(lambda x: x + 1)
    new_left = left.map(lambda x: x + 1)

    assert left is new_left



# Generated at 2022-06-24 00:01:03.376191
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    # Given
    maybe_instance = Maybe.just('Value')

    # When
    result = Left('Value').to_maybe()

    # Then
    assert result == Maybe.nothing()



# Generated at 2022-06-24 00:01:06.194951
# Unit test for method bind of class Right
def test_Right_bind():
    def func(_):
        return Right(10)

    assert Right(20).bind(func) == Right(10)


# Generated at 2022-06-24 00:01:08.154470
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left(x)) == Left(2)


# Generated at 2022-06-24 00:01:09.567912
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().value() == 1

# Generated at 2022-06-24 00:01:11.309606
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() == True
    assert Left(1).is_right() == False


# Generated at 2022-06-24 00:01:15.885892
# Unit test for method is_left of class Left
def test_Left_is_left():
    # Given
    left = Left(1)
    # When
    result = left.is_left()
    # Then
    assert result is True


# Generated at 2022-06-24 00:01:23.474293
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left('A')
    left_2 = Left('B')
    right_1 = Right(1)
    right_2 = Right(1)

    assert not left_1.__eq__(left_2)
    assert not left_1.__eq__(right_1)
    assert not left_1.__eq__(right_2)
    assert not left_2.__eq__(right_1)
    assert not left_2.__eq__(right_2)
    assert not left_2.__eq__(left_1)
    assert not right_1.__eq__(right_2)
    assert not right_1.__eq__(left_1)
    assert not right_1.__eq__(left_2)
    assert not right_2.__eq__(left_1)

# Generated at 2022-06-24 00:01:25.607955
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('test').to_validation() == Validation.fail(['test'])


# Generated at 2022-06-24 00:01:30.625142
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Box(Right(42).to_box()) == Box(42)
    assert Box(Right(42).to_box()) == Box(42)



# Generated at 2022-06-24 00:01:34.413639
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert (Left(3).to_lazy() == Lazy(lambda: 3))
    assert (Right(3).to_lazy() == Lazy(lambda: 3))


# Generated at 2022-06-24 00:01:37.729805
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.either import Right
    from pymonet.either import Left

    left = Left(5)
    result = isinstance(left.bind(lambda x: Right(x * 2)), Left)
    assert result is True



# Generated at 2022-06-24 00:01:39.310260
# Unit test for constructor of class Either
def test_Either():
    assert Either(2) == Either(2)
    assert Either(2) == Either(3) is False


# Generated at 2022-06-24 00:01:40.752431
# Unit test for method is_left of class Right
def test_Right_is_left():
    def test():
        assert Right(3).is_left() is False

    test()



# Generated at 2022-06-24 00:01:43.959307
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(12) == Left(12)
    assert Left(12) != Left(13)
    assert Right(12) == Right(12)
    assert Right(12) != Right(13)
    assert Right(12) != Left(12)


# Generated at 2022-06-24 00:01:53.127937
# Unit test for method is_right of class Either
def test_Either_is_right():
    def run_test(either: Either, expected: bool):
        actual: bool = either.is_right()
        return actual == expected

    def create_test_either(is_right: bool) -> Either[int]:
        return Right(5) if is_right else Left(5)

    assert run_test(create_test_either(True), True) is True
    assert run_test(create_test_either(False), True) is False
    assert run_test(create_test_either(True), False) is False
    assert run_test(create_test_either(False), False) is True



# Generated at 2022-06-24 00:01:54.484538
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(1).is_right())



# Generated at 2022-06-24 00:01:57.018676
# Unit test for method case of class Either
def test_Either_case():
    result = Either.case
    assert result(Left(1), lambda x: x, lambda x: x) == 1

# Generated at 2022-06-24 00:01:59.007181
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() is True
    assert Left(None).is_right() is False



# Generated at 2022-06-24 00:02:07.382704
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.either import Either, Right, Left
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    # Box
    def fn(a: int) -> int:
        return a + 1

    assert Either(fn).ap(Box(1)).value == 2

    # Lazy
    assert Either(fn).ap(Lazy(lambda: 1)).value == 2

    # Maybe
    assert Either(fn).ap(Maybe.just(1)).value == 2

    # Try
    assert Either(fn).ap(Try(1)).value == 2


if __name__ == '__main__':
    test_Either_ap()

# Generated at 2022-06-24 00:02:11.354429
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left("error")
    functor = Right(lambda x: 2 * x)
    result = left.ap(functor)
    assert result == Left("error")



# Generated at 2022-06-24 00:02:19.229330
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(3).to_lazy().map(lambda x: x + 2).force() == 5
    assert Either(3).to_lazy().map(lambda x: x + 2).value == Lazy(lambda: 5).value
    assert Either(3).to_lazy().map(lambda x: x + 2).is_forced == False
    assert Either(3).to_lazy().map(lambda x: x + 2).force().is_forced == True

    assert Left(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-24 00:02:21.429752
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(2)
    maybe = right.to_maybe()

    assert isinstance(maybe, Right)
    assert maybe == 2


# Generated at 2022-06-24 00:02:24.079907
# Unit test for method bind of class Right
def test_Right_bind():
    """Test method bind of class Right"""
    right = Right(1)
    right_mapped = right.bind(lambda x: Right(x + 1))
    assert right_mapped == Right(2)



# Generated at 2022-06-24 00:02:25.929989
# Unit test for method map of class Right
def test_Right_map():
    # Should return right with mapped value
    assert Right(4).map(lambda x: x * 2) == Right(8)



# Generated at 2022-06-24 00:02:29.248195
# Unit test for method ap of class Left
def test_Left_ap():
    actual = Left('1').ap(Left('2'))

    assert actual.value == '1'
    assert actual.is_right() == False

# Generated at 2022-06-24 00:02:32.483862
# Unit test for method bind of class Left
def test_Left_bind():
    """Check if method bind returns value stored in monad"""
    left = Left(1)
    assert left.bind(lambda x: x) == 1


# Generated at 2022-06-24 00:02:34.744861
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(object).is_left() is False


# Generated at 2022-06-24 00:02:36.122328
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:02:42.269591
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def value_func():
        return 'test'

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-24 00:02:46.065342
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try_ = Try('value')
    lazy = try_.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == try_.value
    assert lazy.value() == 'value'

# Generated at 2022-06-24 00:02:48.560593
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda val: Right(val + 5)) == 1


# Generated at 2022-06-24 00:02:53.160547
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    @typechecked
    def _(value: Any) -> Validation:
        return Left(value).to_validation()

    value = 'Is not I'
    assert _(value).is_fail()
    assert _(value).fail() == [value]



# Generated at 2022-06-24 00:02:54.719350
# Unit test for constructor of class Either
def test_Either():
    assert Either('test').value == 'test'



# Generated at 2022-06-24 00:02:59.107749
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Given
    right = Right(11)
    left = Left("left")

    # When
    is_right = right.is_right()
    is_left = left.is_left()

    # Then
    assert is_right
    assert not is_left


# Generated at 2022-06-24 00:03:00.725426
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    value = Right(1)
    assert value.to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:03:02.298595
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-24 00:03:03.596222
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('left').is_left()


# Generated at 2022-06-24 00:03:10.360168
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success

    be_test = Right(1)
    assert be_test.to_validation() == Validation.success(1)
    assert be_test.to_validation().is_success(), "expect success"
    assert not be_test.to_validation().is_fail(), "expect not fail"
    assert be_test.to_validation() == Success(1), "expect Success(1)"


# Generated at 2022-06-24 00:03:14.332600
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(2)) == Left(2), 'Left.ap should return Left(2)'
    assert Left(1).ap(Right(2)) == Left(2), 'Left.ap should return Left(2)'
    assert Left(1).ap(None) == Left(None), 'Left.ap should return Left(None)'



# Generated at 2022-06-24 00:03:20.835681
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad import Monad
    from pymonet.box import Box
    from pymonet.computation import Computation

    def add1(num):
        return num + 1

    def add2(num):
        return num + 2

    def _test(test_case):
        run_test = lambda: test_case.call_ap_on(test_case.monad).bind(test_case.result)\
            .equal_to(test_case.expected_value)
        test_case.assert_true("Ap on {} with {} failed", run_test)


# Generated at 2022-06-24 00:03:22.153792
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-24 00:03:24.992435
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(42).is_left()



# Generated at 2022-06-24 00:03:31.865827
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # Act
    left = Left(1)
    right = Right(Maybe.just(1))

    # Assert
    assert Try(1, error=1, is_success=False) == left.to_try()
    assert Try(1) == right.to_try()

    # Act
    left = Left(1).to_try()
    right = Right(Maybe.just(1)).to_try()

    # Assert
    assert Try(1, error=1, is_success=False) == left
    assert Try(1) == right


# Generated at 2022-06-24 00:03:35.689768
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) == Right(1) is False
    assert Right(1) == Left(1) is False


# Generated at 2022-06-24 00:03:39.707364
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right("Pyszka").to_lazy() == Lazy(lambda: "Pyszka")
    assert Left("Miauczy").to_lazy() == Lazy(lambda: "Miauczy")


# Generated at 2022-06-24 00:03:43.236698
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def generator_function():
        yield 1
        yield 2
        yield 3

    generator = generator_function()
    assert Right(generator).to_lazy() == Lazy(lambda: generator)
    assert Right(None).to_lazy() == Lazy(lambda: None)
    assert Left(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:03:46.074025
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(1).to_try() == Try(1, True) == Try.success(1)
    assert Either(1).to_try() == Try(1, True) == Try.success(1)



# Generated at 2022-06-24 00:03:48.246183
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Just(1)


# Generated at 2022-06-24 00:03:50.325393
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('some-value').is_right()
