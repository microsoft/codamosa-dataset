

# Generated at 2022-06-23 23:53:49.364508
# Unit test for method bind of class Right
def test_Right_bind():
    """Test bind method of class Right"""
    assert Right(5).bind(lambda x: Right(x + 10)) == Right(15)
    assert Right(5).bind(lambda x: Left(x + 10)) == Left(15)


# Generated at 2022-06-23 23:53:54.779214
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.value == 1
    assert type(left.value) is int



# Generated at 2022-06-23 23:53:56.156100
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(0).to_validation() == Validation.success(0)



# Generated at 2022-06-23 23:53:57.250524
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(1).is_right() == True)


# Generated at 2022-06-23 23:53:58.595071
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.value == 1


# Generated at 2022-06-23 23:54:01.974795
# Unit test for constructor of class Either
def test_Either():
    # When I create instance of Either
    either = Either(0)
    # Then I should have instance of it
    assert isinstance(either, Either)

# Unit tests for Either.case function

# Generated at 2022-06-23 23:54:03.372936
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-23 23:54:10.376067
# Unit test for method ap of class Either
def test_Either_ap():
    def e1(x):
        return x + 1

    def e2(x):
        return x + 2

    assert Right(e1).ap(Right(4)).value == 5
    assert Left(4).ap(Right(e1)).value == 4
    assert Right(e1).ap(Left(4)).value == 4
    assert Left(e1).ap(Left(4)).value == e1
    assert Right(e1).ap(Right(e2)).value == e2



# Generated at 2022-06-23 23:54:14.189494
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)

# Generated at 2022-06-23 23:54:16.429479
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(0).is_right()


# Generated at 2022-06-23 23:54:21.246488
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(10).is_right()
    assert type(Right(10)) == Right
    assert not type(Right(10)) == Left
    assert not Left(10).is_right()
    assert type(Left(10)) == Left
    assert not type(Left(10)) == Right


# Generated at 2022-06-23 23:54:23.506754
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-23 23:54:27.263898
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.compare import compare
    from pymonet.lazy import Lazy

    def is_Lazy(value):
        return isinstance(value, Lazy) and value.is_forced() is False and value.value() == "TEST"
    assert compare(Right("TEST").to_lazy(), is_Lazy).is_success()
    assert compare(Left("TEST").to_lazy(), is_Lazy).is_success()


# Generated at 2022-06-23 23:54:34.213801
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either('test') == Either('test')
    assert Either(1) != Either('test')
    assert Left(1) != Right(1)
    assert Either(1) != Right(1)
    assert Left(1) != 2
    assert Right(1) != 2
    assert Right(1) != ['a']
    assert Left(1) != ['a']
    assert Left(1) != 'a'
    assert Right(1) != 'a'



# Generated at 2022-06-23 23:54:36.632299
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe() == Maybe.just(2)



# Generated at 2022-06-23 23:54:39.869912
# Unit test for method map of class Right
def test_Right_map():
    # Arrange
    right = Right([1, 2])

    # Act
    result = right.map(lambda x: x + [3])

    # Assert
    assert result == Right([1, 2, 3])



# Generated at 2022-06-23 23:54:41.869750
# Unit test for method bind of class Right
def test_Right_bind():
    assert Either[int](1).to_right().bind(lambda x: Either[int](x + 2)).case(lambda x: False, lambda x: x == 3)

# Generated at 2022-06-23 23:54:49.467226
# Unit test for constructor of class Right
def test_Right():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert issubclass(Right, Functor)
    assert issubclass(Right, Monad)
    assert issubclass(Right, Applicative)

    right = Right(42)

    assert right.value == 42
    assert right.is_right()
    assert right.is_left() is False
    assert right.map(lambda x: x + 1) == Right(43)


# Generated at 2022-06-23 23:54:52.291885
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def func():
        return 1
    result = Lazy(func)
    assert Right(1).to_lazy() == result
    assert Left(2).to_lazy() == result


# Generated at 2022-06-23 23:54:54.105792
# Unit test for constructor of class Left
def test_Left():
    left_instance = Left(3)
    assert type(left_instance) == Left
    assert left_instance.value == 3


# Generated at 2022-06-23 23:54:57.019822
# Unit test for method map of class Right
def test_Right_map():
    value = Right(1)
    mapper = lambda v: v + 1
    expected = Right(2)
    assert value.map(mapper) == expected
    mapper = Right(1).map
    assert value.map(mapper) == expected


# Generated at 2022-06-23 23:54:59.115826
# Unit test for method case of class Either
def test_Either_case():
    assert Left("Left").case(
        lambda x: "Left",
        lambda x: "Right"
    ) == "Left"

    assert Right("Right").case(
        lambda x: "Left",
        lambda x: "Right"
    ) == "Right"


# Generated at 2022-06-23 23:55:06.550164
# Unit test for method bind of class Left
def test_Left_bind():
    # setup
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    left = Left('error')
    right_box = Box(10)
    right_try = Try(10)
    right_lazy = Lazy(lambda: 10)

    # act
    left_box = left.bind(lambda x: right_box.map(lambda y: y * x))
    left_try = left.bind(lambda x: right_try.map(lambda y: y * x))
    left_lazy = left.bind(lambda x: right_lazy.map(lambda y: y * x))

    # assert
    assert left_box.is_left()
    assert left_try.is_left()

# Generated at 2022-06-23 23:55:08.133198
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(None).is_left()


# Generated at 2022-06-23 23:55:09.332259
# Unit test for method is_left of class Left
def test_Left_is_left():
    """Unit test for method is_left of class Left"""
    assert isinstance(Left(1).is_left(), bool)


# Generated at 2022-06-23 23:55:11.147352
# Unit test for method is_right of class Either
def test_Either_is_right():
    a = Either(0)
    assert a.is_right() == None


# Generated at 2022-06-23 23:55:12.948782
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:55:14.911467
# Unit test for constructor of class Left
def test_Left():
    """Unit test for constructor of class Left"""

    left = Left(1)
    assert left.value == 1
    assert left.case(
        lambda error: error,
        lambda success: success
    ) == 1


# Generated at 2022-06-23 23:55:23.060186
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Maybe.just(1)
    # Check that unit and optional objects aren't equal
    assert not (Left(1) == None)



# Generated at 2022-06-23 23:55:25.228984
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(None).is_right()
    assert Right(None).is_right()


# Generated at 2022-06-23 23:55:28.446239
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: Right(x + 2)) == Right(5)
    assert Right(3).bind(lambda x: Left([f'{x} is greater or equal than 3'])) == Left(['3 is greater or equal than 3'])



# Generated at 2022-06-23 23:55:33.331073
# Unit test for method case of class Either
def test_Either_case():
    result = Either(3).case(lambda x: x + 2, lambda x: "test")
    assert result == "test"
    result = Either(3).case(lambda x: x + 2, lambda x: "test")
    assert result == "test"
    result = Either(3).case(lambda x: x + 2, lambda x: "test")
    assert result == "test"


# Generated at 2022-06-23 23:55:37.614069
# Unit test for constructor of class Either
def test_Either():
    left = Left("left")
    right = Right("right")
    assert left.case(error=lambda value: value, success=lambda value: value) == "left"
    assert right.case(error=lambda value: value, success=lambda value: value) == "right"

# Generated at 2022-06-23 23:55:39.116948
# Unit test for constructor of class Left
def test_Left():
    left = Left('foo')
    assert left.value == 'foo'
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-23 23:55:40.336505
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert(Left(5).is_left())


# Generated at 2022-06-23 23:55:42.334567
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:55:43.072171
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('ERROR').to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:55:49.783713
# Unit test for method map of class Left
def test_Left_map():
    """Test method map of Left class"""

    def add(a: int) -> int:
        return a + 1

    assert Left(1).map(add) == Left(1)
    assert Left(2).map(add) == Left(2)
    assert Left('foo').map(lambda a: a + 'bar') == Left('foo')
    assert Left('foo').map(lambda _: 'bar') == Left('foo')
    assert Left('foo').map(lambda _: 1) == Left('foo')



# Generated at 2022-06-23 23:55:55.920152
# Unit test for constructor of class Right
def test_Right():
    class A:
        def __eq__(self, other):
            return self.a == other.a

    a = A()
    a.a = 1
    right = Right(a)
    assert right.value.a == 1



# Generated at 2022-06-23 23:55:57.401661
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left("Left").is_right()


# Generated at 2022-06-23 23:56:01.986012
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('some_value').is_right() is False



# Generated at 2022-06-23 23:56:05.035188
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(5).to_lazy(), Lazy)
    assert isinstance(Right(5).to_lazy(), Lazy)



# Generated at 2022-06-23 23:56:09.112663
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    print("test Either to_lazy")
    assert Lazy(lambda: 42) == Right(42).to_lazy()
    assert Lazy(lambda: 42) == Left(42).to_lazy()


# Generated at 2022-06-23 23:56:11.088162
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)
    assert Right(-1).to_validation() == Validation.success(-1)


# Generated at 2022-06-23 23:56:12.514336
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(1)
    assert right.to_maybe() == Maybe.just(1)



# Generated at 2022-06-23 23:56:15.560502
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 1) == Right(3)



# Generated at 2022-06-23 23:56:16.595561
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:56:25.433853
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    assert left.value == 1
    left_box = left.to_box()
    assert left_box.value == 1
    left_try = left.to_try()
    assert left_try.value == 1
    left_lazy = left.to_lazy()
    assert left_lazy.call() == 1
    left_maybe = left.to_maybe()
    assert left_maybe.is_nothing
    left_validation = left.to_validation()
    assert left_validation.is_fail
    assert left_validation.value == [1]

    right = Right(1)
    right_box = right.to_box()
    assert right_box.value == 1
    right_try = right.to_try()
    assert right_try.value == 1
   

# Generated at 2022-06-23 23:56:26.688982
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(2).is_left()


# Generated at 2022-06-23 23:56:28.456938
# Unit test for method map of class Left
def test_Left_map():
    monad = Left(10)
    assert monad.map(lambda x: x * 100) == monad


# Generated at 2022-06-23 23:56:29.539204
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()


# Generated at 2022-06-23 23:56:30.573935
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)

    assert right.value == 1
    assert right.is_right()



# Generated at 2022-06-23 23:56:33.891237
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(5).to_try() == Try(5, is_success=True)
    assert Left(5).to_try() == Try(5, is_success=False)


# Generated at 2022-06-23 23:56:34.882462
# Unit test for method map of class Left
def test_Left_map():
    left = Left('a')

    assert left is left.map(lambda x: x.upper())


# Generated at 2022-06-23 23:56:39.049490
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)


# Generated at 2022-06-23 23:56:44.235910
# Unit test for constructor of class Left
def test_Left():
    assert Left(1).is_left()
    assert not Left(1).is_right()
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert isinstance(Left(1), Either)
    assert isinstance(Left(1), Left)
    assert not isinstance(Left(1), Right)


# Generated at 2022-06-23 23:56:46.683909
# Unit test for constructor of class Right
def test_Right():
    value = Right(42)
    assert value.value == 42, 'Right.value should be 42'


# Generated at 2022-06-23 23:56:48.262289
# Unit test for method map of class Right
def test_Right_map():
    assert Right(12).map(lambda x: x * 2) == Right(24)



# Generated at 2022-06-23 23:56:49.459853
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:56:53.073100
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda i: i + 1) == Right(2)

# Generated at 2022-06-23 23:56:55.832532
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(5)
    right = Right(5)

    assert not left.is_right()
    assert right.is_right()


# Generated at 2022-06-23 23:56:57.290695
# Unit test for method map of class Right
def test_Right_map():
    right = Right("right")
    assert right.map(lambda x: x.lower()) == Left("right")



# Generated at 2022-06-23 23:57:00.547904
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(7)
    maybe = right.to_maybe()

    assert maybe == maybe.just(7)



# Generated at 2022-06-23 23:57:03.363595
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    result = Left(['error']).to_validation()
    assert isinstance(result, Validation)
    assert result.is_fail()
    assert result.value == ['error']



# Generated at 2022-06-23 23:57:06.218628
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    x = 5
    y = lambda z: z * 2
    result = x >> Lazy(y) >> Maybe.just

    assert result == Maybe.just(10)

# Generated at 2022-06-23 23:57:08.443389
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.of(1) == Right(1).to_maybe()

# Generated at 2022-06-23 23:57:19.438623
# Unit test for constructor of class Right
def test_Right():
    from pymonet.maybe import Maybe

    assert Maybe(Right(1)).equals(Maybe(1))

    assert Maybe(Right(1)).bind(lambda x: Maybe(x ** 2)) == Maybe(1) ** 2
    assert Maybe(Right(1)).bind(lambda x: Maybe(x * 2)) == Maybe(1) * 2
    assert Maybe(Right(1)).bind(lambda x: Maybe(x + 2)) == Maybe(1) + 2

    assert Right(1) * 2 == Right(1 * 2)
    assert Right(1) ** 2 == Right(1 ** 2)
    assert Right(1) + 2 == Right(1 + 2)
    assert Right(1) - 2 == Right(1 - 2)
    assert Right(1) / 2 == Right(1 / 2)



# Generated at 2022-06-23 23:57:20.901799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-23 23:57:22.850208
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:57:25.110319
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    value = 1
    assert Right(value).to_validation() == Validation.success(value)

# Generated at 2022-06-23 23:57:27.197521
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:57:28.919106
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 2) == Left(1)



# Generated at 2022-06-23 23:57:29.880816
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(5)
    assert right.is_left() is False, "Right must be right"


# Generated at 2022-06-23 23:57:31.792307
# Unit test for method to_try of class Either
def test_Either_to_try():
    either1 = Right(1)
    assert either1.to_try() == True
    either2 = Left(2)
    assert either2.to_try() == False


# Generated at 2022-06-23 23:57:36.341244
# Unit test for method ap of class Left
def test_Left_ap():
    def wrapper(value: int) -> Either[int]:
        return Left(value)

    assert Left(7).ap(wrapper(10)) == Left(7)

# Generated at 2022-06-23 23:57:39.131455
# Unit test for method is_left of class Left
def test_Left_is_left():
    # Arrange
    left = Left(1)
    # Act
    result = left.is_left()
    # Assert
    assert result



# Generated at 2022-06-23 23:57:41.201325
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:57:43.305883
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)

test_Right_to_maybe()



# Generated at 2022-06-23 23:57:48.009499
# Unit test for method case of class Either
def test_Either_case():
    # Given
    error = lambda x: x * 2
    success = lambda x: x * 3
    left = Left(2)
    right = Right(2)

    # When
    error_result = left.case(error, success)
    success_result = right.case(error, success)

    # Then
    assert error_result == 4
    assert success_result == 6


# Generated at 2022-06-23 23:57:58.396693
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy


    assert Either(10).__eq__(Either(10)) is True, "Should be True"
    assert Either(10).__eq__(Either(20)) is False, "Should be False"
    assert Either(10).__eq__(Right(10)) is True, "Should be True"
    assert Either(10).__eq__(Left(10)) is True, "Should be True"
    assert Either(10).__eq__(Box(10)) is False, "Should be False"
    assert Either(10).__eq__(Try(10, is_success=True)) is False, "Should be False"
    assert Either(10).__eq__(Lazy(lambda: 10)) is False

# Generated at 2022-06-23 23:57:59.932930
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('1')
    assert left.bind(lambda x: x) == '1'



# Generated at 2022-06-23 23:58:03.228462
# Unit test for method is_right of class Either
def test_Either_is_right():
    either = Either(None)
    either_left = Left(None)
    either_right = Right(None)

    assert either.is_right() is False
    assert either_left.is_right() is False
    assert either_right.is_righ

# Generated at 2022-06-23 23:58:04.408397
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-23 23:58:07.430006
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.from_iterable([]) == Left(0).to_validation()



# Generated at 2022-06-23 23:58:10.540981
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """ Unit test for method to_maybe of class Right """

    right = Right(123)
    assert right.to_maybe() == Maybe.just(123)



# Generated at 2022-06-23 23:58:14.090846
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: x * x) == Left(3)



# Generated at 2022-06-23 23:58:17.377568
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for instance of Left
    assert Either.Left(2).to_lazy().force() == 2

    # Test for instance of Right
    assert Either.Right(3).to_lazy().force() == 3


# Generated at 2022-06-23 23:58:22.428238
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(5).to_box() == Box(5)
    assert Either('test').to_box() == Box('test')


# Generated at 2022-06-23 23:58:25.700031
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-23 23:58:31.198725
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.function import id

    # Test with Right
    assert Right(0)\
        .to_lazy()\
        .map(id) == Lazy(lambda: 0)

    # Test with Left
    assert Left(0)\
        .to_lazy()\
        .map(id) == Lazy(lambda: 0)


# Generated at 2022-06-23 23:58:37.964804
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_box import Box

    from random import randint

    x = randint(1, 100)
    y = randint(1, 100)
    left = Either.Left(x).to_lazy()
    right = Either.Right(y).to_lazy()

    assert isinstance(left, Lazy)
    assert isinstance(left.value, Callable)
    assert left.value() == x
    assert isinstance(right, Lazy)
    assert isinstance(right.value, Callable)
    assert right.value() == y

# Generated at 2022-06-23 23:58:39.828338
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:58:44.785999
# Unit test for method is_right of class Left
def test_Left_is_right():
    result = Left(1).is_right()
    expected = False
    assert result == expected



# Generated at 2022-06-23 23:58:48.591079
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Test for Left.to_validation method.

    :rtype: Boolean
    """
    test_value = "test"
    left = Left(test_value)
    validation = left.to_validation()
    return validation.is_fail() and validation.value == [test_value]



# Generated at 2022-06-23 23:58:51.691615
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(10).bind(lambda x: Right(x + 10)) == Left(10)



# Generated at 2022-06-23 23:58:53.914806
# Unit test for method case of class Either
def test_Either_case():
    left = Right(1)
    right = Left('a')
    assert left.case(lambda x: x, lambda x: x + 1) == 2
    assert right.case(lambda x: x, lambda x: x + 1) == 'a'


# Generated at 2022-06-23 23:58:55.347402
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('error').ap(Left('error')).value == 'error'


# Generated at 2022-06-23 23:59:05.467241
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # when Either is Left and to_try
    try_ = Left(2).to_try()

    # then it should be Try with False
    assert isinstance(try_, Try)
    assert not try_.is_success

    # when Either is Right and to_try
    try_ = Right(2).to_try()

    # then it should be Try with True
    assert isinstance(try_, Try)
    assert try_.is_success

    # when Either is Left and to_try
    try_ = Left('error').to_try()

    # then it should be Try with False
    assert isinstance(try_, Try)
    assert not try_.is_success

    # when Either is Right and to_try
    try_ = Right('success').to_try()

   

# Generated at 2022-06-23 23:59:07.006213
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()
    assert Left('error').is_left()


# Generated at 2022-06-23 23:59:08.252730
# Unit test for constructor of class Left
def test_Left():
    assert(isinstance(Left(1), Left))



# Generated at 2022-06-23 23:59:15.245036
# Unit test for method ap of class Either
def test_Either_ap():
    @ap_testable
    def test_success(e: Either[int, Callable[[int], int]]):
        return e.ap(Right(2)) == Right(4)

    @ap_testable
    def test_error(e: Either[Callable[[int], int], int]):
        return e.ap(Left(2)) == Left(2)



# Generated at 2022-06-23 23:59:17.197209
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() is False


# Generated at 2022-06-23 23:59:18.192227
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(123).is_right() == False



# Generated at 2022-06-23 23:59:20.247151
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right("success").to_validation() == Validation.success("success")


# Generated at 2022-06-23 23:59:22.847974
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    actual = left.map(lambda x: x + 1)
    assert actual == left


# Generated at 2022-06-23 23:59:25.918544
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    value = 'value'
    assert Right(value).to_validation() == Validation.success(value)



# Generated at 2022-06-23 23:59:29.193045
# Unit test for method map of class Left
def test_Left_map():
    left = Left(True)
    result = left.map(lambda x: x)
    assert (isinstance(result, Left))
    assert (result.value == True)



# Generated at 2022-06-23 23:59:31.677861
# Unit test for method is_left of class Left
def test_Left_is_left():
    # Given
    left = Left(10)

    assert left.is_left() is True


# Generated at 2022-06-23 23:59:39.161300
# Unit test for constructor of class Either
def test_Either():
    a = Either(1)
    assert a.case(lambda err: "Left", lambda suc: "Right") == "Right"
    assert a.ap(Either(lambda x: x + 1)) == Right(2)
    assert a.to_box() == Box(1)
    assert a.to_lazy() == Lazy(1)
    assert a.to_try() == Try(1)


# Generated at 2022-06-23 23:59:43.925705
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(10).is_right() == False
    assert Either('foo').is_right() == False
    assert Either([]).is_right() == False
    assert Either({}).is_right() == False


# Generated at 2022-06-23 23:59:45.976776
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    either = Right(1)

    assert either.to_validation().is_success() == True
    assert either.to_validation().get_value() == 1


# Generated at 2022-06-23 23:59:49.473836
# Unit test for constructor of class Left
def test_Left():
    assert Left(1).value == 1



# Generated at 2022-06-23 23:59:50.968583
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:59:52.733539
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 2) == Left(1)


# Generated at 2022-06-24 00:00:00.069742
# Unit test for method map of class Left
def test_Left_map():
    left_instance_0 = Left(0)
    left_instance_1 = Left(1)
    # Check identity
    assert left_instance_0.map(lambda x: x) == left_instance_0
    # Check composition
    mapper = lambda x: x + 1
    assert left_instance_0.map(lambda x: mapper(left_instance_0.value)) == left_instance_1


# Generated at 2022-06-24 00:00:02.018142
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.of(1) == Right(1).to_maybe()


# Generated at 2022-06-24 00:00:03.978399
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1).value == 1



# Generated at 2022-06-24 00:00:06.559934
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(5), Either)
    assert isinstance(Right(5), Either)
    assert Left(5).value == 5
    assert Right(5).value == 5

# Unit tests for method case of class Either

# Generated at 2022-06-24 00:00:07.284589
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-24 00:00:08.263680
# Unit test for constructor of class Either
def test_Either():
    either = Either(6)
    assert isinstance(either, Either)



# Generated at 2022-06-24 00:00:09.237523
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(123).is_right()


# Generated at 2022-06-24 00:00:12.821231
# Unit test for constructor of class Right
def test_Right():
    assert Right(True).is_right()
    assert not Right(True).is_left()
    assert Right('abc').value == 'abc'
    assert Right(42).value == 42
    assert Right([1, 2, 3]).value == [1, 2, 3]


# Generated at 2022-06-24 00:00:16.172988
# Unit test for method to_box of class Either
def test_Either_to_box():
    import pytest
    from pymonet.box import Box

    left = Left(Box(1))
    right = Right(Box(1))
    assert left.to_box() == Box(left)
    assert right.to_box() == Box(right)



# Generated at 2022-06-24 00:00:18.307306
# Unit test for method ap of class Left
def test_Left_ap():
    actual = Left(10).ap(Left(20))
    expected = Left(10)

    assert actual == expected



# Generated at 2022-06-24 00:00:20.378810
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert(Right(Box(1)).to_maybe() == Maybe.just(Box(1)))

# Generated at 2022-06-24 00:00:21.137586
# Unit test for method to_box of class Either
def test_Either_to_box():
    pass



# Generated at 2022-06-24 00:00:22.716604
# Unit test for method case of class Either
def test_Either_case():
    assert Right(5).case(lambda x: x + 4, lambda x: x + 5) == 10
    assert Left(5).case(lambda x: x + 4, lambda x: x + 5) == 9



# Generated at 2022-06-24 00:00:28.816873
# Unit test for method case of class Either
def test_Either_case():
    """Test case method for class Either"""

    # Initialize Left and Right
    left = Left("Error")
    right = Right("Success")

    # Take 2 functions and return String
    error_handler = lambda error: f"Error handler: {error}"
    success_handler = lambda success: f"Success handler: {success}"

    # Test case
    assert left.case(error_handler, success_handler) == "Error handler: Error"
    assert right.case(error_handler, success_handler) == "Success handler: Success"



# Generated at 2022-06-24 00:00:31.806276
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(123).is_left() is False


# Generated at 2022-06-24 00:00:32.576147
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:00:33.780045
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("error message").is_left()


# Generated at 2022-06-24 00:00:38.553745
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Left(1) == Left(1))
    assert(Left(1) != Left(2))
    assert(Right(1) == Right(1))
    assert(Right(1) != Right(2))



# Generated at 2022-06-24 00:00:39.605949
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right() == True


# Generated at 2022-06-24 00:00:43.344874
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:00:45.885401
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Left('error')) == Left('error')


# Generated at 2022-06-24 00:00:54.737645
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    x = Left(1)
    y = Left(1)
    assert x is not y
    assert x is not Left(2)
    assert x != Right(1)
    assert Right(1) == Right(1)
    x = Right(1)
    y = Right(1)
    assert x is not y
    assert x is not Right(2)
    assert x != Left(1)

    # Test case function
    assert Left(1).case(lambda x: True, lambda x: False) is True
    assert Right(1).case(lambda x: True, lambda x: False) is False

    # Test to_box function
    from pymonet.box import Box
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box

# Generated at 2022-06-24 00:01:01.544764
# Unit test for method to_try of class Either
def test_Either_to_try():
    try_instance = Right(3).to_try()
    assert isinstance(try_instance, Either)
    assert try_instance.is_right()
    assert try_instance.value == 3

    try_instance = Left(3).to_try()
    assert isinstance(try_instance, Either)
    assert try_instance.is_left()
    assert isinstance(try_instance.value, ValueError)



# Generated at 2022-06-24 00:01:02.937052
# Unit test for method is_right of class Left
def test_Left_is_right():
    error = Left("error")
    assert error.is_right() == False


# Generated at 2022-06-24 00:01:05.209045
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.string import String

    assert String("111").ap(String("222")).value == "111222"
    assert String("111").ap(String("222")).__class__ == String

# Generated at 2022-06-24 00:01:06.514586
# Unit test for constructor of class Right
def test_Right():
    from pymonet.box import Box

    assert Right(Box(1)) == Right(Box(1))

# Generated at 2022-06-24 00:01:08.107042
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert isinstance(Left(1).to_maybe(), Maybe)


# Generated at 2022-06-24 00:01:11.731615
# Unit test for method map of class Right
def test_Right_map():
    """
    Asserts for Right.map() method.
    :returns: Nothing
    :rtype: None
    """

    actual = Right(1).map(lambda x: x * 2)
    expected = Right(2)
    assert actual == expected



# Generated at 2022-06-24 00:01:13.593085
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('error').to_maybe().equals(Maybe.nothing())


# Generated at 2022-06-24 00:01:16.013042
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('some').is_right()


# Generated at 2022-06-24 00:01:17.726712
# Unit test for method map of class Right
def test_Right_map():
    assert Right.map(Right(2), lambda value: value * 2) == Right(4)


# Generated at 2022-06-24 00:01:24.397202
# Unit test for method ap of class Either
def test_Either_ap():
    '''
    Right(3).ap(Right(lambda x: x * 2)) == Right(6) == Right(3).ap(Left(2))
    Left(3).ap(Right(lambda x: x * 2)) == Left(3) == Left(3).ap(Left(2))
    '''
    assert Right(3).ap(Right(lambda x: x * 2)) == Right(6)
    assert Right(3).ap(Left(2)) == Right(6)
    assert Left(3).ap(Right(lambda x: x * 2)) == Left(3)
    assert Left(3).ap(Left(2)) == Left(3)



# Generated at 2022-06-24 00:01:26.315730
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('value')
    assert left.is_left() == True


# Generated at 2022-06-24 00:01:32.140778
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(0) == Either(0) == Either(0)
    assert Either(1) == Either(1) == Either(1)
    assert Either(0) != Either(1) != Either(2)
    assert Either(2) != Either(1) != Either(0)



# Generated at 2022-06-24 00:01:34.618034
# Unit test for constructor of class Left
def test_Left():
    value = "value"
    assert rather_left(value).value == str(value)


# Generated at 2022-06-24 00:01:38.297915
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.functor import fmap

    res = fmap(lambda x: x + 1, Right(1))
    assert isinstance(res, Right), "Not Right was returned"  # type: ignore
    assert res == Right(2), "Not 2 was returned"



# Generated at 2022-06-24 00:01:39.894505
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right

    assert Right(2).to_validation() == Validation.success(2)



# Generated at 2022-06-24 00:01:41.908793
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    result = Right(True).to_validation()

    assert result == Validation(True, [])



# Generated at 2022-06-24 00:01:44.725908
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    val = Right(2).to_validation()
    assert isinstance(val, Validation)
    assert val.is_success()
    assert val.value == 2



# Generated at 2022-06-24 00:01:48.653100
# Unit test for method map of class Right
def test_Right_map():
    """When mapping Right with a function, return a new Right with the result of the function."""
    right: Either[int] = Right(2)

    assert right.map(lambda x: x + 2) == Right(4)



# Generated at 2022-06-24 00:01:50.591017
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False



# Generated at 2022-06-24 00:01:52.678316
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Left(1).to_maybe(), Maybe)



# Generated at 2022-06-24 00:01:53.995254
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(0).is_right() == False


# Generated at 2022-06-24 00:01:57.292037
# Unit test for method bind of class Left
def test_Left_bind():
    result = Left(1).bind(lambda x: x + 1)
    assert isinstance(result, Left)
    expected = Left(1)
    assert result == expected



# Generated at 2022-06-24 00:01:59.209258
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)



# Generated at 2022-06-24 00:02:00.871210
# Unit test for constructor of class Left
def test_Left():
    # Given
    element = 1

    # When
    result = Left(element)

    # Then
    assert isinstance(result, Left)


# Generated at 2022-06-24 00:02:03.145846
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-24 00:02:04.180753
# Unit test for method map of class Left
def test_Left_map():
    assert Left('Error value').map(lambda x: x + ' new string') == 'Error value'



# Generated at 2022-06-24 00:02:10.898720
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test function checks whether the method of Right class is working properly.

    In particular:

    >>> foo = lambda a: Right(a + 5)
    >>> right = Right(3)
    >>> right.bind(foo).value == 8
    True

    """
    foo = lambda a: Right(a + 5)
    right = Right(3)
    assert right.bind(foo).value == 8


# Generated at 2022-06-24 00:02:16.585040
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Right(Validation.success(1)).is_left() == False
    assert Right(Validation.fail(1)).is_left() == False
    assert Right(Try.success(1)).is_left() == False
    assert Right(Try.fail(1)).is_left() == False



# Generated at 2022-06-24 00:02:19.020925
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    import pymonet.maybe

    left = Left(1)
    assert left.to_maybe() == pymonet.maybe.Maybe.nothing()


# Generated at 2022-06-24 00:02:21.682943
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    m = Maybe.just("xyz")
    right = Right("xyz")
 
    assert right.to_maybe() == m


# Generated at 2022-06-24 00:02:25.658478
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x * 2).ap(Right(4)) == Right(8)
    assert Right(lambda x: x * 2).ap(Left(2)) == Left(2)
    assert Left(2).ap(Right(4)) == Right(4)
    assert Left(lambda x: x * 2).ap(Left(2)) == Left(2)

# Generated at 2022-06-24 00:02:29.686245
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box() == Box(2)
    assert Left([1, 2]).to_box() == Box([1, 2])



# Generated at 2022-06-24 00:02:33.250063
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-24 00:02:36.707321
# Unit test for constructor of class Either
def test_Either():
    from pymonet.monad_unit_test import test_either
    from pymonet.monad import identity
    test_either(Right, identity, Left=Left) # type: ignore


# Generated at 2022-06-24 00:02:42.593590
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    right = Right(1)
    # When
    result = right.bind(lambda x: Left("error"))
    # Then
    assert isinstance(result, Left)
    assert result.value == "error"



# Generated at 2022-06-24 00:02:44.593304
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('').is_left() is True
    assert Left('').is_right() is False


# Generated at 2022-06-24 00:02:52.809505
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.box import Box

    def add_one(value):
        return Right(value + 1)

    assert isinstance(Right(1).bind(add_one), Right)
    assert Right(1).bind(add_one).value == 2
    assert Right(1).bind(add_one) == Right(2)
    assert Right(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).value == 5
    assert Right(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one) == Right(5)
    assert Right(1).bind(add_one).bind(add_one).bind(add_one).bind(add_one).bind(Box.unit) == Right(5)
    assert Right(1).bind

# Generated at 2022-06-24 00:02:55.998099
# Unit test for method bind of class Left
def test_Left_bind():
    """Test for Left"""
    def test_function(value):
        """Test function"""
        return value

    assert Left(10).bind(test_function) == Left(10)


# Generated at 2022-06-24 00:03:05.054597
# Unit test for constructor of class Right
def test_Right():
    """
    >>> from pymonet.either import Right
    >>> Right(1).value
    1
    >>> Right(1).is_right()
    True
    >>> Right(1).is_left()
    False
    >>> Right('test').value
    'test'
    >>> Right((1, 2)).value
    (1, 2)
    >>> Right(None).value is None
    True
    >>> Right(1) == Right(1)
    True
    >>> Right(1) == Right('test')
    False
    >>> Right(1) == Right(2)
    False
    >>> Right(1) == Left(1)
    False
    """
    pass


# Generated at 2022-06-24 00:03:08.155922
# Unit test for method map of class Right
def test_Right_map():
    a = Right(12)
    assert a.map(lambda x: x + 1) == Right(13)
    assert a.map(lambda x: x ** 2) == Right(144)



# Generated at 2022-06-24 00:03:10.980637
# Unit test for constructor of class Left
def test_Left():
    assert Left(None) == Left(None)
    assert Left(None) != Left('value')
    assert Left(None) != Right(None)
    assert Left(None) != None


# Generated at 2022-06-24 00:03:12.902022
# Unit test for constructor of class Either
def test_Either():
    assert Left(None) == Left(None)


# Unit tests for to_try function

# Generated at 2022-06-24 00:03:14.399553
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1
    assert right is not None


# Generated at 2022-06-24 00:03:16.510358
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left("error")
    maybe = left.to_maybe()
    assert maybe.is_nothing()
    assert maybe.value is None


# Generated at 2022-06-24 00:03:17.702626
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right()


# Generated at 2022-06-24 00:03:20.006862
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(2).to_box() == Box(2)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-24 00:03:22.051027
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:03:26.351211
# Unit test for method bind of class Right
def test_Right_bind():
    def double(x: int) -> int:
        return x * 2

    assert Right(1).bind(lambda x: Right(double(x))) == Right(2)



# Generated at 2022-06-24 00:03:28.109335
# Unit test for method bind of class Left
def test_Left_bind():
    left_5 = Left(5)
    assert left_5.bind(lambda x: x) == 5



# Generated at 2022-06-24 00:03:29.106969
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == None



# Generated at 2022-06-24 00:03:40.290839
# Unit test for method case of class Either

# Generated at 2022-06-24 00:03:41.724425
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right()


# Generated at 2022-06-24 00:03:43.095164
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(4).is_right()


# Generated at 2022-06-24 00:03:44.960066
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    right2 = right.map(lambda x: x + 1)
    assert right2.value == 2
