

# Generated at 2022-06-23 23:53:46.143303
# Unit test for method to_try of class Either
def test_Either_to_try():
    import pymonet.monad_try as my
    assert isinstance(Either(42).to_try(), my.Try)



# Generated at 2022-06-23 23:53:48.421275
# Unit test for constructor of class Left
def test_Left():
    left_instance = Left('Something wrong')

    assert left_instance.value == 'Something wrong'


# Generated at 2022-06-23 23:53:52.389118
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    assert Either.ap(Left(5), Box(lambda x: x * 2)) == Left(5)
    assert Either.ap(Right(5), Box(lambda x: x * 2)) == Right(10)
    assert Either.ap(Right(5.0), Box(lambda x: x // 2)) == Right(2.0)

# Generated at 2022-06-23 23:53:59.214881
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_either import Left, Right
    from pymonet.lazy import Lazy

    # Unit test for Left to_lazy
    # Should return Lazy with function returning previous value
    assert Left(None).to_lazy() == Lazy(lambda: None)

    # Unit test for Right to_lazy
    # Should return Lazy with function returning previous value
    assert Right(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-23 23:54:01.658989
# Unit test for method map of class Left
def test_Left_map():
    # Given
    left = Left(1)

    # When
    result = left.map(lambda x: x + 1)

    # Then
    assert left == result



# Generated at 2022-06-23 23:54:06.679700
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(error=lambda x: x + 1, success=lambda x: x * 2) == 2
    assert Right(1).case(error=lambda x: x + 1, success=lambda x: x * 2) == 2

# Generated at 2022-06-23 23:54:10.095736
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation().fold(
        error=lambda l: l,
        success=lambda r: None) == [1]
    assert Left(1).to_validation().fold(
        error=lambda l: l,
        success=lambda r: None) == [1]


# Generated at 2022-06-23 23:54:13.427823
# Unit test for constructor of class Left
def test_Left():
    left = Left('Foo')
    assert left.value == 'Foo'
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-23 23:54:16.893118
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left('error')
    assert left.is_right() is False


# Generated at 2022-06-23 23:54:21.355188
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Test for Right
    assert Right(1).to_try() == Try(1)

    # Test for Left
    assert Left(1).to_try() == Try(1, is_success=False)


# Generated at 2022-06-23 23:54:23.014806
# Unit test for method bind of class Left
def test_Left_bind():
    f = lambda x: Right(x+2)
    assert Left(4).bind(f) == Left(4)


# Generated at 2022-06-23 23:54:24.748531
# Unit test for method ap of class Either
def test_Either_ap():
    def f(x: int) -> int:
        return x + 1

    assert Either.ap(Left(1), Right(f)) == Left(1)
    assert Either.ap(Right(1), Right(f)) == Right(2)
    assert Either.ap(Right(1), Left(f)) == Left(f)


# Generated at 2022-06-23 23:54:31.394540
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:54:35.986203
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    value = 'value'
    left = Left(value)
    validation = left.to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.errors == [value]


# Generated at 2022-06-23 23:54:37.837989
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(10).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:54:40.306029
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-23 23:54:43.755154
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    value1 = Lazy(lambda: 5)
    value2 = Lazy(lambda: 4)
    right = Right(value1)
    left = Left(value2)
    assert right.to_lazy() == value1
    assert left.to_lazy() == value2


# Generated at 2022-06-23 23:54:45.956416
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('Test').is_right()


# Generated at 2022-06-23 23:54:49.515493
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Callable[[T], U] -> Either[U]
    """
    def double(num: int) -> Either[int]:
        return Right(num * 2)

    assert Right(5).bind(double) == Right(10)


# Generated at 2022-06-23 23:55:00.160859
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.lazy import Lazy

    lazy_10: Lazy[int] = Lazy(lambda: 10)
    lazy_10_copied: Lazy[int] = Lazy.of(10)

    # is_right
    assert Either.of(1).is_right()
    assert not Either.of(1).is_left()

    assert Either.of('1').is_right()
    assert not Either.of('1').is_left()

    assert Either.of(True).is_right()
    assert not Either.of(True).is_left()

    assert Either.of(1.1).is_right()
    assert not Either.of(1.1).is_left()

    assert Either.of(1j).is_right()
    assert not Either.of(1j).is_left()

# Generated at 2022-06-23 23:55:01.995387
# Unit test for constructor of class Right
def test_Right():
    from pymonet.monad_try import Try
    assert Right(Try.just(1)).case(lambda v: 'error', lambda v: v) == 1


# Generated at 2022-06-23 23:55:03.490380
# Unit test for method bind of class Left
def test_Left_bind():
    assert(Left(1).bind(lambda x: Left(x)).bind(lambda x: Right(x)) == Left(1))



# Generated at 2022-06-23 23:55:04.732989
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("hello").is_right()


# Generated at 2022-06-23 23:55:07.542039
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(42).to_box()().value == 42


# Generated at 2022-06-23 23:55:12.771489
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Test if to_try method of either return Try with the proper value and state.
    """
    from pymonet.monad_try import Try

    either = Left(1)
    assert either.to_try() == Try(1, is_success=False)

    either = Right(1)
    assert either.to_try() == Try(1, is_success=True)

# Generated at 2022-06-23 23:55:18.751275
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)
    assert left.value == 1
    assert right.value == 1


# Generated at 2022-06-23 23:55:19.688736
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1

# Generated at 2022-06-23 23:55:20.828265
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:55:27.804157
# Unit test for method case of class Either
def test_Either_case():
    left = Left('hey')
    right = Right(2)
    assert left.case(lambda value: f"Left: {value}", lambda value: f"Right: {value}") == 'Left: hey'
    assert right.case(lambda value: f"Left: {value}", lambda value: f"Right: {value}") == 'Right: 2'


# Generated at 2022-06-23 23:55:34.836364
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Just
    from .lazy import Lazy

    lazy = Lazy(lambda x: x + 1)
    maybe = Just(1)
    assert lazy.to_try() == Try(1)
    assert maybe.to_try() == Try(1)
    assert Right(1).to_try() == Try(1)
    assert Left(1).to_try() == Try(1, is_success=False)



# Generated at 2022-06-23 23:55:36.195101
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:55:38.178986
# Unit test for constructor of class Right
def test_Right():
    assert Right(value=None) == Right(value=None)
    assert Right(value=None).is_right()



# Generated at 2022-06-23 23:55:40.234525
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Right(1).to_maybe()
    assert Maybe.nothing() == Left(1).to_maybe()
    assert Maybe.just(3) == Box(3).to_maybe()


# Generated at 2022-06-23 23:55:41.384493
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not(Left('error').is_right())



# Generated at 2022-06-23 23:55:45.155157
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(10).to_lazy(), Lazy)
    assert isinstance(Right(10).to_lazy(), Lazy)


# Generated at 2022-06-23 23:55:52.682984
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    def assert_validation(validation, is_success, value):
        assert isinstance(validation, Validation), 'Left.to_validation() must return Validation monad'
        assert validation.is_success == is_success, 'Validation, returned by Left.to_validation() must be failed'
        assert validation.value == value, 'Validation.value, returned by Left.to_validation() must be equal to value of Left'

    assert_validation(Left(1).to_validation(), False, [1])
    assert_validation(Left('1').to_validation(), False, ['1'])


# Generated at 2022-06-23 23:55:53.834567
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(3).is_left() is True


# Generated at 2022-06-23 23:55:59.331703
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(None).to_validation() == Validation.fail([None])
    assert Left(1).to_validation() == Validation.fail([1])
    assert Left(4.99).to_validation() == Validation.fail([4.99])
    assert Left("left").to_validation() == Validation.fail(["left"])


# Generated at 2022-06-23 23:56:05.096096
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> Either.ap(Left(3), Right(func))
    Left(3)
    >>> Either.ap(Right(3), Left(func))
    Left(<function func at 0x7f7cef3ca710>)
    >>> Either.ap(Right(3), Right(func))
    Right(6)
    """



# Generated at 2022-06-23 23:56:09.901947
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('error')\
        .to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:10.802141
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-23 23:56:15.031265
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(6).to_lazy().evaluate() == 6
    assert Left(6).to_lazy().evaluate() == 6


# Generated at 2022-06-23 23:56:17.640083
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:56:20.999513
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(1).to_try().get_or_else(0) == 0
    assert Right(1).to_try().get_or_else(0) == 1

# Generated at 2022-06-23 23:56:22.377955
# Unit test for method is_right of class Left
def test_Left_is_right():
    l = Left(Any)
    assert l.is_right() is False


# Generated at 2022-06-23 23:56:23.990816
# Unit test for method is_left of class Right
def test_Right_is_left():
    result = Right(1).is_left()
    assert result == False



# Generated at 2022-06-23 23:56:24.824794
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right()



# Generated at 2022-06-23 23:56:26.411086
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:56:28.305914
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-23 23:56:29.890612
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1).map(lambda x: x + 1)


# Generated at 2022-06-23 23:56:32.958226
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # to_lazy should return Lazy monad with value wrapped by Right (or Left)
    assert Either(100).to_lazy() == Lazy(100)
    assert Either.to_lazy(100) == Lazy(100)


# Generated at 2022-06-23 23:56:36.008935
# Unit test for method ap of class Left
def test_Left_ap():
    get_version = lambda monad: monad.ap(Right(lambda v: '{}'.format(v)))

    for version in range(4):
        assert Left(version) == get_version(Left(version))



# Generated at 2022-06-23 23:56:39.902583
# Unit test for method ap of class Left
def test_Left_ap():
    # given
    left = Left(1)
    right = Right(lambda x: x * 2)

    # then
    assert left.ap(right) == left


# Generated at 2022-06-23 23:56:44.344224
# Unit test for constructor of class Either
def test_Either():
    # we test that the constructor of Either doesn't throw an exception
    assert isinstance(Either(1), Either[int])
    assert isinstance(Either("something"), Either[str])
    assert isinstance(Either(1.2), Either[float])
    assert isinstance(Either(None), Either[None])


# Generated at 2022-06-23 23:56:49.234944
# Unit test for method case of class Either
def test_Either_case():
    """Test of method case of either"""

    error_handler = lambda _: "test"
    success_handler = lambda _: "test2"

    assert Left("test").case(error_handler, success_handler) == "test"
    assert Right("test").case(error_handler, success_handler) == "test2"



# Generated at 2022-06-23 23:56:53.344527
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(2)) == Left(1)

# Generated at 2022-06-23 23:56:54.523197
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Right(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-23 23:56:59.721592
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right()



# Generated at 2022-06-23 23:57:02.867518
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert (Right(1).to_try() == Try(1, True))
    assert (Left(1).to_try() == Try(1, False))



# Generated at 2022-06-23 23:57:05.781355
# Unit test for method is_right of class Either
def test_Either_is_right():
    val = Either(1)
    assert not val.is_right()
    val = Right(1)
    assert val.is_right()
    val = Left(1)
    assert not val.is_right()



# Generated at 2022-06-23 23:57:08.939126
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """Unit test for method to_validation of class Right"""

    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:57:15.211579
# Unit test for method map of class Right
def test_Right_map():
    def add_one(x):
        return x + 1

    right: Either[int] = Right(3)

    assert right.map(add_one) == Right(4)
    assert right.map(add_one).value == 4
    assert right.map(add_one).is_right()
    assert not right.map(add_one).is_left()


# Generated at 2022-06-23 23:57:17.545415
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:57:21.562109
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:57:24.198916
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Right

    assert Validation.success(1) == Right(1).to_validation()

# Generated at 2022-06-23 23:57:26.985636
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(True).to_try() == Try(True, is_success=True)
    assert Either(False).to_try() == Try(False, is_success=False)


# Generated at 2022-06-23 23:57:33.745336
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(1).to_maybe()
    assert Maybe.nothing() == Left("abc").to_maybe()
    assert Maybe.nothing() == Left([]).to_maybe()
    assert Maybe.nothing() == Left(["abc"]).to_maybe()
    assert Maybe.nothing() == Left({}).to_maybe()
    assert Maybe.nothing() == Left({"abc": 1}).to_maybe()
    assert Maybe.nothing() == Left((1,)).to_maybe()
    assert Maybe.nothing() == Left((1, 2, 3)).to_maybe()
    assert Maybe.nothing() == Left(set([1])).to_maybe()
    assert Maybe.nothing() == Left(set([1, 2, 3])).to_maybe()
    assert Maybe.nothing() == Left

# Generated at 2022-06-23 23:57:37.581403
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    import pytest

    result = Right("ok").to_validation()

    assert result.value == "ok"
    assert result.is_success == True


# Generated at 2022-06-23 23:57:43.043882
# Unit test for method ap of class Left
def test_Left_ap():
    print('test_Left_ap')

    def func(arg):
        return arg + 10

    left = Left(3)
    right = Right(func)
    print('left = {}'.format(left))
    print('right = {}'.format(right))

    left_ap = left.ap(right)
    print('left_ap = {}'.format(left_ap))


# Generated at 2022-06-23 23:57:45.588601
# Unit test for method map of class Left
def test_Left_map():
    left = Left('err')

    mapper = lambda x: x + 'or'
    actual = left.map(mapper)

    assert left == actual


# Generated at 2022-06-23 23:57:47.263506
# Unit test for method is_right of class Left
def test_Left_is_right():

    assert Left(4).is_right() == False


# Generated at 2022-06-23 23:57:52.619542
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-23 23:57:54.057466
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-23 23:57:58.847268
# Unit test for method bind of class Left
def test_Left_bind():
    left_value = "Left Value"
    left = Left(left_value)
    assert left.bind(lambda x: x) == left_value



# Generated at 2022-06-23 23:58:01.393103
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda s: s + '123').case(lambda _: 'error', lambda _: 'correct') == 'error'


# Generated at 2022-06-23 23:58:06.915916
# Unit test for constructor of class Either
def test_Either():
    e = Either(10)
    assert e



# Generated at 2022-06-23 23:58:10.940013
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    e = Either(3).to_box()
    assert isinstance(e, Box)
    assert e.is_box()
    assert e.unbox() == 3


# Generated at 2022-06-23 23:58:14.836064
# Unit test for method bind of class Left
def test_Left_bind():
    maybe = Left('Some Error')
    actual = maybe.bind(lambda x: Right(x))
    expected = Left(actual.value)

    assert actual == expected


# Generated at 2022-06-23 23:58:17.333575
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: x + 1) == 2
    assert Right(1).bind(lambda x: x / 0) == ERROR_ZERO_DIVISION



# Generated at 2022-06-23 23:58:22.081738
# Unit test for constructor of class Left
def test_Left():
    # Test on Box class
    assert Left(10) == Left(10)
    assert Left(10) != Left(20)
    assert Left(10) != Right(10)


# Generated at 2022-06-23 23:58:26.527213
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(10)
    mapper = lambda number: Left(number + 1)

    assert left.bind(mapper) == Left(11)



# Generated at 2022-06-23 23:58:27.565305
# Unit test for constructor of class Either
def test_Either():
    assert Either(2)


# Generated at 2022-06-23 23:58:33.413920
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    left = Left(1)
    validation = left.to_validation()

    assert isinstance(validation, Validation)
    assert testing.is_error(validation)
    assert validation.is_fail()
    assert validation.value == [1]
    assert not validation.is_success()
    assert len(validation.value) == 1
    assert validation.value[0] == 1



# Generated at 2022-06-23 23:58:37.261025
# Unit test for constructor of class Right
def test_Right():
    assert Right(2).case(lambda a: a, lambda b: b) == 2


# Generated at 2022-06-23 23:58:39.146126
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    assert right.map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:58:41.536511
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(5) == Right(5)
    assert Left(5) == Left(5)
    assert Left(5) != Right(5)
    assert Left(5) != Right(6)


# Generated at 2022-06-23 23:58:43.483377
# Unit test for method ap of class Left
def test_Left_ap():
    left_value = Left("left_value")
    monad = Left("contains_function")
    assert left_value.ap(monad) == left_value



# Generated at 2022-06-23 23:58:45.432170
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(1)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:58:47.251766
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(5).bind(lambda v: v + 5) == Left(5)



# Generated at 2022-06-23 23:58:56.668981
# Unit test for method bind of class Left
def test_Left_bind():
    v_1 = Left('first')
    f_1 = lambda x: Right(x + ' second')

    v_2 = Left('not')
    f_2 = lambda x: 2

    def f_3(x):
        if x == 'fail':
            return Left('error')
        return Left(x + ' second')

    assert v_1.bind(f_1) == Left('first')
    assert v_1.bind(f_2) == Left('first')
    assert v_2.bind(f_2) == Left('not')
    assert v_1.bind(f_3) == Left('first')



# Generated at 2022-06-23 23:58:57.835542
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False

# Generated at 2022-06-23 23:59:01.068145
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():

    # Given the value "value"
    value = 'value'

    # And the Left monad with the value
    left = Left(value)

    # When I call to_maybe method on the Left monad
    result = left.to_maybe()

    # Then I is a Maybe without value
    assert isinstance(result, Maybe)
    assert result.is_nothing()


# Generated at 2022-06-23 23:59:07.918666
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.lazy import Lazy

    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(3) != Right(3)
    assert Either(4) != Lazy(lambda: 4)
    assert Right(5) != Left(5)



# Generated at 2022-06-23 23:59:09.061399
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(2).is_right()


# Generated at 2022-06-23 23:59:14.328145
# Unit test for method is_right of class Left
def test_Left_is_right():
    # Given
    left = Left("Error")
    # When
    either = left.is_right()
    # Then
    assert not either



# Generated at 2022-06-23 23:59:16.062946
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left("").is_right()


# Generated at 2022-06-23 23:59:22.231261
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(10)
    assert right.is_right() == True


# Generated at 2022-06-23 23:59:24.367895
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(2).is_right() is False
    assert Right(2).is_right() is True



# Generated at 2022-06-23 23:59:27.257960
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(12) == Right(12).to_validation()


# Generated at 2022-06-23 23:59:30.746273
# Unit test for method ap of class Either
def test_Either_ap():
    f = lambda x: x * 2
    assert Right(f).ap(Right(2)) == Right(4)
    assert Left("error").ap(Left("error")) == Left("error")



# Generated at 2022-06-23 23:59:34.998067
# Unit test for method ap of class Left
def test_Left_ap():

    def times3(x):
        return x * 3

    def times4(x):
        return x * 4

    left1 = Either.of(times3)
    right2 = Either.of(2)
    assert left1.ap(right2) == Left(times3)

# Generated at 2022-06-23 23:59:36.744877
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:59:38.819436
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    result = Left(2).ap(Left('function'))
    assert result.value == 2


# Generated at 2022-06-23 23:59:43.764685
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True

# Generated at 2022-06-23 23:59:45.593596
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right("Success").to_validation() == Validation.success("Success")



# Generated at 2022-06-23 23:59:51.548647
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)



# Generated at 2022-06-23 23:59:56.646902
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(5).is_right()
    assert not Left(5).is_right()


# Generated at 2022-06-23 23:59:59.059749
# Unit test for method is_left of class Right
def test_Right_is_left():
    # given
    from pymonet.either import Right
    # when
    either = Right("value")
    # then
    assert not either.is_left()


# Generated at 2022-06-24 00:00:06.991152
# Unit test for constructor of class Left
def test_Left():
    """
    Property: Left value is equal to itself
    """
    from hypothesis.strategies import from_type
    from hypothesis import given, settings

    @given(from_type(Left), from_type(Left))
    @settings(max_examples=10, timeout=0)
    def test_eq(left, other) -> bool:
        return left == other

    # the function test_eq should not raise any exception, otherwise it fails
    test_eq()



# Generated at 2022-06-24 00:00:11.265564
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-24 00:00:14.317978
# Unit test for method bind of class Right
def test_Right_bind():
    def div(x): return Right(1.0 / x)

    assert Right(2.0).bind(div) == Right(0.5)
    assert Right(0.0).bind(div).is_left()


# Generated at 2022-06-24 00:00:18.522852
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.box import Box

    assert Left(Box(2)) == Left(Box(2)).bind(lambda x: Left(Box(x + 1)))



# Generated at 2022-06-24 00:00:19.582155
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(123).to_maybe() == Maybe.just(123)



# Generated at 2022-06-24 00:00:20.932471
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(10).is_right() is False
    assert Right(10).is_right() is True

# Generated at 2022-06-24 00:00:27.008090
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    e = Right(1)

    # when
    lazy = e.to_lazy()

    # then
    assert lazy.value() == 1

    # given
    e = Left(1)

    # when
    lazy = e.to_lazy()

    # then
    assert lazy.value() == 1



# Generated at 2022-06-24 00:00:31.980893
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-24 00:00:33.080565
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:34.683443
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()



# Generated at 2022-06-24 00:00:37.233289
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()


# Generated at 2022-06-24 00:00:38.878584
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: str(x)) == Left(1)



# Generated at 2022-06-24 00:00:40.632797
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda x: x * 2) == Left('error')



# Generated at 2022-06-24 00:00:42.317687
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is False


# Generated at 2022-06-24 00:00:48.199557
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(10) == Left(10), "should be equal"
    assert Right(10) == Right(10), "should be equal"
    assert not Left(10) == Left(11), "should not be equal"
    assert not Left(10) == Right(10), "should not be equal"
    assert not Right(10) == Left(10), "should not be equal"



# Generated at 2022-06-24 00:00:50.372386
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(3).to_box() == Box(3)
    assert Right(3).to_box() == Box(3)

# Generated at 2022-06-24 00:00:51.929126
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-24 00:00:54.513740
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(10)
    assert left.to_validation() == Validation.fail([10])


# Generated at 2022-06-24 00:01:01.053408
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.either import Either

    assert Either(lambda x: x + 1).ap(Box(1)) == Box(2)
    assert Either(lambda x: x + 1).ap(Right(Box(1))) == Right(Box(2))
    assert Either(lambda x: x + 1).ap(Left(1)) == Left(1)
    assert Either(Functor(lambda x: x + 1)).ap(Box(1)) == Box(2)
    assert Either.identity.ap(Box(1)) == Box(1)
    assert Either(Monad(lambda x: x + 1)).ap(Box(Monad(1))) == Box(Monad(2))

# Generated at 2022-06-24 00:01:02.724553
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    result = Left(0).ap(Box(lambda x: x + 1))

    assert result == Left(0)



# Generated at 2022-06-24 00:01:07.311552
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    assert Left(1).ap(Box(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Box(lambda x: x)) == Left(1)
    assert Left(1).ap(Box(lambda x: x - 1)) == Left(1)
    assert Left(None).ap(Box(lambda x: x)) == Left(None)
    assert Left(None).ap(Box(lambda x: x)) == Left(None)


# Generated at 2022-06-24 00:01:10.723121
# Unit test for method map of class Right
def test_Right_map():
    # Given
    right = Right(5)
    mapper = lambda x: x + 2
    # When
    result = right.map(mapper)
    # Then
    assert result == Right(7)


# Generated at 2022-06-24 00:01:17.146195
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()



# Generated at 2022-06-24 00:01:18.799742
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-24 00:01:20.610418
# Unit test for method map of class Left
def test_Left_map():
    left = Left('left')
    left.map(lambda x: x + '_right')
    assert left.value == 'left'



# Generated at 2022-06-24 00:01:23.380591
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.functor import Functor

    @Functor
    class SomeRightFunctor(Right):
        pass

    assert SomeRightFunctor(5).map(lambda x: x * 2) == Right(10)



# Generated at 2022-06-24 00:01:24.914565
# Unit test for method map of class Right
def test_Right_map():
    value = Right(1).map(lambda x: x+1)
    assert value.value == 2
    assert type(value) == Right


# Generated at 2022-06-24 00:01:28.368113
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    assert right.map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-24 00:01:31.011388
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(5)
    assert right.is_left() is False


# Generated at 2022-06-24 00:01:33.835111
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right("toto")
    assert right.to_validation().is_success()


# Generated at 2022-06-24 00:01:37.109912
# Unit test for constructor of class Left
def test_Left():
    assert Left(2) == Left(2)
    assert Left(2) != Left(3)
    assert Left(2) != Left(Right(2))
    assert Left(2) != Left(Left(2))



# Generated at 2022-06-24 00:01:39.713741
# Unit test for method ap of class Left
def test_Left_ap():
    """ Unit test for method ap of class Left """
    from pymonet.box import Box

    assert Left(1).ap(Box(lambda x: x*2)) == Left(1)



# Generated at 2022-06-24 00:01:41.148682
# Unit test for method is_left of class Left
def test_Left_is_left():
    error_value = 1
    left = Left(error_value)
    assert left.is_left()


# Generated at 2022-06-24 00:01:45.130536
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try, Failure

    assert Either(5).to_try() == Try(5, is_success=True)
    assert Try(5, is_success=True).to_try() == Try(5, is_success=True)
    assert Failure(5).to_try() == Try(5, is_success=False)



# Generated at 2022-06-24 00:01:47.201073
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()
    assert not Right(42).is_left()


# Generated at 2022-06-24 00:01:51.646174
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    from pymonet.either import Left, Right

    assert Left("error").to_try() == Try("error", is_success=False)
    assert Right("ok").to_try() == Try("ok", is_success=True)


# Generated at 2022-06-24 00:01:53.077364
# Unit test for method is_right of class Right
def test_Right_is_right():
    result = Right(2).is_right()
    assert result == True



# Generated at 2022-06-24 00:01:57.508567
# Unit test for method bind of class Right
def test_Right_bind():
    def bind_f(value):
        return Right(value + '!')

    assert Right('Hello').bind(bind_f) == Right('Hello!')
    assert Right('Hello').bind(bind_f).bind(bind_f) == Right('Hello!!')



# Generated at 2022-06-24 00:02:00.212927
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(1)
    right = Right(1)

    assert(left.is_right() is False)
    assert(right.is_right() is True)



# Generated at 2022-06-24 00:02:02.583946
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:02:03.501929
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1) # pylint: disable=R1719

# Generated at 2022-06-24 00:02:04.790575
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(3).is_left() is True



# Generated at 2022-06-24 00:02:06.577262
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(2).to_box() == Box(2)



# Generated at 2022-06-24 00:02:18.948102
# Unit test for constructor of class Left
def test_Left():
    assert Left(8).value == 8  # Test that it store value

    # Test that it return new instance of Left
    assert Left(8).map(lambda x: x * 10) == Left(8)
    assert Left(8).bind(lambda x: Right(x + 10)) == Left(8)  # Test that it return Right value in bind
    assert Left(8).is_left()  # Test that it return True
    assert not Left(8).is_right()  # Test that it return False
    assert Left(8).to_maybe() == Maybe.nothing()  # Test that it return empty Maybe
    assert Left(8).to_validation() == Validation.fail([8])  # Test that it return failed validation
    assert Left(8).to_box() == Box(8)  # Test that it return proper box

# Generated at 2022-06-24 00:02:20.371010
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True


# Generated at 2022-06-24 00:02:22.524468
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:02:24.349422
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.right(2).to_lazy().value() == 2
    assert Either.left(None).to_lazy().value() is None


# Generated at 2022-06-24 00:02:25.108235
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(0).is_right()


# Generated at 2022-06-24 00:02:29.350862
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.either import Left

    assert Left(4).ap(Box(lambda x: x * 10)) == Left(4)


# Generated at 2022-06-24 00:02:31.180595
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() == False



# Generated at 2022-06-24 00:02:35.707684
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Either(5).to_lazy()
    assert Lazy(lambda: 6) == Either(6).to_lazy()


# Generated at 2022-06-24 00:02:36.727707
# Unit test for constructor of class Left
def test_Left():
    assert Left("foo") == Left("foo")

# Generated at 2022-06-24 00:02:47.481799
# Unit test for constructor of class Left
def test_Left():
    from asserts import assert_

    assert_(Left(1) == Left(1), True)
    assert_(Left(1).to_box() == Left(1).to_box(), True)
    assert_(Left(1).to_try() == Left(1).to_try(), True)
    assert_(Left(1).to_lazy() == Left(1).to_lazy(), True)
    assert_(Left(1).to_maybe() == Left(1).to_maybe(), True)
    assert_(Left(1).to_validation() == Left(1).to_validation(), True)
    assert_(Left(1).map(lambda v: v) == Left(1), True)
    assert_(Left(1).ap(Left(lambda v: v)) == Left(1), True)

# Generated at 2022-06-24 00:02:49.249132
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)



# Generated at 2022-06-24 00:02:51.059021
# Unit test for method is_right of class Either
def test_Either_is_right():
    res = Right("test").is_right()
    assert res is True



# Generated at 2022-06-24 00:02:52.600694
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-24 00:02:54.669561
# Unit test for constructor of class Either
def test_Either():
    """Unit tests for contructor of class Either"""

    assert Either(1).value == 1



# Generated at 2022-06-24 00:02:58.308356
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left("Error")

    # When
    new_left = left.bind(lambda value: Right(value))

    # Then
    assert new_left.is_left()
    assert new_left.value == "Error"



# Generated at 2022-06-24 00:02:59.639220
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:03:05.692393
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Try(1)
    assert Either(0).to_try() == Try(0)
    assert Either('error').to_try() == Try('error')
    assert Either('').to_try() == Try('')
    assert Either(Exception('error')).to_try() == Try(Exception('error'))
    assert Either(Exception()).to_try() == Try(Exception())


# Generated at 2022-06-24 00:03:10.980462
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    maybe_1 = Right(3).to_maybe()
    assert isinstance(maybe_1, Maybe) and maybe_1.is_just() and maybe_1.value == 3
    maybe_2 = Right([2, 3]).to_maybe()
    assert isinstance(maybe_2, Maybe) and maybe_2.is_just() and maybe_2.value == [2, 3]


# Generated at 2022-06-24 00:03:14.178973
# Unit test for method map of class Left
def test_Left_map():

    # Given
    left_initial = Left("initial value")

    # When
    left_mapped = left_initial.map(str.title)

    # Then
    assert left_initial.value == left_mapped.value



# Generated at 2022-06-24 00:03:15.575283
# Unit test for constructor of class Left
def test_Left():
    from pymonet.utils import identity

    assert Left(10).case(identity, identity) == 10



# Generated at 2022-06-24 00:03:17.664095
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Arrange
    right = Right(2)

    # Act
    result = right.is_right()

    # Assert
    assert result



# Generated at 2022-06-24 00:03:27.077578
# Unit test for method ap of class Left
def test_Left_ap():
    #<editor-fold desc="Arrange">
    from pymonet.box import Box
    from pymonet.box import BoxedValue
    boxed_value = Box(BoxedValue(4))
    left_value = Left(BoxedValue(4))
    #</editor-fold>

    #<editor-fold desc="Act">
    result = left_value.ap(boxed_value)
    #</editor-fold>

    #<editor-fold desc="Assert">
    assert isinstance(result, Left)
    assert result.value == BoxedValue(4)
    #</editor-fold>


# Generated at 2022-06-24 00:03:28.694613
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() ==\
        Maybe.nothing()


# Generated at 2022-06-24 00:03:32.127313
# Unit test for method bind of class Left
def test_Left_bind():
    left: Either[str] = Left('fallback')
    data: Either[str] = left.bind(lambda x: Right(x + ' world'))
    assert data == left


# Generated at 2022-06-24 00:03:36.738031
# Unit test for method is_right of class Left
def test_Left_is_right():
    """
    Test for method is_right of class Left.

    >>> from pymonet.either import Left
    >>> isinstance(Left(1).is_right(), bool)
    True
    """
    from pymonet.either import Left

    assert isinstance(Left(1).is_right(), bool)



# Generated at 2022-06-24 00:03:39.195037
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('toto').to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:03:43.874519
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    assert Right(Maybe.just(Try.success(1))).is_right()
    assert not Right(Maybe.just(Try.failure(Exception('Boom!')))).is_right()
    assert not Left(Maybe.nothing()).is_right()


# Generated at 2022-06-24 00:03:45.737953
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(10).to_validation() == Validation.fail([10])
