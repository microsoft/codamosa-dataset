

# Generated at 2022-06-23 23:53:47.926825
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-23 23:53:55.723924
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test bind method of class Right
    """
    import pytest

    either = Right(3)
    result = either.bind(lambda x: Right(x + 1))
    assert result.value == 4

    either = Right(3)
    result = either.bind(lambda x: Left('wrong'))
    assert isinstance(result, Left) and result.value == 'wrong'



# Generated at 2022-06-23 23:53:58.838552
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left = Left('error')
    assert left.to_lazy() == Lazy(lambda: 'error')

    right = Right('success')
    assert right.to_lazy() == Lazy(lambda: 'success')


# Generated at 2022-06-23 23:54:00.950223
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x * 2) == Right(4)


# Generated at 2022-06-23 23:54:03.042370
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either(Box(2)).to_box() == Box(Box(2))



# Generated at 2022-06-23 23:54:06.993679
# Unit test for method is_left of class Right
def test_Right_is_left():
    value = 1
    expected = False
    result = Right(value).is_left()

    assert result == expected



# Generated at 2022-06-23 23:54:08.331757
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(0).is_right() == False

# Generated at 2022-06-23 23:54:09.513445
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-23 23:54:10.818444
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(None).to_validation().is_fail()


# Generated at 2022-06-23 23:54:14.183228
# Unit test for method bind of class Left
def test_Left_bind():
    result = Left(1).bind(lambda x: Right(x * 2))
    assert result.is_left() and result.value == 1


# Generated at 2022-06-23 23:54:17.967105
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)
    assert left == Left(1)
    assert right == Right(1)
    assert left == Left("kot")
    assert right == Right("kot")
    assert left != Right("kot")
    assert right != Left("kot")


# Generated at 2022-06-23 23:54:21.765815
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:54:25.929126
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Right('test').to_maybe() == Maybe.just('test')



# Generated at 2022-06-23 23:54:31.384576
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True


# Generated at 2022-06-23 23:54:34.292978
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda v: Left(v)) == Left(3)
    assert Right(3).bind(lambda v: Right(v)) == Right(3)


# Generated at 2022-06-23 23:54:37.483717
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    return assert_that(Either[str].to_lazy('value'), equals(Lazy(lambda: 'value')))



# Generated at 2022-06-23 23:54:38.860172
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('left').to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:54:41.152368
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.unit import unit

    assert Left(unit()).is_left() is True
    assert Left(unit()).is_right() is False


# Generated at 2022-06-23 23:54:47.428606
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)
    assert Right("a").map(lambda x: x * 2) == Right("aa")
    assert Right([]).map(lambda x: x.append(1)) == Right([1])
    assert Right("").map(lambda x: x.append("a")) == Right("")


# Generated at 2022-06-23 23:54:50.163495
# Unit test for constructor of class Either
def test_Either():
    """
    Simple test for testing that constructor of Either class doesnt throw any exception and initialize value.

    :returns: None
    :rtype: None
    """
    left = Left(1)
    right = Right(1)

    assert left.value == 1
    assert right.value == 1



# Generated at 2022-06-23 23:54:54.734745
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-23 23:54:55.821389
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(123).is_right()



# Generated at 2022-06-23 23:54:56.327667
# Unit test for constructor of class Either
def test_Either():
    assert Either(42) is None

# Generated at 2022-06-23 23:54:58.809208
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('test')

    assert left.bind(lambda x: Right(1)) == left
    assert left.map(lambda x: 1) == left
    assert left.bind(lambda x: 2) == left
    assert left.ap(Right(lambda x: x)) == left


# Generated at 2022-06-23 23:55:04.966323
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    either = Right(10)
    try_ = either.to_try()

    assert isinstance(try_, Try)
    assert try_.is_success()
    assert try_.value == 10

    either = Left(10)
    try_ = either.to_try()

    assert isinstance(try_, Try)
    assert not try_.is_success()
    assert try_.value == 10

# Generated at 2022-06-23 23:55:11.179383
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:55:13.359926
# Unit test for method map of class Left
def test_Left_map():
    left: Either[int] = Left(1)
    assert left.map(lambda x: x + 2) == left



# Generated at 2022-06-23 23:55:14.605469
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(0)
    assert left.is_left()



# Generated at 2022-06-23 23:55:18.676180
# Unit test for method case of class Either
def test_Either_case():
    def test_string(a: str) -> str:
        return a + '_test_string'

    def test_int(a: int) -> int:
        return a + 1

    assert Left('hoho').case(test_string, test_int) == 'hoho_test_string'
    assert Right(1).case(test_string, test_int) == 2

# Generated at 2022-06-23 23:55:19.954078
# Unit test for constructor of class Left
def test_Left():
    assert_that(Left(1).value, is_(1))


# Generated at 2022-06-23 23:55:24.987130
# Unit test for method ap of class Either
def test_Either_ap():
    right_box = Right(Box(lambda x: x + 1))
    right = Right(1)
    left = Left(1)
    right_after_apply = right.ap(right_box)
    left_after_apply = left.ap(right_box)
    assert isinstance(right_after_apply, Right)
    assert right_after_apply.value == 2
    assert isinstance(left_after_apply, Left)
    assert left_after_apply.value == 1

# Generated at 2022-06-23 23:55:26.430454
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.value == 1


# Generated at 2022-06-23 23:55:28.562096
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left([{'error': 'Oops!'}])
    assert left.to_validation() == Validation.fail([{'error': 'Oops!'}])


# Generated at 2022-06-23 23:55:32.494942
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import Functor

    def process(value: Any) -> Either[Any]:
        return Right(value)

    assert Either.ap(Right(Functor.of(process)).value, Right(10)) == Right(10).value



# Generated at 2022-06-23 23:55:36.678532
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Right(1).to_maybe() == Just(1)


# Generated at 2022-06-23 23:55:40.375418
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:55:42.335390
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:55:44.253812
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(4).to_validation().is_fail() == True
    assert Left(4).to_validation().value == [4]


# Generated at 2022-06-23 23:55:45.962421
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try

    try_ = Try.unit('Success')
    assert try_.bind(lambda x: x + '2') == Right('Success2')

# Generated at 2022-06-23 23:55:49.269767
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(42).to_try() == Try(42, is_success=False)
    assert Right(42).to_try() == Try(42, is_success=True)


# Generated at 2022-06-23 23:55:52.639933
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Set up
    either = Either(1)

    # Invoke the SUT
    is_right = either.is_right()

    # Checking
    assert is_right is False



# Generated at 2022-06-23 23:55:53.764565
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:55:55.461814
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-23 23:55:56.821623
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    res = Right(2).to_maybe()
    expected = Maybe.just(2)
    assert res == expected


# Generated at 2022-06-23 23:56:02.368885
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(1)

    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:07.200492
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Left(5).ap(Box(lambda x: x + 5)) == Left(5)
    assert Left(5).ap(Maybe.just(lambda x: x + 5)) == Left(5)

# Generated at 2022-06-23 23:56:09.469550
# Unit test for constructor of class Left
def test_Left():
    # When create Left with value
    left = Left(1)

    # Then value is the same
    assert(left.value == 1)



# Generated at 2022-06-23 23:56:11.373904
# Unit test for constructor of class Right
def test_Right():
    assert Right(42).value == 42
    assert Right(42) == Right(42)



# Generated at 2022-06-23 23:56:18.220850
# Unit test for constructor of class Left
def test_Left():
    assert Left('error') == Left('error')
    assert Left('error') != Right('right')
    assert Left('error') != Left('wrong')
    assert Left('error') != 'error'
    assert Left('error').case(lambda value: 'error', lambda value: 'right') == 'error'


# Generated at 2022-06-23 23:56:21.245761
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.box import Box
    a = Left(Box(None))
    assert a.is_left() == True


# Generated at 2022-06-23 23:56:25.154603
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)

    assert Right(1) != Left(1)


# Generated at 2022-06-23 23:56:27.374980
# Unit test for method is_left of class Left
def test_Left_is_left():
    """Test Left's method is_left."""
    left_monad = Left(1)
    assert left_monad.is_left(), 'Left is not left'



# Generated at 2022-06-23 23:56:29.958030
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """Test of method to_validation of class Right"""
    from pymonet.validation import Validation
    from pymonet.either import Right

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:56:31.076869
# Unit test for constructor of class Left
def test_Left():
    left = Left("Maybe it's error")
    assert left.value == "Maybe it's error"



# Generated at 2022-06-23 23:56:31.878500
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('test').is_right()

# Generated at 2022-06-23 23:56:33.937585
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-23 23:56:39.057245
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(5)
    assert left.ap(Maybe.just(lambda x: 2 * x)) == Maybe.nothing()

# Generated at 2022-06-23 23:56:43.368152
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(123)
    maybe = right.to_maybe()

    assert isinstance(maybe, Maybe)
    assert maybe.is_just()
    assert maybe.is_nothing() is False
    assert maybe.value is 123



# Generated at 2022-06-23 23:56:45.930866
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-23 23:56:47.960308
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    value = Right(5).to_maybe()
    assert value == Maybe.just(5)


# Generated at 2022-06-23 23:56:49.804258
# Unit test for method ap of class Left
def test_Left_ap():
    expected = Left('Err')

    result = Left('Err').ap(Left('l'))

    assert expected == result


# Generated at 2022-06-23 23:56:50.851800
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:56:53.329577
# Unit test for method ap of class Either
def test_Either_ap():
    # Test when argument is Right
    assert Right(lambda x: x+1).ap(Right(5)) == Right(6)
    # Test when argument is Left
    assert Right(lambda x: x+1).ap(Left('error')) == Left('error')

# Generated at 2022-06-23 23:56:54.592663
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([5]) == Left(5).to_validation()



# Generated at 2022-06-23 23:56:56.291794
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    # Given
    left = Left(3)

    # When
    maybe = left.to_maybe()

    # Then
    assert maybe.is_nothing()
    assert maybe.value == None


# Generated at 2022-06-23 23:56:57.860116
# Unit test for method ap of class Left
def test_Left_ap():
    result = Left(lambda n: n + 5).ap(Left(10))
    assert isinstance(result, Left)
    assert result == Left(10)


# Generated at 2022-06-23 23:56:59.610600
# Unit test for constructor of class Either
def test_Either():
    assert Either(123)



# Generated at 2022-06-23 23:57:04.032401
# Unit test for constructor of class Left
def test_Left():
    test_value = 'test value'
    left = Left(test_value)
    assert left.value == test_value
    assert left.is_left() is True
    assert left.is_right() is False
    assert left.map(lambda x: x) == left



# Generated at 2022-06-23 23:57:08.909609
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    left = Left(1)

    assert left.to_validation() == Validation.fail([1])
    assert left.to_validation() != Validation.success(1)


# Generated at 2022-06-23 23:57:12.109097
# Unit test for constructor of class Either
def test_Either():
    either = Left(3)
    assert 3 == either.value
    either = Right(3)
    assert 3 == either.value



# Generated at 2022-06-23 23:57:15.509820
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-23 23:57:17.460376
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right("1").value == "1"


# Generated at 2022-06-23 23:57:23.722239
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.validation import Validation

    assert Right(lambda x: x + 1).ap(Right(1)) == Right(2)
    assert Left("error").ap(Right(1)) == Left("error")
    assert Right(lambda x: x + 1).ap(Left("error")) == Left("error")
    assert Right(lambda x: x + 1).ap(Validation.success(1)) == Validation.success(2)

# Generated at 2022-06-23 23:57:30.433620
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left('error')).case(
        lambda x: 'error',
        lambda x: 'not error'
    ) == 'error'



# Generated at 2022-06-23 23:57:32.236857
# Unit test for method map of class Right
def test_Right_map():
    mapper = lambda _: '_'
    assert Right('_').map(mapper) == Right('_'), 'Right class map method'



# Generated at 2022-06-23 23:57:35.291478
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-23 23:57:37.502282
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('error').is_right() == False
    assert Right('value').is_right() == True


# Generated at 2022-06-23 23:57:39.933813
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(3).is_right() == True
    assert Left(3).is_right() == False


# Generated at 2022-06-23 23:57:42.677510
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    actual = Right(4).to_maybe()
    expected = Maybe.just(4)

    assert actual == expected


# Generated at 2022-06-23 23:57:45.743964
# Unit test for method bind of class Right
def test_Right_bind():
    """Unit test for method bind of class Right."""
    right = Right(2)
    right2 = right.bind(lambda x: Right(x * 2))
    right3 = right.bind(lambda x: Right(x / 2))
    assert isinstance(right2, Either)
    assert isinstance(right3, Either)
    assert right2.value == 4
    assert right3.value == 1



# Generated at 2022-06-23 23:57:46.665118
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 1) == Right(3)



# Generated at 2022-06-23 23:57:48.518252
# Unit test for method bind of class Right
def test_Right_bind():
    assert Either.Right(1).bind(lambda x: Either.Right(x + 1)) == Either.Right(2)


# Generated at 2022-06-23 23:57:52.589793
# Unit test for method map of class Right
def test_Right_map():
    either_value = Right(5)
    mapper = lambda x: x + 1

    assert Right(6) == either_value.map(mapper)



# Generated at 2022-06-23 23:57:59.509285
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from hypothesis import given, assume

    @given(bool_obj=str())
    def test(bool_obj):
        should = bool_obj == bool_obj

        if str(bool_obj).lower() == 'true':
            assume(should)

        left_a = Left(bool_obj)
        left_b = Left(bool_obj)
        right_a = Right(bool_obj)
        right_b = Right(bool_obj)

        assert left_a == left_b == left_a
        assert not left_a == right_a
        assert not right_a == left_a

        assert right_a == right_b == right_a
        assert not right_a == left_a
        assert not left_a == right_a

    test()

# Generated at 2022-06-23 23:58:00.859332
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-23 23:58:03.991923
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Right(1).to_try() == Try(1)
    assert Left(1).to_try() == Try(1, is_success=False)


# Generated at 2022-06-23 23:58:05.099950
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('meh').to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:58:09.582610
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.maybe import Maybe

    assert Either.of("foo").ap(Maybe.just(len)) == Left("foo")
    assert Either.of(3).ap(Maybe.just(lambda x: x + 1)) == Right(4)

# Generated at 2022-06-23 23:58:15.139340
# Unit test for method case of class Either
def test_Either_case():
    # Given
    either = Either.from_value(10)
    # When
    result = either.case(lambda x: x + 10, lambda x: x + 20)
    # Then
    assert result == 30



# Generated at 2022-06-23 23:58:16.163342
# Unit test for constructor of class Either
def test_Either():
    assert Either("") != None



# Generated at 2022-06-23 23:58:17.456095
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right("whatever").is_left() is False



# Generated at 2022-06-23 23:58:22.485518
# Unit test for constructor of class Right
def test_Right():

    right = Right(5)

    assert right.bind(lambda x: Left(x + 2)) == Left(7)
    assert right.bind(lambda x: Right(x + 2)) == Right(7)

    right1 = right.bind(lambda x: Right(x + 2))
    right2 = right.bind(lambda x: Right(x + 2))
    assert right1 == right2

    right_dbl = right.bind(lambda x: Right(x * 2))
    assert right_dbl.value == 10

    assert right.bind(lambda _: left).is_left()
    assert right.bind(lambda _: left).is_right() is False



# Generated at 2022-06-23 23:58:28.174667
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    left = Left(5)
    assert left.to_try() == Try(5, is_success=False)
    right = Right(5)
    assert right.to_try() == Try(5, is_success=True)



# Generated at 2022-06-23 23:58:30.111362
# Unit test for method map of class Right
def test_Right_map():
    assert Right('a').map(lambda x: x * 2) == Right('aa')


# Generated at 2022-06-23 23:58:31.840501
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) != Either('1')



# Generated at 2022-06-23 23:58:41.141809
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    def add(x:int) -> int:
        return x + 1

    assert Left(1).ap(Box(add)) == Left(1)
    assert Right(1).ap(Box(add)) == Right(2)
    assert Left(1).ap(Right(add)) == Left(1)
    assert Left(1).ap(Left(add)) == Left(1)
    assert Right(1).ap(Right(add)) == Right(2)
    assert Right(1).ap(Left(add)) == Left(add)


# Generated at 2022-06-23 23:58:42.892944
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-23 23:58:47.767208
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Try(1, is_success=True)
    assert Right(1) != Try(1, is_success=False)
    assert Left(1) != Try(1, is_success=True)
    assert Left(1) != Try(1, is_success=False)



# Generated at 2022-06-23 23:58:57.645441
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left_value = Either(5)
    left_value_1 = Either(5)
    left_value_2 = Either(4)
    left_value_3 = Either(5.0)
    left_value_4 = Either(5.0)
    right_value = Either(5)
    right_value_1 = Either(5)
    right_value_2 = Either(4)
    right_value_3 = Either(5.0)
    right_value_4 = Either(5.0)
    unpacked_value = 6

    # When
    left_eq_left = left_value == left_value_1
    left_eq_left_float = left_value_3 == left_value_4
    left_eq_right = left_value == right_value
    left_eq_right

# Generated at 2022-06-23 23:58:58.710551
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-23 23:59:01.492610
# Unit test for method to_box of class Either
def test_Either_to_box():

    left = Left(1)
    right = Right(2)

    assert left.to_box() == Box(1)
    assert right.to_box() == Box(2)


# Generated at 2022-06-23 23:59:08.293235
# Unit test for method case of class Either
def test_Either_case():
    def error(arg): return 'error:' + str(arg)

    def success(arg): return 'success:' + str(arg)

    either = Right(3)

    assert either.case(error, success) == 'success:3'

    either = Left(3)

    assert either.case(error, success) == 'error:3'


# Generated at 2022-06-23 23:59:12.612300
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right() is True


# Generated at 2022-06-23 23:59:15.511577
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(2).to_try() == Try(2, is_success=True)
    assert Left(2).to_try() == Try(2, is_success=False)

# Generated at 2022-06-23 23:59:17.975769
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-23 23:59:19.019891
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('').is_right()



# Generated at 2022-06-23 23:59:21.209218
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(4) == Right(4).to_validation()
    assert Validation.success('test') == Right('test').to_validation()



# Generated at 2022-06-23 23:59:33.656050
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right("test").value == "test"
    assert Right([1, 2, 3]).value == [1, 2, 3]
    assert Right({"a": 1, "b": 2}).value == {"a": 1, "b": 2}
    assert Right(None).value is None
    assert Right([1, 2, 3]).is_right()
    assert not Right([1, 2, 3]).is_left()
    assert Right([1, 2, 3]) == Right([1, 2, 3])
    assert Right([1, 2, 3]) != Left([1, 2, 3])
    assert Right([1, 2, 3]) != Right([1, 2, 4])
    assert Right([1, 2, 3]) != Right(None)


# Generated at 2022-06-23 23:59:37.243740
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left('error')) == Left('error')
    assert Right(3).bind(lambda x: Right(x + 2)) == Right(5)
    assert Right(3).bind(lambda x: Right(x)).bind(lambda x: Right(x + 2)) == Right(5)



# Generated at 2022-06-23 23:59:43.807171
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1).case(lambda x: x+1, lambda x: x+1) == 2
    assert isinstance(Left(1).map(lambda x: x), Left)
    assert isinstance(Left(1).bind(lambda x: x), Left)
    assert isinstance(Left(1).ap(Left(lambda x: x*2)), Left)
    assert Left(1).ap(Right(lambda x: x * 2)).map(lambda x: x + 1) == Right(3)
    assert Left(1).to_box().map(lambda x: x + 1) == Box(1)
    assert not Left(1).to_try().is_success
    assert Left(1).to_lazy().value() == 1
   

# Generated at 2022-06-23 23:59:49.100350
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    lazy = Maybe.just(7).to_lazy()
    assert lazy.value is Lazy
    assert lazy.resolver() == 7

# Generated at 2022-06-23 23:59:51.770522
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    result = right.map(lambda x: x * 2)
    new_result = Right(2)
    assert result == new_result

# Generated at 2022-06-23 23:59:59.042110
# Unit test for method case of class Either
def test_Either_case():
    either_left = Left(1)
    either_right = Right(10)

    def assert_case_left(value):
        assert value == 1
        return 2

    def assert_case_right(value):
        assert value == 10
        return 2

    assert either_left.case(assert_case_left, assert_case_right) == 2
    assert either_right.case(assert_case_left, assert_case_right) == 2



# Generated at 2022-06-24 00:00:05.141448
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(5)
    try:
        assert isinstance(left.bind(lambda x: Right(x + 1)), Left)
        assert left.bind(lambda x: Right(x + 1)).value == 5
    except AssertionError:
        print("test of method bind of class Left failed")



# Generated at 2022-06-24 00:00:06.140657
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)

# Generated at 2022-06-24 00:00:12.000485
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_lazy import Lazy

    f = lambda x: Lazy(lambda: x + 1)

    assert Right(1).bind(f).force() == 2

# Generated at 2022-06-24 00:00:14.949781
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    Test that right element transform to Maybe with content value.
    """
    right = Right(1)
    assert right.to_maybe() == Maybe.just(1)



# Generated at 2022-06-24 00:00:18.140383
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(6)
    validation = right.to_validation()

    assert validation == Validation.success(6)

# Generated at 2022-06-24 00:00:19.627223
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe().equals(Maybe.just(1))


# Generated at 2022-06-24 00:00:24.328583
# Unit test for constructor of class Left
def test_Left():
    assert Left(5) == Left(5)
    assert Left(5) != Right(5)
    assert Left(5) == Left(5.)
    assert Left(5.0) == Left(5)
    assert Left(5).value == 5
    assert not Left(5).is_left()
    assert Left(5).is_right()
    assert Left(5).case(lambda x: 'left', lambda x: 'right') == 'left'


# Generated at 2022-06-24 00:00:25.764166
# Unit test for method map of class Left
def test_Left_map():
    left = Left(11)
    mapper = lambda x: x + 1
    assert left.map(mapper).value == 11



# Generated at 2022-06-24 00:00:26.695198
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left("test").bind(lambda data: data) == "test"


# Generated at 2022-06-24 00:00:28.548470
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()
    assert not Left(None).is_left()
    assert not Right(1).is_left()
    assert not Right(None).is_left()

# Test method is_right of class Right

# Generated at 2022-06-24 00:00:32.495992
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(123).to_validation() == Validation.success(123)


# Generated at 2022-06-24 00:00:35.538038
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    # GIVEN
    value = 5
    left = Left(value)

    from pymonet.maybe import Maybe

    # WHEN
    maybe = left.to_maybe()

    # THEN
    assert isinstance(maybe, Maybe)
    assert maybe.is_nothing()


# Generated at 2022-06-24 00:00:37.629126
# Unit test for method to_try of class Either
def test_Either_to_try():

    assert(Left('value').to_try().is_failure())
    assert(Right('value').to_try().is_success())

# Generated at 2022-06-24 00:00:39.671301
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    right = Right(42)

    assert right.to_maybe() == Maybe.just(42)


# Generated at 2022-06-24 00:00:41.442105
# Unit test for method case of class Either
def test_Either_case():
    left_int = Left(1)
    right_int = Right(1)
    err = lambda x: x * 2
    suc = lambda x: x * 3

    assert left_int.case(err, suc) == 2
    assert right_int.case(err, suc) == 3



# Generated at 2022-06-24 00:00:43.144165
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-24 00:00:47.184597
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1)\
        .map(lambda x: x + 1)\
        .map(lambda x: x + 1)\
        .map(lambda x: x + 1)\
        .value == 1, "Left map function not work!"


# Generated at 2022-06-24 00:00:49.776967
# Unit test for method map of class Right
def test_Right_map():
    def twice_mapper(value): 
        return value * 2
    assert Right(2).map(twice_mapper) == Right(4)


# Generated at 2022-06-24 00:00:52.700270
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)



# Generated at 2022-06-24 00:00:56.729429
# Unit test for method to_try of class Either
def test_Either_to_try():
    # Case when value is Either(Right(1))
    assert Either(Right(1)).to_try() == Try(Right(1), is_success=False)

    def raise_function():
        raise Exception()

    # Case when value is Either(Left(function))
    assert Either(Left(raise_function)).to_try() == Try(Left(raise_function), is_success=False)



# Generated at 2022-06-24 00:00:58.849930
# Unit test for constructor of class Right
def test_Right():
    assert Right(None) == Right(None)
    assert Right(None).value is None


# Generated at 2022-06-24 00:01:00.424797
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    >>> assert Left(1) == Left(1)
    """
    # Nothing



# Generated at 2022-06-24 00:01:01.843002
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:01:02.826398
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-24 00:01:04.824178
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(0).is_right() == False
    assert Right(0).is_right() == True
    assert Left(0).is_right() == False



# Generated at 2022-06-24 00:01:06.860836
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(10).is_right() == False
    assert Right(10).is_right() == True


# Generated at 2022-06-24 00:01:08.868851
# Unit test for method is_right of class Right
def test_Right_is_right():
    either = Right(1)
    assert either.is_right() == True


# Generated at 2022-06-24 00:01:11.393006
# Unit test for method bind of class Right
def test_Right_bind():
    monad = Right(2)
    bind = lambda x: Right(x * 3)
    assert monad.bind(bind).value == 6



# Generated at 2022-06-24 00:01:13.851100
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:01:19.890258
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_maybe import Maybe

    assert Left(2).ap(Maybe.just(lambda a: a + 1)) == Left(2)
    assert Left(2).ap(Maybe.nothing()) == Left(2)
    assert Left(2).ap(Right(lambda a: a + 1)) == Left(2)



# Generated at 2022-06-24 00:01:21.674734
# Unit test for constructor of class Either
def test_Either():
    x = Right(3)
    assert x.value == 3
    x = Left(3)
    assert x.value == 3

# Generated at 2022-06-24 00:01:24.593430
# Unit test for method bind of class Right
def test_Right_bind():
    def double(x):
        return x * 2

    assert Right(5).bind(double) == 10
    assert Right(5).bind(lambda x: Right(x)).is_right() is True
    assert Right(5).bind(lambda x: Right(x)).value == 5



# Generated at 2022-06-24 00:01:27.980862
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    other = Left(2)

    assert left.ap(other) == Left(1)



# Generated at 2022-06-24 00:01:32.022437
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Unit test for method __eq__ of class Either
    """
    e1 = Either(1)
    e2 = Either(1)
    assert e1 != e2
    assert e2 != e1


# Generated at 2022-06-24 00:01:36.481949
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    def f(x): return Left(x + 1)
    right = Right(1)

    # When
    result = right.bind(f)

    # Then
    assert result is not None
    assert result == Left(2)


# Generated at 2022-06-24 00:01:37.908296
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(0).is_left() is True



# Generated at 2022-06-24 00:01:39.010241
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(10)
    new_left = left.ap(maybe)
    assert new_left.value == 10

# Generated at 2022-06-24 00:01:40.604194
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(1)
    right = Right(2)
    assert left.is_right() is False
    assert right.is_right() is True


# Generated at 2022-06-24 00:01:42.663876
# Unit test for method case of class Either
def test_Either_case():
    left = Left(1)
    right = Right(2)
    assert left.case(lambda x: x + 1, lambda y: y + 1) == 2
    assert right.case(lambda x: x + 1, lambda y: y + 1) == 3


# Generated at 2022-06-24 00:01:45.313465
# Unit test for method bind of class Right
def test_Right_bind():

    def mapper(value):
        class Type(type): pass
        return Left('Mapper failed')
        return Right('Mapper successfully applied')

    assert Right('value').bind(mapper) == Left('Mapper failed')


# Generated at 2022-06-24 00:01:48.799690
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    either = Left(5)

    # When
    result = either.bind(lambda x: x + 5)

    # Then
    assert isinstance(result, Left) and result == Left(5)



# Generated at 2022-06-24 00:01:50.740403
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-24 00:01:53.521612
# Unit test for method bind of class Right
def test_Right_bind():
    result = Right(5).bind(lambda value: Right(value * 5))

    assert isinstance(result, Right)
    assert result.value == 25


# Generated at 2022-06-24 00:01:56.749969
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Test for class Right
    assert Right(3).is_right()

    # Test for class Left
    assert not Left('error').is_right()

# Generated at 2022-06-24 00:01:59.109399
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    right = Right(lambda x: x + 1)
    assert left.ap(right) == left

# Generated at 2022-06-24 00:02:01.288560
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right('Pymonet')
    assert right.to_maybe() == Maybe.just('Pymonet')



# Generated at 2022-06-24 00:02:04.541461
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Assert that to_box method return Box monad with expected value.
    """
    assert Left(0).to_box().value == 0
    assert Right(10).to_box().value == 10



# Generated at 2022-06-24 00:02:07.569663
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Test of Either.to_try."""
    assert Either(1).to_try().get_success() == 1
    assert Either(None).to_try().get_error() is None



# Generated at 2022-06-24 00:02:10.722777
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-24 00:02:16.782569
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.maybe import Maybe

    def sum(a: int) -> int:
        return a + 10

    assert Left(5).ap(Maybe.just(sum)) == Left(5)
    assert Left(5).ap(Maybe.nothing()) == Left(5)
    assert Right(5).ap(Maybe.just(sum)) == Right(15)
    assert Right(5).ap(Maybe.nothing()) == Left(None)



# Generated at 2022-06-24 00:02:20.067731
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.functor import Functor

    f = lambda x: x * 2
    l = Left(1)
    l3 = Functor.map(f, l)
    assert l3 == Left(1)


# Generated at 2022-06-24 00:02:22.556835
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(0)
    assert Right(1) != Left(1)



# Generated at 2022-06-24 00:02:23.823385
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-24 00:02:25.372084
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(5).is_right() == True
    assert Left(5).is_right() == False



# Generated at 2022-06-24 00:02:26.766423
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('left').is_right() == False
    assert Right('right').is_right() == True


# Generated at 2022-06-24 00:02:32.030853
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    some_result = lambda x: x + 1
    assert Either.of(None).ap(Try.unit(some_result)) == Left(None)
    assert Either.of(1).ap(Try.unit(some_result)) == Right(2)


# Generated at 2022-06-24 00:02:36.306893
# Unit test for method map of class Left
def test_Left_map():
    # given
    value = 1
    left = Left(value)

    # when
    result = left.map(lambda x: x + 1)

    # then
    assert isinstance(result, Left)
    assert result.value == value


# Generated at 2022-06-24 00:02:38.437297
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(10).is_left()



# Generated at 2022-06-24 00:02:46.383538
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.functions import add
    from pymonet.maybe import Maybe

    assert Right(1).map(add(1)) == Right(2)
    assert Right(1).map(lambda x: x + 1) == Right(2)
    assert Right(1).map(lambda x: x) == Right(1)
    assert Right(1).map(lambda x: Maybe.just(x)) == Right(Maybe.just(1))
    assert Right(1).map(lambda x: Right(x)) == Right(Right(1))



# Generated at 2022-06-24 00:02:51.006908
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: 'error', lambda x: 'success') == 'error'
    assert Right(1).case(lambda x: 'error', lambda x: 'success') == 'success'
    assert Left(2).case(lambda x: x + 1, lambda x: x + 1) == 3
    assert Right(2).case(lambda x: x + 1, lambda x: x + 1) == 3



# Generated at 2022-06-24 00:02:52.882042
# Unit test for method map of class Left
def test_Left_map():
    assert Left("2").map(lambda x: int(x)) == Left("2")


# Generated at 2022-06-24 00:02:54.869906
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1)\
        .bind(lambda x: Right(x * 2)) == Right(2)



# Generated at 2022-06-24 00:02:56.233661
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(0).is_left()


# Generated at 2022-06-24 00:02:58.729289
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(5).to_box() == Box(5)
    assert Right(5).to_box() == Box(5)



# Generated at 2022-06-24 00:03:01.678989
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1).__eq__(Left(1))
    assert Left(1) != Left(2)
    assert Right(1).__eq__(Right(1))
    assert Right(1) != Right(2)
    assert Left(1) != Right(2)



# Generated at 2022-06-24 00:03:05.010286
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right('PyMonet rocks').to_box() == Box('PyMonet rocks')
    assert Left('PyMonet rocks').to_box() == Box('PyMonet rocks')

# Generated at 2022-06-24 00:03:06.480417
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(0).is_left()


# Generated at 2022-06-24 00:03:08.289722
# Unit test for constructor of class Left
def test_Left():
    instance = Left(1)

    assert isinstance(instance, Left)
    assert instance.value == 1


# Generated at 2022-06-24 00:03:09.644353
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False


# Generated at 2022-06-24 00:03:13.880706
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.maybe import Maybe, Just
    from pymonet.monad_try import Try, SuccessTry

    assert Left(5).is_right() == False
    assert Right(5).is_right() == True
    assert Just(5).is_right() == True
    assert SuccessTry(5).is_right() == True



# Generated at 2022-06-24 00:03:16.038828
# Unit test for method bind of class Left
def test_Left_bind():
    first_monad = Left([1])
    second_monad = Left([2])
    assert left_mapper(first_monad) == second_monad



# Generated at 2022-06-24 00:03:19.919444
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """
    Test if to_validation method of class Left return failed Validation monad as expected.
    """
    assert isinstance(Left(12).to_validation(), Validation)
    assert not Left(12).to_validation().is_success
    assert Left(12).to_validation().value == [12]



# Generated at 2022-06-24 00:03:21.238637
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1



# Generated at 2022-06-24 00:03:22.651039
# Unit test for constructor of class Left
def test_Left():
    assert Left(True) == Left(True)


# Generated at 2022-06-24 00:03:26.005646
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right('value')
    assert right.to_validation().is_success()


# Generated at 2022-06-24 00:03:27.441089
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:03:30.928328
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Test to_maybe of class Left.

    :returns: Nothing, raised exception means that test failed.
    :rtype: None
    """
    import pytest
    assert Left('').to_maybe() == Either.to_maybe(Left('')) == Maybe.nothing(), 'Both methods should return Nothing.'


# Generated at 2022-06-24 00:03:35.636993
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    right1 = Right(5)
    right2 = Right(5)
    left1 = Left(5)
    left2 = Left(5)
    assert right1 == right2
    assert left1 == left2
    assert not (right1 == left1)
    assert not (left1 == right1)


# Generated at 2022-06-24 00:03:36.691119
# Unit test for constructor of class Right
def test_Right():
    assert Right(4).value == 4


# Generated at 2022-06-24 00:03:38.342721
# Unit test for constructor of class Left
def test_Left():
    left = Left('Value')

    assert left.value is 'Value'



# Generated at 2022-06-24 00:03:40.722484
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(['error']).to_box() == Box(['error'])


# Generated at 2022-06-24 00:03:43.663996
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)



# Generated at 2022-06-24 00:03:45.213909
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-24 00:03:52.778758
# Unit test for method case of class Either
def test_Either_case():
    def error_case(input_: Any) -> str:
        return 'Error: {}'.format(input_)

    def success_case(input_: Any) -> str:
        return 'Success: {}'.format(input_)

    assert Right(1).case(error_case, success_case) == success_case(1)
    assert Left(1).case(error_case, success_case) == error_case(1)

