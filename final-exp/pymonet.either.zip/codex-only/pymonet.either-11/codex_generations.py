

# Generated at 2022-06-23 23:53:54.045215
# Unit test for method bind of class Right
def test_Right_bind():
    # Set up

    class MockMapper:
        def __init__(self, except_: Exception=None) -> None:
            self.except_ = except_
            self.calls = 0

        def __call__(self, value: T) -> Either[T]:
            self.calls += 1

            if self.except_ != None:
                raise self.except_("Error")

            if value == 0:
                return Left("Error")
            return Right(value * 2)

    f = MockMapper()
    g = MockMapper()

    # Exercise
    h = Right(1).bind(f).bind(g)

    # Verify
    assert h == Right(4)
    assert f.calls == 1
    assert g.calls == 1

    # Exercise

# Generated at 2022-06-23 23:53:55.504017
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True


# Generated at 2022-06-23 23:53:58.991471
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right('str').value == 'str'
    assert Right([1, 2]).value == [1, 2]
    assert Right({'1': 1, '2': 2}).value == {'1': 1, '2': 2}


# Generated at 2022-06-23 23:54:02.144101
# Unit test for method map of class Right
def test_Right_map():
    right = Right(0)
    right_copy = right.map(lambda x: x + 1)
    assert isinstance(right_copy, Right) and right_copy.value == 1


# Generated at 2022-06-23 23:54:09.656445
# Unit test for constructor of class Left
def test_Left():
    def test_case(value: int):
        left = Left(value)
        assert left == Left(value)
        assert left.value == value

    test_case(0)
    test_case(1)
    test_case(2)
    test_case(3)
    test_case(4)
    test_case(5)
    test_case(6)
    test_case(7)
    test_case(8)
    test_case(9)


# Generated at 2022-06-23 23:54:11.140165
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-23 23:54:15.063923
# Unit test for constructor of class Either
def test_Either():
    """Testing constructor of class Either."""
    # Given
    value = 5

    # When
    either = Either(value)

    # Then
    assert either.value == value



# Generated at 2022-06-23 23:54:17.028916
# Unit test for constructor of class Right
def test_Right():
    assert Right("Some value") == Right("Some value")



# Generated at 2022-06-23 23:54:19.408568
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([1]).equals(Left(1).to_validation())


# Generated at 2022-06-23 23:54:22.412212
# Unit test for constructor of class Either
def test_Either():
    class Test:
        def __init__(self, value, is_right):
            self.value = value
            self.is_right = is_right
            self.instance = Either(value)

        def test(self):
            assert self.instance.value == self.value

    Test(42, True).test()

# Generated at 2022-06-23 23:54:27.166906
# Unit test for constructor of class Either
def test_Either():
    # test with class Left
    left = Left([1, 2])
    assert(left.value == [1, 2])
    assert(left.case(lambda x: x, lambda x: x) == [1, 2])
    left_another = Left(['one', 'two'])
    assert(left == left_another)

    # test with class Right
    right = Right(2)
    assert(right.value == 2)
    assert(right.case(lambda x: x, lambda x: x) == 2)
    right_another = Right(2)
    assert(right == right_another)



# Generated at 2022-06-23 23:54:32.106700
# Unit test for method map of class Left
def test_Left_map():
    """
    Test for Left method map.

    :return: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_validation import Validation
    from pymonet.monad_lazy import Lazy

    # Same value is expected when we call on Left map function
    assert Left('Left').map(lambda x: x + '_mapped') == Left('Left')
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).map(lambda x: x + 1.0) == Left(1)

# Generated at 2022-06-23 23:54:38.280781
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left('Error')
    assert left.ap(Right(lambda x: x + 1)) == left, 'Either.ap: return copy of self when other is Right monad'
    assert left.ap(Left(lambda x: x + 1)) == left, 'Either.ap: return copy of self when other is Left monad'



# Generated at 2022-06-23 23:54:39.678768
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """Return Maybe[A] with Right[A] value"""
    from pymonet.maybe import Maybe

    assert Maybe.just(42) == Right(42).to_maybe()


# Generated at 2022-06-23 23:54:40.660102
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-23 23:54:42.682636
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left('something goes wrong').bind(Right) == Left('something goes wrong')


# Generated at 2022-06-23 23:54:48.128710
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(3)
    right = Right(3)
    left2 = Left(3)
    right2 = Right(3)
    left3 = Left(1)
    right3 = Right(1)

    assert left == left2
    assert right == right2
    assert left != right
    assert left3 != right3



# Generated at 2022-06-23 23:54:49.424039
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right() == True



# Generated at 2022-06-23 23:54:50.656226
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)


# Generated at 2022-06-23 23:55:00.859914
# Unit test for constructor of class Either
def test_Either():
    instance_of_either = Either(5)
    instance_of_left = Left(5)
    instance_of_right = Right(5)
    # __eq__
    assert instance_of_left == instance_of_left
    assert instance_of_right == instance_of_right
    assert instance_of_left != instance_of_right
    assert instance_of_right != instance_of_left
    # case
    assert instance_of_left.case(lambda v: v + 1, lambda v: v - 1) == 6
    assert instance_of_right.case(lambda v: v + 1, lambda v: v - 1) == 4
    # ap
    assert instance_of_left.ap(Right(lambda v: v - 1)).value == 5

# Generated at 2022-06-23 23:55:02.391421
# Unit test for constructor of class Left
def test_Left():
    assert Left(1.0) == Left(1.0)
    assert Left(1.0) != Right(1.0)



# Generated at 2022-06-23 23:55:06.402106
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:55:09.339578
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(None)
    right = Right(None)
    assert left.is_right() == False
    assert right.is_right() == True


# Generated at 2022-06-23 23:55:13.489068
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.func import compose
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy().map(lambda x: x * 2).value() == 20
    assert Left(10).to_lazy().map(lambda x: x * 2).value() == 10


# Generated at 2022-06-23 23:55:15.096297
# Unit test for method is_left of class Right
def test_Right_is_left():
    right_instance = Right(5)
    assert right_instance.is_left() is False


# Generated at 2022-06-23 23:55:18.863892
# Unit test for constructor of class Left
def test_Left():
    left = Left('value')

    assert left == Left('value')
    assert left != Left(1)
    assert left.value == 'value'
    assert left.case(lambda _: 'error!', lambda _: 'success!' ) == 'error!'



# Generated at 2022-06-23 23:55:23.393910
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    either = Left(1)
    assert either.to_maybe() == Maybe.nothing()
    assert either.to_try() == Try(1, is_success=False)
    assert either.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:55:25.280186
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    >>> Left('error').to_maybe().is_nothing
    True
    """


# Generated at 2022-06-23 23:55:27.944029
# Unit test for constructor of class Left
def test_Left():
    """Test Left constructor"""
    left = Left(True)

    assert isinstance(left, Either)
    assert isinstance(left, Left)
    assert not isinstance(left, Right)



# Generated at 2022-06-23 23:55:31.391995
# Unit test for method to_try of class Either
def test_Either_to_try():
    import pymonet.monad_try as Try

    assert Try.Success(2).to_either().to_try() == Try.Success(2)
    assert Try.Failure('some error').to_either().to_try() == Try.Failure('some error')


# Generated at 2022-06-23 23:55:36.492762
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)



# Generated at 2022-06-23 23:55:37.786384
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-23 23:55:38.361238
# Unit test for method ap of class Either
def test_Either_ap():
    pass

# Generated at 2022-06-23 23:55:39.638519
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(3).is_right() == False


# Generated at 2022-06-23 23:55:43.255158
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    a = Right(20)
    b = a.to_lazy()

    assert b.value() == 20
    # noinspection PyTypeChecker
    assert b != a



# Generated at 2022-06-23 23:55:47.101535
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(2)

    assert left == left
    assert right == right
    assert left != right
    assert right != left

    assert left != '1'
    assert right != '2'
    assert left != 1
    assert right != 2


# Generated at 2022-06-23 23:55:49.226905
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right("success").to_validation() == Validation.success("success")


# Generated at 2022-06-23 23:55:50.278892
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right('right').to_validation() == True


# Generated at 2022-06-23 23:55:52.344672
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(10).to_validation() == Validation.fail([10])



# Generated at 2022-06-23 23:55:55.456550
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    new_left = left.map(lambda a: a + 3)
    assert new_left.value == 1



# Generated at 2022-06-23 23:55:59.900959
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    GIVEN Right value
    WHEN to_validation is called
    THEN Either.to_validation should return successfull Validation with the same value
    """
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-23 23:56:01.853318
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(3).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:56:03.976857
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(13).bind(lambda v: Right(v)) == Left(13)



# Generated at 2022-06-23 23:56:07.774364
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)

    assert left == Left(1)
    assert right == Right(1)
    assert left != Right(1)
    assert left != "Left 1"
    assert left != 1


# Generated at 2022-06-23 23:56:08.970042
# Unit test for method is_left of class Left
def test_Left_is_left():
    instance = Left(10)
    assert isinstance(instance, Either)
    assert instance.is_left()


# Generated at 2022-06-23 23:56:10.309421
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('left')
    assert left.bind(lambda a: a) == left


# Generated at 2022-06-23 23:56:13.302180
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left('1')
    assert Left(1) != Right('1')


# Generated at 2022-06-23 23:56:13.987218
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-23 23:56:14.825174
# Unit test for constructor of class Either
def test_Either():
    pass



# Generated at 2022-06-23 23:56:17.375298
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation(Box(42)).ap(Left(Box(lambda x: x + 1))) == Validation.fail([43])


# Generated at 2022-06-23 23:56:20.258913
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-23 23:56:25.513650
# Unit test for constructor of class Left
def test_Left():
    left = Left('abc')
    assert left.value == 'abc'
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-23 23:56:30.929581
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation

    assert (Right(1).case(lambda x: Validation.fail(x), lambda x: Validation.success(x + 1)).match(
        success=lambda v: v,
        fail=lambda e: e
    )) == 2

    assert (Left(1).case(lambda x: Validation.fail([x]), lambda x: Validation.success(x + 1)).match(
        success=lambda v: v,
        fail=lambda e: e
    )) == [1]


# Generated at 2022-06-23 23:56:32.866221
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)
    assert Right("A").to_validation() == Validation.success("A")
    assert Right(True).to_validation() == Validation.success(True)


# Generated at 2022-06-23 23:56:35.508087
# Unit test for constructor of class Either
def test_Either():
    left = Left('err')
    right = Right("hello")
    assert left.value == "err"
    assert right.value == "hello"


# Generated at 2022-06-23 23:56:45.243631
# Unit test for method bind of class Right
def test_Right_bind():
    """Test method bind of the class Right."""
    assert Right(1).bind(lambda x: Right(x)) == Right(1)
    assert Right(1).bind(lambda x: x) == 1
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)

# Generated at 2022-06-23 23:56:46.382704
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda value: value.capitalize()) == Left('error')


# Generated at 2022-06-23 23:56:50.232138
# Unit test for method ap of class Either
def test_Either_ap():
    left = Left(lambda x, y: x + y)
    right = Right(lambda x, y: x * y)

    assert left.ap(Right(2)).ap(Right(9)) == Left(lambda x, y: x + y)
    assert right.ap(Right(2)).ap(Right(9)) == Right(18)

# Generated at 2022-06-23 23:56:53.408092
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    a = Left(1)
    assert a.ap(Try(1, is_success=True)) == Left(1)
    assert a.ap(Try(1, is_success=False)) == Left(1)
    assert a.ap(Box(1)) == Left(1)


# Generated at 2022-06-23 23:56:55.289312
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Either(0), Either), 'Either is abstract class, cannot be instantiated'


# Generated at 2022-06-23 23:57:00.004858
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:57:01.775033
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x * 2) == Right(2)


# Generated at 2022-06-23 23:57:06.002181
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass

# Generated at 2022-06-23 23:57:18.116660
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Create new Either, then apply function in other Either to it and checks result.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    function1 = lambda x: x + 5
    function2 = lambda x: x + 2
    function3 = lambda x: x + 1

    assert isinstance(Right(1).ap(Right(function1)), Right)
    assert isinstance(Left(2).ap(Right(function1)), Left)
    assert isinstance(Right(1).ap(Left(function1)), Left)

# Generated at 2022-06-23 23:57:22.892126
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("string").to_lazy() == Lazy(lambda: "string")
    assert Right("string").to_lazy() == Lazy(lambda: "string")



# Generated at 2022-06-23 23:57:25.541751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(True).to_lazy() == Lazy(lambda: True)
    assert Right(False).to_lazy() == Lazy(lambda: False)

# Generated at 2022-06-23 23:57:31.199331
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    def validator(value: int) -> Validation[List[str], int]:
        if not value % 2:
            return Validation.success(value)
        return Validation.fail(["The given value {} is not even".format(value)])

    result = validator(3)   # Validation[["The given value 3 is not even"], None]

    result2 = result.to_validation()  # Validation[["The given value 3 is not even"], None]

    assert result == result2



# Generated at 2022-06-23 23:57:33.684861
# Unit test for constructor of class Right
def test_Right():
    right = Right('a')
    assert right.is_right()
    assert right.value == 'a'



# Generated at 2022-06-23 23:57:36.146598
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:57:38.818351
# Unit test for method map of class Left
def test_Left_map():
    # Init
    left = Left(5)

    # Act
    result = left.map(lambda x: x ** 2)

    # Assert
    assert result == left

# Generated at 2022-06-23 23:57:42.054893
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    obj1 = Left(4)
    obj2 = obj1.to_validation()
    assert obj2 == Validation.fail([4])



# Generated at 2022-06-23 23:57:43.789611
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.just(1) == Right(1).to_maybe()



# Generated at 2022-06-23 23:57:45.734955
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda value: value, lambda value: value**2) == 1
    assert Left(1).case(lambda value: value, lambda value: value**2) == 1

# Generated at 2022-06-23 23:57:47.624871
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() == False
    assert Right(None).is_right() == True

# Generated at 2022-06-23 23:57:53.908711
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import lazy
    import unittest

    class EitherTestCase(unittest.TestCase):

        def test_to_lazy(self):
            self.assertEqual(Right(42).to_lazy(), lazy.Lazy(lambda: 42))

    return unittest.main()


# Generated at 2022-06-23 23:57:55.757195
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == Validation.fail(['error'])


# Generated at 2022-06-23 23:58:02.348229
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Right(5).to_validation() == Validation.success(5)
    assert Right(5).to_validation().case(lambda x: x[0], lambda x: x) == 5


# Generated at 2022-06-23 23:58:08.259677
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert isinstance(Right(2).to_validation(), Validation)
    assert Right(2).to_validation().is_success()
    assert Right(2).to_validation().get_value_or_error() == 2
    assert Right(Right(2)).to_validation().get_value_or_error() == Right(2)
    assert Right(Left(2)).to_validation().get_value_or_error() == [2]
    assert Right(Maybe.just(2)).to_validation().get_value_or_error() == 2
    assert Right(Maybe.nothing()).to_validation().get_value_or_error() == []

# Generated at 2022-06-23 23:58:12.212417
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test method bind in class Right

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe

    def f(value):
        return Maybe.just(value)

    assert Right(2).bind(f) == Maybe.just(2)


# Generated at 2022-06-23 23:58:16.644981
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    result = Left(RuntimeError()).to_try()
    assert isinstance(result, Try) and result.is_failure()
    result = Right(42).to_try()
    assert isinstance(result, Try) and result.is_success()


# Generated at 2022-06-23 23:58:18.698663
# Unit test for constructor of class Either
def test_Either():
    right = Right(5)
    left = Left(5)
    assert right.to_maybe().value == 5
    assert left.to_validation().error == [5]

# Generated at 2022-06-23 23:58:19.432783
# Unit test for method is_left of class Right
def test_Right_is_left():
    # This should be return False
    Right('test').is_left()



# Generated at 2022-06-23 23:58:20.836316
# Unit test for method bind of class Left
def test_Left_bind():
    assert isinstance(Left(1).bind(lambda x: Right(x)), Left)
    assert Left(1).bind(lambda x: Right(x)) == Left(1)


# Generated at 2022-06-23 23:58:26.910953
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x)).value == 1
    assert Left(None).bind(lambda x: Right(x)).value is None
    assert Left("Something").bind(lambda x: Left(x)).value == "Something"
    assert Left(1).bind(lambda x: Left(x)).value == 1


# Generated at 2022-06-23 23:58:31.617783
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either.to_lazy()
    Returns Lazy with function returning previous value

    :returns: None
    :rtype: None
    """
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-23 23:58:38.713890
# Unit test for method ap of class Either
def test_Either_ap():
    def f(x): return x

    assert Right(1).ap(Right(f)) == Right(1)
    assert Right(f).ap(Right(1)) == Right(1)
    assert Right(2).ap(Left("error")) == Left("error")
    assert Left("error").ap(Right(2)) == Left("error")
    assert Left("error1").ap(Left("error2")) == Left("error1")


# Generated at 2022-06-23 23:58:46.959521
# Unit test for method ap of class Either
def test_Either_ap():
    def addMapper(a):
        def add(b):
            return a + b
        return add

    def subMapper(a):
        def sub(b):
            return b - a
        return sub

    left = Left(1)
    right = Right(1)
    add = Right(addMapper)
    sub = Right(subMapper)
    assert (left.ap(add) == Left(1))
    assert (left.ap(sub) == Left(1))
    assert (right.ap(add) == Right(2))
    assert (right.ap(sub) == Right(0))


# Generated at 2022-06-23 23:58:51.273202
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() is False



# Generated at 2022-06-23 23:58:53.128832
# Unit test for method bind of class Left
def test_Left_bind():
    actual = Left(10)
    expected = Left(10)

    assert expected == actual.bind(lambda x: Right(21))



# Generated at 2022-06-23 23:58:56.161086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Lazy(lambda: Left(1).to_lazy().value())
    assert Lazy(lambda: 1) == Lazy(lambda: Right(1).to_lazy().value())



# Generated at 2022-06-23 23:58:59.447489
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x * 2).ap(Right(4)) == Right(8)
    assert Left(1).ap(Right(2)) == Left(1)
    assert Left(1).ap(Left(2)) == Left(1)
    assert Right(lambda x: x * 2).ap(Left(2)) == Left(2)

# Generated at 2022-06-23 23:59:02.642638
# Unit test for method bind of class Right
def test_Right_bind():
    test_value = 10
    success_function = lambda value: Right(value + 1)
    error_function = lambda value: Left(value + 1)
    right_instance = Right(test_value)
    assert right_instance.bind(success_function)\
        == Success(test_value + 1)
    assert right_instance.bind(error_function)\
        == Right(test_value)


# Generated at 2022-06-23 23:59:07.202027
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Just, Nothing
    assert Right(1).to_maybe() == Just(1)


# Generated at 2022-06-23 23:59:09.024474
# Unit test for method bind of class Right
def test_Right_bind():
    def add(x):
        return Right(x + 2)

    assert Right(2).bind(add) == Right(4)


# Generated at 2022-06-23 23:59:15.220910
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    new_right = right.map(lambda x: x + 1)
    assert isinstance(new_right, Right)
    assert new_right.value == 2


# Generated at 2022-06-23 23:59:16.763463
# Unit test for constructor of class Left
def test_Left():
    assert Left("A") == Left("A")



# Generated at 2022-06-23 23:59:19.497853
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.to_try(Either.Left(Exception())) == Try.fail(Exception())
    assert Either.to_try(Either.Right(1)) == Try.success(1)

# Generated at 2022-06-23 23:59:21.653398
# Unit test for method bind of class Left
def test_Left_bind():
    number = Left(1)
    assert number.bind(lambda value: number) == number


# Generated at 2022-06-23 23:59:23.377214
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(3).ap(Left(3)) == Left(3)


# Generated at 2022-06-23 23:59:28.596098
# Unit test for constructor of class Right
def test_Right():
    assert Right("Hi") == Right("Hi")
    assert not Right("Hi") == Right("Bye")
    assert not Right("Hi") == Right("None")
    assert not Right("Hi") == Right("2")
    assert Right("Hi") == Right("Hi")
    assert Right("Hi") == Right("Hi")

# Generated at 2022-06-23 23:59:31.193761
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(10)
    assert left.to_maybe().is_nothing()
    assert left.to_maybe().value is None


# Generated at 2022-06-23 23:59:33.943769
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    # Given
    right_value = Right(10)
    # When
    maybe_instance = right_value.to_maybe()
    # Then
    assert maybe_instance.get() == right_value.value


# Generated at 2022-06-23 23:59:36.723341
# Unit test for method is_left of class Right
def test_Right_is_left():
    @given(integers(), integers())
    def should_be_false(a: int, b: int):
        assert Right(a + b).is_left() is False



# Generated at 2022-06-23 23:59:38.042441
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda x: x + 2) == Right(5)



# Generated at 2022-06-23 23:59:44.691947
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert \
        Left("It's left value").to_box() == Box("It's left value") and \
        Right("It's right value").to_box() == Box("It's right value")



# Generated at 2022-06-23 23:59:49.814031
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_maybe import Maybe
    from pymonet.tools import add
    assert Right(3).bind(
        lambda value: Maybe.just(value + 2)
    ) == Maybe.just(5)



# Generated at 2022-06-23 23:59:51.976150
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert(Maybe.just(1) == Right(1).to_maybe())


# Generated at 2022-06-24 00:00:04.111799
# Unit test for method case of class Either
def test_Either_case():
    def test_case(value: Any, test: Any, success: Any) -> Any:
        """
        Take value and test function and return the result of call test function with value.
        If test function return true return success otherwise return value.

        :param value: value that must be tested
        :type value: A
        :param test: function test to call with value
        :type test: Function(A) -> B
        :param success: value to return if test return True
        :type success: B
        :returns: result of test function when he return True, value otherwise
        :rtype: B or A
        """
        if test(value):
            return success
        return value

    value = 'test'
    test = lambda x: x == 'test'
    success = 'True'

# Generated at 2022-06-24 00:00:08.880873
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Arrange
    expected_result = Validation.fail([1])

    # Act
    result = Left(1).to_validation()

    # Assert
    assert expected_result == result


# Generated at 2022-06-24 00:00:10.171994
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)



# Generated at 2022-06-24 00:00:11.793443
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    x = Left(None)
    assert x.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:00:16.113033
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe() == Maybe.just(2)
    assert Right(None).to_maybe() == Maybe.just(None)
    assert Right(True).to_maybe() == Maybe.just(True)
    assert Right([]).to_maybe() == Maybe.just([])
    assert Right({}).to_maybe() == Maybe.just({})
    

# Generated at 2022-06-24 00:00:17.687056
# Unit test for method map of class Left
def test_Left_map():
    left_value = Left(1)
    left_mapped = left_value.map(lambda x: x + 1)
    assert left_value == left_mapped



# Generated at 2022-06-24 00:00:20.122376
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """Unit test for method to_validation of class Right"""
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:00:25.541413
# Unit test for method is_left of class Right
def test_Right_is_left():
    """
    If method is_right is false then is_left must be true
    """
    from pymonet.utils import assert_equal

    assert_equal(True, ~Right(1).is_right())



# Generated at 2022-06-24 00:00:28.022971
# Unit test for method is_left of class Left
def test_Left_is_left():
    """
    Test for method is_left of class Left.
    """
    from pymonet.monad_test import assert_success, assert_failure

    assert_success(Left(1).is_left)
    assert_failure(Left(1).is_left, False)



# Generated at 2022-06-24 00:00:33.741807
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet import Lazy
    def test():
        return Lazy(lambda: 1)

    left = Left(1)
    assert left.ap(test()) == left

# Generated at 2022-06-24 00:00:37.124210
# Unit test for constructor of class Either
def test_Either():
    assert type(Right(3).value) == int
    assert type(Left(3).value) == int



# Generated at 2022-06-24 00:00:47.894165
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(2) != Right(2)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)

    maybe = Maybe.just(1)
    assert maybe != Left(1)

    maybe_2 = Maybe.nothing()
    assert maybe_2 != Right(None)

    lazy = Lazy(lambda: 1)
    assert lazy != Left(1)
    assert lazy != Right(1)

    box = Box(1)
    assert box != Left(1)
    assert box != Right(1)

    tryy = Try(1, is_success=True)
    assert tryy != Left(1)
    assert tryy != Right(1)


# Generated at 2022-06-24 00:00:58.020747
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left1 = Left(1)
    left2 = Left(1)
    right1 = Right(1)
    right2 = Right(1)

    # When
    is_equal_left1_left2 = left1 == left2
    is_equal_right1_right2 = right1 == right2
    is_equal_left1_right1 = left1 == right1
    is_equal_left1_right2 = left1 == right2
    is_equal_right1_left1 = right1 == left1
    is_equal_right2_left1 = right2 == left1

    # Then
    assert is_equal_left1_left2 is True
    assert is_equal_right1_right2 is True
    assert is_equal_left1_right1 is False
    assert is_equal_left

# Generated at 2022-06-24 00:01:04.932071
# Unit test for method map of class Left
def test_Left_map():
    # assert (Left(3).map(lambda x: x+1) == Left(3))
    assert (Left(3).map(lambda x: x+1).case(lambda a: a+1, lambda b: b+1) == 4)
    assert (Left(3).to_box().case(lambda x: x, lambda x: x) == 3)
    assert (Left(3).to_try().case(lambda x: x, lambda x: x) == 3)
    assert (Left(3).to_lazy().case(lambda x: x, lambda x: x)() == 3)



# Generated at 2022-06-24 00:01:06.283900
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e1 = Either(lambda: 10)

    assert e1.to_lazy().force() == 10

# Generated at 2022-06-24 00:01:09.812900
# Unit test for constructor of class Either
def test_Either():
    assert Left('asdf').case(lambda x: x, lambda x: x) == 'asdf'
    assert Right('qwerty').case(lambda x: x, lambda x: x) == 'qwerty'



# Generated at 2022-06-24 00:01:17.270947
# Unit test for method ap of class Either
def test_Either_ap():
    # Create a class with method map
    class Foo:
        def map(self, mapper):
            return mapper(self.value)

    class Bar(Foo):
        def __init__(self, value):
            self.value = value

    foo1 = Foo()
    foo1.value = 1
    foo2 = Bar(2)
    foo3 = Bar(3)

    foo1_result = Right(foo1).ap(Right(lambda x: x + 10))
    assert foo1_result == Right(11)

    foo2_result = Right(foo2).ap(Right(lambda x: x + 10))
    assert foo2_result == Right(12)

    foo3_result = Right(foo3).ap(Right(lambda x: x + 10))
    assert foo3_result == Right(13)

   

# Generated at 2022-06-24 00:01:19.157467
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left('')
    box = left.ap(Box(lambda v: v.capitalize()))

    assert box.value == ''


# Generated at 2022-06-24 00:01:26.094768
# Unit test for method to_try of class Either
def test_Either_to_try():
    def return_1_or_2(value):
        if value % 2 == 0:
            return Left(value)
        else:
            return Right(value)

    assert return_1_or_2(2).to_try().is_success() is False
    assert return_1_or_2(2).to_try().get_or_else('error') == 'error'
    assert return_1_or_2(2).to_try().get_or_raise() == 2

    assert return_1_or_2(3).to_try().is_success() is True
    assert return_1_or_2(3).to_try().get_or_else('error') == 3
    assert return_1_or_2(3).to_try().get_or_raise() == 3

# Generated at 2022-06-24 00:01:32.680679
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    b_right = Either.unit(1).to_box()
    assert type(b_right) is Box
    assert b_right == Box(1)

    b_left = Left(1).to_box()
    assert type(b_left) is Box
    assert b_left == Box(1)



# Generated at 2022-06-24 00:01:36.054364
# Unit test for method to_try of class Either
def test_Either_to_try():
    from collections import namedtuple
    Point = namedtuple('Point', 'x y')
    test_data = [
        (Right(Point(x=1, y=2)), True),
        (Left('Error'), False)
    ]
    for test in test_data:
        assert test[0].to_try() == Try(test[0].value, is_success=test[1])



# Generated at 2022-06-24 00:01:37.862457
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right("test").to_maybe() == Maybe("test")



# Generated at 2022-06-24 00:01:39.433562
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True


# Generated at 2022-06-24 00:01:40.554425
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(2)) == Left(1)



# Generated at 2022-06-24 00:01:43.050749
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)


# Generated at 2022-06-24 00:01:44.674140
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    right = Right("test")
    assert right.to_validation() == Validation.success("test")



# Generated at 2022-06-24 00:01:47.461675
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    left = Left(1)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:01:48.897313
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(True).is_left() == False


# Generated at 2022-06-24 00:01:51.011770
# Unit test for constructor of class Right
def test_Right():
    assert Either(1) == Either(1)
    assert Either(0) == Either(0)


# Generated at 2022-06-24 00:01:52.488299
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-24 00:01:58.644541
# Unit test for method case of class Either
def test_Either_case():
    """Test Either.case method."""

    def error(value: str) -> str:
        return "error: {}".format(value)

    def success(value: str) -> str:
        return "success: {}".format(value)

    assert Left("error").case(error, success) == "error: error"
    assert Right("success").case(error, success) == "success: success"



# Generated at 2022-06-24 00:02:00.456235
# Unit test for method is_right of class Right
def test_Right_is_right():
    left = Right('Hello')

    assert left.is_right() is True


# Generated at 2022-06-24 00:02:02.051865
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(8).is_left()


# Generated at 2022-06-24 00:02:04.374037
# Unit test for method bind of class Left
def test_Left_bind():
    """
    :returns: True
    :rtype: Boolean
    """
    assert Left(1).bind(lambda v: Right(v)) == Left(1)



# Generated at 2022-06-24 00:02:07.825269
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.functions import identity

    assert Right(True).to_try() == Try(True)
    assert Left(True).to_try() == Try(True, False)

# Generated at 2022-06-24 00:02:09.334203
# Unit test for method is_left of class Right
def test_Right_is_left():
    # Arrange
    # Act
    result = Right(1).is_left()
    # Assert
    assert not result


# Generated at 2022-06-24 00:02:15.670358
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try().value == 1 and\
        Either(1).to_try().is_success == True and\
        Either(1).to_try().is_exception == False and\
        Either(Exception()).to_try().value == Exception() and\
        Either(Exception()).to_try().is_success == False and\
        Either(Exception()).to_try().is_exception == True

# Generated at 2022-06-24 00:02:20.461240
# Unit test for method bind of class Left
def test_Left_bind():
    """
    Unit test for method bind of class Left.
    """
    from pymonet.maybe import Maybe

    assert Left('left') == Left('left').bind(lambda x: Maybe(x))
    assert Left('left') == Left('left').bind(lambda x: Right(x))
    assert Left('left') == Left('left').bind(lambda x: Left(x))



# Generated at 2022-06-24 00:02:22.607560
# Unit test for method bind of class Left
def test_Left_bind():
    """
    Test bind method of Left
    """
    assert Left(5).bind(lambda x: x+2) == 5



# Generated at 2022-06-24 00:02:23.866203
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-24 00:02:25.409895
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(5).to_validation() == Validation.fail([5])


# Generated at 2022-06-24 00:02:27.284424
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)


# Generated at 2022-06-24 00:02:35.924164
# Unit test for method case of class Either
def test_Either_case():
    """
    Test for case method of Either

    :returns: None
    :rtype: No return
    """
    assert Right(1).case(lambda error: error, lambda success: success) == 1
    assert Left(1).case(lambda error: error, lambda success: success) == 1
    assert Right(1).case(lambda success: success + 1, lambda error: error) == 1
    assert Left(1).case(lambda success: success + 1, lambda error: error) == 1



# Generated at 2022-06-24 00:02:43.435547
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # When create Either object
    either = Right(2)
    # And take result of to_lazy method
    actual = either.to_lazy()
    # Then result must be Lazy[Function() -> A]
    from pymonet.lazy import Lazy

    assert type(actual) == Lazy
    assert actual.value() == 2


# Generated at 2022-06-24 00:02:47.136510
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(None).to_try() == Try(None, is_success=True)
    assert Either('something').to_try() == Try('something', is_success=True)
    assert Either({'a': 1, 'b': 2}).to_try() == Try({'a': 1, 'b': 2}, is_success=True)


# Generated at 2022-06-24 00:02:48.722873
# Unit test for constructor of class Left
def test_Left():
    assert Left(3) == Left(3)
    assert isinstance(Left(3), Either)
    assert isinstance(Left(3), Left)



# Generated at 2022-06-24 00:02:51.229482
# Unit test for method map of class Left
def test_Left_map():
    left = Either(1)
    assert left.map(lambda x: x + 1) == Either(1)



# Generated at 2022-06-24 00:02:53.620815
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert (Right(5).to_lazy() == Lazy(lambda: 5))
    assert (Left(5).to_lazy() == Lazy(lambda: 5))

# Generated at 2022-06-24 00:02:57.381476
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)


# Generated at 2022-06-24 00:03:00.064374
# Unit test for constructor of class Either
def test_Either():
    """
    >>> assert Either(5).value == 5
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 00:03:01.284252
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Either.unit(x + 1)) == Right(2), Right(2)


# Generated at 2022-06-24 00:03:07.871635
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    >>> test_Either_to_try()
    1
    """
    from pymonet.monad_try import Try

    try_succcess = Right(1).to_try()
    try_failure = Left(1).to_try()

    assert try_succcess == Try(1, is_success=True)
    assert try_failure == Try(1, is_success=False)

    print(try_succcess.value)



# Generated at 2022-06-24 00:03:09.650112
# Unit test for constructor of class Either
def test_Either():
    assert(Left(1) == Left(1))
    assert(Left(1) != Right(1))
    assert(Left(1) != Either(1))



# Generated at 2022-06-24 00:03:11.763699
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:03:13.316394
# Unit test for constructor of class Right
def test_Right():
    right = Right(5)
    assert right.value == right.bind(lambda x: x)



# Generated at 2022-06-24 00:03:14.752115
# Unit test for method map of class Right
def test_Right_map():
    assert Right(5).map(lambda val: val + 1) == Right(6)


# Generated at 2022-06-24 00:03:20.033642
# Unit test for constructor of class Either
def test_Either():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Left(Box.nothing()) == Left(Box.nothing())
    assert Right(Box.just(42)) == Right(Box.just(42))
    assert Left(Box.nothing()) != Right(Box.just(42))
    assert Left(Box.just(42)) != Right(Box.just(42))
    assert Left(Box.just(42)) != Left(Box.just('42'))
    assert Right(Box.just(42)) != Right(Box.just('42'))
    assert Left(Box.nothing()) != Right(Box.nothing())



# Generated at 2022-06-24 00:03:21.363109
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left('left')
    assert left.ap(None) == left

# Generated at 2022-06-24 00:03:26.055159
# Unit test for method map of class Left
def test_Left_map():
    left = Left(10).map(lambda a: a + 10)
    assert left.is_left()
    assert left.value == 10
    assert left == Left(10)


# Generated at 2022-06-24 00:03:29.182479
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(451).to_lazy() == Lazy(lambda: 451)
    assert Left(451).to_lazy() == Lazy(lambda: 451)


# Generated at 2022-06-24 00:03:34.021524
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation

    # when
    actual = Validation.success('text').to_either().case(lambda t: Validation.fail(''), lambda t: Validation.success(5)).resolve()

    # then
    assert actual == 5, "Error during case of Either method test"

# Generated at 2022-06-24 00:03:36.138531
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    assert left.ap(Left(3)) == Left(1)



# Generated at 2022-06-24 00:03:38.154261
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(4).is_right() == True
    assert Left(4).is_right() == False



# Generated at 2022-06-24 00:03:40.339150
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:03:43.256716
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(1)

    # When
    result = left.bind(lambda x: Left(x))

    # Then
    assert(result == left)



# Generated at 2022-06-24 00:03:50.653015
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    assert Left(1).ap(Box(2)) == Left(1)
    assert Left(1).ap(Box(lambda x: x + 2)) == Left(1)
    assert Right(1).ap(Box(2)) == Right(2)
    assert Right(1).ap(Box(lambda x: x + 2)) == Right(3)