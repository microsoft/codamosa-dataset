

# Generated at 2022-06-23 23:53:49.049510
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(3).is_left() is False



# Generated at 2022-06-23 23:53:56.523045
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result1 = Left(123).to_lazy()
    result2 = Right(123).to_lazy()

    assert isinstance(result1, Lazy)
    assert isinstance(result2, Lazy)
    assert result1.eval() == 123
    assert result2.eval() == 123



# Generated at 2022-06-23 23:53:59.457808
# Unit test for constructor of class Right
def test_Right():
    right = Either.right(1337)
    left = Either.left(42)

    assert right.value == 1337
    assert not right.is_left()
    assert left.value == 42
    assert left.is_left()



# Generated at 2022-06-23 23:54:02.186769
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)


# Generated at 2022-06-23 23:54:09.436645
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    maybe_int = Left("Not a integer")
    result = maybe_int.bind(lambda s: int(s))
    error_result = maybe_int.case(Functor.identity,
                                  Applicative.constant("Not a integer"))

    assert(result == maybe_int)
    assert(error_result == maybe_int.value)


# Generated at 2022-06-23 23:54:10.735402
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left("fail").bind(lambda value: value) == "fail"


# Generated at 2022-06-23 23:54:16.945593
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x).value == 1
    assert Left([1, 2, 3]).map(lambda x: x).value == [1, 2, 3]
    assert Left({'a': 1}).map(lambda x: x).value == {'a': 1}
    assert Left('test').map(lambda x: x).value == 'test'


# Generated at 2022-06-23 23:54:19.318905
# Unit test for method to_try of class Either
def test_Either_to_try():
    # given
    either = Either(1)

    # when
    result = either.to_try()

    # then
    assert None is None

# Generated at 2022-06-23 23:54:25.237163
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('').is_right() is False


# Generated at 2022-06-23 23:54:30.175451
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    a = Either.Left(1)
    assert a.ap(Box(lambda x: x + 1)) == Either.Left(1)

    a = Either.Right(1)
    assert a.ap(Box(lambda x: x + 1)) == Either.Right(2)



# Generated at 2022-06-23 23:54:34.571894
# Unit test for constructor of class Right
def test_Right():
    # Given
    right = 'right'
    # When
    result = Right(right)
    # Then
    assert isinstance(result, Right)
    assert result.value == right
    assert result.is_right() is True
    assert result.is_left() is False



# Generated at 2022-06-23 23:54:36.941742
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(2)
    assert not left.is_right()



# Generated at 2022-06-23 23:54:39.826795
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.monad_try import Try

    assert Try(1).is_right() == True
    assert Try(1, is_success=False).is_right() == False


# Generated at 2022-06-23 23:54:46.037710
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation
    from pymonet.box import Box

    def error_handler(error: str) -> Validation:
        return Validation.fail([error])

    def success_handler(success: str) -> Validation:
        return Validation.success(success)

    assert Left('error').case(error_handler, success_handler) == Validation.fail(['error'])
    assert Right('success').case(error_handler, success_handler) == Validation.success('success')
    assert Left('error').case(error_handler, success_handler).unwrap_or(Box('default')) == 'default'
    assert Right('success').case(error_handler, success_handler).unwrap_or(Box('default')) == 'success'

# Generated at 2022-06-23 23:54:50.565703
# Unit test for constructor of class Left
def test_Left():
    # pylint: disable=C0103
    # pylint: disable=W0621
    assert Left(10).value == 10
    assert Left('test').value == 'test'
    assert Left(10.0).value == 10.0
    assert Left(10).value == 10
    assert Left([1, 2, 3]).value == [1, 2, 3]
    assert Left(['a', 'b', 'c']).value == ['a', 'b', 'c']



# Generated at 2022-06-23 23:54:53.724293
# Unit test for method map of class Left
def test_Left_map():
    assert Left('message').map(lambda x: x.upper()) == Left('message')
    assert Left('message').map(lambda x: x.lower()) == Left('message')
    assert Left('message').map(lambda x: 'new_value') == Left('message')



# Generated at 2022-06-23 23:54:54.934738
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(0).is_right() == False


# Generated at 2022-06-23 23:55:02.151982
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Success, Fail
    from pymonet.monad_try import Success as TrySuccess, Fail as TryFail

    # Box not implemented case method, so in this test we will verify only Either
    # But this test covers others monads because they inherit case method from Either
    result = Either(Just(Box(1))).case(lambda x: x * 2, lambda x: x + 3)
    assert result == 4, f"Expected: 4, Actual: {result}"

    result = Either(Nothing).case(lambda x: x * 2, lambda x: x + 3)
    assert result == 6, f"Expected: 6, Actual: {result}"


# Generated at 2022-06-23 23:55:07.793140
# Unit test for method case of class Either
def test_Either_case():
    def should_return_result_of_right():
        result = Either.case(
            Left('Error'),  # noqa
            lambda x: x.upper()
        )
        assert result == 'ERROR'

    def should_return_result_of_left():
        result = Either.case(
            Right('Success'),
            lambda x: x.upper()
        )
        assert result == 'Success'

    def should_return_result_of_left_because_it_is_left():
        result = Left('Error').case(
            lambda err: err.upper(),
            lambda succ: succ.upper()
        )
        assert result == 'ERROR'


# Generated at 2022-06-23 23:55:09.785539
# Unit test for method map of class Left
def test_Left_map():
    assert Left(10).map(lambda x: x+1) == Left(10)


# Generated at 2022-06-23 23:55:12.018241
# Unit test for method is_right of class Right
def test_Right_is_right():
    @Test
    def should_return_true_when_Value_is_not_left():
        assert Right(5).is_right()



# Generated at 2022-06-23 23:55:17.407522
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    left_box = Either(0).to_box()
    assert isinstance(left_box, Box)
    assert left_box.is_empty()
    assert not left_box.is_full()

    right_box = Either(1).to_box()
    assert isinstance(right_box, Box)
    assert not right_box.is_empty()
    assert right_box.is_full()


# Generated at 2022-06-23 23:55:21.093107
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> from pymonet.either import Right, Left
    >>> Right(2).case(error=lambda x: x+1, success=lambda x: x*2)
    4
    >>> Left(2).case(error=lambda x: x+1, success=lambda x: x*2)
    3
    """


# Generated at 2022-06-23 23:55:25.836127
# Unit test for method ap of class Left
def test_Left_ap():
    result = Left(lambda a: a + 1).ap(Left(2))
    assert result.is_left(), 'Function ap should return Left monad'



# Generated at 2022-06-23 23:55:30.377592
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Try.fail('').to_try() == Try.fail('')
    assert Try.success('').to_try() == Try.success('')
    assert Try(Lazy(lambda: '')).to_try() == Try.success('')

# Generated at 2022-06-23 23:55:31.601537
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-23 23:55:33.210889
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left("TestValue")
    assert left.is_right() is False


# Generated at 2022-06-23 23:55:36.071968
# Unit test for constructor of class Left
def test_Left():
    left = Left("second")
    assert left.case(lambda it: it, lambda it: it[0]) == "second"


# Generated at 2022-06-23 23:55:39.119296
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Unit test for method to_box of class Either"""
    from pymonet.box import Box

    assert Either(1).to_box() == Box(1)
    assert Either('a').to_box() == Box('a')



# Generated at 2022-06-23 23:55:40.106710
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(5).is_right() == False


# Generated at 2022-06-23 23:55:42.847118
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-23 23:55:47.642270
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-23 23:55:50.967049
# Unit test for method ap of class Left
def test_Left_ap():
    def function(any):
        return any

    assert Right(Left(0)).ap(Right(function)).value == Left(0)


# Generated at 2022-06-23 23:55:53.858838
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(value):
        return value + 10

    right = Right(1).bind(mapper)
    assert right.is_right()
    assert right.value == 11



# Generated at 2022-06-23 23:55:56.512928
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    right = Right(1)
    assert right.to_validation() == Validation.success(1)


# Generated at 2022-06-23 23:55:58.761101
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either[int](1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-23 23:56:02.294216
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(0).is_right() == True
    assert Left(0).is_right() == False


# Generated at 2022-06-23 23:56:09.224454
# Unit test for method map of class Right
def test_Right_map():
    def sqr(value):
        return pow(value, 2)

    right = Right(1)
    right_mapped = right.map(sqr)
    assert right_mapped == Right(1)
    assert right_mapped.value == 1

    right = Right(2)
    right_mapped = right.map(sqr)
    assert right_mapped == Right(4)
    assert right_mapped.value == 4



# Generated at 2022-06-23 23:56:11.628886
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)



# Generated at 2022-06-23 23:56:12.549865
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Either(1).is_right(), bool)



# Generated at 2022-06-23 23:56:13.467764
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('error').is_right()


# Generated at 2022-06-23 23:56:14.833409
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-23 23:56:19.144376
# Unit test for method bind of class Left
def test_Left_bind():
    def remove_if_less_than_eight(value: int) -> Either[None, int]:
        if value < 8:
            return Left(None)
        return Right(value)

    assert Left(None).bind(remove_if_less_than_eight) == Left(None)
    assert Left(None).bind(remove_if_less_than_eight).is_left()
    assert Left(None).bind(remove_if_less_than_eight) != Right(None)


# Generated at 2022-06-23 23:56:24.951367
# Unit test for method ap of class Either
def test_Either_ap():
    either1 = Right(lambda n: n ** n)
    either2 = Right(2)
    assert either1.ap(either2) == Right(4)



# Generated at 2022-06-23 23:56:28.724971
# Unit test for method map of class Right
def test_Right_map():
    assert Right(10).map(lambda value: value + 10).value == 20
    assert Right(10).map(lambda value: value - 10).value == 0
    assert Right(10).map(lambda value: value * 10).value == 100
    assert Right("test").map(lambda value: value + "test").value == "testtest"



# Generated at 2022-06-23 23:56:29.824180
# Unit test for method is_left of class Right
def test_Right_is_left():
    Right(99).is_left() == False


# Generated at 2022-06-23 23:56:31.120076
# Unit test for method is_left of class Right
def test_Right_is_left():
    a = Right(1)

    assert a.is_left() == False



# Generated at 2022-06-23 23:56:31.930089
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert isinstance(Right(1).is_right(), bool)



# Generated at 2022-06-23 23:56:34.810691
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Unit test for method to_try of class Either.

    :returns: nothing
    :rtype: None
    """
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-23 23:56:38.692570
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-23 23:56:41.859023
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert not Right(1) != Right(1)
    assert Right(1) != Right(2)
    assert not Right(1) == Right(2)



# Generated at 2022-06-23 23:56:47.137698
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-23 23:56:52.275676
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert isinstance(Left(1).to_try(), Try)
    assert isinstance(Right(1).to_try(), Try)
    assert type(Left(1).to_try().value) is int
    assert type(Right(1).to_try().value) is int
    assert Left(1).to_try().value == 1
    assert Right(1).to_try().value == 1
    assert Left(1).to_try().is_success is False
    assert Right(1).to_try().is_success is True


# Generated at 2022-06-23 23:56:55.487167
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Test transform Right to Validation is successed validation
    """

    validation = Right('value').to_validation()
    assert validation.is_success
    assert 'value' == validation.value



# Generated at 2022-06-23 23:57:00.640360
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda x: x + 1) == Left(1) and left.value == 1



# Generated at 2022-06-23 23:57:11.722350
# Unit test for method case of class Either
def test_Either_case():
    """ Unit test for method case of class Either"""
    def wrap_left(value):
        return Left(value)

    def wrap_right(value):
        return Right(value)

    def error(value):
        return value + '!'

    def success(value):
        return value + '?'

    eq_(Right(0).case(error, success), '0?')
    eq_(Left(0).case(error, success), '0!')
    eq_(Left('foo').map(wrap_left).case(error, success), 'foo!')
    eq_(Right('foo').map(wrap_left).case(error, success), 'foo!')
    eq_(Right('foo').map(wrap_right).case(error, success), 'foo?')

# Generated at 2022-06-23 23:57:15.056597
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)


# Generated at 2022-06-23 23:57:16.218101
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right() is True


# Generated at 2022-06-23 23:57:16.796600
# Unit test for constructor of class Either
def test_Either():
    assert Left(1).value == 1



# Generated at 2022-06-23 23:57:22.474337
# Unit test for constructor of class Right
def test_Right():
    container = Right('x')

    assert container.value == 'x',\
        'expected Right(x) but got ' + str(container)


# Generated at 2022-06-23 23:57:23.418198
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:57:27.648171
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_instance_factory import MonadInstanceFactory

    assert Left(10).to_validation() ==\
        Validation.fail([10]) ==\
        MonadInstanceFactory.create(10).to_validation()


# Generated at 2022-06-23 23:57:29.205739
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(3).to_validation() == Validation.fail([3])



# Generated at 2022-06-23 23:57:30.940538
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)


# Generated at 2022-06-23 23:57:32.468240
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left()
    assert not Left(5).is_right()


# Generated at 2022-06-23 23:57:37.594613
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """Test that to_maybe method of Right transform it to Maybe monad."""
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Maybe.just(5) == Right(5).to_maybe()

# Generated at 2022-06-23 23:57:38.666390
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None



# Generated at 2022-06-23 23:57:45.882631
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    def id_function(value):
        return value

    def add(value, value2):
        return value + value2

    assert Either(id_function).ap(Either("value")) == Either("value")
    assert Either(add).ap(Either("value")).ap(Either("value2")) == Either("valuevalue2")
    assert Either(add).ap(Either("value")).ap(Box("value2")) == Either("valuevalue2")
    assert Either(add).ap(Box("value")).ap(Either("value2")) == Either("valuevalue2")
    assert Either(add).ap(Box("value")).ap(Box("value2")) == Either("valuevalue2")

# Generated at 2022-06-23 23:57:48.282812
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.either import Left

    assert Left('error').ap(Box(lambda x: x)) == Left('error')


# Generated at 2022-06-23 23:57:52.911432
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    mapper = lambda x: Either.left('X')
    left = Either.left('A')

    # When
    result = left.bind(mapper)

    # Then
    assert result == left

# Generated at 2022-06-23 23:57:55.652108
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1, True)
    assert Left(1).to_try() == Try(1, False)


# Generated at 2022-06-23 23:57:56.226782
# Unit test for method ap of class Either
def test_Either_ap():
    pass



# Generated at 2022-06-23 23:57:59.651117
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x * 2).value == 1
    assert Right(1).map(lambda x: x * 2).value == 2


# Generated at 2022-06-23 23:58:02.977514
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1) and Right(1) == Right(1) and Left(1) == Left(2) and Right(1) == Right(2)
    assert Left(1) != Right(1)


# Generated at 2022-06-23 23:58:05.320910
# Unit test for method to_box of class Either
def test_Either_to_box():
    # given
    either = Either(5)

    # when
    result = either.to_box()

    # then
    assert result.to_string() == 'Box(5)'


# Generated at 2022-06-23 23:58:08.448179
# Unit test for constructor of class Left
def test_Left():
    left = Left('lhs')

    assert left.value == 'lhs'
    assert left.is_left()
    assert not left.is_right()



# Generated at 2022-06-23 23:58:10.900763
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().force() == 5
    assert Left(5).to_lazy().force() == 5


# Generated at 2022-06-23 23:58:15.697279
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(2)
    assert left == Left(1)
    assert right == Right(2)
    assert left != Right(1)
    assert right != Left(2)



# Generated at 2022-06-23 23:58:22.341994
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Left(3).case(lambda x: x * 10, lambda x: x / 10) == 30
    assert Right(3).case(lambda x: x * 10, lambda x: x / 10) == 0.3

    assert Left(3.0).case(Box.just, lambda x: x / 10) == Box.just(3.0)
    assert Right(3.0).case(Box.just, lambda x: x / 10) == Box.just(0.3)

    assert Left(3.0).case(Try.fail, lambda x: x / 10) == Try.fail(3.0)

# Generated at 2022-06-23 23:58:23.565946
# Unit test for constructor of class Either
def test_Either():
    assert Either(1)



# Generated at 2022-06-23 23:58:26.717330
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False


# Generated at 2022-06-23 23:58:28.639015
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(3)
    assert(left.is_right() == False)


# Generated at 2022-06-23 23:58:30.492990
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() is False


# Generated at 2022-06-23 23:58:32.527049
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right('a').to_maybe().value == Maybe.just('a').value


# Generated at 2022-06-23 23:58:35.876166
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-23 23:58:40.068966
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3) == Right(3)
    assert Left(3) == Left(3)
    assert Left(3) != Right(3)
    assert Left(3) != Right(4)
    assert Left(3) != Right(3)
    assert Left(3.3) != Right(3)
    assert Left(None) == None



# Generated at 2022-06-23 23:58:42.998692
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda i: i + 1) == Left(1)
    assert Left(1).map(lambda i: i + 1).is_left()
    assert Left(1).map(lambda i: i + 1).value == 1


# Generated at 2022-06-23 23:58:44.492312
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False



# Generated at 2022-06-23 23:58:46.314227
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() is False


# Generated at 2022-06-23 23:58:51.525624
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda x: x + 2) == Right(5)



# Generated at 2022-06-23 23:58:53.046392
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda a: Right(a + 1)) == Right(2)



# Generated at 2022-06-23 23:58:57.013859
# Unit test for method bind of class Right
def test_Right_bind():
    """Test bind method"""
    print("\nRight.bind:")
    result = Right(5)

    def mapper(x: int) -> Right[int]:
        return Right(x * 2)

    print("assert result.bind(mapper) == Right(10)")
    assert result.bind(mapper) == Right(10)


# Generated at 2022-06-23 23:59:02.004654
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Try.success(1).ap(Box.of_function(lambda x: x + 1)) == Try.success(2)
    assert Left.of_value(1).ap(Box.of_function(lambda x: x + 1)) == Left.of_value(1)
    assert Right.of_value(1).ap(Box.of_function(lambda x: x + 1)) == Right.of_value(2)


# Generated at 2022-06-23 23:59:08.638021
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) != Left(5)
    assert Left(5) != Right(5)
    assert Left(5) != 5
    assert Right(5) == Right(5)
    assert Right(5) != Left(5)
    assert Right(5) != 5
    assert Left(5) == Left(5)



# Generated at 2022-06-23 23:59:09.939341
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-23 23:59:14.448790
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-23 23:59:18.291565
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    x = Right(10)
    assert x.is_right() is True
    assert x.is_left() is False
    assert x.to_maybe() == Maybe.just(10)



# Generated at 2022-06-23 23:59:20.170600
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    right = Right(5)
    # When
    result = right.bind(lambda x: Either.right(x + 2))
    # Then
    assert result == Right(7)


# Generated at 2022-06-23 23:59:24.252321
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(5).to_try() == Try(5, is_success=True)
    assert Left(5).to_try() == Try(5, is_success=False)

# Generated at 2022-06-23 23:59:29.801254
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Between(10, 20).is_left() is False
    assert Between(20, 10).is_left() is True
    assert Between(10, 10).is_left() is True



# Generated at 2022-06-23 23:59:33.257251
# Unit test for method bind of class Right
def test_Right_bind():
    def add_one(number):
        if number % 2 == 0:
            return Right(number + 1)
        return Left(number + 1)

    assert Right(2).bind(add_one) == Right(3)
    assert Right(1).bind(add_one) == Left(2)


# Generated at 2022-06-23 23:59:36.750988
# Unit test for method bind of class Left
def test_Left_bind():
    def odd(n):
        from pymonet.maybe import Maybe

        if n % 2 == 1:
            return Maybe.just(n)
        return Maybe.nothing()

    assert Left(1).bind(odd) == Left(1)
    assert Left(2).bind(odd) == Left(2)


# Generated at 2022-06-23 23:59:38.094018
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-23 23:59:45.630214
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either(1).to_box() == Either(1).case(lambda error: Box(error), lambda success: Box(success))
    assert Either("error").to_box() == Either("error").case(lambda error: Box(error), lambda success: Box(success))



# Generated at 2022-06-23 23:59:54.325370
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left('result')).case(
        error=lambda err: 'failure: {}'.format(err),
        success=lambda val: 'success: {}'.format(val)
    ) == 'failure: 1'
    assert Left(1).ap(Right('result')).case(
        error=lambda err: 'failure: {}'.format(err),
        success=lambda val: 'success: {}'.format(val)
    ) == 'failure: 1'



# Generated at 2022-06-23 23:59:56.606298
# Unit test for constructor of class Right
def test_Right():
    right = Right(42)
    assert right.value == 42


# Generated at 2022-06-23 23:59:57.806220
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('some value').is_right() is False



# Generated at 2022-06-23 23:59:59.626997
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() is True


# Generated at 2022-06-24 00:00:01.528089
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:00:04.415131
# Unit test for method bind of class Left
def test_Left_bind():
    a = Left(5)
    b = a.bind(lambda n: n * 2)
    assert isinstance(b, Left)
    assert b.value == 5



# Generated at 2022-06-24 00:00:06.297771
# Unit test for constructor of class Left
def test_Left():
    assert Left(10) == Left(10)
    assert Left(10) == Left(10)
    assert Left(10).is_left()
    assert not Left(10).is_right()



# Generated at 2022-06-24 00:00:10.611397
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    validation = Validation.success(1)
    e = Right(1)

    assert e.to_validation() == validation



# Generated at 2022-06-24 00:00:12.368373
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left('left')

    # When
    actual = left.bind(lambda x: x)

    # Then
    assert left is actual


# Generated at 2022-06-24 00:00:16.081643
# Unit test for method bind of class Left
def test_Left_bind():
    # GIVEN
    left = Left(1)
    mapper = lambda _: Right(2)

    # WHEN
    value = left.bind(mapper)

    # THEN
    assert isinstance(value, Left)
    assert value.value == 1
    assert value.is_left()


# Generated at 2022-06-24 00:00:19.307293
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)
    assert Left(Right(1)).to_box() == Box(Right(1))
    assert Right(Left(1)).to_box() == Box(Left(1))


# Generated at 2022-06-24 00:00:24.681295
# Unit test for method map of class Left
def test_Left_map():
    left_value = Left(1)
    right_value = right_value.map(lambda x: x + 2)
    assert left_value.value == 1


# Generated at 2022-06-24 00:00:25.854351
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True



# Generated at 2022-06-24 00:00:27.116801
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])

# Generated at 2022-06-24 00:00:31.646570
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(-20).is_right() == False



# Generated at 2022-06-24 00:00:33.179889
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-24 00:00:35.750535
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('error message')
    assert left.bind(lambda _: Right('a')) == Left('error message')
    assert left.bind(lambda _: Left('other error message')) == Left('error message')


# Generated at 2022-06-24 00:00:40.092659
# Unit test for constructor of class Right
def test_Right():
    assert Right('value') == Right('value')
    assert Right('value') != Right('value2')
    assert Right('value') != Left('value')



# Generated at 2022-06-24 00:00:43.488717
# Unit test for constructor of class Left
def test_Left():
    left = Left(5)

    assert left == Left(5)
    assert not left == Left(10)
    assert isinstance(left, Either)
    assert left.is_left()



# Generated at 2022-06-24 00:00:47.138001
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda a: Right(a + 2)) == Right(3)
    assert Right(1).bind(lambda a: Left(a + 2)) == Left(3)



# Generated at 2022-06-24 00:00:49.155700
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:00:51.053706
# Unit test for constructor of class Right
def test_Right():
    assert Right(5).value == 5


# Generated at 2022-06-24 00:00:54.062486
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Right(1).to_validation()

# Generated at 2022-06-24 00:00:59.445144
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Either(lambda value: value + 1).ap(Right(Box(0))) == Right(Box(1))
    assert Either(lambda value: value + 1).ap(Left(Try(0))) == Left(Try(0))



# Generated at 2022-06-24 00:01:02.065163
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1



# Generated at 2022-06-24 00:01:03.732603
# Unit test for constructor of class Right
def test_Right():
    r = Right('test')

    assert r.value == 'test'
    assert isinstance(r, Right)



# Generated at 2022-06-24 00:01:05.754489
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-24 00:01:08.107103
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    assert Left('123').to_validation() == Validation.fail(['123'])


# Generated at 2022-06-24 00:01:09.520395
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("a").is_right()


# Generated at 2022-06-24 00:01:11.265600
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-24 00:01:15.886909
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (Left(3)) == Left(3)
    assert (Left(3)) != Left(2)
    assert (Left(3)) != Right(3)



# Generated at 2022-06-24 00:01:17.720989
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    right = Right(10)

    assert right.to_validation() == Validation.success(10)


# Generated at 2022-06-24 00:01:20.388865
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) != Either(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) == Left(1)


# Generated at 2022-06-24 00:01:22.458186
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])
    assert Left("abc").to_validation() == Validation.fail(["abc"])



# Generated at 2022-06-24 00:01:24.674565
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() is False
    assert Left(123).is_right() is False
    assert Left('asd').is_right() is False


# Generated at 2022-06-24 00:01:34.195771
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Create instances

    # Different types
    assert Left(1) != Right(1)
    assert Left(1) != [1]
    # The same value, but different types
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    # The same value, but both are Right
    assert Right(1) != Right(1)
    # The same value and types, but different instance
    assert Left(1) != Left(1)
    assert Right(1) != Right(1)
    # The same instance
    a = Left(1)
    assert a == a
    b = Right(1)
    assert b == b



# Generated at 2022-06-24 00:01:35.926030
# Unit test for constructor of class Left
def test_Left():
    # check if constructor return same type as Left
    assert isinstance(Left(1), Left)



# Generated at 2022-06-24 00:01:38.087324
# Unit test for method is_right of class Left
def test_Left_is_right():
    value = 1
    left = Left(value)

    result = left.is_right()

    assert not result



# Generated at 2022-06-24 00:01:39.949284
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Given
    either = Right(10)

    # When
    actual = either.is_right()

    # Then
    assert actual


# Generated at 2022-06-24 00:01:44.437505
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Unit test for method to_try of class Either"""
    assert Either(None).to_try().to_tuple() == (None, True)
    assert Either(1).to_try().to_tuple() == (1, True)
    assert Either('1').to_try().to_tuple() == ('1', True)
    assert Either(True).to_try().to_tuple() == (True, True)


# Generated at 2022-06-24 00:01:47.785935
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(10) == Left(10)
    assert Right(None) == Right(None)
    assert Left(None) == None
    assert Right(10) == None


# Generated at 2022-06-24 00:01:49.760445
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() is True



# Generated at 2022-06-24 00:01:53.787196
# Unit test for constructor of class Either
def test_Either():
    from pymonet.maybe import Maybe

    assert Either(Maybe.just(1)) == Either(Maybe.just(1))
    assert Either(Maybe.nothing()) == Either(Maybe.nothing())
    assert Either(Maybe.just(1)) != Either(Maybe.nothing())


# Generated at 2022-06-24 00:01:55.656664
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(lambda a: a*2)) == Left(1)

# Generated at 2022-06-24 00:01:59.016939
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-24 00:02:00.455990
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-24 00:02:01.499624
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() is True


# Generated at 2022-06-24 00:02:03.704323
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:02:05.475892
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:02:06.714363
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    actual = left.map(lambda x: x + 2)
    expected = left
    assert actual == expected



# Generated at 2022-06-24 00:02:12.367286
# Unit test for method bind of class Right
def test_Right_bind():
    mock = Mock()
    mock.return_value = Right(1)

    result = Right(0).bind(mock)

    mock.assert_called_once_with(0)
    assert isinstance(result, Right)
    assert result == Right(1)



# Generated at 2022-06-24 00:02:18.415093
# Unit test for method case of class Either
def test_Either_case():
    mul2 = lambda x: x * 2
    def add2(x: int) -> int: return x + 2

    assert Left(7).case(mul2, mul2) == 14
    assert Right(7).case(mul2, add2) == 9
    assert Left('error').case(mul2, mul2) == 'errorerror'
    assert Right('value').case(mul2, add2) == 'valuevalue'

# Generated at 2022-06-24 00:02:22.402284
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1).__eq__(Either(1)) is False
    assert Either(1) == Either(1) is False

    assert Left(1).__eq__(Left(1)) is True
    assert Left(1) == Left(1) is True

    assert Right(1).__eq__(Right(1)) is True
    assert Right(1) == Right(1) is True

    assert Left(1).__eq__(Right(1)) is False
    assert Left(1) == Right(1) is False

    assert Right(1).__eq__(Left(1)) is False
    assert Right(1) == Left(1) is False



# Generated at 2022-06-24 00:02:24.866618
# Unit test for method ap of class Left
def test_Left_ap():
    # Given
    either = Left(lambda x: x + 2)
    monad = Right(2)
    expected = Left(lambda x: x + 2)

    # When
    result = either.ap(monad)

    # Then
    assert result == expected

# Generated at 2022-06-24 00:02:26.043850
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() is False



# Generated at 2022-06-24 00:02:28.209823
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('')
    assert(left.is_left())



# Generated at 2022-06-24 00:02:32.030173
# Unit test for method case of class Either
def test_Either_case():
    left = Left(2)
    right = Right(2)

    assert left.case(lambda value: value, lambda value: value) == right.case(lambda value: value, lambda value: value)



# Generated at 2022-06-24 00:02:34.832666
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(123).bind(lambda x: Right(x + 1)) == Left(123)


# Generated at 2022-06-24 00:02:35.789463
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:02:37.700353
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-24 00:02:41.526008
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(None)
    maybe = left.to_maybe()

    assert maybe.is_nothing()


# Generated at 2022-06-24 00:02:45.662033
# Unit test for constructor of class Either
def test_Either():
    left_value = "fault"
    left = Left(left_value)
    assert left.value == left_value, "Right instance with value"

    right_value = 13
    right = Right(right_value)
    assert right.value == right_value, "Right instance with value"



# Generated at 2022-06-24 00:02:49.198702
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    either = Right(1)
    assert either.to_maybe().is_just() and either.to_maybe(
    ).get() == 1, 'Right[A].to_maybe() fails!'



# Generated at 2022-06-24 00:02:52.364630
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1) and\
            Left('Some error').to_box() == Box('Some error')



# Generated at 2022-06-24 00:02:56.749897
# Unit test for constructor of class Either
def test_Either():
    def left_handler(err):
        assert err == 'error'
        return 'right'

    def right_handler(value):
        assert value == 'value'
        return 'right'

    either = Either('value')
    assert either.case(left_handler, right_handler) == 'right'



# Generated at 2022-06-24 00:02:58.898428
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Either(4).is_right(), bool)
    assert not Either(4).is_right()


# Generated at 2022-06-24 00:03:01.168163
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    either = Right(8)

    assert either.to_maybe().value == 8


if __name__ == '__main__':
    test_Right_to_maybe()

# Generated at 2022-06-24 00:03:02.734137
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(5).is_left()


# Generated at 2022-06-24 00:03:05.547468
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    some_value = 'some value'
    left = Left(some_value)
    maybe = left.to_maybe()
    assert maybe == Maybe.nothing()


# Generated at 2022-06-24 00:03:09.735690
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Lazy(lambda: 'test')
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == lazy
    assert Left(3).to_lazy() == lazy


# Generated at 2022-06-24 00:03:13.983976
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)
    assert Right(5) != Right(3)
    assert Right(5) != Left(5)
    assert Right(5) == Right(5)
    assert Right(5).to_maybe().is_just()
    assert Right(5).to_maybe().is_nothing() == False


# Generated at 2022-06-24 00:03:15.503743
# Unit test for method is_right of class Left
def test_Left_is_right():
    left_either = Left("value")
    assert not left_either.is_right()


# Generated at 2022-06-24 00:03:16.532530
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("abc").is_right() is True



# Generated at 2022-06-24 00:03:17.791799
# Unit test for method map of class Left
def test_Left_map():
    f = lambda x: x + 1
    assert Left(1).map(f) == Left(1)


# Generated at 2022-06-24 00:03:20.093808
# Unit test for constructor of class Right
def test_Right():
    either = Either(1)
    assert isinstance(either, Either)
    assert type(either) is Right
    assert either.value == 1



# Generated at 2022-06-24 00:03:21.779535
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(None)
    assert left.bind(lambda x: Right(x)) == left

# Generated at 2022-06-24 00:03:25.704586
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == Validation.fail(['error'])


# Generated at 2022-06-24 00:03:27.533894
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-24 00:03:28.390858
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(True)
    success = left.bind(lambda x: Right(x))
    assert success == left


# Generated at 2022-06-24 00:03:32.461557
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)
    assert Right('test') == Right('test')
    assert Right(5) != Right(5.0)
    assert Right(5) != Right('5')
    assert Right(5) != '5'



# Generated at 2022-06-24 00:03:35.094021
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert isinstance(Right(10).is_left(), bool) and Right(10).is_left() == False


# Generated at 2022-06-24 00:03:44.958892
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.lazy import Lazy
    from pymonet.functors.functor import Functor
    from pymonet.monad_try import Try

    triple_business_days: Callable[[int], int] = lambda days: (days // 7) * 3 + min(days % 7, 3)
    value = Right(triple_business_days).map(triple_business_days).value(10)
    assert value == 6, "Method map test failed"

    def mapper(x: int) -> Either[int]:
        return Right(x)

    right_either = Either.right(10)

    value = Right(right_either).map(mapper).value
    assert value == right_either, "Method map test failed"

    def mapper2(x: int) -> Lazy[int]:
        return L

# Generated at 2022-06-24 00:03:54.637956
# Unit test for constructor of class Either
def test_Either():
    """
    Create Either from different types and check theirs values.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Either(0) == Left(0)
    assert Either(0).value == 0
    assert Either(0).ap(Lazy(lambda: 'hi')).value == 'hi'
    assert Either(0).to_box().value == 0
    assert Either(0).to_try() == Try(0, is_success=False)
    assert Either(0).to_lazy().value() == 0
    assert Either(0).case(lambda x: x + 1, lambda x: x - 1) == 1
    assert Either('hi').value == 'hi'