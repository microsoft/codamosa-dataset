

# Generated at 2022-06-21 18:54:57.921129
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success

    validation = Right(1).to_validation()

    assert isinstance(validation, Validation)
    assert isinstance(validation, Success)
    assert validation.value == 1


# Generated at 2022-06-21 18:55:02.570123
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.functions import compose

    f = compose(lambda x: x + 1, lambda x: x * 2)
    left = Left(100).bind(f)
    assert left == Left(100)



# Generated at 2022-06-21 18:55:04.959586
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    right = Right(1)
    validation = right.to_validation()

    assert validation == Validation.success(1)

# Generated at 2022-06-21 18:55:07.015171
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left("something")

    # Then
    assert left.bind(lambda x: x+"2") == left



# Generated at 2022-06-21 18:55:08.552810
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() == False



# Generated at 2022-06-21 18:55:11.456909
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(value):
        return Right(value)

    assert Right(1).bind(mapper) == Right(1)


# Generated at 2022-06-21 18:55:13.647390
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('abc').is_left()


# Generated at 2022-06-21 18:55:15.501542
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    maybe = Left(4).to_maybe()
    assert maybe.is_nothing()


# Generated at 2022-06-21 18:55:16.902208
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 18:55:25.828802
# Unit test for method ap of class Left
def test_Left_ap():
    def add_one(x):
        return x + 1

    assert Left(None).ap(Left(lambda x: x + 4)) == Left(None)
    assert Left(None).ap(Right(lambda x: x + 4)) == Left(None)
    assert Left(6).ap(Left(add_one)) == Left(6)
    assert Left(6).ap(Right(add_one)) == Left(6)

# Generated at 2022-06-21 18:55:30.420622
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.either import Right, Left

    def even(x):
        if x % 2 == 0:
            return Right(x)
        return Left('Odd number')

    assert Right(4).bind(even) == Right(4)
    assert Right(9).bind(even) == Left('Odd number')


# Generated at 2022-06-21 18:55:31.915825
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()



# Generated at 2022-06-21 18:55:35.077411
# Unit test for constructor of class Left
def test_Left():
    """Unit test for constructor of class Left"""
    e = Left(1)

    assert isinstance(e, Either)
    assert isinstance(e, Left)
    assert e.is_left()
    assert not e.is_right()
    assert e.value == 1


# Generated at 2022-06-21 18:55:37.433937
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)



# Generated at 2022-06-21 18:55:39.696128
# Unit test for constructor of class Left
def test_Left():
    """
    Test for constructor of class Left.
    """
    left = Left(5)
    assert left.value == 5



# Generated at 2022-06-21 18:55:44.672555
# Unit test for method case of class Either
def test_Either_case():
    assert Right(10).case(
        error=lambda v: v + 20,
        success=lambda v: v + 10
    ) == 20
    assert Left(10).case(
        error=lambda v: v + 20,
        success=lambda v: v + 10
    ) == 30


# Generated at 2022-06-21 18:55:45.901960
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:55:53.405490
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.decorators import raises
    from pymonet.right import Right
    from pymonet.left import Left

    def test_function():
        return 1/0

    assert Right(1).to_try() == Try.success(1)
    assert Left(1).to_try() == Try.failure(1)
    assert Right(test_function()).to_try() == Try.failure(ZeroDivisionError)


# Generated at 2022-06-21 18:55:58.056513
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(42), Either)
    assert isinstance(Right(42), Either)
    assert isinstance(Left(42), Left)
    assert isinstance(Right(42), Right)
    assert not isinstance(Right(42), Left)
    assert not isinstance(Left(42), Right)


# Generated at 2022-06-21 18:55:59.546871
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:56:05.718469
# Unit test for method case of class Either
def test_Either_case():
    def error(error):
        return error + "error"

    def success(success):
        return success + "success"

    assert Left('my').case(error, success) == 'myerror'
    assert Right('your').case(error, success) == 'yoursuccess'

# Generated at 2022-06-21 18:56:09.306729
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.either import Right

    assert Right(5).to_maybe().get_or_else(15) == 5
    assert Right('test').to_maybe().get_or_else('test2') == 'test'

# Generated at 2022-06-21 18:56:17.257308
# Unit test for method ap of class Either
def test_Either_ap():
    def mapper(value):
        return lambda v: value + v

    assert Left(2).ap(Left(3)) == Left(3)
    assert Left(2).ap(Right(3)) == Left(2)
    assert Right(2).ap(Left(3)) == Left(3)
    assert Right(2).ap(Right(3)) == Right(5)
    assert Right(2).ap(mapper(3)) == Right(5)
    assert Right(2).ap(Left(mapper(3))) == Left(mapper(3))
    assert Right(2).ap(Right(mapper(3))) == Right(5)


# Generated at 2022-06-21 18:56:21.694501
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor_list import FunctorList
    from pymonet.either import Left

    assert Left(5).ap(FunctorList.of(lambda x: x * 2)) == FunctorList.of(5)

    f = FunctorList.of(lambda x: x * 2)
    assert Right(5).ap(f) == FunctorList.of(10)

# Generated at 2022-06-21 18:56:25.749036
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-21 18:56:33.443140
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert not Either.__eq__(Right(1), None)
    assert not Either.__eq__(Right(1), Right(2))
    assert not Either.__eq__(Right(1), Left(1))
    assert Either.__eq__(Right(1), Right(1))
    assert not Either.__eq__(Left(1), None)
    assert not Either.__eq__(Left(1), Left(2))
    assert not Either.__eq__(Left(1), Right(1))
    assert Either.__eq__(Left(1), Left(1))


# Generated at 2022-06-21 18:56:36.948723
# Unit test for constructor of class Either
def test_Either():
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)
    assert Left(10) != Right(10)
    assert Left(10) != 10
    assert Right(10) != 10
    assert Left(10) != None
    assert Right(10) != None

# Generated at 2022-06-21 18:56:39.356841
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)


# Generated at 2022-06-21 18:56:44.429267
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Left(1).ap(Try.fail(2)) == Left(1)
    assert Left(1).ap(Try.success(2)) == Left(1)
    assert Left(1).ap(Lazy(lambda: 2)) == Left(1)

# Generated at 2022-06-21 18:56:53.478564
# Unit test for constructor of class Left
def test_Left():
    assert Left('a') == Left('a')
    assert Left('a') is not Right('a')
    assert Left('a') != 'a'
    assert Left('a') is not 'a'
    assert Left('a').value == 'a'
    assert Left('a') is not Left('b')
    assert Left('a').case(lambda x: True, lambda y: False)
    assert Left('a').to_box().is_nothing()
    assert Left('a').to_try().is_failure()
    assert Left('a').to_lazy().get_value() == 'a'
    assert Left('a').to_maybe().is_nothing()
    assert Left('a').to_validation().is_failure()


# Generated at 2022-06-21 18:56:58.783682
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)

# Generated at 2022-06-21 18:57:01.118449
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Left(1).to_maybe(), Maybe)
    assert Left(1).to_maybe().is_nothing()
    assert Left(None).to_maybe().is_nothing()


# Generated at 2022-06-21 18:57:05.753695
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert not Either(1) == Either(2)
    assert not Either(1) == Left(2)
    assert not Either(1) == Right(2)



# Generated at 2022-06-21 18:57:09.377822
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(10).to_try() == Try(Fail(10))
    assert Right(10).to_try() == Try(Success(10))

# Generated at 2022-06-21 18:57:13.428651
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 18:57:16.097615
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('not resolved')
    actual = left.bind(lambda x: 'resolved')
    assert actual == 'not resolved'


# Generated at 2022-06-21 18:57:18.773785
# Unit test for method ap of class Left
def test_Left_ap():
    def f(x):
        return x + 2
    left = Left(3)
    right = Left(f)
    assert left.ap(right).value == f


# Generated at 2022-06-21 18:57:20.912799
# Unit test for method ap of class Either
def test_Either_ap():
    def add(value):
        return lambda x: x + value

    box = Either.right(2).ap(Either.right(3))
    assert box.value == 5
    assert isinstance(box, Either)
    assert isinstance(box, Right)

# Generated at 2022-06-21 18:57:27.770963
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad_maybe import Maybe

    def test_case(error: Callable[[str], Any], success: Callable[[str], Any]):
        return 'error' if error('test') else success('test')

    assert 'error' == Left('test').case(test_case, None)
    assert 'test' == Right('test').case(None, test_case)


# Generated at 2022-06-21 18:57:30.862072
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left('error').to_box() == Box('error')
    assert (Right(1).to_box() == Box(1))
    assert type(Left('error').to_box()) is Box


# Generated at 2022-06-21 18:57:36.956861
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x).is_right() is True
    assert Right(1).map(lambda x: x).value == 1



# Generated at 2022-06-21 18:57:39.041521
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Right(1) == 1



# Generated at 2022-06-21 18:57:47.382142
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Run tests for Either to_try method.

    :returns: True if tests passed, False if not
    :rtype: Boolean
    """
    from pymonet.monad_try import Try

    try_from_left = Left(Exception()).to_try()
    try_from_right = Right(Exception()).to_try()

    return isinstance(try_from_left, Try) and try_from_left.is_failed()\
        and isinstance(try_from_right, Try) and try_from_right.is_success()


# Generated at 2022-06-21 18:57:50.736847
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-21 18:57:53.844371
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.result import Result
    from pymonet.either import Either, Right, Left

    def f(x):
        return Either.from_any(Result.success(x))

    assert Right(1).bind(f) == Right(1)



# Generated at 2022-06-21 18:57:57.363454
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left("Error").to_try() == Try(value="Error", is_success=False)
    assert Right("Success").to_try() == Try(value="Success", is_success=True)


# Generated at 2022-06-21 18:58:01.088859
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either"""
    from pymonet.maybe import Maybe

    assert isinstance(Either(Maybe.just(1)), Either)
    assert isinstance(Either(Maybe.nothing()), Either)

# Generated at 2022-06-21 18:58:04.091709
# Unit test for method map of class Right
def test_Right_map():
    # given
    source = Right(2)

    # when
    target = source.map(lambda x: x + 2)

    # then
    assert target == Right(4)


# Generated at 2022-06-21 18:58:05.408542
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-21 18:58:07.442869
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    assert Right(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 18:58:12.730646
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.monad_maybe import Maybe

    assert Either.right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:58:15.787346
# Unit test for method is_left of class Left
def test_Left_is_left():
    # given
    either = Left(1)

    # when
    result = either.is_left()

    # then
    assert result is True



# Generated at 2022-06-21 18:58:20.897581
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    lazy = Lazy(lambda: "Hello, World!")
    maybe = lazy.to_maybe()
    either = maybe.to_either()
    val = either.to_lazy().call()
    assert val == "Hello, World!"

# Generated at 2022-06-21 18:58:25.642788
# Unit test for method case of class Either
def test_Either_case():
    def test_error(value):
        return 'error'

    def test_success(value):
        return 'success'

    def test_error_2(value):
        return 'error_2'

    def test_success_2(value):
        return 'success_2'

    left_error = Left(test_error)
    assert left_error.case(lambda value: value(None), lambda value: value(None)) == 'error'
    assert left_error.case(test_error_2, test_success_2) == 'error_2'

    right_success = Right(test_success)
    assert right_success.case(lambda value: value(None), lambda value: value(None)) == 'success'
    assert right_success.case(test_error_2, test_success_2) == 'success_2'

# Generated at 2022-06-21 18:58:27.358078
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x)) == Left(1)



# Generated at 2022-06-21 18:58:34.599458
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Either(5).to_try() == Left(5).to_try() == \
        Try(5, is_success=False), 'to_try must return Try with False "left" value'
    assert Either('a').to_try() == Right('a').to_try() == \
        Try('a', is_success=True), 'to_try must return Try with False "right" value'



# Generated at 2022-06-21 18:58:39.917865
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test to_box of Either

    :returns: Boolean test result
    :rtype: Boolean
    """
    from pymonet.box import Box

    assert Left(10).to_box() == Box(10)
    assert Right(10).to_box() == Box(10)



# Generated at 2022-06-21 18:58:46.887591
# Unit test for method __eq__ of class Either

# Generated at 2022-06-21 18:58:49.418681
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-21 18:58:53.778533
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.either import Left, Right

    assert Left(1) == Left(1)
    assert Left(1) != Left('a')
    assert Left(1) != Right(1)
    assert Left(1) != Right('a')

    assert Right(1) == Right(1)
    assert Right(1) != Right('a')
    assert Right(1) != Left(1)
    assert Right(1) != Left('a')


# Generated at 2022-06-21 18:58:59.097888
# Unit test for constructor of class Right
def test_Right():
    assert Right(15) == Right(15)



# Generated at 2022-06-21 18:59:01.461272
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x).ap(Left(lambda x: x)) == Left(lambda x: x)



# Generated at 2022-06-21 18:59:09.367044
# Unit test for method case of class Either
def test_Either_case():
    def test_case_error(value):
        return value ** 2

    def test_case_success(value):
        return value + 1

    assert Either(None).case(test_case_error, test_case_success) == 0
    assert Left(None).case(test_case_error, test_case_success) == 0
    assert Right(None).case(test_case_error, test_case_success) == 1

    assert Either(1).case(test_case_error, test_case_success) == 2
    assert Left(1).case(test_case_error, test_case_success) == 1
    assert Right(1).case(test_case_error, test_case_success) == 2



# Generated at 2022-06-21 18:59:13.602915
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)


# Generated at 2022-06-21 18:59:15.928043
# Unit test for method map of class Left
def test_Left_map():
    result = Left(2)
    assert result == result.map(lambda x: x)



# Generated at 2022-06-21 18:59:18.495710
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:59:20.144759
# Unit test for constructor of class Either
def test_Either():
    a = Either(2)

    assert a.value == 2
    assert a.case(lambda v: v, lambda v: v) == 2


# Generated at 2022-06-21 18:59:24.076844
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import lazy
    from pymonet.box import Box

    # when
    result = Left('error').to_lazy()
    # then
    assert result == Lazy(lambda: 'error')

    # when
    result = Right('value').to_lazy()
    # then
    assert result == Lazy(lambda: 'value')



# Generated at 2022-06-21 18:59:25.579574
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(1).is_right()
    assert Right(1).is_right()



# Generated at 2022-06-21 18:59:27.156053
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(20)
    assert not left.is_right()


# Generated at 2022-06-21 18:59:31.446978
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert getattr(Right(None), 'is_right')() is True


# Generated at 2022-06-21 18:59:34.135805
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)



# Generated at 2022-06-21 18:59:35.556707
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-21 18:59:38.169075
# Unit test for method ap of class Left
def test_Left_ap():
    result = Left(1).ap(Left(lambda x: x))
    assert result.value == 1
    assert result.is_right() is False


# Generated at 2022-06-21 18:59:39.833435
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() == False


# Generated at 2022-06-21 18:59:41.820522
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() is True
    assert Left('').is_left() is True


# Generated at 2022-06-21 18:59:43.919565
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    new_left = left.map(lambda value: value + 1)
    assert left == new_left



# Generated at 2022-06-21 18:59:47.489081
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    # Given
    from pymonet.maybe import Maybe, Nothing
    value = 5

    # When
    maybe = Right(value).to_maybe()

    # Then
    assert isinstance(maybe, Maybe)
    assert maybe != Nothing()
    assert maybe == Maybe.just(value)



# Generated at 2022-06-21 18:59:50.388547
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('error').ap(Left('error2')) == Left('error')
    assert Left('error').ap(Right('error2')) == Left('error')

# Generated at 2022-06-21 18:59:53.461265
# Unit test for method to_try of class Either
def test_Either_to_try():
    left = Left(10)
    assert left.to_try() == Try(10, is_success=False)

    right = Right(10)
    assert right.to_try() == Try(10, is_success=True)

# Generated at 2022-06-21 19:00:01.679383
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() is False


# Generated at 2022-06-21 19:00:05.677867
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    import pytest
    from pymonet.maybe import Maybe

    right_instance = Right(2)
    maybe_instance = right_instance.to_maybe()

    assert isinstance(maybe_instance, Maybe)
    assert maybe_instance.is_just()
    assert maybe_instance.value() == 2


# Generated at 2022-06-21 19:00:09.038804
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.maybe import Maybe

    value = Left(3)
    actual = value.map(lambda x: x + 2)
    expected = Left(3)
    assert actual == expected



# Generated at 2022-06-21 19:00:10.490545
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left('error').to_validation().is_fail()


# Generated at 2022-06-21 19:00:13.313515
# Unit test for method is_right of class Right
def test_Right_is_right():
    def act(): return Right(5)

    assert act().is_right() == True


# Generated at 2022-06-21 19:00:15.473844
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(2).to_lazy().value() == 2


# Generated at 2022-06-21 19:00:21.357668
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.maybe import Maybe

    assert Right(5).ap(Right(add)) == Right(10)
    assert Right(5).ap(Right(inc)) == Right(6)
    assert Right(5).ap(Maybe.just(add)) == Maybe.just(10)
    assert Left(5).ap(Right(add)) == Left(5)
    assert Left(5).ap(Right(inc)) == Left(5)
    assert Left(5).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:00:24.757460
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False, 'Right is not left'



# Generated at 2022-06-21 19:00:31.288440
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    #Test success
    assert isinstance(Either(2).to_try(), Try)
    assert Either(2).to_try().get_value() == 2

    #Test failure
    assert isinstance(Either("Error").to_try(), Try)
    assert Either("Error").to_try().get_value() == "Error"

    # Test result
    assert Either(2).to_try().is_success()
    assert not Either("Error").to_try().is_success()


# Generated at 2022-06-21 19:00:35.279714
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-21 19:00:51.850791
# Unit test for method case of class Either
def test_Either_case():
    def error_func(value): return value

    def right_func(value): return value

    left_either = Left(1)
    right_either = Right(2)

    assert right_either.case(error_func, right_func) == 2
    assert left_either.case(error_func, right_func) == 1

# Generated at 2022-06-21 19:00:54.949101
# Unit test for method ap of class Left
def test_Left_ap():
    class Ap:
        def __init__(self, value):
            self.value = value

        def ap(self, value):
            return self.value(value)

    assert Left(lambda x: x + 1).ap(Right(1)) == Left(lambda x: x + 1)

# Generated at 2022-06-21 19:00:57.097733
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('value').is_left() is True



# Generated at 2022-06-21 19:00:58.986768
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x + 1) == Left(2)


# Generated at 2022-06-21 19:01:02.448947
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(2)

    assert left == left
    assert right == right

    assert left != right
    assert right != left



# Generated at 2022-06-21 19:01:04.452602
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:01:09.703281
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(True).ap(Right(lambda x: x)) == Right(True)
    assert Right(lambda x: x).ap(Right(True)) == Right(True)
    assert Left('error').ap(Right(lambda x: x)) == Left('error')
    assert Right(lambda x: x).ap(Left('error')) == Left('error')



# Generated at 2022-06-21 19:01:12.456813
# Unit test for constructor of class Right
def test_Right():
    """
    Check that instance of check_Right return the same value as constructor.

    :returns: True when instance of Right and Right.value are equals and both are right
    :rtype: Boolean
    """
    return Right(3).value == 3 and\
        Right(3).is_right()



# Generated at 2022-06-21 19:01:15.934251
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(2)
    right = Right(lambda a: a * 2)
    expect = Left(2)
    result = left.ap(right)

    assert result == expect
    assert isinstance(result, Either)
    assert isinstance(result, Left)



# Generated at 2022-06-21 19:01:26.724902
# Unit test for method ap of class Either
def test_Either_ap():
    def add(a, b):
        return a+b
    def add_to_box(b):
        return lambda a: a+b
    assert Right(5).ap(Right(5)) == Right(10)
    assert Left(5).ap(Left(5)) == Left(5)
    assert Right(5).ap(Left(5)) == Left(5)
    assert Left(5).ap(Right(5)) == Left(5)
    assert Right(add_to_box(5)).ap(Left(5)) == Left(5)
    assert Right(add_to_box(5)).ap(Right(5)) == Right(10)

# Generated at 2022-06-21 19:01:54.682932
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-21 19:01:59.186857
# Unit test for method bind of class Left
def test_Left_bind():
    # Arrange
    left = Left(0)
    # Act
    result = left.bind(lambda value: Right(value + 1))
    # Assert
    assert isinstance(result, Left)
    assert result == left



# Generated at 2022-06-21 19:02:01.613362
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:02:03.486088
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left("error").to_lazy().eval() == "error"
    assert Right("success").to_lazy().eval() == "success"



# Generated at 2022-06-21 19:02:06.069752
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:02:09.952297
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Right(42).to_try() == Try(42, True)
    assert Left(42).to_try() == Try(42, False)

# Generated at 2022-06-21 19:02:11.654044
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda n: n * n) == Right(1)



# Generated at 2022-06-21 19:02:13.302023
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-21 19:02:14.814044
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('foo').is_left()


# Generated at 2022-06-21 19:02:18.238966
# Unit test for method to_try of class Either
def test_Either_to_try():

    assert Left(1).to_try().is_success() == False
    assert Left(1).to_try().get_value() == 1

    assert Right(1).to_try().is_success() == True
    assert Right(1).to_try().get_value() == 1


# Generated at 2022-06-21 19:03:21.897527
# Unit test for method bind of class Left
def test_Left_bind():
    value = 1
    left = Left(value)
    binded_left = left.bind(lambda x: Left(x + 1))
    assert left == binded_left
    assert left.value == binded_left.value


# Generated at 2022-06-21 19:03:26.878982
# Unit test for method case of class Either
def test_Either_case():
    """Test Either.case"""

    right_value = Right(10)
    left_value = Left(-10)
    double_error = lambda value: value * 2
    double_success = lambda value: value * 2

    assert left_value.case(double_error, double_success) == -20
    assert right_value.case(double_error, double_success) == 20


# Generated at 2022-06-21 19:03:29.436569
# Unit test for method is_right of class Left
def test_Left_is_right():
    """Test for method is_right of class Left."""
    assert Left("Left").is_right() == False



# Generated at 2022-06-21 19:03:30.903134
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(0)
    assert left.is_left()



# Generated at 2022-06-21 19:03:38.058987
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x).ap(Right(2)) == Right(2)
    assert Left(lambda x: x).ap(Right(2)) == Left(lambda x: x)
    assert Right(lambda x: x).ap(Left(2)) == Left(2)
    assert Left(lambda x: x).ap(Left(2)) == Left(lambda x: x)



# Generated at 2022-06-21 19:03:39.569776
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-21 19:03:41.182185
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:03:42.774678
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(3).to_validation() == Validation.fail([3])



# Generated at 2022-06-21 19:03:45.549318
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(4).is_right()
    assert not Left(4).is_right()


#  Unit test for method is_left of class Either

# Generated at 2022-06-21 19:03:48.455823
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(2) is False
    assert Left(1) == Left(2) is False
    assert Right(1) == Left(1) is False
    assert Left(1) == Right(1) is False

