

# Generated at 2022-06-21 18:54:56.197823
# Unit test for method is_right of class Either
def test_Either_is_right():
    value = 'value'
    left = Left(value)
    right = Right(value)

    assert isinstance(left, Either)
    assert not left.is_right()
    assert isinstance(right, Either)
    assert right.is_right()


# Generated at 2022-06-21 18:54:57.406644
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)

    assert right.value == 1



# Generated at 2022-06-21 18:55:08.468211
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_karver import MonadKarver
    from pymonet.monad_either import MonadEither
    from pymonet.monad_either import Left
    from pymonet.monad_either import Right
    mki = MonadKarver()
    mei = MonadEither()
    assert Right(10).bind(lambda x: Right(x + 3)) == mki.bind(10, lambda x: mki.unit(x + 3), mei)

# Generated at 2022-06-21 18:55:11.106536
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        return Right(x + 1)

    assert Right(1).ap(add) == Right(2)
    assert Right(1).ap(Left(2)) == Left(2)
    assert Left(1).ap(add) == Left(1)



# Generated at 2022-06-21 18:55:13.864235
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)



# Generated at 2022-06-21 18:55:24.640580
# Unit test for constructor of class Either
def test_Either():
    # Given
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    right = Right(1)
    left = Left(1)

    # When
    right_to_boxed = right.to_box()
    left_to_boxed = left.to_box()
    right_to_lazy = right.to_lazy()
    left_to_lazy = left.to_lazy()
    right_to_maybed = right.to_maybe()
    left_to_maybed = left.to_maybe()
    right_to_tried = right.to_try()
    left_to_tried = left.to_try()

# Generated at 2022-06-21 18:55:26.261026
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("Sample text").is_right()



# Generated at 2022-06-21 18:55:37.086229
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.exceptions import MonetException
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Right(2).map(lambda x: x + 1) == Right(3)
    assert Right(2).map(lambda x: Maybe.just(x + 1)) == Right(Maybe.just(3))
    assert Right(2).map(lambda x: Try.success(x + 1)) == Right(Try.success(3))
    assert Right(2).map(lambda x: x - 1) == Right(1)
    assert Right(2).map(lambda x: Maybe.just(x - 1)) == Right(Maybe.just(1))
    assert Right(2).map(lambda x: Try.success(x - 1)) == Right(Try.success(1))


# Generated at 2022-06-21 18:55:41.237133
# Unit test for method case of class Either
def test_Either_case():
    from test_helpers import identity, inc, same_as_right, same_as_left
    assert Right(1).case(same_as_left, same_as_right)() == 1
    assert Left(1).case(identity, inc)() == 1


# Generated at 2022-06-21 18:55:43.830405
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    error = Left(5)
    assert error.to_validation() == Validation([5])


# Generated at 2022-06-21 18:55:51.751803
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test for method __eq__ of class Either.

    :return: assertion error if test is failed
    """
    from nose.tools import assert_true, assert_false

    assert_true(Right(2) == Right(2))
    assert_false(Right('a') == Left('a'))
    assert_false(Right(2) == 2)



# Generated at 2022-06-21 18:55:56.107255
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Should return result of calling mapper contained in applicative with value contained in Either.
    """
    assert isinstance(Right(1).ap(Right(lambda x: x + 1)), Either)
    assert isinstance(Left(1).ap(Right(lambda x: x + 1)), Either)


# Generated at 2022-06-21 18:55:59.926674
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test case verifing method __eq__ of class Either
    """
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(5) != Right(5)


# Generated at 2022-06-21 18:56:03.816042
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    assert Either(lambda x: x + 3).ap(Box(2)) == Box(5)
    assert Either(lambda x: x + 3).ap(Box("2")) == Box("23")



# Generated at 2022-06-21 18:56:04.831500
# Unit test for constructor of class Either
def test_Either():
    assert Either(0) == None



# Generated at 2022-06-21 18:56:10.706786
# Unit test for constructor of class Right
def test_Right():
    assert isinstance(Right(3), Either)
    assert isinstance(Right(3), Right)
    assert isinstance(Right(3).value, int)
    assert isinstance(Right('test'), Either)
    assert isinstance(Right('test'), Right)
    assert isinstance(Right('test').value, str)


# Generated at 2022-06-21 18:56:12.121537
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right()



# Generated at 2022-06-21 18:56:16.150259
# Unit test for constructor of class Left
def test_Left():
    assert type(Left(0)) == Left
    assert type(Left('a')) == Left
    assert type(Left(None)) == Left
    assert type(Left('')) == Left
    assert type(Left(dict())) == Left
    assert type(Left(list())) == Left
    assert type(Left(set())) == Left



# Generated at 2022-06-21 18:56:18.497383
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left([1]).to_maybe() == Maybe.nothing() and Left([1, 2]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 18:56:19.989852
# Unit test for constructor of class Right
def test_Right():
    result = Right(1)
    assert result.value == 1



# Generated at 2022-06-21 18:56:25.854497
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(None).to_maybe() == Maybe.nothing()
    assert Left(1).to_maybe() == Maybe.nothing()
    assert Left("test").to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:56:26.607639
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(None).is_right()


# Generated at 2022-06-21 18:56:28.700708
# Unit test for method map of class Left
def test_Left_map():
    assert Left(10).map(lambda x: x * 2) == Left(10)


# Generated at 2022-06-21 18:56:34.304376
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    x = Either.of(Maybe.of(Try.of(1)))
    y = x.to_try()

    assert y == Try(1, True)
    assert x.to_try() == Try(1, True)
    assert Either.of(Try.of(Maybe.of(1))).to_try() == Try(Maybe.of(1), True)

# Generated at 2022-06-21 18:56:36.332561
# Unit test for constructor of class Right
def test_Right():
    right = Right("right value")
    assert right.value == "right value"
    assert right.is_right() is True
    assert right.is_left() is False


# Generated at 2022-06-21 18:56:39.043937
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:56:45.255533
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Try should have status of Either.
    Right should be resolved successfully.
    Left should not be resolved successfully.
    """
    from pymonet.monad_try import Try

    def mapper(x):
        return x ** 2

    assert Right(10).to_try() == Try(100, is_success=True)
    assert Left(10).to_try() == Try(10, is_success=False)


# Generated at 2022-06-21 18:56:46.510202
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(2).is_right() is False


# Generated at 2022-06-21 18:56:48.161263
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-21 18:56:49.999575
# Unit test for constructor of class Right
def test_Right():
    assert Right('test') == Right('test')
    assert Right(1) != Right(2)



# Generated at 2022-06-21 18:56:54.045725
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(10)
    result = right.to_maybe()
    assert isinstance(result, Maybe)
    assert result is Maybe.just(10)


# Generated at 2022-06-21 18:56:56.143024
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right("OK").to_validation() == Validation.success("OK")



# Generated at 2022-06-21 18:57:07.810471
# Unit test for constructor of class Either
def test_Either():
    from pymonet.core_test import assert_either_instance
    from pymonet.core_test import assert_comparison_result_is_true
    from pymonet.core_test import assert_comparison_result_is_false

    # Construction of Right instance
    right = Right(1)

    assert_either_instance(right, 1, True, False)

    # Construction of Left instance
    left = Left(1)

    assert_either_instance(left, 1, False, True)

    # Equality of 2 Right instances with different values
    assert_comparison_result_is_false(right, Right(2))

    # Equality of 2 Right instances with the same values
    assert_comparison_result_is_true(right, Right(1))

    # Equality of Right and Left instances
    assert_compar

# Generated at 2022-06-21 18:57:10.485001
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(x):
        return Right(x * 2)

    assert Right(2).bind(mapper) == Right(4)



# Generated at 2022-06-21 18:57:12.690119
# Unit test for method is_right of class Left
def test_Left_is_right():
    from pymonet.maybe import Maybe

    assert Left(Maybe.nothing()).is_right() is False


# Generated at 2022-06-21 18:57:14.363403
# Unit test for constructor of class Right
def test_Right():
    right_empty = Right('')
    assert right_empty is not None
    right_empty.value == ''


# Generated at 2022-06-21 18:57:15.852508
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(None).to_box() == Box(None)
    assert Left(None).to_box() == Box(None)


# Generated at 2022-06-21 18:57:17.725433
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('error').is_right() == False
    assert Right('value').is_right() == True


# Generated at 2022-06-21 18:57:20.668458
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    result = Left(1).to_validation()

    Validation.fail([1]).should.equal(result)


# Generated at 2022-06-21 18:57:22.732285
# Unit test for constructor of class Left
def test_Left():
    # Check constructor
    assert Left('error').value == 'error'


# Generated at 2022-06-21 18:57:27.669488
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.maybe import Maybe
    maybe = Maybe.just(3)
    assert maybe.bind(lambda a: [a + 2]).bind(lambda b: b * 2).value == 10



# Generated at 2022-06-21 18:57:30.065750
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    x = Right('abc')
    assert x.to_validation() == Validation.success('abc')



# Generated at 2022-06-21 18:57:38.001078
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Test for method to_box of class Either.
    """
    def run_test(either):
        """
        Runs test for provided either.

        :param either: either to run test on
        :type either: Either[Any]
        :returns: Unit
        :rtype: None
        """
        from pymonet.box import Box
        assert either.to_box() == Box(either.value)

    run_test(Left(10))
    run_test(Right(10))


# Generated at 2022-06-21 18:57:39.356555
# Unit test for method map of class Right
def test_Right_map():
    value = Right(1)
    assert value.map(lambda x: x + 1) == value.map(lambda x: x + 1), f"Right map method doesn't work properly"



# Generated at 2022-06-21 18:57:41.524400
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(2)
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-21 18:57:42.714730
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:57:46.142804
# Unit test for method map of class Right
def test_Right_map():
    first = Right(2)
    second = first.map(lambda i: i * 3)
    assert second == Right(6)



# Generated at 2022-06-21 18:57:47.236547
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()

# Generated at 2022-06-21 18:57:49.880305
# Unit test for constructor of class Either
def test_Either():
    left = Left('Test')
    assert left.value == 'Test'
    right = Right('Test')
    assert right.value == 'Test'


# Generated at 2022-06-21 18:57:52.172858
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    test = Left(1)
    assert test.__eq__(None) == False
    assert test.__eq__(Left(1)) == True


# Generated at 2022-06-21 18:57:57.870631
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(2).to_try() == Try(2, is_successful=True)
    assert Either(None).to_try() == Try(None, is_successful=False)

# Generated at 2022-06-21 18:58:00.351441
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-21 18:58:02.800563
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left('str')) == Left(1)
    assert Left(1).ap(Right('str')) == Left(1)


# Generated at 2022-06-21 18:58:04.314016
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(5).bind(lambda x: Right(x + 5)) == Right(10)

# Generated at 2022-06-21 18:58:06.307357
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    f = lambda x: x + 1
    left.bind(f) == left


# Generated at 2022-06-21 18:58:07.613105
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left() == True



# Generated at 2022-06-21 18:58:14.950267
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    import unittest

    from pymonet.maybe import Maybe
    from pymonet.monad_test_case import MonadTestCase

    class TestRightToMaybe(unittest.TestCase, MonadTestCase):
        def setUp(self) -> None:
            self.valid_monad_value = Either.Right(1)
            self.invalid_monad_value = Either.Right(None)

        def test_monad_type(self) -> None:
            self.assertIsInstance(self.valid_monad_value, Either)

        def test_to_maybe_on_valid_Maybe(self):
            self.assertIsInstance(Either.Right(1), Either)
            self.assertIsInstance(self.valid_monad_value.to_maybe(), Maybe)

# Generated at 2022-06-21 18:58:22.797034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyException

    assert isinstance(Left(5).to_lazy(), Lazy)
    assert isinstance(Right(5).to_lazy(), Lazy)
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy().force() == 5
    assert Right(5).to_lazy().force() == 5


# Generated at 2022-06-21 18:58:24.370533
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()


# Generated at 2022-06-21 18:58:28.724373
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Right(2).to_lazy()
    assert lazy.is_instance(Lazy)
    assert lazy.force() == 2

    lazy = Left(2).to_lazy()
    assert lazy.is_instance(Lazy)
    assert lazy.force() == 2



# Generated at 2022-06-21 18:58:37.767508
# Unit test for method ap of class Either
def test_Either_ap():
    assert Either.ap(Right(lambda x: x + 1), Right(4)) == Right(5)
    assert Either.ap(Left(lambda x: x + 1), Right(4)) == Left(lambda x: x + 1)

# Generated at 2022-06-21 18:58:39.646593
# Unit test for constructor of class Right
def test_Right():
    result = Right(3)
    assert isinstance(result, Right)


# Generated at 2022-06-21 18:58:42.794394
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x + 2).ap(Right(2)) == Left(lambda x: x + 2)
    assert Left(lambda x: x + 2).ap(Right(2)).is_left()


# Generated at 2022-06-21 18:58:44.923066
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:58:47.393102
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(True).to_try() == Try(True, True)
    assert Left('error').to_try() == Try(None, False)


# Generated at 2022-06-21 18:58:51.073556
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:58:54.181149
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert (Either(1).is_right() is None)
    assert (Right(1).is_right() == True)
    assert (Left(1).is_right() == False)


# Generated at 2022-06-21 18:58:55.808918
# Unit test for method map of class Right
def test_Right_map():
    assert Right(10).map(lambda a: a + 2) == Right(12)


# Generated at 2022-06-21 18:58:59.194732
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(2)) == Right(3)
    assert Left(2).ap(Right(2)) == Left(2)



# Generated at 2022-06-21 18:59:00.308385
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()

# Generated at 2022-06-21 18:59:07.309875
# Unit test for method is_right of class Right
def test_Right_is_right():
    right_value = Right(1)
    assert right_value.is_right()



# Generated at 2022-06-21 18:59:10.495264
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(1)).__class__.__name__ == 'Lazy'
    assert Either.to_lazy(Right(1)).value() == 1
    assert Either.to_lazy(Left(1)).__class__.__name__ == 'Lazy'
    assert Either.to_lazy(Left(1)).value() == 1

# Generated at 2022-06-21 18:59:12.977117
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right('A').bind(lambda x: Right(x + 'B')) == Right('AB')



# Generated at 2022-06-21 18:59:18.926826
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test for method bind of class Right.

    Bind changes value from one monad to another.
    Test has to check if bind returns function result of function on passed monad with previous value.
    """
    monad = Right(1)
    result = monad.bind(lambda value: Right(value+1))
    assert result.value == 2 and result.is_right()

# Generated at 2022-06-21 18:59:20.999262
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True



# Generated at 2022-06-21 18:59:22.474150
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(200).to_validation() == \
        Validation.fail([200])

# Generated at 2022-06-21 18:59:24.487681
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x + 2)) == Left(2), 'Wrong implementation of Left bind'


# Generated at 2022-06-21 18:59:26.091787
# Unit test for method is_left of class Right
def test_Right_is_left():
    """
    Test if method is_left of class Right returns False.
    """

    assert Right(2).is_left()


# Generated at 2022-06-21 18:59:27.944687
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) is not Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-21 18:59:29.829572
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)

    assert right.is_left() == False


# Generated at 2022-06-21 18:59:49.732388
# Unit test for method case of class Either
def test_Either_case():
    # Scenario:
    # Either[A] has value of type A
    # method case is called with 2 functions
    # first - should be called if Either is Left
    # second - should be called if Either is Right
    #
    # When I call method case with these functions
    # Then result of called function should be returned

    def fst(error):
        assert error == 'error'
        return None

    def snd(success):
        assert success == 'success'
        return None

    assert Left('error').case(fst, snd) == None
    assert Right('success').case(fst, snd) == None


# Generated at 2022-06-21 18:59:53.595721
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> test_Either_ap()
    True
    """
    return either_right(1).ap(either_right(lambda x: x + 1)) == either_right(2) and \
        either_left('error').ap(either_left('error')) == either_left('error')



# Generated at 2022-06-21 18:59:57.983461
# Unit test for method case of class Either
def test_Either_case():
    # Test for Left Either
    left = Left('Error')
    assert left.case(
        lambda x: 'Error',
        lambda x: x
    ) == 'Error'
    # Test for Right Either
    right = Right(1)
    assert right.case(
        lambda x: 'Error',
        lambda x: x
    ) == 1



# Generated at 2022-06-21 19:00:02.931861
# Unit test for method to_box of class Either
def test_Either_to_box():
    import pytest

    assert Left(1).to_box() == Box(1)

    with pytest.raises(Exception):
        Left(Exception('error')).to_box().unsafe_get()

    assert Right(1).to_box() == Box(1)
    assert Right(Exception('error')).to_box() == Box(Exception('error'))


# Generated at 2022-06-21 19:00:04.547832
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 19:00:06.290877
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 1) == Right(3)



# Generated at 2022-06-21 19:00:07.573400
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Nothing()



# Generated at 2022-06-21 19:00:09.417956
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:00:14.773901
# Unit test for method bind of class Right
def test_Right_bind():
    # Given
    value = 'Test'
    right_value = Right(value)

    # When
    binded = right_value.bind(lambda value: value.strip())

    # Then
    assert isinstance(binded, str)
    assert binded == value.strip()



# Generated at 2022-06-21 19:00:16.419940
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('a').to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:00:29.144154
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda n: n + 3) == Right(6)


# Generated at 2022-06-21 19:00:30.611788
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(5).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:00:32.326273
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True



# Generated at 2022-06-21 19:00:36.166739
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Left(Box(False)).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:00:37.015765
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x).value == 1


# Generated at 2022-06-21 19:00:41.423862
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Failure as VFailure
    from pymonet.validation import Success as VSuccess

    failure = Left('Error')
    assert failure.to_validation() == VFailure('Error')

    success = Right(3)
    assert success.to_validation() == VSuccess(3)

# Generated at 2022-06-21 19:00:42.921391
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(7).is_right()



# Generated at 2022-06-21 19:00:44.680448
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-21 19:00:47.481044
# Unit test for constructor of class Either
def test_Either():
    assert Left is not Right
    assert Left('error') is not Right('value')


# Unit tests for method case of class Either

# Generated at 2022-06-21 19:00:48.964140
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(3).is_left() == False



# Generated at 2022-06-21 19:01:03.194205
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()


# Generated at 2022-06-21 19:01:08.480509
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(None).map(lambda x: x + 1) == Left(None)
    assert Left(True).map(lambda x: x + 1) == Left(True)
    assert Left("foo").map(lambda x: x + 1) == Left("foo")


# Generated at 2022-06-21 19:01:14.204735
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    test_values = [
        (Box(5), Right(5)),
        (Box(5), Left(5))
    ]

    for tup in test_values:
        # Test converting to Box
        box = tup[1].to_box()
        # Test if the Box contains the same value as the Either value
        assert box == tup[0]
        assert box.value == tup[0].value


# Generated at 2022-06-21 19:01:17.057819
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left('error')
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:01:20.542936
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    maybe = Right(12).to_maybe()
    assert isinstance(maybe, Maybe)
    assert maybe.get_or_else(None) == 12



# Generated at 2022-06-21 19:01:23.198234
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(10)
    right = Right(20)
    assert left.ap(right) == left


# Generated at 2022-06-21 19:01:25.306806
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(10).to_box() == Box(10)
    assert Right(10).to_box() == Box(10)


# Generated at 2022-06-21 19:01:26.537534
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:01:28.588222
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(7).to_lazy() == Lazy(lambda: 7)
    assert Left(7).to_lazy() == Lazy(lambda: 7)


# Generated at 2022-06-21 19:01:39.199310
# Unit test for method ap of class Either
def test_Either_ap():
    def test_func(x: int) -> int:
        return x + 1

    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Left(2).ap(Lazy(test_func)) == Left(2)
    assert Left(2).ap(Box(test_func)) == Left(2)
    assert Left(2).ap(Try(test_func, True)) == Left(2)
    assert Left(2).ap(Maybe.just(test_func)) == Left(2)
    assert Left(2).ap(Validation.success(test_func)) == Left(2)


# Generated at 2022-06-21 19:02:08.352597
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert not Right(1) == Left(1)



# Generated at 2022-06-21 19:02:11.543399
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-21 19:02:13.210563
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(10).is_right()



# Generated at 2022-06-21 19:02:14.734373
# Unit test for constructor of class Left
def test_Left():
    assert Left('test') == Left('test')


# Generated at 2022-06-21 19:02:16.132629
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)



# Generated at 2022-06-21 19:02:18.611240
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(1).to_box() == Either(1).to_box()
    assert Either(1).to_box() != Box(1)
    assert Either(1).to_box() != Either(2).to_box()


# Generated at 2022-06-21 19:02:19.795562
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(5)
    assert right.to_maybe().value == 5



# Generated at 2022-06-21 19:02:24.272032
# Unit test for method bind of class Left
def test_Left_bind():
    value = 'test_value'
    error = Left(value)
    mapper = lambda x: Right(x)
    assert mapper(value).__eq__(error.bind(mapper))


# Generated at 2022-06-21 19:02:28.050923
# Unit test for method bind of class Right
def test_Right_bind():

    def mapper(value):
        return Right(value + 1)

    assert Right(1).bind(mapper).bind(mapper).value == 3
    assert Left(1).bind(mapper).value == 1



# Generated at 2022-06-21 19:02:29.867422
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(4) == Right(4).to_validation()



# Generated at 2022-06-21 19:03:31.221543
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either.to_box(Right(1)) == 1
    assert Either.to_box(Left([1, 2])) == [1, 2]



# Generated at 2022-06-21 19:03:37.042703
# Unit test for method case of class Either
def test_Either_case():
    left = Left(8)
    right = Right(7)
    assert left.case(lambda x: x+1, lambda x: x+2) == 8
    assert right.case(lambda x: x+1, lambda x: x+2) == 9


# Generated at 2022-06-21 19:03:41.652340
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> test_Either_to_lazy()
    0
    """
    def producing_something_complex_value() -> int:
        return 0

    res = Right(producing_something_complex_value).to_lazy()
    assert res.value() == 0



# Generated at 2022-06-21 19:03:50.336990
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(123).to_try() == Try(123, is_success=True)
    assert Either(-123).to_try() == Try(-123, is_success=True)
    assert Either('Hello World!').to_try() == Try('Hello World!', is_success=True)
    assert Either(True).to_try() == Try(True, is_success=True)
    assert Either(False).to_try() == Try(False, is_success=True)


# Generated at 2022-06-21 19:04:01.711829
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])
    assert Left('1').to_validation() == Validation.fail(['1'])
    assert Left(None).to_validation() == Validation.fail([None])
    assert Left(['1']).to_validation() == Validation.fail([['1']])
    assert Left([1]).to_validation() == Validation.fail([[1]])
    assert Left(['1', '2']).to_validation() == Validation.fail([['1', '2']])
    assert Left([1, 2, 3]).to_validation() == Validation.fail([[1, 2, 3]])

# Generated at 2022-06-21 19:04:05.063322
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    >>> assert Box(1) == Either(1).to_box()
    >>> assert Box(None) == Either(None).to_box()
    """
    pass


# Generated at 2022-06-21 19:04:06.655682
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: 2*x) == Left(3)


# Generated at 2022-06-21 19:04:14.500585
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x)) == Left(1)
    assert Left("error").bind(lambda x: Right(x)) == Left("error")
    assert Left(True).bind(lambda x: Right(x)) == Left(True)
    assert Left(float("nan")).bind(lambda x: Right(x)) == Left(float("nan"))
    assert Left(None).bind(lambda x: Right(x)) == Left(None)
    assert Left(collection.namedtuple("person", ["name", "age"])("Ivan", 19)).bind(lambda x: Right(x)) == Left(collection.namedtuple("person", ["name", "age"])("Ivan", 19))
    assert Left([]).bind(lambda x: Right(x)) == Left([])

# Generated at 2022-06-21 19:04:19.544522
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    err = "Error"
    left = Left(err)
    # When
    validation = left.to_validation()
    # Then
    assert validation.is_fail()
    assert isinstance(validation.failure, list)
    assert validation.failure == [err]


# Generated at 2022-06-21 19:04:21.358392
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(5).to_validation() == Validation.fail([5])
