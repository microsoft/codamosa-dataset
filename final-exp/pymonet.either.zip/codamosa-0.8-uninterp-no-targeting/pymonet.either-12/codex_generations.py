

# Generated at 2022-06-21 18:54:55.678395
# Unit test for method bind of class Left
def test_Left_bind():
    result = Left('text').bind(lambda x: x)
    assert isinstance(result, Left)
    assert result.value == 'text'



# Generated at 2022-06-21 18:55:01.746509
# Unit test for method bind of class Right
def test_Right_bind():
    # GIVEN
    def mapper(value):
        from pymonet.monad_try import Try

        if value == 'x':
            return Try('y')
        else:
            return Try(None)

    RIGHT = Right('x')

    # WHEN
    result = RIGHT.bind(mapper)

    # THEN
    assert Right('y') == result, 'result should be Right(y)'


# Generated at 2022-06-21 18:55:03.831613
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left('error')
    assert_equal(left.is_right(), False)



# Generated at 2022-06-21 18:55:05.578133
# Unit test for constructor of class Right
def test_Right():
    one = 1
    right_one = Right(one)

    assert right_one.value == one


# Generated at 2022-06-21 18:55:06.561347
# Unit test for constructor of class Left
def test_Left():
    assert Left(100).value == 100



# Generated at 2022-06-21 18:55:09.563322
# Unit test for method map of class Right
def test_Right_map():
    right_1 = Right(1)

    right_2 = right_1.map(lambda x: 2*x)

    assert right_1 == Right(1)
    assert right_2 == Right(2)


# Generated at 2022-06-21 18:55:10.801408
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-21 18:55:16.419902
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Right(2).to_lazy()
    assert Lazy(lambda: 2) == Left(2).to_lazy()


# Run tests
if __name__ == '__main__':
    test_Either_to_lazy()

# Generated at 2022-06-21 18:55:18.169785
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('right_value').is_right() is True



# Generated at 2022-06-21 18:55:26.261881
# Unit test for constructor of class Left
def test_Left():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Left(1) == Left(1)
    assert Left(1).is_left() is True
    assert Left(1).is_right() is False
    assert Left(1).to_maybe() == Maybe.nothing()
    assert Left(1).to_try() == Try(1, is_success=False)



# Generated at 2022-06-21 18:55:32.226470
# Unit test for method ap of class Left
def test_Left_ap():
    test_value = 'test'
    left = Left(test_value)
    right = right = lambda x: Right(x + 1)
    assert left.ap(right) == Left(test_value)
    assert left.ap(None) == Left(test_value)


# Generated at 2022-06-21 18:55:34.127316
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(5).to_validation() == Validation.success(5)



# Generated at 2022-06-21 18:55:36.915255
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(2)
    result = right.bind(lambda x: Right(x+1))

    assert isinstance(result, Right)
    assert result.value == 3



# Generated at 2022-06-21 18:55:38.663497
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:55:44.204617
# Unit test for method case of class Either
def test_Either_case():

    def inc(num): return num + 1

    def double(num): return num * 2

    left_1 = Left(1)
    right_1 = Right(1)

    assert left_1.case(inc, double) == inc(1)
    assert right_1.case(inc, double) == double(1)



# Generated at 2022-06-21 18:55:46.529828
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is False
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True



# Generated at 2022-06-21 18:55:55.216702
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda x: x+1, lambda x: x*2) == 2
    assert Either(1).case(lambda x: x-1, lambda x: x) == 1
    assert Left(1).case(lambda x: x+1, lambda x: x*2) == 2
    assert Left(1).case(lambda x: x-1, lambda x: x) == 0
    assert Right(1).case(lambda x: x+1, lambda x: x*2) == 2
    assert Right(1).case(lambda x: x-1, lambda x: x) == 1


# Generated at 2022-06-21 18:55:57.084783
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(10).is_right() is False


# Generated at 2022-06-21 18:55:57.894979
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left() is True


# Generated at 2022-06-21 18:56:00.769280
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    result = Right(1).to_validation().is_success()
    assert result == True


# Generated at 2022-06-21 18:56:06.097448
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Either.Right(42).is_left()


# Generated at 2022-06-21 18:56:07.746437
# Unit test for constructor of class Right
def test_Right():
    either = Right("success")
    assert either.value == "success"


# Generated at 2022-06-21 18:56:10.443039
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: x) == Left(2)


# Generated at 2022-06-21 18:56:12.458641
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    assert right.map(lambda x: x + 1).value == 2



# Generated at 2022-06-21 18:56:16.987186
# Unit test for constructor of class Either
def test_Either():
    assert Left(0) == Left(0)
    assert Left(0) != Right(0)
    assert Right(0) == Right(0)
    assert Right(0) != Left(0)
    assert Left(0) != Right(1)
    assert Right(1) != Left(0)
    assert Left(0) != Left(1)
    assert Right(0) != Right(1)

# Generated at 2022-06-21 18:56:20.111876
# Unit test for constructor of class Right
def test_Right():
    assert Right(True) == Right(True)
    assert Right(True) != Right(False)
    assert Right('x') == Right('x')
    assert Right('x') != Right('y')


# Generated at 2022-06-21 18:56:24.092655
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)
    assert Right(1).map(lambda x: x + 1).map(lambda x: x + 1) == Right(3)



# Generated at 2022-06-21 18:56:24.870313
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-21 18:56:27.381255
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1) == Right(1).to_validation()


# Generated at 2022-06-21 18:56:31.912367
# Unit test for constructor of class Either
def test_Either():

    assert Either(1) == Either(1)
    assert Either("foo") == Either("foo")
    assert Either(2) != Either(1)
    assert Either("bar") != Either(1)
    assert Either(1) != Either("foo")
    assert Either("foo") != Either("bar")



# Generated at 2022-06-21 18:56:45.466357
# Unit test for method case of class Either
def test_Either_case():
    def addition(num):
        return num + 10

    def substraction(num):
        return num - 10
    either_value = Either(10)
    right_result = Right(20)
    left_result = Left(-10)

    assert either_value.case(substraction, addition) == right_result.case(substraction, addition)
    assert either_value.case(substraction, addition) == right_result.case(substraction, addition)
    assert either_value.case(substraction, addition) == left_result.case(substraction, addition)
    assert either_value.case(substraction, addition) == left_result.case(substraction, addition)


# Generated at 2022-06-21 18:56:50.129195
# Unit test for method map of class Left
def test_Left_map():
    left_value = Left(5)
    new_left_value = left_value.map(lambda x: x + 10)
    assert left_value == new_left_value
    assert isinstance(new_left_value, Left)
    assert isinstance(new_left_value.value, int)
    assert new_left_value.value == 5



# Generated at 2022-06-21 18:56:52.473077
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    result = Left("error").to_validation()
    assert result.errors == ["error"], "Should be failures"



# Generated at 2022-06-21 18:56:56.600147
# Unit test for constructor of class Left
def test_Left():
    # Arrange
    _left: Left[str] = None

    # Act
    _left = Left('error')

    # Assert
    assert _left is not None
    assert _left.is_left() is True
    assert _left.is_right() is False
    assert _left.value == 'error'


# Generated at 2022-06-21 18:56:58.681987
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 18:56:59.740508
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:57:01.174662
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Either(None).is_right()
    assert Left(None).is_right()
    assert Right(None).is_right()


# Generated at 2022-06-21 18:57:06.221808
# Unit test for method map of class Right
def test_Right_map():
    """
    Given a Right monad with value
    When i run map function on it with any mapper
    Then returns Right monad with mapped value by given mapper
    """

    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-21 18:57:08.002926
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(0).is_right()



# Generated at 2022-06-21 18:57:09.577090
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:57:15.969554
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    right = Right(5)
    assert right.to_validation() == Validation.success(5)


# Generated at 2022-06-21 18:57:18.199843
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)



# Generated at 2022-06-21 18:57:19.963898
# Unit test for constructor of class Either
def test_Either():
    assert Either('test').value == 'test'


# Generated at 2022-06-21 18:57:24.913279
# Unit test for method case of class Either
def test_Either_case():
    # test case method on instance of Left
    assert Left('error').case(lambda x: x, lambda x: x + 'some') == 'error'
    # test case method on instance of Right
    assert Right('success').case(lambda x: x + 'some', lambda x: x) == 'success'



# Generated at 2022-06-21 18:57:27.820479
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(123).to_maybe() == Maybe.just(123)


# Generated at 2022-06-21 18:57:34.715620
# Unit test for method case of class Either
def test_Either_case():
    """
    Case should call only one function - success on Right or error on Left

    :returns: None
    :rtype: None
    """
    # checking left case
    test_left = Left(5)
    is_error_called = False
    is_success_called = False

    def error(value):
        nonlocal is_error_called
        assert value == 5
        is_error_called = True

    def success(value):
        nonlocal is_success_called
        assert value == 5
        is_success_called = True

    test_left.case(error, success)

    assert is_error_called and not is_success_called

    # checking right case
    test_right = Right(5)
    is_error_called = False
    is_success_called = False

    test_right.case

# Generated at 2022-06-21 18:57:40.149143
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_option import Option
    from pymonet.monad_try import Try

    assert Left([1,2,3]).ap(Option.just(lambda x: x[0])) == Left([1,2,3])
    assert Left([1,2,3]).ap(Option.nothing()) == Left([1,2,3])


# Generated at 2022-06-21 18:57:41.674222
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:57:42.718282
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False



# Generated at 2022-06-21 18:57:45.657961
# Unit test for constructor of class Left
def test_Left():
    value = 'error'
    left = Left(value)
    assert left.value == value


# Generated at 2022-06-21 18:57:51.777656
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)).value == 1
    assert Left(1).bind(lambda x: Left(x + 1)).value == 2


# Generated at 2022-06-21 18:57:53.236274
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)



# Generated at 2022-06-21 18:57:55.561883
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()
    assert Left('test').to_maybe() == Maybe.nothing()
    assert Left([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:58:00.117792
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left([0, 1])
    f = lambda x: Left(x)
    result = Left([0, 1]).bind(f)

    assert isinstance(result, Left)
    assert result.value == left.value


# Generated at 2022-06-21 18:58:01.824086
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(3)
    assert left.is_right() is False


# Generated at 2022-06-21 18:58:04.092553
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)


# Generated at 2022-06-21 18:58:11.507404
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)

    assert right.map(lambda x: x + 1) == Right(2),\
        "Expected Right(2), but got %s" % right.map(lambda x: x + 1)

    assert right.map(lambda x: x) == Right(1),\
        "Expected Right(1), but got %s" % right.map(lambda x: x)

    assert right.map(lambda x: x / 1) == Right(1),\
        "Expected Right(1), but got %s" % right.map(lambda x: x / 1)



# Generated at 2022-06-21 18:58:12.812631
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(5).is_right()
    assert Right(5).is_right()


# Generated at 2022-06-21 18:58:15.035903
# Unit test for constructor of class Left
def test_Left():
    assert Left('foo') == Left('foo')
    assert Left('foo') != Right(5)


# Generated at 2022-06-21 18:58:19.186236
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x)) == Right(1)
    assert Right(1).bind(lambda x: Right(2)) == Right(2)
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)


# Generated at 2022-06-21 18:58:36.116650
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))
    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))
    assert Left(1) == Left(1)
    assert not (Left(1) == Right(1))
    assert Left(1) == Left(1)
    assert not (Left(1) == 1)
    assert Right(1) == Right(1)
    assert not (Right(1) == Left(1))
    assert Right(1) == Right(1)

# Generated at 2022-06-21 18:58:37.628867
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('').is_right()


# Generated at 2022-06-21 18:58:40.128712
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Validation(5, []) == Right(5).to_validation()


# Generated at 2022-06-21 18:58:42.010958
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:58:43.257563
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(1).is_right() is True)



# Generated at 2022-06-21 18:58:44.844363
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(10).is_right() == True
    assert Left(10).is_right() == False


# Generated at 2022-06-21 18:58:45.737751
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-21 18:58:47.838245
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)
    validation = left.to_validation()
    assert validation.is_fail()
    assert validation.value == [1]


# Generated at 2022-06-21 18:58:49.105015
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()


# Generated at 2022-06-21 18:58:51.515379
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(5).to_maybe() == Maybe.nothing()
    assert Left([5]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 18:59:01.556340
# Unit test for constructor of class Right
def test_Right():
    # Given
    value = 'test'
    # When
    monad = Right(value)
    # Then
    assert monad.value == value


# Generated at 2022-06-21 18:59:07.733600
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert not Left(1) != Left(1)
    assert not Right(1) == Left(2)
    assert not Right(1) == Right(2)
    assert not Right(1) != Right(1)
    assert not Left(1) != Left(1)



# Generated at 2022-06-21 18:59:15.693788
# Unit test for method ap of class Either
def test_Either_ap():
    result = Right(3).ap(Right.of(lambda x: x * 2))
    assert result == Right(6)

    result2 = Right(3).ap(Left(None))
    assert result2 == Left(None)

    result3 = Left(None).ap(Right(lambda x: x * 2))
    assert result3 == Left(None)

    result4 = Left(None).ap(Left(lambda x: x * 2))
    assert result4 == Left(None)



# Generated at 2022-06-21 18:59:22.616608
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box().is_failure, "Failed instance of Either must be failure in Box."
    assert Left(1).to_box().value == 1, "Failed instance of Either must be failure in Box."
    assert Right(1).to_box().is_success, "Success instance of Either must be success in Box."
    assert Right(1).to_box().value == 1, "Success instance of Either must be success in Box."


# Generated at 2022-06-21 18:59:29.200733
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Test Either to_try"""

    # Test Either.to_try method
    def test_Either_to_try_method(a, b):
        assert a.to_try() == b

    # Test Either.to_try method on right value
    def test_Either_to_try_method_on_right(value):
        assert Right(value).to_try().is_success()
        assert Right(value).to_try().value == value

    # Test Either.to_try method on left value
    def test_Either_to_try_method_on_left(value):
        assert Left(value).to_try().is_error()
        assert Left(value).to_try().value == value

    # Test Either.to_try method on various input
    test_Either_to_try_method_on_right(1)

# Generated at 2022-06-21 18:59:32.361322
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try

    left = Left('test')
    assert left.ap(Try.just('test')) == left


# Generated at 2022-06-21 18:59:33.661029
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(2)

    assert right.is_right()



# Generated at 2022-06-21 18:59:35.827001
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left([1, 2, 3])
    assert left.to_validation() == Validation.fail([1, 2, 3])



# Generated at 2022-06-21 18:59:39.502550
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(2) == Either(2)

    assert Either(1) != Either(2)
    assert Either(2) != Either(1)

    assert Either(1) != None
    assert Either(2) != None


# Generated at 2022-06-21 18:59:45.491169
# Unit test for method ap of class Either
def test_Either_ap():
    def plus_one(a):
        return a + 1

    assert Left(1).ap(Left(1)) == Left(1)
    assert Left(1).ap(Right(2)) == Left(1)
    assert Right(1).ap(Left(2)) == Left(2)
    assert (Right(1) == Right(1).ap(Right(plus_one)))
    assert (Right(2) == Right(1).ap(Right(plus_one)))



# Generated at 2022-06-21 18:59:53.492514
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(0).is_right() is False



# Generated at 2022-06-21 18:59:56.189607
# Unit test for method case of class Either
def test_Either_case():
    assert Right(42).case(lambda x: x+1, lambda x: x) == 42
    assert Left(42).case(lambda x: x+1, lambda x: x) == 43



# Generated at 2022-06-21 18:59:58.507603
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(2)
    right = Right(2)

    assert left == left
    assert right == right
    assert left != right
    assert right != left

# Generated at 2022-06-21 19:00:01.515277
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(5).to_try() == Try(5, is_success=False)
    assert Right(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-21 19:00:04.109449
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(3).is_right() == False, 'Left should be not right'
    assert Right('abc').is_right() == True, 'Right should be right'


# Generated at 2022-06-21 19:00:05.366092
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-21 19:00:08.722565
# Unit test for method case of class Either
def test_Either_case():

    assert Left(2).case(error=lambda x: x, success=lambda x: x + 1) == 2
    assert Right(2).case(error=lambda x: x, success=lambda x: x + 1) == 3

# Generated at 2022-06-21 19:00:14.097328
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert not Left(1) == Right(1)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert not Right(1) == Left(1)


# Generated at 2022-06-21 19:00:20.465706
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.try_ import Try
    from pymonet.lazy import Lazy

    assert (Either(lambda x: x + 1).ap(Right(1)) == Right(2))
    assert (Either(lambda x: x + 1).ap(Left('error')) == Left('error'))
    assert (Either(lambda x: x + 1).ap(Try(1)) == Try(2))
    assert (Either(lambda x: x + 1).ap(Lazy(lambda: 1)) == Right(2))

# Generated at 2022-06-21 19:00:25.451786
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x, lambda _: 2) == 1
    assert Right(1).case(lambda _: 2, lambda x: x) == 1



# Generated at 2022-06-21 19:00:38.577752
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-21 19:00:39.833195
# Unit test for constructor of class Right
def test_Right():
    assert Right('Hello').value == 'Hello'



# Generated at 2022-06-21 19:00:44.391739
# Unit test for constructor of class Right
def test_Right():
    from pymonet.lazy import Lazy

    assert Right(2) == Right(2)
    assert Right.from_lazy(Lazy(lambda: 2)) == Right(2)
    assert Right(2) == Right.from_lazy(Lazy(lambda: 2))
    assert Right(3).value == 3



# Generated at 2022-06-21 19:00:52.335054
# Unit test for constructor of class Either
def test_Either():
    # should return Left[1]
    l = Left(1)
    assert isinstance(l, Either)
    assert isinstance(l, Left)
    assert l.value == 1
    # should return Right[1]
    r = Right(1)
    assert isinstance(r, Either)
    assert isinstance(r, Right)
    assert r.value == 1
    # should return Left[1]
    l = Either(1)
    assert isinstance(l, Either)
    assert isinstance(l, Left)
    assert l.value == 1


# Generated at 2022-06-21 19:00:56.085769
# Unit test for constructor of class Right
def test_Right():
    assert Right(None).value is None
    assert Right(True).value is True
    assert Right(1).value == 1
    assert Right('a').value == 'a'
    assert Right({}).value == {}
    assert Right([]).value == []
    assert Right(Right(None)).value == Right(None)
    assert Right(Left(None)).value == Left(None)


# Generated at 2022-06-21 19:00:59.982611
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    v = Right(1)
    assert v.to_box() == Box(1)

    v = Left(1)
    assert v.to_box() == Box(1)



# Generated at 2022-06-21 19:01:03.410276
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    v = Lazy(lambda: 'monad')
    assert Right(v).to_lazy() == v


# Generated at 2022-06-21 19:01:05.773607
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(3).to_maybe() == Maybe.just(3)


# Generated at 2022-06-21 19:01:08.166369
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(5)
    right = Right(lambda x: x * x)

    assert left.ap(right) == left


# Generated at 2022-06-21 19:01:09.946101
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 19:01:41.795980
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False


# Generated at 2022-06-21 19:01:44.053274
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(2).to_try() == Try(2, is_success=True)
    assert Either(Exception("Error")).to_try() == Try(Exception("Error"), is_success=False)



# Generated at 2022-06-21 19:01:46.288785
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    result = Right(1).to_validation()
    assert isinstance(result, Validation)
    assert result.value == [1] and result.is_fail() == False


# Generated at 2022-06-21 19:01:47.685024
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    either = Left(1)
    result = either.to_validation()
    assert result.is_fail() and result.value == [1]


# Generated at 2022-06-21 19:01:48.435687
# Unit test for constructor of class Right
def test_Right():
    assert isinstance(Right(1), Either)


# Generated at 2022-06-21 19:01:49.569739
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(None).is_left()


# Generated at 2022-06-21 19:01:50.751353
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 19:01:52.291891
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(0)

    assert left.to_validation().is_fail()


# Generated at 2022-06-21 19:01:53.797721
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:01:55.152455
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()

# Generated at 2022-06-21 19:03:01.467756
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert lambda: Right(1).is_right()


# Generated at 2022-06-21 19:03:04.468328
# Unit test for method to_box of class Either
def test_Either_to_box():
    result = Left("foo").to_box()
    assert isinstance(result, Box)
    result = Right("foo").to_box()
    assert isinstance(result, Box)
    assert result.value == 'foo'


# Generated at 2022-06-21 19:03:10.309252
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1.1).to_lazy() == Lazy(lambda: 1.1)
    assert Either(1.1).to_lazy().value() == 1.1
    assert Either("string").to_lazy() == Lazy(lambda: "string")
    assert Either("string").to_lazy().value() == "string"



# Generated at 2022-06-21 19:03:15.990621
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from typing import List
    from pymonet.validation import Validation

    success_full_validation = Right(1).to_validation()
    assert isinstance(success_full_validation, Validation), "Should return Validation monad instance"
    assert success_full_validation.is_success(), "Should return success validation"
    assert success_full_validation.value == 1, "Should return success validation with value"



# Generated at 2022-06-21 19:03:18.214984
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False


# Generated at 2022-06-21 19:03:22.277157
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(
        error=lambda a: a + 1,
        success=lambda a: a - 1
    ) == 1
    assert Left(1).case(
        error=lambda a: a + 1,
        success=lambda a: a - 1
    ) == 2



# Generated at 2022-06-21 19:03:28.838858
# Unit test for constructor of class Right
def test_Right():
    assert Right('right') == Right('right')
    assert Right('right') != Right('wrong')
    assert Right('right').value == 'right'
    assert Right('right') == Right(Right('right').value)
    assert Right(Right('right').value).value == 'right'
    assert Right(Right(Right('right').value).value).value == 'right'
    assert Right('right').is_right() is True
    assert Right('right').is_left() is False


# Generated at 2022-06-21 19:03:30.019832
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(3).is_left()



# Generated at 2022-06-21 19:03:32.872834
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)
    assert Right(2).to_validation() == Validation.success(2)



# Generated at 2022-06-21 19:03:37.041164
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.Right(1).to_try().get_or_else(0) == 1
    assert Either.Left(Exception('error')).to_try().get_or_else(0) == 0
