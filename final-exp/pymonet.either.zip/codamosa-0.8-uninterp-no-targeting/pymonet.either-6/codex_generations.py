

# Generated at 2022-06-21 18:54:55.931588
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left() is True



# Generated at 2022-06-21 18:55:03.970931
# Unit test for method case of class Either
def test_Either_case():
    """
    This method test case method of class Either.
    """
    either_left: Either[str] = Left('Error')
    either_right: Either[str] = Right('Right')

    assert either_left.case(lambda err: '{} value'.format(err), lambda suc: '{} value'.format(suc)) == 'Error value'
    assert either_right.case(lambda err: '{} value'.format(err), lambda suc: '{} value'.format(suc)) == 'Right value'



# Generated at 2022-06-21 18:55:06.462963
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)

    def fn(x: int) -> Either[int]:
        return Right(x * 2)
    assert left.bind(fn) == left



# Generated at 2022-06-21 18:55:13.692010
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    assert Left(Box(lambda x: x + ' error')).ap(Left('An')) == Left('An error')
    assert Left(Box(lambda x: x + ' error')).ap(Right('An')) == Left('An error')
    assert Right(Box(lambda x: x + ' error')).ap(Left('An')) == Left('An error')
    assert Right(Box(lambda x: x + ' error')).ap(Right('An')) == Right('An error')

# Generated at 2022-06-21 18:55:15.942717
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False


# Generated at 2022-06-21 18:55:18.372283
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-21 18:55:22.987314
# Unit test for constructor of class Either
def test_Either():
    assert Either(1).value == 1
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either("1")


# Generated at 2022-06-21 18:55:27.017691
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Right(1).to_maybe()



# Generated at 2022-06-21 18:55:28.956405
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(None).is_right() == True


# Generated at 2022-06-21 18:55:32.567527
# Unit test for constructor of class Right
def test_Right():
    value = 5
    new_instance = Right(value)
    assert new_instance.value == value
    assert new_instance.is_right() is True
    assert new_instance.is_left() is False


# Generated at 2022-06-21 18:55:45.832904
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # test return correct value when other not instance of class Either
    assert Left(1) != 1

    # test return correct value when other is instance of class Either but isn't instance of Left
    assert Left(1) != Right(1)

    # test return correct value when other is instance of class Either and instance of Left but have different value
    assert Left(1) != Left(2)

    # test return correct value when other is instance of class Either and instance of Left and have same value
    assert Left(1) == Left(1)

    # test return correct value when other not instance of class Either
    assert Right(1) != 1

    # test return correct value when other is not instance of class Either but is instance of Right
    assert Right(1) != Left(1)

    # test return correct value when other is instance of Both and instance of Right but have different value


# Generated at 2022-06-21 18:55:48.119205
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() is True


# Generated at 2022-06-21 18:55:49.653833
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('Error message')

    assert left.is_left()

# Generated at 2022-06-21 18:55:52.079393
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:55:55.173841
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.functor import Functor

    f = Functor(lambda value: value * 2)

    assert f.ap(Right(1)) == 2
    assert f.ap(Left(1)) == 1



# Generated at 2022-06-21 18:55:57.033673
# Unit test for constructor of class Left
def test_Left():
    assert Left("test").value == "test"



# Generated at 2022-06-21 18:55:58.896131
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(0)
    assert right.is_left() == False


# Generated at 2022-06-21 18:56:00.354378
# Unit test for method is_left of class Left
def test_Left_is_left():
    result = Left(1).is_left()
    assert result == True



# Generated at 2022-06-21 18:56:01.519974
# Unit test for constructor of class Right
def test_Right():
    assert Right(1)



# Generated at 2022-06-21 18:56:02.679460
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left("A")
    assert left.to_validation() == Validation.fail(["A"])



# Generated at 2022-06-21 18:56:07.186989
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right("Hello").is_left()



# Generated at 2022-06-21 18:56:10.342001
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right('test').to_maybe() == Maybe.just('test')


# Generated at 2022-06-21 18:56:13.120976
# Unit test for constructor of class Left
def test_Left():
    # Given
    error = 'error'
    # When
    result = Left(error)
    # Then
    assert result.value == error



# Generated at 2022-06-21 18:56:14.286035
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either.to_box()(Left(None)) == Box(None)


# Generated at 2022-06-21 18:56:18.134890
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left('error').to_try() == Try('error', is_success=False)


# Generated at 2022-06-21 18:56:20.921460
# Unit test for method is_right of class Right
def test_Right_is_right():
    from pymonet.monad_test import assert_right, assert_left

    assert_right(Right(False).is_right())
    assert_left(Right(False).is_left())



# Generated at 2022-06-21 18:56:23.544029
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(10) == Right(10).to_try().to_either()
    assert Left("error") == Left("error").to_try().to_either()



# Generated at 2022-06-21 18:56:25.854427
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-21 18:56:30.250250
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    box = Box(lambda e: e**2)
    assert box.ap(Either.unit(3)) == Box(9)
    assert Either.unit(3).ap(box) == Box(9)


# Generated at 2022-06-21 18:56:34.705288
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.either import Left
    from pymonet.either import Right

    assert Left(1).to_try() == Failure(1)
    assert Right(1).to_try() == Success(1)

# Generated at 2022-06-21 18:56:41.704184
# Unit test for method case of class Either
def test_Either_case():
    assert Left(64).case(lambda x: x**2, lambda x: x**0.5) == 64
    assert Right(64).case(lambda x: x**2, lambda x: x**0.5) == 8


# Generated at 2022-06-21 18:56:49.723470
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box().is_left()
    assert Left(1).to_box().value == 1
    assert Left(1).to_box().map(lambda x: x+1).is_left()
    assert Left(1).to_box().map(lambda x: x+1).value == 2

    assert Right(1).to_box().is_right()
    assert Right(1).to_box().value == 1
    assert Right(1).to_box().map(lambda x: x+1).is_right()
    assert Right(1).to_box().map(lambda x: x+1).value == 2




# Generated at 2022-06-21 18:56:51.086293
# Unit test for method map of class Left
def test_Left_map():
    left1 = Left(1)
    left2 = left1.map(lambda value: value + 2)
    assert left1 == left2



# Generated at 2022-06-21 18:56:52.664201
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right()


# Generated at 2022-06-21 18:56:54.444214
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(3)
    assert left.ap(Either.left(4)) == Left(3)



# Generated at 2022-06-21 18:57:01.824764
# Unit test for constructor of class Either
def test_Either():
    error = Left(1)
    success = Right(2)
    assert error == error
    assert success == success
    assert error != success
    assert isinstance(error, Either)
    assert isinstance(success, Either)
    assert error.is_left()
    assert not error.is_right()
    assert success.is_right()
    assert not success.is_left()
    assert success.to_maybe() == Maybe.just(2)
    assert success.to_validation() == Validation.success(2)
    assert error.to_maybe() == Maybe.nothing()
    assert error.to_validation() == Validation.fail([1])
    assert success.case(lambda x: x, lambda x: x + 1) == 3
    assert error.case(lambda x: x, lambda x: x + 1) == 1

# Generated at 2022-06-21 18:57:04.564834
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    import pymonet.maybe
    assert Left(None).to_maybe() == pymonet.maybe.Maybe.nothing()


# Generated at 2022-06-21 18:57:06.835731
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-21 18:57:09.070170
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: x * 2) == 6
    # TODO: test errors



# Generated at 2022-06-21 18:57:11.072939
# Unit test for constructor of class Either
def test_Either():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)


# Generated at 2022-06-21 18:57:21.179476
# Unit test for method case of class Either
def test_Either_case():
    # Success case
    result = Right(2).case(lambda x: 'Error', lambda x: 'Success')
    assert result == 'Success'

    # Failure case
    result = Left('Error').case(lambda x: 'Error', lambda x: 'Success')
    assert result == 'Error'



# Generated at 2022-06-21 18:57:23.499320
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda e: e, lambda s: s + 1) == 2


# Generated at 2022-06-21 18:57:33.021412
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def f(x: int) -> Either[str]:
        if x > 5:
            return Right(x)
        return Left('out of range')

    assert Right(6).bind(f) == Right(6)
    assert Right(6).bind(f).to_maybe() == Maybe.just(6)
    assert Right(6).bind(f).to_validation() == Validation.success(6)

    assert Right(1).bind(f) == Left('out of range')
    assert Right(1).bind(f).to_maybe() == Maybe.nothing()
    assert Right(1).bind(f).to_validation() == Validation.fail(['out of range'])


# Generated at 2022-06-21 18:57:38.463705
# Unit test for method case of class Either
def test_Either_case():
    # T is a Right when it is a Right
    assert Right(2).case(
        lambda _: 0,
        lambda value: value
    ) == 2
    # T is a Left when it is a Left
    assert Left(2).case(
        lambda value: value,
        lambda _: 0
    ) == 2


# Generated at 2022-06-21 18:57:41.431014
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Left(1) == Left(1))
    assert(Right(1) == Right(1))
    assert(Left(1) != Right(1))
    assert(Left(1) != 1)

# Generated at 2022-06-21 18:57:52.328542
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).is_right()
    assert Right(3).case(
        error = lambda x: None,
        success = lambda x: x
    ) == 3
    assert Right(3) == Right(3)
    assert Right(3).to_maybe() == Maybe.just(3)
    assert Right(3).to_validation() == Validation.success(3)
    assert Right(3).to_try() == Try(3, True)
    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_box() == Box(3)
    assert Right(3).bind(lambda x : Right(x + 1)) == Right(4)
    assert Right(3).map(lambda x : x + 1) == Right(4)

# Generated at 2022-06-21 18:57:53.454792
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(1)) == Left(1)


# Generated at 2022-06-21 18:57:56.289378
# Unit test for constructor of class Right
def test_Right():
    # Test for constructor of class Right
    assert Right(1) == Right(1)
    assert Right(1).value == 1
    assert Right(1).is_right()


# Generated at 2022-06-21 18:57:59.543762
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() is False
    assert right.is_right() is True


# Generated at 2022-06-21 18:58:03.116692
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.either import Left, Right

    assert Right(1).to_try() == Success(1)
    assert Left(1).to_try() == Failure(1)


# Generated at 2022-06-21 18:58:15.692460
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Just(1)


# Generated at 2022-06-21 18:58:19.039901
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.monad_test import assert_maybe
    from pymonet.maybe import Maybe

    assert_maybe(Left(1).to_maybe(), Maybe.nothing())



# Generated at 2022-06-21 18:58:21.492734
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:58:23.653008
# Unit test for constructor of class Right
def test_Right():
    actual = Right(8)
    expected = Right(8)

    assert actual == expected



# Generated at 2022-06-21 18:58:26.516664
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test for method bind of class Right
    """
    assert Right(1).bind(lambda x: Right(x)).bind(lambda x: Right(x + 1)) == Right(2)

# Generated at 2022-06-21 18:58:31.281233
# Unit test for method is_left of class Left
def test_Left_is_left():
    """
    >>> test_Left_is_left()
    True
    """

    return Left(3).is_left()


# Generated at 2022-06-21 18:58:37.437654
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Either(1), Either[int])
    assert isinstance(Either('a'), Either[str])
    assert isinstance(Either(1.1), Either[float])
    assert isinstance(Either((1, 2)), Either[tuple])
    assert isinstance(Either({'a': 1, 'b': 2}), Either[dict])
    assert isinstance(Either([]), Either[list])
    assert isinstance(Either(set()), Either[set])
    assert isinstance(Either(bytearray('test', 'utf-8')), Either[bytearray])
    assert isinstance(Either(1 + 1j), Either[complex])
    assert isinstance(Either(True), Either[bool])
    assert isinstance(Either(None), Either[None])


# Generated at 2022-06-21 18:58:39.758188
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)



# Generated at 2022-06-21 18:58:43.257403
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right('aaa').bind(lambda s: Right(s.upper())).value == 'AAA'
    assert Right('aaa').bind(lambda s: Left('Error: ' + s)).value == 'Error: aaa'



# Generated at 2022-06-21 18:58:45.666660
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    validation = Validation.fail(['bad thing happened'])

    assert Left(23).to_validation() == validation


# Generated at 2022-06-21 18:59:10.403772
# Unit test for constructor of class Left
def test_Left():
    assert Left(10) == Left(10)
    assert Left(10) != Right(10)


# Generated at 2022-06-21 18:59:11.902264
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(100).is_right() is True



# Generated at 2022-06-21 18:59:13.748183
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:59:15.693972
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(-1)) == Left(1)



# Generated at 2022-06-21 18:59:18.076485
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def value():
        return 5

    lazy = Either(value).to_lazy()

    assert lazy.eval() == 5



# Generated at 2022-06-21 18:59:19.836304
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() == True


# Generated at 2022-06-21 18:59:20.742124
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:59:23.338391
# Unit test for method map of class Left
def test_Left_map():
    # Given
    left = Left(1)

    # When
    result = left.map(lambda x: x * x)

    # Then
    assert result == left


# Generated at 2022-06-21 18:59:25.089363
# Unit test for method map of class Right
def test_Right_map():
    result = Right(1).map(lambda x: x + 1)
    expected = Right(2)
    assert result == expected, "Right.map result is not expected"


# Generated at 2022-06-21 18:59:26.756396
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left("error").to_validation() == Validation([("error")])


# Generated at 2022-06-21 18:59:52.173944
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def test():
        assert Left(3) == Left(3)
        assert Right(3) == Right(3)

    test()


# Generated at 2022-06-21 18:59:56.691406
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Either to Try

    Left[A] -> Try[A]
    Right[A] -> Try[A]
    """
    from pymonet.monad_try import Try
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 19:00:00.143539
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])
    assert Left(2).to_validation() == Validation.fail([2])



# Generated at 2022-06-21 19:00:02.981920
# Unit test for method case of class Either
def test_Either_case():

    assert Left(2).case(lambda l: l + 1, lambda r: r + 1) == 3
    assert Right(1).case(lambda l: l + 1, lambda r: r + 1) == 2



# Generated at 2022-06-21 19:00:05.678081
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left("I'm an error").to_validation() == Validation.fail(['I\'m an error'])


# Generated at 2022-06-21 19:00:08.240399
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:00:13.677142
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 6) == Either.to_lazy("value")
    assert Lazy(lambda: "value") == Either.to_lazy("value")
    assert Lazy(lambda: 6) == Either.to_lazy(6)



# Generated at 2022-06-21 19:00:18.390346
# Unit test for constructor of class Either
def test_Either():
    right = Right(0)
    left = Left(Exception('error'))

    assert right == Right(0)
    assert right != right.map(lambda x: x + 1)
    assert right != left
    assert right != Exception('error')
    assert right.value == 0
    assert left.value.args[0] == 'error'



# Generated at 2022-06-21 19:00:21.585516
# Unit test for constructor of class Left
def test_Left():
    left = Left("Error")
    assert left.is_left()
    assert not left.is_right()

    left = Left("Error")
    right = Left("Error")
    assert left == right

    assert left.case(lambda e: e, lambda s: s) == "Error"



# Generated at 2022-06-21 19:00:25.827701
# Unit test for constructor of class Left
def test_Left():
    left = Left(42)

    assert left.value == 42
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-21 19:00:51.468234
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:00:53.200088
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left('err') != Right(1)



# Generated at 2022-06-21 19:00:54.857161
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1).to_maybe()
    assert(right.value == 1)
    assert(right.is_just())



# Generated at 2022-06-21 19:00:56.948164
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 19:00:59.145563
# Unit test for method ap of class Left
def test_Left_ap():
    actual = Left('error').ap(Left('success'))
    expected = Left('error')

    assert expected == actual


# Generated at 2022-06-21 19:01:00.805434
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 19:01:02.701861
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(0).is_left() == True


# Generated at 2022-06-21 19:01:04.373194
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Right(1).to_lazy()


# Generated at 2022-06-21 19:01:07.162571
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:01:12.239232
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Right(True).to_box() == Box(True)
    assert Right('a').to_box() == Box('a')
    assert Left(1).to_box() == Box(1)
    assert Left(True).to_box() == Box(True)
    assert Left('a').to_box() == Box('a')


# Generated at 2022-06-21 19:02:08.393860
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(1).to_maybe()



# Generated at 2022-06-21 19:02:10.125661
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Prepare test data
    right = Right(3)

    # Run test scenario
    assert right.to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-21 19:02:13.253819
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)


# Generated at 2022-06-21 19:02:16.576233
# Unit test for method bind of class Right
def test_Right_bind():
    """Test method bind of class Right."""

    # Given
    right = Right(1)

    # When
    result = right.bind(lambda value: Right(value + 1))

    # Then
    assert result == Right(2)



# Generated at 2022-06-21 19:02:17.716455
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('error').ap(Right('success')) == Left('error')

# Generated at 2022-06-21 19:02:18.709901
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("test").is_left()


# Generated at 2022-06-21 19:02:19.681855
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() is False


# Generated at 2022-06-21 19:02:20.827373
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:02:26.362842
# Unit test for method bind of class Right
def test_Right_bind():
    def even(value):
        return Left(value) if value % 2 != 0 else Right(value)
    assert Right(4).bind(even) == Right(4)
    assert Right(5).bind(even) == Left(5)



# Generated at 2022-06-21 19:02:27.816503
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(1)) == Left(1)



# Generated at 2022-06-21 19:03:29.518984
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(-9).is_right()


# Generated at 2022-06-21 19:03:36.238722
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    from pymonet.monad_test_helpers import TEST_MONAD_FUNCTIONS, test_monad_function, TEST_MONAD_LAWS, get_test_elements

    test_monad_function(
        'to_lazy',
        Either.to_lazy,
        'Left(1).to_lazy()',
        Lazy(lambda: 1),
        TEST_MONAD_FUNCTIONS['to_lazy']['Left'](1))

# Generated at 2022-06-21 19:03:38.714266
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:03:44.871233
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.monad_test_helpers import deep_eq
    from pymonet.monad_test_helpers import throws

    assert deep_eq(
        Left(0).is_left(),
        True
    )

    assert throws(
            lambda: deep_eq(
                Left(0).is_right(),
                True
            )
    )



# Generated at 2022-06-21 19:03:46.939828
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(5)
    assert right.is_left() is False


# Generated at 2022-06-21 19:03:49.863703
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    # given
    right = Right(1)

    # when - then
    assert right.to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:03:52.874531
# Unit test for method case of class Either
def test_Either_case():
    cases = [
        ((Right, lambda _: 'right'), 'right'),
        ((Left, lambda _: 'left'), 'left'),
    ]
    for case in cases:
        left = case[0][0](case[0][1])
        error = case[1]
        assert left.case(lambda x: 'right', lambda x: error) == error



# Generated at 2022-06-21 19:03:54.800959
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True



# Generated at 2022-06-21 19:04:01.010992
# Unit test for method to_try of class Either
def test_Either_to_try():
    # Given
    either = Right(1)

    # When
    result = either.to_try()

    # Then
    assert isinstance(result, Try)
    assert result.is_success()
    assert result.get() == 1

    # Given
    either = Left(1)

    # When
    result = either.to_try()

    # Then
    assert isinstance(result, Try)
    assert not result.is_success()



# Generated at 2022-06-21 19:04:08.764635
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    applicative = Right(lambda x: x * 2)

    # When
    # Then
    print(Right(4).ap(applicative).value)
    assert Right(4).ap(applicative) == Right(8)
    assert Left(10).ap(applicative) == Left(10)
    assert Left(10).ap(Left('A')) == Left(10)
    assert Right(4).ap(Left('A')) == Left('A')

