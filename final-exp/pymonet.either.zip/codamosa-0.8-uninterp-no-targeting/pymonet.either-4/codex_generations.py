

# Generated at 2022-06-21 18:54:46.970247
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    left = Left([1, 2, 3])

    # When
    actual = left.to_validation()

    # Then
    assert actual.is_fail()
    assert actual.value == [1, 2, 3]


# Generated at 2022-06-21 18:54:48.330390
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1)
    assert right.to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:54:49.331401
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(5).is_left()



# Generated at 2022-06-21 18:54:50.311695
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-21 18:54:53.450850
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right('yup').bind(lambda _: Right('nope')) == Right('nope')
    assert Right('yup').bind(lambda value: Left('nope' + value)) == Left('nopenope')




# Generated at 2022-06-21 18:54:56.407908
# Unit test for method case of class Either
def test_Either_case():

    # GIVEN
    e = Left(10)

    # WHEN
    res = e.case(lambda x: x ** 2, lambda x: x ** 3)

    # THEN
    assert(res == 100)



# Generated at 2022-06-21 18:54:58.043030
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Left(lambda x: x * 2)) == Left(2)



# Generated at 2022-06-21 18:55:03.619530
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)


# Generated at 2022-06-21 18:55:06.111133
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(100).to_try() == Try(100, True)
    assert Left(100).to_try() == Try(100, False)



# Generated at 2022-06-21 18:55:09.070187
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Successful test of Right bind method
    """
    either = Right(5)
    value = either.bind(lambda x: x * 2)
    assert value == 10, 'Right bind method test fail'


# Generated at 2022-06-21 18:55:14.195536
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(10) == Right(10).to_maybe()



# Generated at 2022-06-21 18:55:16.764728
# Unit test for method map of class Left
def test_Left_map():
    left = Left('abc')
    assert left.map(lambda x: 'a' * len(x)) == left


# Generated at 2022-06-21 18:55:23.698908
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)
    assert Right('abc').to_validation() == Validation.success('abc')


# Generated at 2022-06-21 18:55:26.102259
# Unit test for constructor of class Right
def test_Right():
    assert Right(3) == Right(3)



# Generated at 2022-06-21 18:55:28.503588
# Unit test for method is_left of class Left
def test_Left_is_left():
    l = Left('not successful value')

    assert l.is_left() is True



# Generated at 2022-06-21 18:55:29.574360
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert(Left(True).is_right() == False)

# Generated at 2022-06-21 18:55:30.697269
# Unit test for constructor of class Right
def test_Right():
    assert Right(2) == Right(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-21 18:55:34.600239
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.lazy import Lazy

    result = Right(42)\
        .bind(lambda x: Left(x + 5))\
        .bind(Lazy(lambda y: Left(y + 5)))

    assert result == Left(52)



# Generated at 2022-06-21 18:55:35.929012
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(4).is_left() is True


# Generated at 2022-06-21 18:55:38.422224
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left("value").bind(lambda v: Right("another_value")) == Left("value")
    assert Left("value").bind(lambda v: Left("another_value")) == Left("value")



# Generated at 2022-06-21 18:55:43.830274
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try().is_success()
    assert Left(1).to_try().is_success() == False

test_Either_to_try()


# Generated at 2022-06-21 18:55:46.671486
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(None).to_box() == Box(None)
    assert Left(None).to_box() == Box(None)
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)



# Generated at 2022-06-21 18:55:52.538808
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    try_obj = Try(1)
    either_obj = Right(1)
    assert either_obj.to_try() == try_obj

    try_obj = Try(1, is_success=False)
    either_obj = Left(1)
    assert either_obj.to_try() == try_obj



# Generated at 2022-06-21 18:55:57.242498
# Unit test for method map of class Left
def test_Left_map():
    # Given
    value = 'value'
    mapper = lambda x: x + x
    either = Left(value)

    # When
    result = either.map(mapper)

    # Then
    assert isinstance(result, Left)
    assert result == Left(value)



# Generated at 2022-06-21 18:55:59.552996
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:56:02.161875
# Unit test for method to_validation of class Left
def test_Left_to_validation():

    from pymonet.validation import Validation

    assert Left.to_validation(Left(1)) == Validation.fail([1])



# Generated at 2022-06-21 18:56:04.606184
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Right(13).to_lazy()
    assert isinstance(result, Lazy)
    assert result() == 13

    result = Left(13).to_lazy()
    assert isinstance(result, Lazy)
    assert result() == 13



# Generated at 2022-06-21 18:56:15.850114
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def fn1(x):
        return x + 2

    def fn2(x):
        return x * 3

    result = Either.unit(2).ap(Lazy(fn1)).ap(Lazy(fn2))
    assert result.case(lambda _: False, lambda x: x == 12)
    result = Either.unit(2).ap(Lazy(fn1)).ap(Box(fn2))
    assert result.case(lambda _: False, lambda x: x == 12)
    result = Either.unit(2).ap(Box(fn1)).ap(Box(fn2))
    assert result.case(lambda _: False, lambda x: x == 12)
    result = Either

# Generated at 2022-06-21 18:56:17.253546
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() == False


# Generated at 2022-06-21 18:56:18.757374
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-21 18:56:23.247291
# Unit test for method map of class Right
def test_Right_map():

    def add_one(value: int) -> int: return value + 1

    assert (Right(2).map(add_one)) == Right(3)



# Generated at 2022-06-21 18:56:28.205257
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    right = Right(lambda x: x + 1)
    assert left.ap(right) == left
    left = Left(1)
    right = Left(lambda x: x + 1)
    assert left.ap(right) == left


# Generated at 2022-06-21 18:56:29.975205
# Unit test for constructor of class Left
def test_Left():
    left = Left(9)
    assert left == Left(9)


# Generated at 2022-06-21 18:56:32.031059
# Unit test for method ap of class Either
def test_Either_ap():
    # ap for Right
    assert Either.ap(Right(lambda x: x + 1), Right(1)) == Right(2)
    # ap for Left
    assert Either.ap(Left(lambda x: x + 1), Left(1)) == Left(1)

# Generated at 2022-06-21 18:56:32.965141
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right()

# Generated at 2022-06-21 18:56:35.155099
# Unit test for method is_right of class Either
def test_Either_is_right():
    either = Right[int](1)
    assert either.is_right()

    either = Left[int](1)
    assert not either.is_right()


# Generated at 2022-06-21 18:56:38.938629
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()
    assert Left('some').to_maybe() == Maybe.nothing()
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:56:40.469670
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("hello").is_right() == True


# Generated at 2022-06-21 18:56:46.042639
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import SUCCESS
    from pymonet.monad_try import FAILURE

    assert Right("OK").to_try() == \
        Try("OK", is_success=True)
    assert Left("Error").to_try() == \
        Try("Error", is_success=False)


# Generated at 2022-06-21 18:56:47.662275
# Unit test for constructor of class Left
def test_Left():
    assert Left(100).case(lambda x: x + 1, lambda _: 0) == 101



# Generated at 2022-06-21 18:56:51.333037
# Unit test for method map of class Left
def test_Left_map():
    assert Left(None).map(lambda x: x) == Left(None)


# Generated at 2022-06-21 18:56:52.907234
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right("test").is_left() == False


# Generated at 2022-06-21 18:56:54.617445
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda a: a + 1) == Right(3)



# Generated at 2022-06-21 18:57:00.590889
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.nothing import Nothing
    from pymonet.error import Error
    from pymonet.monad_try import Try

    assert Right(1).to_try() == Try(1)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Left(Nothing()).to_try() == Try(Nothing(), is_success=False)
    assert Left(Error('Ups, something went wrong')).to_try() == Try(Error('Ups, something went wrong'), is_success=False)


# Generated at 2022-06-21 18:57:04.369576
# Unit test for method bind of class Left
def test_Left_bind():
    # GIVEN
    left = Left(15)

    # WHEN
    result = left.bind(lambda x: x * 2)

    # THEN
    assert left == result



# Generated at 2022-06-21 18:57:07.035589
# Unit test for method map of class Left
def test_Left_map():
    left = Left(2)
    assert left.map(lambda value: value + 1) == left


# Generated at 2022-06-21 18:57:09.676465
# Unit test for method is_left of class Right
def test_Right_is_left():
    monad = Right(42)
    assert isinstance(monad, Either)
    assert not monad.is_left()



# Generated at 2022-06-21 18:57:14.183146
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Left("error").ap(Box(lambda x: x)) == Left("error")
    assert Left("error").ap(Try(lambda x: x)) == Left("error")

# Generated at 2022-06-21 18:57:15.945921
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-21 18:57:18.918947
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(10).bind(lambda x: Right(x * 2)) == Right(20)
    assert Right("black").bind(lambda x: Right(x + " square")) == Right("black square")



# Generated at 2022-06-21 18:57:25.162360
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(3).to_validation() == Validation.fail([3])


# Generated at 2022-06-21 18:57:28.023127
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda value: value + 1) == Left(1)



# Generated at 2022-06-21 18:57:29.188994
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-21 18:57:32.000053
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(5).to_try() == Try(5, is_success=True)
    assert Left(5).to_try() == Try(5, is_success=False)

# Generated at 2022-06-21 18:57:33.631140
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(2).is_left()



# Generated at 2022-06-21 18:57:35.017530
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    Test that when we convert Right to Maybe we get Maybe.Just with previous value.
    """
    right = Right(1)

    maybe = right.to_maybe()

    assert maybe.value == 1

# Generated at 2022-06-21 18:57:37.950011
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    left = Left(12)
    assert left.to_validation() == Validation.fail([12])


# Generated at 2022-06-21 18:57:40.983368
# Unit test for constructor of class Left
def test_Left():
    assert Left(2) == Left(2)
    assert Left(2) != Left(3)
    assert Left(3) != Left(2)
    assert Left(3) == Left(3)


# Generated at 2022-06-21 18:57:42.978740
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:57:53.597837
# Unit test for method case of class Either
def test_Either_case():
    """ Unit test for method case of class Either
    """

    test_error_handling_function = lambda _: 'error'
    test_success_handling_function = lambda x: 'success'

    assert(Left('error value').case(test_error_handling_function, test_success_handling_function)
           == 'error')
    assert(Left(1).case(test_error_handling_function, test_success_handling_function) == 'error')
    assert(Left('1').case(test_error_handling_function, test_success_handling_function) == 'error')
    assert(Left([]).case(test_error_handling_function, test_success_handling_function) == 'error')

# Generated at 2022-06-21 18:58:07.097381
# Unit test for method case of class Either
def test_Either_case():
    def sum_may_fail(val):
        if val % 2 == 0:
            return Right(val + 5)
        return Left(str(val) + " is odd")

    assert sum_may_fail(2).case(error=lambda x: x, success=lambda x: x) == 7
    assert sum_may_fail(3).case(error=lambda x: x, success=lambda x: x) == "3 is odd"


# Generated at 2022-06-21 18:58:11.874934
# Unit test for method to_box of class Either
def test_Either_to_box():
    def assert_to_box(either, expected):
        actual = either.to_box()

        assert isinstance(actual, expected)
        assert actual.value == either.value

    left = Left(1)
    assert_to_box(left, Box)

    right = Right(2)
    assert_to_box(right, Box)


# Generated at 2022-06-21 18:58:14.105626
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(100).to_validation() == Validation.success(100)



# Generated at 2022-06-21 18:58:17.133097
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    expected = Validation.fail(['left value'])
    result = Left('left value').to_validation()
    assert(expected == result)



# Generated at 2022-06-21 18:58:22.690584
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.box import Box

    right = Right(Box('value'))
    validation = right.to_validation()

    assert validation.is_success() is True
    assert validation.is_fail() is False
    assert validation.success == 'value'
    assert validation.fail == []


# Generated at 2022-06-21 18:58:24.631995
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left("error").to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:58:27.004459
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 18:58:30.799631
# Unit test for method ap of class Either
def test_Either_ap():
    class Add:
        def __init__(self, value):
            self.value = value

        def __call__(self, other):
            return self.value + other

    add5 = Add(5)

    assert Right(1).ap(add5).bind(lambda x: Right(x == 6))
    assert not Left(3).ap(add5).bind(lambda x: Right(x == 6))

# Generated at 2022-06-21 18:58:32.722841
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either"""
    assert Either(1) is not None



# Generated at 2022-06-21 18:58:34.995746
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-21 18:58:45.103363
# Unit test for constructor of class Right
def test_Right():
    right = Right(10)
    assert right.value == 10
    assert right.is_right() is True
    assert right.is_left() is False


# Generated at 2022-06-21 18:58:46.283232
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("foo").is_left()


# Generated at 2022-06-21 18:58:47.973597
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)

# Unit tests for method case of class Either

# Generated at 2022-06-21 18:58:50.828908
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)


# Generated at 2022-06-21 18:58:52.599135
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(1)
    from pymonet.maybe import Maybe
    assert left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:58:59.000385
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test if can transform Left[A]
    left = Left(5)
    assert(left.to_lazy() == Lazy(lambda: left.value))

    # Test if can transform Right[A]
    right = Right(5)
    assert(right.to_lazy() == Lazy(lambda: right.value))



# Generated at 2022-06-21 18:59:02.123159
# Unit test for method to_box of class Either
def test_Either_to_box():
    right = Right(2)
    left = Left(1)
    assert right.to_box() == Box(2)
    assert left.to_box() == Box(1)


# Generated at 2022-06-21 18:59:04.611174
# Unit test for method is_left of class Left
def test_Left_is_left():
    # Arrange
    left = Left(4)

    # Act
    result = left.is_left()

    # Assert
    assert result is True


# Generated at 2022-06-21 18:59:05.814620
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:59:07.070287
# Unit test for method bind of class Right
def test_Right_bind():
    value = Right(1)
    result = value.bind(lambda x: Right(x + 1))
    assert result == Right(2)



# Generated at 2022-06-21 18:59:26.527907
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(3).ap(Right(lambda x: x * 3)) == Left(3)
    assert Left(3).ap(Left(lambda x: x * 3)) == Left(3)
    assert Right(2).ap(Left(lambda x: x * 3)) == Left(2)



# Generated at 2022-06-21 18:59:30.550183
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(2).map(lambda x: x + 1) == Left(2)
    assert Left(3).map(lambda x: x + 1) == Left(3)


# Generated at 2022-06-21 18:59:33.962104
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(12)
    assert Maybe.nothing() == left.to_maybe()
    assert Maybe.nothing() == left.to_maybe()


# Generated at 2022-06-21 18:59:38.460665
# Unit test for method is_right of class Left
def test_Left_is_right():
    def test_is_right(value: Any, expected: bool) -> None:
        actual = Left(value).is_right()
        assert actual == expected, f"expected {expected} but got {actual}"

    test_is_right(42, False)
    test_is_right("some string", False)



# Generated at 2022-06-21 18:59:41.502618
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    validation = Right('hi').to_validation()
    assert type(validation) == Validation
    assert validation.value == 'hi'


# Generated at 2022-06-21 18:59:43.274565
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('a').is_right() == False
    assert Right('a').is_right() == True


# Generated at 2022-06-21 18:59:44.381157
# Unit test for constructor of class Left
def test_Left():
    left_value = Left(5)
    assert left_value.value == 5



# Generated at 2022-06-21 18:59:46.659363
# Unit test for constructor of class Left
def test_Left():
    from pymonet.maybe import Just

    assert Left(Just(1)) == Left(Just(1))
    assert Left(Just(1)) != Left(Just(2))


# Generated at 2022-06-21 18:59:49.316572
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)
    assert Right(1).map(lambda x: x - 1) == Right(0)


# Generated at 2022-06-21 18:59:51.095872
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(5)
    assert right.is_right() is True


# Generated at 2022-06-21 19:00:27.629921
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(123).is_left()


# Generated at 2022-06-21 19:00:29.100358
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('value').is_right() is False



# Generated at 2022-06-21 19:00:30.938025
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(42)
    assert left.is_right() == False


# Generated at 2022-06-21 19:00:34.348581
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)


# Generated at 2022-06-21 19:00:36.076631
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()

# Generated at 2022-06-21 19:00:37.957774
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left(1).is_right()


# Generated at 2022-06-21 19:00:43.210549
# Unit test for method bind of class Right
def test_Right_bind():
    def increment(x: int) -> int:
        return x + 1

    assert Right(1).bind(increment) == Right(2)

    def add_one_to_each(list_of_number: list):
        return list(map(increment, list_of_number))

    assert Right([1, 2, 3]).bind(add_one_to_each) == Right([2, 3, 4])



# Generated at 2022-06-21 19:00:54.008207
# Unit test for constructor of class Either
def test_Either():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    empty_left = None
    empty_right = None

    def get_left() -> Either[Exception]:
        return Left(Exception())

    def get_right() -> Either[Exception]:
        return Right(Exception())

    def get_either() -> Either[Exception]:
        return get_left().bind(lambda _: get_right())

    def get_left_result() -> Validation[str, Exception]:
        return get_left().to_validation()

    def get_right_result() -> Validation[str, Exception]:
        return get_right().to_validation()

    def get_either_result() -> Validation[str, Exception]:
        return get_either().to_validation()


# Generated at 2022-06-21 19:00:56.451748
# Unit test for method case of class Either
def test_Either_case():
    # GIVEN
    _either = Left('Error')

    # WHEN
    result = _either.case(lambda x: 'Error: ' + x, lambda x: 'Success: ' + x)

    # THEN
    assert result == 'Error: Error'
    assert isinstance(result, str)


# Generated at 2022-06-21 19:00:58.830096
# Unit test for method map of class Left
def test_Left_map():
    left_instance = Left(1)
    assert left_instance.map(lambda x: x + 1) is left_instance


# Generated at 2022-06-21 19:02:26.399209
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    >>> assert Left(1).to_try().is_failure()
    >>> assert Right(1).to_try().is_success()
    """


# Generated at 2022-06-21 19:02:28.210438
# Unit test for method map of class Left
def test_Left_map():
    assert Left('foo').map(lambda x: x.upper()) == Left('foo')



# Generated at 2022-06-21 19:02:29.973712
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-21 19:02:31.353204
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Right(lambda x: x * 3)) == Left(2)


# Generated at 2022-06-21 19:02:32.569926
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() == False


# Generated at 2022-06-21 19:02:34.788894
# Unit test for method map of class Left
def test_Left_map():
    """Test map method of class Left"""

    def mapper(value):
        return value ** 2

    left = Left(10)
    assert left.map(mapper) == left


# Generated at 2022-06-21 19:02:38.738712
# Unit test for method ap of class Left
def test_Left_ap():
    # Given
    either1 = Left(1)
    either2 = Left(3)
    # When
    result = either1.ap(either2)
    # Then
    assert result == Left(1)


# Generated at 2022-06-21 19:02:42.959068
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert(Left(1).is_left() is True)
    assert(Left(2).is_left() is True)
    assert(Right(1).is_left() is False)
    assert(Right(2).is_left() is False)



# Generated at 2022-06-21 19:02:44.602413
# Unit test for method bind of class Right
def test_Right_bind():
    f = lambda x: Right(x * 2)
    assert Right(4).bind(f) == f(4)



# Generated at 2022-06-21 19:02:46.287211
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right() == True


# Generated at 2022-06-21 19:04:20.426413
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(1)
    assert right.bind(lambda x: Right(x + 1)) == Right(2)



# Generated at 2022-06-21 19:04:22.307975
# Unit test for method bind of class Left
def test_Left_bind():
    left_monad = Left(10)
    func = lambda x: x + 1
    assert left_monad.bind(func) == left_monad



# Generated at 2022-06-21 19:04:24.976647
# Unit test for method case of class Either
def test_Either_case():
    result = Left(1).case(lambda x: x + 2, lambda x: x + 3)
    assert result == 3
    result = Right(1).case(lambda x: x + 2, lambda x: x + 3)
    assert result == 4

# Generated at 2022-06-21 19:04:28.168298
# Unit test for method bind of class Right
def test_Right_bind():
    mapper = lambda _: Left(2)
    assert (Right(1).bind(mapper)).value == 2

# Generated at 2022-06-21 19:04:30.712614
# Unit test for method map of class Right
def test_Right_map():
    result = Right(1).map(lambda x: x + 3)
    expected = Right(4)
    assert result == expected



# Generated at 2022-06-21 19:04:34.615557
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(9).to_try() == Try(9, True)
    assert Left("error").to_try() == Try("error", False)


# Generated at 2022-06-21 19:04:36.758749
# Unit test for method ap of class Either
def test_Either_ap():
    assert (Right(lambda x: x * x).ap(Right(4)) == Right(16)).is_success()


# Generated at 2022-06-21 19:04:41.041412
# Unit test for constructor of class Either
def test_Either():
    """
    >>> Left(123)
    Left(123)
    >>> Right(123)
    Right(123)
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 19:04:43.851053
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None) == Left(None)
    assert Right(None) == Right(None)
    assert Left(None) != Right(None)
    assert isinstance(Left(None) == object(), bool)
