

# Generated at 2022-06-21 18:54:48.904584
# Unit test for constructor of class Left
def test_Left():
    left = Left('error')
    assert left.value == 'error'
    assert left.is_left() is True
    assert left.is_right() is False



# Generated at 2022-06-21 18:54:49.862120
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(10).is_left()



# Generated at 2022-06-21 18:54:51.785382
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(1)

    assert left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:54:53.451267
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right() == True



# Generated at 2022-06-21 18:54:55.723479
# Unit test for method map of class Left
def test_Left_map():
    """Test Either.map()"""
    inc = lambda x: x + 1
    left = Left(1)
    assert left.map(inc) == left



# Generated at 2022-06-21 18:54:57.276839
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left("Error").bind(lambda v: "Result" if v else "Error 2") == "Error"


# Generated at 2022-06-21 18:54:59.859823
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right(1).to_try() == Try(1, True)
    assert Left(1).to_try() == Try(1, False)

# Generated at 2022-06-21 18:55:02.930161
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(10).to_box().get_value() == 10
    assert Left(10).to_box().get_value() == 10


# Generated at 2022-06-21 18:55:04.821830
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(7)
    assert right.is_left() == False


# Generated at 2022-06-21 18:55:09.280082
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    # given
    a = 'I am an error!'
    either = Left(a)

    # when
    validation = either.to_validation()

    # then
    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.fail() == [a]


# Generated at 2022-06-21 18:55:15.790229
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x + 1) == Left(2)



# Generated at 2022-06-21 18:55:17.534268
# Unit test for method is_right of class Right
def test_Right_is_right():
    test_instance = Right(3)
    assert test_instance.is_right() == True



# Generated at 2022-06-21 18:55:21.301143
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:55:25.654300
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left([1, 2, 3])
    assert left.to_validation() == Validation.fail([1, 2, 3])



# Generated at 2022-06-21 18:55:27.668509
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    maybe = Left(3).to_maybe()

    assert maybe.is_nothing()


# Generated at 2022-06-21 18:55:37.069333
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():

    def success(x: int) -> int:
        return x**2

    def validation(x: int) -> int:
        if x % 2 == 0: return x
        raise Exception("{} isn't even number".format(x))

    r = Right(2)
    assert r.to_maybe().case(lambda _: False, lambda x: x == 2)
    r = Right(3)
    assert r.to_maybe().case(lambda _: True, lambda x: False)

    r = Left("error")
    assert r.to_maybe().case(lambda _: False, lambda x: False)

    assert Left(None).to_maybe().case(lambda x: False, lambda x: False)

# Generated at 2022-06-21 18:55:39.118591
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-21 18:55:45.555907
# Unit test for method case of class Either
def test_Either_case():
    as_left = 'error'
    as_right = 'success'

    def test_1():
        assert Left(10).case(error=lambda x: as_left, success=lambda y: as_right) == as_left
    test_1()

    def test_2():
        assert Right(5).case(error=lambda x: as_left, success=lambda y: as_right) == as_right
    test_2()


# Generated at 2022-06-21 18:55:48.232259
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case('error', 'success') == 'success'
    assert Left(None).case('error', 'success') == 'error'

# Generated at 2022-06-21 18:55:51.153034
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    result = Right(5).to_validation()
    assert isinstance(result, Validation) and bool(result) and (list(result) == [5])


# Generated at 2022-06-21 18:55:59.966342
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(4)) == Right(5)
    assert Left(4).ap(Right(4)) == Left(4)
    assert Left(4).ap(Left(4)) == Left(4)



# Generated at 2022-06-21 18:56:02.768610
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    e = Right(5)
    v = e.to_validation()
    assert v == Validation.success(5)


# Generated at 2022-06-21 18:56:03.940631
# Unit test for method map of class Left
def test_Left_map():
    assert Left(5).map(lambda x: x) == Left(5)


# Generated at 2022-06-21 18:56:10.649876
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box, test_Box_identity_law

    assert isinstance(Right(5).to_box(), Box)
    assert isinstance(Left(5).to_box(), Box)
    assert test_Box_identity_law(Right(5).to_box())
    assert test_Box_identity_law(Left(5).to_box())



# Generated at 2022-06-21 18:56:12.647273
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-21 18:56:16.587520
# Unit test for method to_try of class Either
def test_Either_to_try():
    try_success = Right(42).to_try()
    try_fail = Left(42).to_try()

    assert try_success.get() == 42
    assert try_fail.get_error() == 42
    assert try_success.is_success() is True
    assert try_fail.is_success() is False


# Generated at 2022-06-21 18:56:21.282421
# Unit test for method to_try of class Either
def test_Either_to_try():
    """
    Unit test for method to_try of class Either.
    """
    from pymonet.monad_try import Try

    assert Right(3).to_try() == Try(3)
    assert Left('3').to_try() == Try(exception='3', is_success=False)
    assert Left('3').to_try()



# Generated at 2022-06-21 18:56:22.749091
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() == False



# Generated at 2022-06-21 18:56:25.044201
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("TEST").is_left() == True


# Generated at 2022-06-21 18:56:28.799504
# Unit test for method map of class Left
def test_Left_map():
    # Given
    error = Left(Exception())
    mapper = lambda x: x

    # When
    result = error.map(mapper)

    # Then
    assert isinstance(result, Left)
    assert result == error


# Generated at 2022-06-21 18:56:35.837300
# Unit test for method is_right of class Right
def test_Right_is_right():
    right1 = Right(1)
    right2 = Right(2)
    left = Left(1)

    assert right1.is_right() == True
    assert right2.is_right() == True
    assert left.is_right() == False


# Generated at 2022-06-21 18:56:37.126104
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda a: a + 1) == Left(1)



# Generated at 2022-06-21 18:56:39.516980
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)

    assert not right.is_left()

# Generated at 2022-06-21 18:56:41.501643
# Unit test for method map of class Right
def test_Right_map():
    Either.from_value(1).map(lambda x: 2 * x) == Right(2)


# Generated at 2022-06-21 18:56:44.384931
# Unit test for method bind of class Left
def test_Left_bind():
    def add(value):
        return value + 1

    left = Left(2)
    assert left.bind(add) == Left(2)


# Generated at 2022-06-21 18:56:45.343278
# Unit test for constructor of class Left
def test_Left():
    assert Left(1).value == 1



# Generated at 2022-06-21 18:56:50.047731
# Unit test for method ap of class Left
def test_Left_ap():
    def add(a):
        def add_applicative(b):
            return a + b

        return Either.right(add_applicative)

    assert Either.left(5).ap(Either.left(5)) == Either.left(5)
    assert Either.left('error').ap(Either.right(5)) == Either.left('error')



# Generated at 2022-06-21 18:56:52.374308
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:56:53.771222
# Unit test for constructor of class Either
def test_Either():
    assert Left(None) != Right(None)


# Generated at 2022-06-21 18:56:56.458371
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Test to_box of class Either."""
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-21 18:57:06.065350
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    # Given
    value = 'test'
    left = Left(value)

    # When
    result = left.to_validation()

    # Then
    assert isinstance(result, Left)
    assert result.is_left()
    assert result.value == value



# Generated at 2022-06-21 18:57:12.690171
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Success
    from pymonet.validation import Failure

    validation = Validation.success(5)
    assert Right(5).to_validation() == Success(5)
    assert Right(5).to_validation() != Failure([5])
    assert Right(5).to_validation() == validation


# Generated at 2022-06-21 18:57:14.184077
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(12).is_right() == True)


# Generated at 2022-06-21 18:57:18.711086
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either"""

    with pytest.raises(TypeError):
        Either()

    left_value = Left(None)
    right_value = Right(None)

    assert isinstance(left_value, Either) is True
    assert isinstance(right_value, Either) is True



# Generated at 2022-06-21 18:57:19.819185
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-21 18:57:24.397028
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    either = Right(42)

    # When
    result = either.to_lazy()

    # Then
    assert isinstance(result, Lazy)
    assert result.eval() == 42



# Generated at 2022-06-21 18:57:31.580079
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    instance = Right('value')
    # And
    copy = Right('value')
    # And
    instance_with_different_value = Right(1)
    # And
    instance_with_different_type = Left('value')
    # And
    other_object = object()
    # Expect
    assert instance == copy
    # And
    assert not instance == instance_with_different_value
    # And
    assert not instance == instance_with_different_type
    # And
    assert not instance == other_object

# Generated at 2022-06-21 18:57:37.766250
# Unit test for constructor of class Either
def test_Either():
    assert Right(10) == Right(10)
    assert Left(10) == Left(10)
    assert Right(10) != Left(10)
    assert Left(10) != Right(10)
    assert Right(10) != None
    assert Left(10) != None
    assert Right(10) != 10
    assert Left(10) != 10


# Generated at 2022-06-21 18:57:39.249474
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:57:42.477069
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(20).to_lazy() == Lazy(lambda: 20)


# Generated at 2022-06-21 18:57:53.745131
# Unit test for method to_box of class Either
def test_Either_to_box():
    left = Left(42)
    right = Right(42)

    assert left.to_box() == Box(42)
    assert right.to_box() == Box(42)



# Generated at 2022-06-21 18:57:55.286258
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert(Right(1).is_right() == True)


# Generated at 2022-06-21 18:58:00.230740
# Unit test for method bind of class Left
def test_Left_bind():
    assert (Left('Test').bind(lambda x: Right(x)) == Left('Test')), 'Left bind method is broken'
    assert (Left('Test').bind(lambda x: Right(x + ' me')) == Left('Test')), 'Left bind method is broken'



# Generated at 2022-06-21 18:58:05.767878
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Given
    left = Left(1)
    right = Right(1)

    # When
    try_from_left = left.to_try()
    try_from_right = right.to_try()

    # Then
    assert try_from_left == Try(1, False)
    assert try_from_right == Try(1, True)


# Generated at 2022-06-21 18:58:09.021195
# Unit test for constructor of class Right
def test_Right():
    assert Right('right') == Right('right')
    assert Right(1) == Right(1)
    assert (Right(1) == Right(2)) == False
    assert isinstance(Right('right'), Either)

# Generated at 2022-06-21 18:58:11.874872
# Unit test for constructor of class Left
def test_Left():
    """Test constructor of class Left"""
    # Given
    error_value = "Error message"

    # When
    monad = Left(error_value)

    # Then
    assert monad.value == error_value



# Generated at 2022-06-21 18:58:12.906040
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False


# Generated at 2022-06-21 18:58:14.726947
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left("Error").is_right()


# Generated at 2022-06-21 18:58:15.737980
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:58:27.061573
# Unit test for method ap of class Either
def test_Either_ap():
    right_either = Right(5)
    left_either = Left('error')
    right_either_ap_list = right_either.to_list().ap(right_either.to_list())
    right_either_ap_box = right_either.to_box().ap(right_either.to_box())
    right_either_ap_lazy = right_either.to_lazy().ap(right_either.to_lazy())
    right_either_ap_try = right_either.to_try().ap(right_either.to_try())
    left_either_ap_list = left_either.to_list().ap(right_either.to_list())
    left_either_ap_box = left_either.to_box().ap(right_either.to_box())
    left_either_ap_l

# Generated at 2022-06-21 18:58:34.093534
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    right = Right(3)
    assert right.to_validation() == Validation.success(3)



# Generated at 2022-06-21 18:58:37.462268
# Unit test for method ap of class Left
def test_Left_ap():
    def get_left(x):
        return Left(x)
    assert Left(1).ap(Left(get_left)) == Left(1)


# Generated at 2022-06-21 18:58:39.076871
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert either_right.to_maybe() == maybe_just_value



# Generated at 2022-06-21 18:58:40.943387
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 18:58:42.892368
# Unit test for method map of class Left
def test_Left_map():
    assert Left(2).map(lambda x: x**2) == Left(2)


# Generated at 2022-06-21 18:58:44.735179
# Unit test for method map of class Left
def test_Left_map():
    left = Left(3)
    result = left.map(lambda x: x + 2)
    assert result == left



# Generated at 2022-06-21 18:58:48.881136
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    # Given
    either_left = Either(5)
    either_right = Either(5)

    # When
    result_left = either_left.to_box()
    result_right = either_right.to_box()

    # Then
    assert isinstance(result_left, Box)
    assert isinstance(result_right, Box)


# Generated at 2022-06-21 18:58:51.385922
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(1).ap(Right(lambda x: x + 1)) == Right(2)
    assert Left(1).ap(Left(lambda x: x + 1)) == Left(1)
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-21 18:58:54.986337
# Unit test for method map of class Right
def test_Right_map():
    value = "value"
    # Arrange
    result = Right(value)

    # Act
    result = result.map(lambda x: x + ".")

    # Assert
    assert result == Right(value + ".")


# Generated at 2022-06-21 18:58:59.912451
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-21 18:59:17.920562
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Left and Right should be converted to Box. Left should be converted to Box with None value. Right should be converted
    to Box with previous value.
    """
    assert Either(None).to_box() == Either(3).to_box()
    assert Either(None).to_box() == Box(None)
    assert Either(3).to_box() == Box(3)



# Generated at 2022-06-21 18:59:24.815422
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Left(0).to_box() == Box(0)
    assert Right(0).to_box() == Box(0)
    assert Try(0, True).to_box() == Box(0)
    assert Try(0, False).to_box() == Box(0)
    assert Lazy(lambda: 1).to_box() == Box(1)


# Generated at 2022-06-21 18:59:25.950349
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(10).is_right() == False



# Generated at 2022-06-21 18:59:28.103143
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda v: v + 1) == Left(1)


# Generated at 2022-06-21 18:59:35.193374
# Unit test for method to_try of class Either
def test_Either_to_try():
    try_success = Either[int](10).to_try()
    try_failure = Either.Left[int](10).to_try()
    assert try_success.is_success()
    assert not try_failure.is_success()
    assert isinstance(try_success, Try)
    assert isinstance(try_failure, Try)
    assert try_success.get_or_else(0) == 10
    assert try_failure.get_or_else(0) == 0


# Generated at 2022-06-21 18:59:37.833374
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-21 18:59:39.458996
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(5).to_validation() == Validation.fail([5])


# Generated at 2022-06-21 18:59:41.403432
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(4).bind(lambda v: Right(v + 1)) is Left(4)



# Generated at 2022-06-21 18:59:42.789336
# Unit test for constructor of class Left
def test_Left():
    assert Left("a").is_left()


# Generated at 2022-06-21 18:59:44.130155
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('foo').is_left()


# Generated at 2022-06-21 18:59:58.748170
# Unit test for constructor of class Right
def test_Right():
    x = Right(3)

    assert x.value == 3
    assert isinstance(x, Either)


# Generated at 2022-06-21 19:00:00.529392
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(None).is_right()


# Generated at 2022-06-21 19:00:02.219943
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either.to_box(Left('error')) == Box('error')
    assert Either.to_box(Right('right')) == Box('right')


# Generated at 2022-06-21 19:00:03.098642
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3


# Generated at 2022-06-21 19:00:06.982006
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad import left
    from .test.helpers import fn_id

    result = left("error").to_maybe()

    assert isinstance(result, Maybe)
    assert result == Maybe.nothing()


# Generated at 2022-06-21 19:00:08.826599
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(42)
    assert left.is_left()



# Generated at 2022-06-21 19:00:18.259885
# Unit test for method ap of class Either
def test_Either_ap():
    my_func = lambda x: x + 1

    if Either.Right(my_func).ap(Either.Right(100)) != Either.Right(101):
        raise AssertionError()
    if Either.Right(my_func).ap(Either.Left(100)) != Either.Left(100):
        raise AssertionError()
    if Either.Left(my_func).ap(Either.Right(100)) != Either.Left(my_func):
        raise AssertionError()
    if Either.Left(my_func).ap(Either.Left(100)) != Either.Left(my_func):
        raise AssertionError()

# Generated at 2022-06-21 19:00:29.645233
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box

    m_integer = Box(4)
    m_string = Box('4')
    m_add = Box(lambda x, y: x + y)

    assert (Right(2).ap(Box(lambda x: x + 1)) == Right(3))
    assert (Right(2).ap(Box(lambda x: str(x))) == Right('2'))
    assert (Left(2).ap(Box(lambda x: x + 1)) == Left(2))
    assert (Right(2).ap(Box(lambda x: x)) == Right(2))
    assert (Left(3).ap(m_string) == Left(3))
    assert (Right(2).ap(m_integer) == m_integer)
    assert (Right(2).ap(m_add) == m_add)

# Generated at 2022-06-21 19:00:34.596527
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1)

# Unit tests for method bind of class Right

# Generated at 2022-06-21 19:00:37.957321
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)
    assert Right(1).bind(lambda x: Left(x + 1)) == Left(2)



# Generated at 2022-06-21 19:00:53.703956
# Unit test for method map of class Left
def test_Left_map():
    """
    Test for Left.map. Test are performed with pytest.
    """

    # assertion for the function map on Left class
    assert Left(2).map(lambda x: x*2) == Left(2)


# Generated at 2022-06-21 19:00:54.979583
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1)


# Generated at 2022-06-21 19:01:03.411260
# Unit test for method is_left of class Left
def test_Left_is_left():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Left(None).is_left()
    assert not Left(None).is_right()
    assert Left(None).to_box().is_left()
    assert Left(None).to_try().is_left()
    assert Left(None).to_lazy().is_left()
    assert Left(None).to_maybe().is_left()


# Generated at 2022-06-21 19:01:04.865887
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(5).ap(Left("")) == Left("")


# Generated at 2022-06-21 19:01:07.162131
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-21 19:01:09.192173
# Unit test for constructor of class Left
def test_Left():
    left = Left(10)
    assert left.value == 10
    assert isinstance(left, Left) is True



# Generated at 2022-06-21 19:01:10.576924
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(None).is_left()


# Generated at 2022-06-21 19:01:12.327376
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left('x').to_maybe()



# Generated at 2022-06-21 19:01:13.162528
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None


# Generated at 2022-06-21 19:01:14.686543
# Unit test for method to_validation of class Left
def test_Left_to_validation():
     left_with_error = Left("error")
     assert left_with_error.to_validation() == Validation.fail(["error"])

# Generated at 2022-06-21 19:01:43.717377
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation(success=None, error=[1])


# Generated at 2022-06-21 19:01:45.231040
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False



# Generated at 2022-06-21 19:01:46.465340
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box().is_success() == False
    assert Right(1).to_box().is_success() == True


# Generated at 2022-06-21 19:01:47.662139
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('Left value')
    identity = lambda v: Left(v)

    assert left.bind(identity) == left

# Generated at 2022-06-21 19:01:49.924785
# Unit test for method map of class Right
def test_Right_map():
    l = Left([])
    assert l.map(lambda x: x + 1) == l

    r = Right(1)
    assert r.map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-21 19:01:53.258919
# Unit test for method ap of class Either
def test_Either_ap():
    right = Right(lambda x: x + 1)
    right_left = Right(lambda x: Left(x + 1))

    assert right.ap(Right(1)).value == 2
    assert right_left.ap(Right(1)).value.value == 2



# Generated at 2022-06-21 19:01:55.459889
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Try.success(5).equals(Right(5).to_try())
    assert Try.failure(5).equals(Left(5).to_try())



# Generated at 2022-06-21 19:01:57.497581
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Left(1)


# Generated at 2022-06-21 19:01:59.525256
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left("test").is_right()
    assert Right("test").is_right()



# Generated at 2022-06-21 19:02:01.950626
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() == True
    assert left.is_right() == False


# Generated at 2022-06-21 19:03:04.891860
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x: int) -> Either[int]:
        return Right(x + 10)

    def sub(x: int) -> Either[int]:
        return Right(x - 2)

    assert Right(2).ap(add).ap(sub) == Either(10)

# Generated at 2022-06-21 19:03:06.813617
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('String').to_lazy().force() == 'String'
    assert Right(3.14).to_lazy().force() == 3.14

# Generated at 2022-06-21 19:03:08.897863
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-21 19:03:09.937954
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-21 19:03:11.629549
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None) == Left(None)
    assert Left(None) != Right(None)
    assert Right(None) == Right(None)


# Generated at 2022-06-21 19:03:14.094588
# Unit test for method map of class Left
def test_Left_map():
    left_value = 2
    left_instance = Left(left_value)
    actual_result = left_instance.map(lambda a: a * left_value)
    expected_result = Left(left_value)
    assert expected_result.value == actual_result.value
    assert expected_result.is_left() == actual_result.is_left()



# Generated at 2022-06-21 19:03:16.783230
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 19:03:21.261864
# Unit test for method ap of class Either
def test_Either_ap():

    # Initialize
    left = Left(42)
    right = Right(lambda x: x + 1)

    # Apply function inside Right
    result = left.ap(right)

    assert isinstance(result, Left)
    assert result.value == 42


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-21 19:03:23.453668
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-21 19:03:26.178779
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Right(10).to_maybe() == Maybe.just(10) is not None

