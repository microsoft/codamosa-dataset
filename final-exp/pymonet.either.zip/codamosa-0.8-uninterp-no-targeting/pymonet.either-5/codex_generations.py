

# Generated at 2022-06-21 18:54:55.485318
# Unit test for method map of class Right
def test_Right_map():
    right_either = Right(1)
    left_either = Left(1)

    assert right_either.map(lambda x: x + 1) == Right(2)
    assert left_either.map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-21 18:54:56.688184
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-21 18:55:04.061627
# Unit test for constructor of class Right
def test_Right():
    from pymonet.monad_container import MonadContainer

    assert isinstance(Right(1), MonadContainer), "Either.Right should be instance of MonadContainer class"
    assert isinstance(Right(1), Either), "Either.Right should be instance of Either class"
    assert isinstance(Right(1), Right), "Either.Right should be instance of Right class"
    assert not isinstance(Right(1), Left), "Either.Right should not be instance of Left class"



# Generated at 2022-06-21 18:55:05.859157
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left('error').to_validation() == Validation.fail(['error'])


# Generated at 2022-06-21 18:55:08.008949
# Unit test for constructor of class Either
def test_Either():
    # given
    left = Left('left')
    right = Right('right')
    # expect
    assert left.value == 'left'
    assert right.value == 'right'



# Generated at 2022-06-21 18:55:09.596753
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-21 18:55:10.839469
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(5).is_left() == False



# Generated at 2022-06-21 18:55:13.780487
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-21 18:55:20.771698
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Box(1) == Either(1).to_box()
    assert Box(1).case(lambda x: x, lambda x: x) == Either(1).to_box().case(lambda x: x, lambda x: x)
    assert Box(2) == Either(2).to_box()
    assert Box(2).case(lambda x: x, lambda x: x) == Either(2).to_box().case(lambda x: x, lambda x: x)



# Generated at 2022-06-21 18:55:23.847315
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Right(x**x)) == Right(4)


# Generated at 2022-06-21 18:55:29.573799
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.validation import Validation

    left = Validation.fail(1)

    assert left.is_left()

# Generated at 2022-06-21 18:55:31.084304
# Unit test for constructor of class Left
def test_Left():
    left = Left('value')
    assert left.is_left()



# Generated at 2022-06-21 18:55:32.899279
# Unit test for constructor of class Right
def test_Right():
    right = Right(5)
    assert isinstance(right, Right)
    assert right.value == 5


# Generated at 2022-06-21 18:55:34.420190
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Left(1).to_maybe()


# Generated at 2022-06-21 18:55:35.309231
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right()


# Generated at 2022-06-21 18:55:38.206691
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try

    def success_fn():
        return Try.success(2)

    monad = Right(1)
    assert monad.bind(success_fn) == \
        Try.success(2)



# Generated at 2022-06-21 18:55:40.900981
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1
    assert right.is_right()
    assert not right.is_left()


# Generated at 2022-06-21 18:55:46.132347
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import *

    def add(x: int, y: int) -> int:
        return x + y
    assert Either(add).ap(Lazy.unit(2)).ap(Lazy.unit(3)).value == 5
    assert Either(1).ap(Lazy.unit(2)).ap(Lazy.unit(3)).value == 1


# Generated at 2022-06-21 18:55:48.947770
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:55:49.557021
# Unit test for method ap of class Either
def test_Either_ap():
    pass

# Generated at 2022-06-21 18:55:52.995299
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(42).is_left()


# Generated at 2022-06-21 18:55:54.416083
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(2)) == Left(1)


# Generated at 2022-06-21 18:55:55.833807
# Unit test for method is_left of class Left
def test_Left_is_left():
    result = Left("test").is_left()
    assert result == True


# Generated at 2022-06-21 18:55:58.492561
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:56:01.762154
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    To test to_lazy method of class Either

    :return: 'None' if success
    """

    # Testing calling to_lazy on a Right instance
    assert Right(3).to_lazy().evaluate() == 3

    # Testing calling to_lazy on a Left instance
    assert Left(3).to_lazy().evaluate() == 3


# Generated at 2022-06-21 18:56:02.524578
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 18:56:05.076592
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('error').to_lazy().call() == 'error'
    assert Right('value').to_lazy().call() == 'value'


# Generated at 2022-06-21 18:56:07.079843
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()
    assert not Right(1).is_left()



# Generated at 2022-06-21 18:56:09.306065
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False



# Generated at 2022-06-21 18:56:12.745054
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Box(1) == Right(1).to_box()
    assert Box(1) == Left(1).to_box()


# Generated at 2022-06-21 18:56:23.165689
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Either(Box(5)).to_lazy() == Lazy(lambda: Box(5))
    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either(Validation(Try(5))).to_lazy() == Lazy(lambda: Validation(Try(5)))
    assert Either("error").to_lazy() == Lazy(lambda: "error")



# Generated at 2022-06-21 18:56:25.537703
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() == True


# Generated at 2022-06-21 18:56:26.215088
# Unit test for method map of class Right
def test_Right_map():
    Either(1)

# Generated at 2022-06-21 18:56:27.886522
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False


# Generated at 2022-06-21 18:56:33.735870
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Left(5).ap(Box(5)).is_left()
    assert Left(5).ap(Box(lambda x: x + 2)).is_left()
    assert Left(5).ap(Try(5)).is_left()
    assert Left(5).ap(Try(lambda x: x + 2)).is_left()


# Generated at 2022-06-21 18:56:36.367458
# Unit test for method case of class Either
def test_Either_case():
    e = Right(100)
    assert e.case(lambda x: x, lambda x: x) == 100
    e = Left('error')
    assert e.case(lambda x: x, lambda x: x) == 'error'


# Generated at 2022-06-21 18:56:38.665696
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() == False



# Generated at 2022-06-21 18:56:41.898030
# Unit test for constructor of class Either
def test_Either():
    # Check if constructor creates class with private property 'value'
    left = Left(1)
    right = Right(1)

    assert left.value == 1
    assert right.value == 1



# Generated at 2022-06-21 18:56:44.769941
# Unit test for constructor of class Right
def test_Right():
    """
    Test for constructor of class Right.

    :returns: Pass or fail
    :rtype: String
    """
    assert Right(1).is_right()


# Generated at 2022-06-21 18:56:47.097752
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)

    assert isinstance(left, Left)
    assert isinstance(left, Either)
    assert left.value == 1



# Generated at 2022-06-21 18:56:53.013006
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda v: v * 2) == left



# Generated at 2022-06-21 18:56:54.706853
# Unit test for constructor of class Right
def test_Right():
    from pymonet.either import Right

    assert Right(15) == Right(15)



# Generated at 2022-06-21 18:56:58.472790
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe() == Maybe.just(2)
    assert Right('foo').to_maybe() == Maybe.just('foo')
    assert Right(Right(1)).to_maybe() == Maybe.just(Right(1))
    assert Right(Left(2)).to_maybe() == Maybe.just(Left(2))


# Generated at 2022-06-21 18:57:00.473606
# Unit test for method bind of class Left
def test_Left_bind():
    left_value = Left(1)
    assert left_value.bind(lambda v: Right(v)) == left_value


# Generated at 2022-06-21 18:57:05.704744
# Unit test for method case of class Either
def test_Either_case():

    left = Left(1)
    assert left.case(lambda x: x * 2, lambda x: x / 2) == 2

    right = Right(1)
    assert right.case(lambda x: x * 2, lambda x: x / 2) == 0.5



# Generated at 2022-06-21 18:57:13.521296
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Unit test for method is_right of class Either

    Class Either should contains method is_right which returns True or False
    depending on the type of contains Either data.
    """
    print('Unit test for method is_right of class Either')
    assert Left(None).is_right() == False, 'is_right of class Either should return false for Left value'
    assert Right(None).is_right() == True, 'is_right of class Either should return true for Right value'
    print('Success')



# Generated at 2022-06-21 18:57:15.758771
# Unit test for method map of class Left
def test_Left_map():
    assert Left("error").map(lambda x: x) == Left("error")


# Generated at 2022-06-21 18:57:21.293655
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left('error').to_validation() == Left('error').to_validation()
    assert Left(123).to_validation() == Left(123).to_validation()
    assert Left('error').to_validation() == Left('error').to_validation()
    assert Left({}).to_validation() == Left({}).to_validation()


# Generated at 2022-06-21 18:57:22.128613
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('x').to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:57:25.818864
# Unit test for method map of class Left
def test_Left_map():
    # Arrange
    def mapper(value):
        return value + 2

    # Act
    left = Left(2)
    result = left.map(mapper)

    # Assert
    assert(left == result)



# Generated at 2022-06-21 18:57:38.150110
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 'test'
    lazy = Lazy(lambda: test_value)

    assert Left(test_value).to_lazy() == lazy
    assert Right(test_value).to_lazy() == lazy


# Generated at 2022-06-21 18:57:39.545292
# Unit test for constructor of class Left
def test_Left():
    assert Left(42) == Left(42)



# Generated at 2022-06-21 18:57:43.433546
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Either(Right(1)).to_try() == Try(1, is_success=True)
    assert Either(Left(2)).to_try() == Try(2, is_success=False)



# Generated at 2022-06-21 18:57:46.134958
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-21 18:57:48.008426
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    assert left.bind(lambda x: Right(x+1)) == left

# Generated at 2022-06-21 18:57:49.327462
# Unit test for method ap of class Left
def test_Left_ap():
    """Unit test for method ap of class Left"""
    pass



# Generated at 2022-06-21 18:57:53.427672
# Unit test for method is_left of class Right
def test_Right_is_left():
    """
    Checks if method is_left was properly implemented.

    :returns: None
    :rtype: NoneType
    :raises AssertionError: if test fails
    """
    assert Right(True).is_left() is False,\
        'Either.Right should return False when is_left is called!'



# Generated at 2022-06-21 18:57:57.417575
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    x = Left(3)
    y = x.to_validation()
    assert isinstance(y, Validation)
    assert y.is_fail()
    assert y.fail_value == [3]



# Generated at 2022-06-21 18:58:00.350266
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)

    result = right.map(lambda v: v + 2)

    assert result.value == 3


# Generated at 2022-06-21 18:58:01.318648
# Unit test for constructor of class Right
def test_Right():
    assert Right(None).value is None



# Generated at 2022-06-21 18:58:20.206216
# Unit test for method bind of class Right
def test_Right_bind():
    """Test Right bind method."""

    def multiply(number: int) -> Either[int, int]:
        """Multiply number by three."""
        return Right(number * 3)

    value = Right(1).bind(multiply)
    assert value == Right(3)



# Generated at 2022-06-21 18:58:24.418747
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for method bind of class Right.

    :returns: None
    :rtype: None
    """
    def add_one(value):
        return value + 1

    assert Right(10).bind(add_one) == 11



# Generated at 2022-06-21 18:58:26.759213
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.either import Right

    assert (Left('wrong').map(lambda x: x + '!') == Left('wrong'))



# Generated at 2022-06-21 18:58:29.165294
# Unit test for constructor of class Left
def test_Left():
    assert Left(1)
    assert Left(1) == Left(1)  # pylint: disable=comparison-with-itself
    assert Left(1) != Left(2)



# Generated at 2022-06-21 18:58:31.170446
# Unit test for constructor of class Left
def test_Left():
    left = Left("Error")
    assert left.value == "Error"



# Generated at 2022-06-21 18:58:32.638755
# Unit test for constructor of class Right
def test_Right():
    assert Right(2) == Right(2)


# Generated at 2022-06-21 18:58:36.827722
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left("error")
    assert callable(left.bind)
    assert isinstance(left.bind(lambda x: x), Left)
    assert isinstance(left.bind(lambda _: Right("success")), Left)



# Generated at 2022-06-21 18:58:40.128289
# Unit test for constructor of class Either
def test_Either():
    from pymonet.monad_try import Try

    try_ = Try(1)
    either = Either(try_)

    assert either.value == try_



# Generated at 2022-06-21 18:58:42.060514
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(1)

    assert right.to_maybe() == Maybe.just(right.value)



# Generated at 2022-06-21 18:58:43.945174
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Right(1), Either)
    assert isinstance(Left('error'), Either)



# Generated at 2022-06-21 18:59:21.395812
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.monad_maybe import Maybe

    assert Right('value').to_maybe() == Maybe.just('value')


# Generated at 2022-06-21 18:59:23.508246
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left_value = Left(['Error'])

    assert left_value.to_validation() == Validation.fail(['Error'])


# Generated at 2022-06-21 18:59:25.629109
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Unit test for method __eq__ of class Either.
    """
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert NotLeft(1) != Right(1)


# Generated at 2022-06-21 18:59:28.017766
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.lazy import Lazy

    assert lazy.unit(Right(42)) == Lazy(lambda: Right(42))
    assert lazy.unit(Left(42)) == Lazy(lambda: Left(42))


# Generated at 2022-06-21 18:59:30.316106
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right()
    assert not Left('1').is_right()
    assert Left(1).is_right()


# Generated at 2022-06-21 18:59:33.758064
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-21 18:59:35.909910
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:59:38.820452
# Unit test for method bind of class Right
def test_Right_bind():
    x = Right('a')
    f = lambda s: Right(s + 'b')
    y = x.bind(f)
    assert y.value == 'ab' and y.is_right()


# Generated at 2022-06-21 18:59:48.114393
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(0).is_right() == False
    assert Either(1).is_right() == False
    assert Either('foo').is_right() == False
    assert Either([]).is_right() == False
    assert Either([1, 2]).is_right() == False
    assert Either(dict()).is_right() == False

    assert Left(0).is_right() == False
    assert Left(1).is_right() == False
    assert Left('foo').is_right() == False
    assert Left([]).is_right() == False
    assert Left([1, 2]).is_right() == False
    assert Left(dict()).is_right() == False

    assert Right(0).is_right() == True
    assert Right(1).is_right() == True

# Generated at 2022-06-21 18:59:51.765216
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Unit test for method to_box of class Either"""
    from pymonet.box import Box

    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)



# Generated at 2022-06-21 19:01:07.608406
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("error").is_left() is True



# Generated at 2022-06-21 19:01:09.364815
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(3).bind(lambda x: Right(x + 1)) == Left(3)



# Generated at 2022-06-21 19:01:11.250625
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 2) == Right(3)



# Generated at 2022-06-21 19:01:12.576039
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(0)
    res = left.bind(lambda x: Right(x + 1))

    assert left == res


# Generated at 2022-06-21 19:01:16.878628
# Unit test for constructor of class Either
def test_Either():
    left_int = Left(10)
    left_str = Left("string")

    right_int = Right(10)
    right_str = Right("string")

    assert left_int.case(error=lambda x: x, success=lambda x: 10) == 10
    assert left_str.case(error=lambda x: x, success=lambda x: "string") == "string"

    assert right_int.case(error=lambda x: x, success=lambda x: 10) == 10
    assert right_str.case(error=lambda x: x, success=lambda x: "string") == "string"


# Generated at 2022-06-21 19:01:23.200943
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x * 2) == Right(2)
    assert Right(1).map(lambda x: x + 2) == Right(3)
    assert Right(1).map(lambda x: Left(x * 2)) == Right(Left(2))
    assert Right(1).map(lambda x: Right(x + 2)) == Right(Right(3))


# Generated at 2022-06-21 19:01:24.931148
# Unit test for method is_left of class Right
def test_Right_is_left():
    act = Right(True)
    
    assert act.is_left() == False


# Generated at 2022-06-21 19:01:26.539600
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)

    assert left.to_validation() == Validation.fail([1])


# Generated at 2022-06-21 19:01:28.591813
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    left_maybe = Maybe.nothing()
    left = Left('fail')
    assert left.to_maybe() == left_maybe


# Generated at 2022-06-21 19:01:30.664496
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(4).to_try() == Try.fail(4)
    assert Right(4).to_try() == Try.success(4)

# Generated at 2022-06-21 19:04:35.703949
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)
    assert Right(5) != Left(5)


# Generated at 2022-06-21 19:04:39.409696
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """Test for method to_maybe of class Right"""
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-21 19:04:40.626249
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)


# Generated at 2022-06-21 19:04:42.054123
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 19:04:43.604038
# Unit test for constructor of class Either
def test_Either():
    assert Left(None) == Left(None)
    assert Right(1) == Right(1)


# Generated at 2022-06-21 19:04:46.375899
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left("error")
    applicative = Left("something")
    result = left.ap(applicative)
    expected_result = Left("error")
    assert result == expected_result

# Generated at 2022-06-21 19:04:48.632077
# Unit test for method bind of class Right
def test_Right_bind():
    right_value = Right(7)
    result = right_value.bind(lambda x: Right(x * 2))
    assert result == Right(14)



# Generated at 2022-06-21 19:04:52.566625
# Unit test for method map of class Right
def test_Right_map():
    assert Right(5).map(lambda x: x * x) == Right(25)
    assert Right(5).map(lambda x: x * 0) == Right(0)
    assert Right(5).map(lambda x: x + 1) == Right(6)
    assert Right(5).map(None) == Right(5)
