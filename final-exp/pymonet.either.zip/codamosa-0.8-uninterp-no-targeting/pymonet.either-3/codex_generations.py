

# Generated at 2022-06-21 18:54:52.739001
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right('a').is_left()


# Generated at 2022-06-21 18:54:53.609007
# Unit test for constructor of class Either
def test_Either():
    assert True
    # assert False

# Generated at 2022-06-21 18:54:54.842144
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-21 18:54:59.586704
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Right(4).ap(Right(lambda x: x + 1)) == Right(5)
    assert Right(3).ap(Left(1)) == Left(1)
    assert Left(1).ap(Left(2)) == Left(2)
    assert Right(1).ap(Try(1).bind(lambda x: Try(2))) == Right(2)
    assert Right(1).ap(Validation.success(lambda x: x + 1)) == Right(2)

# Generated at 2022-06-21 18:55:03.489467
# Unit test for constructor of class Left
def test_Left():
    from pymonet.utils import is_equals

    assert is_equals(Left(True), Left(True))
    assert is_equals(Left(True), Left(False))


# Generated at 2022-06-21 18:55:06.743551
# Unit test for method bind of class Left
def test_Left_bind():
    # GIVEN
    left = Left('error')
    # WHEN
    result = left.bind(lambda result: Right(result))
    # THEN
    assert left.value == 'error'
    assert left == result



# Generated at 2022-06-21 18:55:08.347363
# Unit test for method map of class Right
def test_Right_map():
    right = Right(1)
    right.map(lambda x: x+1) == Right(2)


# Generated at 2022-06-21 18:55:11.456548
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right(4).to_validation() == Validation.success(4)



# Generated at 2022-06-21 18:55:15.410892
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda i: Right(i * 2)) == Right(2)
    assert Right(1).bind(lambda i: Left(i ** 2)) == Left(1)


# Generated at 2022-06-21 18:55:18.371880
# Unit test for method case of class Either
def test_Either_case():
    assert Either.case(Left(10), lambda e: e, lambda s: s) == 10
    assert Either.case(Right(10), lambda e: e, lambda s: s) == 10

# Generated at 2022-06-21 18:55:25.654716
# Unit test for method bind of class Right
def test_Right_bind():
    def double(x):
        return 2 * x

    def test_input():
        return Right(5)

    result = test_input().bind(double).bind(double).bind(double)

    assert result == Right(40)



# Generated at 2022-06-21 18:55:32.376444
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad import _Monad

    assert isinstance(Left("Error").to_try(), _Monad)
    assert isinstance(Left("Error").to_try(), Try)
    assert Right("Success").to_try() == Try("Success")
    assert Left(Exception("Error")).to_try() == Try(Exception("Error"), False)


# Generated at 2022-06-21 18:55:33.851013
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right('1').is_right()


# Generated at 2022-06-21 18:55:35.234302
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:55:37.589185
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    """
    Unit test for method to_maybe of class Right.
    """

    assert Right(4).to_maybe().get_value() == 4


# Generated at 2022-06-21 18:55:40.608766
# Unit test for method map of class Right
def test_Right_map():
    result = Right(2).map(lambda x: x * 2)
    assert result == Right(4),\
        "Right::map should return new instance of Right with mapped value"



# Generated at 2022-06-21 18:55:45.986993
# Unit test for constructor of class Left
def test_Left():
    # All data are equal, instance are not
    left1 = Left([1, 2, 3])
    left2 = Left([1, 2, 3])

    assert left1 is not left2
    assert left1 == left2
    assert left1.value == left2.value
    assert left1.is_left() == left2.is_left()


# Generated at 2022-06-21 18:55:47.894000
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:55:50.256848
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    v = Left(1)

    assert v.to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:55:51.870239
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()



# Generated at 2022-06-21 18:55:57.751791
# Unit test for constructor of class Either
def test_Either():
    assert Right(2).value == 2
    assert Left(2).value == 2


# Generated at 2022-06-21 18:55:59.989257
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Right(1).to_maybe(), Maybe)
    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right(None).to_maybe() == Maybe.just(None)


# Generated at 2022-06-21 18:56:02.762627
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:56:04.933810
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:56:08.972825
# Unit test for constructor of class Either
def test_Either():
    assert Either(123).__class__ == Left
    assert Either(123) == Left(123)
    assert Either('123') == Left('123')
    assert Either('123').value == '123'

# Unit tests for method case of class Either

# Generated at 2022-06-21 18:56:13.210143
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    result = Right(100).to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value == 100
    print(result)

# Generated at 2022-06-21 18:56:14.870764
# Unit test for method map of class Left
def test_Left_map():
    left = Left('pymonet')
    assert left.map(str.lower) == left



# Generated at 2022-06-21 18:56:17.622576
# Unit test for method is_right of class Right
def test_Right_is_right():
    either = Right(4)

    assert isinstance(either, Right)
    assert either.is_right()


# Generated at 2022-06-21 18:56:20.624830
# Unit test for method is_right of class Left
def test_Left_is_right():
    class A:
        def f(self, val: bool):
            return val

    a = A()
    assert a.f(Left(None).is_right()) is False



# Generated at 2022-06-21 18:56:32.259792
# Unit test for method case of class Either
def test_Either_case():
    def succes(value):
        return value + 1

    def failure(value):
        return value


# Generated at 2022-06-21 18:56:43.122274
# Unit test for method is_right of class Either
def test_Either_is_right():
    """Unit test for method is_right of class Either"""
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True
    print("[pymonet] - Either tests passed")


# Generated at 2022-06-21 18:56:45.254629
# Unit test for method map of class Right
def test_Right_map():
    right = Right(2)
    assert right.map(lambda x: x * x) == Right(4)



# Generated at 2022-06-21 18:56:46.900546
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    monad = Maybe.just(1)
    assert Either(1).to_maybe() == monad


# Generated at 2022-06-21 18:56:50.542717
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.functor_applicative import Maybe, Just
    import unittest

    mapper = lambda x: Maybe.just(x + 1)

    right = Right(1)
    assert (right.bind(mapper) == Just(2))



# Generated at 2022-06-21 18:56:53.725119
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None
    assert Either(1) is not Either(1)
    assert Either(1) == Either(1)
    assert Either(1).value == 1


# Generated at 2022-06-21 18:56:55.660485
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x + 10)).case(lambda x: x, lambda x: x) == 2



# Generated at 2022-06-21 18:56:56.434402
# Unit test for method is_right of class Left
def test_Left_is_right():
    actual = Left(1)
    assert not actual.is_right()



# Generated at 2022-06-21 18:56:57.963493
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left('some error').bind(lambda _: 'unit test') == Left('some error')


# Generated at 2022-06-21 18:57:01.900578
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.unit import Unit

    assert (Right(Unit).to_lazy() == Lazy(lambda: Unit))
    assert (Left(Unit).to_lazy() == Lazy(lambda: Unit))


# Generated at 2022-06-21 18:57:04.159863
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).is_left() == False



# Generated at 2022-06-21 18:57:20.715361
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left("Left")
    assert left.bind(lambda a: Right("Right")) == left


# Generated at 2022-06-21 18:57:23.677568
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(5) == Right(5).to_maybe()


# Generated at 2022-06-21 18:57:26.029873
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left({'a': 1, 'b': 2}).ap(Try(lambda x: x['b'])).is_left()


# Generated at 2022-06-21 18:57:29.553900
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(5).to_try() == \
        Try(5, is_success=False)
    assert Right(5).to_try() == \
        Try(5, is_success=True)


# Generated at 2022-06-21 18:57:30.385638
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None


# Generated at 2022-06-21 18:57:35.861368
# Unit test for method ap of class Either
def test_Either_ap():
    result_success = (Either.right(lambda x: x + 3)).ap(Either.right(1))
    assert result_success == Either.right(4)
    result_fail = (Either.right(lambda x: x + 3)).ap(Either.left('message'))
    assert result_fail == Either.left('message')

# Generated at 2022-06-21 18:57:37.355096
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left(1).is_right()
    assert Right(1).is_right()

# Generated at 2022-06-21 18:57:39.981294
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Arrange
    instance = Either(None)

    # Act
    result = instance.is_right()

    # Assert
    assert not result


# Generated at 2022-06-21 18:57:42.806907
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    mapper = lambda x: x + 1
    actual = left.map(mapper)
    assert actual == left
    assert actual is not left


# Generated at 2022-06-21 18:57:44.718910
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('test').is_right() == False


# Generated at 2022-06-21 18:58:16.983965
# Unit test for method map of class Left
def test_Left_map():
    left = Left('value')
    assert left.map('I am another value') == left



# Generated at 2022-06-21 18:58:18.879312
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True
    assert Left(1).is_right() is False


# Generated at 2022-06-21 18:58:24.915198
# Unit test for constructor of class Left
def test_Left():
    assert Left("").__eq__(Left(""))
    assert not Left("").__eq__("")
    assert not Left("").__eq__(Right(""))
    assert Left("").value == ""
    assert isinstance(Left(""), Either)
    assert isinstance(Left(""), Left)
    assert isinstance(Left(""), Generic)
    assert not isinstance(Left(""), Right)



# Generated at 2022-06-21 18:58:26.468732
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(2)
    assert not left.is_right()


# Generated at 2022-06-21 18:58:28.040769
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Left(lambda x: x * 2)) == Left(1)


# Generated at 2022-06-21 18:58:30.149575
# Unit test for method bind of class Left
def test_Left_bind():
    """
        Left.bind(Function(A) -> Either[B]) -> Left[A]
    """
    assert Left(5).bind(lambda x: Right(x + 5)) == Left(5)



# Generated at 2022-06-21 18:58:37.238586
# Unit test for method case of class Either
def test_Either_case():
    """
    Unit test for method case of class Either.
    To run test: python -m unittest -v unit_tests.test_either
    """
    import unittest

    class TestCase(unittest.TestCase):

        def test_Right_value_and_Right_handler(self):
            """
            Test value of Right with Right handler
            """
            result = Right(2).case(lambda x: x/0, lambda x: x*3)
            self.assertEqual(result, 6)

        def test_Right_value_and_Left_handler(self):
            """
            Test value of Right with Left handler
            """
            result = Right(2).case(lambda x: x/0, lambda x: x*3)
            self.assertEqual(result, 6)


# Generated at 2022-06-21 18:58:39.271412
# Unit test for method is_left of class Left
def test_Left_is_left():
    one = 1
    left = Left(one)
    assert left.is_left()



# Generated at 2022-06-21 18:58:41.904412
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    right = right.bind(lambda x: Left(x + 1))
    assert left == right



# Generated at 2022-06-21 18:58:43.771887
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(5)
    assert right.is_left() == False


# Generated at 2022-06-21 18:59:13.080695
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True



# Generated at 2022-06-21 18:59:14.982090
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-21 18:59:18.247301
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Try(Right(5).to_maybe()) == Try.just(Maybe.just(5))



# Generated at 2022-06-21 18:59:20.295637
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Test is_right method of class Either.

    :return: Nothing
    """
    assert Left(1).is_right() == False
    assert Right(2).is_right() == True

# Generated at 2022-06-21 18:59:22.520056
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(["Error"]).to_maybe() == Maybe.nothing(), 'Either.left().to_maybe() should return Nothing'


# Generated at 2022-06-21 18:59:24.047099
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(2).is_right() is False
    print('Left test_is_right was successful')



# Generated at 2022-06-21 18:59:25.233956
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left('error').is_right()


# Generated at 2022-06-21 18:59:26.320809
# Unit test for constructor of class Right
def test_Right():
    left = Right(1)

    assert left.value == 1


# Generated at 2022-06-21 18:59:28.102543
# Unit test for constructor of class Left
def test_Left():
    expect(Left('error')).to_be_instance_of(Left)


# Generated at 2022-06-21 18:59:30.414462
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from .lazy import Lazy

    value = Right(5)
    assert value.to_lazy() == Lazy(5)


# Generated at 2022-06-21 19:00:31.005860
# Unit test for method map of class Right
def test_Right_map():
    assert Right(5).map(lambda x: x+2) == Right(7)
    assert Right(5).map(lambda x: x+"a") == Right("5a")
    assert Right(4).map(lambda x: x+2).map(lambda x: x*2) == Right(12)


# Generated at 2022-06-21 19:00:36.621413
# Unit test for method case of class Either
def test_Either_case():
    def error(value: str) -> int:
        return int(value)

    def success(value: str) -> int:
        return int(value)

    assert(Left('10').case(error, success) == 10)
    assert(Right('10').case(error, success) == 10)


# Generated at 2022-06-21 19:00:39.177153
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Right(1)



# Generated at 2022-06-21 19:00:42.683744
# Unit test for method to_box of class Either
def test_Either_to_box():
    left = Left(1)
    right = Right(1)

    left_box = left.to_box()
    right_box = right.to_box()

    assert left_box.is_same(Box(left.value))
    assert right_box.is_same(Box(right.value))


# Generated at 2022-06-21 19:00:45.269917
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)

# Generated at 2022-06-21 19:00:47.812157
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-21 19:00:51.551756
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Test transforms correctly Either to Validation.

    :returns: successfull Validation monad with previous value
    :rtype: Validation
    """
    from pymonet.validation import Validation

    assert Right(3).to_validation() == Validation.success(3)

# Generated at 2022-06-21 19:00:55.459771
# Unit test for method bind of class Left
def test_Left_bind():
    # When: call method bind of instance of Left, then:
    callable_mock = mock.Mock()
    result = Either.Left(1).bind(callable_mock)

    # Then: should return result of Left, should not call mapper
    assert result == Either.Left(1)
    assert callable_mock.call_count == 0


# Generated at 2022-06-21 19:00:57.204131
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right()



# Generated at 2022-06-21 19:01:02.614333
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Checks if method is_right returns correct boolean value.

    :returns: Nothing
    :rtype: None
    """
    right_value = Right(1)
    left_value = Left(2)
    assert right_value.is_right()
    assert not left_value.is_right()


# Generated at 2022-06-21 19:03:28.878019
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) != Right(2)
    assert Right(1) != Left(2)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Left(1) != Left("1")
    assert Left("1") != Left("2")


# Generated at 2022-06-21 19:03:30.606872
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(10).bind(lambda x: Right(x + 5)).is_left()


# Generated at 2022-06-21 19:03:32.144619
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(0)
    assert left.is_right() is False


# Generated at 2022-06-21 19:03:33.272272
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-21 19:03:39.237032
# Unit test for constructor of class Either
def test_Either():
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)
    assert not Left(10) != Left(10)
    assert not Right(10) != Right(10)
    assert Left(10).value == 10
    assert Right(10).value == 10


# Generated at 2022-06-21 19:03:40.533209
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(4).to_box() == Either(4).value


# Generated at 2022-06-21 19:03:41.798115
# Unit test for constructor of class Right
def test_Right():
    right = Right(123)
    assert type(right) == Right



# Generated at 2022-06-21 19:03:51.425163
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    import pytest

    right_value = Right(5)
    right_none = Right(None)

    validation_value = right_value.to_validation()
    assert isinstance(validation_value, Validation)
    assert validation_value.is_success()
    assert not validation_value.has_failed()
    assert validation_value.get_value_or_error() == 5

    validation_none = right_none.to_validation()
    assert isinstance(validation_none, Validation)
    assert validation_none.is_success()
    assert not validation_none.has_failed()
    assert validation_none.get_value_or_error() is None



# Generated at 2022-06-21 19:03:53.027063
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-21 19:03:56.547962
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(5).to_validation() == Validation.fail([5])
