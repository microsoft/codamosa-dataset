

# Generated at 2022-06-21 18:54:52.948760
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x + 1)) == \
        Left(1)



# Generated at 2022-06-21 18:54:54.173585
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()


# Generated at 2022-06-21 18:55:05.026138
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Either('value').to_lazy() == Lazy(lambda: 'value')
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either(Maybe('value')).to_lazy() == Lazy(lambda: Maybe('value'))
    assert Either(Try('value')).to_lazy() == Lazy(lambda: Try('value'))
    assert Either(Validation('value')).to_lazy() == Lazy(lambda: Validation('value'))

# Generated at 2022-06-21 18:55:06.378251
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(0).is_right(), 'Left is not right'



# Generated at 2022-06-21 18:55:08.017876
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(100).ap(Right(lambda x: 2 ** x)) == Left(100)



# Generated at 2022-06-21 18:55:10.478519
# Unit test for method case of class Either
def test_Either_case():
    value = Either.Right(10).case(lambda x: 'error', lambda x: 'success')

    assert value == 'success'

    value = Either.Left(10).case(lambda x: 'error', lambda x: 'success')

    assert value == 'error'

# Generated at 2022-06-21 18:55:18.371875
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Unit tests for method to_box of class Either"""

    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)
    assert Left(Lazy(1)).to_box() == Box(Lazy(1))
    assert Right(Lazy(1)).to_box() == Box(Lazy(1))


# Generated at 2022-06-21 18:55:20.565781
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right('value')
    assert right.to_maybe() == Right('value').to_maybe()


# Generated at 2022-06-21 18:55:25.828948
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Right(Box(None)).to_try() == Try(Box(None))
    assert Left(Box(None)).to_try() == Try(Box(None), False)


# Generated at 2022-06-21 18:55:29.522607
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    maybe = Left(2).to_validation()

    assert isinstance(maybe, Validation)
    assert maybe == Validation.fail([2])


# Generated at 2022-06-21 18:55:34.554842
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(2).to_validation().is_success() == False
    assert Left(2).to_validation().get_errors() == [2]


# Generated at 2022-06-21 18:55:36.605841
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(2).to_box().value == 2
    assert Left(2).to_box().value == 2


# Generated at 2022-06-21 18:55:38.226091
# Unit test for constructor of class Either
def test_Either():
    def test_true():
        assert True
    test_true()

# Generated at 2022-06-21 18:55:41.394397
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(1)
    # When
    result = left.bind(lambda value: Right(value + 1))
    # Then
    assert result == left


# Generated at 2022-06-21 18:55:44.630142
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    e = Left(None)

    # When
    result = e.to_lazy()

    # Then
    assert result.value() is None


# Generated at 2022-06-21 18:55:45.814697
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('test').ap(Right(len)) == Left('test')


# Generated at 2022-06-21 18:55:47.666259
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left("Error").is_right()


# Generated at 2022-06-21 18:55:58.782612
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Either(0).to_try() == Try(0, is_success=True)
    assert Either(1).to_try() == Try(1, is_success=True)
    assert Either(-1).to_try() == Try(-1, is_success=True)
    assert Either(False).to_try() == Try(False, is_success=True)
    assert Either(True).to_try() == Try(True, is_success=True)
    assert Either("True").to_try() == Try("True", is_success=True)
    assert Either("False").to_try() == Try("False", is_success=True)
    assert Either("").to_try() == Try("", is_success=True)
    assert Either(1.1).to_try()

# Generated at 2022-06-21 18:56:01.078155
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(2).to_box() == Box(2)


# Generated at 2022-06-21 18:56:03.364577
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left('error').is_right()
    assert Right(10).is_right()


# Generated at 2022-06-21 18:56:16.633089
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def get_value() -> str: return 'first'

    def get_first_letter() -> str: return 'f'

    def get_longest_word() -> str: return 'longest'

    def get_first_letter_of_longest() -> str: return 'l'

    assert Either(get_value()).to_lazy() == Lazy(get_value) == Lazy(get_value)

    assert Either(get_value())\
        .bind(lambda x: Either(get_first_letter()))\
        .to_lazy() == Lazy(lambda: get_first_letter()) == Lazy(get_first_letter)

    assert Either(get_value())\
        .bind(lambda x: Either(get_first_letter()))\
       

# Generated at 2022-06-21 18:56:18.178996
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == None

# Generated at 2022-06-21 18:56:21.469306
# Unit test for method ap of class Either
def test_Either_ap():
    """
    Left should not change by ap
    """
    assert Left(1).ap(None) == Left(1)
    assert Left(1) == Left(1)
    assert Left(1).ap(Right(2)) == Left(1)


# Generated at 2022-06-21 18:56:25.485055
# Unit test for method ap of class Left
def test_Left_ap():
    """Test ap method of Left class."""

    class TestLeft(Left[int]):
        pass

    left = TestLeft(1)
    assert left.ap(
        left
    ) == TestLeft(1)

# Generated at 2022-06-21 18:56:26.912962
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Either(1).to_box() == Box(1)


# Generated at 2022-06-21 18:56:29.331360
# Unit test for method is_right of class Right
def test_Right_is_right():
    right_instance = Right(None)
    result = right_instance.is_right()
    assert result == True


# Generated at 2022-06-21 18:56:32.211180
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    validation = Left('error').to_validation()

    assert isinstance(validation, Validation)
    assert validation.is_fail()
    assert validation.get_value() == ['error']


# Generated at 2022-06-21 18:56:34.144401
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    foo = Either(3)
    bar = Either(4)
    eq_(foo, foo)
    assert foo != bar


# Generated at 2022-06-21 18:56:35.298871
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('Left').is_left()


# Generated at 2022-06-21 18:56:39.150591
# Unit test for method case of class Either
def test_Either_case():
    assert Right(10).case(lambda x: x * -1, lambda x: x * 2) == 20
    assert Left(10).case(lambda x: x * -1, lambda x: x * 2) == -10

# Generated at 2022-06-21 18:56:51.383209
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def add3(a):
        return a + 3

    def add3_box(a):
        return Box(add3(a))

    def add3_try(a):
        return Try(add3(a))

    assert Right(add3).ap(Box(3)) == Right(6)
    assert Left(add3).ap(Box(3)) == Left(add3)
    assert Right(add3_box).ap(Box(3)) == Right(6)
    assert Right(add3_try).ap(Box(3)) == Right(6)
    assert Left(add3_try).ap(Box(3)) == Left(add3_try)
    assert Right(add3_box).ap(Left(3)) == Left

# Generated at 2022-06-21 18:56:57.768054
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Left(x + 1)) == Left(1)
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1)
    assert Left(1).bind(lambda x: Box(x + 1)) == Left(1)
    assert Left(1).bind(lambda x: Try(x + 1, is_success=True)) == Left(1)
    assert Left(1).bind(lambda x: Try(x + 1, is_success=False)) == Left(1)



# Generated at 2022-06-21 18:57:02.267430
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left('Error')
    left2 = Left(B())
    right1 = Right('Success')
    right2 = Right(B())
    assert left1 == left2
    assert right1 == right2
    assert left1 != right2
    assert left2 != right1



# Generated at 2022-06-21 18:57:07.036740
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1) and\
        Right(1).to_validation().is_success() and\
        Right(1).to_validation().is_fail() is False


# Generated at 2022-06-21 18:57:10.697494
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    r = Right("Right")
    v = r.to_validation()

    assert isinstance(v, Right)
    assert v.is_right()
    assert v.value == "Right"


# Generated at 2022-06-21 18:57:13.694788
# Unit test for method ap of class Left
def test_Left_ap():
    instance = Left(0)
    result = instance.ap(Left(lambda x: x + 1))
    expected = Left(0)
    assert result == expected


# Generated at 2022-06-21 18:57:15.997783
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(False).is_left() is True
    assert Left(False).is_right() is False


# Generated at 2022-06-21 18:57:18.201934
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(10)
    right = Right(lambda x: x + 2)

    assert left.ap(right) == left



# Generated at 2022-06-21 18:57:20.761625
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('Error').to_validation() == Validation.fail(['Error'])


# Generated at 2022-06-21 18:57:26.233434
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def mapper(value):
        return Maybe.just(value)

    assert Right(3).bind(mapper) == Maybe.just(3)
    assert Right(4).bind(
        lambda x: Box(3 + x)) == Box(7)



# Generated at 2022-06-21 18:57:38.360289
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Either(1), Either)
    assert isinstance(Left(1), Either)
    assert isinstance(Right(1), Either)

# Unit tests for method case of class Either

# Generated at 2022-06-21 18:57:49.378353
# Unit test for method case of class Either
def test_Either_case():
    """
    Test case method of Either class and it's subclasses.

    Expected results:
    - Left.case should be called, Right.case should not
    - Right.case should be called, Left.case should not
    """
    left = Left(0)
    right = Right(1)

    right_case_called = False
    right_case_value = None

    left_case_called = False
    left_case_value = None

    def success(value: int) -> bool:
        nonlocal right_case_called
        nonlocal right_case_value
        right_case_called = True
        right_case_value = value
        return True

    def error(value: int) -> bool:
        nonlocal left_case_called
        nonlocal left_case_value
        left_case_called = True


# Generated at 2022-06-21 18:57:50.865043
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(3).is_left() == True



# Generated at 2022-06-21 18:57:53.216865
# Unit test for method bind of class Left
def test_Left_bind():
    """Unit test for method bind of class Left"""
    left = Left('error')

    assert left.bind('error') == left



# Generated at 2022-06-21 18:57:55.341959
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Left("error").to_try() == Try("error", is_success=False)
    assert Right("result").to_try() == Try("result", is_success=True)


# Generated at 2022-06-21 18:57:57.645615
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(10).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:57:59.756797
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-21 18:58:01.129181
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right('value').to_validation() == Validation.success('value')

# Generated at 2022-06-21 18:58:06.307379
# Unit test for constructor of class Either
def test_Either():
    assert Left(None) == Left(None)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Left(None) != None
    assert Right(None) != None

# Unit tests for method case

# Generated at 2022-06-21 18:58:08.125372
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    #Given
    e = Left(5)
    #When
    maybe = e.to_maybe()
    #Then
    assert maybe.is_nothing()


# Generated at 2022-06-21 18:58:28.001712
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)
    assert Right(0).to_maybe() == Maybe.just(0)
    assert Right(100).to_maybe() == Maybe.just(100)
    assert Right(199).to_maybe() == Maybe.just(199)


# Generated at 2022-06-21 18:58:31.643833
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(7).to_validation() == Validation.success(7)



# Generated at 2022-06-21 18:58:33.238286
# Unit test for constructor of class Either
def test_Either():
    assert Left('test') == Left('test')
    assert Right('test') == Right('test')



# Generated at 2022-06-21 18:58:35.896775
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() == False
    assert Right(1).is_right() == True


# Generated at 2022-06-21 18:58:38.167747
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    right = Right(lambda x: x * 2)
    assert right.ap(left) == left



# Generated at 2022-06-21 18:58:40.698789
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-21 18:58:42.881425
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(error=lambda value: value + 1, success=lambda value: value - 1) == 0


# Generated at 2022-06-21 18:58:45.756839
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Left(1).to_maybe() == Nothing()
    assert Left(1).to_maybe() != Just(1)



# Generated at 2022-06-21 18:58:46.831080
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda error: error + 1, lambda error: error + 2) == 3



# Generated at 2022-06-21 18:58:49.005960
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(True).to_validation() == Validation.fail([True]), 'Left.to_validation() should return Validation ' \
                                                                   'instance with stored value as error'


# Generated at 2022-06-21 18:59:24.725962
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x * 2).ap(Right(2)) == Right(4)
    assert Left(2).ap(Right(3)) == Left(2)


# Generated at 2022-06-21 18:59:27.843152
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Unit test for method is_right of class Either.

    >>> test_Either_is_right()
    True
    True
    """
    actual = Right(1).is_right()
    expected = True
    assert expected == actual

    actual = Left(1).is_right()
    expected = False
    assert expected == actual


# Generated at 2022-06-21 18:59:29.730725
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left("Some error")
    assert left.is_right() is False


# Generated at 2022-06-21 18:59:34.783274
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.monad_try import Try

    just = Left(1)
    applicative = Try(lambda x: x * 3)

    result = just.ap(applicative)
    assert isinstance(result, Left)
    assert result == Left(1)



# Generated at 2022-06-21 18:59:36.735002
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:59:39.013602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f():
        return 1

    assert Right(1).to_lazy() == f()
    assert Left("").to_lazy() == f()



# Generated at 2022-06-21 18:59:41.348528
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().get() == 2
    assert Left(1).to_lazy().get() == 1


# Generated at 2022-06-21 18:59:43.151471
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + x) == Right(2)


# Generated at 2022-06-21 18:59:44.722195
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left() == True
    assert Left(None).is_right() == False



# Generated at 2022-06-21 18:59:46.257862
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 19:00:59.013611
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() is True



# Generated at 2022-06-21 19:01:03.888865
# Unit test for constructor of class Either
def test_Either():
    # Unit test for construction with left value
    def test_left():
        assert Left(1) == Left(1)
    # Unit test for construction with right value
    def test_right():
        assert Right(1) == Right(1)
    test_left()
    test_right()


# Generated at 2022-06-21 19:01:10.130645
# Unit test for method map of class Left
def test_Left_map():
    value = Left(20)
    assert value.map(lambda x: x*2) == Left(20)
    assert value.map(lambda x: x+20) == Left(20)
    assert value.map(lambda x: x-10) == Left(20)
    assert value.map(lambda x: 0) == Left(20)
    assert value.map(lambda x: 'a') == Left(20)


# Generated at 2022-06-21 19:01:11.589073
# Unit test for constructor of class Left
def test_Left():
    assert(Left(1) == Left(1))



# Generated at 2022-06-21 19:01:12.432750
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3


# Generated at 2022-06-21 19:01:15.231508
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.box import Box

    assert Right(None).bind(lambda x: Box(x)).is_unit()
    assert Right(1).bind(lambda x: Box(x)).unbox() == 1
    assert Right(1).bind(lambda x: Box(2)).unbox() == 2


# Generated at 2022-06-21 19:01:17.155278
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(2).to_validation() == Validation.fail([2])


# Generated at 2022-06-21 19:01:19.126377
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    success = Right(1)

    assert success.to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:01:22.373137
# Unit test for method map of class Left
def test_Left_map():
    """

    :returns: None
    :rtype: None
    """
    assert Left(5).map(lambda x: x + 5) == Left(5)



# Generated at 2022-06-21 19:01:29.037428
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def sum_of_list(list_):
        return sum(list_)

    result = Left(2).ap(Box(sum_of_list))
    assert(result == Left(2))

    result = Left(2).ap(Try(sum_of_list, is_success=True))
    assert(result == Left(2))

    result = Left(2).ap(Lazy(sum_of_list))
    assert(result == Left(2))


# Generated at 2022-06-21 19:04:31.888522
# Unit test for method ap of class Left
def test_Left_ap():
    def add_one(val):
        return val + 1

    def sq(val):
        return val * val

    assert(Left(5).ap(Left(add_one)) == Left(5))
    assert(Left(5).ap(Right(add_one)) == Left(5))


# Generated at 2022-06-21 19:04:35.948988
# Unit test for constructor of class Left
def test_Left():
    assert Left(10) == Left(10)
    assert Left(10) != Left(20)
    assert Left(10) != Right(10)
    assert Left(10) != 10


# Generated at 2022-06-21 19:04:39.714250
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation().is_failed()
    assert Left(1).to_validation().get_errors() == [1]


# Generated at 2022-06-21 19:04:41.179891
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-21 19:04:46.513059
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # when
    either_value = Right(lambda x: x + 1)
    box_value = Box(1)
    lazy_value = Lazy(lambda: 1)

    # then
    assert either_value.ap(box_value) == Right(2)
    assert either_value.ap(lazy_value) == Right(2)

# Generated at 2022-06-21 19:04:48.268053
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation() == Validation.success(1)
