

# Generated at 2022-06-21 18:54:50.785125
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-21 18:54:52.411994
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(10).is_right() is False


# Generated at 2022-06-21 18:54:55.966738
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(5) != Right(5)
    assert Right(5) != Left(5)
    assert Left(5) != Right(6)
    assert Right(5) != Left(6)


# Generated at 2022-06-21 18:54:57.577273
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert left.is_right() == False


# Generated at 2022-06-21 18:55:00.671270
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Either(1)
    assert Left(1) == Either(1)
    assert Left(1) == Left(1)


# Generated at 2022-06-21 18:55:08.142087
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def _equal(first, second):
        if isinstance(first, Lazy) and isinstance(second, Lazy):
            return first.is_wrapped() is second.is_wrapped() and first.is_wrapped() and first._function() == second._function()
        return False

    assert _equal(Left(1).to_lazy(), Lazy(lambda: 1))
    assert _equal(Right(1).to_lazy(), Lazy(lambda: 1))


# Generated at 2022-06-21 18:55:10.372174
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(10).to_maybe() == Maybe.just(10)



# Generated at 2022-06-21 18:55:15.551822
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)
    assert Left('a').to_box() == Box('a')
    assert Right('a').to_box() == Box('a')


# Generated at 2022-06-21 18:55:18.413531
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    assert left.ap(Left(2)) == Left(1)
    assert left.ap(Right(2)) == Left(1)



# Generated at 2022-06-21 18:55:22.979371
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> Right(True).case(lambda _: 1, lambda _: 2)
    2

    >>> Left(False).case(lambda _: 1, lambda _: 2)
    1
    """
    pass

# Generated at 2022-06-21 18:55:30.980241
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(1)
    validation = Validation.fail([1])
    assert left.to_validation() == validation


# Generated at 2022-06-21 18:55:31.623991
# Unit test for method bind of class Right
def test_Right_bind():
    pass

# Generated at 2022-06-21 18:55:33.508695
# Unit test for constructor of class Left
def test_Left():
    left = Left(12)
    assert left.value == 12

test_Left()



# Generated at 2022-06-21 18:55:36.379186
# Unit test for method case of class Either
def test_Either_case():
    assert Either(10).case(lambda x: -x, lambda x: x) == 10
    assert Either(-10).case(lambda x: -x, lambda x: x) == 10



# Generated at 2022-06-21 18:55:40.781905
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(3).to_try().is_success() is False
    assert Left(3).to_try().is_failure() is True
    assert Right(3).to_try().is_success() is True
    assert Right(3).to_try().is_failure() is False


# Generated at 2022-06-21 18:55:43.402332
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)



# Generated at 2022-06-21 18:55:45.521132
# Unit test for method bind of class Left
def test_Left_bind():
    m = Either.case(lambda x: 10, lambda x: x + 5)
    assert m(Left(1)) == 10
    assert m(Right(1)) == 6



# Generated at 2022-06-21 18:55:49.458966
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """ Tests the to_maybe method of Left class. """
    from pymonet.maybe import Maybe

    either = Left(1)
    maybe = either.to_maybe()
    assert maybe == Maybe.nothing()


# Generated at 2022-06-21 18:55:51.921296
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either.unit(1).to_try().is_success()
    assert Either.failure(1).to_try().is_failure()

# Generated at 2022-06-21 18:55:54.957306
# Unit test for method is_right of class Either
def test_Either_is_right():
    right: Either[int] = Right(1)
    left: Either[int] = Left('error')
    assert right.is_right() == True
    assert left.is_right() == False


# Generated at 2022-06-21 18:55:59.595115
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left.bind(Left(1), lambda x: Right(x + 2)) == Left(1)


# Generated at 2022-06-21 18:56:05.520933
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Right(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Right(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Right(1).bind(lambda x: Box(x + 1)) == Box(2)


# Generated at 2022-06-21 18:56:06.700972
# Unit test for constructor of class Right
def test_Right():
    assert Right(42).value == 42


# Generated at 2022-06-21 18:56:08.911259
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda arg: arg + 1) == left


# Generated at 2022-06-21 18:56:14.579614
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3) == Right(3)
    assert Left(3) == Left(3)
    assert Left(3) != Right(3)
    assert Right(3) != Left(3)
    assert Left(3) != 4
    assert Left(3) != [3]
    assert Right(3) != 4
    assert Right(3) != [3]


# Generated at 2022-06-21 18:56:16.259988
# Unit test for constructor of class Right
def test_Right():
    assert Right(5).value == 5


# Generated at 2022-06-21 18:56:17.668660
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(5).to_validation() == Validation.success(5)

# Generated at 2022-06-21 18:56:21.469300
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    validation = Left(8).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_fail() == True
    assert validation.is_success() == False
    assert validation.value == [8]


# Generated at 2022-06-21 18:56:23.968158
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    assert Right("a").to_validation() == Validation.success("a")


# Generated at 2022-06-21 18:56:29.925533
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box

    if not isinstance(Left(2).ap(Box(lambda x: x + 2)), Left):
        assert False, "Should be Left"

    if Left(2).ap(Box(lambda x: x + 2)) != Left(2):
        assert False, "Should be equal"



# Generated at 2022-06-21 18:56:40.777350
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Test method to_maybe of class Left.

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe

    assert isinstance(Left(1).to_maybe(), Maybe)
    assert Left(1).to_maybe().is_nothing()


# Generated at 2022-06-21 18:56:41.852537
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) is not None


# Generated at 2022-06-21 18:56:47.869730
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import ValidationError
    from pymonet.validation import ValidationSuccess
    result = Right(ValidationError([ValidationError(ValidationSuccess(1))])).to_validation()
    assert result is not None
    assert result.is_success() is True
    assert result.value == ValidationError([ValidationError(ValidationSuccess(1))])
    assert result.errors == []


# Generated at 2022-06-21 18:56:49.722936
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x * 2) == Left(1)



# Generated at 2022-06-21 18:56:53.265564
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    either = Right(2)
    adder = Right(lambda x: x + 2)

    # When
    result = either.ap(adder)

    # Then
    assert result == Right(4)



# Generated at 2022-06-21 18:56:56.141926
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left('').to_maybe().is_empty() is True
    assert Left('').to_maybe().is_just() is False
    assert Left(None).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:56:58.420480
# Unit test for constructor of class Right
def test_Right():
    right = Right('right')
    assert right.value == 'right'
    assert right.is_right() == True
    assert right.is_left() == False
    assert isinstance(right, Either)


# Generated at 2022-06-21 18:56:59.779436
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: x + 1) == Left(1)



# Generated at 2022-06-21 18:57:01.846950
# Unit test for method bind of class Right
def test_Right_bind():
    result = Left('error').bind(lambda x: Right(x))
    assert result == Left('error')

    result = Right(10).bind(lambda x: Right(x * 10))
    assert result == Right(100)



# Generated at 2022-06-21 18:57:03.596756
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == None


# Generated at 2022-06-21 18:57:17.797766
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() == True
    assert Left(1).is_right() == False
    assert Left(None).is_right() == False
    assert Right(None).is_right() == True



# Generated at 2022-06-21 18:57:21.098275
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    unit_right = Right(1).to_lazy()
    unit_left = Left(1).to_lazy()
    assert isinstance(unit_right, Lazy)
    assert isinstance(unit_left, Lazy)
    assert unit_right.invoke() == 1
    assert unit_left.invoke() == 1


# Generated at 2022-06-21 18:57:26.029867
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    other_left = Left(1)
    right = Right(1)
    other_right = Right(1)
    assert left == other_left
    assert right == other_right
    assert left != other_right
    assert right != other_left



# Generated at 2022-06-21 18:57:28.902762
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    result = Box(2)
    assert result.to_box() == Box(2).to_box()
    assert Right(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)



# Generated at 2022-06-21 18:57:32.301093
# Unit test for method bind of class Left
def test_Left_bind():
    # given
    value = 10
    left = Left(value)

    # when
    result = left.bind(lambda x: Right(x + 1))

    # then
    assert(result == Left(value))



# Generated at 2022-06-21 18:57:38.659630
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """Unit test for method to_validation(self) of class Right"""
    from pymonet.validation import Validation
    error = [1, "error"]
    right_value = [2]
    assert Right(right_value).to_validation() == Validation.success(right_value)
    assert Left(error).to_validation() == Validation.fail(error)


# Generated at 2022-06-21 18:57:41.573210
# Unit test for method map of class Right
def test_Right_map():
    value = 123
    result = Right(value).map(lambda x: x + 1)

    assert isinstance(result, Right)
    assert result == Right(value + 1)


# Generated at 2022-06-21 18:57:44.477952
# Unit test for method ap of class Either
def test_Either_ap():
    right_tuple = Right((lambda x, y: x + y, 1, 2))
    assert right_tuple.ap(Right(1)) == Right(4)



# Generated at 2022-06-21 18:57:50.572241
# Unit test for method map of class Right
def test_Right_map():
    # GIVEN instance of Right with value 12
    right = Right(12)

    # WHEN map it with lambda x: x * 2
    mapped = right.map(lambda x: x * 2)

    # THEN mapped value is 24 and is instance of Right
    assert isinstance(mapped, Either)
    assert isinstance(mapped, Right)
    assert mapped.value == 24


# Generated at 2022-06-21 18:57:51.827122
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(2).is_right() == True



# Generated at 2022-06-21 18:58:18.077134
# Unit test for method bind of class Right
def test_Right_bind():
    assert Left(1).bind(lambda x: x) == Left(1)
    assert Right(5).bind(lambda x: Right(x * 3)) == Right(15)



# Generated at 2022-06-21 18:58:19.895314
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    initial_left = Left(0)

    # When
    left_after_bind = initial_left.bind(lambda x: Right(x))

    # Expect
    assert left_after_bind == Left(0)



# Generated at 2022-06-21 18:58:21.939920
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)


# Generated at 2022-06-21 18:58:27.440485
# Unit test for constructor of class Either
def test_Either():
    # Test for class Left
    left = Left(4)
    assert left.value == 4
    assert left.is_left() is True
    assert left.is_right() is False

    # Test for class Right
    right = Right(4)
    assert right.value == 4
    assert right.is_left() is False
    assert right.is_right() is True



# Generated at 2022-06-21 18:58:31.111460
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: x) == Left(1)


# Generated at 2022-06-21 18:58:32.584000
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-21 18:58:34.452895
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(None) == Right(None).to_lazy().force()


# Generated at 2022-06-21 18:58:36.634849
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('str').is_left() == True


# Generated at 2022-06-21 18:58:40.333119
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)

# Generated at 2022-06-21 18:58:41.818634
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(10).is_left() is True


# Generated at 2022-06-21 18:59:00.599413
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Left(42).to_try() == Right(42).to_try() == Try(42, is_success=False)
    assert Left('error').to_try() == Right('error').to_try() == Try('error', is_success=False)


# Generated at 2022-06-21 18:59:03.151188
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.maybe import Maybe

    assert Maybe(1).is_right() is True
    assert Maybe(None).is_right() is False



# Generated at 2022-06-21 18:59:07.500917
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_value = Right(5).to_lazy()
    assert lazy_value.__class__.__name__ == 'Lazy'
    assert lazy_value.value() == 5
    lazy_value = Left(5).to_lazy()
    assert lazy_value.__class__.__name__ == 'Lazy'
    assert lazy_value.value() == 5


# Generated at 2022-06-21 18:59:08.902340
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # when
    result = Either(None)

    # then
    assert result is not None


# Generated at 2022-06-21 18:59:14.207459
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 2) == Right(4)
    assert Right(3).map(lambda x: x + 2) == Right(5)
    assert Right(None).map(lambda x: x + 2) == Right(2)
    assert Right(None).map(lambda x: x + 2) != Right(3)


# Generated at 2022-06-21 18:59:21.100137
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.box import Box
    def test():
        return 12

    assert Right(test).to_lazy() == Lazy(lambda: test())
    assert Left(12).to_lazy() == Lazy(lambda: 12)


# Generated at 2022-06-21 18:59:22.525680
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:59:24.185744
# Unit test for method is_right of class Right
def test_Right_is_right():
    real_test = Right(2).is_right()

    assert real_test == True


# Generated at 2022-06-21 18:59:27.429264
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    t1 = Either(1)
    t2 = Either(Exception('Exception'))
    assert t1.to_try() == Try(1)
    assert t2.to_try() == Try(Exception('Exception'))

# Generated at 2022-06-21 18:59:28.544959
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-21 19:00:02.304420
# Unit test for method map of class Right
def test_Right_map():
    # Set up
    right = Right(2)
    mapper = lambda x: x+1

    # Test
    result = right.map(mapper)

    # Asserts
    assert isinstance(result, Right)
    assert result == Right(3)



# Generated at 2022-06-21 19:00:03.181421
# Unit test for constructor of class Right
def test_Right():
    assert 5 == Right(5).value


# Generated at 2022-06-21 19:00:06.341147
# Unit test for method bind of class Left
def test_Left_bind():
    left_value = Left(5)
    result = left_value.bind(lambda x: Left(x + 5))
    assert result.is_left()
    assert result.value == 5


# Generated at 2022-06-21 19:00:08.473000
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(4).bind(lambda x: x // 3) == Right(4 // 3)



# Generated at 2022-06-21 19:00:09.956817
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 19:00:11.390284
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-21 19:00:17.195609
# Unit test for method map of class Right
def test_Right_map():
    def add(arg):
        assert arg == 1, "Right with right value fail map function"
        return arg + 1

    right = Right(1)
    right_result = right.map(add)
    assert right_result.is_right(), "Right.map return Left"
    assert right_result.value == 2, "Right.map return wrong value"



# Generated at 2022-06-21 19:00:20.264267
# Unit test for constructor of class Left
def test_Left():
    """Test for constructor of class Left"""
    assert isinstance(Left(1), Left) and\
        isinstance(Left(1), Either) and\
        Left(1).value == 1


# Generated at 2022-06-21 19:00:25.003802
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)

# Generated at 2022-06-21 19:00:26.537812
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()


# Generated at 2022-06-21 19:01:29.069908
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)



# Generated at 2022-06-21 19:01:31.385298
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left('error').to_validation() == Validation.fail(['error'])


# Generated at 2022-06-21 19:01:32.878333
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(56).to_maybe() == Maybe.just(56)


# Generated at 2022-06-21 19:01:34.651194
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() == True



# Generated at 2022-06-21 19:01:38.547866
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Either: test method to_validation of class Right
    """
    from pymonet.validation import Validation
    result = Right(2).to_validation()
    assert result == Validation.success(2)


# Generated at 2022-06-21 19:01:40.869106
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 19:01:42.896165
# Unit test for constructor of class Left
def test_Left():
    """
    >>> test_Left()
    Left(3)
    """
    left = Left(3)
    print(left)



# Generated at 2022-06-21 19:01:48.520120
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try

    def add(a: int, b: int) -> int:
        return a + b

    left_result = Left(add).ap(Left(5)).ap(Right(5))
    right_result = Right(add).ap(Right(5)).ap(Right(5))

    # __eq__ tests
    assert left_result.is_left() is True
    assert right_result.is_right() is True

    # case tests
    assert left_result.case(lambda x: x.apply(5, 5), lambda x: x.apply(5, 5)) == add(5, 5)
    assert right_result.case(lambda x: x.apply(5, 5), lambda x: x.apply(5, 5)) == add(5, 5)

    # test for types


# Generated at 2022-06-21 19:01:49.932922
# Unit test for method is_right of class Left
def test_Left_is_right():
    """ Test for method is_right of class Left """
    assert Left(1).is_right() is False


# Generated at 2022-06-21 19:01:52.935529
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right([1, 2, 3]).bind(lambda x: Left('Error')) == Left('Error')
    assert Right([1, 2, 3]).bind(lambda x: Right([1, 2, 3])) == Right([1, 2, 3])

# Generated at 2022-06-21 19:04:20.724683
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('error')

    assert left.is_left() is True



# Generated at 2022-06-21 19:04:21.765266
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('error').is_left() == True



# Generated at 2022-06-21 19:04:23.646598
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(10).bind(lambda v: Right(v * 2)) == Left(10)



# Generated at 2022-06-21 19:04:25.916817
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    x = Left('error occured')
    y = x.to_maybe()

    assert isinstance(y, Maybe)
    assert y.is_nothing()


# Generated at 2022-06-21 19:04:30.795880
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(3)

    try:
        assert right.to_maybe().is_just()
    except AssertionError:
        print('AssertionError')

# Unittest for method to_maybe of class Left

# Generated at 2022-06-21 19:04:34.242224
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:04:40.006358
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        return lambda y: y + x

    assert Right(add(2)).ap(Right(2)) == Right(4)
    assert Right(add(2)).ap(Left(None)) == Left(None)
    assert Left(None).ap(Right(2)) == Left(None)
    assert Left(None).ap(Left(None)) == Left(None)



# Generated at 2022-06-21 19:04:43.188848
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-21 19:04:44.216788
# Unit test for constructor of class Right
def test_Right():
    assert Right('result') == Right('result')


# Generated at 2022-06-21 19:04:46.173115
# Unit test for constructor of class Left
def test_Left():
    left = Left('error')
    assert left.value == 'error'

