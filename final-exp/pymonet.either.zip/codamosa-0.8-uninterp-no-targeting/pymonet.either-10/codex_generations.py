

# Generated at 2022-06-21 18:54:53.742101
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-21 18:54:55.324085
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: Right(x + 3)) == Right(6)



# Generated at 2022-06-21 18:54:58.797425
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(1).to_box() == Box(1), "Left(1).to_box() should return Box(1)"
    assert Right(1).to_box() == Box(1), "Right(1).to_box() should return Box(1)"


# Generated at 2022-06-21 18:55:01.208553
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Left(x ** 2)) == Left(2)


# Generated at 2022-06-21 18:55:05.857960
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(
        error=lambda x: x + 10,
        success=lambda x: x - 10
    ) == 11

    assert Right(1).case(
        error=lambda x: x + 10,
        success=lambda x: x - 10
    ) == -9


# Generated at 2022-06-21 18:55:07.491569
# Unit test for method is_left of class Left
def test_Left_is_left():
    """Test Left is left"""
    assert Left(None).is_left()



# Generated at 2022-06-21 18:55:08.993356
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(5).bind(lambda a: Right(a + 5)).value == 10


# Generated at 2022-06-21 18:55:10.672147
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left(2).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:55:15.997636
# Unit test for method map of class Left
def test_Left_map():
    # Given
    left = Left(1)
    # When
    when_left = left.map(lambda x: x * x)
    # Then
    expect_left = left
    assert when_left == expect_left


#Unit test for method  bind of class Left

# Generated at 2022-06-21 18:55:19.138787
# Unit test for method bind of class Left
def test_Left_bind():
    # Given
    left = Left(12)

    # When
    result = left.bind(lambda x: Left(x**2))

    # Then
    assert result == left



# Generated at 2022-06-21 18:55:27.017803
# Unit test for constructor of class Either
def test_Either():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(5) != Right(5)
    assert Right(5) != Left(5)



# Generated at 2022-06-21 18:55:30.227520
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    actual = Left(1).to_validation()
    expected = Validation.fail([1])
    assert actual == expected


# Generated at 2022-06-21 18:55:38.316272
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Right(lambda x: x * 2).ap(Right(5)) == Right(10)
    assert Left(lambda x: x * 2).ap(Right(5)) == Left(lambda x: x * 2)
    assert Try(lambda x: x * 2).ap(Right(5)) == Try(10)
    assert Lazy(lambda x: x * 2).ap(Right(5)) == Lazy(10)
    assert Box(lambda x: x * 2).ap(Right(5)) == Box(10)


# Generated at 2022-06-21 18:55:43.053269
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Left(130).to_validation(), Validation)
    assert Left(130).to_validation().is_fail()
    assert Left(130).to_validation().is_fail([130])


# Generated at 2022-06-21 18:55:46.220985
# Unit test for constructor of class Left
def test_Left():
    assert Left([]) == Left([])
    assert Left(1) == Left(1)
    assert Left(True) == Left(True)
    assert Left(None) == Left(None)
    assert Left([1, 2, 3]) == Left([1, 2, 3])



# Generated at 2022-06-21 18:55:57.805112
# Unit test for constructor of class Left
def test_Left():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    f = lambda x: "xxx"
    l = Left(123)

    assert(l.value == 123)
    assert(l.case(lambda e: e, lambda s: "failed") == 123)
    assert(l.to_box() == Box(123))
    assert(l.to_try() == Try(123, is_success=False))
    assert(l.to_lazy() == Lazy(lambda: 123))
    assert(l.to_maybe() == Maybe.nothing())
    assert(l.to_validation() == Validation.fail([123]))

# Generated at 2022-06-21 18:55:58.701324
# Unit test for constructor of class Right
def test_Right():
    assert Right(42).value == 42


# Generated at 2022-06-21 18:56:00.578669
# Unit test for constructor of class Right
def test_Right():
    """Unit test for constructor of class Right
    """
    assert Right(1) == Right(1)

# Generated at 2022-06-21 18:56:02.905394
# Unit test for constructor of class Either
def test_Either():
    """Unit test for constructor of class Either."""
    assert Left(1) == Left(1)


# Generated at 2022-06-21 18:56:03.834427
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)


# Generated at 2022-06-21 18:56:08.322976
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True

# Generated at 2022-06-21 18:56:13.116761
# Unit test for method ap of class Either
def test_Either_ap():
    # Given
    a = Left(lambda x: x * x)
    b = Right(3)

    # When
    result = a.ap(b)

    # Then
    assert 9 == result.value
    assert "Right(9)" == repr(result)


# Generated at 2022-06-21 18:56:16.922133
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True
    assert Left(2).is_left() == True
    assert Left('str').is_left() == True
    assert Right(2).is_left() != True
    assert Right(None).is_left() != True
    assert Right([]).is_left() != True


# Generated at 2022-06-21 18:56:19.742033
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(1)) == Right(2)
    assert Left(1).ap(Right(1)) == Left(1)

# Generated at 2022-06-21 18:56:22.599990
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: 2*x) == Right(2)

# Unit test of method map of class Left

# Generated at 2022-06-21 18:56:24.878279
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: x + 2) == 4



# Generated at 2022-06-21 18:56:27.118610
# Unit test for method case of class Either
def test_Either_case():
    left = Left("error")
    assert left.case(
        error=lambda x: x,
        success=lambda x: x
    ) == "error"

    right = Right("success")
    assert right.case(
        error=lambda x: x,
        success=lambda x: x
    ) == "success"



# Generated at 2022-06-21 18:56:28.106717
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_righ

# Generated at 2022-06-21 18:56:31.826856
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    >>> test_Either_is_right()
    True
    """
    e1 = Right(1)
    e2 = Left(1)

    return e1.is_right() and not e2.is_right()

# Generated at 2022-06-21 18:56:35.941750
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    # When
    result = Either.right(1).to_box()
    # Then
    assert isinstance(result, Box)
    assert result.value == 1

    # When
    result = Either.left(1).to_box()
    # Then
    assert isinstance(result, Box)
    assert result.value == 1


# Generated at 2022-06-21 18:56:41.083696
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-21 18:56:44.770123
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(5).to_lazy() == \
        Lazy(lambda: 5)
    assert Left(3).to_lazy() == \
        Lazy(lambda: 3)


# Generated at 2022-06-21 18:56:48.593609
# Unit test for method case of class Either
def test_Either_case():
    left = Left(1)
    right = Right(2)
    assert left.case(lambda x: x + 1, lambda y: y - 1) == 2
    assert right.case(lambda x: x + 1, lambda y: y - 1) == 1


# Generated at 2022-06-21 18:56:51.980951
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left("error").to_lazy() == Lazy(lambda: "error")


# Generated at 2022-06-21 18:56:54.183174
# Unit test for method map of class Left
def test_Left_map():
    value = 1
    obj = Left(value)
    assert obj.map(lambda x: x + 1) == Left(value)



# Generated at 2022-06-21 18:56:56.724487
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)



# Generated at 2022-06-21 18:56:58.622563
# Unit test for method to_validation of class Left
def test_Left_to_validation():

    left = Left(1)
    validation = left.to_validation()

    assert validation.is_failed()
    assert validation.fail == [1]



# Generated at 2022-06-21 18:57:01.004673
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    SomeClass = namedtuple('SomeClass', ['name'])
    right = Right(SomeClass(name='someName'))
    assert right.to_maybe() == Maybe.just(SomeClass(name='someName'))



# Generated at 2022-06-21 18:57:05.655035
# Unit test for constructor of class Right
def test_Right():
    from pymonet.maybe import Maybe

    assert Right("test").map(lambda x: "test_result") == Right("test_result")
    assert Right("test").bind(lambda x: Right("test_result")) == Right("test_result")

# Generated at 2022-06-21 18:57:10.743890
# Unit test for method is_right of class Either
def test_Either_is_right():

    # given
    left = Left(2)
    right = Right(4)

    # when
    result = left.is_right()

    # then
    assert result == False

    # when
    result = right.is_right()

    # then
    assert result == True



# Generated at 2022-06-21 18:57:18.154090
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False


# Generated at 2022-06-21 18:57:21.288792
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(0).bind(lambda a: a + 1) == Left(0)
    assert Left("").bind(str.upper) == Left("")


# Generated at 2022-06-21 18:57:24.447050
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(1)
    right = Right(1)
    assert left.is_right() is False
    assert right.is_right() is True


# Generated at 2022-06-21 18:57:26.975770
# Unit test for method map of class Left
def test_Left_map():
    assert Left(18).map(lambda x: x * 2) == Left(18)


# Generated at 2022-06-21 18:57:28.022417
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(2).to_maybe().is_just()

# Generated at 2022-06-21 18:57:33.710290
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    left = Left(100)
    assert left.ap(Box(lambda a: a + 100)) == Box(100)
    assert left.ap(Maybe.just(lambda a: a + 100)) == Maybe.nothing()
    assert left.ap(Try.success(lambda a: a + 100)) == Try(None)
    assert left.ap(Lazy(lambda a: a + 100)) == Lazy(lambda: 100)



# Generated at 2022-06-21 18:57:37.758636
# Unit test for method bind of class Left
def test_Left_bind():
    x = Left(2).bind(lambda x: Left(x))
    assert x == Left(2)
    x = Left(2).bind(lambda x: Right(x))
    assert x == Left(2)


# Generated at 2022-06-21 18:57:39.250057
# Unit test for constructor of class Right
def test_Right():
    right = Right(2)
    assert right.value == 2


# Generated at 2022-06-21 18:57:41.077923
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:57:42.723844
# Unit test for constructor of class Either
def test_Either():
    assert isinstance(Left(3), Either)
    assert isinstance(Right(3), Either)



# Generated at 2022-06-21 18:57:55.434022
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(42).ap(Left(lambda x: x + 1)) == Left(42)



# Generated at 2022-06-21 18:57:58.259475
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)


# Generated at 2022-06-21 18:58:02.900351
# Unit test for method case of class Either
def test_Either_case():
    assert Left(20).case(
        error=lambda x: x * 2,
        success=lambda y: y + 1
    ) == 40
    assert Right(20).case(
        error=lambda x: x * 2,
        success=lambda y: y + 1
    ) == 21



# Generated at 2022-06-21 18:58:05.496921
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(7).to_lazy() == Lazy(lambda: 7)
    assert Right(7).to_lazy() == Lazy(lambda: 7)


# Generated at 2022-06-21 18:58:07.525921
# Unit test for constructor of class Left
def test_Left():
    # GIVEN
    value = 'some value'
    left = Left(value)

    # THEN
    assert left.value == value


# Generated at 2022-06-21 18:58:11.026697
# Unit test for method to_try of class Either
def test_Either_to_try():
    try_r = Either.to_try(Right(True))
    try_l = Either.to_try(Left(True))
    assert try_r == Try(True, True)
    assert try_l == Try(True, False)

# Generated at 2022-06-21 18:58:13.080270
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() == None


# Generated at 2022-06-21 18:58:17.232633
# Unit test for method case of class Either
def test_Either_case():

    def error(value):
        return value / 0

    def success(value):
        return value

    assert Left(1).case(error, success) == 1
    assert Right(1).case(error, success) == 1



# Generated at 2022-06-21 18:58:20.577679
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Right(10).bind(lambda x: Maybe.just("Hello " + str(x))) == Maybe.just("Hello 10")
    assert Right("").bind(lambda x: Maybe.just("Hello " + str(x))) == Maybe.just("Hello ")
    assert Right("Hello").bind(lambda x: Try.fail("Hello")) == Try.fail("Hello")

# Generated at 2022-06-21 18:58:21.608932
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False


# Generated at 2022-06-21 18:58:42.106588
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("error").to_lazy() == Lazy(lambda: "error")
    assert Right("success").to_lazy() == Lazy(lambda: "success")


# Generated at 2022-06-21 18:58:43.163795
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False



# Generated at 2022-06-21 18:58:45.932613
# Unit test for constructor of class Either
def test_Either():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)



# Generated at 2022-06-21 18:58:49.935151
# Unit test for method ap of class Either
def test_Either_ap():
    success = Either.right(lambda x: x + 1)
    assert success.ap(Either.right(2)) == Either.right(3)
    assert success.ap(Either.left(2)) == Either.left(2)
    error = Either.left(lambda x: x + 1)
    assert error.ap(Either.right(2)) == Either.left(2)
    assert error.ap(Either.left(2)) == Either.left(2)

# Generated at 2022-06-21 18:58:51.222380
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False



# Generated at 2022-06-21 18:58:53.742907
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-21 18:58:55.312634
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right()


# Generated at 2022-06-21 18:59:00.700365
# Unit test for method case of class Either
def test_Either_case():
    assert Either(2).case(lambda x: x + 2, lambda y: y - 1) is 1
    assert Left(2).case(lambda x: x + 2, lambda y: y - 1) is 4
    assert Left(2).to_validation().case(lambda x: x + 2, lambda y: y - 1) is 4



# Generated at 2022-06-21 18:59:02.564699
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Right(10).to_maybe(), Maybe)


# Generated at 2022-06-21 18:59:04.281671
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(3).to_maybe() == Right(3).to_box().to_maybe()

# Generated at 2022-06-21 18:59:40.950000
# Unit test for constructor of class Right
def test_Right():
    """
    Check when constructor of Right is called with value it is assigned to self.value
    """
    assert Right(5).value == 5


# Generated at 2022-06-21 18:59:42.103788
# Unit test for constructor of class Right
def test_Right():
    assert Right(3).value == 3


# Generated at 2022-06-21 18:59:43.472147
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()


# Generated at 2022-06-21 18:59:46.382590
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) != 1
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != Right(2)

# Generated at 2022-06-21 18:59:50.612385
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: Left(2)).to_try() == Try(2, is_success=False)
    assert Lazy(lambda: Right(2)).to_try() == Try(2)



# Generated at 2022-06-21 18:59:58.902828
# Unit test for method to_box of class Either
def test_Either_to_box():
    """
    Unit test for method to_box of class Either.

    :return: None
    :rtype: None
    """
    import unittest

    class TestEitherToBox(unittest.TestCase):
        """Test Either to_box method"""

        def test_left_to_box(self):
            """Test Left to_box method"""
            from pymonet.box import Box

            assert Left.of(2).to_box() == Box(2)

        def test_right_to_box(self):
            """Test Left to_box method"""
            from pymonet.box import Box

            assert Right.of(2).to_box() == Box(2)

    unittest.main()


# Generated at 2022-06-21 19:00:01.497745
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Unit test for method to_try of class Either"""
    from pymonet.monad_try import Try
    try_ = Either.Right(1).to_try()
    assert try_ == Try(1)
    try_ = Either.Left(1).to_try()
    assert try_ == Try(1, is_success=False)



# Generated at 2022-06-21 19:00:03.021040
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Left(42).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:00:05.037515
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(3).ap(Left(lambda x: x * 2)) == Left(3)


# Generated at 2022-06-21 19:00:07.491009
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right(2).to_maybe() == Maybe.just(2)


# Generated at 2022-06-21 19:01:25.947094
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left

    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(2).to_try() == Try(2, is_success=False)


# Generated at 2022-06-21 19:01:28.050301
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    actual = Box(1).to_either().to_box()
    expected = Box(1)

    assert expected == actual


# Generated at 2022-06-21 19:01:31.133227
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left('some error').ap(Left(lambda x: x + 1)) == Left('some error')
    assert Left('some error').ap(Right(lambda x: x + 1)) == Left('some error')
    assert Right('some error').ap(Left(lambda x: x + 1)) == Left('some error')
    assert Right(lambda x: x + 1).ap(Right(1)) == Right(2)

# Generated at 2022-06-21 19:01:33.007635
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(5)
    assert left.bind(lambda x: x + 2) == 5



# Generated at 2022-06-21 19:01:34.834160
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left("abc").is_right() == False
    assert Right("abc").is_right() == True


# Generated at 2022-06-21 19:01:37.934751
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)


# Generated at 2022-06-21 19:01:39.198542
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("left").is_left() == True



# Generated at 2022-06-21 19:01:44.728470
# Unit test for method ap of class Either
def test_Either_ap():
    assert\
        Right(lambda x: x + 1).ap(Right(1)) ==\
        Right(2),\
        'Right(lambda x: x + 1).ap(Right(1)) == Right(2)'

    assert\
        Left(1).ap(Right(2)) ==\
        Left(1),\
        'Left(1).ap(Right(2)) == Left(1)'

# Generated at 2022-06-21 19:01:52.940975
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Left(None).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Left("maybe").to_lazy(), Lazy)
    assert isinstance(Right(None).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Right("maybe").to_lazy(), Lazy)

    assert Left(None).to_lazy().call() is None
    assert Left(1).to_lazy().call() == 1
    assert Left("maybe").to_lazy().call() == "maybe"
    assert Right(None).to_lazy().call() is None
    assert Right(1).to_lazy().call()

# Generated at 2022-06-21 19:01:54.399954
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda x: Right(x + 1)) == Left(2)

