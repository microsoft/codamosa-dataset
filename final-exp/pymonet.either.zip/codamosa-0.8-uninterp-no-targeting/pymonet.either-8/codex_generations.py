

# Generated at 2022-06-21 18:54:56.203678
# Unit test for constructor of class Left
def test_Left():
    value = 'some error'
    result = Left(value)
    assert isinstance(result, Left)
    assert isinstance(result.value, str)
    assert result.value == value


# Generated at 2022-06-21 18:54:57.825552
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda x: x + 1) == Right(2)



# Generated at 2022-06-21 18:54:59.639196
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('').is_left() == True


# Generated at 2022-06-21 18:55:09.721633
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_either import Left
    from pymonet.monad_either import Right
    from pymonet.monad_either import Either

    # Test 1
    left = Left(0)
    result = left.bind(lambda x: Either(x))
    assert result == 0

    # Test 2
    left = Left(0)
    result = left.bind(lambda x: Either(x))
    assert result == 0

    # Test 3
    left = Left(0)
    result = left.bind(lambda x: Either(x + 1))
    assert result == 0

    # Test 4
    left = Left(0)
    result = left.bind(lambda x: Right(x + 1))
    assert result == 0


# Generated at 2022-06-21 18:55:17.222364
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-21 18:55:20.345893
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.value == 1


# Generated at 2022-06-21 18:55:25.170623
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    assert Right(5).to_try() == Try(5)
    assert Left("error").to_try() == Try("error", is_success=False)



# Generated at 2022-06-21 18:55:27.181500
# Unit test for constructor of class Either
def test_Either():
    either = Either(1)
    assert either == Either(1)
    assert either.value == 1



# Generated at 2022-06-21 18:55:31.316189
# Unit test for constructor of class Either
def test_Either():
    assert Right(2) == Right(2)
    assert Left(2) == Left(2)
    assert Left(2) != Right(2)
    assert Left(None) == Left(None)
    assert Either(None)


# Generated at 2022-06-21 18:55:36.245775
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda _: 2, lambda v: v + 1) == 2
    assert Right(1).case(lambda _: 2, lambda v: v - 1) == 0

    assert Left(1).case(lambda _: 2, lambda v: v + 1) == 2
    assert Left(1).case(lambda _: 2, lambda v: v - 1) == 2

# Generated at 2022-06-21 18:55:45.924053
# Unit test for method is_right of class Either
def test_Either_is_right():
    # GIVEN
    data_list = [
        # Left[int], Right[int]
        (Left(3), False),
        (Right(3), True)
    ]

    # WHEN
    result_list = [
        (data, monad.is_right())
        for (data, monad) in data_list
    ]

    # THEN
    for ((expected, result), (data, monad)) in zip(result_list, data_list):
        assert expected == result, f'Either.is_right() test fail on {data}'


# Generated at 2022-06-21 18:55:57.500702
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from typing import List, Any, Callable

    either = Right(2)
    # Int or Box[Int]
    obj1: Either[int, Box[int]] = either.bind(lambda v: Box(v + 1))
    assert obj1.value == 3
    # Int or Try[Int]
    obj2: Either[int, Try[int]] = either.bind(lambda v: Try(v).map(lambda v: v + 1))
    assert obj2.value == 3
    # Int or Lazy[Int]
    obj3: Either[int, Lazy[int]] = either.bind(lambda v: Lazy(lambda: v + 1))

# Generated at 2022-06-21 18:55:58.995346
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(10).is_right()



# Generated at 2022-06-21 18:56:01.277631
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert (Lazy(lambda: 10) == Right(10).to_lazy())

# Generated at 2022-06-21 18:56:05.937725
# Unit test for constructor of class Left
def test_Left():
    l_either = Left(None)
    assert isinstance(l_either, Either), "Left should be instance of Either"
    assert isinstance(l_either, Left), "Left should be instance of Left"
    assert l_either.value is None, "Left should store None"



# Generated at 2022-06-21 18:56:16.727933
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert isinstance(Right(1).ap(Right(lambda x: x + 1)), Right)
    assert isinstance(Left('error').ap(Right(lambda x: x + 1)), Left)
    assert isinstance(Right(1).ap(Left('error')), Left)
    assert Right(1).ap(Right(lambda x: x + 1)) == Right(2)
    assert Right(1).ap(Left('error')) == Left('error')
    assert Left('error').ap(Right(lambda x: x + 1)) == Left('error')
    assert Left('error').ap(Left('error')) == Left('error')

    assert Right(1).ap(Validation.just(lambda x: x + 1)) == Validation.just(2)

# Generated at 2022-06-21 18:56:18.269020
# Unit test for constructor of class Right
def test_Right():
    assert Right(2) == Right(2)



# Generated at 2022-06-21 18:56:19.271185
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(x + 1)) == Left(1)



# Generated at 2022-06-21 18:56:21.659496
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)



# Generated at 2022-06-21 18:56:28.333183
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    def return_one():
        """
        :returns: 1
        :rtype: int
        """
        return 1

    assert Right(2).to_lazy() == Lazy(return_one)
    assert Left(2).to_lazy() == Lazy(return_one)


# Generated at 2022-06-21 18:56:31.375875
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:56:34.021185
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Left(1).to_try() == Try(1, False)
    assert Right(1).to_try() == Try(1, True)


# Generated at 2022-06-21 18:56:35.953354
# Unit test for method map of class Left
def test_Left_map():
    left = Left(10)
    assert left.map(lambda x: x * 2) == Left(10)



# Generated at 2022-06-21 18:56:38.878864
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Given
    right = Right(1)
    # Then
    assert right.is_right() is True


# Generated at 2022-06-21 18:56:43.606887
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    # Test for left with None value
    left = Left(None)
    assert left.to_maybe() == Maybe()

    # Test for left with some value
    left = Left(10)
    assert left.to_maybe() == Maybe()


# Generated at 2022-06-21 18:56:45.340833
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left() == True


# Generated at 2022-06-21 18:56:55.078274
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try

    def function_to_apply(a):
        return a * 2

    value = 2
    error = RuntimeError('test')

    assert Right(value).to_lazy().ap(Right(function_to_apply)).value == 4
    assert Left(error).to_lazy().ap(Right(function_to_apply)).value == error
    assert Right(value).to_lazy().ap(Left(error)).value == error

    assert Try(value, is_success=True).to_lazy().ap(Right(function_to_apply)).value == 4
    assert Try(error, is_success=False).to_lazy().ap(Right(function_to_apply)).value == error

# Generated at 2022-06-21 18:56:58.020311
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('error').is_right() is False, 'Not fails Either is_right'
    assert Right('success').is_right() is True, 'Not success Either is_right'


# Generated at 2022-06-21 18:56:59.798810
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Maybe.nothing() == Left(None).to_maybe()



# Generated at 2022-06-21 18:57:03.597424
# Unit test for method bind of class Left
def test_Left_bind():
    # GIVEN monad Either with value 1
    # WHEN call bind with mapper throwing exception
    # THEN return self
    left = Left(1)
    assert left.bind(lambda t: t/0) == left



# Generated at 2022-06-21 18:57:07.955522
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([5]) == Left(5).to_validation()



# Generated at 2022-06-21 18:57:10.598268
# Unit test for method map of class Right
def test_Right_map():
    mapper = lambda x: x + 1

    assert Right(1).map(mapper) == Right(2)



# Generated at 2022-06-21 18:57:12.092806
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(42).is_right()



# Generated at 2022-06-21 18:57:14.125167
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 18:57:16.742082
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Validation.fail([1]) == Left(1).to_validation()

# Generated at 2022-06-21 18:57:17.769531
# Unit test for constructor of class Either
def test_Either():
    assert 5 == Either(5).value



# Generated at 2022-06-21 18:57:19.431140
# Unit test for method is_right of class Right
def test_Right_is_right():
    r = Right(1)
    assert r.is_right()


# Generated at 2022-06-21 18:57:27.970326
# Unit test for constructor of class Left
def test_Left():
    from pymonet.test_utils import assert_is
    from pymonet.test_utils import assert_is_not
    from pymonet.test_utils import assert_equal
    from pymonet.test_utils import assert_not_equal

    assert_is(Left('test'), Left('test'))
    assert_is_not(Left('test'), Left('test2'))
    assert_equal(Left('test'), Left('test'))
    assert_not_equal(Left('test'), Left('test2'))


# Generated at 2022-06-21 18:57:29.290555
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('value').is_left() is False


# Generated at 2022-06-21 18:57:30.378251
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:57:34.480665
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert (Left(1).to_maybe() == Maybe.nothing())


# Generated at 2022-06-21 18:57:37.858804
# Unit test for method bind of class Right
def test_Right_bind():
    value = 10
    f = lambda x: Right(x * 2)
    g = lambda x: Right(x * 3)
    assert Right(value).bind(f).bind(g) == Right(6 * value)

# Generated at 2022-06-21 18:57:39.346958
# Unit test for method is_right of class Either
def test_Either_is_right():
    result = Right(10).is_right()
    assert result == True


# Generated at 2022-06-21 18:57:40.752324
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert(Left(None).is_left() == True)


# Generated at 2022-06-21 18:57:46.706214
# Unit test for method ap of class Left
def test_Left_ap():
    left: Left[Callable[[int], str]] = Left(lambda x: str(x))
    right_value: Either[int] = Right(2)
    left_value: Either[int] = Left(3)

    assert(left.ap(right_value) == left)
    assert(left.ap(left_value) == left)


# Generated at 2022-06-21 18:57:48.095881
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(123).is_left()

# Generated at 2022-06-21 18:57:50.708954
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(2)


# Generated at 2022-06-21 18:57:51.966281
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Right(2).is_right(), bool)


# Generated at 2022-06-21 18:57:53.184005
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:57:54.717998
# Unit test for constructor of class Either
def test_Either():
    assert str(Left(1)) == "Left(1)"
    assert str(Right(1)) == "Right(1)"



# Generated at 2022-06-21 18:58:03.506373
# Unit test for method is_right of class Right
def test_Right_is_right():
    right = Right(1)
    assert right.is_right() == True


# Generated at 2022-06-21 18:58:07.001997
# Unit test for method bind of class Right
def test_Right_bind():
    """Test bind method of Right class."""
    right = Right(1)
    right_bind_result = right.bind(lambda a: Right(a + 1))
    assert isinstance(right_bind_result, Right) and\
        right_bind_result.value == 2

# Generated at 2022-06-21 18:58:10.856611
# Unit test for method to_box of class Either
def test_Either_to_box():
    left = Left(3)
    right = Right(3)
    left_box = left.to_box()
    right_box = right.to_box()
    assert left_box == Box(3)
    assert right_box == Box(3)


# Generated at 2022-06-21 18:58:18.553213
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)

    assert right.__eq__(Right(1)) is True
    assert right.value == 1
    assert right.is_right() is True
    assert right.is_left() is False

    assert right.__eq__(Right(2)) is False
    assert right.__eq__(Left(1)) is False
    assert right.__eq__(Left(2)) is False
    assert right.__eq__('') is False



# Generated at 2022-06-21 18:58:22.152626
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 18:58:23.960109
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)
    assert right.value == 1


# Generated at 2022-06-21 18:58:25.995761
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(lambda x: x + 1)) == Left(1)


# Generated at 2022-06-21 18:58:28.001145
# Unit test for constructor of class Right
def test_Right():
    right = Either.Right(1)
    assert right.value == 1
    assert isinstance(right, Right)


# Generated at 2022-06-21 18:58:36.752920
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.functions import compose
    from pymonet.box import Box

    func_to_test = compose(
        Either.to_try,
        Box.to_either
    )
    func_to_test_left = compose(
        Either.to_try,
        Box.to_either,
        Box.fail
    )

    assert func_to_test(Box(True)) == Try(True)
    assert func_to_test_left(Box(False)) == Try(False, is_success=False)

    def f(x):
        return x

    assert func_to_test(Box(None)).map(f).is_failure()
    assert func_to_test(Box(None)).map(f).is_failure()

# Generated at 2022-06-21 18:58:41.724259
# Unit test for method ap of class Either
def test_Either_ap():
    """
    >>> from pymonet.either import Left, Right
    >>> Left(2).ap(Right(lambda x: x + 3))
    Left(2)
    >>> Right(5).ap(Right(lambda x: x + 3))
    Right(8)
    """



# Generated at 2022-06-21 18:58:51.146803
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left("foo").to_box() == Box("foo")
    assert Right("foo").to_box() == Box("foo")


# Generated at 2022-06-21 18:58:53.649948
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(42) == Right(42).bind(lambda x: Right(x))
    assert Left(42) == Right(42).bind(lambda x: Left(x))



# Generated at 2022-06-21 18:58:56.233105
# Unit test for method bind of class Left
def test_Left_bind():
    def test_mapper(value):
        return Right(value)

    assert Left(14).bind(test_mapper) == Left(14)



# Generated at 2022-06-21 18:58:57.751414
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(2).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:59:02.481642
# Unit test for constructor of class Left
def test_Left():
    # Arrange
    value = "Some text"

    # Act
    left = Left(value)

    # Assert
    assert isinstance(left, Left)
    assert left.value == value
    assert left.case(lambda _: True, lambda _: False)


# Generated at 2022-06-21 18:59:03.754759
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right("1").is_right() is True



# Generated at 2022-06-21 18:59:05.449788
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)


# Generated at 2022-06-21 18:59:07.615443
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box
    assert Right(1).to_box() == Box(1)
    assert Left(2).to_box() == Box(2)


# Generated at 2022-06-21 18:59:09.703464
# Unit test for method ap of class Left
def test_Left_ap():
    value = Left('failure')
    result = value.ap(Either.from_value(lambda x: x))
    expected = 'failure'
    assert result.value == expected



# Generated at 2022-06-21 18:59:11.429899
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left("error").to_maybe()


# Generated at 2022-06-21 18:59:31.494693
# Unit test for method case of class Either
def test_Either_case():
    def add(arg1, arg2):
        return arg1 + arg2

    def mul(arg1, arg2):
        return arg1 * arg2

    either = Right(2)

    assert either.case(lambda x: x ** 2, lambda x: x * 2) == 4
    assert either.case(lambda x: x ** 2, add)(2) == 4
    assert either.case(lambda x: x ** 2, mul)(3) == 6

    either = Left(2)
    assert either.case(lambda x: x ** 2, lambda x: x * 2) == 4



# Generated at 2022-06-21 18:59:34.176165
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 18:59:36.905095
# Unit test for constructor of class Right
def test_Right():
    right = Right(2)
    assert right.value == 2
    assert right.is_right() is True
    assert right.is_left() is False


# Generated at 2022-06-21 18:59:38.168894
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.Nothing


# Generated at 2022-06-21 18:59:47.527534
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    @function_wrapper
    def test_same_value_of_each_type_of_Either():
        left_either = Left(1)
        right_either = Right(1)

        assert left_either == left_either
        assert not left_either == right_either
        assert right_either == right_either
        assert not right_either == left_either

    @function_wrapper
    def test_different_values_of_Each():
        left_either_a = Left(1)
        left_either_b = Left(2)
        right_either_a = Right(1)
        right_either_b = Right(2)

        assert not left_either_a == left_either_b
        assert not right_either_a == right_either_b

    test_same_value_of_each_type_of_

# Generated at 2022-06-21 18:59:53.768683
# Unit test for method ap of class Either
def test_Either_ap():
    result = Left(10).ap(Left(lambda x: x + 2))
    assert result == Left(10)

    result = Left(10).ap(Right(lambda x: x + 2))
    assert result == Left(10)

    result = Right(10).ap(Left(lambda x: x + 2))
    assert result == Left(10)

    result = Right(10).ap(Right(lambda x: x + 2))
    assert result == Right(12)



# Generated at 2022-06-21 18:59:55.680978
# Unit test for constructor of class Either
def test_Either():
    left = Left(2)
    right = Right(2)

    assert left.value == 2
    assert right.value == 2



# Generated at 2022-06-21 18:59:58.069181
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(None).to_maybe()
    assert Maybe.nothing() == Left(object).to_maybe()



# Generated at 2022-06-21 18:59:58.904055
# Unit test for constructor of class Either
def test_Either():
    assert Either(10).value == 10


# Generated at 2022-06-21 19:00:01.131139
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left('test')
    assert left.bind(lambda x: x + 'q') == left


# Generated at 2022-06-21 19:00:30.260169
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    a = Right(1)
    b = a.to_validation()
    assert a.value == b.value
    assert b.is_success()


# Generated at 2022-06-21 19:00:33.569888
# Unit test for method map of class Left
def test_Left_map():
    import pytest

    # Test for method map in Left class
    assert Left(1).map(lambda x: x+1) == Left(1)

# Generated at 2022-06-21 19:00:41.004271
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Test bind on Right

    >>> from pymonet.either import Right, Left
    >>> def add_one(x: int) -> Either[int]:
    ...     if x == 1:
    ...         return Left(x)
    ...     return Right(x + 1)

    >>> Right(10).bind(add_one) == Right(11)
    True
    >>> Right(1).bind(add_one) == Left(1)
    True

    """
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 19:00:42.392865
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()



# Generated at 2022-06-21 19:00:46.463186
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    # Prepare
    error = "left value"
    left = Left(error)
    # Execute
    actual = left.to_maybe()
    # Assert
    from pymonet.maybe import Maybe
    assert actual == Maybe.nothing()


# Generated at 2022-06-21 19:00:49.308761
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-21 19:00:50.863064
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:00:57.371762
# Unit test for constructor of class Right
def test_Right():
    from pymonet.func import partial
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    # If a value of type E is a Right, then the right projection returns that Right value.
    right = Right(1)
    assert right.value == 1

    # If a value of type E is a Left, then the right projection returns the value unchanged.
    left = Left(2)
    assert left.value == 2
    assert left == Left(2)

    # If a value of type E is a Right, then the left projection returns a null value.
    assert right.ap(Lazy(lambda: lambda x: x + 3)) == Right(4)

# Generated at 2022-06-21 19:00:59.934710
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(1).is_right() is False
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True

# Generated at 2022-06-21 19:01:03.719503
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    right = Right(5)
    maybe = right.to_maybe()
    assert maybe.is_something()
    assert maybe.value == 5
    assert right.to_maybe().case(None, lambda x: True)


# Generated at 2022-06-21 19:01:40.506141
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.either import Left
    from pymonet.box import Box

    result = Left(Box(lambda x: x + 3)).ap(Left(Box(lambda x: x + 2)))
    expected = Left(Box(lambda x: x + 3))
    assert result == expected



# Generated at 2022-06-21 19:01:43.051804
# Unit test for method bind of class Left
def test_Left_bind():
    assert type(Left(1).bind(lambda x: Right(x))) is Left
    assert Left(1).bind(lambda x: Right(x)) == Left(1)



# Generated at 2022-06-21 19:01:45.886624
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    assert Right(2).to_try() == Try(2, True)
    assert Left(2).to_try() == Try(2, False)

# Generated at 2022-06-21 19:01:47.380852
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(1).bind(lambda x: Right(x + 1)) == Right(2)


# Generated at 2022-06-21 19:01:48.484900
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(10).is_left() is False



# Generated at 2022-06-21 19:01:50.015387
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(10).is_right() is False


# Generated at 2022-06-21 19:01:51.630864
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(['error1', 'error2'])
    assert left.to_lazy().get() == ['error1', 'error2']

    right = Right(1)
    assert right.to_lazy().get() == 1


# Generated at 2022-06-21 19:01:53.014500
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('some_value').is_left() is False



# Generated at 2022-06-21 19:01:54.131840
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() is False


# Generated at 2022-06-21 19:01:58.683996
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()


# Generated at 2022-06-21 19:03:12.938786
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(None)
    assert Right(1) == Right(1)
    assert Right(1) != Right(None)
    assert Right(1) != Left(1)


# Generated at 2022-06-21 19:03:16.688706
# Unit test for method ap of class Left
def test_Left_ap():
    left_a = Left(0)
    left_b = Left(0)
    assert left_a.ap(left_b) == left_b.ap(left_a)


# Generated at 2022-06-21 19:03:18.721962
# Unit test for constructor of class Either
def test_Either():
    assert Right(1).is_right()
    assert Left(1).is_left()



# Generated at 2022-06-21 19:03:20.371096
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Right(lambda v: v + 2)) == Left(1)



# Generated at 2022-06-21 19:03:22.231393
# Unit test for method map of class Right
def test_Right_map():
    assert Right(3).map(lambda x: x ** 2) == Right(9)


# Generated at 2022-06-21 19:03:25.135220
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Test method is_right of generic class Either.
    """
    assert Right(7).is_right()
    assert Left(7).is_right() is False



# Generated at 2022-06-21 19:03:29.006815
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x + 1) == Right(3)
    assert Right(2).map(lambda x: x ** 2) == Right(4)
    assert Right(2).map(lambda x: x / 0) == Right(4)


# Generated at 2022-06-21 19:03:31.789507
# Unit test for method map of class Left
def test_Left_map():
    """
    Should return Left with the same value as the argument.
    """
    left = Left('not_a_number')
    assert left.map(lambda x: x * 2) == left



# Generated at 2022-06-21 19:03:33.671257
# Unit test for method map of class Left
def test_Left_map():
    assert Left(3).map(lambda x: x * 3) == Left(3)

# Generated at 2022-06-21 19:03:36.686649
# Unit test for method is_right of class Right
def test_Right_is_right():
    test_Either = Right("Test")
    assert test_Either.is_right() == True
