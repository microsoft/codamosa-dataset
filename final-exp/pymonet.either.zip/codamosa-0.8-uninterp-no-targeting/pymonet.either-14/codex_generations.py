

# Generated at 2022-06-21 18:54:51.704496
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> isinstance(Left(1).case(lambda x: None, lambda x: False), type(None))
    True
    >>> Left(1).case(lambda x: None, lambda x: False)
    >>> Right(2).case(lambda x: None, lambda x: True)
    True
    """



# Generated at 2022-06-21 18:54:53.652841
# Unit test for method is_right of class Left
def test_Left_is_right():
    """
    >>> from pymonet.either import Left
    >>> Left(2).is_right()
    False
    """
    pass


# Generated at 2022-06-21 18:54:55.558454
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1234).to_validation() is Validation.fail([1234])


# Generated at 2022-06-21 18:54:57.102042
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(2).ap(Right(lambda x: x + 1)) == Left(2)



# Generated at 2022-06-21 18:54:58.408480
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()


# Generated at 2022-06-21 18:55:00.773500
# Unit test for constructor of class Either
def test_Either():
    assert Left("Error").value == "Error"
    assert Right("Success").value == "Success"



# Generated at 2022-06-21 18:55:06.830218
# Unit test for method bind of class Right
def test_Right_bind():
    def add_one(value: int) -> Either[int]:
        return Right(value + 1)

    assert Right(2).bind(add_one) == Right(3)
    assert Right(2).bind(add_one).bind(add_one) == Right(4)
    assert Right(2).bind(add_one).bind(lambda value: Left(value + 1)) == Left(4)


# Generated at 2022-06-21 18:55:09.070273
# Unit test for method is_left of class Right
def test_Right_is_left():
    right_instance = Right(1)

    actual_value = right_instance.is_left()
    expected_value = False

    assert expected_value == actual_value



# Generated at 2022-06-21 18:55:10.337898
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(5).is_right()



# Generated at 2022-06-21 18:55:12.906539
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)
    assert not left.is_right()


# Generated at 2022-06-21 18:55:19.859257
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-21 18:55:21.308825
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(2).to_validation() == Validation.fail([2])


# Generated at 2022-06-21 18:55:23.894181
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)

    assert right.is_left() is False

# Generated at 2022-06-21 18:55:26.101561
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right('I am Right').is_left() == False



# Generated at 2022-06-21 18:55:27.722518
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either(True).is_right() is None


# Generated at 2022-06-21 18:55:28.329459
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(5).ap(Left(5)) == Left(5)


# Generated at 2022-06-21 18:55:33.989387
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left('1')
    assert Right(1) == Right(1)
    assert Right(1) != Right('1')
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != '1'
    assert Right(1) != '1'


# Generated at 2022-06-21 18:55:35.252136
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(1)
    assert right.is_left() is False



# Generated at 2022-06-21 18:55:36.621382
# Unit test for method map of class Right
def test_Right_map():
    assert Right(1).map(lambda v: v + 1) == Right(2)



# Generated at 2022-06-21 18:55:39.069095
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    expected = Validation.success(2)
    actual = Right(2).to_validation()
    assert expected == actual


# Generated at 2022-06-21 18:55:49.257396
# Unit test for constructor of class Left
def test_Left():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Left('Error value') == Left('Error value')

    assert Left('Error value').case(lambda x: x, lambda x: x) == 'Error value'

    assert Left(Box[int](1)).to_box() == Box[int](1)
    assert Left(Maybe[int](1)).to_maybe() == Maybe[int](1)
    assert Left(Validation[int, Any](1)).ap(Validation.fail([1])) == Validation[int, Any](1)
    assert Left(Validation[int, Any]('Error')).to_validation() == Validation[int, Any]('Error')

# Generated at 2022-06-21 18:55:52.586638
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda val: Right(val + 1)).is_left()
    assert not Right(1).bind(lambda val: Right(val + 1)).is_left()


# Generated at 2022-06-21 18:55:56.816302
# Unit test for method ap of class Left
def test_Left_ap():
    # Given
    def add(a, b):
        return a + b
    left = Left(add)

    # When
    result = left.ap(Right(2))

    # Then
    assert isinstance(result, Left)
    assert result == Left(add)


# Generated at 2022-06-21 18:55:58.283298
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:56:04.601552
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(3) == Either(3)
    assert Left(3) == Left(3)
    assert Right(3) == Right(3)
    assert Either(3) != Either(4)
    assert Left(3) != Left(4)
    assert Right(3) != Right(4)
    assert Left(1) != Right(1)
    assert Left(1) != Either(1)
    assert Right(1) != Either(1)

# Generated at 2022-06-21 18:56:06.156841
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(3).is_left() is False



# Generated at 2022-06-21 18:56:11.543191
# Unit test for constructor of class Left
def test_Left():
    from pymonet.monad_instances import monad_instance
    from pymonet.either_instances import either_instance

    @monad_instance(Either)
    def increment(either):
        return either.bind(lambda x: Either.of(x + 1))

    @monad_instance(Either)
    def query_database_by_id(id):
        return Either.of(id)

    @monad_instance(Either)
    def save_to_database(data):
        if data == 1:
            return Left(1)
        return Either.of(data)

    def mangle_data(data):
        if data == 1:
            return 1
        return data + 1


# Generated at 2022-06-21 18:56:12.524503
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Either('foo').is_right() == False
    assert Either(1).is_right() == False



# Generated at 2022-06-21 18:56:13.477621
# Unit test for method is_left of class Right
def test_Right_is_left():
    Right(1).is_left() == False

# Generated at 2022-06-21 18:56:15.770250
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(None)
    right = Right(None)
    assert left.is_left() is True
    assert right.is_left() is False


# Generated at 2022-06-21 18:56:32.041468
# Unit test for method ap of class Either
def test_Either_ap():
    # Partition of method ap without exceptions
    # Given
    right1 = Right(lambda x: x * 2)
    right2 = Right(2)

    # When
    result = right1.ap(right2)

    # Then
    assert result == Right(4)

    # Given
    left1 = Left("Error")
    left2 = Left("Error")

    # When
    result = left1.ap(left2)

    # Then
    assert result == left1

    # Given
    left = Left("Error")
    right = Right(4)

    # When
    result = left.ap(right)

    # Then
    assert result == Left("Error")

    # Given
    left = Left("Error")
    right = Right(lambda x: x * 2)

    # When

# Generated at 2022-06-21 18:56:34.761649
# Unit test for method to_try of class Either
def test_Either_to_try():
    type_error = TypeError('type error')

    assert Left(type_error).to_try() == Try(exception=type_error, is_success=False)
    assert Right(0).to_try() == Try(value=0, is_success=True)


# Generated at 2022-06-21 18:56:36.430896
# Unit test for constructor of class Left

# Generated at 2022-06-21 18:56:37.354531
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert(Left(1).to_maybe() == Maybe.nothing())



# Generated at 2022-06-21 18:56:44.386442
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either(Box(1)).to_box() == Box(1)
    assert Either(Box('abc')).to_box() == Box('abc')
    assert Either(Box(None)).to_box() == Box(None)
    assert Either(Box([])).to_box() == Box([])
    assert Either(Box({})).to_box() == Box({})


# Generated at 2022-06-21 18:56:46.419739
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)


# Generated at 2022-06-21 18:56:49.681105
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    result = Right(1).to_validation()
    assert isinstance(result, Validation) is True
    assert result.is_success() is True
    assert result.value == 1


# Generated at 2022-06-21 18:56:53.586219
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()



# Generated at 2022-06-21 18:56:55.221055
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda _: Right(1)) == Left(2)



# Generated at 2022-06-21 18:56:56.724493
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    left = Left(1)

    assert left.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:57:04.031340
# Unit test for method bind of class Left
def test_Left_bind():
    """
    Test for method bind of class Left
    """
    error_value = "error"
    left = Left(error_value)
    assert left == left.bind(lambda success: success.to_try())
    assert error_value == left.bind(lambda success: success.to_try())


# Generated at 2022-06-21 18:57:06.223610
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(None).is_right() == False


# Generated at 2022-06-21 18:57:11.782389
# Unit test for method bind of class Right
def test_Right_bind():
    """
    Unit test for Right bind.

    :returns: assertion error if unit test failed
    :rtype: AssertionError
    """
    value = "abc"
    mapper = lambda _: Either.left(value)
    assert Right(value).bind(mapper) == mapper(value)



# Generated at 2022-06-21 18:57:17.120881
# Unit test for method case of class Either
def test_Either_case():
    assert(Left("Error").case(lambda x: "error(" + x + ")", lambda x: "success(" + x + ")") == "error(Error)")
    assert(Right("Success").case(lambda x: "error(" + x + ")", lambda x: "success(" + x + ")") == "success(Success)")



# Generated at 2022-06-21 18:57:28.262553
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.functions import compose

    # Case 1: Left with value 1
    left = Left(1)
    result = left.case(
        error=compose(Right, lambda x: x + 1),  # this won't be called
        success=lambda _: None   # this will be called but won't be returned
    )
    assert result is None

    # Case 2: Right with value 1
    right = Right(1)
    result = right.case(
        error=lambda _: None,  # this will be called but won't be returned
        success=compose(Right, lambda x: x + 1)    # this will be called and returned
    )
    expected = Right(2)
    assert result == expected



# Generated at 2022-06-21 18:57:29.451896
# Unit test for constructor of class Right
def test_Right():
    right = Right('right')
    assert right.value == 'right'


# Generated at 2022-06-21 18:57:31.024705
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(1)

    assert left.is_right() == False


# Generated at 2022-06-21 18:57:34.400360
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Left(100).to_box() == Box(100)
    assert Right(100).to_box() == Box(100)


# Generated at 2022-06-21 18:57:36.957092
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.monad_try import Try

    assert Left(5).ap(Try(5)) == Left(5)



# Generated at 2022-06-21 18:57:48.145523
# Unit test for constructor of class Either
def test_Either():
    """
    Test for constructor of class Either.

    :returns: True when test passed, False otherwise
    :rtype: Boolean
    """
    # Test Left constructor
    assert Left(1) == Left(1)
    assert Left(2) is not Left(1)
    assert Left(1) == Either(1)
    assert Left(1).value == 1
    assert Left(1).case(lambda x: False, lambda _: True) is False
    assert Left(1).case(lambda _: True, lambda _: False) is True
    assert Left(1).map(lambda _: 'a') == Left(1)
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).bind(lambda x: Right(x)) == Left(1)
    assert Left(1).ap

# Generated at 2022-06-21 18:57:58.456931
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet import curry

    def add(a, b):
        return a + b

    result = Either(4).to_lazy().map(lambda x: add(x, 5)).get_result()
    assert result == 9
    assert Either(1).to_lazy().map(curry(add)(2)).get_result() == 3
    assert Either('abc').to_lazy().bind(lambda x: Try(x, is_success=True)).get_result() == 'abc'


# Module test for method case of class Either

# Generated at 2022-06-21 18:58:03.631589
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Left(1) != Left(2)
    assert Left(1) != Right(2)
    assert Left(1) != 1
    assert Left(1) != Maybe(1)
    assert Left(1) != Box(1)



# Generated at 2022-06-21 18:58:04.973203
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(0).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:58:07.371631
# Unit test for method map of class Right
def test_Right_map():
    assert Right(5).map(lambda x: x + 1).is_right()
    assert Right(5).map(lambda _: 3).value == 3


# Generated at 2022-06-21 18:58:11.804418
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_x = Left(10)
    left_y = Left(20)
    right_x = Right(10)
    right_y = Right(20)

    assert left_x == left_x
    assert right_x == right_x
    assert left_x != left_y
    assert right_x != right_y



# Generated at 2022-06-21 18:58:13.078642
# Unit test for method is_right of class Left
def test_Left_is_right():
    obj = Left(1)
    assert obj.is_right() == False


# Generated at 2022-06-21 18:58:19.595845
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    data = (1, 2, 3)
    success_data = [2, 3, 4]
    assert Either(data).to_try() == Try(data, True)
    assert Left(data).to_try() == Try(data, False)
    assert Right(data).to_try() == Try(data, True)
    print("test_Either_to_try passed")


# Generated at 2022-06-21 18:58:23.214707
# Unit test for method case of class Either
def test_Either_case():
    assert (Left([1]).case(lambda error: error, lambda success: success) == [1])
    assert (Right(1).case(lambda error: error, lambda success: success) == 1)



# Generated at 2022-06-21 18:58:25.770020
# Unit test for method bind of class Left
def test_Left_bind():
    _Left = Left(1)
    assert _Left.bind(lambda x: x + 1) == _Left


# Generated at 2022-06-21 18:58:26.760011
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right()

# Generated at 2022-06-21 18:58:35.804750
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.optional import Optional

    assert Left('error').to_try() == Try.fail('error')
    assert Right(1).to_try() == Try.success(1)
    assert isinstance(Left('error').to_try(), Try)
    assert isinstance(Left('error').to_try(), Optional)
    assert isinstance(Right(1).to_try(), Try)
    assert isinstance(Right(1).to_try(), Optional)


# Generated at 2022-06-21 18:58:38.510188
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    """
    Unit test for method to_maybe of class Left
    """
    assert(Left(1).to_maybe() == Maybe.nothing())


# Generated at 2022-06-21 18:58:47.166301
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    import pytest

    assert Right(1).to_maybe() == Maybe.just(1)
    assert Right('Some value').to_maybe() == Maybe.just('Some value')
    assert Right(None).to_maybe() == Maybe.just(None)
    assert Right(True).to_maybe() == Maybe.just(True)
    assert Right(False).to_maybe() == Maybe.just(False)
    assert Right([]).to_maybe() == Maybe.just([])
    assert Right([1]).to_maybe() == Maybe.just([1])
    assert Right(['Some value']).to_maybe() == Maybe.just(['Some value'])



# Generated at 2022-06-21 18:58:50.745675
# Unit test for method bind of class Right
def test_Right_bind():
    actual = Right(1).bind(lambda x: Right(x + 1))
    expected = Right(2)
    assert actual == expected



# Generated at 2022-06-21 18:58:52.503502
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    left = Left(1)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:59:02.564661
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    func = lambda a: a ** 2
    left = Left(2)
    right = Right(2)

    assert left.ap(Box(func)) == Box(4)
    assert right.ap(Box(func)) == Box(4)
    assert left.ap(Try(func)) == Try(4)
    assert right.ap(Try(func)) == Try(4)
    assert left.ap(Lazy(lambda: func)) == Lazy(lambda: 4)
    assert right.ap(Lazy(lambda: func)) == Lazy(lambda: 4)

# Generated at 2022-06-21 18:59:06.298615
# Unit test for method map of class Right
def test_Right_map():
    # Arrange
    value = 'myvalue'
    right = Right(value)
    mapper = lambda x: x * 2
    # Act
    result = right.map(mapper)
    # Assert
    assert result == Right(mapper(value))



# Generated at 2022-06-21 18:59:08.372838
# Unit test for constructor of class Left
def test_Left():
    """
    >>> left = Left(1)
    >>> assert isinstance(left, Left)
    >>> assert isinstance(left.value, int)
    """


# Generated at 2022-06-21 18:59:10.013785
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left()


# Generated at 2022-06-21 18:59:15.259523
# Unit test for constructor of class Right
def test_Right():
    left = Left('Something went wrong, man')
    assert isinstance(left, Either)
    assert isinstance(left.value, str)
    assert left.value == 'Something went wrong, man'
    assert left.is_left()
    assert left.is_right() is False



# Generated at 2022-06-21 18:59:26.822152
# Unit test for method case of class Either
def test_Either_case():
    # test for case when left
    assert Left(1).case(lambda: 1, lambda x: 0) == 1

    # test for case when right
    assert Right(3).case(lambda: 1, lambda x: 2) == 2


# Generated at 2022-06-21 18:59:30.360960
# Unit test for method ap of class Left
def test_Left_ap():
    for i in range(100):
        assert Left(i).ap(Left(i + 1)) == Left(i)

    for i in range(100):
        assert Left(i).ap(Right(i + 1)) == Left(i)



# Generated at 2022-06-21 18:59:33.434467
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(21) == Left(21)
    assert Right(21) == Right(21)
    assert Right(21) != Left(21)



# Generated at 2022-06-21 18:59:38.329220
# Unit test for constructor of class Right
def test_Right():
    assert Right(42) == Right(42)
    assert Right(42) != Right(43)
    assert Left(42) != Right(42)
    assert Right(42).is_right()
    assert Left(42).is_left() is False
    assert Right(42).is_left() is False
    assert Left(42).is_right() is False


# Generated at 2022-06-21 18:59:41.348576
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left('error in Left').ap(Left(lambda x: x + 1)) == Left('error in Left')
    assert Left('error in Left').ap(Right(lambda x: x + 1)) == Left('error in Left')

# Generated at 2022-06-21 18:59:44.203346
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(1) != 1


# Generated at 2022-06-21 18:59:47.089893
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    result = Right('Yes').to_validation()
    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.get() == 'Yes'



# Generated at 2022-06-21 18:59:48.763980
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(100)

    assert left.is_right() == False


# Generated at 2022-06-21 18:59:52.214861
# Unit test for method bind of class Right
def test_Right_bind():
    def plus_one(x):
        return x + 1

    def minus_one(x):
        return x - 1

    assert Right(1).bind(plus_one) == 2
    assert Right(1).bind(minus_one) == 0

# Generated at 2022-06-21 18:59:53.985604
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.nothing() == Left(1).to_maybe()



# Generated at 2022-06-21 19:00:15.690892
# Unit test for constructor of class Right
def test_Right():
    right = Right(2)
    assert right.value == 2



# Generated at 2022-06-21 19:00:19.489986
# Unit test for method ap of class Either
def test_Either_ap():

    assert Right(1).ap(Right(lambda x: x + 2)) == Right(3)
    assert Right(1).ap(Left('Error')) == Left('Error')
    assert Left('Error').ap(Right(lambda x: x + 2)) == Left('Error')


# Generated at 2022-06-21 19:00:21.642462
# Unit test for method bind of class Right
def test_Right_bind():
    def f(x: int) -> Either[int]:
        return Right(x + 1)

    result = Right(1).bind(f)
    assert result == Right(2)



# Generated at 2022-06-21 19:00:27.502380
# Unit test for constructor of class Either
def test_Either():
    assert Right(1) == Right(1)
    assert Right(1) != Left([1])
    assert Left([1]) != Right(1)
    assert Left([1]) is not Right([1])
    assert Left([1]) == Left([1])
    assert Either(1) is not None


# Generated at 2022-06-21 19:00:31.426291
# Unit test for method case of class Either
def test_Either_case():
    def transform_error(error: Any) -> int:
        return len(error)

    def transform_success(value: str) -> int:
        return len(value)

    assert Left("some error").case(transform_error, transform_success) == 14
    assert Right("some value").case(transform_error, transform_success) == 11

# Generated at 2022-06-21 19:00:34.992064
# Unit test for method bind of class Right
def test_Right_bind():
    right = Right(2)
    right_bind = right.bind(lambda x: Right(x*3))
    assert right_bind == Right(6)


# Generated at 2022-06-21 19:00:38.708660
# Unit test for constructor of class Either
def test_Either():
    """
    >>> from pymonet.either import Either
    >>> Either(5)
    Traceback (most recent call last):
    ...
    TypeError: Can't instantiate abstract class Either with abstract methods is_right
    """


# Generated at 2022-06-21 19:00:40.577441
# Unit test for method is_right of class Right
def test_Right_is_right():
    """Test method is_right of class Right"""
    value = Right(1)
    assert value.is_right()


# Generated at 2022-06-21 19:00:45.317751
# Unit test for method bind of class Left
def test_Left_bind():
    from pymonet.monad_maybe import Maybe

    value = 'value'
    new_value = Left(value).bind(lambda v: Maybe.just(v))
    assert new_value.is_nothing()
    assert not new_value.is_just()
    assert new_value == Maybe.nothing()


# Generated at 2022-06-21 19:00:48.649644
# Unit test for method is_right of class Right
def test_Right_is_right():
    # Given
    _ = Right(1)

    # When
    result = _.is_right()

    # Then
    assert result is True



# Generated at 2022-06-21 19:01:45.230676
# Unit test for method ap of class Either
def test_Either_ap():
    """ Unit test for method ap of class Either """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.validation import Validation

    def add_1(x: int) -> int:
        return x + 1

    def add_2(x: int) -> int:
        return x + 2

    def add_3(x: int) -> int:
        return x + 3

    def add_4(x: int) -> int:
        return x + 4

    assert Left(10).ap(Lazy(add_1)).value == 10
    assert Left(10).ap(Try(add_1, True)).value == 10

# Generated at 2022-06-21 19:01:46.056624
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-21 19:01:47.636763
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Left(1) != 1



# Generated at 2022-06-21 19:01:49.933526
# Unit test for constructor of class Either
def test_Either():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)



# Generated at 2022-06-21 19:01:51.056639
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(5).to_maybe() == Maybe.just(5)


# Generated at 2022-06-21 19:01:53.987537
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    # Given
    input_value = 'Input value'
    left = Left(input_value)
    expected_result = None

    # When
    result = left.to_maybe()

    # Then
    assert result is expected_result


# Generated at 2022-06-21 19:01:55.631519
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(10)
    assert right.is_left() == False



# Generated at 2022-06-21 19:02:00.965109
# Unit test for method case of class Either
def test_Either_case():
    assert Either(99).case(
        error=lambda x: "Error",
        success=lambda x: "Success") == "Error"

    assert Either(99).case(
        error=lambda x: "Error",
        success=lambda x: "Success") == "Error"



# Generated at 2022-06-21 19:02:02.336756
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() is True


# Generated at 2022-06-21 19:02:04.609536
# Unit test for method map of class Left
def test_Left_map():
    left = Left(1)
    assert left.map(lambda x: x).value == 1
    assert left.map(lambda x: x + 3).value == 1



# Generated at 2022-06-21 19:03:51.546490
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try

    assert(Right(4).ap(Right(lambda x: x * 4)) == Right(16))
    assert(Right(4).ap(Try(lambda x: x * 4, True)) == Right(16))
    assert(Left("Error").ap(Right(lambda x: x * 4)) == Left("Error"))
    assert(Left("Error").ap(Try(lambda x: x * 4, False)) == Left("Error"))



# Generated at 2022-06-21 19:03:53.026698
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-21 19:03:57.648580
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 'some') == Left('some').to_lazy()


# Generated at 2022-06-21 19:03:59.529631
# Unit test for method ap of class Left
def test_Left_ap():
    left = pytest.Left("Something went wrong")
    assert left.ap(pytest.Right("abc")) is left


# Generated at 2022-06-21 19:04:04.828082
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(True).to_lazy() is not Left(True).to_lazy()
    assert Right(True).to_lazy() is not Right(True).to_lazy()

    assert Lazy(lambda: True) == Left(True).to_lazy()
    assert Lazy(lambda: True) == Right(True).to_lazy()



# Generated at 2022-06-21 19:04:06.411444
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True



# Generated at 2022-06-21 19:04:10.244879
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Right([1, 2, 3]).to_try() == Try([1, 2, 3], True)
    assert Left(1).to_try() == Try(1, False)


# Generated at 2022-06-21 19:04:11.958766
# Unit test for method to_box of class Either
def test_Either_to_box():
    """Test to Box transformation"""
    from pymonet.box import Box

    assert Right(2).to_box() == Box(2)
    assert Left(2).to_box() == Box(2)


# Generated at 2022-06-21 19:04:22.127174
# Unit test for constructor of class Either
def test_Either():
    assert Left(1).value == 1
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1).to_lazy().get() == 1
    assert Left(1).to_box().value == 1
    assert Left(1).to_try().get() is None
    assert Right(1).value == 1
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1).to_lazy().get() == 1
    assert Right(1).to_box().value == 1
    assert Right(1).to_try().get() == 1
    assert Left(1).to_validation().value == [1]
    assert Right(1).to_validation().value == 1



# Generated at 2022-06-21 19:04:24.032242
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(2)
    assert right.is_left() == False

