

# Generated at 2022-06-21 18:54:43.886506
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:54:44.625927
# Unit test for constructor of class Left
def test_Left():
    assert Left('Error')


# Generated at 2022-06-21 18:54:47.800981
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.validation import Validation

    assert Left(1) != Right(1)
    assert Validation.nothing() == Validation.nothing()
    assert Right(1) == Right(1) == Validation.success(1)
    assert Left(1) == Left(1) == Validation.fail([1])

# Generated at 2022-06-21 18:54:49.448410
# Unit test for method is_right of class Left
def test_Left_is_right():
    # Given
    left = Left(1)
    # When
    result = left.is_right()
    # Then
    assert result == False



# Generated at 2022-06-21 18:54:52.150947
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(None).is_right() is False
    assert Left(123).is_right() is False

    assert Right(123).is_right() is True
    assert Right(None).is_right() is True



# Generated at 2022-06-21 18:54:54.586736
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(7)
    assert not left.is_right()

    right = Right(2)
    assert right.is_right()


# Generated at 2022-06-21 18:54:58.013461
# Unit test for method case of class Either
def test_Either_case():
    class SomeError(Exception):
        pass

    # Create mock functions
    def error_handler(error: SomeError) -> int:
        return 0

    def success_handler(value: int) -> int:
        return value + 1

    # Test
    left = Left(SomeError())
    assert left.case(error_handler, success_handler) == 0

    right = Right(2)
    assert right.case(error_handler, success_handler) == 3

# Generated at 2022-06-21 18:55:01.604446
# Unit test for method is_right of class Either
def test_Either_is_right():
    """Tests for method is_right of class Either"""

    assert Right(None).is_right() == True
    assert Left(None).is_right() == False

# Generated at 2022-06-21 18:55:04.520819
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(42)
    mapper = lambda x: Left(x)
    right = right.bind(mapper)
    assert left == right


# Generated at 2022-06-21 18:55:06.519522
# Unit test for method case of class Either
def test_Either_case():
    def success(arg):
        return f'Success {arg}!'

    def error(arg):
        return arg

    assert Left(1).case(error, success) == 1
    assert Right(2).case(error, success) == 'Success 2!'



# Generated at 2022-06-21 18:55:10.630256
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.maybe import Maybe

    assert Right(Maybe.just(2)).is_left() is False



# Generated at 2022-06-21 18:55:13.691211
# Unit test for constructor of class Left
def test_Left():
    """Test constructor of class Left"""
    assert Left(287).value == 287


# Generated at 2022-06-21 18:55:19.956237
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 1).ap(Right(2)) == Right(3)
    assert Left(lambda x: x + 1).ap(Right(3)) == Left(lambda x: x + 1)
    assert Right(lambda x: x + 1).ap(Left(2)) == Left(2)
    assert Left(lambda x: x + 1).ap(Left(2)) == Left(lambda x: x + 1)

# Generated at 2022-06-21 18:55:23.894716
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    left = Left("left")
    assert left.to_validation() == Validation.fail(["left"])


# Generated at 2022-06-21 18:55:25.998607
# Unit test for constructor of class Right
def test_Right():
    """
    test constructor of class Right.

    :returns: passed test
    :rtype: Boolean
    """
    right = Right(10)

    assert right.value == 10
    return True


# Generated at 2022-06-21 18:55:29.731885
# Unit test for method is_right of class Either
def test_Either_is_right():
    left_either = Left(1)
    right_either = Right(1)
    assert left_either.is_right() == False
    assert right_either.is_right() == True


# Generated at 2022-06-21 18:55:31.664432
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)
    assert left.to_validation().is_fail()


# Generated at 2022-06-21 18:55:40.446051
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (
        Right(1) ==
        Right(1)
    ) is True, 'result of __eq__ of Right should be True when values are equal'
    assert (
        Right(1) ==
        Right(2)
    ) is False, 'result of __eq__ of Right should be False when values are different'

    assert (
        Left(1) ==
        Left(1)
    ) is True, 'result of __eq__ of Left should be True when values are equal'
    assert (
        Left(1) ==
        Left(2)
    ) is False, 'result of __eq__ of Left should be False when values are different'

    assert (
        Left(1) ==
        Right(1)
    ) is False, 'result of __eq__ of Eiher should be False when values are different'


# Generated at 2022-06-21 18:55:41.603097
# Unit test for constructor of class Right
def test_Right():
    assert Right(10) == Right(10)
    assert Right(10) != Right(20)
    assert Right(10) != Left(10)


# Generated at 2022-06-21 18:55:42.670868
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left('foo').is_right() is False
    assert Right('foo').is_right() is True


# Generated at 2022-06-21 18:55:47.957081
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert isinstance(Left(1), Either)
    assert isinstance(Right(1), Either)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)

# Generated at 2022-06-21 18:55:49.909999
# Unit test for method map of class Left
def test_Left_map():
    assert isinstance(Left(None).map(lambda x: x), Left)



# Generated at 2022-06-21 18:55:52.332242
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation.success(2)


# Generated at 2022-06-21 18:56:00.252943
# Unit test for method case of class Either
def test_Either_case():
    def error_handler(value):
        return "error"

    def success_handler(value):
        return "ok"

    # test with Right
    right = Right(1)
    assert right.case(error_handler, success_handler) == success_handler(1)
    assert right.case(error_handler, lambda x: x) == 1

    # test with Left
    left = Left("err")
    assert left.case(error_handler, success_handler) == error_handler("err")
    assert left.case(lambda x: x, success_handler) == "err"

# Generated at 2022-06-21 18:56:03.048981
# Unit test for method is_right of class Either
def test_Either_is_right():
    from random import random

    assert Left(random()).is_right() == False
    assert Right(random()).is_right() == True


# Generated at 2022-06-21 18:56:05.268326
# Unit test for method case of class Either
def test_Either_case():
    assert isinstance(Either(None).case(error=lambda a: a, success=lambda a: a), None)



# Generated at 2022-06-21 18:56:07.855181
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(1).to_maybe() == Maybe.just(1)



# Generated at 2022-06-21 18:56:11.593176
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    result = Right(1).to_validation()
    assert result == Validation.success(1)


# Generated at 2022-06-21 18:56:12.981504
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True


# Generated at 2022-06-21 18:56:14.110556
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right()
    assert not Right(False).is_right()


# Generated at 2022-06-21 18:56:19.589516
# Unit test for method map of class Left
def test_Left_map():
    actual = Left("some value").map(lambda v: "value after map")
    expected = Left("some value")
    assert actual == expected

# Generated at 2022-06-21 18:56:21.315687
# Unit test for method map of class Right
def test_Right_map():
    def mapper(_):
        return 1

    assert Right(0).map(mapper) == Right(1)


# Generated at 2022-06-21 18:56:32.882060
# Unit test for method bind of class Right
def test_Right_bind():
    prop_Right_bind_return_Right_for_right_value = \
        forAll(integers(), integers(), integers()) \
        (lambda first, second, third: Right(third).bind(lambda value: Right(first + second + value)) == Right(first + second + third))
    prop_Right_bind_return_Left_for_right_value = \
        forAll(integers(), integers(), integers()) \
        (lambda first, second, third: Right(third).bind(lambda value: Left(first + second + value)) == Left(first + second + third))
    prop_Right_bind_return_Left_for_right = \
        forAll(integers(), integers()) \
        (lambda first, second: Right(first).bind(lambda value: Left(second)) == Left(second))
    prop_Right_bind_return_

# Generated at 2022-06-21 18:56:37.271025
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.monad_maybe import Maybe

    assert Either.Right(2).map(lambda x: x + 2) == Either.Right(4)
    assert Either.Right(5).map(lambda x: Maybe.just(x * 2)).case(None, lambda x: x.value) == 10
    assert Either.Right(5).map(lambda x: Maybe.nothing()).case(None, lambda x: x.value) == None

# Generated at 2022-06-21 18:56:41.304589
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(None).to_maybe() == Maybe.nothing()
    assert Left(None).is_just() is False
    assert Left(None).to_maybe().is_just() is False


# Generated at 2022-06-21 18:56:44.248961
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert isinstance(Right(5), Either)
    assert Right(5).is_right()
    assert Left(5).is_right() is False


# Generated at 2022-06-21 18:56:54.045548
# Unit test for method case of class Either
def test_Either_case():
    """
    test method case for class Either

    :returns: Tru if all function are correct
    :rtype: Boolean
    """
    from random import randint

    def test_either_with_number(number):
        """
        test method case for class Either

        :returns: Tru if all function are correct
        :rtype: Boolean
        """
        def sum_or_multiply(n): return n + 2

        def sum_or_multiply_2(n): return n * 2

        def sum_or_multiply_3(n): return n * 3

        def sum_or_multiply_4(n): return n * 4

        def sum_or_multiply_5(n): return n * 5

        def sum_or_multiply_6(n): return n * 6

       

# Generated at 2022-06-21 18:56:55.323327
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(2)


# Generated at 2022-06-21 18:56:56.501662
# Unit test for constructor of class Right
def test_Right():
    assert Right(5) == Right(5)



# Generated at 2022-06-21 18:56:57.670413
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left('left').is_left()



# Generated at 2022-06-21 18:57:13.299835
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    box_left_double = Box(lambda x: x * 2)
    box_right_plus = Box(lambda x: x + 2)
    lazy_left_generator = Lazy(lambda: lambda x: x * 2)
    lazy_right_generator = Lazy(lambda: lambda x: x + 2)

    assert Left(2).ap(box_left_double) == Left(2)
    assert Left(2).ap(box_right_plus) == Left(2)
    assert Left(2).ap(lazy_left_generator) == Left(2)
    assert Left(2).ap(lazy_right_generator) == Left(2)


# Generated at 2022-06-21 18:57:22.440801
# Unit test for method bind of class Right
def test_Right_bind():
    """Test bind method of Right class."""
    def right_identity(value):
        return Right(value)

    def half_value(value):
        return Right(value / 2)

    def add_ten_to_value(value):
        return Right(value + 10)

    value = Right(20)
    assert value.bind(right_identity) == Right(20)
    assert value.bind(half_value).bind(add_ten_to_value) == Right(15)
    assert value.bind(half_value).bind(half_value).bind(half_value) == Right(2.5)

# Generated at 2022-06-21 18:57:24.397193
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda a: Right(a + 1)) == Left(1)


# Generated at 2022-06-21 18:57:26.923573
# Unit test for constructor of class Either
def test_Either():
    result = Either(1)
    assert isinstance(result, Either)
    assert result.value == 1


# Generated at 2022-06-21 18:57:29.056263
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)


# Generated at 2022-06-21 18:57:32.408693
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Test for method is_right for class Left
    left = Left(1)
    assert not left.is_right()

    # Test for method is_right for class Right
    right = Right(1)
    assert right.is_right()


test_Either_is_right()



# Generated at 2022-06-21 18:57:35.869164
# Unit test for method map of class Left
def test_Left_map():
    def square(x):
        return x*x

    left = Left(2)
    assert left.map(square) == Left(4)


# Generated at 2022-06-21 18:57:38.610815
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)

# Generated at 2022-06-21 18:57:39.980611
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left("A").is_left()



# Generated at 2022-06-21 18:57:40.987453
# Unit test for constructor of class Right
def test_Right():
    assert Right(1).value == 1


# Generated at 2022-06-21 18:57:49.228059
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(10).to_validation() == Validation.success(10)


# Generated at 2022-06-21 18:57:52.445737
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functors.identity import Identity

    x = Lazy(lambda: Identity(1))
    assert isinstance(x.to_lazy(), Lazy)



# Generated at 2022-06-21 18:57:57.045236
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Either(Box(lambda x: x * 2)).ap(Either(Box(2))) == Either(Box(4))
    assert Either(
        Try(lambda x: x * 2, is_success=True)).ap(Either(Try(2, is_success=True))) == Either(Try(4, is_success=True))
    assert Either(
        Try(lambda x: x * 2, is_success=True)).ap(Either(Try(ValueError('error'), is_success=False))) == Either(
        Try(ValueError('error'), is_success=False))

# Generated at 2022-06-21 18:57:59.712278
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: None) == Left(1)



# Generated at 2022-06-21 18:58:04.653216
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right("1") == Right("1")
    assert Left("1") == Left("1")
    assert Right("1") == Right("2") is False
    assert Left("1") == Left("2") is False
    assert Right("1") == Left("1") is False



# Generated at 2022-06-21 18:58:08.075882
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    import pytest

    from pymonet.validation import Validation

    # GIVEN
    right = Right(1)

    # WHEN
    result = right.to_validation()

    # THEN
    assert result == Validation.success(1)



# Generated at 2022-06-21 18:58:10.120564
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(2) != Left(1)
    assert Left(None) == Left(None)


# Generated at 2022-06-21 18:58:15.274301
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.functor import Functor

    assert Either.case(Left(200), Functor.to_upper, Functor.to_upper) == 'PERA'
    assert Either.case(Right('Mika'), Functor.to_upper, Functor.to_upper) == 'MIKA'

# Generated at 2022-06-21 18:58:18.273129
# Unit test for constructor of class Left
def test_Left():
    # Given
    error = "error"

    # When
    either = Left(error)

    # Then
    assert either.error == error



# Generated at 2022-06-21 18:58:20.664986
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    assert Left(5).to_validation() == Validation.fail([5])

# Generated at 2022-06-21 18:58:28.119212
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left("1").is_right() == False



# Generated at 2022-06-21 18:58:37.416284
# Unit test for method case of class Either
def test_Either_case():
    # Test for Right
    # GIVEN
    string_to_int = lambda x: int(x)

    # WHEN
    right = Either.case(Right(1), lambda x: x, lambda x: 2 * x)
    right2 = Either.case(Right(1), lambda x: x, string_to_int)

    # THEN
    assert right == 2
    assert right2 == 1

    # Test for Left
    # GIVEN
    int_to_string = lambda x: str(x)

    # WHEN
    left = Either.case(Left(1), lambda x: x, lambda x: 2 * x)
    left2 = Either.case(Left(1), int_to_string, lambda x: 2 * x)

    # THEN
    assert left == 1
    assert left2 == '1'

# Unit

# Generated at 2022-06-21 18:58:39.011911
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda _: 1) == 1



# Generated at 2022-06-21 18:58:41.774548
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()
    assert Left("2").is_left()
    assert Left(True).is_left()



# Generated at 2022-06-21 18:58:43.667691
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    right = Right(1)
    assert right.to_validation() == Validation.success(1)

# Generated at 2022-06-21 18:58:45.763823
# Unit test for method map of class Left
def test_Left_map():
    left = Left(10)
    empty = left.map(lambda x: x + 1)

    assert empty is left


# Generated at 2022-06-21 18:58:48.944124
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-21 18:58:49.779011
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()


# Generated at 2022-06-21 18:58:51.694481
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Right(4).to_box() == Box(4)
    assert Left(4).to_box() == Box(4)



# Generated at 2022-06-21 18:58:55.645454
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(2) != Either(1)
    assert Either('left') == Either('left')
    assert Either('right') != Either('left')

    assert isinstance(Either(1), Either)



# Generated at 2022-06-21 18:59:12.343813
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe
    instance = Right(1)
    expected = Maybe(1)

    actual = instance.to_maybe()

    assert actual == expected

# Generated at 2022-06-21 18:59:14.938888
# Unit test for constructor of class Left
def test_Left():
    assert Left(0) == Left(0)
    assert Left(0) is not Left(1)


# Generated at 2022-06-21 18:59:16.867872
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: Right(x + 1)) == Right(4)


# Generated at 2022-06-21 18:59:20.531180
# Unit test for constructor of class Left
def test_Left():
    from expecter import expect

    left = Left(3)
    expect(left.value) == 3
    expect(left.is_left()) == True
    expect(left.is_right()) == False


# Generated at 2022-06-21 18:59:23.154435
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(True).is_right() is False
    assert Left(False).is_right() is False
    assert Left(None).is_right() is False


# Generated at 2022-06-21 18:59:24.173125
# Unit test for constructor of class Right
def test_Right():
    assert str(Right(123)) == "Right(123)"


# Generated at 2022-06-21 18:59:25.652902
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: Right(2*x)) == Left(1)


# Generated at 2022-06-21 18:59:27.728495
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    assert Left(None).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 18:59:32.497284
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    my_value = 5

    # Successfully
    right = Right(my_value)

    assert right.to_lazy() == Lazy(lambda: my_value)

    # Failed
    left = Left(my_value)

    assert left.to_lazy() == Lazy(lambda: my_value)

# Generated at 2022-06-21 18:59:36.733658
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left = Left(1)
    another_left = Left(2)
    right = Right(1)
    another_right = Right(2)

    # When/Then
    assert left != another_left
    assert left != right
    assert right != another_right


# Generated at 2022-06-21 19:00:09.483453
# Unit test for constructor of class Either
def test_Either():
    from pymonet.either import Either
    from pymonet.left import Left
    from pymonet.right import Right

    result = Either(Left(10))
    assert result.is_right() is False
    assert result.value == 10

    result = Either(Right(10))
    assert result.is_right() is True
    assert result.value == 10



# Generated at 2022-06-21 19:00:10.539913
# Unit test for constructor of class Left
def test_Left():
    Left('a')


# Generated at 2022-06-21 19:00:16.798753
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    # Given
    left = Left(2)
    validation = Validation.success(lambda x: x ** 2)
    lazy = Lazy(lambda: lambda x: 2 + x)

    # Then
    assert left.ap(validation).value == 2
    assert left.ap(lazy).value == 4


# Generated at 2022-06-21 19:00:19.327706
# Unit test for method bind of class Right
def test_Right_bind():
    obj = Right(2)
    result = obj.bind(lambda x: x + 1)
    assert result == 3


# Generated at 2022-06-21 19:00:25.939659
# Unit test for method case of class Either
def test_Either_case():
    assert Left(3).case(lambda x: x + 1, lambda x: x - 1) == 4
    assert Left(3).case(lambda x: x + 1, lambda x: x - 1) == 4
    assert Right(3).case(lambda x: x + 1, lambda x: x - 1) == 2

# Generated at 2022-06-21 19:00:27.406101
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(None).is_left()


# Generated at 2022-06-21 19:00:29.271459
# Unit test for constructor of class Right
def test_Right():
    result = Right(1)
    assert isinstance(result, Right)
    assert result.value == 1


# Generated at 2022-06-21 19:00:34.494420
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_list import List

    assert Left(Maybe.nothing()).to_maybe() == Maybe.nothing()
    assert Left(List([1, 2, 3])).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:00:36.167016
# Unit test for constructor of class Either
def test_Either():
    class_ = Either(1)
    assert class_.value == 1


# Generated at 2022-06-21 19:00:37.613920
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left('error').is_right() is False



# Generated at 2022-06-21 19:01:45.886910
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(2).is_left() == False


# Generated at 2022-06-21 19:01:47.338924
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(2).bind(lambda x: Left(2 * x)) == Left(4)


# Generated at 2022-06-21 19:01:48.413157
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left('left')
    assert left.is_left()


# Generated at 2022-06-21 19:01:55.317801
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(2).to_validation() == Validation(value=2,
                                                  is_success=True,
                                                  errors=[])
    assert Right(2).to_validation() != Validation(value=2,
                                                  is_success=False,
                                                  errors=[])
    assert Right(2).to_validation() != Validation(value=1,
                                                  is_success=True,
                                                  errors=[])
    assert Right(2).to_validation() != Validation(value=1,
                                                  is_success=False,
                                                  errors=[])



# Generated at 2022-06-21 19:01:58.330369
# Unit test for constructor of class Either
def test_Either():
    assert Either(88) is not None
    assert Either('foo') is not None



# Generated at 2022-06-21 19:02:00.288114
# Unit test for constructor of class Left
def test_Left():
    left = Left(2)

    assert left.value == 2
    assert isinstance(left, Left)



# Generated at 2022-06-21 19:02:01.785269
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False


# Generated at 2022-06-21 19:02:04.954731
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add_one(n):
        return n + 1

    result = (Right(1)
                  .to_lazy()
                  .map(add_one)
                  .get())
    assert result == 2


# Generated at 2022-06-21 19:02:09.520854
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_try import Try

    def add2(v) -> Try:
        return Try(v + 2)
    x = Right(2)
    assert x.bind(add2).bind(add2).bind(add2) == Try(6)



# Generated at 2022-06-21 19:02:11.128417
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left((lambda x: x + 2)).ap(Left(1)) == Left(1)
