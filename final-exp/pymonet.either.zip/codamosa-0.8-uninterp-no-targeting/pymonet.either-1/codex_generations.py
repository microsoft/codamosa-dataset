

# Generated at 2022-06-21 18:54:57.464264
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_value = 5
    left = Left(left_value)
    left_1 = Left(left_value)
    right_value = 'right'
    right = Right(right_value)
    right_1 = Right(right_value)
    assert left == left_1
    assert right == right_1
    assert left != right
    assert left != right_1
    assert right != left
    assert right_1 != left


# Generated at 2022-06-21 18:55:07.508503
# Unit test for method to_try of class Either
def test_Either_to_try():
    def _test_success(either: Either[int]) -> bool:
        try_val = either.to_try()
        return isinstance(try_val, Try) and try_val.is_success and try_val.value == either.value

    def _test_fail(either: Either[int]) -> bool:
        try_val = either.to_try()
        return isinstance(try_val, Try) and not try_val.is_success and try_val.value == either.value

    assert _test_success(Right(1))
    assert _test_fail(Left(1))
    assert _test_success(Right("test"))
    assert _test_fail(Left("test"))


# Generated at 2022-06-21 18:55:11.912599
# Unit test for constructor of class Either
def test_Either():
    """
    Unit test for Either class.
    """
    from pymonet.monad_test import check_monad
    from pymonet.monad_test import check_functor

    def test_functor(value):
        check_functor(Either, value, Left)

    def test_monad(value):
        check_monad(Either,
                    value,
                    Right,
                    lambda x: Right(x ** 2),
                    lambda x, y: Right(x + y),
                    lambda x, y: Right(x * y))

    test_functor(2)
    test_monad(2)



# Generated at 2022-06-21 18:55:18.529146
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.box import Box
    def triple(x):
        return x * 3

    assert Right(triple).ap(Box(3)) == Either.right(9)
    assert Left(triple).ap(Box(3)) == Either.left(triple)

# Generated at 2022-06-21 18:55:20.346112
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert (Right(10).is_left() == False)


# Generated at 2022-06-21 18:55:22.539700
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(1).to_validation().value == 1



# Generated at 2022-06-21 18:55:26.575828
# Unit test for method bind of class Right
def test_Right_bind():
    assert (Right(1).bind(lambda x: Right(x + 1)).value == 2)



# Generated at 2022-06-21 18:55:28.956958
# Unit test for method map of class Left
def test_Left_map():
    left = Left(10)
    assert left.map(lambda x: x + 100) == left


# Generated at 2022-06-21 18:55:30.872749
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    left = Left(1)

    assert left.to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:55:34.755065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either to_lazy method
    """
    from pymonet.lazy import Lazy

    lazy = Right(2).to_lazy()
    assert lazy.value() == 2
    assert lazy == Lazy(lambda: 2)

    lazy = Left('error').to_lazy()
    assert lazy.value() == 'error'
    assert lazy == Lazy(lambda: 'error')


# Generated at 2022-06-21 18:55:39.903518
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    # End test_Either___eq__

# Generated at 2022-06-21 18:55:43.402353
# Unit test for method map of class Right
def test_Right_map():
    result = Right(5).map(lambda value: value + 1)

    assert isinstance(result, Right)
    assert result.value == 6


# Generated at 2022-06-21 18:55:46.643279
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success

    assert Left('error').to_try() == Try(Success('error'), is_success=False)
    assert Right('success').to_try() == Try(Success('success'), is_success=True)


# Generated at 2022-06-21 18:55:48.585788
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(0).to_validation() == Validation.fail([0])

# Generated at 2022-06-21 18:55:50.059245
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(Any).is_right()


# Generated at 2022-06-21 18:55:51.718322
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left() == True


# Generated at 2022-06-21 18:55:54.013858
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(1)
    left_apply = lambda x: Left(x * 2)

    assert left.ap(left_apply) == Left(1)

# Generated at 2022-06-21 18:55:55.833115
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(12).is_right() is True
    assert Left(12).is_right() is False



# Generated at 2022-06-21 18:55:58.056245
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(None).to_validation() == Validation.fail([None])



# Generated at 2022-06-21 18:56:00.424483
# Unit test for method is_right of class Left
def test_Left_is_right():
    left = Left(9000)
    assert not left.is_right()



# Generated at 2022-06-21 18:56:11.242127
# Unit test for method case of class Either
def test_Either_case():
    def error(x: str) -> str:
        return 'Error: ' + x

    def success(x: int) -> str:
        return 'Success: ' + str(x)

    assert Left('msg').case(error, success) == 'Error: msg'
    assert Right(0).case(error, success) == 'Success: 0'



# Generated at 2022-06-21 18:56:13.394863
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(5).to_validation() == Validation.success(5)



# Generated at 2022-06-21 18:56:15.043376
# Unit test for constructor of class Right
def test_Right():
    left = Right(1)
    right = Right(1)

    assert left == right


# Generated at 2022-06-21 18:56:18.966501
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation_test import ValidationTest

    ValidationTest(Validation.fail([1]))\
        .assert_equal(Left([1]).to_validation())



# Generated at 2022-06-21 18:56:21.750840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 2) == Either('a').to_lazy()


# Generated at 2022-06-21 18:56:29.572374
# Unit test for method case of class Either
def test_Either_case():
    # Given
    left = Left(Exception('Test'))
    right = Right(1)

    # When
    left_result = left.case(error=lambda e: e.args[0], success=lambda value: 'Success')
    right_result = right.case(error=lambda e: e.args[0], success=lambda value: 'Success')

    # Then
    assert left_result == 'Test'
    assert right_result == 'Success'



# Generated at 2022-06-21 18:56:32.039995
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Right(Box(7)).to_validation() == Validation.success(Box(7))

# Generated at 2022-06-21 18:56:33.522847
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Right(42).to_maybe() == Maybe.just(42)



# Generated at 2022-06-21 18:56:37.041706
# Unit test for constructor of class Left
def test_Left():
    assert Left(5) == Left(5)
    assert Left(5) != Either(5)
    assert Left(5) != Right(5)
    assert Left(5) != Left('str')
    assert Left(5) != Right('str')
    assert Left(5).value == 5


# Generated at 2022-06-21 18:56:40.368430
# Unit test for method map of class Left
def test_Left_map():
    test_case = Left(1)
    assert test_case.map(lambda x: x + 1) == Left(1)


# Generated at 2022-06-21 18:56:47.193291
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    assert Left(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-21 18:56:51.228062
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(10).ap(Left(lambda x: x + 10)) == Left(10)
    assert Left(10).ap(Right(lambda x: x + 10)) == Left(10)
    assert Right(10).ap(Right(lambda x: x + 10)) == Right(20)


# Generated at 2022-06-21 18:56:54.352546
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x ** 2).ap(Right(3)) == Right(9)
    assert Left(lambda x: x ** 2).ap(Right(3)) == Left(lambda x: x ** 2)

# Generated at 2022-06-21 18:56:55.924303
# Unit test for constructor of class Either
def test_Either():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)


# Generated at 2022-06-21 18:56:57.081504
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right('test').to_maybe() == Maybe.just('test')


# Generated at 2022-06-21 18:56:59.399678
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)



# Generated at 2022-06-21 18:57:01.286388
# Unit test for constructor of class Left
def test_Left():
    assert Left('x') == Left('x')
    assert Left('x') == Left('y')


# Generated at 2022-06-21 18:57:10.107613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    # Test for Left
    expected_left = Left(Box(Maybe.just(0)))
    assert expected_left.to_lazy() == Lazy(lambda: Box(Maybe.just(0)))

    # Test for Right
    expected_right = Right(Box(Maybe.just(0)))
    assert expected_right.to_lazy() == Lazy(lambda: Box(Maybe.just(0)))


# Generated at 2022-06-21 18:57:11.869624
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(None).is_left()



# Generated at 2022-06-21 18:57:13.973892
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(4)
    assert left.is_left() == True



# Generated at 2022-06-21 18:57:19.866081
# Unit test for method bind of class Right
def test_Right_bind():
    assert Right(3).bind(lambda x: Right(x + 1)) == Right(4)
    assert Right(3).bind(lambda x: Left(x + 1)) == Left(4)



# Generated at 2022-06-21 18:57:21.274335
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(None)
    assert left.is_left()
    assert not left.is_right()


# Generated at 2022-06-21 18:57:28.372022
# Unit test for constructor of class Either
def test_Either():
    assert_that(Right(1), equal_to(Right(1)))
    assert_that(Right(1), is_not(Right(2)))
    assert_that(Right([]), not_(Right(None)))
    assert_that(Right(1), equal_to(Right(1)))
    assert_that(Right(1), is_not(Right(2)))
    assert_that(Right([]), not_(Right(None)))



# Generated at 2022-06-21 18:57:30.701581
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 18:57:34.004280
# Unit test for method case of class Either
def test_Either_case():
    args = {
        'error': lambda x: x + 2,
        'success': lambda x: x * 2
    }
    should_be_true = \
        Left(1).case(**args) == Right(1).case(**args) == 3 and\
        Right(1).case(**args) == Left(1).case(**args) == 3
    assert should_be_true



# Generated at 2022-06-21 18:57:38.259994
# Unit test for method to_box of class Either
def test_Either_to_box():
    #Test to_box with Left Either
    left = Left("Fail")
    assert left.to_box() == Box("Fail")
    #Test to_box with Right Either
    right = Right("Ok")
    assert right.to_box() == Box("Ok")


# Generated at 2022-06-21 18:57:47.807341
# Unit test for constructor of class Left
def test_Left():
    assert Left("error") == Left("error")
    assert Left("error") != Left("error2")
    assert Left("error") != Right("error")
    left = Left("error")
    right = Right("error")
    assert left.case(lambda x: x, lambda x: x) == 'error'
    assert left.case(lambda x: x, lambda x: x) != right.case(lambda x: x, lambda x: x)
    assert right.case(lambda x: x, lambda x: x) == 'error'
    assert right.case(lambda x: x, lambda x: x) != left.case(lambda x: x, lambda x: x)


# Generated at 2022-06-21 18:57:49.516042
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(1).to_validation() == Validation.fail([1])



# Generated at 2022-06-21 18:57:50.241997
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert(Left(4).to_maybe() == Maybe.nothing())


# Generated at 2022-06-21 18:57:51.560266
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(12).is_right() is False



# Generated at 2022-06-21 18:58:00.536965
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-21 18:58:05.011887
# Unit test for method ap of class Left
def test_Left_ap():
    # given
    left = Left("Failed")
    right = Right(lambda x: x == 'value')

    # when
    result = left.ap(right)

    # then
    assert isinstance(result, Left)
    assert result.value == "Failed"
    assert result.is_left()


# Generated at 2022-06-21 18:58:12.541025
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)

    assert left == Left(1)
    assert left != Right(1)
    assert left != left
    assert left != 1
    assert left != 'hello'
    assert left != [1, 2, 3]
    assert left != {'one': 1, 'two': 2}

    assert right == Right(1)
    assert right != Left(1)
    assert right != right
    assert right != 1
    assert right != 'hello'
    assert right != [1, 2, 3]
    assert right != {'one': 1, 'two': 2}



# Generated at 2022-06-21 18:58:17.625544
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)
    assert left.value == 1
    assert right.value == 1
    assert left.is_left()
    assert right.is_right()
    assert not left.is_right()
    assert not right.is_left()


# Generated at 2022-06-21 18:58:19.525992
# Unit test for constructor of class Right
def test_Right():
    assert Right(None).value is None
    assert Right(1).value == 1
    assert Right(True).value == True
    assert Right("test").value == "test"


# Generated at 2022-06-21 18:58:21.593183
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    assert Right(None).to_validation() == Validation.success(None)


# Generated at 2022-06-21 18:58:25.672762
# Unit test for constructor of class Either
def test_Either():
    # When I have Left and Right instances of Either
    left = Left(1)
    right = Right(2)

    # Then I have proper objects
    assert left.value == 1
    assert right.value == 2



# Generated at 2022-06-21 18:58:33.868127
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    # Correct Either
    value = Right(1)
    expected_try = Try(1)

    # initialize to_try
    result_try = value.to_try()

    # Check result
    assert result_try == expected_try

    # Failed Either
    value = Left(1)
    expected_try = Try(1, is_success=False)

    # initialize to_try
    result_try = value.to_try()

    # Check result
    assert result_try == expected_try



# Generated at 2022-06-21 18:58:36.677250
# Unit test for method map of class Right
def test_Right_map():
    assertRightEq(Right(2).map(lambda x: x * 2), 4)



# Generated at 2022-06-21 18:58:38.509263
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(10).is_right() is True
    assert Left(10).is_right() is False


# Generated at 2022-06-21 18:59:04.760433
# Unit test for method ap of class Either
def test_Either_ap():
    from .monad_try import Try
    from .box import Box
    from .lazy import Lazy

    def square(number):
        return number * number

    def to_str(number):
        return str(number)

    assert Right(2).ap(Right(square)) == Right(4)
    assert Right(2).ap(Left(square)) == Left(square)
    assert Left(2).ap(Right(square)) == Left(2)
    assert Left(2).ap(Left(square)) == Left(2)
    assert Right(3).ap(Try(square)) == Try(square).map(3)
    assert Left(3).ap(Try(square)) == Left(3)
    assert Right(3).ap(Box(square)) == Box(square).map(3)

# Generated at 2022-06-21 18:59:07.033524
# Unit test for constructor of class Left
def test_Left():
    """Test constructor of class Left"""
    assert Left("string").value == "string"
    assert Left(None).value is None
    assert Left(1).value == 1


# Generated at 2022-06-21 18:59:08.445587
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left('Error1').to_validation() == Validation.fail(['Error1'])


# Generated at 2022-06-21 18:59:10.042916
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:59:14.064526
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Success

    assert Right(42).to_try() == Success(42)
    assert Left('test error').to_try() == Success('test error', is_success=False)


# Generated at 2022-06-21 18:59:16.464591
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(2).bind(lambda _: Right(2)) == Left(2)


# Generated at 2022-06-21 18:59:22.141873
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Right(1).map(lambda s: s + 1) == Right(2)
    assert Right(1).map(lambda s: Box(s)) == Right(Box(1))
    assert Right(1).map(lambda s: Try(s)) == Right(Try(1))



# Generated at 2022-06-21 18:59:24.022722
# Unit test for constructor of class Left
def test_Left():
    left = Left(1)
    assert left.is_left()
    assert left.case(left, left) == left



# Generated at 2022-06-21 18:59:26.094681
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(10).is_left() is True
    assert Left('abc').is_left() is True
    assert Left(None).is_left() is True


# Generated at 2022-06-21 18:59:29.185394
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(None).ap(Left(None)) == Left(None)
    assert Left(None).ap(Right(None)) == Left(None)



# Generated at 2022-06-21 19:00:13.467559
# Unit test for constructor of class Either
def test_Either():
    def test_left() -> None:
        assert isinstance(Left(1), Either)
        assert isinstance(Left(1), Left)
        assert isinstance(Left(1), Left[int])

    def test_right() -> None:
        assert isinstance(Right(1), Either)
        assert isinstance(Right(1), Right)
        assert isinstance(Right(1), Right[int])

    test_left()
    test_right()



# Generated at 2022-06-21 19:00:14.870268
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert not Left(1).is_right()



# Generated at 2022-06-21 19:00:18.734088
# Unit test for method case of class Either
def test_Either_case():
    def error(a: int) -> int:
        return a * 2

    def success(a: int) -> int:
        return a * 3

    assert Left(1).case(error, success) == 2
    assert Right(1).case(error, success) == 3

# Generated at 2022-06-21 19:00:20.878407
# Unit test for method is_right of class Either
def test_Either_is_right():
    left = Left(1)
    right = Right(1)

    assert left.is_right() == False
    assert right.is_right() == True


# Generated at 2022-06-21 19:00:25.985006
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(1).to_try() == Try(1, is_success=True)
    assert Either(None).to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:00:28.715442
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    res = Left(42).to_maybe()
    assert res.is_nothing() == True
    assert res.get_or_else(10) == 10


# Generated at 2022-06-21 19:00:30.890300
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(10)
    f = lambda x: x + 10
    assert left.bind(f) == left


# Generated at 2022-06-21 19:00:35.849837
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Right('a').to_lazy()
    assert Lazy(lambda: 'a') == Left('a').to_lazy()


# Generated at 2022-06-21 19:00:37.719021
# Unit test for method is_left of class Right
def test_Right_is_left():
    right = Right(None)
    assert right.is_left() == False


# Generated at 2022-06-21 19:00:39.397205
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(0).to_maybe() == \
           Maybe.nothing()


# Generated at 2022-06-21 19:01:58.761790
# Unit test for method to_try of class Either
def test_Either_to_try():
    # Given
    expected = True
    either = Right(12).to_try()

    # When
    actual = either.is_success()

    # Then
    assert expected == actual

# Generated at 2022-06-21 19:02:00.710240
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Left(1).is_right() is False
    assert Right(1).is_right() is True



# Generated at 2022-06-21 19:02:02.139891
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(None).is_left() == False


# Generated at 2022-06-21 19:02:04.955594
# Unit test for method map of class Left
def test_Left_map():
    left_a = Left(1)
    mapper = lambda a: a*2
    left_b = left_a.map(mapper)

    assert left_b == Left(1)



# Generated at 2022-06-21 19:02:14.413352
# Unit test for method ap of class Either
def test_Either_ap():
    def add(x):
        def _add(y):
            return x + y

        return _add

    either = Right(1)
    applicative = Right(2)
    assert either.ap(applicative) == Right(3)
    either = Left(1)
    applicative = Right(2)
    assert either.ap(applicative) == Left(1)
    either = Right(1)
    applicative = Left(2)
    assert either.ap(applicative) == Left(2)
    either = Left(1)
    applicative = Left(2)
    assert either.ap(applicative) == Left(1)



# Generated at 2022-06-21 19:02:15.828567
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(True).is_right()



# Generated at 2022-06-21 19:02:17.256151
# Unit test for constructor of class Right
def test_Right():
    right = Right(1)

    assert right is not None
    assert right.value == 1


# Generated at 2022-06-21 19:02:19.098891
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(1)
    assert left.to_validation() == Validation.fail([1])



# Generated at 2022-06-21 19:02:21.462158
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert(Either[str]().to_lazy() == Lazy(lambda: ''))
    assert(Left('Error').to_lazy() == Lazy(lambda: 'Error'))
    assert(Right('Success').to_lazy() == Lazy(lambda: 'Success'))


# Generated at 2022-06-21 19:02:29.018035
# Unit test for method ap of class Either
def test_Either_ap():
    assert Right(lambda x: x + 5).ap(Right(5)) == Right(lambda x: x + 5)(5)
    assert Right(lambda x: x + 5).ap(Left(5)) == Left(5)
    assert Left(lambda x: x + 5).ap(Left(5)) == Left(lambda x: x + 5)
    assert Left(lambda x: x + 5).ap(Right(5)) == Left(lambda x: x + 5)
