

# Generated at 2022-06-21 18:54:52.899503
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    assert Left(4).to_validation().is_fail() and\
        Left(4).to_validation().value == [4]



# Generated at 2022-06-21 18:54:54.458081
# Unit test for method is_left of class Right
def test_Right_is_left():
    result = Right(1).is_left()
    expected = False
    assert result == expected


# Generated at 2022-06-21 18:54:57.020861
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation
    validation = Right('test').to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()



# Generated at 2022-06-21 18:54:58.797716
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    assert Left('error').to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:55:00.564289
# Unit test for constructor of class Right
def test_Right():
    assert Right("test").value == "test"


# Generated at 2022-06-21 18:55:08.397341
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).to_box().map(lambda x: x + 1) == Box(1)
    assert Left(1).to_try().map(lambda x: x + 1) == Try(1, False)
    assert Left(1).to_lazy().map(lambda x: x + 1) == Lazy(lambda: 1)


# Generated at 2022-06-21 18:55:13.385930
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(1).ap(Lazy(lambda: 2)) == Left(1)
    assert Left(1).ap(Box(2)) == Left(1)
    assert Left(1).ap(Try(2)) == Left(1)
    assert Left(1).ap(Lazy(lambda: Try(2))) == Left(1)
    assert Left(1).ap(Lazy(lambda: Box(2))) == Left(1)
    assert Left(Lazy(lambda: 2)).ap(Lazy(lambda: 2)) == Left(Lazy(lambda: 2))
    assert Left(Box(2)).ap(Lazy(lambda: 2)) == Left(Box(2))
    assert Left(Try(2)).ap(Lazy(lambda: 2)) == Left(Try(2))
    assert Left(Lazy(lambda: Try(2))).ap

# Generated at 2022-06-21 18:55:19.614375
# Unit test for method is_right of class Either
def test_Either_is_right():
    """Unit test for method is_right of class Either"""

    assert Right(1).is_right() is True
    assert Right(0).is_right() is True
    assert Right(-1).is_right() is True
    assert Left(1).is_right() is False
    assert Left(0).is_right() is False
    assert Left(-1).is_right() is False

# Generated at 2022-06-21 18:55:22.196290
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(None) == Left(None)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(None)
    assert Right(None) == Right(None)

# Generated at 2022-06-21 18:55:28.253545
# Unit test for constructor of class Right
def test_Right():
    assert Right(2) == Right(2)
    assert Right(2) != Right(3)
    assert Right(2) != Left(2)
    assert Right(2).value == 2



# Generated at 2022-06-21 18:55:34.315067
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(42).to_maybe() == Maybe(None)


# Generated at 2022-06-21 18:55:44.414028
# Unit test for method map of class Right
def test_Right_map():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_list import MonadList
    from pymonet.monad_try import Try

    right_int = Right(2)
    right_float = right_int.map(lambda x: float(x))
    right_complex = right_int.map(complex)
    right_maybe = right_int.map(Maybe)
    right_lazy = right_int.map(lambda x: Lazy(x))
    right_monad_list = right_int.map(lambda x: MonadList([x, x, x]))
    right_try = right_int.map(lambda x: Try(x))

    assert isinstance(right_float, Right)
    assert isinstance(right_complex, Right)

# Generated at 2022-06-21 18:55:45.906833
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(11).is_right()
    assert not Left(11).is_right()



# Generated at 2022-06-21 18:55:47.771681
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left(1).to_maybe() == None


# Generated at 2022-06-21 18:55:52.788296
# Unit test for method to_try of class Either
def test_Either_to_try():
    result = Left(2).to_try()
    assert result.value == 2
    assert result.is_success is False

    result = Right(5).to_try()
    assert result.value == 5
    assert result.is_success is True


if __name__ == '__main__':
    test_Either_to_try()

# Generated at 2022-06-21 18:55:56.504007
# Unit test for constructor of class Right
def test_Right():
    # Given
    value = 'test value'

    # When
    either = Right(value)

    # Then
    assert isinstance(either, Right)
    assert either.value == value


# Unit test constructor of class Left

# Generated at 2022-06-21 18:56:02.666517
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.lazy import Lazy

    assert Right(3).case(lambda _: 2, lambda v: v) == 3
    assert Left(3).case(lambda v: v, lambda _: 2) == 3

    assert Lazy(lambda: 1).case(lambda _: 2, lambda v: v) == 1
    assert Lazy(lambda: 1).case(lambda v: v, lambda _: 2) == 1

# Generated at 2022-06-21 18:56:08.071149
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x: x + 1) == Left(1)
    assert Left(1).map(lambda _: None) == Left(1)
    assert Left(None).map(lambda _: None) == Left(None)
    assert Left([1, 2, 3]).map(lambda x: set(x)) == Left([1, 2, 3])



# Generated at 2022-06-21 18:56:10.758370
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(42).is_left() is True
    assert Left(42).is_right() is False



# Generated at 2022-06-21 18:56:16.792744
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    def div(num, den):
        return 1/num if num != 0 else 0

    # Because try use special constructor with is_success parameter
    # we need to create try in special way
    assert Either(div(1, 2)).to_try() == Try(div(1, 2), is_success=True)
    assert Either(div(0, 2)).to_try() == Try(div(0, 2), is_success=False)


# Generated at 2022-06-21 18:56:33.054989
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(10) == Either(10), "unexpected result"
    assert Either(10) == Either('10'), "unexpected result"
    assert Either(10) != Either(11), "unexpected result"
    assert Either(10) != Either(None), "unexpected result"
    assert Either(10) != Left(10), "unexpected result"
    assert Either(10) != Right(10), "unexpected result"
    assert Left(10) != Right(10), "unexpected result"
    assert Left(10) == Left(10), "unexpected result"
    assert Left(10) != Left(11), "unexpected result"
    assert Right(10) == Right(10), "unexpected result"
    assert Right(10) != Right(11), "unexpected result"


# Generated at 2022-06-21 18:56:34.912904
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right(1).is_right() == True
    assert Left('bla').is_right() == False


# Generated at 2022-06-21 18:56:37.620723
# Unit test for method bind of class Left
def test_Left_bind():
    left = Left(1)
    got = left.bind(lambda _: Left(2))
    assert isinstance(got, Left)
    assert got.value == 1


# Generated at 2022-06-21 18:56:40.064793
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert not Left('Left value').is_right()
    assert Right('Right value').is_right()


# Generated at 2022-06-21 18:56:46.086178
# Unit test for method map of class Right
def test_Right_map():
    """Test for method map of class Right"""
    assert Right(2).map(lambda x: x + 2).value == 4
    assert Right(2).map(lambda x: 2 * x).value == 4
    assert Right(2).map(lambda x: x * x).value == 4
    assert Right(2).map(lambda x: x ** 2).value == 4
    assert Right(2).map(lambda x: x ** x).value == 4


# Generated at 2022-06-21 18:56:48.439537
# Unit test for method map of class Left
def test_Left_map():
    assert Left('error').map(lambda x: x * 2) == Left('error')


# Generated at 2022-06-21 18:56:55.539624
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Transform Either to Lazy.

    :returns: Lazy monad with function returning previous value
    :rtype: Lazy[Function() -> A]
    """
    from pymonet.box import Box
    def test_either_to_lazy_left():
        left = Left(5)
        lazy = left.to_lazy()
        assert lazy.value() == 5

    def test_either_to_lazy_right():
        right = Right(5)
        lazy = right.to_lazy()
        assert lazy.value() == 5


# Generated at 2022-06-21 18:56:59.533748
# Unit test for method map of class Left
def test_Left_map():
    from pymonet.test_utils import assert_type
    from pymonet.test_utils import assert_value
    from pymonet.test_utils import assert_result

    assert_type(Left(10).map, Callable)
    assert_value(Left(10).map, lambda x: x + 1, 11)
    assert_result(Left(10).map, lambda x: x + 1, None)


# Generated at 2022-06-21 18:57:11.993439
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    """Take some value and return it as validaton with error value"""
    from pymonet.validation import Validation

    error1 = Left(1).to_validation()
    error2 = Left(2).to_validation()
    assert isinstance(error1, Validation),\
        'Error1 should be Validation type, got %s' % error1.__class__
    assert error1.is_fail(), 'Error1 should be fail type, got %s' % error1
    assert error1.value == [1], 'Error1 should contain 1, got %s' % error1.value
    assert error1 == error2, 'Error1 and error2 should be equal'
    assert not error1 == Validation.fail([1]), 'Error1 and Validation.fail([1]) should be not equal'
    assert error1 != Validation

# Generated at 2022-06-21 18:57:16.155128
# Unit test for method bind of class Right
def test_Right_bind():
    # When
    result = Right(2).bind(lambda x: Right(x * 3))

    # Then
    assert isinstance(result, Right)
    assert isinstance(result, Either)
    assert result.value == 6



# Generated at 2022-06-21 18:57:28.561117
# Unit test for method is_right of class Either
def test_Either_is_right():
    # Given
    left = Either.left(42)
    right = Either.right(42)
    # Then
    assert left.is_right() == False
    assert right.is_right() == True


# Generated at 2022-06-21 18:57:30.228272
# Unit test for method bind of class Right
def test_Right_bind():
    from pymonet.monad_maybe import Maybe

    assert Right(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 18:57:31.378254
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: x) == 1



# Generated at 2022-06-21 18:57:36.387439
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    """
    Tests whether Right's to_validation method returns instance of Validation
    with successfull result.
    """
    assert isinstance(Right(1).to_validation(), Validation)
    assert Right(1).to_validation().is_success() is True


# Generated at 2022-06-21 18:57:39.494816
# Unit test for constructor of class Right
def test_Right():
    assert Right(42) == Right(42)
    assert Right(42) != Right(24)
    assert Right(42) != Left(42)

# Unit tests for function bind in class Right

# Generated at 2022-06-21 18:57:43.772863
# Unit test for constructor of class Either
def test_Either():
    left = Left(1)
    right = Right(1)
    assert isinstance(left, Left)
    assert isinstance(right, Right) 
    assert left.value == 1
    assert right.value == 1
    assert left.is_left()
    assert right.is_right()


# Generated at 2022-06-21 18:57:46.020910
# Unit test for method is_left of class Left
def test_Left_is_left():
    left = Left(1)
    assert left.is_left()


# Generated at 2022-06-21 18:57:50.954521
# Unit test for method map of class Right
def test_Right_map():
    def plus_1(x: int) -> int:
        return x + 1

    assert Right(1).map(plus_1) == Right(2)
    assert Right(1).map(None) == Right(1)
    assert Right('1').map(None) == Right('1')
    assert Right(1).map(plus_1) == Right(2)


# Generated at 2022-06-21 18:57:52.503204
# Unit test for method is_left of class Right
def test_Right_is_left():
    from pymonet.monad_test_utils import is_left_test

    is_left_test(Right(1))



# Generated at 2022-06-21 18:58:04.091829
# Unit test for method to_try of class Either
def test_Either_to_try():
    """Returned Try must be the same with previous."""
    import pytest
    from pymonet.monad_try import Try

    right_success = Try(1)
    right_failure = Try(Exception('bla'))
    left_success = Try(1, is_success=False)
    left_failure = Try(Exception('bla'), is_success=False)

    assert Either(right_success.value).to_try() == right_success
    assert Either(right_failure.value).to_try() == right_failure
    assert Either(left_success.value).to_try() == left_success
    assert Either(left_failure.value).to_try() == left_failure
    assert Either(1).to_try().is_success

# Generated at 2022-06-21 18:58:15.131888
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2*2).map(lambda x: x/2) == Right(4/2)


# Generated at 2022-06-21 18:58:19.281203
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    value = 20
    either = Right(value)

    result = either.to_validation()
    assert Validation.validation(result)
    assert result.right == value
    assert not result.left


# Generated at 2022-06-21 18:58:20.567069
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)



# Generated at 2022-06-21 18:58:23.094628
# Unit test for method ap of class Left
def test_Left_ap():
    from pymonet.box import Box
    assert Left(1).ap(Box(lambda x: x + 2)) == Left(1)


# Generated at 2022-06-21 18:58:28.468762
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try
    assert Try(1).ap(Try(lambda x: x + 2)) == Try(3)

    from pymonet.lazy import Lazy
    assert Left(1).ap(Lazy(lambda: 2)) == Left(1)

    from pymonet.maybe import Maybe
    assert Right(1).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 18:58:29.488674
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    assert Left("Error").to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 18:58:30.653621
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left.ap('1', Left(lambda x: x + '1')) == Left('1')

# Generated at 2022-06-21 18:58:33.234316
# Unit test for method map of class Right
def test_Right_map():
    assert Right(2).map(lambda x: x*x) == Right(4)
    assert Right(2).map(lambda _: 0) == Right(0)


# Generated at 2022-06-21 18:58:39.647575
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    value = 1
    expected = Validation.fail([value])
    actual = Left(value).to_validation()

    assert expected == actual
    assert type(expected) == type(actual)
    assert not actual.to_maybe().is_just()


# Generated at 2022-06-21 18:58:42.107419
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert Left(None).to_box() == Box(None)
    assert Right(None).to_box() == Box(None)


# Generated at 2022-06-21 18:59:00.361783
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert Right(1).is_left() == False



# Generated at 2022-06-21 18:59:01.798463
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)


# Generated at 2022-06-21 18:59:03.151188
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    assert Right(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 18:59:06.759675
# Unit test for method ap of class Either
def test_Either_ap():
    assert Left(1).ap(Right(lambda x: x + 2)) == Left(1)
    assert Right(1).ap(Left(lambda x: x + 2)) == Left(lambda x: x + 2)
    assert Right(1).ap(Right(lambda x: x + 2)) == Right(3)

# Generated at 2022-06-21 18:59:07.738041
# Unit test for method is_left of class Left
def test_Left_is_left():
    assert Left(1).is_left()



# Generated at 2022-06-21 18:59:12.449092
# Unit test for method to_try of class Either
def test_Either_to_try():
    import pytest

    with pytest.raises(TypeError):
        Either(None).to_try()

    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 18:59:14.981372
# Unit test for method bind of class Left
def test_Left_bind():
    assert Left(1).bind(lambda x: x) == Left(1)


# Generated at 2022-06-21 18:59:17.714306
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Right(10).to_box() == Box(10)
    assert Left(10).to_box() == Box(10)

# Generated at 2022-06-21 18:59:20.529108
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 18:59:22.710331
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:00:07.175408
# Unit test for method bind of class Left
def test_Left_bind():
    left_without_bind = Left(5)
    assert left_without_bind.__eq__(left_without_bind) is True
    assert left_without_bind.case(lambda x: x, lambda x: x) == 5
    assert left_without_bind.is_left() is True
    assert left_without_bind.is_right() is False

    left_with_bind = left_without_bind.bind(lambda x: Right(x))
    assert type(left_with_bind) is Left
    assert left_with_bind == left_without_bind
    assert left_with_bind == left_without_bind
    assert left_with_bind.case(lambda x: x, lambda x: x) == 5
    assert left_with_bind.is_left() is True
    assert left_with_bind.is_right

# Generated at 2022-06-21 19:00:11.869944
# Unit test for method to_box of class Either
def test_Either_to_box():
    assert isinstance(Either.to_box(Right(1)), Box)
    assert isinstance(Either.to_box(Left("error")), Box)
    assert Either.to_box(Right(1)).value == 1
    assert Either.to_box(Left("error")).value == "error"


# Generated at 2022-06-21 19:00:14.821519
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(lambda x : x + 2) == Left(1)


# Generated at 2022-06-21 19:00:17.838603
# Unit test for method ap of class Left
def test_Left_ap():
    assert Left(lambda x: x).ap(Right(6)) == Left(lambda x: x)
    assert Left(lambda x: x).ap(Left(6)) == Left(lambda x: x)

# Generated at 2022-06-21 19:00:19.236873
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-21 19:00:22.241533
# Unit test for method is_right of class Either
def test_Either_is_right():
    from pymonet.Box import Box
    from pymonet.monad_try import Try

    assert Left(Box(1)).is_right() == False
    assert Left(Try(1)).is_right() == False
    assert Right(Box(1)).is_right() == True


# Generated at 2022-06-21 19:00:26.394525
# Unit test for method to_validation of class Left
def test_Left_to_validation():
    from pymonet.validation import Validation

    left = Left(10)
    validation = left.to_validation()
    assert validation == Validation.fail([10])


# Generated at 2022-06-21 19:00:31.753352
# Unit test for method ap of class Either
def test_Either_ap():
    from pymonet.monad_try import Try

    assert Right(lambda x: x * 2).ap(Try.success(2)) == Right(4)
    assert Left(1).ap(Try.success(2)) == Left(1)
    assert Right(lambda x: x * 2).ap(Try.failure(Exception('Exception!'))) == Left(Exception('Exception!'))
    assert Left(1).ap(Try.failure(Exception('Exception!'))) == Left(1)


# Generated at 2022-06-21 19:00:36.801654
# Unit test for method to_try of class Either
def test_Either_to_try():
    from pymonet.monad_try import Try

    a = Left(None)
    assert a.to_try() == Try(None, is_success=False)
    b = Right(None)
    assert b.to_try() == Try(None, is_success=True)

# Generated at 2022-06-21 19:00:39.408293
# Unit test for constructor of class Right
def test_Right():
    assert Right(1) == Right(1)
    assert Right(2) != Right(1)
    assert Right(1) != 1
    assert Right(1) != Left(1)

# Generated at 2022-06-21 19:01:19.319294
# Unit test for method is_right of class Either
def test_Either_is_right():
    left_either = Left("This is Left")
    assert left_either.is_right() == False
    right_either = Right("This is Right")
    assert right_either.is_right() == True

# Generated at 2022-06-21 19:01:23.454022
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from pymonet.validation import Validation

    assert Right(1).to_validation() == Validation.success(1)
    assert Right("a").to_validation() == Validation.success("a")


# Generated at 2022-06-21 19:01:24.796603
# Unit test for method map of class Left
def test_Left_map():
    assert Left(1).map(int) == Left(1)


# Generated at 2022-06-21 19:01:27.969871
# Unit test for method to_try of class Either
def test_Either_to_try():
    assert Either(5).to_try().is_success
    assert not Either(5).to_try().is_failure

    assert not Either.left(5).to_try().is_success
    assert Either.left(5).to_try().is_failure



# Generated at 2022-06-21 19:01:29.936752
# Unit test for method to_maybe of class Right
def test_Right_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Right(1).to_maybe()
    assert Maybe.nothing() == Left(1).to_maybe()


# Generated at 2022-06-21 19:01:33.461158
# Unit test for method to_box of class Either
def test_Either_to_box():
    from pymonet.box import Box

    assert Either('').to_box() == Box('')
    assert Either(None).to_box() == Box(None)
    assert Either('1').to_box() == Box('1')


# Generated at 2022-06-21 19:01:38.225940
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    right = Right(1)
    left = Left(0)

    # When
    lazy_right = right.to_lazy()
    lazy_left = left.to_lazy()

    # Then
    assert lazy_right.get() == 1
    assert lazy_left.get() == 0

# Generated at 2022-06-21 19:01:39.506309
# Unit test for method is_right of class Right
def test_Right_is_right():
    assert Right(1).is_right() == True



# Generated at 2022-06-21 19:01:41.112225
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False

# Generated at 2022-06-21 19:01:47.765129
# Unit test for method to_validation of class Right
def test_Right_to_validation():
    from random import randint
    from pymonet.validation import Validation
    from pymonet.validation import ApplicationError

    for _ in range(100):
        max_value = randint(0, 10000)
        for _ in range(100):
            value = randint(0, max_value)
            validation = Right(value).to_validation()

            assert isinstance(validation, Validation)
            assert validation.is_success
            assert validation.success == value
            assert not validation.is_fail
            assert validation.fail == []


# Generated at 2022-06-21 19:02:58.192453
# Unit test for constructor of class Right
def test_Right():
    assert Right(5).value == 5


# Generated at 2022-06-21 19:03:01.932054
# Unit test for method is_right of class Either
def test_Either_is_right():
    assert Right('right').is_right()
    assert not Right('right').is_left()
    assert not Left('left').is_right()
    assert Left('left').is_left()

# Unit tests for Left class

# Generated at 2022-06-21 19:03:04.546352
# Unit test for constructor of class Left
def test_Left():
    assert Left(1) == Left(1)
    assert Left(1) != Left('qwe')
    assert Left(1) != Right(1)
    assert Left(1) != 1



# Generated at 2022-06-21 19:03:06.008185
# Unit test for method map of class Left
def test_Left_map():
    assert(Left('x').map(lambda x: x + 'y').value == 'x')



# Generated at 2022-06-21 19:03:08.019811
# Unit test for method is_right of class Left
def test_Left_is_right():
    assert Left(1).is_right() is False


# Generated at 2022-06-21 19:03:09.661337
# Unit test for method is_right of class Either
def test_Either_is_right():
    """
    Checks if method is_right works correctly.
    """
    assert Either(1).is_right() == False


# Generated at 2022-06-21 19:03:11.185336
# Unit test for method ap of class Left
def test_Left_ap():
    left = Left(2)
    applicative = Right(lambda x: x ** 2)
    assert left.ap(applicative) == left

# Generated at 2022-06-21 19:03:13.473013
# Unit test for method to_maybe of class Left
def test_Left_to_maybe():
    from pymonet.maybe import Maybe

    left = Left(5)
    assert left.to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:03:15.031557
# Unit test for method is_left of class Right
def test_Right_is_left():
    assert not Right(1).is_left()



# Generated at 2022-06-21 19:03:18.422771
# Unit test for method bind of class Right
def test_Right_bind():
    def mapper(x: int) -> Either[int]:
        return Right(x * x)

    assert Right(2).bind(mapper) == Right(4)
