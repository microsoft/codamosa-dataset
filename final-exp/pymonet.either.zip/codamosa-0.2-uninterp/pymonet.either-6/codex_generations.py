

# Generated at 2022-06-18 01:27:49.322372
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(1.0)
    assert Either(1) != Either("1")
    assert Either(1) != Either(True)
    assert Either(1) != Either(None)
    assert Either(1) != Either([1])
    assert Either(1) != Either((1,))
    assert Either(1) != Either({1})
    assert Either(1) != Either({1: 1})
    assert Either(1) != Either(set([1]))
    assert Either(1) != Either(frozenset([1]))
    assert Either(1) != Either(bytearray(b"1"))
    assert Either(1) != Either(memoryview(bytearray(b"1")))

# Generated at 2022-06-18 01:27:53.095478
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda x: x + 1, lambda x: x - 1) == 0
    assert Left(1).case(lambda x: x + 1, lambda x: x - 1) == 2


# Generated at 2022-06-18 01:27:55.854246
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:28:07.283631
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to

# Generated at 2022-06-18 01:28:12.459991
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:28:16.492186
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)


# Generated at 2022-06-18 01:28:20.503751
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:24.045471
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:28.140190
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda x: x + 1, lambda x: x + 2) == 3
    assert Left(1).case(lambda x: x + 1, lambda x: x + 2) == 2


# Generated at 2022-06-18 01:28:32.324136
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x + 1) == 2
    assert Right(1).case(lambda x: x + 1, lambda x: x + 1) == 2


# Generated at 2022-06-18 01:28:37.579226
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1


# Generated at 2022-06-18 01:28:40.836309
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:28:46.206658
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:28:48.087756
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:49.950102
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:56.374584
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)



# Generated at 2022-06-18 01:29:01.244567
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:05.003848
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:08.729461
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:29:11.842058
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:19.529606
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:24.216741
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(2)
    assert Right(1) != Left(2)


# Generated at 2022-06-18 01:29:29.554969
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:33.699350
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-18 01:29:36.868697
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-18 01:29:42.765440
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:45.309900
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:29:48.058009
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:29:50.891540
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:56.204929
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)



# Generated at 2022-06-18 01:30:07.283935
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:30:10.931669
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:14.322539
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:19.795683
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:30:23.295038
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:30:28.431688
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:33.535540
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:38.372918
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:41.973284
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:30:46.628249
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:06.386600
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:10.292517
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:15.254819
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:20.098771
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:23.332872
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:29.121517
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(1.0)
    assert Either(1) != Either('1')
    assert Either(1) != Either(True)
    assert Either(1) != Either(None)
    assert Either(1) != Either([1])
    assert Either(1) != Either((1,))
    assert Either(1) != Either({1})
    assert Either(1) != Either({1: 1})
    assert Either(1) != Either(set([1]))
    assert Either(1) != Either(frozenset([1]))
    assert Either(1) != Either(bytearray(b'1'))
    assert Either(1) != Either(memoryview(b'1'))
    assert Either

# Generated at 2022-06-18 01:31:31.651560
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:31:36.436242
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:31:40.809255
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:46.054483
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:22.646422
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:32:25.191156
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:28.596572
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:32.200556
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:37.731055
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:32:41.789346
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:47.188312
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:32:52.748164
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Right(Box(1)).to_lazy() == Lazy(lambda: Box(1))


# Generated at 2022-06-18 01:32:56.914188
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:00.988150
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)


# Generated at 2022-06-18 01:33:35.106602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().map(lambda x: x + 1).value() == 2
    assert Either(1).to_lazy().bind(lambda x: Lazy(lambda: x + 1)).value() == 2


# Generated at 2022-06-18 01:33:39.148537
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:33:41.355426
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()


# Generated at 2022-06-18 01:33:47.963391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to

# Generated at 2022-06-18 01:33:49.602374
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:33:53.840190
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:33:57.439952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:34:01.489217
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-18 01:34:04.398682
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:34:07.594132
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-18 01:35:05.978514
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:35:10.978941
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-18 01:35:19.570722
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to

# Generated at 2022-06-18 01:35:23.277412
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:35:27.046903
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:35:30.631363
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:35:33.097547
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:35:38.603151
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-18 01:35:42.151130
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:35:46.690405
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
