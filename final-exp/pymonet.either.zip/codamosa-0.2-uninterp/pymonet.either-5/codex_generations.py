

# Generated at 2022-06-18 01:27:46.430512
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:27:50.124059
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:27:54.977730
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:27:59.728940
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:04.230780
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)



# Generated at 2022-06-18 01:28:08.329892
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:14.172322
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x + 2) == 2
    assert Right(1).case(lambda x: x + 1, lambda x: x + 2) == 3



# Generated at 2022-06-18 01:28:17.921271
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:28:24.141320
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(1.0).to_lazy() == Lazy(lambda: 1.0)
    assert Either(True).to_lazy() == Lazy(lambda: True)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either([]).to_lazy() == Lazy(lambda: [])
    assert Either({}).to_lazy() == Lazy(lambda: {})


# Generated at 2022-06-18 01:28:29.100362
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)



# Generated at 2022-06-18 01:28:34.674870
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:28:37.744108
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:40.423092
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:28:44.374158
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:28:49.062919
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:28:56.102738
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(1.0)
    assert Either(1) != Either("1")
    assert Either(1) != Either(True)
    assert Either(1) != Either(None)
    assert Either(1) != Either([1])
    assert Either(1) != Either((1,))
    assert Either(1) != Either({1})
    assert Either(1) != Either({1: 1})
    assert Either(1) != Either(set([1]))
    assert Either(1) != Either(frozenset([1]))
    assert Either(1) != Either(bytearray(b"1"))
    assert Either(1) != Either(memoryview(b"1"))

# Generated at 2022-06-18 01:29:02.131186
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1
    assert Left(1) != None
    assert Right(1) != None


# Generated at 2022-06-18 01:29:05.647296
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:09.014209
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:11.802995
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:29:20.294121
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:24.505310
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:28.138541
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:29:33.139850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:29:37.598955
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:42.473585
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:50.895318
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().map(lambda x: x + 1).value() == 2
    assert Either(1).to_lazy().bind(lambda x: Lazy(lambda: x + 1)).value() == 2
    assert Either(1).to_lazy().ap(Lazy(lambda: lambda x: x + 1)).value() == 2
    assert Either(1).to_lazy().case(lambda x: x + 1, lambda x: x + 1) == 2
    assert Either(1).to_lazy().is_right()

# Generated at 2022-06-18 01:29:56.256323
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:00.245375
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:30:05.794510
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:19.887722
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:22.815430
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:30:26.501386
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:30.106297
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:33.217567
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:30:43.898655
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either([]).to_lazy() == Lazy(lambda: [])
    assert Either({}).to_lazy() == Lazy(lambda: {})
    assert Either(True).to_lazy() == Lazy(lambda: True)
    assert Either(False).to_lazy() == Lazy(lambda: False)
    assert Either(1.0).to_lazy() == Lazy(lambda: 1.0)
    assert Either(1j).to_lazy() == Lazy(lambda: 1j)


# Generated at 2022-06-18 01:30:48.903896
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:52.007454
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:56.353640
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:59.852428
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:22.120463
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:28.867740
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to

# Generated at 2022-06-18 01:31:33.848500
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:31:39.021326
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:31:44.616421
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:56.161395
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Right(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Left(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Right(Try(1)).to_lazy() == Lazy(lambda: Try(1))

# Generated at 2022-06-18 01:31:59.728763
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:32:04.937548
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:09.452196
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:11.816592
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:32:53.759045
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:32:57.027830
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:59.685475
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:33:03.740766
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:07.886176
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:33:12.339334
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:15.831520
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-18 01:33:18.790000
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:23.106515
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1
    assert Left(1) != None
    assert Right(1) != None


# Generated at 2022-06-18 01:33:27.733920
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:34:48.420089
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:34:52.716122
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:34:56.239773
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)



# Generated at 2022-06-18 01:35:01.115220
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:35:04.184508
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:35:08.753773
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:35:13.810003
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:35:16.734168
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:35:19.944388
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:35:24.378799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
