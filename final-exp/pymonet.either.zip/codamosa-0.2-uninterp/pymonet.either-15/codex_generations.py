

# Generated at 2022-06-18 01:27:37.385099
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:27:41.001016
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x + 2) == 2
    assert Right(1).case(lambda x: x + 1, lambda x: x + 2) == 3


# Generated at 2022-06-18 01:27:45.480743
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:27:48.869063
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:27:57.616661
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(1).to_lazy() != Lazy(lambda: 'a')
    assert Either(1).to_lazy() != Lazy(lambda: 2)
    assert Either(1).to_lazy() != Lazy(lambda: None)
    assert Either(1).to_lazy() != Lazy(lambda: [])
    assert Either(1).to_lazy() != Lazy(lambda: {})
    assert Either(1).to_lazy() != Lazy(lambda: ())
    assert Either(1).to_lazy() != Lazy(lambda: True)

# Generated at 2022-06-18 01:28:02.248129
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:28:07.117604
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:09.420987
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:28:15.299492
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:21.507582
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Left(1).to_box() == Box(1)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_box() == Box(1)

# Generated at 2022-06-18 01:28:27.744438
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:28:32.099483
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:28:35.796665
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:38.442284
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:41.113077
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:46.716238
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:51.013817
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:56.860084
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:28:59.395330
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:29:03.713525
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:29:09.310387
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:29:13.118047
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(1).to_lazy().value() == 1
    assert Either('a').to_lazy().value() == 'a'


# Generated at 2022-06-18 01:29:17.676074
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:21.180698
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:25.683612
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:29.889773
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:29:34.687136
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:38.296691
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:29:43.228448
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:29:46.110504
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:29:57.401415
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:30:04.540434
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:08.304012
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:10.814472
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:30:14.182455
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:19.604498
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:24.849779
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Either(Try(1)).to_lazy()
    assert Lazy(lambda: 1) == Either(Lazy(lambda: 1)).to_lazy()


# Generated at 2022-06-18 01:30:27.788612
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:30.811613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:30:33.508816
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:30:50.357191
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:30:52.763257
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:30:56.520545
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:31:00.715560
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:31:04.870979
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:08.710674
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:31:13.457930
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:19.813353
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1
    assert Left(1) != None
    assert Right(1) != None


# Generated at 2022-06-18 01:31:22.777050
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().map(lambda x: x + 1).value() == 2


# Generated at 2022-06-18 01:31:25.832086
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:31:55.698209
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:31:58.304180
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:32:03.683492
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:06.460180
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-18 01:32:11.091848
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:16.329545
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:32:21.601806
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(2)
    assert Right(1) != Left(2)


# Generated at 2022-06-18 01:32:26.770542
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:29.958192
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:32:34.616478
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:37.960983
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:33:41.903969
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-18 01:33:44.758883
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:33:49.157448
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)



# Generated at 2022-06-18 01:33:53.692157
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:33:56.762213
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-18 01:34:02.349876
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != 1
    assert Right(1) != 1


# Generated at 2022-06-18 01:34:05.586718
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-18 01:34:08.760291
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:34:13.645208
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:32.929728
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:36.371462
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:40.654770
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:45.212600
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:49.635570
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:53.596065
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:36:57.621096
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-18 01:37:02.569186
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().map(lambda x: x + 1).value() == 2
    assert Either(1).to_lazy().flat_map(lambda x: Lazy(lambda: x + 1)).value() == 2


# Generated at 2022-06-18 01:37:05.667388
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-18 01:37:14.342667
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to_lazy().value() == 1
    assert Either(1).to