

# Generated at 2022-06-12 04:58:49.190739
# Unit test for method case of class Either
def test_Either_case():
    assert Left(2).case(error=lambda x: x**2, success=lambda x: x/2) == 4
    assert Right(5).case(error=lambda x: x**2, success=lambda x: x/2) == 10



# Generated at 2022-06-12 04:58:51.393775
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either("foo") == Either("foo")
    assert Either("foo") != Either("bar")
    assert Either("foo") != Either(1)



# Generated at 2022-06-12 04:58:54.622958
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:58:58.879302
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)

    assert not left == right
    assert not left == 'qwe'
    assert left == Left(1)
    assert right == Right(1)
tests.append(test_Either___eq__)


# Generated at 2022-06-12 04:59:00.574808
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)
    assert left.__eq__(left)
    assert right.__eq__(right)
    assert not left.__eq__(right)
    assert not right.__eq__(left)


# Generated at 2022-06-12 04:59:03.406335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(True).to_lazy() == Lazy(lambda: True)
    assert Left(False).to_lazy() == Lazy(lambda: False)


# Generated at 2022-06-12 04:59:05.605768
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: 5, lambda x: x) == 5
    assert Right(2).case(lambda x: x, lambda x: 3) == 3



# Generated at 2022-06-12 04:59:08.165265
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f() -> Either[int]:
        return Right(2)
    result = f().to_lazy().run()
    assert result == 2


# Generated at 2022-06-12 04:59:13.617472
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Left(1) == Left(2)



# Generated at 2022-06-12 04:59:20.350926
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Just, Nothing
    from pymonet.monad_lazy import Lazy

    assert Just(10) == Right(10)
    assert isinstance(Right(10), Either)

# Generated at 2022-06-12 04:59:28.089142
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 04:59:29.872581
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either[int](5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:59:33.000740
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left('Error').to_lazy(), Lazy)
    assert Right(1).to_lazy().get() == 1
    assert Left('Error').to_lazy().get() == 'Error'


# Generated at 2022-06-12 04:59:38.955164
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy_success = Try(10).to_lazy()
    lazy_fail = Try.fail(TypeError).to_lazy()

    assert isinstance(lazy_success, Lazy) and isinstance(lazy_fail, Lazy)
    assert lazy_success is Lazy(lambda: 10) and lazy_fail is Lazy(lambda: TypeError)



# Generated at 2022-06-12 04:59:42.426819
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:59:47.831113
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Either(Maybe.nothing()).to_lazy() == Lazy(lambda: Maybe.nothing())
    assert Either(Maybe.just(3)).to_lazy() == Lazy(lambda: Maybe.just(3))
    assert Either(Left(3)).to_lazy() == Lazy(lambda: Left(3))
    assert Either(Right(3)).to_lazy() == Lazy(lambda: Right(3))



# Generated at 2022-06-12 04:59:51.392233
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().value() == Either(2).to_lazy().value()
    assert Either(1).to_lazy().value() != Either(2).to_lazy().value()



# Generated at 2022-06-12 04:59:55.595704
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    right = Right(1)
    left = Left(1)
    assert right.to_lazy() == Lazy(lambda: 1)
    assert left.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:00:00.425911
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(10)).value() == Lazy(lambda: 10).value()
    assert Either.to_lazy(Left('msg')).value() == Lazy(lambda: 'msg').value()


# Generated at 2022-06-12 05:00:02.944414
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left([1, 2]).to_lazy().value() == [1, 2]
    assert Right(1).to_lazy().value() == 1

# Generated at 2022-06-12 05:00:06.089114
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either.to_lazy
    """
    either = Right(2)
    assert either.to_lazy().get() == 2

# Generated at 2022-06-12 05:00:08.544709
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    x = Lazy(lambda: 'foo')
    assert x == Right(1).to_lazy()
    assert x == Left(1).to_lazy()



# Generated at 2022-06-12 05:00:14.547734
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just
    from pymonet.validation import Valid

    assert Lazy(lambda: 4).to_lazy() == Lazy(lambda: 4)
    assert Just(4).to_lazy() == Lazy(lambda: 4)
    assert Valid(4).to_lazy() == Lazy(lambda: 4)

# Generated at 2022-06-12 05:00:19.243438
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(42).to_lazy(), Lazy)
    assert isinstance(Left(42).to_lazy(), Lazy)
    assert Right(42).to_lazy().get() == 42
    assert Left(42).to_lazy().get() == 42

# Generated at 2022-06-12 05:00:30.089225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def some_func():
        return 'test'

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)

    assert Right(some_func).to_lazy() == Lazy(lambda: 'test')
    assert Left(some_func).to_lazy() == Lazy(lambda: 'test')

    assert Right(Maybe.just(1)).to_lazy() == Lazy(lambda: Maybe.just(1))
    assert Left(Maybe.just(1)).to_lazy() == Lazy(lambda: Maybe.just(1))



# Generated at 2022-06-12 05:00:35.069383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # assert that Left return Lazy with identity of None
    assert Left(None).to_lazy() == Lazy(None)

    # assert that Right return Lazy with identity of 'a_value'
    assert Right('a_value').to_lazy() == Lazy('a_value')



# Generated at 2022-06-12 05:00:37.487829
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Lazy(lambda: 2) == Either(2).to_lazy()


# Generated at 2022-06-12 05:00:38.895427
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import decision
    from pymonet.monad_try import Try

    assert decision('2 + 2').to_lazy() == Lazy(lambda: Try(4))


# Generated at 2022-06-12 05:00:41.188765
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:00:51.029856
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2).is_lazy() is True
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(2).to_lazy().value() == 2
    assert Left('error').to_lazy().value() == 'error'
    assert Lazy(lambda: 2).map(lambda v: v + 1) == Lazy(lambda: 3)

# Generated at 2022-06-12 05:00:56.814353
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either.right(1).to_lazy()
    assert Lazy(lambda: 1) == Either.left(1).to_lazy()



# Generated at 2022-06-12 05:00:59.089400
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1



# Generated at 2022-06-12 05:01:01.548056
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def function():
        return 2
    lazy = Either(1).to_lazy()
    assert lazy == Lazy(function)

# Generated at 2022-06-12 05:01:04.462306
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    from pymonet.lazy import Lazy
    either = Left(1)

    # when
    actual = either.to_lazy()

    # then
    assert actual == Lazy(lambda: 1)



# Generated at 2022-06-12 05:01:09.608568
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.test_utils import assert_exception, assert_equal

    for value in [None, False, 'x', [], (), {}]:
        assert_equal(Right(value).to_lazy().get_value(), value)
        assert_equal(Left(value).to_lazy().get_value(), value)


# Generated at 2022-06-12 05:01:18.807406
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functors import is_functor
    from pymonet.monads import is_monad
    from pymonet.monoids import is_monoid
    from pymonet.applicatives import is_applicative

    assert is_functor(Right(None).to_lazy())
    assert is_monad(Right(None).to_lazy())
    assert is_applicative(Right(None).to_lazy())
    assert is_monoid(Right(None).to_lazy())
    assert Right(None).to_lazy().is_right()
    assert Left(None).to_lazy().is_left()

    assert is_functor(Left(None).to_lazy())

# Generated at 2022-06-12 05:01:27.683851
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either

    :returns: None
    :rtype: None
    """
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Left(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Right(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Left(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Right(Try(1)).to_lazy() == Lazy(lambda: Try(1))



# Generated at 2022-06-12 05:01:34.842445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box

    assert Right(1).to_lazy().value() == 1
    assert Left('Table not created').to_lazy().value() == 'Table not created'
    assert Left(Box()).to_lazy().value().value is None
    assert Left(Box(1)).to_lazy().value().value == 1
    assert Right(Box()).to_lazy().value().value is None
    assert Right(Box(1)).to_lazy().value().value == 1


# Generated at 2022-06-12 05:01:40.017394
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Either(10).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 10

    result = Either("10").to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == "10"


# Generated at 2022-06-12 05:01:42.143833
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:48.490903
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Assert that Either is properly converted to Lazy.
    """
    from pymonet.lazy import Lazy

    def test_function():
        return 'test'

    assert Right('test').to_lazy() == Lazy(test_function)


# Generated at 2022-06-12 05:01:51.036860
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    func = lambda x: x

    assert Either(func).to_lazy() == Lazy(Either(func))


# Generated at 2022-06-12 05:01:53.217564
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # assure that to_lazy of Left monad is equal to lazy(None)
    assert Either.Left(None).to_lazy() == Lazy(lambda: None)

    # assure that to_lazy of Right monad is equal to lazy('1')
    assert Either.Right('1').to_lazy() == Lazy(lambda: '1')

# Generated at 2022-06-12 05:01:56.890225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test for method to_lazy of class Either
    """
    from pymonet.test_utils import assert_equal

    res = Right(5).to_lazy().evaluate()

    assert_equal(res, 5)


# Generated at 2022-06-12 05:02:00.190779
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()



# Generated at 2022-06-12 05:02:03.135975
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:02:05.743834
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    l = Either(1)
    l = l.to_lazy()
    assert isinstance(l, Lazy)
    assert l() == 1


# Generated at 2022-06-12 05:02:10.344357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left = Left(1)
    right = Right(2)

    def assert_to_lazy():
        assert left.to_lazy() == Lazy(lambda: 1)
        assert right.to_lazy() == Lazy(lambda: 2)

    assert_to_lazy()


# Generated at 2022-06-12 05:02:18.422882
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test Either.to_lazy() method with value of type int
    assert isinstance((Right(2)).to_lazy().eval(), int)
    assert (Right(1)).to_lazy() == (Left(1)).to_lazy()

    # Test Either.to_lazy() method with value of type str
    assert isinstance((Right('a')).to_lazy().eval(), str)
    assert (Right('a')).to_lazy() == (Left('a')).to_lazy()

    # Test Either.to_lazy() method with value of type bool
    assert isinstance((Right(True)).to_lazy().eval(), bool)
    assert (Right(True)).to_lazy() == (Left(True)).to_lazy()


# Generated at 2022-06-12 05:02:24.104516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    # GIVEN instance of Either class
    either = Either(42)
    # WHEN to_lazy method is called
    lazy = either.to_lazy()
    # THEN lazy should be instance of Lazy
    assert isinstance(lazy, Lazy)
    # AND contain function resolving previous value
    assert lazy.get() == 42


# Generated at 2022-06-12 05:02:31.681808
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(10).to_lazy().evaluate() == 10
    assert Right(10).to_lazy().evaluate() == 10


# Generated at 2022-06-12 05:02:33.212187
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:02:39.933659
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def sum(x, y): return x + y
    assert Either(1).to_lazy().bind(sum, 2).value() == 3
    assert Either('1').to_lazy().bind(sum, '2').value() == '12'
    assert Either(User('John')).to_lazy().bind(sum, User('Doe')).value().name == 'John Doe'


# Generated at 2022-06-12 05:02:41.821051
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:02:50.032502
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functions import compose
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def f(x):
        return x+1

    def g(x):
        return x*2

    x = Right(5)
    fgh = compose(g, f)

    y = x.to_lazy().map(fgh)
    assert(isinstance(y, Lazy))

    assert(y.eval() == 12)
    assert(y.eval() == 12)

    y = x.to_lazy().bind(lambda x: Lazy(lambda: fgh(x.get_value())))
    assert(isinstance(y, Lazy))

    assert(y.eval() == 12)
    assert(y.eval() == 12)

    y = x.to

# Generated at 2022-06-12 05:02:54.024341
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    x = Either.Right(1)
    assert isinstance(x.to_lazy(), Lazy)
    assert x.to_lazy().evaluate() == 1


# Generated at 2022-06-12 05:02:58.836756
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:03:02.214152
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:03:06.550570
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet import Lazy

    assert Lazy(lambda: "42") == Right("42").to_lazy()
    assert Lazy(lambda: "42") == Left("42").to_lazy()



# Generated at 2022-06-12 05:03:14.034421
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(0).to_lazy() == Lazy(lambda: 0)
    assert Left(0).to_lazy() == Lazy(lambda: 0)

# Generated at 2022-06-12 05:03:29.043825
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Left('error')) == Lazy(lambda: 'error')



# Generated at 2022-06-12 05:03:32.330884
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:03:35.212823
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Right(5).to_lazy()
    assert Lazy(lambda: 5) != Left(5).to_lazy()


# Generated at 2022-06-12 05:03:38.439659
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(1)
    assert right.to_lazy().is_lazy()
    assert right.to_lazy().force() == 1


# Generated at 2022-06-12 05:03:40.488161
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:03:42.964952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("Error message").to_lazy() == Lazy(lambda: "Error message")
    assert Right("Result").to_lazy() == Lazy(lambda: "Result")


# Generated at 2022-06-12 05:03:46.896550
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Given
    either = Either(1)

    # When
    lazy = either.to_lazy()

    # Then
    assert lazy.is_resolved() and \
           lazy.value() == 1


# Generated at 2022-06-12 05:03:50.827846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    right = Either.right(1)

    assert right.to_lazy() == Lazy(lambda: 1)
    assert right.to_lazy() != Lazy(lambda: 2)



# Generated at 2022-06-12 05:03:54.569974
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy = Right(4).to_lazy()

    assert lazy.value() == 4

    lazy = Left('Test').to_lazy()

    assert lazy.value() == 'Test'



# Generated at 2022-06-12 05:03:59.608678
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> from pymonet.either import Right
    >>> result = Right(1)
    >>> lazy = result.to_lazy()
    >>> lazy.evaluate()
    1
    >>> from pymonet.either import Left
    >>> result = Left(1)
    >>> lazy = result.to_lazy()
    >>> lazy.evaluate()
    1
    """


# Generated at 2022-06-12 05:04:11.533375
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:04:17.145999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    try_monad = Try(1)
    right = Right(1)
    assert right.to_lazy().run() == try_monad.to_lazy().run()
    assert right.to_lazy().value == try_monad.to_lazy().value
    assert right.to_lazy().value == 1


# Generated at 2022-06-12 05:04:20.528749
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:26.033837
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.monoid import SumMonoid

    l = lazy.Lazy(lambda: 100)
    assert Lazy(100) == l

    assert SumMonoid(100) == SumMonoid(100).mappend(SumMonoid(100))

    assert SumMonoid(100) < SumMonoid(200)



# Generated at 2022-06-12 05:04:29.997265
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ Unit test for Either.to_lazy. """
    assert Right(42).to_lazy().run() == 42
    assert Left("error").to_lazy().run() == "error"


# Generated at 2022-06-12 05:04:33.730292
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test function to_lazy of class Either.
    """
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    assert Either(6).to_lazy() == Lazy(lambda: 6)
    assert Either(6).to_lazy()() == 6


# Generated at 2022-06-12 05:04:40.180263
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left_lazy = Left(0).to_lazy()
    assert isinstance(left_lazy, Lazy)
    assert left_lazy.value() == 0

    right_lazy = Right(0).to_lazy()
    assert isinstance(right_lazy, Lazy)
    assert right_lazy.value() == 0



# Generated at 2022-06-12 05:04:43.515404
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either.to_lazy(Right(2)), Lazy)
    assert isinstance(Either.to_lazy(Left("a")), Lazy)


# Generated at 2022-06-12 05:04:47.854774
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    def add(x):
        return x + 1
    assert Right(1).to_lazy().map(add) == (2)
    assert Left(1).to_lazy().map(add) == 1


# Generated at 2022-06-12 05:04:49.645914
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:05:15.849928
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either.to_lazy(Left(123)), Lazy)
    assert callable(Either.to_lazy(Left(123)).value)
    assert isinstance(Either.to_lazy(Right(123)), Lazy)
    assert callable(Either.to_lazy(Right(123)).value)



# Generated at 2022-06-12 05:05:20.175425
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def _expr():
        a = Lazy(lambda: 5)
        b = Lazy(lambda: False)
        c = Lazy(lambda: True)
        if b.value:
            return a.value + 6
        else:
            return a.value + 7

    def result():
        if False:
            return 5 + 6
        else:
            return 5 + 7

    assert Right(_expr()).to_lazy().value() == Left(result()).to_lazy().value()


# Unit tests for method case of class Either

# Generated at 2022-06-12 05:05:24.945294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def function():
        return 1 + 2

    value = Right(function)

    assert isinstance(value.to_lazy(), Lazy)
    assert value == value.to_lazy().force()



# Generated at 2022-06-12 05:05:29.676558
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    from pymonet.lazy import Lazy

    def fib(n):
        if n < 2:
            return n
        else:
            return fib(n - 1) + fib(n - 2)

    assert Either.to_lazy(Right(fib)) == Lazy(fib)


# Generated at 2022-06-12 05:05:33.701463
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def value() -> str:
        return 'test'

    assert Right(value).to_lazy() == Lazy(value)
    assert Left(value).to_lazy() == Lazy(value)



# Generated at 2022-06-12 05:05:35.758332
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(100).to_lazy().get_value() == 100
    assert Left(100).to_lazy().get_value() == 100

# Generated at 2022-06-12 05:05:41.280864
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    assert isinstance(Either.to_lazy(Right(1)), Lazy)
    assert Lazy.eval(Either.to_lazy(Right(1))) == 1
    assert isinstance(Either.to_lazy(Left('1')), Lazy)
    assert Lazy.eval(Either.to_lazy(Left('1'))) == '1'


# Generated at 2022-06-12 05:05:50.392827
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test of to_lazy method of Either class."""

    import unittest

    def assert_everything(actual, expected):
        if isinstance(actual, Either):
            assert isinstance(actual.value, Lazy) and actual.value.value() == expected
        else:
            assert isinstance(actual, Lazy) and actual.value() == expected

    def assert_equals(actual, expected):
        assert_everything(actual.to_lazy(), expected)
        assert_everything(actual.to_box().to_lazy(), expected)
        assert_everything(actual.to_try().to_lazy(), expected)

    class TestEitherToLazy(unittest.TestCase):
        """Unit test for to_lazy method of Either class"""


# Generated at 2022-06-12 05:06:00.911722
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def calls_counter(function: Callable[..., U]) -> Callable[..., U]:
        def counter_function(*args, **kwargs):
            counter_function.call_count += 1
            return function(*args, **kwargs)
        counter_function.call_count = 0
        return counter_function

    add_lazy = Lazy(lambda x: calls_counter(lambda y: x + y))

    assert add_lazy(3)(4) == 7
    assert add_lazy(3).call_count == 1
    assert add_lazy.value(3)(4) == 7
    assert add_lazy(3)(5) == 8
    assert add_lazy(3).call_count == 2


# Generated at 2022-06-12 05:06:05.322308
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)

# Generated at 2022-06-12 05:06:34.284202
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.Right(2).to_lazy() == Lazy(lambda: 2)
    assert Either.Left(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:06:36.047735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy.__doc__ is not None

# Generated at 2022-06-12 05:06:40.125656
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:06:43.511747
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:46.895566
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:52.383396
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('error')\
        .to_lazy()\
        .bind(lambda x: x)\
        .__class__.__name__ == 'Left'
    assert Right('1')\
        .to_lazy()\
        .bind(lambda x: int(x))\
        .value == 1


# Generated at 2022-06-12 05:06:57.487853
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 5) == Either(5).to_lazy()
    assert Lazy.unit(5) == Either(5).to_lazy()
    assert Lazy(lambda: Right(5)).join() == Right(5)
    assert Lazy(lambda: Left(5)).join() == Left(5)


# Generated at 2022-06-12 05:07:00.855490
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    a = Left([])
    f = lambda: 1
    lazy = a.to_lazy()
    assert bool(lazy == Lazy[f])

# Generated at 2022-06-12 05:07:02.460125
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy = Right(2).to_lazy()
    assert lazy.call() == 2


# Generated at 2022-06-12 05:07:04.260046
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @lazy
    def f() -> int:
        return 10

    assert Right(f).to_lazy()().value == 10

# Generated at 2022-06-12 05:07:36.253840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either::to_lazy() method to verify that it creates new Lazy instance of the same value and doesn't evaluate it

    :return: True if test passed False otherwise
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy

    def func():
        return 1

    lazy = Lazy(func)
    right = Right(1)

    assert right.to_lazy().is_equals(lazy)



# Generated at 2022-06-12 05:07:39.738294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(3).to_lazy() == Lazy(lambda: Left(3))
    assert Right(3).to_lazy() == Lazy(lambda: Right(3))


# Generated at 2022-06-12 05:07:41.697729
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:07:45.056565
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy() == Lazy(lambda: 2)

    assert Left(3).to_lazy() == Lazy(lambda: 3)

    assert Right(3).to_lazy() == Lazy(lambda: 3)

    assert Right(4).to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 05:07:46.180215
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(1))() == 1

# Generated at 2022-06-12 05:07:49.094500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    assert Left('some value').to_lazy().eval() == 'some value'
    assert Right('some value').to_lazy().eval() == 'some value'


# Generated at 2022-06-12 05:07:52.705046
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    value = 1

    left = Left(value)
    right = Right(value)

    assert left.to_lazy() == Lazy(lambda: value)
    assert right.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:07:58.362981
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy ()

    :return:
    """

    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either([]).to_lazy() == Lazy(lambda: [])
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either('').to_lazy() == Lazy(lambda: '')
    assert Either(['a']).to_lazy() == Lazy(lambda: ['a'])



# Generated at 2022-06-12 05:08:04.018558
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    def test_Left_to_lazy(mocker):
        """Unit test for method to_lazy of class Left"""

        mocker.patch('pymonet.either.Lazy', return_value=True)

        left = Left('data')
        assert left.to_lazy() is True
        left.to_lazy.assert_called_with(lambda: 'data')

    def test_Right_to_lazy(mocker):
        """Unit test for method to_lazy of class Right"""

        mocker.patch('pymonet.either.Lazy', return_value=True)

        right = Right('data')
        assert right.to_lazy() is True
        right.to_lazy.assert_called_with(lambda: 'data')



# Generated at 2022-06-12 05:08:06.547406
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    x = Either(Maybe.just(10))

    assert x.to_lazy() == Lazy(lambda: Maybe.just(10)), 'Either cannot be converted to Lazy'
