

# Generated at 2022-06-12 04:58:55.120145
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(8).to_lazy().value() == 8
    assert Left('error').to_lazy().value() == 'error'


# Generated at 2022-06-12 04:58:58.658410
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Either(1)
    assert Right(1) == Right(1)



# Generated at 2022-06-12 04:59:03.804661
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1) is True
    assert Left(2) == Left(3) is False
    assert Left('a') == Left('b') is False
    assert Left('') == Left('') is True

    assert Right(1) == Right(1) is True
    assert Right(2) == Right(3) is False
    assert Right('a') == Right('b') is False
    assert Right('') == Right('') is True



# Generated at 2022-06-12 04:59:08.854125
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert not Right(1) == Left(2)
    assert not Left(1) == Left('1')
    assert (Left(1) == Left(1)) is True
    assert (Left(1) == Right(1)) is False
    assert (Right(1) == Right(1)) is True
    assert (Right(1) == Left(1)) is False



# Generated at 2022-06-12 04:59:10.912687
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    assert Left(0) == Left(0)
    assert Right(0) == Right(0)
    assert not Left(0) == Right(0)
    assert not Left(0) == 0
    assert not Left(0) == object()
    assert not Right(0) == 0
    assert not Right(0) == object()


# Generated at 2022-06-12 04:59:14.968747
# Unit test for method case of class Either
def test_Either_case():
    assert Either(4).case(lambda _: 4, lambda value: value) == 4

    assert Either("bad").case(lambda _: "bad", lambda value: value) == "bad"



# Generated at 2022-06-12 04:59:19.914786
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 04:59:22.717034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:59:28.206987
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(1.0)
    assert Either(1) != 1
    assert not Either(1) != Either(1)
    assert not Either(1) == Either(2)
    assert not Either(1) == Either(1.0)
    assert not Either(1) == 1


# Generated at 2022-06-12 04:59:31.538744
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)

# Generated at 2022-06-12 04:59:37.393628
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) == None
    assert Right(1) == None


# Generated at 2022-06-12 04:59:42.027454
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # GIVEN
    error = Left(1)
    success = Right(2)

    # WHEN
    result1 = error == error
    result2 = error == success
    result3 = success == success

    # THEN
    assert (result1)
    assert (not result2)
    assert (result3)



# Generated at 2022-06-12 04:59:45.929093
# Unit test for method case of class Either
def test_Either_case():
    def error(value):
        return 'error'

    def success(value):
        return 'success'

    result = Right(1).case(error, success)
    assert result == 'success'

    result = Left(1).case(error, success)
    assert result == 'error'


# Generated at 2022-06-12 04:59:49.926590
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda x: x + 2, lambda x: x + 3) == 4
    # call error handler
    assert Left(2).case(lambda x: x + 2, lambda x: x + 3) == 4
    # call success handler



# Generated at 2022-06-12 04:59:54.483487
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(2) == Right(2)
    assert Left('left') == Left('left')
    assert Right(2) == Right(2)
    assert not Left('left') == Right(2)
    assert not Left('left1') == Left('left2')
    assert not Right(2) == Right(3)

# Generated at 2022-06-12 04:59:58.375819
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) != 2
    assert Right(1) != Left(1)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)


# Generated at 2022-06-12 05:00:00.809308
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(3).to_lazy().run() == 3
    assert Left(3).to_lazy().run() == 3


# Generated at 2022-06-12 05:00:05.223503
# Unit test for method case of class Either
def test_Either_case():
    def left(value):
        return 1

    def right(value):
        return 0

    left_value = Left(1)
    right_value = Right(1)
    result_left = left_value.case(left, right)
    result_right = right_value.case(left, right)

    assert result_left == 1
    assert result_right == 0


# Generated at 2022-06-12 05:00:08.987817
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) != Right(2)

    assert not (Left(1) == Right(1))
    assert not (Right(1) == Left(1))

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)



# Generated at 2022-06-12 05:00:14.739810
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(None)
    right = Right(None)
    assert left.__eq__(left) is True
    assert right.__eq__(right) is True
    assert right.__eq__(right) is right == right
    assert right.__eq__(left) is False
    assert left.__eq__(right) is False


# Generated at 2022-06-12 05:00:18.755631
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _():
        return False

    assert Left(_()).to_lazy() == Lazy(_)

# Generated at 2022-06-12 05:00:30.499415
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right("a") == Right("a")
    assert Right("a") != Right("b")
    assert Left("a") != Right("a")

    assert Lazy(lambda: 1) != Left("a")
    assert Lazy(lambda: 1) != Right("a")
    assert Lazy(lambda: "a") != Left("a")
    assert Lazy(lambda: "a") != Right("a")
    assert Try(1) != Left("a")
    assert Try(1) != Right("a")
    assert Try("a")

# Generated at 2022-06-12 05:00:34.045434
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(2)


# Generated at 2022-06-12 05:00:45.847617
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Case of equality of 2 success Either
    assert Right(7) == Right(7)
    assert Right(1) != Right(7)
    assert Right(7) != Right(1)
    assert Right(7) != Left(7)
    assert Left(7) != Left(7)
    assert Left(1) != Left(7)
    assert Left(7) != Left(1)
    assert Left(7) != Right(7)

    # Case of equality between either and other monads
    assert Right(7) != Maybe.just(7)
    assert Right(1) != Maybe.just

# Generated at 2022-06-12 05:00:48.373061
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:00:51.958416
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)

# Generated at 2022-06-12 05:01:02.079967
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Try(1).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=True).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=False).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:05.482412
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    @Lazy
    def lazy():
        return 'lazy'

    assert Right('right').to_lazy() == Lazy(lambda: 'right')
    assert Left('left').to_lazy() == Lazy(lambda: 'left')



# Generated at 2022-06-12 05:01:07.665230
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(4) == Left(4)
    assert Left(4) != Right(4)


# Generated at 2022-06-12 05:01:10.505122
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('1') == Left('1')
    assert Left('1') != Right('2')
    assert not Left('1') == Right('1')


# Generated at 2022-06-12 05:01:18.128563
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 2) == Right(2).to_lazy()
    assert Lazy(lambda: 2) == Left(None).to_lazy()



# Generated at 2022-06-12 05:01:19.112225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass


# Generated at 2022-06-12 05:01:22.562059
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(123).to_lazy() == Lazy(lambda: 123)
    assert Left(123).to_lazy() == Lazy(lambda: 123)



# Generated at 2022-06-12 05:01:24.096074
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Left(5)) == None


# Generated at 2022-06-12 05:01:27.371691
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(42).to_lazy() == Lazy(lambda: 42)
    assert Left(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-12 05:01:33.035319
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # to_lazy Right
    assert Lazy(lambda: 1) == Box(1).to_lazy() == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Box(1).to_lazy() == Left(1).to_lazy()



# Generated at 2022-06-12 05:01:36.960989
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test of the method to_lazy of the class Either
    """
    assert Left("test").to_lazy() == Lazy(lambda: "test")

    assert Right("test").to_lazy() == Lazy(lambda: "test")



# Generated at 2022-06-12 05:01:45.361873
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @Lazy
    def lazy_value():
        return "value"

    lazy_value_list = [lazy_value(), lazy_value(), lazy_value()]

    empty_either = Left().to_lazy()
    assert empty_either.case(lambda value: value, lambda value: value) == ()

    full_either = Right("value").to_lazy()
    assert full_either.case(lambda value: value, lambda value: value) == "value"

    assert empty_either.case(lambda value: value, lambda value: value) == ()
    assert full_either.case(lambda value: value, lambda value: value) == "value"
    assert Right("value").to_lazy().case(lambda value: value, lambda value: value) == "value"

# Generated at 2022-06-12 05:01:49.683973
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    lazy.unit_test_module()

    from pymonet.lazy import Lazy

    assert Either(True).to_lazy() == Lazy(lambda: True)
    assert Either(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 05:01:53.821042
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def l():
        return 'value'

    assert Left(l).to_lazy() == Lazy(l)
    assert Right(l).to_lazy() == Lazy(l)

# Generated at 2022-06-12 05:01:59.574765
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Right(3).to_lazy()
    assert Lazy(lambda: -1) == Left(-1).to_lazy()


# Generated at 2022-06-12 05:02:03.472133
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def eager():
        # Type hint
        # :type val: int
        val = 1 + 2
        return val

    def lazy():
        # Type hint
        # :type val: Lazy[int]
        val = Right(1).to_lazy().map(lambda x: x + 2)
        return val.get()

    assert eager() == lazy()



# Generated at 2022-06-12 05:02:08.064275
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    right = Right(12345)
    left = Left(12345)

    # when
    lazy_right = right.to_lazy()
    lazy_left = left.to_lazy()

    # then
    assert isinstance(lazy_right, Lazy)
    assert lazy_right.get() == 12345
    assert isinstance(lazy_left, Lazy)
    assert lazy_left.get() == 12345


# Generated at 2022-06-12 05:02:10.301654
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(3).to_lazy().get_value() == 3
    assert Right(3).to_lazy().get_value() == 3


# Generated at 2022-06-12 05:02:12.724994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(None).to_lazy().eval() is None
# test_Either_to_lazy()


# Generated at 2022-06-12 05:02:16.477470
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Right('Argument').to_lazy() == Lazy(lambda: 'Argument')
    assert Left(Box(5)).to_lazy() == Lazy(lambda: Box(5))


# Generated at 2022-06-12 05:02:20.106196
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # pylint: disable=no-else-return
    lazy_either = Left(10).to_lazy()
    if lazy_either:
        return lazy_either.value()
    else:
        return "It's None"

# Generated at 2022-06-12 05:02:22.831319
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().force() == 2
    assert Left(2).to_lazy().force() == 2

# Generated at 2022-06-12 05:02:25.478544
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:02:34.750627
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either."""
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(None).to_lazy() == Lazy(lambda: None)

    assert Right(1).to_lazy().to_either() == Right(1)
    assert Right(1).to_lazy().to_box() == Box(1)
    assert Right(1).to_lazy().to_try() == Try(1, is_success=True)

# Generated at 2022-06-12 05:02:42.769786
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(1).to_lazy() == Lazy(lambda: 1) and Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:02:46.209952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:02:51.052023
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).map(lambda x: x + 1).to_lazy() == Lazy(lambda: 2)
    assert Either(1).flat_map(lambda x: x + 1).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:02:54.789796
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 1
    lazy_left = Left(value).to_lazy()
    lazy_right = Right(value).to_lazy()

    assert lazy_left.evaluate() == value
    assert lazy_right.evaluate() == value



# Generated at 2022-06-12 05:02:56.505781
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('value').to_lazy().get() == 'value'



# Generated at 2022-06-12 05:03:02.815509
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    assert Either(1).to_lazy().run() == 1
    assert Either(Try(1)).to_lazy().run().value() == 1
    assert Either(Try(2)).to_lazy().run().is_failure()


# Generated at 2022-06-12 05:03:09.920852
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(Box(1)).to_lazy().force() == Lazy(lambda: 1)
    assert Right(Box(1)).to_lazy().force() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:03:12.195322
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 05:03:18.848512
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def summ(x, y):
        return x + y
    def square(x):
        return x ** 2

    assert Left(25).to_lazy() == Lazy(lambda: 25)
    assert Right(summ(2, 3)).to_lazy() == Lazy(lambda: 5)
    assert Right(square).to_lazy() == Lazy(lambda: square)


# Generated at 2022-06-12 05:03:21.839694
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either.Right(10).to_lazy()
    assert lazy.get() == 10
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:03:35.469703
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Right(1).to_lazy() == Lazy(lambda: 1))
    assert(Left(1).to_lazy() == Lazy(lambda: 1))
    assert(Right(1).to_lazy() == Lazy(lambda: 1))
    assert(Left(1).to_lazy() == Lazy(lambda: 1))

# Generated at 2022-06-12 05:03:38.159792
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(0).to_lazy().force() == 0
    assert Right(1).to_lazy().force() == 1


# Generated at 2022-06-12 05:03:44.838816
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.monad_either import Left, Right
    from pymonet.monad_maybe import Nothing, Just
    from pymonet.monad_validation import Success, Failure
    from pymonet.monad_list import List

    assert Left("error").to_lazy() == Lazy(lambda: "error")
    assert Right("value").to_lazy() == Lazy(lambda: "value")
    assert Try(Exception("error")).to_lazy() == Lazy(lambda: Exception("error"))
    assert Try("value").to_lazy() == Lazy(lambda: "value")
    assert Box(Exception("error")).to_lazy() == Lazy

# Generated at 2022-06-12 05:03:50.719877
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test with Left Either
    either = Either.to_lazy(Left("test"))

    # Test with Right Either
    assert Lazy(lambda: "test") == either

    # Test with Right Either
    either = Either.to_lazy(Right("test"))

    # Test with Right Either
    assert Lazy(lambda: "test") == either



# Generated at 2022-06-12 05:03:53.648678
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(4).to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 05:03:56.651726
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Left(1).to_lazy() == Right(1).to_lazy()


# Generated at 2022-06-12 05:04:00.180864
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert Right(1).to_lazy().force() == 1
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Left(1).to_lazy().force() == 1


# Generated at 2022-06-12 05:04:03.439324
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('foo').to_lazy().force() == 'foo'
    assert Right('foo').to_lazy().force() == 'foo'


# Generated at 2022-06-12 05:04:06.678730
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    value = 1

    actual = Either(value).to_lazy()
    expected = Lazy(lambda: value)

    assert actual == expected


# Generated at 2022-06-12 05:04:15.931861
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe

    assert Lazy(lambda: Either.lazy(2)) != Lazy(lambda: Either.lazy(3))
    assert Lazy(lambda: Either.lazy(2)).get_value() == Right(2)
    assert Lazy(lambda: Either.lazy(Maybe.just(3))).get_value() == Right(3)
    assert Lazy(lambda: Either.lazy(Maybe.nothing())).get_value() == Left({})


# Generated at 2022-06-12 05:04:39.835036
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    assert Right(5).to_lazy().evaluate() == 5
    assert Right(5).to_lazy().evaluate() == 5


# Generated at 2022-06-12 05:04:44.319116
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:04:47.905039
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.matcher import pattern

    assert type(Left('error').to_lazy()) is pattern(lazy=Lazy)
    assert type(Right('success').to_lazy()) is pattern(lazy=Lazy)


# Generated at 2022-06-12 05:04:57.488495
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    lazy_a_m = Either(Box(8)).to_lazy()
    assert lazy_a_m.val()\
        .map(lambda x: x * 2).val() == 16
    assert lazy_a_m.val()\
        .map(lambda x: x * 2).is_right()

    lazy_b_m = Either(Try(2)).to_lazy()
    assert lazy_b_m.val()\
        .map(lambda x: x * 2).val() == 4
    assert lazy_b_m.val()\
        .map(lambda x: x * 2).is_right()


# Generated at 2022-06-12 05:05:05.508789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add_one(x):
        return x + 1

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).bind(add_one).to_lazy() == Lazy(lambda: add_one(1))
    assert Left(1).bind(add_one).to_lazy() == Lazy(lambda: 1)
    assert Right(1).map(add_one).to_lazy() == Lazy(lambda: add_one(1))
    assert Left(1).map(add_one).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:06.676277
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().value() == 2
    assert Left("error").to_lazy().value() == "error"


# Generated at 2022-06-12 05:05:15.964810
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3).to_either().to_lazy() == Lazy(lambda: 3)
    assert Lazy(lambda: Right(3)).to_either().to_lazy() == Lazy(lambda: 3)
    assert Lazy(lambda: Left(3)).to_either().to_lazy() == Lazy(lambda: 3)
    assert Lazy(lambda: Either(3)).to_either().to_lazy() == Lazy(lambda: 3)
    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:05:20.258842
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    right_lazy = Either.right.to_lazy()
    assert right_lazy == Lazy(lambda: Either.right)

    left_lazy = Either.left.to_lazy()
    assert left_lazy == Lazy(lambda: Either.left)


# Generated at 2022-06-12 05:05:23.474841
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy() == Lazy(None)



# Generated at 2022-06-12 05:05:25.304267
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Either(42)
    lazy = either.to_lazy();

    assert lazy() == 42


# Generated at 2022-06-12 05:06:15.395522
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Either(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:06:18.393234
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Left(1).to_lazy()
    assert result.value() == 1

    result = Right(1).to_lazy()
    assert result.value() == 1

# Generated at 2022-06-12 05:06:21.533840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:06:25.892497
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:29.882782
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Right, Left

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:06:33.075333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get() == 1
    assert Right(1).to_lazy().get() == 1

# Generated at 2022-06-12 05:06:39.975217
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import types

    assert isinstance(Left('test').to_lazy().value, types.LambdaType)
    assert isinstance(Right('test').to_lazy().value, types.LambdaType)
    assert Left('first').to_lazy() == Lazy(lambda: 'first')
    assert Right('second').to_lazy() == Lazy(lambda: 'second')


# Generated at 2022-06-12 05:06:44.121314
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> either = Right(1)
    >>> lazy = either.to_lazy()
    >>> lazy.value()
    1
    >>> either = Left(1)
    >>> lazy = either.to_lazy()
    >>> lazy.value()
    1
    """


# Generated at 2022-06-12 05:06:52.334595
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Success
    from pymonet.lazy import Lazy

    either_with_value = Right("hola")
    lazy = either_with_value.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == either_with_value.value

    either_with_empty = Left("hola")
    lazy = either_with_empty.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == None

# Generated at 2022-06-12 05:07:02.651250
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Left('Test').to_lazy() == Lazy(lambda: 'Test')
    assert Right(100).to_lazy() == Lazy(lambda: 100)
    assert Left(True).to_lazy() == Lazy(lambda: True)
    assert Right('Test').to_lazy() == Lazy(lambda: 'Test')
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(True).to_lazy() == Lazy(lambda: True)