

# Generated at 2022-06-12 04:59:00.090390
# Unit test for method case of class Either
def test_Either_case():
    assert Either(Right(1)).case(lambda e: e + 2, lambda e: e + 1) == 2
    assert Either(Left(2)).case(lambda e: e + 2, lambda e: e + 1) == 4



# Generated at 2022-06-12 04:59:03.553551
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left('fuck') == Left('fuck')
    assert Left('fuck') != Right('fuck')
    assert Right('fuck') != Left('fuck')
    assert Right(1) != Right('fuck')
    assert Left(1) != Left('fuck')



# Generated at 2022-06-12 04:59:09.346700
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_maybe import Maybe

    left_m: Maybe[int] = Maybe.nothing()
    left_e: Either[int] = Left(1)

    assert left_m == left_e

    right_m: Maybe[int] = Maybe.just(1)
    right_e: Either[int] = Right(1)

    assert right_m != left_e


test_Either___eq__()


# Unit Test for method case of class Either

# Generated at 2022-06-12 04:59:10.745446
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test case for to_lazy of class Either.

    :returns: None
    :rtype: NoneType
    """
    assert Right(1).to_lazy().get() == 1

# Generated at 2022-06-12 04:59:17.453915
# Unit test for method __eq__ of class Either
def test_Either___eq__():  # pylint: disable=too-many-locals
    def make_either(value):
        return Right(value)

    value = 'test'
    either1 = make_either(value)
    either2 = make_either(value)
    either3 = make_either(value + '2')
    class Object:
        pass
    object_ = Object()
    assert either1 == either1
    assert either1 == either2
    assert either1 != either3
    assert either1 != object_



# Generated at 2022-06-12 04:59:23.221389
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left(1)
    left2 = Left(1)
    right1 = Right(2)
    right2 = Right(2)

    assert left1 == left2
    assert right1 == right2
    assert left1 != right1
    assert right1 != left1
    assert left1 != right2
    assert right1 != left2


# Generated at 2022-06-12 04:59:26.607465
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Left(1) == Right(1)



# Generated at 2022-06-12 04:59:28.983784
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().evaluate() == 5
    assert Left(5).to_lazy().evaluate() == 5



# Generated at 2022-06-12 04:59:31.390529
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 04:59:34.447379
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    assert(Either.to_lazy(Maybe.just(1)) == Lazy(lambda: 1))



# Generated at 2022-06-12 04:59:44.204068
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)

    assert not Either(1) == Either(2)
    assert not Right(1) == Right(2)
    assert not Left(1) == Left(2)

    assert not Either(1) == Left(2)
    assert not Either(1) == Right(2)
    assert not Left(1) == Either(2)
    assert not Right(1) == Either(2)


# Generated at 2022-06-12 04:59:48.119899
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None) == Left(None)
    assert Right(None) == Right(None)
    assert Left(None) != Right(None)
    assert Left(None) != None
    assert Right(None) != None

# Generated at 2022-06-12 04:59:51.775115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _to_lazy(result: Either[int]):
        return result.to_lazy().get()
    assert 1 == _to_lazy(Right(1))
    assert 2 == _to_lazy(Left(2))



# Generated at 2022-06-12 04:59:58.702339
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Either(Box(4)).to_lazy() == Lazy(lambda: 4)
    assert Either(Try(4)).to_lazy() == Lazy(lambda: 4)
    assert Either(Lazy(lambda: 4)).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 05:00:05.027030
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(2) != Left(2)
    assert not Left(2) == Right(2), 'Left is not equal to Right'
    assert Right(2) != Left(1), 'One is not equel to Two'
    assert not Right(1) != Right(1), 'One is equal to One'
    assert not Left(1) != Left(1), 'One is equal to One'


# Generated at 2022-06-12 05:00:09.170599
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # given:
    right_one = Right(1)
    right_two = Right(1)
    left_one = Left(1)
    left_two = Left(1)

    # when:
    result_right = right_one == right_two
    result_left = left_one == left_two

    # then:
    assert result_right is True
    assert result_left is True



# Generated at 2022-06-12 05:00:20.317164
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # arrange
    right_either = Either('right')
    left_either = Either('left')

    # act
    result_of_right_either_eq_with_right_either = right_either.__eq__(right_either)
    result_of_left_either_eq_with_left_either = left_either.__eq__(left_either)

    result_of_right_either_eq_with_left_either = right_either.__eq__(left_either)

    # assert
    assert result_of_right_either_eq_with_right_either
    assert result_of_left_either_eq_with_left_either

    assert not(result_of_right_either_eq_with_left_either)



# Generated at 2022-06-12 05:00:24.246993
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:00:31.909350
# Unit test for method case of class Either
def test_Either_case():
    assert Either(True).case(
        error=lambda x: x.upper(),
        success=lambda x: x
    ) is True
    assert Either(False).case(
        error=lambda x: x.upper(),
        success=lambda x: x
    ) is False
    assert Either(1).case(
        error=lambda x: x,
        success=lambda x: x + 1
    ) == 2
    assert Either(1).case(
        error=lambda x: x + 1,
        success=lambda x: x + 1
    ) == 2



# Generated at 2022-06-12 05:00:37.917780
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    >>> Left(10) == Left(10)
    True
    >>> Left(10) == Left(11)
    False
    >>> Left(10) == Right(10)
    False
    >>> Right(10) == Left(10)
    False
    >>> Right(10) == Right(10)
    True
    >>> Right(10) == Right(11)
    False
    """


# Generated at 2022-06-12 05:00:45.421309
# Unit test for method case of class Either
def test_Either_case():
    @typechecked
    def error(value: int) -> int:
        return value * 2

    @typechecked
    def success(value: int) -> int:
        return value + 1

    assert Left(1).case(error, success) == success(1)
    assert Right(2).case(error, success) == error(2)

# Generated at 2022-06-12 05:00:48.329657
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda v: v, lambda v: v + 1) == 2
    assert Either(1).case(lambda v: v + 1, lambda v: v) == 1


# Generated at 2022-06-12 05:00:50.945533
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    '''
    Test mapper of Either.
    '''
    assert Right(1).to_lazy().value() == 1
    assert Left('error').to_lazy().value() == 'error'


# Generated at 2022-06-12 05:00:53.497472
# Unit test for method case of class Either
def test_Either_case():
    left = Left(2)
    right = Right(4)
    assert left.case(lambda x: -x, lambda x: x) == -2
    assert left.case(lambda x: -x, lambda x: x) == 4


# Generated at 2022-06-12 05:01:03.457618
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def error_handler(value):
        return value * 10

    def success_handler(value):
        return value / 2

    left_either = Left(2)
    right_either = Right(2)

    assert left_either.case(error_handler, success_handler) == 20
    assert right_either.case(error_handler, success_handler) == 1
    assert isinstance(left_either.case(error_handler, success_handler), int)
    assert isinstance(right_either.case(error_handler, success_handler), int)

    assert left_either.case(Try, Box) == Try(2)
    assert right_either.case(Try, Box) == Box(2)

# Generated at 2022-06-12 05:01:09.609412
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    result_left = Left(1).case(lambda value: value + 10, lambda value: value - 10)
    assert result_left == 11
    result_right = Right(1).case(lambda value: value + 10, lambda value: value - 10)
    assert result_right == -9



# Generated at 2022-06-12 05:01:13.201989
# Unit test for method case of class Either
def test_Either_case():
    """Unit test for method case of class Either"""
    assert Left(1).case(int, str) == 1
    assert Right(1).case(int, str) == '1'



# Generated at 2022-06-12 05:01:19.494294
# Unit test for method case of class Either
def test_Either_case():
    el = Left('aaa')
    ri = Right('bbb')
    assert el.case(lambda x: 'error:' + x, lambda x: 'success:' + x) == 'error:aaa'
    assert ri.case(lambda x: 'error:' + x, lambda x: 'success:' + x) == 'success:bbb'


# Generated at 2022-06-12 05:01:22.149268
# Unit test for method case of class Either
def test_Either_case():
    assert Right(2).case(lambda _: 2, lambda x: x) == 2
    assert Left(2).case(lambda x: x, lambda _: 2) == 2



# Generated at 2022-06-12 05:01:27.086427
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either("abcd").to_lazy() == Lazy(lambda: "abcd")
    assert Either({True: False, False: True}).to_lazy() == Lazy(lambda: {True: False, False: True})


# Generated at 2022-06-12 05:01:36.403511
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    to_lazy of class Either transform our Either to Lazy
    """
    assert str(Left(0).to_lazy()) == '[Lazy:frozen]'
    assert str(Right(0).to_lazy()) == '[Lazy:frozen]'

test_Either_to_lazy()


# Generated at 2022-06-12 05:01:45.092278
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)

    assert Either.to_lazy(Left(Box(1))) == Lazy(lambda: Box(1))
    assert Either.to_lazy(Right(Box(1))) == Lazy(lambda: Box(1))

    assert Either.to_lazy(Left(Try(1))) == Lazy(lambda: Try(1))
    assert Either.to_lazy(Right(Try(1))) == Lazy(lambda: Try(1))


# Generated at 2022-06-12 05:01:49.774394
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:51.210586
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().run() == 1

# Generated at 2022-06-12 05:01:55.521830
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test method to_lazy of class Either"""

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:02:04.048323
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    val = 'value'
    assert Either[int](2).to_lazy() == Lazy(lambda: 2)
    assert Either[str](val).to_lazy() == Lazy(lambda: val)
    assert Either[Box[int]](Box(2)).to_lazy() == Lazy(lambda: Box(2))
    assert Either[str](Validation(val)).to_lazy() == Lazy(lambda: val)
    assert Either[str](Try(val)).to_lazy() == Lazy(lambda: val)
    assert Either[str](Try(val, is_success=False)).to_lazy

# Generated at 2022-06-12 05:02:09.676495
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right, Either

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy().get() == 1

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy().get() == 1

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:02:17.124570
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_method_to_lazy_with_left_should_return_lazy_of_value():
        result = Left(2).to_lazy()

        assert result.value() == 2

    def test_method_to_lazy_with_right_should_return_lazy_of_value():
        result = Right(2).to_lazy()

        assert result.value() == 2

    test_method_to_lazy_with_left_should_return_lazy_of_value()
    test_method_to_lazy_with_right_should_return_lazy_of_value()



# Generated at 2022-06-12 05:02:23.762699
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    # Check if lazy has been evaluated
    assert isinstance(Left(1).to_lazy().value, type(None))
    assert isinstance(Right(1).to_lazy().value, type(None))


# Generated at 2022-06-12 05:02:28.292432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """

    value = 1

    assert Right(value).to_lazy().value() == value
    assert Right(value).to_lazy().map(lambda x: x + 1).value() == value + 1

    assert Left(value).to_lazy().value() == value
    assert Left(value).to_lazy().map(lambda x: x + 1).value() == value



# Generated at 2022-06-12 05:02:41.058625
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    def test_method(unit_test):
        unit_test.assert_equal(Right(10).to_lazy().force(), 10)
        unit_test.assert_equal(Left(10).to_lazy().force(), 10)

    return test_method


# Generated at 2022-06-12 05:02:41.820318
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass



# Generated at 2022-06-12 05:02:48.742113
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    m = Left(10)
    assert m.to_lazy() == Lazy(lambda: m.value)

    m = Right(10)
    assert m.to_lazy() == Lazy(lambda: m.value)

    m = Left(Box(10))
    assert m.to_lazy() == Lazy(lambda: m.value)

    m = Right(Box(10))
    assert m.to_lazy() == Lazy(lambda: m.value)



# Generated at 2022-06-12 05:02:51.442442
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:02:57.137290
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left((5, 6)).to_lazy() == Lazy(lambda: (5, 6))


# Generated at 2022-06-12 05:03:04.874283
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Left(1).to_lazy()
    assert lazy.must_be(Lazy)
    assert lazy.value().must_be(Left)

    lazy = Right(2).to_lazy()
    assert lazy.must_be(Lazy)
    assert lazy.value().must_be(Right)



# Generated at 2022-06-12 05:03:09.744457
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    # When
    right_either = Right(5)
    left_either = Left(5)

    # Then
    assert right_either.to_lazy() == 5
    assert left_either.to_lazy() == 5


# Generated at 2022-06-12 05:03:20.459765
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_lazy() == Lazy(lambda: Maybe.just(1))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: Maybe.nothing())

    assert Try(1, True).to_lazy() == Lazy(lambda: Try(1, True))
    assert Try(1, False).to_lazy() == Lazy(lambda: Try(1, False))

    assert Box(1).to_lazy() == Lazy(lambda: Box(1))


# Generated at 2022-06-12 05:03:25.339034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(2).to_lazy() == Lazy(lambda: 2)
    assert Either(4).to_lazy() == Lazy(lambda: 4)
    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(4).to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 05:03:29.141899
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('something wrong').to_lazy() == Lazy(lambda: 'something wrong')


# Generated at 2022-06-12 05:03:42.413999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    def function():
        return 'function'

    assert Right('test').to_lazy() == Lazy(lambda: 'test')
    assert Left('test').to_lazy() == Lazy(lambda: 'test')
    assert Right(function).to_lazy() == Lazy(lambda: function())
    assert Left('test').to_lazy() == Lazy(lambda: 'test')



# Generated at 2022-06-12 05:03:46.480955
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    _Left = Left(1)
    _Right = Right(2)

    # then
    assert _Left.to_lazy() == Lazy(lambda: 1)
    assert _Right.to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:03:51.249776
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)
    assert Right(10).to_lazy().value() == 10
    assert Left(10).to_lazy().value() == 10



# Generated at 2022-06-12 05:03:54.959813
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def a():
        return 1

    assert Lazy(a) == Right(1).to_lazy()


#  Unit test for method to_box of class Either

# Generated at 2022-06-12 05:03:57.548674
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().evaluate() == 5
    assert Left(5).to_lazy().evaluate() == 5



# Generated at 2022-06-12 05:04:03.865474
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Either("10").to_lazy() == Lazy(lambda: "10")
    assert Either([1, 10]).to_lazy() == Lazy(lambda: [1, 10])
    assert Either({1, 10}).to_lazy() == Lazy(lambda: {1, 10})


# Generated at 2022-06-12 05:04:08.385544
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def f(x):
        return x**2

    actual = Right(5).to_lazy()
    expected = Lazy(lambda: 5)
    assert actual == expected

    actual = Left("something").to_lazy()
    expected = Lazy(lambda: "something")
    assert actual == expected

# Generated at 2022-06-12 05:04:14.680419
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    right_value = Right(5)
    left_value = Left(5)
    assert Lazy(lambda: 5) == right_value.to_lazy()
    assert Lazy(lambda: 5) == left_value.to_lazy()

# Unit tests for method bind of class Right

# Generated at 2022-06-12 05:04:20.488466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert isinstance(Try(1).to_lazy(), Lazy)
    assert Try(1).to_lazy().get() == 1
    assert Try(1.1).to_lazy().get() == 1.1
    assert Try('ala').to_lazy().get() == 'ala'
    assert isinstance(Try(Box(1)).to_lazy().get(), Box)
    assert Try(Box(1)).to_lazy().get().get() == 1
    assert isinstance(Try(Try(1)).to_lazy().get(), Try)
    assert Try(Try(1)).to_lazy().get().get() == 1


# Generated at 2022-06-12 05:04:27.891070
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 'foo')

    left = Left('lorem')
    assert left.to_lazy() == Lazy(lambda: 'lorem')

    right = Right('ipsum')
    assert right.to_lazy() == Lazy(lambda: 'ipsum')

    assert left.to_lazy() != right.to_lazy()
    assert right.to_lazy() != lazy_value
    assert right.to_lazy() != Lazy(lambda: 'bar')


# Generated at 2022-06-12 05:04:55.199863
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
  from typing import cast
  from pymonet.lazy import Lazy
  from pymonet.box import Box
  from pymonet.monad_try import Try
  from pymonet.validation import Validation
  from pymonet.maybe import Maybe
  from pymonet.monad import Monad
  from pymonet.applicative import Applicative

  assert isinstance(Left(5).to_lazy(), Lazy)
  assert isinstance(Right(5).to_lazy(), Lazy)
  assert isinstance(Left(5).to_lazy(), Monad)
  assert isinstance(Right(5).to_lazy(), Monad)
  assert isinstance(Left(5).to_lazy(), Applicative)
  assert isinstance(Right(5).to_lazy(), Applicative)
  assert cast

# Generated at 2022-06-12 05:04:58.850444
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # GIVEN
    either = Either.unit(15)

    # WHEN
    lazy = either.to_lazy()

    # THEN
    assert lazy.value() == either.value()


# Generated at 2022-06-12 05:05:01.917104
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Right(10).to_lazy().value() == 10)
    assert(Left("Error").to_lazy().value() == "Error")


# Generated at 2022-06-12 05:05:06.038814
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:08.655344
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:13.787011
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_fun():
        return 123

    assert Right(lazy_fun).to_lazy() == Lazy(lazy_fun)
    assert Left(lazy_fun).to_lazy() == Lazy(lazy_fun)



# Generated at 2022-06-12 05:05:18.619920
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    :returns: Test results
    :rtype: TestResults
    """
    from pymonet.test import TestResults
    from pymonet.lazy import Lazy

    res = TestResults()
    left_either = Left(10)
    res.add_test(None, left_either.to_lazy(), Lazy(lambda: 10))
    right_either = Right(20)
    res.add_test(None, right_either.to_lazy(), Lazy(lambda: 20))

    return res

# Generated at 2022-06-12 05:05:28.652028
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for to_lazy method of class Either.

    :returns: True if test passed, False otherwise
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert(Right(1).to_lazy() == Lazy(lambda: 1))
    assert(Left(1).to_lazy() == Lazy(lambda: 1))
    assert(Right(Box(1)).ap(Lazy(lambda x: x)).to_lazy() == Lazy(lambda: 1))
    assert(Left(Box(1)).ap(Lazy(lambda x: x)).to_lazy() == Lazy(lambda: 1))



# Generated at 2022-06-12 05:05:38.404639
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functions import identity
    from pymonet.lazy import Lazy

    def assert_right_lazy(either: Either[int]):
        assert either.to_lazy() == Lazy(identity, either.value)

    def assert_left_lazy(either: Either[int]):
        assert either.to_lazy() == Lazy(identity, either.value)

    assert_right_lazy(Right(5))
    assert_left_lazy(Left(None))
    assert_right_lazy(Right(None))
    assert_left_lazy(Left(5))


# Generated at 2022-06-12 05:05:41.552445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(a, b):
        return a + b

    assert (Left(1).to_lazy().map(add).value(2)) == 1
    assert (Right(1).to_lazy().map(add).value(2)) == 3


# Generated at 2022-06-12 05:06:25.993694
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(5).to_lazy(), Lazy)
    assert isinstance(Left(5).to_lazy(), Lazy)
    assert Right(5).to_lazy().evaluate() == 5
    assert Left(5).to_lazy().evaluate() == 5



# Generated at 2022-06-12 05:06:30.917859
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    e = Right(1)
    lazy = e.to_lazy()
    assert isinstance(lazy, Either)
    assert isinstance(lazy, Functor)
    assert isinstance(lazy, Lazy)
    assert lazy.resolve() == 1



# Generated at 2022-06-12 05:06:34.000237
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import lazy
    result = Right(5).to_lazy()
    assert result == Lazy(lambda: 5)
    assert result.unwrap() == 5


# Generated at 2022-06-12 05:06:37.415074
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 05:06:43.849151
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(10).to_lazy().value() == 10
    assert Either("Hello").to_lazy().value() == "Hello"
    assert Either(-2).to_lazy().value() == -2
    assert Either(None).to_lazy().value() is None
    assert Either(True).to_lazy().value() is True
    assert Either(False).to_lazy().value() is False


# Generated at 2022-06-12 05:06:47.453652
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Left(10).to_lazy()
    assert Lazy(lambda: 10) == Right(10).to_lazy()



# Generated at 2022-06-12 05:06:57.791357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1
    assert isinstance(Right(1).to_lazy().to_try(), Try)
    assert isinstance(Left(1).to_lazy().to_try(), Try)
    assert Right(1).to_lazy().to_try().value() == 1
    assert Left(1).to_lazy().to_try().value() == 1



# Generated at 2022-06-12 05:07:00.194086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().value() == 5
    assert Left(5).to_lazy().value() == 5


# Generated at 2022-06-12 05:07:02.650110
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(3).to_lazy() == Right(3).value
    assert Left('error').to_lazy() == Left('error').value


# Generated at 2022-06-12 05:07:05.336857
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe

    assert Maybe.just(2).to_either().to_lazy().value()() == Maybe.just(2).value

    assert Maybe.nothing().to_either().to_lazy().value()() is None



# Generated at 2022-06-12 05:08:45.242709
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    successful = Try.of(lambda: 10).to_either()
    assert successful.to_lazy() == Lazy(lambda: successful.value)

    failure = Try.of(lambda: 1 / 0).to_either()
    assert failure.to_lazy() == Lazy(lambda: failure.value)



# Generated at 2022-06-12 05:08:49.573073
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(2).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.__repr__() == 'Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x000001AE7D11DDC8>)'
    assert lazy.get() == 2


# Generated at 2022-06-12 05:08:51.757106
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test Either to_lazy method."""
    assert Right(8).to_lazy().value() == 8
    assert Left(8).to_lazy().value() == 8


# Generated at 2022-06-12 05:08:54.667582
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('test').to_lazy() == Lazy(lambda: 'test')