

# Generated at 2022-06-12 04:59:00.706724
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit tests for method to_lazy for class Either.
    """

    from pymonet.lazy import Lazy

    result = Right(10).to_lazy()
    expected_result = Lazy(lambda: 10)
    assert result == expected_result

    result = Left(10).to_lazy()
    expected_result = Lazy(lambda: 10)
    assert result == expected_result


# Generated at 2022-06-12 04:59:04.086132
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def get_value(e: Either) -> Lazy:
        return e.to_lazy()

    assert get_value(Left("value")).force() == "value"
    assert get_value(Right(10)).force() == 10



# Generated at 2022-06-12 04:59:14.914639
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    If I compare 2 right Eithers with different value, it should return False
    But if I compare 2 right Eithers with the same value, it should return True
    It should be true for left Eithers too.
    """
    # Given
    either_left_1 = Left("test")
    either_left_2 = Left("test")
    either_right_1 = Right("test")
    either_right_2 = Right("test")
    either_right_3 = Right("test2")

    # Then
    assert either_left_1 == either_left_2
    assert either_right_1 == either_right_2
    assert either_right_1 != either_right_3
    assert either_left_1 != either_right_2
    assert either_left_1 != either_right_1


# Generated at 2022-06-12 04:59:19.097413
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left('test value 1')
    left_2 = Left('test value 2')
    left_3 = Left('test value 1')
    right_1 = Right('test value 2')
    assert left_1 != left_2
    assert left_1 == left_3
    assert left_1 != right_1



# Generated at 2022-06-12 04:59:23.499047
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """Unit test for method __eq__ of class Either"""
    left = Left(12)
    right = Right(12)
    assert left != right
    assert left == left
    assert right == right
    assert Right(12) != Left(12)


# Generated at 2022-06-12 04:59:29.514815
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.validation import Validation

    assert Left(2).case(lambda x: x + 1, lambda x: x + 3) == 3
    assert Right(2).case(lambda x: x + 1, lambda x: x + 3) == 5
    assert Right(2).case(error=lambda _: 1, success=lambda _: 2) == 2
    assert Left(2).case(error=lambda _: 1, success=lambda _: 2) == 1



# Generated at 2022-06-12 04:59:35.867525
# Unit test for method case of class Either
def test_Either_case():
    from pymonet.equal import Equal
    from pymonet.type_signature import type_signature

    @type_signature(Either[int], int, int)
    def case_test(either: Either[int], right_value: int, left_value: int):
        return either.case(
            error=lambda x: left_value,
            success=lambda x: right_value
        )

    # Equal[Left[int].case(Callable[[int], int], Callable[[int], int]) -> int]
    assert Equal(Left(2).case(lambda x: 3, lambda x: 2), 3)
    # Equal[Right[int].case(Callable[[int], int], Callable[[int], int]) -> int]
    assert Equal(Right(2).case(lambda x: 3, lambda x: 2), 2)

# Generated at 2022-06-12 04:59:38.747700
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('meh').to_lazy() == Lazy(lambda: 'meh')


# Generated at 2022-06-12 04:59:41.794158
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(10) == Right(10)
    assert Left(10) == Left(10)
    assert Left(10) != Right(10)


# Generated at 2022-06-12 04:59:47.295157
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    assert Either(1) == Either(1)
    assert Either(1) != Left(1)
    assert Either(1) != Right(1)
    assert Either(1) != Try(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != Try(1)
    assert Right(1) == Right(1)
    assert Right(1) != Try(1)


# Generated at 2022-06-12 04:59:58.893155
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)

test_Either_to_lazy()


# Generated at 2022-06-12 05:00:02.809362
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)
    assert Right(2) != Right(1)
    assert Left(1) == Left(1)
    assert Left(2) != Left(1)


# Generated at 2022-06-12 05:00:05.981459
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2)
    assert Right(1) == Right(1)
    assert Left('error') != Left(2)
    assert Left(2) != Right(2)
    assert Left(2) != Either(2)


# Generated at 2022-06-12 05:00:11.295696
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Lazy(lambda: 3) == Either(Left(3)).to_lazy()
    assert Lazy(lambda: 4) == Either(Right(4)).to_lazy()
    assert Lazy(lambda: Box(3)) == Either(Left(Box(3))).to_lazy()
    assert Lazy(lambda: Box(3)) == Either(Right(Box(3))).to_lazy()


# Generated at 2022-06-12 05:00:14.352399
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert Left(2) != Right(2)

# Generated at 2022-06-12 05:00:15.479699
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) != 1



# Generated at 2022-06-12 05:00:16.101134
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    pass

# Generated at 2022-06-12 05:00:23.333207
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    def test_Either_to_lazy_Right():
        """Unit test for method to_lazy of class Either with Right"""

        assert Right(5).to_lazy() == Lazy(lambda: 5)

    def test_Either_to_lazy_Left():
        """Unit test for method to_lazy of class Either with Left"""

        assert Left(5).to_lazy() == Lazy(lambda: 5)

    def test_Either_to_lazy():
        """Unit test for method to_lazy of class Either"""

        test_Either_to_lazy_Right()
        test_Either_to_lazy_Left()


# Generated at 2022-06-12 05:00:31.005575
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)

    assert Left(1) != Right(1)
    assert Left(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(3) != Right(2)

    assert Right(2) != 3
    assert Right(2) != ''
    assert Right(2) != [2]
    assert Right(2) != {2}
    assert Right(2) != {'a': 2}



# Generated at 2022-06-12 05:00:36.574570
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # given
    val = 1 + 2
    right = Right(val)
    #when
    result = right.to_lazy()
    # then
    assert result.value() == val
    assert result.__class__ == Lazy


# Generated at 2022-06-12 05:00:43.575003
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func():
        return "some string"

    right = Right(func).to_lazy()

    assert right.is_right()



# Generated at 2022-06-12 05:00:45.717921
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test to verify semantics of method __eq__
    """
    assert Left('error') == Left('error')
    assert Right(1) == Right(1)
    assert Left('error') != Right('error')


# Generated at 2022-06-12 05:00:50.987513
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    def success_handler(value):
        return value

    def error_handler(value):
        return value

    monad = Left(123)
    assert monad.to_lazy() == Lazy(lambda: 123)
    monad = Right(123)
    assert monad.to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-12 05:00:52.997993
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)



# Generated at 2022-06-12 05:00:56.772187
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    @Lazy
    def func():
        return 'value'

    assert Right('value').to_lazy() == func
    assert Left('value').to_lazy() == func


# Generated at 2022-06-12 05:00:59.754358
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('foo') != Left('bar')
    assert Left('foo') != Right('foo')
    assert Right('bar') != Left('bar')
    assert Right('foo') == Right('foo')



# Generated at 2022-06-12 05:01:04.334851
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    a = Left(2)
    b = Left(2)
    c = Right(2)

    assert a == b, 'Left(2) should be equal to Left(2)'
    assert a != c, 'Left(2) shouldn\'t be equal to Right(2)'
    assert c != a, 'Right(2) shouldn\'t be equal to Left(2)'


# Generated at 2022-06-12 05:01:05.928084
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either(5).to_lazy(), Lazy)



# Generated at 2022-06-12 05:01:16.664198
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    import pytest

    equal_bool_args = [
        True,
        False
    ]
    equal_bool_args_results = [
        True,
        True,
        False,
        False
    ]

    equal_str_args = [
        'test',
        'test2'
    ]
    equal_str_args_results = [
        True,
        True,
        False,
        False
    ]

    for idx, args in enumerate(zip(equal_bool_args, equal_bool_args)):
        left = Either.__new__(Left, *args)
        right = Either.__new__(Right, *args)

        assert left == right == equal_bool_args_results[idx]
        assert not left == right == equal_bool_args_results[idx + 2]

# Generated at 2022-06-12 05:01:23.461106
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # test when Either is Left
    result = Left('error message').to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 'error message'

    # test when Either is Right
    result = Right('value').to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 'value'


# Unit tests for method is_right of class Either

# Generated at 2022-06-12 05:01:38.780926
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    #
    # Given
    #
    initial_value = 1
    l1 = Left(initial_value)
    l2 = Left(initial_value)
    r1 = Right(initial_value)
    r2 = Right(initial_value)

    #
    # When
    #

    #
    # Then
    #
    assert l1 != r1
    assert l1 != r2
    assert l1 != initial_value
    assert l1 == l1
    assert l1 == l2
    assert r1 == r1
    assert r1 == r2


# Generated at 2022-06-12 05:01:43.725160
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Right(5) == Right(5)
    assert Left(5) != Right(5)
    assert Left(5) == Left(5)
    assert Right(5) != Left(5)
    assert Left(5) != Box(5)
    assert Left(5) != Try(5)


# Generated at 2022-06-12 05:01:46.553643
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy() == Lazy(lambda: None)
    assert Either.to_lazy(Left(None)).value() == None
    assert Either.to_lazy(Right(42)).value() == 42

# Generated at 2022-06-12 05:01:49.821096
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left('a') != Left(1)



# Generated at 2022-06-12 05:01:52.768710
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)
    assert Left(10) != Right(10)



# Generated at 2022-06-12 05:01:54.529335
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(10) == Left(10)
    assert not Left(10) == Right(10)



# Generated at 2022-06-12 05:01:58.111913
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('error') == Left('error')
    assert Right('error') == Right('error')
    assert Left('error') != Right('error')
    assert Right('error') != Left('error')
    assert Right('error') != 1



# Generated at 2022-06-12 05:02:01.996090
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy

    assert pymonet.lazy.Lazy(lambda: 2) == Either.Right(2).to_lazy()
    assert pymonet.lazy.Lazy(lambda: None) == Either.Left(None).to_lazy()


# Generated at 2022-06-12 05:02:09.129349
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    result = Left(3) == Left(3)
    assert result is True, "Expected true to be true, but got {}".format(result)

    result = Right(3) == Right(3)
    assert result is True, "Expected true to be true, but got {}".format(result)

    result = Left(3) == Maybe.just(3)
    assert result is False, "Expected false to be false, but got {}".format(result)

    result = Left(3) == Either
    assert result is False, "Expected false to be false, but got {}".format(result)

    result = Left(3) == None
    assert result is False, "Expected false to be false, but got {}".format(result)

    result = Right(3) == Maybe.just(3)

# Generated at 2022-06-12 05:02:11.842295
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    test_object_1 = Either(1)
    test_object_2 = Either(2)
    assert test_object_1 != test_object_2



# Generated at 2022-06-12 05:02:27.419052
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    passes = Either.unit(1)
    assert passes.to_lazy().get() == 1



# Generated at 2022-06-12 05:02:31.345953
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Setup
    expected = 7

    # Exercise
    result = Right(7).to_lazy()

    # Verify
    assert expected == result.value()
    print('test_Either_to_lazy: OK')


# Generated at 2022-06-12 05:02:34.563258
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('a') == Left('a')
    assert Left('a') != Left('b')
    assert Left('a') != Right('a')
    assert Right('a') == Right('a')
    assert Right('a') != Right('b')
    assert Right('a') != Left('a')


# Generated at 2022-06-12 05:02:36.355717
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    pass

# Generated at 2022-06-12 05:02:39.298565
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ Test to_lazy method of class Either"""

    assert isinstance(Either(3).to_lazy(), Lazy)
    assert Either(3).to_lazy().get_value() == 3


# Generated at 2022-06-12 05:02:43.455716
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))
    assert not (Left(1) == Right(1))



# Generated at 2022-06-12 05:02:47.407626
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left("error").__eq__(Left("error")) is True
    assert Right("success").__eq__(Right("success")) is True
    assert Left("error").__eq__(Right("success")) is False
    assert Right("success").__eq__(Left("error")) is False


# Generated at 2022-06-12 05:02:58.426059
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import operator
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert (Right(Box(1).lazy())).to_lazy() == Lazy(lambda: Box(1).lazy())
    assert (Left(2)).to_lazy() == Lazy(lambda: 2)
    assert (Right(Box(3).lazy())).to_lazy().lazy_value() == Box(3).lazy()
    assert (Right(Box(3).lazy())).to_lazy().lazy_value().map(operator.add(1)) == Box(4)
    assert (Right(Box(7).lazy())).to_lazy().lazy_value().map(operator.add(1)) == Box(8)
   

# Generated at 2022-06-12 05:03:04.161484
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().run() == 1
    assert Either(81).to_lazy().run() == 81
    assert Either('abc').to_lazy().run() == 'abc'
    assert Either(True).to_lazy().run() is True



# Generated at 2022-06-12 05:03:12.041806
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1).__eq__(Left(1))
    assert not Left(1).__eq__(Right(1))
    assert not Left(1).__eq__(Right(2))
    assert not Left(1).__eq__(Left(2))
    assert not Left(1).__eq__(Right(1))
    assert Right(1).__eq__(Right(1))
    assert not Right(1).__eq__(Left(1))
    assert not Right(1).__eq__(Left(2))
    assert not Right(1).__eq__(Right(2))



# Generated at 2022-06-12 05:03:36.045414
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.maybe import Just
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert isinstance(Left(10).to_lazy(), Lazy)
    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(Box(10)).to_lazy(), Lazy)
    assert isinstance(Left(Just(10)).to_lazy(), Lazy)
    assert isinstance(Left(Try(10)).to_lazy(), Lazy)
    assert isinstance(Left(Lazy(lambda: 10)).to_lazy(), Lazy)



# Generated at 2022-06-12 05:03:38.840062
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(5).to_lazy(), Lazy)
    assert isinstance(Left('test').to_lazy(), Lazy)


# Generated at 2022-06-12 05:03:41.107794
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f() -> int:
        return 4

    assert Right(f).to_lazy() == Lazy(f)
    assert Left(f).to_lazy() == Lazy(f)



# Generated at 2022-06-12 05:03:43.406573
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(4345).to_lazy() == Lazy(lambda: 4345)
    assert Either("test").to_lazy() == Lazy(lambda: "test")


# Generated at 2022-06-12 05:03:47.416907
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    assert pytest.approx(Left('test').to_lazy().get()) == 'test'

    assert pytest.approx(Right('test').to_lazy().get()) == 'test'


# Generated at 2022-06-12 05:03:55.790846
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import unittest
    from pymonet.lazy import Lazy

    @unittest.skip('')
    class EitherTestCase(unittest.TestCase):
        """Test case for Eihter"""
        def test_to_lazy(self):
            """Test Either.to_lazy method"""
            self.assertEqual(Left(1).to_lazy(), Lazy(lambda: 1))
            self.assertEqual(Right(1).to_lazy(), Lazy(lambda: 1))

    unittest.main()

# Generated at 2022-06-12 05:03:58.684098
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'lazy either') == Either('either').to_lazy()


# Generated at 2022-06-12 05:04:06.156776
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    # GIVEN
    left = Left(ValueError('error'))
    right = Right(5)

    # WHEN
    left_lazy = left.to_lazy()
    right_lazy = right.to_lazy()

    # THEN
    assert left_lazy.value() == left.value
    assert right_lazy.value() == right.value



# Generated at 2022-06-12 05:04:10.736248
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Testing method to_lazy of class Either.
    """

    assert(Left(1).to_lazy().force() is 1)
    assert(Right(1).to_lazy().force() is 1)


# Generated at 2022-06-12 05:04:15.598602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Right, Left

    def f():
        return 42

    assert Right(42).to_lazy() == Lazy(f)
    assert Left(42).to_lazy() == Lazy(f)


# Generated at 2022-06-12 05:04:59.124850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor, FunctorLaws

    test_value = 'test'
    lazy = Either.to_lazy(Right(test_value))
    functor = Functor[Lazy]
    functor_laws = FunctorLaws(functor)
    functor_laws.test_map_identity(Lazy(test_value))
    functor_laws.test_map_composition(Lazy(test_value), lambda x: x.upper(), lambda x: x.lower())
    assert lazy.bind(lambda val: (val + 's')).value() == test_value + 's'



# Generated at 2022-06-12 05:05:05.968798
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Given
    left = Left(1)
    right = Right(2)

    # Then
    assert left.to_lazy() == Lazy(lambda: 1)
    assert left.map(lambda x: x + 1).to_lazy() == Lazy(lambda: 1)
    assert right.to_lazy() == Lazy(lambda: 2)
    assert right.map(lambda x: x + 1).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:05:09.001697
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either."""

    assert Right(5).to_lazy().run() == 5
    assert Left(5).to_lazy().run() == 5


# Generated at 2022-06-12 05:05:14.050264
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.

    :return: None
    """
    value = 42
    # Creates lazy monad of value 42
    lazy = Right(value).to_lazy().get
    # Validates returned value
    assert value == lazy()



# Generated at 2022-06-12 05:05:16.976826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    lazy_just = Either(Maybe.just(100)).to_lazy()
    assert lazy_just == Lazy(lambda: Maybe.just(100))


# Generated at 2022-06-12 05:05:20.605299
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import compute

    assert (Either('3').to_lazy() == Lazy(lambda: '3'))\
           .case(lambda e: e == AssertionError, lambda s: s)
    assert (Left(None).to_lazy() == Lazy(lambda: None))\
           .case(lambda e: e == AssertionError, lambda s: s)
    assert compute(Right(5).to_lazy().map(lambda a: a + 5)) == 10



# Generated at 2022-06-12 05:05:29.001537
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert isinstance(Left('error').to_lazy(), Lazy)
    assert isinstance(Right(23).to_lazy(), Lazy)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(23).to_lazy() == Lazy(lambda: 23)
    assert Left('error').to_lazy().get() == 'error'
    assert Right(23).to_lazy().get() == 23



# Generated at 2022-06-12 05:05:33.608801
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test either to_lazy method"""

    # Test Left
    assert Left(1).to_lazy() == Lazy(lambda: 1)

    # Test Right
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:05:37.620174
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(2)) == Lazy(lambda: 2)
    assert Either.to_lazy(Left("Error")) == Lazy(lambda: "Error")

# Generated at 2022-06-12 05:05:41.478338
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:07:01.735499
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    from pymonet.lazy import Lazy

    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)


# Generated at 2022-06-12 05:07:05.363953
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda : 2), 'Either.to_lazy should return Lazy with function returning its value'
    assert Left(2).to_lazy() == Lazy(lambda : 2), 'Either.to_lazy should return Lazy with function returning its value'



# Generated at 2022-06-12 05:07:08.036223
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(100).to_lazy().get_value() == 100
    assert Right(100).to_lazy().get_value() == 100


# Generated at 2022-06-12 05:07:12.654467
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def function_to_lazy(value: int) -> int:
        return value + 1

    result = Right(1).to_lazy().peek(function_to_lazy)
    assert result.get() == Right(2).value

    result = Left(1).to_lazy().peek(function_to_lazy)
    assert result.get() == Left(1).value


# Generated at 2022-06-12 05:07:13.433227
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Eith

# Generated at 2022-06-12 05:07:15.759887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def hello():
        return 'hello'

    assert Either(hello).to_lazy().eval() == 'hello'



# Generated at 2022-06-12 05:07:17.556994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:07:20.082808
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either('Test').to_lazy() == Lazy(lambda: 'Test')



# Generated at 2022-06-12 05:07:23.373617
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-12 05:07:25.647668
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Right(2).to_lazy().resolve() == 2
