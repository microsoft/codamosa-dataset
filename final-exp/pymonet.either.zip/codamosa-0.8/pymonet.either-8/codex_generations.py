

# Generated at 2022-06-12 04:58:58.825911
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe

    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Right(1) != Maybe.just(1)


# Generated at 2022-06-12 04:59:02.767544
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert isinstance(Left(1), Either)
    assert isinstance(Right(1), Either)
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)

# Generated at 2022-06-12 04:59:03.590631
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(None) == Either(None)

# Generated at 2022-06-12 04:59:05.441984
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(2)

    assert left == left
    assert right == right
    assert left != right


# Generated at 2022-06-12 04:59:08.793181
# Unit test for method case of class Either
def test_Either_case():
    left = Left(12)
    right = Right(12)

    assert left.case(lambda e: e * 2, lambda s: s + 120) == 24
    assert right.case(lambda e: e * 2, lambda s: s + 120) == 132

# Generated at 2022-06-12 04:59:10.152072
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left = Left(1)
    other_left = Left(1)
    right = Right(1)

    # Then
    assert left == other_left
    assert left != right


# Generated at 2022-06-12 04:59:11.555921
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(None) == Either(None)



# Generated at 2022-06-12 04:59:15.732205
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Right(11)
    lazy = either.to_lazy()
    assert lazy.force() == 11

    either = Left(11)
    lazy = either.to_lazy()
    assert lazy.force() == 11

# Generated at 2022-06-12 04:59:24.784595
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe, Just, Nothing
    from pymonet.box import Box

    assert Either(Maybe.nothing()) == Either(Maybe.nothing())
    assert Either(Maybe.just(12)) == Either(Maybe.just(12))

    assert Either(Maybe.nothing()) != Either(Maybe.just(12))
    assert Either(Maybe.just(12)) != Either(Maybe.nothing())

    assert Either(Maybe.nothing()) != Either(Box(12))
    assert Either(Box(12)) != Either(Maybe.nothing())



# Generated at 2022-06-12 04:59:27.833634
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)


# Generated at 2022-06-12 04:59:35.599496
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)
    assert not Right(1) == 1
    assert not Right(1) == None



# Generated at 2022-06-12 04:59:38.954701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:59:45.137987
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    test_case = Left(1)

    assert test_case == Left(1)
    assert test_case != Left(2)
    assert test_case != 1
    assert test_case != Right(1)
    assert test_case != Right(2)
    assert test_case != Right(3)
    assert test_case != [1, 2, 3]
    assert test_case != {1: 1, 2: 2}


# Generated at 2022-06-12 04:59:57.536695
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(10) == Right(10)
    assert Left(10) == Left(10)
    assert NotImplemented == (Right(10) == None)
    assert NotImplemented == (Right(-10) == '-10')
    assert NotImplemented == (Right([10]) == [10])
    assert NotImplemented == (Right(True) == True)
    assert NotImplemented == (Right(10) == 10)
    assert NotImplemented == (Right(10) == Left(10))
    assert NotImplemented == (Left(10) == None)
    assert NotImplemented == (Left(-10) == '-10')
    assert NotImplemented == (Left([10]) == [10])
    assert NotImplemented == (Left(True) == True)

# Generated at 2022-06-12 04:59:59.972642
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().force() == 5
    assert Left([5]).to_lazy().force() == [5]


# Generated at 2022-06-12 05:00:08.623907
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(2) == Either(2)
    assert Either('user_info') == Either('user_info')
    assert Either(['info']) == Either(['info'])
    assert Either(['info']) != Either(['  info'])
    assert Either(['info']) != Either(['user_info'])
    assert Either(['info']) != Either(('info',))
    assert Either(('info',)) == Either(('info',))
    assert Either(('info',)) != Either((' user_info',))
    assert Either(('info',)) != Either(('user_info',))
    assert Either(('info',)) != Either({'info'})
    assert Either({'info'}) == Either({'info'})
    assert Either({'info'}) != Either({'user_info'})

# Generated at 2022-06-12 05:00:15.954642
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)
    left_other = Left(2)
    right_other = Right(2)
    other_type = 'sdfsdf'

    assert left == left
    assert right == right
    assert left != right
    assert right != left
    assert left_other != left
    assert right_other != right
    assert left != left_other
    assert right != right_other
    assert left != other_type
    assert right != other_type


# Generated at 2022-06-12 05:00:22.104060
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def value_adder(value):
        return value + 1

    lazy = Lazy(lambda: 1).map(value_adder)
    assert lazy.has_value() is False
    assert lazy.get_value() == 2
    assert lazy.has_value() is True
    assert lazy.get_value() == 2
    assert Maybe(1).to_lazy().map(value_adder).get_value() == 2


# Generated at 2022-06-12 05:00:25.111427
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left("left") == Left("left")
    assert Right("left") == Right("left")
    assert not Left(123) == Right(123)
    assert not Right(None) == None



# Generated at 2022-06-12 05:00:31.117610
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)

    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:00:40.410424
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert not Right(1) == Either(1)
    assert not Either(1) == Left(1)
    assert not Left(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) == Either(1)
    assert Right(1) == Either(1)
    assert Either(1) == Left(1)
    assert Either(1) == Right(1)


# Generated at 2022-06-12 05:00:43.774277
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(5) != Right(5)
    assert Right(5) != Left(5)

# Generated at 2022-06-12 05:00:48.415348
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left(1)
    left_2 = Left(2)
    right_1 = Right(1)
    right_2 = Right(2)

    assert left_1 != left_2
    assert left_1 == Left(1)
    assert right_1 == Right(1)
    assert right_1 != right_2



# Generated at 2022-06-12 05:00:51.029656
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:00:54.005849
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:00:56.678524
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) == Right(2)
    assert Left(1) == Left(2)



# Generated at 2022-06-12 05:01:00.707058
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3) == Right(3)
    assert not Right(3) == Right(4)
    assert not Right(3) == Left(4)
    assert Left(3) == Left(3)
    assert not Left(3) == Left(4)
    assert not Left(3) == Right(4)

# Generated at 2022-06-12 05:01:03.965873
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # When
    either = Either(Either(1).value.value)

    # Then
    assert either == Either(Either(1).value.value)
    assert either != Either(Either(1).value.value)



# Generated at 2022-06-12 05:01:14.833592
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert not Right(2) == Left(2)
    assert not Left(2) == Right(2)
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert not Right(2) == Left(2)
    assert not Left(2) == Right(2)
    assert Left(2.0) == Left(2.0)
    assert Right(2.0) == Right(2.0)
    assert not Right(2.0) == Left(2.0)
    assert not Left(2.0) == Right(2.0)
    assert Left('2') == Left('2')
    assert Right('2') == Right('2')
    assert not Right('2') == Left

# Generated at 2022-06-12 05:01:18.593708
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:01:33.471527
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left(1)

    assert left1 == left1, "left1 == left1"
    assert left1 != Right(1), "left1 != Right(1)"
    assert left1 != None, "left1 != None"
    assert left1 != True, "left1 != True"
    assert left1 != False, "left1 != False"
    assert left1 != [1], "left1 != [1]"
    assert left1 != 1, "left1 != 1"
    assert left1 != 1.2, "left1 != 1.2"

    right1 = Right(1)

    assert right1 == right1, "right1 == right1"
    assert right1 != Left(1), "right1 != Left(1)"
    assert right1 != None, "right1 != None"

# Generated at 2022-06-12 05:01:37.008420
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    lazy_value = Lazy(lambda: 5)

    assert Right(5).to_lazy() == lazy_value
    assert Left(5).to_lazy() == lazy_value



# Generated at 2022-06-12 05:01:43.363840
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(None) == Left(None)
    assert Right(1) == Right(1)
    assert Right(None) == Right(None)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(None) != Left(None)
    assert Left(None) != Right(None)


# Generated at 2022-06-12 05:01:47.366262
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    either = Left(42)
    another = Left(42)
    not_equal_value = Left(43)
    not_equal_type = Right(42)

    assert either == another
    assert not either == not_equal_value
    assert not either == not_equal_type



# Generated at 2022-06-12 05:01:50.015757
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange
    either = Right(1)

    # Act
    result = either.to_lazy()

    # Assert
    assert result.value() == 1


# Generated at 2022-06-12 05:01:54.532991
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    either = Right.of(12)
    # When
    lazy = either.to_lazy()
    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 12


# Generated at 2022-06-12 05:01:57.403124
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left('error')
    right = Right(1)
    assert left == left
    assert right == right
    assert not right == left
    assert not left == right



# Generated at 2022-06-12 05:02:04.978709
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def test_either_equality_with_another_type_of_monad():
        assert Left(1) != object()

    def test_either_equality_with_same_type_of_monad_and_equals_value_and_right_constructors():
        assert Left(1) == Left(1)

    def test_either_equality_with_same_type_of_monad_and_equals_value_and_different_constructors():
        assert Left(1) == Right(1)

    def test_either_equality_with_same_type_of_monad_and_different_value_and_different_constructors():
        assert Left(1) == Right(2)


# Generated at 2022-06-12 05:02:08.787704
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(1) != Left(2)



# Generated at 2022-06-12 05:02:11.843696
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 05:02:28.645490
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Either(1).__eq__(Either(1))
    assert Left(1).__eq__(Left(1))
    assert Right(1).__eq__(Right(1))
    assert Right(1).__eq__(Left(1)) is False
    assert Left(1).__eq__(Right(1)) is False
    assert Left(1).__eq__(1) is False
    assert Either(1).__eq__(1) is False
    assert Left(1).__eq__(1) is False
    assert Right(1).__eq__(1) is False
    assert Left(1).__eq__(Right(1)) is False



# Generated at 2022-06-12 05:02:34.323598
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    value = 'test'
    either1 = Left(value)
    either2 = Left(value)
    either3 = Right(value)
    # When
    result1 = either1.__eq__(either2)
    result2 = either1.__eq__(either3)
    result3 = either1.__eq__('test')
    # Then
    assert result1
    assert not result2
    assert not result3


# Generated at 2022-06-12 05:02:38.669099
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(1)
    right = Right(2)

    assert left.to_lazy().get() == left.value
    assert right.to_lazy().get() == right.value


# Generated at 2022-06-12 05:02:41.715500
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    from pymonet.either import Left, Right

    assert Left(1) != Right(1)
    assert Left(2) != Right(2)
    assert Right(1) != Left(1)
    assert Right(2) != Left(2)



# Generated at 2022-06-12 05:02:47.716444
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left(0)
    left_2 = Left(0)
    left_3 = Left(1)

    assert left_1 == left_2
    assert not left_1 == left_3

    right_1 = Right(0)
    right_2 = Right(0)
    right_3 = Right(1)

    assert right_1 == right_2
    assert not right_1 == right_3



# Generated at 2022-06-12 05:02:50.502495
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)

# Generated at 2022-06-12 05:02:59.942535
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Try(7, is_success=False) == Try(7, is_success=False)
    assert Try(7, is_success=False) != Try(6, is_success=False)
    assert Try(7, is_success=False) != Try(6, is_success=True)

    assert Try(7, is_success=True) == Try(7, is_success=True)
    assert Try(7, is_success=True) != Try(6, is_success=True)
    assert Try(7, is_success=True) != Try(6, is_success=False)


# Generated at 2022-06-12 05:03:00.883720
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    pass

# Generated at 2022-06-12 05:03:06.747624
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) == Left('1')
    assert Left(1) != Right(1)
    assert Left(1) != 1
    assert Right(1) != Left(1)
    assert Right(1) != 1


# Generated at 2022-06-12 05:03:09.920807
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != 'foo'
    assert Left(1) != 1



# Generated at 2022-06-12 05:03:29.491868
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_writer import Writer
    from pymonet.writer import WriterValue
    from pymonet.list import List
    from pymonet.either import Left
    from pymonet.either import Right

    e_lazy_left = Left(Lazy(lambda: 8))
    e_lazy_right = Right(Lazy(lambda: 8))
    e_try_left = Left(Try(Lazy(lambda: 8)))
    e_try_right = Right(Try(Lazy(lambda: 8)))

    assert e_lazy_left.to_lazy().value().value == 8
    assert e_lazy_right.to_lazy().value().value == 8
    assert e_try_

# Generated at 2022-06-12 05:03:32.906887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either.to_lazy()

    :return: None
    :rtype: None
    """
    assert Right(1).to_lazy().get() is 1, 'to_lazy() failed.'


# Generated at 2022-06-12 05:03:35.500889
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("error").to_lazy() == Lazy(lambda: "error")
    assert Right("value").to_lazy() == Lazy(lambda: "value")



# Generated at 2022-06-12 05:03:38.479574
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    assert lazy == Right(1).to_lazy()



# Generated at 2022-06-12 05:03:40.525641
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(2)) == Lazy(2)
    assert Either.to_lazy(Left(2)) == Lazy(2)


# Generated at 2022-06-12 05:03:43.679116
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 1

    either_right = Right(value)
    assert either_right.value == value
    assert either_right.to_lazy().evaluate() == value

    either_left = Left(value)
    assert either_left.value == value
    assert either_left.to_lazy().evaluate() == value

# Generated at 2022-06-12 05:03:48.891141
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functions import compose
    from pymonet.lazy import Lazy

    lazy: Lazy[int] = Right(5).to_lazy()
    assert 7 == lazy.map(compose(lambda x: x + 2)(lambda x: x * 3)).get()



# Generated at 2022-06-12 05:03:52.763367
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Either(1).to_lazy()
    assert Either(1).to_lazy().value() == Either(1).to_lazy().value()


# Generated at 2022-06-12 05:03:56.996936
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = 'lazy value'
    result = Lazy(lambda: value)
    assert Right(value).to_lazy() == result
    assert Left(value).to_lazy() == result


# Generated at 2022-06-12 05:03:59.376222
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Either(Box(10)).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:04:22.966932
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    # Test for successfull Either
    def f():
        return 12345
    assert Right(12345).to_lazy()(f) == f()
    # Test for failed Either
    assert Left(12345).to_lazy()(f) == f()


# Generated at 2022-06-12 05:04:27.186540
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test to_lazy method of class Either"""
    from pymonet.lazy import Lazy

    either_right = Right(1)
    either_left = Left(1)

    assert either_right.to_lazy() == Lazy(1)
    assert either_left.to_lazy() == Lazy(1)



# Generated at 2022-06-12 05:04:28.675660
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().force() == 1  # To be continued...


# Generated at 2022-06-12 05:04:32.260263
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy_box = Box(2).to_lazy()
    lazy_either = Right(2).to_lazy()

    assert lazy_box == lazy_either



# Generated at 2022-06-12 05:04:42.845496
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    import unittest

    from pymonet.lazy import Lazy

    def test_case(either):
        return either.to_lazy()

    def test_case_with_full_bind(either):
        return either.to_lazy().bind(lambda x: Lazy(lambda: x + 1))

    class TestEither(unittest.TestCase):
        def test_Left(self):
            self.assertEqual(test_case(Left(1)), Lazy(lambda: 1))

        def test_Right(self):
            self.assertEqual(test_case(Right(1)), Lazy(lambda: 1))


# Generated at 2022-06-12 05:04:45.876390
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('Bad value').to_lazy().force() == 'Bad value'
    assert Right('Good value').to_lazy().force() == 'Good value'



# Generated at 2022-06-12 05:04:55.603254
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    It checks that method to_lazy transform Either to Lazy.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.writer import Writer

    assert Left(Try.failure(ValueError()).to_lazy()).to_lazy() == Lazy(lambda: Try.failure(ValueError()).to_lazy())
    assert Left(Lazy(lambda: "a")).to_lazy() == Lazy(lambda: Lazy(lambda: "a"))
    assert Left(Writer.from_value([], "a")).to_lazy() == Lazy(lambda: Writer.from_value([], "a"))

# Generated at 2022-06-12 05:04:59.965690
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def func(value):
        return value

    assert Lazy(func) == Right(1).to_lazy()
    assert Lazy(func) == Left(func).to_lazy()



# Generated at 2022-06-12 05:05:02.647883
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().force() == 1
    assert Left('Error').to_lazy().force() == 'Error'


# Generated at 2022-06-12 05:05:10.401513
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Right(1).to_lazy() == Try(1, is_success=True).to_lazy() == Validation(1, []).to_lazy()

    val = Validation('fail', ['error']).to_lazy()
    assert val.value() == 'fail' and val.is_fail()



# Generated at 2022-06-12 05:05:55.415973
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:00.458196
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # An Either become to Lazy
    lazy_from_left = Left(1).to_lazy()
    assert isinstance(lazy_from_left, Lazy)
    assert lazy_from_left.force() == 1

    lazy_from_right = Right(1).to_lazy()
    assert isinstance(lazy_from_right, Lazy)
    assert lazy_from_right.force() == 1



# Generated at 2022-06-12 05:06:02.563363
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def function():
        return 'result'

    either = Right(function)

    assert either.to_lazy().force()() == 'result'

# Generated at 2022-06-12 05:06:07.685538
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:06:10.710149
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import is_monad

    assert is_monad(Left(10).to_lazy())
    assert is_monad(Right(10).to_lazy())

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:06:15.329329
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, assert_lazy
    from pymonet.monad_try import Try

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert_lazy(Either(1).to_lazy(), Try(1, True).to_lazy())



# Generated at 2022-06-12 05:06:19.596495
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # method to_lazy should return Lazy monad with function returning value stored in Either
    assert Either.to_lazy(Right(1)).resolve() == 1
    assert Either.to_lazy(Left(1)).resolve() == 1


# Generated at 2022-06-12 05:06:24.775539
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(3).to_lazy() == Lazy(lambda: 3)
    assert Either(3).to_lazy().get() == 3
    assert Either(3).to_lazy().get() == Either(3).value


# Generated at 2022-06-12 05:06:28.456010
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'test') == Right('test').to_lazy()
    assert Lazy(lambda: 'test') == Left('test').to_lazy()


# Generated at 2022-06-12 05:06:31.832361
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ Unit test for method to_lazy of class Either """

    def func(either: Right[int]):
        return either.to_lazy().map(lambda value: value + 1)

    assert func(Right(4)) == func(Right(4)) == Right(5)

# Generated at 2022-06-12 05:08:04.667726
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test whether the to_lazy method of class Either returns a Lazy monad."""
    from pymonet.lazy import Lazy

    assert isinstance(Left('Error').to_lazy(), Lazy) and \
        isinstance(Right(1).to_lazy(), Lazy)


# Generated at 2022-06-12 05:08:08.362891
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy(), Either)
    assert isinstance(Right(1).to_lazy().value(), int)
    assert Right(1).to_lazy().value() == 1

    assert isinstance(Left(1).to_lazy(), Either)
    assert isinstance(Left(1).to_lazy().value(), int)
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:08:10.586153
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(Exception('Error')).to_lazy().get() == Exception('Error')
    assert Right(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:08:12.017817
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def power(number):
        return number * number

    result = Right(2).to_lazy().fmap(power).get()

    assert result == 4

# Generated at 2022-06-12 05:08:16.565422
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    def _test_Either(monad):
        assert isinstance(monad.to_lazy(), Lazy)
        assert monad.value == monad.to_lazy().value()

    monad = Either.unit(Box(1))  # type: Either
    _test_Either(monad)


# Generated at 2022-06-12 05:08:22.449263
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    def lazy_unit() -> int:
        return 10

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(Box(lazy_unit)).to_lazy() == Lazy(lambda: 10)
    assert Left(Box(lazy_unit)).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:08:26.771390
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Left("error")) == Lazy(lambda: "error")
    assert Either.to_lazy(Right("success")) == Lazy(lambda: "success")


# Generated at 2022-06-12 05:08:28.773122
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 05:08:30.590141
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_value = random.randint(0, 200)
    right = Right(test_value)
    lazy = right.to_lazy()

    assert lazy.eval() == test_value

# Generated at 2022-06-12 05:08:33.415293
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either = Left(1)
    assert either.to_lazy() == Lazy(lambda: 1)

    either = Right(1)
    assert either.to_lazy() == Lazy(lambda: 1)

