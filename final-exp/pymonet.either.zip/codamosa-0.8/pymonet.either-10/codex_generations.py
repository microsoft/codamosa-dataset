

# Generated at 2022-06-12 04:58:54.582342
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box

    assert Box(3) == Box(3)
    assert Box(3).__eq__(4) is False
    assert Box(3).__eq__(None) is False

# Generated at 2022-06-12 04:58:58.118203
# Unit test for method case of class Either
def test_Either_case():
    def success(x):
        return x
    def failure(x):
        return x

    assert Right(1).case(failure, success) == 1
    assert Left(0).case(failure, success) == 0

# Generated at 2022-06-12 04:59:00.746381
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(3).__eq__(4) is False
    assert Either(3).__eq__(Right(3)) is True
    assert Either(3).__eq__(Left(3)) is True



# Generated at 2022-06-12 04:59:04.370829
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert (Left("same") == Left("same")) and\
        (Right("same") == Right("same")) and\
        (Left("same") != Right("same")) and\
        (Left("left") == Left("same") == Left("another")) and\
        (Right("right") == Right("same") == Right("another"))



# Generated at 2022-06-12 04:59:09.496880
# Unit test for method case of class Either
def test_Either_case():
    def try_function_that_can_fail(number):
        if number == 2:
            return Right(number)
        return Left(number)

    assert try_function_that_can_fail(2).case(lambda error: 2, lambda success: 5) == 5
    assert try_function_that_can_fail(3).case(lambda error: 5, lambda success: 2) == 5


# Generated at 2022-06-12 04:59:11.683754
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Right('a').bind(Lazy)



# Generated at 2022-06-12 04:59:16.766788
# Unit test for method case of class Either
def test_Either_case():
    def divide_by_two(number: int) -> Either[int, str]:
        return Right(number / 2) if number % 2 == 0 else Left("Not even number")

    assert divide_by_two(4).case(
        error=str,
        success=str,
    ) == "2.0"
    assert divide_by_two(5).case(
        error=str,
        success=str,
    ) == "Not even number"



# Generated at 2022-06-12 04:59:21.509681
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right('a') == Right('a')
    assert Left(1) != Left('a')
    assert Right(1) != Right('a')
    assert Left(1) != Right('a')
    assert Left('a') != Right(1)


# Generated at 2022-06-12 04:59:28.048643
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Two objects are equal when they have the same type and value
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)

    # Two objects with different types are not equal
    assert Left(1) != Right(1)

    # Two objects with different values are not equal
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)



# Generated at 2022-06-12 04:59:33.750175
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1), 'Should be equal.'
    assert not Left(1) == Right(1), 'Should be not equal.'
    assert not Left(1) == Left(2), 'Should be not equal.'
    assert not Left(1) == None, 'Should be not equal.'
    assert not Right(1) == Left(1), 'Should be not equal.'
    assert Right(1) == Right(1), 'Should be equal.'
    assert not Right(1) == Left(2), 'Should be not equal.'
    assert not Right(1) == None, 'Should be not equal.'

# Generated at 2022-06-12 04:59:39.688340
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: Maybe.just(2)) == Right(Maybe.just(2)).to_lazy()

# Generated at 2022-06-12 04:59:42.469659
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(2).to_lazy().value() == 2
    assert Either(True).to_lazy().value() == True


# Generated at 2022-06-12 04:59:46.843588
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    # Given
    val1 = Left(1)
    val2 = Right(2)

    # When
    actual1 = val1.to_lazy()
    actual2 = val2.to_lazy()

    # Then
    assert isinstance(actual1, Lazy)
    assert isinstance(actual2, Lazy)

# Generated at 2022-06-12 04:59:49.178120
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 04:59:51.468034
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('error').to_lazy().force() == 'error'
    assert Right(1).to_lazy().force() == 1


# Generated at 2022-06-12 04:59:56.084498
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    lazy_success = Lazy(lambda: 100)
    lazy_failure = Lazy(lambda: -100)

    assert Right(100).to_lazy() == lazy_success
    assert Left(-100).to_lazy() == lazy_failure


# Generated at 2022-06-12 05:00:03.417059
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from collections import namedtuple

    Result = namedtuple("Result", "value")

    assert isinstance(Left("A").to_lazy(), Lazy)
    assert isinstance(Right("A").to_lazy(), Lazy)
    assert Left("A").to_lazy().value() == "A"
    assert Right("B").to_lazy().value() == "B"


# Unit tests for method to_validation of class Either

# Generated at 2022-06-12 05:00:09.618111
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    import pytest

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(Maybe.just(1)).to_lazy() == Lazy(lambda: 1)
    assert Either(Maybe.nothing()).to_lazy() != Lazy(lambda: 1)
    assert Maybe.just(1) == Maybe.just(1)
    with pytest.raises(Exception):
        Maybe.just(1).get()
    assert Maybe.just(1).get_or_else(2) == 1


# Generated at 2022-06-12 05:00:15.340875
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, force

    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert force(Right(3).to_lazy()) == 3

    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert force(Left('error').to_lazy()) == 'error'

# Generated at 2022-06-12 05:00:20.130286
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:00:25.276746
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def lazy_func():
        return 12

    assert Right(12).to_lazy() == Lazy(lazy_func)



# Generated at 2022-06-12 05:00:31.261832
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import re

    def get_lazy_string(lazy):
        return re.findall(r'type=<class \'(.*)\'>', str(lazy))[0]

    assert 'Lazy' == get_lazy_string(Left(1).to_lazy())
    assert 'Lazy' == get_lazy_string(Right(1).to_lazy())



# Generated at 2022-06-12 05:00:38.454622
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import pymonet.functions as F

    result = Right(2).to_lazy()
    assert result == Lazy(lambda: 2)

    result = Right(2).to_lazy().map(F.add(2))
    assert result == Lazy(lambda: 4)

    result = Left(2).to_lazy().map(F.add(2))
    assert result == Lazy(lambda: 2)


# Generated at 2022-06-12 05:00:43.114196
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method for Either monad.
    """
    from pymonet.lazy import Lazy

    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:00:44.175091
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    result = Right(3).to_lazy()
    assert Lazy(lambda: 3) == result

# Generated at 2022-06-12 05:00:48.287445
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    def assert_value(lazy, value):
        assert lazy.call() == value

    assert_value(Right(1).to_lazy(), 1)
    assert_value(Left(1).to_lazy(), 1)



# Generated at 2022-06-12 05:00:50.244955
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy().force() == 2
    assert Right(2).to_lazy().force() == 2


# Generated at 2022-06-12 05:00:52.077881
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    either_box = Right(5)
    # when
    lazy = either_box.to_lazy()
    # then
    assert lazy.value() == 5


# Generated at 2022-06-12 05:00:54.819466
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(200).to_lazy() == Lazy(lambda: 200)
    assert Left(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-12 05:00:58.836001
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert (Lazy(lambda: 2) == Right(2).to_lazy())
    assert (Lazy(lambda: Maybe.just(2)) == Left(Maybe.just(2)).to_lazy())


# Generated at 2022-06-12 05:01:04.699484
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    GIVEN Either with value
    WHEN to_lazy()
    THEN return Lazy with function returning stored value
    """

    num = 1

    either = Either(num)
    lazy = either.to_lazy()

    assert lazy.value() == 1


# Generated at 2022-06-12 05:01:05.927840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    return


# Generated at 2022-06-12 05:01:08.539930
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(10).to_lazy() == Lazy(lambda : 10)
    assert Right(10).to_lazy() == Lazy(lambda : 10)


# Generated at 2022-06-12 05:01:13.160792
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Right
    either = Either.right(13)
    assert isinstance(either.to_lazy(), Lazy)
    assert either.to_lazy().get() == 13

# Generated at 2022-06-12 05:01:17.240447
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:01:21.385484
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:27.510802
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(3).to_lazy() == Lazy(lambda: 3)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either(3).to_lazy().value() == 3
    assert Either('a').to_lazy().value() == 'a'
    assert Either(None).to_lazy().value() == None



# Generated at 2022-06-12 05:01:35.146419
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert (Right(1).to_lazy() == Lazy(lambda: 1))
    assert (Left(1).to_lazy() == Lazy(lambda: 1))
    assert (Right(1).to_lazy().force() == Lazy(lambda: 1).force())
    assert (Left(1).to_lazy().force() == Lazy(lambda: 1).force())



# Generated at 2022-06-12 05:01:40.271161
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Either(10).to_lazy().evaluate() == 10
    assert Left(10).to_lazy().evaluate() == 10
    assert Right(10).to_lazy().evaluate() == 10
    assert type(Either(10).to_lazy()) is Lazy


# Generated at 2022-06-12 05:01:41.891456
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:01:46.847223
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:01:49.639197
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    e = Right('a')
    # When
    l = e.to_lazy()
    # Then
    assert l.result == 'a'


# Generated at 2022-06-12 05:01:53.772380
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 0) == Either(0).to_lazy()



# Generated at 2022-06-12 05:01:56.714821
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    success = Right(1)
    error = Left(1)

    assert success.to_lazy().get() == 1
    assert error.to_lazy().get() == 1

# Generated at 2022-06-12 05:01:59.919285
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Right('a').to_lazy()
    assert Lazy(lambda: 'a') == Left('a').to_lazy()


# Generated at 2022-06-12 05:02:05.314761
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def assert_lazy(either: Either, lazy: Lazy):
        assert either.to_lazy() == lazy

    assert_lazy(Left(34), Lazy(lambda: 34))
    assert_lazy(Right(34), Lazy(lambda: 34))
    assert_lazy(Left(Maybe.just(5)), Lazy(lambda: Maybe(5)))
    assert_lazy(Right(Try.success(5)), Lazy(lambda: Try(5)))


# Generated at 2022-06-12 05:02:08.292703
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)


# Generated at 2022-06-12 05:02:13.153406
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    monad_right = Either.right(1)
    assert monad_right.to_lazy() == Lazy(1)

    monad_left = Either.left(1)
    assert monad_left.to_lazy() == Lazy(1)



# Generated at 2022-06-12 05:02:15.674022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right("abc").to_lazy() == Lazy(lambda: "abc")
    assert Left("abc").to_lazy() == Lazy(lambda: "abc")

# Generated at 2022-06-12 05:02:26.652906
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Either[int](2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Either[int](2).to_lazy().eval() == 2
    assert Either[int](2.).to_lazy().eval() == 2.
    assert Either[int](2).to_lazy().map(lambda x: x * 2).eval() == 4
    assert Either[int](2).to_lazy().bind(lambda x: Lazy(lambda: x * 2)).eval

# Generated at 2022-06-12 05:02:36.648994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('Oops').to_lazy() == Lazy(lambda: 'Oops')
    assert Right('Yay!').to_lazy() == Lazy(lambda: 'Yay!')



# Generated at 2022-06-12 05:02:39.891512
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(14).to_lazy() == Lazy(lambda: 14)
    assert Left(15).to_lazy() == Lazy(lambda: 15)


# Generated at 2022-06-12 05:02:42.729008
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = Either.Right(1)
    assert value.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:02:45.344416
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test to_lazy result of method of class Left"""
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:02:47.679389
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:02:58.657729
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Right(Box(2)).to_lazy().value() == Lazy(lambda: Box(2)).value()
    assert Left(Box(2)).to_lazy().value() == Lazy(lambda: Box(2)).value()
    assert Right(Try(2)).to_lazy().value() == Lazy(lambda: Try(2)).value()
    assert Left(Try(2)).to_lazy().value() == Lazy(lambda: Try(2)).value()
    assert Right(Maybe(2)).to_lazy().value() == Lazy(lambda: Maybe(2)).value()

# Generated at 2022-06-12 05:03:03.796228
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Right(1).to_lazy()
    assert isinstance(result, Lazy)
    assert callable(result.value)
    assert result.value() == 1


# Generated at 2022-06-12 05:03:13.214632
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Either(10).to_lazy()
    assert Either(10).to_lazy() != Either(7).to_lazy()

    assert Either(10).to_lazy().map(lambda x: x * 2) == Lazy(20)
    assert Either(7).to_lazy().map(lambda x: x * 2) == Lazy(14)

    assert Either(10).to_lazy().bind(lambda x: Lazy(x * 2)) == Lazy(20)
    assert Either(7).to_lazy().bind(lambda x: Lazy(x * 2)) == Lazy(14)

    assert Either(10).to_lazy().__eq__(Lazy(10))
    assert not Either(10).to

# Generated at 2022-06-12 05:03:16.499958
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:03:19.264978
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:03:33.546115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(Lazy(lambda: 1)).to_lazy().value() == Lazy(lambda: 1).value()
    assert Left(Lazy(lambda: 1)).to_lazy().value() == Lazy(lambda: 1).value()



# Generated at 2022-06-12 05:03:38.215421
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either = Right(1)
    assert either.to_lazy() == Lazy(lambda: 1)

    either = Left(2)
    assert either.to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:03:40.840099
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(4).to_lazy() == Lazy(lambda: 4)
    assert Right(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 05:03:47.133224
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    def value_factory():
        return 'value'

    expected = 'value'
    right: Either[str] = Right('value')

    assert right.to_lazy().value() == expected

    lazy: Either[Lazy[str]] = Right(Lazy(value_factory))

    assert lazy.to_lazy().value().value() == expected

    left = Left('value')

    pytest.raises(AssertionError, left.to_lazy)

# Generated at 2022-06-12 05:03:51.147691
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    lazy_right = Right(12).to_lazy()
    assert lazy_right == Lazy(lambda: 12)


# Generated at 2022-06-12 05:03:55.674222
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 2) == Right(2).to_lazy()


# Generated at 2022-06-12 05:03:58.232319
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:04:04.088965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'lazy value') == Either(lambda: 'lazy value').to_lazy()
    assert Lazy(lambda: 'Nothing') == Either('Nothing').to_lazy()
    assert Lazy(lambda: 'lazy!') == Either('lazy!').to_lazy()


# Generated at 2022-06-12 05:04:08.284661
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:04:15.979444
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Right(Failure(Exception("Error"))).to_lazy() == Lazy(lambda: Try(Exception("Error"), is_success=False))


# Generated at 2022-06-12 05:04:42.634789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def side_effect(x):
        print(x)
        return x

    lazy = Either.Right(10).to_lazy()
    assert lazy == Lazy(lambda: 10)
    assert lazy.get() == 10
    assert lazy.get() == 10
    lazy.map(side_effect)
    lazy.map(side_effect)
    assert lazy.get() == 10

# Generated at 2022-06-12 05:04:46.555935
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:48.752302
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy().resolve() == 2
    assert Right(2).to_lazy().resolve() == 2


# Generated at 2022-06-12 05:04:51.104488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5).to_lazy().get() == 5
    assert Left(5).to_lazy().get() == 5
    assert Right(5).to_lazy().get() == 5



# Generated at 2022-06-12 05:04:55.371143
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either(4).to_lazy(), Lazy)
    assert isinstance(Left(4).to_lazy(), Lazy)
    assert isinstance(Right(4).to_lazy(), Lazy)
    assert Right(4).to_lazy().value() == 4


# Generated at 2022-06-12 05:05:04.400566
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Ensure that method to_lazy create new Lazy monad and call it's constructor
    with lambda returning stored value.
    """
    from pymonet.lazy import Lazy

    class MockLazy(Lazy):
        def __init__(self, value, caller=None):
            self.value = value
            self.called = caller

        def __call__(self):
            return self.value

    lazy = MockLazy(1)
    Either.to_lazy = Either.to_lazy.__func__
    assert lazy == Right(1).to_lazy()
    assert lazy == Left(1).to_lazy()



# Generated at 2022-06-12 05:05:09.651115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Test to_lazy method on class Right
    right = Right("a")
    assert right.to_lazy().value == "a"
    # Test to_lazy method on class Left
    left = Left("a")
    assert left.to_lazy().value == "a"


# Generated at 2022-06-12 05:05:13.982889
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.Right(2).to_lazy() == Lazy(lambda: 2)
    assert Either.Left(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:05:16.331578
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # GIVEN
    l = Either.unit(1)

    # THEN
    assert l.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:05:17.633993
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either[int](5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:06:10.784315
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:06:12.270582
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(12).to_lazy().eval() == 12
    assert Right(12).to_lazy().eval() == 12

# Generated at 2022-06-12 05:06:17.864606
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Either('test').to_lazy() == Lazy(lambda: 'test')
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:06:21.378225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Assert if to_lazy method of class Either return right result.
    """
    assert Left(1).to_lazy().getter() == 1
    assert Right(1).to_lazy().getter() == 1



# Generated at 2022-06-12 05:06:24.090757
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e = Right(5)
    assert e.to_lazy().get() == 5



# Generated at 2022-06-12 05:06:27.508066
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:06:33.355259
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy_val = Lazy(lambda: 1)
    assert Either(1).to_lazy() == lazy_val
    assert Either(1).to_box().to_lazy() == lazy_val
    assert Either(1).to_try().to_lazy() == lazy_val

    assert Lazy(lambda: Either(1)).map(lambda x: x.to_lazy()) == Lazy(lambda: Either(1).to_lazy())


# Generated at 2022-06-12 05:06:41.009153
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functional import curry

    assert Lazy(lambda: 'a') == Either.to_lazy(Right('a'))
    assert Lazy(lambda: 'a') == Either.to_lazy(Left('a'))
    assert Lazy(lambda: 'a') == curry(Either.to_lazy)(Left('a'))
    assert Lazy(lambda: 'a') == curry(Either.to_lazy)(Right('a'))


# Generated at 2022-06-12 05:06:44.300889
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(42).to_lazy() == Lazy(lambda: 42)
    assert Left(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:06:47.796199
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert (Left(1).to_lazy() == Lazy(lambda: 1))
    assert (Right(1).to_lazy() == Lazy(lambda: 1))

# Generated at 2022-06-12 05:08:42.080687
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()


# Generated at 2022-06-12 05:08:45.167520
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 'foo') == Left('foo').to_lazy()
    assert Lazy(lambda: 'bar') == Right('bar').to_lazy()


# Generated at 2022-06-12 05:08:46.302982
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:08:49.372469
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(-1).to_lazy()(lambda x: x * 10) == Lazy(-10)
    assert Left(-1).to_lazy()(lambda x: x * 10) == Lazy(-10)


# Generated at 2022-06-12 05:08:52.125948
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test for Right
    assert Lazy(lambda: 1) == Right(1).to_lazy()

    # Test for Left
    assert Lazy(lambda: 'error') == Left('error').to_lazy()