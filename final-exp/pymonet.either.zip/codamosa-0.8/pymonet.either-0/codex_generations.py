

# Generated at 2022-06-12 04:58:50.740844
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 04:58:56.752621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert isinstance(Either('2').to_lazy(), Lazy)
    assert Lazy(lambda: '2') == Either('2').to_lazy()



# Generated at 2022-06-12 04:59:00.132930
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either = Right(3)
    lazy = either.to_lazy()

    assert lazy == Lazy(lambda: 3)



# Generated at 2022-06-12 04:59:02.379176
# Unit test for method case of class Either
def test_Either_case():
    assert Left("fail").case(lambda x: x, lambda x: "success") == "fail"
    assert Right("success").case(lambda x: x, lambda x: x) == "success"

# Generated at 2022-06-12 04:59:06.159819
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(10) == Right(10)
    assert Right(10) != Right(11)
    assert Left(10) == Left(10)
    assert Left(10) != Left(11)
    assert Left(10) != Right(11)
    assert Left(10) != None
    assert Right(10) != None



# Generated at 2022-06-12 04:59:07.924819
# Unit test for method case of class Either
def test_Either_case():
    response = Right(42).case(lambda error: error * 2, lambda success: success + 1)
    assert response == 43

# Generated at 2022-06-12 04:59:15.015777
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(2)
    assert Right(1) != Left(2)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Either(1) != Either(1)



# Generated at 2022-06-12 04:59:23.758922
# Unit test for method case of class Either
def test_Either_case():
    """
    Testing case method for class Either.
    For both subclasses of Either(Left, Right) the method case should return different values.
    """
    def err(x: int) -> int:
        return x * 2

    def succ(x: int) -> int:
        return x * 4

    assert Right(2).case(err, succ) == 8
    assert Left(5).case(err, succ) == 10



# Generated at 2022-06-12 04:59:27.845381
# Unit test for method case of class Either
def test_Either_case():
    def f1(x):
        assert x == 1
        return 2

    def f2(x):
        assert x == 3
        return 4

    assert Left(1).case(f1, f2) == 2
    assert Right(3).case(f1, f2) == 4

# Generated at 2022-06-12 04:59:32.624826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add_one(a):
        return a + 1
    right_lazy = Right(1).to_lazy()
    assert right_lazy.get().get() == 1
    left_lazy = Left(1).to_lazy()
    assert left_lazy.get().get() == 1
    assert right_lazy.map(add_one).get().get() == 2
    assert left_lazy.map(add_one).get().get() == 1

# Generated at 2022-06-12 04:59:39.600041
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy().value() == None
    assert Right(None).to_lazy().value() == None
    assert Right(3).to_lazy().map(lambda x: x + 1).value() == 4
    assert Right(3).to_lazy().bind(lambda x: Lazy(lambda: x + 1)).value() == 4


# Generated at 2022-06-12 04:59:42.025909
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:59:45.929824
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(0)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(0)
    assert Right(1) != Left(1)

# Generated at 2022-06-12 04:59:54.207731
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert not Either(1) == Either(2) and not Either(1) == Either("1") and not Either("1") == Either(1)
    assert not Either("1") == Either("2") and not Either("1") == 1 and not Either("1") == [1]
    assert not Either(1) == "1" and not Either(1) == 1 and not Either([1]) == [1]
    assert Right(1) == Right(1) and Right("1") == Right("1")
    assert Left(1) == Left(1) and Left("1") == Left("1")


# Generated at 2022-06-12 04:59:57.433924
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1

# Generated at 2022-06-12 05:00:06.545669
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Case of two instances of Left with the same value
    assert Left('value') == Left('value')
    # Case of two instances of Right with the same value
    assert Right('value') == Right('value')
    # Case of two instances of Left but with different values
    assert not (Left('value') == Left('other value'))
    # Case of two instances of Right but with different values
    assert not (Right('value') == Right('other value'))
    # Case of two instances of Left and Right
    assert not (Left('value') == Right('value'))
    # Case of instance of Either and not instance of Either
    assert not (Left('value') == 'value')
    # Case of instance of Either and not instance of Either
    assert not (Left('value') == 'value')


# Generated at 2022-06-12 05:00:10.039048
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(True) == Right(True)
    assert Left(True) == Left(True)
    assert Right(True) != Left(True)
    assert Left(True) != Right(True)
    assert Right(True) != Right(False)
    assert Left(True) != Left(False)
    assert Right(True) != True
    assert Left(True) != True


# Generated at 2022-06-12 05:00:20.563537
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.test.test_validation import test_Validation___eq__
    from pymonet.test.test_box import test_Box___eq__
    from pymonet.test.test_lazy import test_Lazy___eq__
    from pymonet.test.test_maybe import test_Maybe___eq__

    assert Right(1) == Right(1) == Left(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)
    assert not Right(1) == 1
    test_Maybe___eq__()
    test_Box___eq__()
    test_Lazy___eq__()
    test_Validation___eq__()



# Generated at 2022-06-12 05:00:23.370522
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy().take() == 5
    assert Right(5).to_lazy().take() == 5


# Generated at 2022-06-12 05:00:29.006873
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from hamcrest.core.core.isequal import equal_to
    from hamcrest_unit_test.matcher_test import assert_that

    # Arrange
    either = Either('value')

    # Act
    result = either.to_lazy()

    # Assert
    assert_that(result(), equal_to('value'))

# Generated at 2022-06-12 05:00:43.823159
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    assert Left(1) == Left(1)
    assert Left(1) == Left(1)
    assert Left(1) == Left(2) == False
    assert Left(1) == Right(1) == False

    assert Right(1) == Right(1)
    assert Right(1) == Right(2) == False
    assert Right(1) == Left(1) == False

    assert Try(1).to_either() == Try(1).to_either()
    assert Try(1).to_either() == Try(None).to_either() == False
    assert Try(1).to_either() == Try(1, is_success=False).to_either() == False


# Generated at 2022-06-12 05:00:52.998631
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1).__eq__(Either(1)) == True
    assert Either(1).__eq__(Either(2)) == False
    assert Either(1).__eq__(Either([1,2])) == False
    assert Either(1).__eq__(Either((1,2))) == False
    assert Either([1,2]).__eq__(Either(1)) == False
    assert Either({1,2}).__eq__(Either({1,2})) == True
    assert Either({1,2}).__eq__(Either(1)) == False
    assert Either({'a':1,'b':2}).__eq__(Either({'a':1,'b':2})) == True

# Generated at 2022-06-12 05:00:58.095695
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(0) == Right(0)
    assert Left(0) == Left(0)
    assert not Right(0) == Left(0)
    assert not Left(0) == Right(0)
    assert not Right(0) == Right(1)
    assert not Left(0) == Left(1)


# Generated at 2022-06-12 05:01:04.671259
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left("a") == Left("a")
    assert Right("a") == Right("a")
    assert Left("a") != Right("a")
    assert Right("a") != Left("a")
    assert Left(1) != Right("a")
    assert Right("a") != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right("a") != Right(1)
    assert Right(1) != Right("a")


# Generated at 2022-06-12 05:01:09.333396
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy1 = Either.right(1).to_lazy()
    assert Lazy.do(lazy1) == 1

    lazy2 = Either.left(1).to_lazy()
    assert Lazy.do(lazy2) == 1

# Generated at 2022-06-12 05:01:12.734766
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('error') == Left('error')
    assert Right('value') == Right('value')
    assert not Left('error') == Right('value')



# Generated at 2022-06-12 05:01:17.215273
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('') == Left('') is True
    assert Right(1) == Right(1) is True
    assert Left('') == Right('') is False
    assert Right(1) == Left(1) is False
    assert Right(1) == Right(2) is False
    assert Left(1) == Left(2) is False



# Generated at 2022-06-12 05:01:18.491041
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Either(1)).value() == 1



# Generated at 2022-06-12 05:01:20.438887
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left() == Left()
    assert Right(1) == Right(1)


# Generated at 2022-06-12 05:01:30.199458
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Two same instances of Right
    assert Right(3) == Right(3)
    # Two instances of the same Right, but different values
    assert Right(3) != Right(4)

    # Two same instances of Left
    assert Left(3) == Left(3)
    # Two instances of the same Left, but different values
    assert Left(3) != Left(4)

    # Left and Right
    assert Left(3) != Right(3)
    # Left and Right with different values
    assert Left(3) != Right(4)
    # Left and Right with different values
    assert Left(4) != Right(3)
    # Left and Right with different values
    assert Left(4) != Right(5)


# Generated at 2022-06-12 05:01:36.352609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:38.147081
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(42).to_lazy() == Either(42).to_lazy()


# Generated at 2022-06-12 05:01:41.539144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right('lazy')) == Lazy(lambda: 'lazy')
    assert Either.to_lazy(Left('error')) == Lazy(lambda: 'error')

# Generated at 2022-06-12 05:01:43.439897
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    right = Right(42)
    assert right.to_lazy() is not None


# Generated at 2022-06-12 05:01:46.363804
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_duplication = Either(10).to_lazy().map(lambda x: x * 2)
    assert lazy_duplication == Lazy(lambda: 10 * 2)


# Generated at 2022-06-12 05:01:50.797290
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.either import Left
    
    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:01:53.365500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:01:57.065172
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Left('a').to_lazy()
    assert Lazy(lambda: 'a') == Right('a').to_lazy()



# Generated at 2022-06-12 05:02:01.040907
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(4).to_lazy().value() == 4
    assert Right('foo').to_lazy().value() == 'foo'

    assert Left(4).to_lazy().value() == 4
    assert Left('foo').to_lazy().value() == 'foo'



# Generated at 2022-06-12 05:02:03.277925
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left([1,2]).to_lazy() == Lazy(lambda: [1,2])


# Generated at 2022-06-12 05:02:15.258941
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either({'key': 'value'}).to_lazy() == Lazy(lambda: {'key': 'value'})
    assert Either(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:02:19.415938
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    right = Right(2)

    # When
    lazy_result = right.to_lazy()

    # Then
    assert lazy_result.eval() == 2


# Generated at 2022-06-12 05:02:23.237867
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:02:28.408533
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    def test_vocabulary():
        assert 1 + 1 == 2

    def test_vocabulary_2():
        assert 2 + 2 == 4

    lazy = Left(RuntimeError('Some error')).to_lazy()
    lazy.bind(test_vocabulary)
    with pytest.raises(RuntimeError):
        lazy.resolve()

    lazy = Right('right way').to_lazy()
    lazy.bind(test_vocabulary)
    lazy.bind(test_vocabulary_2)
    assert 4 == lazy.resolve()

# Generated at 2022-06-12 05:02:32.020015
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    x = 3
    y = Either.right(x)

    # when
    lazy_y = y.to_lazy()

    # then
    assert lazy_y.to_a() == x


# Generated at 2022-06-12 05:02:34.195226
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:02:37.057156
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:02:39.203363
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().force() == 1
    assert Right(1).to_lazy().force() == 1


# Generated at 2022-06-12 05:02:45.295565
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    result = Try(5).to_lazy().force()
    expected = Lazy(lambda: 5).force()
    assert result == expected

    result = Maybe.nothing().to_lazy().force()
    expected = Lazy(lambda: None).force()
    assert result == expected



# Generated at 2022-06-12 05:02:51.114790
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    error = Either(1)
    result = Either(2)
    assert error.to_lazy() == Lazy(lambda: 1)
    assert result.to_lazy() == Lazy(lambda: 2)

    try_error = error.to_try()
    try_result = result.to_try()
    assert try_error.to_lazy() == Lazy(lambda: 1)
    assert try_result.to_lazy() == Lazy(lambda: 2)

    box_error = error.to_box()
    box_result = result.to_box()
    assert box_error.to_lazy() == Lazy(lambda: 1)
    assert box_

# Generated at 2022-06-12 05:03:07.635594
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'foo') == Either('foo').to_lazy()
    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: [1, 2, 3, 4]) == Either([1, 2, 3, 4]).to_lazy()
    assert Lazy(lambda: {'foo': 'bar'}) == Either({'foo': 'bar'}).to_lazy()


# Generated at 2022-06-12 05:03:16.843517
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Validation.success("Lorem ipsum").to_lazy() == Lazy(
        lambda: Validation.success("Lorem ipsum").value)

    assert Validation.fail("Lorem ipsum").to_lazy() == Lazy(
        lambda: Validation.fail("Lorem ipsum").value)

    assert Maybe.just("Lorem ipsum").to_lazy() == Lazy(
        lambda: Maybe.just("Lorem ipsum").value)

    assert Maybe.nothing().to_lazy() == Lazy(
        lambda: Maybe.nothing().value)


# Generated at 2022-06-12 05:03:19.264355
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Either.Left(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:03:21.841285
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(20).to_lazy() == Lazy(lambda: 20)


# Generated at 2022-06-12 05:03:25.638694
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # GIVEN
    either = Right(2)

    # WHEN
    lazy = either.to_lazy()

    # THEN
    assert isinstance(lazy, Lazy)
    assert lazy.compute() == 2



# Generated at 2022-06-12 05:03:31.359459
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    fn = lambda x: x

    actual_result = Right(fn).to_lazy().value()
    expected_result = fn
    assert actual_result == expected_result

    actual_result = Left(fn).to_lazy().value()
    expected_result = fn
    assert actual_result == expected_result


# Generated at 2022-06-12 05:03:34.518229
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def identity(x):
        return x

    assert Right(1).to_lazy() == Lazy(identity(1))
    assert Left(1).to_lazy() == Lazy(identity(1))



# Generated at 2022-06-12 05:03:37.572642
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:03:39.703965
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')


# Generated at 2022-06-12 05:03:43.522022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit tests for method to_lazy of class Either.

    :pre: None
    :post: None
    :return: None
    """
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:03:59.263760
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(2).to_lazy(), type(Lazy(lambda: 2)))


# Generated at 2022-06-12 05:04:05.358619
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:04:08.198893
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(42).to_lazy() == Lazy(lambda: 42)
    assert Left(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-12 05:04:12.396084
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Either.to_lazy(Right("just"))
    assert isinstance(result, Lazy)
    assert result.force() == "just"



# Generated at 2022-06-12 05:04:15.788516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import assert_lazy
    assert_lazy(Right(1).to_lazy(), 1)
    assert_lazy(Left(1).to_lazy(), 1)


# Generated at 2022-06-12 05:04:19.034366
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == Left(1)
    assert Right(1).to_lazy().value() == Right(1)



# Generated at 2022-06-12 05:04:21.854878
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either."""
    value = Either.to_lazy(Right(89))
    assert value.evaluate() == 89



# Generated at 2022-06-12 05:04:23.889327
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 15
    lazy = Either(value).to_lazy()
    assert lazy.value_or(0) == value

# Generated at 2022-06-12 05:04:26.965788
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_fnc():
        return 4

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:04:31.160330
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("test").to_lazy() == Lazy(lambda: "test")
    assert Right("test").to_lazy() == Lazy(lambda: "test")


# Generated at 2022-06-12 05:05:05.079217
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 1
    left = Left(value)
    right = Right(value)
    assert left.to_lazy().get() == left.value, 'Left value should be equal to Lazy value'
    assert right.to_lazy().get() == right.value, 'Right value should be equal to Lazy value'


# Generated at 2022-06-12 05:05:10.947554
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.box import Box

    assert Either(Box(1)).to_lazy() == lazy.Lazy(lambda: Box(1))
    assert Either(Box(1)).to_lazy().map(lambda x: x + 1).force() == Box(2)
    assert Either(None).to_lazy() == lazy.Lazy(lambda: None)

# Generated at 2022-06-12 05:05:14.275581
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Box(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:05:20.321653
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor_laws import test_functor_identity
    from pymonet.functor_laws import test_functor_composition

    # Success
    either = Right(1)
    lazy = either.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1
    assert test_functor_identity(either, lambda x: x)
    assert test_functor_composition(
        either,
        lambda x: x + 1,
        lambda x: x * 2
    )

    # Error
    either = Left(2)
    lazy = either.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 2
    assert test_functor_ident

# Generated at 2022-06-12 05:05:25.161045
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method with instance of Right of class Either.

    :returns: None
    :rtype: NoneType
    """
    assert Right('toto').to_lazy() == Lazy(lambda: 'toto')


# Generated at 2022-06-12 05:05:28.130260
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:32.620674
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:05:34.706227
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e = Either.Right(lambda x: x + 2)
    assert e.to_lazy().run()(2) == 4

# Generated at 2022-06-12 05:05:43.003866
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy as lazy

    assert lazy.Lazy(lambda: 1).value() == 1
    assert lazy.Lazy(lambda: str(1)).value() == '1'
    assert lazy.Lazy(lambda: Either.right(1)).value().value == 1
    assert lazy.Lazy(lambda: Either.right(1)).value().to_lazy().value().value() == 1
    assert lazy.Lazy(lambda: Either.right(1)).value().to_lazy().value().to_lazy().value().value() == 1

    assert lazy.Lazy(lambda: Either.left(1)).value().value == 1
    assert lazy.Lazy(lambda: Either.left(1)).value().to_lazy().value().value() == 1
    assert lazy.Lazy(lambda: Either.left(1)).value

# Generated at 2022-06-12 05:05:51.074587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.list import List
    from pymonet.lazy import Lazy

    assert Right(True).to_lazy() == Lazy(lambda: True)
    assert Left(False).to_lazy() == Lazy(lambda: False)
    assert Right(Maybe.just(True)).to_lazy() == Lazy(lambda: Maybe.just(True))
    assert Left(Maybe.just(True)).to_lazy() == Lazy(lambda: Maybe.just(True))
    assert Right(List(1, 2, 3)).to_lazy() == Lazy(lambda: List(1, 2, 3))
    assert Left(List(1, 2, 3)).to_lazy() == Lazy(lambda: List(1, 2, 3))


# Generated at 2022-06-12 05:07:01.893432
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(Right(1).to_lazy()) == Lazy(lambda: 1),\
        'Function Either.to_lazy must return Lazy with underlying value'
    assert Either(Left(1).to_lazy()) == Lazy(lambda: 1),\
        'Function Either.to_lazy must return Lazy with underlying value'

# Generated at 2022-06-12 05:07:04.006747
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get_value()() == 1
    assert Right(1).to_lazy().get_value()() == 1


# Generated at 2022-06-12 05:07:05.863461
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    value = 'value'
    either = Either(value)

    # When
    lazy = either.to_lazy()

    # Then
    assert lazy.get_value() == value

# Generated at 2022-06-12 05:07:10.426241
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left = Left(1)
    right = Right(2)

    left = left.to_lazy()
    right = right.to_lazy()

    assert isinstance(left, Lazy)
    assert isinstance(right, Lazy)

    assert left.value() == 1
    assert right.value() == 2


# Generated at 2022-06-12 05:07:14.677169
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()


# Generated at 2022-06-12 05:07:17.799054
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    right = Either.right(2)

    # when
    result = right.to_lazy()

    # then
    assert 2 == result.fmap(lambda x: x + 2).get_value()



# Generated at 2022-06-12 05:07:19.475197
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert (Left(1).to_lazy().eval() == 1)
    assert (Right(1).to_lazy().eval() == 1)

# Generated at 2022-06-12 05:07:22.320919
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:07:26.584176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test of Either.to_lazy method.

    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 'a') == Right('a').to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 'a') == Left('a').to_lazy()


# Generated at 2022-06-12 05:07:31.218391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def plusOne(num: int) -> int:
        return num + 1
    def minusOne(num: int) -> int:
        return num - 1

    right = Right(10)
    left = Left(8)
    assert right.to_lazy() == Lazy(lambda: 10)
    assert left.to_lazy() == Lazy(lambda: 8)

