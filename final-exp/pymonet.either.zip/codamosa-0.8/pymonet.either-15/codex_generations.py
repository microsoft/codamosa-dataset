

# Generated at 2022-06-12 04:59:00.746352
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(2)
    assert Left(1) == Left(1)
    assert not Left(1) == Right(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(2)



# Generated at 2022-06-12 04:59:05.724745
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('test').to_lazy() == Lazy(lambda: 'test')
    assert Either({'test': 'test'}).to_lazy() == Lazy(lambda: {'test': 'test'})
    assert Either([]).to_lazy() == Lazy(lambda: [])

# Generated at 2022-06-12 04:59:08.694594
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 04:59:14.638873
# Unit test for method case of class Either
def test_Either_case():
    def left() -> Left[int]:
        return Left(1)

    def right() -> Right[int]:
        return Right(1)

    # Creation and use of Monad
    assert left().case(lambda x: 'error', lambda x: 'success') == 'error'
    assert right().case(lambda x: 'error', lambda x: 'success') == 'success'

# Generated at 2022-06-12 04:59:18.013852
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left(1)
    left2 = Left(2)
    right1 = Right(1)
    right2 = Right(2)

    assert left1 == left1
    assert right1 == right1
    assert right1 != right2
    assert left1 != right1
    assert left2 != right2


# Generated at 2022-06-12 04:59:22.717256
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # arrange
    eith1 = Either('a')
    eith2 = Either('a')

    # act
    result1 = eith1 == eith2
    result2 = eith1 == 'a'

    # assert
    assert result1
    assert not result2


# Generated at 2022-06-12 04:59:30.745958
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    first_right_either = Right(1)
    second_right_either = Right(2)
    assert first_right_either == first_right_either
    assert second_right_either == second_right_either
    assert first_right_either != second_right_either

    first_left_either = Left("1")
    second_left_either = Left("2")
    assert first_left_either == first_left_either
    assert second_left_either == second_left_either
    assert first_left_either != second_left_either

    assert first_right_either != first_left_either
    assert first_left_either != first_right_either



# Generated at 2022-06-12 04:59:34.006840
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Assert positive case
    assert Either(1) == Either(1)

    # Assert negative cases
    assert Either(1) != Either(2)
    assert Either(1) != Either('a')


# Generated at 2022-06-12 04:59:38.053088
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    either_a = Left('a')
    either_b = Left('a')
    either_c = Right('a')
    either_d = Either('a')
    assert either_a == either_b
    assert either_a != either_c
    assert either_a != either_d



# Generated at 2022-06-12 04:59:41.932276
# Unit test for method case of class Either
def test_Either_case():
    """
    Unit test for method case of class Either.

    """
    assert Either(1).case(lambda x: 2, lambda x: 3) == 2
    assert Either(1).case(lambda x: 2, lambda x: 3) == 3


# Generated at 2022-06-12 04:59:47.211715
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('left') == Left('left')
    assert Left('left') != Right('right')
    assert Right('right') == Right('right')


# Generated at 2022-06-12 04:59:52.019733
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import pytest

    to_lazy_result = Lazy(lambda: "Test")
    right_result = Right("Test").to_lazy()

    assert right_result == to_lazy_result
    assert to_lazy_result.value == "Test"


# Generated at 2022-06-12 04:59:55.781994
# Unit test for method case of class Either
def test_Either_case():
    assert Right(0).case(error=lambda x: None, success=lambda x: 2*x) == 0
    assert Left(4).case(error=lambda x: 2*x, success=lambda x: None) == 8



# Generated at 2022-06-12 05:00:00.164530
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Verify that method __eq__ returns True for two same Eithers.
    """
    assert Either(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)


# Generated at 2022-06-12 05:00:04.387437
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)



# Generated at 2022-06-12 05:00:06.147757
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3) == Right(3)
    assert Left(3) == Left(3)
    assert Right(3) != Left(3)



# Generated at 2022-06-12 05:00:09.851104
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1).__eq__(Either(1)) is False
    assert Either(1).__eq__(Either(2)) is False
    assert Either(1).__eq__(None) is False
    assert Either(1).__eq__(2) is False
    assert Either(1).__eq__(Left(1)) is False


# Generated at 2022-06-12 05:00:15.205548
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(2) == Right(2)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Right(1) != 2
    assert Right(1) != object


# Generated at 2022-06-12 05:00:19.372502
# Unit test for method case of class Either
def test_Either_case():
    assert(Left(5).case(lambda value: str(value), lambda value: value + 5) == '5')
    assert(Right(5).case(lambda value: str(value), lambda value: value + 5) == 10)


# Generated at 2022-06-12 05:00:22.852456
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x) == 2
    assert Right(2).case(lambda x: x + 1, lambda x: x) == 2



# Generated at 2022-06-12 05:00:28.909724
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ test_Either_to_lazy """

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:00:30.784613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('foo').to_lazy() == Lazy(lambda: 'foo')
    assert Right('foo').to_lazy() == Lazy(lambda: 'foo')


# Generated at 2022-06-12 05:00:33.572889
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Either(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.eval() == 1

# Generated at 2022-06-12 05:00:45.306246
# Unit test for method to_lazy of class Either

# Generated at 2022-06-12 05:00:49.664061
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance((Left(1).to_lazy()), Lazy)
    assert isinstance((Left(1).to_lazy().resolve()), Left)
    assert isinstance((Right(1).to_lazy()), Lazy)
    assert isinstance((Right(1).to_lazy().resolve()), Right)


# Generated at 2022-06-12 05:00:51.970995
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 'Test'

    assert Right(func).to_lazy() == Lazy(func)
    assert Left(func).to_lazy() == Lazy(func)


# Generated at 2022-06-12 05:00:54.308701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().get() == 5
    assert Left(5).to_lazy().get() == 5


# Generated at 2022-06-12 05:00:57.364448
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:01:00.665575
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def fn():
        return 1

    assert Right(1).to_lazy().value() == fn().to_lazy().value()
    assert Left(1).to_lazy().value() == fn().to_lazy().value()

# Generated at 2022-06-12 05:01:06.129413
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for method to_lazy in class Right
    right_test_value = Right(11)
    right_test_lazy = right_test_value.to_lazy()
    test_value = right_test_lazy()
    assert test_value == 11

    # Test for method to_lazy in class Left
    left_test_value = Left('test value')
    left_test_lazy = left_test_value.to_lazy()
    test_value = left_test_lazy()
    assert test_value == 'test value'

# Generated at 2022-06-12 05:01:12.638391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(42).to_lazy().value(), int) and\
        isinstance(Right(42).to_lazy().value(), int)


# Generated at 2022-06-12 05:01:15.157809
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    assert Left(42).to_lazy().value == 42
    assert Right(42).to_lazy().value() == 42


# Generated at 2022-06-12 05:01:18.834787
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(lambda x: x + 1).to_lazy() == Lazy(lambda: (lambda x: x + 1))


# Generated at 2022-06-12 05:01:28.928555
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    def test_case_0():
        """
        Test case for class Either method to_lazy.

        :returns: assertion error when test failed
        :rtype: AssertionError
        """

        val_0 = Left(1)
        val_1 = Right(2)
        val_2 = val_0.to_lazy()
        val_3 = val_1.to_lazy()
        assert val_2 == Lazy(lambda: 1)
        assert val_3 == Lazy(lambda: 2)
        assert val_0 == Right(1)
        assert val_1 == Right(2)


# Generated at 2022-06-12 05:01:31.377517
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:01:40.018768
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(1)
    assert right.to_lazy().get() == right.value
    assert right.to_lazy().get() == 1
    assert right.to_lazy().is_right() == right.is_right()
    assert right.to_lazy().is_right() == True
    left = Left(1)
    assert left.to_lazy().get() == left.value
    assert left.to_lazy().get() == 1
    assert left.to_lazy().is_left() == left.is_left()
    assert left.to_lazy().is_left() == True


# Generated at 2022-06-12 05:01:41.922910
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(11).to_lazy() == Lazy(lambda: 11)

# Generated at 2022-06-12 05:01:51.465731
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure, Success
    from pymonet.either import Right, Left

    def f():
        return None

    assert Right(None).to_lazy() == Right(Lazy(f))
    assert Left(None).to_lazy() == Left(Lazy(f))
    assert Right(None).to_lazy().case(lambda e: e, lambda v: v) == Lazy(f)
    assert Left(None).to_lazy().case(lambda e: e, lambda v: v) == Lazy(f)
    assert Right(None).to_lazy().case(lambda e: e, lambda v: v).value() == None

# Generated at 2022-06-12 05:01:54.341488
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(42).to_lazy().value() == 42
    assert Left(6).to_lazy().value() == 6


# Generated at 2022-06-12 05:01:57.924511
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:02:10.056265
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Left(4).to_lazy() == Lazy(lambda: 4)
    assert Right(4).to_lazy() == Lazy(lambda: 4)
    assert Left(Box(4)).to_lazy() == Lazy(lambda: Box(4))
    assert Right(Box(4)).to_lazy() == Lazy(lambda: Box(4))
    assert Left(Try(4, is_success=True)).to_lazy() == Lazy(lambda: Try(4, is_success=True))
    assert Right(Try(4, is_success=True)).to_lazy() == Lazy(lambda: Try(4, is_success=True))


# Unit test

# Generated at 2022-06-12 05:02:13.570193
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5).to_lazy().value() == 5
    assert Either(5).constructor() == 'Either'
    assert Either(5).unit() == 5
    assert Either(5).constructor() == 'Either'


# Generated at 2022-06-12 05:02:16.805878
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(10).to_lazy(), Lazy)
    assert Right(10).to_lazy().value() == 10
    assert Left(10).to_lazy().value() == 10



# Generated at 2022-06-12 05:02:20.351793
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy.__doc__ is not None
    assert Either.to_lazy.__annotations__ == {'return': 'Lazy[Function() -> A]', 'self': 'Either[T]'}


# Generated at 2022-06-12 05:02:23.614697
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(4)) == Lazy(4)
    assert Either.to_lazy(Left("test")) == Lazy("test")


# Generated at 2022-06-12 05:02:25.682915
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Either(10).to_lazy()


# Generated at 2022-06-12 05:02:28.832682
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Right(1).value) == Right(1).to_lazy() == Right(Lazy(lambda: 1).value)



# Generated at 2022-06-12 05:02:32.392430
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Equality.are_equals(Right(3).to_lazy(), Lazy(lambda: 3))
    assert Equality.are_equals(Left(3).to_lazy(), Lazy(lambda: 3))



# Generated at 2022-06-12 05:02:36.701819
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e = Right(3)
    assert isinstance(e, Right)
    l = e.to_lazy()
    assert l.is_value()
    assert l.value() == 3


# Generated at 2022-06-12 05:02:40.253172
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    from pymonet.lazy import Lazy
    either = Right(1)

    # when
    to_lazy_result: Lazy = either.to_lazy()

    # then
    assert to_lazy_result.value() == 1


# Generated at 2022-06-12 05:02:47.878167
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert Lazy(lambda: 1) == Right(1).to_lazy()



# Generated at 2022-06-12 05:02:51.883701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either("boom").to_lazy() == Lazy(lambda: "boom")


# Generated at 2022-06-12 05:02:57.137618
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Left(None).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() is None

    result = Right(2).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 2



# Generated at 2022-06-12 05:03:09.922503
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def f(x):
        return x * x

    closure_test = Lazy(lambda: f(2))
    closure_test.force()

    assert Lazy(lambda: 1).map(f).force() == Lazy(lambda: 1).ap(Lazy(lambda: f)).force()
    assert Lazy(lambda: 1).map(f).force() == Lazy(lambda: f(1)).force()
    assert Lazy(lambda: f(1)).force() == Try(1).to_lazy().ap(Lazy(lambda: f)).force()
    assert Lazy(lambda: Try(f(1))).force().is_success() is True

# Generated at 2022-06-12 05:03:11.931824
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(None).to_lazy().run() is None
    assert Right(None).to_lazy().run() is None



# Generated at 2022-06-12 05:03:15.975349
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(3).to_lazy() == Lazy(lambda: 3)
    assert Right(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:03:21.193619
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(10)
    right = Right(10)

    assert left.to_lazy().__str__() == right.to_lazy().__str__() == "Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x{:x}>)"\
        .format(id(left.to_lazy().value))

# Generated at 2022-06-12 05:03:23.410301
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either[str]('').to_lazy().unwrap() == ''
    assert Either[str]('test').to_lazy().unwrap() == 'test'



# Generated at 2022-06-12 05:03:24.801631
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(2).to_lazy().value() == 2


# Generated at 2022-06-12 05:03:28.550919
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)


# Generated at 2022-06-12 05:03:42.583833
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:03:45.581065
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:03:48.990409
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Tests Either to_lazy method."""
    assert Right(1).to_lazy().value() == 1
    assert Left("error").to_lazy().value() == "error"


# Generated at 2022-06-12 05:03:54.046341
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    result = Right(42).to_lazy()

    assert (isinstance(result, Lazy))
    assert (result.value() == 42)

    result = Left(42).to_lazy()

    assert (isinstance(result, Lazy))
    assert (result.value() == 42)



# Generated at 2022-06-12 05:03:57.499603
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(2)
    assert Either(1).to_lazy() == Lazy(2)


# Generated at 2022-06-12 05:04:02.476176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:04:04.864035
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(3).to_lazy(), Lazy)
    assert Left(3).to_lazy().evaluate() == 3


# Generated at 2022-06-12 05:04:13.286903
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monoid import Monoid
    from pymonet.monad import Monad

    assert isinstance(Right(5).to_lazy(), Lazy)
    assert isinstance(Left(5).to_lazy(), Lazy)

    _lazy = Right(5).to_lazy()
    assert _lazy.is_lazy()
    assert 5 == _lazy.eval()
    assert isinstance(_lazy.fmap(lambda x: 2 * x), Lazy)
    assert isinstance(_lazy.ap(Lazy(lambda: lambda x: 2 * x)), Lazy)
    assert isinstance(_lazy.mappend(Lazy(lambda: 5)), Lazy)

# Generated at 2022-06-12 05:04:15.532362
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(2).to_lazy(), Lazy)
    assert Right(2).to_lazy().get()() == 2



# Generated at 2022-06-12 05:04:21.430035
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy().eval() == 1
    assert Right(Box(1)).to_lazy() == Lazy(lambda: 1)
    assert Right(Box(1)).to_lazy().eval() == 1


# Generated at 2022-06-12 05:04:49.348220
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('a').to_lazy() == Lazy(lambda: 'a')
    assert Either(Either(1)).to_lazy() == Lazy(lambda: Either(1))


# Generated at 2022-06-12 05:04:53.335532
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(0).to_lazy().get() == 0
    bad_func = Either(lambda x: 1 / 0)

    try:
        bad_func.to_lazy().get()
    except ZeroDivisionError as ex:
        assert ex
    else:
        assert False


# Generated at 2022-06-12 05:05:03.860523
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monoid import Monoid
    from pymonet.lazy import Lazy
    from pymonet.applicative import Applicative

    # Given
    def plus1(a: int) -> int:
        return a + 1
    def lazy_plus1(a: int) -> int:
        return a + 1
    mapper = Lazy(lazy_plus1)

    # When
    left = Left(1).to_lazy()
    right = Right(1).to_lazy()

    # Then

    # Check left
    assert isinstance(left, Lazy)
    assert left.value() == 1

    # Check right
    assert isinstance(right, Lazy)
    assert right.value() == 1


# Generated at 2022-06-12 05:05:10.831967
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    left = Left(2)
    right = Right(2)

    assert Lazy( lambda: 2) == left.to_lazy()
    assert Lazy( lambda: 2) == right.to_lazy()

# Generated at 2022-06-12 05:05:14.892922
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)

# Generated at 2022-06-12 05:05:18.515887
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Working function for unit test of method to_lazy of class Either.

    :returns: result of unit test
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy

    return Right(5).to_lazy() == Lazy(lambda: 5) and\
        Left([10, 20]).to_lazy() == Lazy(lambda: [10, 20])



# Generated at 2022-06-12 05:05:21.552347
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for to_lazy method"""

    assert Either(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:24.665012
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:05:31.537694
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Either, Left, Right

    def add1(x):
        return x + 1

    # test with Left
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    # test with Right
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    # test with None
    assert (Left(1).to_lazy() == Right(1).to_lazy()) == False
    assert (Left(1).to_lazy() == Lazy(lambda: 1)) == True
    assert (Right(1).to_lazy() == Lazy(lambda: 1)) == True

# Generated at 2022-06-12 05:05:38.162675
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Test with Right
    r = Right(2)
    l = r.to_lazy()
    assert l.eval() == r.value
    assert isinstance(l, Lazy)
    # Test with Left
    r = Left("Left value")
    l = r.to_lazy()
    assert l.eval() == r.value
    assert isinstance(l, Lazy)



# Generated at 2022-06-12 05:06:35.853676
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('abc').to_lazy() == Lazy(lambda: 'abc')


# Generated at 2022-06-12 05:06:37.984172
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:06:42.610173
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Success, Failure

    assert Success(3).to_lazy().force() == Success(3)
    assert Failure(3).to_lazy().force() == Failure(3)



# Generated at 2022-06-12 05:06:44.526012
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)


# Generated at 2022-06-12 05:06:50.771367
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:54.538662
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(15).to_lazy().value(), int)
    assert str(Right(15).to_lazy().value()) == '15'
    assert Left('error').to_lazy().value() == 'error'



# Generated at 2022-06-12 05:06:57.113664
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(42).to_lazy() == Lazy(lambda: 42)
    assert Either(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:07:03.220253
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    either1 = Left(Try.failure(ValueError('This is error')))
    either2 = Right(Try.success('Value'))
    assert either1.to_lazy() == Lazy(lambda: Left(Try.failure(ValueError('This is error'))))
    assert either2.to_lazy() == Lazy(lambda: Right('Value'))


# Generated at 2022-06-12 05:07:04.828230
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(10).to_lazy().value() == 10
    assert Left(20).to_lazy().value() == 20


# Generated at 2022-06-12 05:07:08.271718
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # GIVEN
    e = Either(1)

    # WHEN
    value = e.to_lazy()

    # THEN
    assert isinstance(value, Lazy)
    assert value == Lazy(lambda: 1)
    assert value().value == 1

