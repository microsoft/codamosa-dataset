

# Generated at 2022-06-12 04:58:59.924092
# Unit test for method case of class Either
def test_Either_case():
    result = Either(5).case(lambda e: e * 2, lambda s: s * 3)
    assert result == 15, "Should get 15 when Right"

    result = Either('error').case(lambda e: e * 2, lambda s: s * 3)
    assert result == 'errorerror', "Should get errorerror when Left"

# Generated at 2022-06-12 04:59:02.798546
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    either = Right(1)

    # When
    actual = either.to_lazy()

    # Then
    assert actual.value() == 1
    assert isinstance(actual, Lazy)



# Generated at 2022-06-12 04:59:06.713409
# Unit test for method case of class Either
def test_Either_case():
    def error_handler(message):
        return message.upper()

    def success_handler(message):
        return message.title()

    assert Left("foo").case(error_handler, success_handler) == "FOO"
    assert Right("foo").case(error_handler, success_handler) == "Foo"



# Generated at 2022-06-12 04:59:11.234448
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) == Left(2)
    assert Right(1) == Right(2)
    assert not(Left(1) == Right(1))
    assert not(Left(1) == Left(2) == Right(2))



# Generated at 2022-06-12 04:59:15.498806
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 04:59:27.961197
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def check(eq_first, eq_second, result_first, result_second):
        assert (eq_first == eq_second) == result_first
        assert (eq_second == eq_first) == result_second

    print('-------- test Either class --------')
    print('- test method __eq__ ')
    check(Left(1), Left(2), False, False)
    check(Left(1), Right(1), False, False)
    check(Right(1), Left(1), False, False)
    check(Right(1), Right(2), False, False)
    check(Left(1), Left(1), True, True)
    check(Right(1), Right(1), True, True)
    print('- test method __eq__ - ok')



# Generated at 2022-06-12 04:59:30.072243
# Unit test for method case of class Either
def test_Either_case():
    assert Either.case(Right(1), lambda _: 2, lambda _: 3) == 3
    assert Either.case(Left(1), lambda _: 2, lambda _: 3) == 2

# Generated at 2022-06-12 04:59:32.900679
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 'value'
    right = Right(value)
    lazy = right.to_lazy()
    assert lazy.value() == value
    left = Left(value)
    lazy = left.to_lazy()
    assert lazy.value() == value


# Generated at 2022-06-12 04:59:35.640414
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None) == Left(None)
    assert Left(None) != Right(None)
    assert Right(None) == Right(None)
    assert Right(None) != Left(None)

# Generated at 2022-06-12 04:59:39.350124
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)


# Generated at 2022-06-12 04:59:46.683794
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left1 = Left(1)
    left2 = Left(1)
    right1 = Right(1)
    right2 = Right(2)

    # Then
    assert left1 == left1
    assert not left1 == left2
    assert not left1 == right1
    assert not left1 == right2

    # Then
    assert right1 == right1
    assert not right1 == right2
    assert not right1 == left1
    assert not right1 == left2

# Generated at 2022-06-12 04:59:52.367596
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    from pymonet.lazy import Lazy

    from pymonet.monad_try import Try

    def _test(either):
        return either.to_lazy() == Lazy(lambda: Try.unit(either.value))

    assert _test(Left(3))
    assert _test(Right(3))


# Generated at 2022-06-12 04:59:57.738328
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    x = Lazy(lambda: Right(1))
    assert x.value() == 1

    x = Lazy(lambda: Left('error'))
    assert x.value() == 'error'



# Generated at 2022-06-12 05:00:02.809763
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('test') == Left('test')
    assert Left('test') != Right('test')
    assert Right('test') == Right('test')
    assert Right(1) != Left(1)
    assert Left(1) == Left(1)
    assert Right(1) != Right(2)
    assert Right(1) == Right(1)



# Generated at 2022-06-12 05:00:07.811494
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    
    def double_value(x: int) -> int:
        return x * 2

    def triple_value(x: int) -> int:
        return x * 3

    right = Lazy(lambda: 55)
    assert right.map(double_value).to_lazy().get() == 110

    right = Lazy(lambda: 55)
    assert right.map(double_value).map(triple_value).to_lazy().get() == 330


test_Either_to_lazy()

# Generated at 2022-06-12 05:00:10.602450
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Left(1)



# Generated at 2022-06-12 05:00:16.000743
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not (Right(1) == Left(1))
    assert not (Left(1) == Right(1))
    assert not (Right(1) == Right(2))
    assert not (Left(1) == Left(2))



# Generated at 2022-06-12 05:00:20.352106
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:00:28.573636
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box

    assert Either(Box(5)) == Either(Box(5))
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)

    assert Either(Box(5)) != Either(Box(10))
    assert Left(5) != Left(10)
    assert Right(5) != Right(10)

    assert Left(5) != Either(Box(5))
    assert Right(5) != Either(Box(5))


# Generated at 2022-06-12 05:00:33.477812
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    print("test_Either___eq__")

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Left(1) == Left(2)

# Generated at 2022-06-12 05:00:39.117568
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:00:42.473668
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2)
    assert Left(2) != Right(2)
    assert Right(2) != Left(2)
    assert Right(2) == Right(2)


# Generated at 2022-06-12 05:00:48.763916
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(9) == Left(9)
    assert Right(1) == Right(1)
    assert not (Right(0) == Left(9))
    assert not (Right(0) == Right(1))
    assert not (Left(0) == Left(1))
    assert not (Left(0) == None)
    assert not (Right(0) == None)
    assert not (Right(0) == 3)
    assert not (Left(0) == 3)

# Generated at 2022-06-12 05:00:51.354510
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Right(1) == Right(1))
    assert(Left(1) == Left(1))
    assert(Right(1) != Left(1))
    assert(Left(1) != Right(1))



# Generated at 2022-06-12 05:00:57.411321
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Left(None) == Left(None))
    assert(Left(None) != Right(None))
    assert(Right([1, 2, 3]) != Left([]))
    assert(Right(None) == Right(None))
    assert(Right(5) != Left(5))
    assert(Left('Hi') != Right('Hi'))
    assert(Left(1.1) != Right(1.1))
    assert(Left({'k': 1}) != Right({'k': 1}))


# Generated at 2022-06-12 05:01:02.578122
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test if to_lazy is properly working.
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Either.to_lazy(Right(2)) == Lazy(lambda: 2)
    assert Either.to_lazy(Left(Box(2))) == Lazy(lambda: Box(2))


# Generated at 2022-06-12 05:01:09.090543
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    import pytest
    from pymonet.box import Box

    assert Right(Box(1)) == Right(Box(1))
    assert Left(Box(1)) == Left(Box(1))
    assert not Right(Box(1)) == Right(Box(2))
    assert not Right(Box(1)) == Left(Box(1))
    assert not Right(Box(1)) == Box(1)
    with pytest.raises(Exception):
        Right(Box(1)).__eq__(None)


# Generated at 2022-06-12 05:01:13.280587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:01:18.786867
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_from_left = Left('option').to_lazy()
    assert lazy_from_left.extract_value() == 'option'
    lazy_from_right = Right('option').to_lazy()
    assert lazy_from_right.extract_value() == 'option'


# Generated at 2022-06-12 05:01:26.943145
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    def just_lazy():
        return Maybe.just(lambda: 42)

    def nothing_lazy():
        return Maybe.nothing()

    assert Left(42).to_lazy() == Lazy(lambda: 42)
    assert Right(42).to_lazy() == Lazy(lambda: 42)

    assert maybe_number_either.ap(just_lazy()) == maybe_number_either
    assert maybe_number_either.ap(nothing_lazy()) == maybe_number_either



# Generated at 2022-06-12 05:01:33.425330
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(11) == Left(11)
    assert Right(11) == Right(11)
    assert not Left(11) == Right(11)
    assert not Left(11) == 8


# Generated at 2022-06-12 05:01:37.707067
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('test1') == Left('test1')
    assert Left('test1') != Left('test2')

    assert Right('test1') == Right('test1')
    assert Right('test1') != Right('test2')

    assert Left('test1') != Right('test1')


# Generated at 2022-06-12 05:01:44.964289
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))
    assert not (Left(1) == Right(1))
    assert not (Left(1) == Right(2))
    assert not (Right(1) == Left(1))
    assert not (Right(1) == Left(2))
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not (Left(1) == Right(1))
    assert not (Right(1) == Left(1))



# Generated at 2022-06-12 05:01:48.020480
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == 1



# Generated at 2022-06-12 05:01:51.035786
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert not Either.unit(1) == None
    assert not Left(10) == Right(10)
    assert Left(10) == Left(10)
    assert Right(10) == Right(10)

# Generated at 2022-06-12 05:01:53.553634
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)



# Generated at 2022-06-12 05:01:56.849094
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) == Left(1)
    assert Either(1) == Right(1)
    assert not Either(1) == Either(2)



# Generated at 2022-06-12 05:02:00.047497
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1) == Right(1)
    assert Left('left') == Left('left')

    assert Right(1).to_lazy() != Left(1)
    assert Left('left').to_lazy() != Right('left')


# Generated at 2022-06-12 05:02:01.921809
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Either(10).to_lazy()


# Generated at 2022-06-12 05:02:05.743449
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert not (Left(5) == Left(6))
    assert Right(5) == Right(5)
    assert not (Right(5) == Right(6))
    assert not (Left(5) == Right(5))
    assert not (Right(5) == Left(5))


# Generated at 2022-06-12 05:02:15.218493
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Right(1)


# Generated at 2022-06-12 05:02:19.055372
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(10) == Left(10)
    assert Right(20) == Right(20)
    assert Left(10) != Right(20)



# Generated at 2022-06-12 05:02:23.131040
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(3) == Left(3)
    assert Right(3) == Right(3)
    assert Left(3) != Right(3)
    assert Left(3) != Left('3')
    assert Right(3) != Right('3')



# Generated at 2022-06-12 05:02:29.270464
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from functools import reduce

    assert Right(5).to_lazy().map(lambda x: x + 2).value() == Lazy(lambda: 7).map(lambda x: x + 2).value()
    assert Left(5).to_lazy().map(lambda x: x + 2).value() == Lazy(lambda: 5).map(lambda x: x + 2).value()
    assert Right(5).to_lazy().map(lambda x: x + 2).value() == Lazy(lambda: reduce(lambda x,y:x+y, [1,2,3,4,5,6,7])).map(lambda x: x + 2).value()



# Generated at 2022-06-12 05:02:35.987534
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test for method __eq__ of class Either.
    """
    from pymonet.test import TestClass
    from pymonet.writer import Writer
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.list import List

    assert TestClass(1).__eq__(TestClass(1))
    assert TestClass(1).__eq__(TestClass(2))
    assert str(TestClass(1).__eq__(1)) == "Eithers are not allowed to be equal with other types."
    assert str(TestClass(1).__eq__(TestClass('1'))) == "Eithers are not allowed to be equal with other types."

# Generated at 2022-06-12 05:02:38.573428
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    either = Left(1)
    either2 = Left(2)
    either3 = Left(1)
    assert either == either3
    assert either != either2



# Generated at 2022-06-12 05:02:41.907456
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None).__eq__(Left(None)) is True
    assert Left(None).__eq__(Right(None)) is False
    assert Right(None).__eq__(Left(None)) is False
    assert Right(None).__eq__(Right(None)) is True


# Generated at 2022-06-12 05:02:44.483999
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left(2).to_lazy().value() == 2


# Generated at 2022-06-12 05:02:46.965067
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(2)
    assert not (Either(1) == Either(1))
    assert not (Either(1) == None)


# Generated at 2022-06-12 05:02:52.996517
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    import pymonet.either as either
    import pymonet.validation as validation

    left = either.Left(False)
    left2 = either.Left(False)
    assert left == left2
    right = either.Right(False)
    right2 = either.Right(False)
    assert right == right2
    assert left != right
    assert right != left2
    assert left != right2



# Generated at 2022-06-12 05:03:07.039820
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.free import lift_f

    def add(a, b):
        return a + b

    add_either = lift_f(add)
    lazy = add_either(Right(1), Right(2)).to_lazy()

    assert lazy.value() == 3
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:03:11.701404
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_test_utils import _test_to_lazy
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    _test_to_lazy(Left(20), Lazy(lambda: 20))
    _test_to_lazy(Right(10), Lazy(lambda: 10))


# Generated at 2022-06-12 05:03:16.078172
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import identity

    assert Either(1).to_lazy() == Lazy(identity, 1)
    assert Either(2).to_lazy() == Lazy(identity, 2)



# Generated at 2022-06-12 05:03:20.223510
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    box = Lazy(lambda: 'lazy')
    assert Right(lambda: 'lazy').to_lazy() == box
    assert Left(lambda: 'lazy').to_lazy() == box


# Generated at 2022-06-12 05:03:25.906766
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    # test Right
    assert Either(1).to_lazy() == Lazy(lambda: 1)

    # test Left
    assert Either((1, 2)).to_lazy() == Lazy(lambda: (1, 2))


# Generated at 2022-06-12 05:03:31.584192
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """test_Either_to_lazy"""
    # Test with Left Either
    left = Left("test")
    left_lazy = left.to_lazy()

    assert left_lazy() == left.value

    # Test with Right Either
    right = Right("test")
    right_lazy = right.to_lazy()

    assert right_lazy() == right.value

# Generated at 2022-06-12 05:03:34.408003
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """test_Either_to_lazy"""

    assert Left(1).to_lazy().evaluate() == 1
    assert Right(1).to_lazy().evaluate() == 1


# Generated at 2022-06-12 05:03:37.488852
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def lazy_result():
        return 'Lazy result'

    lazy = Right('Value').to_lazy()
    assert lazy.value() == lazy_result()



# Generated at 2022-06-12 05:03:39.078355
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Should return Lazy monad with function returning value of Either
    Either.to_lazy()


# Generated at 2022-06-12 05:03:45.448823
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # arrange
    class CustomException(Exception):
        def __init__(self, value=None, message=None):
            self.value = value
            self.message = message

    value = 5
    error = CustomException(value, message='test error')
    expected_lazy_return = 5
    result_lazy = None
    # act
    right = Right(value)
    left = Left(error)
    result_lazy = right.to_lazy().value()
    # assert
    assert result_lazy == expected_lazy_return
    # act
    result_lazy = left.to_lazy().value()
    # assert
    assert isinstance(result_lazy, CustomException)
    assert result_lazy.value == error.value
    assert result_lazy.message == error.message



# Generated at 2022-06-12 05:03:55.839556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:04:00.357723
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @Lazy
    def succ(value):
        return value + 1

    @Lazy
    def fail(value):
        return value - 1

    assert Right(1).to_lazy().map(succ) == Lazy(lambda: 2)
    assert Left(1).to_lazy().map(fail) == Lazy(lambda: 0)


# Generated at 2022-06-12 05:04:04.297476
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:04:06.678177
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(2).to_lazy(), Lazy)
    assert isinstance(Right(4).to_lazy(), Lazy)

# Generated at 2022-06-12 05:04:15.156556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def test_mapper(param):
        return str(param)

    test_value = 42
    either = Right(test_value)
    lazy = either.to_lazy()

    assert lazy == Lazy(lambda: test_value)
    assert lazy.map(test_mapper) == Lazy(lambda: test_mapper(test_value))
    assert isinstance(lazy.value, Lazy)



# Generated at 2022-06-12 05:04:19.034390
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:04:23.265254
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # given
    right = Right(5)

    # when
    result = right.to_lazy()

    # then
    assert isinstance(result, Lazy)
    assert result.thunk() == 5



# Generated at 2022-06-12 05:04:24.723094
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().get_value() == 1



# Generated at 2022-06-12 05:04:29.029448
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:04:32.259379
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_ap(expected, actual):
        import pytest
        assert expected == actual

    def f(x):
        return x + 1

    test_ap(Right(4).to_lazy().map(f), Right(4).map(f))

# Generated at 2022-06-12 05:04:51.576076
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def value_to_return():
        return 'value'

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:56.017957
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """test Either.to_lazy method"""
    from pymonet.lazy import Lazy

    def get_value() -> int:
        return 100

    either = Right(get_value())
    fn = either.to_lazy()
    assert(fn.value() == either.value())



# Generated at 2022-06-12 05:04:57.821227
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 10
    result = Either(value).to_lazy()

    assert value == result.evaluate(), 'Should evaluate to initial value'


# Generated at 2022-06-12 05:05:01.681560
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:05:06.502023
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Convert Right to Lazy
    assert Right(True).to_lazy() == Lazy(lambda: True)

    # Convert Left to Lazy
    assert Left(False).to_lazy() == Lazy(lambda: False)



# Generated at 2022-06-12 05:05:07.502454
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(None).to_lazy() is not None

# Generated at 2022-06-12 05:05:10.947825
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Right(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-12 05:05:15.199424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    e = Left(3)
    assert e.to_lazy() == Lazy(lambda: 3)
    e = Right(3)
    assert e.to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:05:17.753826
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:20.268063
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.Right(10).to_lazy().value() == 10
    assert Either.Right(10).to_lazy().value() == 10



# Generated at 2022-06-12 05:05:38.443552
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:05:40.511609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    either = Right(1)
    # When
    lazy = either.to_lazy()
    # Then
    assert lazy == Lazy(lambda: 1)

# Generated at 2022-06-12 05:05:42.070876
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func():
        return 42

    assert Right(func).to_lazy().value() == func()



# Generated at 2022-06-12 05:05:46.682375
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()



# Generated at 2022-06-12 05:05:48.259276
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy().get_value() == Left(2)
    assert Right(2).to_lazy().get_value() == Right(2)



# Generated at 2022-06-12 05:05:52.957716
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(Exception('test except'))
    right = Right(1)

    assert left.to_lazy() == Lazy(lambda: Exception('test except'))
    assert right.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:05:57.164956
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @Lazy
    def lazy_get_right(either):
        return either.to_lazy().value()


    test_Right = Right(3)
    assert test_Right.to_lazy().value() == lazy_get_right(test_Right)



# Generated at 2022-06-12 05:06:00.517495
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(x, y):
        return x + y

    left = Left(0)
    right = Right(1)

    assert left.to_lazy().map(add).value(10) == 0
    assert right.to_lazy().map(add).value(10) == 11


# Generated at 2022-06-12 05:06:05.281255
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy

    def lazy_func(a):
        return a + 10

    assert Lazy(lambda: 10) == Left(10).to_lazy()
    assert Lazy(lambda: lazy_func(10)) == Right(10).to_lazy()


# Generated at 2022-06-12 05:06:12.372688
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def f(x):
        return x + 1

    left = Either.left(10)
    right = Either.right(10)

    # On left
    result_left = left.to_lazy()
    assert isinstance(result_left, Lazy)
    assert result_left.resolve() == 10

    # On right
    result_right = right.to_lazy()
    assert isinstance(result_right, Lazy)
    assert result_right.resolve() == 10

# Generated at 2022-06-12 05:06:34.185470
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def f(x: int) -> int:
        return x

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(6).map(f).to_lazy() == Lazy(f(6))
    assert Right(6).bind(lambda x: Left('error')).to_lazy() == Lazy(lambda: 'error')
    assert Right(6).bind(lambda x: Right(x)).to_lazy() == Lazy(lambda: 6)
    assert Right(6).bind(lambda x: Right(x + 1)).to_lazy() == Lazy(lambda: 7)

# Generated at 2022-06-12 05:06:38.573952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_value = lambda: "lazy"
    assert Lazy(lazy_value).value() == str(Right(lazy_value)) == "lazy"
    assert Lazy(lambda: 4).value() == str(Right(lambda: 4)) == "4"


# Generated at 2022-06-12 05:06:41.984357
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:06:44.120696
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy().eval() == 2
    assert Right(2).to_lazy().eval() == 2

# Generated at 2022-06-12 05:06:53.477992
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet. either import Left, Right

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: True) == Right(True).to_lazy()
    assert Lazy(lambda: [1, 2]) == Right([1, 2]).to_lazy()

    error = len
    assert Lazy(lambda: error) == Left(error).to_lazy()
    assert Lazy(lambda: error) == Left(error).to_lazy()
    assert Lazy(lambda: []) == Left([]).to_lazy()


# Generated at 2022-06-12 05:07:03.705780
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 2) != Lazy(lambda: 3)

    result = Either(Box(3)).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value == 3

    result = Either(Try(3, is_success=True)).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value == 3

    result = Either(Try(3, is_success=False)).to_lazy()
    assert isinstance(result, Lazy)
    assert isinstance(result.value, Exception)

# Generated at 2022-06-12 05:07:10.090729
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1).to_either().to_lazy() == Lazy(lambda: 1)
    assert Lazy(lambda: 1).to_either().to_lazy() != Lazy(lambda: 2)
    assert Lazy(lambda: 1).to_either().to_lazy() == Right(1).to_lazy()
    assert Lazy(lambda: 1).to_either().to_lazy() != Left(1).to_lazy()



# Generated at 2022-06-12 05:07:13.557985
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 10)
    assert Right(10).to_lazy() == lazy
    assert Left(10).to_lazy() == lazy


# Generated at 2022-06-12 05:07:15.890822
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 05:07:18.969381
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # given
    either = Right(2)

    # when
    lazy_either = either.to_lazy()

    # then
    assert isinstance(lazy_either, Lazy)
    assert lazy_either.value() == 2


# Generated at 2022-06-12 05:07:58.555604
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Right(1).to_lazy().eval() == 1
    assert Left(1).to_lazy().eval() == 1


# Generated at 2022-06-12 05:08:02.134972
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right

    def some_function():
        pass

    # Check for Either
    assert(Either(42).to_lazy() == Lazy(lambda: 42))
    # Check for Left
    assert(Left(42).to_lazy() == Lazy(lambda: 42))
    # Check for Right
    assert(Right(42).to_lazy() == Lazy(lambda: 42))



# Generated at 2022-06-12 05:08:03.826921
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    expected = Lazy(lambda: Right(1))
    actual = Either.unit(1).to_lazy()
    assert actual == expected



# Generated at 2022-06-12 05:08:08.107108
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    def test_right_to_lazy():
        assert Either.Right(10).to_lazy() == Lazy(lambda: 10)

    def test_left_to_lazy():
        assert Either.Left(Box(10)).to_lazy() == Lazy(lambda: Box(10))

    test_right_to_lazy()
    test_left_to_lazy()


# Generated at 2022-06-12 05:08:11.287784
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Left(None).to_lazy() == Lazy(lambda: None)
    assert Right(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 05:08:13.842230
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def func():
        return 5

    lazy_five = Lazy(func)

    assert lazy_five.is_equal_to(Right(5).to_lazy())

# Generated at 2022-06-12 05:08:16.418231
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Maybe.nothing().to_lazy(), Lazy)
    assert Maybe.just('value').to_lazy().value().is_right()



# Generated at 2022-06-12 05:08:18.216332
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(10).to_lazy().value() == 10
    assert Left(20).to_lazy().value() == 20


# Generated at 2022-06-12 05:08:20.978259
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(10).to_lazy()
    assert lazy == Lazy(lambda: 10)


# Generated at 2022-06-12 05:08:25.367279
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(42).to_lazy().get() == 42
    assert Right(42).to_lazy().get() == 42
    assert Left(42).to_lazy() != Lazy.of(41)
    assert Right(42).to_lazy() != Lazy.of(42)