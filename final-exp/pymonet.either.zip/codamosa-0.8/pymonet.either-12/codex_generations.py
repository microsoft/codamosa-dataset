

# Generated at 2022-06-12 04:59:01.524722
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    e1 = Right(1)
    e2 = Right(1)
    e3 = Right(2)
    e4 = Left(1)
    e5 = Left(1)
    e6 = Left(2)

    assert e1 == e2
    assert not e1 == e3
    assert not e1 == e4
    assert not e1 == e5
    assert not e1 == e6

    assert e4 == e5
    assert not e4 == e6
    assert not e4 == e1
    assert not e4 == e2
    assert not e4 == e3



# Generated at 2022-06-12 04:59:03.949827
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 04:59:07.370917
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Right(2) != Right(1)
    assert Left(2) != Left(1)



# Generated at 2022-06-12 04:59:11.501810
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_either = Left(1)
    left_either1 = Left(1)
    right_either = Right(2)
    right_either1 = Right(2)
    assert left_either == left_either1
    assert right_either == right_either1
    assert left_either != right_either



# Generated at 2022-06-12 04:59:16.871113
# Unit test for method case of class Either
def test_Either_case():
    assert(
        Either(2).case(
            error=lambda x: x/0,
            success=lambda x: x**2,
        )
        == 4
    )
    assert (
        Either(2).case(
            error=lambda x: x**2,
            success=lambda x: x/0,
        )
        == 4
    )



# Generated at 2022-06-12 04:59:21.220684
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)


# Generated at 2022-06-12 04:59:26.330259
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 04:59:28.781243
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)



# Generated at 2022-06-12 04:59:33.164978
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box

    assert Either(Box('value')).__eq__(Either(Box('value')))
    assert not Either(Box('value')).__eq__(Either(Box('other value')))
    assert not Either(Box('value')).__eq__(3)
    assert not Either(Left(Box('value'))).__eq__(Either(Right(Box('value')))) # assert True


# Generated at 2022-06-12 04:59:35.278810
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().eval() == 1
    assert Left(1).to_lazy().eval() == 1


# Generated at 2022-06-12 04:59:42.682303
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(3).to_lazy() == Lazy(3)
    assert Either('test').to_lazy() == Lazy('test')
    assert Either(1).to_lazy() != Lazy('test')


# Generated at 2022-06-12 04:59:46.982840
# Unit test for method case of class Either
def test_Either_case():
    assert Either(0).case(lambda _: 1, lambda _: 2) == 1
    assert Either(1).case(lambda _: 1, lambda _: 2) == 2

    assert Right(0).case(lambda _: 1, lambda _: 2) == 2
    assert Left(0).case(lambda _: 1, lambda _: 2) == 1


# Generated at 2022-06-12 04:59:50.067950
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right("abc") == Right("abc")
    assert Left("abc") == Left("abc")
    assert Right("abc") != Left("abc")
    assert Left("abc") != Right("abc")



# Generated at 2022-06-12 04:59:55.595569
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    test_Either___eq__ is unit test for method __eq__ of class Either.
    """
    assert Left(5) == Left(5)
    assert Left(5) != Left(6)
    assert Right(5) == Right(5)
    assert Right(5) != Right(6)
    assert Right(5) != Left(5)


# Generated at 2022-06-12 05:00:01.989562
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(None) == Left(None)
    assert Left([]) == Left([])
    assert Left(0) == Left(0)
    assert Right(None) == Right(None)
    assert Right([]) == Right([])
    assert Right(0) == Right(0)
    assert Left(None) != Right(None)
    assert Left([]) != Right([])
    assert Left(0) != Right(0)

# Generated at 2022-06-12 05:00:08.927810
# Unit test for method case of class Either
def test_Either_case():
    assert Right(True).case(lambda v: not v, lambda v: v)
    assert Left(False).case(lambda v: not v, lambda v: False)
    assert Right(False).case(lambda v: True, lambda v: not v)
    assert Left(True).case(lambda v: False, lambda v: not v)
    assert not Right(True).case(lambda v: v, lambda v: not v)
    assert Left(False).case(lambda v: v, lambda v: False)
    assert not Right(False).case(lambda v: not v, lambda v: v)
    assert Left(True).case(lambda v: not v, lambda v: v)



# Generated at 2022-06-12 05:00:19.497417
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @pytest.mark.parametrize('Either, value', [
        (Right(34), 34),
        (Left(45), 45),
    ])
    def _test_Either_to_lazy(Either, value) -> None:
        """
        Test to_lazy method of Either monad.

        :param Either: Either with number
        :type Either: Either[num]
        :param value: value of Either
        :type value: num
        :returns: None
        :rtype: None
        """
        from pymonet.lazy import Lazy

        assert Either.to_lazy() == Lazy(lambda: value)
    _test_Either_to_lazy()


# Generated at 2022-06-12 05:00:30.816380
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.validation import Validation

    assert Left(['some error']) == Left(['some error'])
    assert Left(['some error']) != Left(['another error'])
    assert Left(['some error']) != Right(['some value'])
    assert Right([1, 2, 3]) == Right([1, 2, 3])
    assert Right([1, 2, 3]) != Right([0, 1, 2])
    assert Right([1, 2, 3]) != Left(['some error'])
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) == Left([1, 2, 3])
    assert Left(['some error']) == Validation.fail(['some error'])

# Generated at 2022-06-12 05:00:42.379986
# Unit test for method case of class Either
def test_Either_case():
    assert Left(10).case(lambda value: value * 2, lambda value: value) == 20
    assert Left(10).case(lambda value: value * 2, lambda value: value) == 20
    assert Left(10).case(lambda value: value * 2, lambda value: value) == 20
    assert Left(10).case(lambda value: value * 2, lambda value: value) == 20

    assert Right(10).case(lambda value: value * 2, lambda value: value) == 10
    assert Right(10).case(lambda value: value * 2, lambda value: value) == 10
    assert Right(10).case(lambda value: value * 2, lambda value: value) == 10
    assert Right(10).case(lambda value: value * 2, lambda value: value) == 10



# Generated at 2022-06-12 05:00:48.331589
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    a = Left(3)
    b = Left(3)
    assert a == b
    a = Left(4)
    assert a != b
    a = Right(4)
    b = Right(4)
    assert a == b
    a = Right(5)
    assert a != b
    a = Left(4)
    b = Right(4)
    assert a != b
    assert a != 4



# Generated at 2022-06-12 05:01:02.707906
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(0).__eq__(Left(0)) is True
    assert Left(0).__eq__(Left(1)) is False
    assert Left(0).__eq__(Right(0)) is False
    assert Right(0).__eq__(Right(0)) is True
    assert Right(0).__eq__(Right(1)) is False
    assert Right(0).__eq__(Left(0)) is False
    assert Right(0).__eq__(Left(1)) is False


# Generated at 2022-06-12 05:01:07.219470
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert not (Left(5) == Left(6))
    assert not (Right(5) == Left(5))
    assert not (Right(5) == Left(6))
    assert Right(5) == Right(5)
    assert not (Right(5) == Right(6))


# Generated at 2022-06-12 05:01:10.505574
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f(x):
        return x + 1

    value = 10
    
    result = Right(value).to_lazy().map(f).get()

    assert result == f(value)

# Generated at 2022-06-12 05:01:13.921058
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:01:16.983613
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get() == 1
    assert Right(2).to_lazy().get() == 2


# Generated at 2022-06-12 05:01:19.447324
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    value = 'abc'
    either = Right(value)
    lazy = either.to_lazy()
    assert lazy.value() == value


# Generated at 2022-06-12 05:01:23.591279
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert Left(2) != Right(5)
    assert Left(2) != Right(5)
    assert Left(1) != Left(5)
    assert Right(1) != Right(5)



# Generated at 2022-06-12 05:01:27.730013
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)

# Generated at 2022-06-12 05:01:33.423490
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda: 0
    l = Lazy(f)
    assert isinstance(l, Lazy)
    assert l.get_value() == 0
    assert l.get_value() == 0
    assert l.get_value() == 0
    assert l.get_value() == 0



# Generated at 2022-06-12 05:01:41.680962
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Right('foo') == Right('foo')
    assert Left('foo') == Left('foo')

    assert Right('foo') != Left('foo')
    assert Right('foo') == Right('42')

    assert Left(Box('foo')) == Left(Box('foo'))
    assert Left(Try('foo')) == Left(Try('foo'))
    assert Left(Lazy('foo')) == Left(Lazy('foo'))


# Generated at 2022-06-12 05:01:53.175636
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either_left = Left(1)
    assert either_left.to_lazy() == Lazy(lambda: 1)
    either_right = Right(1)
    assert either_right.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:01:57.235890
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either to_lazy.

    :returns: Nothing
    """
    value = 'test'

    assert Right(value).to_lazy().evaluate() == value
    assert Left(value).to_lazy().evaluate() == value



# Generated at 2022-06-12 05:01:59.749218
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right("foo").to_lazy() == Lazy(lambda: "foo")

# Generated at 2022-06-12 05:02:06.764515
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Either.to_lazy('abc').is_right()
    assert Either.to_lazy('abc').get()() == 'abc'

    assert Either.to_lazy(Either.left('xyz')).is_left()
    assert Either.to_lazy(Either.left('xyz')).get()() == 'xyz'

    assert Either.to_lazy(Lazy(lambda: 'abc')).is_right()
    assert Either.to_lazy(Lazy(lambda: 'abc')).get()() == 'abc'


# Generated at 2022-06-12 05:02:16.510614
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_try() == Try(1, is_success=True)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_box() == Box(1)



# Generated at 2022-06-12 05:02:19.455659
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:02:22.463217
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    value = 1

    # When
    instance = Either(value)

    # Then
    assert instance.to_lazy().get() == value


# Generated at 2022-06-12 05:02:24.728111
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get() == 1
    assert Right(2).to_lazy().get() == 2


# Generated at 2022-06-12 05:02:28.223144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:02:30.645670
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:02:48.209189
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:02:52.877538
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test function to_lazy of class Either.

    :returns: True if test succeed, False otherwise
    :rtype: Boolean
    """
    e = Right(5)

    return e.to_lazy().call() == 5



# Generated at 2022-06-12 05:02:59.182595
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test case for to_lazy method.
    """
    assert Right(5).to_lazy() == Lazy(lambda: 5), "Should return lazy with passed value"
    assert Left('').to_lazy() == Lazy(lambda: ''), "Should return lazy with passed value"
    assert type(Right(5).to_lazy()) == Lazy, "Should return Lazy"
    assert type(Left('').to_lazy()) == Lazy, "Should return Lazy"


# Generated at 2022-06-12 05:03:02.920505
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest
    from pymonet.box import Box
    from pytest import approx

    # Test with a Left object
    e_left = Left(Box(0))
    a_left = e_left.to_lazy()

    assert a_left.get() == 0

    # Test with a Right object
    e_right = Right(Box(1))
    a_right = e_right.to_lazy()

    assert a_right.get() == 1



# Generated at 2022-06-12 05:03:04.454808
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:03:13.596009
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of class Either.

    :returns: True if test passes
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def resolve_lazy(lazy: Lazy[int]) -> int:
        return lazy.get()

    def resolve_maybe(maybe: Maybe[int]) -> int:
        return maybe.value

    assert resolve_lazy(Left(1).to_lazy()) == 1
    assert resolve_maybe(Left(1).to_lazy().to_maybe()) == 1

    assert resolve_lazy(Right(1).to_lazy()) == 1
    assert resolve_maybe(Right(1).to_lazy().to_maybe()) == 1

    return True


# Generated at 2022-06-12 05:03:15.429703
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:03:22.452516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # call method to_lazy() on Right[A] and test if result is of type Lazy[A]
    assert type(Right(5).to_lazy()) == Lazy
    assert Right(5).to_lazy().lazy_value() == 5
    # call method to_lazy() on Left[A] and test if result is of type Lazy[A]
    assert type(Left("error").to_lazy()) == Lazy
    assert Left("error").to_lazy().lazy_value() == "error"


# Generated at 2022-06-12 05:03:24.512411
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value() == 1
    assert Left('err').to_lazy().value() == 'err'


# Generated at 2022-06-12 05:03:29.829364
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.

    :return: None
    :rtype: NoneType
    """
    assert Right(1).to_lazy().value() == 1
    assert Right(1).to_lazy() == Right(1).map(lambda x: Lazy(lambda: x)).value



# Generated at 2022-06-12 05:04:03.650069
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    item = Right(1)
    lazy = item.to_lazy()
    assert lazy.evaluate() == 1

    item = Left(1)
    lazy = item.to_lazy()
    assert lazy.evaluate() == 1

# Generated at 2022-06-12 05:04:06.048361
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test = Right(100)
    test_value = test.to_lazy().get()
    assert test_value == 100



# Generated at 2022-06-12 05:04:12.512901
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    try:
        from pymonet.lazy import Lazy
    except ImportError:
        return
    result = Left(3).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 3
    result = Right(3).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 3

# Generated at 2022-06-12 05:04:16.254782
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left([5]).to_lazy() == Lazy(lambda: [5])


# Generated at 2022-06-12 05:04:27.324210
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.functions import compose, identity, zero

    integer_boxed = Box(1)
    string_boxed = Box('First')
    integer_lazy = Lazy(lambda: 1)
    string_lazy = Lazy(lambda: 'First')
    integer_tried = Try(1)
    string_tried = Try('First')
    integer_maybe = Maybe.just(1)
    string_maybe = Maybe.just('First')
    integer_maybe_nothing = Maybe.nothing()
    integer_validation = Validation.success(1)
    string_valid

# Generated at 2022-06-12 05:04:33.469256
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy_func = Either.to_lazy(Left(Box("test")))
    assert isinstance(lazy_func, Lazy)
    assert isinstance(lazy_func.value(), Box)
    assert lazy_func.value().value == "test"

    lazy_func2 = Either.to_lazy(Right(Box("test")))
    assert isinstance(lazy_func2, Lazy)
    assert isinstance(lazy_func2.value(), Box)
    assert lazy_func2.value().value == "test"


# Generated at 2022-06-12 05:04:41.317576
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 2) == Right(2).to_lazy()
    assert Lazy(lambda: 2) == Left(2).to_lazy()
    assert Lazy(lambda: Maybe.just(2)) == Right(Maybe.just(2)).to_lazy()
    assert Lazy(lambda: Maybe.just(2)) == Left(Maybe.just(2)).to_lazy()


# Generated at 2022-06-12 05:04:44.715825
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().get() == 1
    assert Right(1).to_lazy().get() == 1



# Generated at 2022-06-12 05:04:51.338505
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # create some functions which takes numbers and returns either
    f = lambda x: Right(lambda y: y + x)
    g = lambda x: Right(x * 2)
    # test their composition with apply operator
    a = Right(2)
    b = Right(4)
    c = a.ap(g)
    d = f(2).ap(b)
    assert c.value == 8
    assert d.value == 6



# Generated at 2022-06-12 05:04:55.005785
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_object = Right(5)
    lazy_object = test_object.to_lazy()
    assert lazy_object.get() == 5
    assert lazy_object.map(lambda x: x * 2).get() == 10


# Generated at 2022-06-12 05:05:30.219157
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().force() == 1
    error = AssertionError('some error')
    assert Either(error).to_lazy().force() == error



# Generated at 2022-06-12 05:05:35.671424
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    l = Left(1)
    l_lazy = l.to_lazy()
    assert callable(l_lazy.value)
    assert l_lazy.value() == l.value

    r = Right(2)
    r_lazy = r.to_lazy()
    assert callable(r_lazy.value)
    assert r_lazy.value() == r.value


# Generated at 2022-06-12 05:05:41.210388
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for to_lazy method of class Either"""
    from pymonet.lazy import Lazy

    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:05:44.082418
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().evaluate() == 1
    assert Right("Hello").to_lazy().evaluate() == "Hello"


# Generated at 2022-06-12 05:05:47.482192
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # Given
    either = Left(6)

    # When
    lazy = either.to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.evaluate() == 6


# Generated at 2022-06-12 05:05:52.762284
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    input = Right(1)
    result = input.to_lazy()
    assert Lazy(lambda: input.value) == result

    input = Left(1)
    result = input.to_lazy()
    assert Lazy(lambda: input.value) == result


# Generated at 2022-06-12 05:05:56.110749
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert (Either(Try(42)).to_lazy() == Lazy(lambda: Try(42))) is True

# Generated at 2022-06-12 05:05:59.063701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Right(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1



# Generated at 2022-06-12 05:06:03.034042
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either(True).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-12 05:06:05.963883
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    e = Right(1)
    lazy = e.to_lazy()
    assert lazy == Lazy(lambda:1)


# Generated at 2022-06-12 05:06:46.388586
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_box() == Box(1)
    assert Right(1).to_box() == Box(1)
    assert Left(1).to_try() == Try(1, is_success=False)
    assert Right(1).to_try() ==  Try(1, is_success=True)

# Generated at 2022-06-12 05:06:48.969698
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(5).to_lazy(), Either) is True
    assert isinstance(Right(5).to_lazy(), Either) is True


# Generated at 2022-06-12 05:06:56.657053
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    e = Left(None)
    l = e.to_lazy()
    assert isinstance(l, Lazy)
    assert callable(l.get())
    assert e.value == l.get()()

    e = Right(None)
    l = e.to_lazy()
    assert isinstance(l, Lazy)
    assert callable(l.get())
    assert e.value == l.get()()


# Generated at 2022-06-12 05:06:58.219994
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy() == Lazy(lambda: Either.value)



# Generated at 2022-06-12 05:07:02.973618
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # check that to_lazy return right value
    right_value = Either.right(5).to_lazy()
    assert right_value.value() == 5

    # check that to_lazy return value of left
    left_value = Either.left(10).to_lazy()
    assert left_value.value() == 10


# Generated at 2022-06-12 05:07:05.117582
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:07:06.986291
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().force() == 1
    assert Left(2).to_lazy().force() == 2


# Generated at 2022-06-12 05:07:09.519063
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f():
        pass

    assert Left(2).to_lazy().value() == 2
    assert Right(f).to_lazy().value() == f



# Generated at 2022-06-12 05:07:11.192750
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:07:18.063382
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    # Test Left Maybe
    lazy_either = Maybe.nothing().to_lazy()
    assert isinstance(lazy_either, Lazy)
    assert lazy_either.value() == Maybe.nothing()

    # Test Right Maybe
    lazy_either = Maybe.just(1).to_lazy()
    assert isinstance(lazy_either, Lazy)
    assert lazy_either.value() == Maybe.just(1)


# Generated at 2022-06-12 05:08:03.437199
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(7).to_lazy().force() == 7

    assert Right(7).to_lazy().force() == 7


# Generated at 2022-06-12 05:08:06.761253
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> from pymonet.either import Right
    >>> from pymonet.lazy import Lazy
    >>> from pymonet.lazy import Lazy
    >>> Right(1).to_lazy()
    Lazy(function)
    >>> Right(1).to_lazy() == Lazy(lambda: 1)
    True
    """
    pass


# Generated at 2022-06-12 05:08:08.362926
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 05:08:12.838191
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:08:15.235359
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ Unit test for method to_lazy of class Either """
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 'hello') == Right('hello').to_lazy()

# Generated at 2022-06-12 05:08:20.037314
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    # Test when Either is Right
    assert Right(10).to_lazy() == Lazy(lambda: 10)

    # Test when Either is Left
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Unit test to_try of class Either

# Generated at 2022-06-12 05:08:22.591723
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-12 05:08:26.949789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:08:34.369177
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    lazy_left_either1 = Left(1).to_lazy()
    assert isinstance(lazy_left_either1, Lazy)
    assert lazy_left_either1.get() == 1

    lazy_right_either1 = Right(1).to_lazy()
    assert isinstance(lazy_right_either1, Lazy)
    assert lazy_right_either1.get() == 1

    lazy_right_either_box = Right(Box(1)).to_lazy()
    assert isinstance(lazy_right_either_box, Lazy)
    assert lazy_right_either_box.get() == Box(1)


# Generated at 2022-06-12 05:08:37.958215
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # When : call to_lazy method
    actual = Right(1).to_lazy()

    # Then : return Lazy with stored value
    assert actual == Lazy(lambda: 1)
