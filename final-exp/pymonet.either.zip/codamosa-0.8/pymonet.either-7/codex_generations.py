

# Generated at 2022-06-12 04:58:56.426008
# Unit test for method case of class Either
def test_Either_case():
    """Test for case method of Either."""
    def to_lower_case(value):
        return value.lower()

    def to_upper_case(value):
        return value.upper()

    def to_lower_case_error(value):
        return value('lower')

    assert Either('Test').case(to_lower_case_error, to_lower_case) == 'test'
    assert Either('Test').case(to_lower_case, to_upper_case) == 'TEST'
    assert Either('Test').case(to_upper_case, to_lower_case) == 'TEST'


# Generated at 2022-06-12 04:58:58.955626
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert not (Either(1) == Either(2))



# Generated at 2022-06-12 04:59:01.859795
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3).__eq__(Right(3)) == True
    assert Left(3).__eq__(Left(3)) == True
    assert Left(3).__eq__(Right(3)) == False


# Generated at 2022-06-12 04:59:08.260403
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_equal = Left('content') == Left('content')
    assert left_equal is True

    left_not_equal = Left('content') == Left('other content')
    assert left_not_equal is False

    right_equal = Right('content') == Right('content')
    assert right_equal is True

    right_not_equal = Right('content') == Right('other content')
    assert right_not_equal is False

    left_equal_right = Left('content') == Right('content')
    assert left_equal_right is False



# Generated at 2022-06-12 04:59:18.102493
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.lazy import Lazy
    from pymonet.try_ import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    left_value = 1
    left = Left(left_value)
    assert left == Left(left_value)
    assert left != Left(left_value + 1)
    assert left != Right(left_value)
    assert left != Lazy(lambda: left_value)
    assert left != Try(left_value)
    assert left != Validation.fail([left_value])
    assert left != Maybe(left_value)
    right_value = 'something'
    right = Right(right_value)
    assert right == Right(right_value)
    assert right != Right(right_value + '_another')

# Generated at 2022-06-12 04:59:27.792773
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    first_value = 5
    second_value = 12

    first_left = Left(first_value)
    second_left = Left(second_value)
    third_left = Left(first_value)

    first_right = Right(first_value)
    second_right = Right(second_value)
    third_right = Right(first_value)

    left_right = Left(first_value)
    right_left = Right(first_value)

    assert first_left == third_left
    assert first_left != second_left
    assert first_right == third_right
    assert first_right != second_right
    assert first_left != first_right
    assert first_left != left_right

# Generated at 2022-06-12 04:59:31.464457
# Unit test for method case of class Either
def test_Either_case():
    left = Left(5)
    right = Right(5)

    assert left.case(
        error=lambda x: x + 1,
        success=lambda x: x * 2
    ) == 6
    assert right.case(
        error=lambda x: x + 1,
        success=lambda x: x * 2
    ) == 10


# Generated at 2022-06-12 04:59:35.597753
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    from pymonet.lazy import Lazy

    assert Left('left').to_lazy() == Lazy(lambda: 'left')
    assert Right('right').to_lazy() == Lazy(lambda: 'right')


# Generated at 2022-06-12 04:59:41.389090
# Unit test for method case of class Either
def test_Either_case():
    def error(value):
        return value

    def success(value):
        return value

    def either_case(either):
        return either.case(error, success)

    assert either_case(Left(None)) == None
    assert either_case(Right(None)) == None

    assert either_case(Left('error')) == 'error'
    assert either_case(Right('success')) == 'success'

# Generated at 2022-06-12 04:59:44.349193
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left([1, 2]) == Left([1, 2])
    assert Right([1, 2]) == Right([1, 2])
    assert Left([1, 2]) != Right([1, 2])

# Generated at 2022-06-12 04:59:49.322405
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Right(3).to_lazy()

    assert lazy.value() == 3
    assert lazy.__class__ == Lazy

# Generated at 2022-06-12 04:59:52.462877
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy().get() == 2
    assert Right(2).to_lazy().get() == 2


# Generated at 2022-06-12 04:59:57.075857
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    g = lambda x: x + x
    assert Lazy(lambda: 3).map(g).result() == 6
    assert Right(3).to_lazy().map(g).result() == 6

# Generated at 2022-06-12 05:00:00.671267
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test method to_lazy of class Either
    """
    assert type(Left(1).to_lazy()) == Lazy
    assert type(Right(1).to_lazy()) == Lazy


# Generated at 2022-06-12 05:00:03.832343
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def lazy_func():
        return 5
    assert Right(lazy_func()).to_lazy() == Lazy(lambda: 5)
    assert Left(lazy_func()).to_lazy() == Left(5)

# Generated at 2022-06-12 05:00:06.306646
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Either('left').to_lazy() == Lazy(lambda: 'left')


# Generated at 2022-06-12 05:00:09.131797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    rigth = Right(3).to_lazy()
    assert rigth == Lazy(lambda: 3)
    left = Left(3).to_lazy()
    assert left == Lazy(lambda: 3)


# Generated at 2022-06-12 05:00:12.795819
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(0).to_lazy() == Lazy(lambda: 0)
    assert Left(0).to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-12 05:00:15.573211
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:00:21.880914
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'Result'

    lazy = Right(f).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.run() == 'Result'
    assert lazy.to_maybe().is_nothing()

    lazy = Left(f).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.run() == f
    assert lazy.to_maybe().is_nothing()


# Generated at 2022-06-12 05:00:31.116907
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Either(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Either(Lazy(lambda: 1)).to_lazy() == Lazy(lambda: Lazy(lambda: 1))



# Generated at 2022-06-12 05:00:35.069038
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    unit = Lazy(lambda: 42)
    assert Left(42).to_lazy() == unit
    assert Right(42).to_lazy() == unit



# Generated at 2022-06-12 05:00:39.681505
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert either_a.to_lazy() == Lazy(lambda: 'A')
    assert either_b.to_lazy() == Lazy(lambda: 'B')


# Generated at 2022-06-12 05:00:43.432536
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    from pymonet.lazy import Lazy

    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:00:46.963481
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Either.right(1).to_lazy()
    assert Lazy(lambda: None) == Either.left(1).to_lazy()

# Generated at 2022-06-12 05:00:50.078632
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy_something = Right(42).to_lazy()
    assert lazy_something.value() == 42
    lazy_nothing = Left(42).to_lazy()
    assert lazy_nothing.value() == 42


# Generated at 2022-06-12 05:00:52.222057
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    composed_function = Lazy(lambda: lambda x: x + 1).apply(Lazy(lambda: 2)).force
    assert composed_function() == 3

    return True


# Generated at 2022-06-12 05:00:55.173516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either = Right(5)
    lazy = either.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() == 5

    either = Left('error')
    lazy = either.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() == 'error'


# Generated at 2022-06-12 05:00:58.482018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:02.314094
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Right(11).to_lazy() == Lazy(lambda: 11)
    assert Left(11).to_lazy() == Lazy(lambda: 11)


# Generated at 2022-06-12 05:01:08.902847
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy_box = Lazy(Box(15))
    lazy_left = Lazy(Left(15))
    lazy_right = Lazy(Right(15))

    assert lazy_left.unbox() == lazy_right.unbox() == lazy_box.unbox() == 15


# Generated at 2022-06-12 05:01:18.583022
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left([1, 2]).to_lazy(), Lazy)
    assert Left([1, 2]).to_lazy().get() == [1, 2]

    assert isinstance(Left(10).to_lazy(), Lazy)
    assert Left(10).to_lazy().get() == 10

    assert isinstance(Left("test").to_lazy(), Lazy)
    assert Left("test").to_lazy().get() == "test"

    assert isinstance(Left({'a': 1, 'b': 2}).to_lazy(), Lazy)
    assert Left({'a': 1, 'b': 2}).to_lazy().get() == {'a': 1, 'b': 2}

    assert isinstance(Right([1, 2]).to_lazy(), Lazy)

# Generated at 2022-06-12 05:01:21.945419
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.Right(10).to_lazy() == Lazy(lambda: 10)
    assert Either.Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:01:25.690596
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either.to_lazy(Right(1)), Lazy)
    assert isinstance(Either.to_lazy(Right(1)).value_thunk(), int)
    assert Either.to_lazy(Right(1)).value_thunk() == 1



# Generated at 2022-06-12 05:01:28.685018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    x = Either.to_lazy(Left(2))
    x = Either.to_lazy(Right(2))

    assert x.value() == 2

# Generated at 2022-06-12 05:01:31.905612
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:34.799426
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for class Either"""
    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert Left(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:01:39.284660
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def add(x):
        return lambda y: y + x

    assert Right(add(1)).to_lazy() == Lazy(add(1))
    assert Left(add(1)).to_lazy() == Lazy(add(1))


# Generated at 2022-06-12 05:01:43.432780
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = 'test'
    either = Left(value)
    lazy = either.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.score() == value
    assert lazy.__str__() == "Lazy({0})".format(value)


# Generated at 2022-06-12 05:01:45.647174
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    def unit() -> Lazy[int]:
        return Right(10).to_lazy()

    assert unit().force() == 10

# Generated at 2022-06-12 05:01:50.403074
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right('Monad').to_lazy() == Lazy(lambda: 'Monad')
    assert Left('Monad').to_lazy() == Lazy(lambda: 'Monad')


# Generated at 2022-06-12 05:01:55.870607
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    maybe = Lazy(lambda: "Hi")

    assert Left("Text").to_lazy() == Maybe.nothing()
    assert Right("Text").to_lazy() == Maybe.just("Text")

# Generated at 2022-06-12 05:01:59.358262
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyValueError

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:02:01.690797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def lazy():
        return 1

    assert Lazy(lazy) == Right(1).to_lazy()



# Generated at 2022-06-12 05:02:06.330781
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(15).to_lazy().get() == 15
    assert Either(15).to_lazy().map(lambda x: x + 1).get() == 16
    assert Either(15).to_lazy().bind(lambda x: Either(x + 1)).to_lazy().get() == 16
    assert Either(15).to_lazy().ap(Either(lambda x: x + 1)).get() == 16



# Generated at 2022-06-12 05:02:10.614670
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Right(5).to_lazy()
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert isinstance(result, Lazy)
    assert result.value is not None
    assert isinstance(result.value, Box)
    assert result.value.value == 5


# Generated at 2022-06-12 05:02:14.166746
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Create lazy monad
    lazy = Either(3).to_lazy()
    # force lazy evaluation and get value
    value = lazy.force()

    # Check if value is correct
    assert value == 3


# Generated at 2022-06-12 05:02:19.863569
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    # Check if we can do to_lazy of Either
    assert isinstance(Right(10).to_lazy(), type(Right(10).to_lazy()))
    assert isinstance(Right(10).to_lazy(), type(Left(10).to_lazy()))

    # Check is returned valid Lazy structure
    from pymonet.lazy import Lazy
    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)

    # check if value stored in Lazy is correct
    assert Right(10).to_lazy().get() == 10
    assert Left(10).to_lazy().get() == 10



# Generated at 2022-06-12 05:02:28.588150
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left([0]).to_lazy() == Lazy(lambda: [0])
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(0).to_lazy() == Lazy(lambda: 0)
    assert Try(1, True).to_lazy() == Lazy(lambda: 1)
    assert Try(1, False).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy()

# Generated at 2022-06-12 05:02:32.213629
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy()(Right(10)) == Lazy(lambda: 10)
    assert Either.to_lazy()(Left(10)) == Lazy(lambda: 10)



# Generated at 2022-06-12 05:02:42.628984
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('2').to_lazy() == Lazy(lambda: '2')
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Left('2').to_lazy() == Lazy(lambda: '2')
    assert Either(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Either(Box('2')).to_lazy() == Lazy(lambda: Box('2'))

# Generated at 2022-06-12 05:02:50.200189
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    # Test for Left Either
    left = Left(Validation.fail(["error1", "error2"]))
    assert isinstance(left.to_lazy(), Lazy)
    assert left.to_lazy().__repr__() == "Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x7f6e26572158>)"
    assert left.to_lazy().value == Validation.fail(["error1", "error2"])

    # Test for Right Either
    right = Right(Validation.success(100))
    assert isinstance(right.to_lazy(), Lazy)
    assert right.to_lazy().__

# Generated at 2022-06-12 05:02:54.892285
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Left(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Right(Box(1)).to_lazy() == Lazy(lambda: Box(1))


# Generated at 2022-06-12 05:02:58.029009
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Right(5).to_lazy()
    assert Lazy(lambda: 5) == Left(5).to_lazy()

# Generated at 2022-06-12 05:03:05.778369
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import pytest

    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert None == Left(1).to_lazy().value()
    assert 1 == Right(1).to_lazy().value()
    assert None == Lazy(None).value()


# Generated at 2022-06-12 05:03:11.925054
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    lazy_maybe_left = Either(1).to_lazy()
    assert isinstance(lazy_maybe_left, Lazy)
    assert lazy_maybe_left() == 1

    lazy_maybe_right = Either("abc").to_lazy()
    assert isinstance(lazy_maybe_right, Lazy)
    assert lazy_maybe_right() == "abc"



# Generated at 2022-06-12 05:03:15.189779
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 'value'

    assert Either(Right('value')).to_lazy() == Lazy(func)

# Generated at 2022-06-12 05:03:19.144745
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(
        Left(5).to_lazy(),
        Lazy
    )
    assert isinstance(
        Right(5).to_lazy(),
        Lazy
    )


# Generated at 2022-06-12 05:03:22.412050
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    assert Right('john').to_lazy().value() == 'john'
    assert Left('john').to_lazy().value() == 'john'


# Generated at 2022-06-12 05:03:25.555313
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(42).to_lazy() == Lazy(lambda: 42)
    assert Left(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-12 05:03:33.543355
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(5).to_lazy()
    assert lazy == Lazy(lambda: 5)
    assert lazy.value() == 5



# Generated at 2022-06-12 05:03:38.202520
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return "result"

    assert Lazy(func) == Left("error").to_lazy()
    assert Lazy(func) == Right("result").to_lazy()



# Generated at 2022-06-12 05:03:39.973317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(a, b):
        return a + b
    assert Either(1).to_lazy().map(add, 2).get() == 3

# Generated at 2022-06-12 05:03:41.949285
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right("value").to_lazy().value() == "value"
    assert Left("error").to_lazy().value() == "error"



# Generated at 2022-06-12 05:03:43.781851
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('error').to_lazy().value() == 'error'
    assert Right(12).to_lazy().value() == 12


# Generated at 2022-06-12 05:03:50.622550
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    left = Left(Validation.success('foo'))
    right = Right(Validation.success('foo'))

    assert left.to_lazy() == Lazy(lambda: Validation.success('foo'))
    assert right.to_lazy() == Lazy(lambda: Validation.success('foo'))



# Generated at 2022-06-12 05:03:54.765949
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def f():
        return Validation.success(1)

    assert f() == f().to_lazy().eval()

# Generated at 2022-06-12 05:04:01.791621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Lazy.unit(3)
    assert Lazy(lambda: 3) == Lazy.unit(Try(3))
    assert Lazy(lambda: 3) == Lazy.unit(Box(3))
    assert Lazy(lambda: 3) == Lazy.unit(Maybe.just(3))
    assert Lazy(lambda: 3) == Lazy.unit(Right(3))
    assert Lazy(lambda: 3) == Lazy.unit(Left(3))


# Generated at 2022-06-12 05:04:04.245668
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert (Right(42)).to_lazy().value() == 42
    assert (Left(42)).to_lazy().value() == 42



# Generated at 2022-06-12 05:04:09.395238
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Right(10).to_lazy() == Lazy(lambda : 10)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right.empty().to_lazy() == Lazy(lambda: None)
    assert Left.empty().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:04:17.479162
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    either = Right(7)

    # When
    result = either.to_lazy()

    # Then
    assert isinstance(result, Lazy)
    assert result.value() == 7



# Generated at 2022-06-12 05:04:20.530003
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    expected = "A either lazy value"
    result = Right("A either lazy value")\
        .to_lazy()\
        .force()
    assert expected == result

# Generated at 2022-06-12 05:04:24.037570
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Either.to_lazy(Left(1)) == Either.to_lazy(Right(1))


# Generated at 2022-06-12 05:04:24.681724
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert True

# Generated at 2022-06-12 05:04:30.124854
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functions import identity

    convert_to_lazy = identity | Right(5).to_lazy

    actual = convert_to_lazy()
    expected = 5

    assert actual == expected


# Generated at 2022-06-12 05:04:32.573571
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:36.324858
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(True).to_lazy() == Lazy(lambda: True)
    assert Left(False).to_lazy() == Lazy(lambda: False)



# Generated at 2022-06-12 05:04:39.487042
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Box(10)) == Either(10).to_lazy()


# Generated at 2022-06-12 05:04:43.707821
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return "Right"

    assert Either(func).to_lazy().evaluate() == Either(Lazy(func).evaluate()).to_lazy().evaluate()



# Generated at 2022-06-12 05:04:54.222682
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    result = Right(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1

    result = Left(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1

    result = Right(1).to_try()
    assert isinstance(result, Try)
    assert result.value == 1
    assert result.is_success

    result = Left(1).to_try()
    assert isinstance(result, Try)
    assert result.value == 1
    assert not result.is_success

    result = Right(1).to_validation()

# Generated at 2022-06-12 05:05:03.424397
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:05:07.000744
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: "foo") == Right("foo").to_lazy()


# Generated at 2022-06-12 05:05:10.451158
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    assert Either.Right(4).to_lazy().eval() == 4
    assert Either.Left(4).to_lazy().eval() == 4



# Generated at 2022-06-12 05:05:17.513734
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from unittest import TestCase
    from pymonet.lazy import Lazy

    left = Left[int](10)
    case = left.to_lazy().case(lambda value: value, lambda value: value + 1)
    assert True == isinstance(case, Lazy)
    assert 10 == case.eval()

    right = Right[int](10)
    case = right.to_lazy().case(lambda value: value, lambda value: value + 1)
    assert True == isinstance(case, Lazy)
    assert 11 == case.eval()



# Generated at 2022-06-12 05:05:18.858799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert either.to_lazy() == lazy(either.value)


# Generated at 2022-06-12 05:05:24.386657
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Create instance of Either and Right with value 5. Call to_lazy method and check if Lazy object is create.
    """

    from pymonet.lazy import Lazy

    either = Either(5)
    laz = either.to_lazy()

    assert isinstance(laz, Lazy)


# Generated at 2022-06-12 05:05:28.456092
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test if strict value returned by Either is lazy value
    """
    from pymonet.lazy import Lazy

    assert isinstance(Right("123").to_lazy(), Lazy)
    assert isinstance(Left("123").to_lazy(), Lazy)


# Generated at 2022-06-12 05:05:32.039730
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:05:38.914051
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_of_success = Lazy(lambda: 10)
    lazy_of_success_either = Right(10).to_lazy()

    assert lazy_of_success == lazy_of_success_either

    lazy_of_failure = Lazy(lambda: 'failure')
    lazy_of_failure_either = Left('failure').to_lazy()

    assert lazy_of_failure == lazy_of_failure_either



# Generated at 2022-06-12 05:05:41.738225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Left(10).to_lazy() == Right(10).to_lazy()

# Unit teset for method ap of class Either

# Generated at 2022-06-12 05:05:57.776803
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    either_instance = Right(45)

    # When
    result = either_instance.to_lazy()

    # Then
    assert result.value() == 45



# Generated at 2022-06-12 05:06:09.769294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import compose

    assert Right(15).to_lazy() == Lazy(lambda: 15)
    assert Left("error").to_lazy() == Lazy(lambda: "error")

    f = compose(lambda x: x + 1, lambda x: str(x))
    assert Right(3).to_lazy().map(f) == Lazy(lambda: "4")
    assert Left("error").to_lazy().map(f) == Lazy(lambda: "error")

    f = compose(lambda x: x + 1, lambda x: str(x))
    assert Right(3).to_lazy().bind(lambda value: Lazy(f(value))) == Lazy(lambda: "4")
    assert Left("error").to_lazy().bind

# Generated at 2022-06-12 05:06:11.832070
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(1)
    assert right.to_lazy().value() == 1
    left = Left(1)
    assert left.to_lazy().value() == 1


# Generated at 2022-06-12 05:06:15.533376
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    either = Right(value).to_lazy()

    assert isinstance(either, Lazy)
    assert either.force() == value

# Generated at 2022-06-12 05:06:18.487605
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    test_value = Either(10).to_lazy()
    assert callable(test_value.value)
    assert test_value.value() == 10



# Generated at 2022-06-12 05:06:20.400299
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:27.566571
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """ Unit test for method to_lazy of class Either """
    from pymonet.lazy import Lazy

    def foo():
        return "foo"

    assert Right(foo).to_lazy() == Lazy(foo)
    assert Right(foo()).to_lazy() == Lazy(foo)
    assert Left(foo).to_lazy() == Lazy(foo)
    assert Left(foo()).to_lazy() == Lazy(foo)


# Generated at 2022-06-12 05:06:36.988098
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)

    assert Left(1).to_lazy().force() == 1
    assert Right(1).to_lazy().force() == 1

    assert Left("error").to_lazy().force() == "error"
    assert Right("error").to_lazy().force() == "error"

    assert Left(Box(1)).to_lazy() == Lazy(lambda: Box(1))

# Generated at 2022-06-12 05:06:41.886554
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    from pymonet.lazy import Lazy
    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert Left(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:06:45.847500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_left = Left(5).to_lazy()
    assert isinstance(lazy_left, Lazy)
    assert lazy_left() == 5

    lazy_right = Right(5).to_lazy()
    assert isinstance(lazy_right, Lazy)
    assert lazy_right() == 5

# Generated at 2022-06-12 05:07:12.514969
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    value = 1
    either = Right(value)
    assert either.to_lazy() == Lazy(lambda: value)
    either = Left(value)
    assert either.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:07:22.076256
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    clear = lambda x: x + 3
    right = Right(2)
    lazy = right.to_lazy()
    assert lazy.get() == right.value
    assert lazy.map(clear).get() == right.bind(clear).value
    assert lazy.map(clear).get() == right.ap(Lazy(clear)).value
    left = Left(2)
    lazy_left = left.to_lazy()
    assert lazy_left.get() == left.value
    assert lazy_left.map(clear).get() == left.bind(clear).value
    assert lazy_left.map(clear).get() == left.ap(Lazy(clear)).value
    assert lazy_left.ap(Lazy(clear)).get() == left.value

# Generated at 2022-06-12 05:07:23.939200
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either(1).to_lazy()
    assert lazy == Lazy(lambda: 1)



# Generated at 2022-06-12 05:07:30.209948
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
     Test call to #to_lazy() method of Either class.
    """

    value = Either.unit(10)
    assert value == 10
    value = Either.unit('string')
    assert value == 'string'
    value = Either.unit(None)
    assert value is None
    value = Either.unit([1, 2, 3])
    assert value == [1, 2, 3]
    value = Either.unit({'key': 'value'})
    assert value == {'key': 'value'}
    value = Either.unit((1, 2, 3, 4))
    assert value == (1, 2, 3, 4)

# Generated at 2022-06-12 05:07:32.527213
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange
    either_value = Left("fail")

    # Act
    lazy_instance = either_value.to_lazy()
    lazy_result = lazy_instance.get()

    # Assert
    assert lazy_result == "fail"

# Generated at 2022-06-12 05:07:34.794723
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(3).to_lazy().value() == 3
    assert Left('Error').to_lazy().value() == 'Error'

# Generated at 2022-06-12 05:07:37.906862
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add_one(x): return x + 1
    def foo(): return 5

    assert Right(foo).to_lazy().map(add_one).get()() == 6
    assert Left(foo).to_lazy().map(add_one).get()() == 5


# Generated at 2022-06-12 05:07:46.027664
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def inc(x):
        return x + 1

    def add(x, y):
        return x + y

    # Check Right(5).to_lazy()
    assert isinstance(Right(5).to_lazy(), Lazy)
    assert isinstance(Right(5).to_lazy(), Functor)
    assert isinstance(Right(5).to_lazy(), Applicative)
    assert Right(5).to_lazy().__value__() == 5

    # Check Right(5).to_lazy().map(inc)
    assert Right(5).to_lazy().map(inc).__value__() == 6
    # Check Right(5).to_l

# Generated at 2022-06-12 05:07:48.543235
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(4).to_lazy() == Lazy(lambda: 4)
    assert Right(4).to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 05:07:49.660422
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:08:48.149036
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(5)) == Lazy(lambda: 5)


# Generated at 2022-06-12 05:08:50.565499
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().monad() == Left(1).value
    assert Right(1).to_lazy().monad() == 1
