

# Generated at 2022-06-12 04:58:58.493608
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either._Either__to_lazy == Lazy
    assert hasattr(Either, '_Either__to_lazy')

# Generated at 2022-06-12 04:59:03.406735
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(-1)
    assert Either(-1) != Right(-1) == Left(-1)
    assert Either(-1) != 1 == -1
    assert Left(1) == Left(1) == Either(1)
    assert Right(1) == Right(1) == Either(1)
    assert not (Left(1) == Left(-1))


# Generated at 2022-06-12 04:59:07.586257
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Assert that __eq__ method of Either works as expected.
    """
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)
    assert Left(2) != Right(2)
    assert Left(1) != None



# Generated at 2022-06-12 04:59:10.547717
# Unit test for method case of class Either
def test_Either_case():
    assert Right(2).case(lambda x: x, lambda x: x ** 2) == 4
    assert Left(None).case(lambda _: 'error', lambda _: 'success') == 'error'



# Generated at 2022-06-12 04:59:15.618199
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) == Right(1)
    assert Either(1) == Left(1)

    assert Either(1) != Either(2)
    assert Either(1) != Right(2)
    assert Either(1) != Left(2)



# Generated at 2022-06-12 04:59:23.407417
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test function test_Either_to_lazy
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    box_value = Box(1)

    lazy_value = Either.to_lazy(box_value)

    assert isinstance(lazy_value, Lazy)
    assert lazy_value.eval() == box_value.value


# Generated at 2022-06-12 04:59:25.751031
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Right(1)



# Generated at 2022-06-12 04:59:30.192657
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 1, lambda x: x * 2) == 2
    assert Right(1).case(lambda x: x + 1, lambda x: x * 2) == 2


# Generated at 2022-06-12 04:59:34.291602
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Unit test for Either.__eq__
    """

    # Case where Either are equals
    assert Either(2) == Either(2)

    # Case where Either are not equals
    assert not Either(True) == Either(2)
    assert not Either(True) == Either.right(2)


# Generated at 2022-06-12 04:59:44.723675
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Run test of to_lazy method and print error message if result is incorrect.
    """
    from pymonet.lazy import Lazy
    from pymonet.test_utils import check_test_cases

    tests = [
        {
            'test_name': 'Tests if to_lazy returns Lazy monad with function returning previous value',
            'test_inputs': [
                {
                    'test_input': Right('value'),
                    'expected_result': Lazy(lambda: 'value')
                },
                {
                    'test_input': Left('value'),
                    'expected_result': Lazy(lambda: 'value')
                }
            ]
        }
    ]

    check_test_cases(tests, lambda test_input: test_input.to_lazy())



# Generated at 2022-06-12 04:59:51.108590
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    assert Right(5) == Right(5)
    assert Left(5) == Left(5)
    assert Left(5) != Left(6)
    assert Left(5) != Right(5)
    assert Left(5) != Try(5)



# Generated at 2022-06-12 04:59:54.366782
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(4) == Left(4)
    assert Right(4) == Right(4)
    assert Left(4) != Right(4)
    assert Right(4) != Left(4)

# Generated at 2022-06-12 05:00:00.571507
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('a') == Left('a')
    assert Right(1) == Right(1)
    assert Left('a') != Right('a')
    assert Left('a') != Left('b')
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right({}) != Right({'a': 1})


# Generated at 2022-06-12 05:00:03.080391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Right("test").to_lazy()

    assert result == Lazy(lambda: "test")


# Generated at 2022-06-12 05:00:05.894028
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)
    assert left != right
    assert left == Left(1)
    assert right == Right(1)
    assert left != Left(2)
    assert right != Right(2)



# Generated at 2022-06-12 05:00:08.553025
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('error').to_lazy().get() == Lazy(lambda: 'error').get()
    assert Right('value').to_lazy().get() == Lazy(lambda: 'value').get()

# Generated at 2022-06-12 05:00:13.786373
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert not 1 == Left(1)
    assert not Left(1) == 1



# Generated at 2022-06-12 05:00:22.450830
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pymonet.lazy
    import pymonet.monad_try

    assert pymonet.monad_try.Try(1).to_lazy() == pymonet.lazy.Lazy(lambda: 1)
    assert pymonet.monad_try.Try(Right(1)).to_lazy() == pymonet.lazy.Lazy(lambda: 1)
    assert pymonet.monad_try.Try(Right(Right(1))).to_lazy() == pymonet.lazy.Lazy(lambda: 1)
    assert pymonet.monad_try.Try(Left(1)).to_lazy() == pymonet.lazy.Lazy(lambda: 1)


# Generated at 2022-06-12 05:00:27.586551
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != 1
    assert not (Right(1) == 1)



# Generated at 2022-06-12 05:00:32.082463
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    eitherA = Left(1)
    eitherB = Left(1)

    assert eitherA == eitherB
    assert eitherB == eitherA

    eitherA = Right(1)
    eitherB = Right(1)
    eitherC = Left(1)

    assert eitherA == eitherB
    assert eitherB == eitherA

    assert eitherA != eitherC
    assert eitherC != eitherA



# Generated at 2022-06-12 05:00:40.554182
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(10)
    right = Right('ABC')
    left2 = Left(20)
    right2 = Right(100)
    assert left == left
    assert right == right
    assert not left == right
    assert not left == left2
    assert not right == right2



# Generated at 2022-06-12 05:00:42.561357
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(2) == Either(2)
    assert Either(2) != Either(3)


# Generated at 2022-06-12 05:00:45.847144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    val = Either(4).to_lazy()
    assert isinstance(val, Lazy)
    assert val.value() == 4



# Generated at 2022-06-12 05:00:48.621968
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(123) == Left(123)
    assert Left(123) == Right(123) == False
    assert Left(321) == Left(123) == False
    assert Right(123) == Right(123)
    assert Right(123) == Left(123) == False
    assert Right(321) == Right(123) == False



# Generated at 2022-06-12 05:00:55.532619
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Either()
    assert Left(1) == Left(1)
    assert Left(1).__eq__(Right(1)) is False
    assert Left(1).__eq__(1) is False

    # Either().case
    result = Left(1).case(lambda a: 2, lambda b: 3)
    assert result == 2

    result = Right(1).case(lambda a: 2, lambda b: 3)
    assert result == 3

    # Either().ap
    result = Left(1).ap(Right(2))
    assert result == Left(1)

    result = Left(1).ap(Right(lambda a: 2))
    assert result == Left(1)

    result = Right(1).ap(Right(2))
    assert result == Right(2)


# Generated at 2022-06-12 05:00:59.541418
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    x = Left(2)
    y = x.to_lazy()

    assert y == Lazy(lambda: 2)

    x = Right(2)
    y = x.to_lazy()

    assert y == Lazy(lambda: 2)


# Generated at 2022-06-12 05:01:03.305792
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('a') == Left('a')
    assert Right('a') == Right('a')
    assert Left('a') != Right('a')
    assert Left('a') != Right('b')
    assert Left('a') != 'a'



# Generated at 2022-06-12 05:01:07.179625
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)

    assert Right(1) != Left(1)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)

    assert Left('a') != 'b'

# Generated at 2022-06-12 05:01:15.019844
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    print('Test Either - method __eq__')

    assert Left(0) == Left(0)
    assert Left('0') == Left('0')
    assert Left(0) != Left(1)
    assert Left(0) != Right(0)
    assert Left(0) != Right('0')

    assert Right(0) == Right(0)
    assert Right('0') == Right('0')
    assert Right(0) != Right(1)
    assert Right(0) != Left(0)
    assert Right(0) != Left('0')



# Generated at 2022-06-12 05:01:21.183812
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Given
    left_one = Left(1)
    left_one_other = Left(1)
    right_one = Right(1)

    # When
    left_result = left_one.__eq__(left_one_other)
    right_result = right_one.__eq__(left_one_other)

    # Then
    assert left_result is True
    assert right_result is False



# Generated at 2022-06-12 05:01:26.150314
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy1 = Either(1).to_lazy()
    lazy2 = Either('test string').to_lazy()

    assert lazy1.get() == 1
    assert lazy2.get() == 'test string'



# Generated at 2022-06-12 05:01:31.667838
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Right(1).to_lazy().value() == Right(1).value
    assert Left(1).to_lazy().value() == Left(1).value


# Generated at 2022-06-12 05:01:34.627218
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:01:37.827518
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:41.586608
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:44.672540
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().call() == 1
    assert Either("abc").to_lazy().call() == "abc"
    assert Either(1).to_lazy() is not None
    assert Either("abc").to_lazy() is not None



# Generated at 2022-06-12 05:01:53.076345
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Test for Right
    val = Right(Box(1))
    assert val.to_lazy() == Lazy(lambda: 1)
    assert val.to_lazy().map(lambda x: 2 * x) == Lazy(lambda: 2)

    # Test for Left
    val = Left('error')
    assert val.to_lazy() == Lazy(lambda: 'error')
    assert val.to_lazy().map(lambda x: 2 * x) == Lazy(lambda: 'error')


# Generated at 2022-06-12 05:01:55.480729
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad import monad_test
    monad_test(Either, 'to_lazy')



# Generated at 2022-06-12 05:01:57.706233
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 1

    assert Either(1).to_lazy() == Lazy(func)

# Generated at 2022-06-12 05:02:01.650987
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def to_lazy_monad(): return Either(1)
    # Function to call just after lazy computation.
    def success_handler(x: int) -> bool:
        return x == 1
    assert to_lazy_monad().to_lazy().map(success_handler).value()



# Generated at 2022-06-12 05:02:10.492347
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    a = Left(42)
    assert a.to_lazy() == Lazy(lambda: 42)
    a = Right(42)
    assert a.to_lazy() == Lazy(lambda: 42)

    b = Left(42).to_lazy()
    assert b.force() == 42
    b = Right(42).to_lazy()
    assert b.force() == 42



# Generated at 2022-06-12 05:02:15.599556
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    success = Right(1)
    failure = Left(Failure(RuntimeError('Hello!')))

    assert success.to_lazy() == Lazy(lambda: 1)
    assert failure.to_lazy() == Lazy(RuntimeError('Hello!'))



# Generated at 2022-06-12 05:02:23.468295
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def call_me(param: str) -> str:
        return 'call(%s)' % (param)

    def call_me_too(param: str) -> str:
        return 'call_me_too(%s)' % (param)

    x = Right(call_me_too)
    y = Left(call_me)
    assert x.to_lazy() == Lazy(call_me_too)
    assert y.to_lazy() == Lazy(call_me)


# Generated at 2022-06-12 05:02:27.337626
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of class Either.

    :param None:
    :returns: Nothing
    :raises: AssertionError
    """
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('error').to_lazy() == Lazy(lambda: 'error')


# Generated at 2022-06-12 05:02:32.815995
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    from pymonet.lazy import Lazy
    assert Either(0).is_right() == Neither(1).is_right()
    assert Either(0).to_lazy() == Lazy(lambda : 0)
    assert Neither(1).to_lazy() == Lazy(lambda : 1)

# Generated at 2022-06-12 05:02:36.444415
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().evaluate() == 1
    assert Right(1).to_lazy().evaluate() == 1


# Generated at 2022-06-12 05:02:38.669302
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try


# Generated at 2022-06-12 05:02:42.881171
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(3).to_lazy() == Lazy(lambda: 3)
    assert Left(Box(4)).to_lazy() == Lazy(lambda: Box(4))
    assert Right(Box(5)).to_lazy() == Lazy(lambda: Box(5))


# Generated at 2022-06-12 05:02:47.328625
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Scenario 1: left Either to lazy
    left1 = Left(1)
    lazy1 = left1.to_lazy()
    assert lazy1() == 1

    # Scenario 2: right Either to lazy
    right2 = Right(2)
    lazy2 = right2.to_lazy()
    assert lazy2() == 2


# Generated at 2022-06-12 05:02:51.589924
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    right = Right(10)

    assert right.to_lazy() == Lazy(lambda: 10)

    left = Left(20)

    assert left.to_lazy() == Lazy(lambda: 20)



# Generated at 2022-06-12 05:02:57.949399
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(3).to_lazy(), Lazy)
    assert isinstance(Left(3).to_lazy(), Lazy)


# Generated at 2022-06-12 05:03:04.110197
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try_value = Try.success(1)
    lazy_value = try_value.to_lazy()

    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() == 1

# Generated at 2022-06-12 05:03:07.235234
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(2).to_lazy(), Lazy)


# Generated at 2022-06-12 05:03:09.718206
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Function test_Either_to_lazy to test if `to_lazy` method of class Either return a Lazy monad with
    returned value equals to Either value.
    """
    assert Either(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:03:11.931349
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Lazy(4) == Right(4).to_lazy()
    assert Lazy("error") == Left("error").to_lazy()


# Generated at 2022-06-12 05:03:21.713785
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    lazy_right = Right(1).to_lazy()
    assert isinstance(lazy_right, Lazy)
    assert lazy_right.is_computed() is False
    assert lazy_right.force() == 1
    assert lazy_right.is_computed() is True

    lazy_left = Left(1).to_lazy()
    assert isinstance(lazy_left, Lazy)
    assert lazy_left.is_computed() is False
    assert lazy_left.force() == 1
    assert lazy_left.is_computed() is True


# Generated at 2022-06-12 05:03:24.761940
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(42).to_lazy() == Lazy(lambda: 42)
    assert Left(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 05:03:27.580441
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy()._function() == 1
    assert Left(1).to_lazy()._function() == 1


# Generated at 2022-06-12 05:03:35.468008
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Lazy(lambda: 'default') == Either(Try(Box(123))).to_lazy()
    assert Lazy(lambda: 'default') == Either(Try(Box(False))).to_lazy()
    assert Lazy(lambda: 'default') == Either(Try(Box(123))).to_lazy()
    assert Lazy(lambda: 'default') == Either(Try(Box('value'))).to_lazy()
    assert Lazy(lambda: 'default') == Either(Try(Box(None))).to_lazy()

# Generated at 2022-06-12 05:03:39.433813
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().get() == 1
    assert Either(1).to_lazy().get() == 1
    assert Left(1).to_lazy().get() == 1
    assert Right(1).to_lazy().get() == 1



# Generated at 2022-06-12 05:03:53.056794
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    # When
    start = Lazy(lambda: 1).to_either()
    end = Left(1).to_lazy()

    # Then
    assert start == end
    assert start.to_lazy().value() == 1
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1



# Generated at 2022-06-12 05:04:00.180705
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either."""

    from pymonet.lazy import Lazy

    def test_lazy():
        return 'lazy'

    assert Right('something').to_lazy() == Lazy(lambda: 'something')
    assert Left('something').to_lazy() == Lazy(lambda: 'something')
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(Lazy(test_lazy)).to_lazy() == Lazy(lambda: Lazy(test_lazy))



# Generated at 2022-06-12 05:04:03.439139
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().memoize().get() == 1
    assert Left(1).to_lazy().memoize().get() == 1


# Generated at 2022-06-12 05:04:06.317337
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    assert Either(value).to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:04:10.028245
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:13.259510
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:04:14.787058
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(4).to_lazy() == Lazy(lambda: 4)

# Generated at 2022-06-12 05:04:16.759802
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:04:20.329665
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert(Left(5).to_lazy().value() == 5)
    assert(Right(5).to_lazy().value() == 5)


# Generated at 2022-06-12 05:04:23.015797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(3).to_lazy().get() == 3
    assert Right(3).to_lazy().get() == 3


# Generated at 2022-06-12 05:04:40.476448
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Either[int](5).to_lazy(), Lazy)
    assert Either[int](5).value == 5

    assert isinstance(Left[str]('Error').to_lazy(), Lazy)
    assert Left[str]('Error').value == 'Error'



# Generated at 2022-06-12 05:04:45.370773
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Try

    assert Either(Try.fail('Error')).to_lazy() ==\
        Try.fail('Error')
    assert Either(Try.success('Success')).to_lazy() ==\
        Try.success('Success')



# Generated at 2022-06-12 05:04:47.303850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Right(1).to_lazy()

    assert either.value() == 1



# Generated at 2022-06-12 05:04:51.011107
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    result = Lazy(lambda: 1)
    assert Either(1).to_lazy() == result


# Unit tests for method to_box of class Either

# Generated at 2022-06-12 05:04:55.627317
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test for method to_lazy when Either is Right
    from pymonet.lazy import Lazy

    assert Right("test").to_lazy() == Lazy(lambda: "test")
    # Test for method to_lazy when Either is Left
    assert Left("test").to_lazy() == Lazy(lambda: "test")


# Generated at 2022-06-12 05:05:04.562848
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Box(1).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=True).to_lazy() == Lazy(lambda: 1)
    assert Try(1, is_success=False).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:05:08.902902
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(None).to_lazy() == Lazy(lambda: None)
    assert Left(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:05:13.711388
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()


# Generated at 2022-06-12 05:05:17.757808
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import random

    result = random.randint(1, 9)
    assert Right(result).to_lazy() == Lazy(lambda: result)
    assert Left(result).to_lazy() == Lazy(lambda: result)


# Generated at 2022-06-12 05:05:22.333653
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Success

    assert Success(1).to_lazy() == Lazy(lambda: 1)
    assert Success(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:05:57.814740
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    result = Left(1).to_lazy() == Lazy(lambda: 1)
    assert result

    result = Right(2).to_lazy() == Lazy(lambda: 2)
    assert result


# Generated at 2022-06-12 05:06:01.003122
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Either.to_lazy(Right(5))

    assert lazy == Lazy(lambda: 5)



# Generated at 2022-06-12 05:06:04.944850
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(5).to_lazy() == Lazy(lambda: 5)
    assert Left('value').to_lazy() == Lazy(lambda: 'value')
    assert Right('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:06:08.763685
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().force() == 1
    assert Right(1).to_lazy().force() == 1

# Generated at 2022-06-12 05:06:14.111805
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def get_number():
        return 10
    assert isinstance(Left(None).to_lazy().value(), int), "Left should be lazy result of get_number()"
    assert Left(None).to_lazy().value() == get_number(), "Left should be lazy result of get_number()"
    assert Right(10).to_lazy().value() == 10, "Left should be lazy result of get_number()"
    assert isinstance(Right(10).to_lazy().value(), int), "Left should be lazy result of get_number()"


# Generated at 2022-06-12 05:06:20.532480
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_either = Left(3).to_lazy()
    assert isinstance(lazy_either, Lazy)
    assert lazy_either.value() == 3

    lazy_either = Right(4).to_lazy()
    assert isinstance(lazy_either, Lazy)
    assert lazy_either.value() == 4



# Generated at 2022-06-12 05:06:25.294029
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    right = Either.right(100)
    # expect
    assert right.to_lazy().evaluate() == 100
    # because
    left = Either.left(10)
    # expect
    assert left.to_lazy().evaluate() == 10

# Generated at 2022-06-12 05:06:27.462818
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Either.right(2).to_lazy()


# Generated at 2022-06-12 05:06:30.813757
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Right(5).to_lazy()

    if lazy != Lazy(lambda: 5):
        raise ValueError("Unit test for method to_lazy of class Either has been failed")


# Generated at 2022-06-12 05:06:35.613585
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(12).to_lazy() == Lazy(lambda: 12)
    assert Left(14).to_lazy() == Lazy(lambda: 14)
    assert Right(15).to_lazy() == Lazy(lambda: 15)


# Generated at 2022-06-12 05:07:40.242852
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either("a").to_lazy() == Lazy(lambda: "a")
    assert Either(1.0).to_lazy() == Lazy(lambda: 1.0)


# Generated at 2022-06-12 05:07:45.935509
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either to_lazy function.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy

    lazy = Either.Right(5).to_lazy()
    assert lazy.to_maybe().value == 5
    assert isinstance(lazy, Lazy)
    assert lazy.is_computated is False
    assert lazy.value is None

    # Check if computation is working
    Either.Right(5).to_lazy().value

    assert lazy.is_computated is True
    assert lazy.value == 5



# Generated at 2022-06-12 05:07:49.427148
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either('test').to_lazy() == Lazy(lambda: 'test')
    assert Either(1).to_lazy().value() == 1
    assert Either('test').to_lazy().value() == 'test'

# Generated at 2022-06-12 05:07:51.523028
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().compute() == 1
    assert Left(1).to_lazy().compute() == 1


# Generated at 2022-06-12 05:07:53.636881
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Left("error")
    assert either.to_lazy().call("arg1", "arg2") == either

    either = Right("success")
    assert either.to_lazy().call("arg1", "arg2") == either


# Generated at 2022-06-12 05:07:57.212751
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test to_lazy method of class Either"""

    from pymonet.lazy import Lazy

    assert Left(1).to_lazy().get() == 1
    assert Lazy(lambda: 1).to_lazy().get() == 1
    assert Right(1).to_lazy().get() == 1



# Generated at 2022-06-12 05:07:59.584915
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    ex1 = Left(1)
    ex2 = Right(1)

    assert ex1.to_lazy() == Lazy(lambda: 1)
    assert ex2.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:08:01.618935
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def stub():
        return 1

    stub_type = type(stub)

    assert isinstance(Left(1).to_lazy(), stub_type)
    assert isinstance(Right(1).to_lazy(), stub_type)
# End of unit test



# Generated at 2022-06-12 05:08:03.798300
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:08:05.864393
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy().value() == 1
