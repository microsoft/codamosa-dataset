

# Generated at 2022-06-12 04:59:00.006949
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left(1)
    left_2 = Left(2)
    right_1 = Right(1)
    right_2 = Right(2)

    assert left_1 == Left(left_1.value)
    assert not left_1 == Right(left_1.value)
    assert not left_1 == Left(left_2.value)
    assert not left_1 == None

    assert right_1 == Right(right_1.value)
    assert not right_1 == Left(right_1.value)
    assert not right_1 == Right(right_2.value)
    assert not right_1 == None


# Generated at 2022-06-12 04:59:02.964678
# Unit test for method case of class Either
def test_Either_case():
    def method1(e):
        return e + 1

    def method2(e):
        return e - 1
    assert Right(2).case(method1, method2) == 1
    assert Left(2).case(method1, method2) == 3

# Generated at 2022-06-12 04:59:06.575323
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)


# Generated at 2022-06-12 04:59:11.054266
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Left(1) == Left(2)



# Generated at 2022-06-12 04:59:14.686075
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right('a')
    assert left == left
    assert right == right
    assert left != right
    assert left != None


# Generated at 2022-06-12 04:59:17.007857
# Unit test for method case of class Either
def test_Either_case():
    assert Right(1).case(lambda x: 0, lambda x: x + 1) == 2 and\
        Left(1).case(lambda x: x + 1, lambda x: 0) == 2


# Unit tests for method map of class Either

# Generated at 2022-06-12 04:59:28.408219
# Unit test for method case of class Either
def test_Either_case():
    assert Either.case(Left(1), lambda x: x + 1, lambda x: x + 2) == 2
    assert Either.case(Left('a'), lambda x: x + 'b', lambda x: x + 'c') == 'ab'
    assert Either.case(Left([1, 2, 3]), lambda x: ''.join(map(str, x)), lambda x: x + 'c') == '1,2,3'
    assert Either.case(Left(1), lambda x: None, lambda x: x + 2) is None

    assert Either.case(Right(1), lambda x: x + 1, lambda x: x + 2) == 3
    assert Either.case(Right('a'), lambda x: x + 'b', lambda x: x + 'c') == 'ac'

# Generated at 2022-06-12 04:59:30.512811
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(lambda _: None, lambda _: 2) == 2
    assert Either(1).case(lambda _: 2, lambda _: None) == 2


# Generated at 2022-06-12 04:59:34.368546
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(2) == Right(2)
    assert Left(2) == Left(2)
    assert Right(2) == Left(2) is False
    assert Right(0) == Left(2) is False
    assert Left(0) == Right(0) is False



# Generated at 2022-06-12 04:59:38.532946
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Left(3) != Right(3)


# Generated at 2022-06-12 04:59:44.252717
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)

# Generated at 2022-06-12 04:59:51.155303
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def _test_Either___eq__(left_val, right_val):
        left = Left(left_val)
        right = Right(right_val)

        assert left == Left(left_val)
        assert right == Right(right_val)
        assert left != right
        assert right != left

    _test_Either___eq__(1, 2)
    _test_Either___eq__('a', 'ab')



# Generated at 2022-06-12 04:59:55.050404
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(5) == Right(5)
    assert Left(5) == Left(5)
    assert Left(5) != Right(5)
    assert Right(5) != Left(5)
    assert Left(5) != 5


# Generated at 2022-06-12 05:00:00.279191
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # method __eq__ case when instance of all three classes are equal
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    # method __eq__ case when instance of Right and Left are not equal
    assert Left(5) != Right(5)


# Generated at 2022-06-12 05:00:05.780808
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    example_func = lambda: 5
    assert Either(example_func).to_lazy() == Lazy(example_func)
    assert Either(None).to_lazy() == Lazy(lambda: None)
    assert Either(Lazy(lambda: 12)).to_lazy() == Lazy(lambda: 12)



# Generated at 2022-06-12 05:00:11.457370
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left(1)
    left_2 = Left(2)
    left_1_2 = Left(1)

    right_1 = Right(1)
    right_2 = Right(2)
    right_1_2 = Right(1)

    assert left_1 == left_1
    assert left_1 != left_1_2
    assert left_1 != left_2
    assert left_1 != right_1
    assert left_1 != right_2

    assert right_1 == right_1
    assert right_1 != right_1_2
    assert right_1 != right_2
    assert right_1 == left_1_2
    assert right_2 != left_1_2

# Generated at 2022-06-12 05:00:18.108118
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert not Right(1) == Left(1)
    assert not Right(1) == Right(2)
    assert not Left(2) == Right(2)


# Generated at 2022-06-12 05:00:23.518006
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """
    assert isinstance(Either(5).to_lazy(), Lazy)
    assert Either(5).to_lazy().value() == 5
    assert isinstance(Either('string').to_lazy(), Lazy)
    assert Either('string').to_lazy().value() == 'string'
    assert isinstance(Left(5).to_lazy(), Lazy)
    assert Left(5).to_lazy().value() == 5
    assert isinstance(Left('string').to_lazy(), Lazy)
    assert Left('string').to_lazy().value() == 'string'

# Generated at 2022-06-12 05:00:25.368312
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)



# Generated at 2022-06-12 05:00:29.330937
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not Left(1) == Right(2)
    assert Right(1) == Right(1)
    assert not Right(1) == Left(1)



# Generated at 2022-06-12 05:00:41.949717
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)  # type: ignore
    assert Left(1) == Left(1)  # type: ignore
    assert Right("1") == Right("1")  # type: ignore
    assert Left("1") == Left("1")  # type: ignore
    assert Right(None) == Right(None)  # type: ignore
    assert Left(None) == Left(None)  # type: ignore



# Generated at 2022-06-12 05:00:46.765968
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Ensure that Either.to_lazy() will return Lazy instance with function returning value of Either.
    """
    def test_value(value):
        def function():
            return value

        return Lazy(function)

    assert test_value('Hello, world!') == Either('Hello, world!').to_lazy()


# Generated at 2022-06-12 05:00:49.873823
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 2) == Right(2).to_lazy()
    assert Lazy(lambda: 2) == Left(2).to_lazy()


# Generated at 2022-06-12 05:00:53.168522
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 05:01:03.113239
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(True) != Maybe.just(False)
    assert Maybe.just(False) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(False)
    assert Maybe.nothing() != Maybe.just(True)

    assert Box(True) == Box(True)
    assert Box(True) != Box(False)
    assert Box(False) != Maybe.nothing()
    assert Box(False) != Maybe.just(False)  # type: ignore
    assert Box(False) != Maybe.just(True)  # type: ignore


# Generated at 2022-06-12 05:01:09.053443
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(2)
    assert Right(2) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Left(2)
    assert Left(1) != []
    assert Left(1) != 1


# Generated at 2022-06-12 05:01:16.871389
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    left = lambda: Left(1)
    print("Left lazy: " + str(left()))
    assert left().to_lazy() == Lazy(left)
    assert Left("left").to_lazy() == Lazy(lambda: Left("left"))

    right = lambda: Right(1)
    print("Right lazy: " + str(right()))
    assert right().to_lazy() == Lazy(right)
    assert Right("right").to_lazy() == Lazy(lambda: Right("right"))

# Generated at 2022-06-12 05:01:18.975937
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().value() == 5
    assert Left("string").to_lazy().value() == "string"


# Generated at 2022-06-12 05:01:24.089634
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def add_one(value):
        return value + 1

    value = 10
    expected_lazy = Lazy(lambda: value)

    assert(Left(value).to_lazy() == expected_lazy)
    assert(Right(value).to_lazy() == expected_lazy)



# Generated at 2022-06-12 05:01:26.615862
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) != Right(1)
    assert Left(1) != 1
    assert Right(1) != 1
    assert Right(1) == Right(1)


# Generated at 2022-06-12 05:01:35.826335
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right("Hello").to_lazy() == Lazy(lambda: "Hello")



# Generated at 2022-06-12 05:01:44.805668
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_a = Left(3)
    left_b = Left("3")
    left_c = Left("3")
    right_a = Right(3)
    right_b = Right("3")
    right_c = Right("3")

    assert left_a != left_b
    assert left_a != right_a
    assert left_a != right_b
    assert left_b != left_c
    assert left_b != right_a
    assert left_b != right_b
    assert left_b != right_c
    assert right_a != right_b
    assert right_a != right_c
    assert right_a != left_a
    assert right_a != left_b
    assert right_b != right_c
    assert right_b != left_a
    assert right_b != left_b

# Generated at 2022-06-12 05:01:49.041728
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)

    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)

# Generated at 2022-06-12 05:01:59.967120
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(0) == Left(0)
    assert Left(1) == Left(1)
    assert Right(0) == Right(0)
    assert Right(1) == Right(1)
    assert Left(0) != Left(1)
    assert Left(1) != Left(0)
    assert Right(0) != Right(1)
    assert Right(1) != Right(0)
    assert Left(0) != Right(0)
    assert Right(0) != Left(0)
    assert Left(0) != 1
    assert Left(1) != 0
    assert Right(0) != 1
    assert Right(1) != 0
    assert Left(0) != "0"
    assert Left("0") != 0
    assert Right(0) != "0"
    assert Right("0") != 0
    assert Left

# Generated at 2022-06-12 05:02:01.141332
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert not Right(2) == Left(2)
    assert not Left(1) == Right(1)



# Generated at 2022-06-12 05:02:08.421546
# Unit test for method __eq__ of class Either
def test_Either___eq__():

    # When I create two Right with the same value
    right_1 = Right(42)
    right_2 = Right(42)

    # Then I expect them to be equal
    assert right_1 == right_2

    # When I create two Left with the same value
    left_1 = Left(42)
    left_2 = Left(42)

    # Then I expect them to be equal
    assert left_1 == left_2

    # When I create a Right and a Left with the same value
    right_l = Right(42)
    left_l = Left(42)

    # Then I expect them not to be equal
    assert right_l != left_l

    # When I create a Left and a Right with the same value
    left_r = Left(42)
    right_r = Right(42)

    # Then I

# Generated at 2022-06-12 05:02:15.891245
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test of to_lazy method of Either.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    value = 1000
    either = Right(value)

    # Testing
    assert isinstance(either.to_lazy(), Lazy)  # Should return Lazy
    assert either.to_lazy().get() == value  # Should return Lazy with value
    assert either.to_lazy().get() == either.to_box().value  # Should return Lazy with value



# Generated at 2022-06-12 05:02:19.175867
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)

    assert left == left
    assert right != left
    assert left != right
    assert right == right


# Generated at 2022-06-12 05:02:24.152029
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('error message') == Left('error message')
    assert Left('error message') != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)
    assert Left('error message') != Left('another error message')



# Generated at 2022-06-12 05:02:25.954457
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)

# Generated at 2022-06-12 05:02:40.486507
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(5)
    other_left = Left(5)

    assert left == other_left

    right = Right(5)
    assert not left == right

    other_right = Right(5)

    assert right == other_right



# Generated at 2022-06-12 05:02:47.327365
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    def test_lazy_to_lazy():
        fn = lambda x: x + 1
        lazy = Either(1).to_lazy()
        assert lazy == Lazy(fn)

    def test_either_to_lazy():
        assert Either(1).to_lazy() == Lazy(lambda: 1)

    test_lazy_to_lazy()
    test_either_to_lazy()


# Generated at 2022-06-12 05:02:51.980393
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert(Left("a") == Left("a"))
    assert(Left("a") == Left("a"))
    assert(Right("a") == Right("a"))

    assert(Left("a") != Right("a"))
    assert(Left("a") != "a")
    assert(Left("a") != AnythingElse())


# Generated at 2022-06-12 05:02:57.585070
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    right = Right(1)

    assert left == left
    assert right == right
    assert left.__eq__(right) is False
    assert right.__eq__(left) is False
    left_copy = Left(1)
    assert left == left_copy
    right_copy = Right(1)
    assert right == right_copy


# Generated at 2022-06-12 05:03:09.226007
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Either(None).to_lazy() == Lazy(lambda: None)

    # Test methods to_lazy of classes that inherited from Either
    assert Left(None).to_lazy() == Lazy(lambda: None)
    assert Right(None).to_lazy() == Lazy(lambda: None)

    # Test methods to_lazy and to_try of classes that inherited from Either
    assert Try(None).to_lazy() == Lazy(lambda: None)
    assert Box(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:03:19.368871
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try

    # Eithier
    either = Left(2)
    should_be_false = (either == Right(2))
    assert isinstance(should_be_false, bool)
    assert should_be_false is False

    either = Left(2)
    should_be_false = (either == Right(lambda x: x + 1))
    assert isinstance(should_be_false, bool)
    assert should_be_false is False

    either = Left(2)
    should_be_false = (either == Try(lambda x: x + 1))
    assert isinstance(should_be_false, bool)
    assert should_be_false is False

    either = Right(2)
    should_be_false = (either == Left(2))

# Generated at 2022-06-12 05:03:26.903871
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Right(1).__eq__(Right(1))
    assert Left(1).__eq__(Left(1))
    assert Right(1).__eq__(Maybe.just(1))
    assert Left(1).__eq__(Maybe.nothing())
    assert Right(1).__eq__(Validation.success(1))
    assert Left(1).__eq__(Validation.fail([1]))
    assert Left(1).__eq__(1)



# Generated at 2022-06-12 05:03:33.586145
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(3) != Either(3)
    assert not Either(3) == Either('3')
    assert Either(3) == Either(3)
    assert not Either(3) != Either(3)
    assert not Either(3) == Either(4)
    assert Either(3) != Either(4)
    assert not Either(3) == Either('3')
    assert not Either(3) == Left(3)
    assert not Either(3) == Either('3')
    assert not Either(3) == Right('3')

# Generated at 2022-06-12 05:03:36.262584
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(2) == Right(2)
    assert Left(2) == Left(2)



# Generated at 2022-06-12 05:03:40.840304
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) == Left(2)
    assert Left(1) == Right(1)

    assert not Left(1) == Right(2)

    assert Right(1) == Right(1)
    assert Right(1) == Right(2)
    assert Right(1) == Left(1)

    assert not Right(1) == Left(2)


# Generated at 2022-06-12 05:03:48.845318
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    actual = Left("value").to_lazy()
    expect = Lazy("value")
    assert actual == expect



# Generated at 2022-06-12 05:03:58.279794
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.functor import Functor

    def to_lazy(f):
        def wrapper(*args, **kwargs):
            return Lazy(lambda: f(*args, **kwargs))
        return wrapper

    Functor.use_method(to_lazy)

    assert Left(5).to_lazy().value() == 5
    assert Right(5).to_lazy().value() == 5
    assert Left(Box(5)).to_lazy().value() == 5
    assert Right(Box(5)).to_lazy().value() == 5

# Generated at 2022-06-12 05:04:02.477686
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left('failure').to_lazy() == Lazy(lambda: 'failure')


# Generated at 2022-06-12 05:04:04.863478
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right("success").to_lazy().force() == "success"
    assert Left("failed").to_lazy().force() == "failed"

# Generated at 2022-06-12 05:04:13.287077
# Unit test for method to_lazy of class Either

# Generated at 2022-06-12 05:04:15.108578
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert (Right(42).to_lazy() == Lazy(lambda: 42))
    assert (Left('Was Left').to_lazy() == Lazy(lambda: 'Was Left'))


# Generated at 2022-06-12 05:04:23.411534
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either, Left, Right
    import time

    start_time = time.time()
    result = Left(1).to_lazy().bind(lambda x: Lazy(lambda: time.time() - start_time)).get_value()
    assert result > 0

    start_time = time.time()
    result = Right(10).to_lazy().bind(lambda x: Lazy(lambda: time.time() - start_time)).get_value()
    assert result > 0


# Generated at 2022-06-12 05:04:26.669604
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(4).to_lazy() == Lazy(lambda: 4)
    assert Right(4).to_lazy() == Lazy(lambda: 4)



# Generated at 2022-06-12 05:04:31.860325
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    f = Either.Right(1).to_lazy().get()
    assert f() == 1
    g = Either.Left(1).to_lazy().get()
    assert g() == 1
    assert isinstance(Either.Right(1).to_lazy(), Lazy)


# Generated at 2022-06-12 05:04:37.087361
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.

    :returns: None
    :rtype: None
    """
    def unit():
        return 'unit test of Either'

    assert Right(unit).to_lazy().force() == 'unit test of Either'



# Generated at 2022-06-12 05:04:44.230804
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of Either class.

    :returns: Nothing
    :rtype: None
    """
    assert Right(10).to_lazy().value() == 10
    assert Left(10).to_lazy().value() == 10


# Generated at 2022-06-12 05:04:54.416605
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Success as ValidationSuccess, Failure as ValidationFailure

    assert Lazy(lambda: 1) == Either(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Box(1).to_lazy()
    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: 1) == Success(1).to_lazy()
    assert Lazy(lambda: 1)

# Generated at 2022-06-12 05:05:00.100146
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1
    assert Left(1).to_lazy().bind(lambda x: x + 1).value() == 2
    assert Right(1).to_lazy().bind(lambda x: x + 1).value() == 2



# Generated at 2022-06-12 05:05:03.133957
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(12).to_lazy() == Lazy(lambda: 12)
    assert Right(12).to_lazy() == Lazy(lambda: 12)



# Generated at 2022-06-12 05:05:07.807103
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left("error").to_lazy() == Lazy(lambda: "error")
    assert Right("success").to_lazy() == Lazy(lambda: "success")


# Generated at 2022-06-12 05:05:10.001162
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(42).to_lazy().evaluate() == 42
    assert Right(42).to_lazy().evaluate() == 42



# Generated at 2022-06-12 05:05:13.137333
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy().func() == 2
    assert Right(2).to_lazy().func() == 2


# Generated at 2022-06-12 05:05:18.488878
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functor import Fn
    from pymonet.monad_try import Try

    # Given
    either = Either(1)

    # When
    lazy = either.to_lazy()

    # Then
    assert Try(lazy.unsafe_get).bind(Fn(lambda x: x.to_maybe().is_just())).unsafe_get()

# Generated at 2022-06-12 05:05:22.713663
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    e = Left(1).to_lazy()
    assert isinstance(e, Lazy) and e.value() == 1

    e = Right(2).to_lazy()
    assert isinstance(e, Lazy) and e.value() == 2

# Generated at 2022-06-12 05:05:27.512843
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_try import Success, Failure
    from pymonet.lazy import Lazy

    assert Success("A").to_lazy() == Lazy(lambda: "A")
    assert Failure("A").to_lazy() == Lazy(lambda: "A")


# Generated at 2022-06-12 05:05:37.948498
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    x = 5
    assert Right(x).to_lazy() == Lazy(lambda: x)
    assert Left(x).to_lazy() == Lazy(lambda: x)


# Generated at 2022-06-12 05:05:40.548541
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Left(1)) == Lazy(lambda: 1)
    assert Either.to_lazy(Right(1)) == Lazy(lambda: 1)



# Generated at 2022-06-12 05:05:44.240159
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 05:05:47.324418
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().value() == 5
    assert Left(5).to_lazy().value() == 5
# End of unit test for method to_lazy of class Either


# Generated at 2022-06-12 05:05:54.048477
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> to_lazy()
    Lazy(function () -> 1)
    >>> to_lazy()
    Lazy(function () -> 'foo')
    """
    from pymonet.lazy import Lazy

    def to_lazy(value):
        return Either(value).to_lazy()

    assert to_lazy(1) == Lazy(lambda: 1)
    assert to_lazy('foo') == Lazy(lambda: 'foo')



# Generated at 2022-06-12 05:05:58.545303
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    """
    Unit test for method to_lazy of class Either.

    :returns: only raises exception when test failed
    :rtype: None
    """

    from pymonet.lazy import Lazy

    assert(Either(5).to_lazy() == Lazy(lambda: 5))



# Generated at 2022-06-12 05:06:02.895013
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'foo'

    lazy = Right(f).to_lazy()
    assert right.case(lambda _: False, lambda _: True)
    assert lazy.value() == right.value()



# Generated at 2022-06-12 05:06:08.094849
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:06:10.214130
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy()._value() == 5
    assert Left(2).to_lazy()._value() == 2

# Generated at 2022-06-12 05:06:11.452662
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Left(2).to_lazy()



# Generated at 2022-06-12 05:06:28.597988
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from operator import add
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) + Lazy(lambda: 1) == Left(1).to_lazy() + Left(1).to_lazy()



# Generated at 2022-06-12 05:06:31.608759
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.to_lazy(Right(0))(1) == Lazy(lambda: 0)(1)
    assert Either.to_lazy(Left(0))(1) == Lazy(lambda: 0)(1)



# Generated at 2022-06-12 05:06:35.083799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    right_either = Right(5)

    # When
    lazy_monad = right_either.to_lazy()

    # Then
    assert lazy_monad.value == 5



# Generated at 2022-06-12 05:06:36.841049
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() != Right(1).to_lazy()



# Generated at 2022-06-12 05:06:39.726205
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().evaluate() == 1
    assert Right(1).to_lazy().evaluate() == 1



# Generated at 2022-06-12 05:06:47.058027
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monoid import Monoid

    def add(*args):
        def inner_add(x, y):
            return x + y
        reduce(inner_add, args)

    # Test for Left
    assert Left(4).to_lazy() == Lazy(lambda: 4)
    assert Left(4).to_lazy().run() == 4

    # Test for Right
    some_lazy = Right(4.0).to_lazy()
    assert isinstance(some_lazy, Lazy)
    assert some_lazy.run() == 4.0
    lazy_monoid = Monoid[Lazy[float]]

# Generated at 2022-06-12 05:06:51.245611
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(True).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-12 05:06:53.831125
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().calculate() == 1
    assert Right(1).to_lazy().calculate() == 1


# Generated at 2022-06-12 05:06:57.028616
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    fn = lambda: 'foo'
    assert Either('bar').to_lazy().callable() == 'bar'
    assert Either(fn).to_lazy().callable() == 'foo'


# Generated at 2022-06-12 05:07:03.783018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    val = 2

    def lazy_result():
        return val

    lazy = Either.right(val).to_lazy()
    assert lazy.is_instance(Lazy)
    assert lazy.result() == Box.right(lazy_result())

    lazy = Either.left(val).to_lazy()
    assert lazy.is_instance(Lazy)
    assert lazy.result() == Box.left(lazy_result())


# Generated at 2022-06-12 05:07:31.680840
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Left(1).to_lazy()
    assert Lazy(lambda: 1) == Right(1).to_lazy()



# Generated at 2022-06-12 05:07:33.939722
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def dummy():
        return None

    assert Either(None).to_lazy() == Lazy(dummy)


# Generated at 2022-06-12 05:07:36.840687
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:07:39.343086
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1



# Generated at 2022-06-12 05:07:42.937911
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1) == Lazy(lambda: Either(1).value)
    assert Either(2).to_lazy() == Lazy(lambda: 2) == Lazy(lambda: Either(2).value)



# Generated at 2022-06-12 05:07:46.145216
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Tests if mapping function of class Either works correctly for both Right and Left.
    :return:
    """
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left("error").to_lazy() == Lazy(lambda: "error")



# Generated at 2022-06-12 05:07:49.093622
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: "abc") == Either(Right("abc")).to_lazy()
    assert Lazy(lambda: "abc") == Either(Left("abc")).to_lazy()



# Generated at 2022-06-12 05:07:51.172701
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(42).to_lazy() == Lazy(lambda: 42)



# Generated at 2022-06-12 05:07:53.141129
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of Either class.
    """
    assert Right(100).to_lazy().value() == 100
    assert Left(100).to_lazy().value() == 100


# Generated at 2022-06-12 05:07:54.527938
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1
