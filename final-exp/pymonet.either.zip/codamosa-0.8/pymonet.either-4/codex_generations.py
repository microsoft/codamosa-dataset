

# Generated at 2022-06-12 04:58:55.699896
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(2).to_lazy() == Lazy(lambda: 2)
    assert Either('asd').to_lazy() == Lazy(lambda: 'asd')
    assert Either(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 04:58:58.826678
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Left(1)
    assert Either(1) != Right(2)


# Generated at 2022-06-12 04:59:01.116614
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != None
    assert Either(1) != 1


# Generated at 2022-06-12 04:59:04.152508
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> either = Either(2).case(lambda _: 'Error', lambda value: value * 2)
    >>> assert either == 4
    >>> either = Either(2).case(lambda _: 'Error', lambda value: value)
    >>> assert either == 2
    """



# Generated at 2022-06-12 04:59:06.893492
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Right(5) == Right(5)
    assert not Right(5) == Left(5)
    assert not Left(5) == Right(5)



# Generated at 2022-06-12 04:59:09.497490
# Unit test for method case of class Either
def test_Either_case():
    assert Either.case(Left(1), lambda x: x, lambda x: x) == 1
    assert Either.case(Right(1), lambda x: x, lambda x: x) == 1

# Generated at 2022-06-12 04:59:10.913512
# Unit test for method case of class Either
def test_Either_case():
    assert Left(10).case(lambda value: value * 2, lambda value: value // 2) == 20
    assert Right(10).case(lambda value: value * 2, lambda value: value // 2) == 5

# Generated at 2022-06-12 04:59:15.922641
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left(1)
    assert left == Left(1)
    assert left != Left(2)
    assert left != Right(1)

    right = Right(1)
    assert right == Right(1)
    assert right != Right(2)
    assert right != Left(1)


# Generated at 2022-06-12 04:59:20.402858
# Unit test for method case of class Either
def test_Either_case():
    assert Left(3).case(lambda error: error * 2, lambda success: success) == 6
    assert Right(3).case(lambda error: error * 2, lambda success: success) == 3



# Generated at 2022-06-12 04:59:25.242357
# Unit test for method case of class Either
def test_Either_case():
    assert Left(5).case(lambda x: x - 1, lambda x: x + 1) == 4
    assert Right(5).case(lambda x: x - 1, lambda x: x + 1) == 6



# Generated at 2022-06-12 04:59:33.645772
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().get() == 1
    assert Left(1).to_lazy().get() == 1


# Generated at 2022-06-12 04:59:42.513541
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(2) == Right(2)
    assert Left(1) != Left(2)
    assert Right(2) != Right(3)
    assert Left(1) != Right(1)
    assert Left(1) != 2
    assert Right(3) != 4
    assert Left(1) != (1, 2)
    assert (1, 2) != Left(2)
    assert Right(3) != (3, 4)
    assert (3, 4) != Right(4)
    assert not(Right(4) == (4, 4))

if __name__ == "__main__":
    test_Either___eq__()

# Generated at 2022-06-12 04:59:48.062383
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(0) == Left(0), 'Should return true for the same instances of Left'
    assert Right(0) == Right(0), 'Should return true for the same instances of Right'
    assert Left(0) != Left(1), 'Should return false for different instances of Left'
    assert Right(0) != Right(1), 'Should return false for different instances of Right'
    assert Left(0) != Right(0), 'Should return false when comparing Left with Right'
    assert Right(0) != Left(0), 'Should return false when comparing Right with Left'


# Generated at 2022-06-12 04:59:51.248572
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left("H") == Left("H")
    assert Right("H") == Right("H")
    assert not Right("H") == Left("H")
    assert not Left("H") == Right("H")


# Generated at 2022-06-12 04:59:58.328930
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Test for equals with Left and Right
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    # Test for equals with other class
    assert not Right(1) == 1
    assert not Left(1) == 1
    assert not Right("A") == "A"
    assert not Left("A") == "A"

# Generated at 2022-06-12 05:00:05.981223
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test behavior of method to_lazy.

    :returns: AssertionError in case of error
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try


    lazy = Lazy(lambda: 42)
    assert lazy.to_lazy() == Lazy(lambda: 42)
    assert lazy.to_try() == Try(42)
    assert lazy.to_either() == Right(42)
    assert lazy.to_box() == Box(42)
    assert lazy.to_maybe() == Maybe(42)



# Generated at 2022-06-12 05:00:08.375709
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    assert Left(1).to_lazy().value() == 1
    assert Right(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:00:14.352851
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(4) == Left(4)
    assert Either(4) == Right(4)
    assert Either(4) == Either(4)
    assert Left(4) == Left(4)
    assert Right(4) == Right(4)
    assert Left(4) != Right(4)
    assert Left(4) != Either(4)
    assert Right(4) != Either(4)



# Generated at 2022-06-12 05:00:20.352988
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) == Left(1)
    assert Left(1) != Left(2)
    assert Left(1) != Right(1)
    assert Right(1) == Right(1)
    assert Right(1) == Right(1)
    assert Right(1) != Right(2)
    assert Right(1) != Left(1)



# Generated at 2022-06-12 05:00:27.215622
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def get_value():
        return "A"

    assert Right(get_value()).to_lazy().value() == "A"
    assert Right("B").to_lazy().value() == "B"
    assert Left("C").to_lazy().value() == "C"
    assert Left(get_value()).to_lazy().value() == "A"



# Generated at 2022-06-12 05:00:35.534232
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    # Test 1
    assert Left(2) == Left(2)

    # Test 2
    assert Right(2) == Right(2)

    # Test 3
    assert Right(2) != Left(2)

    # Test 4
    assert Left(2) != Right(2)



# Generated at 2022-06-12 05:00:40.457789
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().get() == Either(1).value

    assert Left(1).to_lazy().get() == Left(1).value

    assert Right(1).to_lazy().get() == Right(1).value



# Generated at 2022-06-12 05:00:45.156174
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.try_ import Try
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:00:49.111489
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left("1")
    assert Left(1) != Right("1")


# Generated at 2022-06-12 05:00:50.655816
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(5) == Right(5)
    assert Left(5) == Left(5)



# Generated at 2022-06-12 05:00:53.530748
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1) == Left(2)
    assert Right(1) == Right(1) == Right(2)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != ''

# Generated at 2022-06-12 05:00:55.440144
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)



# Generated at 2022-06-12 05:01:00.149868
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    import pytest
    right1 = Right(1)
    right2 = Right(2)
    assert right1 != right2
    assert right1 == Right(1)
    left1 = Left(1)
    left2 = Left(2)
    assert left1 != left2
    assert left1 == Left(1)
    assert right1 != left1


# Generated at 2022-06-12 05:01:04.365916
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    x = Right(5)
    assert True == x.to_lazy().is_lazy()
    assert x.value == x.to_lazy().force()
    y = Left(True)
    assert True == y.to_lazy().is_lazy()
    assert y.value == y.to_lazy().force()



# Generated at 2022-06-12 05:01:08.119792
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1) and Right(1) == Right(1) and \
        Left(1) != Right(1) and Right(2) != Left(2) and \
        Left(None) != None and Right(None) != None

# Generated at 2022-06-12 05:01:17.444401
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)


# Generated at 2022-06-12 05:01:27.467100
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    either1 = Left(10)
    either2 = Left(10)
    either3 = Right(10)
    either4 = Right(10)
    assert either1 == either2
    assert either3 == either4
    assert not either1 == either3
    assert not either2 == either4
    assert not either1 == None
    assert not either2 == None
    assert not either1 == 10
    assert not either2 == 10
    assert either1 != either3
    assert either2 != either4
    assert not either1 != either2
    assert not either3 != either4
    assert either1 != None
    assert either2 != None
    assert either1 != 10
    assert either2 != 10
    assert not either1 != either1
    assert not either2 != either2
    assert not either3 != either3
    assert not either4 != either4

# Generated at 2022-06-12 05:01:35.981678
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('1').__eq__(Left('1')) is True
    assert Left('1').__eq__(Left('2')) is False
    assert Left('1').__eq__(Right('1')) is False
    assert Left('1').__eq__(Right('2')) is False
    assert Right('1').__eq__(Left('1')) is False
    assert Right('1').__eq__(Left('2')) is False
    assert Right('1').__eq__(Right('1')) is True
    assert Right('1').__eq__(Right('2')) is False


# Generated at 2022-06-12 05:01:42.360727
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def function_result() -> int:
        return 3

    either = Left(4)
    lazy: Lazy[Any] = either.to_lazy()
    assert lazy.force(function_result)() == function_result()

    either = Right(5)
    lazy: Lazy[Any] = either.to_lazy()
    assert lazy.force(function_result)() == either.value



# Generated at 2022-06-12 05:01:44.291315
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left([1, 2, 3]) == Left([1, 2, 3])



# Generated at 2022-06-12 05:01:48.354781
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:01:57.149619
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.either import Left, Right
    from hypothesis import given, assume, settings

    @settings(max_examples=500)
    @given(value=str)
    def test_eq(value: str) -> None:
        assume(value != '')
        assert Left(value) == Left(value)
        assert Right(value) == Right(value)
        assert Left(value) != Right(value)
        assert Right(value) != Left(value)
        assert Left(value) != (value)
        assert Right(value) != (value)

    test_eq()


# Generated at 2022-06-12 05:02:01.769874
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy"""
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.either import Right

    assert Left.to_lazy(Left('Error')) == Lazy(lambda: 'Error')
    assert Right.to_lazy(Right(5)) == Lazy(lambda: 5)


# Generated at 2022-06-12 05:02:08.956062
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    class A:
        pass

    a = A()
    b = A()

    assert Right(a) == Right(a), "__eq__ failed"
    assert Left(a) == Left(a), "__eq__ failed"

    assert Right(a) != Right(b), "__eq__ failed"
    assert Left(a) != Left(b), "__eq__ failed"

    assert Left(a) != Right(a), "__eq__ failed"
    assert Left(a) != Right(b), "__eq__ failed"
    assert Right(a) != Left(a), "__eq__ failed"
    assert Right(a) != Left(b), "__eq__ failed"

    assert Left(a) != b, "__eq__ failed"
    assert Right(a) != b, "__eq__ failed"

# Unit

# Generated at 2022-06-12 05:02:12.778789
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert not (Left(1) == Left(2))
    assert not (Left(1) == Right(1))
    assert Right(1) == Right(1)
    assert not (Right(1) == Right(2))

# Generated at 2022-06-12 05:02:27.337927
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_left = Left(1).to_lazy()
    assert isinstance(lazy_left, Lazy) and\
        lazy_left.value() == 1, 'Left Either does not convert to lazy monad'

    lazy_right = Right(2).to_lazy()
    assert isinstance(lazy_right, Lazy) and\
        lazy_right.value() == 2, 'Right Either does not convert to lazy monad'


# Generated at 2022-06-12 05:02:32.481126
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either("sss").to_lazy() == Lazy(lambda: "sss")
    assert Either("sss").to_lazy() == Lazy(lambda: "sss")
    assert Lazy(lambda: "sss") != Lazy(lambda: "ddd")


# Generated at 2022-06-12 05:02:36.396366
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1).to_either().to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:02:39.685212
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 1)
    assert Right(1).to_lazy() == lazy_value
    assert Left(1).to_lazy() == lazy_value



# Generated at 2022-06-12 05:02:47.369215
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test method to_lazy of class Either.
    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.list import List

    def to_lazy():
        return Lazy(lambda: Box(Maybe.just(Try.success(Validation.success(1)))))

    assert to_lazy().value().value().value().value().value() == 1


# Generated at 2022-06-12 05:02:53.467115
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy


# Generated at 2022-06-12 05:02:59.011516
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    num = Right(1)
    assert num.to_lazy() == Lazy(lambda: 1)

    num = Left(1)
    assert num.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:03:03.263192
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import pytest

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:03:09.557505
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    either = Right(5)

    assert isinstance(either.to_lazy(), Lazy)
    assert either.to_lazy().value() == 5

    either = Left(5)

    assert isinstance(either.to_lazy(), Lazy)
    assert callable(either.to_lazy().value)
    assert either.to_lazy().value() == 5


# Generated at 2022-06-12 05:03:15.414179
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def test_case_1():
        # Test when Either is Left
        e = Left(10)
        l = e.to_lazy()

        assert l.value() == 10

    def test_case_2():
        # Test when Either is Right
        e = Right(10)
        l = e.to_lazy()

        assert l.value() == 10

    test_case_1()
    test_case_2()


# Generated at 2022-06-12 05:03:29.191891
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    right = Right(0)
    lazy = right.to_lazy()
    assert(lazy == Lazy(lambda: 0))
    assert(lazy.equals(Lazy(lambda: 0)))
    assert(lazy.value == 0)

# Generated at 2022-06-12 05:03:31.310950
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(42)
    lazy = right.to_lazy()

    assert lazy[0](), 42



# Generated at 2022-06-12 05:03:34.478515
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Left(3).to_lazy()
    assert Lazy(lambda: 'abc') == Right('abc').to_lazy()


# Generated at 2022-06-12 05:03:36.353144
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:03:38.479496
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(15).to_lazy().force() == 15
    assert Left(5).to_lazy().force() == 5


# Generated at 2022-06-12 05:03:40.235355
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().value()() == 1
    assert Left(1).to_lazy().value()() == 1


# Generated at 2022-06-12 05:03:47.511931
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    try_monad = Try(5, is_success=True)
    assert try_monad.to_lazy() == Lazy(lambda: 5)

    maybe_monad = Maybe.just(5)
    assert maybe_monad.to_lazy() == Lazy(lambda: 5)

    either_monad = Right(5)
    assert either_monad.to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:03:57.044181
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 4) == Either[int, int](4).to_lazy()
    assert Lazy(lambda: Maybe.just(4)) == Either[int, Maybe[int]](Maybe.just(4)).to_lazy()

    assert not Lazy(lambda: 4) == Either[int, int](5).to_lazy()
    assert not Lazy(lambda: Maybe.just(4)) == Either[int, Maybe[int]](Maybe.just(5)).to_lazy()



# Generated at 2022-06-12 05:04:01.187742
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    left = Left(1)
    right = Right(2)
    assert left.to_lazy() == Lazy(lambda: 1)
    assert left.to_lazy() == Lazy(lambda: left.value)
    assert right.to_lazy() == Lazy(lambda: 2)
    assert right.to_lazy() == Lazy(lambda: right.value)


# Generated at 2022-06-12 05:04:06.214446
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    def lazy_test():
        return 20

    assert Left(30).to_lazy() == Lazy(lambda: 30)
    assert Right(lazy_test).to_lazy() == Lazy(lazy_test)


# Generated at 2022-06-12 05:04:25.957956
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Left(10).to_lazy(), Lazy)
    assert isinstance(Right(10).to_lazy(), Lazy)


# Generated at 2022-06-12 05:04:30.949090
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def first():
        return 1

    def second():
        return 2

    assert Left(first).to_lazy() == Lazy(first)
    assert Right(second).to_lazy() == Lazy(second)


# Generated at 2022-06-12 05:04:35.170947
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def get_lazy_value(lazy):
        return lazy.get_value()

    assert get_lazy_value(Right(10).to_lazy()) == 10
    assert get_lazy_value(Left(10).to_lazy()) == 10



# Generated at 2022-06-12 05:04:43.724219
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    import time

    start1 = time.time()
    result1 = Right(10).to_lazy().force()
    end1 = time.time()

    start2 = time.time()
    result2 = Right(10).to_lazy().bind(lambda r: r * 2).force()
    end2 = time.time()

    start3 = time.time()
    result3 = Right(10).to_lazy().bind(lambda r: r * 3).force()
    end3 = time.time()

    assert result1 == 10
    assert end1 - start1 < 0.01

    assert result2 == 20
    assert end2 - start2 < 0.01

    assert result3 == 30
    assert end3 - start3 < 0.01



# Generated at 2022-06-12 05:04:46.274183
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:04:49.558595
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:04:58.122478
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_lazy import Unit
    from pymonet.lazy import get_value
    from pymonet.either import Left, Right
    from pymonet.monad_type import MonadType

    assert get_value(Left(1).to_lazy()) == 1
    assert get_value(Right(1).to_lazy()) == 1

    assert Left(1).to_lazy().value == Left(1).to_lazy().value
    assert Right(1).to_lazy().value == Right(1).to_lazy().value

    assert MonadType.same_type(Left(1).to_lazy(), Left(1).to_lazy())
    assert MonadType.same_type(Right(1).to_lazy(), Right(1).to_lazy())

    assert Mon

# Generated at 2022-06-12 05:05:01.587001
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:05:03.745614
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_functions import unit

    assert isinstance(unit(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:05:15.927180
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.monad_list import List
    import pytest
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def to_maybe_or_none(value):
        monad = value.to_maybe()
        return None if monad.is_nothing() else monad.value

    def to_list(value):
        return value.to_lazy().value()

    def to_box(value):
        return value.to_box().value

    def to_try(value):
        return value.to_try()

    def to_validation(value):
        return value.to_validation()

    value = Either.of(List.of(1, 2, 3))
    assert to_list(value) == List.of(1, 2, 3)

   

# Generated at 2022-06-12 05:05:58.328798
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    value = 'value'
    assert Either(value).to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:06:01.503226
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left("value").to_lazy(), Lazy)
    assert isinstance(Right("value").to_lazy(), Lazy)



# Generated at 2022-06-12 05:06:11.433231
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert isinstance(Left(5).to_lazy(), Lazy)
    assert str(Left(5).to_lazy()) == 'Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x354e7e600>)'
    assert Left(5).to_lazy().value() == 5
    assert isinstance(Right(5).to_lazy(), Lazy)
    assert str(Right(5).to_lazy()) == 'Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x354e7e600>)'
    assert Right(5).to_lazy().value() == 5


# Generated at 2022-06-12 05:06:16.341937
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(1).to_lazy().value, int)
    assert isinstance(Right('1').to_lazy().value, str)
    assert Left(1).to_lazy().value == 1
    assert Left('1').to_lazy().value == '1'



# Generated at 2022-06-12 05:06:21.583797
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test right
    right = Right(5)
    assert right.to_lazy().value() == 5
    assert right.to_lazy().is_right()

    # Test left
    left = Left('Some error')
    assert left.to_lazy().value() == 'Some error'
    assert left.to_lazy().is_left()



# Generated at 2022-06-12 05:06:24.725470
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(-1).to_lazy().force() == -1
    assert Right(1).to_lazy().force() == 1



# Generated at 2022-06-12 05:06:28.770478
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    either = Left(1)
    expected = Lazy(lambda:1)

    # When
    result = either.to_lazy()

    # Then
    assert expected == result


# Generated at 2022-06-12 05:06:30.951835
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(lambda: 2)
    assert Left(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:06:37.910020
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    import lazy
    import types

    def test_function():
        return 'test'

    either = Right(lazy.later(test_function))

    assert type(either.to_lazy()) == Lazy, 'Wrong type of returned result of to_lazy method of Either class'
    assert type(either.to_lazy().value) == types.LambdaType, 'Wrong type of value of returned Lazy object'


# Generated at 2022-06-12 05:06:41.290738
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(5)) == Lazy(5)
    assert Either.to_lazy(Left('error')) == Lazy('error')

# Generated at 2022-06-12 05:08:11.893236
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Lazy(lambda: 'value'), Lazy)
    assert isinstance(Left('value').to_lazy(), Lazy)
    assert isinstance(Right('value').to_lazy(), Lazy)
    assert Left('value').to_lazy().value() == 'value'
    assert Right('value').to_lazy().value() == 'value'



# Generated at 2022-06-12 05:08:13.454027
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(10).to_lazy().get() == 10
    assert Right(20).to_lazy().get() == 20


# Generated at 2022-06-12 05:08:22.071932
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _test_Either_to_lazy(either: Either, expected: bool) -> None:
        """
        Asserts either evaluates to expected.

        :param either: Either to evaluate
        :type either: Either[A]
        :param expected: expected result of function evaluation
        :type expected: Boolean
        """
        assert either.to_lazy().eval() == expected

    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    def constant_lazy_function() -> Lazy[int]:
        return Lazy(lambda: 1)

    def falsy_lazy_function() -> Lazy[int]:
        return Lazy(lambda: 0)

    _test_Either_to_lazy(Left('Error'), False)

# Generated at 2022-06-12 05:08:26.284336
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    data = [
        (Right(1).to_lazy().force(), 1),
        (Left(1).to_lazy().force(), 1)
    ]
    for (actual, expected) in data:
        assert actual == expected


# Generated at 2022-06-12 05:08:29.891944
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # An empty either to test with
    either = Left(None)
    # Apply to_lazy on the empty either
    lazy = either.to_lazy()
    # Check the result is a Lazy monad
    assert isinstance(lazy, Lazy)
    # Check the result is a Lazy with a lambda function as initial value
    assert lazy.value.__class__ is types.FunctionType


# Generated at 2022-06-12 05:08:33.287417
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.

    :returns: Nothing
    :rtype: None
    """
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left("error").to_lazy() == Lazy(lambda: "error")



# Generated at 2022-06-12 05:08:35.630492
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert(Left("some error").to_lazy() == Lazy(lambda: "some error"))
    assert(Right(123).to_lazy() == Lazy(lambda: 123))

# Generated at 2022-06-12 05:08:39.030633
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Right(20).to_lazy(), Lazy)
    assert isinstance(Left(20).to_lazy(), Lazy)


# Generated at 2022-06-12 05:08:41.519691
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:08:50.135695
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy().case(lambda value: value + 1, lambda value: value) == 6
    assert Left(5).to_lazy().case(lambda value: value + 1, lambda value: value) == 5
    assert Right('sf').to_lazy().case(lambda value: value + 1, lambda value: value) == 'sf'
    assert Left(5).to_lazy().case(lambda value: value + 1, lambda value: value) == 5
    assert Right(None).to_lazy