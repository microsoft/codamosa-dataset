

# Generated at 2022-06-12 04:59:00.420438
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Test __eq__ method of class Either.

    :returns: AssertionError if test failed
    :rtype: AssertionError
    """
    assert Left('test') == Left('test')
    assert Left('test') != Right('test')
    assert Left('test') != Either('test')
    assert Right('test') == Right('test')
    assert Right('test') != Either('test')



# Generated at 2022-06-12 04:59:04.120189
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    e = Left(0).to_lazy()
    assert isinstance(e, Lazy)
    assert e.force() is 0
    e = Right(0).to_lazy()
    assert isinstance(e, Lazy)
    assert e.force() is 0


# Generated at 2022-06-12 04:59:14.969105
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_1 = Left(1)
    left_2 = Left(2)
    right_1 = Right(1)
    right_2 = Right(2)

    assert left_1 == left_1
    assert left_1 != left_2
    assert left_1 != right_1
    assert left_1 != right_2

    assert left_2 == left_2
    assert left_2 != left_1
    assert left_2 != right_1
    assert left_2 != right_2

    assert right_1 == right_1
    assert right_1 != right_2
    assert right_1 != left_1
    assert right_1 != left_2

    assert right_2 == right_2
    assert right_2 != right_1
    assert right_2 != left_1
    assert right_2 != left_2

# Generated at 2022-06-12 04:59:21.044802
# Unit test for method case of class Either
def test_Either_case():
    assert Either(1).case(
        error=lambda x: 2,
        success=lambda x: 1
    ) == 1

    assert Either("Ala").case(
        error=lambda x: 2,
        success=lambda x: 1
    ) == 1


# Generated at 2022-06-12 04:59:25.283860
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left: Either[int] = Left(5)
    left1: Either[int] = Left(5)
    left2: Either[int] = Left(10)
    right: Either[int] = Right(5)
    right1: Either[int] = Right(5)
    right2: Either[int] = Right(10)
    assert left == left1
    assert left != left2
    assert right != right1
    assert right == right1


# Generated at 2022-06-12 04:59:32.063260
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    lazy = Try.of(lambda: 1 / 0).to_lazy()
    assert lazy == Lazy(Try.of(lambda: 1 / 0))
    lazy = Right(5).to_lazy()
    assert lazy == Lazy(5)
    lazy = Left(5).to_lazy()
    assert lazy == Lazy(5)


# Generated at 2022-06-12 04:59:35.064619
# Unit test for method case of class Either
def test_Either_case():
    assert Left(1).case(lambda x: x + 2,
                        lambda x: x + 1) == 3
    assert Right(1).case(lambda x: x + 2,
                         lambda x: x + 1) == 2



# Generated at 2022-06-12 04:59:37.633536
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 04:59:41.878820
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) != 1
    assert Left(2) == Left(2)
    assert Left(2) != Right(1)
    assert Right(2) != 1
    assert Right(2) == Right(2)
    assert Right(2) != Left(1)


# Generated at 2022-06-12 04:59:46.084977
# Unit test for method case of class Either
def test_Either_case():
    assert Right(3).case(lambda x: '!', lambda x: x * 2) == 6
    assert Left(3).case(lambda x: x * 2, lambda x: '!') == 6
    assert Left(1).case(lambda x: Left(x * 2), lambda x: Right(x * 2)) == Left(2)



# Generated at 2022-06-12 04:59:59.973111
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)

    assert Left(1).case(lambda x: x, lambda x: x) == Left(1).case(lambda x: x, lambda x: x)
    assert Left(1).case(lambda x: x, lambda x: x) == Left(1).case(lambda x: x, lambda x: x + 1)

# Generated at 2022-06-12 05:00:02.139017
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    expected_value = Lazy(lambda: "100")

    actual_value = Either.to_lazy(Right("100"))

    assert expected_value == actual_value


# Generated at 2022-06-12 05:00:05.077893
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Left(1) == Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Right(1) == Right(1)
    assert Right(1) == Right(1)


# Generated at 2022-06-12 05:00:11.641599
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    m = Left('string')
    n = Left('string')
    assert m == n

    m = Right(2)
    n = Right(2)  # type: ignore
    assert m == n

    m = Left(None)
    n = Right(None)
    assert not m == n

    try_m = m.to_try()
    try_n = n.to_try()
    assert try_m == try_n

    box_m = m.to_box()
    box_n = n.to_box()
    assert box_m == box_n

    lazy_m = m.to_lazy()
    lazy_n = n.to_lazy

# Generated at 2022-06-12 05:00:18.513578
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def test_function1(x, y, z):
        return x + y + z
    right = Right(lambda x, y, z: x + y + z)
    assert right.to_lazy().force(1, 2, 3) == 6
    left = Left(lambda x, y, z: x + y + z)
    assert left.to_lazy().force(1, 2, 3) == 6

# Generated at 2022-06-12 05:00:22.853802
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:00:27.643700
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(20) == Right(20)
    assert Left(20) == Left(20)
    assert Right(20) == Left(20) is False
    assert Left(20) == Right(20) is False
    assert Left(20) == 'test' is False



# Generated at 2022-06-12 05:00:32.112575
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """Unit test for Either.__eq__"""
    # Test1
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    # Test2
    assert not Left('1') == Left(1)
    assert not Right('1') == Right(1)
    assert not Left('1') == Right('1')


# Generated at 2022-06-12 05:00:34.448895
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 05:00:46.260042
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    left_str = Left('Left').case(str, str)
    left_try = Left('Left').to_try()
    right_try = Right('Right').to_try()
    right_box = Right('Right').to_box()
    right_lazy = Right('Right').to_lazy()
    right_maybe = Right('Right').to_maybe()

    assert left_str == 'Left'
    assert left_try == Try('Left', is_success=False)
    assert not left_try == Try('Right', is_success=False)
    assert right_try == Try('Right', is_success=True)
    assert not right

# Generated at 2022-06-12 05:00:51.080976
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(3) == Left(3)
    assert Right(3) == Right(3)
    assert Right(3) != Left(3)
    assert Left(3) != Right(3)


# Generated at 2022-06-12 05:00:54.442706
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2) and Right(2) == Right(2) and Left(3) != Right(3) and Left(2) != Right(2)\
        and Right(3) != Left(3) and Right(2) != Left(2)



# Generated at 2022-06-12 05:00:59.202805
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    """
    Both are right and have the same value or both are left and have the same value.
    """
    assert Right(1) == Right(1)
    assert Left('error') == Left('error')
    assert not Right(1) == Left(1)
    assert not Right(1) == Right(2)
    assert not Left('error') == Left('errors')

# Generated at 2022-06-12 05:01:03.893083
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(3) == Right(3)
    assert Left(3) == Left(3)
    assert not Right(3) == Left(3)
    assert not Right(3) == Right(4)
    assert not Left(3) == Right(3)
    assert not Left(3) == Left(4)
    assert not Left(3) == None



# Generated at 2022-06-12 05:01:07.985230
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left1 = Left('foo')
    left2 = Left('foo')
    right1 = Right('foo')
    right2 = Right('foo')

    assert left1 == left2
    assert right1 == right2
    assert not left1 == right1
    assert not right1 == left1

# Generated at 2022-06-12 05:01:15.020127
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either('1') == Either('1')
    assert not Either('1') == Either('2')
    assert not Either('1') == 4
    assert not Either('1') == 4.0
    assert not Either('1') == [1, 2, 3]
    assert not Either('1') == (1, 2, 3)
    assert not Either('1') == {1: 'a', 2: 'b', 3: 'c'}
    assert not Either('1') == {1, 2, 3}


# Generated at 2022-06-12 05:01:19.542633
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(2) == Right(2)
    assert not (Left('error') == Right(2))
    assert not (Left('error') == 'error')
    assert not (Left('error') == Left('another_error'))
    assert Left('error') == Left('error')



# Generated at 2022-06-12 05:01:26.897144
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_a = Left("this is a value")
    right_a = Right("this is a value")
    right_b = Right("this is not a value")
    assert left_a.__eq__(left_a)
    assert right_a.__eq__(right_a)
    assert not left_a.__eq__(right_a)
    assert not left_a.__eq__(right_b)
    assert not right_a.__eq__(left_a)
    assert not right_a.__eq__(right_b)


# Generated at 2022-06-12 05:01:34.093889
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert not (Left(5) == Right(5))
    assert Right(5) == Right(5)
    assert not (Right(5) == Left(5))
    assert not (Left(5) == None)
    assert not (Left(5) == 5)
    assert Left(5) != Right(5)
    assert Right(5) != Left(5)
    assert Left(5) != None
    assert Left(5) != 5


# Generated at 2022-06-12 05:01:36.035275
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left = Left('test_value')
    right = Right('test_value')
    assert left



# Generated at 2022-06-12 05:01:42.550744
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    # Test for Left
    assert Left(1).to_lazy() == Lazy(lambda: 1)

    # Test for Right
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:01:50.698402
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    some_lazy = Lazy(lambda: 10)
    assert some_lazy.to_maybe() == Maybe.just(10)

    nothing_lazy = Lazy(lambda: None)
    assert nothing_lazy.to_maybe() == Maybe.nothing()

    some_either_right = Right(10)
    assert some_either_right.to_lazy().to_maybe() == Maybe.just(10)

    nothing_either_left = Left(10)
    assert nothing_either_left.to_lazy().to_maybe() == Maybe.nothing()



# Generated at 2022-06-12 05:01:53.669991
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @Lazy
    def f():
        return 1

    assert f() == Right(1).to_lazy().value(None)


# Generated at 2022-06-12 05:01:57.280220
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    new_lazy = Right(1).to_lazy()
    assert isinstance(new_lazy, Lazy)
    assert new_lazy.value() == 1


# Generated at 2022-06-12 05:02:02.181024
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():  # pylint: disable=too-many-public-methods
    """
    Method to_lazy should transform Either to Lazy with result of current Either.
    """
    from pymonet.lazy import Lazy

    assert(Left(1).to_lazy() == Lazy(lambda: 1))
    assert(Right(1).to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-12 05:02:05.122551
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either.Left(5).to_lazy() == Lazy(lambda: 5)
    assert Either.Right(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:02:08.322233
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test method to_lazy of class Either.
    """

    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Left(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:02:11.264011
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()



# Generated at 2022-06-12 05:02:15.637444
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Left(2).to_lazy(), Lazy)
    assert isinstance(Right(2).to_lazy(), Lazy)
    assert Left(2).to_lazy().value() == 2
    assert Right(2).to_lazy().value() == 2


# Generated at 2022-06-12 05:02:18.761954
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().force() == 1
    assert Right(10).to_lazy().force() == 10


# Generated at 2022-06-12 05:02:22.602927
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 5) == Either(5).to_lazy()


# Generated at 2022-06-12 05:02:24.868848
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Either(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:02:31.108365
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    def _sum_square(x: int, y: int) -> int:
        return x ** 2 + y ** 2

    val = Either.to_lazy()(Either.to_lazy()(Either.to_lazy()(Right(10)).bind(lambda x: Right(x + 5))).bind(lambda y: Right(y + 3))).bind(_sum_square)
    assert 12 * 12 + 3 * 3 == val()



# Generated at 2022-06-12 05:02:33.743500
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box

    assert Box(1).to_lazy().value() == 1
    assert Box(1).to_lazy() == Box(1).to_lazy()



# Generated at 2022-06-12 05:02:41.586392
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy, LazyException
    from pymonet.either import Left, Right

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)

    def my_func():
        raise LazyException('For test')

    assert Left(my_func).to_lazy() == Lazy(my_func)
    assert Right(my_func).to_lazy() == Lazy(my_func)


# Generated at 2022-06-12 05:02:46.623236
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit tests
    """
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy().map(lambda a: a + 1).get() == 6



# Generated at 2022-06-12 05:02:50.747868
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def test_function():
        return 1

    assert Right(1).to_lazy() == Lazy(test_function)
    assert Left(1).to_lazy() == Lazy(test_function)


# Generated at 2022-06-12 05:02:56.802952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test of to_lazy concrete class of Either type class

    :meth: to_lazy
    :class: Either
    :return: result of test
    :rtype: Boolean
    """

    right_inst = Right(1)
    left_inst = Left(2)

    return right_inst.to_lazy().value == 1 and left_inst.to_lazy().value == 2

# Generated at 2022-06-12 05:03:01.344702
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Right(8).to_lazy()
    assert result.invoke() == 8

    result = Left('value').to_lazy()
    assert result.invoke() == 'value'



# Generated at 2022-06-12 05:03:09.272518
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(5).to_lazy().evaluate() == 5
    assert Either(5)().evaluate() == 5
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 5)
    assert lazy.evaluate() == 5
    from pymonet.monad_try import Try

    try_monad = Try(5)
    assert try_monad.evaluate() == 5
    assert try_monad.get_value() == 5
    not_existing_variable
    assert True


# Generated at 2022-06-12 05:03:15.757197
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()



# Generated at 2022-06-12 05:03:18.160329
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Left('a').to_lazy()



# Generated at 2022-06-12 05:03:19.614713
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy() == Lazy.pure()

# Generated at 2022-06-12 05:03:23.449621
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    val = Right(10)
    result = val.to_lazy()
    assert result == Lazy(lambda: 10)

    val = Left(10)
    result = val.to_lazy()
    assert result == Lazy(lambda: 10)

# Generated at 2022-06-12 05:03:31.119913
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of Either.

    :tests: Either.to_lazy
    """
    from pymonet.lazy import Lazy
    import time

    def value_creator():
        start = time.time()
        time.sleep(1)
        return start

    e = Right(value_creator)
    start = time.time()
    lazy = e.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == start
    assert time.time() - start > 1

# Generated at 2022-06-12 05:03:34.332762
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def result(): return 1

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert Either(1).to_lazy().value()() == 1


# Generated at 2022-06-12 05:03:38.160455
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:03:43.193763
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Create Right monad
    fun = lambda x: x * x
    right = Right(2)

    # convert to lazy monad and call only once.
    lazy = right.to_lazy().get()

    # check if result is the same
    assert lazy() == fun(right.value)

    # Create Left monad
    left = Left(2)

    # convert to lazy monad and call only once.
    lazy = right.to_lazy().get()

    # check if result is the same
    assert lazy() == fun(left.value)



# Generated at 2022-06-12 05:03:46.338993
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(10).to_lazy(), Lazy)
    assert isinstance(Left(10).to_lazy(), Lazy)


# Generated at 2022-06-12 05:03:50.305819
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(0).to_lazy() == Lazy(lambda: 0)
    assert Left(0).to_lazy() == Lazy(lambda: 0)

# Generated at 2022-06-12 05:03:57.451229
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Right(5).to_lazy().value() == 5
    assert Left(5).to_lazy().value() == 5
    assert isinstance(Right(5).to_lazy(), Lazy)



# Generated at 2022-06-12 05:04:01.467905
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f(x):
        return x

    either = Right(2)
    lazy_result = either.to_lazy()
    assert lazy_result.force() == 2
    assert type(lazy_result) == either.to_lazy().__class__


# Generated at 2022-06-12 05:04:08.525491
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Either(1).to_lazy() == Lazy(lambda: 1)
    assert Either(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Either(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Either([1]).to_lazy() == Lazy(lambda: [1])


# Generated at 2022-06-12 05:04:14.276416
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def _test_Either_to_lazy(either_value):
        assert either_value.to_lazy().value() is either_value.value

    _test_Either_to_lazy(Right(1))
    _test_Either_to_lazy(Left("error"))



# Generated at 2022-06-12 05:04:17.316625
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Left(3).to_lazy()
    assert Lazy(lambda: 3) == Right(3).to_lazy()



# Generated at 2022-06-12 05:04:20.528754
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(a, b):
        return a + b
    # Create lazy monad with add function
    result = add(1, 2)
    assert result == 3

# Generated at 2022-06-12 05:04:25.126163
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test for method to_lazy of class Either."""
    from pymonet.lazy import Lazy

    assert Left(100).to_lazy() == Lazy(lambda: 100)
    assert Right(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-12 05:04:27.148151
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert type(Right(1).to_lazy()) == Lazy
    assert type(Left(2).to_lazy()) == Lazy


# Generated at 2022-06-12 05:04:31.323076
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either.
    """
    result = Left(1).to_lazy().memoized_value
    assert(isinstance(result, Lazy))
    result2 = Right(1).to_lazy().memoized_value
    assert(isinstance(result2, Lazy))
    assert(result.value == 1)
    assert(result2.value == 1)



# Generated at 2022-06-12 05:04:32.532327
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().value() == 5


# Generated at 2022-06-12 05:04:41.812938
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Check if convertation to Lazy work correctly.
    """
    import pytest

    assert Either.to_lazy(Right(1)).force() == 1
    assert Either.to_lazy(Left(1)).force() == 1


# Generated at 2022-06-12 05:04:45.370944
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:04:48.092083
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy() == Lazy(2)
    assert Left(2).to_lazy() == Lazy(2)



# Generated at 2022-06-12 05:04:51.140416
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy function of Either[A].

    :return: Nothing
    :rtype: None
    """
    left = Left(42)
    assert left.to_lazy().force() == 42

    right = Right(42)
    assert right.to_lazy().force() == 42

# Generated at 2022-06-12 05:04:54.818174
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""
    assert isinstance(Left(ValueError('error')).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)



# Generated at 2022-06-12 05:04:57.579816
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    assert Right(10).to_lazy().value == 10
    assert Left(10).to_lazy().value == 10


# Generated at 2022-06-12 05:05:01.442044
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:05:04.298747
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    x = Lazy(lambda: 12)
    assert Left(12).to_lazy() == x
    assert Right(12).to_lazy() == x


# Generated at 2022-06-12 05:05:07.655429
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Either[int](1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:05:10.252638
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:05:25.215972
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert isinstance(Right(4).to_lazy(), Lazy)
    assert isinstance(Left(4).to_lazy(), Lazy)
    assert Right(4).to_lazy().value == 4
    assert Left(4).to_lazy().value == 4



# Generated at 2022-06-12 05:05:29.395262
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def divide_by_three(x):
        return x/3.0

    assert Either(5).to_lazy().map(divide_by_three).get() == 1.6666666666666667
    assert Either(5).to_lazy().map(lambda x: x/3.0).get() == 1.6666666666666667


# Generated at 2022-06-12 05:05:33.655047
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert [1, 2, 3] == Lazy(lambda: Left(1)).to_lazy().force()
    assert [1, 2, 3] == Lazy(lambda: Right(1)).to_lazy().force()



# Generated at 2022-06-12 05:05:39.904225
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >>> left = Left("left")
    >>> lazy_left = left.to_lazy()
    >>> assert callable(lazy_left.value)
    >>> assert lazy_left.is_lazy()
    >>> right = Right("right")
    >>> lazy_right = right.to_lazy()
    >>> assert callable(lazy_right.value)
    >>> assert lazy_right.is_lazy()
    """
    pass



# Generated at 2022-06-12 05:05:44.240203
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    left = Left(5)
    right = Right(5)
    assert left.to_lazy().evaluate() == 5
    assert right.to_lazy().evaluate() == 5
    assert left.to_lazy().evaluate(5) == 5



# Generated at 2022-06-12 05:05:50.202230
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 4) == Either(4).to_lazy()
    assert Lazy(lambda: 'foo') == Either('foo').to_lazy()
    assert Lazy(lambda: Try(5, is_success=True)) == Right(Try(5, is_success=True)).to_lazy()
    assert Lazy(lambda: Try('foo', is_success=True)) == Right(Try('foo', is_success=True)).to_lazy()


# Generated at 2022-06-12 05:05:59.426360
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    val1 = Either.left(Maybe.just(1))
    assert val1.to_lazy().val() == 1

    val2 = Either.left(Maybe.nothing())
    assert val2.to_lazy().val() == None

    val3 = Either.right(Maybe.just('hello'))
    assert val3.to_lazy().val() == 'hello'

    val4 = Either.right(Maybe.nothing())
    assert val4.to_lazy().val() == None



# Generated at 2022-06-12 05:06:03.081529
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import identity

    assert Right(1).to_lazy() == Lazy(identity(1))
    assert Left("err").to_lazy() == Lazy(identity("err"))


# Generated at 2022-06-12 05:06:04.761416
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(5)) == Either.to_lazy(Left(5))

# Generated at 2022-06-12 05:06:13.585119
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor_functions import compose
    from pymonet.monad_functions import bind

    def f1(value):
        return value * 2

    def f2(value):
        return value * 3

    def f3(value):
        return value * 5

    funcs = [f1, f2, f3]

    identity = lambda x: x

    expected = Lazy(lambda: f1(f2(f3(2))))
    actual = Either(2).to_lazy().to_right().bind(compose(*funcs)).to_lazy()

    assert expected == actual

# Generated at 2022-06-12 05:06:40.669259
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert "test" == Left("test").to_lazy().force()
    assert "test1" == Right("test1").to_lazy().force()


# Generated at 2022-06-12 05:06:44.384071
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    # When
    result = Left(1).to_lazy()

    # Then
    assert result == Lazy(lambda: 1)

    # When
    result = Right(1).to_lazy()

    # Then
    assert result == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:47.943545
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy method of class Either.
    """
    assert Left(2).to_lazy().value() == 2
    assert Right(2).to_lazy().value() == 2

# Generated at 2022-06-12 05:06:52.239146
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:06:58.032864
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def error(arg):
        return 'error'

    def success(arg):
        return 'success'

    cases = [
        (Left(1), 'error'),
        (Right(2), 'success'),
        (Left('a'), 'error'),
        (Right('b'), 'success')
    ]

    for case in cases:
        assert case[0].to_lazy().force() == case[1]



# Generated at 2022-06-12 05:07:01.855814
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'foo') == Either.to_lazy('foo')
    assert Lazy(lambda: 'bar') == Either.to_lazy('bar')


# Generated at 2022-06-12 05:07:03.663635
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).map(lambda x: x + 1).ap(Either(lambda x: x + 10)).to_lazy().evaluate() == 12

# Generated at 2022-06-12 05:07:10.537398
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import id_
    from pymonet.either import Left, Right

    def number_to_string(value: int) -> str:
        return str(value)

    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() != Lazy(lambda: 10)
    assert Right(10).to_lazy().map(number_to_string) == Lazy(lambda: "10")
    assert Right(10).to_lazy().map(number_to_string).map(id_) == Lazy(lambda: "10")


# Generated at 2022-06-12 05:07:13.380176
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def func(a, b):
        return a + b

    either = Either[int](func)
    assert either.to_lazy()()(2, 2) == 4

# Generated at 2022-06-12 05:07:16.722173
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)

# Generated at 2022-06-12 05:07:49.028980
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    # given
    either_5: Either[int] = Right(5)

    # when
    lazy_of_either_5: Lazy[int] = either_5.to_lazy()

    # then
    assert lazy_of_either_5.value == 5


# Generated at 2022-06-12 05:07:54.502288
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    assert Either(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Either(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Either(Left(1)).to_lazy() == Lazy(lambda: Left(1))
    assert Either(Right(1)).to_lazy() == Lazy(lambda: Right(1))



# Generated at 2022-06-12 05:07:56.204735
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:08:01.291541
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    import pytest

    def test_Either_to_lazy_Left(nothing):
        # type: (int) -> None
        v = Either.Left(nothing)
        actual = v.to_lazy()
        expected = Lazy(lambda: nothing)
        assert actual == expected

    def test_Either_to_lazy_Right(nothing):
        # type: (int) -> None
        v = Either.Right(nothing)
        actual = v.to_lazy()
        expected

# Generated at 2022-06-12 05:08:07.036404
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_right_1: Lazy[int] = Either.right(3).to_lazy()
    assert lazy_right_1.value() == 3

    lazy_right_2: Lazy[int] = Either.right(5).to_lazy()
    assert lazy_right_2.value() == 5

    lazy_right_3: Lazy[int] = Either.left(3).to_lazy()
    assert lazy_right_3.value() == 3

    lazy_right_4: Lazy[int] = Either.left(5).to_lazy()
    assert lazy_right_4.value() == 5


# Generated at 2022-06-12 05:08:14.346391
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    >> Left(3).to_lazy()
    Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x0236C1E0>)
    >> Right(3).to_lazy()
    Lazy(<function Either.to_lazy.<locals>.<lambda> at 0x0236C2F0>)
    """
    from pymonet.lazy import Lazy

    assert(Left(3).to_lazy() == Lazy(lambda: 3))
    assert(Left('Hello').to_lazy() == Lazy(lambda: 'Hello'))
    assert(Right(3).to_lazy() == Lazy(lambda: 3))
    assert(Right('Hello').to_lazy() == Lazy(lambda: 'Hello'))


# Generated at 2022-06-12 05:08:16.301678
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    lazy = Either('a').to_lazy()

    assert lazy.is_resolved() == True
    assert lazy.get() == 'a'



# Generated at 2022-06-12 05:08:20.681609
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    lazy_from_left = Left(1).to_lazy()
    lazy_from_right = Right(2).to_lazy()

    assert lazy_from_left == Lazy(lambda: 1)
    assert lazy_from_right == Lazy(lambda: 2)



# Generated at 2022-06-12 05:08:22.419587
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(2).to_lazy() == Lazy(lambda: 2)
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:08:27.021392
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 1) == Left(1).to_lazy()
