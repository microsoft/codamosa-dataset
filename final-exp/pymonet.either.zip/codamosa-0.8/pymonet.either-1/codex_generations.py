

# Generated at 2022-06-12 04:58:47.991767
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)

# Generated at 2022-06-12 04:58:50.622071
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def a_func():
        pass

    assert Left(a_func).to_lazy().evaluate() == a_func
    assert Right(a_func).to_lazy().evaluate() == a_func


# Generated at 2022-06-12 04:58:58.181528
# Unit test for method case of class Either
def test_Either_case():
    message = 'fail'
    f1 = lambda x: message
    f2 = lambda x: x
    left = Left('fail')
    right = Right('success')

    assert left.case(f1, f2) == message, 'test_Either_case, case on left should return result of error function'
    assert right.case(f1, f2) == right.value, 'test_Either_case, case on right should return value of right'



# Generated at 2022-06-12 04:59:00.133015
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(111).to_lazy().value() == 111
    assert Right(111).to_lazy().value() == 111


# Generated at 2022-06-12 04:59:02.339599
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:59:05.026294
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 04:59:13.513029
# Unit test for method case of class Either
def test_Either_case():

    error_called = False
    success_called = False

    def error_handler(error):
        nonlocal error_called
        error_called = True
        return error

    def success_handler(success):
        nonlocal success_called
        success_called = True
        return success

    error = Left('error')
    assert error.case(error_handler, success_handler) == 'error'
    assert error_called
    assert not success_called

    success = Right('success')
    assert success.case(error_handler, success_handler) == 'success'
    assert success_called
    assert not error_called

# Generated at 2022-06-12 04:59:16.837169
# Unit test for method case of class Either
def test_Either_case():
    left = Left(10)
    right = Right(10)

    assert left.case(lambda x: x - 1, lambda x: x + 1) == 9
    assert right.case(lambda x: x - 1, lambda x: x + 1) == 11

# Generated at 2022-06-12 04:59:21.550010
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for method to_lazy of class Either
    """

    either = Either(5)
    assert either.to_lazy().value() == 5

    either_left = Either(-1)
    assert either_left.to_lazy().value() == -1



# Generated at 2022-06-12 04:59:24.612021
# Unit test for method case of class Either
def test_Either_case():
    """
    >>> error_func = lambda x: x + 1
    >>> success_func = lambda x: x * 2
    >>> print(Left(1).case(error_func, success_func))
    2
    >>> print(Right(1).case(error_func, success_func))
    2
    """


# Generated at 2022-06-12 04:59:34.504197
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(1) == Either(1)
    assert Either(1) != Either(2)
    assert Either(1) != Either(2)
    assert Either(2) != Either(1)
    assert Either(1) == Either(1)
    assert not Either(1) == Either(2)
    assert not Either(2) == Either(1)
    assert Either(1) != Either(2)
    assert Either(2) != Either(1)
    assert not Either(1) == Either(2)
    assert not Either(1) == Either(2)
    assert not Right(1) == Left(1)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert not Right(1) == Left(1)


# Generated at 2022-06-12 04:59:39.388518
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(None) == Either(None)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Either(1)
    assert Either(1) != Left(1)
    assert Right(1) != Either(1)
    assert Either(1) != Right(1)



# Generated at 2022-06-12 04:59:46.717103
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.monad_maybe import Maybe

    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)
    assert Left(2) != Right(1)
    assert Right(2) != Left(1)

    assert Left(1).to_maybe() == Left(1).to_maybe()
    assert Left(1).to_maybe() == Maybe.nothing()
    assert Maybe.nothing() == Left(1).to_maybe()



# Generated at 2022-06-12 04:59:49.881591
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.functions import add
    from pymonet.lazy import Lazy

    actual = Left('Error').to_lazy()
    assert actual == Lazy(lambda: 'Error')



# Generated at 2022-06-12 04:59:51.016327
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    pass



# Generated at 2022-06-12 04:59:55.301910
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Left(5) != Left('5')
    assert Right(5) == Right(5)
    assert Right(5) != Right('5')
    assert Left(5) != Right(5)


# Generated at 2022-06-12 04:59:59.319952
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right(10)) == Lazy(lambda: 10)
    assert Either.to_lazy(Left('error')) == Lazy(lambda: 'error')


# Generated at 2022-06-12 05:00:02.260559
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(True) == Left(True)
    assert Left(True) != Left(False)
    assert Right(True) == Right(True)
    assert Right(True) != Right(False)

# Generated at 2022-06-12 05:00:05.183037
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Arrange & Act
    right = Right(1).to_lazy()
    left = Left(2).to_lazy()

    # Assert
    assert right.value() == 1
    assert left.value() == 2

# Generated at 2022-06-12 05:00:10.928017
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    succ, err = 1, 2
    same_succ, other_succ = 'same', 'another'
    same_err, other_err = 'same', 'another'

    assert Either(succ) == Right(same_succ)
    assert Either(succ) != Right(other_succ)
    assert Either(succ) != Left(same_err)
    assert Either(succ) != Left(other_err)
    assert Either(err) != Right(same_succ)
    assert Either(err) != Right(other_succ)
    assert Either(err) == Left(same_err)
    assert Either(err) != Left(other_err)

# Generated at 2022-06-12 05:00:20.829679
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 4) == Either(4).to_lazy()
    assert Lazy(lambda: 'test') == Either('test').to_lazy()
    assert Lazy(lambda: {'key': 5}) == Either({'key': 5}).to_lazy()
    assert Lazy(lambda: [5, 2, 3]) == Either([5, 2, 3]).to_lazy()
    assert Lazy(lambda: None) == Either(None).to_lazy()



# Generated at 2022-06-12 05:00:27.429733
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Left(1) != Right('1')
    assert Left('1') != Left(1)
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Right(1) != None
    assert Left(1) != None

# Generated at 2022-06-12 05:00:33.209984
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.box import Box

    assert Either(Box(1)) == Either(Box(1)) and\
        Left(Box(1)) == Left(Box(1)) and\
        Right(Box(1)) == Right(Box(1)) and\
        Either(Box(1)) != Either(Box(2)) and\
        Left(Box(1)) != Left(Box(2)) and\
        Right(Box(1)) != Right(Box(2)) and\
        Left(Box(1)) != Right(Box(1)) and\
        Right(Box(1)) != Left(Box(1))

# Generated at 2022-06-12 05:00:40.017415
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left('a') == Left('a')
    assert not Left('a') == Left('b')
    assert not Left('a') == Right('a')
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)
    assert not Right(1) == 1
    assert not Left('a') == 'a'

# Unit test method case of class Either

# Generated at 2022-06-12 05:00:41.709288
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(42) != Right(42)



# Generated at 2022-06-12 05:00:45.306018
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:00:53.334950
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_0 = Left("left_0")
    left_1 = Left("left_0")

    # Test _eq with the same Right
    assert left_0 == left_0, "Either[A].__eq__ not pass"

    # Test _eq with different Right
    assert left_0 == left_1, "Either[A].__eq__ not pass"

    right_0 = Right("right_0")
    right_1 = Right("right_0")

    # Test _eq with the same Right
    assert right_0 == right_0, "Either[A].__eq__ not pass"

    # Test _eq with different Right
    assert right_0 == right_1, "Either[A].__eq__ not pass"


# Generated at 2022-06-12 05:00:57.506901
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left(2)
    assert Right(1) != Right(2)
    assert Left(1) != Right(1)
    assert Right(1) != Left(1)


# Generated at 2022-06-12 05:01:05.906680
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Success, Failure
    from pymonet.box import Box

    assert Left(1) == Left(1)
    assert not Left(1) == Left(2)
    assert not Left(1) == Right(1)
    assert Right(1) == Right(1)
    assert not Right(1) == Right(2)
    assert not Right(1) == Left(1)
    assert Success(1) == Success(1)
    assert not Success(1) == Success(2)
    assert not Success(1) == Failure(1)
    assert Failure(1) == Failure(1)
    assert not Failure(1) == Failure(2)
    assert not Failure(1) == Success(1)

# Generated at 2022-06-12 05:01:07.358549
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Either(2) == Either(2)



# Generated at 2022-06-12 05:01:17.465856
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)
    assert Right(1) != Left(2)
    assert Left(1) != Right(2)
    assert Right(1) != None
    assert Left(1) != None
    assert Right(1) != 1
    assert Left(1) != 1

# Generated at 2022-06-12 05:01:20.916053
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either(2).to_lazy().value(None) == 2
    assert Left(1).to_lazy().value(None) == 1
    assert Right(0).to_lazy().value(None) == 0


# Generated at 2022-06-12 05:01:23.955606
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(1) == Left(1)
    assert Right(1) == Right(1)
    assert Left(1) != Left('1')
    assert Right(1) != Right('1')


# Generated at 2022-06-12 05:01:26.070518
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(4).to_lazy().get() == 4
    assert Left(4).to_lazy().get() == 4


# Generated at 2022-06-12 05:01:32.809206
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    def eq(e1, e2):
        return e1.__eq__(e2)

    assert eq(Right(1), Right(1)) is True
    assert eq(Right(1), Right(2)) is False
    assert eq(Left(1), Left(1)) is True
    assert eq(Left(1), Left(2)) is False
    assert eq(Right(1), Left(1)) is False
    assert eq(Left(1), Right(1)) is False



# Generated at 2022-06-12 05:01:35.827717
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(5) == Left(5)
    assert Left(5) != Right(5)
    assert Right(5) == Right(5)
    assert Right(5) != Left(5)


# Generated at 2022-06-12 05:01:38.916047
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Right(1) == Right(1)
    assert Left(1) == Left(1)
    assert Right(1) != Left(1)
    assert Left(1) != Right(1)


# Generated at 2022-06-12 05:01:44.514439
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    left_a = Left(1)
    left_b = Left(1)
    right_a = Right(1)
    right_b = Right(1)

    assert left_a.__eq__(left_b) is True
    assert left_a.__eq__(right_a) is False
    assert right_a.__eq__(right_b) is True
    assert right_a.__eq__(left_a) is False

test_Either___eq__()




# Generated at 2022-06-12 05:01:47.786645
# Unit test for method __eq__ of class Either
def test_Either___eq__():
    assert Left(2) == Left(2)
    assert Right(2) == Right(2)
    assert Left(2) == Right(2) is False
    assert Right(2) == Left(2) is False



# Generated at 2022-06-12 05:01:50.005905
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(2).to_lazy().resolve() == 2
    assert Left(1).to_lazy().resolve() == 1


# Generated at 2022-06-12 05:01:55.439267
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def f():
        return "a"

    assert Either(f).to_lazy() == Lazy(f)

# Generated at 2022-06-12 05:01:59.974383
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # given
    from pymonet.lazy import Lazy

    either = Right(314)

    # when
    result = either.to_lazy()

    # then
    assert isinstance(result, Lazy)
    assert result.invoke() == either.value, "Should return Lazy with function returning either value"


# Generated at 2022-06-12 05:02:03.005572
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def test_value() -> int:
        return 1

    assert Right(1).to_lazy() == Lazy(test_value)
    assert Left(1).to_lazy() == Lazy(test_value)


# Generated at 2022-06-12 05:02:09.766351
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyType

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert isinstance(Left(1).to_lazy(), Lazy)
    assert isinstance(Right(1).to_lazy(), Lazy)
    assert Either(5).to_lazy().get_type() == LazyType.STRICT
    assert Left(5).to_lazy().get_type() == LazyType.STRICT
    assert Right(5).to_lazy().get_type() == LazyType.STRICT
    assert Either(5).to_lazy().get() == 5
    assert Left(5).to_lazy().get() == 5
    assert Right(5).to_lazy().get() == 5



# Generated at 2022-06-12 05:02:12.180764
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(123).to_lazy().value() == 123
    assert Left(123).to_lazy().value() == 123


# Generated at 2022-06-12 05:02:15.178640
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    either_string = Either("abc")
    actual = either_string.to_lazy()
    expected = Lazy("abc")
    assert actual == expected



# Generated at 2022-06-12 05:02:26.580320
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_mapper(a): return a + 1
    assert Left(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Right(1).to_lazy().map(lazy_mapper) == Lazy(lambda: 2)
    assert Left(1).to_lazy().bind(lazy_mapper) == Lazy(lambda: 1)
    assert Right(1).to_lazy().bind(lazy_mapper) == Lazy(lambda: 2)
    assert Left(1).to_lazy().ap(Lazy(lambda: lazy_mapper)) == Lazy(lambda: 1)

# Generated at 2022-06-12 05:02:30.304798
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Left(None).to_lazy() == Lazy(None)
    assert Right(13).to_lazy() == Lazy(13)



# Generated at 2022-06-12 05:02:34.246716
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    lazy_even = Either.Right(2).to_lazy()
    lazy_odd = Either.Left(5).to_lazy()

    assert lazy_even.equals(Lazy(lambda: 2))
    assert lazy_odd == Either.Left(5).to_lazy()


# Generated at 2022-06-12 05:02:39.432849
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Either(Box(7)).to_lazy() == Lazy(lambda: Box(7)), "Either should be convertable to lazy with its stored value"


# Generated at 2022-06-12 05:02:46.923108
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy().get() == 1
    assert Left(2).to_lazy().get() == 2


# Generated at 2022-06-12 05:02:49.716538
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:02:52.226684
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Right(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:03:00.761351
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Test unit for method to_lazy of class Right
    def test_Right_to_lazy():
        # Test unit for method value_f of class Lazy
        def test_Lazy_value_f():
            # Declare variables
            expected = 1
            right = Right(expected)
            actual = right.to_lazy().value_f()

            assert (expected == actual), "Expected %s but got %s" % (expected, actual)

        # Test unit for method value of class Lazy
        def test_Lazy_value():
            # Declare variables
            expected = 1
            right = Right(expected)
            actual = right.to_lazy().value

            assert (expected == actual), "Expected %s but got %s" % (expected, actual)

        # Run unit tests
        test_Lazy_

# Generated at 2022-06-12 05:03:11.851801
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Check all monad laws for Either to Lazy
    """
    from pymonet.lazy import Lazy, compose
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    # Lazy(Lazy) == Lazy(Lazy)
    assert (
        Lazy(Left([]).to_lazy()) ==
        Lazy(Left([]).to_lazy())
    )

    # Lazy(Lazy(a).bind(f)) == Lazy(a).bind(Lazy(f))
    assert (
        Lazy(Left([]).to_lazy().bind(Box)) ==
        Lazy(Left([]).to_lazy()).bind(Lazy(lambda a: Box(a)))
    )

   

# Generated at 2022-06-12 05:03:15.457537
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(1).to_lazy().map(lambda x: x + 2).force() == 1
    assert Right(1).to_lazy().map(lambda x: x + 2).force() == 3


# Generated at 2022-06-12 05:03:19.470824
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # ARRANGE
    from pymonet.lazy import Lazy

    either = Left(2)
    lazy = Lazy(lambda: 2)

    # ACT
    result = either.to_lazy()

    # ASSERT
    assert lazy == result


# Generated at 2022-06-12 05:03:22.973336
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    with description('to_lazy test'):
        with it('should return lazy with function'):
            expect(Left('error').to_lazy().force()).to(equal('error'))
            expect(Right('success').to_lazy().force()).to(equal('success'))

# Generated at 2022-06-12 05:03:30.974330
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test to_lazy of Either class.
    """
    from pymonet.lazy import Lazy

    Lazy(lambda: 10)\
        .map(lambda x: x + 10) == Lazy(lambda: 20)\
        .map(lambda x: x + 10) == Right(20).to_lazy()
    Lazy(lambda: 10)\
        .map(lambda x: x - 10) == Lazy(lambda: 0)\
        .map(lambda x: x - 10) == Left(0).to_lazy()



# Generated at 2022-06-12 05:03:33.585267
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    right = Right(lambda x: x + 2)
    lazy = right.to_lazy()
    lazy.eval()
    assert lazy.eval()(2) == 4


# Generated at 2022-06-12 05:03:46.146860
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    result = Either(1).to_lazy()
    expected = 1
    assert result.value() == expected

# Generated at 2022-06-12 05:03:51.749960
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    :returns: True if function return boxed value
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 123) == Right(123).to_lazy()
    assert Lazy(lambda: '123') == Right(lambda: '123').to_lazy()
    return True


# Generated at 2022-06-12 05:03:57.747692
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Test Either in action
    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def test_function():
        return "pymonet"

    value = Lazy(test_function)

    unit_test = Left(Box(value)).to_lazy()

    assert unit_test.value == value.value



# Generated at 2022-06-12 05:04:01.517446
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Right(1).to_lazy()
    assert Lazy(lambda: 2) == Left(2).to_lazy()



# Generated at 2022-06-12 05:04:07.321179
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from pymonet.either import Right
    from pymonet.either import Left

    a = "I am lazy"
    b = Lazy(lambda: a)
    right = Right(a)
    left = Left(a)

    assert right.to_lazy() == b
    assert left.to_lazy() == b

# Generated at 2022-06-12 05:04:15.696478
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():

    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Either[int].Left(2).to_lazy() == Lazy(lambda: 2)
    assert Either[int].Right(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:04:19.289636
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Either.to_lazy(Right('a')) == Lazy(lambda: 'a')
    assert Either.to_lazy(Left('a')) == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:04:26.594412
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    value = 'value'

    # When
    result = Left(value).to_lazy()

    # Then
    assert isinstance(result, Lazy)
    assert result.value() == value
    assert result.to_box().value == value
    assert result.to_try().is_success
    assert result.to_try().value == value


# Generated at 2022-06-12 05:04:33.027399
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Unit test for to_lazy method of class Either

    :returns: Nothing
    :rtype: None
    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy: Lazy[int] = Right(3).to_lazy()

    assert lazy.value() == 3

    lazy = Left(Box('a')).to_lazy()

    assert lazy.value() == Box('a')


# Generated at 2022-06-12 05:04:39.486121
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def f(x): return x

    assert isinstance(Either(1).to_lazy(), Lazy)
    assert Either(1).to_lazy().force == 1

    assert isinstance(Left(1).to_lazy(), Lazy)
    assert Left(1).to_lazy().force == 1



# Generated at 2022-06-12 05:05:03.680748
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left(5).to_lazy() == Lazy(lambda: 5)
    assert Right(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 05:05:08.606605
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    # Given
    expected = 'foo'
    either = Left(expected)

    # When
    lazy = either.to_lazy()
    res = lazy.run()

    # Then
    assert res == expected


# Generated at 2022-06-12 05:05:15.928039
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def get_value() -> int:
        return 5

    def get_value_error() -> int:
        return -5

    assert isinstance(Left(get_value_error()).to_lazy(), Lazy)
    assert isinstance(Right(get_value()).to_lazy(), Lazy)
    assert Left(get_value_error()).to_lazy().get() == get_value_error()
    assert Right(get_value()).to_lazy().get() == get_value()

# Generated at 2022-06-12 05:05:17.545602
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Left('value').to_lazy().value() == 'value'
    assert Right('value').to_lazy().value() == 'value'

# Generated at 2022-06-12 05:05:22.474644
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Test to_lazy of Either monad."""
    from pymonet.lazy import Lazy

    assert Left('error').to_lazy() == Lazy(lambda: 'error')
    assert Right(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:05:25.257968
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert not Lazy(lambda: Right(10)).value().is_right()
    assert Lazy(lambda: Right(10)).value().value == 10


# Generated at 2022-06-12 05:05:31.724901
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    # Test Either to Lazy
    assert Either(Try(True)).to_lazy() == Lazy(lambda: Try(True))
    assert Either(Maybe.nothing()).to_lazy() == Lazy(lambda: Maybe.nothing())
    assert Either(Box(True)).to_lazy() == Lazy(lambda: Box(True))

    # Test Left to Lazy
    assert Left(Try(True)).to_lazy() == Lazy(lambda: Try(True))
    assert Left(Maybe.nothing()).to_lazy() == Lazy(lambda: Maybe.nothing())
    assert Left(Box(True)).to_lazy() == Lazy

# Generated at 2022-06-12 05:05:36.363841
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from typing import Callable

    f: Callable[[int], int] = lambda a: a + 1
    either: Either[int] = Right(f)
    lazy: Lazy[Callable[[int], int]] = either.to_lazy()

    assert lazy.value()(2) == 3



# Generated at 2022-06-12 05:05:43.105804
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def add(a, b):
        return a + b

    def subtract(a, b):
        return a - b

    assert Left(1).to_lazy().map(add, 10).value == 1
    assert Right(1).to_lazy().map(add, 10).value == 11
    assert Left(1).to_lazy().bind(add, 10).value == 1
    assert Right(1).to_lazy().bind(add, 10).value == 11
    assert Right(1).to_lazy().map(subtract, 10).value == -9
    assert Right(1).to_lazy().bind(subtract, 10).value == -9



# Generated at 2022-06-12 05:05:46.338286
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(5).to_lazy().resolve() == 5
    assert Left(5).to_lazy().resolve() == 5


# Generated at 2022-06-12 05:06:41.742799
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:06:43.133827
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Identity(10).to_lazy().get() == 10



# Generated at 2022-06-12 05:06:47.943568
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """Unit test for method to_lazy of class Either"""

    from pymonet.lazy import Lazy

    assert Either(10).to_lazy() == Lazy(lambda: 10)
    assert Left(10).to_lazy() == Lazy(lambda: 10)
    assert Right(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:06:53.385284
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    """
    Tests to_lazy function with Right and Left values
    """
    from pymonet.lazy import Lazy
    from pymonet.lazy import State

    assert Right(1).to_lazy() == Lazy(lambda: 1)
    assert Left(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:07:00.856172
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_stream import LazyStream
    from pymonet.box import Box

    assert Either(Box(100)).to_lazy() == Lazy(lambda: Box(100))
    assert Either(Lazy(lambda: 100)).to_lazy() == Lazy(lambda: Lazy(lambda: 100))
    assert Either(LazyStream([1, 2, 3])).to_lazy() == Lazy(lambda: LazyStream([1, 2, 3]))

# Generated at 2022-06-12 05:07:07.123050
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    def is_even(number):
        return number % 2 == 0

    def get_item_from_dict(dictionary, key):
        return dictionary[key]

    dictionary = {"key1": "value1", "key2": "value2"}
    
    assert(Left(dictionary).to_lazy().value() is dictionary)
    assert(Right("value1").to_lazy().value() == "value1")

    assert(Left(dictionary).to_lazy().map(get_item_from_dict, "key1") == Left(dictionary))
    assert(Left(dictionary).to_lazy().map(get_item_from_dict, "key3") == Left(dictionary))

# Generated at 2022-06-12 05:07:09.671298
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    assert Right(42).to_lazy().is_memoized() is False
    assert Right(42).to_lazy().get() == Right(42).value


# Generated at 2022-06-12 05:07:11.976748
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    def one():
        return 1

    assert Right(1).to_lazy() == Lazy(one)


# Generated at 2022-06-12 05:07:15.705047
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: '2') == Left(2).to_lazy()
    assert Lazy(lambda: 2) == Right(2).to_lazy()


# Generated at 2022-06-12 05:07:19.092013
# Unit test for method to_lazy of class Either
def test_Either_to_lazy():
    @Lazy
    def lazy_function(value):
        print('I will not be called until this.value()')
        return value

    # None has NoneType, so it is not possible to create Right(None)
    assert Right(lazy_function(5)).to_lazy().map(lambda x: x()).value() == 5