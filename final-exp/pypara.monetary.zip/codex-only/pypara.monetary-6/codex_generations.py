

# Generated at 2022-06-24 01:18:36.951356
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    import datetime
    from pytest import raises
    from dataclasses import dataclass
    from financepy.products.bonds.FinBond import FinBond
    from financepy.products.bonds.FinBondYield import FinBondYield
    from financepy.products.bonds.FinBondYieldConvention import FinBondYieldConvention
    from financepy.finutils.FinFrequency import FinFrequencyTypes
    from financepy.finutils.FinDayCount import FinDayCountTypes
    from financepy.finutils.FinDate import FinDate
    coupon = 0.05
    freqType = FinFrequencyTypes.ANNUAL
    accrualType = FinDayCountTypes.ACT_ACT_ICMA
    settlementDate = FinDate(1,1,2008)

# Generated at 2022-06-24 01:18:41.129617
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    assert abs(NoPrice) is NoPrice
    assert isinstance(abs(NoPrice), (SomePrice, NonePrice))

# Generated at 2022-06-24 01:18:47.335792
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert SomeMoney(USD, Decimal("12.3000"), Date(2018, 12, 12)).is_equal(SomeMoney(USD, Decimal("12.300"), Date(2018, 12, 12)))
    assert not SomeMoney(USD, Decimal("12.3000"), Date(2018, 12, 12)).is_equal(SomeMoney(USD, Decimal("12.300"), Date(2018, 12, 10)))
    return

# Generated at 2022-06-24 01:18:52.013682
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    from .currency import Currency as __Currency
    from .price import Price as __Price
    from datetime import date as __date
    from decimal import Decimal as __Decimal
    p11 = __Price.of(__Currency("USD"), __Decimal("100.00"), __date(2018, 11, 1))
    p12 = __Price.of(__Currency("USD"), __Decimal("100.00"), __date(2018, 11, 1))
    p13 = __Price.of(__Currency("USD"), __Decimal("101.00"), __date(2018, 11, 1))
    p14 = __Price.of(__Currency("USD"), __Decimal("100.00"), __date(2018, 11, 2))

# Generated at 2022-06-24 01:19:01.768477
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    """
    Tests that the product of a Currency and a Decimal is a Money object,
    which is the same as the sum of the product of the Currency and the sign of
    the Decimal, and the Decimal.
    """

    n1: Decimal = Decimal("-3.14")
    n2: Decimal = Decimal("2.3")
    USD: Currency = Currency("USD")
    DKK: Currency = Currency("DKK")
    today: Date = Date("2018-03-06")
    USD_n1: Money = Money.of(USD, n1, today)
    USD_n2: Money = Money.of(USD, n2, today)
    DKK_n1: Money = Money.of(DKK, n1, today)

# Generated at 2022-06-24 01:19:04.890273
# Unit test for method __int__ of class Money
def test_Money___int__():
    # Arrange
    from .currencies import CURRENCIES
    from .money import Money, SomeMoney

    USD_100 = Money.of(CURRENCIES.USD, 100, Date("2019-01-01"))

    # Act
    result = int(USD_100)

    # Assert
    assert isinstance(result, int)
    assert result == 100

# Generated at 2022-06-24 01:19:12.890368
# Unit test for method round of class Price
def test_Price_round():
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round() == 2
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round(0) == 2
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round(1) == 1.1
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round(2) == 1.11
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round(3) == 1.106
    assert Price.of(Currency.USD, 1.1055, Date(2019, 7, 1)).round(-1) == 1.

# Generated at 2022-06-24 01:19:23.456925
# Unit test for constructor of class Price
def test_Price():
    someprice = Price.of(ccy=Currency.of('EUR'), qty=Decimal(1.0), dov=Date(1,1,1))
    assert isinstance(someprice, Price)
    assert isinstance(someprice, SomePrice)
    assert someprice.ccy == Currency.of('EUR')
    assert someprice.qty == Decimal(1.0)
    assert someprice.dov == Date(1,1,1)
    assert someprice.qty == Decimal(1.0)
    assert someprice.defined
    assert not someprice.undefined
    with pytest.raises(TypeError):
        someprice.money
    with pytest.raises(TypeError):
        someprice.ccy
    with pytest.raises(TypeError):
        someprice.d

# Generated at 2022-06-24 01:19:34.045398
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert Money.of(None, None, None).is_equal(Money.of(None, None, None)) == True
    assert Money.of(Currency.of('CAD'), Decimal('100.00'), Date.of('2018/01/01')).is_equal(Money.of(Currency.of('CAD'), Decimal('100.00'), Date.of('2018/01/01'))) == True
    assert Money.of(Currency.of('CAD'), Decimal('100.00'), Date.of('2018/01/01')).is_equal(Money.of(Currency.of('CAD'), Decimal('100.00'), Date.of('2018/01/01'))) == True
    return True


# Generated at 2022-06-24 01:19:35.730587
# Unit test for method add of class Price
def test_Price_add():
    with pytest.raises(MonetaryOperationException):
        Price(USD, Decimal(0), date(2018, 1, 1)) + Price(USD, Decimal(1), date(2018, 1, 1))


# Generated at 2022-06-24 01:19:46.293124
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    import core_types as T

    SomePrice(ccy=T.Currency('USD'), qty=T.Decimal('10.00'), dov=T.Date(2020, 3, 1)) // 2
    SomePrice(ccy=T.Currency('USD'), qty=T.Decimal('10.00'), dov=T.Date(2020, 3, 1)) // 2.0
    SomePrice(ccy=T.Currency('USD'), qty=T.Decimal('10.00'), dov=T.Date(2020, 3, 1)) // T.Decimal('2.0')
    SomePrice(ccy=T.Currency('USD'), qty=T.Decimal('10.00'), dov=T.Date(2020, 3, 1)) // T.Decimal('0')

# Generated at 2022-06-24 01:19:56.971605
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    def assert_scalar_subtract(amount, currency, scalar, result):
        c1 = Currency(currency)
        p1 = Price.of(c1, amount, Date(2020, 1, 1))
        p1_minus_scalar = p1.scalar_subtract(scalar)
        assert p1_minus_scalar.qty == result
        assert p1_minus_scalar.ccy == c1

    assert_scalar_subtract(Decimal('10.12345678'), 'USD', 1, Decimal('9.12345678'))  # type: ignore
    assert_scalar_subtract(Decimal('10.12345678'), 'USD', 2, Decimal('8.12345678'))  # type: ignore

# Generated at 2022-06-24 01:20:02.213803
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    price = NoPrice
    assert price.scalar_subtract(0) == NoPrice
    assert price.scalar_subtract(1) == NoPrice
    assert price.scalar_subtract(-1) == NoPrice


# Generated at 2022-06-24 01:20:07.833232
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    from data.currency import Currency as Currency

    from data.date import Date as Date
    
    from data.money import Money as Money

    from data.rate import FXRate as FXRate

    from data.fxrate import MemoryFXRateService as MemoryFXRateService

    from data.math import EPSILON as EPSILON

    MemoryFXRateService.default = MemoryFXRateService()

    MemoryFXRateService.default.add(FXRate(
        Currency.of("CHF"),
        Currency.of("USD"),
        Decimal("1.0836"),
        Date(2018, 11, 20),
    ))

    MemoryFXRateService.default.add(FXRate(
        Currency.of("USD"),
        Currency.of("CHF"),
        Decimal("0.9247"),
        Date(2018, 11, 20),
    ))

    m

# Generated at 2022-06-24 01:20:09.237612
# Unit test for method divide of class Money
def test_Money_divide():
    with raises(MonetaryOperationException):
        Money.NA.divide(42)

# Generated at 2022-06-24 01:20:16.444394
# Unit test for method __round__ of class Money
def test_Money___round__():
    from decimal import Decimal
    from pytest import raises
    from asl_money import Money

    # Given a money object
    money = Money.NA

    # When __round__ is called with no argument,
    # Then an exception should be raised
    with raises(NotImplementedError):
        round(money)

    # When __round__ is called with 0,
    # Then an exception should be raised
    with raises(NotImplementedError):
        round(money, 0)

    # When __round__ is called with 1,
    # Then an exception should be raised
    with raises(NotImplementedError):
        round(money, 1)


# Generated at 2022-06-24 01:20:27.548547
# Unit test for method lt of class Money
def test_Money_lt():
    Money.of(Currency('AUD', 2, 'A$', 'dollar', 'dollars', '', 'Australia'), Decimal(1), Date(2018, 1, 1)).lt(Money.of(Currency('AUD', 2, 'A$', 'dollar', 'dollars', '', 'Australia'), Decimal(2), Date(2018, 1, 1))) is True
    Money.of(Currency('AUD', 2, 'A$', 'dollar', 'dollars', '', 'Australia'), Decimal(1), Date(2018, 1, 1)).lt(Money.of(Currency('AUD', 2, 'A$', 'dollar', 'dollars', '', 'Australia'), Decimal(1), Date(2018, 1, 1))) is False

# Generated at 2022-06-24 01:20:28.266397
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    assert False

# Generated at 2022-06-24 01:20:34.889084
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    # Test case data
    ccy_ = Currency.get_default(USD)
    qty_ = Decimal(100)
    dov_ = datetime.date(2017, 3, 1)
    money_ = SomeMoney(ccy_, qty_, dov_)
    expected = float(qty_)
    # Perform the test
    actual = money_.__float__()
    # Verify the result
    assert actual == expected



# Generated at 2022-06-24 01:20:45.988528
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    """
    Tests equality check on SomePrice.
    """
    #                                                                          +-----------------------+
    #                                                                          |  Method Under Test:   |
    #                                                                          +-----------------------+
    #                                                                          |  SomePrice.__ge__     |
    #                                                                          +-----------------------+
    #                                                                          |  Purpose:             |
    #                                                                          |  - Tests equality     |
    #                                                                          |    check on SomePrice |
    #                                                                          +-----------------------+
    #                                                                          |  Arguments:           |
    #                                                                          |  -  N/A               |
    #                                                                          +-----------------------+
    #                                                                          |  Return:              |


# Generated at 2022-06-24 01:20:57.496772
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    ccy1 = Currency.USD
    qty1 = Decimal(100)
    dov1 = Date(2008, 1, 1)
    mm1  = SomeMoney(ccy1, qty1, dov1)
    ccy2 = Currency.JPY
    qty2 = Decimal(100)
    dov2 = Date(2008, 1, 1)
    mm2  = SomeMoney(ccy2, qty2, dov2)
    ccy3 = Currency.JPY
    qty3 = Decimal(200)
    dov3 = Date(2008, 1, 1)
    mm3  = SomeMoney(ccy3, qty3, dov3)
    ccy4 = Currency.USD
    qty4 = Decimal(100)

# Generated at 2022-06-24 01:21:07.299808
# Unit test for method gt of class Price
def test_Price_gt():
    assert NoPrice.gt(NoPrice) == False
    assert NoPrice.gt(SomePrice(USD, '100.0', date(2020, 8, 31))) == False
    assert NoPrice.gt(SomePrice(USD, '100.0', date(2020, 8, 31))) == False
    assert SomePrice(USD, '100.0', date(2020, 8, 31)).gt(NoPrice) == True
    assert SomePrice(USD, '100.0', date(2020, 8, 31)).gt(SomePrice(USD, '200.0', date(2020, 8, 31))) == False
    assert SomePrice(USD, '200.0', date(2020, 8, 31)).gt(SomePrice(USD, '100.0', date(2020, 8, 31))) == True

# Generated at 2022-06-24 01:21:08.261911
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    """Unit test for method __sub__ of class Money."""
    pass



# Generated at 2022-06-24 01:21:12.363523
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    assert NoPrice/1.0 == NoPrice

# Generated at 2022-06-24 01:21:19.762981
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    """
    Unit test for method with_qty of class SomeMoney
    """
    ccy, qty, dov = Currency.of('EUR'), Decimal('123.45'), Date.of('2019-01-02')
    m = SomeMoney(ccy, qty, dov)

    ## Assert method result type is SomeMoney
    assert isinstance(m.with_qty(qty), SomeMoney)
    ## Assert method result has correct quantity
    assert m.with_qty(qty).qty == qty
    ## Assert other fields are copied
    assert m.with_qty(qty).ccy == ccy
    assert m.with_qty(qty).dov == dov



# Generated at 2022-06-24 01:21:27.002304
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    assert Equals(SomePrice('USD', Decimal(2), dov), SomePrice('USD', Decimal(1), dov).scalar_add(Decimal(1)))
    assert Equals(SomePrice('USD', Decimal(0), dov), NoPrice.scalar_add(Decimal(0)))


# Generated at 2022-06-24 01:21:38.149449
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    x: SomePrice = SomePrice(ccy=USD, qty=Decimal(1), dov=Date('1971-01-01'))
    y: SomePrice = SomePrice(ccy=USD, qty=Decimal(2), dov=Date('1971-01-01'))
    z: SomePrice = SomePrice(ccy=USD, qty=Decimal(1), dov=Date('1971-01-01'))

    ## x is less than y
    assert x < y

    ## However, x is not greater than y
    assert not x > y

    ## x is less than or equal to y
    assert x <= y

    ## Similarly, y is greater than or equal to x
    assert y >= x

    ## x is equal to z
    assert x == z

    ## x is not less than z

# Generated at 2022-06-24 01:21:39.075470
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    with raises(TypeError):
        NoneMoney().__neg__()

# Generated at 2022-06-24 01:21:47.110753
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    # arrange
    dummy_ccy = Currency.of("USD")
    dummy_qty = Decimal(100)
    dummy_dov = Date.today()

    # act
    instance = SomeMoney(ccy=dummy_ccy, qty=dummy_qty, dov=dummy_dov)

    # assert
    assert bool(instance) is True
    assert instance.undefined is False
    assert instance.defined is True
    assert instance.ccy == dummy_ccy
    assert instance.qty == dummy_qty
    assert instance.dov == dummy_dov

    dummy_dov = Date.today()
    actual = instance.with_dov(dummy_dov)

    assert actual.ccy == instance.ccy
    assert actual.qty == instance.qty
    assert actual

# Generated at 2022-06-24 01:21:58.217451
# Unit test for method __le__ of class Money
def test_Money___le__():
    from .currencies import Currency, currency_lookup
    from .exchange import FXRateService
    from .valuation import NoneMoney, SomeMoney

    USD = currency_lookup("USD")
    EUR = currency_lookup("EUR")
    GBP = currency_lookup("GBP")
    JPY = currency_lookup("JPY")

    mx = NoneMoney
    ms = SomeMoney(USD, 1.0, Date.today())

    assert not (mx <= mx)
    assert not (ms <= mx)
    assert mx <= ms

    assert mx.__le__(ms) == mx <= ms
    assert ms.__le__(mx) == ms <= mx

    assert not (ms <= SomeMoney(EUR, 1.0, Date.today()))

# Generated at 2022-06-24 01:22:01.009735
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    ## Create a price object and negative it:
    assert -SomePrice(Currency.USD, Decimal("10"), Date.today()) == SomePrice(Currency.USD, Decimal("-10"), Date.today())

# Generated at 2022-06-24 01:22:07.732218
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    assert NoneMoney.of(None, None, None).add(NoneMoney.of(None, None, None)) == NoneMoney.of(None, None, None)
    assert NoneMoney.of(None, None, None).add(NoneMoney.of('USD', -100, '2019-03-22')) == NoneMoney.of('USD', -100, '2019-03-22')
    assert NoneMoney.of(None, None, None).add(NoneMoney.of('GBP', 100, '2019-03-22')) == NoneMoney.of('GBP', 100, '2019-03-22')



# Generated at 2022-06-24 01:22:08.767328
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    with raises(TypeError):
        NoPrice.__pos__()



# Generated at 2022-06-24 01:22:11.523349
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    from finins import Money, Currency, Decimal
    from finins.money import SomeMoney
    from datetime import date

    usd = Currency.from_iso("USD")

    neq = Money.of(usd, Decimal('-7.5'), date(2016, 8, 1))
    eq = NoneMoney.with_qty(Decimal('-7.5'))
    assert eq == neq


# Generated at 2022-06-24 01:22:21.990246
# Unit test for method __add__ of class Money
def test_Money___add__():
    c1 = Currency("EUR")
    c2 = Currency("USD")
    m1 = Money.of(c1, 10000, Date("2018-01-02"))
    m2 = Money.of(c2, 10000, Date("2018-02-03"))
    m3 = Money.of(c2, 10000, Date("2018-02-03"))

    assert (m1.ccy == c1) & (m1.qty == 10000) & (m1.dov == Date("2018-01-02"))
    assert m2.ccy == c2
    assert m2.qty == 10000
    assert m2.dov == Date("2018-02-03")
    assert m3.ccy == c2
    assert m3.qty == 10000
    assert m3.dov == Date("2018-02-03")

# Generated at 2022-06-24 01:22:22.662923
# Unit test for method __le__ of class Price
def test_Price___le__():
    assert (NoPrice <= NoPrice)



# Generated at 2022-06-24 01:22:24.015348
# Unit test for method __int__ of class Money
def test_Money___int__():
    pass



# Generated at 2022-06-24 01:22:27.315509
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    assert SomeMoney(CCY_USD, Decimal("123.4"), Date.today()).__bool__() is True
    assert SomeMoney(CCY_USD, Decimal("0.0"), Date.today()).__bool__() is False

# Generated at 2022-06-24 01:22:29.219277
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    """
    Tests method __gt__ of class SomePrice
    """
    pass



# Generated at 2022-06-24 01:22:30.677494
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    """
    Tests the boolean conversion of an undefined price.
    """
    assert not Price.of(None, None, None)

# Generated at 2022-06-24 01:22:35.968647
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    sm = SomeMoney(Currency.USD, Decimal('1000000.00'), date(2000, 1, 1))
    assert sm.ccy == Currency.USD
    assert sm.qty == Decimal('1000000.00')
    assert sm.dov == date(2000, 1, 1)
    assert sm.defined == True
    assert sm.undefined == False
    assert sm.is_equal(SomeMoney(Currency.USD, Decimal('1000000.00'), date(2000, 1, 1))) == True
    assert sm.as_boolean() == True
    assert sm.as_float() == 1000000.0
    assert sm.as_integer() == 1000000
    assert sm.abs() == SomeMoney(Currency.USD, Decimal('1000000.00'), date(2000, 1, 1))
    assert sm.negative()

# Generated at 2022-06-24 01:22:40.545747
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    ## Test:
    assert SomeMoney(USD, Decimal("100"), today).__bool__() is True
    assert SomeMoney(USD, Decimal("0"), today).__bool__() is False

## Unit test for method is_equal of class SomeMoney

# Generated at 2022-06-24 01:22:43.982130
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    from baikal.core.utils import now

    NoPrice = NonePrice()

    assert NoPrice <= NoPrice
    assert NoPrice <= SomePrice(CAD, Decimal(1), now())



# Generated at 2022-06-24 01:22:55.059786
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    from datetime import date
    from datetimeutils import Date
    from decimal import Decimal
    from money import Money, Price
    money = Money.of(Currency.USD, Decimal(10.1234), date(2020, 1, 1))
    price = Price.of(Currency.USD, Decimal("2.1234"), date(2020, 1, 1))
    money = Price.of(Currency.USD, Decimal("0"), date(2020, 1, 1)).money

    assert(int(price) == 2)
    assert(int(money) == 10)

    try:
        Price.of(None, None, None).as_integer()
        raise AssertionError("should not be reached")
    except MonetaryOperationException:
        pass


## Define and attach undefined price singleton.

# Generated at 2022-06-24 01:22:59.119526
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():


    A_PRICE = SomePrice(GBP, Decimal('12'), Date(2020, 7, 12))
    assert A_PRICE.positive() == SomePrice(GBP, Decimal('12'), Date(2020, 7, 12))

    assert NonePrice.positive() == NonePrice





# Generated at 2022-06-24 01:23:04.661666
# Unit test for method negative of class Price
def test_Price_negative():
    assert Price.of("USD", 1.25, None).negative().qty == -1.25
    assert Price.of("USD", None, None).negative().qty is None


# Generated at 2022-06-24 01:23:08.256260
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    global NoneMoney

    ## Setup:
    mny = NoneMoney

    ## We do not have a currency object:
    assert mny.round() == mny
    assert mny.round(ndigits=4) == mny



# Generated at 2022-06-24 01:23:12.938503
# Unit test for method positive of class Money
def test_Money_positive():
    import pandas as pd
    a=pd.read_csv("Input/input1.csv")
    b=a['Money']
    b[0].positive()
    
    

# Generated at 2022-06-24 01:23:17.729931
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    from pyutil.money import Money
    from pyutil.money import NoMoney
    from pyutil.money import SomeMoney

    money = Money.of(None, None, None)
    assert money == NoMoney

    money = Money.of(None, None, None)
    assert money == NoMoney

# Generated at 2022-06-24 01:23:29.346648
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    from datetime import date
    from .currency import USD
    from .price import Price
    from .price import SomePrice
    from .temporal import Date
    from .temporal import Day
    from .temporal import Month
    from .temporal import Year

    usd = USD
    date1 = Date(year=Year(2020), month=Month(1), day=Day(1))
    date2 = date(2020, 1, 1)
    price1 = Price.of(ccy=usd, qty=1, dov=date1)
    price2 = Price.of(ccy=usd, qty=1, dov=date2)

    assert isinstance(price1, SomePrice)
    assert isinstance(price2, SomePrice)

    assert price1 == price2
    assert price1.dov == price2

# Generated at 2022-06-24 01:23:32.572921
# Unit test for constructor of class Money
def test_Money():
    Money


# Generated at 2022-06-24 01:23:40.784583
# Unit test for method __le__ of class Price
def test_Price___le__():
    # Price.__le__
    assert Price.NA <= Price.NA
    assert Price.NA <= Price.of(GBP, 123, Date.today())
    assert Price.of(GBP, 123, Date.today()) <= Price.of(GBP, 123, Date.today())

# Generated at 2022-06-24 01:23:45.357485
# Unit test for method gt of class Money
def test_Money_gt():
    # Given
    m1 = Money.of(Currency.of("USD"), Decimal('1.0'), Date.today())
    m2 = Money.of(Currency.of("USD"), Decimal('2.0'), Date.today())
    # Then
    assert m1.gt(m2) is False

# Generated at 2022-06-24 01:23:46.710295
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    np = NonePrice()
    assert np.__neg__() is np

# Generated at 2022-06-24 01:23:47.834984
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    # TODO
    pass

# Generated at 2022-06-24 01:23:49.510855
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    assert (NoneMoney() == NoMoney)



# Generated at 2022-06-24 01:23:55.473153
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    # Arrange
    money = Money.of(EUR, Decimal('100'), Date(2021, 2, 10))
    other = Money.of(EUR, Decimal('50'), Date(2022, 1, 10))

    # Act
    q = money // other

    # Assert
    assert q.qty == Decimal('2')

    # Act (divide by zero)
    q = money // Money.of(EUR, Decimal('0'), Date(2022, 1, 10))

    # Assert
    assert not q.defined

    # Act (different currency)
    with pytest.raises(IncompatibleCurrencyError):
        money // Money.of(USD, Decimal('50'), Date(2022, 1, 10))

# Generated at 2022-06-24 01:24:08.238997
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    assert __ge__(SomePrice(Currency("USD"), Decimal("1"), Date(2020, 5, 8)), SomePrice(Currency("USD"), Decimal("1"), Date(2020, 5, 8)))
    assert not __ge__(SomePrice(Currency("USD"), Decimal("1"), Date(2020, 5, 8)), None)
    assert __ge__(SomePrice(Currency("USD"), Decimal("1"), Date(2020, 5, 8)), SomePrice(Currency("USD"), Decimal("2"), Date(2020, 5, 8)))
    assert __ge__(SomePrice(Currency("USD"), Decimal("1"), Date(2020, 5, 8)), SomePrice(Currency("USD"), Decimal("0"), Date(2020, 5, 8)))


# Generated at 2022-06-24 01:24:10.492555
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    nomoney = NoMoney; assert nomoney.__abs__() is nomoney


# Generated at 2022-06-24 01:24:11.212786
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    pass

# Generated at 2022-06-24 01:24:12.680914
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    assert float(SomePrice(ccyUSD, Decimal(0.01), Date('01/01/0001'))) == 0.01

# Generated at 2022-06-24 01:24:18.112098
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    for money in (NoMoney, USD(10), USD(10.0)):
        assert money.__gt__(USD(6)) == True
        assert money.__gt__(USD(8)) == True
        assert money.__gt__(USD(10)) == False
        assert money.__gt__(USD(12)) == False
        assert money.__gt__(USD(14)) == False
        assert money.__gt__(NoMoney) == True



# Generated at 2022-06-24 01:24:23.786390
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    class TestMoney:
        def __init__(self, qty: Decimal):
            self.qty = qty
        def __mul__(self, other: Numeric) -> "Money":
            return TestMoney(self.qty * other)

    assert TestMoney(Decimal(1)) * 2 == TestMoney(Decimal(2))



# Generated at 2022-06-24 01:24:25.641181
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert (bool(NoMoney) is False)
    
    

# Generated at 2022-06-24 01:24:31.059840
# Unit test for method negative of class Price
def test_Price_negative():
    for ccy in CURRENCIES:
        for qty in [Decimal(x) for x in range(-10000, 10000)]:
            assert Price.of(ccy, qty, Date.today()).negative().qty == -qty


# Generated at 2022-06-24 01:24:37.166106
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    money = Money.of(Currency.USD, 100.0)
    price = Price.of(Currency.USD, 1.0)
    price2 = Price.of(Currency.USD, 0.2)

    assert not price.scalar_subtract(100) == price2
    assert not price.scalar_subtract(100) != price2


# Generated at 2022-06-24 01:24:44.675381
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    """
    Tests method as_boolean of class Price.
    """
    price1 = Price.of(None, None, None)
    assert price1.as_boolean() is False

    price2 = Price.of(EUR, None, None)
    assert price2.as_boolean() is False

    price3 = Price.of(EUR, 0, None)
    assert price3.as_boolean() is False

    price4 = Price.of(EUR, 12.99, None)
    assert price4.as_boolean() is True

    price5 = Price.of(EUR, -12.99, None)
    assert price5.as_boolean() is True

    price6 = Price.of(EUR, 0, TODAY)
    assert price6.as_boolean() is False

    price7

# Generated at 2022-06-24 01:24:49.100458
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    p = Price.of(Currency.GBP, Decimal(100), Date(2020, 4, 1))
    assert p.scalar_add(10).qty == Decimal(110)


# Generated at 2022-06-24 01:24:58.911934
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    # Constant values and variables.
    NoneMoneyVisual = "Monetary(NaN, Not a Number, NaN)"

    # We want to make sure that address of NoneMoney stays constant
    # If not, then something is wrong
    address1 = id(Money.NA)
    address2 = id(Money.NA)
    assert address1 == address2

    # Constant values and variables.

# Generated at 2022-06-24 01:25:11.495909
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    m = NoneMoney()
    assert m.price == NoPrice
    assert m.__eq__(NoMoney)
    assert not m.__bool__()
    assert m.__abs__() == m
    assert m.__neg__() == m
    with pytest.raises(TypeError):
        m.__float__()
    with pytest.raises(TypeError):
        m.__int__()
    with pytest.raises(NotImplementedError):
        m.__round__()
    assert m.__pos__() == m
    assert m.__add__(USD(1)) == USD(1)
    assert m.__sub__(USD(1)) == USD(-1)
    assert m.__round__() == m
    assert m.__mul__(2) == m

# Generated at 2022-06-24 01:25:17.398402
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    assert SomePrice(USD, 11, Date("2019-06-01")).positive() == SomePrice(USD, 11, Date("2019-06-01"))
    assert SomePrice(USD, -11, Date("2019-06-01")).positive() == SomePrice(USD, 11, Date("2019-06-01"))
    
    
test_SomePrice___pos__()

# Generated at 2022-06-24 01:25:20.661653
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    self = NoneMoney()
    qty = Decimal('0.000')
    a = self.with_qty(qty)
    b = NoMoney
    assert a == b

# Generated at 2022-06-24 01:25:28.118632
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    import pytest
    import datetime
    from money import Money
    from money import SomeMoney
    from money import Currency
    from money import NoMoney
    from decimal import Decimal
    from dataclasses import dataclass
    from dataclasses import field
    from dataclasses import asdict
    from dataclasses import astuple
    from typing import Dict
    from typing import List
    from typing import Optional
    from typing import NamedTuple
    from typing import Any
    from money.exceptions import ProgrammingError
    from money.exceptions import ApplicationError
    from money.exceptions import IncompatibleCurrencyError
    from money.exceptions import IncompatibleTypeError
    from money.exceptions import FXRateLookupError
    from money.fxrate import FXRateService
    from money.fxrate import NoFXRateService

# Generated at 2022-06-24 01:25:32.006276
# Unit test for method gte of class Money
def test_Money_gte():
    # Check the condition on undefined money
    if NoMoney >= NoMoney:
        print('Exception is not raised')

# Generated at 2022-06-24 01:25:37.708497
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    """
    Test method scalar_add for class SomeMoney
    """
    some_money = SomeMoney(EUR, Decimal('1.0'), date(2020, 1, 1))
    some_money2 = some_money.scalar_add(1.0)
    assert some_money2.undefined == False
    assert some_money2.defined == True
    assert some_money2.ccy == EUR
    assert some_money2.qty == Decimal('2')
    assert some_money2.dov == date(2020, 1, 1)


# Generated at 2022-06-24 01:25:43.728484
# Unit test for method __add__ of class Money
def test_Money___add__():
    # Arrange
    m1 = Money.of(currency('EUR'), 1, date(2017, 12, 31))
    m2 = Money.of(currency('EUR'), 1, date(2018, 1, 1))
    expected = SomeMoney(currency('EUR'), 2, date(2018, 1, 1))

    # Act
    actual = m1 + m2

    # Assert
    assert actual == expected


# Generated at 2022-06-24 01:25:52.168425
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    '''
    Unit test for method with_qty of class NonePrice
    '''
    #
    # Open and read the file
    #
    file1 = open('data/output/expected_output_with_qty_NonePrice.txt',"r")
    expected_output_with_qty_NonePrice = file1.read()

    assert repr(NonePrice().with_qty(Decimal(0))) == expected_output_with_qty_NonePrice

    file1.close()

# Generated at 2022-06-24 01:25:55.847041
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    assert NonePrice().__ge__(NonePrice()) is True
    assert NonePrice().__ge__(SomePrice("USD", Decimal("2.01"), datetime.date(2020,1,1))) is True
    assert NonePrice().__ge__(NoPrice) is True

# Generated at 2022-06-24 01:25:56.609236
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    pass



# Generated at 2022-06-24 01:26:09.400420
# Unit test for method subtract of class Price
def test_Price_subtract():
    mv1 = SomePrice(USD, 100, date(2020,5,5))
    mv2 = SomePrice(USD, 50, date(2020,5,5))
    mv3 = NoPrice
    mv4 = SomePrice(GBP, 50, date(2020,5,5))

    assert mv1.subtract(mv2) == SomePrice(USD, 50, date(2020,5,5))
    assert mv1.subtract(mv3) == SomePrice(USD, 100, date(2020,5,5))
    assert mv2.subtract(mv1) == SomePrice(USD, -50, date(2020,5,5))

    with pytest.raises(IncompatibleCurrencyError):
        mv1.subtract(mv4)

Price.NA

# Generated at 2022-06-24 01:26:14.709894
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert SomePrice(USD, 0.2, Date(2018, 8, 27)).is_equal(SomePrice(USD, 0.2, Date(2018, 8, 27))) == True
    assert SomePrice(USD, 0.2, Date(2018, 8, 27)).is_equal(SomePrice(USD, 0.2, Date(2018, 8, 28))) == False
    assert SomePrice(USD, 0.2, Date(2018, 8, 27)).is_equal(SomePrice(USD, 0.3, Date(2018, 8, 27))) == False
    assert SomePrice(USD, 0.2, Date(2018, 8, 27)).is_equal(SomePrice(USD, 0.2, Date(2018, 8, 28))) == False

# Generated at 2022-06-24 01:26:23.037422
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    from .currencies import TRY
    from .zeitgeist import Date

    today = Date.today()
    ten_liras = Money.of(TRY, 10, today)
    assert ten_liras >= Money.of(TRY, 10, today)
    assert ten_liras >= Money.of(TRY, 0, today)
    assert ten_liras >= Money.of(TRY, 10, today)
    assert not ten_liras >= Money.of(TRY, 11, today)



# Generated at 2022-06-24 01:26:25.567040
# Unit test for constructor of class Price
def test_Price():
    assert Price(USD, Decimal('10.00'), Date(2020, 5, 25)) == Price(USD, Decimal('10.00'), Date(2020, 5, 25))


# Generated at 2022-06-24 01:26:36.499925
# Unit test for method __round__ of class Price
def test_Price___round__():
    from fmlib.models.units import MetricSystem, ImperialSystem
    from datetime import date
    import quantities as pq

    ns = MetricSystem()
    ns.define_unit("flow", pq.L / pq.s)
    ns.define_unit("power", pq.kW)
    ns.define_unit("energy", pq.kWh)

    EUR = Currency.of("EUR")
    USD = Currency.of("USD")
    USD.define_rate(EUR, 0.8, date.today())

    usd_price = Price.of(USD, 1.9, date.today())
    eur_price = usd_price.convert(EUR, date.today())

    assert usd_price.__round__() == 2

# Generated at 2022-06-24 01:26:40.538638
# Unit test for method convert of class Price
def test_Price_convert():
    m = Price.of(Currency.USD, 100, Date(2010, 10, 10))
    a = m.convert(Currency.EUR, Date(2010, 9, 1))
    b = Price.of(Currency.EUR, 120, Date(2010, 9, 1))
    assert a == b



# Generated at 2022-06-24 01:26:45.166990
# Unit test for method subtract of class Money
def test_Money_subtract():
    m1 = SomeMoney(Currency('GBP'), Decimal('1'), Date.today())
    m2 = SomeMoney(Currency('GBP'), Decimal('2'), Date.today())
    b = m2.subtract(m1)
    assert b.qty == Decimal('1')
    assert b.ccy == Currency('GBP')
    assert b.dov == Date.today()
    print("Unit test for method subtract of class Money completed")

# Generated at 2022-06-24 01:26:45.878443
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    pass

# Generated at 2022-06-24 01:26:48.535354
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    expected = NoMoney
    actual = NoPrice.times(None)
    assert actual == expected


# Generated at 2022-06-24 01:26:50.247490
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    assert NonePrice.__neg__(None) == NonePrice

# Generated at 2022-06-24 01:26:56.054944
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    assert NonePrice() - Decimal('1') == NonePrice()
    assert NonePrice() - Decimal('1.5') == NonePrice()
    assert NonePrice() - 1 == NonePrice()

# Generated at 2022-06-24 01:26:57.747589
# Unit test for method __le__ of class Price
def test_Price___le__():
    assert 0 <= 1



# Generated at 2022-06-24 01:27:05.339057
# Unit test for method lte of class Price
def test_Price_lte():
    # Test in reverse order
    assert((SomePrice(USD, 100, dov=today()) >= SomePrice(USD, 100, dov=today())) is True)
    assert((SomePrice(USD, 100, dov=today()) >= SomePrice(USD, 101, dov=today())) is False)
    assert((SomePrice(USD, 100, dov=today()) >= SomePrice(USD, 100, dov=today() + 1)) is True)
    assert((SomePrice(USD, 100, dov=today()) >= SomePrice(USD, 100, dov=today() + 1)) is True)
    assert NoPrice.gte(SomePrice(USD, 100, dov=today())) is False
    assert NoPrice.gte(NoMoney) is True
    assert NoPrice.gte(NoPrice) is True

# Generated at 2022-06-24 01:27:08.820052
# Unit test for method abs of class Price
def test_Price_abs():
    m = Price.of(USD, 100, date(2020, 5, 1))
    assert m.abs() == Money(USD, 100, date(2020, 5, 1))

# Generated at 2022-06-24 01:27:13.658337
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    p1 = Price.of(Currency.of("USD"), Decimal("10.0"), Date.today())
    p2 = Price.of(Currency.of("USD"), Decimal("10.0"), Date.today())
    assert p1.__eq__(p2)


# Generated at 2022-06-24 01:27:14.782718
# Unit test for method gte of class Money
def test_Money_gte():
    pass # TODO



# Generated at 2022-06-24 01:27:15.426024
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    pass

# Generated at 2022-06-24 01:27:16.887330
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    from . import ccy
    from . import price

    assert float(price.of(ccy.AUD, 250, None)) == 250.00

# Generated at 2022-06-24 01:27:19.876859
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    usd = Currency("USD")
    a = SomePrice(usd, Decimal("100.25"), Date(2016, 8, 28))
    b = a.with_dov(Date(2016, 9, 21))
    assert b == SomePrice(usd, Decimal("100.25"), Date(2016, 9, 21))
    assert a == SomePrice(usd, Decimal("100.25"), Date(2016, 8, 28))
    assert a is not b
    assert a != b



# Generated at 2022-06-24 01:27:24.484904
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    v = Money.of(Currency.of('USD'), Decimal('0.0'), Date.today())
    assert not v

    v = Money.of(Currency.of('USD'), Decimal('1.0'), Date.today())
    assert v



# Generated at 2022-06-24 01:27:33.941763
# Unit test for method add of class Money
def test_Money_add():
    # Setup
    ccy = Currency.of("EUR")
    quantity1 = Decimal(5)
    quantity2 = Decimal(5)
    date_of_value = Date.today()
    money1 = Money(ccy, quantity1, date_of_value)
    money2 = Money(ccy, quantity2, date_of_value)
    # Exercise
    result = money1.add(money2)
    # Verify
    assert result.ccy == ccy
    assert result.qty == quantity1+quantity2
    assert result.dov == date_of_value


# Generated at 2022-06-24 01:27:39.649896
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
  # Testing method __mul__ of class SomePrice
  # Test 1:
  input = SomePrice(ccy = Currency(code = "USD"), qty = Decimal('1'), dov = Date(year = 2018, month = 10, day = 10))
  expected = SomePrice(ccy = Currency(code = "USD"), qty = Decimal('10'), dov = Date(year = 2018, month = 10, day = 10))
  actual = input.__mul__(other = 10)
  assert actual.is_equal(other = expected)



# Generated at 2022-06-24 01:27:44.109613
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    # TODO: Implement unit test for 'Money.with_dov' method
    raise NotImplementedError("Method 'test_Money_with_dov' not implemented")


# Generated at 2022-06-24 01:27:53.525402
# Unit test for method gte of class Money
def test_Money_gte():
    from swiftsc.currencies import CURRENCIES

    USD = CURRENCIES["USD"]
    d1 = Money.of(USD, 1, Date.today())
    assert d1.with_dov(Date(2018, 11, 1)) >= d1 == Money.of(USD, 1, Date(2018, 11, 1))
    assert d1 >= d1 == Money.of(USD, 1, Date.today())
    assert d1 >= NoneMoney == False
    assert d1 >= NonePrice == False
    assert d1 >= SomeMoney(USD, 1, Date.today()) == True
    assert d1 >= SomePrice(USD, 1, Date.today()) == True
    assert Money.of(USD, 2, Date.today()) >= d1 == True
    assert d1 >= Money.of(USD, 2, Date.today()) == False

# Generated at 2022-06-24 01:28:05.568409
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    from finance.model.currency import Currency, CurrencyService
    from finance.model.date import Date, DateService
    from finance.model.price import SomePrice
    from finance.model.quantity import Quantity
    ccy1 = CurrencyService.default.query("USD") # type: ignore
    assert ccy1 is not None
    ccy2 = CurrencyService.default.query("EUR") # type: ignore
    assert ccy2 is not None
    value = Quantity(10, "")
    dov = DateService.default.today() # type: ignore
    assert dov is not None
    price = SomePrice(ccy1, value, dov)
    price = price.with_ccy(ccy2)
    assert price is not None
    assert price.ccy == ccy2
    assert price.qty == value

# Generated at 2022-06-24 01:28:16.666552
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    """
    Tests if floor division works as expected.
    """
    from .currencies import USD

    assert USD(10).floor_divide(3) == USD(3)
    assert USD(10).floor_divide(3.2) == USD(3)
    assert USD(10).floor_divide(4.4) == USD(2)
    assert USD(10).floor_divide(4.6) == USD(2)
    assert USD(10).floor_divide(3.7) == USD(2)
    assert USD(10).floor_divide(5.5) == USD(1)

    ## Undefined money should be returned as is:
    assert USD(10).floor_divide(0) is USD(10)



# Generated at 2022-06-24 01:28:27.540670
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    # Set up
    ccy = Currency("USD")
    qty = Decimal("1.00")
    dov = Date("2020-01-01")
    input_object = SomePrice(ccy, qty, dov)
    expected_value = SomePrice(ccy, qty, dov)


    # Invoke the function
    actual_value = input_object.__pos__()


    # Check the result in detail
    assert actual_value is not expected_value
    assert actual_value.ccy is expected_value.ccy
    assert actual_value.qty == expected_value.qty
    assert actual_value.dov == expected_value.dov


