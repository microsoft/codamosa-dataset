

# Generated at 2022-06-24 01:18:34.635307
# Unit test for method __float__ of class Price
def test_Price___float__():
    m1 = Price.of(USD, 10, 20200101)
    m2 = Price.of(CAD, 10, 20200101)
    m3 = Price.of(USD, 10, 20200102)
    m4 = Price.of(USD, 20, 20200101)
    assert float(m1) == 10
    assert float(m2) == 10
    assert float(m3) == 10
    assert float(m4) == 20
    with pytest.raises(MonetaryOperationException):
        float(NoPrice)

# Generated at 2022-06-24 01:18:35.712914
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    assert MonetaryOperationException("This is a test")



# Generated at 2022-06-24 01:18:37.153436
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    from .currencies import CurrencyFactory
    raise IncompatibleCurrencyError(CurrencyFactory.USD, CurrencyFactory.EUR)



# Generated at 2022-06-24 01:18:45.790962
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    print("testing method scalar_add of class NoneMoney")
    assert NoneMoney.of("USD").scalar_add(None) is NoMoney
    assert NoneMoney.of("USD").scalar_add("1.123") is NoMoney
    assert NoneMoney.of("USD").scalar_add(1.123) is NoMoney
    assert NoneMoney.of("USD").scalar_add(1) is NoMoney


# Generated at 2022-06-24 01:18:57.863405
# Unit test for method __float__ of class Price
def test_Price___float__():
    test_cases = [
        (Money.of(Currency.of('EUR'), 1.1, Date.today()).price, 1.1),
        (Money.of(Currency.of('EUR'), -1.1, Date.today()).price, -1.1),
        (Money.of(Currency.of('EUR'), 12345.67, Date.today()).price, 12345.67),
        (Money.of(Currency.of('EUR'), -12345.67, Date.today()).price, -12345.67),
    ]
    for (price, expected) in test_cases:
        with assert_raises(TypeError):
            _ = float(NoPrice)
        with assert_raises(TypeError):
            _ = float(NoMoney.price)

# Generated at 2022-06-24 01:19:05.005532
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    try:
        NoneMoney(  # type: ignore
            (assert_raises(TypeError, lambda: NoneMoney())))
    except TypeError as exc:
        assert type(exc) is TypeError

        try:
            SomeMoney(  # type: ignore
                (assert_raises(TypeError, lambda: SomeMoney())))
        except TypeError as exc:
            assert type(exc) is TypeError
            pass
        pass

    assert(not (NoneMoney() or not NoneMoney()))
    assert(not (bool(NoneMoney()) or not NoneMoney()))
    assert(not (NoneMoney() or not bool(NoneMoney())))
    assert(bool(NoneMoney()) == (not (not (NoneMoney()))))
    assert(bool(NoneMoney()) == (not (not (bool(NoneMoney())))))

# Generated at 2022-06-24 01:19:12.844589
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    assert Money.of(Currency.USD, Decimal("5.0"), Date.today()).scalar_subtract(10) == Money.of(Currency.USD, Decimal("-5.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("5.0"), Date.today()).scalar_subtract("10.0") == Money.of(Currency.USD, Decimal("-5.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("5.0"), Date.today()).scalar_subtract(-10) == Money.of(Currency.USD, Decimal("15.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("5.0"), Date.today()).scalar_subtract

# Generated at 2022-06-24 01:19:18.724548
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    with Money.new(Currency.EUR, Decimal(35), Date.today()).subtract(Money.new(Currency.JPY, Decimal(1000), Date.today())) as m:
        assert m == -Money.new(Currency.JPY, Decimal(1000), Date.today())

NoMoney = NoneMoney()



# Generated at 2022-06-24 01:19:23.618713
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    num = 100
    ccy = CAD
    dov = Date.today()
    money = SomeMoney(ccy, num, dov)
    assert money.__float__() == num



# Generated at 2022-06-24 01:19:30.857099
# Unit test for method __round__ of class Money
def test_Money___round__():
    class MoneyStub:
        def __round__(self, ndigits: Optional[int] = 0) -> Union["Money", int]:
            raise NotImplementedError

    money: Money = MoneyStub()
    assert round(money) == money.__round__()
    assert round(money, 1) == money.__round__(1)
    # Unit test for method __abs__ of class Money

# Generated at 2022-06-24 01:19:38.666787
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    import datetime

    from numpy.random import choice, randint

    from estrade.enums import Side

    from estrade.constants import DECIMAL_PLACES

    from estrade.graph import Epic, Tick
    from estrade.tick import TickData, TickValue

    from estrade.mixins.attributes import EpicMixin, RefMixin, GameRound

    from estrade.mixins.snapshot import SnapshotMixin

    from estrade.mixins.temporal import TemporalMixin
    from estrade.mixins.temporal import Temporal, Shift

    from estrade.indicators.temporal.sma import SMA

    from estrade.trades.trade import TradeProp

    from estrade.portfolios.portfolio import Position

    from estrade.strategies.strategy import Strategy


# Generated at 2022-06-24 01:19:49.220101
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from . import currency

    from . import price

    from . import money

    from . import fx_rate

    from decimal import Decimal

    ccy1 = currency.SomeCurrency(name="USD", code="USD")
    ccy2 = currency.SomeCurrency(name="EUR", code="EUR")

    usd_price = price.SomePrice(ccy1, Decimal("1"), date(2019, 1, 1))
    eur_price = price.SomePrice(ccy1, Decimal("1"), date(2019, 1, 1))

    with raises(price.IncompatibleCurrencyError):
        usd_price.add(eur_price)

    r = fx_rate.SomeFXRate(ccy1, ccy2, Decimal(1.2), date(2019, 1, 1))

    usd

# Generated at 2022-06-24 01:19:53.172186
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    """
    Test `NoneMoney.__ge__` method.
    """

    ## Test unit:
    tst: NoMoney = NoneMoney
    assert tst.__ge__(NoneMoney) is True
    assert tst.__ge__(SomeMoney(GBP, Decimal("1.0"), Date.today())) is True
    assert tst.__ge__(SomeMoney(CHF, Decimal("1.0"), Date.today())) is True



# Generated at 2022-06-24 01:19:58.295099
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    dummy_price = Price(Currency.USD, Decimal('2'), Date(22,12,1987))

# Generated at 2022-06-24 01:20:01.319974
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    with pytest.raises(TypeError):
        SomePrice.of(
            "EUR",
            Decimal(1.23),
            Date.of(2018, 1, 1),
        ).__int__()



# Generated at 2022-06-24 01:20:02.179411
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__(): pass



# Generated at 2022-06-24 01:20:07.908334
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    """
    Unit test for method scalar_add of class Money
    """
    from .currencies import USD
    from .money import Money
    from .dates import Date

    a = Money.of(USD, 1, Date(2000, 1, 1))
    b = a.scalar_add(1)
    assert(b.qty == 2)
    assert(b.ccy == USD)
    assert(b.dov == Date(2000, 1, 1))



# Generated at 2022-06-24 01:20:11.778557
# Unit test for method positive of class Money
def test_Money_positive():
    NoMoney.positive()
    SomeMoney.positive(NoMoney)
    SomeMoney.positive(SomeMoney(Currency.USD, Decimal(100), Date(2019, 3, 1)))
    assert SomeMoney.positive(SomeMoney(Currency.USD, Decimal(-100), Date(2019, 3, 1))) == SomeMoney(Currency.USD, Decimal(-100), Date(2019, 3, 1))

# Generated at 2022-06-24 01:20:14.297143
# Unit test for constructor of class Price
def test_Price():
    assert isinstance(Price.of(USD, Decimal('1.23'), date(2017, 1, 1)), Price)



# Generated at 2022-06-24 01:20:16.327619
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    val = SomePrice(Currency.USD, 100.000, date(2019, 5, 31))
    assert val.__bool__()

# Generated at 2022-06-24 01:20:20.601428
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.NA.as_integer() == 0
    assert Price.of(USD, Decimal("12.5"), D1).as_integer() == 13
    assert Price.of(USD, Decimal("12.4"), D1).as_integer() == 12


# Generated at 2022-06-24 01:20:30.088780
# Unit test for method __round__ of class Money
def test_Money___round__():
    none_money = NoneMoney
    none_money.__round__()
    none_money.__round__(1)
    eur = Currency.of('EUR')
    some_money = SomeMoney(eur, Decimal('1.234'), Date.today())
    (some_money.__round__(0)).qty == Decimal('1')
    (some_money.__round__(1)).qty == Decimal('1.2')
    (some_money.__round__(2)).qty == Decimal('1.23')
    (some_money.__round__(3)).qty == Decimal('1.234')
    (some_money.__round__(4)).qty == Decimal('1.234')

# Generated at 2022-06-24 01:20:41.472420
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    assert NoneMoney - NoneMoney == NoneMoney
    assert NoneMoney - SomeMoney(EUR, Decimal('1'), Date.today()) == NoMoney
    assert SomeMoney(EUR, Decimal('1'), Date.today()) - NoMoney == NoMoney
    assert SomeMoney(EUR, Decimal('1'), Date.today()) - NoneMoney == NoMoney
    assert SomeMoney(EUR, Decimal('1'), Date.today()) - SomeMoney(EUR, Decimal('1'), Date.today()) == SomeMoney(EUR, Decimal('0'), Date.today())
    assert SomeMoney(EUR, Decimal('1'), Date.today()) - SomeMoney(EUR, Decimal('2'), Date.today()) == SomeMoney(EUR, Decimal('-1'), Date.today())


# Generated at 2022-06-24 01:20:45.279157
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date
    from .exchange import FXRateService
    
    Money.NA = NoMoney
    assert NoMoney.__abs__() == NoMoney
    assert SomeMoney(USD, "10").__abs__() == SomeMoney(USD, "10")
    assert SomeMoney(USD, "-10").__abs__() == SomeMoney(USD, "10")
    
    # Unit test for method __eq__ of class Money

# Generated at 2022-06-24 01:20:49.455230
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    import os
    import unittest
    import datetime
    from decimal import Decimal
    from orcanet.test_support.testcases import TestCase
    from orcanet.test_support.testcases import TestCaseWithFx
    from orcanet.core.currencies import Currency
    from orcanet.core.date import Date
    from orcanet.core.encoding import Money
    from orcanet.core.encoding import NoMoney
    from orcanet.core.encoding import Price
    from orcanet.core.encoding import SomeMoney

    from orcanet.core.encoding import Money
    from orcanet.core.encoding import Price

    # expected number of tests
    num_tests = 10

    JAN_01_1970 = Date(1970, 1, 1)


# Generated at 2022-06-24 01:21:00.369915
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    some_undefined_price = Price.of(None, None, None)
    some_defined_price = Price.of(Currency.of("USD"), Decimal("10.0"), Date.of("2020-01-01"))
    assert some_undefined_price.positive() == Price.of(None, None, None)
    assert some_defined_price.positive() == Price.of(Currency.of("USD"), Decimal("10.0"), Date.of("2020-01-01"))
    assert some_defined_price.positive() != Price.of(None, None, None)
    assert some_undefined_price.positive() != Price.of(Currency.of("USD"), Decimal("10.0"), Date.of("2020-01-01"))



# Generated at 2022-06-24 01:21:01.746451
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    NoMoney.__truediv__(42)



# Generated at 2022-06-24 01:21:06.395000
# Unit test for method as_float of class Price
def test_Price_as_float():
    pass # just to suppress the warning
    price = Price.of(ccy=currency_codes.USD, qty=Decimal('1.0'), dov=Date(2020, 3, 1))
    assert price.as_float() == 1.0
    assert Price.of(ccy=None, qty=None, dov=None).as_float() == 0.0



# Generated at 2022-06-24 01:21:13.102981
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    price1 = SomePrice(Currency.USD, Decimal("100.375"), Date(2018,9,8))
    print(round(price1,ndigits=0))
    print(round(price1))
    print(price1.__round__(ndigits=2))
    print(price1.__round__(ndigits=0))
    print(price1.__round__())
    price2 = SomePrice(Currency.USD, Decimal("-100.375"), Date(2018,9,8))
    print(round(price2,ndigits=0))
    print(round(price2))
    print(price2.__round__(ndigits=2))
    print(price2.__round__(ndigits=0))
    print(price2.__round__())
test_SomePrice

# Generated at 2022-06-24 01:21:17.612593
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    # Defined price
    defined_price = Price.of(Currency.USD, 1.00000000, date.today())
    res_0 = defined_price.as_boolean()
    assert res_0 == True

    # price quantity is zero
    defined_price = Price.of(Currency.USD, 0.00000000, date.today())
    res_1 = defined_price.as_boolean()
    assert res_1 == False

    # Undefined price
    res_2 = NoPrice.as_boolean()
    assert res_2 == False


# Generated at 2022-06-24 01:21:18.913696
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    assert NoneMoney.scalar_add(1) is NoneMoney
    assert NoneMoney.scalar_add(1.0) is NoneMoney

# Generated at 2022-06-24 01:21:20.609647
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    assert NonePrice.convert(None, None, None, False) == NoPrice


# Generated at 2022-06-24 01:21:31.675966
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(EUR, 1.0, TODAY) == Price.of(EUR, 1.0, TODAY)
    assert Price.of(EUR, 1.0, TODAY) != Price.of(EUR, 1.0, TODAY + DAY)
    assert Price.of(EUR, 1.0, TODAY) != Price.of(EUR, 1.1, TODAY)
    assert Price.of(EUR, 1.0, TODAY) != Price.of(GBP, 1.0, TODAY)

    assert Price.of(EUR, -1.0, TODAY) != Price.of(EUR, 1.0, TODAY)

    assert Price.of(EUR, 0.0, TODAY) is NoPrice
    assert Price.of(EUR, 0.0, TODAY).defined is False

# Generated at 2022-06-24 01:21:43.267958
# Unit test for method gt of class Money
def test_Money_gt(): # pragma: no cover
    from .currencies import BASE_CCY
    from .exchange import NoFXRateService
    from .zeitgeist import Today

    Money.NA._fx_service = NoFXRateService

    assert Money.of(BASE_CCY, Decimal("100"), Today) > Money.of(BASE_CCY, Decimal("90"), Today)
    assert not Money.of(BASE_CCY, Decimal("80"), Today) > Money.of(BASE_CCY, Decimal("90"), Today)
    assert Money.of(BASE_CCY, Decimal("100"), Today) > Money.of(BASE_CCY, Decimal("80"), Today)
    assert Money.of(BASE_CCY, Decimal("100"), Today) > NoMoney

# Generated at 2022-06-24 01:21:55.391475
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    print("test_Price___eq__")

    # Identity properties
    assert Price.of(CCY_USD, 1.1, date(2018, 1, 1)) == Price.of(CCY_USD, 1.1, date(2018, 1, 1))  # No exception
    assert Price.of(CCY_USD, 1.1, date(2018, 1, 1)) != Price.of(CCY_EUR, 1.1, date(2018, 1, 1))  # No exception
    assert Price.of(CCY_USD, 1.1, date(2018, 1, 1)) != Price.of(CCY_USD, 1.2, date(2018, 1, 1))  # No exception

# Generated at 2022-06-24 01:22:05.656509
# Unit test for method convert of class Price
def test_Price_convert():
    from datetime import date
    from decimal import Decimal
    from zipline.api import symbols, order, record
    from zipline.finance.commission import PerTrade
    from zipline.finance.slippage import FixedSlippage
    from zipline.utils.events import date_rules, time_rules
    from zipline.pipeline import Pipeline
    from zipline.pipeline.data.testing import TestingDataSet
    from zipline.pipeline.factors import AverageDollarVolume
    from zipline.pipeline.filters import StaticAssets
    from zipline.pipeline.loaders import USEquityPricingLoader
    from zipline.testing import core, make_fake_pipeline_engine, data_portal
    import pandas as pd
   

# Generated at 2022-06-24 01:22:17.599064
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    price1 = Price.of(GBP, Decimal("100"), today())
    price2 = Price.of(GBP, Decimal("200"), today())
    price3 = Price.of(USD, Decimal("100"), today())

    assert not price1.lt(NoPrice)
    assert not price2.lt(NoPrice)
    assert not price3.lt(NoPrice)
    assert NoPrice.lt(price1)
    assert NoPrice.lt(price2)
    assert NoPrice.lt(price3)
    assert not NoPrice.lt(NoPrice)
    assert price1.lt(price2)
    assert price2.lt(price3)
    assert price1.lt(price3)
    assert not price3.lt(price1)
    assert not price2.lt(price1)



# Generated at 2022-06-24 01:22:26.446710
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from .currencies import USD
    from .commons.zeitgeist import Date

    _money: Money = Money.of(USD, 1, Date(2018, 1, 1))
    _money_with_dov: Money = _money.with_dov(Date(2019, 1, 1))

    assert _money_with_dov._ccy == USD
    assert _money_with_dov._qty == Decimal(1)
    assert _money_with_dov._dov == Date(2019, 1, 1)



# Generated at 2022-06-24 01:22:30.757378
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    ccy = EUR
    qty = Decimal("1.0")
    dov = Date.today()
    a = SomeMoney(ccy, qty, dov)
    b = SomeMoney(ccy, qty, dov)
    assert a.__eq__(b)


# Generated at 2022-06-24 01:22:42.397421
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    """
    Tests the __ge__ method of the SomePrice class
    """
    # Test cases and expected results

# Generated at 2022-06-24 01:22:45.108501
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    m = NoMoney
    assert m.scalar_add(10.25) == m

# Generated at 2022-06-24 01:22:57.141815
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    class PriceStub(Price):
        __slots__ = ('ccy', 'qty', 'dov', 'defined', 'undefined')

        def __init__(self, ccy, qty, dov):
            self.ccy = ccy
            self.qty = qty
            self.dov = dov
            self.defined = True
            self.undefined = False

        def is_equal(self, other):
            if not isinstance(other, Price):
                return False
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov

        def as_boolean(self):
            return self.qty != 0

        def as_float(self):
            return float(self.qty)


# Generated at 2022-06-24 01:23:00.949493
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    # An incompatible operation error:
    error = IncompatibleCurrencyError(ccy1=Currency.BZD, ccy2=Currency.USD, operation="TestOp")
    assert isinstance(error, IncompatibleCurrencyError)
    assert isinstance(error, ValueError)

    # Check error message:
    assert str(error) == "BZD vs USD are incompatible for operation 'TestOp'."



# Generated at 2022-06-24 01:23:05.155988
# Unit test for method __int__ of class Price
def test_Price___int__():
    # Arrange
    ccy = Currency.USD
    qty = Decimal(100.000000)
    dov = datetime.date(2020, 5, 1)
    price = Price.of(ccy, qty, dov)

    # Act
    result = price.__int__()

    # Assert
    assert result == 100


# Generated at 2022-06-24 01:23:14.887971
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    # Python compiler error: 'Price' object is not subscriptable
    # assert Price.of("USD", 10, Date.today()) is Price[("USD", 10, Date.today())]
    assert Price.of("USD", 10, Date.today()) > Price.of("USD", 1, Date.today())
    assert Price.of("USD", 10, Date.today()) > Price.of("EUR", 10, Date.today())
    assert Price.of("USD", 10, Date.today()) >= Price.of("USD", 10, Date.today())
    try:
        Price.of("USD", 10, Date.today()) > Price.of("EUR", 1, Date.today())
    except IncompatibleCurrencyError:
        pass
    else:
        raise Exception("unexpected result")

# Generated at 2022-06-24 01:23:18.704999
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    actual = SomeMoney(Currency.USD, Decimal(1), date(2018, 1, 1)).with_qty(-1)
    expected = SomeMoney(Currency.USD, Decimal(-1), date(2018, 1, 1))
    assert actual == expected


# Generated at 2022-06-24 01:23:19.347817
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    pass



# Generated at 2022-06-24 01:23:29.456010
# Unit test for method round of class Price
def test_Price_round():
    dov = today()
    ccy = Currency("EUR")
    price = Price.of(ccy, "0.0007784", dov)
    price_rounded = price.round()
    # print(price_rounded)
    assert price_rounded.qty == "0.0008"  # Pass
    assert price_rounded.ccy == "EUR"  # Pass
    assert price_rounded.dov == dov  # Pass
    assert price_rounded.defined  # Pass
    price_rounded = price.round(7)
    assert price_rounded.qty == "0.0007784"  # Pass
    assert price_rounded.ccy == "EUR"  # Pass
    assert price_rounded.dov == dov  # Pass
    assert price_rounded.defined  # Pass
    # Unit test for

# Generated at 2022-06-24 01:23:36.224320
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    # (1) Defined price
    p: Price = Price.of(USD, Decimal(3), Date(2018, 1, 1))
    assert bool(p) is True
    # (2) Defined price with zero quantity
    p = Price.of(USD, Decimal('0.00'), Date(2018, 1, 1))
    assert bool(p) is False
    # (3) Undefined price
    p = Price.of(None, None, None)
    assert bool(p) is False
    pass



# Generated at 2022-06-24 01:23:44.023719
# Unit test for method __le__ of class Money
def test_Money___le__():
    """
    Tests method __le__ of class Money
    """
    assert SomeMoney("USD", 10, Date("2017-12-31")) <= SomeMoney("USD", 10, Date("2017-12-31"))
    assert SomeMoney("USD", 10, Date("2017-10-31")) <= SomeMoney("USD", 10, Date("2017-12-31"))
    assert SomeMoney("USD", 8, Date("2017-12-31")) <= SomeMoney("USD", 10, Date("2017-12-31"))
    assert SomeMoney("USD", 8, Date("2017-12-31")) <= SomeMoney("USD", 10, Date("2017-12-31"))
    assert SomeMoney("USD", 10, Date("2017-12-31")) <= SomeMoney("USD", 10, Date("2017-12-31")) == True

# Generated at 2022-06-24 01:23:49.554404
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    m1 = Money.of(USD, 1000, today())
    m2 = Money.of(USD, 100, today())
    assert m1 > m2


# Generated at 2022-06-24 01:23:52.276023
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert NoPrice.floor_divide(10) is NoPrice
    assert SomePrice(USD, 100, Date(2018, 5, 17)).floor_divide(10) == SomePrice(USD, Decimal("10"), Date(2018, 5, 17))



# Generated at 2022-06-24 01:23:55.212351
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    # function to test:
    from common_primitives.money import NoneMoney

    # test cases:
    from common_primitives.money import NoMoney

    assert NoMoney.__abs__() == NoMoney



# Generated at 2022-06-24 01:23:56.231303
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    assert bool(NoPrice) == False


# Generated at 2022-06-24 01:24:09.013796
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    from .price import SomePrice
    from .quantity import SomeQuantity
    from .currency import Currency
    from .money import SomeMoney
    from .price import Price
    from .quantity import Quantity
    from .date import Date
    from .date import DateTime
    from .date import DateTimeZone
    from .date import TimeDelta
    from .date import Time
    from .enums import Month
    from .enums import WeekDay
    from .currency import Currency
    from .currency import CurrencyCode
    from .currency import CurrencyPair
    ccy = Currency.USD
    qty = float(1.00)
    dov = DateTime.now(tz=DateTimeZone.UTC)
    money = SomeMoney(ccy, qty, dov)
    price = SomePrice(ccy, qty, dov)
    assert money

# Generated at 2022-06-24 01:24:11.350559
# Unit test for method gt of class Price
def test_Price_gt():
    assert Price.of(USD, One, Date(2020, 8, 1)).gt(Price.of(USD, One, Date(2020, 8, 1))) == False

# Generated at 2022-06-24 01:24:13.479127
# Unit test for method __int__ of class Money
def test_Money___int__():
    m1 = Money.of(Currency.USD, 1.0, Date.today())
    assert int(m1) == 1



# Generated at 2022-06-24 01:24:21.455570
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    from datetime import date
    from privex.helpers import empty
    from moneyonchain.types import Currency
    from moneyonchain.manager import ConnectionManager
    from moneyonchain.rkco import RDOCPriceFeed
    custom_logging()
    
    
    connection_manager = ConnectionManager(network='rdocMainnet')
    
    rdoc_feed = RDOCPriceFeed(connection_manager)
    # DOC (as of 2019/12/13)
    price = rdoc_feed.market_price
    
    assert price.qty     == +1
    assert price.ccy     == Currency('DOC')
    assert price.dov     == date(2019, 12, 13)
    assert price.defined == True
    assert price.undefined == False
    assert price.currency == Currency('DOC')
    

# Generated at 2022-06-24 01:24:32.654944
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert NoMoney >= NoMoney
    assert NoMoney >= SomeMoney(Currency("USD"), 2, Date("2020-01-01"))
    assert SomeMoney(Currency("USD"), 2, Date("2020-01-01")) >= SomeMoney(Currency("USD"), 2, Date("2020-01-01"))
    assert SomeMoney(Currency("USD"), 3, Date("2020-01-01")) >= SomeMoney(Currency("USD"), 2, Date("2020-01-01"))
    try:
        NoMoney >= None  # type: ignore
        assert False, "None should be ignored by class Money"
    except TypeError:
        pass


Money.NA = NoMoney
"""Provides the undefined money object."""



# Generated at 2022-06-24 01:24:44.317245
# Unit test for method negative of class Money
def test_Money_negative():
    """
    Test for method negative of class Money
    """
    m = Money.of(Currency("EUR", "€", 2), Decimal("1.35"), Date.today())
    assert m == Money.of(Currency("EUR", "€", 2), Decimal("1.35"), Date.today())
    assert Money.NA == Money.NA
    assert Money.NA != m
    assert m != Money.NA

    assert m.is_equal(Money.of(Currency("EUR", "€", 2), Decimal("1.35"), Date.today()))
    assert not m.is_equal(Money.NA)
    assert not m.is_equal("Money")

    assert Money.NA.is_equal(Money.NA)

# Generated at 2022-06-24 01:24:54.648204
# Unit test for method negative of class Money
def test_Money_negative():
    import pytest

    from .currencies import USD, JPY
    from .exchange import FXRateServiceStub
    from .money import Money, NoMoney
    from .price import Price

    ccy1 = USD
    ccy2 = JPY

    amount1 = -100.0
    amount2 = +100.0
    amount3 = +0.0

    asof = Date(2018, 1, 1)

    fx_service = FXRateServiceStub().add(ccy1, ccy2, 1.0)

    some_money1 = SomeMoney(ccy1, ccy1.quantize(amount1), asof)
    some_money2 = SomeMoney(ccy1, ccy1.quantize(amount2), asof)

# Generated at 2022-06-24 01:24:56.329053
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    truediv_result = NonePrice().__truediv__(Decimal("1"))
    assert truediv_result is NonePrice


# Generated at 2022-06-24 01:25:04.524263
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    price1 = Price.of(None, None, None)
    price2 = Price.of(USD, None, None)
    price3 = Price.of(None, Decimal(1), None)
    price4 = Price.of(None, None, Date(2018, 1, 1))
    price5 = Price.of(USD, Decimal(3.14), None)
    price6 = Price.of(USD, Decimal(3.14), Date(2018, 1, 1))
    price7 = Price.of(EUR, Decimal(2.71), None)
    price8 = Price.of(EUR, Decimal(2.71), Date(2018, 2, 28))
    price9 = Price.of(USD, Decimal(1.59), Date(2018, 3, 31))

# Generated at 2022-06-24 01:25:11.106793
# Unit test for method __int__ of class Money
def test_Money___int__():
    from .currencies import USD
    from .primitives.money import Money, SomeMoney
    from .primitives.time import DARJEELING
    from .types import Numeric

    a_money = SomeMoney(USD, 1000, DARJEELING)

    # When
    a_money_as_int = int(a_money)

    # Then
    assert a_money_as_int == 1000
    assert isinstance(a_money_as_int, Numeric)

# Generated at 2022-06-24 01:25:16.974394
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    a = SomePrice(JPY, 100, Date(2017, 5, 9))
    b = SomePrice(CAD, 100, Date(2017, 5, 9))
    assert not a.__ge__(b)

    a = SomePrice(CAD, 100, Date(2017, 5, 9))
    b = SomePrice(CAD, 100, Date(2017, 5, 9))
    assert a.__ge__(b)

    a = SomePrice(CAD, 100, Date(2017, 5, 9))
    b = SomePrice(CAD, 50, Date(2017, 5, 9))
    assert a.__ge__(b)

    a = SomePrice(CAD, 100, Date(2017, 5, 9))
    b = SomePrice(CAD, 100, Date(2017, 5, 10))
    assert a.__

# Generated at 2022-06-24 01:25:20.168860
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NonePrice().with_qty(Decimal("10")).is_some()

# Generated at 2022-06-24 01:25:23.631346
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NonePrice.with_qty(Decimal(10)) == NoPrice

# Generated at 2022-06-24 01:25:31.039281
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    money = Money.of(USD, Decimal(0.5), Date(2018, 1, 1))
    result = money // 2
    assert isinstance(result, Money)
    assert result == Money.of(USD, Decimal(0.25), Date(2018, 1, 1))
    result = money // Decimal(2)
    assert isinstance(result, Money)
    assert result == Money.of(USD, Decimal(0.25), Date(2018, 1, 1))
    result = money // Money.of(USD, Decimal(2), Date(2018, 1, 1))
    assert isinstance(result, Money)
    assert result == Money.of(USD, 0, Date(2018, 1, 1))
    assert money // Money.of(GBP, Decimal(1), Date(2018, 1, 1)) == Money.of

# Generated at 2022-06-24 01:25:35.167258
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    assert SomeMoney(USD, Decimal(1.23), date(2020, 1, 1)) - 3 == SomeMoney(USD, Decimal(-2.23), date(2020, 1, 1))
    assert SomeMoney(USD, Decimal(1.23), date(2020, 1, 1)) - 3.5 == SomeMoney(USD, Decimal(-2.27), date(2020, 1, 1))


# Generated at 2022-06-24 01:25:44.845406
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    assert(Money.of(Currency.USD, 100, Date.today()).__truediv__(2) == Money.of(Currency.USD, 50, Date.today()))
    assert(Money.of(Currency.USD, 100, Date.today()).__truediv__(None) is Money())
    assert(Money.of(Currency.USD, 100, Date.today()).__truediv__(Money.of(Currency.USD, 2.5, Date.today())) == Money.of(Currency.USD, 40, Date.today()))

# Generated at 2022-06-24 01:25:55.692862
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    a = NoneMoney()
    print(a.as_boolean())
    print(a.abs())
    print(a.round())
    print(a.negative())
    print(a.positive())
    print(a+5)
    print(a-5)
    print(a*5)
    print(a/5)
    print(a//5)
    print(a.lt(2))
    print(a.lte(2))
    print(a.gt(2))
    print(a.gte(2))
    print(a.with_ccy(3))
    print(a.with_qty(3))
    print(a.with_dov(3))
    print(a.convert(5))
    # print(a.price())


# Generated at 2022-06-24 01:26:01.896765
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    price = NoPrice.with_qty(Decimal("10.0"))
    assert price.ccy is None
    assert price.qty == Decimal("10.0")
    assert price.dov is None

# Generated at 2022-06-24 01:26:04.165662
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    result = NoPrice.with_dov(dov=parse_date('2017-07-03'))
    assert result == NoPrice


# Generated at 2022-06-24 01:26:11.974847
# Unit test for method negative of class Money
def test_Money_negative():
    """
    Test negative method of class Money.
    """
    # Create a Money object
    money = Money.of("EUR", 10, "2019-01-01")
    # Call the method
    r = money.negative()
    # Check if the result is the expected one
    assert r.qty == -10 and r.ccy.code == "EUR" and r.dov.value == "2019-01-01"
    # Create a Money object
    money = Money.of("EUR", 10, "2019-01-01")
    # Call the method
    r = money.negative().negative()
    # Check if the result is the expected one
    assert r.qty == 10 and r.ccy.code == "EUR" and r.dov.value == "2019-01-01"
    # Create a Money

# Generated at 2022-06-24 01:26:12.823300
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__(): pass

# Generated at 2022-06-24 01:26:25.522972
# Unit test for method divide of class Money
def test_Money_divide():
    some_money = SomeMoney(USD, Decimal("3"), TODAY)
    assert some_money.divide(Decimal("3")) == SomeMoney(USD, Decimal("1"), TODAY)

    with raises(DivisionByZero):
        some_money.divide(Decimal("0"))

    some_money = SomeMoney(USD, Decimal("3.14"), TODAY)
    assert some_money.divide(Decimal("2.0")) == SomeMoney(USD, Decimal("1.57"), TODAY)

    # Check for rounding issues with python 2.6
    some_money = SomeMoney(USD, Decimal("10"), TODAY)
    assert some_money.divide(Decimal("3.0")) == SomeMoney(USD, Decimal("3.33"), TODAY)


# Generated at 2022-06-24 01:26:27.330605
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    n = NoneMoney()
    assert n == n.__pos__()



# Generated at 2022-06-24 01:26:29.670761
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    m = Price(Currency.USD, 1, Date(2000, 1, 1))
    assert 1 < m
    assert m < Price(Currency.USD, 2, Date(2000, 1, 1))
    assert not (m < Price(Currency.USD, 1, Date(2000, 1, 1)))


# Generated at 2022-06-24 01:26:38.564143
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    assert SomePrice.of("USD", 1, Date.of(2020, 1, 1)) - 2 == SomePrice.of("USD", -1, Date.of(2020, 1, 1))
    assert SomePrice.of("USD", Decimal("1"), Date.of(2020, 1, 1)) - Decimal("2") == SomePrice.of("USD", Decimal("-1"), Date.of(2020, 1, 1))
    assert SomePrice.of("USD", Decimal("1"), Date.of(2020, 1, 1)) - 2.5 == SomePrice.of("USD", Decimal("-1.5"), Date.of(2020, 1, 1))

# Generated at 2022-06-24 01:26:40.153946
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    assert NonePrice().__abs__() is NonePrice()

# Generated at 2022-06-24 01:26:50.547209
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(ccy=CAD, qty=Decimal("0"), dov=TZDate.of(2020, 3, 11)).convert(CCY_USD, asof=TZDate(2020, 3, 12)) == Price.of(ccy=USD, qty=Decimal('0'), dov=TZDate(2020, 3, 11))
    assert Price.of(ccy=USD, qty=Decimal("1"), dov=TZDate(2020, 3, 12)).convert(CCY_USD, asof=TZDate(2020, 3, 12)) == Price.of(ccy=USD, qty=Decimal('1'), dov=TZDate(2020, 3, 12))

# Generated at 2022-06-24 01:26:57.097445
# Unit test for method gte of class Money
def test_Money_gte():
    m1 = SomeMoney(ccy=USD, qty=7, dov=Date.date(2019, 12, 10))
    m2 = SomeMoney(ccy=USD, qty=6, dov=Date.date(2019, 12, 10))
    m3 = SomeMoney(ccy=USD, qty=7, dov=Date.date(2019, 12, 10))
    m4 = SomeMoney(ccy=USD, qty=8, dov=Date.date(2019, 12, 10))
    assert m1.gte(m2)
    assert m1.gte(m3)
    assert not m1.gte(m4)



# Generated at 2022-06-24 01:27:00.035374
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    result = SomePrice(USD, Decimal(99), d1).__eq__(SomePrice(USD, Decimal(99), d1))
    assert result == True

# Generated at 2022-06-24 01:27:03.897199
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    try:
        res = _Money_as_integer()
    except Exception as e:
        print(e)
    else:
        print(res)


# Generated at 2022-06-24 01:27:12.193453
# Unit test for method negative of class Price
def test_Price_negative():
    exp_result = 2.0
    obj = SomePrice(US, 2.0, None)
    result = obj.negative()
    assert exp_result == result
a = NoMoney()
a.is_zero()

a = SomeMoney(US, 2.0)
a.is_zero()

a = NoPrice()
a.is_zero()

a = SomePrice(US, 2.0, None)
a.is_zero()
## Define and attach undefined price singleton.
Price.NA = NoPrice = NonePrice()

# Generated at 2022-06-24 01:27:16.861313
# Unit test for method __int__ of class Money
def test_Money___int__():
    from types import MethodType
    from .money import Money
    assert isinstance(int(Money), int)
    assert isinstance(Money().__int__, MethodType)
    assert int(Money()) == 0
    assert int(Money.NA) == 0
    assert int(Money(Currency('USD'), 1000, Date.today())) == 1000

# Generated at 2022-06-24 01:27:18.532964
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__():
    result = NoneMoney.__floordiv__(None, 6)
    assert result == NoMoney


# Generated at 2022-06-24 01:27:25.220204
# Unit test for method __le__ of class SomePrice

# Generated at 2022-06-24 01:27:36.257977
# Unit test for method multiply of class Price
def test_Price_multiply():
    ccy_USD = USD()
    p = SomePrice.of(ccy_USD, Decimal(10), date(1977, 5, 9))
    m = p.multiply(4)
    assert m.ccy == ccy_USD
    assert m.qty == Decimal(40)
    assert m.dov == date(1977, 5, 9)
    assert p.multiply(0) == NoPrice
    assert isinstance(p.multiply(0), NoPrice.__class__)
    assert NoPrice.multiply(4) == NoPrice
    assert isinstance(NoPrice.multiply(4), NoPrice.__class__)
    assert 4 * NoPrice == NoPrice



# Generated at 2022-06-24 01:27:39.143515
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    ccy = USD
    qty = Decimal('1.23')
    dov = Date(2019, 1, 1)
    money = SomeMoney(ccy, qty, dov)
    money.__neg__()
    #TODO: Should we assert?



# Generated at 2022-06-24 01:27:45.119114
# Unit test for method __add__ of class Price
def test_Price___add__():
    """
    Test method __add__ of class Price
    """
    price_0 = Price.of(None, None, None)
    price_1 = Price.of(None, None, None)
    price_2 = price_0.__add__(price_1)
    assert price_2 is None



# Generated at 2022-06-24 01:27:46.880653
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Test with no argument
    some_price = Price.of("GBP", 12.3, Date.today())
    some_price.with_dov()


# Generated at 2022-06-24 01:27:52.627762
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    def test(ccy: Currency, qty: Decimal, dov: Date) -> bool:
        return SomePrice(ccy, qty, dov).__neg__() == SomePrice(ccy, qty.__neg__(), dov)

    assert test(ccy=Currency.AUD, qty=Decimal(12.0), dov=Date.today())

# Generated at 2022-06-24 01:28:04.573010
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from .immutable import ImmutableMoney
    a = ImmutableMoney(Currency.USD, Decimal(100), Date.today())
    b = a.scalar_subtract(10)
    c = a.scalar_subtract(Decimal(10))

    # c is an instance of Money
    assert isinstance(c, ImmutableMoney)

    # c is a new money object with correct ccy, qty and dov
    assert c.ccy == a.ccy
    assert c.qty == a.qty - Decimal(10)
    assert c.dov == a.dov

    # b and c are same
    assert b == c

    # b and a are different
    assert b != a

    # a does not change
    assert a.ccy == Currency.USD

# Generated at 2022-06-24 01:28:16.433675
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    """unit test for method SomePrice.__truediv__"""
    import re
    import io
    import unittest
    import datetime
    from decimal import Decimal
    from pickle import Pickler, Unpickler
    from pytest import raises
    from orders import Order
    from orders.order import OrderSide, OrderType, OrderValidity, OrderState
    from instruments import InstrumentType
    from instruments.converters import InstrumentConverter
    from instruments.commodities import COMMODITIES
    from instruments.currencies import CURRENCIES
    from instruments.equities import EQUITIES
    from instruments.options import OPTIONS
    from instruments.futures import FUTURES
    from instruments.futures import FuturesExpiration
    from instruments.synthetics import EQUITY_OPTIONS, EQUITY_FUTURES

# Generated at 2022-06-24 01:28:28.207278
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    some_price = Price.of(Currency.USD, Decimal("1.23"), Date.today())
    assert some_price.scalar_subtract(1) == Price.of(Currency.USD, Decimal("0.23"), Date.today())
    assert some_price.scalar_subtract(Decimal("1")) == Price.of(Currency.USD, Decimal("0.23"), Date.today())
    assert some_price.scalar_subtract(Decimal("1.1")) == Price.of(Currency.USD, Decimal("0.13"), Date.today())
    assert some_price.scalar_subtract(Decimal("1.23")) == Price.of(Currency.USD, Decimal("0.00"), Date.today())
    assert some_price.scal