

# Generated at 2022-06-24 01:18:40.013502
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    assert NoneMoney.of("EUR", -100, "2020-01-01", strict=True) == (
        "EUR",
        Decimal("-100"),
        datetime.date(2020, 1, 1),
    )
import typing as t
from types import MappingProxyType
from decimal import Decimal
from datetime import date
from inspect import isclass
from typing import Optional, Union, Any, Sequence
from hypothesis import given, strategies as st
from hypothesis_jsonschema import from_schema
from hypothesis_regex import regex
from jsonschema import validate, FormatChecker
from jsonschema.exceptions import ValidationError
from functools import partial
from jsonschema import validate
from pandas import notna
from .money import Money, Currency, NoMoney
from .price import Price, NoPrice

# Generated at 2022-06-24 01:18:41.135525
# Unit test for method __add__ of class Money
def test_Money___add__():
    return None


# Generated at 2022-06-24 01:18:47.336605
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Set up currency
    ccy = Currency.USD
    # Set up quantitiy
    qty = Decimal(2)
    # Set up value date
    dov = Date.today()
    # Set up price
    price = Price.of(ccy, qty, dov)
    # Check to_dov
    assert price.with_dov(dov) == price

# Generated at 2022-06-24 01:18:59.318654
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():

    money1 = SomeMoney(USD, Decimal("100"), Date(2019, 1, 1))
    money2 = SomeMoney(USD, Decimal("100"), Date(2019, 1, 1))
    money3 = SomeMoney(USD, Decimal("100"), Date(2019, 1, 1))

    assert money1.convert(USD, Date(2019, 1, 1)) == money2
    assert money1.convert(JPY, Date(2019, 1, 1)) == money3

NoMoney.__bool__.__func__.__annotations__ = {"return": bool}
NoMoney.__eq__.__func__.__annotations__ = {"other": Any, "return": bool}
NoMoney.__abs__.__func__.__annotations__ = {"return": Money}
NoMoney.__float__.__func__.__annot

# Generated at 2022-06-24 01:19:05.853934
# Unit test for method gte of class Money
def test_Money_gte():
    assert SomeMoney(usd, 1.0, Date.today()) >= SomeMoney(usd, 1.0, Date.today())
    assert not SomeMoney(usd, 1.0, Date.today()) >= SomeMoney(usd, 2.0, Date.today())
    assert SomeMoney(usd, 2.0, Date.today()) >= SomeMoney(usd, 1.0, Date.today())
    assert not SomeMoney(usd, 1.0, Date.today()) >= NoMoney
    assert not SomeMoney(usd, 1.0, Date.today()) >= NoneMoney
    assert SomeMoney(usd, 1.0, Date.today()) >= None
    assert SomeMoney(usd, 1.0, Date.today()) >= NoPrice
    assert SomeMoney(usd, 1.0, Date.today()) >= NonePrice
#

# Generated at 2022-06-24 01:19:17.977346
# Unit test for method add of class Money
def test_Money_add():
    assert (SomeMoney(Currency.JPY, Decimal("10"), Date(2019, 1, 1)) +
            SomeMoney(Currency.JPY, Decimal("20"), Date(2019, 1, 2))) == \
           SomeMoney(Currency.JPY, Decimal("30"), Date(2019, 1, 2))

    assert (SomeMoney(Currency.JPY, Decimal("10"), Date(2019, 1, 1)) +
            SomeMoney(Currency.EUR, Decimal("1.5"), Date(2019, 1, 2))) == \
           SomeMoney(Currency.EUR, Decimal("1.5"), Date(2019, 1, 2))

    assert NoMoney + SomeMoney(Currency.EUR, Decimal("10"), Date(2019, 1, 1)) == NoMoney

# Generated at 2022-06-24 01:19:24.604441
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert (Money.of(Currency.of('USD'), '1').as_float() == 1.0)
    assert (Money.of(Currency.of('USD'), '1.1').as_float() == 1.1)
    assert (Money.of(Currency.of('USD'), '0').as_float() == 0.0)
    assert (Money.of(Currency.of('USD'), '0.0').as_float() == 0.0)
    assert (Money.of(Currency.of('USD'), '-1').as_float() == -1.0)
    assert (Money.of(Currency.of('USD'), '-1.1').as_float() == -1.1)

# Generated at 2022-06-24 01:19:28.498616
# Unit test for constructor of class SomePrice
def test_SomePrice():
    SomePrice(currencies.USD, Decimal(0.0), Date(2019, 12, 31))


# Generated at 2022-06-24 01:19:31.239952
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    x = NonePrice
    actual = x.__abs__()
    assert actual.__class__ is NonePrice

# Generated at 2022-06-24 01:19:35.162032
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert NoPrice == NoPrice.__neg__()
    assert SomePrice.__new__(SomePrice, 'CCY1', Decimal('1'), Date(2018, 10, 10)) == SomePrice.__new__(SomePrice, 'CCY1', Decimal('1'), Date(2018, 10, 10)).__neg__()

# Generated at 2022-06-24 01:19:40.205510
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    sp1 = SomePrice(Currency("USD"), Decimal("1"), Date("2019-11-12"))
    sp2 = SomePrice(Currency("USD"), Decimal("1"), Date("2019-11-12"))
    assert sp1 <= sp2




# Generated at 2022-06-24 01:19:49.818215
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) == SomeMoney("CAD", 111, Date(2018, 2, 1))
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) != SomeMoney("CAD", 111, Date(2018, 2, 2))
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) != SomeMoney("CAD", 112, Date(2018, 2, 1))
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) != SomeMoney("USD", 111, Date(2018, 2, 1))
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) != SomeMoney("CAD", 111, Date(2018, 2, 2))
    assert SomeMoney("CAD", 111, Date(2018, 2, 1)) != Some

# Generated at 2022-06-24 01:19:54.732199
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    from .currencies import USD
    from .currencies import EUR
    error = IncompatibleCurrencyError(USD, EUR)
    assert error.ccy1 == USD, "Property 'ccy1' must be set correctly."
    assert error.ccy2 == EUR, "Property 'ccy2' must be set correctly."
    assert error.operation == "<Unspecified>", "Property 'operation' must be set correctly."
    assert str(error) == "USD vs EUR are incompatible for operation '<Unspecified>'.", "Error message must be correct."



# Generated at 2022-06-24 01:20:01.157242
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    ccy = Currency("USD", Decimal("0.01"))
    Money = Money.of(ccy, Decimal("10"), Date(2020, 9, 1))
    result = Money.floor_divide(Money)
    assert result == Money
    Money = Money.of(ccy, Decimal("10"), Date(2020, 9, 1))
    result = Money.floor_divide(Decimal("10"))
    assert result == Money
    
    

# Generated at 2022-06-24 01:20:11.644921
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    raise SkipTest()
## Unit test for method __add__ of class NonePrice
# def test_NonePrice___add__():
#     ## Test for ~ [addition]
#     from mio import eq as _eq
#     from ioflo.aid.odicting import odict as _dict
#     from ioflo.aid import getConsole
#     console = getConsole()
#     console.reinit(verbosity=console.Wordage.concise)
#
#     console.terse("TESTING NoPrice.__add__ \n")
#
#     c = Currency(ISO="USD")
#     q = Decimal(1.0)
#     d = Date.today()
#     p = SomePrice(c, q, d)
#
#     assert _eq(p + NoPrice, p)
#     assert _eq

# Generated at 2022-06-24 01:20:14.116619
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    na = NoMoney

    assert na > SomeMoney(CAD, 5, TODAY)
    assert not na > SomeMoney(USD, 5, TODAY)



# Generated at 2022-06-24 01:20:17.964351
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert not NoMoney >= NoMoney
    assert not NoMoney >= SomeMoney(usd, Decimal("1"), Date(2017, 1, 1))
    assert not SomeMoney(usd, Decimal("1"), Date(2017, 1, 1)) >= NoMoney
    assert NoMoney >= usd("1.00")


# Generated at 2022-06-24 01:20:20.334996
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    assert NoneMoney.with_qty(Decimal(123)) == NoMoney


# Generated at 2022-06-24 01:20:22.627408
# Unit test for method __abs__ of class Price
def test_Price___abs__():
	assert Price_A.__abs__()==Price_B
	assert Price_C.__abs__()==Price_C

# Generated at 2022-06-24 01:20:32.247715
# Unit test for method lt of class Money
def test_Money_lt():
    class TestMoney1(Money):
        __slots__ = ("ccy", "qty", "dov")

        NA = NoneMoney
        ccy: Currency
        qty: Decimal
        dov: Date
        defined: bool
        undefined: bool

        def __init__(self, ccy: Currency, qty: Decimal, dov: Date) -> None:
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

        def is_equal(self, other: Any) -> bool:
            return isinstance(other, TestMoney1) and self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov

        def as_boolean(self) -> bool:
            return self.qty != 0

       

# Generated at 2022-06-24 01:20:37.714000
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    from datetime import date

    from pymonads.Maybe import Just, Nothing, Maybe

    assert isinstance(NoPrice.__gt__(NoPrice), bool)
    assert NoPrice.__gt__(NoPrice) is False

    assert isinstance(NoPrice.__gt__(Price(AUD, Decimal(50), date(2020, 1, 1))), bool)
    assert NoPrice.__gt__(Price(AUD, Decimal(50), date(2020, 1, 1))) is False

    assert isinstance(Price(AUD, Decimal(50), date(2020, 1, 1)).__gt__(NoPrice), bool)
    assert Price(AUD, Decimal(50), date(2020, 1, 1)).__gt__(NoPrice) is True


# Generated at 2022-06-24 01:20:40.695403
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    """Unittest for NonePrice.__int__()."""
    from pytest import raises

    n = NonePrice()
    assert n.__int__() == 0

    with raises(TypeError):
        NonePrice().__int__()


# Generated at 2022-06-24 01:20:43.860385
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    from .currency import GBP, EUR
    from .date import today
    from .prices import SomePrice, NoPrice
    from .rates import FXRateService
    # Set-up rate service:
    FXRateService.default = DummyFXRateService()

    # @TODO: Implement tests for method round of class NonePrice

    # Reset rate service:
    FXRateService.default = None



# Generated at 2022-06-24 01:20:47.937479
# Unit test for method add of class Price
def test_Price_add():
    p1 = Price.of(USD, 1, Date.today())
    p2 = Price.of(USD, 1, Date.today())
    p3 = p1.add(p2)
    assert p3.ccy == USD
    assert p3.qty == Decimal(2)



# Generated at 2022-06-24 01:20:59.549819
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert (Price.of(Currency.of('USD'), Decimal('0.9'), Date.today()).multiply(Decimal('0.9')) == Price.of(Currency.of('USD'), Decimal('0.81'), Date.today()))
    assert (Price.of(Currency.of('EUR'), Decimal('4.2'), Date.today()).multiply(Decimal('1.1')) == Price.of(Currency.of('EUR'), Decimal('4.62'), Date.today()))
    assert (Price.of(Currency.of('CHF'), Decimal('3.9'), Date.today()).multiply(Decimal('0.5')) == Price.of(Currency.of('CHF'), Decimal('1.95'), Date.today()))


# Generated at 2022-06-24 01:21:04.879026
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    """
    Unit test for method with_dov of class SomeMoney
    """
    tester = unittest.TestCase()
    m = SomeMoney(USD, 10.0, Date("2017-01-05"))
    m_out = m.with_dov(Date("2017-01-01"))
    tester.assertEqual(m_out.dov, Date("2017-01-01"))

# Generated at 2022-06-24 01:21:15.750391
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    m1 = SomeMoney(CAD, Decimal("12.3456"), asof)
    assert m1.round() == SomeMoney(CAD, Decimal("12"), asof)
    assert m1.round(1) == SomeMoney(CAD, Decimal("12.3"), asof)
    assert m1.round(2) == SomeMoney(CAD, Decimal("12.35"), asof)
    assert m1.round(3) == SomeMoney(CAD, Decimal("12.346"), asof)
    assert m1.round(4) == SomeMoney(CAD, Decimal("12.3456"), asof)


# Generated at 2022-06-24 01:21:20.418947
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    value_1: Money
    value_1 = Money.of(None, None, None)
    assert value_1.__pos__() == NoMoney
    value_1 = Money.of(Currency.JPY(), Decimal("100"), None)
    assert value_1.__pos__() == SomeMoney(Currency.JPY(), Decimal("100"), None)
    value_1 = Money.of(Currency.JPY(), Decimal("-100"), None)
    assert value_1.__pos__() == SomeMoney(Currency.JPY(), Decimal("-100"), None)

    pass



# Generated at 2022-06-24 01:21:31.593379
# Unit test for method convert of class Price
def test_Price_convert():
    print("\n")
    print("-"*60)
    
    rate = Rate(RateType.CROSS, CurrencyPair.USD_JPY, Decimal(115.50), Date.from_date(2018, 1, 1))
    fx_provider = MemoryFXProvider({rate.ccy_pair: rate})

    p1 = Price.of(Currency.USD, Decimal(1), Date.from_date(2018, 1, 1))
    p2 = p1.convert(Currency.JPY, Date.from_date(2018, 1, 1), fx_provider)
    print('p1: {}'.format(p1))
    print('p1.convert(Currency.JPY, Date.from_date(2018, 1, 1), fx_provider): {}'.format(p2))


# Generated at 2022-06-24 01:21:33.592999
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    m1 = NoneMoney
    m2 = NoneMoney
    assert m1.__eq__(m2) is True
    assert m2.__eq__(m1) is True

# Generated at 2022-06-24 01:21:44.640159
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    """
    Test that the method ``__abs__`` of class ``SomeMoney`` works as expected.
    """
    a = SomeMoney(ccy=Currency("EUR"), qty=Decimal("10.00"), dov=Date(2020, 5, 15))
    assert a.__abs__() == SomeMoney(ccy=Currency("EUR"), qty=Decimal("10.00"), dov=Date(2020, 5, 15))

    b = SomeMoney(ccy=Currency("EUR"), qty=Decimal("-10.00"), dov=Date(2020, 5, 15))
    assert b.__abs__() == SomeMoney(ccy=Currency("EUR"), qty=Decimal("10.00"), dov=Date(2020, 5, 15))

# Generated at 2022-06-24 01:21:45.652738
# Unit test for method abs of class Money
def test_Money_abs():
    pass

# Generated at 2022-06-24 01:21:52.714918
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    ccy = USD
    qty = Decimal("1.23")
    dov = Date.today()
    p = SomePrice(ccy, qty, dov)
    assert p // 3 == SomePrice(ccy, qty // 3, dov)
    assert p.floor_divide(3) == SomePrice(ccy, qty // 3, dov)


# Generated at 2022-06-24 01:22:03.052995
# Unit test for method __ge__ of class Money

# Generated at 2022-06-24 01:22:10.341378
# Unit test for method round of class Money
def test_Money_round():
  money1 = Money.of(usd, Decimal('2000.501'), date(2020, 1, 1))
  money2 = Money.of(usd, Decimal('2000.499'), date(2020, 1, 1))
  assert round(money1, 2) == Money.of(usd, Decimal('2000.50'), date(2020, 1, 1))
  assert round(money2, 2) == Money.of(usd, Decimal('2000.50'), date(2020, 1, 1))



# Generated at 2022-06-24 01:22:20.077334
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    ccys = [Banker.GBP, Banker.USD, Banker.CHF]
    qtys = [10.0, 100.0, 1000.0]
    dovs = [datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)]
    values = [0.0, 10.0, 100.0]
    for cc in ccys:
        for q in qtys:
            for d in dovs:
                for v in values:
                    assert SomeMoney(cc, q, d).scalar_subtract(v) == SomeMoney(cc, q - v, d)



# Generated at 2022-06-24 01:22:25.089414
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    eur = Money.of(ccy=EUR, qty=-1.0, dov=Date.today())
    assert eur == -eur



# Generated at 2022-06-24 01:22:33.909017
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Test for method gte of class Money
    """
    nullMoney = Money.of(None, None, None)
    assert not nullMoney.gte(nullMoney)
    nullMoney2 = Money.of(None, None, None)
    assert not nullMoney.gte(nullMoney2)
    nullMoney2 = Money.of(None, 2, None)
    assert not nullMoney.gte(nullMoney2)
    nullMoney = Money.of(None, 2, None)
    assert nullMoney.gte(nullMoney2)
    assert not nullMoney2.gte(nullMoney)
    tMoney = Money.of(Currency.USD, 2, None)
    assert tMoney.gte(tMoney)
    assert tMoney.gte(tMoney.with_qty(Decimal(2)))
   

# Generated at 2022-06-24 01:22:46.290368
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.NA.floor_divide(12) == Price.NA
    assert SomePrice(Ccy("USD"), 1, Date("2018-01-01")).floor_divide(2) == Price.of(Ccy("USD"), 0, Date("2018-01-01"))
    assert SomePrice(Ccy("USD"), 3, Date("2018-01-01")).floor_divide(2) == Price.of(Ccy("USD"), 1, Date("2018-01-01"))
    assert SomePrice(Ccy("USD"), 1, Date("2018-01-01")).floor_divide(2) == Price.of(Ccy("USD"), 0, Date("2018-01-01"))

# Generated at 2022-06-24 01:22:48.228388
# Unit test for method __int__ of class Price
def test_Price___int__():
    with pytest.raises(TypeError):
        Price.NA.__int__()


# Generated at 2022-06-24 01:22:55.841708
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    """
    Returns a money object with the given value date.
    """
    ccy, dov, dob, qty = (
        Currency("USD"),
        Date.today(),
        Date.today(),
        Decimal("1.2345"),
    )
    assert SomeMoney(ccy, qty, dob).with_dov(dov) == SomeMoney(ccy, qty, dov)


# Generated at 2022-06-24 01:22:59.549752
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
  some_money = SomeMoney("XCD", "123", "1995-02-02")
  result = some_money.negative()
  assert isinstance(result, Money)
  assert result.undefined is True
  assert result == NoMoney
  assert float(result) == 0.0
  assert str(result) == "0.00"

# Generated at 2022-06-24 01:23:08.787745
# Unit test for method __add__ of class Money
def test_Money___add__():
    """
    Tests the method __add__ of class Money.
    """
    from .currencies import USD, EUR, try_parse_ccy, NO_CURRENCY
    from .exchange import FXRate
    from .money import Money, SomeMoney
    from .prices import SomePrice, NonePrice
    from pytz import UTC
    from decimal import Decimal
    from datetime import date
    from unittest import TestCase
    from unittest.mock import Mock, sentinel
    from pytest import raises
    from dateutil.parser import parse

    ## A typical money object:
    today = date.today()
    eur = try_parse_ccy("EUR")
    usd = try_parse_ccy("USD")

# Generated at 2022-06-24 01:23:13.415299
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Test method __add__ of class NoneMoney
    """
    a = NoneMoney()
    b = NoneMoney()
    c = a + b
    assert c is NoneMoney

# Generated at 2022-06-24 01:23:17.281987
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    ccy = Currency.of("GBP")
    assert SomeMoney(ccy, Decimal("1.234"), Date.today()).__float__() == 1.2340000000000001

# Generated at 2022-06-24 01:23:27.149145
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    """ Unit test for constructor of class IncompatibleCurrencyError. """
    Currency("EUR").assert_equals(IncompatibleCurrencyError(Currency("EUR"), Currency("USD")).ccy1)
    Currency("USD").assert_equals(IncompatibleCurrencyError(Currency("EUR"), Currency("USD")).ccy2)
    "check".assert_equals(IncompatibleCurrencyError(Currency("EUR"), Currency("USD"), "check").operation)
    "check".assert_equals(IncompatibleCurrencyError(Currency("EUR"), Currency("USD"), operation="check").operation)


# Generated at 2022-06-24 01:23:34.742405
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():

    a = MonetaryOperationException()
    assert type(a) == MonetaryOperationException
    assert a.args == ()

    b = MonetaryOperationException("a_message")
    assert type(b) == MonetaryOperationException
    assert b.args == ("a_message",)

    c = MonetaryOperationException("a_message", "another")
    assert type(c) == MonetaryOperationException
    assert c.args == ("a_message", "another")




# Generated at 2022-06-24 01:23:38.190185
# Unit test for method __add__ of class Money
def test_Money___add__():
    pass

# Generated at 2022-06-24 01:23:41.522912
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    """
    Tests method __add__ of class NonePrice.
    """
    pass



# Generated at 2022-06-24 01:23:51.397678
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    """
    Tests that the method __le__ of class SomePrice
    """

    # Import necessary modules
    from contracts import contract

    # Set up necessary variables
    some_price_1 = SomePrice(Currency.usd, Decimal('1.23'), Date('2020-01-02'))
    some_price_2 = SomePrice(Currency.usd, Decimal('1.23'), Date('2020-01-02'))
    some_price_3 = SomePrice(Currency.usd, Decimal('1.22'), Date('2020-01-02'))
    some_price_4 = SomePrice(Currency.eur, Decimal('1.23'), Date('2020-01-02'))
    some_price_5 = NoPrice

    # Test expected behaviour

# Generated at 2022-06-24 01:23:56.950066
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    """
    Tests method convert
    """

    # In:
    # out = NonePrice().convert(Euro, Date.today())
    pass

# Generated at 2022-06-24 01:23:57.570299
# Unit test for method convert of class SomePrice
def test_SomePrice_convert(): ...



# Generated at 2022-06-24 01:24:07.817175
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    for P in [SomePrice, NoPrice]:
        assert P == P, "Object should be equal to itself."
        assert P != Money.NA, "Undefined price is never equal to undefined money."

        assert (
            P(Currency("USD"), Decimal("1.34"), Date(2000, 3, 27))
            == P(Currency("USD"), Decimal("1.34"), Date(2000, 3, 27))
        ), "Two prices with same elements are equal."

        assert P(Currency("USD"), Decimal("1.34"), Date(2000, 3, 27)) != P(
            Currency("USD"), Decimal("1.34"), Date(2000, 5, 21)
        ), "Prices with different dates are not equal."


# Generated at 2022-06-24 01:24:14.493360
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert Money.of(None, None, None).as_boolean() is False
    assert Money.of(None, Decimal("0.0"), None).as_boolean() is False
    assert Money.of(Currency.USD, Decimal("0.0"), Date.today()).as_boolean() is False
    assert Money.of(Currency.USD, Decimal("10.0"), Date.today()).as_boolean() is True


# Generated at 2022-06-24 01:24:15.998704
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    assert SomePrice("USD", Decimal("100"), Date.today()).with_ccy("CHF") == SomePrice("CHF", Decimal("100"), Date.today())

# Generated at 2022-06-24 01:24:23.100580
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    """
    Tests method SomeMoney.__truediv__
    """

    # Case 1: __truediv__ of a SomeMoney object with a defined currency and quantity against a numeric
    # object, returning a SomeMoney object
    #   Input:
    #       self: A SomeMoney object with a defined currency, EUR, and a defined quantity, 0.000001
    #       other: Numeric object, 100
    #   Expected output:
    #       A SomeMoney object with a currency, EUR, and a quantity, 0.00000001
    #   Actual output:
    #       A SomeMoney object with a currency, EUR, and a quantity, 0.00000001

# Generated at 2022-06-24 01:24:32.959270
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    '''
    Tests constructor of class IncompatibleCurrencyError
    '''
    ccy1 = Currency.EUR
    ccy2 = Currency.USD
    operation = 'operation'
    try:
        raise IncompatibleCurrencyError(ccy1, ccy2, operation)
    except IncompatibleCurrencyError as e:
        assert e.ccy1 == ccy1
        assert e.ccy2 == ccy2
        assert e.operation == operation
        assert e.msg == f"{ccy1.code} vs {ccy2.code} are incompatible for operation '{operation}'."



# Generated at 2022-06-24 01:24:41.549322
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    from datetime import date
    from business.money import EUR, USD, Money
    from business.price import Price, SomePrice, NonePrice

    sp = SomePrice(EUR, Decimal("1.25"), date(2020, 1, 1))
    np = NonePrice()

    assert not (np == sp)

    assert np == np

    assert np == NonePrice()

    assert np == Price()

    assert not (np != np)

    assert not (np != NonePrice())

    assert not (np != Price())


# Generated at 2022-06-24 01:24:45.020151
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert (-NoPrice).abs() == NoPrice
    assert (-SomePrice(USD, Decimal(10), dov)).abs() == SomePrice(USD, Decimal(10), dov)

# Generated at 2022-06-24 01:24:46.689888
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    assert SomeMoney("USD", Decimal("123.45"), Date(2020, 1, 1)).with_ccy("EUR") == Money.of("EUR", Decimal("123.45"), Date(2020, 1, 1))

# Generated at 2022-06-24 01:24:56.367563
# Unit test for constructor of class NonePrice
def test_NonePrice():
    a = NonePrice()
    # Result: False
    print(a.__bool__())
    # Result: a
    print(a.__abs__())
    # Result: a
    print(a.__float__())
    # Result: a
    print(a.__int__())
    # Result: a
    print(a.__neg__())
    # Result: a
    print(a.__pos__())
    # Result: a
    print(a.__add__(a))
    # Result: a
    print(a.__sub__(a))
    # Result: a
    print(a.__mul__(a))
    # Result: a
    print(a.__truediv__(a))
    # Result: a
    print(a.__floordiv__(a))
   

# Generated at 2022-06-24 01:25:04.102480
# Unit test for method gte of class Price
def test_Price_gte():
    assert NoPrice.gte(USD(0, "2002-01-01")) is True
    assert NoPrice.gte(NoPrice) is True
    assert NoPrice.gte(NoMoney) is True
    assert NoMoney.gte(NoPrice) is True
    assert NoMoney.gte(USD(1, "2002-01-01")) is True
    assert USD(1, "2002-01-01").gte(NoMoney) is False
    assert USD(1, "2002-01-01").gte(USD(1, "2002-01-01")) is True
    assert USD(1, "2002-01-01").gte(USD(2, "2002-01-01")) is False

test_Price_gte()

# Generated at 2022-06-24 01:25:08.173414
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(EUR, Decimal('300'), dt.date(2017,6,26)).multiply(Decimal('2')) == Price.of(EUR, Decimal('600'), dt.date(2017,6,26))



# Generated at 2022-06-24 01:25:15.322448
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    assert NoneMoney.scalar_add(1) == NoneMoney
    assert SomeMoney(Currency.USD, Decimal(1), Date.today()).scalar_add(1) == SomeMoney(Currency.USD, Decimal(2), Date.today())


# Generated at 2022-06-24 01:25:25.639948
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    with raises(IncompatibleCurrencyError):
        SomePrice(Currency("EUR"), Decimal("1.12345"), Date(2019, 12, 31)) > Price(Currency("USD"), Decimal("1.12345"), Date(2019, 12, 31))
    with raises(IncompatibleCurrencyError):
        Price(Currency("EUR"), Decimal("1.12345"), Date(2019, 12, 31)) > SomePrice(Currency("USD"), Decimal("1.12345"), Date(2019, 12, 31))
    with raises(IncompatibleCurrencyError):
        Price(Currency("EUR"), Decimal("1.12345"), Date(2019, 12, 31)) > Price(Currency("USD"), Decimal("1.12345"), Date(2019, 12, 31))

# Generated at 2022-06-24 01:25:35.598365
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    from .currencies import CAD, USD
    from .money import Money, NoMoney, SomeMoney

    assert (+NoMoney).__abs__() == NoMoney
    assert (+NoMoney).__abs__() is NoMoney

    assert (+SomeMoney(CAD, 0, Date.today())).__abs__() == SomeMoney(CAD, 0, Date.today())
    assert (+SomeMoney(CAD, 0, Date.today())).__abs__() is not SomeMoney(CAD, 0, Date.today())

    assert (+SomeMoney(CAD, -1.23, Date.today())).__abs__() == SomeMoney(CAD, 1.23, Date.today())
    assert (+SomeMoney(CAD, -1.23, Date.today())).__abs__() is not SomeMoney(CAD, 1.23, Date.today())



# Generated at 2022-06-24 01:25:37.711455
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    assert NoMoney.__eq__(NoMoney) == True
    assert NoMoney.__eq__(SomeMoney(USD, Decimal("100.00"), Date.today())) == False


# Generated at 2022-06-24 01:25:47.365778
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    assert UndefinedMoney / UndefinedMoney == UndefinedMoney
    assert UndefinedMoney / UndefinedPrice == UndefinedPrice
    assert UndefinedMoney / UndefinedQuantity == UndefinedQuantity
    assert UndefinedMoney / UndefinedRate == UndefinedRate
    assert UndefinedMoney / UndefinedSpread == UndefinedSpread
    assert UndefinedMoney / UndefinedValue == UndefinedValue
    assert UndefinedMoney / UndefinedVolatility == UndefinedVolatility
    assert UndefinedMoney / Money(UndefinedCurrency, 0, Date(1900, 1, 1)) == UndefinedMoney
    assert UndefinedMoney / Price(UndefinedCurrency, 0, Date(1900, 1, 1)) == UndefinedPrice
    assert UndefinedMoney / Quantity(UndefinedCurrency, 0, Date(1900, 1, 1)) == UndefinedQuantity

# Generated at 2022-06-24 01:25:48.154971
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    pass



# Generated at 2022-06-24 01:25:51.755064
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    a = Money.of(Currency('USD'), 1.000000, date(2020, 1, 1))
    b = NoMoney
    assert (a.__bool__() == True)
    assert (b.__bool__() == False)


# Generated at 2022-06-24 01:25:53.840213
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    mon1 = SomeMoney(Currency("USD", decimals=2), Decimal("10.00"), Date("2019-05-01"))
    mon2 = SomeMoney(Currency("USD", decimals=2), Decimal("10.00"), Date("2019-05-01"))
    assert mon1.__gt__(mon2) == False

# Generated at 2022-06-24 01:26:02.431924
# Unit test for method lt of class Price
def test_Price_lt():
    class Price:
        undefined = False
        def __init__(self, ccy, qty, dov):
            self.currency = ccy
            self.quantity = qty
            self.dov = dov
        def is_equal(self, other):
            return other is not None and self.currency == other.currency and self.quantity == other.quantity and self.dov == other.dov
        def as_boolean(self):
            return self.quantity != 0
        def as_float(self):
            return float(self.quantity)
        def as_integer(self):
            return int(self.quantity)
        def abs(self):
            return Price(self.currency, abs(self.quantity), self.dov)

# Generated at 2022-06-24 01:26:03.558911
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    pass



# Generated at 2022-06-24 01:26:12.119521
# Unit test for method lt of class Price
def test_Price_lt():
    m1: Price = Price.of(None, None, None)
    m2: Price = Price.of(Currency.USD, 1, Date.now())
    assert m1 < m2
    m1 = Price.of(Currency.USD, None, Date.now())
    assert not (m1 < m2)
    m1 = Price.of(Currency.USD, 1, Date.now())
    assert not (m1 < m2)
    m1 = Price.of(Currency.USD, 2, Date.now())
    assert not (m1 < m2)
    m1 = Price.of(Currency.USD, 1, Date.now() + 1)
    assert not (m1 < m2)
    m1 = Price.of(Currency.MXN, 1, Date.now())
    assert m1

# Generated at 2022-06-24 01:26:13.069768
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    pass

# Generated at 2022-06-24 01:26:14.331021
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    assert float(NoMoney) == 0



# Generated at 2022-06-24 01:26:25.121680
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    m1 = Money.of(GBP, Decimal(0))
    m2 = Money.of(GBP, Decimal(1))
    assert bool(m1) == False
    assert bool(m2) == True

    p1 = Price.of(GBP, Decimal(0), Date(1970, 1, 1))
    p2 = Price.of(GBP, Decimal(1), Date(1970, 1, 1))
    assert bool(p1) == False
    assert bool(p2) == True

    assert bool(NoPrice) == False

    with pytest.raises(TypeError, match="undefined price has no attribute"):
        bool(NoMoney)

# Generated at 2022-06-24 01:26:31.826867
# Unit test for method multiply of class Price
def test_Price_multiply():
    p1 = Price.of(ccy=Currency.of("USD"), qty=Decimal("100.00"), dov=Date.of(2020, 4, 20))
    p2 = p1.multiply(2)
    assert p2.ccy == Currency.of("USD")
    assert p2.qty == Decimal("200.00")
    assert p2.dov == Date.of(2020, 4, 20)

# Generated at 2022-06-24 01:26:37.173637
# Unit test for method add of class Price
def test_Price_add():
    Price.add(SomePrice(EUR, Decimal(500), datetime.date(2020,1,1)), SomePrice(USD, Decimal(500), datetime.date(2020,2,2)))


# Generated at 2022-06-24 01:26:43.676074
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    # Test with undefined price
    if Price.of(USD, None, None):
        raise RuntimeError()

    # Test with defined price
    price = Price.of(USD, Decimal(9), Date.of(19, 5, 2019))
    if not price.with_qty(Decimal(10)) == Price.of(USD, Decimal(10), Date.of(19, 5, 2019)):
        raise RuntimeError()

test_Price_with_qty()

# Generated at 2022-06-24 01:26:51.574224
# Unit test for method negative of class Price
def test_Price_negative():
    assert Price.NA.negative() == Price.NA

    assert Price.of(USD, +Decimal(100), date(2020, 1, 1)).negative().qty < Decimal(0)
    assert Price.of(USD, -Decimal(100), date(2020, 1, 1)).negative().qty > Decimal(0)

    assert Price.of(USD, Decimal(100), date(2020, 1, 1)).negative().dov == date(2020, 1, 1)

    assert Price(USD, Decimal(0), date(2020, 1, 1)).negative() == Price(USD, Decimal(0), date(2020, 1, 1))

    # Test for object equality

# Generated at 2022-06-24 01:27:03.342534
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    ccy, qty, dov = 'USD', Decimal('103'), Date(2018, 1, 1)
    t = SomeMoney(ccy, qty, dov)
    x = t.__sub__(None)
    assert x == (ccy, qty, dov)
    assert not isinstance(x, SomeMoney)
    x = t.__sub__(NoMoney)
    assert x == (ccy, qty, dov)
    assert not isinstance(x, SomeMoney)
    tccy, tqty, tdov = t
    xccy, xqty, xdov = x
    assert xccy == tccy
    assert xqty == tqty
    assert xdov == tdov

# Generated at 2022-06-24 01:27:14.924682
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    """
    Unit test for method __mul__ of class Money

    """
    # Issue:
    #   https://github.com/HazımK/quantulum3/issues/4
    #
    # Subject:
    #   Multiply Price by Decimal
    #
    # Tags:
    #   `Decimal`, `Money`
    #
    # Scenario:
    #   - Given a Money object, for instance ``M``
    #   - When it is multiplied by a Decimal object, for instance ``D``
    #     - Then the multiplication is successful and returns a Money object

    from decimal import Decimal
    from .currencies import get_currency
    from .models import Money

    M = Money.of(get_currency("USD"), Decimal("10.3"), None)

# Generated at 2022-06-24 01:27:16.753175
# Unit test for method gte of class Money
def test_Money_gte():
    assert Money.of(Currency.USD, 1, Date.today() + 1) >= Money.of(Currency.USD, 1, Date.today())

# Generated at 2022-06-24 01:27:17.432906
# Unit test for method abs of class Money
def test_Money_abs():
    pass

# Generated at 2022-06-24 01:27:20.899105
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    """
    Test method __gt__ of class NonePrice
    """
    # Test code
    # <Code>

# Generated at 2022-06-24 01:27:25.031048
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert (
        SomePrice("EUR", Decimal("100"), Date(2019, 4, 1)).convert("USD") ==
        SomePrice("USD", Decimal("109.89"), Date(2019, 4, 1))
    )
    assert (
        SomePrice("EUR", Decimal("100"), Date(2019, 4, 1)).convert("USD", strict=True) ==
        SomePrice("USD", Decimal("109.89"), Date(2019, 4, 1))
    )

# Generated at 2022-06-24 01:27:36.758055
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    money = NoneMoney()
    assert money.defined == False
    assert money.undefined == True
    assert money.as_boolean() == False
    assert money.is_equal(money) == True
    assert money.abs() is money
    with pytest.raises(TypeError):
        money.as_float()
    with pytest.raises(TypeError):
        money.as_integer()
    assert money.round() is money
    assert money.negative() is money
    assert money.positive() is money
    assert money.add(money) is money
    assert money.scalar_add(money) is money
    assert money.subtract(money) is money
    assert money.scalar_subtract(money) is money
    assert money.multiply(money) is money
    assert money.div

# Generated at 2022-06-24 01:27:49.570381
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    from datetime import date
    from decimal import Decimal
    from datetime import date
    from decimal import Decimal
    from finxact.types import Currency
    from finxact.types import Date
    from finxact.types import Money
    from finxact.types import NoMoney
    from finxact.types import NoPrice
    from finxact.types import Price
    from finxact.types import SomeMoney
    from finxact.types import SomePrice
    from finxact.types import Amount
    from finxact.types import FixedCurrency
    from finxact.types import Money
    from finxact.types import Money
    from finxact.types import Price
    from finxact.types import Price
    from finxact.types import SomeMoney
    from finxact.types import SomePrice

# Generated at 2022-06-24 01:27:53.381453
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():

    ## Assert function returns correct result:
    assert NoneMoney.of(USD, 5, date(2020, 10, 5)) < NoneMoney.of(USD, 10, date(2020, 10, 5))


# Generated at 2022-06-24 01:28:05.348495
# Unit test for method __round__ of class Money
def test_Money___round__():
    assert Money.of(USD, 1.001, Date.today()).__round__() == 1
    assert Money.of(USD, 1.001, Date.today()).__round__(None) == 1
    assert Money.of(USD, 1.001, Date.today()).__round__() == 1
    assert Money.of(USD, 1.001, Date.today()).__round__(2) == Money.of(USD, 1.00, Date.today())
    assert Money.of(USD, 1.001, Date.today()).__round__(Decimal(2)) == Money.of(USD, 1.00, Date.today())
    assert round(Money.of(USD, 1.001, Date.today())) == 1

# Generated at 2022-06-24 01:28:11.388529
# Unit test for method lte of class Price
def test_Price_lte():
    p1 = SomePrice(SomeCurrency('USD'), Decimal(1), SomeDate(2016,12,30))
    p2 = SomePrice(SomeCurrency('USD'), Decimal(1), SomeDate(2016,12,30))
    assert p1.lte(p2)

    

# Generated at 2022-06-24 01:28:15.845890
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    with_ccy=SomePrice(Currency('EUR'),Decimal('35'), date(2018, 1, 1)).with_ccy(Currency('USD'))
    assert with_ccy==SomePrice(Currency('USD'),Decimal('35'), date(2018, 1, 1))
    None

# Generated at 2022-06-24 01:28:27.175707
# Unit test for method lte of class Money
def test_Money_lte():
    # NoMoney
    assert NoMoney <= NoMoney
    assert NoMoney <= SomeMoney("USD", 1)
    assert SomeMoney("USD", 1) >= NoMoney
    # SomeMoney
    assert SomeMoney("USD", 1) <= SomeMoney("USD", 1)
    assert SomeMoney("USD", 1) <= SomeMoney("USD", 2)
    assert SomeMoney("USD", 2) >= SomeMoney("USD", 1)
    with pytest.raises(IncompatibleCurrencyError):
        assert SomeMoney("USD", 1) <= SomeMoney("EUR", 2)
    with pytest.raises(IncompatibleCurrencyError):
        assert SomeMoney("EUR", 2) >= SomeMoney("USD", 1)

# Generated at 2022-06-24 01:28:36.021013
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
  md = Price.of('USD', 100.0, '2019-03-31')
  d = Decimal(50)
  s = md.scalar_subtract(d)
  assert (s.value == 50.0 and s.ccy == 'USD' and s.dov == '2019-03-31')
  d = Price.of('USD', 50.0, '2019-03-31')
  s = md.scalar_subtract(d)
  assert (s.value == 50.0 and s.ccy == 'USD' and s.dov == '2019-03-31')
