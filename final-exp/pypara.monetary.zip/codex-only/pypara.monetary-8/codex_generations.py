

# Generated at 2022-06-24 01:18:37.166305
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert NoMoney >= NoMoney
    assert NoMoney >= SomeMoney(USD, 0, TODAY)
    assert SomeMoney(USD, 0, TODAY) >= NoMoney
    assert SomeMoney(USD, 1, TODAY) >= SomeMoney(USD, 0, TODAY)
    assert SomeMoney(USD, 1, TODAY) >= SomeMoney(USD, 1, TODAY)
    assert SomeMoney(USD, 1, TODAY) >= SomeMoney(USD, 2, TODAY)
    assert SomeMoney(USD, 1, TODAY) >= SomeMoney(EUR, 2, TODAY)



# Generated at 2022-06-24 01:18:42.203570
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    np = NonePrice()
    np2 = NonePrice()
    np3 = Price()
    assert np == np2
    assert not (np == np3)
    assert not (np2 == np3)

# Generated at 2022-06-24 01:18:45.744663
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    price = Price.of(Currency.of('USD'), Decimal('10.00'), Date.today())
    assert price.is_equal(price)

# Generated at 2022-06-24 01:18:49.500249
# Unit test for method __le__ of class NoneMoney
def test_NoneMoney___le__():
    some_money = SomeMoney(Currency("USD"), Decimal("11.22"), Date(2019, 1, 13))
    none_money = NoneMoney()
    assert some_money <= none_money
    assert not none_money <= some_money



# Generated at 2022-06-24 01:18:54.261968
# Unit test for method positive of class Money
def test_Money_positive():
    assert [
        Money.NA.positive(),
        Money("USD", 10.0, Date.today()).positive(),
    ] == [NoneMoney, SomeMoney("USD", 10.0, Date.today())]

# Generated at 2022-06-24 01:18:58.699487
# Unit test for method divide of class Money
def test_Money_divide():
    m = Money.of(None, None, None)
    m = m.with_ccy("USD").with_qty(100).with_dov("2029-09-01")
    m = m.divide(2)
    assert m.as_boolean() == True



# Generated at 2022-06-24 01:19:03.014365
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(CCY, Decimal(1), DOV).__bool__() is True
    assert SomePrice(CCY, Decimal(0), DOV).__bool__() is False


# Generated at 2022-06-24 01:19:04.036761
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    _1 = NoneMoney.round(None)
    assert type(_1) == NoneMoney
    assert repr(_1) == 'NoneMoney'

# Generated at 2022-06-24 01:19:09.686197
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    import unittest
    import zeitgeist.commons.random as rnd
    import zeitgeist.currencies as ccy


    class MoneyTestCase(unittest.TestCase):
        def test_NoneMoney___sub__(self):
            self.assertIs(
                NoMoney - NoMoney,
                NoMoney,
            )
            self.assertIs(
                NoMoney - SomeMoney.of(ccy.USD, 1, Date.today()),
                NoMoney,
            )
            self.assertIs(
                SomeMoney.of(ccy.USD, 1, Date.today()) - NoMoney,
                NoMoney,
            )
            self.assertRaises(
                MonetaryOperationException,
                lambda: NoneMoney - NoMoney,
            )

# Generated at 2022-06-24 01:19:19.821131
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    from pytest import raises
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    from money import Money as PyMoney
    class Money:
        """
        Monetary value.
        """

        def __init__(self, ccy, qty, dov):
            self.ccy = ccy
            self.qty = qty
            self.dov

# Generated at 2022-06-24 01:19:20.534873
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    pass



# Generated at 2022-06-24 01:19:21.272739
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    pass # TODO

# Generated at 2022-06-24 01:19:27.919830
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    from .price import Price
    from .price import SomePrice
    from .money import Money
    from pyksa.exchange import Currency
    from pyksa.exchange import NoneCurrency
    from dataclasses import dataclass
    from dataclasses import field
    from dataclasses import InitVar
    from dataclasses import is_dataclass
    from datetime import date
    from fractions import Fraction
    from typing import Any
    from typing import Optional
    from typing import Union
    from decimal import Decimal
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND

# Generated at 2022-06-24 01:19:29.662871
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    assert not (-SomeMoney(Currency("XXX"), 10.0, Date.now()))

# Generated at 2022-06-24 01:19:41.341158
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    m1 = SomeMoney(EUR, Decimal("100"), Date(2018, 11, 30))
    assert m1 // 1 == SomeMoney(EUR, Decimal("100"), Date(2018, 11, 30))
    assert m1 // Decimal("1.0") == SomeMoney(EUR, Decimal("100"), Date(2018, 11, 30))
    assert m1 // Decimal("1.00") == SomeMoney(EUR, Decimal("100"), Date(2018, 11, 30))
    assert m1 // Decimal("2.00") == SomeMoney(EUR, Decimal("50"), Date(2018, 11, 30))
    assert m1 // Decimal("1/10") == SomeMoney(EUR, Decimal("1000"), Date(2018, 11, 30))

# Generated at 2022-06-24 01:19:43.857947
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(Money.of(Currency.usd, Decimal(4.99), DATE)) == 4.99



# Generated at 2022-06-24 01:19:50.383154
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    print ("Testing __init__ in Price")
    price = SomePrice(USD, Decimal('100'), Date(2003, 12, 12))
    price.with_qty(Decimal('200'))
    assert price.qty == 200
    assert price.ccy == USD
    assert price.dov == Date(2003, 12, 12)
    print ("Test with_qty in Price Passed!")
test_Price_with_qty()

# Generated at 2022-06-24 01:19:59.979426
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    USD = Currency.USD
    EUR = Currency.EUR

    assert SomePrice(USD, 10, None).times(2.0) == SomeMoney(USD, 20, None)
    assert SomePrice(EUR, 10, None).times(2) == SomeMoney(EUR, 20, None)
    assert SomePrice(USD, 10, None).times(2) == SomeMoney(USD, 20, None)
    assert SomePrice(EUR, 10, None).times(-2.0) == SomeMoney(EUR, -20, None)
    assert SomePrice(USD, 10, None).times(-2) == SomeMoney(USD, -20, None)
    assert SomePrice(EUR, 10, None).times(-2) == SomeMoney(EUR, -20, None)



# Generated at 2022-06-24 01:20:04.623971
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Any

    class Price:
        pass

    class Money:
        pass

    class Currency:
        pass

    class Date:
        pass

    class SomeMoney:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        pass

    class FXRateService:
        pass

    class SomePrice:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        pass

    class IncompatibleCurrencyError:
        pass

    class FXRateLookupError:
        pass

    class ProgrammingError:
        pass

    class SomePrice:
        pass

    class FXRateService:
        pass


# Generated at 2022-06-24 01:20:10.898343
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    import pytest  # type: ignore
    # Decorator to mark a test as being a unit test.
    from pytest import mark  # type: ignore
    from .core import NoMoney, SomeMoney
    from .core import SomePrice

    assert not NoMoney >= NoMoney
    assert not NoMoney >= SomeMoney(None, None, None)
    assert not NoMoney >= SomePrice(None, None)
    assert not NoMoney >= NoPrice
    assert not NoMoney >= SomePrice(None, None)
    assert not NoMoney >= 1.0
    assert not NoMoney >= 1

    with pytest.raises(TypeError):
        NoMoney >= "hello"


# Generated at 2022-06-24 01:20:21.136411
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    assert (NoMoney - 3.0 == NoMoney)
    assert (NoMoney - 3 == NoMoney)
    assert (NoMoney - 3.000 == NoMoney)
    assert (NoMoney - Decimal('3.0') == NoMoney)
    assert (NoMoney - Decimal('3.0') == NoMoney)

    try:
        NoMoney - 3.5
        assert False
    except:
        assert True


Money.__slots__ = ()

##noinspection PyUnresolvedReferences
from testmonies.test_money import *
##noinspection PyUnresolvedReferences
from testmonies.test_monies import *
##noinspection PyUnresolvedReferences
from testmonies.test_price import *
##noinspection PyUnresolvedReferences
from testmonies.test_prices import *

# Generated at 2022-06-24 01:20:22.525141
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    assert (NoPrice.convert(USD) == USD.NA)

# Generated at 2022-06-24 01:20:29.085035
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    c = Currency('INR')
    q = Decimal('20.0000')
    d = Date('2020-01-01')
    p = SomePrice(c, q, d)

    divisor = Decimal('7.0000')
    result = p / divisor

    assert isinstance(result, SomePrice)
    assert result.ccy == c
    assert result.qty == Decimal('2.8571')
    assert result.dov == d



# Generated at 2022-06-24 01:20:30.894420
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    # Exercise
    actual_result = NoneMoney.scalar_add(0)
    # Verify
    assert actual_result == NoneMoney



# Generated at 2022-06-24 01:20:38.371455
# Unit test for method as_float of class Money
def test_Money_as_float():
    """
    Checks the correctness of method as_float of class Money.
    """
    def _test_Money_as_float_case(m: Money) -> None:
        assert isinstance(m.as_float(), float)

    _test_Money_as_float_case(NoMoney)
    _test_Money_as_float_case(SomeMoney(Currency("EUR"), Decimal("1.1"), Date.today()))



# Generated at 2022-06-24 01:20:40.688832
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    ...

# Generated at 2022-06-24 01:20:43.906266
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    assert SomePrice(Currency.of("USD"), Decimal("1.23"), date(2019, 2, 15)) + Decimal("4.56") \
        == SomePrice(Currency.of("USD"), Decimal("5.79"), date(2019, 2, 15))

# Generated at 2022-06-24 01:20:55.547102
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    from .currency import EUR
    from .price import SomePrice, NonePrice
    from .money import Money
    from datetime import date
    from decimal import Decimal
    assert NonePrice.__eq__(SomePrice(EUR, Decimal(1), date(2018, 10, 28))) == False
    assert NonePrice.__eq__(Money(EUR, Decimal(1), date(2018, 10, 28))) == False
    assert NonePrice.__eq__(NonePrice()) == True
    assert NonePrice.__eq__(SomePrice(EUR, Decimal(1), date(2018, 10, 28))) is True
    assert NonePrice.__eq__(Money(EUR, Decimal(1), date(2018, 10, 28))) is True
    assert NonePrice.__eq__(NonePrice()) is True



# Generated at 2022-06-24 01:21:05.657391
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(CAD, Decimal("1.2345"), Date.now()).times(Decimal("10")) == Money.of(CAD, Decimal("12.345"), Date.now())
    assert Price.of(USD, Decimal("1.2345"), Date.now()).times(Decimal("10")) == Money.of(USD, Decimal("12.345"), Date.now())
    assert Price.of(EUR, Decimal("1.2345"), Date.now()).times(Decimal("10")) == Money.of(EUR, Decimal("12.345"), Date.now())
    assert Price.of(GBP, Decimal("1.2345"), Date.now()).times(Decimal("10")) == Money.of(GBP, Decimal("12.345"), Date.now())
    assert Price.of

# Generated at 2022-06-24 01:21:14.531844
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    """
    Tests ``__float__`` method of ``SomeMoney`` class.

    Notes:
        1. We use ``USD`` as the currency.
        2. We test against ``10.0`` (float) and ``100.0`` (float).
    """
    ## Create a money object:
    m1 = SomeMoney(USD, Decimal("10.0"), Date.today())

    ## Test:
    assert m1.__float__() == 10.0

# Generated at 2022-06-24 01:21:15.509695
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    assert isinstance(int(NonePrice()), int)


# Generated at 2022-06-24 01:21:20.064291
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    ## Arrange:
    ccy: Currency = Currency.USD
    qty: Decimal = Decimal(100)
    dov: Date = Date.today()
    m: Money = SomeMoney(ccy, qty, dov)
    ## Act:
    m = m.__abs__()
    ## Assert:
    assert isinstance(m, SomeMoney)
    assert m.ccy == ccy
    assert m.qty == qty
    assert m.dov == dov


# Generated at 2022-06-24 01:21:22.441114
# Unit test for method lte of class Money
def test_Money_lte():
    # Make sure that None <= None
    assert (NoneMoney <= NoneMoney) == True


# Generated at 2022-06-24 01:21:32.224649
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert Money.of(ccy=Currency.USD, qty=1.00, dov=Date(2001, 1, 1)).as_integer() == 1
    assert Money.of(ccy=Currency.USD, qty=1.50, dov=Date(2001, 1, 1)).as_integer() == 1
    assert Money.of(ccy=Currency.USD, qty=1.99, dov=Date(2001, 1, 1)).as_integer() == 1
    assert Money.of(ccy=Currency.USD, qty=2.00, dov=Date(2001, 1, 1)).as_integer() == 2

    with raises(MonetaryOperationException):
        NoMoney.as_integer()

    with raises(MonetaryOperationException):
        NoneMoney.as_integer()



# Generated at 2022-06-24 01:21:33.013896
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    assert NoneMoney == +NoneMoney


# Generated at 2022-06-24 01:21:34.932720
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    not_implemented()


# Generated at 2022-06-24 01:21:39.087198
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    # Test 1.
    actual = SomeMoney(USD, Decimal("10.00"), Date("2018-12-31"))
    expected = SomeMoney(USD, Decimal("10.00"), Date("2018-12-31"))
    assert actual == expected



# Generated at 2022-06-24 01:21:47.112792
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    ## Prepare data:
    b = NoPrice
    ## Execute action:
    x: bool = b < b
    ## Verify outcome:
    assert x == False, "Failed when NoPrice < NoPrice"
    ## Prepare data:
    b = NoPrice
    c = SomePrice(USD, 1, None)
    ## Execute action:
    x: bool = b < c
    ## Verify outcome:
    assert x == False, "Failed when NoPrice < SomePrice"
    ## Prepare data:
    b = SomePrice(USD, 1, None)
    c = NoPrice
    ## Execute action:
    x: bool = b < c
    ## Verify outcome:
    assert x == True, "Failed when SomePrice < NoPrice"
    ## Prepare data:
    b = SomePrice(USD, 1, None)
   

# Generated at 2022-06-24 01:21:58.217364
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.NA.divide(2) == Price.NA
    assert Price.of(USD, 4, Date.today()).divide(2) == Price.of(USD, 2, Date.today())
    assert Price.of(USD, 4, Date.today()).divide(2.0) == Price.of(USD, 2, Date.today())
    assert Price.of(USD, 16, Date.today()).divide(4) == Price.of(USD, 4, Date.today())
    assert Price.of(USD, 16, Date.today()).divide(4.0) == Price.of(USD, 4, Date.today())
    assert Price.of(USD, 4.0, Date.today()).divide(2) == Price.of(USD, 2, Date.today())

# Generated at 2022-06-24 01:22:06.840797
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert_equal(Price.of(ccy='USD',qty=Decimal('1234567890123456789.1234567890123456789'),dov=Date(2020,8,18)).__neg__(), Price.of(ccy='USD',qty=Decimal('-1234567890123456789.1234567890123456789'),dov=Date(2020,8,18)))
    assert_equal(Price.of(ccy='GBP',qty=Decimal('0E-10'),dov=Date(2020,8,18)).__neg__(), Price.of(ccy='GBP',qty=Decimal('0E-10'),dov=Date(2020,8,18)))

# Generated at 2022-06-24 01:22:18.646302
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    assert Money.of(Currency.USD, 100, Date(2018, 1, 1)) * Money.of(Currency.USD, 10, Date(2018, 1, 1)) == Money.of(Currency.USD, 1000, Date(2018, 1, 1))
    assert Money.of(Currency.USD, 100, Date(2018, 1, 1)) * 10 == Money.of(Currency.USD, 1000, Date(2018, 1, 1))
    assert int(Money.of(Currency.USD, 100, Date(2018, 1, 1))) == 100
    assert float(Money.of(Currency.USD, 100, Date(2018, 1, 1))) == 100.0

# Generated at 2022-06-24 01:22:25.451818
# Unit test for constructor of class Money
def test_Money():
    from .currencies import USD
    from .commons.zeitgeist import Date

    m = Money.of(USD, 1.0, Date())
    assert m.ccy == USD
    assert m.qty == 1.0
    assert m.dov == Date()



# Generated at 2022-06-24 01:22:28.714545
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    return None



# Generated at 2022-06-24 01:22:31.665168
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    money = SomeMoney(usd, Decimal("1.2345"), dov)
    assert (money * 1.23) == SomeMoney(usd, Decimal("1.5235"), dov)


# Generated at 2022-06-24 01:22:43.228667
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    """
    Assert that __add__ of some price object with None, None, None and another valid price object
    raises TypeError.
    """
    #Arrange
    from my_money.domain.price import NoPrice
    from my_money.domain.price import SomePrice
    from my_money.domain.currency import USD
    from my_money.domain.currency import EUR
    from moneyed import Money
    from datetime import date
    from decimal import Decimal
    from decimal import ROUND_HALF_UP
    import pytest 
    ccy = EUR
    qty = Money(9.9, ccy)
    dov = date(2020, 3, 20)
    price = SomePrice(ccy, qty, dov)
    new_dov = date(2020, 3, 20)
    new_qty

# Generated at 2022-06-24 01:22:45.003556
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoMoney
    assert NoMoney.as_boolean() == False

# Generated at 2022-06-24 01:22:47.722522
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    assert float(SomePrice(ccy="USD", qty=Decimal("10.500"), dov=from_iso("2019-01-01"))) == 10.5

# Generated at 2022-06-24 01:22:56.139925
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    try:
        from cppyy.gbl import std
    except ImportError:
        print(f"skipping test_SomePrice___float__(): no CPPYY..")
    else:
        try:
            p = SomePrice.of(USD, Decimal(2.5), Date(2020, 1, 2))
            std.cout << p.__float__() << std.endl
        except Exception as exc:
            assert False, f"failed test_SomePrice___float__(): {exc}"


# Generated at 2022-06-24 01:23:01.657912
# Unit test for method __int__ of class Money
def test_Money___int__():
    from decimal import Decimal
    from datetime import date
    from pyexlatex.currencies import Currency
    Currency.FXRateService = MockFXRateService( {
        ('USD', 'EUR'): 0.8,
        ('EUR', 'USD'): 1.25,
        ('USD', 'USD'): 1.0
    })
    from pyexlatex.money import Money
    money = Money.of(Currency.of('USD'), Decimal('1.01'), date(2019, 1, 1))
    assert int(money) == 1
    assert float(money) == 1.01


# Generated at 2022-06-24 01:23:11.754185
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert (SomePrice(CCY.EUR, Decimal('20.00'), now()) < SomePrice(CCY.EUR, Decimal('20.00'), now()+timedelta(days=1))) == False
    assert (SomePrice(CCY.EUR, Decimal('20.00'), now()) < SomePrice(CCY.EUR, Decimal('30.00'), now())) == True
    assert (SomePrice(CCY.EUR, Decimal('20.00'), now()+timedelta(days=2)) < SomePrice(CCY.EUR, Decimal('20.00'), now()+timedelta(days=1))) == False

# Generated at 2022-06-24 01:23:17.644441
# Unit test for method __add__ of class Price
def test_Price___add__():
    # arrange
    price1 = Price.of(USD, 1, date(2020, 1, 1))
    price2 = Price.of(USD, 2, date(2020, 1, 1))
    
    # act
    result = price1 + price2
    
    # assert
    assert result.ccy == USD
    assert result.qty == 3
    assert result.dov == date(2020, 1, 1)

# Generated at 2022-06-24 01:23:22.562563
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    assert (
        NoPrice * Decimal(9) == NoPrice
    )

# Generated at 2022-06-24 01:23:33.463351
# Unit test for constructor of class Money
def test_Money():
    """
    Executes unit tests for :class:`Money`.
    """
    from .currencies import Currency
    from ..utils import TestCase

    class SomeMoneyTestCase(TestCase):
        def setUp(self) -> None:
            self.ccy = Currency("USD")
            self.qty = Decimal("1.234567")
            self.dov = Date(2017, 1, 2)

        def test_create_with_valid_arguments(self):
            m = SomeMoney(self.ccy, self.qty, self.dov)

            # Assert we have a SomeMoney
            self.assertIsInstance(m, SomeMoney)

            # Assert that slots are set accordingly
            self.assertEqual(m.ccy, self.ccy)

# Generated at 2022-06-24 01:23:34.833213
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    assert NoneMoney.__neg__(NoneMoney()) == NoneMoney()


# Generated at 2022-06-24 01:23:40.527473
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    ccy = Currency.find("EUR")
    qty = Decimal("1000")
    dov = Date(2016, 12, 31)
    moneyA = SomeMoney(ccy, qty, dov)
    qty2 = Decimal("2000")
    moneyB = moneyA.with_qty(qty2)
    assert moneyA == SomeMoney(ccy, qty, dov)
    assert moneyB == SomeMoney(ccy, qty2, dov)


# Generated at 2022-06-24 01:23:44.716293
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert NoPrice.__bool__() is False
    assert SomePrice(Currency.USD, 10, Date(2018, 10, 10)).__bool__() is True
    assert SomePrice(Currency.USD, 0, Date(2018, 10, 10)).__bool__() is False

# Generated at 2022-06-24 01:23:53.095455
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from .currencies import CAD
    from .tp.calendars import get_business_day
    from .tp.dates import Days

    m = SomeMoney(CAD, 55, get_business_day(Days(2)))
    assert (m - 5) == SomeMoney(CAD, 50, get_business_day(Days(2)))
    assert (m - 5.5) == SomeMoney(CAD, 49.5, get_business_day(Days(2)))
    assert (m + (-5.5)) == SomeMoney(CAD, 49.5, get_business_day(Days(2)))
    assert (m + (-5.5)) == (m - 5.5)
    assert (m - (-5)) == SomeMoney(CAD, 60, get_business_day(Days(2)))

# Generated at 2022-06-24 01:23:55.527627
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert_that(NoPrice < NoPrice, equal_to(False))
    assert_that(NoPrice < SomePrice("USD", 1, Date.today), equal_to(True))
    assert_that(SomePrice("USD", 1, Date.today) < NoPrice, equal_to(False))

# Generated at 2022-06-24 01:24:01.341939
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    ccy = Currency.find("USD")
    m1 = SomeMoney(ccy, 1, Date.today())
    m2 = SomeMoney(ccy, 2, Date.today())
    assert (m1 + m2).qty == 3
    assert (m1 + m2).as_float() == 3.0
    assert (m1 + m2).as_integer() == 3

# Generated at 2022-06-24 01:24:07.756701
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(NoneMoney) == False
    assert bool(SomeMoney(Currency("USD"), Decimal("1E-64"), Date(2019, 1, 1))) == False
    assert bool(SomeMoney(Currency("USD"), Decimal("-1E-64"), Date(2019, 1, 1))) == False
    assert bool(SomeMoney(Currency("USD"), Decimal("0.0"), Date(2019, 1, 1))) == False
    assert bool(SomeMoney(Currency("USD"), Decimal("0.0"), Date(2019, 1, 1))) == False
    # perform a clean-up
    Money.NA = NoneMoney
    Money.ccy = NoneMoney.ccy
    Money.qty = NoneMoney.qty
    Money.dov = NoneMoney.dov
    Money.defined = NoneMoney.defined
    Money.und

# Generated at 2022-06-24 01:24:14.991507
# Unit test for method round of class Money
def test_Money_round():
    # 
    assert (Money.NA.round() == Money.NA)
    assert (Money.of(Currency.USD, Decimal("0.0"), Date.today()).round() == Money.of(Currency.USD, Decimal("0.0"), Date.today()))
    assert (Money.of(Currency.USD, Decimal("0.0"), Date.today()).round(ndigits=None) == Money.of(Currency.USD, Decimal("0.0"), Date.today()))
    assert (Money.of(Currency.USD, Decimal("0.0"), Date.today()).round(ndigits=0) == Money.of(Currency.USD, Decimal("0.0"), Date.today()))

# Generated at 2022-06-24 01:24:21.342375
# Unit test for method __sub__ of class Money
def test_Money___sub__():

    assert Money.of(USD, Decimal("100.25"), Date(2018, 1, 1)) - Money.of(USD, Decimal("0.25"), Date(2018, 2, 1)) == Money.of(
        USD, Decimal("100.00"), Date(2018, 2, 1)
    )
    assert Money.of(USD, Decimal("100.25"), Date(2018, 1, 1)) - Money.of(USD, Decimal("0"), Date(2018, 2, 1)) == Money.of(
        USD, Decimal("100.25"), Date(2018, 2, 1)
    )

# Generated at 2022-06-24 01:24:29.450514
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    ccy, qty = Currency.of("EUR"), Decimal(0.01)
    assert Money.of(ccy, qty, Date().today()).as_boolean() == True
    assert Money.of(ccy, 0.0, Date().today()).as_boolean() == False
    assert Money.of(ccy, None, None).as_boolean() == False


# Generated at 2022-06-24 01:24:31.235813
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    case = NoneMoney.convert(Dollar)
    assert isinstance(case, (NoneMoney))


# Generated at 2022-06-24 01:24:38.164342
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    # Test case 1.1
    _1_1_1 = CopyableMoney(Currency.USD, Decimal('100'), Date(1, 1, 1))
    _1_1_1_res = NonePrice.__ge__(_1_1_1)
    assert _1_1_1_res is True
    # Test case 1.2
    _1_1_2 = CopyableMoney(Currency.USD, Decimal('100'), Date(1, 1, 2))
    _1_1_2_res = NonePrice.__ge__(_1_1_2)
    assert _1_1_2_res is True
    # Test case 2.1
    _2_1_1 = CopyableMoney(Currency.EUR, Decimal('100'), Date(1, 1, 1))
    _2_1_1

# Generated at 2022-06-24 01:24:42.289885
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(SomeMoney(Currency.USD, Decimal(101), Date(2018, 1, 1))) is True
    assert bool(NoneMoney) is False
    assert bool(NoMoney) is False



# Generated at 2022-06-24 01:24:44.902415
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    try:
        raise MonetaryOperationException("Error")
    except TypeError as tc:
        assert("Error" == str(tc))



# Generated at 2022-06-24 01:24:55.528591
# Unit test for method __pos__ of class Money
def test_Money___pos__():

    # Unknown money object
    unknown_money = Money.of(ccy=Currency('EUR'), qty=None, dov=date.today())
    assert unknown_money.__pos__() == unknown_money
    assert unknown_money.__pos__() is not unknown_money
    assert unknown_money.__pos__().ccy == unknown_money.ccy
    assert unknown_money.__pos__().qty == unknown_money.qty
    assert unknown_money.__pos__().dov == unknown_money.dov
    assert unknown_money.__pos__().defined is False
    assert unknown_money.__pos__().undefined is True

    # Defined money object
    defined_money = Money.of(ccy=Currency('EUR'), qty=Decimal(1), dov=date.today())
   

# Generated at 2022-06-24 01:25:02.912691
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    """
    Test ``SomeMoney`` class method ``__int__``.
    """
    ## This is a None object:
    money = SomeMoney(Currency.USD, Decimal(0), Date(2019, 1, 1))
    assert isinstance(money, Money)
    assert isinstance(money, SomeMoney)
    assert int(money) == 0

    ## This is a None object:
    money = SomeMoney(Currency.USD, Decimal(1), Date(2019, 1, 1))
    assert isinstance(money, Money)
    assert isinstance(money, SomeMoney)
    assert int(money) == 1

test_SomeMoney___int__()

# Generated at 2022-06-24 01:25:14.470650
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    """
    Tests method __ge__ of class SomePrice

    **Test Scenario**

    - create a couple of prices
    - check their comma-separation
    - check that an undefined price can always be greater or equal to a defined one
    - check that an undefined price can always be greater or equal to another undefined one
    - check that an :class:`IncompatibleCurrencyError` is raised when comparing two defined prices with different
      currencies
    """
    ccy1 = Currency("EUR")
    ccy2 = Currency("USD")

    asof1 = Date(2018, 1, 1)
    asof2 = Date(2018, 1, 2)

    p1 = SomePrice(ccy1, Decimal("1.5"), asof1)
    p2 = SomePrice(ccy1, Decimal("1.51"), asof2)

# Generated at 2022-06-24 01:25:25.722210
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert Money.of(CSA.USD, 100, Date.today()) >= Money.of(CSA.USD, 99, Date.today())
    assert Money.of(CSA.USD, 100, Date.today()) >= Money.of(CSA.USD, 100, Date.today())
    assert not Money.of(CSA.USD, 99, Date.today()) >= Money.of(CSA.USD, 100, Date.today())

    assert not Money.of(CSA.USD, 100, Date.today()) >= CSA.USD(100, Date.today())
    assert Money.of(CSA.USD, 100, Date.today()) >= Money.of(CSA.USD, 100, Date.today())
    assert not Money.of(CSA.USD, 99, Date.today()) >= CSA.USD(100, Date.today())


# Generated at 2022-06-24 01:25:32.838249
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    c1=Currency('USD')
    q1=Decimal(1)
    d1=Date(2019,12,31)
    c2=Currency('USD')
    q2=Decimal(1)
    d2=Date(2019,12,31)
    p1 = SomePrice(c1, q1, d1)
    p2 = SomePrice(c2, q2, d2)
    ans=p1 <= p2
    print('equal: ', ans)




# Generated at 2022-06-24 01:25:39.637530
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    assert (SomeMoney(Currency("USD"), Decimal("10.25"), Date.today()) // Numeric(2)).qty == Decimal("5")
    assert (SomeMoney(Currency("USD"), Decimal("10.25"), Date.today()) // Numeric("2")).qty == Decimal("5")
    assert (SomeMoney(Currency("USD"), Decimal("10.25"), Date.today()) // Numeric("2.")) == NoMoney
    assert (SomeMoney(Currency("USD"), Decimal("10.25"), Date.today()) // Numeric("0")) == NoMoney
    assert (SomeMoney(Currency("USD"), Decimal("10.25"), Date.today()) // Numeric("2.0")) == NoMoney

# Generated at 2022-06-24 01:25:40.610534
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    price = Price()
    """Tests Price.__sub__ method"""



# Generated at 2022-06-24 01:25:44.887489
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    assert (SomeMoney(USD, Decimal(0), Date(2018, 12, 18)) or True) is True
    assert (SomeMoney(USD, Decimal(0), Date(2018, 12, 18)) or False) is False
    assert (SomeMoney(USD, Decimal(1), Date(2018, 12, 18)) or True) is True

# Generated at 2022-06-24 01:25:49.926822
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    """
    Checks the constructor of class MonetaryOperationException
    """
    # Try with no specification of operation
    moe1 = MonetaryOperationException("Some message")
    assert moe1.args[0] == "Some message"
    assert moe1.operation is None

    # Try with operation specification
    moe2 = MonetaryOperationException("Some message", operation="Some operation")
    assert moe2.args[0] == "Some message"
    assert moe2.operation == "Some operation"



# Generated at 2022-06-24 01:25:52.259599
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    NonePrice(None, None) > SomePrice(CCY.USD, Decimal('1'), Date('2018-01-01'))

# Generated at 2022-06-24 01:26:02.348314
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    ccy = Currency('EUR')
    qty = Decimal(10)
    dov = Date(2020, 1, 1)
    value = SomeMoney(ccy, qty, dov)
    other = SomeMoney(ccy, qty, dov)

    assert value.__eq__(value.__add__(other)) is True
    assert value.__add__(other).is_equal(value.__add__(other)) is True
    assert value.__add__(other).__eq__(value.__add__(other)) is True

    # Other way around:

    assert other.__eq__(value.__add__(other)) is True
    assert other.is_equal(value.__add__(other)) is True
    assert other.__eq__(value.__add__(other)) is True

   

# Generated at 2022-06-24 01:26:12.228025
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    from finstmt.config import load as cfg_load
    from finstmt.config.const import ConfigKey
    from finstmt.config.util import get_fxra_config

    cfg_load(get_fxra_config(ConfigKey.FXRATE_LOCAL))


# Generated at 2022-06-24 01:26:13.850757
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    x = USD(1)
    assert x.as_float() == 1.0

# Generated at 2022-06-24 01:26:17.246143
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    assert NoMoney.scalar_subtract(10) == NoMoney
    assert NoMoney.scalar_subtract(10.0) == NoMoney


# Generated at 2022-06-24 01:26:23.013445
# Unit test for constructor of class Money
def test_Money():
    ccy = Currency("USD")
    qty = Decimal("1000")
    dov = Date("2019-01-01")
    money = Money.of(ccy , qty, dov)
    assert money.ccy == ccy
    assert money.qty == qty
    assert money.dov == dov



# Generated at 2022-06-24 01:26:34.729965
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from .currency import Currency
    from .money import Money
    from .price import Price
    from .quantity import Quantity
    from .quantity.bases import M
    from ..datemath import Date
    from ..fxrates import FXRateService, FXRate
    from ..money import Money
    from ..schema import MoneyDecimal, MoneyString
    from decimal import Decimal
    from marshmallow import Schema, fields, post_load
    from pytest import mark, raises

    ## Define the provider that extends the base currency
    class MyCurrency(Currency):
        ## Extend the base class with more currencies
        supported = Currency.supported + ("USD", "EUR", "GBP", "CHF")

        ## Simplify the data by to avoid repetitions:

# Generated at 2022-06-24 01:26:42.148152
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    U1 = SomePrice(Currency.of('EUR'), Decimal('1'), Date.today())
    assert U1.with_qty(Decimal('2')) == SomePrice(Currency.of('EUR'), Decimal('2'), Date.today())
    assert U1.with_qty(Decimal('1')) == SomePrice(Currency.of('EUR'), Decimal('1'), Date.today())
    assert U1.with_qty(Decimal('-1')) == SomePrice(Currency.of('EUR'), Decimal('-1'), Date.today())


# Generated at 2022-06-24 01:26:49.705968
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    """
    Unit test for method scalar_subtract of class SomePrice
    """
    print("\nTest scalar_subtract method of SomePrice")
    theprice = SomePrice(USDCurrency, Decimal(100), Date(2019, 12, 31))
    theprice2 = theprice.scalar_subtract(10)
    assert theprice2.qty == Decimal(90)



# Generated at 2022-06-24 01:26:54.567064
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    price = Price(USD, Decimal(10), Date(2014, 12, 1))
    price_trunc = Decimal(10) / Decimal(3)
    price_floor = Decimal(10) // Decimal(3)
    assert price / 3 == Price(USD, price_trunc, Date(2014, 12, 1))
    assert price // 3 == Price(USD, price_floor, Date(2014, 12, 1))



# Generated at 2022-06-24 01:26:59.822783
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert Price.NA.with_ccy(EUR) == Price.NA
    assert SomePrice(GBP, Decimal('123.34'), Date(2019, 9, 5)).with_ccy(EUR) == SomePrice(EUR, Decimal('123.34'), Date(2019, 9, 5))


# Generated at 2022-06-24 01:27:05.559743
# Unit test for method __float__ of class Money
def test_Money___float__():
    from .monetary import NoneMoney, SomeMoney

    money = NoneMoney
    assert money.__float__() == 0.0

    money = SomeMoney(Currency('EUR'), 0.0, Date(2018, 7, 31))
    assert money.__float__() == 0.0



# Generated at 2022-06-24 01:27:08.969988
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    assert Price.of(USD, Decimal("1.0"), today()) / Decimal("1.0") == Price.of(USD, 1, today())

# Generated at 2022-06-24 01:27:10.497654
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoMoney



# Generated at 2022-06-24 01:27:13.431908
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    expected = NoPrice
    actual = (Price() >= Price())
    assert actual == expected, "Test code is broken"


# Test for method __ge__ of class Price

# Generated at 2022-06-24 01:27:22.072114
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(USD, Decimal("10"), today) * Decimal("0.5") == Price.of(USD, Decimal("5"), today)
    assert Decimal("0.5") * Price.of(USD, Decimal("10"), today) == Price.of(USD, Decimal("5"), today)
    assert Price.of(USD, Decimal("10"), today) * 2 == Price.of(USD, Decimal("20"), today)
    assert 2 * Price.of(USD, Decimal("10"), today) == Price.of(USD, Decimal("20"), today)
    assert Price.of(USD, Decimal("10"), today) * 2.0 == Price.of(USD, Decimal("20"), today)

# Generated at 2022-06-24 01:27:25.187901
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    x = NonePrice.with_ccy(Currency("EUR"))
    y = NonePrice.with_ccy(Currency("HKD"))
    assert x == y
assert y == x


# Generated at 2022-06-24 01:27:36.879345
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    from numbers import Number
    from datetime import date
    from money import Money
    from money import Price
    USD = Money.usd
    EUR = Money.eur
    GBP = Money.gbp
    CHF = Money.chf
    JPY = Money.jpy
    date = date(year=2018, month=6, day=12)
    assert (isinstance(NoMoney(0,0,0), Money)) == True
    assert (isinstance(NoMoney(0,0,0), Price)) == True
    assert (isinstance(NoMoney(0,0,0).__abs__(), Money)) == True
    assert (isinstance(NoMoney(0,0,0).__abs__(), Price)) == True
    assert (NoMoney(0,0,0).__abs__()) == NoMoney(0,0,0)

# Generated at 2022-06-24 01:27:44.197471
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of("USD", Decimal("123.45"), Date("1995-02-24")).as_integer() == 123

    with pytest.raises(MonetaryOperationException):
        Price.NA.as_integer()



# Generated at 2022-06-24 01:27:45.542198
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert isinstance(NoPrice.__int__(), int)


# Generated at 2022-06-24 01:27:52.935029
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    def dov_lt(a: Date, b: Date) -> bool:
        return a < b

    from dateutil.relativedelta import relativedelta
    assert dov_lt(Date.now() + relativedelta(days=-1), Date.now())
    assert not dov_lt(Date.now() + relativedelta(days=-1), Date.now() + relativedelta(days=-1))
    assert not dov_lt(Date.now(), Date.now() + relativedelta(days=-1))

    def someprice_lt(a: "SomePrice", b: "SomePrice") -> bool:
        return (a.qty, a.dov) < (b.qty, b.dov)

    from .money import CAD, USD
    from .fx import FXRateService

    fx1 = FXRate

# Generated at 2022-06-24 01:28:04.937322
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    """
    Tests the :meth:`~SomeMoney.with_qty` method.
    """
    assert SomeMoney(USD, "1.50", TODAY) == SomeMoney(USD, "1.50", TODAY).with_qty("1.50")
    assert SomeMoney(USD, "1.50", TODAY).with_qty("2.50") != SomeMoney(USD, "1.50", TODAY)
    assert SomeMoney(USD, "1.50", TODAY).with_qty("1.50") == SomeMoney(USD, "1.50", TODAY)
    assert SomeMoney(USD, "1.50", TODAY).with_qty("1.501") != SomeMoney(USD, "1.50", TODAY)
    assert SomeMoney(USD, "1.50", TODAY).with_qty("1.500") == Some

# Generated at 2022-06-24 01:28:11.248801
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Unit test for method __add__ of class NoneMoney
    """
    cls = NoneMoney
    # Default case:
    def1 = lambda : cls()
    def2 = lambda : cls()
    exp1 = def1()
    act1 = def1() + def2()
    assert exp1 is act1

# Generated at 2022-06-24 01:28:15.308932
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    assert SomePrice(USD, Decimal("2"), Date("2019-12-25")).with_qty(Decimal("3")) == SomePrice(USD, Decimal("3"), Date("2019-12-25"))
    # Unit test for method convert of class SomePrice

# Generated at 2022-06-24 01:28:28.025221
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    # Test Case 1
    SM1 = SomeMoney(USD, 3, date(2018, 1, 1))
    SM2 = SomeMoney(USD, 2, date(2018, 1, 1))
    res = SM1 > SM2
    assert res == True

    # Test Case 2
    SM1 = SomeMoney(USD, 3, date(2018, 1, 1))
    SM2 = SomeMoney(USD, 3, date(2018, 1, 1))
    res = SM1 > SM2
    assert res == False

    # Test Case 3
    SM1 = SomeMoney(USD, 2, date(2018, 1, 1))
    SM2 = SomeMoney(USD, 3, date(2018, 1, 1))
    res = SM1 > SM2
    assert res == False


test_SomeMoney___gt__()


# Generated at 2022-06-24 01:28:30.871157
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert SomeMoney("USD", 100, Date.today()).as_float() == 100.0
    assert SomeMoney("USD", 100.0, Date.today()).as_float() == 100.0

    with raises(MonetaryOperationException):
        SomeMoney("USD", 10, Date.today()).as_float()

    with raises(MonetaryOperationException):
        assert NoMoney.as_float()
