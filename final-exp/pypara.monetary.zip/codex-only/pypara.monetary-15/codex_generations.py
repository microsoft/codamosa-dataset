

# Generated at 2022-06-24 01:18:33.107154
# Unit test for method round of class Money
def test_Money_round():
    assert Money.of(
        Currency.USD, Decimal("10.125"), Date.now()
    ).round(2) == Money.of(Currency.USD, Decimal("10.13"), Date.now())
    assert Money.of(
        Currency.USD, Decimal("10.125"), Date.now()
    ).round(2) == Money.of(Currency.USD, Decimal("10.13"), Date.now())

# Generated at 2022-06-24 01:18:39.330890
# Unit test for method __add__ of class Money
def test_Money___add__():
    """unit test for method __add__ of class Money"""
    # TODO: implement more tests
    assert (Money.of("EUR", Decimal("10"), date(
        2018, 1, 1)) + Money.of("EUR", Decimal("10"), date(2018, 1, 1))).is_equal(
            Money.of("EUR", Decimal("20"), date(2018, 1, 1)))
    assert Money(
        "EUR", Decimal("10"), date(2018, 1, 1)).__add__(
            Money("EUR", Decimal("10"), date(2018, 1, 1))) is NotImplemented


# Generated at 2022-06-24 01:18:47.427477
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    eur = Currency.of('EUR')
    usd = Currency.of('USD')
    qty = Decimal(1)
    price1 = Price.of(eur, qty, None)
    price2 = Price.of(usd, qty, None)
    price3 = price1.floor_divide(price2)
    assertEqual(price3.qty, Decimal(1))
    assertEqual(price3.ccy, eur)
    assertEqual(price3.dov, None)



# Generated at 2022-06-24 01:18:48.941235
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    with raises(TypeError):
        int(NoMoney)


# Generated at 2022-06-24 01:19:00.625305
# Unit test for method positive of class Price
def test_Price_positive():
    import dataclasses
    import math

    @dataclasses.dataclass(order=True, frozen=True)
    class Money:
        ccy: str
        qty: int

    @dataclasses.dataclass(order=True, frozen=True)
    class Price:
        ccy: str
        qty: int
        dov: datetime.date

    def abs(self):
        return Price(
            ccy=self.ccy, qty=int(math.fabs(self.qty)), dov=self.dov
        )

    def positive(self):
        return Price(
            ccy=self.ccy, qty=int(math.fabs(self.qty)), dov=self.dov
        )


# Generated at 2022-06-24 01:19:05.360217
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    """Unit test for method __neg__ of class SomePrice"""
    assert SomePrice( Currency('CZK'), Decimal('1.23'), Date('2020-12-12')).__neg__() == SomePrice( Currency('CZK'), Decimal('-1.23'), Date('2020-12-12'))

# Generated at 2022-06-24 01:19:11.180576
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    """
    Tests method with_ccy of class Price
    """
    from instruments import Money, Price, Currency, Date

    test_Price_with_ccy_inner("EUR", 10, "2020-01-01")
    test_Price_with_ccy_inner("EUR", 10, "2020-01-01")



# Generated at 2022-06-24 01:19:20.798611
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    price1 = Price.of(Currency.USD, Decimal("11.5"), Date.of(2020, 5, 10))
    price2 = Price.of(Currency.USD, Decimal("3"), Date.of(2020, 5, 10))
    assert price1.floor_divide(price2) == Price.of(Currency.USD, Decimal("3"), Date.of(2020, 5, 10))
    assert price1.floor_divide(price2.qty) == Price.of(Currency.USD, Decimal("3"), Date.of(2020, 5, 10))
    assert NoPrice.floor_divide(NoPrice) == NoPrice
    assert NoPrice.floor_divide(price1) == NoPrice
    assert price1.floor_divide(NoPrice) == NoPrice
    assert NoPrice.floor_

# Generated at 2022-06-24 01:19:25.248438
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    for ccy, qty, dov, expected in [
        ("EUR", Decimal("1"), today, "Price(ccy=EUR, qty=1, dov=%s)" % today),
    ]:
        assert expected == repr(Price(Currency(ccy), Decimal(qty), dov).with_dov(today))

# Generated at 2022-06-24 01:19:29.641050
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    assert Money.of(CCY, Decimal("0.10"), Date(year=2019, month=11, day=17)) - Money.of(
        CCY, Decimal("0.10"), Date(year=2019, month=11, day=17)
    ) == Money.of(CCY, Decimal("0.00"), Date(year=2019, month=11, day=17))
    assert Money.of(CCY, Decimal("0.10"), Date(year=2019, month=11, day=17)) - Money.of(
        CCY, Decimal("0.00"), Date(year=2019, month=11, day=17)
    ) == Money.of(CCY, Decimal("0.10"), Date(year=2019, month=11, day=17))


# Generated at 2022-06-24 01:19:38.233372
# Unit test for method __add__ of class Price
def test_Price___add__():
    expected_results = [
        NoPrice,
        SomePrice(ccy=USD, qty=Decimal("100"), dov=Date(2019, 1, 1)),
        SomePrice(ccy=USD, qty=Decimal("200"), dov=Date(2019, 1, 1)),
        SomePrice(ccy=USD, qty=Decimal("300"), dov=Date(2019, 1, 1)),
        SomePrice(ccy=USD, qty=Decimal("300"), dov=Date(2019, 1, 1)),
    ]

# Generated at 2022-06-24 01:19:48.178825
# Unit test for method positive of class Price
def test_Price_positive():
    assert Price.of(USD, Decimal(1), date(2018, 3, 22)).negative().positive() == Price.of(USD, Decimal(1), date(2018, 3, 22))
    assert Price.of(USD, Decimal(1), date(2018, 3, 22)).positive().positive() == Price.of(USD, Decimal(1), date(2018, 3, 22))
    assert Price.of(USD, Decimal(0), date(2018, 3, 22)).positive() == Price.of(USD, Decimal(0), date(2018, 3, 22))
    assert Price.of(USD, Decimal(1), date(2018, 3, 22)).positive() == Price.of(USD, Decimal(1), date(2018, 3, 22))

# Generated at 2022-06-24 01:19:51.100220
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    usd = Currency("USD")
    my_money = NoneMoney
    my_money_usd = my_money.with_ccy(usd)
    assert my_money_usd.defined is False
    assert my_money_usd.undefined is True
    return True

# Generated at 2022-06-24 01:19:57.458324
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    """
    Unit test for method ``__float__ of class NoneMoney
    """
    from dolmen.money import SomeMoney
    from dolmen.money import NoneMoney
    from dolmen.money import NoMoney
    ## Test call to NoneMoney.__float__.
    assert isinstance(NoneMoney.__float__(NoneMoney()), float)
    with raises(TypeError):
        NoneMoney.__float__(NoMoney)
    ## Test call to SomeMoney.__float__.
    assert SomeMoney.__float__(SomeMoney(amount=Decimal('5.5'), currency='EUR')) == 5.5
    assert SomeMoney.__float__(SomeMoney(amount=Decimal('1.5'), currency='EUR')) == 1.5

# Generated at 2022-06-24 01:20:04.812306
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    assert NonePrice() - NonePrice() == NonePrice()
    assert NonePrice() - SomePrice(Currency.get_or_create("EUR"), Decimal(10), Date(2018, 12, 31)) == NonePrice()
    assert SomePrice(Currency.get_or_create("EUR"), Decimal(10), Date(2018, 12, 31)) - NonePrice() == NonePrice()
    assert NonePrice() - 1234 == NonePrice()
    assert 1234 - NonePrice() == NonePrice()

# Generated at 2022-06-24 01:20:07.182362
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    n1 = NoMoney
    n2 = NoMoney
    assert (n1 < n2), "NoMoney is not LT NoMoney"


# Generated at 2022-06-24 01:20:11.708029
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    from .currencies import USD
    from .money import Money, SomeMoney
    m = Money.of(USD, 10, None)
    m_pos = +m
    assert isinstance(m_pos, Money)
    assert m == m_pos

# Generated at 2022-06-24 01:20:18.792880
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    # Method: __floordiv__
    # Description: Divides a quantity by a scalar and returns a new quantity
    # Test case: Defining an instance of NonePrice, then divide by a scalar
    # Expectation: The NonePrice instance should be returned.

    
    # Create an instance of NonePrice
    x = NonePrice()

    # Create a scalar value
    y = 2

    # Divide
    z = x // y

    # Make sure we have NonePrice instance
    assert isinstance(z, NonePrice)



# Generated at 2022-06-24 01:20:29.454444
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    assert SomePrice(USD, Decimal(1.23), Date(2019, 8, 16)).round() == SomePrice(USD, Decimal(1), Date(2019, 8, 16))
    assert SomePrice(USD, Decimal(1.25), Date(2019, 8, 16)).round() == SomePrice(USD, Decimal(1), Date(2019, 8, 16))
    assert SomePrice(USD, Decimal(1.5), Date(2019, 8, 16)).round() == SomePrice(USD, Decimal(2), Date(2019, 8, 16))
    assert SomePrice(USD, Decimal(1.51), Date(2019, 8, 16)).round() == SomePrice(USD, Decimal(2), Date(2019, 8, 16))
    assert SomePrice(USD, Decimal(1.51), Date(2019, 8, 16)).round

# Generated at 2022-06-24 01:20:30.808383
# Unit test for method __le__ of class Money
def test_Money___le__():

    assert(True)

# Generated at 2022-06-24 01:20:39.035317
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    new_ccy = Currency('USD')
    new_qty = Decimal('0.7')
    new_dov = Date('2017-09-01')
    price = SomePrice(new_ccy, new_qty, new_dov)
    actual = price.with_ccy(new_ccy)
    assert actual.ccy == new_ccy
    assert actual.qty == new_qty
    assert actual.dov == new_dov
    assert actual == price


# Generated at 2022-06-24 01:20:44.888490
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert SomePrice(USD, Decimal("1234.56"), DD_MMM_YY) < SomePrice(USD, Decimal("1234.57"), DD_MMM_YY), "Check <"
    assert SomePrice(USD, Decimal("1234"), DD_MMM_YY) < SomePrice(USD, Decimal("1234.56"), DD_MMM_YY), "Check <"
    assert SomePrice(USD, Decimal("1234"), DD_MMM_YY) < SomePrice(EUR, Decimal("1234.56"), DD_MMM_YY), "Check <"

# Generated at 2022-06-24 01:20:48.657191
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    import datetime
    from .currency import Currency
    from .money import SomeMoney
    from .date import Date

    ccy = Currency("ABC")

    try:
        SomeMoney(ccy, Decimal('1'), Date.today()) < SomeMoney(ccy, Decimal('2'), Date.today())
    except NotImplementedError:
        assert False, "Should not throw exception"
    else:
        assert True



# Generated at 2022-06-24 01:20:51.441758
# Unit test for method __int__ of class Price
def test_Price___int__():
    a = Price.of(EUR, 10, Date.today())
    b = int(a)
    assert b == 10



# Generated at 2022-06-24 01:21:02.371594
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    from analyzer.money import Money
    from datetime import date
    from pyassert import assert_that
    from tests import money
    from tests.money import EUR, USD
    from tests.price import PRICES
    from typing import Any

    ## Undefined money is always less than any other money object:
    assert_that(money.UNDEFINED.__gt__(money.UNDEFINED)).is_false()
    assert_that(money.UNDEFINED.__gt__(money.EUR_ZERO)).is_false()
    assert_that(money.UNDEFINED.__gt__(money.EUR_ONE)).is_false()
    assert_that(money.UNDEFINED.__gt__(money.EUR_TWO)).is_false()

# Generated at 2022-06-24 01:21:04.241849
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    _: float = float(NoPrice)
    with raises(TypeError):
        _ = NoPrice.__float__()

# Generated at 2022-06-24 01:21:11.625838
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert float(Money.of(GBP, Decimal(1.234), Date.today()).price) == 1.234
    assert float(Money.of(EUR, Decimal(1.234), Date.today()).price) == 1.234
    assert float(Money.of(USD, Decimal(1.234), Date.today()).price) == 1.234
    with raises(TypeError):
        Money.of(GBP, Decimal(1.234), Date.today()).price.__float__()
    with raises(TypeError):
        Money.of(EUR, Decimal(1.234), Date.today()).price.__float__()
    with raises(TypeError):
        Money.of(USD, Decimal(1.234), Date.today()).price.__float__()

# Generated at 2022-06-24 01:21:12.943638
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():

    nl = NonePrice()

    assert type(nl) is NonePrice

    assert nl.__pos__() is nl


# Generated at 2022-06-24 01:21:19.019810
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from .currencies import USD

    dov: Date = Date(date(2010, 1, 1))
    m1: Money = USD.of(100)
    m2: Money = m1.with_dov(dov)
    assert m2 is not m1
    assert m1.dov == Date(date(1900, 1, 1))
    assert m2.dov == dov
    assert m1.qty == Decimal("100")
    assert m2.qty == Decimal("100")

# Generated at 2022-06-24 01:21:24.513768
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    from .currency import CCY
    from .date import Date
    from .money import Money, NoMoney

    ccy = CCY.of("USD")
    qty = Decimal("10.0")
    dov = Date(year=2020, month=2, day=25)

    money1: Money = SomeMoney(ccy, qty, dov)
    money2: Money = NoMoney

    assert (money1 * 5) == SomeMoney(ccy, Decimal("50.0"), dov)
    assert (money1 * 5.0) == SomeMoney(ccy, Decimal("50.0"), dov)
    assert (5.0 * money1) == SomeMoney(ccy, Decimal("50.0"), dov)

    assert (money1 * money2) == NoMoney

# Generated at 2022-06-24 01:21:35.902989
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    import pytest
    from datetime import date
    from gordo_components.data_provider.sensor_tag import SensorTag
    from gordo_components.data_provider.sensor_tag_list import TagList
    from gordo_components.data_provider import DataProvider
    from gordo_components.dataset.sensor_tag import NormalizedTag, Tag
    from gordo_components.dataset.dataset import GordoBaseDataset
    from gordo_components.dataset.datasets import TimeSeriesDataset
    from gordo_components.dataset.data_index import DataIndex
    from gordo_components.data_provider.providers.data_provider import _IProvider

# Generated at 2022-06-24 01:21:41.467361
# Unit test for method __int__ of class Money
def test_Money___int__():
    _qty_ = Decimal("0.00")
    _ccy_ = Currency.get("USD")
    _dov_ = Date.today()
    _instance_ = SomeMoney(_ccy_, _qty_, _dov_)
    result = _instance_.__int__()
    assert result == int(_qty_)

# Generated at 2022-06-24 01:21:47.517797
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    """
    Tests method __lt__ of class NonePrice
    """
    some = SomePrice(
        Currency(
            'US DOLLAR',
            'USD',
            '840',
            '2',
            ('$',),
            ('US$',),
            ('US Dollar',),
            ('US Dollars',),
            ('Dollar',),
            ('Dollars',),
            ('Cents',),
            ('Cent',)
        ),
        Decimal('1.00'),
        Date(2020, 9, 24)
    )
    none = NonePrice()
    assert (not none < some)
    assert (not none <= some)
    assert (not none > some)
    assert none <= some
    assert none == none
    assert some == some



# Generated at 2022-06-24 01:21:58.523434
# Unit test for constructor of class Money
def test_Money():
    ClassMoney = Money
    ClassMoney.NA
    ClassMoney.NA.ccy
    ClassMoney.NA.qty
    ClassMoney.NA.dov
    ClassMoney.NA.defined
    ClassMoney.NA.undefined
    ClassMoney.NA.is_equal(Money)
    ClassMoney.NA.as_boolean()
    ClassMoney.NA.as_float()
    ClassMoney.NA.as_integer()
    ClassMoney.NA.abs()
    ClassMoney.NA.negative()
    ClassMoney.NA.positive()
    ClassMoney.NA.round()
    ClassMoney.NA.add(Money)
    ClassMoney.NA.scalar_add(Money)
    ClassMoney.NA.subtract(Money)
    ClassMoney.NA.scalar_subtract(Money)

# Generated at 2022-06-24 01:22:00.210159
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    """
    Tests to ensure that the method __int__ behaves correctly.
    """
    ## Test known cases:
    ## Nothing to test here.

    ## Check:
    return True


# Generated at 2022-06-24 01:22:01.918080
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    NoMoney._with_dov(datetime.date(2018, 3, 9))

# Generated at 2022-06-24 01:22:06.620887
# Unit test for method __add__ of class Price
def test_Price___add__():
    pass


# Generated at 2022-06-24 01:22:18.383872
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    """
    This function provides some basic tests for the Exception class MonetaryOperationException.
    """

    def test_instance_creation():
        """
        This function tests the creation of new instances.
        """

        # Create instance with default message
        msg = MonetaryOperationException()
        assert isinstance(msg, MonetaryOperationException)

        # Create instance with specific message
        msg = MonetaryOperationException("The amount must be positive!")
        assert isinstance(msg, MonetaryOperationException)
        assert msg.args[0] == "The amount must be positive!"

    def test_instance_formatting():
        """
        This function tests the formatting of new instances.
        """

        # Create instance with default message and check its format
        msg = MonetaryOperationException()
        assert isinstance(msg, MonetaryOperationException)

# Generated at 2022-06-24 01:22:31.210000
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import USD
    from .exchange import FXRateService, FXRateLookupError
    from .money import Money, Price

    class DummyFXRateService(FXRateService):
        def lookup(self, asof: Date, ccy1: Currency, ccy2: Currency) -> Price:
            if ccy1.code == 'USD' and ccy2.code == 'TRY':
                return Price(USD, 1, 1)
            else:
                raise FXRateLookupError(ccy1, ccy2, 'test')

    fx = DummyFXRateService()


# Generated at 2022-06-24 01:22:33.545108
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    assert NoneMoney / 1 == NoneMoney
    assert NoneMoney / "1.1" == NoneMoney
    assert NoneMoney / 1.1 == NoneMoney


# Generated at 2022-06-24 01:22:45.584386
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    brl = Currency.get_currency_by_code("BRL")

    # __pos__ of a non-negative amount
    candidate = Money.of(brl, Decimal(1), Date.today())
    result = +candidate
    expected = Money.of(brl, Decimal(1), Date.today())
    assert result == expected

    # __pos__ of a non-positive amount
    candidate = Money.of(brl, Decimal(-1), Date.today())
    result = +candidate
    expected = Money.of(brl, Decimal(-1), Date.today())
    assert result == expected

    # __pos__ of a NoneMoney
    candidate = NoneMoney
    result = +candidate
    expected = NoneMoney
    assert result == expected



# Generated at 2022-06-24 01:22:46.744079
# Unit test for method divide of class Price
def test_Price_divide():
    pass


# Generated at 2022-06-24 01:22:53.474752
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    ccy = Currency('ZAR')
    price = SomePrice(Currency('USD'), 100, datetime.date(2019, 1, 1))
    actual = price.with_ccy(ccy)
    assert actual.ccy is ccy
    assert actual.dov == price.dov
    assert actual.qty == price.qty



# Generated at 2022-06-24 01:22:58.988593
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    price1 = Price.of(ZAR, Decimal("123.45"), Date(2018, 11, 15))
    result = price1.as_integer()
    assert result == 123
    price2 = NoPrice
    result = price2.as_integer()
    assert result == 0

# Generated at 2022-06-24 01:23:06.298801
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(Currency.USD, 1, Date.today()) == Price.of(Currency.USD, 1, Date.today()).times(1)
    assert Price.of(Currency.USD, 10, Date.today()) == Price.of(Currency.USD, 1, Date.today()).times(10)
    assert Price.of(Currency.USD, 0, Date.today()) == Price.of(Currency.USD, 1, Date.today()).times(0)
    assert NoPrice == Price.of(Currency.USD, 1, Date.today()).times(None)

# Generated at 2022-06-24 01:23:08.968711
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert SomePrice(USD, 12, Date.now()).as_integer() == 12
    assert NoPrice.as_integer() == 0

# Generated at 2022-06-24 01:23:20.120608
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    print('Testing method with_ccy of class Price')
    print()

    #
    # Create a price object and use it in with_ccy method
    #

    currency = Currency.of('SEK')
    quantity = Decimal('100')
    date = Date.of(2014, Month.FEBRUARY, 12)
    price = SomePrice(currency, quantity, date)

    print('Input price: ' + str(price))
    print()

    # Create a new currency object to use in with_ccy method
    drachma = Currency.of('GRD')

    # Use with_ccy method on the input price object
    price2 = price.with_ccy(drachma)

    # Print method output
    print('Method output: ' + str(price2))
    print()

    #
    # Use with

# Generated at 2022-06-24 01:23:31.807718
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    from .currencies import Currency

    from .money import Money


    assert Money.of(Currency.USD, 10, "2023-01-01").__neg__().is_equal(Money.of(
        Currency.USD, -10, "2023-01-01")
    )

    assert Money.of(Currency.USD, 10, "2023-01-01").__neg__().__neg__().is_equal(Money.of(
        Currency.USD, 10, "2023-01-01")
    )

    assert Money.of(Currency.USD, 10, "2023-01-01").positive().is_equal(Money.of(
        Currency.USD, 10, "2023-01-01")
    )


# Generated at 2022-06-24 01:23:38.279291
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    assert NoPrice <= NoPrice
    assert NoPrice <= SomePrice(EUR, Decimal("1"), today)
    assert SomePrice(EUR, Decimal("1"), today) <= SomePrice(EUR, Decimal("1"), today)
    assert SomePrice(EUR, Decimal("1"), today) <= SomePrice(EUR, Decimal("2"), today)

    with raises(IncompatibleCurrencyError):
        assert SomePrice(EUR, Decimal("1"), today) <= SomePrice(USD, Decimal("1"), today)



# Generated at 2022-06-24 01:23:43.356281
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    ccy = Currency.get("USD")
    qty = Decimal("123")
    dov = Date.today()
    p = SomePrice(ccy, qty, dov)
    assert p.__int__() == 123

# Generated at 2022-06-24 01:23:52.307025
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from financepy.finutils.FinDate import FinDate
    from financepy.markets.curves.FinDiscountCurveFlat import FinDiscountCurveFlat
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.finutils.FinGlobalTypes import FinSwapTypes
    from financepy.models.FinModelRatesHW import FinModelRatesHW
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import FinIborFuture

# Generated at 2022-06-24 01:23:53.184550
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    assert (not NoPrice == SomePrice(EUR, Decimal("42"), Date.today()))

# Generated at 2022-06-24 01:23:55.565759
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    assert 1 == NoPrice * 1

# Generated at 2022-06-24 01:24:08.319893
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price(10, Currency("USD"), Date("2021-06-10")).multiply(10) == Price(100, Currency("USD"), Date("2021-06-10"))
    assert Price("10.23", Currency("USD"), Date("2021-06-10")).multiply("9.23") == Price("94.6429", Currency("USD"), Date("2021-06-10"))
    assert Price("10.23", Currency("USD"), Date("2021-06-10")).multiply("9.00") == Price("92.07", Currency("USD"), Date("2021-06-10"))
    assert Price("10.23", Currency("USD"), Date("2021-06-10")).multiply("9") == Price("92.07", Currency("USD"), Date("2021-06-10"))

# Generated at 2022-06-24 01:24:10.587705
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    assert SomePrice('USD', 0, None).scalar_subtract(2) == NoPrice


# Generated at 2022-06-24 01:24:15.942857
# Unit test for method divide of class Price
def test_Price_divide():
    # Test for division by zero
    assert ((SomeMoney(Currency.USD, Decimal(100), Date(2020, 1, 1))/0) == NoMoney)

    # Test for division by a number
    assert(((SomeMoney(Currency.USD,Decimal(100), Date(2020,1,1))/2) == SomeMoney(Currency.USD,Decimal(50), Date(2020,1,1))))


# Generated at 2022-06-24 01:24:21.900796
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert NoPrice.is_equal(SomePrice(CURRENCY_USD, Decimal(1.0), DATE_1)) == False
    assert SomePrice(CURRENCY_USD, Decimal(1.0), DATE_1).is_equal(SomePrice(CURRENCY_USD, Decimal(1.0), DATE_1)) == True
    assert SomePrice(CURRENCY_USD, Decimal(1.0), DATE_1).is_equal(SomePrice(CURRENCY_USD, Decimal(1.0), DATE_2)) == False
    assert SomePrice(CURRENCY_USD, Decimal(1.0), DATE_1).is_equal(SomePrice(CURRENCY_USD, Decimal(2.0), DATE_1)) == False

# Generated at 2022-06-24 01:24:24.106709
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    new_Price = Price()
    new_Price.__ge__()

# Generated at 2022-06-24 01:24:30.615673
# Unit test for method __add__ of class Money
def test_Money___add__():
    from .currencies import Currency
    from .money import Money

    m1 = Money.of(Currency.USD, 1, Date.today())
    m2 = Money.of(Currency.EUR, 2, Date.today())
    m = m1 + m2
    assert m.eq(m1.add(m2))


# Generated at 2022-06-24 01:24:33.338123
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    """Unit test for method__eq__ of class SomePrice."""
    pass



# Generated at 2022-06-24 01:24:41.496477
# Unit test for method round of class Price
def test_Price_round():
    price: Price = Price.of(USD, 123.456789, dt.date(2020, 1, 1))
    assert price.round() == Price.of(USD, 123, dt.date(2020, 1, 1))
    assert price.round(1) == Price.of(USD, 123.5, dt.date(2020, 1, 1))
    assert price.round(2) == Price.of(USD, 123.46, dt.date(2020, 1, 1))



# Generated at 2022-06-24 01:24:45.394500
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert (
            SomeMoney(
                Currency("USD"), Decimal("1.5"), Date.today()
            ) == SomeMoney(
                Currency("USD"), Decimal("1.5"), Date.today()
            )
    ) is True

# Generated at 2022-06-24 01:24:53.913010
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    from .currencies import Currency
    from .dates import Date
    from .money import Money
    m_1 = Money(ccy=Currency.DKK(), qty=100, dov=Date.today())
    assert m_1.__floordiv__(1) == m_1
    assert m_1.__floordiv__(2) == m_1.with_qty(50)
    assert m_1.__floordiv__(100) == m_1.with_qty(1)
    assert m_1.__floordiv__(1000) == m_1.with_qty(0.1)



# Generated at 2022-06-24 01:24:56.038752
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    assert SomePrice(GBP("100.00"), GBP("100.00"), now()) == SomePrice(GBP("100.00"), GBP("100.00"), now())


# Generated at 2022-06-24 01:24:57.622721
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(USD, Decimal("1"), Date(2019, 1, 1)) > SomePrice(USD, Decimal("0"), Date(2019, 1, 1))



# Generated at 2022-06-24 01:25:05.047284
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    assert NonePrice() + NonePrice() == NonePrice()
    assert NonePrice() + Price(Currency("GBP"), 1, Date()) == Price(Currency("GBP"), 1, Date())
    assert Price(Currency("GBP"), 1, Date()) + NonePrice() == Price(Currency("GBP"), 1, Date())

# Generated at 2022-06-24 01:25:09.395099
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    Price.of(None, None, None) + Price.of(None, None, None)


# Generated at 2022-06-24 01:25:12.114459
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    assert NonePrice() // Decimal("1") == NonePrice()

# Generated at 2022-06-24 01:25:19.028786
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    A = SomeMoney(USD, 125, 0)
    B = SomeMoney(USD, 0, 0)
    C = NoneMoney()
    assert A / 2 == SomeMoney(USD, 62.5, 0)
    assert 2 / A == NoMoney
    assert B / 2 == SomeMoney(USD, 0, 0)
    assert 2 / B == NoMoney
    assert C / 2 == NoMoney
    assert 2 / C == NoMoney
    assert A / B == NoMoney
    assert A / C == NoMoney
    assert B / C == NoMoney


# Generated at 2022-06-24 01:25:24.096557
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    try:
        raise MonetaryOperationException(msg="test message", some_field_for_debug="some_value")
    except MonetaryOperationException as ex:
        assert ex.args == ('test message',)
        assert ex.some_field_for_debug == "some_value"
    else:
        assert False, "Failure to raise an error."



# Generated at 2022-06-24 01:25:29.270435
# Unit test for method subtract of class Money
def test_Money_subtract():
    assert Money.of(Currency("EUR"), Decimal("100.00"), Date("2018-01-02")) - Money.of(Currency("EUR"), Decimal("100.00"), Date("2018-01-02")) == SomeMoney(Currency("EUR"), Decimal("0.00"), Date("2018-01-02"))



# Generated at 2022-06-24 01:25:36.207587
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    arg = Price.of(ccy=Currency("USD"), qty=Decimal("1"), dov=Date(2019, 10, 18))
    expected = Price.of(ccy=Currency("XAU"), qty=Decimal("0.0001"), dov=Date(2019, 10, 18))

    assert arg.convert(to=Currency("XAU"), asof=Date(2019, 10, 18)) == expected
    assert arg.convert(to=Currency("XAU"), asof=Date(2019, 10, 18), strict=False) == expected


# Generated at 2022-06-24 01:25:42.878169
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
 
    # Given the money object A
    A = SomeMoney(USD, Decimal("100.00"), date(2020, 1, 1))

    # And another money object B
    B = SomeMoney(USD, Decimal("100.00"), date(2020, 1, 1))

    # When we add them together
    C = A + B

    # Then it should be equal to the sum
    assert C == SomeMoney(USD, Decimal("200.00"), date(2020, 1, 1))


# Generated at 2022-06-24 01:25:47.084873
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    test = NonePrice()
    assert type(test.times(2)) is NoMoney

# Generated at 2022-06-24 01:25:56.944820
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    c1 = Currency.of("GBP")
    c2 = Currency.of("EUR")
    c3 = Currency.of("USD")
    sp1 = SomePrice(c1, Decimal("0.003400"), Date(2019, 3, 12))
    sp2 = SomePrice(c2, Decimal("0.003400"), Date(2019, 3, 12))
    sp3 = SomePrice(c3, Decimal("0.003400"), Date(2019, 3, 12))
    sp4 = SomePrice(c1, Decimal("0.003400"), Date(2019, 3, 12)).round()
    sp5 = SomePrice(c2, Decimal("0.003400"), Date(2019, 3, 12)).round()

# Generated at 2022-06-24 01:26:04.221831
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    c = Currency(code = "USD")
    q2 = Decimal(2)
    q3 = Decimal(3)
    d = Date(year=2020,month=2,day=12)
    sp = SomePrice(c,q2,d)
    sp2 = sp.with_qty(q3)
    assert sp2.qty is q3

# Generated at 2022-06-24 01:26:07.452056
# Unit test for method negative of class Price
def test_Price_negative():
    price_instance = Price.of(ccy=None, qty=None, dov=None)
    res = price_instance.negative()
    assert res is None



# Generated at 2022-06-24 01:26:15.943166
# Unit test for method subtract of class Money
def test_Money_subtract():
    """ Tests the functionality of subtract method of the class Money"""
    from .currencies import Currencies
    from .time.clock import Clock

    assert NoMoney.subtract(NoMoney) == NoMoney
    assert NoMoney.subtract(SomeMoney(Currencies.USD, Decimal(10), Clock.now())) == NoMoney
    assert SomeMoney(Currencies.INR, Decimal(10), Clock.now()).subtract(NoMoney) == NoMoney


    assert SomeMoney(Currencies.INR, Decimal(10), Clock.now()).subtract(
        SomeMoney(Currencies.INR, Decimal(10), Clock.now())) == SomeMoney(Currencies.INR, Decimal(0), Clock.now())

# Generated at 2022-06-24 01:26:26.171002
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    from .amount import Amount
    from .currency import Currency
    from .money import Money
    from .price import NoPrice, SomePrice, Price
    TESTDATA = [
        (
            {'args': (), 'ccy': Currency('EUR'), 'qty': Decimal('1.0000'), 'dov': date(2019, 2, 12)},
            SomePrice(
                Currency('EUR'),
                Decimal('-1.0000'),
                date(2019, 2, 12),
            ),
        ),
    ] # type: List[Tuple[Tuple[Any, ...], SomePrice]]
    for args, expected in TESTDATA:
        # Unpack args:
        arg, = args
        # Do the test:
        actual = -arg
        # Verify the result:

# Generated at 2022-06-24 01:26:36.643967
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    # ------------------------------------------------------------
    # Given
    # ------------------------------------------------------------
    ccy = Currency("USD")
    w = SomeMoney(ccy, Decimal("2.0"), "2021-01-01")
    # ------------------------------------------------------------
    # When
    # ------------------------------------------------------------
    x = w.scalar_subtract(Decimal("2.0"))
    y = w.scalar_subtract(2.0)
    z = w.scalar_subtract(2)
    # ------------------------------------------------------------
    # Then
    # ------------------------------------------------------------
    assert x[0] == y[0]
    assert y[0] == z[0]
    assert x[1] == y[1]
    assert y[1] == z[1]
    assert x[2] == y[2]

# Generated at 2022-06-24 01:26:43.940111
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    ccy: Currency
    qty: Decimal
    dov: Date
    ccy = Currency.from_string("USD")
    qty = Decimal(1)
    dov = TODAY
    x0 = SomePrice(ccy, qty, dov)
    x1 = x0.__neg__()
    assert (x1.ccy == ccy)
    assert (x1.qty == (qty.__neg__()))
    assert (x1.dov == dov)


# Generated at 2022-06-24 01:26:46.719203
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():

    price = SomePrice(ccy=USD, qty=Decimal("100.0"), dov=tomorrow)
    actual = price.__neg__()


# Generated at 2022-06-24 01:26:56.846632
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    class _Mock(Price):
        def __init__(self, ccy: Currency, qty: Decimal, dov: Date) -> None:
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

        @property
        def defined(self) -> bool:
            return True

        @property
        def undefined(self) -> bool:
            return False

        def is_equal(self, other: Any) -> bool:
            return False

        def as_boolean(self) -> bool:
            return False

        def as_float(self) -> float:
            return 0.0

        def as_integer(self) -> int:
            return 0

        def abs(self) -> Price:
            return self

        def negative(self) -> Price:
            return self



# Generated at 2022-06-24 01:27:01.750527
# Unit test for method __le__ of class Money
def test_Money___le__():
    """ Unit test for method __le__ of class Money """
    
    from .currencies import USD
    from .money import SomeMoney
    
    assert None <= None
    
    assert SomeMoney(USD, 0) <= 1
    assert SomeMoney(USD, 0) <= SomeMoney(USD, 1)
    assert not SomeMoney(USD, 1) <= SomeMoney(USD, 0)

# Generated at 2022-06-24 01:27:07.468176
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    p1 = Price.of(USD(), Decimal('10.0'), Date(2020, 1, 1))
    p2 = p1.floor_divide(Decimal('2'))
    assert p2.ccy == USD()
    assert p2.qty == Decimal('5.0')
    assert p2.dov == Date(2020, 1, 1)


# Generated at 2022-06-24 01:27:18.265507
# Unit test for method times of class Price
def test_Price_times():
    import money
    gbp = money.GBP
    EUR_USD_FX = money.FXRate.of(EUR, USD, Decimal("1.200"), TODAY)
    EUR_GBP_FX = money.FXRate.of(EUR, GBP, Decimal("0.890"), TODAY)
    FX_RATES.update(
        {
            (EUR, USD): EUR_USD_FX,
            (EUR, EUR): EUR_USD_FX,
            (EUR, GBP): EUR_GBP_FX,
        }
    )

    # times
    assert money.Price.of(GBP(2.25), EUR(1.1), TODAY).times(EUR(0.5)) == money.SomeMoney(GBP, Decimal('1.125'))

# Generated at 2022-06-24 01:27:23.345423
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert (SomePrice(USD, DEC_10, TODAY) == SomePrice(USD, DEC_10, TODAY)) is True
    assert (SomePrice(USD, DEC_10, TODAY) == SomePrice(USD, DEC_10, TODAY.add_days(1))) is False
    assert (SomePrice(USD, DEC_10, TODAY) == SomePrice(USD, DEC_10.add_prec(1), TODAY)) is False
    assert (SomePrice(USD, DEC_10, TODAY) == SomePrice(GBP, DEC_10, TODAY)) is False



# Generated at 2022-06-24 01:27:33.717680
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    from mymoneypy.money import EUR, \
        NoMoney, \
        Money
    from mymoneypy.price import NoPrice

    def test_main():
        test_NoMoney_USD_NoPrice()
        test_NoMoney_EUR_NoPrice()
        test_NoMoney_EUR_SomePrice_EUR_10_0()
        test_Money_1_EUR_NoPrice()
        test_Money_1_EUR_SomePrice_EUR_10_0()
        test_Money_1_EUR_SomePrice_EUR_10_0_USD_5_0()
        test_Money_1_EUR_SomePrice_EUR_0_0()

    def test_NoMoney_USD_NoPrice():
        a = NoMoney
        b = NoPrice
        c = a / b



# Generated at 2022-06-24 01:27:37.657266
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    from pytest import raises

    with raises(TypeError) as exc_info:
        result = (
            NonePrice.__times__(
                NoPrice,
                Decimal(1),
            )
        )
    assert str(exc_info.value) == "Undefined monetary values do not have quantity information."


# Generated at 2022-06-24 01:27:39.769476
# Unit test for method __int__ of class Money
def test_Money___int__():
    pass

# Generated at 2022-06-24 01:27:43.760095
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    assert (NoPrice.convert(Currency.USD) == NoPrice)


# Generated at 2022-06-24 01:27:53.320090
# Unit test for method lte of class Money
def test_Money_lte():
    m = Money.of(USD, Decimal('-123.45'), Date(2000, 1, 1))
    assert (m <= m)
    assert (m <= Money.of(USD, Decimal('-123.45'), Date(2000, 1, 1)))
    assert (m >= Money.of(USD, Decimal('-123.45'), Date(2000, 1, 1)))
    assert (m <= Money.of(USD, Decimal('-123.45'), Date(2000, 1, 1)))
    assert (m <= Money.of(USD, Decimal('-123.44'), Date(2000, 1, 1)))
    assert (m <= Money.of(USD, Decimal('-123.44'), Date(2000, 1, 1)))

# Generated at 2022-06-24 01:28:05.392203
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    # General test
    pt1=SomeMoney(Currency.from_symbol("EUR"), Decimal("100.000"), Date.from_string("2017-12-21"))
    pt2=SomeMoney(Currency.from_symbol("EUR"), Decimal("100.000"), Date.from_string("2017-12-21"))
    pt3=SomeMoney(Currency.from_symbol("EUR"), Decimal("99.000"), Date.from_string("2017-12-21"))
    pt4=SomeMoney(Currency.from_symbol("USD"), Decimal("100.000"), Date.from_string("2017-12-21"))
    assert pt1.__ge__(pt2) == True
    assert pt2.__ge__(pt3) == True

# Generated at 2022-06-24 01:28:06.981096
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    assert not NonePrice()



# Generated at 2022-06-24 01:28:17.870143
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    """Unit test for method ``__ge__`` of class ``NoneMoney``."""
    # Test case 1
    money1 = SomeMoney(GBP, Decimal("0"), TODAY)
    money2 = SomeMoney(GBP, Decimal("0"), TODAY)
    result = NoneMoney() >= money1
    assert result is True
    # Test case 2
    money1 = SomeMoney(GBP, Decimal("0"), TODAY)
    money2 = SomeMoney(GBP, Decimal("0"), TODAY)
    result = money1 >= NoneMoney()
    assert result is False
    # Test case 3
    money1 = SomeMoney(GBP, Decimal("0"), TODAY)
    money2 = SomeMoney(GBP, Decimal("0"), TODAY)
    result = NoneMoney() >= NoneMoney()
    assert result is True
    # Test case

# Generated at 2022-06-24 01:28:22.652467
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    from .currencies import USD

    assert USDCash(10.0, "USD", Date(2018, 11, 14)).floor_divide(USDCash(4.0, "USD", Date(2018, 11, 14))) == USDCash(2.0, "USD", Date(2018, 11, 14))

    assert USDCash(10.0, "USD", Date(2018, 11, 14)).floor_divide(USDCash(-4.0, "USD", Date(2018, 11, 14))) == USDCash(-3.0, "USD", Date(2018, 11, 14))


# Generated at 2022-06-24 01:28:30.020583
# Unit test for method round of class SomeMoney