

# Generated at 2022-06-24 01:18:36.677431
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    price1 = Money.of(Currency.USD, 10, date(2016, 4, 8))
    price2 = Money.of(Currency.USD, 10, date(2016, 5, 8))
    price3 = Money.of(Currency.EUR, 10, date(2016, 5, 8))
    assert NoPrice == -NoPrice
    assert -price1 == -price2 == Money.of(Currency.USD, -10, date(2016, 5, 8))
    assert (NoPrice == (price1 - price1) + price1 - price1)
    assert -NoMoney == NoMoney
    expect_failure(
        -price3, IncompatibleCurrencyError, property_name="currency"
    )  # fails because of incompatible currencies



# Generated at 2022-06-24 01:18:41.667545
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert NonePrice() < Price(10)
    assert not (NonePrice() < Price(0))
    assert not (NonePrice() < Price(None))
    assert NonePrice() < Price()



# Generated at 2022-06-24 01:18:54.360721
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    #
    # The price is greater than or equal to the other price
    #
    price_1 = SomePrice(ccy=USD, qty=1.0, dov=JUN_30_2020)
    price_2 = SomePrice(ccy=USD, qty=1.1, dov=JUN_30_2020)
    assert price_1.__ge__(price_2) == True

    #
    # The price is less than the other price
    #
    price_1 = SomePrice(ccy=USD, qty=1.0, dov=JUN_30_2020)
    price_2 = SomePrice(ccy=USD, qty=1.1, dov=JUN_30_2020)
    assert price_1.__ge__(price_2) == True

    #
   

# Generated at 2022-06-24 01:19:01.580902
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    assert Price.of(USD, 10, Date(2018, 10, 1)).scalar_subtract(10) == Price.of(USD, 0, Date(2018, 10, 1))
    assert Price.of(USD, 10, Date(2018, 10, 1)).scalar_subtract(1) == Price.of(USD, 9, Date(2018, 10, 1))
    assert Price.of(USD, 10, Date(2018, 10, 1)).scalar_subtract(Decimal(1.1)) == Price.of(USD, 8.9, Date(2018, 10, 1))
    assert Price.of(USD, 10, Date(2018, 10, 1)).scalar_subtract(-1) == Price.of(USD, 11, Date(2018, 10, 1))

# Generated at 2022-06-24 01:19:03.318637
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    # Test logic
    # Create aliases
    sm = NoMoney
    # Add a new case
    assert sm.scalar_subtract(10) == sm



# Generated at 2022-06-24 01:19:15.481876
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    assert SomeMoney(USD, D("0.01"), 20181201) <= SomeMoney(USD, D("0.01"), 20181201)
    assert SomeMoney(USD, D("0.01"), 20181201) <= SomeMoney(USD, D("0.02"), 20181201)
    assert SomeMoney(USD, D("0.01"), 20181202) <= SomeMoney(USD, D("0.01"), 20181201)
    assert SomeMoney(USD, D("-0.01"), 20181201) <= SomeMoney(USD, D("-0.01"), 20181201)
    assert SomeMoney(USD, D("-0.01"), 20181201) <= SomeMoney(USD, D("-0.02"), 20181201)

# Generated at 2022-06-24 01:19:16.725410
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    assert SomePrice(CAD, Decimal(10), Date(2019, 1, 1)).__int__() == 10


# Generated at 2022-06-24 01:19:21.528701
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    m = Money.of(USD, 1.404040404040404040404040404040404040404040404040404040404040404, Date(1971, 12, 14))
    assert m.round().qty == Decimal('1.4')
    assert m.round(2).qty == Decimal('1.4')
    assert m.round(3).qty == Decimal('1.404')


# Generated at 2022-06-24 01:19:22.452448
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    assert NonePrice() == NonePrice()

# Generated at 2022-06-24 01:19:26.080174
# Unit test for constructor of class NonePrice
def test_NonePrice():
    with pytest.raises(TypeError):
        NonePrice()


NonePrice = NonePrice()


NoPrice = NonePrice


__all__ = ("Price", "NoPrice", "SomePrice", "CurrencyPair", "PricingService", "PriceSource")

# Generated at 2022-06-24 01:19:31.239862
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    def _():
        m = SomeMoney(EUR, Decimal(1), Date.today())
        m.__truediv__(Decimal(1))
    ## Check that test passes:
    _()
    ## Check that test fails:
    with pytest.raises(ZeroDivisionError):
        _()

# Generated at 2022-06-24 01:19:32.725574
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    assert (NonePrice() > NonePrice()) is False


# Generated at 2022-06-24 01:19:37.222295
# Unit test for method gte of class Money
def test_Money_gte():

    str_test = StringIO()
    with redirect_stdout(str_test):
        Money.of(Currency.of("USD"), Decimal(0), Date.now()) >= SomeMoney(
            Currency.of("USD"), Decimal(0), Date.now())

    assert str_test.getvalue().strip() == 'True'

NoneMoney = None  # type: Optional[Money]
NoMoney = None  # type: Optional[Money]



# Generated at 2022-06-24 01:19:48.321986
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """Unit test for method ``__gt__`` of class ``SomeMoney``."""
    ## Define the type:
    T = TypeVar("T")
    ## Define class under test:
    CUT = SomeMoney
    ## Define the value:
    m1 = CUT(EUR, Decimal("+1000.00"), Date(2018, 1, 1))
    ## Define the list of (couple of) values and expected results:

# Generated at 2022-06-24 01:19:48.830231
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    ...

# Generated at 2022-06-24 01:19:50.931429
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():

    p = Price.of(USD, 100, Date.today())
    assert p.scalar_subtract(x) == Price.of(USD, 50, Date.today())



# Generated at 2022-06-24 01:19:55.607696
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert not NoPrice.__lt__(SomePrice('USD', qty=Decimal('2.00'), dov=Date(2017, 1, 1)))



# Generated at 2022-06-24 01:20:02.809471
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    try:
        NoneMoney().__int__()
    except TypeError as exc:
        assert (
            exc.args[0]
            == "Undefined monetary values do not have quantity information."
        ), "Wrong exception message for TypeError."
    else:
        assert False, "Did not raise TypeError"

# Generated at 2022-06-24 01:20:04.117432
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    assert NoMoney.__pos__() is NoMoney


# Generated at 2022-06-24 01:20:11.569950
# Unit test for method convert of class Money
def test_Money_convert():
    ConversionException = MonetaryOperationException
    # This section tests the method Money.convert
    c = Currency("TRY")
    c2 = Currency("USD")
    b = Price(c, Decimal("1.0"))
    a = Money(b, Decimal("100.0"))
    a2 = Money(b, Decimal("100.0"), date(2019, 12, 26))
    r = FXRate(c, c2, date(2019, 12, 26), Decimal("1.0"), Decimal("6.0"))
    r2 = FXRate(c, c2, date(2019, 12, 25), Decimal("1.0"), Decimal("5.0"))
    cache.push(r)
    cache.push(r2)
    # Test 1

# Generated at 2022-06-24 01:20:14.562803
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert (Price.of(USD, Decimal(3), today() + 2)).__neg__() == Price.of(USD, Decimal(-3), today() + 2)

# Generated at 2022-06-24 01:20:15.526768
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert False, "TODO"

# Generated at 2022-06-24 01:20:18.009005
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    m = Price.of(Currency.of("EUR"), Decimal("12.9"), Date.today())
    assert m.as_integer() == 12



# Generated at 2022-06-24 01:20:29.039741
# Unit test for method lt of class Money
def test_Money_lt():
    from .currencies import USD, EUR
    from .dates import TODAY
    from .money import Money
    from .exchange import NoFXRateService
    from .prices import Price

    m1 = Money.of(USD, Decimal('10.22'), TODAY)
    m2 = Money.of(EUR, Decimal('10.22'), TODAY)
    m3 = Money.of(USD, Decimal('10.22'), TODAY)
    m4 = Money.of(EUR, Decimal('0'), TODAY)
    m5 = Money.of(EUR, Decimal('10.22'), TODAY)
    m6 = Money.of(EUR, Decimal('0'), TODAY)

    print(m1)
    print(m2)
    print(m3)
    print(m4)
    print(m5)
   

# Generated at 2022-06-24 01:20:36.871161
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    """
    Tests the method `__mul__` of class `NoneMoney`
    """

    # Test definition:
    from xbbg.core.money import NoneMoney

    # Test cases:
    # xbbg.core.money.NoneMoney.__mul__
    assert NoneMoney().__mul__(10) == None
    assert NoneMoney().__mul__(10.0) == None

    # Return success:
    return True


# Generated at 2022-06-24 01:20:49.000327
# Unit test for constructor of class SomePrice
def test_SomePrice():
    with raises(TypeError, match="__init__\\(\\) takes 3 positional arguments but 4 were given"):
        SomePrice(Currency.USD, Decimal(1.1), Date.today(), Decimal(1.1))

    with raises(TypeError, match="Currency has to be a Currency, but got <class 'str'>:"):
        SomePrice('XXX', Decimal(1.1), Date.today())

    with raises(TypeError, match="Quantity has to be a Decimal, but got <class 'str'>:"):
        SomePrice(Currency.USD, 'XXX', Date.today())

    with raises(TypeError, match="Date of value has to be a Date, but got <class 'str'>:"):
        SomePrice(Currency.USD, Decimal(1.1), 'XXX')


# Generated at 2022-06-24 01:20:53.115403
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    price = Price.of("USD", Decimal("12.345"), Date.today())
    assert price.round() == Price.of("USD", Decimal("12"), Date.today())
    assert price.round(1) == Price.of("USD", Decimal("12.3"), Date.today())
    assert price.round(2) == Price.of("USD", Decimal("12.35"), Date.today())
    assert price.round(3) == Price.of("USD", Decimal("12.345"), Date.today())
    assert price.round(4) == Price.of("USD", Decimal("12.345"), Date.today())
    assert price.round(5) == Price.of("USD", Decimal("12.345"), Date.today())


# Generated at 2022-06-24 01:20:58.731286
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    from .currencies import USD, TRY

    assert (SomeMoney(USD, 1000, Date()) // 5) == SomeMoney(USD, 200, Date())
    assert (SomeMoney(TRY, 1000, Date()) // 5) == SomeMoney(TRY, 200, Date())

    assert (NoMoney // 5) == NoMoney
    assert (NoneMoney // 5) == NoneMoney

    assert (SomeMoney(USD, 1000, Date()) // 0) == NoMoney


# Generated at 2022-06-24 01:21:04.359827
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():

    from .. import Money, SomeMoney, NoneMoney

    m1 = Money(price=1, ccy="USD", dov=Date.today())
    m2 = m1.with_qty(100)

    assert m1.is_equal(m2)

# Generated at 2022-06-24 01:21:06.751230
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    from .date import Date
    from .currency import Currency
    from .money import Money, SomeMoney
    x = SomeMoney(Currency("USD"), Decimal("100.00"), Date(2015, 1, 1))
    assert x.__int__() == 100



# Generated at 2022-06-24 01:21:11.314676
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    lhs = NonePrice()
    rhs = SomePrice(None, None, None)
    if not(lhs < rhs):
        raise AssertionError


# Generated at 2022-06-24 01:21:12.948270
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    assert NoMoney.convert(Currency("EUR"), Date(2017, 1, 1), strict=False) is NoMoney

# Generated at 2022-06-24 01:21:15.190305
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    usd = Currency.of('USD')
    eur = Currency.of('EUR')
    date = Date.today()
    instance = Price.of(usd, 100.00, date)
    assert instance.with_ccy(eur).ccy == eur

# Generated at 2022-06-24 01:21:17.960970
# Unit test for method subtract of class Money
def test_Money_subtract():
    assert Money.of(Currency.of("USD"), Decimal("10"), Date.today()).subtract(
        Money.of(Currency.of("USD"), Decimal("10"), Date.today())) == Money.of(Currency.of("USD"), Decimal("0"), Date.today())


# Generated at 2022-06-24 01:21:23.669550
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    expected = bool(SomePrice(EUR, Decimal("1"), today))
    actual_1 = SomePrice(EUR, Decimal("1"), today).__bool__()
    actual_2 = bool(SomePrice(EUR, Decimal("1"), today))
    assert expected == actual_1 == actual_2

# Generated at 2022-06-24 01:21:32.303335
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.of(None, None, None).abs() == Price.of(None, None, None)
    assert Price.of(None, Decimal("0.0"), None).abs() == Price.of(None, Decimal("0.0"), None)
    assert Price.of(None, None, datetime.date(1970, 1, 1)).abs() == Price.of(None, None, datetime.date(1970, 1, 1))
    assert Price.of(Currency("TEST"), None, None).abs() == Price.of(Currency("TEST"), None, None)
    assert Price.of(Currency("TEST"), Decimal("0.0"), None).abs() == Price.of(Currency("TEST"), Decimal("0.0"), None)

# Generated at 2022-06-24 01:21:35.514108
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    """
    Unit test for method NoneMoney.__lt__ of class NoneMoney
    """

    assert (NoMoney < NoMoney) is False
    assert (NoMoney < SomeMoney(USD, Decimal("0.000"), Date.today())) is False
    assert (SomeMoney(USD, Decimal("0.000"), Date.today()) < NoMoney) is True



# Generated at 2022-06-24 01:21:36.680049
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():

    n = NoneMoney()
    assert n.with_ccy(None) is n

# Generated at 2022-06-24 01:21:46.489267
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():

    #   SomePrice(ccy = USD, qty = 0.005, dov = 2019-01-04) >= NoPrice
    assert (SomePrice( USD, Decimal("0.005"), Date("2019-01-04")) >= NoPrice)

    #   NoPrice >= SomePrice(ccy = USD, qty = 0.005, dov = 2019-01-04)
    assert (NoPrice >= SomePrice( USD, Decimal("0.005"), Date("2019-01-04")))

    #   SomePrice(ccy = USD, qty = 0.005, dov = 2019-01-04) >= SomePrice(ccy = USD, qty = 0.005, dov = 2019-01-04)

# Generated at 2022-06-24 01:21:52.026220
# Unit test for method round of class Price
def test_Price_round():
    p1 = Price.of('CHF', 1.1235)
    p2 = p1.round()
    assert p2 == Price.of('CHF', 1.12)
    p3 = p1.round(3)
    assert p3 == Price.of('CHF', 1.124)
    p4 = p1.round(4)
    assert p4 == Price.of('CHF', 1.1235)
    p5 = p1.round(5)
    assert p5 == Price.of('CHF', 1.1235)
    p6 = p1.round(6)
    assert p6 == Price.of('CHF', 1.1235)
    p7 = p1.round(7)
    assert p7 == Price.of('CHF', 1.1235)



# Generated at 2022-06-24 01:22:01.974285
# Unit test for method gt of class Price
def test_Price_gt():
    try:
        1.0 < some_price
    except IncompatibleCurrencyError:
        pass

    try:
        some_price < some_price
    except IncompatibleCurrencyError:
        pass

    try:
        1.0 < no_price
    except IncompatibleCurrencyError:
        pass

    try:
        no_price < no_price
    except IncompatibleCurrencyError:
        pass

    try:
        no_price < some_price
    except IncompatibleCurrencyError:
        pass


# Generated at 2022-06-24 01:22:06.971598
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    assert float(NoPrice) == 0.0

# Generated at 2022-06-24 01:22:16.543899
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    c1 = Currency.USD
    ccy = c1
    qty = Decimal(2)
    d1 = Date(2019, 1, 1)
    dov = d1
    p1 = Price.of(ccy, qty, dov)
    d2 = Date(2019, 2, 1)
    with_dov_result = p1.with_dov(d2)
    assert with_dov_result.ccy == c1
    assert with_dov_result.qty == Decimal(2)
    assert with_dov_result.dov == d2

# Generated at 2022-06-24 01:22:22.290705
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import Currency
    from .money import Money
    obj = Money.of(Currency.of("USD"), 100, Date.today())
    other = Money.of(Currency.of("USD"), 100, Date.today())
    assert (obj - other) == Money.of(Currency.of("USD"), 0, Date.today())



# Generated at 2022-06-24 01:22:28.542428
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    import pytest  # type: ignore
    from money import Money, NoMoney  # type: ignore
    from money.price import NonePrice  # type: ignore
    from money.currency import Currency  # type: ignore
    from money.money import SomeMoney  # type: ignore
    from decimal import Decimal  # type: ignore
    
    
    
    
    
    
    
    
    
    
    



# Generated at 2022-06-24 01:22:34.262865
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    a = SomePrice(Currency.USD, Decimal('1000'), datetime.date(2020, 3, 31))
    assert a.scalar_subtract(1) == SomePrice(Currency.USD, Decimal('999'), datetime.date(2020, 3, 31))
    assert a.scalar_subtract(1) != SomePrice(Currency.USD, Decimal('1000'), datetime.date(2020, 3, 31))

# Generated at 2022-06-24 01:22:46.444383
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    class Money_Mock_for_test(Money):
        def is_equal(self, other: Any) -> bool:
            raise NotImplementedError
        def as_boolean(self) -> bool:
            raise NotImplementedError
        def as_float(self) -> float:
            raise NotImplementedError
        def as_integer(self) -> int:
            raise NotImplementedError
        def abs(self) -> Money:
            raise NotImplementedError
        def negative(self) -> Money:
            raise NotImplementedError
        def positive(self) -> Money:
            raise NotImplementedError
        def round(self, ndigits: int = 0) -> Money:
            raise NotImplementedError
        def add(self, other: Money) -> Money:
            raise NotImplemented

# Generated at 2022-06-24 01:22:50.329656
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    p = Price('USD', PriceCcyType.QUOTED, Date.today(), PriceUnitType.POINT, 100, 0)
    m = Money(p)
    m = m.with_qty(100)
    assert m == Money(Currency.USD, 100, Date.today())



# Generated at 2022-06-24 01:22:58.899919
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    from .currencies import Currency
    
    ccy1 = Currency.of('AUD')
    ccy2 = Currency.of('USD')
    qty1 = Decimal('22.2')
    dov = Date(2018, 8, 31)
    
    m1 = SomeMoney(ccy1, qty1, dov)
    m2 = SomeMoney(ccy1, qty1, dov)
    
    assert m1 == m2
    
    m2 = SomeMoney(ccy1, qty1 * 2, dov)
    assert m1 != m2

# Generated at 2022-06-24 01:23:03.729860
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    expected = NoPrice
    actual = +NonePrice
    assert expected == actual

# Generated at 2022-06-24 01:23:08.785124
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    """
    Tests method __lt__ of class Money
    """

    custom_func = Money.__lt__

    # assert custom_func.__doc__ == "docstr_str"

    m_1 = Money.of(Currency.of("USD"), 1, Date.today())
    m_2 = Money.of(Currency.of("USD"), 1, Date.today())
    m_3 = Money.of(Currency.of("USD"), 2, Date.today())
    m_4 = Money.of(Currency.of("GBP"), 2, Date.today())

    assert (m_1 < m_2) is False
    assert (m_1 < m_3) is True
    assert (m_1 < m_4) is True

    # assert custom_func(obj_with_attr) == expected_return_value

# Generated at 2022-06-24 01:23:15.141410
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    # Check the NonePrice with NaN
    assert isinstance(NonePrice(), NonePrice)
    assert NonePrice().__float__() == float('nan')
    assert NonePrice().__float__ is NonePrice.as_float
    # Check the NonePrice with None
    assert NonePrice().__float__() is None

# Generated at 2022-06-24 01:23:22.504941
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    res = NonePrice() - NonePrice()
    assert res.defined == False
    assert res.undefined == True
    assert res == res
    assert res.abs() == res
    assert res.round() == res
    assert res.negative() == res
    assert res.positive() == res
    assert res.add(NonePrice()) == res
    assert res.subtract(NonePrice()) == res
    assert res.multiply(1) == res
    assert res.times(1) == NoMoney
    assert res.divide(1) == res
    assert res.floordiv(1) == res
    assert res.lt(NonePrice()) == False
    assert res.lte(NonePrice()) == True
    assert res.gt(NonePrice()) == False
    assert res.gte(NonePrice()) == True
    assert res

# Generated at 2022-06-24 01:23:33.463314
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    import pytest
    from moneyonchain.manager import ConnectionManager
    from moneyonchain.commons import Decimal

    connection_manager = ConnectionManager(network='rdocTestNet')

    ccy = connection_manager.docs_roptoken

    no_money = Money.of(ccy, Decimal('0'), Date(1,1,1))
    assert no_money.__gt__(no_money) is False

    some_money = Money.of(ccy, Decimal('1'), Date(1,1,1))
    assert some_money.__gt__(some_money) is False

    assert no_money.__gt__(some_money) is False

    assert some_money.__gt__(no_money) is True


# Generated at 2022-06-24 01:23:41.981049
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    ## Test use-case:
    from finance.common.currency import Currency
    from finance.common.date import Date
    from finance.common.price import Price
    from finance.common.price import SomePrice
    from decimal import Decimal
    from typing import Tuple
    from typing import NamedTuple
    class TestCase(NamedTuple):
        p: Price
        expected_ccy: Currency
        expected_qty: Decimal
        expected_dov: Date
        expected_defined: bool
        expected_undefined: bool

# Generated at 2022-06-24 01:23:47.488762
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    m = NoMoney
    assert m.positive() is NoMoney

# Generated at 2022-06-24 01:23:49.093029
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    # Test to assert that floor divide method works as expected
    n = Money.of(Currency.USD, 10, Date.today())
    assert n // 2 == 5 and n // 0 == 0



# Generated at 2022-06-24 01:23:49.888297
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    assert float(NonePrice) == 0.0

# Generated at 2022-06-24 01:23:51.577821
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert SomePrice(USD, 1, today).as_boolean() is True
    assert SomePrice(USD, 0, today).as_boolean() is False
    assert NoPrice.as_boolean() is False


# Generated at 2022-06-24 01:23:59.986832
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    ## Define a few instances of SomePrice:
    p0 = SomePrice(USD, Decimal(10), Date.today())
    p1 = SomePrice(USD, Decimal(10), Date.today())
    p2 = SomePrice(USD, Decimal(20), Date.today())
    ## Assertions:
    assert p0 == p0
    assert p0 == p1
    assert p0 != p2

# Generated at 2022-06-24 01:24:03.052492
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    sm = SomeMoney(USD, Decimal("12.387"), Date.today())
    assert sm.__bool__()

    sm = sm.with_qty(Decimal("0"))
    assert not sm.__bool__()


# Generated at 2022-06-24 01:24:11.560313
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    # GIVEN:
    args: Tuple[Currency, Decimal, Date] = (Currency.EUR, Decimal(10), Date(2020, 1, 2))

    # WHEN:
    result: Money = NoMoney + SomeMoney(*args)

    # THEN:
    assert isinstance(result, SomeMoney)
    assert result.ccy == args[0]
    assert result.qty == args[1]
    assert result.dov == args[2]

# Generated at 2022-06-24 01:24:17.503526
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    """
    Unit test for method `__abs__` of class `SomeMoney`.
    """
    ## IMPORTANT: `__abs__` is a **parallel** method
    ##            called by :meth:`abs`
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ##
    ## 1. Defined money with positive qty:
    ## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    ##
    ## Verify the `__abs__` method returns the correct type, i.e. `SomeMoney`:
    assert isinstance(SomeMoney(USD, Decimal("10"), Date(2018, 1, 1)).__abs__(), SomeMoney)

    ## Verify the `__abs__` method returns the correct value:

# Generated at 2022-06-24 01:24:26.783263
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    """
    Tests that method ``scalar_subtract`` of class :class:`Price` raises ``TypeError`` for undefined price objects.
    """
    assert isinstance(NoPrice.scalar_subtract(Money(1, USD, dov=Date(2018, 1, 1))), NoPrice)
    assert isinstance(NoPrice.scalar_subtract(5), NoPrice)
    assert isinstance(NoPrice.scalar_subtract(5.5), NoPrice)
    assert isinstance(NoPrice.scalar_subtract(Decimal(5.5)), NoPrice)



# Generated at 2022-06-24 01:24:31.103748
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    # Fixture:
    expected = NoPrice

    # Test:
    actual = NoPrice.with_qty(Decimal(2))

    # Assert:
    assert actual is expected

# Generated at 2022-06-24 01:24:43.787389
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    assert NoPrice * 1 == NoPrice
    assert NoPrice * 10 == NoPrice
    assert NoPrice * 100 == NoPrice
    assert NoPrice * -1 == NoPrice
    assert NoPrice * -10 == NoPrice
    assert NoPrice * -100 == NoPrice
    assert NoPrice * 1.0 == NoPrice
    assert NoPrice * 10.0 == NoPrice
    assert NoPrice * 100.0 == NoPrice
    assert NoPrice * -1.0 == NoPrice
    assert NoPrice * -10.0 == NoPrice
    assert NoPrice * -100.0 == NoPrice
    assert NoPrice * Decimal(1) == NoPrice
    assert NoPrice * Decimal(10) == NoPrice
    assert NoPrice * Decimal(100) == NoPrice
    assert NoPrice * Decimal(-1) == NoPrice

# Generated at 2022-06-24 01:24:47.300796
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of("usd", Decimal("100.00"), "2020-01-02").divide("100.00") == Price.of("usd", Decimal("1.0000"), "2020-01-02")


# Generated at 2022-06-24 01:24:54.169092
# Unit test for constructor of class SomePrice
def test_SomePrice():
    assert SomePrice(Currency.USD, Decimal(12), Date('2018-12-01')) == SomePrice(Currency.USD, Decimal(12), Date('2018-12-01'))
    assert SomePrice(Currency.USD, Decimal(12), Date('2018-12-01')).ccy == Currency.USD
    assert SomePrice(Currency.USD, Decimal(12), Date('2018-12-01')).qty == Decimal(12)
    assert SomePrice(Currency.USD, Decimal(12), Date('2018-12-01')).dov == Date('2018-12-01')
    assert SomePrice(Currency.USD, Decimal(12), Date('2018-12-01')).defined

# Generated at 2022-06-24 01:25:03.023230
# Unit test for method __round__ of class Price
def test_Price___round__():
    # Test simple round up
    assert Price.of(EUR, Decimal("10.12"), Date(days=0)).__round__() == 10
    assert Price.of(EUR, Decimal("10.12"), Date(days=0)).__round__() == Price.of(EUR, Decimal("10"), Date(days=0))

    # Test simple round down
    assert Price.of(EUR, Decimal("10.88"), Date(days=0)).__round__() == 11
    assert Price.of(EUR, Decimal("10.88"), Date(days=0)).__round__() == Price.of(EUR, Decimal("11"), Date(days=0))

    # Test round up with ndigits
    assert Price.of(EUR, Decimal("10.12"), Date(days=0)).__round__

# Generated at 2022-06-24 01:25:04.389538
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    assert round(NonePrice()) == 0


# Generated at 2022-06-24 01:25:09.615023
# Unit test for method __round__ of class Price
def test_Price___round__():
    assert floor(Price.of(Currency.of("USD"), Decimal(1.55), Date.today())) == 1
    assert floor(Price.of(Currency.of("USD"), Decimal(1.55), Date.today()), ndigits=1) == Price.of(Currency.of("USD"), Decimal(1.5), Date.today())



# Generated at 2022-06-24 01:25:13.954746
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    c, q, d = CCY, Decimal("1.0"), TODAY
    p1, p2 = SomePrice(c, q, d), SomePrice(c, q, d)

    assert p1 <= p2
    assert p2 <= p1
    assert p1 <= p1
    assert p2 <= p2

# Generated at 2022-06-24 01:25:16.234525
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    from datetime import date
    a = SomeMoney(Currency.of("USD"), Decimal("100"), date(2019, 1, 1))
    assert a.dov
    assert a.with_dov(date(2019, 1, 2)).dov == date(2019, 1, 2)

# Generated at 2022-06-24 01:25:17.626008
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    assert True



# Generated at 2022-06-24 01:25:26.549168
# Unit test for method lt of class Price
def test_Price_lt():
    """
    Ensure that comparing prices the right way
    """
    assert Price.of(Currency.USD, Decimal(10), "2014-01-01") < Price.of(Currency.USD, Decimal(2), "2014-01-01")
    assert not (Price.of(Currency.USD, Decimal(10), "2014-01-01") < Price.of(Currency.USD, Decimal(10), "2014-01-01"))
    assert not (Price.of(Currency.USD, Decimal(2), "2014-01-01") < Price.of(Currency.USD, Decimal(1), "2014-01-01"))


# Generated at 2022-06-24 01:25:34.409454
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Test whether the method __add__ of class NoneMoney
    works as desired.

    We test this by checking the outcome of adding
    NoneMoney to an arbitrary Money value.
    """
    ## Let's define a random currency:
    ccy = Currency(random_code())

    ## And a random date:
    dov = random_date()

    ## Define a money value and a NoneMoney value:
    a = Money.of(ccy, random_decimal(), dov)
    b = NoneMoney

    ## Check that adding the two values gives us the first money value:
    assert a == b + a

# Generated at 2022-06-24 01:25:37.541705
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    # First assert that Date is imported correctly
    # Second assert that NoPrice is imported correctly
    assert is_same(Date.of(2018, 11, 28), NoPrice.with_dov(Date.of(2018, 11, 28)).dov)


# Generated at 2022-06-24 01:25:40.954132
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    from hamcrest import assert_that, equal_to
    from money.models import NoPrice

    result = NoPrice.__pos__()

    assert_that(result, equal_to(NoPrice))



# Generated at 2022-06-24 01:25:48.639530
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    """
    Tests method with_qty of class Money
    """
    # we should use a Money class that is NOT abstract
    # lets use its subclass SomeMoney
    from .pricing import SomeMoney
    
    # lets create a SomeMoney object
    a = SomeMoney(Currency('USD'), Decimal('10'), Date('2019-01-01'))
    
    # lets create a new Money object with a different quantity
    b = a.with_qty(Decimal('20'))
    
    # lets compare the attributes of the Money objects
    assert a.ccy == b.ccy
    assert a.dov == b.dov
    assert a.qty != b.qty

# Generated at 2022-06-24 01:25:59.243020
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert SomeMoney(Currency.USD, 1.23, Date.today()).with_qty(4.56) == SomeMoney(Currency.USD, 4.56, Date.today())
    assert SomeMoney(Currency.USD, 1.23, Date.today()).with_qty(None) == NoMoney
    assert SomeMoney(Currency.USD, 1.23, Date.today()).with_qty(Decimal("nan")) == NoMoney
    assert SomeMoney(Currency.USD, 1.23, Date.today()).with_qty(Decimal("inf")) == NoMoney
    assert SomeMoney(Currency.USD, 1.23, Date.today()).with_qty(Decimal("-inf")) == NoMoney
    assert NoMoney.with_qty(4.56) == NoMoney

# Generated at 2022-06-24 01:26:09.826965
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.of(ccy=Currency.of("USD"), qty=Decimal("2.45"), dov=Date.today()).floor_divide(
        Price.of(ccy=Currency.of("USD"), qty=Decimal("0.00"), dov=Date.today())
    ) == Price.of(ccy=Currency.of("USD"), qty=Decimal("0E+2"), dov=Date.today())


# Generated at 2022-06-24 01:26:14.132291
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    price_xyz = Price.of(Currency.of("USD"), 1.00, Date(2019, 10, 11))
    price_xyz_same = Price.of(Currency.of("USD"), 1.00, Date(2019, 10, 11))
    price_abc = Price.of(Currency.of("USD"), 1.50, Date(2019, 10, 11))

    assert price_xyz.is_equal(price_xyz_same)
    assert not price_xyz.is_equal(price_abc)

    assert price_xyz == price_xyz_same
    assert price_xyz != price_abc

# Generated at 2022-06-24 01:26:25.406945
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    import gs_quant.timeseries as ts  # import dependency
    import gs_quant.instrument as inst  # import dependency
    from gs_quant.target.backtests import Backtest, BacktestRequest, BacktestSpec

    class SomeMoney__add__:
        def __init__(self):
            """
            Class initialiser.
            """
            pass

    from gs_quant.markets.portfolio import Portfolio

    class SomeMoney__add__:
        def __init__(self):
            """
            Class initialiser.
            """
            pass

    class SomeMoney__add__:
        def __init__(self):
            """
            Class initialiser.
            """
            pass



# Generated at 2022-06-24 01:26:36.322550
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    """Unit tests for __gt__ method of class Money"""
    m1_pass_1 = SomeMoney(ccy=currencies.USD, qty=Decimal("10.00"), dov=Date(2018, 1, 1))
    m1_pass_2 = SomeMoney(ccy=currencies.USD, qty=Decimal("10.00"), dov=Date(2018, 1, 1))
    m1_Pass_3 = SomeMoney(ccy=currencies.USD, qty=Decimal("9.99"), dov=Date(2018, 1, 1))
    m2_pass_1 = SomeMoney(ccy=currencies.USD, qty=Decimal("10.00"), dov=Date(2018, 1, 1))

# Generated at 2022-06-24 01:26:39.087054
# Unit test for method abs of class Price
def test_Price_abs():
    usd = Currency.of("USD")
    moneyUSD = Money.of(usd, 1)
    priceUSD = moneyUSD.price
    assert priceUSD.abs() == priceUSD

# Generated at 2022-06-24 01:26:48.534981
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert SomePrice(USD, Decimal("42.00"), DOV).as_integer() == 42
    assert SomePrice(USD, Decimal(42.00), DOV).as_integer() == 42
    assert SomePrice(USD, Decimal(42.0), DOV).as_integer() == 42
    assert SomePrice(USD, Decimal(42), DOV).as_integer() == 42
    assert SomePrice(USD, 42, DOV).as_integer() == 42
    assert SomePrice(USD, 42.00, DOV).as_integer() == 42
    assert SomePrice(USD, 42.0, DOV).as_integer() == 42

    # If quantity is defined but not an integer
    with raises(MonetaryOperationException):
        SomePrice(USD, 42.71, DOV).as_integer()

# Generated at 2022-06-24 01:26:56.772042
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    m = Money.of(Currency.get("USD"), 1.0, Date.today())
    assert not (m == -m)
    assert not m.lt(m)
    assert m.lte(m)
    assert not m.gt(m)
    assert m.gte(m)
    assert m.ccy == m.convert(m.ccy, Date.today()).ccy and m.qty == m.convert(m.ccy, Date.today()).qty and m.dov == m.convert(m.ccy, Date.today()).dov
    assert str(m) == "1.00 USD"
    assert str(Money.of(m.ccy, 1.0, Date.today())) == str(m)



# Generated at 2022-06-24 01:27:01.431178
# Unit test for method round of class Money
def test_Money_round():
    print("begin Money.round() test")
    import datetime
    from money import Money
    from currencies import Currency
    from zeitgeist import Date
    from money import Money

    #test round
    money0 = Money.of(Currency.USD, 1.235, Date.today())
    money1 = Money.of(Currency.USD, 1.235, Date.today())
    if money0.round() == money1.round():
        print("round test passed")
    else:
        print("round test failed")

    money0 = Money.of(Currency.USD, 2.235, Date.today())
    money1 = Money.of(Currency.USD, 2.235, Date.today())
    if money0.round() == money1.round():
        print("round test passed")

# Generated at 2022-06-24 01:27:13.469429
# Unit test for method subtract of class Price
def test_Price_subtract():
    ccy_a = Currency("GBP")
    ccy_b = Currency("CHF")
    na = Price.NA
    money_a = Money.of(ccy=ccy_a, qty=Decimal("0"), dov=Date("2016-01-01"))
    money_b = Money.of(ccy=ccy_b, qty=Decimal("0"), dov=Date("2016-01-01"))
    money_c = Money.of(ccy=ccy_a, qty=Decimal("3"), dov=Date("2016-01-01"))
    prc_a = Price.of(ccy=ccy_a, qty=Decimal("0"), dov=Date("2016-01-01"))

# Generated at 2022-06-24 01:27:15.733581
# Unit test for method __le__ of class Money
def test_Money___le__():
    assert Money.of("USD", 100, Date.today()) <= Money.of("USD", 100, Date.today())



# Generated at 2022-06-24 01:27:18.111768
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    """
    Test method __eq__ of class NoneMoney.
    """
    pass # print("No test written for method NoneMoney.__eq__")


# Generated at 2022-06-24 01:27:27.805110
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    m1 = SomeMoney(USD, 10, Date(2020, 1, 1))
    m2 = m1.scalar_add(5)
    m3 = m1.scalar_add(-5)

    assert m1 != m2
    assert m1 != m3
    assert m2 != m3

    assert m1 != m2
    assert m2 != m3

    assert m1 == m1
    assert m2 == m2
    assert m3 == m3

    assert not m1 == m2
    assert not m2 == m3

    assert m2 == SomeMoney(USD, 15, Date(2020, 1, 1))
    assert m3 == SomeMoney(USD, 5, Date(2020, 1, 1))



# Generated at 2022-06-24 01:27:38.986471
# Unit test for method times of class Price
def test_Price_times():
    p = Price.of(USD, Decimal("1.2"), Date(2016, 12, 22))
    assert p * Decimal("2.0") == Price.of(USD, Decimal("2.4"), Date(2016, 12, 22))
    assert p * Decimal("0.5") == Price.of(USD, Decimal("0.6"), Date(2016, 12, 22))
    assert p * Decimal("0.0") == Price.of(USD, Decimal("0.0"), Date(2016, 12, 22))

    assert p * 2 == Price.of(USD, Decimal("2.4"), Date(2016, 12, 22))
    assert p * 0.5 == Price.of(USD, Decimal("0.6"), Date(2016, 12, 22))

# Generated at 2022-06-24 01:27:40.708966
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__():
    result = NoneMoney / 1.0
    pass


# Generated at 2022-06-24 01:27:52.610792
# Unit test for method gte of class Price
def test_Price_gte():
    assert (NoPrice >= NoPrice) is True
    assert (SomePrice(JPY, 0.01, Date(2020, 1, 1)) >= NoPrice) is True
    assert (NoPrice >= SomePrice(JPY, 0.01, Date(2020, 1, 1))) is False
    assert (SomePrice(JPY, 0.01, Date(2020, 1, 1)) >= SomePrice(JPY, 0.01, Date(2020, 1, 1))) is True
    assert (SomePrice(JPY, 0.01, Date(2020, 1, 1)) >= SomePrice(JPY, 0.01, Date(2020, 2, 1))) is True
    assert (SomePrice(JPY, 0.01, Date(2020, 2, 1)) >= SomePrice(JPY, 0.01, Date(2020, 1, 1))) is False

# Generated at 2022-06-24 01:27:58.170142
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    price = Price.of("USD", 1.0, local_date("2018-01-01"))
    price_pos = price.__pos__()
    assert price_pos == Price(currency="USD", quantity=1, date_of_value=local_date("2018-01-01"))


# Generated at 2022-06-24 01:28:04.170195
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    # given:
    usd = Currency.USD
    p = SomePrice(usd, 100.0, Date(2018, 10, 22))
    # exercise:
    result = +p
    # verify:
    assert result.ccy == usd
    assert result.qty == 100.0
    assert result.dov == Date(2018, 10, 22)
    # cleanup:
    pass

# Generated at 2022-06-24 01:28:13.679862
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    p = Price.of('NZD', 0.25, Date.today())

    q = p.floor_divide(2)
    assert isinstance(q, Price)
    assert q.ccy == 'NZD'
    assert q.qty == 0
    assert q.dov == Date.today()

    q = p.floor_divide(2.0)
    assert isinstance(q, Price)
    assert q.ccy == 'NZD'
    assert q.qty == 0
    assert q.dov == Date.today()

    q = p.floor_divide(Decimal('2.0'))
    assert isinstance(q, Price)
    assert q.ccy == 'NZD'
    assert q.qty == 0
    assert q.dov == Date.today()

    q = p

# Generated at 2022-06-24 01:28:17.861537
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    NonePrice = quantipy.data.base.NonePrice()
    assert NonePrice.convert(Currency(code='USD'), None, True) == quantipy.data.base.NonePrice()


# Generated at 2022-06-24 01:28:27.015461
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from .money import SomeMoney, NoMoney
    from .fxrate import FXRate, FXRateService


    mon = SomeMoney(Currency("GBP"), Decimal("12.50"), None)
    pri = SomePrice(Currency("GBP"), Decimal("12.50"), None)
    assert mon == pri.money

    # -- SomePrice#convert
    assert pri.convert(Currency("USD")) == SomePrice(Currency("USD"), Decimal("17.50"), None)

    assert SomePrice(Currency("GBP"), Decimal("12.50"), None).convert(Currency("USD")) == SomePrice(
        Currency("USD"), Decimal("17.50"), None
    )