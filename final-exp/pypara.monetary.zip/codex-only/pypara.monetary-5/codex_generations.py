

# Generated at 2022-06-24 01:18:39.610155
# Unit test for method __le__ of class NoneMoney
def test_NoneMoney___le__():
    mny = Money.of(USD, 10, None)
    mny2 = Money.of(EUR, 10, None)
    mny3 = Money.of(EUR, 5, None)
    assert mny2 <= mny
    assert mny2 <= mny2
    assert mny <= mny3
    assert mny3 <= mny
    with raises(IncompatibleCurrencyError):
        mny <= mny2
    with raises(IncompatibleCurrencyError):
        mny2 <= mny
    mny4 = Money.of(USD, 5, None)
    mny5 = Money.of(EUR, 5, None)
    assert mny4 <= mny5
    assert mny5 <= mny4
    mny6 = Money.of(USD, Decimal(100), None)
    mny

# Generated at 2022-06-24 01:18:51.327183
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    from datetime import date
    from finacc.core.budget import Budget
    from finacc.core.transaction import Transaction
    from finacc.core.utils import to_cents
    from finacc.core.currency import Currency, CurrencySet

    EUR = Currency("EUR", 2, "-")
    USD = Currency("USD", 2, "-")

    ## Build budgets:
    anual = Budget("Anual", date(2020, 1, 1), date(2020, 12, 31), "")
    car = Budget("Car", date(2020, 1, 1), date(2020, 12, 31), "", parent=anual)
    food = Budget("Food", date(2020, 1, 1), date(2020, 12, 31), "", parent=anual)

# Generated at 2022-06-24 01:18:56.602963
# Unit test for method divide of class Money
def test_Money_divide():
    money1 = Money(200, "USD")
    money2 = Money(300, "USD")
    money3 = Money(200, "EUR")
    assert (money1 / money2 == Decimal("0.67"))
    assert (isinstance(money1 / money2, Decimal))


# Generated at 2022-06-24 01:18:59.842413
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    ## Test logic:
    ## Tests that the method returns the object itself.
    p = Price.of(USD, Decimal("123.45"), dtnow())
    assert (p.positive().is_equal(p))


# Generated at 2022-06-24 01:19:08.956574
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():

    # NoPrice is always false
    assert NoPrice.as_boolean() == False

    # Zero value price is always false
    assert Price.of(ccy(Currencies.USD), D(0), today()).as_boolean() == False

    # Positive value price is always true
    assert Price.of(ccy(Currencies.USD), D(10), today()).as_boolean() == True

    # Negative value price is always true
    assert Price.of(ccy(Currencies.USD), D(-10), today()).as_boolean() == True


# Generated at 2022-06-24 01:19:10.637092
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert Price.NA.__float__() == 0.0



# Generated at 2022-06-24 01:19:17.249759
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
#     ## Prepare:
    from finance.money import Money

#     ## Execute:
    money = Money.of("USD", 123, "2018-12-03")

#     ## Verify:
    assert money == Money.of("USD", 123, "2018-12-03")
    assert money.__pos__() == Money.of("USD", 123, "2018-12-03")
    assert money == +money


# Generated at 2022-06-24 01:19:25.167044
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():


    ##
    ## Unit test for method __abs__ of class NonePrice:
    ##
    ##     def __abs__(self) -> "Price":
    ##         return self
    ##
    ##     def __bool__(self) -> bool:
    ##         return False
    ##


    ## Failed by exception:
        ## RuntimeError: maximum recursion depth exceeded

    x = NonePrice()
    assert x == NoPrice
    x_abs = x.__abs__()
    assert x_abs == x
    x_bool = x.__bool__()
    assert_equal(x_bool, False)

## Unit test for method __add__ of class NonePrice

# Generated at 2022-06-24 01:19:26.993953
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    np = NonePrice()
    assert np.__neg__() is np

# Generated at 2022-06-24 01:19:31.505767
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    from money import Price
    from money.exceptions import MonetaryOperationException

    assert Price.NA.__neg__() is Price.NA
    assert Price.of(None, None, None).__neg__() is Price.NA

    with pytest.raises(MonetaryOperationException):
        Price.of(Currency("EUR"), Decimal(10), Date(2019, 12, 12)).__neg__()

    assert Price.of(Currency("EUR"), None, Date(2019, 12, 12)).__neg__() is Price.NA
    assert Price.of(Currency("EUR"), Decimal(0), Date(2019, 12, 12)).__neg__() is Price.NA

# Generated at 2022-06-24 01:19:38.167721
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    from .currency import Currency
    from .date import Date
    from .price import Price
    from .settlement_type import SettlementType

    # Test Cases:
    # Case 1:
    EUR = Currency("EUR", SettlementType.CASH)
    EUR_100 = Price.of(EUR, Decimal("100.0"), Date.today())
    assert EUR_100.__int__() == 100  # type: ignore

    # Case 2:
    INR_100 = Price.of(Currency("INR", SettlementType.CASH), Decimal("100.0"), Date.today())
    assert INR_100.__int__() == 100  # type: ignore


# Generated at 2022-06-24 01:19:48.285386
# Unit test for method add of class Price
def test_Price_add():
    from datetime import date
    from .currency import USD
    
    m1 = Money.of(1000, USD, date(2019, 8, 8))
    m2 = Money.of(2000, USD, date(2019, 8, 8))
    m3 = Money.of(2000, USD, date(2020, 8, 9))

    m4 = m1.add(m2)
    assert m4.as_float() == 3000.0
    assert m4.ccy == USD
    assert m4.dov == date(2019, 8, 8)

    m5 = m3.add(m4)
    assert m5.as_float() == 5000.0
    assert m5.ccy == USD
    assert m5.dov == date(2020, 8, 9)

# Generated at 2022-06-24 01:19:51.986776
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    """
    Unit test for method ``__abs__`` of class :class:`SomePrice`.
    """
    assert abs(SomePrice("XXX", Decimal("10.0"), Date("2020-06-30"))).as_float() == 10.0
    assert abs(SomePrice("XXX", Decimal("-10.0"), Date("2020-06-30"))).as_float() == 10.0

# Generated at 2022-06-24 01:19:58.446275
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    """
    Unit test for method Price.__sub__ of class Price.
    """
    a = Price(USD, 100, TODAY)
    b = Price(USD, 50, TODAY)
    c = Price(CHF, 3, TODAY)
    d = Price.NA
    assert (a - b) == Price(USD, 50, TODAY)
    assert (a - c) == Price.NA
    assert (a - d) == Price.NA
    assert (b - a) == Price(USD, -50, TODAY)
    assert (b - c) == Price.NA
    assert (b - d) == Price.NA
    assert (c - a) == Price.NA
    assert (c - b) == Price.NA
    assert (c - d) == Price.NA
    assert (d - a) == Price.NA

# Generated at 2022-06-24 01:20:08.181902
# Unit test for method __eq__ of class Money
def test_Money___eq__():

    # Test with NoMoney

    assert NoMoney == NoMoney
    assert not NoMoney != NoMoney

    # Test with NoneMoney

    assert NoneMoney == NoneMoney
    assert not NoneMoney != NoneMoney

    # Test with SomeMoney

    assert SomeMoney("USD", 1, Date(2016, 1, 1)) == SomeMoney("USD", 1, Date(2016, 1, 1))
    assert not SomeMoney("USD", 1, Date(2016, 1, 1)) != SomeMoney("USD", 1, Date(2016, 1, 1))

    # Test with incompatible currencies

    assert SomeMoney("USD", 1, Date(2016, 1, 1)) != SomeMoney("EUR", 1, Date(2016, 1, 1))
    assert SomeMoney("USD", 1, Date(2016, 1, 1)) != SomeMoney("USD", 1, Date(2016, 2, 1))

# Generated at 2022-06-24 01:20:13.089781
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    ## Test case 1:
    ## Test case 1.1:
    money = Money.of(USD, Decimal(101.9), Date(2018, 5, 1))
    expected = Money.of(USD, Decimal(111.9), Date(2018, 5, 1))
    result = money.scalar_add(10)
    assert expected == result
    ## Test case 1.2:
    money = Money.of(USD, Decimal(101.9), Date(2018, 5, 1))
    expected = Money.of(USD, Decimal(92.9), Date(2018, 5, 1))
    result = money.scalar_add(-9)
    assert expected == result
    ## Test case 2:
    ## Test case 2.1:

# Generated at 2022-06-24 01:20:16.239479
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    from mathematics import Money
    from tests import do_test

    do_test(Money, "__ge__", Money.of(None, None, None), Money.of(None, None, None), expected=True)



# Generated at 2022-06-24 01:20:27.320905
# Unit test for method gte of class Money
def test_Money_gte():

    class Test(Money):
        __slots__ = ('a',)

        def __init__(self, a: str):
            self.a = a

        def is_equal(self, other):
            return NotImplemented

        def as_boolean(self):
            return NotImplemented

        def as_float(self):
            return NotImplemented

        def as_integer(self):
            return NotImplemented

        def abs(self):
            return NotImplemented

        def negative(self):
            return NotImplemented

        def positive(self):
            return NotImplemented

        def round(self, ndigits):
            return NotImplemented

        def add(self, other):
            return NotImplemented

        def scalar_add(self, other):
            return NotImplemented

# Generated at 2022-06-24 01:20:36.390629
# Unit test for method abs of class Money
def test_Money_abs():
    # 1. Arrange
    from datetime import date
    import pytest
    from .currencies import Euro

    class TestMoney(Money):
        def is_equal(self, other: Any) -> bool:
            return False

        @property
        def ccy(self) -> Currency:
            return Euro

        @property
        def qty(self) -> Decimal:
            return 0

        @property
        def dov(self) -> Date:
            return Date.today()

        @property
        def defined(self) -> bool:
            return True

        @property
        def undefined(self) -> bool:
            return False

        def as_boolean(self) -> bool:
            return False

        def as_float(self) -> float:
            return 0

        def as_integer(self) -> int:
            return

# Generated at 2022-06-24 01:20:37.709670
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    assert None == SomePrice(None, None, None).__pos__()

# Generated at 2022-06-24 01:20:38.338422
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    pass

# Generated at 2022-06-24 01:20:49.626897
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    import abc
    import datetime
    import numbers
    import types
    import typing
    import unittest
    import uuid
    from dataclasses import dataclass
    from decimal import Decimal
    from numbers import Number
    from typing import (Any as typing_Any,
                        Callable,
                        Dict,
                        Generic as typing_Generic,
                        Iterable as typing_Iterable,
                        List,
                        Mapping,
                        MutableMapping,
                        MutableSequence,
                        MutableSet,
                        Optional,
                        Sequence as typing_Sequence,
                        Set,
                        Tuple,
                        Type,
                        TypeVar,
                        Union as typing_Union,
                        )
    from typing import _FakeAnnotatedAlias
    from typing import _GenericAlias as typing__GenericAlias

# Generated at 2022-06-24 01:20:55.217519
# Unit test for method multiply of class Price
def test_Price_multiply():
    ccy = Currency('a')
    qty = Decimal(100)
    date = date_of_value(10)
    price = Price.of(ccy,qty,date)
    assert(price.multiply('2') == Price.of(ccy,qty*2,date))


# Generated at 2022-06-24 01:21:00.094975
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    import pytest

    with pytest.raises(TypeError):
        NoMoney + NoMoney

    with pytest.raises(TypeError):
        NoMoney + SomeMoney(USD, Decimal(100), Date.now())

    with pytest.raises(TypeError):
        SomeMoney(USD, Decimal(100), Date.now()) + NoMoney



# Generated at 2022-06-24 01:21:04.588322
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Tests the method ``__add__`` of class ``NoneMoney``.
    """
    assert NoneMoney + SomeMoney("SEK",  Decimal("1.2345"), Date.today()) is None
    assert SomeMoney("SEK",  Decimal("1.2345"), Date.today()) + NoneMoney is None



# Generated at 2022-06-24 01:21:05.840858
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    #TODO:
    pass
# Test class SomeMoney

# Generated at 2022-06-24 01:21:17.755914
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import EUR

    # {__sub__(self, other: Money) -> Money}
    # [21, 24]
    # ... (21)
    # {self:  na , other:  na ->  na}
    # ... (22)
    # {self:  na , other: EUR(2.00) ->  na}
    # ... (23)
    # {self: EUR(2.00) , other:  na -> EUR(2.00)}
    # ... (24)
    # {self: EUR(2.00) , other: EUR(2.00) -> EUR(0.00)}
    # __sub__(self, other: Money) -> Money
    # Equivalent to self - other.
    # ... (21)
    # {self:  na , other:  na ->  na}

# Generated at 2022-06-24 01:21:21.139715
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    assert SomePrice('EUR', Decimal('1.0'), '2019-01-01').with_ccy('GBP') == SomePrice('GBP', Decimal('1.0'), '2019-01-01')

# Generated at 2022-06-24 01:21:21.733005
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    ...



# Generated at 2022-06-24 01:21:31.783182
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    m = Money
    assert bool(m.of(Currency.USD, Decimal('1.0109050908509423'), Date.today())) == True
    assert bool(m.of(Currency.USD, Decimal('1.0000908509423'), Date.today())) == True
    assert bool(m.of(Currency.USD, Decimal('0.0000908509423'), Date.today())) == True
    assert bool(m.of(Currency.USD, Decimal('0E-9'), Date.today())) == False
    assert bool(m.of(Currency.USD, Decimal('0E-9'), Date(1900, 1, 1))) == False
    assert bool(NoMoney) == False


# Generated at 2022-06-24 01:21:34.034034
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    """
    Tests the double-star multiplication of NoneMoney objects.
    """
    assert NoneMoney * 123 == NoneMoney
    assert NoneMoney * 123.45 == NoneMoney
    assert NoneMoney * (NoneMoney * 123) == NoneMoney

# Generated at 2022-06-24 01:21:36.160121
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    price = Price.of(Currency.USD, Decimal("-123"), Date.today())  # type: Price
    assert price.abs() == Price.of(Currency.USD, Decimal("123"), Date.today())


# Generated at 2022-06-24 01:21:39.189467
# Unit test for method __int__ of class Money
def test_Money___int__():
    """
    Testing the method __int__ of class Money
    """
    try:
        Money.__int__()
    except TypeError as e:
        pass


# Generated at 2022-06-24 01:21:46.351280
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from .. import EUR, USD
    from decimal import Decimal
    
    d = Decimal("2.2")
    today = Date.today()
    
    m = Money.of(EUR, d, today)

    with raises(TypeError):
        m.with_dov(None)
        
    new_dov = Date(year=2011, month=1, day=1)
    
    new_m = m.with_dov(new_dov)
    
    assert new_m.ccy == EUR
    assert new_m.qty == d
    assert new_m.dov == new_dov
    
    

# Generated at 2022-06-24 01:21:51.366099
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    """
    Tests for the constructor of the class MonetaryOperationException.
    """
    ## Create an instance of the class MonetaryOperationException
    moe = MonetaryOperationException()
    ## Ensure the object is an instance of the class MonetaryOperationException
    assert isinstance(moe, MonetaryOperationException)



# Generated at 2022-06-24 01:21:55.579266
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    assert SomePrice(EUR, Decimal('1.00'), '2018-01-01').times(Decimal('2.00')) == SomeMoney(EUR, Decimal('2.00'), '2018-01-01')
test_SomePrice_times()




# Generated at 2022-06-24 01:22:04.574972
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    from t_tests.asserts import *
    from t_core.messages import Packet
    # self.any = NoPrice
    # self.other = NoPrice
    with Packet("self.any = NoPrice"):
        with Packet("self.other = NoPrice"):
            self.any = NoPrice
            self.other = NoPrice
            result = self.any - self.other
            assert result is NoPrice
    # self.any = NoPrice
    # self.other = SomePrice(currencies.USD, Decimal('1'), date.today())
    with Packet("self.any = NoPrice"):
        with Packet("self.other = SomePrice(currencies.USD, Decimal('1'), date.today())"):
            self.any = NoPrice

# Generated at 2022-06-24 01:22:10.976246
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    #
    # undefined price is never greater than or equal to defined price
    #
    assert (not (NoPrice >= SomePrice(EUR, 10 ** 2, today())))
    assert (not (NoPrice >= NoPrice))
    #
    # undefined price is always greater than or equal to undefined price
    #
    assert (NoPrice >= NoPrice)
    assert (
        SomePrice(EUR, 10 ** 2, today()) >= SomePrice(EUR, 10 ** 2, today())
    )
    #
    # defined price is always greater than or equal to undefined price
    #
    assert (SomePrice(EUR, 10 ** 2, today()) >= NoPrice)
    assert (SomePrice(EUR, 10 ** 2, today()) >= SomePrice(EUR, 10 ** 2, today()))



# Generated at 2022-06-24 01:22:19.944135
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    """
    Test round
    """
    from .currency import Currency
    import pytest

    currency = Currency("USD")
    qty = Decimal("100.12345")

    someMoney = SomeMoney(currency, qty, None)
    assert someMoney.round(1) == Money("100.1", currency)
    assert someMoney.round(2) == Money("100.12", currency)
    assert someMoney.round(3) == Money("100.123", currency)
    assert someMoney.round(4) == Money("100.1235", currency)

    exception = pytest.raises(
        IncompatibleRoundingError,
        match="Rounding of quantity 100.1235 with precision 4 is incompatible with currency USD with precision 2"
    )
    with exception:
        someMoney.round(5)

# Generated at 2022-06-24 01:22:24.673030
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    c = SomeMoney(USD, 1, Date.today())
    assert c.__float__() == 1.0

# Generated at 2022-06-24 01:22:30.045801
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    x = SomeMoney(USD, Decimal("0.01"), Date.today())
    y = SomeMoney(USD, Decimal("0.01"), Date.today())
    assert x >= y

# Generated at 2022-06-24 01:22:35.659484
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    """
    Test for method NonePrice.__neg__.
    """
    pr = NoPrice  # type: Price
    assert pr.__neg__() is NoPrice, "price.__neg__ is not NoPrice"


# Generated at 2022-06-24 01:22:45.895497
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """
    Tests for method __gt__ of class SomeMoney.
    """
    a = SomeMoney(USD, 100, Date(2018, 1, 1))
    a1 = SomeMoney(USD, 100, Date(2018, 1, 1))
    assert a == a1
    assert not a < a1
    assert a1 < a
    assert a >= a1
    assert a1 <= a
    b = SomeMoney(USD, 10, Date(2018, 1, 1))
    assert b < a
    assert a > b
    c = SomeMoney(EUR, 100, Date(2018, 1, 1))
    assert c != a
    with pytest.raises(IncompatibleCurrencyError):
        a > c
    with pytest.raises(IncompatibleCurrencyError):
        c < a
    assert c > b

# Generated at 2022-06-24 01:22:48.025151
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    ## Setup:
    S = SomeMoney(USD, Q(100), DEFAULT_DOV)

    ## Assert:
    assert SomeMoney(EUR, Q(90), DEFAULT_DOV) == S.convert(EUR, strict=True)


## TODO: test name

# Generated at 2022-06-24 01:22:53.785472
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    # type: () -> None

    usd100 = Money.of(Currency.usd(), Decimal("100.00"), Date.today())
    x = usd100.scalar_add(-5)
    assert x == Money.of(Currency.usd(), Decimal("95.00"), Date.today())

# Generated at 2022-06-24 01:22:58.789023
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    uut = Money.of(Currency("USD"), Decimal("123.4"), Date("2020-01-01"))
    other = Money.of(Currency("USD"), Decimal("123.3"), Date("2020-01-01"))
    other2 = Money.of(Currency("USD"), Decimal("123.4"), Date("2020-01-01"))
    assert not other > uut
    assert uut > other
    assert not uut > other2



# Generated at 2022-06-24 01:23:03.185843
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    pass

# Generated at 2022-06-24 01:23:09.147092
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    from .currencies import Currency

    assert -NoneMoney == NoneMoney
    assert -NoMoney == NoMoney
    assert --SomeMoney(ccy=Currency("USD"), qty=1.0, dov=Date(2020, 1, 1)) == SomeMoney(ccy=Currency("USD"), qty=1.0, dov=Date(2020, 1, 1))
    assert ---SomeMoney(ccy=Currency("USD"), qty=1.0, dov=Date(2020, 1, 1)) == SomeMoney(ccy=Currency("USD"), qty=-1.0, dov=Date(2020, 1, 1))

# Generated at 2022-06-24 01:23:16.633789
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    usd = Currency.of('USD')
    assert Price.of(usd, Decimal('10.0'), date_today()).as_integer() == 10
    assert Price.of(usd, Decimal('10.0'), date_today()).as_integer() == 10

    with pytest.raises(TypeError):
        Price.of(usd, None, date_today()).as_integer()



# Generated at 2022-06-24 01:23:19.094154
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    assert SomeMoney(GBP, 1, dt.date(2020, 1, 1)).__bool__() is True
    assert SomeMoney(GBP, 0, dt.date(2020, 1, 1)).__bool__() is False

# Generated at 2022-06-24 01:23:29.429314
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    print("==> test_SomeMoney___lt__")

    a: Money = SomeMoney(CURRENCY_HKD, 1, Date.today())
    b: Money = SomeMoney(CURRENCY_HKD, 2, Date.today())
    c: Money = SomeMoney(CURRENCY_HKD, 1, Date.today())
    d: Money = SomeMoney(CURRENCY_HKD, 2, Date.today())
    e: Money = SomeMoney(CURRENCY_HKD, 1, Date.today())
    f: Money = SomeMoney(CURRENCY_HKD, 2, Date.today())
    g: Money = SomeMoney(CURRENCY_HKD, 1, Date.today())
    h: Money = SomeMoney(CURRENCY_HKD, 2, Date.today())

# Generated at 2022-06-24 01:23:33.066939
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    """
    Test function for the method with_dov of class NonePrice.
    """
    ## AAA:
    # Arrange:
    expected: Price = NonePrice

    # Act:

# Generated at 2022-06-24 01:23:41.662047
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    m = Money.of(Currency.USD, Decimal('1.0'), Date.today())
    assert m.with_ccy(Currency.JPY).ccy == Currency.JPY
    assert m.with_ccy(Currency.JPY).qty == Decimal('1.0')
    assert m.with_ccy(Currency.JPY).dov == Date.today()
    m1 = Money.of(Currency.USD, Decimal('2.0'), Date.today())
    assert m1.with_ccy(Currency.JPY).ccy == Currency.JPY
    assert m1.with_ccy(Currency.JPY).qty == Decimal('2.0')
    assert m1.with_ccy(Currency.JPY).dov == Date.today()

# Generated at 2022-06-24 01:23:47.540506
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    ccy = Currency.of('USD')
    qty = Decimal('-6.543')
    dov = Date.today()
    instance = SomePrice(ccy, qty, dov)
    result: Price = instance.__neg__()
    assert isinstance(result, Price)
    assert result.ccy == ccy
    assert result.qty == -qty
    assert result.dov == dov


# Generated at 2022-06-24 01:23:48.253988
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    pass

# Generated at 2022-06-24 01:23:55.345508
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    """
    Test method round.
    """
    from .money import Money

    ## Define variable:
    test_subject = NoPrice
    test_input = 0
    expected_result = NoPrice
    actual_result = test_subject.round(test_input)
    assert actual_result == expected_result, f"The result is expected to be: {expected_result} but got {actual_result}"

    ## Define variable:
    test_subject = NoPrice
    test_input = 0
    expected_result = test_subject
    actual_result = test_subject.round(test_input)
    assert actual_result == expected_result, f"The result is expected to be: {expected_result} but got {actual_result}"

    ## Define variable:
    test_subject = NoPrice
    expected_result = test_subject

# Generated at 2022-06-24 01:24:01.307305
# Unit test for method round of class Money
def test_Money_round():
        money = Money.of(Currency.USD, Decimal("1.234"), Date.today())
        money_r = money.round()
        assert money_r == Money.of(Currency.USD, Decimal("1"), Date.today())
        money_r = money.round(ndigits=1)
        assert money_r == Money.of(Currency.USD, Decimal("1.2"), Date.today())
Money.NA = NoMoney()


# Generated at 2022-06-24 01:24:01.856759
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():pass

# Generated at 2022-06-24 01:24:13.438755
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    assert SomeMoney(USD, Decimal('1'), today).convert(GBP, today) == SomeMoney(GBP, Decimal('1.22'), today)
    assert SomeMoney(USD, Decimal('1'), today).convert(GBP, None, strict=False) == NoMoney
    assert SomeMoney(USD, Decimal('1'), today).convert(GBP, None, strict=True) == SomeMoney(GBP, Decimal('1.22'), today)
    assert SomeMoney(USD, Decimal('1'), today).convert(GBP, yesterday) == SomeMoney(GBP, Decimal('1.21'), yesterday)
    assert SomeMoney(USD, Decimal('1'), yesterday).convert(GBP, today) == SomeMoney(GBP, Decimal('1.22'), today)

# Generated at 2022-06-24 01:24:15.593637
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    obj = Price()
    other = Price()
    result = obj.__gt__(other)
    assert isinstance(result, bool)

# Generated at 2022-06-24 01:24:17.007856
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(Money(Currency.USD, Decimal('1.1111'), Date.today())) == 1



# Generated at 2022-06-24 01:24:21.272291
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    assert Price.of("USD", Decimal("10"), Date(2019, 12, 1)).__abs__().money == Money(
        "USD", Decimal("10"), Date(2019, 12, 1)
    )
    assert Price.of("USD", Decimal("-10"), Date(2019, 12, 1)).__abs__().money == Money(
        "USD", Decimal("10"), Date(2019, 12, 1)
    )



# Generated at 2022-06-24 01:24:33.366469
# Unit test for method add of class Money
def test_Money_add():
    from .currencies import USD, EUR
    from .commons.zeitgeist import date_factory
    dt = date_factory()
    money = SomeMoney(USD, Decimal('500'), dt)
    money1 = SomeMoney(USD, Decimal('300'), dt)
    money2 = SomeMoney(USD, Decimal('200'), dt)
    money3 = SomeMoney(USD, Decimal('300'), dt)
    
    assert money.add(money2) == money1
    assert money1.add(money2) == money
    assert money2.add(money1) == money
    
    try:
        money1.add(NoMoney)
        assert False
    except MonetaryOperationException:
        assert True

# Generated at 2022-06-24 01:24:37.899512
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    # Arrange:
    price = SomePrice(USD, Decimal("100"), Date.today())

    # Act:
    actual = price * 10

    # Assert:
    assert actual == SomePrice(USD, Decimal("1000"), Date.today())



# Generated at 2022-06-24 01:24:50.346607
# Unit test for method divide of class Money
def test_Money_divide():
    for nominal, divisor, expected in [  # type: ignore
        (SomeMoney(Currency.USD, 100, Date(2019, 1, 1)), NoMoney, NoMoney),
        (SomeMoney(Currency.USD, 100, Date(2019, 1, 1)), SomeMoney(Currency.USD, 20, Date(2019, 1, 1)), 5),
        (SomeMoney(Currency.USD, 100, Date(2019, 1, 1)), SomeMoney(Currency.ZAR, 20, Date(2019, 1, 1)), NoMoney),
        (SomeMoney(Currency.USD, 100, Date(2019, 1, 1)), 0, NoMoney),
    ]:
        expected_qty = expected.qty if isinstance(expected, SomeMoney) else None

# Generated at 2022-06-24 01:24:54.085290
# Unit test for method lte of class Price
def test_Price_lte():
    qty: Numeric = 100.00
    ccy: Currency = "USD"
    dov: Date = Date.today()

    p: Price = Price.of(ccy=ccy, qty=qty, dov=dov)
    q: Price = Price.of(ccy=ccy, qty=(qty - DECIMAL_ONE), dov=dov)

    assert p.lte(q) is False

# Generated at 2022-06-24 01:25:02.912853
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    """
    Tests :meth:`SomeMoney.__lt__` method.
    """
    usd = Currency.get("USD")
    gbp = Currency.get("GBP")

    ## Compare universal no-money:
    assert not (NoMoney < NoMoney)
    assert not (NoMoney < SomeMoney(usd, 100, Date.now()))
    assert not (SomeMoney(usd, 100, Date.now()) < NoMoney)

    ## Compare money in the same currency:
    assert not (SomeMoney(usd, 100, Date.now()) < SomeMoney(usd, 100, Date.now()))
    assert SomeMoney(usd, 100, Date.now()) < SomeMoney(usd, 101, Date.now())

# Generated at 2022-06-24 01:25:14.442114
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    assert NoneMoney() is NoMoney


NoMoney = NoneMoney()


Money.of = staticmethod(Money.of)
Money.__bool__ = abstractproperty(Money.__bool__)
Money.__eq__ = abstractproperty(Money.__eq__)
Money.__abs__ = abstractproperty(Money.__abs__)
Money.__float__ = abstractproperty(Money.__float__)
Money.__int__ = abstractproperty(Money.__int__)
Money.__round__ = abstractproperty(Money.__round__)
Money.__neg__ = abstractproperty(Money.__neg__)
Money.__pos__ = abstractproperty(Money.__pos__)
Money.__add__ = abstractproperty(Money.__add__)
Money.__sub__ = abstractproperty(Money.__sub__)
Money.__mul__ = abstractproperty

# Generated at 2022-06-24 01:25:20.125017
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    """
    Tests method round of class SomePrice
    """
    sp = SomePrice(USD, Decimal("1"), Date(year=2019, month=12, day=1))
    sp.round(ndigits=0)
    # assert False # TODO: implement your test here
    raise NotImplementedErrorFromTutorial



# Generated at 2022-06-24 01:25:23.826133
# Unit test for method times of class Price
def test_Price_times():
    # Setup
    p = Price.of(USD, 3, today)
    # Exercise
    result = p.times(10)
    # Verify
    assert result == Money.of(USD, 30, today)


# Generated at 2022-06-24 01:25:34.000982
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    from .currency import Currency
    from .currency import CurrencyService
    from .money import Money
    from .money import NoneMoney
    from .money import SomeMoney
    from .time import Date
    c1 = CurrencyService.default.get("EUR")
    c2 = CurrencyService.default.get("GBP")
    dt = Date.today()
    zero = 0
    nm1 = NoneMoney
    sm1 = SomeMoney(c1, zero, dt)
    sm2 = SomeMoney(c2, zero, dt)
    assert sm1.with_ccy(c2).__class__ is SomeMoney
    assert nm1.with_ccy(c1).__class__ is NoneMoney
    assert nm1.with_ccy(c2).__class__ is NoneMoney

# Generated at 2022-06-24 01:25:37.759238
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    """
    Unit test for Money.__floordiv__()
    """

    try:
        ## Instance Method
        ## Success Cases
        # Method was tested as a part of Money class unit test.
        # User code should not call __floordiv__() as it's an internal method.

        ## Failure Cases
        None
    except Exception:
        assert False, "Raised an exception."

# Generated at 2022-06-24 01:25:41.556654
# Unit test for method divide of class Money
def test_Money_divide():
    assert Money(Currency('USD'), Decimal(1000), Date(2019, 1, 1)).divide(2) == \
           Money(Currency('USD'), Decimal(500), Date(2019, 1, 1))
    

# Generated at 2022-06-24 01:25:46.979094
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    assert SomeMoney(USD, Decimal("100.00"), today()).__bool__()



# Generated at 2022-06-24 01:25:47.857237
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    NoneMoney() >= NoneMoney()


# Generated at 2022-06-24 01:25:55.961571
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, Decimal(1), Date.today()).with_dov(Date(2019, 7, 1)) == Price.of(USD, Decimal(1), Date(2019, 7, 1))
    assert Price.of(USD, Decimal(1), Date(2019, 6, 1)).with_dov(Date.today()) == Price.of(USD, Decimal(1), Date.today())
    assert Price.of(USD, Decimal(1), Date.today()).with_dov(Date(2019, 6, 1)) == Price.of(USD, Decimal(1), Date(2019, 6, 1))


# Generated at 2022-06-24 01:26:02.048308
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    m = Money.of(USD, 1.23, date(2020, 3, 1))
    m2 = Money.of(USD, 1.23, date(2020, 3, 1))
    assert m == m2

# Generated at 2022-06-24 01:26:04.662070
# Unit test for method __le__ of class Money
def test_Money___le__():
    """

    """
    assert NoMoney <= NoMoney
    assert NoMoney <= SomeMoney(Currency.USD, 10.00, Date.today())



# Generated at 2022-06-24 01:26:05.482192
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    pass



# Generated at 2022-06-24 01:26:09.490857
# Unit test for method __int__ of class Price
def test_Price___int__():
    for m in ccy_set:
        for n in qty_set:
            assert int(Price.of(m, n, today)) == int(n)
    assert int(NoPrice) == int(0)
    assert int(NoPrice) == 0

# Generated at 2022-06-24 01:26:16.058782
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    _p = Price(Currency.of("EUR"), Decimal("3.141592653589793"), Date(2020, 4, 2))
    assert (_p * 2) == Price(Currency.of("EUR"), Decimal("6.283185307179586"), Date(2020, 4, 2))
    assert Price(Currency.of("EUR"), Decimal("2"), Date(2020, 4, 2)) * Price(Currency.of("USD"), Decimal("1"), Date(2020, 4, 2)) == Price(Currency.of("EUR"), Decimal("2"), Date(2020, 4, 2))

# Generated at 2022-06-24 01:26:16.845649
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    pass


# Generated at 2022-06-24 01:26:24.540918
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    p = Money.NA
    print(p)
    p1 = Money(100, 'USD')
    print(p1)
    p2 = Money(-100, 'USD')
    print(p2)
    
    print(p.__abs__())
    print(p1.__abs__())
    print(p2.__abs__())
    
    print(abs(p))
    print(abs(p1))
    print(abs(p2))

# Generated at 2022-06-24 01:26:36.438365
# Unit test for method __round__ of class Price
def test_Price___round__():
    assert Price.of('USD', Decimal('100.0'), Date(2018, 1, 1)).__round__() == 100
    assert Price.of('USD', Decimal('100.2'), Date(2018, 1, 1)).__round__() == 100
    assert Price.of('USD', Decimal('100.5'), Date(2018, 1, 1)).__round__() == 101
    assert Price.of('USD', Decimal('100.8'), Date(2018, 1, 1)).__round__() == 101
    assert Price.of('USD', Decimal('101.5'), Date(2018, 1, 1)).__round__() == 102

# Generated at 2022-06-24 01:26:37.183532
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    pass

# Generated at 2022-06-24 01:26:44.813181
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    """Test __gt__ method of class NonePrice."""

    import datetime

    from money.price import SomePrice
    from money.money import NoMoney

    # test with NonePrice
    arg = NonePrice
    assert arg.__gt__(SomePrice(Currency("USD"), Decimal(1), datetime.date.today())), "Failed with NonePrice"

    # test with NoMoney
    arg = NoMoney
    assert arg.__gt__(
        SomePrice(Currency("USD"), Decimal(1), datetime.date.today())), "Failed with NoMoney"



# Generated at 2022-06-24 01:26:51.866164
# Unit test for method gte of class Money
def test_Money_gte(): # unit test for method gte of class Money
    assert Money.of(Currency.USD, -100.0, Date.today()).gte(Money.of(Currency.USD, -100.0, Date.today()))
    assert Money.of(Currency.USD, -100.0, Date.today()).gte(Money.of(Currency.USD, -200.0, Date.today()))
    assert Money.of(Currency.USD, -100.0, Date.today()).gte(Money.of(Currency.USD, -600.0, Date.today()))
    assert Money.of(Currency.USD, -100.0, Date.today()).gte(Money.of(Currency.USD, -1000.0, Date.today()))
    

# Generated at 2022-06-24 01:27:03.374295
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    """
    Unit test for method ``__add__`` of class ``NonePrice``.
    """
    ## Initialize:
    p1 = Price(USD, 10.00)
    p2 = Price(USD, 20.00)
    p3 = Price(CAD, 30.00)
    p4 = Price(CAD, 40.00)

    ## Test:
    assert (p1 + p2).as_tuple() == (USD, 30.00)
    assert (p1 + p3).as_tuple() == NoPrice
    assert (p1 + NoPrice).as_tuple() == (USD, 10.00)
    assert (NoPrice + p1).as_tuple() == (USD, 10.00)
    assert (NoPrice + NoPrice).as_tuple() == NoPrice



# Generated at 2022-06-24 01:27:14.925349
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    # Setup:
    from quantaq.pipes import Money

    # Exercise:
    assert (Money.of(None, None, None) > Money.of(None, None, None)) is False
    assert (Money.of(None, None, None) > Money.of(None, 0.0, None)) is False
    assert (Money.of(None, None, None) > Money.of(None, Decimal("0"), None)) is False
    assert (Money.of(None, None, None) > Money.of(None, Decimal("1"), None)) is False
    assert (Money.of(None, 0.0, None) > Money.of(None, None, None)) is True
    assert (Money.of(None, 0.0, None) > Money.of(None, 0.0, None)) is False

# Generated at 2022-06-24 01:27:22.145245
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    # Default Value Test
    assert Price().__ge__() == NotImplemented
    # Default Value Test
    assert Price.NA.__ge__() == NotImplemented
    # Default Value Test
    assert Price.of("EUR", 5, date(2016, 1, 1)).__ge__() == NotImplemented


# Generated at 2022-06-24 01:27:32.277946
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    assert (NoMoney.with_dov(None) == NoMoney)
    assert (NoMoney.with_dov(Date(1990, 4, 8)) == NoMoney)
    assert (SomeMoney(Currency.usd, Decimal("100.0"), Date(1990, 4, 7)).with_dov(None) == SomeMoney(
        Currency.usd, Decimal("100.0"), Date(1990, 4, 7)))
    assert (SomeMoney(Currency.usd, Decimal("100.0"), Date(1990, 4, 7)).with_dov(Date(1990, 4, 8)) == SomeMoney(
        Currency.usd, Decimal("100.0"), Date(1990, 4, 8)))



# Generated at 2022-06-24 01:27:37.769879
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    """
    Tests the ``with_dov`` method of ``NonePrice`` class.
    """

    ## Initialize test price:
    p = NoPrice

    ## Do testing:
    assert p.with_dov(None).is_equal(NoPrice)
    assert p.with_dov(Date(2000, 12, 31)).is_equal(NoPrice)



# Generated at 2022-06-24 01:27:46.315409
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    from money import NoMoney
    assert isinstance(SomeMoney(EUR, Decimal(1), Date(1, 1, 1)) / 1, SomeMoney)
    assert isinstance(SomeMoney(GBP, Decimal(1), Date(1, 1, 1)) / NoMoney, NoMoney)
    assert isinstance(SomeMoney(USD, Decimal(1), Date(1, 1, 1)) / None, NoMoney)

# Generated at 2022-06-24 01:27:50.411367
# Unit test for method __add__ of class Money
def test_Money___add__():
    """
    Unit test for method __add__ of class Money
    """
    a = SomeMoney(Currency.USD, 10.00, Date.today())
    b = SomeMoney(Currency.USD, 8.00, Date.today())
    assert a + b == SomeMoney(Currency.USD, 18.00, Date.today())
    
    

# Generated at 2022-06-24 01:27:51.736344
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    monetary_operation_exception = MonetaryOperationException()
    assert monetary_operation_exception is not None



# Generated at 2022-06-24 01:27:53.438909
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    ccy = Currency("CAD")
    subject = NoMoney
    result = subject.with_ccy(ccy)
    assert result == NoMoney

# Generated at 2022-06-24 01:27:57.848221
# Unit test for method subtract of class Price
def test_Price_subtract():
    with raises(IncompatibleCurrencyError):
        Price(Currency.USD, 100, Date(2020, 1, 1)).subtract(Price(Currency.JPY, 100, Date(2020, 1, 1)))


# Generated at 2022-06-24 01:28:04.615769
# Unit test for method divide of class Money
def test_Money_divide():
    # Arrange
    ccy = Currency("USD")
    qty = Decimal("10")
    dov = Date(year=2019, month=11, day=5)
    money = Money.of(ccy, qty, dov)

    # Act
    actual = money.divide(2)

    # Assert
    assert actual.ccy == ccy
    assert actual.qty == Decimal("5")
    assert actual.dov == dov

# Generated at 2022-06-24 01:28:10.911403
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    with VOICEFILE_INVOICE.open() as file:
        inv: Invoice = load(file)
        assert inv.total_amount / Decimal("0.00") == Decimal("0.00")
        assert inv.total_amount // Decimal("0.00") == Decimal("0.00")



# Generated at 2022-06-24 01:28:11.949271
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    assert not NonePrice()

# Generated at 2022-06-24 01:28:20.436064
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from finance.common.currency import Currency
    from finance.util.timeutil import Date
    from finance.common.fxrateservice import FXRate, FXRateService
    from finance.common.fxrateservice import InMemoryFXRateService
    from finance.money import SomeMoney
    EUR = Currency.get('EUR')
    USD = Currency.get('USD')
    GBP = Currency.get('GBP')
    EURUSD = FXRate(EUR, USD, Decimal(1.2), date=Date.today())
    EURGBP = FXRate(EUR, GBP, Decimal(0.8), date=Date.today())
    FXRateService.default = InMemoryFXRateService([EURUSD, EURGBP])
    price_eur = SomePrice(EUR, Decimal(2), Date.today())
    price_us

# Generated at 2022-06-24 01:28:25.250042
# Unit test for method __float__ of class Price
def test_Price___float__():
    """Unit test for method __float__ of class Price"""

    from datetime import date
    from money import Price

    p1 = Price.of(USD, Decimal("1.23"), date.today())
    assert p1.__float__() == 1.23



# Generated at 2022-06-24 01:28:31.227196
# Unit test for method __add__ of class Price
def test_Price___add__():
    def test_Price___add__1(self):
        # noinspection PyProtectedMember
        self.assertEqual(Price.of(Currency.of("USD"), Decimal("10.00"), Date.of(2016, 1, 1)) + Price.of(Currency.of("USD"), Decimal("10.00"), Date.of(2016, 1, 2)), Price.of(Currency.of("USD"), Decimal("20.00"), Date.of(2016, 1, 2)))
    
    