

# Generated at 2022-06-24 01:18:32.742717
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    dt_x = datetime.date(2019, 1, 2)
    none_price = NonePrice()
    none_price2 = none_price.with_dov(dt_x)
    assert none_price.dov == dt_x
    assert type(none_price2) == NonePrice


# Generated at 2022-06-24 01:18:40.007389
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert Nothing >= Nothing == True
    assert Nothing >= Something(Currency.USD, 1.0, Date.today()) == False

    assert Something(Currency.USD, 1.0, Date.today()) >= Nothing == True
    assert Something(Currency.USD, 1.0, Date.today()) >= Something(Currency.USD, 1.0, Date.today()) == True

    assert Something(Currency.USD, 1.0, Date.today()) >= Something(Currency.USD, 0.0, Date.today()) == True
    assert Something(Currency.USD, 1.0, Date.today()) >= Something(Currency.USD, 2.0, Date.today()) == False


# Generated at 2022-06-24 01:18:41.948748
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    assert int(SomeMoney(USD, Decimal(1), Date(2018, 9, 15))) == 1


# Generated at 2022-06-24 01:18:54.703500
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20))) == 1
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20)).round()) == 1
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20)).round(1)) == 1
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20)).round(2)) == 1
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20)).round(3)) == 1
    assert int(SomeMoney(USD, Decimal("1.2234"), date(2019, 3, 20)).round(4)) == 1

# Generated at 2022-06-24 01:18:57.184671
# Unit test for method multiply of class Price
def test_Price_multiply():
    test_Price=PriceOf(ccy=USD,value=1,date=Date(2018,1,1))
    factor=Decimal(2)
    result=PriceOf(ccy=USD,value=2,date=Date(2018,1,1))
    assert test_Price.multiply(factor)==result
assert test_Price_multiply()

# Generated at 2022-06-24 01:19:01.524121
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from martin_fowler.money.currencies import Currency
    from martin_fowler.money.money import Money
    CNY = Currency.of("CNY")
    M = Money.of(CNY, 1, Date.today())
    assert (M * 1) == M
    assert (M * 1) == M
    assert (M * 1) == M

# Generated at 2022-06-24 01:19:08.573004
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    c, q, d = Currency("USD"), Decimal("10.00"), Date.today()
    a = SomeMoney(c, q, d)
    b = SomeMoney(c, q, d)
    res = a - b
    assert res.ccy == c
    assert res.qty == Decimal("0.00")
    assert res.dov == d
    assert res.defined == True
    assert res.undefined == False


# Generated at 2022-06-24 01:19:11.928702
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    m = Money.of('USD', 100, Date.today())
    r = m.convert('GBP', Date.today())
    assert str(r) == "GBP 74.95"


# Generated at 2022-06-24 01:19:13.606979
# Unit test for method subtract of class Price
def test_Price_subtract():
    # TODO: Add your implementation code here
    pass

# Generated at 2022-06-24 01:19:16.712891
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    # FIXME: Implement unit test
    pass

# Generated at 2022-06-24 01:19:20.206166
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    m = SomeMoney(CAD, Decimal(0), None)
    assert m.__bool__() is False

    m = SomeMoney(CAD, Decimal(0.3), None)
    assert m.__bool__() is True



# Generated at 2022-06-24 01:19:26.273334
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    ## Arrange:
    ccy, qty, dov = Currency.EUR, Decimal(1.234), datetime.date(2019, 4, 1)

    ## Act:
    m = SomeMoney(ccy, qty, dov)

    ## Assert:
    assert SomeMoney(ccy, abs(qty), dov) == m.__abs__()


# Generated at 2022-06-24 01:19:37.416125
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    """
    Tests: NonePrice.__floordiv__
    """
    from . import Numeric

    # Test cases that are expected to pass:
    pass_cases: List[Tuple[Any, Any]] = [
    ]

    for arg in pass_cases:
        assert isinstance(NonePrice.__floordiv__(*arg), Price)

# Generated at 2022-06-24 01:19:40.477581
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert Money.NA.as_integer() == 0
    assert Money(Currency.USD, 9).as_integer() == 9


# Generated at 2022-06-24 01:19:43.897696
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    m = SomeMoney(USD, Decimal("1.6789"), Date(2019, 12, 31))
    assert m.round(2) == SomeMoney(USD, Decimal("1.67"), Date(2019, 12, 31))

# Generated at 2022-06-24 01:19:49.157005
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    ccy = Currency("XXX")
    qty = Decimal("1")
    dov = Date(year=2020, month=1, day=1)
    money = SomeMoney(ccy, qty, dov)

    assert not bool(NoneMoney())
    assert not NoneMoney() < money
    assert not NoneMoney() <= money
    assert not NoneMoney() > money
    assert NoneMoney() >= money


# Generated at 2022-06-24 01:19:53.141080
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    currency = Currency("CHF").quantize(0.0001)
    string_date = "2018-01-01"

    money1 = currency(2, string_date)
    money2 = currency(3, string_date)

    result = money1 + money2
    assert isinstance(result, Money)
    assert result.ccy == currency
    assert result.qty == 5
    assert result.dov == datetime.date(2018, 1, 1)


# Generated at 2022-06-24 01:19:54.858172
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    assert isinstance(NoMoney.__pos__(), Money)
    assert NoMoney.__pos__() == NoMoney


# Generated at 2022-06-24 01:19:56.432308
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    ## Tests just return None
    pass


# Generated at 2022-06-24 01:19:59.497194
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    pass


# Generated at 2022-06-24 01:20:08.662921
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    from decimal import Decimal as D

    assert NoneMoney - NoneMoney is NoneMoney
    assert NoneMoney - SomeMoney(EUR, D('1'), Date.today()) == SomeMoney(EUR, D('-1'), Date.today())
    assert SomeMoney(EUR, D('1'), Date.today()) - NoneMoney == SomeMoney(EUR, D('1'), Date.today())
    assert SomeMoney(EUR, D('2'), Date.today()) - SomeMoney(EUR, D('2'), Date.today()) == NoneMoney

    assert NoneMoney - SomeMoney(EUR, D('1e-16'), Date.today()) == SomeMoney(EUR, D('-1e-16'), Date.today())

# Generated at 2022-06-24 01:20:15.688582
# Unit test for method add of class Price
def test_Price_add():
    usd = Currency.of("USD")
    p1 = Price.of(usd, Decimal("10.00"), today)
    p2 = Price.of(usd, Decimal("30.00"), later)
    p3 = Price.of(usd, Decimal("40.00"), later)
    p4 = Price.of(Currency.of("AED"), Decimal("10.00"), today)
    p5 = Price.of(None, None, None)
    p6 = Price.of(usd, None, today)
    p7 = Price.of(None, Decimal("10.00"), today)
    p8 = Price.of(usd, Decimal("10.00"), None)

    assert Price.of(usd, Decimal("40.00"), later) == p1.add(p2)

# Generated at 2022-06-24 01:20:26.851317
# Unit test for method __float__ of class Money
def test_Money___float__():
    from .currencies import base
    from .exchange import FXRateService
    from .money import Money, SomeMoney
    from .prices import Price, SomePrice
    from .zeitgeist import Date

    ccy = base()
    dov = Date.today
    fxs = FXRateService()

    assert(Money.of(ccy, 0, dov).__float__() == 0.0)
    assert(Money.of(ccy, Decimal(10), dov).__float__() == 10.0)
    assert(Money.of(ccy, Decimal(10.1234), dov).__float__() == 10.1234)
    assert(Money.of(ccy, Decimal(-10), dov).__float__() == -10.0)

# Generated at 2022-06-24 01:20:30.594015
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    # Test case data
    value1 = SomePrice(GBP, 2, Date(2020, 5, 9))
    expected1 = SomePrice(GBP, 2, Date(2020, 5, 9))
    # Perform the test
    assert expected1 == value1.__abs__()


# Generated at 2022-06-24 01:20:35.464185
# Unit test for constructor of class SomePrice
def test_SomePrice():
    assert SomePrice(Currency("USD"), Decimal("1.5"), date(2019, 12, 12)) == SomePrice(Currency("USD"), Decimal("1.5"), date(2019, 12, 12))


# Generated at 2022-06-24 01:20:42.861024
# Unit test for method positive of class Price
def test_Price_positive():
    a = Price.of('USD',Decimal(1),date(2019,4,4))
    assert a.positive() == Price.of('USD',Decimal(1),date(2019,4,4))
    assert a.positive().ccy == 'USD'
    assert a.positive().qty == Decimal(1)
    assert a.positive().dov == date(2019,4,4)


# Generated at 2022-06-24 01:20:54.458399
# Unit test for method __le__ of class NoneMoney
def test_NoneMoney___le__():
    """Unit test for method ``__le__`` of class ``NoneMoney``."""
    eq_(Money.of(USD, Decimal("100.00"), Date.today()).__le__(Money.of(USD, Decimal("100.00"), Date.today())), True)
    eq_(Money.of(USD, Decimal("100.00"), Date.today()).__le__(Money.of(USD, Decimal("100.01"), Date.today())), True)
    eq_(Money.of(USD, Decimal("100.01"), Date.today()).__le__(Money.of(USD, Decimal("100.00"), Date.today())), False)

# Generated at 2022-06-24 01:20:56.977276
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    # Negative of undefined price
    _NoPrice__undefined__SomePrice__ishidden = Price.NA
    NoPrice__undefined__SomePrice__ishidden = _NoPrice__undefined__SomePrice__ishidden
    SomePrice__ishidden = NoPrice__undefined__SomePrice__ishidden
    assert - SomePrice__ishidden == NoPrice

# Generated at 2022-06-24 01:20:58.880337
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    raise RuntimeError("Method test_SomeMoney___le__ has not been implemented")


# Generated at 2022-06-24 01:21:08.107800
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    """
    Just a unit test for method with_qty of class Price for now.
    """
    result = Price.of(USD, 1.0, Date.current()).with_qty(2.0)
    assert result == Price.of(USD, 2.0, Date.current())

    result = Price.of(USD, 1.0, Date.current()).with_qty(Decimal("2.0"))
    assert result == Price.of(USD, Decimal("2.0"), Date.current())

    result = Price.of(USD, Decimal("1.0"), Date.current()).with_qty(Decimal("2.0"))
    assert result == Price.of(USD, Decimal("2.0"), Date.current())


# Generated at 2022-06-24 01:21:13.670741
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    m = Money.of(GBP, Decimal(3.45), Date.today())
    assert m.scalar_add(10) == Money.of(GBP, Decimal(13.45), Date.today())
    assert m.scalar_add(10.5) == Money.of(GBP, Decimal(13.95), Date.today())
    assert m.scalar_add('10.5') == Money.of(GBP, Decimal(13.95), Date.today())
    assert m.scalar_add(Money.of(USD, Decimal(10.5), Date.today())) == Money.of(GBP, Decimal(13.95), Date.today())


# Generated at 2022-06-24 01:21:19.098144
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    ## Arrange:
    ccy = Currency.get_default()
    m = SomeMoney(ccy, Decimal("123456789.123456789"), Date(2020, 7, 26))
    # Act:
    result = m.__mul__(2)
    # Assert:
    assert result.ccy.name == "EUR"
    assert result.qty.__unicode__() == "246913578.2500000000"
    assert result.dov == Date(2020, 7, 26)


# Generated at 2022-06-24 01:21:30.748290
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    """
    Tests the method __lt__ of class Money
    """
    c = Currency('ccy')
    m0 = NoneMoney
    m1 = SomeMoney(ccy=c, qty=Decimal('10'), dov=Date(2001, 1, 1))
    m2 = SomeMoney(ccy=c, qty=Decimal('20'), dov=Date(2002, 1, 1))
    m3 = SomeMoney(ccy=c, qty=Decimal('15'), dov=Date(2003, 1, 1))

    # Test 1-1: Comparison for undefined vs undefined
    assert (m0 < m0) == False

    # Test 1-2: Comparison for undefined vs defined
    assert (m0 < m1) == True

    # Test 1-3: Comparison for defined vs undefined

# Generated at 2022-06-24 01:21:35.140811
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    assert (Money(Currency("USD"), Decimal(10), Date(2019, 11, 1)) / Decimal(2.5) == Money(Currency("USD"), Decimal(4), Date(2019, 11, 1)))



# Generated at 2022-06-24 01:21:38.932224
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    ccy = Currency("USD")
    assert SomeMoney(ccy, Decimal("10"), Date(2010, 1, 1)) < SomeMoney(ccy, Decimal("20"), Date(2010, 1, 1))



# Generated at 2022-06-24 01:21:41.984881
# Unit test for method as_float of class Money
def test_Money_as_float():
    money = Money.of("EUR", 20.3, Date(2000, 1, 1))
    assert money.as_float() == 20.3

# Generated at 2022-06-24 01:21:53.408435
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    # Arrange
    m1 = SomeMoney(EUR, Decimal(123), Date.today())
    m2 = SomeMoney(USD, Decimal(123), Date.today())

    # Act
    m3 = m1.scalar_add(1)
    m4 = m2.scalar_add(1)

    # Assert
    assert m1.qty == Decimal(123)
    assert m2.qty == Decimal(123)
    assert m1.ccy == EUR
    assert m2.ccy == USD

    assert m3.qty == Decimal(124)
    assert m4.qty == Decimal(124)
    assert m3.ccy == EUR
    assert m4.ccy == USD
    assert m3.dov == Date.today()

# Generated at 2022-06-24 01:22:02.819135
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    #
    # Undefined Money object
    #
    money1: Money = Money.NA
    result = abs(money1)
    # The value of money1 remains unchanged.
    assert money1 is Money.NA
    # The result is an undefined Money object.
    assert result is Money.NA
    # The result is not None.
    assert result is not None
    # The currency of the result is None.
    assert result.ccy is None
    assert result.ccy is None
    # The quantity of the result is None.
    assert result.qty is None
    assert result.qty is None
    # The DOV of the result is None.
    assert result.dov is None
    assert result.dov is None
    # The result is undefined.
    assert result.undefined
    # The result is not defined.


# Generated at 2022-06-24 01:22:09.917018
# Unit test for method subtract of class Money
def test_Money_subtract():
    import pytest
    from pymonads import Just, Nothing
    from pymonads.tools import do, caseof
    from pymonads.types import Option

    from finstmt import Currency, Date, Money, SomeMoney, Money
    from finstmt.exchange import FXRateService


# Generated at 2022-06-24 01:22:11.585144
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    price = Price.of(USD, Decimal("0.9"), Date.today())
    assert price.__gt__(Price.of(USD, Decimal("0.8"), Date.today()))

# Generated at 2022-06-24 01:22:20.555933
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    m = Money(0, {})

    # Call method
    m.__gt__(0)
    
    for x in [0, '', b'', bytearray(b''), [], (), {}, set(), range(0), MemoryView(b''), Money(0, {})]:
        try:
            m.__gt__(x)
            # Call method
        except Exception as ex:
            print(type(ex).__name__ + ' raised')
            # Log
            raise AssertionError(str(ex))
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 01:22:27.572654
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    """
    Check basic conversion of NoneMoney
    """
    # Arrange
    from_: Money = NoMoney
    to: Currency = "EUR"
    asof: Optional[Date] = datetime(2018, 1, 1)
    # Act
    actual: Money = from_.convert(to, asof)
    # Assert
    assert actual == NoMoney

# Generated at 2022-06-24 01:22:33.218463
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    """Unit test for method __lt__ of class NoneMoney"""
    # Initialize objects and variables

    m0 = Money.of(USD,0,Date(1970,1,1))

    m1 = Money.of(USD,10,Date(1970,1,1))

    # Test method
    testname = "NoneMoney.__lt__"

    m0.__lt__(m1)

    # Return Error if any
    return None


# Generated at 2022-06-24 01:22:39.812434
# Unit test for method as_float of class Price
def test_Price_as_float():
    ccy = Currency.of("EUR")
    qty = Decimal(10.50).quantize(Q_2)
    dov = Date(2020,5,5)
    p:SomePrice = SomePrice(ccy, qty, dov)
    assert p.as_float() == 10.50

    assert (NoPrice.as_float() == Decimal(0)).all()


# Generated at 2022-06-24 01:22:52.256178
# Unit test for method gte of class Price
def test_Price_gte():
    """
    Test for method gte of class Price
    """
    x = Price(USD, 100, '2001-01-01')
    y = Price(USD, 100, '2001-01-01')
    assert (x.gte(y) == True)
    x = Price(USD, 100, '2001-01-01')
    y = Price(USD, 200, '2001-01-01')
    assert (x.gte(y) == False)
    x = Price(USD, 200, '2001-01-01')
    y = Price(USD, 100, '2001-01-01')
    assert (x.gte(y) == True)
    x = Price(USD, 100, '2001-01-01')
    y = Price(USD, 'NA', 'NA')

# Generated at 2022-06-24 01:23:03.038166
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 100, TODAY))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 100, TOMORROW))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 100, TODAY))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 100, TOMORROW))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 99, TODAY))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 99, TOMORROW))
    assert Price.of(USD, 100, TODAY).gte(Price.of(USD, 100, TODAY))

# Generated at 2022-06-24 01:23:09.012648
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    assert NoneMoney.scalar_subtract(NoneMoney(),1) == NoneMoney()
    assert NoneMoney.scalar_subtract(NoneMoney(),1.01) == NoneMoney()
    assert NoneMoney.scalar_subtract(NoneMoney(),"1.01") == NoneMoney()
    assert NoneMoney.scalar_subtract(NoneMoney(),Decimal("1.01")) == NoneMoney()

# Generated at 2022-06-24 01:23:19.332417
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    m1 = Money.of(Currency.USD, 819829.9, Date.today())
    m2 = Money.of(Currency.USD, 8198, Date.today())
    m3 = Money.NA
    p1 = Price.of(Currency.USD, 1.2, Date.today())
    p2 = Price.of(Currency.USD, 0.0, Date.today())
    p3 = Price.NA
    assert int(m1) == 819829
    assert int(m2) == 8198
    assert int(m3) is None
    assert int(p1) == 1
    assert int(p2) == 0
    assert int(p3) is None

# Generated at 2022-06-24 01:23:24.152969
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    ccy = Currency.AED
    qty = Decimal(100)
    dov = Date.today()

    ccy1 = Currency.EUR
    qty1 = Decimal(100)
    dov1 = Date.today()

    ccy2 = ccy
    qty2 = qty
    dov2 = dov

    ccy3 = ccy1
    qty3 = qty1
    dov3 = dov1

    assert SomeMoney(ccy, qty, dov).with_ccy(ccy1) == SomeMoney(ccy1, qty, dov)
    assert SomeMoney(ccy1, qty1, dov1).with_ccy(ccy2) == SomeMoney(ccy2, qty1, dov1)

# Generated at 2022-06-24 01:23:27.067394
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    assert (+NoMoney) == NoMoney


# Generated at 2022-06-24 01:23:30.337909
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    ## TODO
    assert True



# Generated at 2022-06-24 01:23:39.407437
# Unit test for method __lt__ of class Price
def test_Price___lt__():

    assert Price.of(ccy='USD', qty=Decimal('0.98'), dov=Date(2018, 1, 1)) < Price.of(ccy='USD', qty=Decimal('0.99'), dov=Date(2018, 1, 1))
    assert Price.of(ccy='USD', qty=Decimal('0.98'), dov=Date(2018, 1, 1)) < Price.of(ccy='USD', qty=Decimal('0.99'), dov=Date(2017, 1, 1))
    assert not (Price.of(ccy='USD', qty=Decimal('0.98'), dov=Date(2018, 1, 1)) < Price.of(ccy='USD', qty=Decimal('0.98'), dov=Date(2018, 1, 1)))

# Generated at 2022-06-24 01:23:46.128740
# Unit test for method lte of class Price
def test_Price_lte():
    assert Price.of(Currency('USD'), Decimal('1'), Date(2018, 1, 1)).lte(
        Price.of(Currency('USD'), Decimal(1), Date(2018, 1, 1))
    )
    assert Price.of(Currency('USD'), Decimal('1'), Date(2018, 1, 1)).lte(
        Price.of(Currency('USD'), Decimal('1.1'), Date(2018, 1, 1))
    )
    with pytest.raises(IncompatibleCurrencyError, match='Incompatible currencies'):
        Price.of(Currency('USD'), Decimal(1), Date(2018, 1, 1)).lte(
            Price.of(Currency('EUR'), Decimal(1), Date(2018, 1, 1))
        )


# Generated at 2022-06-24 01:23:54.035574
# Unit test for method round of class Price
def test_Price_round():
    import sys
    import random
    import math
    import decimal
    import pytest

    def assert_equals(expected, actual):
        # type: (Price, Price) -> None
        assert expected == actual, "Expected %s, got %s" % (expected, actual)

    def round_half_even(n):
        # type: (int) -> int
        return round(n, 0)

    def round_half_up(n):
        # type: (int) -> int
        return math.ceil(n)
        # if n != n.to_integral_value():
        #     if n >= 0:
        #         return int(n) + 1
        #     else:
        #         return int(n) - 1
        # else:
        #     return int(n)


# Generated at 2022-06-24 01:23:56.950594
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    np = NonePrice()
    np1 = np.__neg__()
    assert not np1.defined
    assert np1.undefined


# Generated at 2022-06-24 01:24:00.929731
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    s = SomePrice(USD, Decimal(0.2362), get_today())
    assert s.times(1) == Money(USD, Decimal(0.2362), get_today())
    assert s.times(0.0) == Money(USD, Decimal(0.0), get_today())



# Generated at 2022-06-24 01:24:10.128603
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    import pytest
    from decimal import Decimal
    from smm.monetary.money import Money, NoneMoney, SomeMoney
    from smm.fx.rates import FXRate

    class FXRateService:
        @staticmethod
        def query(
            ccy1: str, ccy2: str, asof: Optional[Date] = None, strict: bool = False) -> Optional[FXRate]:
            return None

    NoneMoney.__mul__(NoneMoney, Decimal("2"))



# Generated at 2022-06-24 01:24:20.109648
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    # Test with undefined money
    assert NoMoney == NoMoney
    assert NoMoney == NoneMoney
    assert NoMoney == NoPrice
    assert NoMoney == NonePrice
    assert NoMoney == 0
    assert NoMoney == 0.0
    assert NoMoney is not 0

    # Test with defined money
    assert SomeMoney(Currency("USD"), 1, Date.today()) == SomeMoney(Currency("USD"), 1, Date.today())
    assert SomeMoney(Currency("USD"), 1, Date.today()) is not SomeMoney(Currency("USD"), 1, Date.today())
    assert SomeMoney(Currency("USD"), 1, Date.today()) == 1.0
    assert SomeMoney(Currency("USD"), 1, Date.today()) == 1

# Generated at 2022-06-24 01:24:23.078931
# Unit test for method negative of class Money
def test_Money_negative():
    assert (Money.of(Currency.USD, -100, Date(2018, 4, 1)) == -Money.of(Currency.USD, 100, Date(2018, 4, 1))).value

# Generated at 2022-06-24 01:24:27.187120
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    from .money import NoMoney
    from numpy import isnan
    from math import nan
    assert isnan(float(NoMoney / 100.))


# Generated at 2022-06-24 01:24:31.626979
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    result = Money.of(Currency.of("USD"), Decimal("1234.5"), Date.today()).__pos__()
    # isinstance(result, Money)
    assert isinstance(result, Money)



# Generated at 2022-06-24 01:24:43.281275
# Unit test for method __sub__ of class Price
def test_Price___sub__():
  def __sub__(self, other: "Price") -> "Price":
    # If the currency of the price is not equal to the currency of the
    # argument, then raise an IncompatibleCurrencyError
    if self.ccy != other.ccy:
      raise IncompatibleCurrencyError('Cannot subtract two price objects with different currencies')
    
    # If either self or other is undefined, return the other price
    if not self.defined:
      return other
    if not other.defined:
      return self

    # Return a new price with self.ccy, self.qty - other.qty, and self.dov
    return self.__class__(self.ccy, self.qty - other.qty, self.dov)



# Generated at 2022-06-24 01:24:51.959878
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    # Initialization ...
    #######################
    ccy = Currency("USD")
    qty = Decimal("1234.5600")
    dov = Date("2020-07-21")
    money = SomeMoney(ccy, qty, dov)
    #######################

    # Testing ...
    #######################
    (int(money))
    #######################

    # Verification ...
    #######################
    assert True
    #######################

    # Clean up ...
    #######################
    #######################


# Generated at 2022-06-24 01:24:54.296503
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    print("Unit test for the with_dov method of class NonePrice")

    l = NonePrice
    assert (l.with_dov(Date(2018, 4, 14)) == NonePrice)


# Generated at 2022-06-24 01:25:04.636355
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Test method __add__ of class NoneMoney.
    """
    V = NoneMoney()
    V.__add__(V)
    V.__add__(None)
    V.__add__(10)
    V.__add__(10.0)
    V.__add__('10')

    V.__add__(Money(Currency.USD, 10))
    V.__add__(Money(Currency.USD, 10.0))
    V.__add__(Money(Currency.USD, '10'))
    V.__add__(Money(Currency.USD, 10, asof=Date(20200101)))
    V.__add__(Money(Currency.USD, 10.0, asof=Date(20200101)))

# Generated at 2022-06-24 01:25:06.916872
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    np = NonePrice()
    assert np.scalar_add(1) == np


# Generated at 2022-06-24 01:25:13.321580
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    ccy_A = Currency.from_iso('A')
    ccy_B = Currency.from_iso('B')
    date = Date.from_iso('2020-02-20')
    NonePrice = Price.of(ccy_A, None, date)
    assert NonePrice.convert(ccy_B, date) == Price.of(ccy_B, None, date)


# Generated at 2022-06-24 01:25:17.802194
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__():

    from itertools import product

    with pytest.raises(TypeError):
        assert isinstance(NoMoney.__floordiv__(NoMoney, None), Money)


# Generated at 2022-06-24 01:25:22.167157
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    """
    Test for method SomePrice.__mul__
    """
    p1 = SomePrice(USD, 1000, Date(2017, 1, 1))
    assert p1 * 2 == SomePrice(USD, 2000, Date(2017, 1, 1))



# Generated at 2022-06-24 01:25:28.822414
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    assert SomeMoney(USD, 1.00, Date(2018, 1, 1)).__sub__(SomeMoney(USD, 2.00, Date(2018, 1, 1))) == SomeMoney(USD, -1.00, Date(2018, 1, 1))

    with raises(IncompatibleCurrencyError):
        SomeMoney(USD, 1.00, Date(2018, 1, 1)).__sub__(SomeMoney(AUD, 1.00, Date(2018, 1, 1)))



# Generated at 2022-06-24 01:25:34.160684
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    pass


# Case: Undefined money
test_m_1 = NoMoney


# Case: Some money
test_m_2 = SomeMoney(Currency.of("USD"), Decimal(1.1), Date.today())


# Expectation: False
expect(test_m_1.as_boolean()) == False

# Expectation: True
expect(test_m_2.as_boolean()) == True

# Generated at 2022-06-24 01:25:43.685665
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert (NoMoney.is_equal(NoMoney)==True)
    assert (NoMoney.is_equal(SomeMoney(Currency.USD,1,Date.today()))==False)
    assert (SomeMoney(Currency.USD,1,Date.today()).is_equal(NoMoney)==False)
    assert (SomeMoney(Currency.USD,1,Date.today()).is_equal(SomeMoney(Currency.USD,1,Date.today()))==True)
    assert (SomeMoney(Currency.USD,1,Date.today()).is_equal(SomeMoney(Currency.CAD,1,Date.today()))==False)
    assert (SomeMoney(Currency.USD,1,Date.today()).is_equal(SomeMoney(Currency.USD,1,Date.yesterday()))==False)

# Generated at 2022-06-24 01:25:51.490170
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    a: Price = Price.of(ccy=USD, qty=Decimal("1.23"), dov=Date(2020, 1, 1))
    b: Price = Price.of(ccy=EUR, qty=Decimal("1.23"), dov=Date(2020, 1, 1))
    c: Price = Price.of(ccy=USD, qty=Decimal("1.23"), dov=Date(2020, 1, 1))
    d: Price = Price.of(ccy=USD, qty=Decimal("2.46"), dov=Date(2020, 1, 1))
    e: Price = Price.of(ccy=USD, qty=Decimal("0.61"), dov=Date(2020, 1, 1))
    assert not (Price.NA > Price.NA)

# Generated at 2022-06-24 01:26:00.639245
# Unit test for method add of class Price
def test_Price_add():
    # Test the add method for when one of the two prices is empty
    USD = Currency.of('USD')
    EUR = Currency.of('EUR')
    now = Date.today()
    
    price1 = Price.of(USD, Decimal(10), now)
    price2 = Price.of(EUR, Decimal(25), now)
        
    res = price1.add(price2)
    assert(res.undefined)
    assert(res.dov == now)
    assert(res.ccy == USD)
    assert(res.qty == Decimal(10))
    
    res = price2.add(price1)
    assert(res.undefined)
    assert(res.dov == now)
    assert(res.ccy == EUR)

# Generated at 2022-06-24 01:26:03.947451
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    # TODO: Implement this unit test
    pass

# Generated at 2022-06-24 01:26:05.388071
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    money = NoneMoney()
    other = Decimal()
    
    money.scalar_subtract(other)


# Generated at 2022-06-24 01:26:09.673946
# Unit test for method subtract of class Money
def test_Money_subtract():
    assert SomeMoney(Currency.USD, Decimal(20), Date(2020, 7, 1)).subtract(SomeMoney(Currency.USD, Decimal(10), Date(2020, 7, 1))) == SomeMoney(Currency.USD, Decimal(10), Date(2020, 7, 1))

# Generated at 2022-06-24 01:26:13.205939
# Unit test for method subtract of class Money
def test_Money_subtract():
    print("\nUnittest for Money.subtract() method of class Money")
    try:
        assert SomeMoney("EUR", Decimal(1), Date.today()).subtract(SomeMoney("EUR", Decimal(2), Date.today())) == NoMoney
        print("    Money.subtract() method of class Money is tested successfully")
    except:
        print("    Money.subtract() method of class Money is failed")


# Generated at 2022-06-24 01:26:17.127392
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert NoneMoney().__neg__() == NoMoney, "Satisfy 1"
    assert Money(1234, 'USD').__neg__() == Money(-1234, 'USD'), 'Satisfy 2'

# Generated at 2022-06-24 01:26:18.333513
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    pass


# Generated at 2022-06-24 01:26:21.406758
# Unit test for method negative of class Money
def test_Money_negative():
    from . import Money

    m = Money(Currency('USD'), 1, '2020-03-14')
    assert m.negative().qty == -1



# Generated at 2022-06-24 01:26:28.249834
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    price = SomePrice(CNY, Decimal(12.34), Date.today())
    assert price.round(2) == SomePrice(CNY, Decimal(12.34), Date.today())
    assert price.round(0) == SomePrice(CNY, Decimal(12), Date.today())
    assert price.round() == SomePrice(CNY, Decimal(12), Date.today())

# Generated at 2022-06-24 01:26:35.645751
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    dov = Date.now()
    ccy = Currency.get("USD")
    one = Price.of(ccy, 1, dov)
    assert one.as_boolean()
    assert bool(one)

    zero = Price.of(ccy, 0, dov)
    assert not zero.as_boolean()
    assert not bool(zero)

    undef = Price.of(ccy, None, dov)
    assert not undef.as_boolean()
    assert not bool(undef)

# Generated at 2022-06-24 01:26:36.922512
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    pass


# Generated at 2022-06-24 01:26:41.255920
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    money = Money.of(EUR, None, None)
    expected = 0.0
    actual = money.as_float()
    assert expected == actual
# class Money



# Generated at 2022-06-24 01:26:47.369196
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    SomePrice(USD, 1.0, TODAY)
    assert True == SomePrice(USD, 1.0, TODAY).__bool__()
    assert False == SomePrice(USD, 0.0, TODAY).__bool__()
    assert False == NoPrice.__bool__()


# Generated at 2022-06-24 01:26:51.018223
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    assert (NoPrice > NoPrice.__class__(CNY, 1, datetime.date(2019, 1, 1)))



# Generated at 2022-06-24 01:26:58.340062
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    """
    Unit test for method with_qty of class NoneMoney.
    """
    from datetime import date
    from abc import ABC, abstractmethod
    from decimal import Decimal
    from dataclasses import dataclass
    from typing import Optional
    from pytest import raises
    from datetime import date
    from decimal import Decimal
    from dataclasses import dataclass
    from typing import Optional
    from more import Money, Currency, to_money, NoMoney
    from pytest import raises


# Generated at 2022-06-24 01:27:01.693840
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    pass # TODO

# Generated at 2022-06-24 01:27:03.654241
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    assert NoMoney.with_qty(0).undefined


# Generated at 2022-06-24 01:27:08.710620
# Unit test for method round of class SomePrice
def test_SomePrice_round():
   x = SomePrice('EUR', Decimal('4.149'), date(2019, 3, 1))
   assert x.round() == 4
   assert x.round(0) == 4
   assert x.round(1) == SomePrice('EUR', Decimal('4.1'), date(2019, 3, 1))

# Generated at 2022-06-24 01:27:10.901109
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    assert abs(Price.of(None, None, None)) == Price.of(None, None, None)

# Generated at 2022-06-24 01:27:14.229495
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    with nose.tools.assert_raises(NotImplementedError):
        SomePrice(USD, FOUR, Date(2018, 12, 10)).__ge__(Price.NA)

# Generated at 2022-06-24 01:27:18.110758
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    from .currency import Currency
    from .date import Date
    from .price import NonePrice

    assert NonePrice(Currency("USD"), None, Date(2019, 1, 2)) == \
        NonePrice(Currency("USD"), None, Date(2019, 1, 2)).with_qty(None)

# Generated at 2022-06-24 01:27:21.072866
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    x = SomePrice(type(None), Decimal('100'), date(2020, 6, 27))
    assert x.__mul__(Decimal('2')) == SomePrice(type(None), Decimal('200'), date(2020, 6, 27))


# Generated at 2022-06-24 01:27:22.877591
# Unit test for method convert of class Money
def test_Money_convert():
    # Implicitly tested in other unit test modules.
    pass

# Generated at 2022-06-24 01:27:33.310232
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    from decimal import Decimal
    from pymonad.Maybe import Nothing
    from pymonad.Either import Left
    no_price = NonePrice()
    assert no_price * 1 == NoPrice
    assert no_price * 1.0 == NoPrice
    assert no_price * Decimal(1) == NoPrice
    assert no_price * Nothing == NoPrice
    assert no_price * Left("foo") == NoPrice
    assert NoPrice * 1 == NoPrice
    assert NoPrice * 1.0 == NoPrice
    assert NoPrice * Decimal(1) == NoPrice
    assert NoPrice * Nothing == NoPrice
    assert NoPrice * Left("foo") == NoPrice
    try:
        no_price * []
    except ValueError as exc:
        assert str(exc) == "Numeric values only."
    no_price = NonePrice

# Generated at 2022-06-24 01:27:40.866638
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    m = SomeMoney(USD, Decimal("1.234"), date(2020, 1, 1))
    assert m.__eq__(m) is True
    assert m == m
    assert m.__eq__(NoMoney) is False
    assert m != NoMoney

    assert m.__eq__(SomeMoney(USD, Decimal("1.234"), date(2020, 1, 1))) is True
    assert m.__eq__(SomeMoney(USD, Decimal("1.234"), date(2020, 1, 2))) is True
    assert m.__eq__(SomeMoney(USD, Decimal("1.235"), date(2020, 1, 1))) is True
    assert m.__eq__(SomeMoney(USD, Decimal("1.234"), date(2020, 1, 2))) is True


# Generated at 2022-06-24 01:27:43.931734
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    NonePrice().times(1)
    NonePrice()*1
    1*NonePrice()
    with raises(InvalidOperation):
        NonePrice()/1
    with raises(InvalidOperation):
        1/NonePrice()


# Generated at 2022-06-24 01:27:51.751052
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    # Test that the function runs without errors with 0.
    money = NoMoney.scalar_subtract(0)
    assert money is NoMoney
    # Test that the function runs without errors with 0.0.
    money = NoMoney.scalar_subtract(0.0)
    assert money is NoMoney
    # Test that the function runs without errors with Decimal(0).
    money = NoMoney.scalar_subtract(Decimal(0))
    assert money is NoMoney
    # Test that the function runs without errors with '0'.
    money = NoMoney.scalar_subtract('0')
    assert money is NoMoney
    # Test that the function runs without errors with '0.0'.
    money = NoMoney.scalar_subtract('0.0')
    assert money is No

# Generated at 2022-06-24 01:27:55.684442
# Unit test for method __float__ of class Money
def test_Money___float__():
    money = Money.of(None, Decimal("8.0123"), None)
    assert(float(money) == 8.0123)

# Generated at 2022-06-24 01:28:00.541598
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    from finpy.money import SomeMoney

    assert SomeMoney(Currency.of("USD"), Decimal("1.0"), Date.now()).__bool__() == True
    assert SomeMoney(Currency.of("USD"), Decimal("0.0"), Date.now()).__bool__() == False

# Generated at 2022-06-24 01:28:01.876644
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    pass


# Generated at 2022-06-24 01:28:13.944636
# Unit test for method positive of class Money
def test_Money_positive():
    from .test_currencies import EUR
    d = Date.today()
    # Check no money
    assert NoMoney.positive() is NoMoney
    # Check undefined money
    assert NoneMoney.positive() is NoneMoney
    # Check defined money
    m0 = Money.of(EUR, None, d)
    assert m0.positive() is m0
    assert m0.positive() is not m0
    # Check equality
    assert m0 is not m0.positive()
    m = Money.of(EUR, 100, d)
    assert m is not m.positive()
    assert m.positive() == m
    assert m == m.positive()
    assert m.qty == m.positive().qty
    assert m.dov == m.positive().dov
    assert m.ccy == m.positive().ccy


# Generated at 2022-06-24 01:28:26.045332
# Unit test for method __float__ of class Price
def test_Price___float__():
    # TemplateTypeVar
    from typing import TypeVar
    A = TypeVar("A", bound="Price")
    # TemplateFunctionVariable
    from decimal import Decimal
    from datetime import date
    from test_templates import currency, undefined_price
    from test_templates import defined_price
    from test_templates import undefined_price_object_that_implies_false
    from test_templates import defined_price_object_that_implies_true
    from test_templates import value_assertion

    T = TypeVar("T", bound="UndefinedPrice")
    T_co = TypeVar("T_co", covariant=True, bound="UndefinedPrice")

    # Case 1: undefined price
    pytest.raises(TypeError, lambda: undefined_price_object_that_implies_false().__float__())



# Generated at 2022-06-24 01:28:27.039945
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    pass



# Generated at 2022-06-24 01:28:34.430324
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    p1 = SomePrice(USD, Decimal("1.5"), Date(2000, 1, 1))
    assert p1.round() == SomePrice(USD, Decimal("2"), Date(2000, 1, 1))
    assert p1.round(1) == SomePrice(USD, Decimal("1.5"), Date(2000, 1, 1))
    assert p1.round(2) == SomePrice(USD, Decimal("1.50"), Date(2000, 1, 1))
    assert p1.round(3) == SomePrice(USD, Decimal("1.500"), Date(2000, 1, 1))
