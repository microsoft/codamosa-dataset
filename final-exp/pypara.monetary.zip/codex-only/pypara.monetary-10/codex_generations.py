

# Generated at 2022-06-24 01:18:36.911223
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    ccy, qty, dov = (
        Currency("GBP"),
        Decimal("1.12"),
        date(2014, 11, 6)
    )
    price1 = SomePrice(ccy, qty, dov)
    price2 = SomePrice(ccy, qty, dov)
    assert (price1 >= price2) == True
    ccy, qty, dov = (
        Currency("GBP"),
        Decimal("1.12"),
        date(2014, 11, 6)
    )
    price1 = SomePrice(ccy, qty, dov)
    price2 = SomePrice(ccy, qty, dov)
    assert (price1 >= price2) == True

# Generated at 2022-06-24 01:18:37.964964
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass



# Generated at 2022-06-24 01:18:46.070515
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    # Test with a date
    p = NonePrice( )
    assert p >= NoPrice
    # Test with a date
    p = NonePrice( )
    assert p >= SomePrice(USD( ), 45.8, Date(2011, 12, 11))
    # Test with a date
    p = NonePrice( )
    assert p >= NoPrice
    # Test with a date
    p = NonePrice( )
    assert p >= NoPrice



# Generated at 2022-06-24 01:18:58.102551
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    assert Price.of(USD, 1.0, TODAY).scalar_subtract(1) == Price.of(USD, 0.0, TODAY)
    assert Price.of(USD, 1.0, TODAY).scalar_subtract(1.0) == Price.of(USD, 0.0, TODAY)
    assert Price.of(USD, Decimal("1.0"), TODAY).scalar_subtract(1) == Price.of(USD, 0.0, TODAY)
    assert Price.of(USD, Decimal("1.0"), TODAY).scalar_subtract(1.0) == Price.of(USD, 0.0, TODAY)

# Generated at 2022-06-24 01:18:58.570713
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    pass



# Generated at 2022-06-24 01:19:00.808776
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():

    assert NonePrice.with_qty(None)==NonePrice
    assert NonePrice.with_qty(Decimal(1))==NonePrice



# Generated at 2022-06-24 01:19:06.782937
# Unit test for method __le__ of class Money
def test_Money___le__():
    """
    Tests the method __le__ of class Money
    """
    from .currencies import currencies

    eur = currencies["eur"]
    eight = eur.new(8)
    eight_eur = eight.with_ccy(eur)
    eight_gbr = eight.with_ccy(currencies["gbr"])
    eight_usd = eight.with_ccy(currencies["usd"])
    eight_nok = eight.with_ccy(currencies["nok"])
    eight_nok_minus = eight.negative().with_ccy(currencies["nok"])
    assert bool(eight_eur) is True
    assert bool(eight_gbr) is True
    assert bool(eight_usd) is True
    assert bool(eight) is True

# Generated at 2022-06-24 01:19:09.860102
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():

    ## Setup:
    ccy = USD

    ## Exercise:
    p: Price = NoPrice.with_qty(10.0)

    ## Verify:
    assert p == NoPrice, "Expected the same value."
    assert p is NoPrice, "Expected the same instance."

# Generated at 2022-06-24 01:19:19.821430
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    from .currencies import HKD
    from .commons.zeitgeist import Date

    assert bool(Money.of(HKD, 0, Date.today())) is False
    assert bool(Money.of(HKD, -1, Date.today())) is False
    assert bool(Money.of(HKD, 1, Date.today())) is True
    assert bool(Money.of(HKD, Decimal("-1.00"), Date.today())) is False
    assert bool(Money.of(HKD, Decimal("1.00"), Date.today())) is True
    assert bool(Money.of(HKD, Decimal("1.50"), Date.today())) is True
    assert bool(Money.of(HKD, Decimal("1.51"), Date.today())) is True

# Generated at 2022-06-24 01:19:23.282767
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    from datetime import date
    from dolosse.enums import Currency

    assert NoneMoney.scalar_subtract(1) == NoMoney
    assert NoneMoney.scalar_subtract(1.1) == NoMoney
    assert NoneMoney.scalar_subtract(currency(Currency.USD)) == NoMoney
    assert NoneMoney.scalar_subtract(Money(Currency.USD, 1.1)) == NoMoney
    assert NoneMoney.scalar_subtract(date(2020, 1, 1)) == NoMoney

# Generated at 2022-06-24 01:19:34.376843
# Unit test for method add of class Money
def test_Money_add():
    """
    Checks the addition with respect to undefined money.
    """

    # Case 1: Both operands are NoneMoney:
    assert NoMoney + NoMoney == NoMoney

    # Case 2: First operand is NoneMoney:
    m1 = NoMoney
    m2 = SomeMoney(Currency("EUR"), 5, Date.of("2018-01-01"))
    m3 = m1 + m2
    assert isinstance(m3, Money)
    assert m3 == m2

    # Case 3: Second operand is NoneMoney:
    m1 = SomeMoney(Currency("EUR"), 5, Date.of("2018-01-01"))
    m2 = NoMoney
    m3 = m1 + m2
    assert isinstance(m3, Money)
    assert m3 == m1

    # Case 4: Both operands

# Generated at 2022-06-24 01:19:44.572223
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    assert Money.of(None, 1, Date.today()).scalar_add(1.1) == Money.of(None, Decimal('2.1'), Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).scalar_add(1.1) == Money.of(Currency.USD, Decimal('2.1'), Date.today())
    assert Money.of(None, None, Date.today()).scalar_add(1.1) == NoneMoney
    assert Money.of(None, 1, Date.today()).scalar_add(None) == NoneMoney
    assert Money.of(Currency.USD, 1, Date.today()).scalar_add(None) == NoneMoney
    assert Money.of(None, None, Date.today()).scalar_

# Generated at 2022-06-24 01:19:51.480999
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    ## Set up
    p = Price.of(USD, '10.00', '2020-01-01')
    ## Test
    negp = p.__neg__()
    ## Verify
    assert isinstance(negp, Price)
    assert negp.ccy == p.ccy
    assert negp.qty == -p.qty
    assert negp.dov == p.dov


## Unit test for method __pos__ of class Price

# Generated at 2022-06-24 01:19:53.607047
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    # Given
    a = NoMoney
    b = SomeMoney(USD, -10, TODAY)
    # When
    actual = a < b
    # Then
    assert actual



# Generated at 2022-06-24 01:19:56.796844
# Unit test for method abs of class Money
def test_Money_abs():
    money = Money(iso="EUR", qty=1.23)
    print(abs(money))
    print(money.abs())
    assert isinstance(money.abs(), Money)

# Generated at 2022-06-24 01:20:02.215585
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    obj = SomePrice(USD, Decimal("1"), today)
    assert obj > NoPrice
    assert obj > SomePrice(EUR, Decimal("1"), today)
    assert not obj > SomePrice(USD, Decimal("2"), today)


# Generated at 2022-06-24 01:20:05.983681
# Unit test for method round of class Money
def test_Money_round():
    money = Money.of(Currency.USD, Decimal('1.25'), Date.today())
    money = money.round(0)

    assert money.qty == Decimal('1')
    assert money.ccy == Currency.USD
    assert money.dov == Date.today()



# Generated at 2022-06-24 01:20:10.755402
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    # 1. Arrange
    money1 = NoMoney
    # 2. Act
    # 3. Assert
    result = money1.as_integer()

# Generated at 2022-06-24 01:20:13.208297
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    base_exception = MonetaryOperationException("message")
    assert base_exception.args == ("message",)
# End of unit test for constructor of class MonetaryOperationException



# Generated at 2022-06-24 01:20:16.327624
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    p1 = Price.of(USD,10,date.today())
    p2 = p1.scalar_add(10)
    assert p2.ccy == USD
test_Price_scalar_add()

# Generated at 2022-06-24 01:20:18.245148
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    Money.NA.scalar_subtract(0)



# Generated at 2022-06-24 01:20:19.731410
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    pass # Should be implemented.


# Generated at 2022-06-24 01:20:20.593228
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    '''
    Unit test for method times of class SomePrice
    '''
    pass


# Generated at 2022-06-24 01:20:22.377446
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    assert NoneMoney.with_dov(Date(2020, 1, 1)) == NoMoney

# Generated at 2022-06-24 01:20:28.595201
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import ZAR
    from .money import Money, SomeMoney, NA

    assert (SomeMoney(ZAR, 10, None) - NA) == NA

    assert (NA - SomeMoney(ZAR, 10, None)) == NA

    assert (NA - NA) == NA

    assert (SomeMoney(ZAR, 10, None) - SomeMoney(ZAR, 10, None)) == SomeMoney(ZAR, 0, None)



# Generated at 2022-06-24 01:20:29.534677
# Unit test for method __int__ of class Money
def test_Money___int__():
    pass



# Generated at 2022-06-24 01:20:40.812363
# Unit test for method __floordiv__ of class SomeMoney

# Generated at 2022-06-24 01:20:47.885323
# Unit test for method negative of class Price
def test_Price_negative():
    assert Price.of(None, None, None).negative() == Price.NA
    assert Price.of(None, Decimal("0.0"), None).negative() == Price.NA
    assert Price.of(None, Decimal("1234.5"), None).negative() == Price.NA
    assert Price.of(None, None, Date.min()).negative() == Price.NA
    assert Price.of(None, None, Date.max()).negative() == Price.NA
    assert Price.of(None, Decimal("0.0"), Date.min()).negative() == Price.NA
    assert Price.of(None, Decimal("1234.5"), Date.max()).negative() == Price.NA
    assert Price.of(None, Decimal("0.0"), Date.max()).negative() == Price.NA
    assert Price.of

# Generated at 2022-06-24 01:20:52.253505
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    ## Arrange ##
    m = SomeMoney(Currency("EUR"), Decimal("10.00"), Date.today())

    ## Act ##
    i = m.__int__()

    ## Assert ##
    assert i == 10


# Generated at 2022-06-24 01:20:56.902522
# Unit test for method multiply of class Money
def test_Money_multiply():
    from .currencies import USD, GBP
    from .exchange import FXRate
    from .core import Today
    from .core import Yesterday
    from .core import Tomorrow

    # Define FX rates.
    eurusd = FXRate(
        Date(2018, 10, 31),  # date
        USD,  # ccy1
        EUR,  # ccy2
        Decimal("1.14500")  # rate
    )
    usdgbp = FXRate(
        Date(2018, 10, 31),  # date
        GBP,  # ccy1
        USD,  # ccy2
        Decimal("1.29430")  # rate
    )
    fxrm = FXRateService.from_fxrates(eurusd, usdgbp)

    # Testing for Cases that is defined

# Generated at 2022-06-24 01:20:57.872810
# Unit test for constructor of class SomePrice
def test_SomePrice():
    pass

# Generated at 2022-06-24 01:21:07.334369
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    # Test a defined price object
    # Define an input argument:
    ccy = Currency.of("KRW")
    qty = Decimal(12345)
    dov = Date.today()
    price1 = SomePrice(ccy, qty, dov)
    price2 = price1._Price__neg__()
    assert isinstance(price2, SomePrice)
    assert price2.defined
    assert (price2.ccy == price1.ccy)
    assert (price2.qty == -price1.qty)
    assert (price2.dov == price1.dov)
    # Test an undefined price object
    price3 = NoPrice
    price4 = price3._Price__neg__()
    assert (price4 == NoPrice)
    return

# Generated at 2022-06-24 01:21:13.695987
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from pymonads import Identity, Just
    from pymonads import Container as ContainerMeta
    from pymonads import Option as OptionMeta
    from .currencies import USD
    from .exchange import FXRateService
    from .monetary import Money
    from .pipes import PipeFunc

    fx = FXRateService.empty.fx_rate_register(USD.as_ccy, USD.as_ccy, 1.0)
    p = PipeFunc.of_callable(lambda m: m.convert(USD, strict=False))

    money_fx_unpack_func = p(fx)  # PipeFunc[Money, Option[Money]]
    print(money_fx_unpack_func)  # PipeFunc(<function <lambda> at 0x10df8c7b8>, [])

    money_fx_

# Generated at 2022-06-24 01:21:15.773446
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    """Unit test for method __le__ of class SomeMoney
    """
    one_eos = Money.of(Currency.EOS, Decimal('1'), Date(2018, 11, 2))
    assert one_eos <= one_eos

# Generated at 2022-06-24 01:21:19.280075
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    """Unit test for method convert of class NoneMoney."""
    # Imports
    import pytest
    from finance.tests.utils import prepare_money

    # Setup
    usd, eur, cny, mxn = prepare_money()

    # Test
    assert NoneMoney.convert(usd, cny) is NoMoney
    assert NoneMoney.convert(usd, cny, strict=True) is NoMoney



# Generated at 2022-06-24 01:21:19.747053
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    pass

# Generated at 2022-06-24 01:21:31.142051
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    ## method __eq__ of class SomePrice
    #
    # __eq__ should return True if the price objects are equal.
    assert SomePrice(Currency.uk_pound, 1.25, Date.today()) == SomePrice(Currency.uk_pound, 1.25, Date.today())
    #
    ## method __eq__ of class SomePrice
    #
    # __eq__ should return False if the price objects are not equal.
    assert SomePrice(Currency.uk_pound, 1.25, Date.today()) != SomePrice(Currency.uk_pound, 1.50, Date.today())
    assert SomePrice(Currency.uk_pound, 1.25, Date.today()) != SomePrice(Currency.uk_pound, 1.25, Date.today() + 7)

# Generated at 2022-06-24 01:21:31.977200
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    pass

# Generated at 2022-06-24 01:21:32.729261
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass


# Generated at 2022-06-24 01:21:44.038284
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from abc import abstractmethod

    from pymarketcap.test.test_utils import TestCase

    from pymarketcap.types import Currency, Date, SomePrice

    from pymarketcap.types import \
        EUR, GBP, USD, PLN, TRY,\
        EUR_USD, USD_EUR, GBP_EUR, EUR_PLN, PLN_EUR,\
        EUR_TRY, TRY_EUR, USD_TRY, TRY_USD, USD_PLN, PLN_USD

    class FXRateServiceMock:
        __slots__ = ("rates", "strict")

        def __init__(self, rates, strict=False) -> None:
            self.rates = rates
            self.strict = strict


# Generated at 2022-06-24 01:21:49.312920
# Unit test for method __add__ of class SomeMoney

# Generated at 2022-06-24 01:21:54.336426
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert (True is
            Price.of(USD, "1.0", TODAY).__bool__())
    assert (False is
            Price.of(USD, "0.0", TODAY).__bool__())
    assert (False is
            Price.of(USD, None, None).__bool__())

# Generated at 2022-06-24 01:22:00.064158
# Unit test for method abs of class Money
def test_Money_abs():
    m = Money.of(bgn, Decimal("-1"), Date(2018, 11, 3))
    assert m.abs() == Money.of(bgn, 1, Date(2018, 11, 3))
    assert m.abs().ccy == bgn
    assert m.abs().qty == 1
    assert m.abs().dov == Date(2018, 11, 3)
    assert m.abs().defined
    assert not m.abs().undefined

# Generated at 2022-06-24 01:22:00.807359
# Unit test for method __round__ of class Price
def test_Price___round__(): ...



# Generated at 2022-06-24 01:22:06.989268
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():

    m1 = Price.of(EUR, Decimal("0.0"), Date(year=2010, month=1, day=1))
    m2 = Price.of(EUR, Decimal("1.0"), Date(year=2010, month=1, day=1))

    assert m1.as_boolean() == False
    assert m2.as_boolean() == True
    assert m1.as_boolean() == (m1.qty == 0)
    assert m2.as_boolean() == (m2.qty != 0)


# Generated at 2022-06-24 01:22:11.029548
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    none = NoneMoney()
    assert none.__neg__() is none

# Generated at 2022-06-24 01:22:12.335492
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    assert False, "Unit Test not implemented!"


# Generated at 2022-06-24 01:22:17.269351
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    assert SomeMoney(USD, Decimal("0.00"), today) < SomeMoney(USD, Decimal("0.01"), today)
    assert not SomeMoney(USD, Decimal("0.01"), today) < SomeMoney(USD, Decimal("0.00"), today)
    assert not SomeMoney(USD, Decimal("0.00"), today) < SomeMoney(USD, Decimal("0.00"), today)

# Generated at 2022-06-24 01:22:24.243858
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    import pytest
    from .currencies import CURRENCIES

    with pytest.raises(IncompatibleCurrencyError) as ex:
        raise IncompatibleCurrencyError(CURRENCIES["USD"], CURRENCIES["GBP"])

    assert "USD vs GBP" in str(ex.value)
    assert "'None'" in str(ex.value)
    assert "IncompatibleCurrencyError" in str(ex.value)

    with pytest.raises(IncompatibleCurrencyError) as ex:
        raise IncompatibleCurrencyError(CURRENCIES["USD"], CURRENCIES["GBP"], "Add")

    assert "USD vs GBP" in str(ex.value)
    assert "'Add'" in str(ex.value)
    assert "IncompatibleCurrencyError" in str(ex.value)



# Generated at 2022-06-24 01:22:26.402280
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    with raises(IncompatibleCurrencyError):
        USD["1"].__le__(EUR["1"])



# Generated at 2022-06-24 01:22:30.649128
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    x = NonePrice()
    y = x.__pos__()
    assert y == x
    assert y is not x

    x = SomePrice(EUR, 1, 1)
    y = x.__pos__()
    assert y == x
    assert y is not x

# Generated at 2022-06-24 01:22:34.688703
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    # Setup
    m = Price.of(USD, Decimal("-4.4"), datetime.date(2014, 4, 9))

    # Exercise
    result = -m

    # Verify
    assert result == Price.of(USD, Decimal("4.4"), datetime.date(2014, 4, 9))

# Generated at 2022-06-24 01:22:41.588093
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    ## Preparing data:
    a = NoPrice
    b = NoPrice

    ## Executing the code to be tested:
    result = a.__lt__(b)

    ## Validating the results:
    assert result is False


# Generated at 2022-06-24 01:22:45.585407
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    from .currencies import Currency
    from .money import SomeMoney
    assert SomeMoney("CHF", 100, Date()).__neg__() == SomeMoney("CHF", -100, Date())


# Generated at 2022-06-24 01:22:53.509362
# Unit test for method __int__ of class Money
def test_Money___int__():
    from .currencies import TUR, USD
    from .dates import TODAY
    from .money import Money, SomeMoney
    TUR_10 = Money.of(TUR, 10, TODAY)
    USD_10 = Money.of(USD, 10, TODAY)
    assert TUR_10.__int__() == 10
    assert USD_10.__int__() == 10
    assert Money.of(TUR, 10.3, TODAY).__int__() == 10
    assert Money.of(TUR, 10.6, TODAY).__int__() == 11
    assert Money.of(TUR, -10.3, TODAY).__int__() == -10
    assert Money.of(TUR, -10.6, TODAY).__int__() == -11
    assert Money.of(TUR, 10.1, TODAY).__int__

# Generated at 2022-06-24 01:22:58.676204
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    ccy = Currency("GBP")
    qty = Decimal("1.23456")
    dov = Date.today()
    sp1 = SomePrice(ccy, qty, dov)
    sp2 = SomePrice(ccy, qty, dov)
    sp3 = sp1 + sp2
    assert sp3.ccy == ccy
    assert sp3.qty == qty * 2
    assert sp3.dov == dov

# Generated at 2022-06-24 01:23:04.403860
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    from money import Money
    from money import NoMoney
    none_money = NoneMoney()
    assert (1 * none_money) is NoneMoney()


# Generated at 2022-06-24 01:23:12.181889
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    import datetime
    import money
    assert(
        money.SomePrice(
            money.Currency.USD,
            Decimal('123.45'),
            datetime.date(2017, 11, 20),
        ) / Decimal('2.0')
        == money.SomePrice(
            money.Currency.USD,
            Decimal('61.725'),
            datetime.date(2017, 11, 20),
        )
    )

# Generated at 2022-06-24 01:23:21.035833
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.NA.floor_divide(10) == Price.NA
    assert Price.of('EUR', 10, '2020-01-01').floor_divide(2) == Price.of('EUR', 5, '2020-01-01')
    assert Price.of('EUR', 10, '2020-01-01').floor_divide(0) == Price.NA
    assert Price.of('EUR', 10, '2020-01-01').floor_divide('2') == Price.of('EUR', 5, '2020-01-01')
    assert Price.of('EUR', 10, '2020-01-01').floor_divide(Price.of('EUR', 10, '2020-01-01')) == Price.NA
    assert Price.of('EUR', 10, '2020-01-01').floor_

# Generated at 2022-06-24 01:23:32.192874
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    from z3 import And, Function, If, IntSort, Or, Solver, Symbol
    from z3 import make_quantifier, Quantifier, RealSort, exists, forall
    a, b = Symbol("a", RealSort()), Symbol("b", RealSort())
    f = Function("f", RealSort(), RealSort())
    g = Function("g", RealSort(), RealSort())
    Q = [make_quantifier(Quantifier.EXISTS, [a], f(a) > 0), make_quantifier(Quantifier.FORALL, [b], g(b) < 0)]
    s = Solver()
    s.add(And(*Q))
    for i in range(100):
        print(s.check())


# Generated at 2022-06-24 01:23:33.633680
# Unit test for method lte of class Price
def test_Price_lte():
    assert 0 <= Money.of(USD,0)

# Generated at 2022-06-24 01:23:41.038622
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    assert SomePrice(USD, Decimal(1), Date(2020, 6, 23)) == SomePrice(USD, Decimal(1), Date(2020, 6, 23))
    assert SomePrice(USD, Decimal(1), Date(2020, 6, 23)) != SomePrice(USD, Decimal(1), Date(2020, 9, 23))
    assert SomePrice(USD, Decimal(1), Date(2020, 6, 23)) != NoPrice
    assert SomePrice(USD, Decimal(1), Date(2020, 6, 23)) != USDMoney(1, Date(2020, 6, 23))
    assert SomePrice(USD, Decimal(1), Date(2020, 6, 23)) != Decimal(1)

# Generated at 2022-06-24 01:23:50.847748
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    assert SomePrice("USD", Decimal("1.555"), DOV) == SomePrice("USD", Decimal("1.555"), DOV).round(3)
    # You can choose to be strict if you'd like
    assert SomePrice("USD", Decimal("1.555"), DOV).round(2) == SomePrice("USD", Decimal("1.56"), DOV)
    assert SomePrice("USD", Decimal("-1.555"), DOV).round(1) == SomePrice("USD", Decimal("-1.6"), DOV)
    for n in range(0, 27):
        assert SomePrice("USD", Decimal("-1.555"), DOV).round(n) == SomePrice("USD", Decimal("-1.555"), DOV)
    return True

# Generated at 2022-06-24 01:24:03.306728
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from .currencies import USD

    assert USD(100).scalar_subtract(4) == USD(96)

    m = Money.of(USD, 100, Date.puzzle)
    assert m.scalar_subtract(20) == USD(80, Date.puzzle)
    assert m.scalar_subtract(20.0) == USD(80, Date.puzzle)

    assert Money.of(USD, 10, Date.puzzle).scalar_subtract(NoMoney) == USD(10, Date.puzzle)

    assert NoMoney.scalar_subtract(USD(10)) == NoMoney
    assert Money.of(USD, 10, Date.puzzle).scalar_subtract(NoPrice) == USD(10, Date.puzzle)

    assert Money.of

# Generated at 2022-06-24 01:24:08.279736
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    """it should return ``self``"""
    assert (NoPrice.__abs__() == NoPrice)

# Generated at 2022-06-24 01:24:17.880296
# Unit test for method positive of class Price
def test_Price_positive():


    # Create some money objects
    m1 = Money(ccy=Currency("USD"), qty=Decimal(10), dov=Date(2016, 10, 10))
    m2 = Money(ccy=Currency("USD"), qty=Decimal(-10), dov=Date(2016, 10, 10))
    m3 = Money.NA

    # Symbolically call the methods of the money objects
    p1 = m1.positive()
    p2 = m2.positive()
    p3 = m3.positive()

    # Create the expected results
    e1 = Money(ccy=Currency("USD"), qty=Decimal(10), dov=Date(2016, 10, 10))

# Generated at 2022-06-24 01:24:20.257711
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    assert is_close(SomePrice(Currency.USD, Decimal("3.14"), Date(2018, 1, 1)) / Decimal("1.23"), Decimal("2.55"))



# Generated at 2022-06-24 01:24:32.581423
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    global NoPrice
    price_dict_A = {
        'ccy': Currency.USD,
        'qty': Decimal('100.0'),
        'dov': Date('2019-01-02')
    }

    price_dict_B = {
        'ccy': Currency.USD,
        'qty': Decimal('50.0'),
        'dov': Date('2019-01-02')
    }

    price_dict_C = {
        'ccy': Currency.CAD,
        'qty': Decimal('100.0'),
        'dov': Date('2019-01-02')
    }

    price_A = Price.of(price_dict_A['ccy'],price_dict_A['qty'],price_dict_A['dov'])
    price_B = Price

# Generated at 2022-06-24 01:24:34.514333
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert NoMoney >= NoMoney

    from yadm.documents import Document, fields

    class SomeMoneyDocument(Document):
        money = fields.MoneyField()

    assert SomeMoneyDocument().money >= NoMoney



# Generated at 2022-06-24 01:24:43.830961
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    # Assert that "NoMoney < NoMoney" returns False
    # Assert that "NoMoney < SomeMoney" returns True
    # Assert that "NoMoney < NoneMoney" returns False
    # Assert that "NoneMoney < NoMoney" returns False
    # Assert that "NoneMoney < SomeMoney" returns True
    # Assert that "NoneMoney < NoneMoney" returns False
    # Assert that "SomeMoney < NoMoney" returns False
    # Assert that "SomeMoney < SomeMoney" returns False
    # Assert that "SomeMoney < NoneMoney" returns False
    pass


# Generated at 2022-06-24 01:24:49.265913
# Unit test for method lte of class Money
def test_Money_lte():
    assert NoneMoney <= SomeMoney(Currency('USD'), Decimal('1'), Date(2019, 1, 1))
    assert SomeMoney(Currency('USD'), Decimal('1'), Date(2019, 1, 1)) <= SomeMoney(Currency('USD'), Decimal('1'), Date(2019, 1, 1))

# Generated at 2022-06-24 01:24:51.721168
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    assert NoneMoney() == NoneMoney()
    assert NoneMoney() != SomeMoney(Currency('AAPL'), Decimal('1'), Date('2018-03-08'))
    assert not NoneMoney()


# Generated at 2022-06-24 01:25:01.620365
# Unit test for method lt of class Price
def test_Price_lt():
    assert NoPrice.lt(NoPrice) is False
    assert NoPrice.lt(SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1))) is True
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).lt(NoPrice) is False
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).lt(SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1))) is False
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).lt(SomePrice(USD, Decimal("1.1"), Date(2020, 1, 1))) is True

# Generated at 2022-06-24 01:25:07.734098
# Unit test for method __round__ of class Money
def test_Money___round__():
    """
    Tests the method __round__ of the class Money
    """
    from .currencies import Currency
    from .dates import Date
    #
    usd = Currency("USD")
    jpy = Currency("JPY")
    #
    money1 = SomeMoney(usd,Decimal("1.01"),Date("2019-01-01"))
    # 
    money2 = money1.__round__()  # should be 1
    money3 = money1.__round__(2) # should be 1.01
    #
    # test None
    money1 = SomeMoney(usd,Decimal("1.01"),None)
    money1.__round__(2) # TypeError is raised.
    #
    # test incorrect currency

# Generated at 2022-06-24 01:25:16.254873
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    # arrange
    target = SomeMoney(Currency("USD"), Decimal("-4.5"), date(2018, 8, 31))
    # act
    result = target.with_ccy(Currency("EUR"))
    # assert
    assert result == SomeMoney(Currency("EUR"), Decimal("-4.5"), date(2018, 8, 31))

# Generated at 2022-06-24 01:25:27.241327
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert SomeMoney(Currency.USD, Decimal("10.0"), Date(2000, 1, 1)).is_equal(SomeMoney(Currency.USD, Decimal("10.0"), Date(2000, 1, 1)))
    assert SomeMoney(Currency.USD, Decimal("10.0"), Date(2000, 1, 1)).is_equal(SomeMoney(Currency.USD, Decimal("10.0")))
    assert SomeMoney(Currency.USD, Decimal("10.0"), Date(2000, 1, 1)).is_equal(SomeMoney(Currency.USD, Decimal("10.0"), dov=Date.today()))
    assert SomeMoney(Currency.USD, Decimal("10.0"), Date(2000, 1, 1)).is_equal(SomeMoney(Currency.USD, Decimal("10.0")))
   

# Generated at 2022-06-24 01:25:32.468563
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    USD = Currency.of('USD')
    p1 = Price.of(USD, 1, today)
    p2 = p1.scalar_subtract(1)
    assert p2.qty == Decimal('0')



# Generated at 2022-06-24 01:25:36.631165
# Unit test for method lt of class Money
def test_Money_lt():
    from .currencies import Currency
    
    assert NoMoney < SomeMoney(Currency("USD"), 10, Date.today())
    assert SomeMoney(Currency("USD"), 10, Date.today()) < SomeMoney(Currency("USD"), 20, Date.today())
    assert SomeMoney(Currency("USD"), 10, Date.today()) < SomeMoney(Currency("EUR"), 10, Date.today())

# Generated at 2022-06-24 01:25:44.115871
# Unit test for method divide of class Price
def test_Price_divide():
    p: Price = NoPrice
    q: Price = SomePrice(USD, 10, date(2016, 1, 1))
    assert p / 10 == NoPrice
    assert q / 10 == SomePrice(USD, 1, date(2016, 1, 1))
    assert q / 10.5 == SomePrice(USD, Decimal('0.952380952380952380952380952381'), date(2016, 1, 1))
    assert q / 0 == NoPrice
    with pytest.raises(TypeError):
        _: float = float(p / 10)


# Generated at 2022-06-24 01:25:49.393680
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    # this test is flawed, because it doesn't pass in a Money as the other
    # parameter; it passes in a Quantity!
    assert NoneMoney() >= NoneMoney()
    assert NoneMoney() >= NoMoney
    assert not NoneMoney() >= Quantity(1.23)


# Generated at 2022-06-24 01:25:53.238074
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    assert(SomeMoney(USD, Decimal('99.99'), date(2020, 1, 1)) <= SomeMoney(USD, Decimal('99.99'), date(2020, 1, 1)))
    assert(SomeMoney(USD, Decimal('99.99'), date(2020, 1, 1)) <= SomeMoney(USD, Decimal('100.00'), date(2020, 1, 1)))
    assert(not (SomeMoney(USD, Decimal('99.99'), date(2020, 1, 1)) <= SomeMoney(USD, Decimal('99.98'), date(2020, 1, 1))))
    assert(not (SomeMoney(USD, Decimal('99.99'), date(2020, 1, 1)) <= NoMoney))


# Generated at 2022-06-24 01:26:01.051839
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert NoPrice < NoPrice
    assert NoPrice < SomePrice(AUD, 1, d1)
    assert SomePrice(AUD, 1, d1) < NoPrice
    assert SomePrice(AUD, 1, d1) < SomePrice(AUD, 1, d1)
    assert SomePrice(AUD, 1, d1) < SomePrice(AUD, 1.1, d1)
    assert SomePrice(AUD, 1, d1) < SomePrice(AUD, 1, d2)
    assert SomePrice(AUD, 1, d1) < SomePrice(AUD, 1, d1+1)
    assert SomePrice(AUD, 1, d1) < SomePrice(USD, 1, d1)


# Generated at 2022-06-24 01:26:07.648628
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    assert NonePrice().scalar_add(Decimal('0.0000')) == NoPrice
    assert NonePrice().scalar_add(Decimal('0.5')) == NoPrice
    assert NonePrice().scalar_add(Decimal('1.0')) == NoPrice
    raises(TypeError, lambda: NonePrice().scalar_add(object()))


# Generated at 2022-06-24 01:26:12.927129
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    price = SomePrice(usd, 100, today)
    assert price.with_qty(20) == SomePrice(usd, 20, today)
    assert price == SomePrice(usd, 100, today)

# Generated at 2022-06-24 01:26:25.642129
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    "tests SomeMoney.__lt__()"
    ccy = Currency('USD', 2)
    qty1 = Decimal(1)
    dov1 = Date(1, 1, 1)
    qty2 = Decimal(2)
    dov2 = Date(1, 1, 1)
    qty3 = Decimal(1)
    dov3 = Date(1, 1, 2)
    qty4 = Decimal(2)
    dov4 = Date(1, 1, 2)
    m1 = SomeMoney(ccy, qty1, dov1)
    m2 = SomeMoney(ccy, qty2, dov2)
    m3 = SomeMoney(ccy, qty3, dov3)
    m4 = SomeMoney(ccy, qty4, dov4)



# Generated at 2022-06-24 01:26:36.533688
# Unit test for method add of class Price
def test_Price_add():
    from . import Direction, Party, Payments
    from .backtest_analytics import BacktestAnalytics
    from .common import Date, Decimal, Money, Price

    # Example 1
    ba = BacktestAnalytics("mybacktest")

    dov = Date.today()

    with ba.context("trade 1"):

        ba.set_base_amount(Money("25.00", "USD", dov))

        price = Price("0.015", "USD/EUR", dov)

        ba.add_payment(Payments([{"base": 25.00, "counter": 1.0}], "USD/EUR", "trade"))

        ba.set_price(price)

        # Check if the amount added is correct
        assert ba.backtest.amount == Money("25.00", "USD", dov)
        # Check if the

# Generated at 2022-06-24 01:26:40.589041
# Unit test for method multiply of class Price
def test_Price_multiply():

    assert Price.of(USD, None, None).multiply(2) == Price.of(USD, None, None)

    assert Price.of(USD, Decimal(10), DOV).multiply(Decimal(3)) == Price.of(USD, Decimal(30), DOV)

# Generated at 2022-06-24 01:26:46.391309
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
        """Checks if NoneMoney * a numeric value results in NoneMoney"""
        v_NoneMoney = NoneMoney()
        v_int = 20
        assert v_NoneMoney.__mul__(v_int) == NoneMoney()

# Generated at 2022-06-24 01:26:56.809744
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    assert NoneMoney * 1 == NoneMoney
    assert NoneMoney * 1.0 == NoneMoney
    assert NoneMoney * Decimal() == NoneMoney
    assert NoneMoney * Decimal("1") == NoneMoney
    assert NoneMoney * Decimal("1.0") == NoneMoney
    assert NoneMoney * Fraction(1, 1) == NoneMoney
    assert NoneMoney * Fraction(0, 1) == NoneMoney
    assert NoneMoney * Fraction(1, 1) == NoneMoney
    assert NoneMoney * Fraction(1, 2) == NoneMoney
    assert NoneMoney * Fraction(1, 3) == NoneMoney
    assert NoneMoney * Fraction(2, 3) == NoneMoney
    assert NoneMoney * Fraction(10, 1) == NoneMoney
    assert NoneMoney * Fraction(20, 1) == NoneMoney
    assert NoneMoney * Fraction

# Generated at 2022-06-24 01:26:57.845132
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert False, "Have not implemented unit test yet."



# Generated at 2022-06-24 01:27:01.939064
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    m1 = Money.of(Currency("USD"), 100, Date(2018, 11, 11))
    m2 = Money.of(Currency("USD"), 10, Date(2018, 11, 11))

    assert m1.scalar_subtract(10) == m2



# Generated at 2022-06-24 01:27:09.737034
# Unit test for constructor of class SomePrice
def test_SomePrice():
    price = SomePrice(Currency.get("EUR"), Decimal("10.0000"), datetime.date.today())
    assert isinstance(price, Price)
    assert price.ccy == Currency.get("EUR")
    assert price.qty == Decimal("10.0000")
    assert price.dov == datetime.date.today()
    assert price.defined == True
    assert price.undefined == False


NO_PRICE: Price = Undefined



# Generated at 2022-06-24 01:27:11.857525
# Unit test for method positive of class Price
def test_Price_positive():
    m = Money.of(USD, NAIVE_DEC)
    assert m.positive() is m



# Generated at 2022-06-24 01:27:15.025704
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    assert NoPrice.with_dov(Date(2020, 8, 20)) == NoPrice

# Generated at 2022-06-24 01:27:27.252085
# Unit test for method __add__ of class Money
def test_Money___add__():
    # Unit test for method __add__ of class Money defined at line 369 of file types.py
    import pytest  # type: ignore

    # Local imports
    from .currencies import Currency
    from .exchange import FXRateService
    from .types import Money, SomeMoney

    some_money1 = SomeMoney(Currency("USD"), Decimal("0.001"), Date(2020, 9, 1))
    some_money2 = SomeMoney(Currency("USD"), Decimal("0.002"), Date(2020, 9, 1))
    assert some_money1 + some_money2 == SomeMoney(Currency("USD"), Decimal("0.003"), Date(2020, 9, 1))
    incompatible_money = SomeMoney(Currency("EUR"), Decimal("0.001"), Date(2020, 9, 1))

# Generated at 2022-06-24 01:27:27.984269
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    pass


# Generated at 2022-06-24 01:27:29.830272
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    ccy = Currency("CA")
    qty = Decimal("1.12345")
    dov = Date("2018-01-01")

    prc = SomePrice(ccy, qty, dov)
    assert float(prc) == float(qty)



# Generated at 2022-06-24 01:27:35.637851
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.NA.abs() == Price.NA
    assert Price.of(CAD, 1, TODAY).abs() == Price.of(CAD, 1, TODAY)
    assert Price.of(CAD, -1, TODAY).abs() == Price.of(CAD, 1, TODAY)

# Generated at 2022-06-24 01:27:36.482236
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert (NoMoney >= NoMoney) is True

# Generated at 2022-06-24 01:27:39.856954
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    """
    Tests :func:`Money.__floordiv__` method.
    """
    from ..models.money import Money, SomeMoney

    m = Money.of(Currency("USD"), 100, Date.today())
    assert m / 2 == Money.of(Currency("USD"), 50, Date.today())
    assert isinstance(m / 2, SomeMoney)



# Generated at 2022-06-24 01:27:47.529770
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    assert SomePrice(ccy=USD, qty=Decimal("1.0"), dov=Date.today()).__abs__() == SomePrice(ccy=USD, qty=Decimal("1.0"), dov=Date.today())
    assert SomePrice(ccy=USD, qty=Decimal("-1.0"), dov=Date.today()).__abs__() == SomePrice(ccy=USD, qty=Decimal("1.0"), dov=Date.today())

# Generated at 2022-06-24 01:27:51.999326
# Unit test for method __float__ of class Price
def test_Price___float__():
    # Test empty price
    assert float(Price.of(None, None, None)) == 0.0
    # Test price with a quantity
    assert float(Price.of(Currency.USD, 1.0, Date.today())) == 1.0
    # Test price with a quantity, currency and value date
    assert float(Price.of(Currency.USD, 1.0, Date.of(2019, 7, 4))) == 1.0


# Generated at 2022-06-24 01:28:04.488523
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    from datetime import date
    from money import Money, SomeMoney, NoMoney
    from .test_fx import  USD, GBP, CHF, JPY, EUR
    from .test_fx import USD_CHF_CF, GBP_USD_CF, GBP_JPY_CF, TestFXService1, TestFXService2
    from .test_fx import test_fx_service_1, test_fx_service_2

    m1 = SomeMoney(USD, 1, date(2018, 9, 10))
    m2 = SomeMoney(USD, 2, date(2018, 9, 11))
    assert m1.__ge__(m2) is False
    assert m2.__ge__(m1) is True
    assert m1.__ge__(m1) is True


# Generated at 2022-06-24 01:28:16.353163
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from dataclasses import dataclass
    from decimal import Decimal as D
    from .currencies import Currency

    @dataclass(frozen=True)
    class TestMoney(Money):
        ccy: Currency
        qty: Decimal
        dov: Date

        # noinspection PyMethodMayBeStatic
        def is_equal(self, other: Any) -> bool:
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov

        def as_boolean(self) -> bool:
            raise NotImplementedError

        def as_float(self) -> float:
            raise NotImplementedError

        def as_integer(self) -> int:
            raise NotImplementedError

        def abs(self) -> Money:
            raise Not

# Generated at 2022-06-24 01:28:25.289638
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    r = SomeMoney('USD', Decimal('1.00'), datetime.date(2020, 1, 1))
    assert r.abs() == SomeMoney('USD', Decimal('1.00'), datetime.date(2020, 1, 1))
    s = SomeMoney('USD', Decimal('-1.00'), datetime.date(2020, 1, 1))
    assert s.abs() == SomeMoney('USD', Decimal('1.00'), datetime.date(2020, 1, 1))