

# Generated at 2022-06-24 01:18:27.782151
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    """
    Tests method __ge__ of class Price.
    """
    # Limitation: Method Price.__ge__ not tested.
    pass


# Generated at 2022-06-24 01:18:30.103879
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
  ## Check
  assert (-NoMoney) == NoMoney
## Unit test for method __pos__ of class NoneMoney

# Generated at 2022-06-24 01:18:41.669001
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    ccy1 = Currency(code="usd", name="US Dollar", format="{code} {name}", quantizer=Decimal("0.001"))
    qty1 = Decimal("10.000")
    dov1 = Date(year=2018, month=11, day=5)
    sp1 = SomePrice(ccy1, qty1, dov1)
    ccy2 = Currency(code="jpy", name="Japanese Yen", format="{code} {name}", quantizer=Decimal("0"))
    qty2 = Decimal("10")
    dov2 = Date(year=2018, month=11, day=6)
    sp2 = SomePrice(ccy2, qty2, dov2)
    if sp1 < sp2:
        assert True
    else:
        assert False

#

# Generated at 2022-06-24 01:18:49.134872
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    p1 = Price.of(ccy=Currency.EUR, qty=Decimal(10.0), dov=Date.today())
    p2 = Price.of(ccy=Currency.EUR, qty=Decimal(1.0), dov=Date.today())

    assert p1.scalar_add(p2) == Price.of(ccy=Currency.EUR, qty=Decimal(11.0), dov=Date.today())

# Generated at 2022-06-24 01:18:50.209883
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    assert NonePrice.scalar_subtract(1) == NoPrice


# Generated at 2022-06-24 01:18:56.555983
# Unit test for method positive of class Money
def test_Money_positive():
    assert SomeMoney("USD", 1, Date.today()).positive() == SomeMoney("USD", 1, Date.today())
    assert SomeMoney("USD", -1, Date.today()).positive() == SomeMoney("USD", -1, Date.today())
    assert NoMoney.positive() == NoMoney

# Generated at 2022-06-24 01:19:06.008870
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    from money import Price

    # create Price objects
    p1 = Price(ccy="USD", qty=1.00, dov="20181231")
    p2 = Price(ccy="USD", qty=1.00, dov="20190101")

    # apply scalar addition
    p3 = p1.scalar_add(2.00)
    p4 = p2.scalar_add(2.00)

    # expect
    assert p3 == Price(ccy="USD", qty=3.00, dov="20181231")
    assert p4 == Price(ccy="USD", qty=3.00, dov="20190101")

# Generated at 2022-06-24 01:19:12.620415
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(Money.of(Currency("EUR"), Decimal("-5.5"), Date(2012, 3, 2))) == -5
    assert int(Money.of(Currency("EUR"), Decimal("5.5"), Date(2012, 3, 2))) == 5
    assert int(Money.of(Currency("EUR"), Decimal("0.0"), Date(2012, 3, 2))) == 0


# Generated at 2022-06-24 01:19:20.662227
# Unit test for method convert of class Money
def test_Money_convert():
    """
    Whitebox unit-test for method convert of class Money
    """
    from decimal import Decimal
    from tcip.currencies import Currency
    from tcip.money import Money
    from tcip.money import SomeMoney
    # Test with simple defined someMoney
    someMoney = SomeMoney(Currency('USD'), Decimal('10'), Date('20-10-2020'))
    money = someMoney.convert(Currency('EUR'), Date('20-10-2020'), False)
    assert money.qty == Decimal('8.4750')


# Generated at 2022-06-24 01:19:23.621323
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    m1 = NoMoney
    m2 = NoMoney
    assert m1 == m2
    assert m1.is_equal(m2)
    assert m2 == m1

# Generated at 2022-06-24 01:19:32.537571
# Unit test for method abs of class Money
def test_Money_abs():
    assert Money.of(None, None, None).abs() == Money.of(None, None, None)
    assert Money.of("USD", Decimal("-10.1234"), None).abs() == Money.of("USD", "10.1234", None)
    assert Money.of("USD", Decimal("0.0"), None).abs() == Money.of("USD", "0.0", None)
    assert Money.of("USD", Decimal("10.1234"), None).abs() == Money.of("USD", "10.1234", None)


# Generated at 2022-06-24 01:19:39.843962
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    # Test Money.scalar_add()
    from .currencies import Currency
    from .exchange import FXRateServiceImpl
    from .utilities import (DateTimeUtilities, DateUtilities,
                            PeriodUtilities, StrUtilities)
    import datetime
    import random
    import time

    seed = int(time.time())
    print(f"Random seed: {seed}")
    random.seed(seed)

    timeUtilities = DateTimeUtilities.getInstance()
    dateUtilities = DateUtilities.getInstance()
    periodUtilities = PeriodUtilities.getInstance()
    strUtilities = StrUtilities.getInstance()
    fxService = FXRateServiceImpl.getInstance()

    # One by one currency assignment.
    Currency.setFXRateService(fxService)

# Generated at 2022-06-24 01:19:43.763749
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from money.money import Money
    from money.currencies import USD
    money1 = Money.of(USD, 100, date(2019, 10, 10))
    money2 = money1.with_dov(date(2019, 10, 15))
    assert money2.dov == date(2019, 10, 15)
    assert money1.dov == date(2019, 10, 10)
    assert money1.ccy == USD
    assert money2.ccy == USD


Money.NA = NoMoney



# Generated at 2022-06-24 01:19:54.655975
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    # noinspection DuplicatedCode
    def test(m: Money, tgt: Money):
        if m.defined:
            act = abs(m)
            assert act.ccy == tgt.ccy
            assert act.qty == tgt.qty
            assert act.dov == tgt.dov
        else:
            with pytest.raises(MonetaryOperationException):
                abs(m)

    ## Test with undefined money object:
    test(NoMoney, NoMoney)
    test(NoneMoney, NoneMoney)

    ## Test with defined money objects:
    test(SomeMoney(CAD(10.0), Date("2018-11-01")), SomeMoney(CAD(10.0), Date("2018-11-01")))

# Generated at 2022-06-24 01:19:55.528856
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    # Nothing to test.
    pass

# Generated at 2022-06-24 01:19:58.801444
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    m = Money.of(USD, 0, TODAY)
    assert (m > NoMoney) is true
    assert (NoMoney > m) is false



# Generated at 2022-06-24 01:20:00.161667
# Unit test for method positive of class Money
def test_Money_positive():
    result = Money.positive()
    assert result == None


# Generated at 2022-06-24 01:20:09.122593
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    import pandas as pd
    from pandas._testing import assert_series_equal, assert_frame_equal
    from .currency import Currency
    from .rates import FXRateService
    from .types import Date
    from .types import Decimal

    a = NoneMoney
    b = Money(CAD, Decimal('10.0'), Date(15, 4, 2020))
    c = NoneMoney
    d = Money(CAD, Decimal('30.0'), Date(15, 4, 2020))

    e = NoneMoney
    f = Money(EUR, Decimal('10.0'), Date(15, 4, 2020))

    def test1(a, b, c, d, e, f):
        expected = Money(CAD, Decimal('40.0'), Date(15, 4, 2020))

# Generated at 2022-06-24 01:20:15.997813
# Unit test for method negative of class Price
def test_Price_negative():
    assert Price.of(Currency.of('USD'), 100, Date.today()).negative() == Price.of(Currency.of('USD'), -100, Date.today())
    assert Price.of(Currency.of('USD'), 100, Date.today()).negative() != Price.of(Currency.of('USD'), 100, Date.today())
    assert Price.of(Currency.of('USD'), 100, Date.today()).negative() != Price.of(Currency.of('USD'), -100, Date.today() + DAY)
    assert Price.of(Currency.of('USD'), 100, Date.today()).negative() != Price.of(Currency.of('JPY'), -100, Date.today())
    assert Price.of(Currency.of('USD'), 100, Date.today()).negative() != NoPrice

# Generated at 2022-06-24 01:20:18.292409
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    mny = SomeMoney(USD, 100, None)
    assert +mny == mny
    assert +NoneMoney == NoneMoney


# Generated at 2022-06-24 01:20:25.125851
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():

    from ..money.classes import NoneMoney

    n = NoneMoney()
    m0 = n
    m1 = None
    m2 = n
    m3 = NoneMoney()
    m4 = NoneMoney()

    assert n == n
    assert n != m1
    assert n != m3
    assert n == m0
    assert m3 == m4
    assert m3 != n
    assert m3 != NoneMoney(None)

# Generated at 2022-06-24 01:20:33.491480
# Unit test for method __round__ of class Price
def test_Price___round__():
    price_one = SomePrice(Currency.USD, Decimal('1.234'), Date(2013, 1, 1))
    assert price_one.__round__().__class__ is int
    assert price_one.__round__().__class__ is int

    assert price_one.__round__(ndigits=None).__class__ is int
    assert price_one.__round__(ndigits=None).__class__ is int

    assert price_one.__round__(ndigits=0).__class__ is SomePrice
    assert price_one.__round__(ndigits=0).__class__ is SomePrice

    price_two = SomePrice(Currency.USD, Decimal('1.234'), Date(2013, 1, 1))
    assert price_two.__round__().__class__ is int
    assert price

# Generated at 2022-06-24 01:20:42.556359
# Unit test for method lt of class Money
def test_Money_lt():
    from .currencies import Currency
    from .exchange import TestFXRateService
    from .money import Money

    ccy1 = Currency("USD")
    ccy2 = Currency("GBP")
    ccy3 = Currency("EUR")

# Generated at 2022-06-24 01:20:43.112314
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    assert int(NoPrice) == 0

# Generated at 2022-06-24 01:20:47.492462
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    n0 = NoMoney
    n1 = NoMoney
    n2 = SomeMoney(USD, 1, TODAY)
    assert n0 == n0
    assert n0 == n1
    assert not n0 == n2
    return n0, n1, n2
n0, n1, n2 = test_NoneMoney___eq__()


# Generated at 2022-06-24 01:20:48.120861
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    pass



# Generated at 2022-06-24 01:20:51.545798
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    """
    Tests the with_dov method of class NoneMoney
    """
    mny = NoMoney.with_dov(Date.of(2020, 12, 31))
    assert mny == NoMoney

# Generated at 2022-06-24 01:21:00.739707
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    assert int(NoneMoney) == 0
    assert int(NoMoney) == 0
    assert int(SomeMoney(USD, 0, datetime.date(2000, 1, 1))) == 0
    assert int(SomeMoney(USD, 1, datetime.date(2000, 1, 1))) == 1
    assert int(SomeMoney(USD, -1, datetime.date(2000, 1, 1))) == -1
    assert int(SomeMoney(USD, 1.0, datetime.date(2000, 1, 1))) == 1
    assert int(SomeMoney(USD, -1.0, datetime.date(2000, 1, 1))) == -1



# Generated at 2022-06-24 01:21:05.385302
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    import pytest
    from mimesis import Generic
    from pymarketcap.test import populate

    instance = NonePrice()
    assert not instance.round()

    for _ in range(0, 5):
        ccy = Generic("en").currency.name()
        qty = float(Generic("en").code.numeric())
        dov = Generic("en").datetime.date().date(start=1970)

        price = populate(SomePrice, ccy=ccy, qty=qty, dov=dov)
        assert price.round() == int(qty)

    with pytest.raises(AssertionError):
        SomePrice("usd", "foo", "bar")

# Generated at 2022-06-24 01:21:16.722011
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    """
    Tests that the constructor of class IncompatibleCurrencyError behaves as expected.
    """
    ccy1 = Currency("USD")
    ccy2 = Currency("JPY")
    try:
        raise IncompatibleCurrencyError(ccy1, ccy2)
    except IncompatibleCurrencyError as e:
        assert isinstance(e.args[0], str)
        assert e.args[0] == "USD vs JPY are incompatible for operation '<Unspecified>'."
        assert e.ccy1 == ccy1
        assert e.ccy2 == ccy2
        assert e.operation == "<Unspecified>"
    else:
        raise ProgrammingError("Exception type IncompatibleCurrencyError not raised.")

#
#
# A base class for Money and Price:

# Generated at 2022-06-24 01:21:18.115051
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    raise NotImplementedError

# Generated at 2022-06-24 01:21:29.998249
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    from decimal import Decimal
    from datetime import date
    from .currency import Currency
    from .money import Money
    from .price import Price
    from .service import FXRateService

    FXRateService.default = lambda: 0
    p1 = Price.of(None, None, None)
    assert p1 == p1
    assert not p1 != p1

    p2 = Price.of(Currency.USD, None, None)
    assert p1 == p2
    assert not p1 != p2

    p3 = Price.of(Currency.USD, Decimal(4), None)
    assert not p1 == p3
    assert p1 != p3

    p4 = Price.of(Currency.USD, Decimal(4), date(2020, 1, 2))
    assert not p1 == p4
    assert p

# Generated at 2022-06-24 01:21:33.505849
# Unit test for method __add__ of class Money
def test_Money___add__():
    assert Money.of('EUR', 1617, '2020-03-01') + Money.of('EUR', 279, '2020-03-01') == Money.of('EUR', 1896, '2020-03-01')



# Generated at 2022-06-24 01:21:41.830957
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    """
    Tests the constructor of class IncompatibleCurrencyError.
    """
    # Setup test:
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    operation = "Addition"

    # Run test:
    error = IncompatibleCurrencyError(ccy1, ccy2, operation)

    # Assert results:
    assert error.ccy1 == ccy1
    assert error.ccy2 == ccy2
    assert error.operation == operation



# Generated at 2022-06-24 01:21:44.141709
# Unit test for method positive of class Money
def test_Money_positive():
    assert Money.of(EUR, Decimal("-1"), Date.now()).positive() == Money.of(EUR, Decimal("1"), Date.now())
    assert Money.NA.positive() == Money.NA



# Generated at 2022-06-24 01:21:49.980445
# Unit test for method add of class Price
def test_Price_add():
    assert(SomePrice(USD, Decimal('1.23'), Date(2018, 11, 3)) + SomePrice(USD, Decimal('1.23'), Date(2018, 11, 3))
           == SomePrice(USD, Decimal('2.46'), Date(2018, 11, 3)))


# Generated at 2022-06-24 01:22:00.329254
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    price=Price.of(ccy=USD,qty=Decimal('1000'),dov=Date.now())
    price_divided = price / 2
    assert price_divided == Price.of(ccy=USD,qty=Decimal('500'),dov=Date.now())
    assert price_divided == Decimal('500')
    assert price_divided * 2 == price
    # Unit test for method __sub__ of class Price
    def test_Price___sub__():
        price1 = Price.of(ccy=USD,qty=Decimal('1000'),dov=Date.now())
        price2 = Price.of(ccy=USD,qty=Decimal('1000'),dov=Date.now())

# Generated at 2022-06-24 01:22:07.541747
# Unit test for method positive of class Price
def test_Price_positive():
    m1 = Money.USD(42.0)
    m2 = Money.USD(123.45)
    m3 = Money.USD(-42.0)
    m4 = Money.USD(-123.45)

    assert Money.USD(42.0) == m1.positive()
    assert Money.USD(123.45) == m2.positive()
    assert Money.USD(42.0) == m3.positive()
    assert Money.USD(123.45) == m4.positive()
    assert Money.NA == Money.NA.positive()
    assert Money.NA.undefined == Money.NA.positive().undefined
    assert Money.NA.defined == Money.NA.positive().defined

# Generated at 2022-06-24 01:22:09.673055
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    price = SomePrice(USD, Decimal("-12.34"), date(2020, 1, 1))
    assert price.__abs__() == SomePrice(USD, Decimal("12.34"), date(2020, 1, 1))

# Generated at 2022-06-24 01:22:10.186875
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    pass

# Generated at 2022-06-24 01:22:20.045723
# Unit test for method add of class Price
def test_Price_add():
    assert Price.of("USD", Decimal("10"), date_today()) == Price.of("USD", 10, date_today())
    assert Price.of("USD", Decimal("10"), date_today()) != Price.of("EUR", 10, date_today())
    assert Price.of("USD", Decimal("10"), date_today()) != Price.of("USD", Decimal("20"), date_today())
    assert Price.of("USD", Decimal("10"), date_today()) != Price.of("USD", 10, date_tomorrow())
    assert Price.of("USD", Decimal("10"), date_today()) != Price.of("USD", Decimal("10"), date_today(), strict=True)

# Generated at 2022-06-24 01:22:31.627383
# Unit test for method positive of class Money
def test_Money_positive():
    # Unit test for method positive of class Money
    a = Money.of(None, None, None)
    b = Money.of(Currency.of("EUR"), Decimal("0"), Date.of(2020, 6, 1))
    c = Money.of(Currency.of("EUR"), Decimal("1"), Date.of(2020, 6, 1))
    assert a.positive() == Money.of(None, None, None)
    assert b.positive() == Money.of(Currency.of("EUR"), Decimal("0"), Date.of(2020, 6, 1))
    assert c.positive() == Money.of(Currency.of("EUR"), Decimal("1"), Date.of(2020, 6, 1))

# Generated at 2022-06-24 01:22:43.262978
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    ccy = Currency("AUD")
    qty = Decimal("100")
    dov = Date(2017, 6, 1)
    sm = SomeMoney(ccy, qty, dov)
    assert sm.scalar_subtract("20") == SomeMoney(ccy, Decimal("80.00"), dov)
    assert sm.scalar_subtract("20.00") == SomeMoney(ccy, Decimal("80.00"), dov)
    assert sm.scalar_subtract("20.00") == SomeMoney(ccy, Decimal("80"), dov)
    assert sm.scalar_subtract("20.00") == SomeMoney(ccy, Decimal("80.00"), dov)
    assert sm.scalar_subtract(Decimal("20.00"))

# Generated at 2022-06-24 01:22:50.748279
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    __coverage___25059 = {'line_num': 25059, 'hits': 0, 'condition_coverage': 0}
    ''' '
    ## Just return false:
    __coverage___25059['line_num'] = 25059
    if __coverage___25059['line_num'] > 0:
        __coverage___25059['hits'] += 1
    return False
    '''
    return False

# Generated at 2022-06-24 01:23:00.940253
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    """Unit test for method `__add__` of class `NonePrice`."""
    from finanpy.base.dtypes import Currency

    p1: Price = NonePrice
    p2: Price = SomePrice(Currency.usd(), 10, Date.now())

    assert (p1 - p2).is_equal(p1)
    assert p1.__sub__(p2).is_equal(p1)
    assert (p2 - p1).is_equal(p2)
    assert p2.__sub__(p1).is_equal(p2)
    assert (p1 - p1).is_equal(p1)
    assert p1.__sub__(p1).is_equal(p1)

NoPrice = NonePrice()


# Generated at 2022-06-24 01:23:03.962710
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
  from quantipy.domain import SomePrice, Date

  dov = Date(2019, 5, 2)
  p = SomePrice(None, None, dov)

  assert p.dov == dov
## Unit test for method with_ccy of class SomePrice

# Generated at 2022-06-24 01:23:09.694042
# Unit test for method __add__ of class Money
def test_Money___add__():
    for a, b, c in [(Money.of("USD", 1.0, Date(2019, 1, 1)),
                     Money.of("USD", 1.5, Date(2019, 1, 1)),
                     Money.of("USD", 2.5, Date(2019, 1, 1))),
                    (Money.of("USD", 1.0, Date(2019, 1, 1)),
                     Money.of("EUR", 1.5, Date(2019, 1, 1)),
                     NoMoney),
                    (Money.of("USD", 1.0, Date(2019, 1, 1)),
                     NoMoney,
                     NoMoney),
                    (NoMoney,
                     Money.of("USD", 1.5, Date(2019, 1, 1)),
                     NoMoney)]:
        assert a.__add__(b) == c


# Generated at 2022-06-24 01:23:19.161590
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    ## Given a defined money object;
    a = SomeMoney(USD, Decimal(1000.0), date(year=2020, month=1, day=1))

    ## When I add a standard type:
    b = a.scalar_add(100)

    ## Then I expect a new money object with the same currency:
    assert b.ccy is USD
    assert b.qty == Decimal(1100.0)
    assert b.dov == date(year=2020, month=1, day=1)
    assert b.defined is True
    assert b.undefined is False



# Generated at 2022-06-24 01:23:22.180893
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    """
    Test method scalar_add of class NoneMoney
    """
    arg1 = None
    arg2 = 0
    expected = None
    result = NoneMoney().scalar_add(arg2)
    assert expected == result



# Generated at 2022-06-24 01:23:30.035141
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    """
    GIVEN a defined Money object
    WHEN the object is negated
    THEN the object must have the correct value:
    (1) the currency must be unchanged
    (2) the quantity must have the opposite sign of the original value
    (3) the date of valuation must be unchanged
    """
    
    m = Money.of(Currency.USD, Decimal("1.00"), Date(2018, 1, 1))
    assert m.ccy == Currency.USD
    assert m.qty == Decimal("1.00")
    assert m.dov == Date(2018, 1, 1)
    
    m2 = -m
    assert m2.ccy == Currency.USD
    assert m2.qty == -Decimal("1.00")
    assert m2.dov == Date(2018, 1, 1)


# Generated at 2022-06-24 01:23:39.136803
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    # NonePrice.convert

    from .currency import EUR, GBP, USD

    from .service import FXRateService

    from .money import Money

    from .price import SomePrice

    import datetime

    ## MOCK-UP:
    class MockupFxRateService(FXRateService):
        """
        Provides a mockup FX rate service.
        """

        def query(self, ccy1: Currency, ccy2: Currency, asof: Optional[Date] = None, strict: bool = False) -> Optional["FXRate"]:
            if ccy1 == EUR and ccy2 == USD:
                return SomeFXRate(EUR, USD, Decimal("1.3"), datetime.date(2018, 1, 1))

# Generated at 2022-06-24 01:23:50.129727
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    """
    Tests the method __eq__ of class SomePrice
    """
    # Arrange
    price1 = SomePrice(Currency.USD, Decimal(10), Date(2020, 1, 1))
    price2 = SomePrice(Currency.USD, Decimal(20), Date(2020, 1, 1))
    price3 = SomePrice(Currency.EUR, Decimal(10), Date(2020, 1, 1))

    # Assert
    assert price1.qty != price2.qty
    assert price1.ccy == price2.ccy
    assert price1.ccy != price3.ccy
    assert price1.dov == price2.dov

    assert price1 == price1
    assert price1 != price2
    assert price1 != price3
    assert price2 != price3

# Generated at 2022-06-24 01:23:50.993985
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    assert NoPrice * 5 == NoPrice

# Generated at 2022-06-24 01:24:03.580720
# Unit test for method divide of class Price
def test_Price_divide():
    #
    #        def divide(self, other):
    #            """
    #            Performs ordinary division on the monetary value if *defined*, itself otherwise.
    #
    #            Note that division by zero yields an undefined monetary value.
    #            """
    #            return self if not other else self.__class__.of(
    #    self._ccy, self._qty / other if self.defined else None, self._dov
    #            )

    # Some.__div__
    ccy = Currency.of('USD')
    qty = Decimal('123.456')
    dov = Date.of('2020-01-01')
    some = SomeMoney(ccy, qty, dov) # mv

    other = '456'

# Generated at 2022-06-24 01:24:14.422226
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    """
    Tests multiplication of money types.
    """
    m1 = SomeMoney("USD", Decimal("10.0"), Date.now())
    m2 = SomeMoney("USD", Decimal("11.0"), Date.now())
    assert m1 * m2 == NoMoney
    assert m1 * 10 == SomeMoney("USD", Decimal("100.0"), Date.now())
    assert 10 * m1 == SomeMoney("USD", Decimal("100.0"), Date.now())
    assert m1 * 10 == SomeMoney("USD", Decimal("100.0"), Date.now())
    assert m1 * 10.0 == SomeMoney("USD", Decimal("100.0"), Date.now())
    assert m1 * Decimal("10.0") == SomeMoney("USD", Decimal("100.0"), Date.now())
    assert m1

# Generated at 2022-06-24 01:24:16.540818
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert bool(Price.of("USD", Decimal("1"), today())), "SomePrice should evaluate to True in boolean context"

# Generated at 2022-06-24 01:24:19.566131
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    with raises(AttributeError) as excinfo:
        NonePrice.convert('', '', '')
    assert str(excinfo.value) == "Did you implement and set the default FX rate service?"



# Generated at 2022-06-24 01:24:21.682574
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    assert round(NonePrice(Currency.USD, Decimal('1.2345'), dt.date(1994, 1, 29))) == 1



# Generated at 2022-06-24 01:24:25.692755
# Unit test for method multiply of class Price
def test_Price_multiply():
    m = Price.of(Currency.USD, 10, Date.today())
    assert m.multiply(2) == Price.of(Currency.USD, 20, Date.today())


# Generated at 2022-06-24 01:24:31.835398
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(GBP, 1, Date(2020, 1, 1)).__bool__() is True
    assert SomePrice(GBP, 0, Date(2020, 1, 1)).__bool__() is False
    assert SomePrice(GBP, Decimal("0.0"), Date(2020, 1, 1)).__bool__() is False

# Generated at 2022-06-24 01:24:36.112486
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    sp = SomePrice(EUR, Decimal(1.23), Date.today())
    np = NonePrice()
    assert sp + np == sp
    assert np + sp == sp
    assert np + np == np



# Generated at 2022-06-24 01:24:44.301922
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    from breezypythongui import EasyFrame
    import math
    import random
    import string
    import tkinter as tk
    from pkg_resources import resource_listdir
    from typing import Any
    from core import Currency
    from core import DefaultCurrencyContext
    from core.exceptions import IncompatibleCurrencyError
    from core.exceptions import ProgrammingError
    from core.money import Money
    from core.money import NoMoney
    from core.money import SomeMoney
    from core.prices import NoPrice
    from core.prices import Price
    from core.prices import SomePrice
    from core.prices import TestPrice
    from core.services import MarketService
    from core.services import FXRateService
    from datetime import date
    from decimal import Decimal
    from decimal import getcontext

    DefaultCurrencyContext

# Generated at 2022-06-24 01:24:55.475037
# Unit test for method __add__ of class Money
def test_Money___add__():
    # Test case 1 of method __add__ of class Money
    m1 = Money.of(EUR, 100, Date.today())
    m2 = Money.of(EUR, 100, Date.today())
    assert (m1 + m2) == Money.of(EUR, 200, Date.today())
    # Test case 2 of method __add__ of class Money
    m1 = Money.of(EUR, 100, Date.today())
    m2 = Money.of(USD, 100, Date.today())
    try:
        m1 + m2
    except CurrencyMismatchError:
        pass
    else:
        assert False
    # Test case 3 of method __add__ of class Money
    m1 = Money.of(EUR, 100, Date.today())
    m2 = Money.undefined

# Generated at 2022-06-24 01:25:03.944355
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from .currencies import Currency
    from .money import Money

    name = 'Money.scalar_subtract'

    assert Money.of(Currency.USD, 10, Date.today()).scalar_subtract(4) == Money.of(Currency.USD, 6, Date.today())
    assert Money.of(Currency.USD, 10, Date.today()).scalar_subtract(4.5) == Money.of(Currency.USD, 5.5, Date.today())
    assert Money.of(Currency.USD, 10, Date.today()).scalar_subtract('4') == Money.of(Currency.USD, 6, Date.today())

    assert Money.of(Currency.USD, 10, Date.today()).scalar_subtract(0) == Money

# Generated at 2022-06-24 01:25:10.705834
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert Money.of(None, Decimal("123.57"), None) is NoMoney
    assert Money.of(Currency.of("USD"), None, None) is NoMoney
    assert Money.of(Currency.of("USD"), Decimal("123.57"), None) is NoMoney
    assert Money.of(Currency.of("USD"), Decimal("123.57"), Date.today()) == Money.of(Currency.of("USD"), Decimal("123.57"), Date.today())



# Generated at 2022-06-24 01:25:11.920600
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    assert int(NoMoney) == 0

# Generated at 2022-06-24 01:25:16.249155
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    qty = Decimal("1234567.89")
    ccy = Currency("USD")
    dov = Date("20170315")
    obj = SomeMoney(ccy, qty, dov)
    new_qty = Decimal("987654.321")
    new_object = obj.with_qty(new_qty)
    assert obj.qty != new_object.qty
    assert obj.qty < new_object.qty
    assert new_object.qty == new_qty
    assert obj.ccy == new_object.ccy
    assert obj.dov == new_object.dov
    assert new_object.as_boolean() == True



# Generated at 2022-06-24 01:25:19.146261
# Unit test for method negative of class Money
def test_Money_negative():
    assert SomeMoney(USD, 12, DATE_2020_01_01).negative() == SomeMoney(USD, -12, DATE_2020_01_01)

# Generated at 2022-06-24 01:25:21.565858
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NonePrice.with_qty(Decimal("1.2")) == NoPrice


# Generated at 2022-06-24 01:25:25.197411
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(NoneMoney) is False
    assert bool(NoMoney) is False
    assert bool(SomeMoney(EUR, Decimal("0"), Date.today())) is False
    assert bool(SomeMoney(EUR, Decimal("1"), Date.today())) is True

# Generated at 2022-06-24 01:25:28.233852
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    assert NonePrice().__le__(SomePrice(EUR, 1, TODAY))


# Generated at 2022-06-24 01:25:36.781172
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    """
    Test to check equality of two money objects.
    """
    # Test when money objects are equal
    M1 = SomeMoney(Currency.USD, 100, Date.today())
    M2 = SomeMoney(Currency.USD, 100, Date.today())
    assert(M1 == M2)

    # Test when currency is different
    M1 = SomeMoney(Currency.USD, 100, Date.today())
    M2 = SomeMoney(Currency.INR, 100, Date.today())
    assert(M1 != M2)

    # Test when quantity is different
    M1 = SomeMoney(Currency.USD, 100, Date.today())
    M2 = SomeMoney(Currency.USD, 200, Date.today())
    assert(M1 != M2)

    # Test when value date is different
    M1

# Generated at 2022-06-24 01:25:38.168307
# Unit test for method abs of class Price
def test_Price_abs():
    # TODO: Write unit tests for method abs of class Price
    pass

# Generated at 2022-06-24 01:25:43.772574
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(EUR, 1.0, TODAY).as_integer() == 1
    assert Price.of(EUR, 1.0, TODAY).as_integer() == 1
    assert Price.of(EUR, 1.0, TODAY).as_integer() == 1
    assert Price.of(EUR, 1.0, TODAY).as_integer() == 1    
    
    
    



# Generated at 2022-06-24 01:25:47.705422
# Unit test for method round of class SomePrice
def test_SomePrice_round():
   """
   Test case for unit test of method round of class SomePrice.
   """
   from src.price import SomePrice
   from src.currency import Currency
   from datetime import date
   from decimal import Decimal
   curr = Currency('EUR')
   price = SomePrice(curr, Decimal(15.10), date(2018, 4, 20))
   test = price.round(2)
   assert test == SomePrice(curr, Decimal('15.10'), date(2018, 4, 20))
   assert type(test) is SomePrice

# Generated at 2022-06-24 01:25:55.885740
# Unit test for method times of class Price
def test_Price_times():
    # testing with a defined price
    assert Price.of(ccy="USD", qty=Decimal("100.0"), dov=dt(2020, 1, 1)).times(\
    Decimal("10.0")) == Money.of(ccy="USD", qty=Decimal("1000.0"), dov=dt(2020, 1, 1))

    # testing with an undefined price
    assert Price.of(ccy=None, qty=None, dov=None).times(Decimal("10.0")) == Money.of(ccy=None, qty=None, dov=dt.max)
test_Price_times()

# Generated at 2022-06-24 01:26:08.892898
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    from .currencies import Currency
    from .dates import Date
    from .instruments.money import Money
    
    mny1 = Currency("USD", "United States Dollar", ndp=2)
    mny2 = Currency("CHF", "Swiss Franc", ndp=2)
    
    # Test with defined and undefined money
    USD100 = Money.of(mny1, 100.00, Date.today())
    assert USD100.positive() == Money(mny1, 100.00, Date.today())
    assert USD100.positive().is_equal(Money.of(mny1, 100.00, Date.today()))
    assert USD100.positive().ccy == mny1
    assert USD100.positive().qty == 100.00
    assert USD100.positive().dov == Date.today()
    assert USD

# Generated at 2022-06-24 01:26:12.925436
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    price = Money(1, SGD)
    date = datetime.date(2019, 1, 1)
    assert price.with_dov(date) == SomePrice(SGD, 1, date)

# Generated at 2022-06-24 01:26:14.236525
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    x = NoMoney
    assert x.with_ccy(Currency("USD")) == NoMoney


# Generated at 2022-06-24 01:26:21.745289
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert Money.of(ccy="USD", qty=Decimal("1000.00"), dov=Date.today()).__int__() == 1000
    assert Money.of(ccy="USD", qty=Decimal("1000.55"), dov=Date.today()).__int__() == 1000
    assert Money.of(ccy="USD", qty=Decimal("1000.95"), dov=Date.today()).__int__() == 1001



# Generated at 2022-06-24 01:26:33.942887
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    """
    Tests whether the method __pos__ of class Money works as expected.
    """
    ## Test cases:

# Generated at 2022-06-24 01:26:34.775434
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    assert empty.scalar_subtract(2*USD) == empty

# Generated at 2022-06-24 01:26:37.905175
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    ccy = Currency("USD")
    qty = Decimal("10.00")
    dov = Date.today()
    ccy1 = Currency("EUR")
    qty1 = Decimal("10.00")
    dov1 = Date.today()
    p1 = SomePrice(ccy, qty, dov)
    p2 = SomePrice(ccy1, qty1, dov1)
    p1.subtract(p2)

# Generated at 2022-06-24 01:26:48.432746
# Unit test for method subtract of class Money
def test_Money_subtract():
    """
    Test the subtract method of the Money Class
    """
    from .currencies import Currency
    from .pricing import SomePrice
    from .currencies.converter import FXConversion
    from .pricing.money import Money
    from .pricing.money import NoMoney
    from .currencies.converter.simple import SimpleFXConverter
    from datetime import datetime

    cur_eur = Currency.get_currency("EUR")
    cur_usd = Currency.get_currency("USD")
    val_date = datetime.now()
    fx_rate_1 = SomePrice(0.59, cur_eur, cur_usd, val_date)
    fx_rate_2 = SomePrice(0.00059, cur_usd, cur_eur, val_date)
    fx_con

# Generated at 2022-06-24 01:26:56.973145
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    sp = SomePrice(USD, Decimal(2.1), date(2020, 1, 1))
    assert sp >= sp         # type: ignore
    assert sp >= SomePrice(USD, Decimal(2.1), date(2020, 1, 1))
    assert sp >= SomePrice(USD, Decimal(2.0), date(2020, 1, 1))
    # assert sp >= SomePrice(USD, Decimal(2.0), date(2020, 3, 1)) # fails IncompatibleCurrencyError
    assert not sp >= SomePrice(USD, Decimal(2.2), date(2020, 1, 1))
    # assert not sp >= SomePrice(USD, Decimal(2.0), date(2020, 3, 1)) # fails IncompatibleCurrencyError
    assert not sp >= NoPrice
    assert sp >= SomePrice(USD, None, None)

# Generated at 2022-06-24 01:27:05.043481
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    from .money import SomeMoney
    from .currency import GBP, USD
    from .date import Date
    q = SomeMoney(CCY=GBP, QTY=10, DOV=Date(2017, 1, 1))
    assert q.with_dov(Date(2018, 1, 1)) == SomeMoney(GBP, 10, Date(2018, 1, 1))
    assert q.with_dov(Date(2017, 2, 1)) == SomeMoney(GBP, 10, Date(2017, 2, 1))
    assert q == q.with_dov(Date(2017, 1, 1))
    # Unit test for method with_qty of class SomeMoney
    def test_SomeMoney_with_qty():
        from .money import SomeMoney
        from .currency import GBP, USD
        from .date import Date
        q

# Generated at 2022-06-24 01:27:16.448438
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    # 1. Check the __gt__ method returns the expected value for various combinations of arguments.
    assert SomePrice(CAD, 12345, today) > SomePrice(CAD, 1234, today)
    assert SomePrice(CAD, 12345, today) > SomePrice(CAD, None, today)
    assert not (SomePrice(CAD, None, today) > SomePrice(CAD, 12345, today))
    assert SomePrice(CAD, 12345, today) > NoPrice
    assert not (NoPrice > SomePrice(CAD, 12345, today))
    assert NoPrice > NoPrice
    assert SomePrice(CAD, 12345, today) > SomePrice(CAD, 1234, today)
    assert SomePrice(CAD, 12345, today) > SomePrice(CAD, 1234, today)
    assert SomePrice

# Generated at 2022-06-24 01:27:19.212618
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    assert SomePrice(JPY, Decimal(123), Date(2017, 12, 1)) == -SomePrice(JPY, Decimal(-123), Date(2017, 12, 1))


# Generated at 2022-06-24 01:27:23.338127
# Unit test for method negative of class Money
def test_Money_negative():
    from .pricing.money import Money
    from .currencies import Currency

    money = Money.of(Currency("USD"), 12.34, Date.today())
    assert money.negative().qty == -12.34



# Generated at 2022-06-24 01:27:27.436817
# Unit test for method divide of class Price
def test_Price_divide():
    expected = False

    m1 = Money.of(Currency.USD, 10, None)
    m2 = Money.of(Currency.USD, 5, None)
    p = Price.of(Currency.USD, 2, None)
    result = p.divide(2)

    assert isinstance(expected == result, bool)


# Generated at 2022-06-24 01:27:38.667322
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    import unittest
    import unittest.mock as mock

    from decimal import Decimal

    from .commons.numbers import Numeric
    from .currencies import Currency

    from .money import Money

    # Make a mock class for abstract class Money for unit test purpose.
    class _MockMoney(Money):
        __slots__ = ("_ccy", "_qty", "_dov", "_defined")

        def __init__(self, ccy: Currency, qty: Numeric, dov: Date, defined: bool = True) -> None:
            self._ccy = ccy
            self._qty = ccy.quantize(qty)
            self._dov = dov
            self._defined = defined


# Generated at 2022-06-24 01:27:40.211820
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    """
    Test function for method `__bool__` of class `NoneMoney`.
    """
    assert not NoneMoney  # type: ignore

# Generated at 2022-06-24 01:27:40.850607
# Unit test for method gte of class Money
def test_Money_gte():
    pass

# Generated at 2022-06-24 01:27:43.191143
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert NoPrice.as_boolean() == False
    assert SomePrice(CAD, Decimal(0.0), Date(1, 1, 1)).as_boolean() == False
    assert SomePrice(CAD, Decimal(1.0), Date(1, 1, 1)).as_boolean() == True

# Generated at 2022-06-24 01:27:48.281412
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    x = SomeMoney(ccy=Currency('EUR'), qty=Decimal(1), dov=Date(2019, 1, 1))
    y = SomeMoney(ccy=Currency('USD'), qty=Decimal(2), dov=Date(2019, 1, 1))
    try:
        assert x.__ge__(y)
        assert True
    except IncompatibleCurrencyError:
        pass
    try:
        assert y.__ge__(x)
        assert True
    except IncompatibleCurrencyError:
        pass
    x = SomeMoney(ccy=Currency('EUR'), qty=Decimal(1), dov=Date(2019, 1, 1))

# Generated at 2022-06-24 01:27:52.192466
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    price = SomePrice("EUR", Decimal("100.123"), now())
    assert price.__int__() == 100
    assert price.as_integer() == 100

# Generated at 2022-06-24 01:27:52.964646
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    pass



# Generated at 2022-06-24 01:27:59.339125
# Unit test for method as_float of class Money
def test_Money_as_float():
    """
    Unit test for method as_float of class Money.
    """
    # Test that we can convert an undefined money object to float.
    assert NoMoney.as_float() == 0.0
    # Test that we can convert a defined money object to float.
    assert SomeMoney("USD", 100, Date.now()).as_float() == 100.0



# Generated at 2022-06-24 01:28:06.245944
# Unit test for method __round__ of class Money
def test_Money___round__():
    money = Money.of(ccy=Currency.USD, qty=Decimal(2), dov=Date(2019, 1, 1))

    assert (money).round(1) == SomeMoney(ccy=Currency(code='USD'), qty=Decimal('2.0'), dov=Date(2019, 1, 1))
    assert (money).round() == SomeMoney(ccy=Currency(code='USD'), qty=Decimal('2'), dov=Date(2019, 1, 1))



# Generated at 2022-06-24 01:28:17.799511
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    from nicelib.money import Money
    from cytoolz.functoolz import identity
    from cytoolz.dicttoolz import assoc
    from cytoolz.curried import map
    from cytoolz.functoolz import compose
    from cytoolz.functoolz import itemmap
    def g(x: Money) -> Money:
        return compose(Money.__lt__, identity)(x)
    def f(x: Money) -> int:
        return map(compose(Money.__lt__, identity))(x)
    def a(x: Money) -> Money:
        return compose(Money.__lt__, identity)(x)
    def b(x: int) -> int:
        return map(compose(Money.__lt__, identity))(x)

# Generated at 2022-06-24 01:28:19.963547
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    c = Currency.get("EUR")
    m = SomeMoney(c, 1000, Date.today())
    assert m.with_qty(2000) == SomeMoney(c, 2000, Date.today())


# Generated at 2022-06-24 01:28:28.986964
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    smoney = SomeMoney(Currency('AUD'), Decimal('10'), Date(2017, 11, 20))
    emoney = smoney.with_ccy(Currency('EUR'))

    # Incompatible currency:
    assert smoney <= emoney == False
    # Disagrement on quantity:
    assert smoney <= emoney.with_qty(Decimal('20')) == True
    # Disagreement on value date:
    assert smoney <= emoney.with_qty(Decimal('10')).with_dov(Date(2017, 11, 21)) == True
    # Equal:
    assert smoney <= smoney == True
    # Not equal:
    assert smoney <= smoney.with_dov(Date(2017, 11, 21)) == True
