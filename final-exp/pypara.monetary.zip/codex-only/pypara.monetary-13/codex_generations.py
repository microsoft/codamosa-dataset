

# Generated at 2022-06-24 01:18:29.029432
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    assert NotImplementedError == NoneMoney.convert.__doc__

# Generated at 2022-06-24 01:18:33.301212
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert (NoneMoney()).__bool__() == False


# Generated at 2022-06-24 01:18:39.680286
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .currencies import Currency

    # Test data
    qty = Decimal('100.00')

    # Test error path
    def test_Money___truediv__start():
        Currency.with_code('USD', name='US Dollar', numeric='840', fract_digits=2)
        Money = MoneyFactory.Money(Currency.with_code('USD', name='US Dollar', numeric='840', fract_digits=2))
        x = Money(qty=qty)
        y = Decimal('2.00')
        x.__truediv__(y)
    with raises(MonetaryOperationException):
        test_Money___truediv__start()


# Generated at 2022-06-24 01:18:49.561307
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    from decimal import Decimal
    from price.domain import Price, SomePrice
    from price.domain import NoPrice, NonePrice
    from price.domain import currency_from_string
    from datetime import date
    assert NonePrice().__truediv__(1.0) == NoPrice
    assert NonePrice().__truediv__(Decimal("1.0")) == NoPrice
    assert NonePrice().__truediv__(Price.of(currency_from_string("USD"), 1.0, date(2018, 11, 18))) == NoPrice
    assert NonePrice().__truediv__("1.0") == NoPrice

# Generated at 2022-06-24 01:18:55.276386
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    m = Money.of(EUR, Decimal(100))
    p = Price.of(EUR, Decimal(100), Date(2018, 1, 2))
    assert p.with_ccy(USD).money == m.with_ccy(USD)



# Generated at 2022-06-24 01:19:03.524530
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    # NoMoney.with_ccy()
    assert NoMoney.with_ccy(USD) == NoMoney
    assert NoMoney.with_ccy(GBP) == NoMoney
    assert NoMoney.with_ccy(EUR) == NoMoney
    # NoMoney.with_ccy(qty=ZZZ)
    assert NoMoney.with_ccy(USD, "ZZZ") == NoMoney
    # NoMoney.with_ccy(qty=ZZZ, dov=Date.today())
    assert NoMoney.with_ccy(USD, "ZZZ", Date.today()) == NoMoney
    # NoMoney.with_ccy(dov=Date.today())
    assert NoMoney.with_ccy(USD, dov=Date.today()) == NoMoney
NoMoney = NoneMoney()  # Singleton




# Generated at 2022-06-24 01:19:11.264534
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(USD, Decimal("1.00"), "1980-01-01") > NoPrice
    assert SomePrice(USD, Decimal("1.00"), "1980-01-01") > SomePrice(USD, Decimal("0.99"), "1980-01-01")
    # Must raise IncompatibleCurrencyError since currencies are different
    assert raises(IncompatibleCurrencyError, lambda: SomePrice(EUR, Decimal("0.99"), "1980-01-01") > SomePrice(USD, Decimal("0.99"), "1980-01-01"))



# Generated at 2022-06-24 01:19:14.997726
# Unit test for method negative of class Money
def test_Money_negative():
    assert Money.of(Currency.USD, 10, Date.today()).negative().is_equal(Money.of(Currency.USD, -10, Date.today()))
stub(Money)



# Generated at 2022-06-24 01:19:17.873674
# Unit test for method lt of class Price
def test_Price_lt():
    with pytest.raises(NotImplementedError):
        NoPrice.lt(SomePrice("USD", Decimal("1"), Date("2018-08-01")))


# Generated at 2022-06-24 01:19:20.276250
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    ccy = Currency("JPY")
    price = SomePrice(ccy, Decimal("100.00"), datetime.date(2018, 1, 1))
    assert price.with_ccy(Currency("USD")) == SomePrice(Currency("USD"), Decimal("100.00"), datetime.date(2018, 1, 1))



# Generated at 2022-06-24 01:19:21.209429
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    assert NoMoney.with_dov(Date.of(2020, 6, 1)) == NoMoney


# Generated at 2022-06-24 01:19:22.184809
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    assert NoPrice.__pos__() == 0

# Generated at 2022-06-24 01:19:22.884140
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    pass


# Generated at 2022-06-24 01:19:29.163740
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    m1 = SomeMoney(Currency('USD'), Decimal('100.123'), Date('2020-02-02'),)
    m2 = SomeMoney(Currency('USD'), Decimal('100.123'), Date('2020-02-02'),)
    assert m1.with_dov(Date('2019-01-01')) == m2.with_dov(Date('2019-01-01'))
    

    

# Generated at 2022-06-24 01:19:41.301081
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    from . import Money
    from . import NonePrice
    from . import SomeMoney
    from . import Currency
    from . import UTC
    from . import Date
    from . import FXRate
    from . import FXRateService
    from . import Decimal
    from . import NoMoney
    from . import Money
    from . import SomeMoney
    from . import NoPrice
    from . import SomePrice
    from . import Price
    from . import NonePrice
    from . import NA
    from . import NoMoney
    from . import Money
    from . import SomeMoney
    from . import NoPrice
    from . import SomePrice
    from . import Currency
    from . import UTC
    from . import Date
    from . import FXRate
    from . import FXRateService
    from . import NoMoney
    from . import Money
    from . import SomeMoney

# Generated at 2022-06-24 01:19:50.662958
# Unit test for method __round__ of class Price
def test_Price___round__():
    assert Price(Currency('USD'), Decimal('1'), Date(2019, 9, 1)).__round__() == 1
    assert Price(Currency('USD'), Decimal('1.00'), Date(2019, 9, 1)).__round__() == 1
    assert Price(Currency('USD'), Decimal('1.01'), Date(2019, 9, 1)).__round__() == 1
    assert Price(Currency('USD'), Decimal('1.50'), Date(2019, 9, 1)).__round__() == 2
    assert Price(Currency('USD'), Decimal('1.51'), Date(2019, 9, 1)).__round__() == 2
    assert Price(Currency('USD'), Decimal('1.25'), Date(2019, 9, 1)).__round__() == 1

# Generated at 2022-06-24 01:20:00.373460
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    the_money = SomeMoney("USD", Decimal(1.23456789), Date.today())
    assert the_money == the_money.round()
    assert the_money == the_money.round(0)
    assert the_money == the_money.round(-1)
    assert SomeMoney("USD", Decimal("1.234"), Date.today()) == the_money.round(-3)
    assert SomeMoney("USD", Decimal("1.2345"), Date.today()) == the_money.round(-4)
    assert SomeMoney("USD", Decimal("1.23457"), Date.today()) == the_money.round(-5)
    assert SomeMoney("USD", Decimal("1.234568"), Date.today()) == the_money.round(-6)

# Generated at 2022-06-24 01:20:02.034065
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    assert float(NoPrice) == 0.0

# Generated at 2022-06-24 01:20:10.131625
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    from financepy.products.bonds.FinBond import FinBond
    from financepy.markets.curves.FinDiscountCurveFlat import FinDiscountCurveFlat
    from financepy.markets.curves.FinInterpolator import FinInterpTypes
    from financepy.finutils.FinDate import FinDate

    # Create a flat rate discount curve
    settlementDate = FinDate(2018, 12, 3)
    discountCurve = FinDiscountCurveFlat(settlementDate, 0.05, FinInterpTypes.FLAT_FWD_RATES, 0.05)

    maturityDate = FinDate(2028, 12, 3)
    coupon = 0.05
    freqType = FinFrequencyTypes.SEMI_ANNUAL
    accrualType = FinDayCountTypes.ACT_ACT_ICMA
   

# Generated at 2022-06-24 01:20:12.582002
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    X = SomeMoney('AUD', '1000', '2018-01-01')
    assert X.ccy == 'AUD'
    assert X.qty == '1000'
    assert X.dov == '2018-01-01'
    Y = SomeMoney(ccy='AUD', qty='1000', dov='2018-01-01')
    assert Y == X


# Generated at 2022-06-24 01:20:16.918424
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    money=SomeMoney(Currency("HKD"),Decimal(10000),Date(2018,5,5))
    res=money.scalar_subtract(100)
    assert repr(res)=="SomeMoney(ccy=Currency(HKD), qty=Decimal('9900'), dov=Date(2018, 5, 5))"

# Generated at 2022-06-24 01:20:24.371621
# Unit test for method as_float of class Money
def test_Money_as_float():
    from .currencies import EUR, TRY
    from .date import TODAY
    from .money import Money
    from .price import Price

    # Arrange
    some_money: Money = Money.of(EUR, Decimal("4.5"), TODAY)
    expected_float_value: float = 4.5

    # Act
    float_value: float = some_money.as_float()

    # Assert
    assert float_value == expected_float_value
    assert isinstance(float_value, float)



# Generated at 2022-06-24 01:20:33.059223
# Unit test for method __round__ of class Money
def test_Money___round__():
    from hypothesis import strategies as st

    from ..commons.testing import result_value_validity, strategy_money, strategy_zzz_monetary_value
    from ..currencies import Currency
    from ..exchange import FXRateService
    from ..primitives import ValueType
    from ..sessions import Session

    # As the monetary values are randomly generated, we use the real foreign exchange service.
    session = Session()
    fx_service = session.services.rates
    money = strategy_money(
        ccy=st.none() | st.sampled_from(Currency),
        qty=st.one_of(st.none(), st.just(0), st.decimals(min_value=1)),
        dov=st.one_of(st.just(Date.today()), st.none()),
    ).example()

# Generated at 2022-06-24 01:20:39.703714
# Unit test for method lt of class Money
def test_Money_lt():
    assert NoMoney < NoMoney
    assert not (NoMoney < SomeMoney(Currency.USD, 1, Date.Today))
    assert SomeMoney(Currency.USD, 1, Date.Today) < SomeMoney(Currency.USD, 2, Date.Today)
    assert SomeMoney(Currency.USD, 1, Date.Today) < SomeMoney(Currency.EUR, 1, Date.Today)
    assert not (SomeMoney(Currency.USD, 2, Date.Today) < SomeMoney(Currency.USD, 1, Date.Today))


# Generated at 2022-06-24 01:20:42.817718
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    t1 = SomePrice(Currency('USD'), Decimal(10), date(2018, 9, 12))
    t2 = t1 // Decimal(2) # type: ignore
    assert t2.qty == Decimal(5)
    assert t2.ccy == Currency('USD')
    assert t2.dov == date(2018, 9, 12)


# Generated at 2022-06-24 01:20:47.981152
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    with raises(TypeError):
        somePrice1 = SomePrice(Currency("EUR"), Decimal("100"), Date(2004, 11, 1))
        somePrice1.__neg__()
        somePrice2 = SomePrice(Currency("JPY"), Decimal("23"), Date(2011, 10, 30))
        somePrice2.__neg__()
    assert NonePrice().__neg__() is NonePrice()



# Generated at 2022-06-24 01:20:59.640011
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    from .currency import Currency as Currency
    from .currency import CurrencyLookupError as CurrencyLookupError
    from .currency import CurrencyService as CurrencyService
    from .price import SomePrice as SomePrice
    from .price import Price as Price
    from .price import IncompatibleCurrencyError as IncompatibleCurrencyError
    from .money import Money as Money
    from .money import NoMoney as NoMoney
    from .money import SomeMoney as SomeMoney
    from .money import Money as Money
    from .money import IncompatibleCurrencyError as IncompatibleCurrencyError
    from .fx_rate import FXRate as FXRate
    from .fx_rate import FXRateLookupError as FXRateLookupError
    from .fx_rate import FXRateService as FXRateService

    ## Price math:
    USD = Currency.of("USD")

# Generated at 2022-06-24 01:21:05.209259
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    a = Money(currency='USD', quantity=12, value_date=Date(year=2020, month=3, day=8))
    assert a.scalar_subtract(12) == Money(currency='USD', quantity=0, value_date=Date(year=2020, month=3, day=8))


# Generated at 2022-06-24 01:21:12.280657
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    # price1 = SomePrice(model.Currency("USD"), model.Decimal("1234"), model.Date("2019-01-01"))
    price1 = SomePrice(Currency("USD"), Decimal("1234"), Date("2019-01-01"))
    # price2 = model.SomePrice(model.Currency("USD"), model.Decimal("1233"), model.Date("2019-01-02"))
    # price3 = model.SomePrice(model.Currency("EUR"), model.Decimal("1234"), model.Date("2019-01-02"))
    price2 = SomePrice(Currency("USD"), Decimal("1233"), Date("2019-01-02"))
    price3 = SomePrice(Currency("EUR"), Decimal("1234"), Date("2019-01-02"))
    # assert price1.__le__(

# Generated at 2022-06-24 01:21:17.977392
# Unit test for method as_float of class Money
def test_Money_as_float():
    from decimal import Decimal
    from money.api import Money
    from money.currencies import USD, EUR, GBP
    from datetime import date
    
    assert Money(10, USD).as_float() == 10.
    assert Money(1.1, USD).as_float() == 1.1
    assert Money(1.1, EUR).as_float() == 1.1
    assert Money(Decimal(1.1), EUR).as_float() == 1.1
    assert Money(12.34, USD, date(2020,1,1)).as_float() == 12.34
    assert Money(Decimal(12.34), USD, date(2020,1,1)).as_float() == 12.34
    assert Money.of(USD,None,None).as_float() == 0.
    

# Generated at 2022-06-24 01:21:29.962995
# Unit test for method divide of class Price
def test_Price_divide():
    # Passes
    assert(Price.of('USD', 2, '2018-01-01').divide(1) == Price.of('USD', 2, '2018-01-01'))
    assert(Price.of('USD', None, '2018-01-01').divide(1) == Price.of('USD', None, '2018-01-01'))
    assert(Price.of('USD', 0, '2018-01-01').divide(3) == Price.of('USD', 0, '2018-01-01'))
    assert(Price.of('USD', 3, '2018-01-01').divide(3) == Price.of('USD', 1, '2018-01-01'))

# Generated at 2022-06-24 01:21:36.285621
# Unit test for method __le__ of class Price
def test_Price___le__():

    assert (Price(USD, Decimal(1), date(2019, 12, 31)) <= Price(USD, Decimal(1), date(2019, 12, 31)))
    assert (Price(USD, Decimal(1), date(2019, 12, 31)) <= Price(USD, Decimal(2), date(2019, 12, 31)))
    assert (Price(USD, Decimal(2), date(2019, 12, 31)) <= Price(USD, Decimal(1), date(2019, 12, 31)) == False)
    assert (Price(USD, Decimal(1), date(2019, 12, 31)) <= Price(USD, Decimal(1), date(2020, 1, 1)) == False)

# Generated at 2022-06-24 01:21:45.893269
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    assert SomePrice(ccy("USD"), Decimal("1.000000"), Date("2019-01-01")) == SomePrice(ccy("USD"), Decimal("1.000000"), Date("2019-01-01"))
    assert SomePrice(ccy("USD"), Decimal("1.000000"), Date("2019-01-01")) != SomePrice(ccy("USD"), Decimal("0.000000"), Date("2019-01-01"))
    assert SomePrice(ccy("USD"), Decimal("1.000000"), Date("2019-01-01")) != SomePrice(ccy("USD"), Decimal("1.000000"), Date("2019-01-31"))

# Generated at 2022-06-24 01:21:50.993710
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert(Money.of(ccy='USD', qty=Decimal('1.5'), dov='2018-08-01').__ge__(Money.of(ccy='USD', qty=Decimal('1.5'), dov='2018-08-01')))



# Generated at 2022-06-24 01:22:01.053938
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    ## Try comparing two incompatible currency objects:
    try:
        SomePrice(Currency.USD, Decimal("10"), TODAY) <= SomePrice(Currency.EUR, Decimal("20"), TODAY)
    except IncompatibleCurrencyError as exc:
        assert exc.args == (Currency.USD, Currency.EUR, "<= comparison")
    else:
        raise AssertionError("Not raised")

    ## Try comparing two price objects:
    assert SomePrice(Currency.USD, Decimal("10"), TODAY) <= SomePrice(Currency.USD, Decimal("10"), TODAY)
    assert SomePrice(Currency.USD, Decimal("10"), TODAY) <= SomePrice(Currency.USD, Decimal("20"), TODAY)

# Generated at 2022-06-24 01:22:06.996564
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert Price.NA.__bool__() is False
    assert NoPrice.__bool__() is False
    assert Price.of(EUR, 0, date(2019, 2, 20)).__bool__() is False
    assert Price.of(EUR, Decimal("1.0"), date(2019, 2, 20)).__bool__() is True
    assert Price.of(USD, Decimal("1.0"), date(2019, 2, 20)).__bool__() is True

# Generated at 2022-06-24 01:22:12.157203
# Unit test for constructor of class NonePrice
def test_NonePrice():
    '''
    Test if the constructor works
    '''
    np = NonePrice()

## Define the singleton NA price:
NoPrice = NonePrice()

# Generated at 2022-06-24 01:22:22.586802
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert SomePrice(CAD, Decimal(0.0), asof).as_integer() == 0
    assert SomePrice(CAD, Decimal(1.0), asof).as_integer() == 1
    assert SomePrice(CAD, Decimal(2.0), asof).as_integer() == 2
    assert SomePrice(CAD, Decimal(3.5), asof).as_integer() == 3
    assert SomePrice(CAD, Decimal(4.9999), asof).as_integer() == 4
    assert SomePrice(CAD, Decimal(5.0000), asof).as_integer() == 5
    assert SomePrice(CAD, Decimal(5.0001), asof).as_integer() == 5

# Generated at 2022-06-24 01:22:27.841422
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    from datetime import date
    from testfixtures import Comparison as C
    from .currencies import USD, ZAR
    from .exchange import FXRateService
    usd_zar = FXRateService(base=USD, terms=[ZAR], values=[4.20])
    assert isinstance(Money.of(USD, 1, date(2018, 1, 1)) >= Money.of(USD, 1, date(2018, 1, 1)), bool)
    assert Money.of(USD, 2, date(2018, 1, 1)) >= Money.of(USD, 1, date(2018, 1, 1))
    assert Money.of(USD, 1, date(2018, 1, 1)) >= Money.of(USD, 1, date(2018, 1, 1))
    assert not  Money.of(USD, 1, date(2018, 1, 1)) >= Money

# Generated at 2022-06-24 01:22:32.129948
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    """
    Unit test for method floor_divide of class Money
    """
    x = Money.of(Currency.of('USD'), 1, Date.today())
    assert x.floor_divide(2) == SomeMoney.of(Currency.of('USD'), 0.5, Date.today())

# Generated at 2022-06-24 01:22:39.374727
# Unit test for method positive of class Price
def test_Price_positive():
    import hamcrest as hc
    from decimal import Decimal

    # Some Price
    m12 = Price.of(USD, Decimal(12), Date.today())
    hc.assert_that(m12.positive(), hc.is_(m12))
    hc.assert_that(hc.is_not(m12.positive(), NoPrice))
    # No Price
    hc.assert_that(NoPrice.positive(), hc.is_(NoPrice))


# Generated at 2022-06-24 01:22:51.887463
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    """
    Unit test for method __eq__ of class SomePrice
    """
    # Setup
    p1 = Price.of(Currency("USD"), Decimal("100.00"), Date("2018-12-31")) # type: ignore
    p2 = Price.of(Currency("USD"), Decimal("100.00"), Date("2018-12-31")) # type: ignore
    p3 = Price.of(Currency("JPY"), Decimal("100.00"), Date("2018-12-31")) # type: ignore
    p4 = Price.of(Currency("USD"), Decimal("101.00"), Date("2018-12-31")) # type: ignore
    p5 = Price.of(Currency("USD"), Decimal("100.00"), Date("2019-12-31")) # type: ignore

# Generated at 2022-06-24 01:23:01.921556
# Unit test for method divide of class Price
def test_Price_divide():
    from datetime import date
    from e3.env import Env
    from xl.money import Money, Price
    from xl.money.exchange import Exchanges, FXRateLookupError
    from xl.money.models import USD

    Env("~/e3")
    exchanges = Exchanges()
    assert exchanges.load("dukascopy")
    assert exchanges.of("CHF", USD, date(2019, 8, 8)).as_decimal() == 1.10
    assert exchanges.of("CHF", USD, date(2019, 8, 8)).as_decimal() == 1.10

    assert Money(100, "USD") / Price(exchanges.of("CHF", "USD", date(2019, 8, 8)).as_decimal(), "USD") == Money(90, "USD")

# Generated at 2022-06-24 01:23:07.858940
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from pyhkd import SomeMoney
    from pyhkd.currencies import Currency
    from pyhkd.zeitgeist import Date
    m = SomeMoney(Currency('EUR'),Decimal(100.0),Date(2030,12,31))
    assert m.with_dov(Date(2020,12,31)) == SomeMoney(Currency('EUR'),Decimal(100.0),Date(2020,12,31))



# Generated at 2022-06-24 01:23:13.674488
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    """
    Tests method __gt__ of class NoneMoney
    """
    nonemoney_obj_0 = NoneMoney()
    money_obj_0 = SomeMoney(USD, Decimal('0.000'), Date(2019, 4, 1))
    assert_equal(nonemoney_obj_0.__gt__(money_obj_0), False)


# Generated at 2022-06-24 01:23:15.418660
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    assert (NoMoney == NoMoney) is True



# Generated at 2022-06-24 01:23:22.661827
# Unit test for method negative of class Money
def test_Money_negative():
    ######################################################################################################
    # Test the method negative of the class Money
    ######################################################################################################

    with open("/Users/imrul/PycharmProjects/untitled/venv/test_Money_negative.txt", "w") as outfile:

        def cprint(content: str):
            print(content)
            outfile.write(content + "\n")

        cprint("Negative Test: Money.negative")
        cprint("Invalid input test")

        # Invalid input test
        # Money object is None

# Generated at 2022-06-24 01:23:26.067048
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    with raises(TypeError, match="Undefined monetary values do not have quantity information"):
        NoMoney > NoMoney
    with raises(TypeError, match="Undefined monetary values do not have quantity information"):
        NoMoney > 1
    assert not NoMoney > NoMoney
    assert not NoMoney > 1.2



# Generated at 2022-06-24 01:23:34.966448
# Unit test for method abs of class Price
def test_Price_abs():
    nmp = Price.of(Currency.USD, Decimal("-112.32"), Date.today())
    p1  = Price.of(Currency.USD, Decimal("112.32"), Date.today())
    p2  = Price.of(Currency.USD, Decimal("112.32"), Date.today())
    nmp_abs = Price.of(Currency.USD, Decimal("112.32"), Date.today())

    assert nmp.abs() == nmp_abs
    assert p1.abs() == p2



# Generated at 2022-06-24 01:23:38.561656
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert Price.of(usd, Decimal("1.0"), Date.today()) + Price.of(usd, Decimal("2.0"), Date.today()) == Price.of(usd, Decimal("3.0"), Date.today())


# Generated at 2022-06-24 01:23:47.814331
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    # Setup:
    ccy1 = Currency.usd()
    qty1 = Decimal('100.00')
    dov1 = Date.today()
    target1 = SomePrice(ccy1, qty1, dov1)
    from_ccy = Currency.usd()
    to_ccy = Currency.eur()
    asof = Date.today()
    strict = False

    # Exercise:
    actual = target1.convert(to_ccy, asof, strict)

    # Verify:
    expected = SomePrice(ccy1, qty1, dov1)
    assert expected == actual

# Generated at 2022-06-24 01:23:53.348568
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    a = SomeMoney(CAD, Decimal("1.23"), date(2016, 10, 10))
    b = a.__neg__()
    assert b.__class__ is SomeMoney
    assert b.ccy == CAD
    assert b.qty == Decimal("-1.23")
    assert b.dov == date(2016, 10, 10)



# Generated at 2022-06-24 01:23:56.246531
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    # Test case data
    ccy = None

    # Perform the test
    result = NoneMoney.with_ccy(ccy)

    # Check the result
    assert isinstance(result, NoneMoney)



# Generated at 2022-06-24 01:24:05.670583
# Unit test for method __int__ of class Price
def test_Price___int__():
    contract = Contract(Notional(USD, 1_000), "2019-01-01", "2020-01-01", CancellationPenalty.ZERO)
    assert int(FXRate(USD, EUR, 0.85, "2020-01-01").value(contract)) == int(Money(USD, 1_000).convert(EUR))
    assert int(FXRate(USD, EUR, 0.85, "2020-01-01").value(contract).with_qty(0.85)) == int(
        Money(USD, 1_000).convert(EUR).with_qty(0.85))

# Generated at 2022-06-24 01:24:11.201385
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    try:
        raise MonetaryOperationException()
    except MonetaryOperationException as ex:
        assert ex.args[0] == "Monetary data structure cannot be operated on."



# Generated at 2022-06-24 01:24:19.837703
# Unit test for method __add__ of class Money
def test_Money___add__():
    def test(in1, in2, out):
        """
        Parameters
        ----------
        in1 : Money
        in2 : Money
        out : Money

        Returns
        -------
        None

        """
        o = in1.__add__(in2)
        if o != out:
            raise RuntimeError(
                "Error on operation __add__ with input: %s %s" % (in1, in2)
            )


    test(SomeMoney(currencies.ILS, Decimal(1.0), Date(2018, 1, 1)), SomeMoney(
        currencies.ILS, Decimal(1.0), Date(2018, 1, 1)), SomeMoney(currencies.ILS, Decimal(2.0),
                                                                   Date(2018, 1, 1)))

# Generated at 2022-06-24 01:24:32.241224
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():

    # Define fixtures
    ## FIXTURE 1:
    some_price_1 = SomePrice("USD", Decimal("0.123"), Date("2019-06-28"))
    ## FIXTURE 2:
    some_price_2 = SomePrice("USD", Decimal("0.123"), Date("2019-06-28"))
    ## FIXTURE 3:
    some_price_3 = SomePrice("USD", Decimal("0.124"), Date("2019-06-28"))
    ## FIXTURE 4:
    some_price_4 = SomePrice("EUR", Decimal("0.123"), Date("2019-06-28"))
    ## FIXTURE 5:
    some_price_5 = SomePrice("EUR", Decimal("0.124"), Date("2019-06-29"))

    # Test itself
    ## This should pass


# Generated at 2022-06-24 01:24:44.413823
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    global NoPrice
    global SomePrice
    ## Basic:
    # NB: remember that we are testing the NonePrice class,
    # NOT the NoPrice global variable (which is an instance
    # of NonePrice.
    assert NonePrice(None, None, None) < SomePrice(EUR, Decimal("42"), Date.today())
    assert NonePrice(None, None, None) <= SomePrice(EUR, Decimal("42.0000"), Date.today())
    assert not (NonePrice(None, None, None) > SomePrice(EUR, Decimal("42"), Date.today()))
    assert not (NonePrice(None, None, None) >= SomePrice(EUR, Decimal("42.0000"), Date.today()))


## Unit test for method __eq__ of class NonePrice

# Generated at 2022-06-24 01:24:50.182607
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    """
    Tests that the method with_qty of class NoneMoney behaves as expected.

    """
    ccy, qty, dov = Currency("GBP", 2), Decimal("1.23"), Date(2020, 1, 1)
    result = NoneMoney.with_qty(qty)
    assert result.__eq__(NoneMoney)
    return

# Generated at 2022-06-24 01:24:51.910930
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    assert (NoPrice.round() == NoPrice)



# Generated at 2022-06-24 01:24:59.771675
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    # noinspection PyShadowingNames
    def impl(price: Price) -> bool:
        return price.__bool__()

    def test(price: Price, expected: bool):
        assert impl(price) == expected

    test(SomePrice(USD, Decimal("1.0"), TODAY), True)
    test(SomePrice(USD, Decimal("0.0"), TODAY), False)
    test(SomePrice(USD, Decimal("0.0"), TODAY), False)
    test(SomePrice(USD, Decimal("-1.0"), TODAY), True)
    test(NoPrice, False)

# Generated at 2022-06-24 01:25:04.993047
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    _return = NoneMoney( ) / 1
    assert isinstance(_return, Money)
    assert not _return.defined
    assert _return.undefined
    assert not _return



# Generated at 2022-06-24 01:25:12.072256
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    some_price = Price.of(USD, 1, TODAY)
    some_dov = TONIGHT
    actual = some_price.with_dov(some_dov)

    assert actual.is_equal(Price.of(USD, 1, some_dov))



# Generated at 2022-06-24 01:25:16.253918
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert SomePrice(USD, 10, TODAY).convert(EUR) == SomePrice(EUR, 8.3, TODAY)
    assert SomePrice(EUR, 10, TODAY).convert(USD) == SomePrice(USD, 12, TODAY)

# Generated at 2022-06-24 01:25:26.859236
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    x = SomePrice(Currency("USD"), Decimal("5.5"), Date.today())

    assert(x.__le__(x))

    y = SomePrice(Currency("USD"), Decimal("4.4"), Date.today())
    z = SomePrice(Currency("USD"), Decimal("6.6"), Date.today())

    assert(y.__le__(x))
    assert(x.__ge__(y))

    assert(not z.__le__(x))
    assert(not x.__ge__(z))

    # Test the undefined case:
    assert(x.__le__(NoPrice))
    assert(not NoPrice.__le__(x))
test_SomePrice___le__()


# Generated at 2022-06-24 01:25:29.271057
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    p = NonePrice()
    assert p.scalar_subtract(1) is p

# Generated at 2022-06-24 01:25:37.433977
# Unit test for method lte of class Price
def test_Price_lte():
    assert SomePrice(USD, Decimal(1), NullDate).lte(SomePrice(USD, Decimal(2), NullDate)) == True


## Specification of abstract methods.

# Generated at 2022-06-24 01:25:38.771675
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():

    assert (float(NoMoney) == 0.0)


# Generated at 2022-06-24 01:25:43.156832
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():  # noqa
    usd = Currency.of("USD")

    m = SomeMoney(usd, Decimal("3"), Date.today())
    assert m.floor_divide(Decimal("0")) is NoMoney
    assert m.floor_divide(Decimal("2")) == SomeMoney(usd, Decimal("1"), Date.today())



# Generated at 2022-06-24 01:25:51.114214
# Unit test for method lte of class Money
def test_Money_lte():
    assert Money.of(None, None, None) <= Money.of(None, None, None)
    assert Money.of(None, qty=1, dov=Date(2018, 1, 1)) <= Money.of(Currency.USD, qty=1, dov=Date(2018, 1, 1))
    assert Money.of(Currency.USD, qty=1, dov=Date(2018, 1, 1)) <= Money.of(Currency.USD, qty=1, dov=Date(2018, 1, 1))
    assert Money.of(Currency.USD, qty=1, dov=Date(2018, 1, 1)) <= Money.of(Currency.USD, qty=2, dov=Date(2018, 1, 1))

# Generated at 2022-06-24 01:25:54.764847
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    """
    NoMoney + Money == Money
    Money + Money == Money
    """
    ccy = Currency("USD")
    qty = Decimal("100.00")
    some_money = SomeMoney(ccy, qty, Date.today())
    #no_money = NoMoney()
    scalar = Decimal("100.00")
    #print(some_money + no_money)
    print(some_money + scalar)
#test_SomeMoney_scalar_add()


# Generated at 2022-06-24 01:25:59.816123
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    ccy1 = Currency.EUR
    ccy2 = Currency.USD
    op = "X+Y"

    ex = IncompatibleCurrencyError(ccy1, ccy2, op)

    assert ex.ccy1 == ccy1
    assert ex.ccy2 == ccy2
    assert ex.operation == op

    assert str(ex) == "EUR vs USD are incompatible for operation 'X+Y'."



# Generated at 2022-06-24 01:26:09.027128
# Unit test for method positive of class Price
def test_Price_positive():
    x1 = Price.of(ccy=Currency.of('USD'), qty=Decimal('5.5'), dov=Date.of(2018, 10, 1))
    x2 = Price.of(ccy=Currency.of('USD'), qty=Decimal('-5.5'), dov=Date.of(2018, 10, 1))
    x3 = Price.of(ccy=Currency.of('USD'), qty=Decimal('0'), dov=Date.of(2018, 10, 1))
    assert x1.positive() == x1
    assert x2.positive() == x1
    assert x3.positive() == x3
    


# Generated at 2022-06-24 01:26:12.492069
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    np = NonePrice()
    try:
        assert np.__floordiv__(np) is NonePrice()
    except Exception:
        raise

    return True

# Generated at 2022-06-24 01:26:25.294971
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    def __le__(self, other: "Price") -> bool:
        if other.undefined:
            return False
        elif self.ccy != other.ccy:
            raise IncompatibleCurrencyError(ccy1=self.ccy, ccy2=other.ccy, operation="<= comparision")
        return self.qty <= other.qty
    from trading.domain.price import SomePrice as SP
    from trading.domain.price import IncompatibleCurrencyError as ICE
    from trading.domain.currency import EUR as EUR
    from trading.domain.currency import USD as USD
    _EURUSD = EUR/USD
    assert SP(EUR, 1, "20200701").__le__(SP(USD, 1, "20200701"))

# Generated at 2022-06-24 01:26:33.740707
# Unit test for method lte of class Money
def test_Money_lte():
    assert SomeMoney(ccy=Currency.of('CAD'), qty=Decimal(100), dov=Date.today()) <= SomeMoney(ccy=Currency.of('CAD'), qty=Decimal(100), dov=Date.today())
    assert NoMoney <= SomeMoney(ccy=Currency.of('CAD'), qty=Decimal(100), dov=Date.today())
    assert not SomeMoney(ccy=Currency.of('CAD'), qty=Decimal(100), dov=Date.today()) <= NoMoney
    


# Generated at 2022-06-24 01:26:35.934778
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    money = SomeMoney('USD', Decimal('1.222'), Date(2020, 2, 1))
    money = money.round(2)
    assert isinstance(money, SomeMoney)



# Generated at 2022-06-24 01:26:40.244674
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    assert NoMoney.__int__() == 0


# Generated at 2022-06-24 01:26:43.108203
# Unit test for method __le__ of class Price
def test_Price___le__():
    """
    Tests that::

    1. Undefined price objects are always less than or equal to other, and
    2. :class:`IncompatibleCurrencyError` is raised when comparing two defined price objects with different currencies.
    """
    pass

# Generated at 2022-06-24 01:26:51.545546
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    from .currencies import USD
    from .money import Money

    assert Money.of(USD, 100, Date.today()) == Money.of(USD, 100, Date.today())
    assert Money.of(USD, 100, Date.today()) == Money.of(USD, 100, Date.today().next_day())
    assert Money.of(USD, 100, Date.today()) != Money.of(USD, 99, Date.today())
    assert Money.of(USD, 100, Date.today()) != Money.of(USD, 100, Date.today().next_day())

    assert Money.of(USD, 100, Date.today()) == Money.of(USD, 100, Date.today()).round()
    assert Money.of(USD, 100, Date.today()) == Money.of(USD, 100.0001, Date.today()).round()


# Generated at 2022-06-24 01:27:02.161414
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    a = Price.of(GBP, Decimal('100'), DOV)
    b = Price.of(GBP, Decimal('1000'), DOV)
    assert a / 2 == Price.of(GBP, Decimal('50'), DOV)
    assert abs(b / 2 - Price.of(GBP, Decimal('500'), DOV)) < 1e-15
    assert a / Price.of(GBP, Decimal('2'), DOV) == Price.of(GBP, Decimal('50'), DOV)
    assert b / Price.of(GBP, Decimal('2'), DOV) == Price.of(GBP, Decimal('500'), DOV)


# Generated at 2022-06-24 01:27:06.907893
# Unit test for method __le__ of class Money
def test_Money___le__():
    # Set the __le__ method of class Money
    def __le__(self, other: "Money") -> bool:
        return self.lt(other) or self.is_equal(other)
    Money_type.__le__ = __le__
    # Test the body of method __le__ of class Money


# Generated at 2022-06-24 01:27:16.709205
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    assert SomeMoney(USD, 1, datetime.date.today()) == SomeMoney(USD, 1, datetime.date.today()).with_ccy(USD)
    assert SomeMoney(USD, 1, datetime.date.today()) != SomeMoney(USD, 1, datetime.date.today()).with_ccy(EUR)
    assert SomeMoney(USD, 1, datetime.date.today()) != SomeMoney(USD, 2, datetime.date.today()).with_ccy(USD)
    assert SomeMoney(USD, 1, datetime.date.today()) != SomeMoney(USD, 2, datetime.date.today())
# $end-of-test$


# Generated at 2022-06-24 01:27:24.199226
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    assert (Money.of(USD, Decimal(100), None) - Money.of(USD, Decimal(100), None)) == Money.of(USD, Decimal(0), None)
    assert (Money.of(USD, Decimal(100), None) - Money.of(USD, Decimal(99), None)) == Money.of(USD, Decimal(1), None)
    assert (Money.of(USD, Decimal(100), None) - Money.of(USD, Decimal(-99), None)) == Money.of(USD, Decimal(199), None)
    assert (Money.of(USD, Decimal(-100), None) - Money.of(USD, Decimal(-99), None)) == Money.of(USD, Decimal(-1), None)

# Generated at 2022-06-24 01:27:27.252161
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from decimal import Decimal
    from datetime import date
    from ..currencies import Currency

    assert Money.of(Currency.ccy("USD"), Decimal(5), date.today()).as_integer()==5

# Generated at 2022-06-24 01:27:28.309610
# Unit test for method __le__ of class NoneMoney
def test_NoneMoney___le__():
    pass
## -- End: class


NoMoney: Money = NoneMoney()
## -- End: class



# Generated at 2022-06-24 01:27:39.010575
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import EUR, USD
    from .exchange import FXRateService, FIXER
    from .spot import Spot, SpotOverrides
    from datetime import date
    from decimal import Decimal
    assert (USD(1) - USD(1)) == USD(0)
    assert (USD(1) - USD(-1)) == USD(2)
    assert (USD(-1) - USD(1)) == USD(-2)
    assert (USD(-1) - USD(-1)) == USD(0)
    assert (USD(1).with_qty(None) - USD(1)) == NoMoney
    assert (USD(1) - USD(1).with_qty(None)) == NoMoney

# Generated at 2022-06-24 01:27:49.781454
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():

    # Set up context:
    SomePrice = sdt.sd_price.SomePrice
    ccy = Currency.USD
    qty = Decimal("3.14")
    dov = Date.today()
    p1 = SomePrice(ccy, qty, dov)
    p2 = SomePrice(ccy, qty, dov)
    p3 = SomePrice(ccy, qty, dov - 1)
    p4 = SomePrice(Currency.CNY, qty, dov)
    p5 = SomePrice(ccy, qty * 2, dov)
    p6 = SomePrice(ccy, qty, dov + 1)
    p7 = SomePrice(ccy, qty / 2, dov)
    p8 = SomePrice(ccy, qty // 2, dov)


# Generated at 2022-06-24 01:27:54.565343
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    # Arrange
    from moneyed import GBP
    from moneyed.money import Money as Money

    foo = Money(GBP, 2, Date.today())
    bar = Money(GBP, 2, Date.today())
    # Act
    actual_result = foo >=bar
    # Assert
    assert (actual_result == True)


# Generated at 2022-06-24 01:28:05.839851
# Unit test for method multiply of class Price
def test_Price_multiply():
  """
  Method multiply of class Price
  """
  
  # Declare any variables you need
  currency = Currency('USD')
  price1 = Price.of(currency, Decimal('0'), Date('20170301'))
  price2 = Price.of(currency, Decimal('1.22'), Date('20170301'))
  
  # Run your code
  price1_result = price1.multiply(Decimal('0'))
  price2_result = price2.multiply(Decimal('1.22'))
  
  # Check the result
  assert price1_result.defined == False
  assert price2_result.defined == True
  assert price2_result.qty == Decimal('1.4884')
  assert price2_result.ccy == Currency('USD')
  assert price2_

# Generated at 2022-06-24 01:28:08.917767
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert Money.NA.is_equal(Money.NA) == True


# Generated at 2022-06-24 01:28:13.623592
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    some_money = SomeMoney(USD, UNIT, Date(2020, 3, 1))
    assert (-some_money).ccy == USD
    assert (-some_money).qty == -UNIT
    assert (-some_money).dov == Date(2020, 3, 1)



# Generated at 2022-06-24 01:28:15.713674
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoMoney
test_NoneMoney___bool__.__name__ = "test_NoneMoney___bool__"


# Generated at 2022-06-24 01:28:21.970344
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    a1 = NoneMoney
    a2 = NoneClass()
    a3 = NoneMoney
    assert not (a1 < a2)
    assert not (a1 < a3)


# Generated at 2022-06-24 01:28:27.988054
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    import pytest  # type: ignore
    from pytest import raises  # type: ignore
    from daedalus.core import Price
    from daedalus.core import Currency
    from daedalus.core import Date

    with raises(AttributeError) as excinfo:
        Price.SomePrice.of(ccy=Currency.of('USD'), qty=Decimal('1.5'), dov=Date.of('2019-02-02')).__abs__()
    assert str(excinfo.value) == "__abs__"

