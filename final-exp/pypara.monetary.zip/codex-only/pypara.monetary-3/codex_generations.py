

# Generated at 2022-06-24 01:18:31.262061
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    ccy = USD
    qty = ONE
    dov = today()
    expected = SomeMoney(ccy, qty, dov)
    expected = -expected if expected is not NoMoney else NoMoney
    actual = SomeMoney(ccy, qty, dov)
    actual = -actual if actual is not NoMoney else NoMoney
    assert actual == expected

# Generated at 2022-06-24 01:18:42.852130
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    """
    Tests method __add__ of class NonePrice
    """
    # Define some quantities
    c1 = USD
    c2 = JPY
    q1 = Decimal(3)
    q2 = Decimal(7)
    d1 = Date(1, 1, 1)
    d2 = Date(2, 2, 2)
    p1 = SomePrice(c1, q1, d1)
    p2 = SomePrice(c2, q2, d2)

    # Define expected result
    n = NoPrice

    # Basic test
    assert n + p1 is p1
    assert n + p2 is p2
    assert p1 + n is p1
    assert p2 + n is p2

    # Test exception is raised when trying to add different currencies

# Generated at 2022-06-24 01:18:50.091902
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    ccy = Currency("GBP")
    qty = Decimal("10.47")
    dov = Date(2018, 1, 1)
    price = SomePrice(ccy, qty, dov)
    ccy1 = Currency("USD")
    with_ccy = price.with_ccy(ccy1)
    assert with_ccy.ccy == ccy1
    assert with_ccy.qty == qty
    assert with_ccy.dov == dov

# Generated at 2022-06-24 01:19:01.527360
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    import re
    import pyrsistent as p
    import pytest
    import hypothesis
    import hypothesis.strategies as st
    import decimal
    import money as m
    import money.quantize as q
    import money.currency as c
    import money.fx as fx
    import money.fx.test as fxt
    import money.register as r


# Generated at 2022-06-24 01:19:04.035502
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    assert SomePrice(usd, Decimal("1"), today) == SomePrice(usd, Decimal("1"), today)


# Generated at 2022-06-24 01:19:08.071569
# Unit test for method as_float of class Price
def test_Price_as_float():
  my_price = Price(Currency('AUD'), Decimal(2.1), Date(2019, 11, 25))
  assert my_price.as_float() == 2.1



# Generated at 2022-06-24 01:19:19.326138
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    gte = SomeMoney.__ge__
    assert gte(SomeMoney(EUR, Decimal("5.5"), Date(2006, 12, 12)),
        SomeMoney(EUR, Decimal("5.5"), Date(2006, 12, 12))) is True
    assert gte(SomeMoney(EUR, Decimal("5.5"), Date(2006, 12, 12)),
        SomeMoney(EUR, Decimal("5.5"), Date(2006, 12, 12))) is True
    assert gte(SomeMoney(EUR, Decimal("6.1"), Date(2006, 12, 12)),
        SomeMoney(EUR, Decimal("5.5"), Date(2006, 12, 12))) is True

# Generated at 2022-06-24 01:19:30.330973
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    a = NonePrice()

    assert a.scalar_subtract(3) is NoPrice
    assert a.scalar_subtract(3.7) is NoPrice
    assert a.scalar_subtract(Decimal("3.45")) is NoPrice
    assert a.scalar_subtract(Decimal("1.23456789")) is NoPrice
    assert a.scalar_subtract("3.45") is NoPrice
    assert a.scalar_subtract("3.4567") is NoPrice
    assert a.scalar_subtract("3.456789") is NoPrice



NoPrice: Price = NonePrice()
## No money:


# Generated at 2022-06-24 01:19:34.046413
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    rt = Price.of('CNY', Decimal('1.0'), Date.today())
    zero = Decimal('0')
    one = Decimal('1')
    assert rt.floor_divide(zero) == NoPrice
    assert rt.floor_divide(one) == rt

# Generated at 2022-06-24 01:19:34.976198
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    # TODO
    pass



# Generated at 2022-06-24 01:19:41.487760
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    print('Test for method __sub__ of class SomePrice')
    print('with arguments:')
    print('')
    print('arguments for SomePrice(Currency,Decimal,Date):')
    print('Currency:')
    print(AUD)
    print('Decimal:')
    print(Decimal(2))
    print('Date:')
    print(Date.of(2020, 2, 18))
    print('arguments for SomePrice(Currency,Decimal,Date):')
    print('Currency:')
    print(AUD)
    print('Decimal:')
    print(Decimal(1))
    print('Date:')
    print(Date.of(2020, 2, 18))
    print('')

# Generated at 2022-06-24 01:19:46.443331
# Unit test for method round of class Money
def test_Money_round():
    m1 = Money(USD, Decimal("12.345"), Decimal("12.346"), Date(2020, 10, 12))
    m2 = Money(USD, Decimal("12.345"), Decimal("12.346"), Date(2020, 10, 12))
    m1.round(2)
    m2.round(2)
    assert m1 == m2
    
    

# Generated at 2022-06-24 01:19:53.849184
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    # SomeMoney.is_equal
    assert SomeMoney(USD, Decimal(0), None) == SomeMoney(USD, Decimal(0), None)
    assert SomeMoney(USD, Decimal(1), None) == SomeMoney(USD, Decimal(1), None)
    assert SomeMoney(USD, Decimal(1), TODAY) == SomeMoney(USD, Decimal(1), TODAY)
    assert SomeMoney(EUR, Decimal(1), TODAY) == SomeMoney(EUR, Decimal(1), TODAY)
    assert not (SomeMoney(EUR, Decimal(1), TODAY) == SomeMoney(USD, Decimal(1), TODAY))
    assert not (SomeMoney(EUR, Decimal(1), TODAY) == SomeMoney(EUR, Decimal(1), TOMORROW))

    # NoMoney.is_equal
   

# Generated at 2022-06-24 01:19:55.349473
# Unit test for method __int__ of class Price
def test_Price___int__():
    a = Price.of(USD, Decimal(25), Date.today())
    assert int(a) == 25


# Generated at 2022-06-24 01:20:02.384946
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    from sparkquantum import constants as c
    import random

    a = Money.of(c.USD, 0.3275456535490907, Date(2019, 1, 1))

    for i in range(100):
        n = random.randint(0, 1000)
        r = a.round(n)
        assert r.ccy.iso_code == a.ccy.iso_code
        assert r.qty == a.qty.quantize(a.ccy.quantizer)
        assert r.dov == a.dov

# Generated at 2022-06-24 01:20:07.793262
# Unit test for method add of class Money
def test_Money_add():
    a = Money.of(ccy=Currency.USD, qty=Decimal(100.00), dov=Date.today())
    b = Money.of(ccy=Currency.USD, qty=Decimal(100.00), dov=Date.today())
    assert a.add(b) == Money.of(ccy=Currency.USD, qty=Decimal(200.00), dov=Date.today())


# Generated at 2022-06-24 01:20:12.735042
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    import io
    import io, sys
    import io, sys, textwrap
    import pytest
    from hamcrest import assert_that, calling, equal_to, is_
    from hamcrest.core.core.isequal import is_equal, equal_to
    import numpy as np
    import numpy as np, numpy.testing as npt, numpy.testing.noseclasses as np_tc

    with pytest.raises(IncompatibleCurrencyError) as exc:
        (SomeMoney(USD, 100, Date(2018, 1, 1)) <= SomeMoney(EUR, 100, Date(2018, 1, 1)))

# Generated at 2022-06-24 01:20:19.396517
# Unit test for method abs of class Money
def test_Money_abs():
    """
    Unit test for method abs of class Money
    """
    assert abs(Money.of(Currency.USD, Decimal('-1.000'), Date.today())) == SomeMoney(Currency.USD, Decimal('1.000'), Date.today())
    assert abs(Money.of(Currency.USD, Decimal('1.000'), Date.today())) == SomeMoney(Currency.USD, Decimal('1.000'), Date.today())
    assert abs(NoMoney) == NoMoney

# Generated at 2022-06-24 01:20:21.030939
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NoPrice.with_qty(Decimal(100)) == NoPrice

# Generated at 2022-06-24 01:20:25.706397
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert SomeMoney(CNY, 1.0, Date.today()).as_integer() == 1
    assert SomeMoney(CNY, 1.0, Date.today()).as_integer() == 1
    assert NoMoney.as_integer() == 0
    assert NoneMoney.as_integer() == 0



# Generated at 2022-06-24 01:20:26.420082
# Unit test for method __round__ of class Price
def test_Price___round__():
    pass



# Generated at 2022-06-24 01:20:31.681482
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    o = NonePrice()
    try:
        o.scalar_subtract(100)
        assert False
    except TypeError:
        assert True

NonePrice = NonePrice()

# Generated at 2022-06-24 01:20:42.025535
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    money = SomeMoney(ccy=JPY, qty=Decimal("100.00"), dov=Date(2019, 10, 3))
    assert not money.lt(NoMoney)
    with pytest.raises(IncompatibleCurrencyError):
        money.lt(SomeMoney(ccy=USD, qty=Decimal("100.00"), dov=Date(2019, 10, 3)))
    assert money.lt(SomeMoney(ccy=JPY, qty=Decimal("200.00"), dov=Date(2019, 10, 3)))
    assert not money.lt(SomeMoney(ccy=JPY, qty=Decimal("100.00"), dov=Date(2019, 10, 3)))

# Generated at 2022-06-24 01:20:48.283705
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """
    Tests method __gt__ of class SomeMoney
    """
    C = Currency("USD")
    m1 = SomeMoney(C, Decimal("100"), date.today())
    m2 = SomeMoney(C, Decimal("80"), date.today())
    (m1 < m2) == True  # type: ignore

    try:
        m1 < 1.0
    except TypeError:
        pass
    else:
        raise AssertionError("Expected exception TypeError")

# Generated at 2022-06-24 01:20:51.804182
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    price_obj = NonePrice
    price_obj2 = NonePrice
    # Call function
    assert price_obj.__floordiv__(price_obj2) is price_obj

# Generated at 2022-06-24 01:20:54.788181
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    obj = NoneMoney()
    assert obj.__mul__(3.14) == obj

# Generated at 2022-06-24 01:21:01.202607
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    assert SomeMoney("USD", Decimal("20"), Date.of(2019, 9, 6)).floor_divide(2) == SomeMoney("USD", Decimal("10"), Date.of(2019, 9, 6))
    assert SomeMoney("USD", Decimal("10"), Date.of(2019, 9, 6)).floor_divide(3) == SomeMoney("USD", Decimal("3"), Date.of(2019, 9, 6))
    assert NoMoney.floor_divide(2) == NoMoney

# Generated at 2022-06-24 01:21:02.828909
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert bool(NoneMoney) == False

# Generated at 2022-06-24 01:21:04.237156
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    pass # TODO



# Generated at 2022-06-24 01:21:10.104012
# Unit test for method convert of class Price
def test_Price_convert():
    logger.info("Testing Price.convert")
    assert USD(1, dov="2020-01-01").convert("EUR", dov="2020-01-01") == EUR(
        0.914094, dov="2020-01-01"
    )
    assert EUR(1, dov="2020-01-01").convert("USD", dov="2020-01-01") == USD(
        1.097, dov="2020-01-01"
    )
    assert (
        USD(1, dov="2020-01-01").convert("EUR", dov="2020-01-01", strict=True)
        == EUR(0.914094, dov="2020-01-01")
    )

# Generated at 2022-06-24 01:21:17.078067
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    print("Testing method: NoneMoney.__sub__")
    try:
        NoneMoney.__sub__(NoMoney, SomeMoney(JPY, Decimal(1), Date.today()))
    except Exception as exc:
        if 'IncompatibleCurrencyError' not in str(type(exc)):
            raise exc
    else:
        assert False, "Expecting an IncompatibleCurrencyError being raised."
    try:
        NoneMoney.__sub__(SomeMoney(JPY, Decimal(1), Date.today()), NoneMoney())
    except Exception as exc:
        if 'IncompatibleCurrencyError' not in str(type(exc)):
            raise exc
    else:
        assert False, "Expecting an IncompatibleCurrencyError being raised."
    assert SomeMoney(JPY, Decimal(0), Date.today()) == None

# Generated at 2022-06-24 01:21:19.158180
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    # Test without error:
    assert NonePrice == -NonePrice



# Generated at 2022-06-24 01:21:26.009838
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    # Case 1:
    assert -NoPrice == NoPrice

    # Case 2:
    try:
        -SomePrice(currency(), Decimal("1"), yesterday())
    except IncompatibleCurrencyError as exc:
        pass
    else:
        assert False, "IncompatibleCurrencyError was not raised."

# Generated at 2022-06-24 01:21:28.481311
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    np = NonePrice()
 
    assert np.__abs__() == NonePrice()
    assert not hasattr(np, "__abs__")

# Generated at 2022-06-24 01:21:29.895483
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    a = NonePrice
    assert NoMoney == a.times(3)


# Generated at 2022-06-24 01:21:41.920633
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    """
    Test adding two SomeMoney objects together and what happens to their dov when they are added.
    """
    # Create some Money with various dov's
    m1 = USD(1, dov=Date(1980, 1, 1))
    m2 = USD(1, dov=Date(1990, 1, 1))
    m3 = USD(1, dov=Date(2000, 1, 1))

    # Test adding m1 and m2 together
    m4 = m1 + m2
    assert m4.dov == Date(1990, 1, 1)
    assert m4.qty == Decimal(2)

    # Test adding m2 and m3 together
    m5 = m2 + m3
    assert m5.dov == Date(2000, 1, 1)

# Generated at 2022-06-24 01:21:43.798956
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(SomeMoney(USD, 10, dt.date(2019, 12, 31))) == True
    assert bool(NoneMoney) == False


# Generated at 2022-06-24 01:21:46.613478
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 1)).as_integer() == 1

# Generated at 2022-06-24 01:21:48.379549
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert NonePrice() < SomePrice(EUR, Decimal(1), TODAY)
    assert not (NonePrice() < NonePrice())
    assert not (SomePrice(EUR, Decimal(1), TODAY) < NonePrice())


# Generated at 2022-06-24 01:21:59.275023
# Unit test for method divide of class Price
def test_Price_divide():
    ccy = Currency.of("USD")
    price = Price.of(ccy, 100, Date.today())
    assert price.divide(1) == Price.of(ccy, 100, Date.today())
    assert Price.of(ccy, 100, Date.today()).divide(1) == Price.of(ccy, 100, Date.today())
    assert Price.of(ccy, 100, Date.today()) / 1 == Price.of(ccy, 100, Date.today())
    assert price.divide(2) == Price.of(ccy, 50, Date.today())
    assert Price.of(ccy, 100, Date.today()).divide(2) == Price.of(ccy, 50, Date.today())
    assert Price.of(ccy, 100, Date.today()) / 2 == Price

# Generated at 2022-06-24 01:22:07.573362
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    from pony import orm
    from datetime import date
    from numbers import Number

    # Test case associated to the NoneMoney class
    n = NoneMoney
    n2 = NoneMoney
    assert n.__eq__(n2)
    assert n == n2
    assert n == None
    assert not n == False

    #Test case associated to the SomeMoney class
    m = Money.of(Currency.USD, Decimal('1.0'), date(2020, 6, 1))
    assert m.defined
    assert not m.undefined
    m2 = Money.of(Currency.USD, Decimal('1.0'), date(2020, 6, 1))
    assert m.__eq__(m2)
    assert m == m2

    assert not (n == m)
    assert not (m == n)

# Generated at 2022-06-24 01:22:19.278573
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    """Test method __sub__ of class NonePrice."""
    assert NonePrice().__sub__(Price.of(Currency.EUR, Decimal('1'), Date.from_string('2019-12-21'))) == SomeMoney(Currency.EUR, Decimal('-1'), Date.from_string('2019-12-21'))
    assert NonePrice().__sub__(Price.of(Currency.EUR, Decimal('1'), Date.from_string('2019-12-21'))) == SomeMoney(Currency.EUR, Decimal('-1'), Date.from_string('2019-12-21'))

# Generated at 2022-06-24 01:22:26.357615
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Money(CCY.USD, 10).__floordiv__(2) == Money(CCY.USD, 5)
    assert Money.NA.__floordiv__(2) == Money.NA
    assert Money.NA.__floordiv__(Money.NA) == Money.NA



# Generated at 2022-06-24 01:22:32.837070
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    eps = 1e-12
    some_price = Price(
        ccy=USD,
        qty=Decimal("1.5"),
        dov=Date(2020, 7, 4),
    )

    #
    # Test with None value.
    #
    assert some_price.__pos__() == some_price
    #
    # Test with None value.
    #
    some_price.qty = None
    assert some_price == Price.NA



# Generated at 2022-06-24 01:22:36.981819
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    e1 = Money()
    e2 = Money()

    assert e1._eq(e1.__neg__())
    assert e2._eq(e2.__neg__())

# Generated at 2022-06-24 01:22:38.217998
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    pass


# Generated at 2022-06-24 01:22:39.288638
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoMoney

# Generated at 2022-06-24 01:22:44.946665
# Unit test for method lte of class Money
def test_Money_lte():
    m1 = Money.of(Currency.of("USD"), 100, Date.today())
    m2 = Money.of(Currency.of("USD"), -100, Date.today())
    assert m1 <= m1
    assert m1 <= m2
    assert m2 <= m1
    assert m2 <= m2



# Generated at 2022-06-24 01:22:47.673119
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    _test_SomePrice___floordiv__(SomePrice.__floordiv__)
    _test_SomePrice___floordiv__(operator.floordiv)


# Generated at 2022-06-24 01:22:52.722581
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    """
    Test `__gt__` method of class `NonePrice`
    """
    assert NonePrice() > Price.of(Currency.get("USD"), +10, Date.today())



# Generated at 2022-06-24 01:22:57.351282
# Unit test for method as_float of class Price
def test_Price_as_float():
    with pytest.raises(NotImplementedError):
        Price().as_float()


# Generated at 2022-06-24 01:22:58.195399
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoneMoney()

# Generated at 2022-06-24 01:23:01.408784
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    result = SomeMoney(ccy=USD, qty=Decimal("100.00"), dov=date(2019, 4, 2)).with_qty(Decimal("50.00"))
    assert result == SomeMoney(ccy=USD, qty=Decimal("50.00"), dov=date(2019, 4, 2))

# Generated at 2022-06-24 01:23:02.734586
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    pass



# Generated at 2022-06-24 01:23:06.459925
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert SomePrice(USD, Decimal('1.0'), date(2017, 12, 12)).as_boolean()
    assert not SomePrice(USD, Decimal('0.0'), date(2017, 12, 12)).as_boolean()
    assert not NoPrice.as_boolean()

# Generated at 2022-06-24 01:23:08.670517
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney.of(USD, 1.00, D.today()).round() == SomeMoney.of(USD, 1.00, D.today())

# Generated at 2022-06-24 01:23:14.129751
# Unit test for method lt of class Price
def test_Price_lt():
    m1 = Money.of(EUR, 1)
    m2 = Money.of(EUR, 2)
    assert m1.lt(m2)
    assert not m2.lt(m1.lt(m2))


# Generated at 2022-06-24 01:23:21.775979
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    assert SomeMoney('USD', Decimal('100'), Date.today()).__floordiv__(Decimal('2.00')) == SomeMoney('USD', Decimal('50.00'), Date.today())
    assert SomeMoney('USD', Decimal('100'), Date.today()).__floordiv__(2) == SomeMoney('USD', Decimal('50.00'), Date.today())
    assert SomeMoney('USD', Decimal('100'), Date.today()).__floordiv__(2.00) == SomeMoney('USD', Decimal('50.00'), Date.today())
    assert SomeMoney('USD', Decimal('100'), Date.today()).__floordiv__(None) == NoMoney

# Generated at 2022-06-24 01:23:29.996541
# Unit test for method __int__ of class Money
def test_Money___int__():
    """
    Unit test for method Money.__int__
    """

    import typing

    from . import exchange
    from . import locales

    def test_case_1():
        """
        """
        _ = Money(curr=None, qty=None, dov=None)
        assert isinstance(_, Money)
        assert isinstance(_, typing.Union[None, Money])
        assert isinstance(_, typing.Union[None, Money, typing.Any])
        assert not isinstance(_, typing.Any)
        assert not isinstance(_, typing.List)
        assert not isinstance(_, typing.Optional[Money])
        assert not isinstance(_, typing.Optional[typing.Any])
        assert not isinstance(_, typing.Optional[int])
    def test_case_2():
        """
        """
        _

# Generated at 2022-06-24 01:23:39.385825
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    # Test to make sure we raise a ValueError if an invalid parameter is passed in
    with pytest.raises(ValueError):
        someMoney = Money.of(Currency.of('USD'), 1234, Date(2020, Month.JANUARY, 1))
        someMoney = someMoney.with_qty(None)
    # Result is 0 as a default
    someMoney = Money.of(Currency.of('USD'), Decimal(0), Date(2020, Month.JANUARY, 1))
    assert someMoney.qty == someMoney.with_qty(None).qty
    assert someMoney.qty == Decimal(0)
    # Result is 1 for a positive input
    someMoney = Money.of(Currency.of('USD'), Decimal(1), Date(2020, Month.JANUARY, 1))

# Generated at 2022-06-24 01:23:50.163867
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    print(Price.of(None, None, None).with_qty(None))
    print(Price.of(None, None, None).with_qty(Decimal(0)))
    print(Price.of(None, None, None).with_qty(Decimal(1)))
    print(Price.of(Ccy.USD, None, None).with_qty(None))
    print(Price.of(Ccy.USD, None, None).with_qty(Decimal(0)))
    print(Price.of(Ccy.USD, None, None).with_qty(Decimal(1)))
    print(Price.of(Ccy.USD, Decimal(0), None).with_qty(None))

# Generated at 2022-06-24 01:23:56.277084
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(NoPrice) == 0
    assert int(SomePrice(CCY, Decimal(1.0), dov=Date.now())) == 1
    assert int(SomePrice(CCY, Decimal(1.1), dov=Date.now())) == 1

# Generated at 2022-06-24 01:23:59.667333
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    assert isinstance(SomePrice(USD, Decimal("0"), d).__float__(), float)

# Generated at 2022-06-24 01:24:09.655262
# Unit test for method lte of class Price
def test_Price_lte():
    price1 = Price.of(Currency.USD, Decimal("100"), Date(2018, 12, 1))
    price2 = Price.of(Currency.USD, Decimal("50"), Date(2018, 12, 1))
    price3 = Price.of(Currency.USD, Decimal("100"), Date(2019, 12, 1))

    assert (price1.lte(price2) == False)
    assert (price2.lte(price1) == True)
    assert (price1.lte(price1) == True)
    assert (price1.lte(price3) == True)

    try:
        price1.lte(None)
        assert False
    except:
        assert True


# Generated at 2022-06-24 01:24:13.045062
# Unit test for method __float__ of class Money
def test_Money___float__():
    # GIVEN a money object
    # WHEN calling __float__ method
    actual = Money.of(Currency.USD, 1, Date.today()).__float__()
    # THEN the result is expected
    expected = 1.0
    assert expected == actual


# Generated at 2022-06-24 01:24:21.182363
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
        ccys = (Currency("EUR", Decimal("0.01")), Currency("USD", Decimal("0.01")))
        prices = (
            SomePrice(ccys[0], Decimal("1.00"), Date(2019, 1, 1)),
            SomePrice(ccys[1], Decimal("1.00"), Date(2019, 1, 1)),
            SomePrice(ccys[0], Decimal("2.00"), Date(2019, 1, 1)),
            SomePrice(ccys[0], Decimal("2.50"), Date(2019, 1, 1)),
            SomePrice(ccys[0], Decimal("2.50"), Date(2019, 1, 2)),
            SomePrice(ccys[0], Decimal("2.50"), Date(2019, 1, 3))
        )

# Generated at 2022-06-24 01:24:32.790137
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    #
    # SomePrice
    #
    date_a: Date = Date(27, 6, 2061)
    date_b: Date = Date(23, 2, 2044)
    price_a: Price = SomePrice(GBP, Decimal(5), date_a)
    price_b: Price = SomePrice(GBP, Decimal(2), date_b)
    assert price_a // price_b == price_a.__floordiv__(price_b)
    #
    # None
    #
    assert price_a // None == price_a.__floordiv__(None)
    #
    # D
    #
    assert price_a // 1 == price_a.__floordiv__(1)



# Generated at 2022-06-24 01:24:38.207458
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    to_ = Currency("USD")
    asof = Date("2019-12-13")
    strict = bool()
    expected_return_value = Price()
    actual_return_value = NonePrice().convert(to=to_, asof=asof, strict=strict)
    assert actual_return_value is expected_return_value

# Generated at 2022-06-24 01:24:51.063764
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    from cashflows.core.monetary import Currency, SomeMoney
    from cashflows.core.time import Date

    p1 = SomePrice(Currency.USD, Decimal(5), Date.today())
    p2 = SomePrice(Currency.USD, Decimal(5), Date.today())
    p3 = SomePrice(Currency.USD, Decimal(4), Date.today())
    p4 = SomePrice(Currency.USD, Decimal(6), Date.today())

    assert p1.__ge__(p2) == True
    assert p1.__ge__(p3) == True
    assert p1.__ge__(p4) == False

    assert p1.__ge__(SomeMoney(Currency.USD, Decimal(5), Date.today())) == True

# Generated at 2022-06-24 01:24:52.866155
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert not NoPrice.__lt__(SomePrice(USD, 1.1, dov=Date(2018, 10, 1)))


# Generated at 2022-06-24 01:24:59.215428
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    c1 = USD
    q1 = Decimal("1")
    d1 = TradeDate(2020,1,1)
    t1 = SomePrice(c1, q1, d1)
    
    c2 = USD
    q2 = Decimal("1")
    d2 = TradeDate(2020,2,2)
    t2 = SomePrice(c2, q2, d2)
    
    t3 = t1 - t2
    
    assert t3.qty == Decimal("-1")
    assert t3.ccy == USD
    assert t3.dov == TradeDate(2020,2,2)
    
    c3 = USD
    q3 = Decimal("1")
    d3 = TradeDate(2019,2,2)

# Generated at 2022-06-24 01:25:04.944753
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    args = dict(ccy = SomeCurrency, qty = SomeDecimal, dov = SomeDate)
    result = SomePrice(**args).__abs__()
    assert isinstance(result, SomePrice)



# Generated at 2022-06-24 01:25:07.098414
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    I: Money = Money.of(USD, None, None)
    assert I * 1.0 == I



# Generated at 2022-06-24 01:25:09.365981
# Unit test for method __int__ of class Price
def test_Price___int__():
    #TODO: Add better unit test coverage.
    pass

# Generated at 2022-06-24 01:25:19.851532
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():

        ccy = Currency.parse("USD")
        qty = Decimal("123.45678")
        dov = Date.today()

        money = SomeMoney(ccy, qty, dov)

        money = money.round()

        assert money == SomeMoney(ccy, Decimal("123.46"), dov)

        money = money.round(2)

        assert money == SomeMoney(ccy, Decimal("123.46"), dov)

        money = money.round(3)

        assert money == SomeMoney(ccy, Decimal("123.460"), dov)

        money = money.round(4)

        assert money == SomeMoney(ccy, Decimal("123.4600"), dov)

        money = money.round(5)


# Generated at 2022-06-24 01:25:21.366687
# Unit test for method __le__ of class Price
def test_Price___le__():
    pass



# Generated at 2022-06-24 01:25:23.872318
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    set_global_decimal_precision(2)
    assert NonePrice.with_qty(Decimal('3.14')) == NonePrice


# Generated at 2022-06-24 01:25:27.936098
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    # Method resolution order:
    # SomePrice
    # Price
    # object
    some_price = SomePrice(Currency.INR, Decimal(1), Date.today())

    expected = SomePrice(Currency.INR, Decimal(10), Date.today())

    value = 10

    actual = some_price * value

    assert expected == actual

# Generated at 2022-06-24 01:25:28.641518
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    pass

# Generated at 2022-06-24 01:25:33.592509
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    """ Testing the method convert of class NoneMoney
    """
    m1 = NoMoney
    m2 = SomeMoney(USDCurrency, 10, date(2020, 12, 31))
    assert m1.convert(USDCurrency, date(2020, 12, 31), False) == NoMoney
    assert m2.convert(USDCurrency, date(2020, 12, 31), False) == m2


# Generated at 2022-06-24 01:25:43.054900
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    class TMoney(Money):
        ccy: Currency
        qty: Decimal
        dov: Date

        def __init__(self, ccy: Currency, qty: Decimal, dov: Date) -> None:
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

        def is_equal(self, other: Any) -> bool:
            return isinstance(other, TMoney) and all([
                self.ccy == other.ccy,
                self.qty == other.qty,
                self.dov == other.dov,
            ])

        def as_boolean(self) -> bool:
            return self.qty == 0

        def as_float(self) -> float:
            raise MonetaryOperationException("Incompatible operation")


# Generated at 2022-06-24 01:25:44.021757
# Unit test for method __float__ of class Money
def test_Money___float__():
    pass



# Generated at 2022-06-24 01:25:46.312961
# Unit test for method lte of class Price
def test_Price_lte():
    assert (SomePrice(USD, 100, date(2020, 1, 1)) <= SomePrice(USD, 100, date(2020, 1, 1))) is True



# Generated at 2022-06-24 01:25:49.998195
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    n = NonePrice()
    # n.round()
    n.round(ndigits=0)
    n.round(ndigits=None)
    n.round(0)
    n.round(None)

# Generated at 2022-06-24 01:25:59.515079
# Unit test for method abs of class Price
def test_Price_abs():
    # NoPrice.abs() => NoPrice
    assert NoPrice.abs() == NoPrice
    # SomePrice(SomeCurrency('USD'), Decimal(100), Today).abs() => SomePrice(SomeCurrency('USD'), Decimal(100), Today)
    assert SomePrice(SomeCurrency('USD'), Decimal(100), Today).abs() == SomePrice(SomeCurrency('USD'), Decimal(100), Today)
    # SomePrice(SomeCurrency('USD'), Decimal(-100), Today).abs() => SomePrice(SomeCurrency('USD'), Decimal(100), Today)
    assert SomePrice(SomeCurrency('USD'), Decimal(-100), Today).abs() == SomePrice(SomeCurrency('USD'), Decimal(100), Today)
    pass


# Generated at 2022-06-24 01:26:03.043302
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    defaultPrice = SomePrice(CAD, Decimal('1.24'), Date(1, 1, 1))
    print(defaultPrice)
    assert defaultPrice.__ge__(defaultPrice) == True

# Generated at 2022-06-24 01:26:09.362582
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    print("Testing method __add__ at {0}".format(datetime.now()))
    a = SomePrice(USD, 100, Date(2018, 1, 1))
    b = SomePrice(USD, 200, Date(2018, 1, 1))
    result = a.add(b)
    print(result)
    print("Success in testing method __add__ at {0}".format(datetime.now()))
    print("==================================================")


# Generated at 2022-06-24 01:26:21.463140
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    # Setup
    ccy1 = Currency("USD")
    qty1 = Decimal("100.1234567").quantize(ccy1.scale)
    dov1 = Date(2042, 1, 1)
    na1 = SomeMoney(ccy1, qty1, dov1)
    # Exercise
    na2 = -na1
    # Verify
    assert isinstance(na2, SomeMoney), "Returned money object must be SomeMoney."
    assert na2.ccy == ccy1, "Currency must match."
    assert na2.qty == -qty1, "Quantity must match."
    assert na2.dov == dov1, "Date of value must match."
# Test
test_Money___neg__()


# Generated at 2022-06-24 01:26:33.688608
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    """
    Unit test for method ``__neg__`` of class :class:`SomeMoney`.
    """
    # Assert that we raise exception when we try to negate undefined money:
    with pytest.raises(InvalidOperation):
        NoMoney.__neg__()

    # Assert that we can negate some money:
    assert (-SomeMoney(Currency("EUR"), Decimal("100"), Date.today())).qty == Decimal("-100")

    # Assert that this should not be possible:
    with pytest.raises(TypeError):
        (-SomeMoney(Currency("EUR"), Decimal("100"), Date.today())).ccy

    # Assert that we can negate some money with a different currency:

# Generated at 2022-06-24 01:26:35.225241
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    """
    Ensure that the method __eq__ of class NoneMoney returns True when called with an NoneMoney object.
    """
    return NoMoney.__eq__(NoMoney)



# Generated at 2022-06-24 01:26:44.215988
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    # Only defined price objects can be added.
    assert NoPrice.scalar_add(0) == NoPrice
    # Price addition is always with respect to the ccy of the price.
    assert Price.of(USD, 10, Date.of(2017, 12, 11)) + 5 == Price.of(USD, 15, Date.of(2017, 12, 11))
    assert Price.of(USD, 10, Date.of(2017, 12, 11)) + Price.of(EUR, 5, Date.of(2017, 12, 11)) == Price.of(EUR, 5, Date.of(2017, 12, 11))

# Generated at 2022-06-24 01:26:53.498247
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    """
    Unit tests for method is_equal of class Money.
    """
    ## Case: Money objects are equal if all slots are the same.
    eq_(True, (SomeMoney(USD, 2.0, Date.today())).is_equal(SomeMoney(USD, 2.0, Date.today())))
    eq_(False, (SomeMoney(USD, 2.1, Date.today())).is_equal(SomeMoney(USD, 2.0, Date.today())))
    eq_(False, (SomeMoney(USD, 2.0, Date.today())).is_equal(SomeMoney(USD, 2.0, Date.today() + 1)))
    eq_(False, (SomeMoney(USD, 2.0, Date.today())).is_equal(SomeMoney(GBP, 2.0, Date.today())))

    ## Case: Money

# Generated at 2022-06-24 01:26:59.638940
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    """
    Unit test for method with_qty of class Money

    """

    ccy = Currency('USD')
    date = date.today()
    amount = Decimal(50.00)

    money = Money.of(ccy, amount, date)
    new_amount = Decimal(100.00)
    new_money = money.with_qty(new_amount)

    expected_money = Money.of(ccy, new_amount, date)

    assert new_money == expected_money


# Generated at 2022-06-24 01:27:12.791624
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():

    t0: Price = Price.of(Currency.usd, Decimal("100.00"), Date.today())
    t1: Price = Price.of(Currency.eur, Decimal("100.00"), Date.today())

    t2: Price = Price.of(Currency.usd, Decimal("0.00"), Date.today())
    t3: Price = Price.of(Currency.eur, Decimal("0.00"), Date.today())

    assert t0.scalar_subtract(7) == Price.of(Currency.usd, Decimal("93.00"), Date.today())
    assert t1.scalar_subtract(7) == Price.of(Currency.eur, Decimal("93.00"), Date.today())


# Generated at 2022-06-24 01:27:17.244195
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    try:
        raise IncompatibleCurrencyError(None, None)
    except IncompatibleCurrencyError as x:
        assert str(x) == "<Unspecified>('', '', '<Unspecified>')"

        assert x.ccy1 == None
        assert x.ccy2 == None
        assert x.operation == "<Unspecified>"



# Generated at 2022-06-24 01:27:18.079192
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    assert NoneMoney() / Decimal(123) == NoneMoney()


# Generated at 2022-06-24 01:27:19.177847
# Unit test for method lte of class Price
def test_Price_lte():
    pass

# Generated at 2022-06-24 01:27:25.187009
# Unit test for method positive of class Price
def test_Price_positive():
    assert NoPrice.positive() is NoPrice

    assert SomePrice(USD, Decimal("100"), Date(2018, 12, 28)).positive() == (USD, Decimal("100"), Date(2018, 12, 28))

    assert SomePrice(USD, Decimal("-100"), Date(2018, 12, 28)).positive() == (USD, Decimal("100"), Date(2018, 12, 28))



# Generated at 2022-06-24 01:27:36.958100
# Unit test for method subtract of class Money
def test_Money_subtract():
    import pytest
    from decimal import Decimal
    from datetime import date
    from hw04 import Money
    from hw04 import SomeMoney
    from hw04 import NoMoney
    from hw04 import Currency
    from hw04 import IncompatibleCurrencyError
    value = Money.of(Currency.of("USD"), Decimal("100.0"), date(2018,11,20))
    value_expect = Money.of(Currency.of("USD"), Decimal("50.0"), date(2018,11,20))
    value_fail = Money.of(Currency.of("USD"), Decimal("50.0"), date(2018,11,20))
    value_two = Money.of(Currency.of("USD"), Decimal("100.0"), date(2018,11,20))
    value_undefined = No

# Generated at 2022-06-24 01:27:49.619725
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert (Price.NA == Price.NA)
    assert (Price.NA == Price.NA.__eq__(Price.NA))
    assert (not (Price.of("USD", 100, today) == Price.NA))
    assert (Price.of("USD", 100, today) == Price.of("USD", 100, today))
    assert (Price.of("USD", 100, today) == Price.of("USD", 100, today).__eq__(Price.of("USD", 100, today)))
    assert (not (Price.of("USD", 100, today) == Price.of("JPY", 100, today)))
    assert (not (Price.of("USD", 100, today) == Price.of("USD", 200, today)))
    assert (not (Price.of("USD", 100, today) == Price.of("USD", 100, tomorrow)))


# Generated at 2022-06-24 01:27:57.524762
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    USD = Currency("USD")
    ZAR = Currency("ZAR")
    price_1 = SomePrice(USD, Decimal("10.12345"), Date(2018, 1, 18))
    price_2 = SomePrice(USD, Decimal("10.12345"), Date(2018, 1, 18))
    price_3 = SomePrice(USD, Decimal("10.12345"), Date(2018, 1, 18))
    price_4 = SomePrice(USD, Decimal("10.12345"), Date(2018, 1, 18))
    price_5 = SomePrice(USD, Decimal("10.12345"), Date(2018, 1, 18))


    # Subtract Numeric with object type SomePrice.
    # Returns 'SomePrice' type object

# Generated at 2022-06-24 01:28:04.021412
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    price = MoneyService.price(1, 'USD', 0, datetime.date.today())
    assert price.__abs__() == MoneyService.price(1, 'USD', 0, datetime.date.today())

    price = MoneyService.price(-1, 'USD', 0, datetime.date.today())
    assert price.__abs__() == MoneyService.price(1, 'USD', 0, datetime.date.today())


# Generated at 2022-06-24 01:28:08.060387
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    with raises(TypeError):
        bool(NoMoney)

# Generated at 2022-06-24 01:28:14.537321
# Unit test for method lte of class Money
def test_Money_lte():
    money = Money(Currency.USD, Decimal(10), Date(2020, 10, 10))
    money1 = Money(Currency.USD, Decimal(9), Date(2020, 10, 10))
    money2 = Money(Currency.USD, Decimal(10), Date(2020, 10, 10))
    money3 = Money(Currency.USD, Decimal(11), Date(2020, 10, 10))
    money4 = Money(Currency.EUR, Decimal(10), Date(2020, 10, 10))
    assert money <= money
    assert money1 <= money
    assert money1 <= money1
    assert money2 <= money
    assert money2 <= money2
    assert money3 >= money
    assert money3 >= money3
    with pytest.raises(TypeError):
        assert money4 <= money

# Generated at 2022-06-24 01:28:21.878355
# Unit test for method gt of class Price
def test_Price_gt():
    # Define some monetary values.
    p1 = Money.of(EUR, 1, asof=Date.of(2016, 3, 1))
    p2 = Money.of(EUR, 2, asof=Date.of(2016, 3, 1))

    # Accessor tests.
    # Check that p2 is greater than p1.
    assert 2 > p1
    assert not 2 > p2
    assert not 0 > p1
    assert not p1 > p1

    # Check the relation with undefined, defined and the same.
    assert not NoMoney > p1
    assert not p1 > NoMoney
    assert not NoMoney > NoMoney
    # Check that a type error is raised when comparing with a non price instance.
    with pytest.raises(TypeError):
        _ = p1 > None



# Generated at 2022-06-24 01:28:29.647657
# Unit test for method multiply of class Price
def test_Price_multiply():
    
    # testing in isolation
    # creating a Currency object ccy
    ccy = Currency.of(ISO.CAD)
    # creating a Date object dov
    dov = Date.from_string('2018-01-26')
    
    # testing method multiply of class Price 
    assert Price.of(ccy, decimal.Decimal('5'), dov).multiply(2) == Price.of(ccy, decimal.Decimal('10'), dov)
    assert Price.of(ccy, decimal.Decimal('5'), dov).multiply(decimal.Decimal('3')) == Price.of(ccy, decimal.Decimal('15'), dov)
    assert Price.of(ccy, decimal.Decimal('5'), dov).multiply(decimal.Decimal('-4')) == Price