

# Generated at 2022-06-24 01:18:30.286473
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    with raises(NotImplementedError):
        NoMoney.__mul__(1)

# Generated at 2022-06-24 01:18:33.409529
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    t = NonePrice
    u = SomePrice(Currency.USD, Decimal("1"), Date.today())
    assert t.__gt__(u) == False, "__gt__ was incorrect, it should have returned False."

# Generated at 2022-06-24 01:18:35.139860
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert NoPrice.__abs__() is NoPrice
    assert SomePrice(Currency("USD"), Decimal("100.00"), Date.today()).__abs__() == SomePrice(
        Currency("USD"), Decimal("100.00"), Date.today()
    )



# Generated at 2022-06-24 01:18:40.482754
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    test_Price_scalar_add_1()
    test_Price_scalar_add_2()
    test_Price_scalar_add_3()
    test_Price_scalar_add_4()

# Generated at 2022-06-24 01:18:48.341545
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    """
    Unit test for method __lt__ of class SomeMoney
    """
    m1 = money.of(USD, Decimal("12.35"), dt.date(2020, 5, 6))
    m2 = money.of(USD, Decimal("12.349"), dt.date(2020, 5, 6))
    assert m1.__lt__(m2)
    assert not m2.__lt__(m1)
    assert m2.__lt__(m1) == m1.gt(m2)

# Generated at 2022-06-24 01:19:00.166245
# Unit test for method __add__ of class Price
def test_Price___add__():
    # Test signature and docstring of method __add__
    m1 = SomeMoney('USD', Decimal('0.5'), Date(2018, 1, 5))
    m2 = SomeMoney('USD', Decimal('0.5'), Date(2018, 1, 5))
    p = m1 + m2

    assert is_equal(p, SomePrice('USD', Decimal('1.00'), Date(2018, 1, 5)))

    m1 = SomeMoney('USD', Decimal('0.5'), Date(2018, 1, 5))
    m2 = NoMoney

    with pytest.raises(TypeError):
        p = m1 + m2

    p = m2 + m1

    assert is_equal(p, SomePrice('USD', Decimal('0.50'), Date(2018, 1, 5)))

    m1 = NoMoney


# Generated at 2022-06-24 01:19:03.280872
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    rp = NonePrice()
    sp = SomePrice(CAD, Decimal('1'), Date(2020,1,1))
    assert rp <= sp

# Generated at 2022-06-24 01:19:04.398320
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    pass


# Generated at 2022-06-24 01:19:06.060728
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    NonePrice().with_ccy(ccy=None)



# Generated at 2022-06-24 01:19:18.030194
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    from .commons.zeitgeist import Date
    from .currencies import Currency
    assert NoMoney.__lt__(NoMoney) is False
    assert NoMoney.__lt__(SomeMoney(Currency("TRY"), Decimal("15.000"), Date.asof("20180222"))) is True
    assert NoMoney.__lt__(SomeMoney(Currency("USD"), Decimal("15.000"), Date.asof("20180222"))) is True
    assert SomeMoney(Currency("TRY"), Decimal("15.000"), Date.asof("20180222")).__lt__(NoMoney) is False
    assert SomeMoney(Currency("USD"), Decimal("15.000"), Date.asof("20180222")).__lt__(NoMoney) is False

# Generated at 2022-06-24 01:19:23.329022
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    """
    Tests that Money.__gt__ raises an error if operand types are not matched.
    """
    from datetime import date
    from decimal import Decimal
    from numpy import nan
    from pytest import raises
    from .dates import Date
    from .currencies import Currency
    from .money import Money, SomeMoney
    from .errors import IncompatibleCurrencyError
    from .commons.zeitgeist import DateLocator, WorkingDayConvention
    from .exchange.fx_rate_service import FXRateService

    # Initialize fx rate service:
    fxrs = FXRateService(lambda *args, **kwargs: Decimal("0.88"), DateLocator(WorkingDayConvention.ModifiedFollowing))

    # Asserts that the type check is done correctly:

# Generated at 2022-06-24 01:19:25.553698
# Unit test for method negative of class Price
def test_Price_negative():
    assert isinstance(NoPrice.negative(), Price)
    assert NoPrice.negative() == NoPrice
    assert isinstance(SomePrice(EUR, Decimal(100)).negative(), Price)
    assert SomePrice(EUR, Decimal(100)).negative() == SomePrice(EUR, Decimal(-100))

# Generated at 2022-06-24 01:19:36.936729
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    m1 = SomeMoney("USD", Decimal("10.01"), Date("2019-03-01"))
    m2 = Decimal("1.25")
    m3 = Decimal("-1.25")
    m4 = Decimal("1.234567")
    m5 = Decimal("-1.234567")
    m6 = Decimal("1.2345")
    m7 = Decimal("-1.2345")
    m8 = Decimal("0")
    m9 = Decimal("1")
    assert type(m1 * m2) == SomeMoney
    assert type(m1 * m3) == SomeMoney
    assert type(m1 * m4) == SomeMoney
    assert type(m1 * m5) == SomeMoney
    assert type(m1 * m6) == SomeMoney
    assert type

# Generated at 2022-06-24 01:19:43.172527
# Unit test for method subtract of class Price
def test_Price_subtract():
    x = Price.of(Currency.USD, Decimal("10"), Date(2017,1,1))
    y = Price.of(Currency.USD, Decimal("19"), Date(2018,1,1))
    assert (x - y).qty == -Decimal("9")
test_Price_subtract()

# Generated at 2022-06-24 01:19:54.622821
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    from asq.initiators import query
    from datacleaner import money # type: ignore
    from moneyed import GBP # type: ignore
    from datetime import date # type: ignore

    ccy: Currency = GBP
    qty: Decimal = Decimal(100).quantize(ccy.quantizer)
    dov: Date = date(2018, 1, 1)
    p1: Price = money(qty, ccy, dov)
    assert p1 * 2 == money(qty * 2, ccy, dov)

    assert query(p1).multiply(2).first() == money(qty * 2, ccy, dov)

    assert query(p1).scalar_multiply(2).first() == money(qty * 2, ccy, dov)
# Unit test

# Generated at 2022-06-24 01:20:00.169762
# Unit test for constructor of class Money
def test_Money():
    from datetime import date
    from .currencies import USD, EUR, GBP

    # NoMoney
    assert not bool(NoMoney)
    assert NoMoney is NotImplemented

    # NoneMoney
    assert not bool(NoneMoney)
    assert isinstance(NoneMoney, Money)

    # SomeMoney
    a = Money.of(USD, 10, date.today())
    assert bool(a)


# Generated at 2022-06-24 01:20:01.588127
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    assert Price.of(USD, 10, TODAY) > Price.ZERO


# Generated at 2022-06-24 01:20:09.967073
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert (SomeMoney(Currency("USD", 2, "$"), Decimal(123), Date.now()) >= SomeMoney(Currency("USD", 2, "$"), Decimal(122), Date.now()))
    assert not (SomeMoney(Currency("USD", 2, "$"), Decimal(123), Date.now()) >= SomeMoney(Currency("USD", 2, "$"), Decimal(123), Date.now()))
    assert not (SomeMoney(Currency("USD", 2, "$"), Decimal(123), Date.now()) >= SomeMoney(Currency("USD", 2, "$"), Decimal(124), Date.now()))
    assert (SomeMoney(Currency("USD", 2, "$"), Decimal(123), Date.now()) >= NoMoney)

# Generated at 2022-06-24 01:20:18.892905
# Unit test for method __ge__ of class SomeMoney

# Generated at 2022-06-24 01:20:28.773988
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    # 1. Arrange
    ccy1 = Currency.eur; ccy2 = Currency.eur
    qty1 = Decimal('4.9'); qty2 = Decimal('4.9')
    dov1 = Date(2014, 4, 19); dov2 = Date(2014, 4, 19)
    price1 = SomePrice(ccy1, qty1, dov1)
    price2 = NonePrice()
    expected = False; result1 = False; result2 = False

    # 2. Act
    result1 = price1 > price2
    result2 = price2 > price1

    # 3. Assert
    assert result1 == expected, 'Wrong result'
    assert result2 == expected, 'Wrong result'

# Generated at 2022-06-24 01:20:34.781364
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    ## TODO: fix this unit test, it should test NoneMoney methods...
    # SomeMoney(ccy=ccy, qty=10, dov=date(2001, 12, 15))
    # SomeMoney(ccy=ccy, qty=10, dov=date(2001, 12, 15)).__float__()
    assert True



# Generated at 2022-06-24 01:20:41.285846
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    ccy = Currency("GBP")
    qty = Decimal("3.45")
    other_qty = Decimal("3.46")
    dov = Date("2000-01-01")

    p1 = SomePrice(ccy, qty, dov)
    p2 = SomePrice(ccy, qty, dov)
    p3 = SomePrice(ccy, other_qty, dov)

    assert p1 == p2
    assert p1 != p3
    assert p1 != NoPrice
    assert p3 == p3

# Generated at 2022-06-24 01:20:42.480252
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    assert not NoMoney.scalar_subtract(1)


# Generated at 2022-06-24 01:20:43.781835
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    assert(NoPrice // 1.0 == NoPrice)

# Generated at 2022-06-24 01:20:45.090907
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    print("Testing method __int__ of class NoneMoney")
    assert int(NoneMoney) == 0


# Generated at 2022-06-24 01:20:56.594715
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    price = Price.of('USD', 5, d1)
    # Price.__mul__
    assert price * Decimal('10') == Price.of('USD', Decimal('50'), d1)
    assert price * Price.of('USD', Decimal('10'), d1) == Price.of('USD', Decimal('50'), d1)
    assert (price * Price.of('USD', Decimal('10'), d1)) == Price.of('USD', Decimal('50'), d1)
    assert (Price.of('USD', Decimal('10'), d1) * price) == Price.of('USD', Decimal('50'), d1)
    with pytest.raises(IncompatibleCurrencyError):
        price * Price.of('EUR', Decimal('10'), d1)

# Generated at 2022-06-24 01:20:59.225902
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    assert SomePrice(USD, '1.2345678', February(28), 2020).round() == SomePrice(USD, '1', February(28), 2020)

# Generated at 2022-06-24 01:21:08.360740
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    """
    Tests for method __le__ of class SomeMoney
    """
    m1 = SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1))
    m2 = SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1))
    m3 = SomeMoney(USD, Decimal("1.01"), Date(2020, 1, 1))
    m4 = SomeMoney(EUR, Decimal("1.00"), Date(2020, 1, 1))
    m5 = NoMoney
    assert m1.__le__(m2)
    assert m1.__le__(m3)
    assert m2.__le__(m3)
    with pytest.raises(IncompatibleCurrencyError):
        m1.__le__(m4)
    assert m1.__le

# Generated at 2022-06-24 01:21:18.377056
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    try:
        Money.of(Currency.USD, 1, Date(2020)).__ge__(Money.of(Currency.EUR, 1, Date(2020)))
        raise RuntimeError("This should not happen!")
    except IncompatibleCurrencyError:
        pass
    try:
        Money.of(Currency.USD, 1, Date(2020)).__ge__(Money.of(Currency.USD, 2, Date(2020)))
        raise RuntimeError("This should not happen!")
    except MonetaryOperationException:
        pass
    try:
        Money.of(Currency.USD, None, Date(2020)).__ge__(Money.of(Currency.USD, 1, Date(2020)))
        raise RuntimeError("This should not happen!")
    except MonetaryOperationException:
        pass

# Generated at 2022-06-24 01:21:29.354282
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    # Function to test scalar addition of money objects
    def scalar_add(first_object, second_object):
        return first_object.scalar_add(second_object)
    
    # Testing with NoMoney object
    assert scalar_add(NoMoney, 0.0) is NoMoney
    
    # Testing with NoneMoney object
    assert scalar_add(NoneMoney, 0.5) is NoneMoney
    
    # Testing with SomeMoney object
    assert scalar_add(SomeMoney(Currency.from_string("AED"), 5, None), -6) == SomeMoney(Currency.from_string("AED"), -1, None)
from typing import NamedTuple


# Generated at 2022-06-24 01:21:30.110093
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    t = NoneMoney
    assert t.__neg__() is t


# Generated at 2022-06-24 01:21:32.166914
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert SomeMoney(USD, 1.23).as_float() == 1.23


# Generated at 2022-06-24 01:21:34.150809
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(GBP, 10, Date.of(2019, 9, 24)).multiply(2) == Price.of(GBP, 20, Date.of(2019, 9, 24))

# Generated at 2022-06-24 01:21:36.354129
# Unit test for method __le__ of class Price
def test_Price___le__():
    price = Price.of(USD, 1, Date.today())
    assert price <= price
    assert not price >= price
    assert Price.of(USD, 0, Date.today()) <= Price.of(USD, 1, Date.today())


# Generated at 2022-06-24 01:21:46.461319
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    import datetime as dt
    from pytz import UTC
    from .primitives import Currency, Date

    # SomePrice.__class__ is Price, Price.__eq__ is Price.is_equal, so I'm testing SomePrice.is_equal under
    # the covers here.

    # SomePrice(Currency('AUD'), Decimal('1.23'), Date(2018, 1, 1))
    s_x = SomePrice(Currency('AUD'), Decimal('1.23'), Date(2018, 1, 1))

    # Date(2018, 1, 1)
    y = Date(2018, 1, 1)

    # SomePrice(Currency('AUD'), Decimal('1.23'), y)
    s_y = SomePrice(Currency('AUD'), Decimal('1.23'), y)

    # (s_x is s_y)

# Generated at 2022-06-24 01:21:50.033863
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    assert Money.NA.__abs__() is NoMoney
    assert Money(USD, -2.8).__abs__() == Money(USD, 2.8)


# Generated at 2022-06-24 01:21:52.262621
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():

    m1 = Money.of(EUR, 1, d(20200101))
    m2 = Money.of(None, 1, d(20200101))

    assert bool(m1) is True
    assert bool(m2) is False


# Generated at 2022-06-24 01:22:00.694771
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    """
    Tests monetary equality of two money objects.
    """
    # WHEN:
    undefined = Money.NA
    defined = Money.of(Currency("USD"), 10.0, Date.today())

    # THEN:
    assert undefined.is_equal(undefined) == True
    assert defined.is_equal(defined) == True
    assert undefined != defined
    assert defined != undefined

# Generated at 2022-06-24 01:22:08.461171
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    """Test case for method __gt__ of class Price"""
    # Test for method __gt__
    assert Price.of(USD, 1, date.today()) > Price.of(USD, 0, date.today())

    with pytest.raises(IncompatibleCurrencyError):
        Price.of(USD, 1, date.today()) > Price.of(EUR, 0, date.today())

    assert Price.of(EUR, 1, date.today()) > NoPrice

    assert Price.of(USD, 1, date.today()) > Price.of(USD, 1, date.today())

    assert Price.of(USD, 1, date.today()) != Price.of(USD, 1, date.today())

    assert Price.of(USD, 1, date.today()) != Price.of(USD, 2, date.today())

#

# Generated at 2022-06-24 01:22:13.549320
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert SomeMoney(Currency.USD, Decimal(1), EpochDate).as_float() == 1.0
    assert SomeMoney(Currency.USD, Decimal(1), EpochDate).as_float() == 1.0

# Generated at 2022-06-24 01:22:20.059722
# Unit test for constructor of class SomePrice
def test_SomePrice():
    ccy = Currency.get_or_raise(code="USD")
    qty = Decimal(10)
    dov = Date.today()
    p = SomePrice(ccy, qty, dov)
    assert isinstance(p, Price)
    assert p.defined
    assert not p.undefined
    assert isinstance(p, SomePrice)
    assert (10, "USD", dov) == (float(p), str(p.ccy), p.dov)
    assert (ccy, qty, dov) == (p.ccy, p.qty, p.dov)


# Generated at 2022-06-24 01:22:32.349137
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    from camayoc.money import Money
    from camayoc.money import SomeMoney
    from camayoc.money import NoneMoney
    from camayoc.money import NoMoney
    from camayoc.money import NoMoneyValueError
    from camayoc.money import IncompatibleCurrencyError
    from camayoc.money import Currency

    USD = Currency(3, 0.001, radix=10, code="USD", symbol="$")

    assert (NoneMoney + NoneMoney) == NoMoney

    try:
        NoneMoney + SomeMoney(USD, Decimal(10), Date.today())
    except NoMoneyValueError:
        pass
    else:
        assert False

    try:
        NoneMoney + Money.of(USD, 10, Date.today())
    except NoMoneyValueError:
        pass
    else:
        assert False

# Generated at 2022-06-24 01:22:42.481872
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    from Priceless import Price
    from Priceless import SomePrice
    from Priceless import NoPrice
    from Priceless.Model import Currency
    from Priceless.Model import Date
    from decimal import Decimal

    ## Case 1 - undefined + undefined
    p1: Price = NoPrice
    p2: Price = NoPrice
    result = p1 + p2
    assert result is p1, "Case 1 failed!"
    assert type(result) is NoPrice, "Case 1 failed!"

    ## Case 2 - defined + undefined
    p1 = SomePrice(Currency("EUR"), Decimal("100.05"), Date("2019-01-01"))
    p2 = NoPrice
    result = p1 + p2
    assert result is p1, "Case 2 failed!"
    assert type(result) is SomePrice, "Case 2 failed!"

    ## Case

# Generated at 2022-06-24 01:22:44.990429
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    assert SomePrice(US_DOLLAR, Decimal("10.123"), date(2020, 1, 1)) * Decimal("1.3") == SomePrice(US_DOLLAR, Decimal("13.1609"), date(2020, 1, 1))


# Generated at 2022-06-24 01:22:51.683369
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    a0 = NoneMoney()
    a1 = (a0 * None)
    assert a1 == NoMoney
    a2 = (a0 * 10)
    assert a2 == NoMoney
    a3 = (a0 * Decimal(12))
    assert a3 == NoMoney


# Generated at 2022-06-24 01:22:59.261328
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert NoMoney.as_integer() == NoneMoney.as_integer()
    assert SomeMoney(Currency.EUR, Decimal(42), Date(2000, 1, 1)).as_integer() == 42
    try:
        assert NoneMoney.as_integer()
        raise AssertionError("Undefined money object should not yield an integer")
    except:
        pass
    try:
        assert NoMoney.as_integer()
        raise AssertionError("Undefined money object should not yield an integer")
    except:
        pass

# Generated at 2022-06-24 01:23:04.218622
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    assert SomePrice(Currency("USD"), 1, None) + 1 == SomePrice(Currency("USD"), 2, None)

# Generated at 2022-06-24 01:23:06.168849
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    none_money1 = NoneMoney()
    ccy = None
    none_money2 = none_money1.with_ccy(ccy)
    assert NoneMoney() == NoneMoney()
    assert NoneMoney() == none_money2


# Generated at 2022-06-24 01:23:12.155163
# Unit test for method negative of class Money
def test_Money_negative():
    try:
        Money.NA.negative()
    except ProgrammingError:
        assert True
    else:
        assert False
    assert Money(100, USD, dov=Date(2020, 8, 1)).negative() == Money(-100, USD, dov=Date(2020, 8, 1))
    assert SomeMoney(100, USD, dov=Date(2020, 8, 1)).negative() == Money(-100, USD, dov=Date(2020, 8, 1))


# Generated at 2022-06-24 01:23:14.793203
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    """
    Test method `__bool__` of class `NonePrice`.
    
    Tested: 2019-12-09 12:20
    """
    assert NonePrice().__bool__() is False



# Generated at 2022-06-24 01:23:16.805024
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    from datetime import date as _date
    from covid.types import Date as _Date
    from covid.types import Price as _Price
    from covid.types import NonePrice as _NonePrice
    _NonePrice.with_dov(_Date(_date(2020, 1, 24)))

# Generated at 2022-06-24 01:23:29.262709
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    assert SomeMoney(USD, 10, None) + SomeMoney(USD, 10, None) == SomeMoney(USD, 20, None)
    assert SomeMoney(USD, 10, None) + SomeMoney(USD, 20, None) == SomeMoney(USD, 30, None)
    assert SomeMoney(USD, 20, None) + SomeMoney(USD, 10, None) == SomeMoney(USD, 30, None)
    assert SomeMoney(USD, 20, None) + SomeMoney(USD, -10, None) == SomeMoney(USD, 10, None)
    assert SomeMoney(USD, -10, None) + SomeMoney(USD, -20, None) == SomeMoney(USD, -30, None)
    assert SomeMoney(USD, -10, None) + SomeMoney(USD, 20, None) == SomeMoney(USD, 10, None)

# Generated at 2022-06-24 01:23:36.222380
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    ccy = Currency.get_instance("USD")
    qty = Decimal("1")
    dov = Date.today()
    price = SomePrice(ccy, qty, dov)

    other = Numeric(1)
    expected = Money.of(ccy, qty.quantize(ccy.quantizer), dov)

    assert price.times(other) == expected



# Generated at 2022-06-24 01:23:43.995427
# Unit test for constructor of class NonePrice
def test_NonePrice():
    nil_price = NonePrice()
    assert nil_price.defined == False

    nil_price.abs() == nil_price
    nil_price.negative() == nil_price
    nil_price.positive() == nil_price
    nil_price.round() == nil_price

    nil_price.add(nil_price) == nil_price
    nil_price.scalar_add(nil_price) == nil_price
    nil_price.subtract(nil_price) == nil_price
    nil_price.scalar_subtract(nil_price) == nil_price
    nil_price.multiply(nil_price) == nil_price
    nil_price.times(nil_price) == nil_price
    nil_price.divide(nil_price) == nil_price

# Generated at 2022-06-24 01:23:46.705125
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    assert __ge__(NonePrice(), Price())
    assert __ge__(Price(), NonePrice())
    assert __ge__(Price(None, None, None), Price())



# Generated at 2022-06-24 01:23:51.730864
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    """
    Tests whether method is_equal of class Price works correctly
    """

    assert NoPrice.is_equal(NoPrice)
    assert NoPrice.is_equal(SomePrice(USD, Decimal("1.00"), asof))

    assert not SomePrice(USD, Decimal("1.00"), asof).is_equal(NoPrice)
    assert not NoPrice.is_equal(SomePrice(EUR, Decimal("1.00"), asof))
    assert not SomePrice(USD, Decimal("1.00"), asof).is_equal(SomePrice(EUR, Decimal("1.00"), asof))
    assert not SomePrice(USD, Decimal("1.00"), asof).is_equal(SomePrice(USD, Decimal("1.50"), asof))

# Generated at 2022-06-24 01:23:52.767059
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    NoneMoney() - (Currency('HUF') | 100 | None)


# Generated at 2022-06-24 01:23:57.516910
# Unit test for method as_float of class Price
def test_Price_as_float():
    cola_price = SomePrice(Currency.USD, Decimal(1.25), Date(2020, 5, 10))
    assert cola_price.as_float() == 1.25


# Generated at 2022-06-24 01:24:10.057229
# Unit test for method lt of class Price
def test_Price_lt():
    # Let us check that lt works well for SomePrice
    p1 = SomePrice(USD, Decimal(1.1), TODAY)
    p2 = SomePrice(USD, Decimal(1.1), TODAY)

    result = p1.lt(p2)
    assert not result
    # Check that lt for SomePrice raises error for different currencies
    p1 = SomePrice(USD, Decimal(1.1), TODAY)
    p2 = SomePrice(GBP, Decimal(1.1), TODAY)
    with pytest.raises(IncompatibleCurrencyError):
        p1.lt(p2)
    # Check that lt for NoPrice returns false if arg is defined
    p1 = NoPrice
    p2 = SomePrice(USD, Decimal(1.1), TODAY)

# Generated at 2022-06-24 01:24:16.028856
# Unit test for method multiply of class Money
def test_Money_multiply():
    assert Money.of(Currency.USD, Decimal('2'), Date('2019-11-05')) * Decimal('3') == Money.of(Currency.USD, Decimal('6'), Date('2019-11-05'))
    assert Money.of(Currency.USD, Decimal('2'), Date('2019-11-05')) * 3 == Money.of(Currency.USD, Decimal('6'), Date('2019-11-05'))
    # Unit test for method __floordiv__ of class Money

# Generated at 2022-06-24 01:24:21.958965
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    #
    # Monkey patch the abstract method.
    #
    Money.is_equal = lambda self, other: (
        hasattr(other, "ccy")
        and hasattr(other, "dov")
        and hasattr(other, "qty")
        and self.ccy == other.ccy
        and self.dov == other.dov
        and self.qty == other.qty
    )

    #
    # Test is_equal
    #
    import datetime
    from .currencies import Currency
    from .exchange import TestFXRateService, TestFXRateSource

    from . import Money

    ccy = Currency.USD
    dov = Date(2018, 12, 31)
    qty = Decimal("12.00000")


# Generated at 2022-06-24 01:24:30.382784
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    r"""
    Tests the method with_dov of the class NonePrice.
    """

    ## Should return self:

    assert NonePrice.with_dov(None) == NonePrice
    assert NonePrice.with_dov(Date(2020, Month.JANUARY, 1)) == NonePrice
    assert NonePrice.with_dov(Date(2021, Month.JANUARY, 1)) == NonePrice

    return

# Generated at 2022-06-24 01:24:36.538823
# Unit test for method convert of class Money
def test_Money_convert():
    ccy1 = Currency.of('USD')
    ccy2 = Currency.of('EUR')
    v1 = 100
    d1 = 20190101
    m1 = SomeMoney(ccy1, ccy1.quantize(v1), d1)
    #print(m1.convert(ccy2))


# Generated at 2022-06-24 01:24:49.389721
# Unit test for method lte of class Price
def test_Price_lte():
    ccy = Currency.of('USD')
    assert ccy is not None
    dov = Date.of(2020, 2, 24)
    assert dov is not None
    p1 = Price.of(ccy, Decimal(1), dov)
    assert p1 is not None
    p2 = Price.of(ccy, Decimal(2), dov)
    assert p2 is not None
    p3 = Price.of(ccy, Decimal(-1), dov)
    assert p3 is not None
    assert p2.lte(p1) is False
    assert p1.lte(p2) is True
    assert p3.lte(p2) is False
    assert p3.lte(p1) is True
    assert p3.lte(p3) is True
test_Price

# Generated at 2022-06-24 01:24:59.256196
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    ## Should match
    assert (Money.of(None, None, None) // 4 == NoMoney)
    assert (Money.of(None, None, None) // 4.0 == NoMoney)
    assert (Money.of(None, None, None) // Decimal(4) == NoMoney)

    ## Should match
    assert (Money.of(Currency.USD, None, None) // 4 == NoMoney)
    assert (Money.of(Currency.USD, None, None) // 4.0 == NoMoney)
    assert (Money.of(Currency.USD, None, None) // Decimal(4) == NoMoney)

    ## Should match
    assert (Money.of(Currency.USD, 4, None) // 0 == NoMoney)

# Generated at 2022-06-24 01:25:11.797370
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    from .money import SomeMoney
    from .quant import Quantity
    from .rate import FXRate

    ccy, qty, dov = Currency("USD"), Decimal("10.00"), Date(2018, 1, 1)
    p1, p2, p3 = SomePrice(ccy, qty, dov), SomePrice(ccy, qty, dov), SomePrice(ccy, qty, dov)
    assert p1.__eq__(p1)
    assert p1.__eq__(p2)
    assert p2.__eq__(p1)
    assert p1.__eq__(p3)
    assert p3.__eq__(p1)
    assert not p1.__eq__(NoPrice)
    assert not p1.__eq__(None)
    assert not p1.__

# Generated at 2022-06-24 01:25:20.417475
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    p = SomePrice(Currency.USD, Decimal('1.2568'), Date.ISO('20181230'))
    assert p.round() == SomePrice(Currency.USD, Decimal('1'), Date.ISO('20181230'))
    assert p.round(1) == SomePrice(Currency.USD, Decimal('1.3'), Date.ISO('20181230'))
    assert p.round(2) == SomePrice(Currency.USD, Decimal('1.26'), Date.ISO('20181230'))
    assert p.round(3) == SomePrice(Currency.USD, Decimal('1.257'), Date.ISO('20181230'))
    assert p.round(4) == SomePrice(Currency.USD, Decimal('1.2568'), Date.ISO('20181230'))
    assert p

# Generated at 2022-06-24 01:25:27.161709
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    assert NonePrice.__add__(NonePrice, NonePrice) == Price.of(None, None, None)
    assert NonePrice.__add__(NonePrice, Price.of(USD, Decimal('10'), date(2020, 1, 1))) == Price.of(USD, Decimal('10'), date(2020, 1, 1))
    assert NonePrice.__add__(Price.of(USD, Decimal('10'), date(2020, 1, 1)), NonePrice) == Price.of(USD, Decimal('10'), date(2020, 1, 1))



# Generated at 2022-06-24 01:25:32.399058
# Unit test for method divide of class Price
def test_Price_divide():
    a = Price.of(EUR, 1, None)
    b = Price.of(USD, 1, None)
    assert (a.divide(b)==Price.of(EUR, 1, None))


# Generated at 2022-06-24 01:25:38.902138
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    # import nose
    # from pyexasol.decorators.deprecated import deprecated
    # from pyexasol.decorators.type import ignore_warnings
    # @deprecated
    # @ignore_warnings(category=DeprecationWarning)
    def __lt__(self, other: Money) -> bool:
        if other.undefined:
            return False
        elif self.ccy != other.ccy:
            raise IncompatibleCurrencyError(ccy1=self.ccy, ccy2=other.ccy, operation="< comparision")
        return self.qty < other.qty



# Generated at 2022-06-24 01:25:43.054426
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    ccy = parse_iso_ccy(test_ccy_name)
    qty = Decimal(test_qty)
    val = Money.of(ccy, qty, test_date)
    assert not (val >= val)



# Generated at 2022-06-24 01:25:47.710772
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    # Setup
    ccy = Currency.USD
    qty = Decimal('1.0')
    dov = Date(year=2018, month=1, day=1)
    price = Price.of(ccy, qty, dov)

    # Exercise
    actual = -price

    # Verify
    expected = Price.of(ccy, -qty, dov)
    assert actual == expected

# Generated at 2022-06-24 01:25:50.350099
# Unit test for constructor of class NonePrice
def test_NonePrice():
    from datetime import date
    from finacc.currency import Currency
    c = Currency('USD')
    NonePrice(c,5,date(2018,5,5))

    try:
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 01:26:00.142717
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert Price(1, USD).__neg__() == Price(-1, USD)
    # Price has been initialised with Currency as USD, and quantity 1
    assert Price(-1, USD).__neg__() == Price(1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price(1, USD).__neg__() == Price(-1, USD)
    assert Price

# Generated at 2022-06-24 01:26:02.148317
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    assert NoMoney.__truediv__(3) == NoMoney


# Generated at 2022-06-24 01:26:10.635020
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    assert SomeMoney(USD, 1, Date.today()).scalar_subtract(1) == NoMoney
    assert SomeMoney(USD, 1, Date.today()).scalar_subtract(1.1).qty == -0.1
    assert SomeMoney(USD, 1, Date.today()).scalar_subtract(Decimal("1.1")).qty == -0.1
    assert SomeMoney(USD, 1, Date.today()).scalar_subtract(Money(1, USD)) == NoMoney
    assert SomeMoney(USD, 1, Date.today()).scalar_subtract(Money(1.1, USD)).qty == -0.1



# Generated at 2022-06-24 01:26:19.800048
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    # Test cases
    test_case = namedtuple("Test Case", ["input", "expected"])
    cases = [
        test_case(
            input=dict(
                money=NoneMoney,
            ),
            expected=NoneMoney,
        ),
    ]
    # Test code
    for c in cases:
        actual = c.input["money"].with_qty(c.input["qty"])
        assert actual == c.expected, "Expected: " + str(c.expected) + " but got: " + str(actual)

# Generated at 2022-06-24 01:26:23.150235
# Unit test for method gt of class Price
def test_Price_gt():
    n = NoMoney.with_qty(0)
    m = n.with_ccy(USD)

    assert(n.gt(m) == False)

# Generated at 2022-06-24 01:26:28.818156
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    # Case 1: Money is undeined
    money = NoMoney
    assert money.as_boolean() == False

#     Case 2: Money is defined
    money = SomeMoney(Currency.of("EUR"), Decimal(1), Date(2018, 9, 1))
    assert money.as_boolean() == True

# Generated at 2022-06-24 01:26:33.555379
# Unit test for method abs of class Price
def test_Price_abs():
    p = Price.of(EUR, Decimal("-12.5"), Date(2021, 1, 1))
    assert p.abs() == Price.of(EUR, Decimal("12.5"), Date(2021, 1, 1))



# Generated at 2022-06-24 01:26:36.241554
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    s: SomePrice = SomePrice("EUR", Decimal("1"), date(2020, 1, 1))

    assert s == s.with_ccy("EUR")
    assert s != s.with_ccy("USD")
    assert s.with_ccy("USD") == SomePrice("USD", Decimal("1"), date(2020, 1, 1))

# Generated at 2022-06-24 01:26:42.089853
# Unit test for method lt of class Money
def test_Money_lt():
    a = Money.of(ccy='USD', qty=2.5, dov=Date.today())
    b = Money.of(ccy='USD', qty=3.5, dov=Date.today())
    print(a.lt(b))


# Generated at 2022-06-24 01:26:45.824899
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    assert int(SomeMoney(GBP, 1234, Date(2015, 8, 21))) == 1234


# Generated at 2022-06-24 01:26:51.611151
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():

    def test_it(a: SomeMoney):
        assert a.negative() == SomeMoney(USD, -Decimal('2.14'), Date(year=2016, month=3, day=15))

    def _():
        a = SomeMoney(USD, Decimal('2.14'), Date(year=2016, month=3, day=15))
        test_it(a)

    _()



# Generated at 2022-06-24 01:26:57.656332
# Unit test for method divide of class Money
def test_Money_divide():
    """
    Test case: divide
    """
    money = Money.of(Currency.USD, 20, Date.today())
    assert (money.divide(2) == Money.of(Currency.USD, Decimal('10.00'), Date.today()))

# Generated at 2022-06-24 01:26:59.133867
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    pass


# Generated at 2022-06-24 01:27:12.620199
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    from datetime import date
    from quantulum3 import parser
    from quantulum3.currency import USD
    from quantulum3.units import MASS
    from pytest import raises

    # Test for undefined price object
    assert NoPrice.scalar_add(1) == NoPrice

    # Test for defined price object
    price1 = Price.of(USD, Decimal(5.99), date(year=2019, month=4, day=1))
    price2 = Price.of(USD, Decimal(10.99), date(year=2019, month=4, day=1))
    price3 = Price.of(USD, Decimal(1.0), date(year=2019, month=4, day=1))


# Generated at 2022-06-24 01:27:21.374444
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    from .currency import Currency
    from .date import Date
    from .money import Money
    from .money import MoneyException
    from .numeric import Decimal
    from .price import NoPrice
    from .price import Price

    assert Price.of(Currency.USD, Decimal(1), Date.today()) == -Price.of(Currency.USD, Decimal(-1), Date.today())
    assert not (Price.of(Currency.USD, Decimal(1), Date.today()) < -Price.of(Currency.USD, Decimal(-1), Date.today()))
    assert not (Price.of(Currency.USD, Decimal(-1), Date.today()) > -Price.of(Currency.USD, Decimal(1), Date.today()))

# Generated at 2022-06-24 01:27:32.971626
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    m0 = Money.of(ccy = Currency('USD'), qty = None, dov = None)
    assert m0.as_boolean() == False

    m1 = Money.of(ccy = Currency('USD'), qty = 0, dov = None)
    assert m1.as_boolean() == False

    m2 = Money.of(ccy = Currency('USD'), qty = 0.0, dov = None)
    assert m2.as_boolean() == False

    m3 = Money.of(ccy = Currency('USD'), qty = 1, dov = None)
    assert m3.as_boolean() == True

    m4 = Money.of(ccy = Currency('USD'), qty = 1.0, dov = None)
    assert m4.as_boolean() == True



# Generated at 2022-06-24 01:27:40.697471
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    m = SomeMoney(Currency.of('USD'), Decimal(1))
    m_1 = m.with_qty(Decimal(2))
    assert m_1.ccy == m.ccy
    assert m_1.qty == Decimal(2)
    assert m_1.dov == m.dov
    assert m_1 != m
    
    m = SomeMoney(Currency.of('USD'), Decimal(1))
    m_2 = m.with_qty(m.qty)
    assert m_2.ccy == m.ccy
    assert m_2.qty == m.qty
    assert m_2.dov == m.dov
    assert m_2 == m
    
    qty = Decimal(3)
    m_3 = m.with_q

# Generated at 2022-06-24 01:27:44.368468
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    np = NonePrice()
    assert np.with_qty(Decimal("0.0")) is np

# Generated at 2022-06-24 01:27:48.083340
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    res = NoneMoney.round()
    assert res == NoMoney

# Generated at 2022-06-24 01:27:49.003550
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    raise NotImplementedError()


# Generated at 2022-06-24 01:27:49.980785
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    """
    TODO: Test __bool__ method of class NonePrice.
    """
    pass


# Generated at 2022-06-24 01:28:03.782462
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    from xbbg.core.money import Money
    from xbbg.core.money import NoneMoney
    from xbbg.core.money import SomeMoney
    from xbbg.core.money import NoMoney
    from xbbg.core.money import InvalidOperation
    from xbbg.core.money import DivisionByZero
    
    
    ## Money/NoneMoney
    assert (Money(3.0,"USD",None)/NoneMoney) == Money(3.0,"USD",None)
    
    
    
    
    
    
    
    
    
    
    
    
    ## Money/SomeMoney
    assert (Money(3.0,"USD",None)/Money(3.0,"USD",None)) == Money(1.0,None,None)

# Generated at 2022-06-24 01:28:15.715334
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    _pymonads_test_Price___gt___alt_1(NoPrice, EUR.with_qty(0), NoPrice)
    _pymonads_test_Price___gt___alt_1(NoPrice, EUR.with_qty(123), NoPrice)
    _pymonads_test_Price___gt___alt_1(NoPrice, NoMoney, NoPrice)
    _pymonads_test_Price___gt___alt_2(NoPrice, EUR.with_qty(0), None)
    _pymonads_test_Price___gt___alt_2(NoPrice, EUR.with_qty(123), None)
    _pymonads_test_Price___gt___alt_2(NoPrice, NoMoney, None)
    _pymonads_test_Price___gt___alt_3

# Generated at 2022-06-24 01:28:28.056949
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
        _lhs_val = NonePrice()
        _rhs_val = Price.of('USD', Decimal('1.0'), Date(1999, 12, 31))
        _rhs_val2 = Price.of('USD', Decimal('0.0'), Date(1999, 12, 31))
        _result = _lhs_val.__gt__(_rhs_val)
        _result2 = _lhs_val.__gt__(_rhs_val2)
        _expect = False
        _expect2 = False
        assert _result == _expect, "Expected {0}, got {1}".format(str(_expect), str(_result))
        assert _result2 == _expect2, "Expected {0}, got {1}".format(str(_expect2), str(_result2))
        _result3