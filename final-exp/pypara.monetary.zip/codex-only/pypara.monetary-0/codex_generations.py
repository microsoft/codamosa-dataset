

# Generated at 2022-06-24 01:18:30.122650
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    """
    Tests the with_dov method of the SomePrice class
    """
    some_price_sample = SomePrice(ccy=Currency.get("USD"), qty=Decimal("1"), dov=Date(2019, 3, 1))
    assert some_price_sample.with_dov(dov=Date(2019, 3, 1)) == some_price_sample

# Generated at 2022-06-24 01:18:31.931213
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    assert NonePrice().times(10) == NoMoney

# Generated at 2022-06-24 01:18:37.306955
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    dv_price = Price.of('USD', 100, Date(1,1,1))
    dv_divisor = 20

    dv_result = dv_price.floor_divide(dv_divisor)

    assert dv_result.qty == 5
    assert dv_result.ccy == 'USD'
    assert dv_result.dov == Date(1,1,1)



# Generated at 2022-06-24 01:18:44.792239
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    example_qty = Decimal('20')
    example_money = SomeMoney(EUR, example_qty, TODAY)
    example_qty = Decimal('10')
    assert example_money.with_qty(example_qty) == SomeMoney(EUR, Decimal('10'), TODAY)



# Generated at 2022-06-24 01:18:50.019189
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    ccy_str = "USD"
    qty_str = "10.00"
    dov_str = "2020-01-01"

    ccy = Currency.of(ccy_str)
    qty = Decimal(qty_str)
    dov = Date.today()

    price = SomePrice(ccy, qty, dov)

    ccy_str = "USD"
    new_dov = "2020-01-01"

    new_dov = Date.parse(
        new_dov,
        formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd"),
    )

    price_new_dov = price.with_dov(new_dov)


# Generated at 2022-06-24 01:18:59.318840
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    # Provide inputs for the test here
    arg1 = Money
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None
    arg9 = None

    # Perform the test here
    try:
        result = Money.__eq__(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
        assert result is None # fill in the right value here
    except Exception as e:
        raise e

# Generated at 2022-06-24 01:19:02.904538
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    instance = NonePrice()
    other = Decimal(2)

    assert isinstance(instance.scalar_subtract(other), Price)

# Generated at 2022-06-24 01:19:05.671944
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    """
    Test that a money object returns itself when calling the method with_dov.

    This test is required by the `abstract` base class decorator.
    """
    # Arrange
    money: Money = NoMoney

    # Act
    assert money.with_dov(Date(2018, 10, 1)) is money



# Generated at 2022-06-24 01:19:07.411445
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    raise NotImplementedError()

# Generated at 2022-06-24 01:19:18.730789
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    m1 = SomeMoney(Currency("USD"), Decimal("1000"), Date(2020, 7, 1))
    m2 = SomeMoney(Currency("USD"), Decimal("1001"), Date(2020, 7, 1))
    m3 = SomeMoney(Currency("USD"), Decimal("1000"), Date(2020, 7, 2))
    m4 = SomeMoney(Currency("EUR"), Decimal("1000"), Date(2020, 7, 1))
    m5 = SomeMoney(Currency("EUR"), Decimal("1000"), Date(2020, 7, 2))
    m6 = SomeMoney(Currency("USD"), Decimal("1000"), Date(2020, 7, 1))
    m7 = SomeMoney(Currency("USD"), Decimal("1000"), Date(2020, 7, 1))

    assert not m1.is_equal(m2)
   

# Generated at 2022-06-24 01:19:19.707302
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    assert not NoPrice


# Generated at 2022-06-24 01:19:31.565341
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    """
    Tests that method with_qty of the NoneMoney class
    """
    ## Tests that you can get the qty of a NoneMoney instance
    q: Decimal = NoneMoney.with_qty(Decimal(10))
    assert q.qty == Decimal(10)
    assert q.defined is False
    ## Tests that it doesn't matter what value you put in the method
    q: Decimal = NoneMoney.with_qty(Decimal(0))
    assert q.qty == Decimal(0)
    assert q.defined is False
    q: Decimal = NoneMoney.with_qty(Decimal(-10))
    assert q.qty == Decimal(-10)
    assert q.defined is False
    ## Tests that the method with_qty also works with floats

# Generated at 2022-06-24 01:19:33.401348
# Unit test for method as_float of class Money
def test_Money_as_float():
    result = None
    try:
        m = Money.of(None, None, None)
        result = m.as_float()
    except MonetaryOperationException:
        result = "No money"
    except TypeError:
        result = "No money"
    return "No money" == result

# Generated at 2022-06-24 01:19:40.410049
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():

    Today = Date(2020, 10, 10)
    assert Date.today() == Date.today(asof=Today)

    USD = Currency("USD")
    CAD = Currency("CAD")

    p1 = Price.of(USD, 2.0, Today)
    p2 = Price.of(CAD, 3.0, Today)

    assert p1.ccy == USD
    assert p2.ccy == CAD

    p3 = p1.with_ccy(CAD)
    assert p3.ccy == CAD

    assert p1.with_ccy(USD).qty == p1.qty
    assert p1.with_ccy(USD).dov == p1.dov

    assert p1.with_ccy(CAD).qty == p1.qty
    assert p1.with_cc

# Generated at 2022-06-24 01:19:41.892577
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    NoneMoney().with_ccy(USD) == NoMoney
    pass

# Generated at 2022-06-24 01:19:54.490743
# Unit test for method __int__ of class Price
def test_Price___int__():
    some_price_1 = SomePrice(JPY, 0.50, Date(2020, 1, 1))
    assert int(some_price_1) == 0

    some_price_2 = SomePrice(JPY, 0.75, Date(2020, 1, 1))
    assert int(some_price_2) == 0

    some_price_3 = SomePrice(JPY, 1.50, Date(2020, 1, 1))
    assert int(some_price_3) == 1

    some_price_4 = SomePrice(JPY, -0.50, Date(2020, 1, 1))
    assert int(some_price_4) == 0

    some_price_5 = SomePrice(JPY, -0.75, Date(2020, 1, 1))
    assert int(some_price_5) == 0

    some

# Generated at 2022-06-24 01:19:55.415289
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    # TODO
    pass



# Generated at 2022-06-24 01:19:57.622678
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    assert (NoPrice > 0) == False


# Generated at 2022-06-24 01:20:04.471429
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    from datetime import date
    from cpy2py.utility.monkeypatch import monkeypatch_test

    with monkeypatch_test(Price) as mock:
        with mock.patch('Price.with_dov', mock.Mock(return_value=mock.sentinel.result)):
            assert Price.NA.with_dov(date.today()) == mock.sentinel.result
            Price.NA.with_dov.assert_called_with(date.today())

# Generated at 2022-06-24 01:20:09.889698
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    ## Make sure we use default currency:
    Currency.default = Currency.USD

    ## Create a money:
    money = SomeMoney(
        ccy=Currency.USD,
        qty=Decimal("123.45"),
        dov=Date.today()
    )
    ## Check it is correct:
    assert money == SomeMoney(
        ccy=Currency.USD,
        qty=Decimal("123.45"),
        dov=Date.today()
    )
    assert money.scalar_add(123) == SomeMoney(
        ccy=Currency.USD,
        qty=Decimal("246.45"),
        dov=Date.today()
    )

# Generated at 2022-06-24 01:20:13.723230
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    from decimal import Decimal
    NoneMoney().scalar_subtract(Decimal(10)) == NoneMoney()
    NoneMoney().scalar_subtract(1.0) == NoneMoney()
    NoneMoney().scalar_subtract(1) == NoneMoney()
test_NoneMoney_scalar_subtract()
# test_NoneMoney_scalar_add = []

# Generated at 2022-06-24 01:20:20.561691
# Unit test for method round of class Price
def test_Price_round():
    ccy = Currency.of('EUR')
    qty = Decimal(1.15)
    dov = Date(2020, 1, 1)
    input = Price.of(ccy, qty, dov)
    expected = Price.of(ccy, Decimal(1.2), dov)

    assert input.round(1) == expected
    assert input.__round__(1) == expected
    assert round(input, 1) == expected

test_Price_round()

# Generated at 2022-06-24 01:20:23.956640
# Unit test for method multiply of class Money
def test_Money_multiply():
    ### Definition of money
    m = Money.__init__()
    ### Definition of quantity
    qty = Decimal.__init__(3)
    ### Multiplication of money by quantity
    m * qty



# Generated at 2022-06-24 01:20:25.891063
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    o1 = SomeMoney(CCY_USD, Decimal("100"), "2019-01-01")
    assert o1.__int__() == 100

# Generated at 2022-06-24 01:20:29.164235
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    assert Money(Currency.USD, 1.0) / Money(Currency.USD, 1.0) == 1
    assert Money(Currency.USD, 10.0) / Money(Currency.USD, 2.0) == 5



# Generated at 2022-06-24 01:20:40.380757
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():

    from jload.models.money import Money
    from jload.models.fx_rate import FXRate
    from jload.models.fx_rate_service import FXRateService

    ## Define test case parameters:
    ccy_a = Currency.find("USD")
    ccy_b = Currency.find("EUR")
    date_today = Date.today()

    ## Define fixture:
    price = SomePrice(ccy_a, Decimal("100.00"), date_today)

    ## Test:
    assert price.__truediv__(Decimal("100.00")) == SomePrice(ccy_a, Decimal("1.00"), date_today)
    assert price.__truediv__("100.00") == SomePrice(ccy_a, Decimal("1.00"), date_today)

    assert price

# Generated at 2022-06-24 01:20:41.056872
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    pass

# Generated at 2022-06-24 01:20:43.408147
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert SomeMoney("USD", Decimal("125"), Date.today()).as_integer() == 125
    assert NoMoney.as_integer() == 0
    assert NoneMoney.as_integer() == 0

# Generated at 2022-06-24 01:20:49.876565
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    """
    Tests the method __floordiv__ of class Price
    """
    # create a test price
    price1 = Price.of(CCY, QTY, DOV)
    # create another test price
    price2 = Price.of(CCY, QTY, DOV)
    # check that floor division of two defined prices yields a defined price
    assert (price1 // price2).defined
    # create a test price
    price3 = Price.of(CCY, Decimal(0), DOV)
    # check that floor division of a defined price by a zero quantity price yields an undefined price
    assert (price1 // price3).undefined
    # check that floor division of an undefined price by a defined price yields an undefined price
    assert (NoPrice // price1).undefined
    # create a test price
    price4 = Price.of

# Generated at 2022-06-24 01:21:01.150140
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    from money import Money
    from money import Currency
    from money import NoMoney
    from money import SomeMoney
    from numbers import Number
    ccy = Currency.get("CAD")
    assert isinstance(Money.of(ccy), Money)
    assert isinstance(Money.of(ccy), NoMoney)
    money = Money.of(ccy)
    scalar = Number(2)
    assert isinstance(money.scalar_add(scalar), Money)
    assert isinstance(money.scalar_add(scalar), NoMoney)
    some_money = SomeMoney(ccy, Decimal("2.00"), Date.today())
    assert isinstance(some_money.scalar_add(scalar), Money)

# Generated at 2022-06-24 01:21:05.930638
# Unit test for constructor of class Price
def test_Price():
    ccy = Currency.USD
    qty = Decimal('1.2')
    dov = Date.now()
    p = Price(ccy, qty, dov)
    assert p.ccy == Currency.USD
    assert p.qty == Decimal('1.2')
    assert p.dov == Date.now()




# Generated at 2022-06-24 01:21:08.361083
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    from .currencies import GBP, EUR, USD
    gbp = GBP[1000]
    eur = EUR[1000]
    assert gbp > gbp
    assert eur >= eur

# Generated at 2022-06-24 01:21:11.372555
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert Money.of(Currency.USD, Decimal("10.1234"), None).__ge__(Money.of(Currency.USD, Decimal("10.1234"), None))
    assert not Money.of(Currency.USD, Decimal("10.1234"), None).__ge__(Money.of(Currency.USD, Decimal("20.1234"), None))



# Generated at 2022-06-24 01:21:12.176613
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    assert NoPrice.with_dov(date.today()) == NoPrice



# Generated at 2022-06-24 01:21:17.415539
# Unit test for method positive of class Price
def test_Price_positive():
    assert NoPrice.positive is NoPrice
    assert SomePrice(CAD, 1, date).positive == SomePrice(CAD, 1, date)
    assert SomePrice(CAD, Decimal("-1"), date).positive == SomePrice(CAD, Decimal("-1"), date)

# Generated at 2022-06-24 01:21:19.536728
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    m = SomeMoney(Currency.USD, Decimal("1.23"), Date(2020, 1, 2))
    assert m.__bool__()

    m = SomeMoney(Currency.USD, Decimal("0"), Date(2020, 1, 2))
    assert not m.__bool__()

# Generated at 2022-06-24 01:21:24.454057
# Unit test for method divide of class Money
def test_Money_divide():
    m1 = Money.of(CURRENCY_USD, Decimal('1234.56'), Date.now())
    assert m1.divide(1) == m1


# Generated at 2022-06-24 01:21:30.230574
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """
    Tests the method ``__gt__`` of a ``SomeMoney`` object.
    """
    ## Arrange:
    money = Money.of(Currency.AUD, Decimal("1000.00"), Date(2020, 1, 1))

    ## Act and assert:
    assert money > Money.of(Currency.AUD, Decimal("999.99"), Date(2020, 1, 1))



# Generated at 2022-06-24 01:21:35.953191
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    x = NoneMoney
    assert x.scalar_add(1) is x

    x = SomeMoney(USD, Decimal("13.13"), Date(2019, 10, 15))
    assert x.scalar_add(0) == SomeMoney(USD, Decimal("13.13"), Date(2019, 10, 15))
    assert x.scalar_add(1) == SomeMoney(USD, Decimal("14.13"), Date(2019, 10, 15))
    assert x.scalar_add("1") == SomeMoney(USD, Decimal("14.13"), Date(2019, 10, 15))
    assert x.scalar_add(Decimal("1.0")) == SomeMoney(USD, Decimal("14.13"), Date(2019, 10, 15))

# Generated at 2022-06-24 01:21:37.663203
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():
    assert (NoPrice // 2) == NoPrice



# Generated at 2022-06-24 01:21:39.383603
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    assert (NonePrice().scalar_subtract(10) == NoPrice)
    assert (type(NonePrice().scalar_subtract(10)) == NoPrice)

# Generated at 2022-06-24 01:21:46.464738
# Unit test for method convert of class Money
def test_Money_convert():
    from .monetary import Money
    from .currencies import Currency
    
    jpy = Currency.of("JPY")
    usd = Currency.of("USD")

# Generated at 2022-06-24 01:21:50.033492
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():

    #Case A: Empty 
    result = NoMoney.__neg__()
    assert result == NoMoney
    print("Case A:", result)


# Generated at 2022-06-24 01:21:54.204080
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert Price.of("USD", 1, "2019-01-01").__int__() == 1
    assert Price.of("USD", 1.2, "2019-01-01").__int__() == 1
    assert Price.of("USD", 1.5, "2019-01-01").__int__() == 1
    assert Price.of("USD", -1.2, "2019-01-01").__int__() == -1
    assert Price.of("USD", -1.5, "2019-01-01").__int__() == -1

# Generated at 2022-06-24 01:22:05.582896
# Unit test for constructor of class Money
def test_Money():

    from .currencies import KAZ, TRY, USD

    assert SomeMoney(KAZ, 1, Date.today()).ccy == KAZ
    assert SomeMoney(KAZ, 1, Date.today()).qty == 1
    assert SomeMoney(KAZ, 1, Date.today()).dov == Date.today()
    assert NoMoney.ccy == None
    assert NoMoney.qty == None
    assert NoMoney.dov == None

    # TypeError if set
    try:
        SomeMoney(KAZ, 1, Date.today()).ccy = USD
        assert False
    except AttributeError:
        pass

    # TypeError if set
    try:
        SomeMoney(KAZ, 1, Date.today()).qty = 2
        assert False
    except AttributeError:
        pass

    # Type

# Generated at 2022-06-24 01:22:17.517978
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    # Test is_equal
    assert Money.of('USD', 1).is_equal(Money.of('USD', 1))
    assert not Money.of('USD', 1).is_equal(Money.of('USD', 2))
    assert not Money.of('USD', 1).is_equal(Money.NA)
    assert Money.NA.is_equal(Money.NA)

    # Test as_float
    assert Money.of('USD', 1).as_float() == 1.0
    assert_raises(MonetaryOperationException, Money.NA.as_float)

    # Test as_integer
    assert Money.of('USD', 1).as_integer() == 1
    assert_raises(MonetaryOperationException, Money.NA.as_integer)

    # Test as_boolean
    assert Money.of('USD', 1).as_

# Generated at 2022-06-24 01:22:22.806319
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    """
    Unit test for method __int__ of class SomeMoney
    """
    # Test with regular money:
    some_money = SomeMoney(USD(5), Decimal('1.55'), Date('2020-08-15'))
    assert int(some_money) == 1
    # Test with undefined money:
    assert int(NoMoney) == 0
    # Test with negative money:
    some_money = SomeMoney(USD(5), Decimal('-1.55'), Date('2020-08-15'))
    assert int(some_money) == -1
    # Test with undefined money:
    assert int(NoMoney) == 0


# Generated at 2022-06-24 01:22:24.469826
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    res = NoneMoney.of()
    assert(res == NoMoney)


# Generated at 2022-06-24 01:22:30.259109
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    from zircle import z as z_
    assert not z_().convert(Currency(code="USD"), Date(day=1, month=1, year=2014))
test_NoneMoney_convert()


# Generated at 2022-06-24 01:22:31.186049
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    # FIXME: implement this test:
    assert False

# Generated at 2022-06-24 01:22:34.346511
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NonePrice.with_qty(Decimal(10)) == NonePrice


# Generated at 2022-06-24 01:22:40.509200
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    # Test case data
    some_money_1 = SomeMoney(currency('USD'), Decimal('1.25'), date(2017, 12, 29))
    # Perform the test
    result = some_money_1.__abs__()
    # Verify the results
    assert result == SomeMoney(currency('USD'), Decimal('1.25'), date(2017, 12, 29))

# Generated at 2022-06-24 01:22:47.593591
# Unit test for method lte of class Price
def test_Price_lte():
    # Test method Price.lte
    ccy = Currency.parse("USD")
    qty = Decimal("2.00")
    dov = Date(year=2018, month=1, day=1)
    price_a = Price.of(ccy=ccy, qty=qty, dov=dov)
    ccy = Currency.parse("USD")
    qty = Decimal("2.00")
    dov = Date(year=2018, month=1, day=1)
    price_b = Price.of(ccy=ccy, qty=qty, dov=dov)
    assert price_a.lte(price_b)
    ccy = Currency.parse("USD")
    qty = Decimal("2.00")

# Generated at 2022-06-24 01:22:57.321632
# Unit test for method __round__ of class Money
def test_Money___round__():
    assert round(Money.of(Currency.USD, 10, Date.today())) == 10
    assert round(Money.of(Currency.USD, 10.1, Date.today()), 1) == Money.of(Currency.USD, 10.1, Date.today())
    assert round(Money.of(Currency.USD, 10.1, Date.today()), 0) == Money.of(Currency.USD, 10, Date.today())
    assert round(Money.of(Currency.USD, 1.25, Date.today()), 0) == Money.of(Currency.USD, 1, Date.today())
    assert round(Money.of(Currency.USD, 2.5, Date.today()), 0) == Money.of(Currency.USD, 2, Date.today())

# Generated at 2022-06-24 01:23:04.175128
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    from decimal import Decimal
    from datetime import date
    from src.domain.value.money import Money
    from src.domain.value.price import Price
    from src.domain.value.quantity import Quantity
    from src.domain.value.rate import Rate
    from src.domain.value.timeframe import TimeFrame
    from src.domain.value.value_amount import ValueAmount
    from src.lib.logger import Logger
    from src.lib.program_context import ProgramContext

    money_usd_1 = Money.of("USD", Decimal("100"), None)
    money_usd_2 = Money.of("USD", Decimal("200"), None)
    money_usd_3 = Money.of("USD", Decimal("300"), None)

# Generated at 2022-06-24 01:23:16.313202
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    from .currency import USD, EUR
    from .price import Price
    from .money import Money

    # Price comparison

# Generated at 2022-06-24 01:23:23.215474
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    from inspect import signature
    from gnucashcamelot.core.model.util.portable import SomePrice, NoPrice, Price, Currency, Money
    from gnucashcamelot.setting.setting import Setting
    setting = Setting()
    if setting.api == "sqlalchemy":
        return

# Generated at 2022-06-24 01:23:31.390453
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    ## Setup & Exercise:
    m = Money.of(Currency.USD, Decimal(1), date(2020, 1, 1))
    assert m.dov == date(2020, 1, 1)

    ## Verify:
    assert m.with_dov(date(2020, 2, 1)) == Money.of(Currency.USD, Decimal(1), date(2020, 2, 1))
# Unit tests for class Price
# Unit tests for class Money

# Generated at 2022-06-24 01:23:34.148720
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(USD, Decimal("1.075"), date(2020, 1, 3)).convert(EUR, date(2020, 1, 3)).qty == Decimal("1.0")


# Generated at 2022-06-24 01:23:39.527001
# Unit test for method abs of class Money
def test_Money_abs():
    assert Money.of(Currency.USD, -1, Date.today()) == Money.of(Currency.USD, 1, Date.today())


# Generated at 2022-06-24 01:23:44.005657
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    from decimal import Decimal
    from datetime import date
    from core.core import Currency, SomeMoney, EUR, GBP
    from core.core import expect

    ## When:
    actual = -SomeMoney(EUR, Decimal("10.10"), date(2017, 2, 21))

    ## Then:
    expected = SomeMoney(EUR, -Decimal("10.10"), date(2017, 2, 21))
    expect(actual).to_be(expected)


# Generated at 2022-06-24 01:23:45.999036
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    x = Price.of(Currency.USD, Decimal(1), Date.today())
    assert x.floor_divide(Decimal(2)) == Price.of(Currency.USD, Decimal(0), Date.today())



# Generated at 2022-06-24 01:23:53.887387
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    """
    Unit test for method ``__mul__`` of class ``NonePrice``
    """
    method_name = "NonePrice.__mul__"
    # Case 1: mul: NonePrice and NonePrice
    arg1 = NonePrice
    arg2 = NonePrice
    npt_assert_equal(method_name, arg1 * arg2, NonePrice, verbose=True)
    # Case 2: mul: NonePrice and int
    arg1 = NonePrice
    arg2 = 1
    npt_assert_equal(method_name, arg1 * arg2, NonePrice, verbose=True)
    # Case 3: mul: NonePrice and float
    arg1 = NonePrice
    arg2 = 1.0
    npt_assert_equal(method_name, arg1 * arg2, NonePrice, verbose=True)


# Generated at 2022-06-24 01:24:04.056686
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    """
    Test method scalar_add of class Price
    """
    print("Testing method scalar_add of class Price...")
    a = Price.of("USD", 3.0, Date(year=2018, month=1, day=1))

    # Test for 'undefined' Price
    try:
        a.scalar_add(0)
        assert False
    except MonetaryOperationException:
        pass

    # Test for 'defined' Price
    b = Price.of("USD", 10.0, Date(year=2018, month=1, day=1))
    assert b.scalar_add(3).qty == 13.0
    print("The method scalar_add of Price passed the test!")


test_Price_scalar_add()



# Generated at 2022-06-24 01:24:11.483222
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    price1 = Price.of(Currency("CAD"), Decimal("10.9999"), Date(2020, 4, 1))
    assert price1.scalar_subtract(decimal("1.123")) == Price.of(Currency("CAD"), Decimal("9.8769"), Date(2020, 4, 1))
    assert price1.scalar_subtract(1) == Price.of(Currency("CAD"), Decimal("9.9999"), Date(2020, 4, 1))
    assert price1.scalar_subtract(2.12) == Price.of(Currency("CAD"), Decimal("8.8799"), Date(2020, 4, 1))

# Generated at 2022-06-24 01:24:20.163001
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    from numpy import decimal
    from collections import namedtuple
    from . import Currency
    from . import FXRateService
    from . import Date
    from . import NoPrice
    from . import NoMoney
    from . import Money
    from . import _money_repr
    from . import SomePrice
    from . import SomeMoney
    from . import _price_repr
    from . import _price_str
    from . import IncompatibleCurrencyError
    from . import ProgrammingError
    from . import FXRateLookupError
    ccy = Currency.of("GBP")
    assert ccy.defined
    qty = Decimal("1.000000")
    assert qty.__class__ is decimal.Decimal
    dov = Date.today()
    assert dov.__class__ is dt.date

# Generated at 2022-06-24 01:24:30.478039
# Unit test for method divide of class Price
def test_Price_divide():
    LOGGER.info("Started ")
    price = Price.of(ccy = Currency.of('TRY'), qty = Decimal(10), dov = Date(year = 2020, month = 1, day = 1))
    price2 = Price.of(ccy = Currency.of('TRY'), qty = Decimal(5), dov = Date(year = 2020, month = 1, day = 1))
    price_divide = price.divide(other = price2)
    assert str(price_divide) == '2.0'
    LOGGER.info("Ended ")



# Generated at 2022-06-24 01:24:43.636063
# Unit test for method convert of class Price
def test_Price_convert():
    from dataclasses import _MISSING_TYPE
    from datetime import date
    from arctic.dates import Date
    from arctic.money import Price

    _ccy1 = Currency("EUR")
    _ccy2 = Currency("USD")
    _asof = Date(date(2020, 9, 4))

    def _setup(qty: Optional[Decimal] = None, ccy: Optional[Currency] = None, dov: Optional[Date] = None):
        return Price.of(ccy or _ccy1, qty or 1, dov or _asof)

    _setup()
    assert raise_if_invalid(_setup(), _ccy1, 1, _asof) is None

    _setup(ccy = Currency("USD"))

# Generated at 2022-06-24 01:24:50.346221
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    money = Money(USD, 20, None)

    assert 3 == money.scalar_subtract(17)
    assert -3 == money.scalar_subtract(-23)
    assert 20 == money.scalar_subtract(0)

    assert money is money.scalar_subtract(None)
    assert NoMoney is NoMoney.scalar_subtract(None)



# Generated at 2022-06-24 01:24:53.022088
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    price = Price.of(Currency("USD"), Decimal("100.00"), Date.today())
    price = price.scalar_subtract(10)
    assert price == Price.of(Currency("USD"), Decimal("90.00"), Date.today())


# Generated at 2022-06-24 01:24:55.387029
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    instance = NoneMoney
    result = instance.__int__()
    assert (type(result) is int)



# Generated at 2022-06-24 01:24:58.189973
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    a = Price.of(USD, Decimal('0.5'), Date(2020, 12, 31))
    b = a.floor_divide(2)
    c = b.price
    d = c.with_qty(Decimal('0'))
    assert d == NoPrice



# Generated at 2022-06-24 01:25:11.072326
# Unit test for method lte of class Money
def test_Money_lte():
    assert Money.of(None, None, None).lte(NoPrice) == False
    assert Money.of(None, None, None).lte(NoneMoney) == False
    assert Money.of(None, None, None).lte(Money.of(None, None, None)) == True
    assert Money.of(None, None, None).lte(SomeMoney(CAD, Decimal("100.00"), Date(2018, 1, 1))) == True
    # assert Money.of(None, None, None).lte(SomePrice(CAD, Decimal("100.00"), Date(2018, 1, 1))) == True
    # assert Money.of(None, None, None).lte(SomePrice(CAD, Decimal("100.00"), Date(2018, 1, 1))) == True
    # assert Money.of(None, None

# Generated at 2022-06-24 01:25:16.254390
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    assert float(SomeMoney(USD, Decimal("1"), date(2000, 1, 1))) == 1.0
    assert float(SomeMoney(USD, Decimal("0"), date(2000, 1, 1))) == 0.0
    assert float(SomeMoney(USD, Decimal("-1"), date(2000, 1, 1))) == -1.0

# Generated at 2022-06-24 01:25:25.402473
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    """
    Tests method __float__ of class SomeMoney.
    """
    test_data = [(-1.0001, USD, -1.0001), (-1.0001, EUR, -1.0001), (1.0001, USD, 1.0001), (1.0001, EUR, 1.0001)]
    for qty, ccy, expected in test_data:
        some_money = SomeMoney(ccy, qty, Date.today())
        assert some_money.__float__() == expected

# Generated at 2022-06-24 01:25:36.891745
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    """
    Tests NumericComparison.lt for NonePrice
    """
    for ccy, qty in [(GBP, Decimal(1.234)), (USD, Decimal(2.345)), (EUR, Decimal(3.456))]:
        for dov in [date(2020, 1, 1), date(2020, 1, 2), date(2020, 1, 3)]:
            assert (NoPrice < SomePrice(ccy, qty, dov)) == True
            assert (NoPrice < NoPrice) == False
            assert (SomePrice(ccy, qty, dov) < NoPrice) == False

            # Ensure we get some reasonable output regardless

# Generated at 2022-06-24 01:25:41.789326
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    c = Currency.get("USD")
    p = SomePrice(c, Decimal(25), Date.today())
    p2 = p.convert(Currency.get("CAD"))
    assert p2.ccy == Currency.get("CAD")
    assert p2.qty == Decimal('30.7184')



# Generated at 2022-06-24 01:25:55.485462
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    assert SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2020)) == SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2020))
    assert SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2020)) != SomeMoney(Ccy.EUR, Decimal(0.8), Date(1, 1, 2020))
    assert SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2020)) != SomeMoney(Ccy.USD, Decimal(0.8), Date(1, 1, 2020))
    assert SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2020)) != SomeMoney(Ccy.USD, Decimal(1), Date(1, 1, 2019))
    
    

# Generated at 2022-06-24 01:26:04.663963
# Unit test for method positive of class Price
def test_Price_positive():
    price1 = Price.of(ccy="CAD", qty=12, dov=date(2020, 10, 15))
    price2 = Price.of(ccy="CAD", qty=-12, dov=date(2020, 10, 15))
    expected = Price.of(ccy="CAD", qty=12, dov=date(2020, 10, 15))
    assert price1.positive() == expected
    assert price2.positive() == expected


# Generated at 2022-06-24 01:26:11.414091
# Unit test for method multiply of class Price
def test_Price_multiply():
    p = Price(USD, "1")
    p1 = p.multiply(2)
    assert p1.qty == Decimal("2")
    assert p1.ccy == USD
    p2 = p * 2
    assert p2.qty == Decimal("2")
    assert p2.ccy == USD

    p3 = p * 2.0
    p4 = p * 2.0
    assert p3.qty == Decimal("2.0")
    assert p3.ccy == USD
    assert p3.qty == Decimal("2.0")
    assert p3.ccy == USD


# Generated at 2022-06-24 01:26:24.254417
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    base_currency = Currency("EUR")
    other_currency = Currency("USD")
    defined_price = Price.of(base_currency, Decimal("100.00"), TODAY)
    other_price = Price.of(base_currency, Decimal("100.00"), TODAY)

    # Valid cases
    assert defined_price.with_ccy(base_currency) == defined_price.with_ccy(other_currency)

    # Invalid cases
    with pytest.raises(TypeError):
        undefined_price = NoPrice.with_ccy(base_currency)
    with pytest.raises(TypeError):
        undefined_price.with_ccy(base_currency) == other_price.with_ccy(other_currency)

# Generated at 2022-06-24 01:26:33.699026
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    from datetime import date

    from finstmt.common.models.base import Currency, Date

    from finstmt.common.models.prices import SomePrice

    dov = Date.of(2012, 1, 1)
    ccy = Currency.of("USD")

    price1 = SomePrice.of(ccy, Decimal(1), dov)

    assert price1.dov == dov
    assert price1.with_dov(dov) is price1
    assert price1.with_dov(Date.of(2019, 1, 1)).dov == Date.of(2019, 1, 1)


# Generated at 2022-06-24 01:26:38.925414
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    from pyrates.util.data_types import Money
    import pytest
    m1 = Money.of(None, None, None)
    m2 = Money.of(None, None, None)
    with pytest.raises(TypeError):
        m1.scalar_subtract(m2)



# Generated at 2022-06-24 01:26:48.966967
# Unit test for method gte of class Money
def test_Money_gte():
    # Setup
    m1 = SomeMoney(Currency.USD, Decimal('100'), Date.na())
    m2 = SomeMoney(Currency.USD, Decimal('100'), Date.na())
    m3 = SomeMoney(Currency.USD, Decimal('200'), Date.na())
    m4 = SomeMoney(Currency.TRY, Decimal('200'), Date.na())
    m5 = SomeMoney(Currency.USD, Decimal('0'), Date.na())
    m6 = NoMoney

    # Exercise
    r1 = m1.gte(m2)
    r2 = m1.gte(m3)
    r3 = m1.gte(m4)
    r4 = m1.gte(m5)
    r5 = m1.gte(m6)

    # Verify


# Generated at 2022-06-24 01:26:57.393847
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    ## Default constructor
    assert SomeMoney(USD, decimal.Decimal(4), datetime.date(2019, 1, 2)).qty == decimal.Decimal(4)
    assert SomeMoney(USD, decimal.Decimal(4), datetime.date(2019, 1, 2)).ccy == USD
    assert SomeMoney(USD, decimal.Decimal(4), datetime.date(2019, 1, 2)).dov == datetime.date(2019, 1, 2)
    assert SomeMoney(USD, decimal.Decimal(4), datetime.date(2019, 1, 2)).defined == True
    assert SomeMoney(USD, decimal.Decimal(4), datetime.date(2019, 1, 2)).undefined == False

# Generated at 2022-06-24 01:27:00.711220
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    assert SomeMoney(USD, 2, None) <= SomeMoney(USD, 3, None)
    assert not SomeMoney(USD, 3, None) <= SomeMoney(USD, 2, None)


# Generated at 2022-06-24 01:27:10.231671
# Unit test for method __le__ of class Money
def test_Money___le__():
    ## Given
    m1 = Money.of(ccy="CHF", qty=10.00, dov=Date.today())
    m2 = Money.of(ccy="EUR", qty=10.00, dov=Date.today())

    ## When and Then
    assert not m1.__le__(NoMoney)  # NoMoney is always less than defined money
    assert m1.__le__(m1)  # Money is always less than or equal to itself
    assert m1.__le__(m2)  # Money is always less than or equal to Money of different currency



# Generated at 2022-06-24 01:27:12.333518
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(Currency.USD, 1, Date.today())
test_SomePrice___bool__()


# Generated at 2022-06-24 01:27:15.413711
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    assert_raises_regex(TypeError, "^Undefined monetary values do not have quantity information.$", float, NoMoney)

# Generated at 2022-06-24 01:27:18.943941
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    return SomeMoney(
        None,
        None,
        None
    )

# Generated at 2022-06-24 01:27:29.305620
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    from finance.money import SomeMoney
    from finance.rates import SomeFXRate
    from finance.currencies import USD, EUR
    from finance.rates import FXRateService, MemoryFXRateService

    ## Define data:
    eur = EUR()
    usd = USD()
    date = date(2017, 1, 1)
    rate = SomeFXRate(eur, usd, Decimal("1.2"), date)

    ## Define service:
    service = MemoryFXRateService(rate)

    ## Setup service:
    FXRateService.default = service
    assert FXRateService.default is service

    ## Define two monies:
    m1 = SomeMoney(eur, Decimal("100"), date)
    m2 = SomeMoney(usd, Decimal("120"), date)

    ## Convert from Euro to USD:
    m3

# Generated at 2022-06-24 01:27:31.685406
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    assert Money.of("EUR", 10, "2017-03-03") // 1.123 == Money.of("EUR", 8.9, "2017-03-03")



# Generated at 2022-06-24 01:27:39.193316
# Unit test for method __mul__ of class Price
def test_Price___mul__():

    # Creating first price
    ccy1 = Currency.of("USD")
    qty1 = Decimal(5)
    dov1 = Date(2018, 7, 12)
    price1 = Price.of(ccy1, qty1, dov1)

    # Creating second price
    ccy2 = Currency.of("USD")
    qty2 = Decimal(0.5)
    dov2 = Date(2018, 7, 12)
    price2 = Price.of(ccy2, qty2, dov2)

    # Testing method
    price3 = Price.of(ccy1, Decimal(5) * Decimal(0.5), dov1)
    assert price1 * price2 == price3



# Generated at 2022-06-24 01:27:45.788987
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    p1 = Price.of(GBP, 10, today())
    p2 = Price.of(GBP, 10, None)
    p3 = Price.of(GBP, None, today())
    p4 = Price.of(GBP, None, None)
    p1_res = p1.with_dov(tomorrow())
    p2_res = p2.with_dov(tomorrow())
    p3_res = p3.with_dov(tomorrow())
    p4_res = p4.with_dov(tomorrow())
    assert p1_res == Price.of(GBP, 10, tomorrow())
    assert p2_res == p2
    assert p3_res == p3
    assert p4_res == p4



# Generated at 2022-06-24 01:27:51.232446
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    """
    :type self: TestCase | None
    """
    # Setup
    ccy = EUR
    qty = 10.0
    dov = Date(2018, 10, 1)
    p = SomePrice(ccy, qty, dov)
    # Exercise
    p_ = p.with_dov(Date(2019, 1, 1))
    # Verify
    assert p_.ccy == ccy
    assert p_.qty == qty
    assert p_.dov == Date(2019, 1, 1)

# Generated at 2022-06-24 01:28:04.400515
# Unit test for method __le__ of class Price
def test_Price___le__():
    _19_13 = Price.of(Currency.USD, 19.13, date(2020, 1, 1))
    _19_23 = Price.of(Currency.USD, 19.23, date(2020, 2, 1))
    assert not _19_13.__le__(_19_23)
    assert not _19_13.__le__(_19_13.with_qty(20))
    assert not _19_13.__le__(_19_13.with_qty(18))
    assert not _19_13.__le__(_19_13.with_dov(date(2019, 12, 31)))
    assert _19_13.__le__(_19_13.with_dov(date(2020, 1, 1)))

# Generated at 2022-06-24 01:28:09.914131
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert Money.of((Currency.of("USD")), Decimal("1.0"), (Date.of("2019-05-01"))) > Money.of((Currency.of("USD")), Decimal("0.9"), (Date.of("2019-05-01")))

# Generated at 2022-06-24 01:28:19.162119
# Unit test for method __le__ of class Price
def test_Price___le__():
    from datetime import date
    from mcs_benchmark_data.path import TEST_DATA_DIR_PATH
    from mcs_benchmark_data.resources.fixtures.benchmark.currencies import USD
    from mcs_benchmark_data.resources.fixtures.benchmark.sources import FX_RATE_SOURCE_ID
    #
    import mcs_benchmark_data.utils.math.calculus as math_calculus
    #
    math_calculus.USE_CALCULUS = False
    math_calculus.USE_SYM = False
    #
    from mcs_benchmark_data.utils.math.money import Money
    from mcs_benchmark_data.utils.math.price import Price
    #

# Generated at 2022-06-24 01:28:20.341887
# Unit test for method positive of class Money
def test_Money_positive():
    assert Money.of("USD", 100.00, Date.today()).positive() == SomeMoney("USD", 100.00, Date.today())

# Generated at 2022-06-24 01:28:29.400465
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    c1 = Currency("USD", "United States Dollars", 2)
    c2 = Currency("EUR", "Euros", 2)
    c3 = Currency("XBT", "Bitcoin", 8)
    d1 = UTC()
    d2 = UTC()
    p1 = SomePrice(c1, 10, d1)  # 10 USD
    p2 = SomePrice(c1, 20, d2)  # 20 USD
    p3 = SomePrice(c1, 00, d2)  #  0 USD
    p4 = SomePrice(c1, -5, d1)  # -5 USD
    p5 = SomePrice(c2, 10, d2)  # 10 EUR
    p6 = SomePrice(c2, -5, d1)  # -5 EUR