

# Generated at 2022-06-24 01:18:30.504857
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    print("Testing method... [times]")
    assert SomePrice("EUR", 1, None).times(2) == SomeMoney("EUR", Decimal(2), None)
    assert SomePrice("EUR", Decimal("1.1"), None).times(2) == SomeMoney("EUR", Decimal("2.2"), None)
    assert SomePrice("USD", 1, None).times(2) == SomeMoney("USD", Decimal(2), None)
    print("Passed!")


# Generated at 2022-06-24 01:18:33.366507
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.of(CAD, Decimal("-1.0"), LocalDate.now()).__abs__() == Price.of(CAD, Decimal("1.0"), LocalDate.now())

# Generated at 2022-06-24 01:18:34.033410
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    pass

# Generated at 2022-06-24 01:18:46.783728
# Unit test for method __floordiv__ of class Price

# Generated at 2022-06-24 01:18:58.779686
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    x = Price.of(Currency.USD, Decimal(100), Date(2006, 12, 25))
    y = Price.of(Currency.USD, Decimal(10), Date(2007, 12, 25))
    z = Price.of(Currency.USD, Decimal(5), Date(2008, 12, 25))
    assert x.with_dov(Date(2007, 12, 25)) == Price.of(Currency.USD, Decimal(100), Date(2007, 12, 25))
    assert x.with_dov(Date(2008, 12, 25)) == Price.of(Currency.USD, Decimal(100), Date(2008, 12, 25))

# Generated at 2022-06-24 01:19:11.558380
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    """
    Test method with_qty of class SomePrice
    """
    # Setup
    ccy = Currency.of("ABC")
    qty = Decimal(10)
    dov = Date(2019, 9, 1)
    price = SomePrice(ccy, qty, dov)

    # Execute the method with the following parameters
    new_qty = Decimal(20)
    result = price.with_qty(new_qty)

    # Assert if the result is True
    assert result.qty == new_qty

    # Execute the method with the following parameters
    new_qty = Decimal(30)
    result = price.with_qty(new_qty)

    # Assert if the result is True
    assert result.qty == new_qty

# Generated at 2022-06-24 01:19:17.299820
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    ccy1 = Currency("USD")
    ccy2 = Currency("BGN")
    exc = IncompatibleCurrencyError(ccy1, ccy2, "A")
    assert exc.ccy1 == ccy1 and exc.ccy2 == ccy2 and exc.operation == "A"
    assert str(exc) == "USD vs BGN are incompatible for operation 'A'."



# Generated at 2022-06-24 01:19:18.963503
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    t = NoMoney
    assert not t.defined
    assert t.undefined
    assert not t


# Generated at 2022-06-24 01:19:21.864821
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    qtyA = Decimal("0.5")
    priceA = Price.of("USD", qtyA, Date.today("UTC"))
    assert (priceA.with_qty(Decimal("0.75")) == Price.of("USD", Decimal("0.75"), Date.today("UTC")))

# Generated at 2022-06-24 01:19:26.282248
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import Currency, EUR
    from .money import Money, NoMoney, SomeMoney
    from .value import Date

    m1 = NoMoney
    m2 = SomeMoney(EUR, 100, Date("2020-01-01"))

    assert isinstance(m1, Money)
    assert isinstance(m2, Money)

    assert m1.with_ccy(EUR) == NoMoney
    assert m2.with_ccy(EUR) == m2
    assert m2.with_ccy(Currency("GBP")) == SomeMoney(Currency("GBP"), 100, Date("2020-01-01"))



# Generated at 2022-06-24 01:19:36.175822
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    class TestMoney(Money):
        __slots__=('ccy','qty','dov')
        def __init__(self, ccy: Currency, qty: Decimal, dov: Date) -> None:
            self.ccy = ccy
            self.qty = qty
            self.dov = dov
        def is_equal(self, other: Any) -> bool:
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov
        def as_boolean(self) -> bool:
            return self.qty != 0
        def as_float(self) -> float:
            return float(self.qty)
        def as_integer(self) -> int:
            return int(self.qty)

# Generated at 2022-06-24 01:19:37.425977
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    assert NoneMoney.__truediv__(1) == NoneMoney

# Generated at 2022-06-24 01:19:43.321181
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    # Undefined price objects are returned as is
    assert NoPrice / 10 == NoPrice
    assert NoPrice / NoPrice == NoPrice

    # Valid quotients
    assert Price.of(Currency.USD, 6, Date.from_str("2020-01-01")) / 2 == Price.of(Currency.USD, 3, Date.from_str("2020-01-01"))



# Generated at 2022-06-24 01:19:50.374879
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    import pytest
    from math import isnan
    from pmx import LocalDate, USD

    sm = SomeMoney(USD, 1, LocalDate.from_string('2017-05-09'))
    assert sm.__neg__().qty == -1

    sm = SomeMoney(USD, 10.123, LocalDate.from_string('2017-05-09'))
    assert sm.__neg__().qty == -10.123


# Generated at 2022-06-24 01:19:52.994091
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    ## Initialize the service:
    service = FXRateService.default = MemoryFXRateService()

    ## test for rounding NonePrice
    x = NoPrice
    assert x.round(0) == NoPrice
    assert x.round(None) == NoPrice
    assert x.round(6) == NoPrice



# Generated at 2022-06-24 01:20:02.239423
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    from pfrock.currency import Currency
    from pfrock.money import Money
    from pfrock.price import Price

    ## Prepare Currency and Money objects:
    ccy = Currency.of("CNY")
    money = Money.of(ccy, "1.234567890", "2020-05-01")

    ## Test:
    assert money * 100 == Money.of(ccy, "123.4567890000", "2020-05-01")
    assert money * "2.345678901" == Money.of(ccy, "2.917370089", "2020-05-01")
    assert money * ccy.of("2.345678901") == Money.of(ccy, "2.917370089", "2020-05-01")

# Generated at 2022-06-24 01:20:03.844896
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    assert (NoMoney.convert(None, None, None)) == NoMoney
    assert (NoMoney.convert(None, None, None, None)) == NoMoney

# Generated at 2022-06-24 01:20:11.372562
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from money import Money, NoMoney, SomeMoney

    assert Money.of("USD", 100, "2020-06-01") == SomeMoney("USD", 100, "2020-06-01")
    assert Money.of("USD", 100, "2020-06-01").with_ccy("GBP") == SomeMoney("GBP", 100, "2020-06-01")
    assert Money.of("USD", 100, "2020-06-01").with_ccy("GBP").with_ccy("USD") == SomeMoney("USD", 100, "2020-06-01")
    assert NoMoney.with_ccy("GBP") is NoMoney
    assert SomeMoney("USD", 100, "2020-06-01").with_ccy("GBP").with_ccy("USD") == SomeMoney("USD", 100, "2020-06-01")


# Generated at 2022-06-24 01:20:21.951350
# Unit test for method __le__ of class Price
def test_Price___le__():
    assert NoPrice <= NoPrice
    assert SomePrice(USD, 1, today) <= SomePrice(USD, 1, today)
    assert not SomePrice(USD, 1, today) <= SomePrice(USD, 10, today)
    assert not SomePrice(USD, 1, today) <= SomePrice(USD, 1, tomorrow)
    assert not SomePrice(USD, 1, today) <= SomePrice(GBP, 1, today)
    assert not SomePrice(USD, 1, tomorrow) <= SomePrice(USD, 1, today)
    assert not SomePrice(GBP, 1, tomorrow) <= SomePrice(USD, 1, today)
    assert SomePrice(USD, 10, today) <= SomePrice(USD, 20, today)
    assert SomePrice(USD, 1, tomorrow) <= SomePrice(USD, 1, later)

# Generated at 2022-06-24 01:20:25.944382
# Unit test for method __le__ of class NoneMoney
def test_NoneMoney___le__():
    """
    Test method __le__ of class NoneMoney
    """
    na = NoMoney
    assert na <= NoMoney
    assert na <= SomeMoney(Currency("USD"), Decimal("1.000"), Date(2013, 1, 1))



# Generated at 2022-06-24 01:20:30.782275
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from .currencies import USD

    assert Money.of(USD, Decimal("1.23456"), Date.today()).as_integer() == 1
    assert Money.of(USD, Decimal("1.23456"), Date.today()).as_integer(UP) == 2
    assert Money.of(USD, Decimal("1.23456"), Date.today()).as_integer(DOWN) == 1

# Generated at 2022-06-24 01:20:41.872723
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert Money.of(ccy=None, qty=None, dov=None) > Money.of(ccy=None, qty=None, dov=None) is False
    assert Money.of(ccy=None, qty=None, dov=None) > Money.of(ccy=None, qty=None, dov=Date(2018, 12, 31)) is False
    assert Money.of(ccy=None, qty=None, dov=None) > Money.of(ccy=Currency('FOO'), qty=None, dov=None) is False
    assert Money.of(ccy=None, qty=None, dov=None) > Money.of(ccy=Currency('FOO'), qty=None, dov=Date(2018, 12, 31)) is False
    assert Money

# Generated at 2022-06-24 01:20:44.955592
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert NoMoney.__ge__(NoMoney)
    assert NoMoney.__ge__(SomeMoney(CAD, Decimal("5"), Date(2020, 1, 1)))
    assert not NoMoney.__ge__(SomeMoney(USD, Decimal("5"), Date(2020, 1, 1)))


# Generated at 2022-06-24 01:20:49.884349
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    p1 = SomePrice("USD", 2, Date(2020, 1, 1))
    p2 = SomePrice("JPY", 1, Date(2020, 1, 1))

    assert p1.__floordiv__(p2) == NoPrice
    assert p1.__floordiv__(2) == SomePrice("USD", 1, Date(2020, 1, 1))
    assert p1.__floordiv__(1) == SomePrice("USD", 2, Date(2020, 1, 1))
    assert p1.__floordiv__(0) == NoPrice

# Generated at 2022-06-24 01:20:54.788744
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    some_price = SomePrice(Currency('EUR'), Decimal('3.14159265359'), Date('2020-08-13'))
    actual = some_price.__float__()
    assert actual == 3.14159265359

# Generated at 2022-06-24 01:20:59.404390
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    try:
        raise MonetaryOperationException("Monetary operation exception")
    except MonetaryOperationException as e:
        assert (e.args[0] == "Monetary operation exception")



# Generated at 2022-06-24 01:21:01.621720
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    # xxx:
    with expected(TypeError):
        SomePrice(USD, 10, None).with_dov(None)

# Generated at 2022-06-24 01:21:11.068161
# Unit test for method positive of class Money
def test_Money_positive():
    assert Money.of(None, None, None).positive() is NoMoney
    assert Money.of(Currency('USD'), None, None).positive() is NoMoney
    assert Money.of(Currency('USD'), Decimal(1), None).positive() == Money.of(Currency('USD'), Decimal(1), None)
    assert Money.of(Currency('USD'), Decimal(1), Date(2020, 1, 1)).positive() == Money.of(Currency('USD'), Decimal(1), Date(2020, 1, 1))
    assert Money.of(Currency('USD'), Decimal(-1), None).positive() == Money.of(Currency('USD'), Decimal(-1), None)

# Generated at 2022-06-24 01:21:13.321316
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    # Setup
    p = Price.of(Currency.USD, 10, Date.today())
    other = Numeric
    expected = Price

    # Exercise
    actual = p.__floordiv__(other)

    # Verify
    assert actual == expected


# Generated at 2022-06-24 01:21:15.573047
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    c = Currency("EUR")
    q = Decimal(1000)
    d = Date.parse("2019-01-31")
    pric = SomePrice(c, q, d)
    pric.__truediv__(Decimal(100))

# Generated at 2022-06-24 01:21:20.995841
# Unit test for method __floordiv__ of class NonePrice
def test_NonePrice___floordiv__():

    assert NonePrice / Decimal(0) == NonePrice

## Unit test for method __ge__ of class NonePrice

# Generated at 2022-06-24 01:21:26.784432
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    price = Price.of(ccy='USD', qty=Decimal('5'), dov=Date.today())
    print(price.with_qty(Decimal('4.011')))


# Generated at 2022-06-24 01:21:30.502967
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
        assert (SomeMoney(USDCurrency, Decimal(100), date(2019,11,18))+100)==SomeMoney(USDCurrency, Decimal(200), date(2019,11,18))
        pass
    # Unit test for method scalar_subtract of class SomeMoney

# Generated at 2022-06-24 01:21:31.241427
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    assert not NoneMoney()


# Generated at 2022-06-24 01:21:37.379261
# Unit test for constructor of class Price
def test_Price():
    def test_Price():
        assert Price.of(USD, 100, TODAY)
        assert Price.of(USD, 100, TODAY).as_float() == 100
        assert Price.of(USD, 100, TODAY).with_ccy(EUR)
        assert Price.of(USD, 100, TODAY).with_qty(50)
        assert Price.of(USD, 100, TODAY).with_dov(TODAY.add(days=5))
        assert Price.of(USD, 100, TODAY).as_boolean() == True
        assert Price.of(USD, 0, TODAY).as_boolean() == False
        assert Price.of(USD, 100, TODAY).abs()
        assert Price.of(USD, 100, TODAY).negative()
        assert Price.of(USD, 100, TODAY).negative().negative()

# Generated at 2022-06-24 01:21:46.409537
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    ccy = Currency("USD")
    money = SomeMoney(ccy, Decimal("1.01"), Date.today())
    m = money / 1
    assert m.ccy == ccy  # type: ignore
    assert m.qty == Decimal("1.01")  # type: ignore
    assert m.dov == Date.today()  # type: ignore
    assert m == money  # type: ignore
    m = money / None
    assert m.ccy == ccy  # type: ignore
    assert m.qty == Decimal("1.01")  # type: ignore
    assert m.dov == Date.today()  # type: ignore
    assert m == money  # type: ignore
    m = money / True
    assert m.ccy == ccy  # type: ignore

# Generated at 2022-06-24 01:21:57.994266
# Unit test for method subtract of class Price
def test_Price_subtract():
    from datetime import date
    from money_class import Money
    from money_class import Price
    from money_class import NoCurrency
    from money_class import NoMoney
    from money_class import IncompatibleCurrencyError
    from money_class import MonetaryOperationException

    assert (Money.of(None, 0) -  Money.of(None, 0)).defined == False
    assert (Money.of(None, 0) -  Money.of('USD', 0)).defined == False
    assert (Money.of(None, 0) -  Money.of('USD', 10)).defined == False
    assert (Money.of('USD', 0) -  Money.of(None, 0)).defined == True
    assert (Money.of('USD', 0) -  Money.of('USD', 0)).defined == True

# Generated at 2022-06-24 01:22:06.599405
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    price = Price.of(Currency.of("USD"), Decimal("100"), Date.today())
    assert price.scalar_subtract(Decimal("20")) == Price.of(Currency.of("USD"), Decimal("80"), Date.today())
    assert price.scalar_subtract(20) == Price.of(Currency.of("USD"), Decimal("80"), Date.today())
    assert price.scalar_subtract(20.11) == Price.of(Currency.of("USD"), Decimal("79.89"), Date.today())
    assert price.scalar_subtract(-20) == Price.of(Currency.of("USD"), Decimal("120"), Date.today())

# Generated at 2022-06-24 01:22:14.893932
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    """
    Unit test checking that __eq__ method of class SomePrice compares Prices by all attributes, including of its superclass
    """
    price1 = SomePrice(BND, 1, Date.fromdate(date(2019, 1, 1)))
    price2 = SomePrice(BND, 1, Date.fromdate(date(2019, 1, 1)))
    assert price1.__eq__(price2) == price1.__class__.__eq__(price1, price2)


# Generated at 2022-06-24 01:22:22.255828
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    assert SomeMoney(USD, Decimal("1"), dov) * Decimal("1") == SomeMoney(USD, Decimal("1"), dov)
    assert SomeMoney(USD, Decimal("1"), dov) * Decimal("2") == SomeMoney(USD, Decimal("2"), dov)
    assert SomeMoney(USD, Decimal("1"), dov) * Decimal("1.1") == SomeMoney(USD, Decimal("1.1"), dov)
    assert SomeMoney(USD, Decimal("1"), dov) * Decimal("1.1") == SomeMoney(USD, Decimal("1.1"), dov)
    assert SomeMoney(USD, Decimal("1"), dov) * Decimal("1.2") == SomeMoney(USD, Decimal("1.2"), dov)

# Generated at 2022-06-24 01:22:27.563317
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    assert Price.of(Currency.USD, Decimal("1.00"), Date.today()).__pos__() == Price.of(Currency.USD, Decimal("1.00"), Date.today())
    assert Price.of(Currency.USD, Decimal("1.00"), Date.today()).__pos__() >= Price.of(Currency.USD, Decimal("1.00"), Date.today())
    assert Price.of(Currency.USD, Decimal("1.00"), Date.today()).__pos__() <= Price.of(Currency.USD, Decimal("1.00"), Date.today())
    assert Price.of(Currency.USD, Decimal("1.00"), Date.today()).__pos__() != Price.of(Currency.USD, Decimal("1.01"), Date.today())
    assert Price

# Generated at 2022-06-24 01:22:29.252118
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    assert int(SomePrice(USD, 1, date.today())) == 1

# Generated at 2022-06-24 01:22:31.389197
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
        assert not NonePrice()
        assert not NonePrice.__bool__(NonePrice())
    ### Unit tests for method __eq__ of class NonePrice

# Generated at 2022-06-24 01:22:43.005506
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    from datetime import datetime
    from gordo_dataset.sensor_tag import SensorTag
    from gordo_dataset.sensor_tag import SensorTag
    from gordo_dataset.sensor_tag import SensorTag
    from gordo_dataset.sensor_tag import SensorTag

    sensor_tag = SensorTag(
        name="GTGTGTGTG",
        asset_id=1,
        asset_name="turbines",
        kind="turbine",
        type="turbine",
        metadata={"a": "b"},
    )
    m = sensor_tag.from_value(Currency.DKK, Decimal(10.00), datetime(2020, 1, 1, 0, 0))

# Generated at 2022-06-24 01:22:49.025147
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    to_test = NonePrice()
    result = to_test.__lt__(NonePrice())
    assert result == False
    result = to_test.__lt__(SomePrice(CAD, Decimal('1.23'), Date('2019-12-31')))
    assert result == False

# Generated at 2022-06-24 01:22:59.792065
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    x: Price = SomePrice(Currency.USD, Decimal('1.2000'), Date(2020, 11, 4))
    y: Price = SomePrice(Currency.USD, Decimal('1.0000'), Date(2020, 11, 1))
    z: Price = x.scalar_add(1)
    assert z == SomePrice(Currency.USD, Decimal('2.2000'), Date(2020, 11, 4))
    #
    y2: Price = y.scalar_add(1)
    assert y2 == SomePrice(Currency.USD, Decimal('2.0000'), Date(2020, 11, 1))
    #
    assert x.scalar_add(0) == x
    assert y.scalar_add(0) == y


# Generated at 2022-06-24 01:23:04.181984
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    ## Assert that the method `__neg__` of class `NoneMoney` returns a value of type `Money`.
    assert isinstance(-NoMoney, Money)

    ## Assert that the method `__neg__` of class `NoneMoney` raises a `NotImplementedError`.
    with raises(NotImplementedError) as exc:
        -NoMoney


# Generated at 2022-06-24 01:23:14.866642
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(CCY, Decimal("0.0"), DATE).gte(Price.of(CCY, Decimal("0.0"), DATE))
    assert Price.of(CCY, Decimal("0.0"), DATE).gte(Price.of(CCY, Decimal("0.0"), DATE))
    assert Price.of(CCY, Decimal("10.0"), DATE).gte(Price.of(CCY, Decimal("0.0"), DATE))
    assert Price.of(CCY, Decimal("0.0"), DATE).gte(Price.of(CCY, Decimal("10.0"), DATE))

# Generated at 2022-06-24 01:23:25.544211
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    assert abs(NoMoney) == NoMoney
    assert abs(NoMoney) == None
    assert abs(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == "100.00 USD"
    assert abs(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == "100.00 USD"
    assert abs(SomeMoney(Currency("USD"), Decimal("-100.00"), Date(2018, 1, 1))) == "100.00 USD"
    assert abs(SomeMoney(Currency("USD"), Decimal("-100.00"), Date(2018, 1, 1))) == "100.00 USD"



# Generated at 2022-06-24 01:23:37.559110
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    from decimal import Decimal
    from datetime import date
    from pymonies.quantities import Quantity, Unit
    from pymonies.currencies import Currency, CurrencyService, CurrencyNotFoundError
    from pymonies.money import SomeMoney
    Quantity(Unit.STANDARD, Decimal(1), 1, SomeMoney(CurrencyService.default.get_by_mnemonic('USD'), Decimal(1), date(2019, 1, 1)))
    Money = SomeMoney
    Monetary = Quantity
    Money(CurrencyService.default.get_by_mnemonic('USD'), Decimal(1), date(2019, 1, 1))
    val = CurrencyService.default.get_by_mnemonic('USD')

# Generated at 2022-06-24 01:23:43.911001
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    c = Currency("AED")
    dov = Date.today()
    price = SomePrice(c, Decimal("1.12345"), dov)
    assert SomePrice(c, Decimal("2.2"), dov) == (price // Decimal("0.5"))

# Generated at 2022-06-24 01:23:47.353574
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    pass



# Generated at 2022-06-24 01:23:49.806986
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    pass  # TODO: Implement unit test for test_SomeMoney___pos__



# Generated at 2022-06-24 01:24:01.862762
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    from decimal import Decimal
    from numbers import Number
    from datetime import date
    from .currency import Currency
    from .date import Date
    from .price import SomePrice
    from .price import NoPrice

    q = Decimal('2030.2')
    dov = Date(date(1992, 1, 1))
    p1 = SomePrice(Currency('HKD'), q, dov)
    assert p1.__pos__() is p1

    p2 = NoPrice
    assert p2.__pos__() is p2

    q = Decimal('-2030.2')
    p3 = SomePrice(Currency('HKD'), q, dov)
    p4 = p3.__pos__()
    assert isinstance(p4, SomePrice)

# Generated at 2022-06-24 01:24:02.464487
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
  pass

# Generated at 2022-06-24 01:24:03.062381
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    pass

# Generated at 2022-06-24 01:24:10.926390
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    """Unit test for method __add__ of class SomePrice"""
    import sys
    import pytest
    from decimal import Decimal, InvalidOperation, DivisionByZero
    from yui.types import Price, Money
    from yui.types.currency import Currency
    from yui.utils import datetime
    from yui.types.exchange import FXRateService
    from yui.types.exchange import FXRateLookupError
    from yui.types.exchange import IncompatibleCurrencyError

    with pytest.raises(ProgrammingError):
        ccy1, ccy2, ccy3 = Currency.of('CNY'), Currency.of('USD'), Currency.of('EUR')
        p1 = Price.of(ccy1, Decimal('1.23'), datetime(2019, 1, 1))

# Generated at 2022-06-24 01:24:14.363663
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    from ccy import usd

    assert (
        Price.of(usd, Decimal("0.01"), Date.today(usd))
        .as_integer()
        == 1
    ), "Test failed for Price.as_integer()"



# Generated at 2022-06-24 01:24:22.031944
# Unit test for method positive of class Money
def test_Money_positive():
    assert Money.of(Currency("USD"), Decimal("10.00"), Date(2019, 11, 22)).positive() == SomeMoney(
        Currency("USD"), Decimal("10.00"), Date(2019, 11, 22)
    )
    assert Money.of(Currency("USD"), Decimal("-10.00"), Date(2019, 11, 22)).positive() == SomeMoney(
        Currency("USD"), Decimal("-10.00"), Date(2019, 11, 22)
    )
    assert Money.of(Currency("USD"), Decimal("0"), Date(2019, 11, 22)).positive() == SomeMoney(
        Currency("USD"), Decimal("0"), Date(2019, 11, 22)
    )
    assert Money.of(Currency("USD"), Decimal("10.00"), Date(2019, 11, 22)).positive() == Some

# Generated at 2022-06-24 01:24:24.980857
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of("usd", 1.1, dov=Date.today()).as_integer() == 1



# Generated at 2022-06-24 01:24:30.526223
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    money = Money.of('USD', Decimal("10.0"), Date(2018, 1, 1))
    assert money * Decimal("3.0") == SomeMoney(
        Currency('USD'), Decimal("30.0"), Date(2018, 1, 1)
    )


# Generated at 2022-06-24 01:24:43.699058
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(no_ccy, no_qty, no_dov).__bool__() is False
    assert SomePrice(no_ccy, no_qty, some_dov).__bool__() is False
    assert SomePrice(no_ccy, some_qty, no_dov).__bool__() is False
    assert SomePrice(no_ccy, some_qty, some_dov).__bool__() is False

    assert SomePrice(some_ccy, no_qty, no_dov).__bool__() is False
    assert SomePrice(some_ccy, no_qty, some_dov).__bool__() is False
    assert SomePrice(some_ccy, some_qty, no_dov).__bool__() is True

# Generated at 2022-06-24 01:24:46.400937
# Unit test for method lt of class Price
def test_Price_lt():
    price = Price('GBP', 2, '2018-10-31')
    assert_that(price.lt('GBP', 3, '2018-10-31'))



# Generated at 2022-06-24 01:24:48.678041
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert NoneMoney() < SomeMoney(USD, Decimal("1.1"), Date(2020, 1, 1))



# Generated at 2022-06-24 01:24:50.098248
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    assert not NoPrice

# Generated at 2022-06-24 01:24:51.405352
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    price = NonePrice
    assert price == NonePrice
    assert price != SomePrice(USD, 1, Date.today())


# Generated at 2022-06-24 01:24:57.056334
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    assert SomePrice(Currency.of('USD'), Decimal('1'), Date.of('2020-05-01')).with_dov(Date.of('2020-05-02')) == SomePrice(Currency.of('USD'), Decimal('1'), Date.of('2020-05-02'))
    assert SomePrice(Currency.of('USD'), Decimal('1'), Date.of('2020-05-01')).with_dov(Date.of('2020-05-01')) == SomePrice(Currency.of('USD'), Decimal('1'), Date.of('2020-05-01'))



# Generated at 2022-06-24 01:25:05.008359
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    #
    # `Money` instances with round-tripping values that are going to be used in tests.
    #
    m_1 = SomeMoney(Currency.BTC, Decimal(1), Date(2018, 9, 1))
    m_2 = SomeMoney(Currency.USD, Decimal(-1), Date(2018, 9, 1))
    m_3 = SomeMoney(Currency.USD, Decimal(0), Date(2018, 9, 1))
    m_4 = SomeMoney(Currency.USD, Decimal(0), Date(2018, 9, 1))
    #
    # Guarantee that `m_1` is non-zero and non-negative.
    #
    assert m_1 == m_1.abs()
    assert (m_1 * Decimal(2)) > m_1
    #
    # Guarantee

# Generated at 2022-06-24 01:25:15.842444
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    from pymonad import Just, Nothing
    assert SomePrice(ccy="USD", qty=1, dov="2010-01-01") >= SomePrice(ccy="USD", qty=1, dov="2010-01-01")
    assert SomePrice(ccy="USD", qty=1, dov="2010-01-01") >= Just(SomePrice(ccy="USD", qty=1, dov="2010-01-01"))
    assert SomePrice(ccy="USD", qty=1, dov="2010-01-01") >= Nothing()
    assert not (SomePrice(ccy="USD", qty=1, dov="2010-01-01") >= SomePrice(ccy="USD", qty=2, dov="2010-01-01"))

# Generated at 2022-06-24 01:25:22.852997
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    assert NonePrice() <= NonePrice()
    assert NonePrice() <= SomePrice(AED, Decimal('-1.00000'), Date(2016, 7, 1))
    try:
        NonePrice() <= SomePrice(EUR, Decimal('-1.00000'), Date(2016, 7, 1))
        assert False, "Did not see IncompatibleCurrencyError."
    except IncompatibleCurrencyError:
        pass
NoPrice = NonePrice()



# Generated at 2022-06-24 01:25:23.316538
# Unit test for method __le__ of class Price
def test_Price___le__():
    pass

# Generated at 2022-06-24 01:25:33.539062
# Unit test for method __sub__ of class Price
def test_Price___sub__():

    #
    def check(self, other, expected):
        actual = self.__sub__(other)

        assert type(actual) == type(expected)

        assert actual.ccy == expected.ccy
        assert actual.qty == expected.qty
        assert actual.dov == expected.dov

    #
    # Check with undefined price objects.
    #

    check(NoPrice, NoPrice, NoPrice)
    check(NoPrice, SomePrice(CAD(1), Decimal(100), today()), NoPrice)
    check(SomePrice(CAD(1), Decimal(100), today()), NoPrice, NoPrice)

    #
    # Check with defined price objects.
    #


# Generated at 2022-06-24 01:25:43.011340
# Unit test for method __round__ of class Money
def test_Money___round__():
    """
    Tests method __round__ of class Money
    """
    ## Test case 1
    ## Description: An undefined money object
    ## Expected: A NoMoney object
    oMoney = Money.of(None, None, None)
    oTest = oMoney.__round__()
    assert type(oTest) == NoMoney

    ## Test case 2
    ## Description: A value money object
    ## Expected: A NoMoney object
    oMoney = Money.of(Currency.of('EUR'), 1.235125529999999999, None)
    oTest = oMoney.__round__()
    assert type(oTest) == SomeMoney
    assert oTest.qty == 1.24

    ## Test case 3
    ## Description: A value money object with a specified number of decimal places
    ## Expected: A NoMoney object

# Generated at 2022-06-24 01:25:51.710018
# Unit test for constructor of class Price
def test_Price():
    from datetime import date
    from solar.market.currency import Currency
    some_price = Price.of(Currency.of(['USD']),Decimal(5.0),date(2019,5,5))
    assert some_price.ccy == Currency.of(['USD'])
    assert some_price.qty == Decimal(5.0)
    assert some_price.dov == date(2019,5,5)
    assert some_price == some_price



# Generated at 2022-06-24 01:25:58.160682
# Unit test for method negative of class Money
def test_Money_negative():
    """
    Unit test for method negative of class Money
    """
    from .currencies import Currency

    some_test_money = Money.of(Currency.of("EUR"), Decimal(2), Date.today())
    assert -some_test_money == Money.of(Currency.of("EUR"), Decimal(-2), Date.today())
    assert some_test_money.negative() == Money.of(Currency.of("EUR"), Decimal(-2), Date.today())



# Generated at 2022-06-24 01:26:09.567186
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    """
    Unittest for method __sub__ of class SomePrice
    """
    # Test for normal behaviour
    try:
        SomePrice("USD", Decimal("34.87"), date_parser("2018-12-01")) - SomePrice("USD", Decimal("34.87"), date_parser("2018-12-01"))
    except Exception:
        assert False # Test passed
    
    # Test for expected behaviour of exception IncompatibleCurrencyError
    try:
        SomePrice("USD", Decimal("34.87"), date_parser("2018-12-01")) - SomePrice("JPY", Decimal("34.87"), date_parser("2018-12-01"))
        assert False # Test failed
    except IncompatibleCurrencyError:
        pass # Test passed

    # Test for expected behaviour of exception IncompatibleCurrencyError

# Generated at 2022-06-24 01:26:14.608303
# Unit test for method __sub__ of class NonePrice
def test_NonePrice___sub__():
    ## Initialization:
    price = NonePrice
    SP = SomePrice
    ## Case: Test NonePrice - NonePrice
    assert (price - price) == Price(None, None, None)
    ## Case: Test NonePrice - SomePrice
    assert (price - SP("USD", 100, "2019-01-01")) == Price(None, None, None)
    ## Case: Test SomePrice - NonePrice
    assert (SP("USD", 100, "2019-01-01") - price) == Price("USD", 100, "2019-01-01")
    ## Case: Test SomePrice - SomePrice
    assert (SP("USD", 100, "2019-01-01") - SP("USD", 100, "2019-01-01")) == Price("USD", 0, "2019-01-01")


# Generated at 2022-06-24 01:26:20.780453
# Unit test for method __mul__ of class NoneMoney
def test_NoneMoney___mul__():
    """
    Unit test for method ``__mul__`` of class ``NoneMoney``.
    """
    base = Money.of(USD, 1, Date(2017, 1, 1))

    assert (base * 2) == base
    assert (-base * 2) == -base
    assert (base * 0) == NoMoney
    assert (-base * 0) == NoMoney



# Generated at 2022-06-24 01:26:33.104884
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():

    """
    Tests :meth:`~.Price.scalar_subtract`
    """

    # Case 1: Subtract 10 from a defined price object
    x = SomePrice(Currency.USD, 100, Date(2020, 1, 1))
    y = x.scalar_subtract(10)
    assert y.ccy == Currency.USD
    assert y.qty == 90
    assert y.dov == Date(2020, 1, 1)

    # Case 2: Subtract an undefined price
    z = x.scalar_subtract(NoPrice)
    assert z == NoPrice
    assert z.ccy == Currency.USD
    assert z.qty == Decimal(100)
    assert z.dov == Date(2020, 1, 1)

    # Case 3: Subtract

# Generated at 2022-06-24 01:26:35.402151
# Unit test for constructor of class NonePrice
def test_NonePrice():
    assert not NoPrice


# Generated at 2022-06-24 01:26:38.381912
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    money = Money()
    assert money.__class__ is NoMoney
    try:
        int(money)
    except TypeError:
        return
    assert False, "Expected TypeError not raised."



# Generated at 2022-06-24 01:26:40.588203
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    from money.classes import NoMoney

    money = NoMoney

    assert isinstance(money.__int__(), int)

# Generated at 2022-06-24 01:26:50.940994
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from financepy.finutils.FinFrequency import FinFrequencyTypes
    from financepy.finutils.FinGlobalVariables import gDaysInYear
    sel, buy = (Price.of(USD, 100), Price.of(GBP, 100))
    fxRate = FXRate(USD, GBP, 0.65, sel, buy)
    fxRateServiceUSDGBP = FXRateService(USD, GBP, fxRate)
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinHelperFunctions import strStripQuote
    valDate = FinDate(6, 11, 2017)
    rateUSDGBP = fxRateServiceUSDGBP.query(valDate)
    assert np.abs(rateUSDGBP.value - 0.65) < 1e-9

    # Test convert

# Generated at 2022-06-24 01:26:52.468513
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    # check NoneMoney.__init__()
    assert NoneMoney().__slots__ == ()



# Generated at 2022-06-24 01:27:03.750779
# Unit test for method __bool__ of class Price
def test_Price___bool__():

    # Test case 1
    p1 = Price.of(CCY("USD"), Decimal("1.0"), DOV("1999-01-01"))
    assert bool(p1) is True
    p1 = Price.of(CCY("USD"), Decimal("0.0"), DOV("1999-01-01"))
    assert bool(p1) is False
    p1 = Price.of(CCY("USD"), None, DOV("1999-01-01"))
    assert bool(p1) is False

    # Test case 2
    p1 = Price.of(CCY("USD"), None, DOV("1999-01-01"))
    p2 = Price.of(CCY("USD"), Decimal("1.0"), DOV("1999-01-01"))
    assert (p1 and p2) is Price.NA

# Generated at 2022-06-24 01:27:07.798853
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    with raises(NotImplementedError):
        SomePrice(Currency('EUR'), Decimal('2.0'), Date(2014, 1, 1)).__pos__()



# Generated at 2022-06-24 01:27:12.902475
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    nomoney = NoneMoney()
    assert nomoney.defined == False
    assert nomoney.undefined == True


NoMoney = NoneMoney()
##
# `Price` model.
#



# Generated at 2022-06-24 01:27:21.654922
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    from ..currency import Currency, USD
    from ..money import Money
    from ..fxrates import FXRate, FXRateService, FXRateLookupError
    from ..daterange import DateRange
    from ..finance import SomeFinance
    from datetime import date

    USD.quantizer = "0.01"

    ## Setup some fxrates:
    usd = Currency("USD")
    eur = Currency("EUR")
    fxrate = FXRate(Currency("USD"), Currency("EUR"), 0.8, DateRange(date(2020, 1, 1), date(2020, 12, 31)))
    fxrate_service = FXRateService()
    fxrate_service.add(fxrate)
    FXRateService.default = fxrate_service
    finance = SomeFinance(fxrate_service)

    ## Create some

# Generated at 2022-06-24 01:27:25.320094
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    a = Price.of(USD, Decimal("2"), Date.today())
    b = +a
    assert type(b) is Price
    assert b.qty == Decimal("2")
    assert a is b


# Generated at 2022-06-24 01:27:37.076552
# Unit test for method multiply of class Price
def test_Price_multiply():

    p1 = Price.of(USD, Decimal(1), date(2019, 8, 1))
    p2 = Price.of(USD, Decimal(1), date(2019, 8, 1))
    p3 = Price.of(GBP, Decimal(2), date(2019, 8, 1))
    p4 = Price.of(EUR, Decimal(3), date(2019, 8, 1))

    p5 = p1.multiply(1.234)
    assert p5.ccy == USD
    assert p5.qty == Decimal(1.234)
    assert p5.dov == date(2019, 8, 1)

    p5 = p1.multiply(Decimal(1.2345))
    assert p5.ccy == USD

# Generated at 2022-06-24 01:27:43.842807
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    m = SomeMoney(USD, 1, Date(2018, 1, 1))
    p = m / 1
    assert p.defined
    assert p.qty == Decimal('1')

# Generated at 2022-06-24 01:27:45.420704
# Unit test for constructor of class Price
def test_Price():
    # two ways to construct 
    assert Price.of(None, None, None) == NoPrice
    assert Price(None, None, None) == NoPrice


# Generated at 2022-06-24 01:27:51.268790
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    # Testing positive case
    m = Money.of(ccy="USD", qty=Decimal("100.0"), dov=Date(2020, 4, 1))
    assert m == SomeMoney(Currency("USD"), Decimal("100.0"), Date(2020, 4, 1))
    assert bool(m)
    # Testing negative case
    m = Money.of(ccy="USD", qty=Decimal("0"), dov=Date(2020, 4, 1))
    assert m == SomeMoney(Currency("USD"), Decimal("0"), Date(2020, 4, 1))
    assert not bool(m)

# Generated at 2022-06-24 01:28:04.400412
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    from money import NoneMoney, SomeMoney, NoMoney, Money

    assert NoneMoney().__int__() == 0

    assert SomeMoney(CAD, 1, Date.today()).__int__() == 1

    assert NoMoney.__int__() == 0

    assert Money.of(CAD, 1, Date.today()).__int__() == 1

    assert (Money.of(None, None, None) == NoMoney).is_true()
    assert (NoMoney == Money.of(None, None, None)).is_true()
    assert (Money.of(None, None, None) == Money.of(None, None, None)).is_true()  # type: ignore
    assert (Money.of(None, None, None) == Money.of(CAD, None, None)).is_false()

# Generated at 2022-06-24 01:28:12.889425
# Unit test for method gte of class Money
def test_Money_gte():
    # Test as per https://mail.python.org/pipermail/python-ideas/2014-March/028698.html 
    usd1 = Money.of(ccy=USD, qty=Decimal('1'), dov=today)
    usd2 = Money.of(ccy=USD, qty=Decimal('1'), dov=today)
    assert (usd1 >= usd2) is True
    assert (usd2 >= usd1) is True

# Generated at 2022-06-24 01:28:23.197675
# Unit test for method round of class Price
def test_Price_round():
    m = Price.of(USD, Decimal("123.456"), Date(2001, 1, 1))
    assert m.round() == m.round(0)
    assert m.round() == m.round(None)
    assert m.round(1) == Price.of(USD, Decimal("123.5"), Date(2001, 1, 1))
    assert m.round(2) == Price.of(USD, Decimal("123.46"), Date(2001, 1, 1))
    assert m.round(3) == Price.of(USD, Decimal("123.456"), Date(2001, 1, 1))
    assert m.round(4) == Price.of(USD, Decimal("123.456"), Date(2001, 1, 1))

# Generated at 2022-06-24 01:28:28.500948
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    expected = Money(Currency.of('USD'), Decimal('1.00'), Date('2020-01-01'))
    actual = Price.of(Currency.of('USD'), Decimal.one(), Date('2020-01-01')).__pos__()
    assert expected == actual