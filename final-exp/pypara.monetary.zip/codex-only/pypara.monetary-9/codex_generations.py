

# Generated at 2022-06-24 01:18:36.998100
# Unit test for method __sub__ of class Money

# Generated at 2022-06-24 01:18:49.857948
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    # Price : Price
    p1 = Price.of(Currency.USD, Decimal("100.00"), Date.today())
    p2 = Price.of(Currency.EUR, Decimal("100.00"), Date.today())
    p3 = Price.of(Currency.USD, Decimal("50.00"), Date.today())
    p4 = Price.of(Currency.USD, Decimal("50.00"), Date.today())
    p5 = Price.of(Currency.EUR, Decimal("50.00"), Date.today())
    p6 = Price.of(Currency.USD, Decimal("50.00"), Date.today())
    p7 = Price.of(Currency.USD, Decimal("50.00"), Date.today())

# Generated at 2022-06-24 01:18:54.869010
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    """
    Test method __truediv__(self, other: Numeric) -> Money
    """
    Money.__truediv__(SomeMoney(None, None, None), 0)



# Generated at 2022-06-24 01:19:00.470894
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    """
    Test for method __float__ of class SomePrice
    """
    #
    # Returns the base price's monetary value as a floating-point number.
    #
    # For example::
    #
    #   >>> USD(42.5).__float__()
    #   42.5
    #   >>> USD(42).__float__()
    #   42.0
    #
    pass # TODO


# Generated at 2022-06-24 01:19:03.442765
# Unit test for method positive of class Price
def test_Price_positive():
    b = Money.of(Currency.USD, Decimal(124.0))
    assert b.positive() == b
    # Unit test for method negative of class Money

# Generated at 2022-06-24 01:19:08.676326
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    """
    Test `SomeMoney.scalar_subtract` method.
    """
    from finstmt.financial import SomeMoney

    # Define a money object:
    m = SomeMoney(ccy="SEK", qty=2.50, dov="20180731")

    # Subtract:
    assert m.scalar_subtract(1.50) == SomeMoney(ccy="SEK", qty=1.00, dov="20180731")

    # Subtract:
    assert m.scalar_subtract(1) == SomeMoney(ccy="SEK", qty=1.50, dov="20180731")

    # Subtract:

# Generated at 2022-06-24 01:19:18.724685
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    ccy = Currency.USD
    date = date(2020, 1, 1)
    value = Decimal("1000000.00")
    othervalue = Decimal("50000.00")
    price = Price.of(ccy, value, date)

    result = price.floor_divide(value)
    assert isinstance(result, Price) is True
    assert result.ccy == ccy
    assert result.qty == Decimal("1")
    assert result.dov == date

    result = price.floor_divide(othervalue)
    assert isinstance(result, Price) is True
    assert result.ccy == ccy
    assert result.qty == Decimal("20")
    assert result.dov == date

    result = price.floor_divide(0.00)
    assert isinstance(result, Price)

# Generated at 2022-06-24 01:19:23.986775
# Unit test for method __eq__ of class Price
def test_Price___eq__():

    from .monetary import Decimal,Date,NoPrice,Price,SomePrice,Undefined

    # Test for undefined currency
    price1 = NoPrice
    price2 = NoPrice
    assert price1.is_equal(price2)

    price2 = SomePrice(Undefined, 0.0, Date.today())
    assert not price1.is_equal(price2)

    price2 = SomePrice(Undefined, 0.0, Date.today())
    assert price1.is_equal(price2)

    price2 = SomePrice(Undefined, 0.0, Date.today())
    assert price1.is_equal(price2)

    price1 = SomePrice(Undefined, 0.0, Date.today())
    price2 = NoPrice
    assert not price1.is_equal(price2)

    price1 = SomePrice

# Generated at 2022-06-24 01:19:30.719033
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    ccy1 = Currency(code='AUD', decimals=2)
    ccy2 = Currency(code='AUD', decimals=2)
    qty = Decimal('35.43')
    dov = Date(2018,3,3)
    money1 = SomeMoney(ccy1, qty, dov)
    assert money1.with_ccy(ccy2) == money1
test_SomeMoney_with_ccy()


# Generated at 2022-06-24 01:19:36.704594
# Unit test for method abs of class Money
def test_Money_abs():
    """
    Tests abs method of Money
    """
    ccy = Currency("TRY")
    money = Money.of(ccy, Decimal(100.0), Date.today())
    abs_money = money.abs()
    assert abs_money.qty == Decimal(100.0)
    assert abs_money.ccy == Currency("TRY")
    assert abs_money.dov == Date.today()
    assert abs_money.defined == True
    assert abs_money.undefined == False
    assert abs_money.__class__ == SomeMoney



# Generated at 2022-06-24 01:19:39.957279
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    p = Price.of(Currency.USD, Decimal("1.1"), Date.today())
    assert p.as_boolean() == True

    p = Price.of(Currency.USD, Decimal("0.0"), Date.today())
    assert p.as_boolean() == False

    p = NoPrice
    assert p.as_boolean() == False


# Generated at 2022-06-24 01:19:41.674411
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    t: NonePrice = NonePrice()
    assert t * (1.0) == NoPrice



# Generated at 2022-06-24 01:19:42.721699
# Unit test for method round of class Money
def test_Money_round():
    pass

# Generated at 2022-06-24 01:19:49.689956
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(Currency.USD, 10, DATE_20200101).gte(Price.of(Currency.USD, 10, DATE_20200101)) is True
    assert Price.of(Currency.USD, 10, DATE_20200101).gte(Price.of(Currency.USD, 30, DATE_20200101)) is False


# Generated at 2022-06-24 01:19:51.611574
# Unit test for method abs of class Price
def test_Price_abs():
    assert Price.of(USD, Decimal("-1.50"), Date.today()).abs() == Price.of(USD, Decimal("1.50"), Date.today())



# Generated at 2022-06-24 01:19:52.875203
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    model: Money = NoMoney
    assert model.__bool__() == False

# Generated at 2022-06-24 01:19:57.918668
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of(Currency.of('USD'), Decimal('1'), Date.of('2016-02-02')).divide(Decimal('1')) == Price.of(Currency.of('USD'), Decimal('1'), Date.of('2016-02-02'))
    assert Price.of(Currency.of('USD'), Decimal('1'), Date.of('2016-02-02')).divide(Decimal('1')).ccy == Currency.of('USD')
    assert Price.of(Currency.of('USD'), Decimal('1'), Date.of('2016-02-02')).divide(Decimal('1')).qty == Decimal('1')

# Generated at 2022-06-24 01:20:00.130329
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert Price(Currency.USD, Decimal("1"), Date.now()).__lt__(Price(Currency.USD, Decimal("2"), Date.now()))



# Generated at 2022-06-24 01:20:05.619369
# Unit test for method __float__ of class Money
def test_Money___float__():
    """
    Tests method __float__ of class Money
    """
    
    assert float(NoMoney) == 0.0
    assert float(NoMoney.USD) == 0.0
    assert float(SomeMoney(Currency("USD"), Decimal(1.5), Date.today())) == 1.5

    try:
        float(None)
    except MonetaryOperationException:
        pass
    else:
        assert False



# Generated at 2022-06-24 01:20:10.982015
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    assert SomeMoney(ccy = ccy, qty = qty, dov = dov) >= SomeMoney(ccy = ccy, qty = qty, dov = dov)

    pass


# Generated at 2022-06-24 01:20:21.230086
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    from winton_kafka_streams.util.money import NonePrice, SomePrice
    assert(NonePrice.with_qty(None) is NonePrice)
    assert(NonePrice.with_qty(1.1) is NonePrice)
    assert(NonePrice.with_qty(0.0) is NonePrice)
    assert(NonePrice.with_qty(-1.1) is NonePrice)
    assert(NonePrice.with_qty(1) is NonePrice)
    assert(NonePrice.with_qty(-1) is NonePrice)
    assert(SomePrice(None, 1.1, None).with_qty(None) is NonePrice)
    assert(SomePrice(None, 1.1, None).with_qty(1.1) is NonePrice)

# Generated at 2022-06-24 01:20:29.709495
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():  # pylint: disable=invalid-name
    ## Check all negative combinations:
    assert SomeMoney(C.USD, Decimal("-2"), Date(2018, 1, 1)) > SomeMoney(C.USD, Decimal("-3"), Date(2018, 1, 1))
    assert SomeMoney(C.USD, Decimal("-2"), Date(2018, 1, 1)) > SomeMoney(C.USD, Decimal("3"), Date(2018, 1, 1))
    assert SomeMoney(C.USD, Decimal("-2"), Date(2018, 1, 1)) > SomeMoney(C.USD, Decimal("3"), Date(2017, 1, 1))

# Generated at 2022-06-24 01:20:36.387011
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert not NonePrice() < SomePrice(USD, "100", dt.date.today())
    assert not NonePrice() < Money(USD, "100", dt.date.today())
    assert not NonePrice() < Price(USD, "100", dt.date.today())
    assert not NonePrice() < NonePrice()


# Generated at 2022-06-24 01:20:48.948686
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    from .currency import Currency
    from .fx_rate import FXRate
    from .fx_rate_service import FXRateService
    from .money import Money
    from .price import Price
    from .some_money import SomeMoney
    from .some_price import SomePrice
    from .some_rate import SomeRate
    from .time_bucket import TimeBucket

    from datetime import date

    from decimal import Decimal

    from hamcrest import *

    ##
    # Construct FXRateService:
    ##
    fx_service_under_test = FXRateService()

    ##
    # Set some test rates:
    ##

# Generated at 2022-06-24 01:20:53.046166
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    """
    Unit test for method scalar_add of class NonePrice

    """
    assert NonePrice.scalar_add(1) == NoPrice

# Generated at 2022-06-24 01:20:54.550189
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    assert (NoPrice + 1) == NoPrice



# Generated at 2022-06-24 01:21:04.241793
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    m = SomeMoney('USD', Decimal(10), Date(2020, 4, 21))
    assert m.ccy == 'USD'
    assert isinstance(m.qty, Decimal)
    assert m.qty == Decimal(10)
    assert m.dov == Date(2020, 4, 21)
    assert m.as_boolean() == True

    assert SomeMoney('USD', Decimal(10), Date(2020, 4, 21)) == SomeMoney('USD', Decimal(10), Date(2020, 4, 21))
    assert SomeMoney('USD', Decimal(10), Date(2020, 4, 21)) != SomeMoney('NZD', Decimal(10), Date(2020, 4, 21))

# Generated at 2022-06-24 01:21:10.182063
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    price1 = Price.of(Currency.of('USD'), Decimal('100.00'), Date.of(2020, 1, 1))
    price2 = Price.of(Currency.of('USD'), Decimal('100.00'), Date.of(2020, 1, 2))
    price3 = Price.of(Currency.of('USD'), Decimal('100.00'), Date.of(2019, 1, 1))
    price4 = Price.of(Currency.of('USD'), Decimal('99.99'), Date.of(2020, 1, 1))
    price5 = Price.of(Currency.of('USD'), Decimal('99.99'), Date.of(2020, 1, 1))
    price6 = Price.of(Currency.of('USD'), Decimal('100.00'), Date.of(2020, 1, 1))
   

# Generated at 2022-06-24 01:21:15.811297
# Unit test for method add of class Money
def test_Money_add():
    # verify that Money objects are added correctly
    assert Money.of(EUR, Decimal("1"), dt.date(2000, 1, 1)) == Money.of(EUR, Decimal("1"), dt.date(2000, 1, 1))
    assert Money.of(EUR, Decimal("1"), dt.date(2000, 1, 1)) != Money.of(EUR, Decimal("2"), dt.date(2000, 1, 1))
    assert Money.of(EUR, Decimal("1"), dt.date(2000, 1, 1)) != Money.of(EUR, Decimal("1"), dt.date(1999, 1, 1))
    
    # verify that addition of Money objects works correctly

# Generated at 2022-06-24 01:21:25.004343
# Unit test for method __round__ of class Money
def test_Money___round__():
    from decimal import Decimal as D
    from datetime import date as Date

    from pyg3.utilities import strings

    from pygenesis.currencies import Currency
    from pygenesis.encoding.money import Money

    assert Money(Currency.USD(), D("0"), Date.today()).__round__() == 0
    assert Money(Currency.USD(), D("0.50"), Date.today()).__round__() == 1
    assert Money(Currency.USD(), D("1.25"), Date.today()).__round__() == 1
    assert Money(Currency.USD(), D("1.75"), Date.today()).__round__() == 2
    assert Money(Currency.USD(), D("-0.5"), Date.today()).__round__() == -1

# Generated at 2022-06-24 01:21:32.489649
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    """
    Testing method __lt__ of class NoneMoney
    """
    print("Testing method __lt__ of class NoneMoney")
    from math import nan
    from insight.utils import get_currency
    from insight.utils import get_date
    from insight.utils import get_money

# Generated at 2022-06-24 01:21:38.437096
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    input = SomeMoney(Currency('EUR'), Decimal(12), date(2019, 12, 31))
    instance = NoneMoney()
    expected = False
    actual = instance.__lt__(input)
    assert actual == expected
    print(actual)

    input = NoMoney
    expected = True
    actual = instance.__lt__(input)
    assert actual == expected
    print(actual)

    input = SomeMoney(Currency('EUR'), Decimal(12), date(2019, 12, 31))
    expected = "Undefined monetary values do not have quantity information."
    with pytest.raises(TypeError) as excinfo:
        instance.__lt__(input)
    the_exception = excinfo.value
    assert str(the_exception) == expected
    print(the_exception)


# Unit

# Generated at 2022-06-24 01:21:39.210591
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    pass


# Generated at 2022-06-24 01:21:41.962534
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert SomeMoney(CCY, 100, Date.today()) == SomeMoney(CCY, 100, Date.today())


# Generated at 2022-06-24 01:21:53.408077
# Unit test for method __add__ of class Price
def test_Price___add__():
    from money import Price
    from money import SomePrice
# __add__ of class Price
    # when inputs are valid
    # when accepting a Price object as an argument
    try:
        assert Price.of('EUR', 1.0, None) + Price.of('EUR', 1.0, None) == SomePrice('EUR', 2.0, None)
    except:
        assert False
    # when accepting a float
    try:
        assert Price.of('EUR', 1.0, None) + 1 == SomePrice('EUR', 2.0, None)
    except:
        assert False
    # when accepting a int
    try:
        assert Price.of('EUR', 1.0, None) + 1 == SomePrice('EUR', 2.0, None)
    except:
        assert False
    # when accepting a

# Generated at 2022-06-24 01:21:54.364333
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    # TODO: Update test code.
    pass


# Generated at 2022-06-24 01:21:56.099905
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    return

# Generated at 2022-06-24 01:22:04.997465
# Unit test for constructor of class Price
def test_Price():
    # Create purpose specific price objects
    p = Price.of(Currency.of("USD"), Decimal('1'), Date.of(2017, 8, 1))
    p_1 = Price.of(Currency.of("USD"), None, Date.of(2017, 8, 1))
    p_2 = Price.of(None, Decimal('1'), Date.of(2017, 8, 1))
    p_3 = Price.of(None, None, Date.of(2017, 8, 1))
    p_4 = Price.of(Currency.of("USD"), Decimal('1'), None)
    p_5 = Price.of(Currency.of("USD"), None, None)
    p_6 = Price.of(None, Decimal('1'), None)
    p_7 = Price.of(None, None, None)

   

# Generated at 2022-06-24 01:22:16.381194
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    # ARRANGE #
    ccy1 = Currency.of("USD")
    ccy2 = Currency.of("EUR")

    qty1 = Decimal("100.00")
    qty2 = Decimal("100.00")

    dov1 = Date.today()
    dov2 = Date.today()

    dov3 = Date.today()
    dov4 = Date.today()
    dov5 = Date.today()
    dov6 = Date.today()

    sm1 = SomeMoney(ccy1, qty1, dov1)
    sm2 = SomeMoney(ccy2, qty2, dov2)

    # ACT & ASSERT #
    raising_msg = "Incompatible currency encountered. "

# Generated at 2022-06-24 01:22:17.908436
# Unit test for method round of class Money
def test_Money_round():
    """Test method round of class Money."""
    pass



# Generated at 2022-06-24 01:22:19.882380
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    assert SomePrice(USD, 123.4543, date(2018, 12, 31)).with_qty(0) == (USD, 0, date(2018, 12, 31))

# Generated at 2022-06-24 01:22:26.446354
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    m = SomeMoney(CNY, Decimal(1), Date(2020, 6, 1))
    m_with_ccy = m.with_ccy(CAD)
    assert m_with_ccy == SomeMoney(CAD, Decimal(1), Date(2020, 6, 1))

# Generated at 2022-06-24 01:22:37.026846
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import AUD, USD
    from .exchange import Rate, FXRateServiceStub
    from .money import Money, SomeMoney

    # Arrange
    FXRateService._instance = FXRateServiceStub()
    R1 = Rate(ccy1=AUD, ccy2=USD, qty=Decimal(0.5), dov=Date(2019, 1, 1))
    FXRateService._instance.register(R1)
    a1 = SomeMoney(ccy=AUD, qty=Decimal(1), dov=Date(2019, 1, 1))
    b1 = SomeMoney(ccy=USD, qty=Decimal(0.5), dov=Date(2019, 1, 1))

# Generated at 2022-06-24 01:22:42.052033
# Unit test for method negative of class Price
def test_Price_negative():
    new_Price = Price.of(ccy= Currency.USD, qty=Decimal("1000"), dov=Date.of(2018, 12, 28))
    assert new_Price.negative() == Price.of(ccy= Currency.USD, qty=Decimal("-1000"), dov=Date.of(2018, 12, 28))



# Generated at 2022-06-24 01:22:43.723474
# Unit test for method times of class Price
def test_Price_times():
    price = Price.of(Currency.USD, Decimal("12.34"), now())
    assert price.times(4) == Money.of(Currency.USD, Decimal("49.36"), now())



# Generated at 2022-06-24 01:22:55.008289
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert NoneMoney.is_equal(NoneMoney)
    assert SomeMoney("EUR", 1.0, "2019-01-01").is_equal(SomeMoney("EUR", 1.0, "2019-01-01"))
    assert not SomeMoney("USD", 1.0, "2019-01-01").is_equal(SomeMoney("EUR", 1.0, "2019-01-01"))
    assert not SomeMoney("USD", 1.0, "2019-01-01").is_equal(SomeMoney("USD", 2.0, "2019-01-01"))
    assert not SomeMoney("USD", 1.0, "2019-01-01").is_equal(SomeMoney("USD", 1.0, "2020-01-01"))



# Generated at 2022-06-24 01:22:57.511131
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    p = NonePrice
    assert_equal(float(p), float(p.__float__()))



# Generated at 2022-06-24 01:23:02.749132
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    USD_1 = USD(1)
    GBP_1 = USD_1.with_ccy(GBP)
    assert GBP_1.ccy == GBP, "USD 1 should be converted to GBP 1"
    assert GBP_1.qty == GBP(1)
    
    assert GBP_1.with_ccy(None) == None, "GBP_1 should be representable by None"
    assert GBP_1.with_ccy(None) == GBP_1.set_ccy(None), "GBP_1 should be convertible by NoneMoney"

# Generated at 2022-06-24 01:23:05.138124
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    assert SomeMoney(USD, Decimal("0"), None).__pos__() == SomeMoney(USD, Decimal("0"), None)
    assert SomeMoney(USD, Decimal("1"), None).__pos__() == SomeMoney(USD, Decimal("1"), None)
    assert SomeMoney(USD, Decimal("-1"), None).__pos__() == SomeMoney(USD, Decimal("1"), None)



# Generated at 2022-06-24 01:23:17.329137
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    """
    Defines unit tests for method __gt__
    of class Money.
    """
    print(f"\n{test_Money___gt__.__doc__}")
    # Create some money objects
    usd = Money.of(Currency.of(USD), Decimal(1), Date(1,1,2018))
    chf = Money.of(Currency.of(CHF), Decimal(2), Date(1,1,2018))
    # Test
    assert (usd > chf) == False
    assert (usd > usd) == False
    assert (usd > chf) == False
    assert (usd > usd) == False
    assert (chf > usd) == True
    assert (chf > usd) == True
    assert (usd > usd) == False
   

# Generated at 2022-06-24 01:23:23.614445
# Unit test for method __float__ of class Money
def test_Money___float__():
    Money.NA = NoMoney
    assert_that(
        Money.NA.__float__(),
        raises(
            MonetaryOperationException,
            "Money object is undefined",
        ),
    )



# Generated at 2022-06-24 01:23:33.541172
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    from datetime import datetime
    from finx import Currency, Date, Money, NoMoney, SomeMoney, fxrate
    from arctic import Arctic, TICK_STORE
    from arctic.date import DateRange
    from numbers import Number

    assert (SomeMoney(Currency('USD'), 1, Date(datetime(2019, 1, 1)))
            <= SomeMoney(Currency('USD'), 2, Date(datetime(2019, 1, 1))))
    assert not (SomeMoney(Currency('USD'), 3, Date(datetime(2019, 1, 1)))
                <= SomeMoney(Currency('USD'), 2, Date(datetime(2019, 1, 1))))

    ## Test that an undefined money object is never less than or equal to the other
    ## money object, even if both are undefined:
    assert not (NoMoney <= NoMoney)

   

# Generated at 2022-06-24 01:23:42.031758
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    from .currencies import Currency
    from .dateutils import Date
    from .exchange import FXRateServiceType
    from .monetary import NoMoney, SomeMoney
    from .numbers import ZERO
    from .schema import AccountSchema
    
    
    
    
    ## Prepare data:
    ## -------------
    def init_env():
        schema = AccountSchema()
        schema.register("GBP", 2)
        schema.register("USD", 2)
        schema.register("EUR", 2)
        FXRateService.initialize(FXRateServiceType.Memory, schema)
        
    ## Actual tests:
    ## -------------
    init_env()
    
    
    
    
    
    
    
    
    
    
    
    
    print("Case 1: Two undefined money is equal.")
   

# Generated at 2022-06-24 01:23:51.625674
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    usd = Currency.of("USD")
    a = Money.of(usd, 1, Date(2010, 9, 1))
    b = Money.of(usd, 5, Date(2010, 9, 1))

    assert a.floor_divide(b).qty == Decimal('0')
    assert a.floor_divide(b).ccy == usd
    assert a.floor_divide(b).dov == Date(2010, 9, 1)
    assert a.floor_divide(b).defined == False
    assert a.floor_divide(b).undefined == True
    try:
        Money.of(usd, 1.1, Date(2010, 9, 1)).floor_divide(b)
        assert False
    except MonetaryOperationException:
        assert True

# Generated at 2022-06-24 01:23:55.552611
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    assert SomeMoney("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) == SomeMoney("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) 
    assert SomeMoney("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) == Money.of("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) 
    assert SomeMoney("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) == Money("USD", Decimal("123456.78901234567890"), Date(2027, 4, 10)) 


# Generated at 2022-06-24 01:24:01.166448
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    # create a contrived example of data to operate on
    val1 = 100
    val2 = 30
    money1 = Money(Currency.GBP, 100, Date(2020, 1, 1))
    expected = 70
    # perform the test
    actual = money1.scalar_subtract(val2)
    # assert the expected output
    assert actual == expected

# Generated at 2022-06-24 01:24:02.081118
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert not NoMoney
    assert not NoMoney.__bool__()



# Generated at 2022-06-24 01:24:06.941633
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__():
    ccys = Currency.valid_currencies()[:5]
    qtys: List[Decimal] = []
    datestrs = ["2017-01-01", "2017-12-31", "2018-01-01", "2018-12-31"]
    for i in range(5):
        ## We'll multicast over Numeric type:
        qtys.append(Decimal(i) + 0.145)

    money_items: List[Tuple[Currency, Decimal, Date]] = []
    for ccy in ccys:
        for qty in qtys:
            for dt in datestrs:
                money_items.append((ccy, qty, Date.from_string(dt)))

    for item in money_items:
        money = SomeMoney(*item)

# Generated at 2022-06-24 01:24:11.894249
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(SomeMoney(ccy=Currency.USD, qty=123.456, dov=Date(year=2020, month=1, day=1))) == 123.456
    assert float(NoMoney) == 0.0

# Generated at 2022-06-24 01:24:16.833000
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    c = Currency.get_instance("USD")
    p1 = SomePrice(
        c,
        Decimal("10.00").quantize(c.quantizer),
        date(2012, 6, 1),
    )
    assert p1 // 2 == SomePrice(
        c,
        Decimal("5").quantize(c.quantizer),
        date(2012, 6, 1),
    )

# Generated at 2022-06-24 01:24:18.315624
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    tMoney = Money.of(None, None, None)
    assert tMoney is NoMoney


# Generated at 2022-06-24 01:24:20.130547
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    assert (NonePrice + NonePrice) == NoPrice


# Generated at 2022-06-24 01:24:24.530794
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    for ccy in available_currencies:
        for qty in (10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0):
            for dov in (today(), today() - 14, today() - 54):
                p = SomePrice(ccy, Decimal(qty), dov)
                pp = p.__neg__()
                assert type(pp) is SomePrice
                assert pp.ccy == ccy
                assert pp.qty == Decimal(-qty)
                assert pp.dov == dov


# Generated at 2022-06-24 01:24:26.126246
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    MonetaryOperationException(message = "Testing MonetaryOperationException")



# Generated at 2022-06-24 01:24:27.706901
# Unit test for method divide of class Price
def test_Price_divide():
    # Test body
    pass


# Generated at 2022-06-24 01:24:32.543076
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    from financepy.base.Currencies import Currency
    from financepy.base.Date import Date
    ccy = Currency('USD')
    d = Date(1,1,2020)
    m = NoneMoney
    price = m.convert(ccy, d, strict=False)
    assert price.undefined


# Generated at 2022-06-24 01:24:34.508867
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    some_money: Money = SomeMoney(USD, Decimal('1'), Date(Date.now().year, 12, 31))
    assert some_money.__truediv__(2) == Money.of(USD, Decimal('0.5'), Date(Date.now().year, 12, 31))



# Generated at 2022-06-24 01:24:41.928947
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    # Positive case:
    a = Money.of(Currency.USD, Decimal("0.1234"), Date(2020, 1, 1))
    b = Money.of(Currency.USD, Decimal("0.1234"), Date(2020, 1, 1))
    assert a == b
    assert a == a
    assert b == b
    # Negative case:
    a = Money.of(Currency.USD, Decimal("0.1234"), Date(2020, 1, 1))
    b = Money.of(Currency.USD, Decimal("0.1234"), Date(2020, 1, 2))
    c = Money.of(Currency.EUR, Decimal("0.1234"), Date(2020, 1, 1))
    assert a != b
    assert b != c
    assert a != c
    assert a != None

# Generated at 2022-06-24 01:24:53.161946
# Unit test for constructor of class SomePrice
def test_SomePrice():
    d = date(2019,1,1)
    P1 = SomePrice(USD,100,d)
    ccy, qty, dov = P1
    assert(ccy == USD)
    assert(qty == 100)
    assert(dov == d)
    P2 = SomePrice(USD,0,d)
    assert(not P2.__bool__())
    assert(bool(P1) == True)
    Money1 = P1.money
    assert(Money1.ccy == USD)
    assert(Money1.qty == 100)
    assert(Money1.dov == d)
    assert(P1.__float__() == 100)
    assert(P1.__int__() == 100)
    P3 = SomePrice(USD,1,d)

# Generated at 2022-06-24 01:24:57.674763
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("0.1234"), TODAY).round() == SomeMoney(USD, Decimal("0.12"), TODAY)
    assert SomeMoney(USD, Decimal("0.1234"), TODAY).round(0) == SomeMoney(USD, Decimal("0.12"), TODAY)
    assert SomeMoney(USD, Decimal("0.1234"), TODAY).round(1) == SomeMoney(USD, Decimal("0.12"), TODAY)
    assert SomeMoney(USD, Decimal("0.1234"), TODAY).round(2) == SomeMoney(USD, Decimal("0.123400"), TODAY)



# Generated at 2022-06-24 01:25:10.927388
# Unit test for method round of class Price
def test_Price_round():
    assert Price.of(USD, 0, TODAY).round() == Price.of(USD, 0, TODAY)
    assert Price.of(USD, Decimal('0.00'), TODAY).round() == Price.of(USD, 0, TODAY)
    assert Price.of(USD, Decimal('1.00'), TODAY).round() == Price.of(USD, 1, TODAY)
    assert Price.of(USD, Decimal('1.235000'), TODAY).round() == Price.of(USD, 1.24, TODAY)
    assert Price.of(USD, Decimal('1.234000'), TODAY).round() == Price.of(USD, 1.23, TODAY)
    assert Price.of(USD, Decimal('1.230000'), TODAY).round() == Price.of(USD, 1.23, TODAY)

# Generated at 2022-06-24 01:25:13.478048
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    _t: Price = SomePrice(Currency("USD"), Decimal("1"), Date.now())
    _t.round(ndigits=None)
    _t.round(0)

# Generated at 2022-06-24 01:25:25.639850
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    """
    TODO
    """

    ccy = Currency(code="USD", description="US Dollar", decimals=2)
    qty = Decimal("12.34")
    dov = Date(year=2007, month=11, day=27)

    m1 = SomeMoney(ccy, qty, dov)

    m2 = m1.__floordiv__(2)

    assert isinstance(m2, SomeMoney)

    assert m2.ccy == ccy
    assert m2.qty == Decimal("6.00")
    assert m2.dov == dov

    m3 = m1.__floordiv__(Decimal("2.00"))

    assert isinstance(m3, SomeMoney)

    assert m3.ccy == ccy
    assert m3.qty == Dec

# Generated at 2022-06-24 01:25:35.564157
# Unit test for method round of class Price
def test_Price_round():
    obj1 = Price.of(Currency.of("USD"),Decimal("100.0000"), Date.today())
    assert obj1.round() == Price.of(Currency.of("USD"),Decimal("100"), Date.today())
    assert obj1.round(-1) == Price.of(Currency.of("USD"),Decimal("100.0"), Date.today())
    assert obj1.round(-2) == Price.of(Currency.of("USD"),Decimal("100.00"), Date.today())
    assert obj1.round(-3) == Price.of(Currency.of("USD"),Decimal("100.000"), Date.today())
    assert obj1.round(-4) == Price.of(Currency.of("USD"),Decimal("100.0000"), Date.today())
    assert obj1.round(-5) == Price

# Generated at 2022-06-24 01:25:45.625622
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    # Python
    assert SomePrice(USD, Decimal("1.234"), Date.in_month(2, 2018)) + Decimal("1.234") == \
           SomePrice(USD, Decimal("2.468"), Date.in_month(2, 2018))
    assert SomePrice(USD, Decimal("1.234"), Date.in_month(2, 2018)) + 1 == \
           SomePrice(USD, Decimal("2.234"), Date.in_month(2, 2018))
    assert SomePrice(USD, Decimal("1.234"), Date.in_month(2, 2018)) + 1.234 == \
           SomePrice(USD, Decimal("2.468"), Date.in_month(2, 2018))
    assert SomePrice(USD, Decimal("1.234"), Date.in_month(2, 2018)) + None is No

# Generated at 2022-06-24 01:25:47.295055
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    assert NoPrice.scalar_add(1.0) == NoPrice

# Generated at 2022-06-24 01:25:48.400550
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    assert (NonePrice() * 2.5) == NonePrice()


# Generated at 2022-06-24 01:25:59.164582
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    import money
    import datetime
    money.FXRateService.default = money.fx.memory.MemoryFXRateService(rates={})
    usd = money.Currency("USD", "US Dollars", decimals=2)
    cad = money.Currency("CAD", "Canadian Dollars", decimals=2)
    money.Currency.default = usd
    u0 = money.Money(usd, 10, datetime.date(2020, 1, 1))
    u0.convert(to=cad, asof=datetime.date(2020, 1, 2)) == money.NA

    money.FXRateService.default.update(usd, cad, money.FXRate(usd, cad, 1.5, datetime.date(2020, 1, 2)))

# Generated at 2022-06-24 01:26:03.488278
# Unit test for method __int__ of class Money
def test_Money___int__():
    money = SomeMoney(
        Currency("EUR"),  # pylint: disable=no-value-for-parameter
        100.00,
        Date.from_string("2020-01-01"),
    )

    assert int(money) == 100



# Generated at 2022-06-24 01:26:12.096940
# Unit test for method convert of class Price
def test_Price_convert():
    """
    Tests for the method convert of class Price.
    """
    # Define the conversion factor from USD to EUR as 0.9
    usd_to_eur = fxs.ConversionFactor(cur.usd, cur.eur, 0.9)
    # Define the CurrencySet with USD and EUR, and USd/EUR conversion factor
    usd_eur = fxs.CurrencySet([cur.usd, cur.eur], [usd_to_eur])
    # Set the default currency set
    fxs.CurrencyContext.set(usd_eur)
    #
    # Note that the class Price has two sub classes: SomePrice and NoPrice.
    #
    # We need to test both of them.
    #

    ################################################################################################################
    # A price defined in USD, 1 at some date.

# Generated at 2022-06-24 01:26:12.941455
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    return

# Generated at 2022-06-24 01:26:15.124505
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    nprc = NoPrice > NoPrice
    assert nprc == False
    return None



# Generated at 2022-06-24 01:26:27.787393
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    NoneMoney, SomeMoney = Money()
    assert NoneMoney.with_dov(Date(1, 1, 1)) is NoneMoney
    money_some_123 = SomeMoney(Currency("USD"), Decimal("1.23"), Date(2018, 1, 1))
    money_some_123_1111 = money_some_123.with_dov(Date(1111, 1, 1))
    assert money_some_123_1111.ccy == money_some_123.ccy
    assert money_some_123_1111.qty == money_some_123.qty
    assert money_some_123_1111.dov == Date(1111, 1, 1)
    assert money_some_123.dov == Date(2018, 1, 1)
Money.NA = NoMoney = NoneMoney = NoneMoney()


# Generated at 2022-06-24 01:26:38.031921
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    assert isinstance(SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today()), Price)
    assert SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today()) <= SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today())
    assert SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today()) <= SomePrice.of(ccy=USD, qty=Decimal("2"), dov=today())
    assert isinstance(SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today()), Price)
    assert not SomePrice.of(ccy=USD, qty=Decimal("1"), dov=today()) <= NoPrice

# Generated at 2022-06-24 01:26:45.987581
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():

    ## Case no.1:
    p1 = SomePrice(Currency.of("EUR", 2), Decimal(10), Date.of(2018, Month.NOV, 1))
    p2 = SomePrice(Currency.of("EUR", 2), Decimal(10), Date.of(2018, Month.NOV, 1))

    assert p1.__eq__(p2) is True
    assert p2.__eq__(p1) is True

    ## Case no.2:
    p1 = SomePrice(Currency.of("EUR", 2), Decimal(10), Date.of(2018, Month.NOV, 1))
    p2 = SomePrice(Currency.of("EUR", 3), Decimal(10), Date.of(2018, Month.NOV, 1))


# Generated at 2022-06-24 01:26:52.439258
# Unit test for method __int__ of class Money
def test_Money___int__():
    from finance.currencies import USD
    from finance.model.money import SomeMoney
    from finance.model.types import Numeric
    from finance.model.zeitgeist import Date

    m = SomeMoney(USD, 10, Date(2019, 2, 12))
    assert int(m) == 10



# Generated at 2022-06-24 01:26:53.317645
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    NonePrice().__pos__()

# Generated at 2022-06-24 01:26:58.445924
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():

    assert(NoMoney.scalar_add(Decimal("0.25")))
    assert(NoMoney.scalar_add(1))
    assert(NoMoney.scalar_add("1.42"))



# Generated at 2022-06-24 01:27:03.475910
# Unit test for method negative of class Money
def test_Money_negative():
    from .currencies import USD, TRY

    mny = Money(USD, 10, Date.today())
    assert mny.negative() == Money(USD, -10, Date.today())
    assert mny.negative().negative() == mny
    assert Money.NA.negative() is Money.NA
    assert Money(TRY, 10, Date.today()).negative() == Money(TRY, -10, Date.today())


# Generated at 2022-06-24 01:27:07.761922
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    """
    Unit test for method `__eq__` of class `NoneMoney`.
    """
    assert NoMoney.__eq__(NoMoney)


# Generated at 2022-06-24 01:27:10.811380
# Unit test for method __le__ of class Money
def test_Money___le__():
    # TODO: Unit test for method __le__ of class Money
    raise NotImplementedError()



# Generated at 2022-06-24 01:27:20.369557
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import Currency
    from .currencies import Currency

    ccy = Currency.of('GBP')
    ccy = Currency.of('GBP')
    qty = Decimal('1')
    dov = Date.from_ymd(2000, 1, 1)
    m = Money.of(ccy, qty, dov)

    assert m.ccy == ccy
    assert m.qty == qty
    assert m.dov == dov
    assert m.defined == True
    assert m.undefined == False

    assert m.with_ccy(ccy) == m
    assert m.with_ccy(ccy).ccy == Currency.of('GBP')
    assert m.with_qty(qty) == m
    assert m.with_qty(qty).qty

# Generated at 2022-06-24 01:27:26.299763
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    price1 = SomePrice(USD, 100.0, Date(2018, 6, 4))
    price2 = SomePrice(USD, 50.0, Date(2018, 6, 4))
    price1.subtract(price2)

    price1 = SomePrice(USD, 100.0, Date(2018, 6, 4))
    price2 = SomePrice(USD, 50.0, Date(2018, 6, 3))
    price1.subtract(price2)

    price1 = SomePrice(USD, 100.0, Date(2018, 6, 4))
    price2 = NoPrice
    price1.subtract(price2)

    price1 = SomePrice(USD, 100.0, Date(2018, 6, 4))
    price2 = NoPrice
    price1.subtract(price2)

    price1 = Some

# Generated at 2022-06-24 01:27:31.558247
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    data = Decimal('inf')
    expected = Decimal('inf')
    result = NoneMoney.with_qty(data)
    assert result == expected, f'Expected: {expected!r}, but got: {result!r}'

# Generated at 2022-06-24 01:27:39.587595
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    from money import Money
    from money import FXRate
    from money import Prices
    from money import FXRateService
    from decimal import Decimal

    assert float(NoPrice / 2) == float(0)
    assert float(NoPrice / 2.0) == float(0)
    assert float(NoPrice / Decimal("2.0")) == float(0)
    assert float(NoPrice / Money("2", "EUR")) == float(0)
    assert float(NoPrice / Prices("2", "EUR")) == float(0)
    assert float(NoPrice / Prices("2", "EUR", asof="2000-01-01")) == float(0)
    assert float(NoPrice / FXRate(1.0)) == float(0)

    fx = FXRate(1.0)
    assert fx.value == Decimal

# Generated at 2022-06-24 01:27:50.800294
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    import hamcrest as hc
    from hamcrest import assert_that

    assert_that(Price.of(USD, Decimal('10'), asof=Date(2018, 1, 2)).scalar_subtract(Decimal('7')),
                hc.equal_to(Price.of(USD, Decimal('3'), asof=Date(2018, 1, 2))))

    assert_that(Price.of(USD, Decimal('10'), asof=Date(2018, 1, 2)).scalar_subtract(Decimal('-7')),
                hc.equal_to(Price.of(USD, Decimal('17'), asof=Date(2018, 1, 2))))


# Generated at 2022-06-24 01:27:54.403675
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    from ._data import PriceData

    assert PriceData.USD(19.95) > PriceData.EUR(10)
    assert PriceData.USD(19.95) > PriceData.USD(19.95)
    assert PriceData.USD(19.95) > PriceData.USD(10)
    assert PriceData.USD(19.95) > PriceData.EUR(19.95) is False


# Generated at 2022-06-24 01:27:56.384502
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    ########
    # TODO #
    ########
    raise SkipTest

# Generated at 2022-06-24 01:28:02.201522
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    # Arrange
    price = Price.of(EUR, Decimal("10.53"), date(2020, 1, 1))
    ccy = USD

    # Act
    actual = price.with_ccy(ccy)

    # Assert
    assert actual.ccy == USD, "Price.with_ccy should return a price with the given currency."


# Generated at 2022-06-24 01:28:08.503114
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    ccy = Currency.USD
    qty = Decimal(random.randint(1, 1000))
    dov = Date.random()
    money = SomeMoney(ccy, qty, dov)
    assert money.__int__() == int(qty)
    assert money.__int__() == 0
    assert money.__int__() == 1

# Generated at 2022-06-24 01:28:09.376600
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    assert not NoneMoney()

# Generated at 2022-06-24 01:28:18.824852
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    # Test 1: Undefined money object
    ccy = Currency.of('EUR')
    dov = Date.now()
    money = Money.of(ccy, 0.0, dov)
    assert money.__mul__(1.0) == money
    assert money.__mul__(1.0) == money

    # Test 2: Defined money object
    ccy = Currency.of('EUR')
    dov = Date.now()
    money = Money.of(ccy, 0.0, dov)
    assert money.is_negative()

    # Test 3: Positive multiplication
    ccy = Currency.of('EUR')
    dov = Date.now()
    money = Money.of(ccy, 2.0, dov)
    assert money.__mul__(2.0)

# Generated at 2022-06-24 01:28:26.447410
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    from datetime import date
    from arctic.date import Date
    from arctic.money import Currency
    from arctic.price import SomePrice
    from arctic.price import Decimal
    t1 = (Currency.USD, Decimal(-1.0000), Date.today())
    t2 = (Currency.USD, Decimal(1.0000), Date.today())
    p1 = SomePrice(*t1)
    p2 = SomePrice(*t2)
    assert p1.__abs__() == p2
