

# Generated at 2022-06-26 00:55:32.665705
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    some_money_0 = SomeMoney()
    some_money_1 = some_money_0.with_dov(DO_485_567)
    some_money_2 = some_money_0.with_dov(DO_485_567)
    some_money_3 = some_money_2.with_dov(DO_485_567)
    some_money_4 = some_money_1.with_dov(DO_485_567)
    some_money_5 = some_money_3.with_dov(DO_485_567)


# Generated at 2022-06-26 00:55:42.393023
# Unit test for method __float__ of class Money
def test_Money___float__():
    from decimal import Decimal as D
    from datetime import date as DATE
    from .currencies import Currency as C
    from .money_models import SomeMoney as M

    _ = D
    _ = DATE
    _ = C
    _ = M

    M(C('USD'), D(0)      , DATE(2012, 1, 1)).__float__()  # E: IncompatibleCurrencyError

    M(C('USD'), D(0.000)  , DATE(2012, 1, 1)).__float__()  # E: MonetaryOperationException
    M(C('USD'), D(0.000)  , DATE(2012, 1, 1)).__float__()  # E: MonetaryOperationException

    M(C('USD'), D(0.00)   , DATE(2012, 1, 1)).__float__() 

# Generated at 2022-06-26 00:55:44.097851
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert Price.NA.is_equal(Price.NA) is True


# Generated at 2022-06-26 00:55:54.564830
# Unit test for method __add__ of class Price

# Generated at 2022-06-26 00:56:05.023053
# Unit test for method subtract of class Price
def test_Price_subtract():
    """
    Runs unit tests for the subtract method of class Price
    """
    from models.base import Price
    from models.base import Money
    from fx.fx_provider import FXProvider
    import datetime
    from models.base import NoPrice
    from models.base import NoMoney
    
    
    # Case 1
    try:
        price_0 = Price(ccy="USD", qty=2, dov="2020-01-01")
    except:
        price_0 = Price(ccy="TRY", qty=2, dov="2020-01-01")

# Generated at 2022-06-26 00:56:05.930170
# Unit test for method __int__ of class Price
def test_Price___int__():
    return Price.__init__()


# Generated at 2022-06-26 00:56:15.592378
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    #Case 1
    some_money_0 = SomeMoney(ccy=Currency.USD, qty=Decimal('1.0'), dov=Date.today())
    assert some_money_0.scalar_add(Decimal('2.0')) == SomeMoney(ccy=Currency.USD, qty=Decimal('3.0'), dov=Date.today())
    #Case 2
    some_money_0 = SomeMoney(ccy=Currency.USD, qty=Decimal('1.0'), dov=Date.today())
    assert some_money_0.scalar_add(2) == SomeMoney(ccy=Currency.USD, qty=Decimal('3.0'), dov=Date.today())
    #Case 3

# Generated at 2022-06-26 00:56:19.708224
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert Price.NA.as_boolean() == False
    assert Price.of(USD, 100, Date.of(1, 1, 1)).as_boolean() == True
    assert Price.of(USD, 0, Date.of(1, 1, 1)).as_boolean() == False


# Generated at 2022-06-26 00:56:22.301682
# Unit test for method gte of class Price
def test_Price_gte():
    some_price_0 = SomePrice()
    boolean_0 = SomePrice.gte(some_price_0, some_price_0)
    assert boolean_0 == True


# Generated at 2022-06-26 00:56:31.900830
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    from datetime import date
    from .currency import GBP, USD

    some_money_0 = SomeMoney(CCY=GBP, QTY=10, DOV=date(2019, 1, 1))
    some_money_1 = SomeMoney(CCY=USD, QTY=10, DOV=date(2019, 1, 2))
    some_money_2 = SomeMoney(CCY=USD, QTY=1, DOV=date(2019, 1, 2))
    some_money_3 = SomeMoney(CCY=USD, QTY=1, DOV=date(2019, 1, 3))
    some_money_list = [some_money_2, some_money_3]

    some_money_4 = SomeMoney(CCY=GBP, QTY=20, DOV=date(2019, 1, 1))

# Generated at 2022-06-26 00:56:57.624388
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    class SomeMoney_0(Money):
        def is_equal(self, other: Any) -> bool:
            return False

        def as_boolean(self) -> bool:
            raise ProgrammingError("We should not have reached here!")

        def as_float(self) -> float:
            raise ProgrammingError("We should not have reached here!")

        def as_integer(self) -> int:
            raise ProgrammingError("We should not have reached here!")

        def abs(self) -> "Money":
            raise ProgrammingError("We should not have reached here!")

        def negative(self) -> "Money":
            raise ProgrammingError("We should not have reached here!")

        def positive(self) -> "Money":
            raise ProgrammingError("We should not have reached here!")


# Generated at 2022-06-26 00:57:10.399746
# Unit test for method subtract of class Price
def test_Price_subtract():
    # {
    #     "ccy": Currency.of("USD"),
    #     "qty": Decimal(100.00),
    #     "dov": Date(1996, 12, 12)
    # }
    # some dollar money
    some_dollar_money = SomeMoney(Currency.of("USD"), Decimal(100.00), Date(1996, 12, 12))
    # {
    #     "ccy": Currency.of("EUR"),
    #     "qty": Decimal(100.00),
    #     "dov": Date(1996, 12, 12)
    # }
    # some euro money
    some_euro_money = SomeMoney(Currency.of("EUR"), Decimal(100.00), Date(1996, 12, 12))
    # {
    #     "ccy": Currency.

# Generated at 2022-06-26 00:57:16.548196
# Unit test for method lt of class Price

# Generated at 2022-06-26 00:57:31.035166
# Unit test for method subtract of class Price
def test_Price_subtract():
    some_money_1 = SomeMoney()
    some_money_2 = SomeMoney(ccy=Currency.USD, qty=Decimal("1.2345"), dov=Date.D19000101)
    some_money_3 = SomeMoney(ccy=Currency.USD, qty=Decimal("234"), dov=Date.D19000101)
    some_money_4 = SomeMoney(ccy=Currency.USD, qty=Decimal("-1234.01"), dov=Date.D19000101)
    some_money_5 = SomeMoney(ccy=Currency.USD, qty=Decimal("1234.01"), dov=Date.D19000101)

# Generated at 2022-06-26 00:57:33.890868
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert (NoMoney.is_equal(NoMoney)) == True
    assert (SomeMoney.is_equal(SomeMoney)) == True


# Generated at 2022-06-26 00:57:43.061968
# Unit test for method __int__ of class Price
def test_Price___int__():
    some_price_0 = SomePrice()
    some_price_1 = SomePrice()
    some_price_2 = SomePrice()
    some_price_3 = SomePrice()
    some_price_4 = SomePrice()
    some_price_5 = SomePrice()
    some_price_6 = SomePrice()
    some_price_7 = SomePrice()
    some_price_8 = SomePrice()
    some_price_9 = SomePrice()
    some_price_10 = SomePrice()
    some_price_11 = SomePrice()

    assert(int(some_price_0.as_integer()) == None)

    some_price_0 = SomePrice(int(some_price_1.as_integer()), some_price_2.as_integer())


# Generated at 2022-06-26 00:57:47.939223
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    ccy = None
    qty = None
    dov = None
    some_money = SomeMoney(ccy = ccy, qty = qty, dov = dov)
    ccy_to = Currency("USD")
    res = some_money.with_ccy(ccy_to)
    assert isinstance(res, Money)


# Generated at 2022-06-26 00:57:54.965038
# Unit test for method as_float of class Price
def test_Price_as_float():
    ccys = ["EUR", "USD", "CAD", "GBP", "JPY"]
    qtys = [Decimal(x) for x in range(100)]
    ccy = ccys[random.randrange(0, len(ccys))]
    qty = qtys[random.randrange(0, len(qtys))]
    dov = datetime.date.today()
    price = SomePrice(ccy, qty, dov)
    assert price.as_float() == float(qty)
    assert NoPrice.as_float() == float(0)


# Generated at 2022-06-26 00:58:03.795754
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    some_price_0 = SomePrice(Currency.USD, Decimal('25.00'), Date(2011, 3, 2))
    some_price_1 = SomePrice(Currency.USD, Decimal('75.00'), Date(2011, 3, 2))
    some_price_2 = SomePrice(Currency.USD, Decimal('36.00'), Date(2011, 3, 2))

    assert some_price_0.__lt__(some_price_1) == (some_price_0.qty < some_price_1.qty)
    assert some_price_2.__lt__(some_price_1) == (some_price_2.qty < some_price_1.qty)


# Generated at 2022-06-26 00:58:05.669109
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert True


# Generated at 2022-06-26 00:58:43.107823
# Unit test for method multiply of class Money
def test_Money_multiply():
    none_money_0 = NoneMoney()
    some_money_0 = SomeMoney(module_1.Currency.USD, Decimal(0), Date.today())
    some_money_1 = SomeMoney(module_1.Currency.USD, Decimal('0'), Date.today())
    some_money_2 = SomeMoney(Currency.GBP, Decimal(0), Date.today())
    some_money_3 = SomeMoney(module_1.Currency.USD, Decimal('0'), Date.today())
    some_money_4 = some_money_1.negative()
    some_money_5 = some_money_3.scalar_multiply(some_money_3)
    money_0 = some_money_0.multiply(some_money_2)

# Generated at 2022-06-26 00:58:51.369491
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    none_money_0 = NoneMoney()
    some_money_0 = SomeMoney(ccy=Currency.USD, qty=Decimal(0), dov=Date(2018, 11, 1))
    some_money_1 = SomeMoney(ccy=Currency.USD, qty=Decimal(0), dov=Date(2018, 11, 1))
    some_money_2 = SomeMoney(ccy=Currency.USD, qty=Decimal(0), dov=Date(2018, 11, 2))
    some_money_3 = SomeMoney(ccy=Currency.CHF, qty=Decimal(0), dov=Date(2018, 11, 1))

# Generated at 2022-06-26 00:58:55.082138
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    """ Checks whether method __pos__ of class Price works properly. """
    none_money_0 = NoneMoney()
    try:
        price_0 = none_money_0.positive()
    except Exception as exception_0:
        pass

# Generated at 2022-06-26 00:58:57.832015
# Unit test for method __int__ of class Price
def test_Price___int__():
    none_price_0 = NonePrice()
    none_money_0 = NoneMoney()
    currency_type_0 = module_1.CurrencyType.ALTERNATIVE
    int_0 = none_price_0.as_integer()

# Generated at 2022-06-26 00:59:01.731085
# Unit test for method __le__ of class Price
def test_Price___le__():
    some_price_0 = SomePrice(None, None, None)
    price_0 = Price.of(None)
    some_price_1 = SomePrice(None, None, None)
    price_0 = Price.of(None)
    bool_0 = some_price_0.__le__(price_0)
    bool_1 = some_price_1.__le__(price_0)



# Generated at 2022-06-26 00:59:06.648887
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    some_price_0 = SomePrice(currency_1, decimal_0, date_0)
    some_price_1 = SomePrice(currency_1, decimal_0, date_0)
    bool_1 = some_price_0.gt(some_price_1)
    # AssertionError: <class 'AssertionError'>: expected: True, actual: False



# Generated at 2022-06-26 00:59:11.740886
# Unit test for method as_float of class Price
def test_Price_as_float():
    ccy_0 = module_1.CurrencyType.ALTERNATIVE
    decimal_0 = Decimal(0)
    date_0 = Date(2020, 12, 10)
    some_price_0 = SomePrice(ccy_0, decimal_0, date_0)
    int_0 = some_price_0.as_integer()
    assert_equal(int_0, 0)


# Generated at 2022-06-26 00:59:16.439473
# Unit test for method multiply of class Price
def test_Price_multiply():
    qty_0 = 100
    ccy_0 = module_1.Currency.AED
    dov_0 = module_1.Date(
        year=1,
        month=1,
        day=1)
    price_type_0 = module_1.Price(
        ccy_0,
        qty_0,
        dov_0)
    dec_0 = Decimal(0)
    price_type_1 = price_type_0.multiply(
        dec_0)


# Generated at 2022-06-26 00:59:19.643939
# Unit test for method times of class Price
def test_Price_times():
    cur = Currency("USD")
    pr = Price.of(cur, 3, today.value)
    amount = Decimal("4.5")
    mny = pr.times(amount)
    assert mny.ccy == cur
    assert mny.qty == Decimal("13.5")
    assert mny.dov == today.value

    assert pr.times(3) == pr.multiply(3)


# Generated at 2022-06-26 00:59:24.260266
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    # Create a new instance of class SomePrice
    some_price_0 = SomePrice(Currency.USD, Decimal('0.01'), Date.today())
    # Execute the method under test
    actual_result = some_price_0.__floordiv__(Decimal('2'))
    expected_result = Price.of(Currency.USD, Decimal('0.005'), Date.today())
    assert actual_result == expected_result
