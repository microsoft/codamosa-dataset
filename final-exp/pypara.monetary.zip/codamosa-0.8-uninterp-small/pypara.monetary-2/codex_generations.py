

# Generated at 2022-06-26 00:56:52.118096
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    print(Money.of(Currency.CAD,Decimal(5),Date(1,1,1)).scalar_subtract(Decimal(3)))
    print(Money.of(Currency.EUR,Decimal(1),Date(1,1,1)).scalar_subtract(Decimal(1)))
    print(Money.of(Currency.JPY,Decimal(1),Date(1,1,1)).scalar_subtract(Decimal(1)))
    print(Money.of(Currency.KZT,Decimal(1),Date(1,1,1)).scalar_subtract(Decimal(1)))

# Generated at 2022-06-26 00:57:04.352490
# Unit test for method __le__ of class Money
def test_Money___le__():

    # Undefined money objects are less than or equal to all money objects
    assert NoneMoney <= NoneMoney
    assert NoneMoney <= SomeMoney(Currency("USD"), 1.0, Date.today())
    assert NoneMoney <= SomePrice(Currency("USD"), Price.of(1.0, Currency("JPY")))

    # Defined money objects are less than or equal to others if quantities are less than or equal
    assert SomeMoney(Currency("USD"), 1.0, Date.today()) <= SomeMoney(Currency("USD"), 1.0, Date.today())
    assert SomeMoney(Currency("USD"), 1.0, Date.today()) <= SomeMoney(Currency("USD"), 10.0, Date.today())

# Generated at 2022-06-26 00:57:08.173596
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    result = Money.of(None, Decimal(1), None) / Decimal(1.0)
    assert result.defined == False
    result = Money.of(None, Decimal(1), None) / Decimal(0.0)
    assert result.defined == False


# Generated at 2022-06-26 00:57:19.280477
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    ccy = get_currency("EUR")
    some_money_0 = SomeMoney(ccy, Decimal("76.429736772389"), ccy.day_count.from_ymd(2018, 1, 3))
    some_money_1 = SomeMoney(ccy, Decimal("94.490729985476"), ccy.day_count.from_ymd(2018, 1, 3))
    certainly_true = some_money_0 <= some_money_0
    certainly_false = some_money_1 <= some_money_0


# Generated at 2022-06-26 00:57:31.122605
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert SomeMoney(ccy_usd, Decimal("-100.15"), dov_20200214) .as_integer() == -100
    assert SomeMoney(ccy_usd, Decimal("-100.99"), dov_20200214) .as_integer() == -101
    assert SomeMoney(ccy_usd, Decimal("-100"), dov_20200214)    .as_integer() == -100
    assert SomeMoney(ccy_usd, Decimal("0"), dov_20200214)      .as_integer() == 0
    assert SomeMoney(ccy_usd, Decimal("100"), dov_20200214)    .as_integer() == 100

# Generated at 2022-06-26 00:57:40.248555
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    s = NonePrice()
    t1 = Price.of(None, Decimal(3), None)
    t2 = Price.of(None, Decimal(-3), None)
    t3 = Price.of(None, Decimal(0), None)
    t4 = Price.of(None, None, None)
    assert s <= t1
    assert s <= t2
    assert s <= t3
    assert s <= t4
    t4 = Price.of(Currency.USD, Decimal(3), None)
    assert not s <= t4


# Generated at 2022-06-26 00:57:49.475426
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    EUR = Currency("EUR")
    USD = Currency("USD")

    # Case 0
    fx_rate_0 = FXRate("EUR", "USD", datetime.date(2017, 12, 1), Decimal("1.123"))
    some_price_0 = SomeMoney("EUR", Decimal("100.0001"), datetime.date(2017, 12, 12))
    expected_price_0 = SomeMoney("USD", Decimal("112.300123"), datetime.date(2017, 12, 12))

    actual_price_0 = some_price_0.convert("USD", datetime.date(2017, 12, 12), False)
    assert actual_price_0 == expected_price_0

    # Case 1

# Generated at 2022-06-26 00:57:54.793204
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    # Test 0
    price_0 = Price.of(Currency.of("USD"),Decimal(0),Date.of(2019, 10, 1))
    price_0 = price_0.scalar_add(Decimal(1))
    assert price_0.qty == Decimal(1), "Price.scalar_add: test_0 failed"
    assert price_0.ccy == Currency.of("USD")


# Generated at 2022-06-26 00:58:04.230996
# Unit test for method gt of class Money
def test_Money_gt():
    class SomeMoney_1(Money):
        ccy = Currency('CAD')
        qty = Decimal('0.01')
        dov = Date(2020, 1, 1)
        defined = True
        undefined = False

        def is_equal(self, other):
            if not isinstance(other, SomeMoney_1):
                return False
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov

        def as_boolean(self):
            return self.qty != 0

        def as_float(self):
            return float(self.qty)

        def as_integer(self):
            return int(self.qty)


# Generated at 2022-06-26 00:58:09.575865
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    date = Date(2018, 8, 27)
    money = Money.of(Currency.USD, 1, date)
    money_1 = money.with_dov(date)
    assert money_1.dov == date
    try:
        money_2 = money.with_dov(Date.today())
    except ValueError as e:
        assert e == '<null>'
