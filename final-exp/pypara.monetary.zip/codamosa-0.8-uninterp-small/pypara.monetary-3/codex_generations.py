

# Generated at 2022-06-26 00:58:15.279409
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    assert(NoPrice >= NoMoney)
    assert(NoPrice >= NoPrice)
    assert(NoPrice >= SomeMoney(NoCurrency(), NoAmount(), NoDate()))
    assert(NoPrice >= SomePrice(NoCurrency(), NoAmount(), NoDate()))
    assert(SomePrice(NoCurrency(), NoAmount(), NoDate()) >= NoMoney)
    assert(SomePrice(NoCurrency(), NoAmount(), NoDate()) >= NoPrice)
    assert(SomePrice(NoCurrency(), NoAmount(), NoDate()) >= SomeMoney(NoCurrency(), NoAmount(), NoDate()))
    assert(SomePrice(NoCurrency(), NoAmount(), NoDate()) >= SomePrice(NoCurrency(), NoAmount(), NoDate()))
    assert(SomePrice(NoCurrency(), NoAmount(), NoDate()) >= SomePrice(NoCurrency(), SomeAmount(), NoDate()))

# Generated at 2022-06-26 00:58:25.673466
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    x = SomeMoney()
    y = Money.of(y.ccy, y.qty, y.dov)
    # Now let's redefine the value date
    # We need to create a new instance
    x = x.with_dov(Date(2018, 12, 21))
    # checking that the equality holds
    assert x.is_equal(y)
    # Note: if we try to compare the objects, this would raise an exception
    # Reason: x and y are instances of a private class in Python
    # So we need to use their properties
    assert x.ccy == y.ccy
    assert x.qty == y.qty
    assert x.dov == y.dov


# Generated at 2022-06-26 00:58:33.300955
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert NoPrice.is_equal(NoPrice) == True
    assert NoPrice.is_equal(SomePrice(USD, 1, Date.from_str("2019-01-01"))) == False
    assert SomePrice(USD, 1, Date.from_str("2019-01-01")).is_equal(NoPrice) == False
    assert SomePrice(USD, 1, Date.from_str("2019-01-01")).is_equal(SomePrice(USD, 1, Date.from_str("2019-01-01"))) == True
    assert SomePrice(USD, 1, Date.from_str("2019-01-01")).is_equal(SomePrice(EUR, 1, Date.from_str("2019-01-01"))) == False

# Generated at 2022-06-26 00:58:41.466331
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    some_money_0 = SomeMoney()
    some_money_1 = SomeMoney(ccy = Currency(code = "TEST_CURRENCY_0"), qty = Decimal('1.1'), dov = Date(year = 1400, month = 1, day = 1))
    some_money_2 = SomeMoney(ccy = Currency(code = "TEST_CURRENCY_1"), qty = Decimal('2.2'), dov = Date(year = 914, month = 2, day = 2))
    some_money_3 = SomeMoney(ccy = Currency(code = "TEST_CURRENCY_2"), qty = Decimal('3.3'), dov = Date(year = 714, month = 3, day = 3))

# Generated at 2022-06-26 00:58:46.836079
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    c0 = Currency()
    q0 = Decimal()
    d0 = Date()
    some_price_0 = SomePrice(c0, q0, d0)
    some_price_0.__truediv__(Decimal(0))
    some_price_1 = SomePrice(c0, q0, d0)
    some_price_1.__truediv__(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 00:58:54.294872
# Unit test for method convert of class Money
def test_Money_convert():
    (Currency("USD"), Currency("EUR"), Currency("GBP"))

    # Unit test for function Money.convert with bad args
    def test_Money_convert_with_bad_args():
        ccy_USD = Currency("USD")
        fx_rate_service = FXRateService()
        some_money_0 = SomeMoney(ccy_USD, Decimal("1"), Date.now())
        ccy_EUR = Currency("EUR")
        some_money_1 = some_money_0.convert(ccy_EUR, fx_rate_service=fx_rate_service)
        assert some_money_1.ccy == ccy_EUR
    test_Money_convert_with_bad_args()



# Generated at 2022-06-26 00:59:01.795946
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    print("Testing scalar_add")
    assert SomeMoney().scalar_add(1) == SomeMoney()
    assert SomeMoney(ccy=Currency(code="USD"), qty=1, dov=Date.today()).scalar_add(1) == SomeMoney(ccy=Currency(code="USD"), qty=2, dov=Date.today())
    assert SomeMoney(ccy=Currency(code="USD"), qty=1, dov=Date.today()).scalar_add(-1) == SomeMoney(ccy=Currency(code="USD"), qty=0, dov=Date.today())

# Generated at 2022-06-26 00:59:07.491983
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    m = SomeMoney(ccy = Currency("EUR"), qty = Decimal("12.7"), dov = Date("2019-10-13"))
    n = m.scalar_add(2)
    assert n.qty == Decimal("14.7") and n.ccy == Currency("EUR") and n.dov == Date("2019-10-13")


# Generated at 2022-06-26 00:59:11.197901
# Unit test for method __abs__ of class SomeMoney
def test_SomeMoney___abs__():
    m = SomeMoney(USD(), Decimal('17.8'), datetime.date.today())
    m1 = m.__abs__()
    assert isinstance(m1, Money)
    assert isinstance(m1, SomeMoney)
    assert m1.qty == Decimal('17.8')


# Generated at 2022-06-26 00:59:23.393249
# Unit test for method __le__ of class Money
def test_Money___le__():
    ccy = Currency()
    qty = Decimal()
    some_money = SomeMoney()
    some_money.ccy = ccy
    some_money.qty = qty
    some_money.dov = Date()
    py_money = some_money
    py_money.ccy = Currency.USD
    py_money.qty = Decimal("1.0")
    py_money.dov = Date.CURRENT
    assert (some_money <= py_money == False)

    py_money.ccy = ccy
    assert (some_money <= py_money == True)
