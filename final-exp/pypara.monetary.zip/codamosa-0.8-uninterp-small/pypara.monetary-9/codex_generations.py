

# Generated at 2022-06-26 00:56:03.972365
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    money_0 = Price()
    money_0.with_qty(Decimal(str(1)))


# Generated at 2022-06-26 00:56:08.936159
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    ccy_0 = Currency("usd", "USD", 2)
    money_0 = Money()
    money_1 = Money()
    money_1 = money_0.with_ccy(ccy_0)
    print(money_1.ccy)
    print(money_1.dov)
    print(money_1.qty)


# Generated at 2022-06-26 00:56:09.944960
# Unit test for method __float__ of class Price
def test_Price___float__():
    pass # nothing to test


# Generated at 2022-06-26 00:56:11.164678
# Unit test for method gt of class Money
def test_Money_gt():
    # TODO: Add your test implementation here
    pass


# Generated at 2022-06-26 00:56:13.891693
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    price_0 = Price()
    price_1 = Price()
    price_2 = price_0.__floordiv__(price_1)


# Generated at 2022-06-26 00:56:21.040908
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    ccx_0 = Currency('EUR')
    dov_0 = Date(2017, 8, 27)
    qty_0 = Decimal('0.0')
    money_0 = Money.of(ccx_0, qty_0, dov_0)
    ccx_1 = Currency('AFN')
    qty_1 = Decimal('0')
    money_1 = Money.of(ccx_1, qty_1, dov_0)
    money_2 = money_0 - money_1
    assert isinstance(money_2, Money)


# Generated at 2022-06-26 00:56:22.953955
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert True

test_Money___ge__.unittest = ['.Money', 'Money.__ge__']


# Generated at 2022-06-26 00:56:32.570288
# Unit test for method __gt__ of class Money
def test_Money___gt__():

    # Arrange
    from .currencies import CURRENCY_CODES
    from .exchange import FXRateLookupError
    from .markup import Markup

    import unittest

    # Assert

# Generated at 2022-06-26 00:56:36.388127
# Unit test for method __int__ of class Price
def test_Price___int__():
    """
    Test the __int__ method of class Price
    """
    # Create an instance of class Price
    price = Price()
    # Assert that the result of the method __int__ is equal to None
    assert price.__int__() is None
    

# Generated at 2022-06-26 00:56:41.369100
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    ccy = Currency.USD
    qty = Decimal(10)
    dov = Date(1, 1, 2018)
    somePrice_instance = SomePrice(ccy, qty, dov)

    other = Decimal(2)
    result = somePrice_instance.__truediv__(other)
    assert result == SomePrice(ccy, qty / Decimal(other), dov)


# Generated at 2022-06-26 00:57:09.631980
# Unit test for method divide of class Money
def test_Money_divide():
    some_money_0 = SomeMoney(Currency.USD, Decimal('0.6'), Date('2020-12-11'))
    some_money_1 = SomeMoney(Currency.JPY, Decimal('0.2'), Date('2020-12-11'))
    try:
        some_money_0.divide(some_money_1)
        assert False
    except MonetaryOperationException:
        print("Passed test  Money_divide_0")
    try:
        some_money_1.divide(some_money_0)
        assert False
    except MonetaryOperationException:
        print("Passed test Money_divide_1")

# Generated at 2022-06-26 00:57:18.485914
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    result = SomeMoney(ccy=Currency.USD, qty=Decimal('1.00'), dov=Date(year=2020, month=1, day=1)).with_dov(dov=Date(year=2020, month=1, day=2))
    expected = SomeMoney(ccy=Currency.USD, qty=Decimal('1.00'), dov=Date(year=2020, month=1, day=2))
    assert result == expected


# Generated at 2022-06-26 00:57:21.591208
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert(abs(float(Money.of("USD", Decimal(1), Date.today())) - 1.0) <= 0.0001)


# Generated at 2022-06-26 00:57:26.293525
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Setup
    none_price_0 = NonePrice()
    date_0 = date(2014, 12, 28)

    # Invocation
    result = none_price_0.with_dov(date_0)

    # Verification
    assert result is none_price_0

    # Cleanup - none necessary



# Generated at 2022-06-26 00:57:39.757133
# Unit test for method divide of class Money
def test_Money_divide():
    print("test_Money_divide")
    # Testing divide when money is empty
    m0 = Money.of(None, None, None)
    print("m0: {}".format(m0))
    # Testing divide when money is empty and scalar quantity is empty
    m1 = m0.divide(None)
    print("m1: {}".format(m1))
    if m1 != Money.of(None, None, None):
        raise Exception("divide is failing")
    # Testing divide when money is empty and scalar quantity is zero
    m2 = m0.divide(0)
    print("m2: {}".format(m2))
    if m2 != Money.of(None, None, None):
        raise Exception("divide is failing")
    # Testing divide when money is empty and scalar quantity is not

# Generated at 2022-06-26 00:57:49.161295
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    none_money_0 = NoneMoney()
    none_money_1 = NoneMoney()
    none_money_2 = NoneMoney()
    none_money_3 = NoneMoney()
    none_money_4 = NoneMoney()
    none_money_5 = NoneMoney()
    none_money_6 = NoneMoney()
    none_money_7 = NoneMoney()
    none_money_8 = NoneMoney()
    none_money_9 = NoneMoney()
    none_money_10 = NoneMoney()
    none_money_11 = NoneMoney()
    none_money_12 = NoneMoney()
    none_money_13 = NoneMoney()
    none_money_14 = NoneMoney()
    none_money_15 = NoneMoney()
    none_money_16 = NoneMoney()
    none_money_17 = NoneMoney()
   

# Generated at 2022-06-26 00:57:57.226183
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    ccy = USD
    qty = Decimal(10)
    dov = date(2020, 5, 1)
    money_0 = SomeMoney(ccy, qty, dov)
    to = TRY
    asof = date(2020, 5, 1)
    strict = True
    # Test
    try:
        money_0.convert(to, asof, strict)
        assert False
    except FXRateLookupError as e:
        assert e.ccy1 == USD
        assert e.ccy2 == TRY
        assert e.asof == date(2020, 5, 1)


# Generated at 2022-06-26 00:58:07.028531
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    none_price_0 = NonePrice()
    money_0 = NoneMoney()
    price_0 = Price.of(Currency.USD, Decimal('7.30000'), Date(2016, 11, 30))
    assert not (price_0 == money_0)
    assert price_0 == price_0
    assert not (price_0 == none_price_0)
    price_1 = Price.of(Currency.USD, Decimal('4.40000'), Date(2016, 11, 30))
    assert price_1 == price_1
    assert not (none_price_0 == price_0)
    price_2 = Price.of(Currency.USD, Decimal('7.30000'), Date(2016, 11, 30))
    assert price_2 == price_2
    assert price_2 == price_0
    price_

# Generated at 2022-06-26 00:58:08.633593
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    none_price_0 = NonePrice()
    price_0 = Price.of(ccy=None, qty=None, dov=None)
    assert (none_price_0 == price_0)



# Generated at 2022-06-26 00:58:10.567873
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    testObject = Money
    assert_exception_thrown = None

    def test_case_0():
        testObject.__gt__()

    def test_case_1():
        assert True


# Generated at 2022-06-26 00:59:25.505116
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    """
    Unit tests for method with_dov of class Price
    """
    ccy = Currency.USD
    ccy2= Currency.EUR
    qty = Decimal(1)
    dov = Date(2017,1,1)
    dov2 = Date(2017,12,31)
    price = SomePrice(ccy,qty,dov)
    price2 = SomePrice(ccy,qty,dov2)
    assert price.ccy is ccy and price.qty == qty and price.dov == dov
    assert price2.ccy is ccy and price2.qty == qty and price2.dov == dov2
    assert price.with_dov(dov) == price
    assert price.with_dov(dov2) == price2
    assert price

# Generated at 2022-06-26 00:59:32.738038
# Unit test for method as_float of class Money
def test_Money_as_float():
    def test_case_0():
        money_0 = NoneMoney()
        try:
            test_case_0_var_0 = money_0.as_float()
            print('test_case_0 failed, an exception was raised')
        except MonetaryOperationException:
            pass
        else:
            print('test_case_0 failed, an exception was not raised')
    test_case_0()

    def test_case_1():
        currency_0 = Currency.of('EUR')
        money_0 = SomeMoney(currency_0, Decimal('123'), Date.today())
        test_case_1_var_0 = money_0.as_float()

# Generated at 2022-06-26 00:59:40.041469
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    mock_fx_rate_service_0 = Mock()
    FXRateService.default = mock_fx_rate_service_0
    Money.of(ccy=Currency('USD'), qty=Decimal('1'), dov=Date(year=2019, month=12, day=13)).convert(Currency('EUR'), asof=Date(year=2019, month=12, day=13), strict=False)
    mock_fx_rate_service_0.query.assert_called_once_with(ccy=Currency('USD'), to=Currency('EUR'), asof=Date(year=2019, month=12, day=13), strict=False)



# Generated at 2022-06-26 00:59:50.049178
# Unit test for method multiply of class Money
def test_Money_multiply():
    some_money_0 = SomeMoney(Currency.USD, Decimal('7'), Date.today())
    money_0 = some_money_0
    some_money_1 = SomeMoney(Currency.GBP, Decimal('4.5'), Date.today())
    money_1 = some_money_1
    some_money_2 = money_0.multiply(Decimal('9.9'))
    money_2 = some_money_2
    some_money_3 = money_1.multiply(Decimal('1'))
    money_3 = some_money_3
    some_money_4 = money_0.multiply(Decimal('8.5'))
    money_4 = some_money_4
    some_money_5 = money_1.multiply(Decimal('3'))

# Generated at 2022-06-26 01:00:02.450346
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    # Test with defined money
    money_0 = Money.of(Currency("EUR"), Decimal("1.1"), Date("2019-06-09"))
    money_1 = money_0.with_dov(Date("2020-06-09"))
    assert (money_1.dov == Date("2020-06-09"))
    assert (money_1.qty == Decimal("1.1"))
    assert (money_1.ccy == Currency("EUR"))
    # Test with undefined money
    money_2 = NoMoney.with_dov(Date("2020-06-09"))
    assert (money_2.dov == None)
    assert (money_2.qty == None)
    assert (money_2.ccy == None)


# Generated at 2022-06-26 01:00:06.316372
# Unit test for method gte of class Price
def test_Price_gte():
    ccy_0 = Currency.of("USD")
    price_0 = Price.of(ccy_0, Decimal("0"), None)
    assert price_0.gte(price_0)


# Generated at 2022-06-26 01:00:08.221957
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    none_price_0 = NonePrice()
    price_0 = none_price_0.positive()


# Generated at 2022-06-26 01:00:10.920565
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    none_price_0 = NonePrice()
    none_price_2 = NonePrice()
    none_price_1 = none_price_0.__eq__(none_price_2)


# Generated at 2022-06-26 01:00:21.272866
# Unit test for method gte of class Money
def test_Money_gte():
    money_0 = SomeMoney(Currency.USD, 1, Date.today())
    money_1 = SomeMoney(Currency.USD, 1, Date.today())
    money_2 = SomeMoney(Currency.USD, 2, Date.today())
    money_3 = SomeMoney(Currency.EUR, 1, Date.today())

    assert money_0.gte(money_0) == True
    assert money_0.gte(money_1) == True
    assert money_0.gte(money_2) == False
    assert money_0.gte(money_3) == False



# Generated at 2022-06-26 01:00:29.249338
# Unit test for method as_float of class Money
def test_Money_as_float():
    from .commons import Integer

    # test as_float for class NoneMoney
    none_money_0 = NoneMoney
    float_0 = none_money_0.as_float()
    if (not isinstance(float_0, float)):
        raise AssertionError
    assert float_0 == 0.0

    # test as_float for class SomeMoney
    some_money_0 = None
    some_money_0 = SomeMoney(Currency.USD, Decimal('1'), Date.today())
    float_0 = some_money_0.as_float()
    if (not isinstance(float_0, float)):
        raise AssertionError
    assert float_0 == 1.0
