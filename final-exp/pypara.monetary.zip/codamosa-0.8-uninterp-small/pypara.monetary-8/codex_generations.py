

# Generated at 2022-06-26 00:58:27.057305
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    assert SomePrice(Currency('CAD'), 1, None) >= NonePrice
    assert SomePrice(Currency('CAD'), 1, None) >= SomePrice(Currency('CAD'), 1, None)
    assert SomePrice(Currency('CAD'), 1, None) >= SomePrice(Currency('CAD'), 0.9, None)
    assert not (SomePrice(Currency('CAD'), 1, None) >= SomePrice(Currency('CAD'), 1.1, None))
    assert not (SomePrice(Currency('CAD'), 1, None) >= SomePrice(Currency('AUD'), 1, None))


# Generated at 2022-06-26 00:58:33.785513
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    ccy_A = Currency('A', 'AAA', Decimal(0.0001), Decimal(1))
    ccy_B = Currency('B', 'BBB', Decimal(0.0001), Decimal(1))
    ccy_C = Currency('C', 'CCC', Decimal(0.0001), Decimal(1))
    money_A_1 = SomeMoney(ccy_A, Decimal(100), date(2016, 6, 8))
    money_A_2 = SomeMoney(ccy_A, Decimal(100), date(2016, 6, 8))
    money_A_3 = SomeMoney(ccy_A, Decimal(101), date(2016, 6, 8))
    money_B_1 = SomeMoney(ccy_B, Decimal(200), date(2016, 6, 8))
    money_C

# Generated at 2022-06-26 00:58:38.167710
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    price_0 = Price.of(
        Currency.of('EUR'),
        Decimal('20.3210'),
        Date.now())
    date_0 = Date.of('2019-10-25')
    price_1 = price_0.with_dov(date_0)
    assert price_1.dov == date_0


# Generated at 2022-06-26 00:58:46.067332
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    ccy_0 = Ccy.get_instance("USD")
    qty_0 = Decimal(1)
    dov_0 = Date(0, 0, 0)
    qty_1 = Decimal(1)
    some_money_0 = SomeMoney(ccy_0, qty_0, dov_0)
    some_money_1 = some_money_0.__floordiv__(qty_1)
    assert some_money_1.qty == some_money_0.qty // qty_1
    assert some_money_1.with_dov(None).with_ccy(None).with_qty(None) == some_money_1.with_dov(None).with_ccy(None).with_qty(None)


# Generated at 2022-06-26 00:58:54.107295
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    # Create a Money instance called money_0 (currency: None, quantity: None, value date: None)
    # Create a Currency instance called ccy_0 (code: None, precision: None, base: None, decimal_point: None,
    # symbol: None, name: None)
    ccy_0 = Currency(None, None, None, None, None, None)
    # Create a Money instance called money_1 (currency: ccy_0, quantity: None, value date: None)
    money_1 = Money.of(ccy_0, None, None)
    # Create a Currency instance called ccy_1 (code: None, precision: None, base: None, decimal_point: None,
    # symbol: None, name: None)
    ccy_1 = Currency(None, None, None, None, None, None)
   

# Generated at 2022-06-26 00:58:57.238563
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    none_money = NoneMoney()
    date = Date(2020, 1, 1)

    money = none_money.with_dov(date)

    assert money.dov == date
    assert money.dov == Date(2020, 1, 1)


# Generated at 2022-06-26 00:58:59.731058
# Unit test for method as_float of class Price
def test_Price_as_float():
    price_0 = Price.of(Currency.USD, Decimal('2.0'), Date.now())
    float_0 = price_0.as_float()
    assert(isinstance(float_0, float))


# Generated at 2022-06-26 00:59:01.730305
# Unit test for method __le__ of class Money
def test_Money___le__():
    none_money_0 = NoneMoney()
    none_money_1 = NoneMoney()
    assert (NoneMoney().__le__(NoneMoney()) == True)


# Generated at 2022-06-26 00:59:05.910393
# Unit test for method __int__ of class Money
def test_Money___int__():
    # initialise a NoneMoney
    none_money_0 = NoneMoney()
    expected_result = 0
    # call the method
    result = none_money_0.__int__()
    assert result == expected_result, \
        'Result does not match the expected result.'


# Generated at 2022-06-26 00:59:11.086956
# Unit test for method negative of class Money
def test_Money_negative():
    # Test case 1
    test_money = Money(None, None, None)
    assert test_money.negative() == NoneMoney()
    # Test case 2
    test_money = Money("uSD", 25.3442, 20190603)
    assert test_money.negative() == Money("uSD", -25.3442, 20190603)


# Generated at 2022-06-26 00:59:40.420823
# Unit test for method gte of class Money
def test_Money_gte():
    none_money_0 = NoneMoney()
    some_money_0 = SomeMoney(Currency.USD, Decimal('0.0'), Date('2018-05-29'))
    some_money_1 = SomeMoney(Currency.USD, Decimal('-2.2'), Date('2014-08-11'))
    some_money_2 = SomeMoney(Currency.USD, Decimal('1.1'), Date('2018-05-29'))
    assert some_money_0.gte(some_money_1)
    assert some_money_2.gte(some_money_1)
    assert not none_money_0.gte(some_money_2)
    assert not some_money_1.gte(some_money_0)

# Generated at 2022-06-26 00:59:41.837594
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert Price.of(None, None, None).with_ccy(Currency.of('USD')).ccy == Currency.of('USD')


# Generated at 2022-06-26 00:59:51.120505
# Unit test for method __add__ of class Money
def test_Money___add__():
    print("Running test_Money___add__...")
    a_money_0 = Money.of(Currency("AUD"), Decimal("1.5"), Date("2018-08-19"))
    a_money_1 = a_money_0.negative()
    a_money_2 = a_money_0.add(a_money_1)
    assert a_money_2.qty == Decimal("0.0") and type(a_money_2.qty) is Decimal
    assert a_money_2.ccy == Currency("AUD") and type(a_money_2.ccy) is Currency
    assert a_money_2.dov == Date("2018-08-19") and type(a_money_2.dov) is Date
    assert not a_money_2.undefined
    assert a_money_

# Generated at 2022-06-26 01:00:00.525691
# Unit test for method subtract of class Money
def test_Money_subtract():
    ccy = Currency.parse_iso("USD")
    qty = Decimal(100)
    dov = Date.current()
    m = Money.of(ccy, qty, dov)
    other = Money.of(ccy, qty, dov)
    expected = Money.of(ccy, Decimal(0), dov)
    actual = m.subtract(other)
    assert actual.qty == expected.qty


# Generated at 2022-06-26 01:00:05.481266
# Unit test for method abs of class Money
def test_Money_abs():
    money = Money.of(Currency.USD, 100.00, Date(2020, 1, 1))
    assert money.abs().qty == 100.00



# Generated at 2022-06-26 01:00:14.757215
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert(SomePrice(Currency.USD,Decimal('1.0'),today()).is_equal(SomePrice(Currency.USD,Decimal('1.0'),today())))
    assert(not SomePrice(Currency.USD,Decimal('1.0'),today()).is_equal(SomePrice(Currency.USD,Decimal('2.0'),today())))
    assert(not SomePrice(Currency.USD,Decimal('1.0'),today()).is_equal(SomePrice(Currency.EUR,Decimal('1.0'),today())))
    assert(not SomePrice(Currency.USD,Decimal('1.0'),today()).is_equal(SomePrice(Currency.USD,Decimal('1.0'),today().add(1))))

# Generated at 2022-06-26 01:00:19.381860
# Unit test for method abs of class Money
def test_Money_abs():
    none_money_0 = NoneMoney()
    assert isinstance(none_money_0, Money) == True
    assert none_money_0.defined == False
    assert none_money_0.undefined == True
    # abs
    assert abs(none_money_0) == NoneMoney()


# Generated at 2022-06-26 01:00:22.666774
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Money.USD(10).divide(1.5).floor_divide(2) == Money.USD(3)
    assert Money.JPY(10).divide(1.3).floor_divide(2) == Money.JPY(1)

# Generated at 2022-06-26 01:00:31.586169
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    # Define a NoneMoney
    none_money_0 = NoneMoney()
    # Define a Money
    some_money_0 = SomeMoney(ccy=Currency(code='EUR'), qty=Decimal('0.0020'), dov=Date(year=2000, month=2, day=15))
    # Compare Money to Money
    assert (none_money_0.__eq__(some_money_0) == True)
    # Define a Money
    some_money_0 = SomeMoney(ccy=Currency(code='EUR'), qty=Decimal('1.0020'), dov=Date(year=2000, month=2, day=16))
    # Compare Money to Money
    assert (none_money_0.__eq__(some_money_0) == False)
    # Compare Money to int

# Generated at 2022-06-26 01:00:41.540048
# Unit test for method subtract of class Price
def test_Price_subtract():
    print("test_Price_subtract...")
    none_price_0 = NoPrice()
    none_price_1 = NoPrice()
    usd_price_0 = Price.of(USD, 50, datetime(year=1966, month=2, day=14))
    usd_price_1 = Price.of(USD, 10, datetime(year=1966, month=2, day=14))
    assertEqual(usd_price_1, (usd_price_0.add(Price.of(USD, -40, datetime(year=1966, month=2, day=14)))))
    assertEqual(usd_price_0, (usd_price_1.add(Price.of(USD, 40, datetime(year=1966, month=2, day=14)))))