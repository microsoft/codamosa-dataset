

# Generated at 2022-06-26 00:56:50.554013
# Unit test for method multiply of class Money
def test_Money_multiply():
    s_money = SomeMoney(Decimal(1))
    s_money2 = s_money.multiply(Decimal(1))
    assert s_money2.qty == Decimal(1)


# Generated at 2022-06-26 00:57:02.421426
# Unit test for method __le__ of class Price
def test_Price___le__():
    print("Starting test_Price___le__...")
    some_money_0 = SomeMoney.of(ccy = Currency.get("usd"), qty = Decimal("0"), dov = Date.of(2018, 7, 1))
    c_0 = Price.of(ccy = Currency.get("usd"), qty = Decimal("0"), dov = Date.of(2018, 7, 1))
    __DATETIME__ = datetime.datetime.now()
    some_money_1 = SomeMoney.of(ccy = Currency.get("usd"), qty = Decimal("0"), dov = Date.of(2018, 7, 1))
    c_1 = Price.of(ccy = Currency.get("usd"), qty = Decimal("0"), dov = Date.of(2018, 7, 1))

# Generated at 2022-06-26 00:57:12.244139
# Unit test for method gt of class Price
def test_Price_gt():
    some_price_0 = SomePrice()
    some_price_1 = SomePrice()
    some_price_2 = SomePrice()
    some_price_3 = SomePrice()
    some_price_1.dov = some_price_0.dov
    some_price_1.ccy = some_price_0.ccy
    some_price_2.dov = some_price_1.dov
    some_price_2.ccy = some_price_1.ccy
    some_price_3.dov = some_price_2.dov
    some_price_3.ccy = some_price_2.ccy
    some_price_0.qty = Decimal('10.00')
    some_price_1.qty = Decimal('9.00')
    some_price_

# Generated at 2022-06-26 00:57:15.829153
# Unit test for method add of class Money
def test_Money_add():
    m1 = Money.of(ccy = Currency.of("USD"), qty = Decimal("10"), dov = Date.today())
    m2 = Money.of(ccy = Currency.of("USD"), qty = Decimal("10"), dov = Date.today())
    m3 = m1.add(m2)
    m4 = m1.convert(to = Currency.of("EUR"), asof = Date.today(), strict = False)



# Generated at 2022-06-26 00:57:29.760327
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    '''
    Unit test for method __truediv__ of class Price
    '''

    # Define a custom money with USD currency and an amount of 10.
    some_money_0 = SomeMoney(Currency('USD'), Decimal(10), Date(2019, Month.January, 1))

    # Define a custom money with USD currency and an amount of 20.
    some_money_1 = SomeMoney(Currency('USD'), Decimal(20), Date(2019, Month.January, 1))

    # Define a custom money with USD currency and an amount of 0.5.
    some_money_2 = SomeMoney(Currency('USD'), Decimal(0.5), Date(2019, Month.January, 1))

    # Define a custom price with USD currency, 5 quantity and DOV of 2019-01-01
    some_price_0

# Generated at 2022-06-26 00:57:33.024525
# Unit test for method lt of class Money
def test_Money_lt():
    some_money_0 = SomeMoney()
    some_money_1 = SomeMoney()
    some_money_0.__lt__(some_money_1)


# Generated at 2022-06-26 00:57:40.737105
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    some_money_0 = SomeMoney(Currency.USD, Decimal(3.14), Date.today())
    some_money_1 = some_money_0.scalar_add(Decimal(1))
    assert some_money_1 == SomeMoney(Currency.USD, Decimal(4.14), Date.today())
    some_money_2 = some_money_0.scalar_add(1)
    assert some_money_2 == SomeMoney(Currency.USD, Decimal(4.14), Date.today())


# Generated at 2022-06-26 00:57:49.835014
# Unit test for method __float__ of class Price
def test_Price___float__():
    '''
    Tests for correct handling of case where no argument is passed.
    '''
    some_money_0 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_1 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_2 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_3 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_4 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_5 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_6 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_7 = SomeMoney(SomeCurrency(),SomeQuantity(),SomeDate())
    some_money_8 = SomeMoney

# Generated at 2022-06-26 00:57:53.914502
# Unit test for method divide of class Price
def test_Price_divide():
    some_money_0 = SomeMoney()
    some_money_1 = SomeMoney()
    some_money_2 = SomeMoney()

    some_money_0.divide(some_money_1)
    some_money_0.divide(some_money_2)
    assert(True)


# Generated at 2022-06-26 00:57:57.354998
# Unit test for method __int__ of class Price
def test_Price___int__():
    some_money_0 = SomeMoney.of(Currency.USD, Decimal("0.00"), Date(2018, 12, 5))
    assert int(some_money_0) == 0


# Generated at 2022-06-26 01:00:05.345473
# Unit test for method lt of class Price
def test_Price_lt():
    # tests for:
    # - comparison of defined/undefined prices.
    # - inappropriate comparison of defined prices.
    assert SomePrice(USD, Decimal('2.0'), Date(2000, 1, 1)).lt(NoPrice), "Method lt failed test 1"
    assert SomePrice(USD, Decimal('2.0'), Date(2000, 1, 1)).lt(SomePrice(USD, Decimal('2.0'), Date(2000, 1, 1))), "Method lt failed test 2"
    assert SomePrice(USD, Decimal('1.0'), Date(2000, 1, 1)).lt(SomePrice(USD, Decimal('2.0'), Date(2000, 1, 1))), "Method lt failed test 3"

# Generated at 2022-06-26 01:00:08.534083
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    some_price_003 = SomePrice()
    some_price_004 = SomePrice()
    result = (some_price_003 >= some_price_004)
    assert result == False


# Generated at 2022-06-26 01:00:09.533639
# Unit test for method add of class Price
def test_Price_add():
    pass


# Generated at 2022-06-26 01:00:12.673970
# Unit test for method __int__ of class Price
def test_Price___int__():
    # Setup:
    some_price = SomePrice()

    # Expectation:
    assert 1 == some_price.__int__()
    assert 1 == int(some_price)


# Generated at 2022-06-26 01:00:20.056408
# Unit test for method __add__ of class Price
def test_Price___add__():
    ccy_0 = SomeCurrency()
    qty_0 = Decimal()
    dov_0 = some_date_0 = SomeDate()

    price_0 = SomePrice(ccy_0, qty_0, dov_0)
    price_1 = SomePrice(ccy_0, qty_0, dov_0)
    result_1 = price_0 + price_1
    assert type(result_1) is SomePrice


# Generated at 2022-06-26 01:00:23.717366
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    some_money_0 = Money(Decimal("-0.10"), Currency("USD"), Date(2000, 1, 1))
    some_money_1 = Money(Decimal("-0.10"), Currency("USD"), Date(2000, 1, 1))
    assert some_money_0 >= some_money_1


# Generated at 2022-06-26 01:00:31.545820
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    some_price_0 = SomePrice()
    assert some_price_0.__ge__(some_price_0)
    # test that the expcetions raised during the execution of defaultPrice.__ge__(defaultPrice) are as expected
    try:
        some_price_0.__ge__(some_price_0)
        assert False
    except:
        assert True
    # test that the expcetions raised during the execution of Price.__ge__(defaultPrice) are as expected
    try:
        Price.__ge__(some_price_0, some_price_0)
        assert False
    except:
        assert True


# Generated at 2022-06-26 01:00:33.682751
# Unit test for method multiply of class Price
def test_Price_multiply():
    some_price_0 = SomePrice()
    some_price_0.multiply(float)


# Generated at 2022-06-26 01:00:37.831470
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Price.__floordiv__(Money(1),1) == Price(1)
    assert Price.__floordiv__(Money(1),2) == Price(1)
    assert Price.__floordiv__(Money(1),None) == NoneMoney()


# Generated at 2022-06-26 01:00:39.868582
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    x = Price()
    y = SomePrice()
    assert y.__floordiv__(x) is NoPrice



# Generated at 2022-06-26 01:01:28.432906
# Unit test for method multiply of class Money
def test_Money_multiply():
    money_0 = Money()
    money_0.multiply(money_1)


# Generated at 2022-06-26 01:01:35.654477
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    c0 = Currency('EUR')
    q0 = Decimal('5')
    d0 = Date.today()
    d1 = Date.today()
    d2 = Date.today()
    d3 = Date.today()
    c1 = Currency('EUR')
    q1 = Decimal('10')
    c2 = Currency('EUR')
    q2 = Decimal('10')
    c3 = Currency('USD')
    q3 = Decimal('10')
    price0 = SomePrice(c0, q0, d0)
    price1 = SomePrice(c1, q1, d1)
    price2 = SomePrice(c2, q2, d2)
    price3 = SomePrice(c3, q3, d3)

# Generated at 2022-06-26 01:01:38.973615
# Unit test for method positive of class Price
def test_Price_positive():
    global Price
    price_0 = Price()
    price_1 = NonePrice()
    price_1.positive()
    price_2 = SomeNonePrice()
    assert price_2.positive() == NoPrice
    price_2.positive()
    price_3 = NoneSomePrice()
    assert price_3.positive() == NoPrice
    price_3.positive()



# Generated at 2022-06-26 01:01:41.666057
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    """
    Purpose: Test for the method with_qty of the class Price
    """
    price_0 = Price.of(USD, Decimal(), None)
    price_1 = (price_0.with_qty(Decimal(1)))
    assert(price_1.ccy == USD and price_1.qty == Decimal(1) and price_1.dov == None)

