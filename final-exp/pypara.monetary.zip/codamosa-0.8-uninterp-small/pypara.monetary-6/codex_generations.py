

# Generated at 2022-06-26 00:55:07.177290
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    assert SomeMoney(Currency.US_DOLLAR, 0, date(2019, 4, 9)) / 0 == NoMoney
    assert SomeMoney(Currency.US_DOLLAR, 1, date(2019, 4, 9)) / 0 == NoMoney
    assert SomeMoney(Currency.US_DOLLAR, 2, date(2019, 4, 9)) / 0 == NoMoney
    assert SomeMoney(Currency.US_DOLLAR, 3, date(2019, 4, 9)) / 0 == NoMoney
    assert SomeMoney(Currency.US_DOLLAR, 4, date(2019, 4, 9)) / 0 == NoMoney
    assert SomeMoney(Currency.US_DOLLAR, 5, date(2019, 4, 9)) / 0 == NoMoney

# Generated at 2022-06-26 00:55:08.450699
# Unit test for method gt of class Price
def test_Price_gt():
    pass


# Generated at 2022-06-26 00:55:18.225300
# Unit test for method divide of class Price
def test_Price_divide():
    # SomePrice
    price_0_ccy_0 = Currency()
    price_0_qty_0 = Decimal()
    price_0_dov_0 = Date()
    price_0 = SomePrice(price_0_ccy_0, price_0_qty_0, price_0_dov_0)
    # Decimal
    decimal_0 = Decimal()
    assert(type(price_0.divide(decimal_0)) == type(SomePrice(None, Decimal(), None)))
    # For coverage
    print(NoneMoney.divide(decimal_0))
    # For coverage
    print(NoPrice.divide(decimal_0))


# Generated at 2022-06-26 00:55:24.482536
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    date_0 = module_0.datetime()
    date_1 = module_0.datetime()
    price_0 = Price(Money(2, 3), date_0)
    price_1 = Price(Money(2, 3), date_1)
    price_2 = price_0.add(price_1)
    assert price_2.value.amount == 4
    assert price_2.value.currency.code == "EUR"
    assert price_2.value_date == date_1


# Generated at 2022-06-26 00:55:26.885886
# Unit test for method lte of class Price
def test_Price_lte():
    # Test case 1
    assert NoPrice.lte(module_0) == True


# Generated at 2022-06-26 00:55:35.881127
# Unit test for method abs of class Money
def test_Money_abs():
    date_1 = module_0.date(2019, 7, 1)
    date_2 = module_0.date(2020, 1, 2)
    date_3 = module_0.date(2019, 2, 1)
    date_4 = module_0.date(2020, 11, 1)
    date_5 = module_0.date(2019, 2, 16)
    date_6 = module_0.date(2021, 1, 1)
    date_7 = module_0.date(2019, 9, 1)
    date_8 = module_0.date(2019, 8, 1)
    date_9 = module_0.date(2021, 6, 1)
    date_10 = module_0.date(2022, 7, 1)

# Generated at 2022-06-26 00:55:41.695251
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    def check(ccy, ccy_expected):
        price = Price(ccy, Decimal('123'), Date(2012, 12, 21))
        assert price.with_ccy(ccy_expected) == Price(ccy_expected, Decimal('123'), Date(2012, 12, 21))
    yield check, Currency('USD'), Currency('USD')
    yield check, NoCurrency, NoCurrency


# Generated at 2022-06-26 00:55:47.785635
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():

    price_0 = Price.of(Currency.EUR, Decimal('0.0050'), date_0)
    price_1 = price_0 / Decimal('0.0050')
    assert_equal(price_1.ccy, Currency.EUR)
    assert_equal(price_1.qty, Decimal('1.00'))
    assert_equal(price_1.dov, date_0)
    pass




# Generated at 2022-06-26 00:55:48.747221
# Unit test for method __lt__ of class Price
def test_Price___lt__():
  pass # Skipped


# Generated at 2022-06-26 00:55:50.060381
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    qty_0 = Decimal()
    price_0 = SomePrice(Currency.USD, qty_0, Date.today())


# Generated at 2022-06-26 00:56:19.457087
# Unit test for method subtract of class Money
def test_Money_subtract():
    price_0 = SomePrice(Currency.USD, Decimal("1"), Date.today())
    price_1 = SomePrice(Currency.USD, Decimal("10.000000"), Date.today())
    price_2 = SomePrice(Currency.USD, Decimal("199.999999"), Date.today())
    price_3 = SomePrice(Currency.USD, Decimal("10.000001"), Date.today())
    price_4 = SomePrice(Currency.USD, Decimal("100.0"), Date.today())
    price_5 = SomePrice(Currency.USD, Decimal("10.0"), Date.today())
    price_6 = SomePrice(Currency.USD, Decimal("20.0"), Date.today())
    price_7 = SomePrice(Currency.USD, Decimal("50.0"), Date.today())

# Generated at 2022-06-26 00:56:22.223056
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    # Money
    none_money_1 = NoneMoney()
    none_money_2 = NoneMoney()
    assert none_money_1 == none_money_2
    none_money_3 = non


# Generated at 2022-06-26 00:56:31.825857
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    # Test with defined money (returns SomeMoney instance)
    defined_money_0 = SomeMoney('EUR', 5, '2020-01-01 12:34:56.000000')
    some_money_0 = defined_money_0.floor_divide(2)
    assert some_money_0.ccy == 'EUR'
    assert some_money_0.qty == 2
    assert some_money_0.dov == '2020-01-01 12:34:56.000000'
    # Test with undefined money (returns NoMoney instance)
    undefined_money_0 = NoMoney
    no_money_0 = undefined_money_0.floor_divide(2)
    assert no_money_0.ccy == None
    assert no_money_0.qty == None

# Generated at 2022-06-26 00:56:41.289210
# Unit test for method round of class Money
def test_Money_round():
    class Money_1(Money):
        def __init__(self, ccy: Currency, qty: Decimal, dov: Date):
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

    def round_aux(money_0, ndigits):
        return money_0.round(ndigits)

    # Initializing for testing
    money_0 = Money_1(Currency.JPY, Decimal(1.1), Date(2020, 1, 1))

    #  Testing round
    money_0 = round_aux(money_0, 1)
    assert money_0.ccy == Currency.JPY and money_0.qty == Decimal(1.1) and money_0.dov == Date(2020, 1, 1)


# Generated at 2022-06-26 00:56:45.891627
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    someMoney_0 = SomeMoney(USD, Decimal('1E+1'), date(1970, 1, 1))
    date_0 = date(1970, 1, 1)
    someMoney_1 = someMoney_0.with_dov(date_0)
    assert someMoney_1 == someMoney_0


# Generated at 2022-06-26 00:56:55.292605
# Unit test for method gt of class Price
def test_Price_gt():
    none_price_0 = NonePrice()
    none_price_1 = NonePrice()
    assert not none_price_0.gt(none_price_1)
    price_0 = NonePrice()
    price_1 = Price.of(USD, Decimal('3.0'), Date(year=1, month=1, day=1))
    assert not price_0.gt(price_1)
    price_0 = Price.of(USD, Decimal('3.0'), Date(year=1, month=1, day=1))
    price_1 = Price.of(USD, Decimal('3.0'), Date(year=1, month=1, day=1))
    assert not price_0.gt(price_1)

# Generated at 2022-06-26 00:56:56.573988
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    pass
test_Money_floor_divide()



# Generated at 2022-06-26 00:57:09.310306
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    x = Price.of(USD, 10, None)
    y = x.scalar_add(5)
    assert y.qty == Decimal(15)
    assert y.ccy == USD
    assert y.dov == None

    z = Price.of(CAD, 2, None)
    y = z.scalar_add(5)
    assert y.qty == Decimal(7)
    assert y.ccy == CAD
    assert y.dov == None

    x = Price.of(None, 10, None)
    y = x.scalar_add(5)
    assert y.qty == None
    assert y.ccy == None
    assert y.dov == None

    x = Price.of(USD, None, None)

# Generated at 2022-06-26 00:57:12.508286
# Unit test for method as_float of class Money
def test_Money_as_float():
    # Arrange
    price_0 = NonePrice()
    
    # Act
    try:
        price_0.as_float()
    except:
        err = sys.exc_info()[0]
        print( "type error: " + str(err)) 



# Generated at 2022-06-26 00:57:22.734441
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ccy_0 = Currency(CurrencyType.UAH, Decimal('1.00'))
    qty_0 = Decimal('0.001')
    dov_0 = Date(year = 1999, month = 11, day = 1)
    some_price_0 = SomePrice(ccy = ccy_0, qty = qty_0, dov = dov_0)
    strict = False
    to = Currency(CurrencyType.CNY, Decimal('0.15'))
    asof = Date(year = 2000, month = 12, day = 2)
    result_0 = some_price_0.convert(to = to, asof = asof, strict = strict)

    assert(result_0.ccy.ccy_type == CurrencyType.CNY)

# Generated at 2022-06-26 00:59:46.129372
# Unit test for method __bool__ of class Price
def test_Price___bool__():

    # Test cases

    # Test case #0
    none_price_0 = NonePrice()
    condition_0 = none_price_0.as_boolean()
    assert condition_0


# Generated at 2022-06-26 00:59:52.042392
# Unit test for method as_float of class Price
def test_Price_as_float():
    # Test case 0
    print('Test case 0')
    none_price_0 = NonePrice()
    price_0 = none_price_0.positive()
    float_0 = none_price_0.as_float()
    assert float_0 is float_0
    # Test case 1
    print('Test case 1')
    usd = Currency.of('USD')
    today = Date.today()
    money_0 = Money.of(1.5, usd, today)
    price_0 = Price.of(usd, 2.5, today)
    float_0 = price_0.as_float()
    assert float_0 is float_0
    # Test case 2
    print('Test case 2')
    usd = Currency.of('USD')
    today = Date.today()

# Generated at 2022-06-26 01:00:01.015522
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    x = SomeMoney(Currency.USD, Decimal(5), Date.now())
    y = SomeMoney(Currency.USD, Decimal(0), Date.now())
    z = SomeMoney(Currency.USD, Decimal(-5), Date.now())

    assert x.as_boolean()
    assert not y.as_boolean()
    assert not z.as_boolean()

    assert bool(x)
    assert not bool(y)
    assert not bool(z)


# Generated at 2022-06-26 01:00:09.408817
# Unit test for method subtract of class Money
def test_Money_subtract():
    import currencies as cur
    import dates as dts
    ccys = cur.CurrencySet.of('EUR USD JPY')
    date_0 = dts.external_date(2017, 12, 31)
    money_0 = SomeMoney(ccys.eur, Decimal(1.5), date_0)
    money_1 = NoneMoney()
    money_2 = money_0.subtract(money_0)
    money_3 = money_0.subtract(money_1)


# Generated at 2022-06-26 01:00:16.874466
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    none_money_0 = NoneMoney()
    price_0 = NonePrice()

    try:
        none_money_0.__ge__(price_0)
        exception_raised_0 = False
    except MonetaryOperationException:
        exception_raised_0 = True

    try:
        none_money_0.__ge__(NoneMoney())
        exception_raised_1 = False
    except MonetaryOperationException:
        exception_raised_1 = True

    if (NoneMoney().__ge__(price_0)):
        test_0 = False
    
    if (not exception_raised_0):
        test_1 = True
    
    if (not exception_raised_1):
        test_2 = True
    
    if ((not exception_raised_0) and (not exception_raised_1)):
        test_3

# Generated at 2022-06-26 01:00:21.050854
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    price_0 = Price(Money('USD', 1))
    price_1 = Price(Money('USD', 1))
    price_2 = price_0.__sub__(price_1)
    assert(price_2 == Price(Money('USD', 0)))


# Generated at 2022-06-26 01:00:23.979025
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    money_0 = Money((Currency, Currency()), (Decimal, Decimal('0.0')), (Date, Date()))
    money_1 = money_0.positive()
    assert isinstance(money_1, Money)


# Generated at 2022-06-26 01:00:26.937171
# Unit test for method lt of class Money
def test_Money_lt():
    none_price_0 = NonePrice()
    price_0 = none_price_0.positive()
    bool_0 = none_price_0.lt(price_0)


# Generated at 2022-06-26 01:00:28.600795
# Unit test for method convert of class Price
def test_Price_convert():
    price_0 = NonePrice()
    price_0.convert(EUR)


# Generated at 2022-06-26 01:00:33.879072
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    qty_0 = SomeMoney.of(
        None,
        Decimal('0.0'),
        None
    )
    qty_1 = SomeMoney.of(
        None,
        Decimal('0.0'),
        None
    )
    qty_2 = qty_0.subtract(qty_1)
    assert qty_2.as_float() == 0.0
