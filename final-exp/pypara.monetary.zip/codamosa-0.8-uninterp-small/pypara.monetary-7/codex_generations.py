

# Generated at 2022-06-26 00:57:14.484261
# Unit test for method multiply of class Money
def test_Money_multiply(): 
    foo = SomeMoney(Currency.USD, 1.0, Date.today()) # Line 1 
    assert foo.multiply(10.0)  == SomeMoney(Currency.USD, 10.0, Date.today())  # Line 2 
    assert foo.multiply(-1.0)  == SomeMoney(Currency.USD, -1.0, Date.today())  # Line 3 
    assert foo.multiply(0.0)  == SomeMoney(Currency.USD, 0.0, Date.today())  # Line 4 


# Generated at 2022-06-26 00:57:20.174027
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    m = SomeMoney(Currency('USD'), Decimal(1), Date(2019, 12, 12))
    print(m.with_dov(Date(1,1,1)))
    assert m.with_dov(Date(1,1,1)) == NoMoney
    print(type(m.with_dov(Date(1,1,1))))


# Generated at 2022-06-26 00:57:24.518148
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    NonePrice.__lt__
    #AllTests.assertTrue(NonePrice() < SomeMoney(Currency('USD'), Decimal('101'), Date(2020, 1, 1)))
    #AllTests.assertFalse(SomeMoney(Currency('USD'), Decimal('101'), Date(2020, 1, 1)) < NonePrice())


# Generated at 2022-06-26 00:57:38.482589
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    """Tests that NonePrice class is less than or equal to every price objects"""
    some_price_0 = SomePrice(ccy=Currency('USD'), qty=Decimal('10'), dov=Date(2011, 1, 18))
    is_true_0 = some_price_0 <= some_price_0
    is_true_1 = some_price_0 <= SomePrice(ccy=Currency('USD'), qty=Decimal('10'), dov=Date(2011, 1, 18))
    is_true_2 = some_price_0 <= SomePrice(ccy=Currency('GBP'), qty=Decimal('10'), dov=Date(2011, 1, 18))

# Generated at 2022-06-26 00:57:48.875142
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    from datetime import date
    from py_algo_ds import Money

    price = Price.of(Currency.USD, Decimal("10.00"), date(2019, 7, 18))
    price2 = Price.of(Currency.USD, Decimal("10.00"), date(2019, 7, 19))

    assert price.with_dov(date(2019, 7, 1)) == Price.of(Currency.USD, Decimal("10.00"), date(2019, 7, 1))
    assert price.with_dov(date(2019, 7, 18)) == Price.of(Currency.USD, Decimal("10.00"), date(2019, 7, 18))

# Generated at 2022-06-26 00:57:58.544907
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    from dataclasses import dataclass

    from dataclasses import dataclass

    @dataclass
    class Mock:
        def __init__(self):
            self.quantizer = Decimal(100)
            self.decimals = 2
        def quantize(self, qty):
            return qty

    @dataclass
    class Mock_0:
        def __init__(self):
            self.quantizer = Decimal(100)
            self.decimals = 2
        def quantize(self, qty):
            return qty

    @dataclass
    class Mock_1:
        def __init__(self):
            self.quantizer = Decimal(100)
            self.decimals = 2
        def quantize(self, qty):
            return qty


# Generated at 2022-06-26 00:58:07.028114
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    # Instance of class Price:
    # Method args:
    #   other: Any
    # Method return type:
    #   Price
    # Instance attributes/properties of class Price:
    #   ccy: Optional[Currency]
    #   dov: Optional[Date]
    #   qty: Optional[Decimal]
    #   defined: bool
    #   undefined: bool

    # Test 0:
    none_price_0 = NonePrice()
    none_price_0__floordiv__ = none_price_0.__floordiv__(0)
    assert isinstance(none_price_0__floordiv__, NonePrice)



# Generated at 2022-06-26 00:58:10.826702
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    sut = Money()
    result = sut.__mul__(None)
    assert isinstance(result, Money)
    assert result == Money
    assert id(result) != id(sut)

    result = sut.__mul__(3)
    assert isinstance(result, Money)
    assert result == Money



# Generated at 2022-06-26 00:58:19.564789
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    ccy = CurrencyService.default.get_currency("USD")
    qty = Decimal(10)
    dov = Date(2017, 1, 1)
    some_money = SomeMoney(ccy, qty, dov)
    new_dov = Date(2017, 1, 2)
    some_money_with_dov = some_money.with_dov(new_dov)
    assert some_money_with_dov.ccy == some_money.ccy
    assert some_money_with_dov.qty == some_money.qty
    assert some_money_with_dov.dov == new_dov
    assert some_money_with_dov.dov != some_money.dov


# Generated at 2022-06-26 00:58:25.825856
# Unit test for method gt of class Money
def test_Money_gt():
    m1 = SomeMoney(Currency.USD, Decimal(25.0), Date.today())
    m2 = SomeMoney(Currency.USD, Decimal(25.0), Date.today())
    m3 = SomeMoney(Currency.USD, Decimal(15.0), Date.today())

    assert not m1.gt(m2)
    assert m1.gt(m3)
    assert not m3.gt(m2)


# Generated at 2022-06-26 00:58:53.136870
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    class Price(object):
        def __init__(self, ccy, qty, dov):
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

        def positive(self):
            return self

    a = Price("USD", "100.00", datetime.date(2019, 1, 1))

    if a.qty == "100.00":
        pass
    else:
        raise AssertionError

    b = a.positive()
    c = a.__pos__()

    if (b.qty == "100.00") and (b.qty == c.qty):
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 00:58:56.003961
# Unit test for method __gt__ of class Price
def test_Price___gt__():

    none_price_0 = NonePrice()
    assert not none_price_0.__gt__(NonePrice())
    assert not none_price_0.__gt__(SomePrice(EUR, "0", Date.today()))


# Generated at 2022-06-26 00:59:01.038786
# Unit test for method divide of class Money
def test_Money_divide():

    from .exchange import FXRateLookupError

    money1 = Money.of(Currency.USD, 1, Date.today())
    assert money1.divide(2) == Money.of(Currency.USD, 0.5, Date.today())
    assert money1.divide(2.0) == Money.of(Currency.USD, 0.5, Date.today())
    assert money1.divide(Decimal(2)) == Money.of(Currency.USD, 0.5, Date.today())



# Generated at 2022-06-26 00:59:05.174465
# Unit test for method add of class Money
def test_Money_add():
    # Operation Money.add
    print("Running test_Money_add")
    none_price = NonePrice()
    price = NonePrice().positive()
    none_price.add(price)
    none_price.add(none_price)
    price.add(none_price)
    price.add(price)



# Generated at 2022-06-26 00:59:12.005023
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Return type for method with_dov of class Price
    assert isinstance(Price.NA.with_dov(Date.today()), Price)

    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_dov(Date.today().add(years=1)) == Price.of(Currency.USD, Decimal(1), Date.today().add(years=1))

    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_dov(None) == NoPrice


# Generated at 2022-06-26 00:59:16.858256
# Unit test for method times of class Price
def test_Price_times():
    ccy_0 = Currency('CAD')
    ccy_1 = Currency('CAD')
    qty_0 = Decimal(0)
    dov_0 = Date(0, 0, 0)
    price_0 = SomePrice(ccy_0, qty_0, dov_0)
    qty_1 = Decimal(0)
    price_1 = SomePrice(ccy_1, qty_1, dov_0)
    integer_0 = price_0.times(price_1)


# Generated at 2022-06-26 00:59:25.823298
# Unit test for method __float__ of class Price
def test_Price___float__():
    none_price_0 = NonePrice()
    #test_raise_exception(none_price_0)
    #test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()
    #test_case_4()
    #test_case_5()
    #test_case_6()
    #test_case_7()
    #test_case_8()
    #test_case_9()
    #test_case_10()
    #test_case_11()
    #test_case_12()
    #test_case_13()
    #test_case_14()
    #test_case_15()
    #test_case_16()
    #test_case_17()
    #test_case_18()
   

# Generated at 2022-06-26 00:59:29.667772
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    print('test_Price_as_boolean')
    price_0 = NonePrice()
    price_1 = SomePrice(ccy=Currency.USD, qty=Decimal('10.00'), dov=Date.today())
    assert (price_1.as_boolean() == True)
    assert (price_0.as_boolean() == False)


# Generated at 2022-06-26 00:59:36.312483
# Unit test for method gte of class Money
def test_Money_gte():
    m0 = Money.of(Currency.USD, 0, Date.today())
    c0 = Currency.USD
    q0 = Decimal(0)
    d0 = Date.today()
    m1 = Money.of(c0, q0, d0)
    assert(m0.gte(m1))


# Generated at 2022-06-26 00:59:39.669014
# Unit test for method convert of class Price
def test_Price_convert():
    price_0 = Price.of(Currency.USD, Decimal(6.0), Date(2018, 10, 31))
    currency = Currency.of('USD')
    price_0 = price_0.convert(currency)
    price_0 = price_0.convert(Currency.USD)
