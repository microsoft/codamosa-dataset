

# Generated at 2022-06-26 00:55:23.889987
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert noMoney.as_boolean() is False
    assert noneMoney.as_boolean() is False
    assert SomeMoney(USD, 0.0, Date.today()).as_boolean() is False
    assert SomeMoney(USD, 10.0, Date.today()).as_boolean() is True


# Generated at 2022-06-26 00:55:27.065865
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    aSomeMoney = SomeMoney()
    aSomeMoney.__ge__()
    assert False # TODO: implement your test here


# Generated at 2022-06-26 00:55:35.453839
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    some_money = SomeMoney()
    some_money_1 = some_money.__pos__()
    assert some_money_1.qty == some_money.qty and some_money_1.ccy == some_money.ccy and some_money_1.dov == some_money.dov
    some_money2 = SomeMoney(Currency('USD'),10, Date(2018,7,8))
    some_money2_1 = some_money2.__pos__()
    assert some_money2_1.qty == some_money2.qty and some_money2_1.ccy == some_money2.ccy and some_money2_1.dov == some_money2.dov


# Generated at 2022-06-26 00:55:38.456197
# Unit test for method as_float of class Price
def test_Price_as_float():
    # GIVEN
    some_price = SomePrice()
    # WHEN
    actual = some_price.as_float()
    # THEN
    assert actual == 1.0


# Generated at 2022-06-26 00:55:41.201900
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    some_money_0 = SomeMoney()
    assert some_money_0.__neg__().qty == -1.1



# Generated at 2022-06-26 00:55:42.108731
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    ...


# Generated at 2022-06-26 00:55:52.879348
# Unit test for method convert of class Money
def test_Money_convert():
    # Test 0
    ccy_0 = Currency.USD
    qty_0 = Decimal('11.000000000000000')
    dov_0 = Date.today(ccy_0)
    m_0 = SomeMoney(ccy_0, qty_0, dov_0)
    to_0 = Currency.TRY
    asof_0 = Date.today(to_0)
    strict_0 = True
    expected_0 = NoMoney
    actual_0 = m_0.convert(to_0, asof_0, strict_0)
    assert actual_0 == expected_0

    # Test 1
    ccy_1 = Currency.USD
    qty_1 = Decimal('11.000000000000000')
    dov_1 = Date.today(ccy_1)

# Generated at 2022-06-26 00:55:57.485770
# Unit test for method as_float of class Money
def test_Money_as_float():
    ccy = 'USD'
    qty = Decimal(10.5)
    exp_val = 10.5
    money = SomeMoney(Currency.of(ccy), qty)
    res_val = money.as_float()
    assert res_val == exp_val


# Generated at 2022-06-26 00:56:01.431352
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    some_money_0 = SomeMoney()
    money_0 = Money.of(Currency.USD, 1.00, Date.today())
    price_0 = Price.of(Currency.USD, 1.00, Date.today())
    assert price_0 != money_0
    assert money_0 == money_0
    assert money_0 != price_0
    assert not price_0 < some_money_0
    assert not some_money_0 <= money_0
    assert not some_money_0 > price_0
    assert not some_money_0 >= money_0



# Generated at 2022-06-26 00:56:11.325043
# Unit test for method multiply of class Money
def test_Money_multiply():
    import math
    import datetime

    from .currencies import Currency
    from .exchange.fxserviceprovider import FxServiceProvider
    from .exchange.fxratelookup import FXRateLookup
    from .exchange.fxmemory import FxMemory
    from .exchange.fxsqlite import FxSqlite
    from .money import *
    from .commons.numbers import Numeric
    import time
    import sys


    # Test case: 1
    assert some_price_0.multiply(Decimal(-5)).ccy.code == 'USD'
    assert some_price_0.multiply(Decimal(-5)).qty == -5.00

    # Test case: 2
    assert some_price_0.multiply(Decimal(5)).ccy.code == 'USD'