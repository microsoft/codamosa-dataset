

# Generated at 2022-06-26 00:58:30.113804
# Unit test for method abs of class Money
def test_Money_abs():
    # instance of NonePrice
    none_price_0 = NonePrice()
    # Expecting a result of type Money
    assert isinstance(none_price_0.abs(), Money)
    # instance of SomePrice
    some_price_0 = SomePrice("C1", Decimal("2.5240"), Date(2020, 4, 6))
    assert some_price_0.abs() == some_price_0


# Generated at 2022-06-26 00:58:33.762369
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    Money.NA.scalar_subtract(1)
    Money.NA.scalar_subtract(float('inf'))
    Money.NA.scalar_subtract(float('nan'))
    Money.NA.scalar_subtract(Decimal('inf'))
    Money.NA.scalar_subtract(Decimal('nan'))
    Money.NA.scalar_subtract(complex(1, 2))



# Generated at 2022-06-26 00:58:36.537035
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    price = Price(currency, quantity, dov)
    date = date
    new_price = price.with_dov(date)
    assert new_price.dov == date


# Generated at 2022-06-26 00:58:44.496014
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    # Local variables
    var_0: Price
    var_1: Price
    var_2: Price
    var_3: Currency
    var_4: Price
    var_5: Price
    var_6: Price
    var_7: Price
    var_8: Price
    var_9: Price

    var_0 = Price.of(var_3, Decimal('0'), Date(1, 1, 1))
    var_0 = var_0.with_dov(Date(1, 1, 1))
    var_1 = Price.of(var_3, Decimal('0'), Date(1, 1, 1))
    var_2 = var_0.gte(var_1)
    var_0 = Price.of(var_3, Decimal('0'), Date(1, 1, 1))
    var_

# Generated at 2022-06-26 00:58:52.621183
# Unit test for method lte of class Money
def test_Money_lte():
    # Test Case 1 (Expected: Undefined Money is always less than 
    # or equal to the defined money)
    some_money_0 = SomeMoney(Currency("EUR"), Decimal(21.0), Date.today())
    test_1_result = NoMoney.lte(some_money_0)
    # Test Case 2 (Expected: IncompatibleCurrency Error should be raised when 
    # comparing two defined money objects with different currencies)
    some_money_1 = SomeMoney(Currency("USD"), Decimal(21.0), Date.today())
    try:
        test_2_result = (some_money_0).lte((some_money_1))
        raise AssertionError("Error: IncompatibleCurrencyException is expected for Test Case 2")
    except IncompatibleCurrencyError:
        pass
    #

# Generated at 2022-06-26 00:58:59.272250
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    """
    Description:
        Test __ge__ method of class Money
    """
    # ---------- Test Case 0 ---------- #
    some_price_0 = SomePrice(Currency.USD, Decimal('10.0'), Date.today())
    some_price_1 = SomePrice(Currency.USD, Decimal('20.0'), Date.today())
    money_0 = some_price_1.money
    expected_result_0 = some_price_1.__ge__(some_price_0)
    observed_result_0 = money_0.__ge__(some_price_0)
    assert expected_result_0 == observed_result_0


# Generated at 2022-06-26 00:59:08.771318
# Unit test for method abs of class Money
def test_Money_abs():
    s = SomeMoney(Currency.USD, Decimal('3.555'), Date())
    assert s.abs() == SomeMoney(Currency.USD, Decimal('3.555'), Date())
    assert (-s).abs() == SomeMoney(Currency.USD, Decimal('3.555'), Date())
    assert (s + s).abs() == SomeMoney(Currency.USD, Decimal('7.11'), Date())
    assert (s - s).abs() == SomeMoney(Currency.USD, Decimal('0'), Date())
    assert (s * 3).abs() == SomeMoney(Currency.USD, Decimal('10.665'), Date())
    assert (s / 3).abs() == SomeMoney(Currency.USD, Decimal('1.185'), Date())

# Generated at 2022-06-26 00:59:16.177186
# Unit test for method lt of class Money
def test_Money_lt():
    """
    Tests lt method of Money class
    """
    m0 = SomeMoney(Currency("CHF"), Decimal(100), Date(2018, 10, 1)) # Constructor for SomeMoney
    m1 = SomeMoney(Currency("CHF"), Decimal(100), Date(2018, 10, 1)) # Constructor for SomeMoney
    m2 = SomeMoney(Currency("CHF"), Decimal(50), Date(2018, 10, 1)) # Constructor for SomeMoney
    m3 = NoneMoney() # Constructor for NoneMoney

    # Test 1
    assert m0.lt(m1) == False, 'Test 1 Failed'

    # Test 2
    assert m2.lt(m1) == True, 'Test 2 Failed'

    # Test 3
    assert m0.lt(m3) == False, 'Test 3 Failed'

# Generated at 2022-06-26 00:59:21.542596
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    assert NoneMoney.with_dov(Date.today()) == NoneMoney
    assert (SomeMoney(None, Decimal("10"), None).with_dov(Date.today()) == NoneMoney)
    assert (SomeMoney(None, None, None).with_dov(Date.today()) == NoneMoney)
    assert (SomeMoney(None, Decimal("10"), None).with_dov(Date.today()+1) == NoneMoney)
    assert (SomeMoney(None, None, None).with_dov(Date.today()+1) == NoneMoney)
    assert NoneMoney.with_dov(Date.today()+1) == NoneMoney

# Generated at 2022-06-26 00:59:28.011374
# Unit test for method lte of class Money
def test_Money_lte():
    # used for later testing
    some_price_0 = SomePrice(Currency.EUR, Decimal("100.00"))
    some_price_1 = SomePrice.of(Currency.USD, "100.00", Date.today())
    # used for later testing
    string_0 = repr(some_price_1)
    # used for later testing
    some_price_2 = SomePrice(Currency.USD, Decimal(str(123.123)))
    # used for later testing
    some_price_3 = SomePrice(Currency.USD, Decimal("0.0"))
    # used for later testing
    some_price_4 = SomePrice(Currency.USD, Decimal(str(123.123)))
    # used for later testing

# Generated at 2022-06-26 01:00:55.339350
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    # Case 0
    none_money_0 = NoneMoney()
    none_money_1 = NoneMoney()
    none_money_0.__ge__(none_money_1)

    # Case 1
    none_money_2 = NoneMoney()
    some_money_0 = SomeMoney(Currency("USD"), 2.0, Date.today())
    none_money_2.__ge__(some_money_0)

    # Case 2
    some_money_1 = SomeMoney(Currency("USD"), 3.0, Date.today())
    some_money_2 = SomeMoney(Currency("JPY"), 1.0, Date.today())
    some_money_1.__ge__(some_money_2)



# Generated at 2022-06-26 01:01:02.632271
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    some_money_0 = SomeMoney()
    some_money_1 = Money.of()
    assert some_money_0.with_qty(some_money_0.qty) == some_money_1.with_qty(some_money_1.qty)

    some_money_2 = SomeMoney(Currency.USD, Decimal('100.000000'), Date(2017, 12, 18))
    some_money_3 = Money.of(Currency.USD, Decimal('100.000000'), Date(2017, 12, 18))
    assert some_money_2.with_qty(some_money_2.qty) == some_money_3.with_qty(some_money_3.qty)


# Generated at 2022-06-26 01:01:10.048436
# Unit test for method lte of class Money
def test_Money_lte():
    # Verify that money is not greater or equal to NonePrice
    assert no_money.lte(NonePrice) == False

    # Verify that NonePrice is less or equal than money
    assert NonePrice.lte(no_money) == True

    # Verify that NonePrice is less than money
    assert NonePrice.lt(no_money) == True

    # Verify that NonePrice is less or equal than NonePrice
    assert NonePrice.lte(NonePrice) == True

    # Verify that money is not greater or equal to NonePrice
    assert some_money.lte(NonePrice) == False

    # Verify that NonePrice is less or equal than money
    assert NonePrice.lte(some_money) == True

    # Verify that NonePrice is less than money
    assert NonePrice.lt(some_money) == True

    # Verify that NonePrice is

# Generated at 2022-06-26 01:01:17.888040
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(ccy=None, qty=None, dov=None).lt(Money.of(ccy=None, qty=None, dov=None)) == False
    assert Money.of(ccy=None, qty=None, dov=None).lt(Money.of(ccy=None, qty=None, dov=None)) == None
    assert Money.of(ccy=None, qty=None, dov=None).lt(Money.of(ccy=None, qty=None, dov=None)) == False
    assert Money.of(ccy=None, qty=None, dov=None).lt(Money.of(ccy=None, qty=None, dov=None)) == None

# Generated at 2022-06-26 01:01:25.413699
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    ccy_0 = Currency('EUR')
    qty_0 = Decimal('0.01')
    dt_0 = Date.from_ymd(2020, 4, 20)
    sp_0 = SomePrice(ccy_0, qty_0, dt_0)
    ccy_1 = Currency('JPY')
    qty_1 = Decimal('0.15')
    dt_1 = Date.from_ymd(2020, 4, 20)
    sp_1 = SomePrice(ccy_1, qty_1, dt_1)
    try:
        sp_0.lt(sp_1)
        assert False, 'Expected exception'
    except IncompatibleCurrencyError:
        expected_error = IncompatibleCurrencyError('EUR', 'JPY', '< comparision')



# Generated at 2022-06-26 01:01:31.353119
# Unit test for method abs of class Money
def test_Money_abs():
    assert NoMoney.abs() == NoMoney
    assert NonePrice.abs() == NonePrice
    assert (
        SomeMoney(Currency.get("USD"), Decimal("1.11"), Date.today()).abs()
        == SomeMoney(Currency.get("USD"), Decimal("1.11"), Date.today())
    )
    assert (
        SomeMoney(Currency.get("USD"), Decimal("-1.11"), Date.today()).abs()
        == SomeMoney(Currency.get("USD"), Decimal("1.11"), Date.today())
    )


# Generated at 2022-06-26 01:01:38.229390
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    none_money_0 = NoneMoney()
    none_money_1 = NoneMoney()
    none_money_2 = NoneMoney()
    none_money_3 = NoneMoney()
    none_money_4 = NoneMoney()
    none_money_5 = NoneMoney()
    none_money_6 = NoneMoney()
    none_money_7 = NoneMoney()
    none_money_8 = NoneMoney()
    none_money_9 = NoneMoney()
    none_money_10 = NoneMoney()
    none_money_11 = NoneMoney()
    none_money_12 = NoneMoney()
    none_money_13 = NoneMoney()
    none_money_14 = NoneMoney()
    none_money_15 = NoneMoney()
    none_money_16 = NoneMoney()
    none_money_17 = NoneMoney()
   