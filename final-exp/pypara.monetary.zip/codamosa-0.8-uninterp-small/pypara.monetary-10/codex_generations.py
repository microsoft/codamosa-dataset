

# Generated at 2022-06-26 00:54:57.035758
# Unit test for method multiply of class Money
def test_Money_multiply(): 
    # Test the definition of undefined money 
    # of the field NA of class Money
    print("The value of test_undefined_money is:", Money.NA.qty)
    assert Money.NA.qty == Decimal('0')

    # Test the definition of currency
    # of the field ccy of class Money
    print("The value of test_currency is:", Money.NA.ccy)
    assert Money.NA.ccy == Currency.USD

    # Test the definition of value date of value
    # of the field dov of class Money
    print("The value of test_value_date_of_value is:", Money.NA.dov)
    assert Money.NA.dov == Date.today()

    # Test the attribute defined of class Money
    # It is not the undefined monetary value

# Generated at 2022-06-26 00:55:02.648609
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    def expected_result():
        return 10

    def actual_result():
        return Price(Currency.USD, 10, Date.today()).as_integer()

    assert actual_result() == expected_result()



# Generated at 2022-06-26 00:55:06.245509
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    none_price_0 = NonePrice()
    float_0 = none_price_0.__neg__().as_float()
    float_1 = NonePrice.__neg__(none_price_0).as_float()
    float_2 = (- NoPrice).as_float()


# Generated at 2022-06-26 00:55:10.452273
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    none_price_0 = NonePrice()
    none_price_1 = NonePrice()
    some_price_0 = SomePrice('RUB', Decimal('5.5'), Date(2007, 1, 1))
    some_price_1 = SomePrice('RUB', Decimal('1.2'), Date(2007, 1, 1))

    assert (some_price_0.scalar_add(some_price_1) == SomePrice('RUB', (Decimal('5.5') + Decimal('1.2')), Date(2007, 1, 1)))
    assert (some_price_0.scalar_add(none_price_0) == NonePrice())

# Generated at 2022-06-26 00:55:14.668219
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    none_money_0 = NoneMoney()
    # maybe using exception here
    assert False == none_money_0.defined
    try:
        none_money_0.as_integer()
        assert False
    except TypeError:
        assert True
    none_money_1 = NoneMoney()
    assert False == none_money_1.defined
    try:
        none_money_1.as_integer()
        assert False
    except TypeError:
        assert True
    none_money_2 = NoneMoney()
    assert False == none_money_2.defined
    try:
        none_money_2.as_integer()
        assert False
    except TypeError:
        assert True
    none_money_3 = NoneMoney()
    assert False == none_money_3.defined

# Generated at 2022-06-26 00:55:17.252252
# Unit test for method gte of class Money
def test_Money_gte():
    x = Money.of(Currency("USD"), Decimal("100"), Date("2020-01-01"))
    y = Money.of(Currency("USD"), Decimal("100"), Date("2020-01-01"))
    z = Money.of(Currency("USD"), Decimal("101"), Date("2020-01-01"))

    assert x.gte(y) == True
    assert x.gte(x) == True
    assert x.gte(z) == False


# Generated at 2022-06-26 00:55:18.959133
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    none_money_0 = NoneMoney()
    none_money_0.as_boolean()

    some_money_0 = SomeMoney(Currency.USD, Decimal(1.0), Date.today())
    some_money_0.as_boolean()


# Generated at 2022-06-26 00:55:21.209812
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert(SomeMoney.of(USD, 5, None).as_boolean() == True)
    assert(SomeMoney.of(USD, 0, None).as_boolean() == False)
    assert(SomeMoney.of(USD, None, None).as_boolean() == True)
    assert(SomeMoney.of(None, None, None).as_boolean() == False)


# Generated at 2022-06-26 00:55:23.574586
# Unit test for method as_float of class Money
def test_Money_as_float():
    none_price_0 = NonePrice()
    float_0 = float()
    float_1 = float()
    float_0 = float(8)
    float_0 = float(3)
    float_1 = float(3)


# Generated at 2022-06-26 00:55:33.529128
# Unit test for method add of class Money
def test_Money_add():
    none_price_0 = NonePrice()
    some_price_0 = SomePrice(
        currency_0=Currency.CAD,
        quantity=Decimal('-1.0'),
    )
    some_price_1 = SomePrice(
        currency_0=Currency.CAD,
        quantity=Decimal('60.0'),
    )
    some_price_0 = some_price_0.add(some_price_1)

    some_price_1 = SomePrice(
        currency_0=Currency.CAD,
        quantity=Decimal('60.0'),
    )

    # assert some_price_0 == some_price_1, "Assertion failed"
    some_price_0 = some_price_0.abs()


# Generated at 2022-06-26 00:59:36.353724
# Unit test for method divide of class Price
def test_Price_divide():
    print("Testing Price.divide")
    res = Price(Currency.USD,0,0).divide(Price(Currency.USD,0,0))
    assert res.undefined == True
    assert res.qty == Decimal(0)
    assert res.ccy == Currency.USD 
    assert res.dov == 0
    res = Price(Currency.USD,Decimal(1),0).divide(Price(Currency.USD,Decimal(2),0))
    assert res.undefined == True
    assert res.qty == Decimal(0)
    assert res.ccy == Currency.USD 
    assert res.dov == 0
    res = Price(Currency.USD,Decimal(2),0).divide(Price(Currency.USD,Decimal(1),0))

# Generated at 2022-06-26 00:59:42.634829
# Unit test for method divide of class Price
def test_Price_divide():
    assert 1/NoPrice == NoPrice
    assert NoPrice/1 == NoPrice
    assert 1/(NonePrice()/1) == NoPrice
    assert (1/NonePrice())/1 == NoPrice
    assert 1/SomePrice(Currency("USD"), Decimal("10"), Date(2019, 6, 1)) == SomePrice(Currency("USD"), Decimal("0.1"), Date(2019, 6, 1))
    assert SomePrice(Currency("USD"), Decimal("10"), Date(2019, 6, 1))/1 == SomePrice(Currency("USD"), Decimal("10"), Date(2019, 6, 1))
    assert 1/(SomePrice(Currency("USD"), Decimal("10"), Date(2019, 6, 1))/1) == SomePrice(Currency("USD"), Decimal("10"), Date(2019, 6, 1))

# Generated at 2022-06-26 00:59:48.668337
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    print(NonePrice() == NonePrice())
    print(NonePrice() == SomePrice(Currency.USD, Decimal(1), Date.today()))
    print(SomePrice(Currency.USD, Decimal(1), Date.today()) == NonePrice())
    print(SomePrice(Currency.USD, Decimal(1), Date.today()) == SomePrice(Currency.USD, Decimal(1), Date.today()))
    print(SomePrice(Currency.USD, Decimal(1), Date.today()) == SomePrice(Currency.INR, Decimal(1), Date.today()))
    print(SomePrice(Currency.USD, Decimal(1), Date.today()) == SomePrice(Currency.USD, Decimal(2), Date.today()))

# Generated at 2022-06-26 00:59:53.072778
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    test_obj_1 = NoneMoney()
    test_obj_2 = NoneMoney()
    qty_0 = Decimal('0')

    assert(test_obj_2.with_qty(qty_0) is test_obj_1)


# Generated at 2022-06-26 01:00:03.634243
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ccy1 = Currency('CHF')
    qty1 = Decimal(100)
    dov1 = Date(2018, 1, 2)
    ccy2 = Currency('USD')
    asof = Date(2018, 1, 3)
    strict = False
    priceObject = SomePrice(ccy1, qty1, dov1)
    amt = priceObject.scale
    expectedAmount = ccy1.scale
    assert expectedAmount == amt
    somePrice_0 = SomePrice(ccy1, qty1, dov1)
    price_0 = somePrice_0.convert(ccy2, asof, strict)
    ccy = price_0.ccy
    expectedCcy = Currency('USD')
    assert expectedCcy == ccy
    qty = price_0.qty
    expected

# Generated at 2022-06-26 01:00:11.436026
# Unit test for method positive of class Money
def test_Money_positive():
    none_money_0 = NoneMoney()
    some_money_0 = SomeMoney("CNY", "88.0000", "2019-04-03")
    money_0 = Money.of("CNY", "88.0000", "2019-04-03")
    # Create a Price object
    price_0 = Price(some_money_0, NonePrice())
    # Create a Price object
    price_1 = Price(some_money_0, NonePrice())
    # Create a Price object
    price_2 = Price(some_money_0, price_0)


# Generated at 2022-06-26 01:00:20.581144
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    result = Money.of(ccy=Currency('JPY'), qty= Decimal(10000.0), dov=Date(20, 3, 2020)).with_qty(qty=Decimal(0.00))
    assert result == SomeMoney(Currency('JPY'), Decimal(0.00), Date(20, 3, 2020)),\
        'Expected result: SomeMoney(Currency(\'JPY\'), Decimal(0.00), Date(20, 3, 2020)), Actual result: ' + str(result)
    

# Generated at 2022-06-26 01:00:29.837939
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    # round with expected output : 10.00
    # Money rounded between 0 to 2 decimals
    true_res1 = SomeMoney(AUD, Decimal('10'), date(2020, 1, 16))
    res1 = SomeMoney(AUD, Decimal('10.0'), date(2020, 1, 16))
    assert res1.round() == true_res1
    # Money rounded between 0 to 3 decimals
    true_res2 = SomeMoney(AUD, Decimal('10.0'), date(2020, 1, 16))
    res2 = SomeMoney(AUD, Decimal('10.00'), date(2020, 1, 16))
    assert res2.round() == true_res2
    # Money rounded between 0 to 4 decimals

# Generated at 2022-06-26 01:00:39.791070
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    print("Test for method round of class SomeMoney")
    ccy = Currency("USD")
    qty = Decimal("100.23456789")
    dov = Date(2020, 10, 11)
    m = SomeMoney(ccy, qty, dov)
    # test with default argument
    m1 = m.round()
    result = SomeMoney(Currency("USD"), Decimal("100.23"), Date(2020, 10, 11))
    assert m1 == result
    # test with integer argument
    m2 = m.round(1)
    result = SomeMoney(Currency("USD"), Decimal("100.2"), Date(2020, 10, 11))
    assert m2 == result
    # test with a too big ndigits argument
    ndigits = ccy.decimals + 1
    m3 = m

# Generated at 2022-06-26 01:00:48.131721
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    currency1 = Currency(name = "USD", country = "US")
    ccy = currency1
    quantity = 1000
    to = ccy
    money0 = SomeMoney(ccy, quantity, None) #Constructor for SomeMoney
    assert money0.convert(to) == money0
