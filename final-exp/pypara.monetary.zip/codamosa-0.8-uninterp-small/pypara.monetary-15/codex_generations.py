

# Generated at 2022-06-26 00:55:43.717798
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    none_money_0 = NoneMoney()
    assert none_money_0.as_integer() == 0
    usd_money_0 = SomeMoney(Currency.USD(), Decimal('0.0'), Date('2019-03-03'))
    assert usd_money_0.as_integer() == 0
    other_usd_money_0 = SomeMoney(Currency.USD(), Decimal('0.0'), Date('2019-05-05'))
    assert other_usd_money_0.as_integer() == 0
    no_money_0 = NoMoney
    assert no_money_0.as_integer() is None
    usd_money_1 = SomeMoney(Currency.USD(), Decimal('0.0'), Date('2019-05-05'))
    usd_money_1.ccy = None


# Generated at 2022-06-26 00:55:54.258842
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    """Test method __eq__ of class SomeMoney"""
    nom1 = SomeMoney(ccy = Currency.USD, qty = Decimal(100), dov = Date.from_str('2020-12-31'))
    nom2 = SomeMoney(ccy = Currency.USD, qty = Decimal(100), dov = Date.from_str('2020-12-31'))
    nom3 = SomeMoney(ccy = Currency.USD, qty = Decimal(100), dov = Date.from_str('2021-01-01'))
    nom4 = SomeMoney(ccy = Currency.AUD, qty = Decimal(100), dov = Date.from_str('2020-12-31'))

# Generated at 2022-06-26 00:56:04.757129
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    if i == 0:
                        money_0 = SomeMoney()
                    else:
                        money_0 = NoMoney()
                    if j == 0:
                        money_1 = SomeMoney()
                    else:
                        money_1 = NoMoney()
                    if k == 0:
                        money_2 = SomeMoney()
                    else:
                        money_2 = NoMoney()
                    if l == 0:
                        money_3 = SomeMoney()
                    else:
                        money_3 = NoMoney()
                    if money_0.__ge__(money_1) == money_2.__ge__(money_3):
                        continue
                    else:
                        assert False


# Generated at 2022-06-26 00:56:14.365326
# Unit test for method gt of class Money
def test_Money_gt():
    # Test case 0
    m1 = Money.of(None, None, None)
    m2 = Money.of(None, None, None)
    assert (m1 > m2)

    # Test case 1
    m1 = Money.of(None, None, None)
    m2 = Money.of(None, 1, None)
    assert (m1 > m2)

    # Test case 2
    m1 = Money.of(None, None, None)
    m2 = Money.of(None, None, date(2017, 5, 1))
    assert (m1 > m2)

    # Test case 3
    m1 = Money.of(None, None, None)
    m2 = Money.of(Currency.of("GBP"), None, None)
    assert (m1 > m2)

    # Test

# Generated at 2022-06-26 00:56:24.027129
# Unit test for method multiply of class Money
def test_Money_multiply():
    # test case 1
    money_0 = NoneMoney()
    qty = Decimal('1.0')
    assert money_0.multiply(qty) == NoneMoney()

    # test case 2
    money_1 = SomeMoney(Currency.USD, Decimal('0.0'), Date(2000, 12, 31))
    assert money_1.multiply(qty) == money_1

    # test case 3
    money_2 = SomeMoney(Currency.USD, Decimal('0.0'), Date(2000, 12, 31))
    money_2 = Money.of( money_2.ccy, money_2.qty.quantize(Decimal('1.0E-21')), Date(2000, 12, 31))

# Generated at 2022-06-26 00:56:25.426177
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    assert SomeMoney('thing', 1, 2) <= 2


# Generated at 2022-06-26 00:56:34.314549
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    ccy1 = mock.Mock(spec=Currency)
    qty1 = mock.Mock(spec=Decimal)
    dov1 = mock.Mock(spec=Date)
    ccy2 = mock.Mock(spec=Currency)
    qty2 = mock.Mock(spec=Decimal)
    dov2 = mock.Mock(spec=Date)
    money1 = SomeMoney(ccy1, qty1, dov1)
    money2 = SomeMoney(ccy2, qty2, dov2)
    # Case 0
    try:
        result = money1.__gt__(money2)
        assert False
    except Exception as e:
        assert e.__class__ is IncompatibleCurrencyError

    # Case 1:
    ccy1.__eq__.return_

# Generated at 2022-06-26 00:56:42.242734
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    some_price_0 = SomePrice(Currency.USD, Decimal('0'), date(2020, 1, 1))
    some_price_1 = SomePrice(Currency.USD, Decimal('0'), date(2020, 1, 1))
    some_price_2 = SomePrice(Currency.USD, Decimal('0'), date(2020, 1, 1))
    some_price_3 = SomePrice(Currency.USD, Decimal('0'), date(2020, 1, 1))
    assert some_price_1 / some_price_3 == some_price_2
    assert some_price_1 // some_price_3 == some_price_0


# Generated at 2022-06-26 00:56:52.199875
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    ccy_0 = Currency.from_str('HKD')
    qty_0 = Decimal('1.000000')
    dov_0 = Date.from_str('2020-08-04')
    some_money_0 = SomeMoney(ccy_0, qty_0, dov_0)
    ccy_1 = Currency.from_str('HKD')
    qty_1 = Decimal('1.000000')
    dov_1 = Date.from_str('2020-08-04')
    some_money_1 = SomeMoney(ccy_1, qty_1, dov_1)
    boolean_0 = some_money_1.lte(some_money_0)
    assert_true(boolean_0)
    ccy_2 = Currency.from_str('HKD')
   

# Generated at 2022-06-26 00:56:56.897292
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    ccy = Currency('USD')
    obj = SomeMoney(ccy, Decimal(100), Date(2012, 12, 1))
    other = NoneMoney()
    expected = SomeMoney(ccy, Decimal(100), Date(2012, 12, 1))
    actual = obj.__sub__(other)
    assert expected == actual, f'{expected} != {actual}'


# Generated at 2022-06-26 01:01:35.188067
# Unit test for method multiply of class Money
def test_Money_multiply():
    money_0 = Money.of(Currency.USD, Decimal(1), Date.today())
    money_1 = Money.of(Currency.USD, Decimal(2), Date.today())
    money_2 = Money.of(Currency.USD, Decimal(3), Date.today())

    money_1 = money_1.multiply(3.0)
    assert money_1 == money_2

    money_1 = money_1.multiply(-3.0)
    assert money_1 == money_0

    money_1 = money_1.multiply(-1.0)
    assert money_1 == money_0

    money_1 = money_1.multiply(Decimal(0))
    assert money_1 == money_0


# Generated at 2022-06-26 01:01:41.065699
# Unit test for method lt of class Price
def test_Price_lt():
    amount_0 = Money(10, "USD")
    amount_1 = Money(5, "USD")
    amount_2 = Money(10, "EUR")

    try:
        amount_0 < amount_1
    except Exception as err:
        sys.stdout.write('assertEqual failed: got ' + repr(err) + ', expected <class \'IncompatibleCurrencyError\'>\n')
    except:
        sys.stdout.write('AssertionError: assertEqual failed: got <class \'IncompatibleCurrencyError\'>, expected <class \'IncompatibleCurrencyError\'>\n')
