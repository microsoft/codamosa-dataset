

# Generated at 2022-06-26 00:55:00.190084
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():

    # Call SomePrice class constructor
    SomePrice_instance_0 = SomePrice(Currency(currency_code="\U000f9e61\U000fa3d3"), Decimal("-0.0"), Date(2019, 1, 3))

    # Call method with_qty of SomePrice instance with argument Decimal("-0.0")
    result = SomePrice_instance_0.with_qty(Decimal("-0.0"))

    # Check if result is a SomePrice and if it's Currency is the same as the of the SomePrice instance
    if not (result.__class__ is SomePrice) or result.ccy != SomePrice_instance_0.ccy:
        raise RuntimeError("Incorrect test result (actual result: " + str(result) + ")")


# Generated at 2022-06-26 00:55:10.045930
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    # Arrange
    monetary_operation_exception_0 = MonetaryOperationException()
    monetary_operation_exception_1 = MonetaryOperationException()
    monetary_operation_exception_2 = MonetaryOperationException()
    monetary_operation_exception_3 = MonetaryOperationException()
    monetary_operation_exception_4 = MonetaryOperationException()
    monetary_operation_exception_5 = MonetaryOperationException()
    monetary_operation_exception_6 = MonetaryOperationException()
    monetary_operation_exception_7 = MonetaryOperationException()
    monetary_operation_exception_8 = MonetaryOperationException()
    monetary_operation_exception_9 = MonetaryOperationException()

    # Act
    monetary_operation_exception_0.__ge__(monetary_operation_exception_1)

# Generated at 2022-06-26 00:55:10.846605
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    monetary_operation_exception_0 = MonetaryOperationException()


# Generated at 2022-06-26 00:55:21.491826
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    ccy1 = Currency("EUR")
    qty1 = Decimal("1")
    dov1 = Date("2019-01-01")
    price1 = SomePrice(ccy1, qty1, dov1)
    ccy2 = Currency("USD")
    qty2 = Decimal("2")
    dov2 = Date("2019-01-01")
    price2 = SomePrice(ccy2, qty2, dov2)

    # Test case when price2 is undefined
    expected1 = price1
    actual1 = price1.__add__(NoPrice)
    assert(expected1 == actual1)

    # Test case when currencies are equal
    expected2 = SomePrice(ccy1, qty1 + qty2, dov1)

# Generated at 2022-06-26 00:55:26.930911
# Unit test for method positive of class Price
def test_Price_positive():
    a = Price.of('USD', 1, date(2020, 1, 2))
    b = Price.of('USD', 2, date(2020, 1, 2))
    c = Price.of('USD', 1, date(2020, 1, 2))
    d = Price.of('EUR', 1, date(2020, 1, 2))


    assert a.positive() is a
    # assert b.positive() is b
    # assert c.positive() is c
    # assert d.positive() is d



# Generated at 2022-06-26 00:55:28.549756
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    price = Price()
    with raises(NotImplementedError):
        price.__ge__(1)


# Generated at 2022-06-26 00:55:31.173458
# Unit test for method __float__ of class Price
def test_Price___float__():
    sut = Price.NA
    result = sut.as_float()


# Generated at 2022-06-26 00:55:33.377258
# Unit test for method __int__ of class Money
def test_Money___int__():
    m = Money.of(Currency.USD, Decimal(1), Date.original_date())
    assert m.__int__() == 1


# Generated at 2022-06-26 00:55:43.313802
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    some_price_0 = SomePrice(Currency.of('CHF'), Decimal('-7.066832489093251'), Date(11, 7, 1970))
    some_price_1 = SomePrice(Currency.of('NOK'), Decimal('-7933.45'), Date(5, 11, 2031))
    some_price_2 = SomePrice(Currency.of('BGN'), Decimal('0.0'), Date(30, 9, 2026))
    assert some_price_0.with_dov(Date(25, 5, 2023)) == SomePrice(Currency.of('CHF'), Decimal('-7.066832489093251'), Date(25, 5, 2023))

# Generated at 2022-06-26 00:55:46.917309
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    monetary_operation_exception_0 = MonetaryOperationException()

    monetary_operation_exception_0.args = monetary_operation_exception_0.args.__add__(tuple())



# Generated at 2022-06-26 00:58:20.657780
# Unit test for method __float__ of class Price
def test_Price___float__():
    price_0 = Price()
    float_0 = float(price_0)


# Generated at 2022-06-26 00:58:24.127843
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    monetary_operation_exception = MonetaryOperationException()
    money = Money()
    money.__lt__(monetary_operation_exception)
    money.__lt__(money)


# Generated at 2022-06-26 00:58:32.383689
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    monetary_operation_exception_0 = MonetaryOperationException()
    some_money_0 = SomeMoney(Currency.USD, Decimal('1868.520247779800487515803408348414932793875'), Date(2018, 12, 18))
    some_money_1 = SomeMoney(Currency.USD, Decimal('0E-24'), Date(1461, 4, 8))
    some_money_2 = SomeMoney(Currency.USD, Decimal('0E-24'), Date(2010, 12, 7))
    some_money_3 = SomeMoney(Currency.USD, Decimal('0E-24'), Date(2035, 4, 9))
    some_money_4 = SomeMoney(Currency.USD, Decimal('0E-24'), Date(2033, 12, 13))
    some_money

# Generated at 2022-06-26 00:58:35.916079
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    a = Money()
    b = Any()
    monetary_0 = a.__floordiv__(b)
    assert monetary_0 != a or monetary_0 == a
    monetary_1 = a.__floordiv__(b)
    assert monetary_1 != a or monetary_1 == a


# Generated at 2022-06-26 00:58:37.806256
# Unit test for method __int__ of class Money
def test_Money___int__():
    monetary_operation_exception = MonetaryOperationException()
    assert(int(monetary_operation_exception) == 0)


# Generated at 2022-06-26 00:58:42.802688
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    amount_0 = Quantity(100.0)
    price_0 = SomeMoney(USD, amount_0, Date(10, 8, 10))
    amount_1 = Quantity(-1.0)
    price_1 = SomeMoney(CAD, amount_1, Date(10, 8, 10))
    try:
        result = price_0.__le__(price_1)
    except IncompatibleCurrencyError:
        print("some money cannot be compared to another with a different currency")



# Generated at 2022-06-26 00:58:44.665587
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    gte = SomeMoney.of(None, None, None).gte
    assert gte(NoMoney) == None


# Generated at 2022-06-26 00:58:46.549293
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    monetary_operation_exception_0 = MonetaryOperationException()
    monetary_operation_exception_1 = MonetaryOperationException()


# Generated at 2022-06-26 00:58:47.352953
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass


# Generated at 2022-06-26 00:58:55.086756
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    ## First, setup variables:
    ccy_10 = USD
    qty_10 = Decimal(7)
    dov_10 = datetime(2019, 10, 15, 0, 0)
    some_money_10 = SomeMoney(ccy_10, qty_10, dov_10)
    ## Run method under test (i.e, __truediv__) and check output:
    assert some_money_10.__truediv__(Decimal(2)) == SomeMoney(USD, Decimal(3.5), datetime(2019, 10, 15, 0, 0))
    ## Run method under test (i.e, __truediv__) and check output:
    assert some_money_10.__truediv__(0) is NoMoney


# Generated at 2022-06-26 00:59:26.059820
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    c1: Currency
    q1: Decimal
    d1: Date
    c2: Currency
    q2: Decimal
    d2: Date
    y = SomeMoney(c1, q1 > q2, d1)
    y = SomeMoney(c1, q1 >= q2, d1)
    y = SomeMoney(c1, q1 == q2, d1)
    y = SomeMoney(c1, q1 != q2, d1)
    y = SomeMoney(c1, q1 < q2, d1)
    y = SomeMoney(c1, q1 <= q2, d1)
    y = SomeMoney(c1, q1 + q2, d1)
    y = SomeMoney(c1, q1 - q2, d1)

# Generated at 2022-06-26 00:59:28.884463
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    m1 = Money.of(ccy='USD', qty=1, dov='2017-02-01')
    m2 = m1 * 2
    m3 = m1 * 0
    m4 = m1 * -1


# Generated at 2022-06-26 00:59:35.745443
# Unit test for method negative of class Money
def test_Money_negative():
    currency = Currency('KWD')
    date = Date(2020,12,13)
    value = 4
    #test case 0
    none_price_0 = NonePrice()
    price_0 = none_price_0.negative()
    assert price_0.ccy == None, 'price_0.ccy is None'
    assert price_0.qty == None, 'price_0.qty is None'
    assert price_0.dov == None, 'price_0.dov is None'
    #test case 1
    some_price_1 = SomePrice(currency,value,date)
    price_1 = some_price_1.negative()
    assert price_1 != some_price_1, 'price_1 is not some_price_1'
    assert price_1.ccy == some_price_1

# Generated at 2022-06-26 00:59:38.859805
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    none_price_0 = NonePrice()
    price_0 = NonePrice()
    price_0.__gt__(none_price_0)
    price_0.__gt__(price_0)
    price_0.__gt__(None)


# Generated at 2022-06-26 00:59:45.003371
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    assert SomeMoney(
        ccy=Currency("USD"),
        qty=Decimal("100.12345"),
        dov=Date("2020-07-14")
        ).with_dov(dov=Date("2020-07-15")) == SomeMoney(
        ccy=Currency("USD"),
        qty=Decimal("100.12345"),
        dov=Date("2020-07-15")
        )


# Generated at 2022-06-26 00:59:45.632716
# Unit test for method lt of class Price
def test_Price_lt():
    pass


# Generated at 2022-06-26 00:59:50.200055
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    #! [__mul__]
    m = Money(Currency.USD, 10.0, Date.today())
    assert m.multiply(2) == Money(Currency.USD, 20.0, Date.today())
    #! [__mul__]


# Generated at 2022-06-26 01:00:02.780300
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    # NoneMoney
    none_price_0 = NonePrice()
    none_money_0 = NoneMoney()

    assert (none_price_0.__mul__(none_money_0) == NonePrice())
    # SomePrice
    some_price_0 = SomePrice(1.0, "USD")
    some_price_1 = SomePrice(-1.0, "USD")

    assert (some_price_0.__mul__(2) == SomeMoney(2.0, "USD"))
    assert (some_price_0.__mul__(-2) == SomeMoney(-2.0, "USD"))
    assert (some_price_1.__mul__(2) == SomeMoney(-2.0, "USD"))

# Generated at 2022-06-26 01:00:07.364209
# Unit test for method convert of class Money
def test_Money_convert():
    #Case 0
    some_money_0 = SomeMoney(Currency('XCD'),Decimal('14.00000000'),Date(2019, 3, 6))
    some_money_1 = some_money_0.convert(Currency('CHF'))


# Generated at 2022-06-26 01:00:15.769620
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    import random
    import decimal
    from decimal import Decimal
    from moneyed import Money, Money as SomeMoney
    from moneyed import UndefinedMoney, UndefinedMoney as NoMoney
    from moneyed import Currency, INR as Ccy

    money = SomeMoney(Ccy, Decimal('10.02'), '2018-11-18')
    money2 = SomeMoney(Ccy, Decimal('9.02'), '2018-11-18')
    money3 = SomeMoney(Ccy, Decimal('10.02'), '2018-11-18')
    money4 = SomeMoney(Ccy, Decimal('10.02'), '2018-11-19')
    money5 = SomeMoney(Ccy, Decimal('10.02'), '2018-11-20')

    money_1 = None
    money_2 = None

    # Verify that the

# Generated at 2022-06-26 01:01:08.471466
# Unit test for method negative of class Money
def test_Money_negative():
    none_price_0 = NonePrice()
    price_0 = none_price_0.negative()
    assert bool(price_0) is False


# Generated at 2022-06-26 01:01:14.118766
# Unit test for method convert of class Money
def test_Money_convert():
    assert (NoneMoney.convert(Currency.USD)).undefined == True
    assert (NoneMoney.convert(Currency.USD, Date.today())).undefined == True
    assert (NoneMoney.convert(Currency.USD, Date.today(), True)).undefined == True

    assert (NoMoney.convert(Currency.USD)).undefined == True
    assert (NoMoney.convert(Currency.USD, Date.today())).undefined == True
    assert (NoMoney.convert(Currency.USD, Date.today(), True)).undefined == True



# Generated at 2022-06-26 01:01:21.665501
# Unit test for method lt of class Price
def test_Price_lt():
    import pytest
    from pytest import raises

    USD, EUR = "USD", "EUR"
    C, D = Currency.of(USD), Currency.of(EUR)
    p = Price.of(C, Decimal("1.0"), Date.today())
    q = Price.of(C, Decimal("0.0"), Date.today())
    r = Price.of(D, Decimal("0.0"), Date.today())
    with raises(TypeError):
        x = p < None
    with raises(TypeError):
        x = p < 10
    with raises(TypeError):
        x = p < Decimal("0.0")
    with raises(TypeError):
        x = p < Money.of(C, Decimal("0.0"), Date.today())
    assert p < q
    assert not q

# Generated at 2022-06-26 01:01:26.128104
# Unit test for method negative of class Money
def test_Money_negative():

    none_price_0 = NonePrice()
    price_0 = none_price_0.negative()

    none_price_1 = NonePrice()
    price_1 = none_price_1.negative()

    assert price_0.defined == price_1.defined
    assert price_0.quantity == price_1.quantity
    assert price_0.currency == price_1.currency

    # Unit test for method multiply of class Money

# Generated at 2022-06-26 01:01:34.067782
# Unit test for method convert of class Money
def test_Money_convert():
    # Converting from USD to EUR
    from_ccy = Currency.of("USD")
    to_ccy =  Currency.of("EUR")
    from_qty = Decimal(100)
    from_dov = Date(2018, 4, 1)
    from_money = Money.of(from_ccy, from_qty, from_dov)
    to_money =  from_money.convert(to_ccy, None)


    print(from_money.ccy)
    print(from_money.qty)
    print(from_money.dov)

    print(to_money.ccy)
    print(to_money.qty)
    print(to_money.dov)

    print(from_money.convert(to_ccy, None))

# Generated at 2022-06-26 01:01:40.286236
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    # Setup
    # Create a NonePrice object
    none_price = NonePrice()

    # create a SomePrice object
    quantity = Decimal('1000000.00000000')
    date_of_value = Date(2018, 1, 1)
    currency = Currency('CNY')
    amount = Money(quantity, currency, date_of_value)
    some_price = Price.of(currency, quantity, date_of_value)

    # Exercise
    none_price_convert = none_price.convert(Currency('HKD'), Date(2018, 1, 1), True)
    some_price_convert = some_price.convert(Currency('HKD'), Date(2018, 1, 1), True)

    # Verify
    # assert that the converted price should be NonePrice

# Generated at 2022-06-26 01:01:46.060851
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    USD = Currency("USD")
    GBP = Currency("GBP")
    EUR = Currency("EUR")
    price_0 = SomePrice(USD, 1.23, Date(year=2020, month=2, day=3))
    price_1 = SomePrice(GBP, 1.23, Date(year=2020, month=2, day=3))
    price_2 = SomePrice(EUR, 1.23, Date(year=2020, month=2, day=3))
    # Test with another price of the same currency
    try:
        price_0 - price_0
    except IncompatibleCurrencyError:
        print("IncompatibleCurrencyError raised")
    # Test with a price of different currency
    try:
        price_0.subtract(price_1)
    except IncompatibleCurrencyError:
        print