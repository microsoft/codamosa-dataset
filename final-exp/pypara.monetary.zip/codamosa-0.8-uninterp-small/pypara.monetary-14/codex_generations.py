

# Generated at 2022-06-26 00:56:09.431053
# Unit test for method convert of class Price
def test_Price_convert():
    logger.info("Unit test for method convert of class Price")
    price = Price.of(USD, 100, Date.today())
    price = price.convert(JPY)
    assert price.ccy is JPY
    assert price.qty == 100
    assert price.defined
    assert price.dov is Date.today()



# Generated at 2022-06-26 00:56:18.987011
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    print("[[[[[[[[ START ]]]]]]]]")
    ## Test case:
    # Price.of(Currency("USD"), Decimal("1.5"), Date("2020-01-01")) - Price.of(Currency("USD"), Decimal("1.5"), Date("2020-01-01"))
    #
    # Expected result:
    # SomePrice(ccy=Currency(code='USD', name='US Dollar', precision=2, quantizer=Decimal('0.01'), symbol='$', rounding=HALF_UP), qty=Decimal('0'), dov=Date(2020, 1, 1))

# Generated at 2022-06-26 00:56:24.641879
# Unit test for method add of class Money
def test_Money_add():
    from .currencies import USD
    from .commons.zeitgeist import Date
    money_1 = Money.of(USD, 1, Date(2020, 1, 1))
    money_2 = Money.of(USD, 1, Date(2020, 1, 1))
    money_3 = Money.of(USD, 2, Date(2020, 1, 1))
    assert money_1.add(money_2) == money_3


# Generated at 2022-06-26 00:56:27.418712
# Unit test for method __ge__ of class Price
def test_Price___ge__():

    # Setup
    price_0 = Price.of(None, None, None)

    # Invocation
    result = price_0.__ge__(price_0)

    # Verification
    assert result is None

# Generated at 2022-06-26 00:56:33.508611
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from decimal import Decimal
    money_0 = Money.of(Currency("USD"), Decimal('0'), Date.earlier('01-02-2015 00:00:00'))
    money_1 = Money.of(Currency("USD"), Decimal('0'), Date.earlier('01-02-2015 00:00:00'))
    result = money_1.subtract(money_0)
    assert isinstance(result, Money)



# Generated at 2022-06-26 00:56:36.711147
# Unit test for method add of class Money
def test_Money_add():
    money_0 = Money()
    money_1 = Money()
    money_2 = Money()
    money_3 = Money()
    money_2 = money_3.add(money_0)



# Generated at 2022-06-26 00:56:46.389032
# Unit test for method lt of class Money
def test_Money_lt():
    money = SomeMoney(Currency('USD'), 100.0, Date(2020,2,6))
    money1 = SomeMoney(Currency('YEN'), 200.0, Date(2020,2,7))
    money2 = SomeMoney(Currency('USD'), 100.0, Date(2020,3,7))
    money3 = SomeMoney(Currency('USD'), 200.0, Date(2020,2,7))
    money4 = SomeMoney(Currency('YEN'), 200.0, Date(2020,2,7))
    # check if the given money on left-hand-side is less than the one given on right-hand-side of the inequality
    # by performing the following test cases
    assert money.lt(money1)
    assert money2.lt(money3)
    assert not money3.lt(money)

# Generated at 2022-06-26 00:56:55.822197
# Unit test for method round of class Money
def test_Money_round():
    # Test with no currency
    with pytest.raises(MonetaryOperationException):
        money_nocc = Money.of(None, Decimal(2.2), None)
        money_nocc.round()

    # Test with no quantity
    with pytest.raises(MonetaryOperationException):
        money_noqty = Money.of(Currency('USD'), None, None)
        money_noqty.round()

    # Test with no date of valuation
    with pytest.raises(MonetaryOperationException):
        money_nodov = Money.of(Currency('USD'), Decimal(2.2), None)
        money_nodov.round()

    # Test with currency and quantity, but no date of valuation
    with pytest.raises(MonetaryOperationException):
        money_noqty_n

# Generated at 2022-06-26 00:57:08.479057
# Unit test for method lt of class Price
def test_Price_lt():  
    price_0 = Price()
    price_1 = Price()
    price_0.lt(price_1)
    if (price_0.lt(price_1) == False):
        print("Testcase 0.0: Pass!")
    else:
        print("Testcase 0.0: Fail!")
    
    price_0 = Price(ccy='USD', qty = 100, dov=datetime.date(2019, 9, 12))
    price_1 = Price(ccy='USD', qty = 100, dov=datetime.date(2019, 9, 12))
    price_0.lt(price_1)
    if (price_0.lt(price_1) == False):
        print("Testcase 0.1: Pass!")

# Generated at 2022-06-26 00:57:14.506444
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert SomePrice(USD, 40.80, Dec("2019-01-01")).convert(CAD, Dec("2019-01-01")) == SomePrice(CAD, 56.30, Dec("2019-01-01"))


# Generated at 2022-06-26 00:59:33.443121
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Parametrize
    amount = Decimal('14.45')
    ccy = Currency.USD
    dov = Date('2020-12-01')

    # Test
    price_0 = Price.of(ccy, amount, dov)
    price_1 = Price.of(ccy, amount, None)

    # Test
    assert price_0.with_dov(Date('2020-12-02')).dov == Date('2020-12-02')
    assert price_1.with_dov(Date('2020-12-02')).undefined


# Generated at 2022-06-26 00:59:36.107676
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    price_0 = Price()
    date_0 = Date.of(1, 1)
    price_1 = price_0.with_dov(date_0)


# Generated at 2022-06-26 00:59:42.480206
# Unit test for method subtract of class Price
def test_Price_subtract():
    money_0 = Money.NA
    money_1 = Money.of(Currency.of("GBP"), Decimal(0), Date())
    price_0 = Price.of(Currency.of("GBP"), Decimal(0), Date())
    price_1 = Price.of(Currency.of("GBP"), Decimal(0), Date(2019, 12, 4))
    price_2 = Price.of(Currency.of("GBP"), Decimal(3), Date(2019, 12, 4))
    # Expected exception "IncompatibleCurrencyError"
    with raises(
            IncompatibleCurrencyError):
        price_0.subtract(price_1)
    # Expected exception "MonetaryOperationException"
    with raises(
            MonetaryOperationException):
        price_2.subtract(money_0)
   

# Generated at 2022-06-26 00:59:44.430886
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    price_0 = Money()
    price_1 = SomePrice(Currency(), Decimal(), Date())
    assert price_1 >= price_0 == True


# Generated at 2022-06-26 00:59:49.067569
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    from math import fabs
    money_0 = Money(Currency.USD, 100, dt.date(2018, 12, 31))
    money_1 = -money_0
    result_0 = money_1.__abs__()
    if fabs(result_0.qty - 100) > 1e-05:
        raise RuntimeError('value does not match')
    if result_0.ccy != Currency.USD:
        raise RuntimeError('value does not match')


# Generated at 2022-06-26 00:59:51.118781
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    some_price = SomePrice(CAD, Decimal("0.01"), Date.today())
    other = SomePrice(CAD, Decimal("0.01"), Date.today())
    print("some_price.__eq__(other) == ", some_price.__eq__(other))



# Generated at 2022-06-26 00:59:55.906951
# Unit test for method times of class Price
def test_Price_times():
    price = Price()
    multiplier = Decimal("1.0")

    money = price.times(multiplier)


# Generated at 2022-06-26 00:59:59.976858
# Unit test for method times of class Price
def test_Price_times():
    price = Price()
    out = price.times(Money(1000, Currency.GBP, Date(23,2,2017)))
    assert str(out) == "1000.0 GBP on 23-FEB-2017"
    

# Generated at 2022-06-26 01:00:06.267893
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    ccy = Currency()
    qty = Decimal()
    dov = Date()
    obj = SomePrice(ccy, qty, dov)
    other = Price()
    obj.__ge__(other)


# Generated at 2022-06-26 01:00:15.221941
# Unit test for method divide of class Price
def test_Price_divide():
    ccy0 = Currency.of('USD')
    ccy1 = Currency.of('EUR')
    qty0 = Decimal('123.45')
    qty1 = Decimal('23.45')
    dov0 = Date(2012, 6, 28)
    dov1 = Date(2012, 6, 29)
    price0 = Price(ccy0, qty0, dov0)
    assert price0.divide(2) == Price(Currency.of('USD'), Decimal('61.725'), Date(2012, 6, 28))
    assert price0.divide(Decimal('2')) == Price(Currency.of('USD'), Decimal('61.725'), Date(2012, 6, 28))

# Generated at 2022-06-26 01:01:06.047759
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import Currency
    from .exchange import FxRateService
    from .exchange.fixerio import FixerIo
    from .exchange.ratesapi import RatesApi
    from .exchange.simple_bureaus import SimpleBureaus
    from .exchange.simple_factory import SimpleFactory
    from .money import Money
    from .time_series import TimeSeries

    fxrates = RatesApi()
    fx_lookup = FxRateService(fxrates)

    fxrate = fx_lookup.get_rates(Currency.USD, Currency.TRY)
    print(fxrate)
    fxrate = fx_lookup.get_rates(Currency.USD, Currency.EUR)
    print(fxrate)
    fxrate = fx_lookup.get_

# Generated at 2022-06-26 01:01:08.440210
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    ccy = Currency("USD")
    qty = Decimal(10.00)
    dov = Date(2020, 1, 1)
    # TODO: write unit test for SomePrice.__eq__



# Generated at 2022-06-26 01:01:14.085726
# Unit test for method convert of class Price
def test_Price_convert():
    set_config(fx_provider="dodgy")
    set_config(fx_provider_params={"$USD": {"EUR": 1.1}})

    price_0 = Price.of("USD", 100, "2019-01-01")

    assert price_0.convert("EUR", "2018-01-01").qty == Decimal("110")
    assert price_0.convert("EUR", "2019-01-02").qty == Decimal("121")  # 110 * 11% = 12.1 + 110 = 122.1


# Generated at 2022-06-26 01:01:19.899933
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    def test_Price_with_ccy0():
        price_0 = Price.of(CURRENCY_CODE.USD, DECIMAL_ONE, date(2020, 5, 1))
        return price_0.with_ccy(CURRENCY_CODE.USD)

    def test_Price_with_ccy1():
        return NoPrice.with_ccy(CURRENCY_CODE.USD)

    assert isinstance(test_Price_with_ccy0(), Price)
    assert isinstance(test_Price_with_ccy1(), Price)


# Generated at 2022-06-26 01:01:20.820002
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    pass


# Generated at 2022-06-26 01:01:28.185696
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    money_0 = Money(
        currency=usd,
        quantity=Decimal("0.019031183"),
        value_date="2020-02-25",
    )
    money_1 = Money(
        currency=usd,
        quantity=Decimal("0.019031183"),
        value_date="2020-02-25",
    )
    money_2 = Money(
        currency=usd,
        quantity=Decimal("0.019031183"),
        value_date="2020-02-25",
    )
    money_3 = Money(
        currency=usd,
        quantity=Decimal("0.019031183"),
        value_date="2020-02-26",
    )

# Generated at 2022-06-26 01:01:31.705935
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    money_0 = SomePrice(Currency('USD'), Decimal(2.58), Date(2020, 2, 28))
    money_1 = SomePrice(Currency('USD'), Decimal(2.58), Date(2020, 2, 28))
    result = money_0.__ge__(money_1)



# Generated at 2022-06-26 01:01:38.533885
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    money_0 = Money.of(Currency.JPY, Decimal(99), Date(1, 1, 1))
    assert not money_0.is_equal(None), "Failed on None"

    money_1 = Money.of(Currency.JPY, Decimal(99), Date(1, 1, 1))
    assert money_0.is_equal(money_1) and money_1.is_equal(money_0)

    money_2 = Money.of(Currency.JPY, Decimal(99), Date(1, 1, 2))
    assert not money_0.is_equal(money_2) and not money_2.is_equal(money_0)

    money_3 = Money.of(Currency.JPY, Decimal(99), Date(1, 2, 1))
    assert not money_