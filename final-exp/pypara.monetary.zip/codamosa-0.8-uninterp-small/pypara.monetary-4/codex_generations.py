

# Generated at 2022-06-26 00:56:51.139867
# Unit test for method multiply of class Price
def test_Price_multiply():
    some_price_1 = SomePrice()
    # Input assignment
    some_price_1.qty = Decimal(25)
    some_price_1.ccy = "EUR"
    some_price_1.dov = date(2020, 1, 1)
    # Testing for method multiply for class Price
    some_price_1.multiply(some_price_1)



# Generated at 2022-06-26 00:56:54.929508
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    # known values
    price1 = SomePrice(USD, 42, date(2014, 3, 1))
    price2 = SomePrice(USD, 13, date(2014, 3, 1))
    assert price1.with_dov(date(2014, 3, 1)) == price2


# Generated at 2022-06-26 00:57:07.517786
# Unit test for method gt of class Money
def test_Money_gt():
    some_money_0 = SomeMoney()
    some_money_1 = SomeMoney(Currency('CHF'), Decimal('1'), Date(2018, 1, 1))
    some_money_2 = SomeMoney(Currency('CHF'), Decimal('-1'), Date(2018, 1, 1))
    some_money_3 = SomeMoney(Currency('CHF'), Decimal('0'), Date(2018, 1, 1))
    some_money_4 = SomeMoney(Currency('CHF'), Decimal('1.01'), Date(2018, 1, 1))
    some_money_5 = SomeMoney(Currency('CHF'), Decimal('1.01'), Date(2018, 3, 1))
    some_money_6 = SomeMoney(Currency('CHF'), Decimal('1.01'), Date(2018, 4, 1))
   

# Generated at 2022-06-26 00:57:13.394956
# Unit test for method round of class Money
def test_Money_round():
    assert Money.of(None, 1, None).round() == NoMoney
    assert Money.of(Currency.AUD, None, None).round() == NoMoney
    assert Money.of(Currency.AUD, Decimal(2.345), None).round() == SomeMoney(Currency.AUD, Decimal('2.35'), Date.today())
    assert Money.of(Currency.AUD, Decimal(2), Date.today()).round() == SomeMoney(Currency.AUD, Decimal(2), Date.today())


# Generated at 2022-06-26 00:57:22.968503
# Unit test for method subtract of class Price
def test_Price_subtract():
    # Test case of subtract with no args.
    # expected: expected result
    expected = NoPrice
    # actual: result of subtract with no args
    actual = Price.subtract()
    # is_equal: True if actual equals expected, False otherwise
    is_equal = actual == expected
    msg = f'Expected: {expected}, but got: {actual}'
    assert is_equal, msg
    # Test case of subtract with args.
    # expected: expected result
    expected = NoPrice
    # actual: result of subtract with args
    other = Price()
    actual = Price.subtract(other)
    # is_equal: True if actual equals expected, False otherwise
    is_equal = actual == expected
    msg = f'Expected: {expected}, but got: {actual}'
    assert is_equal, msg



# Generated at 2022-06-26 00:57:35.573717
# Unit test for method gt of class Money
def test_Money_gt():

    print('Unit tests for method gt of class Money')

    # Case 0:
    #   some_money_0 = SomeMoney()
    #   some_money_1 = SomeMoney()
    #
    #   some_money_0.ccy is 'USD', some_money_1 is 'USD'
    #   some_money_0.qty is 1, some_money_1.qty is 2
    #   some_money_0.dov is '2020-04-15', some_money_1.dov is '2020-04-15'
    #
    #   some_money_0.gt(some_money_1) should return False
    some_money_0 = SomeMoney(Currency('USD'), Decimal(1), Date.of('2020-04-15'))
    some_money_1 = Some

# Generated at 2022-06-26 00:57:43.949394
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    some_price_1 = SomePrice(Currency.USD, Decimal('1.0000000000000000'), date(2020, 5, 12))
    some_price_2 = SomePrice(Currency.USD, Decimal('2.0000000000000000'), date(2020, 5, 12))
    some_price_3 = SomePrice(Currency.USD, Decimal('3.0000000000000000'), date(2020, 5, 12))
    some_price_4 = SomePrice(Currency.BTC, Decimal('1.0000000000000000'), date(2020, 5, 12))
    some_price_5 = SomePrice(Currency.USD, Decimal('2.0000000000000000'), date(2020, 5, 11))
    assert some_price_1.__add__(some_price_2) == some_price_3

# Generated at 2022-06-26 00:57:52.980630
# Unit test for method convert of class Money
def test_Money_convert():
    # Setup
    fx_service = FXRateService()
    m1 = Money.of(Currency('USD'), 2, Date.now())
    m2 = Money.of(Currency('EUR'), 3, Date.now())
    fx_service.add_rate(Currency('USD'), Currency('EUR'), 1.1)
    # Exercise
    m3 = m1.convert(Currency('EUR'), fx_service=fx_service)
    m4 = m2.convert(Currency('USD'), fx_service=fx_service)
    m5 = m1.convert(Currency('CNY'), fx_service=fx_service)
    # Verify
    assert m3 == Money.of(Currency('EUR'), 2*1.1, Date.now())

# Generated at 2022-06-26 00:58:02.690737
# Unit test for method __gt__ of class Price
def test_Price___gt__():

    # Test Cases
    # 1. Defined price is greater than undefined price.
    # 2. Defined price is greater than defined price.
    # 3. Defined prices are not comparable when their currencies do not match.

    # Test Case 1
    # undefined price is less than defined price.
    mny_0 = Money(Currency('EUR'), Decimal(1.0), Date(1, 1, 1))
    assert not mny_0 <= Money.NA

    # Test Case 2
    # defined price is greater than defined price.
    mny_1 = Money(Currency('EUR'), Decimal(1.0), Date(1, 1, 1))
    mny_2 = Money(Currency('USD'), Decimal(2.0), Date(1, 1, 1))
    assert not mny_1 <= mny_2



# Generated at 2022-06-26 00:58:06.827604
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    some_price = SomePrice()
    assert some_price.as_integer() == 1.00
    assert some_price.as_integer() == 1.01
    assert some_price.as_integer() == 1.5


# Generated at 2022-06-26 01:00:36.423408
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    some_price_0 = SomePrice()
    assert bool(some_price_0) == True
    assert bool(some_price_0) == False
    assert bool(some_price_0) == False
    assert bool(some_price_0) == True
    assert bool(some_price_0) == True
    assert bool(some_price_0) == False


# Generated at 2022-06-26 01:00:38.120641
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    some_money = SomeMoney()
    assert some_money.__bool__() == True


# Generated at 2022-06-26 01:00:42.482433
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert Money.of(USD, 10).as_boolean() == True
    assert Money.of(USD).as_boolean() == False
    assert Money.of(USD, 10).is_defined == True
    assert Money.of(USD).is_defined == False
    assert Money.of(USD, 10).is_undefined == False
    assert Money.of(USD).is_undefined == True


# Generated at 2022-06-26 01:00:45.905748
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    some_price_0 = SomePrice()
    some_price_1 = SomePrice(ccy='USD', qty=Decimal('100.0000'), dov=Date(year=2020, month=1, day=12))
    assert some_price_0.as_boolean() == False
    assert some_price_1.as_boolean() == True
    return True


# Generated at 2022-06-26 01:00:50.270388
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    ccy = Currency("EUR")
    qty = Decimal("100.50")
    dov = Date("2020-01-01")
    money = SomeMoney(ccy, qty, dov)
    dov_new = Date("2020-01-02")
    money_new = money.with_dov(dov_new)
    assert money_new.ccy == ccy
    assert money_new.qty == qty
    assert money_new.dov == dov_new


# Generated at 2022-06-26 01:00:57.495779
# Unit test for method gt of class Money
def test_Money_gt():
    from .currencies import CcyFactory
    from .time import DateFactory
    from .money import Money
    ccy = CcyFactory.usd()
    ccy1 = CcyFactory.trx()
    qty = Decimal(100)
    qty1 = Decimal(112)
    qty2 = Decimal(100)
    dov = DateFactory.now()
    dov1 = DateFactory.tomorrow()
    dov2 = DateFactory.today()
    zero = Decimal(0)
    m1 = Money.of(ccy, qty1, dov1)
    m2 = Money.of(ccy1, qty, dov2)
    m3 = Money.of(ccy, qty, dov)

# Generated at 2022-06-26 01:00:59.936426
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    some_money_0 = SomeMoney()
    some_money_1 = SomeMoney()
    some_money_2 = some_money_0.__add__(some_money_1)
    assert some_money_2 is not None


# Generated at 2022-06-26 01:01:02.875209
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    ccy = Currency()
    qty = Decimal()
    dov = Date()
    some_price = SomePrice(ccy, qty, dov)
    dov2 = Date()
    p = some_price.with_dov(dov2)



# Generated at 2022-06-26 01:01:10.236777
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    some_price_0 = SomePrice()
    some_price_0_ccy = some_price_0.ccy
    some_price_0_dov = some_price_0.dov
    some_price_0_qty = some_price_0.qty
    some_price_1_ccy = (some_price_0.with_dov(some_price_0_ccy)).ccy
    some_price_1_dov = (some_price_0.with_dov(some_price_0_ccy)).dov
    some_price_1_qty = (some_price_0.with_dov(some_price_0_ccy)).qty
    assert some_price_1_ccy == some_price_0_ccy
    assert some_price_1_d

# Generated at 2022-06-26 01:01:18.070373
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():

    ## Arrange
    ccys = Currency.euro, Currency.dollar, Currency.pound
    qtys = Decimal("1"), Decimal("10"), Decimal("100")
    dovs = Date.today(), Date.today() + 1, Date.today() + 2

    ## Act/Assert
    try:
        SomePrice(ccys[0], qtys[0], dovs[0]).\
        convert(to=ccys[1], asof=dovs[1])

        assert False

    except ProgrammingError as exc:
        assert str(exc) == "Did you implement and set the default FX rate service?"

    ## Act/Assert