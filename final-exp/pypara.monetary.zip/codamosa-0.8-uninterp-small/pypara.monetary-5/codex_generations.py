

# Generated at 2022-06-26 00:57:22.733035
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .currencies import Currency as ccy
    from .zeitgeist import Date as dt

    # SomeMoney
    money_0 = SomeMoney(ccy.of('USD'), Decimal('0.1'), dt.of('2001-01-01'))
    number_0 = Decimal("0.001")
    expected_0 = SomeMoney(ccy.of('USD'), Decimal('100'), dt.of('2001-01-01'))
    money_actual_0 = money_0 / number_0
    assert money_actual_0.is_equal(expected_0)

    money_1 = SomeMoney(ccy.of('USD'), Decimal('0.1'), dt.of('2001-01-01'))
    number_1 = Decimal("-0.001")

# Generated at 2022-06-26 00:57:33.242080
# Unit test for method __add__ of class Money
def test_Money___add__():
    ccy = Currency.USD
    ccy2 = Currency.EUR
    m1 = Money.of(ccy, 100, Date.now())
    m2 = Money.of(ccy, 200, Date.now())
    m3 = m1.add(m2)
    assert m3.qty == Decimal('300')
    m4 = Money.of(ccy2, 100, Date.now())
    try:
        m5 = m1.add(m4)
    except IncompatibleCurrencyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 00:57:40.705778
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    # in the case of the base currency, we should get back the same price
    ccy_1 = Currency.of(code='EUR')
    ccy_2 = Currency.of(code='EUR')
    price = SomePrice(ccy=ccy_1, qty=Decimal('1.25'), dov=Date(year=2020, month=7, day=21))
    assert price.convert(ccy_2, Date(year=2020, month=7, day=22)) == price


# Generated at 2022-06-26 00:57:49.771376
# Unit test for method __add__ of class Money
def test_Money___add__():
    from .currencies import EUR, USD
    from .exchange import FXRateService
    from .money import Money, NoneMoney, SomeMoney
    eur_computation_fx_rate_service = FXRateService(
        {
            (EUR.code, USD.code): 1.12
        }
    )
    none_money_0 = NoneMoney()
    none_money_1 = NoneMoney()

# Generated at 2022-06-26 00:57:50.987359
# Unit test for method gt of class Price
def test_Price_gt():
    # test line 523 of price.py
    pass


# Generated at 2022-06-26 00:58:00.790662
# Unit test for method multiply of class Price
def test_Price_multiply():
    # Test 1
    price_1 = Price.of(None, 1, None)
    price_2 = price_1.multiply(2)
    assert price_1.is_equal(NonePrice())
    assert price_2.is_equal(Price.of(None, 1, None))

    # Test 2
    price_3 = Price.of(USD, 2, date(2018, 1, 1))
    price_4 = price_3.multiply(2)
    assert price_3.is_equal(Price.of(USD, 2, date(2018, 1, 1)))
    assert price_4.is_equal(Price.of(USD, 4, date(2018, 1, 1)))

    # Test 3
    price_5 = Price.of(USD, 2, None)

# Generated at 2022-06-26 00:58:03.989331
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    price = Price.of(ccy=CAD, qty=Decimal(1), dov=Date(2017, 11, 23))
    truth_value = price.__bool__()
    assert truth_value == True


# Generated at 2022-06-26 00:58:13.524211
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    from datetime import datetime
    from datetime import date
    date_zero = date.min
    date_object_one = date(2020, 4, 16)
    date_object_two = date(2020, 5, 29)
    date_zero_string = "0000-01-01"
    date_object_one_string = "2020-04-16"
    date_object_two_string = "2020-05-29"
    date_zero_string_iso = "0000-01-01T00:00:00"
    date_object_one_string_iso = "2020-04-16T00:00:00"
    date_object_two_string_iso = "2020-05-29T00:00:00"
    date_zero_string_alt = "00000101"
    date_object_one

# Generated at 2022-06-26 00:58:20.809532
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    d1 = Date(2018,6,27)
    c1 = Currency("USD")
    q1 = Decimal("1")
    some_price1 = SomePrice(c1,q1,d1)
    d2 = Date(2018,6,27)
    c2 = Currency("USD")
    q2 = Decimal("1.1")
    some_price2 = SomePrice(c2,q2,d2)
    try:
        result = some_price1.__gt__(some_price2)
    except Exception:
        print("Fail")
    else:
        print(result)
        print("Pass")


# Generated at 2022-06-26 00:58:29.242363
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    # Setup:
    ccy = Currency.USD
    qty = Decimal(123.45)
    dov = Date(2020, 1, 14)
    price_0 = SomePrice(ccy, qty, dov)
    qty_1 = Decimal(234.66)
    price_1 = SomePrice(ccy, qty_1, dov)

    # Invocation:
    result = price_0 - price_1

    # Assertion:
    assert type(result) is SomePrice and result == SomePrice(ccy, -111.21, dov)


# Generated at 2022-06-26 00:59:00.609868
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Setup
    some_price = Price.of(Currency.of("EUR"), Decimal(100), Date.of(2019, 2, 20))
    # Exercise
    actual = some_price.with_dov(Date.of(2019, 3, 1))
    # Post-process
    expected = SomePrice(Currency.of("EUR"), Decimal(100), Date.of(2019, 3, 1))
    # Verify
    assert expected == actual

    # Setup
    some_price = Price.of(Currency.of("EUR"), Decimal(100), Date.of(2019, 2, 20))
    # Exercise
    actual = some_price.with_dov(Date.of(2019, 2, 20))
    # Post-process

# Generated at 2022-06-26 00:59:04.085148
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    ccy = Currency()
    value = Decimal()
    date = Date()
    Money_instance_0 = Money.of(ccy, value, date)
    other = Money.of(ccy, value, date)
    boolean_0 = Money_instance_0.is_equal(other)


# Generated at 2022-06-26 00:59:09.459994
# Unit test for method __le__ of class Money
def test_Money___le__():

    # Test case 1
    ccy_1 = Currency('USD')
    obj_1 = Money.of(ccy_1, Decimal('1'), Date())
    other_1 = Decimal.__float__(Decimal('1'))
    result_1 = obj_1.__le__(other_1)


# Generated at 2022-06-26 00:59:10.731436
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    price_0 = Price()
    price_0.__bool__()


# Generated at 2022-06-26 00:59:21.444948
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    ccy, qty, dov = Currency.of("USD"), Decimal(0.0001), None
    price_0 = Price(ccy, qty, dov)
    price_1 = Price(ccy, qty, dov)
    bool_0 = price_0.__gt__(price_1)
    print(bool_0)

test_SomeMoney___gt__()

# Generated at 2022-06-26 00:59:26.113443
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    ccy = Currency.from_string("USD")
    qty = Decimal("1.00")
    dov = Date.from_string("2018-12-31")
    mny = SomeMoney(ccy, qty, dov)
    new_dov = Date.from_string("2019-04-31")
    result = mny.with_dov(new_dov)
    assert result.ccy == ccy
    assert result.qty == qty
    assert result.dov == new_dov


# Generated at 2022-06-26 00:59:36.946028
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ccy0=Currency(code="AUD", decimal_places=2, quantizer=Decimal("1.00"))
    qty0=Decimal("12.345")
    dov0=Date("2019-01-01")
    price0=SomePrice(ccy0, qty0, dov0)
    ccy1=Currency(code="USD", decimal_places=2, quantizer=Decimal("1.00"))
    asof0=Date("2019-02-01")
    price1=price0.convert(to=ccy1, asof=asof0, strict=True)
    assert isinstance(price1, SomePrice)
    assert price1.ccy==ccy1
    assert price1.qty==qty0
    assert price1.dov==asof0
    # testing the

# Generated at 2022-06-26 00:59:41.856090
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    money_0 = Money()
    money_1 = Money()
    money_0.__eq__(money_1)


# Generated at 2022-06-26 00:59:43.656727
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    price_0 = Price()
    ccy_0 = Currency()
    price_1 = price_0.with_ccy(ccy_0)
    assert price_1.__class__ == SomePrice


# Generated at 2022-06-26 00:59:45.292698
# Unit test for method gt of class Price
def test_Price_gt():
    try:
        price_0 = Price()
        price_0.gt(price_0)
        assert False
    except MonetaryOperationException:
        assert True
