

# Generated at 2022-06-18 02:53:28.316421
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).__bool__() is True
    assert SomePrice(USD, Decimal("0.0"), Date(2020, 1, 1)).__bool__() is False
    assert SomePrice(USD, Decimal("-1.0"), Date(2020, 1, 1)).__bool__() is True

# Generated at 2022-06-18 02:53:38.876906
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) - SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) == SomePrice(USD, Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) - SomePrice(USD, Decimal("1.0"), Date(2020, 1, 2)) == SomePrice(USD, Decimal("0.0"), Date(2020, 1, 2))
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 2)) - SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) == SomePrice(USD, Decimal("0.0"), Date(2020, 1, 2))
    assert SomePrice

# Generated at 2022-06-18 02:53:45.802453
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).scalar_subtract(Decimal('1.0')) == Price.of(USD, Decimal('0.0'), Date(2020, 1, 1))
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).scalar_subtract(1) == Price.of(USD, Decimal('0.0'), Date(2020, 1, 1))
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).scalar_subtract(1.0) == Price.of(USD, Decimal('0.0'), Date(2020, 1, 1))

# Generated at 2022-06-18 02:53:52.949216
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of(USD, Decimal("100"), Date.today()).divide(Decimal("2")) == Price.of(USD, Decimal("50"), Date.today())
    assert Price.of(USD, Decimal("100"), Date.today()).divide(Decimal("0")) == NoPrice
    assert Price.of(USD, Decimal("100"), Date.today()).divide(Decimal("2.5")) == Price.of(USD, Decimal("40"), Date.today())
    assert Price.of(USD, Decimal("100"), Date.today()).divide(Decimal("-2")) == Price.of(USD, Decimal("-50"), Date.today())

# Generated at 2022-06-18 02:54:04.042374
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert NoMoney == NoMoney
    assert SomeMoney(USD, Decimal(1), Date.today()) == SomeMoney(USD, Decimal(1), Date.today())
    assert SomeMoney(USD, Decimal(1), Date.today()) != SomeMoney(USD, Decimal(2), Date.today())
    assert SomeMoney(USD, Decimal(1), Date.today()) != SomeMoney(USD, Decimal(1), Date.today() + 1)
    assert SomeMoney(USD, Decimal(1), Date.today()) != SomeMoney(EUR, Decimal(1), Date.today())
    assert SomeMoney(USD, Decimal(1), Date.today()) != SomeMoney(USD, Decimal(1), Date.today() + 1)

# Generated at 2022-06-18 02:54:09.048495
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).as_float() == 1.0

# Generated at 2022-06-18 02:54:18.495517
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 02:54:29.611957
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 1)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 3)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 3))

# Generated at 2022-06-18 02:54:39.397273
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(Currency.USD, Decimal(1), Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == Price.of(Currency.USD, Decimal(1), Date(2020, 1, 2))
    assert Price.of(Currency.USD, Decimal(1), Date(2020, 1, 1)).with_dov(Date(2020, 1, 1)) == Price.of(Currency.USD, Decimal(1), Date(2020, 1, 1))
    assert Price.of(Currency.USD, Decimal(1), Date(2020, 1, 1)).with_dov(Date(2020, 1, 3)) == Price.of(Currency.USD, Decimal(1), Date(2020, 1, 3))

# Generated at 2022-06-18 02:54:40.505528
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    """
    Tests the method __floordiv__ of class Money
    """
    pass



# Generated at 2022-06-18 02:56:56.648456
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .currencies import USD
    from .money import Money
    from .money import NoMoney
    from .money import SomeMoney
    from .money import UndefinedMoney
    from .money import UndefinedPrice
    from .money import UndefinedQuantity
    from .money import UndefinedValueDate
    from .money import UndefinedCurrency
    from .money import UndefinedMoney
    from .money import UndefinedPrice
    from .money import UndefinedQuantity
    from .money import UndefinedValueDate
    from .money import UndefinedCurrency
    from .money import UndefinedMoney
    from .money import UndefinedPrice
    from .money import UndefinedQuantity
    from .money import UndefinedValueDate
    from .money import UndefinedCurrency
    from .money import UndefinedMoney
    from .money import UndefinedPrice
    from .money import UndefinedQuantity


# Generated at 2022-06-18 02:57:07.747829
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(NoPrice) == 0
    assert int(SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1))) == 1
    assert int(SomePrice(USD, Decimal("1.53"), Date(2020, 1, 1))) == 1
    assert int(SomePrice(USD, Decimal("1.93"), Date(2020, 1, 1))) == 1
    assert int(SomePrice(USD, Decimal("2.13"), Date(2020, 1, 1))) == 2
    assert int(SomePrice(USD, Decimal("2.53"), Date(2020, 1, 1))) == 2
    assert int(SomePrice(USD, Decimal("2.93"), Date(2020, 1, 1))) == 2
    assert int(SomePrice(USD, Decimal("3.13"), Date(2020, 1, 1))) == 3


# Generated at 2022-06-18 02:57:17.731250
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("2.0")) == Price.of(USD, Decimal("0.5"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("0.0")) == NoPrice
    assert NoPrice.divide(Decimal("2.0")) == NoPrice
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(2) == Price.of(USD, Decimal("0.5"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(0) == NoPrice
    assert NoPrice.divide(2) == NoPrice

# Generated at 2022-06-18 02:57:25.473384
# Unit test for method abs of class Price
def test_Price_abs():
    assert Price.of(USD, Decimal("-1.0"), Date(2018, 1, 1)).abs() == Price.of(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).abs() == Price.of(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("0.0"), Date(2018, 1, 1)).abs() == Price.of(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("-0.0"), Date(2018, 1, 1)).abs() == Price.of(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert Price.of

# Generated at 2022-06-18 02:57:34.488647
# Unit test for method abs of class Money
def test_Money_abs():
    assert Money.of(Currency.USD, Decimal("-1.0"), Date.today()).abs() == Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).abs() == Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("0.0"), Date.today()).abs() == Money.of(Currency.USD, Decimal("0.0"), Date.today())
    assert NoMoney.abs() == NoMoney

# Generated at 2022-06-18 02:57:45.022099
# Unit test for method __add__ of class Price
def test_Price___add__():
    assert Price.of(USD, Decimal("10.00"), Date.today()) + Price.of(USD, Decimal("20.00"), Date.today()) == Price.of(USD, Decimal("30.00"), Date.today())
    assert Price.of(USD, Decimal("10.00"), Date.today()) + Price.of(USD, Decimal("20.00"), Date.today()) != Price.of(USD, Decimal("30.00"), Date.today() + timedelta(days=1))
    assert Price.of(USD, Decimal("10.00"), Date.today()) + Price.of(USD, Decimal("20.00"), Date.today()) != Price.of(USD, Decimal("30.00"), Date.today() - timedelta(days=1))

# Generated at 2022-06-18 02:57:50.689893
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date

    assert Money.of(USD, 1.0, Date.today()).as_integer() == 1
    assert Money.of(USD, 1.5, Date.today()).as_integer() == 1
    assert Money.of(USD, 1.6, Date.today()).as_integer() == 2
    assert Money.of(USD, -1.0, Date.today()).as_integer() == -1
    assert Money.of(USD, -1.5, Date.today()).as_integer() == -1
    assert Money.of(USD, -1.6, Date.today()).as_integer() == -2
    assert Money.of(USD, 0.0, Date.today()).as_integer() == 0
   

# Generated at 2022-06-18 02:57:59.973196
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) / Decimal("2.0") == SomePrice(USD, Decimal("0.5"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) / 2.0 == SomePrice(USD, Decimal("0.5"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) / 2 == SomePrice(USD, Decimal("0.5"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) / Decimal("0.0") == NoPrice

# Generated at 2022-06-18 02:58:06.919121
# Unit test for method __sub__ of class Price

# Generated at 2022-06-18 02:58:15.975759
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05ODD
    from decimal import ROUND_TRUNCATE
    from decimal import ROUND_ROUND_HALF_EVEN
    from decimal import ROUND_ROUND_HALF_UP

# Generated at 2022-06-18 02:58:33.510927
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    m1 = Money.of(USD, Decimal("100.00"), Date(2018, 1, 1))
    m2 = m1.with_dov(Date(2018, 1, 2))
    assert m2.dov == Date(2018, 1, 2)
    assert m2.ccy == USD
    assert m2.qty == Decimal("100.00")
    assert m2.dov == Date(2018, 1, 2)
    assert m1.dov == Date(2018, 1, 1)
    assert m1.ccy == USD
    assert m1.qty == Decimal("100.00")
    assert m1.dov == Date(2018, 1, 1)

# Generated at 2022-06-18 02:58:38.188421
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(Currency.USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(Currency.USD, Decimal(0), Date(2020, 1, 1))
    assert SomePrice(Currency.USD, Decimal(1), Date(2020, 1, 1)) > NoPrice
    assert not SomePrice(Currency.USD, Decimal(0), Date(2020, 1, 1)) > SomePrice(Currency.USD, Decimal(1), Date(2020, 1, 1))
    assert not SomePrice(Currency.USD, Decimal(0), Date(2020, 1, 1)) > NoPrice
    assert not NoPrice > SomePrice(Currency.USD, Decimal(1), Date(2020, 1, 1))
    assert not NoPrice > NoPrice

# Generated at 2022-06-18 02:58:49.382874
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    assert SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 1)) == SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 3)) == SomeMoney(USD, Decimal("1.0"), Date(2020, 1, 3))

# Generated at 2022-06-18 02:58:56.648786
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert SomeMoney(USD, Decimal("1.0"), Date.today()).as_integer() == 1
    assert SomeMoney(USD, Decimal("1.5"), Date.today()).as_integer() == 1
    assert SomeMoney(USD, Decimal("1.9"), Date.today()).as_integer() == 1
    assert SomeMoney(USD, Decimal("2.0"), Date.today()).as_integer() == 2
    assert SomeMoney(USD, Decimal("2.5"), Date.today()).as_integer() == 2
    assert SomeMoney(USD, Decimal("2.9"), Date.today()).as_integer() == 2
    assert SomeMoney(USD, Decimal("3.0"), Date.today()).as_integer() == 3

# Generated at 2022-06-18 02:59:06.425619
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23

# Generated at 2022-06-18 02:59:18.249481
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.5"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.6"), Date.today()).as_integer() == 2
    assert Money.of(Currency.USD, Decimal("-1.0"), Date.today()).as_integer() == -1
    assert Money.of(Currency.USD, Decimal("-1.5"), Date.today()).as_integer() == -1
    assert Money.of(Currency.USD, Decimal("-1.6"), Date.today()).as_integer() == -2

# Generated at 2022-06-18 02:59:24.543991
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from .currencies import Currency
    from .money import Money
    from .money import SomeMoney
    from decimal import Decimal
    from datetime import date
    from datetime import datetime
    from datetime import time
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from fractions import Fraction
    from fractions import gcd
    from fractions import _Rational
    from fractions import _normalize
    from fractions import _normalized
    from fractions import _operator_fallbacks
    from fractions import _gcd
    from fractions import _gcd_iter
    from fractions import _gcd_eval
    from fractions import _gcd_exact
    from fractions import _gcd_generic
    from fractions import _gcd_rational
    from fractions import _gcd_float
    from fractions import _

# Generated at 2022-06-18 02:59:34.266105
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_integer() == 1

# Generated at 2022-06-18 02:59:36.830993
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert Price.NA.__float__() == 0.0
    assert Price.of(EUR, Decimal(1), Date.today()).__float__() == 1.0


# Generated at 2022-06-18 02:59:41.027224
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import USD, EUR
    from .money import Money, SomeMoney, NoMoney
    from .commons.zeitgeist import Date
    from .exchange import FXRateService

    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class Money
    # Test for method __sub__ of class