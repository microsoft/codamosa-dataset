

# Generated at 2022-06-18 02:56:03.315181
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from .currencies import USD
    from .zeitgeist import Date
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import NoneMoney
    from .money import NonePrice
    from .money import SomePrice
    from .money import Price
    from .money import NoPrice
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import Money
    from .money import Price
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import Money
    from .money import Price
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import Money
    from .money import Price
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrency

# Generated at 2022-06-18 02:56:12.484726
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(USD, Decimal("1.5"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 1)) == Price.of(EUR, Decimal("1.5"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.5"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 2)) == Price.of(EUR, Decimal("1.5"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.5"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 3)) == Price.of(EUR, Decimal("1.5"), Date(2020, 1, 3))

# Generated at 2022-06-18 02:56:20.163762
# Unit test for method __eq__ of class Money

# Generated at 2022-06-18 02:56:28.587587
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1

# Generated at 2022-06-18 02:56:35.147231
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.NA.gte(Price.NA)
    assert Price.NA.gte(Price.of(USD, Decimal("1.0"), Date.today()))
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.NA)
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("1.0"), Date.today()))
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("0.5"), Date.today()))
    assert not Price.of(USD, Decimal("0.5"), Date.today()).gte(Price.of(USD, Decimal("1.0"), Date.today()))

# Generated at 2022-06-18 02:56:42.610497
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert Money.of(Currency.USD, Decimal("1"), Date.today()).__gt__(Money.of(Currency.USD, Decimal("0"), Date.today()))
    assert not Money.of(Currency.USD, Decimal("0"), Date.today()).__gt__(Money.of(Currency.USD, Decimal("1"), Date.today()))
    assert not Money.of(Currency.USD, Decimal("1"), Date.today()).__gt__(Money.of(Currency.USD, Decimal("1"), Date.today()))
    assert not Money.of(Currency.USD, Decimal("1"), Date.today()).__gt__(Money.of(Currency.USD, Decimal("1"), Date.today()))

# Generated at 2022-06-18 02:56:54.210330
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_float() == 1.0

# Generated at 2022-06-18 02:57:04.818947
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, Decimal(100), Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == Price.of(USD, Decimal(100), Date(2020, 1, 2))
    assert Price.of(USD, Decimal(100), Date(2020, 1, 1)).with_dov(Date(2020, 1, 1)) == Price.of(USD, Decimal(100), Date(2020, 1, 1))
    assert Price.of(USD, Decimal(100), Date(2020, 1, 1)).with_dov(Date(2020, 1, 3)) == Price.of(USD, Decimal(100), Date(2020, 1, 3))
    assert Price.of(USD, Decimal(100), Date(2020, 1, 1)).with_dov(Date(2020, 1, 4))

# Generated at 2022-06-18 02:57:15.937313
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import USD, EUR
    from .dates import today
    from .money import Money, SomeMoney
    from .prices import Price, SomePrice

    m1 = Money.of(USD, 100, today())
    assert m1.ccy == USD
    assert m1.qty == 100
    assert m1.dov == today()
    assert m1.defined
    assert not m1.undefined
    assert m1.as_boolean()
    assert m1.as_float() == 100.0
    assert m1.as_integer() == 100
    assert m1.abs() == m1
    assert m1.negative() == Money.of(USD, -100, today())
    assert m1.positive() == m1
    assert m1.round() == Money.of(USD, 100, today())
   

# Generated at 2022-06-18 02:57:23.937755
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1

# Generated at 2022-06-18 02:58:09.828060
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(3) == SomeMoney(USD, Decimal("1.235"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(4) == SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1))
    assert SomeMoney

# Generated at 2022-06-18 02:58:19.300263
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    assert NoMoney < NoMoney
    assert NoMoney < SomeMoney(Currency.USD, Decimal("1"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1"), Date.today()) < NoMoney
    assert SomeMoney(Currency.USD, Decimal("1"), Date.today()) < SomeMoney(Currency.USD, Decimal("2"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1"), Date.today()) < SomeMoney(Currency.USD, Decimal("1"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1"), Date.today()) < SomeMoney(Currency.USD, Decimal("1.1"), Date.today())

# Generated at 2022-06-18 02:58:22.469863
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    # Arrange
    from .currencies import USD
    from .money import Money, SomeMoney

    # Act
    m = Money.of(USD, 1, Date.today())

    # Assert
    assert m == +m

# Generated at 2022-06-18 02:58:28.719614
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.of(USD, Decimal("10"), Date(2020, 1, 1)).floor_divide(Decimal("2")) == Price.of(USD, Decimal("5"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10"), Date(2020, 1, 1)).floor_divide(Decimal("2.5")) == Price.of(USD, Decimal("4"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10"), Date(2020, 1, 1)).floor_divide(Decimal("0")) == NoPrice
    assert Price.of(USD, Decimal("10"), Date(2020, 1, 1)).floor_divide(Decimal("-2")) == Price.of(USD, Decimal("-5"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:40.009246
# Unit test for method __truediv__ of class Price

# Generated at 2022-06-18 02:58:52.117378
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).is_equal(Money.of(Currency.USD, Decimal("1.0"), Date.today()))
    assert not Money.of(Currency.USD, Decimal("1.0"), Date.today()).is_equal(Money.of(Currency.USD, Decimal("1.0"), Date.today() + 1))
    assert not Money.of(Currency.USD, Decimal("1.0"), Date.today()).is_equal(Money.of(Currency.USD, Decimal("2.0"), Date.today()))

# Generated at 2022-06-18 02:58:59.823954
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    assert SomeMoney(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomeMoney(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomeMoney(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomeMoney(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomeMoney(USD, Decimal("0.0"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:59:06.141064
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).scalar_add(Decimal("1.0")) == Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).scalar_add(Decimal("-1.0")) == Money.of(Currency.USD, Decimal("0.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).scalar_add(Decimal("0.0")) == Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).sc

# Generated at 2022-06-18 02:59:18.001385
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(USD, Decimal("10.0"), Date(2019, 1, 1)).multiply(Decimal("2.0")) == Price.of(USD, Decimal("20.0"), Date(2019, 1, 1))
    assert Price.of(USD, Decimal("10.0"), Date(2019, 1, 1)).multiply(Decimal("2.0")) != Price.of(USD, Decimal("20.0"), Date(2019, 1, 2))
    assert Price.of(USD, Decimal("10.0"), Date(2019, 1, 1)).multiply(Decimal("2.0")) != Price.of(EUR, Decimal("20.0"), Date(2019, 1, 1))

# Generated at 2022-06-18 02:59:27.666538
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("10"), Date.today()).__mul__(Decimal("10")) == Price.of(USD, Decimal("100"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).__mul__(Decimal("0")) == Price.of(USD, Decimal("0"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).__mul__(Decimal("-10")) == Price.of(USD, Decimal("-100"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).__mul__(Decimal("10.5")) == Price.of(USD, Decimal("105"), Date.today())