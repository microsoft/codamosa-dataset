

# Generated at 2022-06-18 02:56:11.740882
# Unit test for method times of class Price

# Generated at 2022-06-18 02:56:19.367666
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import USD
    from .exchange import FXRateService
    from .money import Money, SomeMoney
    from .zeitgeist import Date

    fx = FXRateService()
    fx.set_rate(USD, USD, 1.0)

    m1 = SomeMoney(USD, 10.0, Date(2020, 1, 1))
    m2 = SomeMoney(USD, 20.0, Date(2020, 1, 1))
    m3 = m1.subtract(m2)
    assert m3.ccy == USD
    assert m3.qty == -10.0
    assert m3.dov == Date(2020, 1, 1)

    m1 = SomeMoney(USD, 10.0, Date(2020, 1, 1))

# Generated at 2022-06-18 02:56:27.882704
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from decimal import Decimal
    from datetime import date
    from pymonies.currencies import Currency
    from pymonies.money import Money
    from pymonies.exchange import FXRateService
    from pymonies.commons.zeitgeist import Date
    from pymonies.commons.numbers import Numeric
    from pymonies.money import MonetaryOperationException
    from pymonies.money import IncompatibleCurrencyError
    from pymonies.money import Money
    from pymonies.money import NoMoney
    from pymonies.money import SomeMoney
    from pymonies.money import Price
    from pymonies.money import NoPrice
    from pymonies.money import SomePrice
    from pymonies.money import NoneMoney
    from pymonies.money import NonePrice
    from pymonies.money import Monetary

# Generated at 2022-06-18 02:56:32.305958
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    """
    Tests method __le__ of class SomePrice.
    """
    ## Arrange:
    ccy = Currency("USD")
    qty = Decimal("100")
    dov = Date(2019, 1, 1)
    price = SomePrice(ccy, qty, dov)

    ## Act:
    result = price <= price

    ## Assert:
    assert result is True

# Generated at 2022-06-18 02:56:37.565570
# Unit test for method round of class Price
def test_Price_round():
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round() == 1
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(0) == 1
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(1) == Price.of(USD, Decimal("1.2"), Date.today())
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(2) == Price.of(USD, Decimal("1.23"), Date.today())
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(3) == Price.of(USD, Decimal("1.235"), Date.today())

# Generated at 2022-06-18 02:56:45.671173
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__floordiv__(Decimal("1.0")) == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__floordiv__(Decimal("2.0")) == Price.of(USD, Decimal("0.5"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__floordiv__(Decimal("0.0")) == NoPrice
    assert Price.of(USD, Decimal("1.0"), Date.today()).__floordiv__(Decimal("-1.0")) == Price.of(USD, Decimal("-1.0"), Date.today())

# Generated at 2022-06-18 02:56:57.723108
# Unit test for method add of class Price
def test_Price_add():
    assert Price.of(USD, Decimal("100.00"), Date(2018, 1, 1)) + Price.of(USD, Decimal("200.00"), Date(2018, 1, 1)) == Price.of(USD, Decimal("300.00"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("100.00"), Date(2018, 1, 1)) + Price.of(USD, Decimal("200.00"), Date(2018, 1, 2)) == Price.of(USD, Decimal("300.00"), Date(2018, 1, 2))

# Generated at 2022-06-18 02:57:08.817015
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert not SomePrice(USD, Decimal("2.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert not SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert not SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < NoPrice
    assert not NoPrice < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert not NoPrice < NoPrice

# Generated at 2022-06-18 02:57:18.637694
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    """
    Tests the scalar addition of money.
    """
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()) + Decimal("10.00") == Money.of(
        Currency.USD, Decimal("110.00"), Date.today()
    )
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()) + 10 == Money.of(
        Currency.USD, Decimal("110.00"), Date.today()
    )
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()) + 10.0 == Money.of(
        Currency.USD, Decimal("110.00"), Date.today()
    )
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()) + 10.

# Generated at 2022-06-18 02:57:26.106516
# Unit test for method add of class Price
def test_Price_add():
    assert Price.of(USD, 100, Date(2018, 1, 1)) + Price.of(USD, 100, Date(2018, 1, 1)) == Price.of(USD, 200, Date(2018, 1, 1))
    assert Price.of(USD, 100, Date(2018, 1, 1)) + Price.of(USD, 100, Date(2018, 1, 2)) == Price.of(USD, 200, Date(2018, 1, 2))
    assert Price.of(USD, 100, Date(2018, 1, 1)) + Price.of(USD, 100, Date(2018, 1, 3)) == Price.of(USD, 200, Date(2018, 1, 3))

# Generated at 2022-06-18 02:58:43.016158
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0
    assert Price.of(USD, Decimal("1.0"), Date.today()).as_float() == 1.0

# Generated at 2022-06-18 02:58:54.087345
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("2.0")) == Money.of(USD, Decimal("2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("0.0")) == Money.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("-2.0")) == Money.of(USD, Decimal("-2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("-0.0")) == Money.of(USD, Decimal("0.0"), Date.today())

# Generated at 2022-06-18 02:58:59.407587
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    # Setup
    ccy1 = Currency.of("USD")
    ccy2 = Currency.of("EUR")
    qty = Decimal(100)
    dov = Date.today()
    money = SomeMoney(ccy1, qty, dov)
    asof = Date.today()
    strict = False
    # Exercise
    result = money.convert(ccy2, asof, strict)
    # Verify
    assert result.ccy == ccy2
    assert result.qty == qty
    assert result.dov == asof


# Generated at 2022-06-18 02:59:07.107513
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    from datetime import date
    from pyexlatex.models.item import NoOptions
    from pyexlatex.models.section.base import TextAreaMixin
    from pyexlatex.models.template import Template
    from pyexlatex.models.format.breaks import LineBreak
    from pyexlatex.models.format.fonts.sizes import LargeText
    from pyexlatex.models.format.fonts.sizes import SmallText
    from pyexlatex.models.format.fonts.sizes import TinyText
    from pyexlatex.models.format.fonts.sizes import LargeText
    from pyexlatex.models.format.fonts.sizes import SmallText
    from pyexlatex.models.format.fonts.sizes import TinyText

# Generated at 2022-06-18 02:59:16.250059
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import USD
    from .zeitgeist import Date
    from .money import Money
    from decimal import Decimal
    m = Money.of(USD, Decimal('1.2345'), Date.today())
    assert m.with_qty(Decimal('2.3456')).qty == Decimal('2.3456')
    assert m.with_qty(Decimal('2.3456')).ccy == USD
    assert m.with_qty(Decimal('2.3456')).dov == Date.today()

# Generated at 2022-06-18 02:59:18.166786
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    """
    Tests the __ge__ method of class SomePrice
    """
    pass

# Generated at 2022-06-18 02:59:27.725317
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert SomeMoney(ccy=Currency.USD, qty=Decimal("1.0"), dov=Date.today()) >= SomeMoney(ccy=Currency.USD, qty=Decimal("1.0"), dov=Date.today())
    assert SomeMoney(ccy=Currency.USD, qty=Decimal("1.0"), dov=Date.today()) >= SomeMoney(ccy=Currency.USD, qty=Decimal("0.0"), dov=Date.today())
    assert not SomeMoney(ccy=Currency.USD, qty=Decimal("0.0"), dov=Date.today()) >= SomeMoney(ccy=Currency.USD, qty=Decimal("1.0"), dov=Date.today())

# Generated at 2022-06-18 02:59:32.894084
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import USD, EUR
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .money import Money
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import NoMoney
    from .money import SomeMoney
    from .money import NoPrice
    from .money import SomePrice
    from .money import Price
    from .money import NoneMoney
    from .money import NonePrice
    from .money import Money
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import NoMoney
    from .money import SomeMoney
    from .money import NoPrice
    from .money import SomePrice
    from .money import Price
    from .money import NoneMoney
    from .money import NonePrice

# Generated at 2022-06-18 02:59:42.970470
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("2.0")) == Price.of(USD, Decimal("2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(2) == Price.of(USD, Decimal("2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(2.0) == Price.of(USD, Decimal("2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(2.0 + 0j) == Price.of(USD, Decimal("2.0"), Date.today())
    assert Price

# Generated at 2022-06-18 02:59:50.777359
# Unit test for method multiply of class Price