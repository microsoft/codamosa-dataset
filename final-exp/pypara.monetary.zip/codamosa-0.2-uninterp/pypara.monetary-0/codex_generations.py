

# Generated at 2022-06-18 02:56:49.319521
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_float() == 1.23

# Generated at 2022-06-18 02:57:01.593037
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(Money.of(Currency.USD, Decimal("1.2345"), Date.today())) == 1.2345
    assert float(Money.of(Currency.USD, Decimal("1.2345"), Date.today()).with_qty(Decimal("2.3456"))) == 2.3456
    assert float(Money.of(Currency.USD, Decimal("1.2345"), Date.today()).with_ccy(Currency.EUR)) == 1.2345
    assert float(Money.of(Currency.USD, Decimal("1.2345"), Date.today()).with_dov(Date.today() + 1)) == 1.2345

# Generated at 2022-06-18 02:57:12.151695
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from datetime import date
    from decimal import Decimal
    from finance.models import Currency, SomePrice
    from finance.models.money import SomeMoney

    assert SomePrice(Currency("USD"), Decimal("1.0"), date(2019, 1, 1)) + SomePrice(Currency("USD"), Decimal("2.0"), date(2019, 1, 1)) == SomePrice(Currency("USD"), Decimal("3.0"), date(2019, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), date(2019, 1, 1)) + SomePrice(Currency("USD"), Decimal("2.0"), date(2019, 1, 2)) == SomePrice(Currency("USD"), Decimal("3.0"), date(2019, 1, 2))

# Generated at 2022-06-18 02:57:18.082424
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert NoMoney.__ge__(NoMoney)
    assert NoMoney.__ge__(SomeMoney(Currency.USD, Decimal(1), Date.today()))
    assert SomeMoney(Currency.USD, Decimal(1), Date.today()).__ge__(NoMoney)
    assert SomeMoney(Currency.USD, Decimal(1), Date.today()).__ge__(SomeMoney(Currency.USD, Decimal(1), Date.today()))
    assert not SomeMoney(Currency.USD, Decimal(1), Date.today()).__ge__(SomeMoney(Currency.USD, Decimal(2), Date.today()))
    assert not SomeMoney(Currency.USD, Decimal(2), Date.today()).__ge__(SomeMoney(Currency.USD, Decimal(1), Date.today()))

# Generated at 2022-06-18 02:57:25.650772
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    from datetime import date
    from decimal import Decimal
    from pytz import UTC
    from dateutil.tz import tzoffset
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone

# Generated at 2022-06-18 02:57:35.579449
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, 1, Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == Price.of(USD, 1, Date(2020, 1, 2))
    assert Price.of(USD, 1, Date(2020, 1, 1)).with_dov(Date(2020, 1, 1)) == Price.of(USD, 1, Date(2020, 1, 1))
    assert Price.of(USD, 1, Date(2020, 1, 1)).with_dov(Date(2020, 1, 3)) == Price.of(USD, 1, Date(2020, 1, 3))
    assert Price.of(USD, 1, Date(2020, 1, 1)).with_dov(Date(2020, 1, 4)) == Price.of(USD, 1, Date(2020, 1, 4))
    assert Price

# Generated at 2022-06-18 02:57:45.568444
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_float() == 1.23

# Generated at 2022-06-18 02:57:51.084877
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).times(Decimal(2)) == Money.of(USD, Decimal(2), Date(2020, 1, 1))
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).times(Decimal(0)) == Money.of(USD, Decimal(0), Date(2020, 1, 1))
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).times(Decimal(-1)) == Money.of(USD, Decimal(-1), Date(2020, 1, 1))
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).times(Decimal(2.5)) == Money.of(USD, Decimal(2.5), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:55.190396
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert Price.NA.__bool__() == False
    assert Price.of(USD, Decimal(0), Date(2020, 1, 1)).__bool__() == False
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).__bool__() == True

# Generated at 2022-06-18 02:58:02.700298
# Unit test for method divide of class Money
def test_Money_divide():
    from decimal import Decimal
    from datetime import date
    from money import Money, Currency, NoneMoney, SomeMoney
    from money.exchange import FXRateService
    from money.exchange import FXRateLookupError
    from money.commons.numbers import Numeric
    from money.commons.zeitgeist import Date
    from money.commons.errors import ProgrammingError
    from money.commons.errors import IncompatibleCurrencyError
    from money.commons.errors import MonetaryOperationException
    from money.commons.errors import PriceOperationException
    from money.commons.errors import FXRateLookupError
    from money.commons.errors import FXRateServiceError
    from money.commons.errors import FXRateServiceUnavailableError
    from money.commons.errors import FXRateServiceTimeoutError

# Generated at 2022-06-18 02:58:41.035969
# Unit test for method with_qty of class Price

# Generated at 2022-06-18 02:58:52.548522
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    from decimal import Decimal
    from datetime import date
    from pyexlatex.currencies import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.money import SomeMoney
    from pyexlatex.models.money import NoMoney
    from pyexlatex.models.money import NoneMoney
    from pyexlatex.models.money import NonePrice
    from pyexlatex.models.money import SomePrice
    from pyexlatex.models.money import Price
    from pyexlatex.models.money import NoPrice
    from pyexlatex.models.money import Money
    from pyexlatex.models.money import MonetaryOperationException
    from pyexlatex.models.money import IncompatibleCurrencyError
    from pyexlatex.models.money import FXRateLookupError
   

# Generated at 2022-06-18 02:59:03.511178
# Unit test for method lte of class Money
def test_Money_lte():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("2.0"), Date.today())

# Generated at 2022-06-18 02:59:14.523256
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    """
    Tests method __le__ of class SomePrice
    """
    # Test with undefined price:
    assert NoPrice <= NoPrice
    assert NoPrice <= SomePrice(Currency.USD, Decimal("1.0"), Date.today())
    assert SomePrice(Currency.USD, Decimal("1.0"), Date.today()) <= NoPrice

    # Test with defined price:
    assert SomePrice(Currency.USD, Decimal("1.0"), Date.today()) <= SomePrice(Currency.USD, Decimal("1.0"), Date.today())
    assert SomePrice(Currency.USD, Decimal("1.0"), Date.today()) <= SomePrice(Currency.USD, Decimal("2.0"), Date.today())
    assert not SomePrice(Currency.USD, Decimal("2.0"), Date.today()) <= Some

# Generated at 2022-06-18 02:59:25.009713
# Unit test for method gte of class Money
def test_Money_gte():
    assert Money.of(Currency.USD, Decimal(1), Date.today()).gte(Money.of(Currency.USD, Decimal(1), Date.today()))
    assert Money.of(Currency.USD, Decimal(1), Date.today()).gte(Money.of(Currency.USD, Decimal(0), Date.today()))
    assert not Money.of(Currency.USD, Decimal(0), Date.today()).gte(Money.of(Currency.USD, Decimal(1), Date.today()))
    assert Money.of(Currency.USD, Decimal(0), Date.today()).gte(Money.of(Currency.USD, Decimal(0), Date.today()))
    assert Money.of(Currency.USD, Decimal(1), Date.today()).g

# Generated at 2022-06-18 02:59:30.020193
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Tests the method gte of class Money.
    """
    from .currencies import USD
    from .exchange import FXRateService
    from .money import Money
    from .zeitgeist import Date

    # Test 1:
    m1 = Money.of(USD, 1.0, Date.today())
    m2 = Money.of(USD, 2.0, Date.today())
    assert m1.gte(m2) is False
    assert m2.gte(m1) is True
    assert m1.gte(m1) is True
    assert m2.gte(m2) is True

    # Test 2:
    m1 = Money.of(USD, 1.0, Date.today())
    m2 = Money.of(USD, 1.0, Date.today())
    assert m1

# Generated at 2022-06-18 02:59:39.836808
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) < Price.of(USD, Decimal("1.1"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) < Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) < Price.of(EUR, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) < Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:59:49.371164
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(USD, Decimal(10), Date.today()).times(Decimal(2)) == Money.of(USD, Decimal(20), Date.today())
    assert Price.of(USD, Decimal(10), Date.today()).times(Decimal(0)) == Money.of(USD, Decimal(0), Date.today())
    assert Price.of(USD, Decimal(10), Date.today()).times(Decimal(-2)) == Money.of(USD, Decimal(-20), Date.today())
    assert Price.of(USD, Decimal(10), Date.today()).times(Decimal(2.5)) == Money.of(USD, Decimal(25), Date.today())
    assert Price.of(USD, Decimal(10), Date.today()).times(Decimal(-2.5)) == Money

# Generated at 2022-06-18 02:59:58.572988
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(EUR, Decimal("1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 03:00:09.279150
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("2.0")) == Price.of(USD, Decimal("2.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("0.0")) == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("-2.0")) == Price.of(USD, Decimal("-2.0"), Date.today())