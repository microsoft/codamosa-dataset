

# Generated at 2022-06-18 02:56:40.844294
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    ## Setup:
    ccy1 = Currency.of("USD")
    ccy2 = Currency.of("EUR")
    ccy3 = Currency.of("GBP")
    qty = Decimal("100.00")
    dov = Date.today()

    ## Exercise:
    money1 = SomeMoney(ccy1, qty, dov)
    money2 = money1.convert(ccy2)
    money3 = money1.convert(ccy3)

    ## Verify:
    assert money2.ccy == ccy2
    assert money2.qty == Decimal("90.00")
    assert money2.dov == dov

    assert money3.ccy == ccy3
    assert money3.qty == Decimal("80.00")
    assert money3.dov == dov

# Generated at 2022-06-18 02:56:51.117554
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date

    assert Money.of(USD, 1, Date(date(2020, 1, 1))).with_dov(Date(date(2020, 1, 2))) == Money.of(USD, 1, Date(date(2020, 1, 2)))
    assert Money.of(USD, 1, Date(date(2020, 1, 1))).with_dov(Date(date(2020, 1, 1))) == Money.of(USD, 1, Date(date(2020, 1, 1)))
    assert Money.of(USD, 1, Date(date(2020, 1, 1))).with_dov(Date(date(2020, 1, 3))) == Money.of(USD, 1, Date(date(2020, 1, 3)))


# Generated at 2022-06-18 02:57:03.177113
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    assert Price.of(Currency.USD, Decimal("10"), Date.today()).__truediv__(Decimal("2")) == Price.of(Currency.USD, Decimal("5"), Date.today())
    assert Price.of(Currency.USD, Decimal("10"), Date.today()).__truediv__(Decimal("0")) == NoPrice
    assert Price.of(Currency.USD, Decimal("10"), Date.today()).__truediv__(Decimal("-2")) == Price.of(Currency.USD, Decimal("-5"), Date.today())
    assert Price.of(Currency.USD, Decimal("10"), Date.today()).__truediv__(Decimal("2.5")) == Price.of(Currency.USD, Decimal("4"), Date.today())
    assert Price

# Generated at 2022-06-18 02:57:05.193531
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass

# Generated at 2022-06-18 02:57:15.980266
# Unit test for method gt of class Money
def test_Money_gt():
    assert Money.of(Currency.USD, Decimal("10.0"), Date.today()) > Money.of(Currency.USD, Decimal("5.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("10.0"), Date.today()) > Money.of(Currency.USD, Decimal("10.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("10.0"), Date.today()) > Money.of(Currency.USD, Decimal("15.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("10.0"), Date.today()) > Money.of(Currency.USD, Decimal("20.0"), Date.today())

# Generated at 2022-06-18 02:57:23.991322
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, 1, Date.today()))
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, 0, Date.today()))
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, -1, Date.today()))
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, -2, Date.today()))
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, -3, Date.today()))
    assert Price.of(USD, 1, Date.today()).gte(Price.of(USD, -4, Date.today()))
    assert Price

# Generated at 2022-06-18 02:57:29.064136
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.price import Price
    from pyexlatex.models.quantity import Quantity
    from pyexlatex.models.unit import Unit
    from pyexlatex.models.unit.length import LengthUnit
    from pyexlatex.models.unit.mass import MassUnit
    from pyexlatex.models.unit.temperature import TemperatureUnit
    from pyexlatex.models.unit.time import TimeUnit
    from pyexlatex.models.unit.volume import VolumeUnit
    from pyexlatex.models.unit.currency import CurrencyUnit
    from pyexlatex.models.unit.information import InformationUnit

# Generated at 2022-06-18 02:57:33.319608
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    from datetime import date
    from decimal import Decimal
    from finance.money import Currency
    from finance.money import SomePrice
    from finance.money import NoPrice
    from finance.money import IncompatibleCurrencyError
    from finance.money import ProgrammingError
    from finance.money import FXRateLookupError
    from finance.money import FXRateService
    from finance.money import Money
    from finance.money import SomeMoney
    from finance.money import NoMoney
    from finance.money import IncompatibleCurrencyError
    from finance.money import ProgrammingError
    from finance.money import FXRateLookupError
    from finance.money import FXRateService
    from finance.money import Money
    from finance.money import SomeMoney
    from finance.money import NoMoney
    from finance.money import IncompatibleCurrencyError
    from finance.money import ProgrammingError


# Generated at 2022-06-18 02:57:37.482580
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) - SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) == SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) - SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) == SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) - SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) == Some

# Generated at 2022-06-18 02:57:47.485123
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    """
    Tests method __gt__ of class SomePrice
    """
    # Test with undefined price
    price1 = Price.of(ccy=Currency.of("USD"), qty=Decimal(1), dov=Date.today())
    price2 = Price.of(ccy=Currency.of("USD"), qty=None, dov=Date.today())
    assert price1.__gt__(price2) == True
    # Test with defined price
    price1 = Price.of(ccy=Currency.of("USD"), qty=Decimal(1), dov=Date.today())
    price2 = Price.of(ccy=Currency.of("USD"), qty=Decimal(2), dov=Date.today())
    assert price1.__gt__(price2) == False
    # Test with different

# Generated at 2022-06-18 02:59:16.198200
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    from datetime import date
    from decimal import Decimal
    from finance.models import Currency, SomePrice
    from finance.services import FXRateService
    from finance.services.fx import FXRate

    ## Define a currency:
    USD = Currency("USD", "US Dollar", "United States of America", Decimal("0.01"))

    ## Define a price:
    price = SomePrice(USD, Decimal("12.3456"), date(2020, 1, 1))

    ## Define another price:
    other = SomePrice(USD, Decimal("12.3456"), date(2020, 1, 1))

    ## Define a price with different currency:

# Generated at 2022-06-18 02:59:26.337133
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(Currency("USD"), Decimal("2.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 2))
    assert not SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:59:31.139202
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    assert NoMoney < NoMoney
    assert NoMoney < SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < NoMoney
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < SomeMoney(Currency.USD, Decimal("2.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("2.0"), Date.today()) < SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < SomeMoney(Currency.EUR, Decimal("2.0"), Date.today())

# Generated at 2022-06-18 02:59:41.995168
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.of(USD, Decimal("-1"), Date(2020, 1, 1)).__abs__() == Price.of(USD, Decimal("1"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1"), Date(2020, 1, 1)).__abs__() == Price.of(USD, Decimal("1"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("0"), Date(2020, 1, 1)).__abs__() == Price.of(USD, Decimal("0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("-0"), Date(2020, 1, 1)).__abs__() == Price.of(USD, Decimal("0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:59:48.989479
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, Decimal(1), Date(2019, 1, 1)).with_dov(Date(2019, 1, 2)) == Price.of(USD, Decimal(1), Date(2019, 1, 2))
    assert Price.of(USD, Decimal(1), Date(2019, 1, 1)).with_dov(None) == Price.of(USD, Decimal(1), Date(2019, 1, 1))
    assert NoPrice.with_dov(Date(2019, 1, 2)) == NoPrice
    assert NoPrice.with_dov(None) == NoPrice


# Generated at 2022-06-18 02:59:58.314998
# Unit test for method __add__ of class Price

# Generated at 2022-06-18 03:00:08.691820
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 1)).with_dov(Date(2018, 1, 2)) == Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 2))
    assert Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 1)).with_dov(Date(2018, 1, 1)) == Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 1)).with_dov(Date(2018, 1, 3)) == Price.of(Currency.USD, Decimal("1.0"), Date(2018, 1, 3))

# Generated at 2022-06-18 03:00:17.379167
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomePrice(USD, Decimal("0.0"), Date(2018, 1, 1))
    assert not SomePrice(USD, Decimal("0.0"), Date(2018, 1, 1)) > SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert not SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) > SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert not SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) > NoPrice
    assert not NoPrice > SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert not NoPrice > NoPrice

# Generated at 2022-06-18 03:00:23.181190
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert SomePrice(USD, Decimal("100.00"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 1)) == SomePrice(EUR, Decimal("90.00"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("100.00"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 2)) == SomePrice(EUR, Decimal("91.00"), Date(2020, 1, 2))
    assert SomePrice(USD, Decimal("100.00"), Date(2020, 1, 1)).convert(EUR, Date(2020, 1, 3)) == SomePrice(EUR, Decimal("92.00"), Date(2020, 1, 3))

# Generated at 2022-06-18 03:00:29.784566
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    from datetime import date
    from decimal import Decimal
    from fin.book.domain import Currency, SomePrice
    from fin.book.domain.price import IncompatibleCurrencyError

    ccy1 = Currency.of("USD")
    ccy2 = Currency.of("EUR")
    qty1 = Decimal("1.00")
    qty2 = Decimal("2.00")
    dov1 = date(2018, 1, 1)
    dov2 = date(2018, 1, 2)

    price1 = SomePrice(ccy1, qty1, dov1)
    price2 = SomePrice(ccy1, qty2, dov2)
    price3 = SomePrice(ccy2, qty1, dov1)
