

# Generated at 2022-06-18 02:57:23.613492
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert NoPrice.with_ccy(USD) == NoPrice
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)).with_ccy(USD) == SomePrice(USD, Decimal(1), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)).with_ccy(EUR) == SomePrice(EUR, Decimal(1), Date(2020, 1, 1))


# Generated at 2022-06-18 02:57:34.294139
# Unit test for method subtract of class Price

# Generated at 2022-06-18 02:57:37.271378
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    assert NoneMoney.with_dov(Date(2020, 1, 1)) == NoneMoney

# Generated at 2022-06-18 02:57:46.083240
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("1.0")) == Money.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).times(Decimal("0.0")) == Money.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("0.0"), Date.today()).times(Decimal("1.0")) == Money.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("0.0"), Date.today()).times(Decimal("0.0")) == Money.of(USD, Decimal("0.0"), Date.today())

# Generated at 2022-06-18 02:57:51.473122
# Unit test for method lte of class Money
def test_Money_lte():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) <= Money.of(Currency.USD, Decimal("2.0"), Date.today())

# Generated at 2022-06-18 02:57:57.393239
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert NoPrice.__abs__() == NoPrice
    assert SomePrice(USD, Decimal("-10.0"), Date(2020, 1, 1)).__abs__() == SomePrice(USD, Decimal("10.0"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("10.0"), Date(2020, 1, 1)).__abs__() == SomePrice(USD, Decimal("10.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:04.104408
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05ODD
    from decimal import ROUND_TOWARD_ZERO
    from decimal import ROUND_TOWARD_POSITIVE
    from decimal import ROUND_TOWARD

# Generated at 2022-06-18 02:58:11.476962
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__ge__(Price.of(USD, Decimal("1.0"), Date.today())) == True
    assert Price.of(USD, Decimal("1.0"), Date.today()).__ge__(Price.of(USD, Decimal("1.0"), Date.today())) == True
    assert Price.of(USD, Decimal("1.0"), Date.today()).__ge__(Price.of(USD, Decimal("1.0"), Date.today())) == True
    assert Price.of(USD, Decimal("1.0"), Date.today()).__ge__(Price.of(USD, Decimal("1.0"), Date.today())) == True

# Generated at 2022-06-18 02:58:21.886570
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).as_integer() == 1

# Generated at 2022-06-18 02:58:28.380020
# Unit test for method lte of class Price
def test_Price_lte():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2020, 1, 2))