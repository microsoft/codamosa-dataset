

# Generated at 2022-06-18 02:54:31.649517
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert Price.of(USD, Decimal("10.0"), Date(2020, 1, 1)) - Price.of(USD, Decimal("5.0"), Date(2020, 1, 1)) == Price.of(USD, Decimal("5.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10.0"), Date(2020, 1, 1)) - Price.of(USD, Decimal("5.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("10.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:54:37.701474
# Unit test for method __le__ of class Money

# Generated at 2022-06-18 02:54:48.669108
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert NoPrice < NoPrice
    assert NoPrice < SomePrice(USD, Decimal(1), Date(1, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)) < NoPrice
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)) < SomePrice(USD, Decimal(2), Date(1, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)) < SomePrice(USD, Decimal(1), Date(1, 1, 2))
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)) < SomePrice(USD, Decimal(1), Date(1, 2, 1))
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)) < SomePrice

# Generated at 2022-06-18 02:54:56.191162
# Unit test for method __add__ of class SomePrice

# Generated at 2022-06-18 02:55:06.091302
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_TRUNCATE
    from decimal import ROUND_PASS_MINUS_INFINITY
    from decimal import ROUND_PASS_PLUS_INFINITY
    from decimal import ROUND

# Generated at 2022-06-18 02:55:14.393527
# Unit test for method __add__ of class Price

# Generated at 2022-06-18 02:55:19.309765
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1

# Generated at 2022-06-18 02:55:26.317587
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    assert (NoPrice > NoPrice) == False
    assert (NoPrice > SomePrice(USD, Decimal(1), Date(1, 1, 1))) == False
    assert (SomePrice(USD, Decimal(1), Date(1, 1, 1)) > NoPrice) == True
    assert (SomePrice(USD, Decimal(1), Date(1, 1, 1)) > SomePrice(USD, Decimal(1), Date(1, 1, 1))) == False
    assert (SomePrice(USD, Decimal(1), Date(1, 1, 1)) > SomePrice(USD, Decimal(1), Date(1, 1, 2))) == False
    assert (SomePrice(USD, Decimal(1), Date(1, 1, 1)) > SomePrice(USD, Decimal(2), Date(1, 1, 1))) == False

# Generated at 2022-06-18 02:55:30.801618
# Unit test for method subtract of class Money
def test_Money_subtract():
    assert Money.of(Currency.USD, Decimal(100), Date(2020, 1, 1)).subtract(Money.of(Currency.USD, Decimal(100), Date(2020, 1, 1))) == Money.of(Currency.USD, Decimal(0), Date(2020, 1, 1))
    assert Money.of(Currency.USD, Decimal(100), Date(2020, 1, 1)).subtract(Money.of(Currency.USD, Decimal(200), Date(2020, 1, 1))) == Money.of(Currency.USD, Decimal(-100), Date(2020, 1, 1))

# Generated at 2022-06-18 02:55:39.435321
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("1.0"), Date.today()))
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("0.0"), Date.today()))
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("-1.0"), Date.today()))
    assert Price.of(USD, Decimal("1.0"), Date.today()).gte(Price.of(USD, Decimal("1.0"), Date.today()))

# Generated at 2022-06-18 02:57:09.477986
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()).scalar_subtract(Decimal("50.00")) == Money.of(Currency.USD, Decimal("50.00"), Date.today())
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()).scalar_subtract(Decimal("50.00")) != Money.of(Currency.USD, Decimal("50.01"), Date.today())
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()).scalar_subtract(Decimal("50.00")) != Money.of(Currency.USD, Decimal("50.00"), Date.today() + 1)

# Generated at 2022-06-18 02:57:19.225443
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) >= SomeMoney(Currency.USD, Decimal("1.0"), Date.today()))
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) >= SomeMoney(Currency.USD, Decimal("0.0"), Date.today()))
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) >= SomeMoney(Currency.USD, Decimal("-1.0"), Date.today()))
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) >= SomeMoney(Currency.USD, Decimal("-2.0"), Date.today()))

# Generated at 2022-06-18 02:57:26.435466
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert float(Price.of(Currency.USD, Decimal("1.23"), Date.today())) == 1.23
    assert float(Price.of(Currency.USD, Decimal("1.23"), Date.today()).with_qty(Decimal("2.34"))) == 2.34
    assert float(Price.of(Currency.USD, Decimal("1.23"), Date.today()).with_ccy(Currency.EUR)) == 1.23
    assert float(Price.of(Currency.USD, Decimal("1.23"), Date.today()).with_dov(Date.today() + 1)) == 1.23

# Generated at 2022-06-18 02:57:35.628312
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import Currency
    from .exchange import FXRateService
    from .money import Money
    from .zeitgeist import Date
    import pytest
    from decimal import Decimal
    from datetime import datetime
    from .exchange import FXRateLookupError
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import MonetaryOperationException
    from .money import Money
    from .money import NoMoney
    from .money import NoPrice
    from .money import NoneMoney
    from .money import NonePrice
    from .money import Price
    from .money import SomeMoney
    from .money import SomePrice
    from .money import Money
    from .money import NoMoney
    from .money import NoPrice
    from .money import NoneMoney
    from .money import NonePrice

# Generated at 2022-06-18 02:57:45.509120
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    """
    Tests method __floordiv__ of class Money
    """
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money
    # Test for method __floordiv__ of class Money

# Generated at 2022-06-18 02:57:50.935778
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).with_ccy(EUR) == Price.of(EUR, Decimal("1.23"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).with_ccy(USD) == Price.of(USD, Decimal("1.23"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.23"), Date(2020, 1, 1)).with_ccy(JPY) == Price.of(JPY, Decimal("1.23"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:57.736860
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1)).convert(EUR, Date(2018, 1, 1)) == SomePrice(EUR, Decimal("1.23"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1)).convert(EUR, Date(2018, 1, 1), strict=True) == SomePrice(EUR, Decimal("1.23"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1)).convert(EUR, Date(2018, 1, 1), strict=False) == SomePrice(EUR, Decimal("1.23"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:58:04.413503
# Unit test for method gt of class Price
def test_Price_gt():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).gt(Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))) == False
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).gt(Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))) == False
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).gt(Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))) == False
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).gt(Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))) == False
    assert Price

# Generated at 2022-06-18 02:58:11.650402
# Unit test for method __le__ of class Money
def test_Money___le__():
    assert NoMoney <= NoMoney
    assert NoMoney <= SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) <= NoMoney
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) <= SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) <= SomeMoney(Currency.USD, Decimal("2.0"), Date.today())
    assert not SomeMoney(Currency.USD, Decimal("2.0"), Date.today()) <= SomeMoney(Currency.USD, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 02:58:22.026645
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1

# Generated at 2022-06-18 03:00:33.731565
# Unit test for method gt of class Money
def test_Money_gt():
    assert Money.of(Currency.USD, Decimal(1), Date.today()).gt(Money.of(Currency.USD, Decimal(0), Date.today()))

# Generated at 2022-06-18 03:00:43.291364
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date(2020, 1, 1)) < Price.of(ccy=USD, qty=Decimal("2.0"), dov=Date(2020, 1, 1))
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date(2020, 1, 1)) < Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date(2020, 1, 2))
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date(2020, 1, 1)) < Price.of(ccy=EUR, qty=Decimal("1.0"), dov=Date(2020, 1, 1))

# Generated at 2022-06-18 03:00:51.610364
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("1.0")) == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("0.0")) == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("-1.0")) == Price.of(USD, Decimal("-1.0"), Date.today())

# Generated at 2022-06-18 03:00:59.617086
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from datetime import date
    from decimal import Decimal
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.price import Price
    from pyexlatex.models.quantity import Quantity
    from pyexlatex.models.unit import Unit
    from pyexlatex.models.value import Value
    from pyexlatex.models.variable import Variable
    from pyexlatex.models.variable import VariableValue
    from pyexlatex.models.variable import VariableValueWithUnit
    from pyexlatex.models.variable import VariableValueWithUnitAndCurrency
    from pyexlatex.models.variable import VariableValueWithUnitAndCurrencyAndDate
    from pyexlatex.models.variable import VariableValueWithUnitAndCurrencyAndDateAndQuantity


# Generated at 2022-06-18 03:01:10.416004
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    assert NoPrice >= NoPrice
    assert NoPrice >= SomePrice(USD, 1, Date.today())
    assert SomePrice(USD, 1, Date.today()) >= NoPrice
    assert SomePrice(USD, 1, Date.today()) >= SomePrice(USD, 1, Date.today())
    assert SomePrice(USD, 1, Date.today()) >= SomePrice(USD, 0, Date.today())
    assert SomePrice(USD, 1, Date.today()) >= SomePrice(USD, 1, Date.today() + timedelta(days=1))
    assert SomePrice(USD, 1, Date.today()) >= SomePrice(USD, 1, Date.today() - timedelta(days=1))
    assert SomePrice(USD, 1, Date.today()) >= SomePrice(USD, 0, Date.today() + timedelta(days=1))
    assert Some

# Generated at 2022-06-18 03:01:21.958990
# Unit test for method __le__ of class Price
def test_Price___le__():
    assert Price.NA <= Price.NA
    assert Price.NA <= Price.of(USD, 1, TODAY)
    assert Price.of(USD, 1, TODAY) <= Price.of(USD, 1, TODAY)
    assert Price.of(USD, 1, TODAY) <= Price.of(USD, 2, TODAY)
    assert Price.of(USD, 1, TODAY) <= Price.of(USD, 1, TODAY + 1)
    assert Price.of(USD, 1, TODAY) <= Price.of(EUR, 1, TODAY)
    assert Price.of(USD, 1, TODAY) <= Price.of(EUR, 2, TODAY)
    assert Price.of(USD, 1, TODAY) <= Price.of(EUR, 1, TODAY + 1)

# Generated at 2022-06-18 03:01:30.992693
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    from pyexcel_xlsx import get_data
    from pyexcel_xlsx import save_data
    import os
    import pytest
    from decimal import Decimal
    from datetime import date
    from pyexcel_xlsx import get_data
    from pyexcel_xlsx import save_data
    import os
    import pytest
    from decimal import Decimal
    from datetime import date
    from pyexcel_xlsx import get_data
    from pyexcel_xlsx import save_data
    import os
    import pytest
    from decimal import Decimal
    from datetime import date
    from pyexcel_xlsx import get_data
    from pyexcel_xlsx import save_data
    import os
    import pytest
    from decimal import Decimal

# Generated at 2022-06-18 03:01:38.535528
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of(USD, Decimal("100"), Date(2020, 1, 1)).divide(Decimal("2")) == Price.of(USD, Decimal("50"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("100"), Date(2020, 1, 1)).divide(Decimal("0")) == Price.NA
    assert Price.NA.divide(Decimal("2")) == Price.NA
    assert Price.NA.divide(Decimal("0")) == Price.NA
