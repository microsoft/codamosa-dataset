

# Generated at 2022-06-18 02:57:05.059797
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.2345"), Date(2020, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2020, 1, 1)).round(1) == SomeMoney(USD, Decimal("1.2"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2020, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2020, 1, 1)).round(3) == SomeMoney(USD, Decimal("1.235"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:14.605539
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.price import Price, SomePrice
    from pyexlatex.models.quantity import Quantity
    from pyexlatex.models.unit import Unit

    price1 = SomePrice(Currency.USD, 1, date(2018, 1, 1))
    price2 = SomePrice(Currency.USD, 2, date(2018, 1, 1))
    price3 = SomePrice(Currency.USD, 2, date(2018, 1, 2))
    price4 = SomePrice(Currency.USD, 1, date(2018, 1, 2))
    price5 = SomePrice(Currency.USD, 1, date(2018, 1, 2))

# Generated at 2022-06-18 02:57:23.474434
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert Price.of(USD, Decimal(1), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal(1), Date(2020, 1, 1)))
    assert not Price.of(USD, Decimal(1), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal(2), Date(2020, 1, 1)))
    assert not Price.of(USD, Decimal(1), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal(1), Date(2020, 1, 2)))
    assert not Price.of(USD, Decimal(1), Date(2020, 1, 1)).is_equal(Price.of(EUR, Decimal(1), Date(2020, 1, 1)))

# Generated at 2022-06-18 02:57:28.151249
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert NoPrice.__neg__() == NoPrice
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).__neg__() == SomePrice(USD, Decimal("-1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:30.917154
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    assert NonePrice.with_dov(Date(2020, 1, 1)) == NoPrice

# Generated at 2022-06-18 02:57:42.617667
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.USD, 10, Date.today())
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.USD, 9, Date.today())
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.USD, 10, Date.today() - 1)
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.USD, 9, Date.today() - 1)
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.EUR, 10, Date.today())

# Generated at 2022-06-18 02:57:51.902100
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).as_float() == 1.23

# Generated at 2022-06-18 02:58:00.524068
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRate
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRate
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRate
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRate
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRate
    from .exchange import FXRateService
    from .exchange import FXRateLookup

# Generated at 2022-06-18 02:58:07.192888
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import USD, EUR
    from .exchange import FXRateService
    from .exchange.rates import FXRateProvider
    from .exchange.rates.ecb import ECBFXRateProvider
    from .exchange.rates.oanda import OandaFXRateProvider
    from .exchange.rates.yahoo import YahooFXRateProvider
    from .exchange.rates.google import GoogleFXRateProvider
    from .exchange.rates.fixer import FixerFXRateProvider
    from .exchange.rates.currencylayer import CurrencyLayerFXRateProvider
    from .exchange.rates.openexchangerates import OpenExchangeRatesFXRateProvider
    from .exchange.rates.alphavantage import AlphaVantageFXRateProvider
    from .exchange.rates.oneforge import OneForgeFXRateProvider

# Generated at 2022-06-18 02:58:16.288594
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1
    assert int(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1

# Generated at 2022-06-18 02:58:54.086385
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal("1.23"), Date(2018, 1, 1)).__float__() == 1.23

# Generated at 2022-06-18 02:59:00.973435
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import Currency
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import NoneMoney
    from .money import NonePrice
    from .money import SomePrice
    from .money import NoPrice
    from .money import Price
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import MonetaryOperationException
    from .money import Money
    from .money import NoMoney
    from .money import NoPrice
    from .money import NoneMoney
    from .money import NonePrice
    from .money import SomeMoney
    from .money import SomePrice
    from .money import Price
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import MonetaryOperationException
    from .money import Money

# Generated at 2022-06-18 02:59:06.862293
# Unit test for method __add__ of class Price

# Generated at 2022-06-18 02:59:18.618447
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1

# Generated at 2022-06-18 02:59:28.128153
# Unit test for method gt of class Price
def test_Price_gt():
    assert NoPrice.gt(NoPrice) == False
    assert NoPrice.gt(SomePrice(USD, Decimal(1), Date(1, 1, 1))) == False
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)).gt(NoPrice) == True
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)).gt(SomePrice(USD, Decimal(1), Date(1, 1, 1))) == False
    assert SomePrice(USD, Decimal(1), Date(1, 1, 1)).gt(SomePrice(USD, Decimal(2), Date(1, 1, 1))) == False
    assert SomePrice(USD, Decimal(2), Date(1, 1, 1)).gt(SomePrice(USD, Decimal(1), Date(1, 1, 1))) == True
   

# Generated at 2022-06-18 02:59:38.227574
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)))
    assert not Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal("1.0"), Date(2020, 1, 2)))
    assert not Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).is_equal(Price.of(USD, Decimal("2.0"), Date(2020, 1, 1)))
    assert not Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).is_equal(Price.of(EUR, Decimal("1.0"), Date(2020, 1, 1)))

# Generated at 2022-06-18 02:59:45.795403
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Price.of(USD, Decimal("1.5"), Date.today()).__floordiv__(Decimal("2")) == Price.of(USD, Decimal("0.75"), Date.today())
    assert Price.of(USD, Decimal("1.5"), Date.today()).__floordiv__(Decimal("0")) == NoPrice
    assert NoPrice.__floordiv__(Decimal("2")) == NoPrice

# Generated at 2022-06-18 02:59:54.358718
# Unit test for method subtract of class Money
def test_Money_subtract():
    from datetime import date
    from decimal import Decimal
    from pyexlatex.currencies import Currency
    from pyexlatex.money.money import Money
    from pyexlatex.money.price import Price
    from pyexlatex.money.some_money import SomeMoney
    from pyexlatex.money.no_money import NoMoney
    from pyexlatex.money.none_money import NoneMoney
    from pyexlatex.money.some_price import SomePrice
    from pyexlatex.money.no_price import NoPrice
    from pyexlatex.money.none_price import NonePrice
    from pyexlatex.money.money_exceptions import MonetaryOperationException
    from pyexlatex.money.incompatible_currency_error import IncompatibleCurrencyError

# Generated at 2022-06-18 02:59:56.309900
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(Money.of(Currency.USD, Decimal("1.23"), Date.today())) == 1

# Generated at 2022-06-18 03:00:06.070867
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    assert Money.of(Currency.USD, Decimal("10.00"), Date.today()).floor_divide(Decimal("2.00")) == Money.of(Currency.USD, Decimal("5.00"), Date.today())
    assert Money.of(Currency.USD, Decimal("10.00"), Date.today()).floor_divide(Decimal("2.50")) == Money.of(Currency.USD, Decimal("4.00"), Date.today())
    assert Money.of(Currency.USD, Decimal("10.00"), Date.today()).floor_divide(Decimal("3.00")) == Money.of(Currency.USD, Decimal("3.00"), Date.today())