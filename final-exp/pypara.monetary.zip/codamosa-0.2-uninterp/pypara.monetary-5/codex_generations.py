

# Generated at 2022-06-18 02:57:22.265690
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("1.0")) == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("0.0")) == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__mul__(Decimal("-1.0")) == Price.of(USD, Decimal("-1.0"), Date.today())

# Generated at 2022-06-18 02:57:33.403048
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(EUR, Decimal("1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:44.346525
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    from .currency import Currency
    from .money import Money
    from .money import NoMoney
    from .money import SomeMoney
    from .money import UndefinedMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_UP
    from datetime import date
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from typing import Any
    from typing import Optional
    from typing import Union
    from typing import List
    from typing import Tuple
    from typing import Dict
    from typing import NamedTuple
    from typing import TypeVar
    from typing import Generic
    from typing import Callable
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING

# Generated at 2022-06-18 02:57:50.073577
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    from .currency import Currency
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import IncompatibleCurrencyError
    from .money import UndefinedMoneyError
    from .money import UndefinedMoneyComparisonError
    from .money import UndefinedMoneyOperationError
    from .money import UndefinedMoneyArithmeticError
    from .money import UndefinedMoneyConversionError
    from .money import UndefinedMoneyConversionOperationError
    from .money import UndefinedMoneyConversionComparisonError
    from .money import UndefinedMoneyConversionArithmeticError
    from .money import UndefinedMoneyConversionScalarError
    from .money import UndefinedMoneyConversionScalarOperationError
    from .money import UndefinedMoneyConversionScalarComparisonError
    from .money import UndefinedMoneyConversionScal

# Generated at 2022-06-18 02:57:59.846896
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("1.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("0.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("-1.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("-2.0"), Date.today()))
    assert Price.of

# Generated at 2022-06-18 02:58:01.795133
# Unit test for method __int__ of class Price
def test_Price___int__():
    # Test for method __int__(self) of class Price
    assert Price.of(USD, Decimal("1.23"), Date.today()).__int__() == 1



# Generated at 2022-06-18 02:58:08.518009
# Unit test for method convert of class Price
def test_Price_convert():
    # Test case 1
    # Input:
    #   price: SomePrice(ccy=USD, qty=Decimal('1.0'), dov=datetime.date(2020, 1, 1))
    #   to: EUR
    #   asof: datetime.date(2020, 1, 1)
    #   strict: False
    # Expected output:
    #   SomePrice(ccy=EUR, qty=Decimal('0.9'), dov=datetime.date(2020, 1, 1))
    price = SomePrice(ccy=USD, qty=Decimal('1.0'), dov=datetime.date(2020, 1, 1))
    to = EUR
    asof = datetime.date(2020, 1, 1)
    strict = False

# Generated at 2022-06-18 02:58:17.856535
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    """
    Tests method __eq__ of class SomeMoney.
    """
    ## Initialize:
    ccy = Currency("USD")
    qty = Decimal("100.00")
    dov = Date.today()
    money1 = SomeMoney(ccy, qty, dov)
    money2 = SomeMoney(ccy, qty, dov)
    money3 = SomeMoney(ccy, qty, dov + 1)
    money4 = SomeMoney(ccy, qty + 1, dov)
    money5 = SomeMoney(Currency("EUR"), qty, dov)

    ## Test:
    assert money1 == money2
    assert money1 != money3
    assert money1 != money4
    assert money1 != money5
    assert money1 != NoMoney

# Generated at 2022-06-18 02:58:26.061105
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import USD, EUR
    from .exchange import FXRateService
    from .zeitgeist import Date
    from .money import Money
    from .prices import Price
    from decimal import Decimal
    from datetime import date
    from unittest import TestCase
    from unittest.mock import MagicMock

    class TestMoney(TestCase):
        def setUp(self):
            self.fx_service = MagicMock(spec=FXRateService)
            self.fx_service.lookup.return_value = Decimal("1.2")
            self.date = Date(date(2020, 1, 1))
            self.money1 = Money.of(USD, Decimal("1"), self.date)
            self.money2 = Money.of(EUR, Decimal("1"), self.date)

       

# Generated at 2022-06-18 02:58:31.867971
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    assert Price.of(USD, Decimal("10"), Date.today()).scalar_subtract(Decimal("5")) == Price.of(USD, Decimal("5"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).scalar_subtract(Decimal("-5")) == Price.of(USD, Decimal("15"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).scalar_subtract(Decimal("0")) == Price.of(USD, Decimal("10"), Date.today())
    assert Price.of(USD, Decimal("10"), Date.today()).scalar_subtract(Decimal("10")) == Price.of(USD, Decimal("0"), Date.today())

# Generated at 2022-06-18 02:59:26.118647
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(Price.of(USD, Decimal("1.23"), Date.today())) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today()).with_qty(Decimal("1.25"))) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today()).with_ccy(EUR)) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today()).with_dov(Date.today() + 1)) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today()).convert(EUR)) == 1
    assert int(Price.of(USD, Decimal("1.23"), Date.today()).abs()) == 1

# Generated at 2022-06-18 02:59:30.424208
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)).with_dov(Date(2020, 1, 2)) == SomePrice(USD, Decimal("1.0"), Date(2020, 1, 2))


# Generated at 2022-06-18 02:59:40.268228
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).__pos__() == Price.of(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("-1.0"), Date(2018, 1, 1)).__pos__() == Price.of(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("0.0"), Date(2018, 1, 1)).__pos__() == Price.of(USD, Decimal("0.0"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:59:49.637530
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    from datetime import date
    from decimal import Decimal
    from pytest import raises
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinFXRateTypes
    from financepy.finutils.FinError import FinError
    from financepy.finutils.FinCurrency import FinCurrency
    from financepy.finutils.FinFXRate import FinFXRate
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import Fin

# Generated at 2022-06-18 02:59:58.662172
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()) == Money.of(Currency.USD, Decimal("1.23"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()) != Money.of(Currency.USD, Decimal("1.23"), Date.today() + 1)
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()) != Money.of(Currency.USD, Decimal("1.23"), Date.today() - 1)
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()) != Money.of(Currency.USD, Decimal("1.24"), Date.today())

# Generated at 2022-06-18 03:00:09.256546
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from datetime import date
    from fin.currency import Currency
    from fin.fxrate import FXRateService
    from fin.fxrate.service import FXRateServiceImpl
    from fin.money import Money, SomeMoney, NoMoney

    ## Set up the FX rate service:
    FXRateService.default = FXRateServiceImpl()

    ## Create a money object:
    money = SomeMoney(Currency.USD, Decimal("100.00"), date(2018, 1, 1))

    ## Convert to EUR:
    money = money.convert(Currency.EUR, date(2018, 1, 1))

    ## Check:
    assert money == SomeMoney(Currency.EUR, Decimal("84.00"), date(2018, 1, 1))

    ## Convert to EUR:

# Generated at 2022-06-18 03:00:15.017316
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    ccy = Currency.of("USD")
    m1 = SomeMoney(ccy, Decimal("100"), Date.today())
    m2 = SomeMoney(ccy, Decimal("50"), Date.today())
    m3 = m1 - m2
    assert m3.ccy == ccy
    assert m3.qty == Decimal("50")
    assert m3.dov == Date.today()
    assert m3.defined
    assert not m3.undefined


# Generated at 2022-06-18 03:00:21.606875
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    assert SomeMoney(USD, Decimal("100"), Date(2020, 1, 1)).scalar_subtract(Decimal("100")) == SomeMoney(USD, Decimal("0"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("100"), Date(2020, 1, 1)).scalar_subtract(Decimal("200")) == SomeMoney(USD, Decimal("-100"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("100"), Date(2020, 1, 1)).scalar_subtract(Decimal("-100")) == SomeMoney(USD, Decimal("200"), Date(2020, 1, 1))

# Generated at 2022-06-18 03:00:24.154018
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    assert int(SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1))) == 1

# Generated at 2022-06-18 03:00:33.303155
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.of(USD, Decimal("-1.0"), Date.today()).__abs__() == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__abs__() == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("0.0"), Date.today()).__abs__() == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("-0.0"), Date.today()).__abs__() == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("-1.0"), Date.today()).__abs__()