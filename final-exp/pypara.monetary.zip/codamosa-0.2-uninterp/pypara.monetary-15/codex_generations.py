

# Generated at 2022-06-18 02:54:53.282377
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    assert SomeMoney(USD, Decimal("100"), Date(2018, 1, 1)).with_dov(Date(2018, 1, 2)) == SomeMoney(USD, Decimal("100"), Date(2018, 1, 2))

# Generated at 2022-06-18 02:54:57.838271
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    assert SomePrice(Currency.USD, Decimal("1.0"), Date(2018, 1, 1)).with_dov(Date(2018, 1, 2)) == SomePrice(Currency.USD, Decimal("1.0"), Date(2018, 1, 2))

# Generated at 2022-06-18 02:55:07.222999
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("0.0"), Date.today()))
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > NoMoney)
    assert (not (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("1.0"), Date.today())))
    assert (not (SomeMoney(Currency.USD, Decimal("0.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("1.0"), Date.today())))
    assert (not (NoMoney > SomeMoney(Currency.USD, Decimal("1.0"), Date.today())))

# Generated at 2022-06-18 02:55:14.858313
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert Money.of(Currency.USD, 0, Date.today()).as_boolean() is False
    assert Money.of(Currency.USD, 1, Date.today()).as_boolean() is True
    assert Money.of(Currency.USD, -1, Date.today()).as_boolean() is True
    assert Money.of(Currency.USD, Decimal("0.0"), Date.today()).as_boolean() is False
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()).as_boolean() is True
    assert Money.of(Currency.USD, Decimal("-1.0"), Date.today()).as_boolean() is True
    assert Money.of(Currency.USD, Decimal("0.0000"), Date.today()).as_bo

# Generated at 2022-06-18 02:55:26.523374
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    assert SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1)) == SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1)) != SomePrice(USD, Decimal("1.23"), Date(2020, 1, 2))
    assert SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1)) != SomePrice(USD, Decimal("1.24"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1)) != SomePrice(EUR, Decimal("1.23"), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:55:27.682195
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    assert float(SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1))) == 1.23


# Generated at 2022-06-18 02:55:37.119437
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date.today()).gte(Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date.today()))
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date.today()).gte(Price.of(ccy=USD, qty=Decimal("0.0"), dov=Date.today()))
    assert Price.of(ccy=USD, qty=Decimal("1.0"), dov=Date.today()).gte(Price.of(ccy=USD, qty=Decimal("-1.0"), dov=Date.today()))

# Generated at 2022-06-18 02:55:45.657957
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    from money import Money
    from money import SomeMoney
    from money import NoMoney
    from money import Currency
    from money import Date
    from money import Decimal
    from money import IncompatibleCurrencyError
    from money import ProgrammingError
    from money import FXRateLookupError
    from money import FXRateService
    from money import SomePrice
    from money import Price
    from money import Numeric
    from money import InvalidOperation
    from money import DivisionByZero
    from money import NamedTuple
    from money import Optional
    from money import Union
    from money import overload
    from money import abstractmethod
    from money import abstractproperty
    from money import final
    from money import dataclass
    from money import field
    from money import asdict
    from money import astuple
    from money import make_dataclass
    from money import replace


# Generated at 2022-06-18 02:55:51.392247
# Unit test for method round of class Price
def test_Price_round():
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round() == 1
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(1) == Price.of(USD, Decimal("1.2"), Date.today())
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(2) == Price.of(USD, Decimal("1.23"), Date.today())
    assert Price.of(USD, Decimal("1.2345"), Date.today()).round(3) == Price.of(USD, Decimal("1.235"), Date.today())

# Generated at 2022-06-18 02:55:55.320311
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    assert SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1)).__neg__() == SomeMoney(USD, Decimal("-1.23"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:57:33.254984
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    from .currency import Currency
    from .money import SomeMoney
    from .money import NoMoney
    from .money import Money
    from .money import IncompatibleCurrencyError
    from .money import FXRateLookupError
    from .money import FXRateService
    from .money import ProgrammingError
    from .money import Price
    from .money import SomePrice
    from .money import NoPrice
    from .money import Date
    from decimal import Decimal
    from decimal import InvalidOperation
    from decimal import DivisionByZero
    from typing import NamedTuple
    from typing import Optional
    from typing import Union
    from typing import Any
    from typing import Numeric
    from typing import TypeVar
    from typing import Type
    from typing import Generic
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import List

# Generated at 2022-06-18 02:57:44.158642
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Price.of(USD, Decimal("1.23"), Date.today()).as_integer() == 1

# Generated at 2022-06-18 02:57:51.631804
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(USD, Decimal(0), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(USD, Decimal(0), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(USD, Decimal(0), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(USD, Decimal(0), Date(2020, 1, 1))
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)) > SomePrice(USD, Decimal(0), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:00.334809
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert Money.of(None, None, None).as_boolean() is False
    assert Money.of(None, Decimal(0), None).as_boolean() is False
    assert Money.of(None, Decimal(1), None).as_boolean() is True
    assert Money.of(Currency.USD, None, None).as_boolean() is False
    assert Money.of(Currency.USD, Decimal(0), None).as_boolean() is False
    assert Money.of(Currency.USD, Decimal(1), None).as_boolean() is True
    assert Money.of(Currency.USD, Decimal(0), Date.today()).as_boolean() is False
    assert Money.of(Currency.USD, Decimal(1), Date.today()).as_boolean() is True


# Generated at 2022-06-18 02:58:07.098570
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from .currencies import USD
    from .zeitgeist import Date
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import NoneMoney
    from .money import NonePrice
    from .money import SomePrice
    from .money import Price
    from .money import NoPrice
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import FXRateLookupError
    from .money import FXRateService
    from .money import Money
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import FXRateLookupError
    from .money import FXRateService
    from .money import Money
    from .money import MonetaryOperationException
    from .money import IncompatibleCurrencyError
    from .money import FX

# Generated at 2022-06-18 02:58:16.520733
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) > SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) > SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) > SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))
    assert SomePrice(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)) > SomePrice(Currency("USD"), Decimal("0.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:25.021139
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).scalar_subtract(Decimal("1.0")) == Price.of(USD, Decimal("0.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).scalar_subtract(Decimal("0.0")) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).scalar_subtract(Decimal("-1.0")) == Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:36.138101
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert not (SomePrice(USD, Decimal("2.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)))
    assert not (SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)))
    assert SomePrice(USD, Decimal("1.0"), Date(2020, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2020, 1, 2))

# Generated at 2022-06-18 02:58:44.593936
# Unit test for method convert of class Price
def test_Price_convert():
    from datetime import date
    from pymonad.Reader import curry
    from pymonad.Maybe import Just, Nothing
    from pymonad.Either import Left, Right
    from pymonad.tools import do
    from pymonad.tools import do_return
    from pymonad.tools import do_yield
    from pymonad.tools import do_yield_from
    from pymonad.tools import do_bind
    from pymonad.tools import do_bind_as
    from pymonad.tools import do_bind_return
    from pymonad.tools import do_bind_yield
    from pymonad.tools import do_bind_yield_from
    from pymonad.tools import do_then
    from pymonad.tools import do_then_return
    from pymonad.tools import do_

# Generated at 2022-06-18 02:58:51.733009
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    # Arrange
    ccy = Currency.USD
    qty = Decimal("100.00")
    dov = Date.today()
    money = SomeMoney(ccy, qty, dov)
    to = Currency.EUR
    asof = Date.today()
    strict = True
    # Act
    result = money.convert(to, asof, strict)
    # Assert
    assert result.ccy == to
    assert result.qty == Decimal("100.00")
    assert result.dov == asof
