

# Generated at 2022-06-18 02:58:16.114504
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__truediv__(Decimal("1.0")) == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__truediv__(Decimal("2.0")) == Price.of(USD, Decimal("0.5"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__truediv__(Decimal("0.0")) == NoPrice
    assert NoPrice.__truediv__(Decimal("1.0")) == NoPrice
    assert NoPrice.__truediv__(Decimal("0.0")) == NoPrice

# Generated at 2022-06-18 02:58:24.644486
# Unit test for method lte of class Price
def test_Price_lte():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2020, 1, 2))

# Generated at 2022-06-18 02:58:30.874684
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)) == Price.of(USD, Decimal("1.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)) != Price.of(USD, Decimal("1.0"), Date(2018, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)) != Price.of(USD, Decimal("2.0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)) != Price.of(EUR, Decimal("1.0"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:58:35.738394
# Unit test for method divide of class Money
def test_Money_divide():
    # Test for undefined money
    assert Money.NA.divide(1) == Money.NA
    # Test for defined money
    assert Money.of(Currency.USD, 1, Date.today()).divide(1) == Money.of(Currency.USD, 1, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).divide(0) == Money.NA
    assert Money.of(Currency.USD, 1, Date.today()).divide(2) == Money.of(Currency.USD, 0.5, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).divide(2.0) == Money.of(Currency.USD, 0.5, Date.today())

# Generated at 2022-06-18 02:58:40.490968
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    # Test case data
    ccy = Currency.USD
    qty = Decimal('1.00')
    dov = Date(2018, 1, 1)
    to = Currency.EUR
    asof = Date(2018, 1, 1)
    strict = False
    # Perform the test
    money = SomeMoney(ccy, qty, dov)
    result = money.convert(to, asof, strict)
    # Verify the result
    assert isinstance(result, Money)
    assert result.ccy == to
    assert result.qty == Decimal('0.835')
    assert result.dov == asof

# Generated at 2022-06-18 02:58:52.485656
# Unit test for method __gt__ of class Money

# Generated at 2022-06-18 02:58:59.974550
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    assert Money.of(Currency.USD, Decimal("1"), Date.today()) - Money.of(Currency.USD, Decimal("1"), Date.today()) == Money.of(Currency.USD, Decimal("0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1"), Date.today()) - Money.of(Currency.USD, Decimal("2"), Date.today()) == Money.of(Currency.USD, Decimal("-1"), Date.today())
    assert Money.of(Currency.USD, Decimal("2"), Date.today()) - Money.of(Currency.USD, Decimal("1"), Date.today()) == Money.of(Currency.USD, Decimal("1"), Date.today())

# Generated at 2022-06-18 02:59:06.317035
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLookupError
    from .exchange import FXRateLook

# Generated at 2022-06-18 02:59:18.045796
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) == Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.EUR, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.USD, Decimal("1.0"), Date.today() + 1)

# Generated at 2022-06-18 02:59:27.752095
# Unit test for method gte of class Price
def test_Price_gte():
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("1.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("0.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("1.0"), Date.today()))
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).gte(Price.of(Currency.USD, Decimal("1.0"), Date.today()))

# Generated at 2022-06-18 03:00:11.664023
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import Currency
    from .exchange import FXRateService
    from .money import Money
    from .zeitgeist import Date
    import pytest
    from decimal import Decimal
    from datetime import datetime
    from unittest.mock import Mock

    # Test case 1
    # Input:
    #   ccy1 = Currency("USD")
    #   ccy2 = Currency("EUR")
    #   qty = Decimal("100")
    #   dov = Date(datetime(2020, 1, 1))
    #   asof = Date(datetime(2020, 1, 1))
    #   fx_rate = Decimal("1.1")
    #   strict = False
    # Expected output:
    #   Money(ccy2, qty * fx_rate, dov)

# Generated at 2022-06-18 03:00:19.528136
# Unit test for method __eq__ of class Price

# Generated at 2022-06-18 03:00:29.832080
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import USD
    from .dates import Date
    from .money import Money, SomeMoney
    from decimal import Decimal

    assert Money.of(USD, Decimal("1.23"), Date(2020, 1, 1)).with_qty(Decimal("2.34")) == SomeMoney(USD, Decimal("2.34"), Date(2020, 1, 1))
    assert Money.of(USD, Decimal("1.23"), Date(2020, 1, 1)).with_qty(None) == Money.NA
    assert Money.of(None, Decimal("1.23"), Date(2020, 1, 1)).with_qty(Decimal("2.34")) == Money.NA
    assert Money.of(None, Decimal("1.23"), Date(2020, 1, 1)).with_qty(None) == Money.NA


# Generated at 2022-06-18 03:00:32.625548
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    """
    Tests the as_integer method of Money class.
    """
    # Test for defined money
    money = Money.of(Currency.USD, Decimal(10), Date.today())
    assert money.as_integer() == 10

    # Test for undefined money
    money = NoMoney
    with pytest.raises(MonetaryOperationException):
        money.as_integer()

# Generated at 2022-06-18 03:00:37.229972
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("0.0"), Date.today())) == True
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("1.0"), Date.today())) == False
    assert (SomeMoney(Currency.USD, Decimal("0.0"), Date.today()) > SomeMoney(Currency.USD, Decimal("1.0"), Date.today())) == False
    assert (SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) > SomeMoney(Currency.EUR, Decimal("1.0"), Date.today())) == False

# Generated at 2022-06-18 03:00:42.026921
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    """
    Tests method __sub__ of class Money
    """
    from .currencies import USD, EUR
    from .exchange import FXRateService
    from .money import Money, SomeMoney

    fx = FXRateService()
    fx.set_rate(USD, EUR, 0.9)

    assert Money.of(USD, 100, Date.today()) - Money.of(USD, 100, Date.today()) == Money.of(USD, 0, Date.today())
    assert Money.of(USD, 100, Date.today()) - Money.of(USD, 100, Date.today()) == Money.of(USD, 0, Date.today())
    assert Money.of(USD, 100, Date.today()) - Money.of(USD, 100, Date.today()) == Money.of(USD, 0, Date.today())

# Generated at 2022-06-18 03:00:50.453346
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23
    assert Price.of(USD, Decimal('1.23'), Date(2020, 1, 1)).__float__() == 1.23

# Generated at 2022-06-18 03:00:55.047897
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    ccy = Currency.USD
    qty = Decimal(1)
    dov = Date(2020, 1, 1)
    price = SomePrice(ccy, qty, dov)
    new_dov = Date(2020, 2, 1)
    new_price = price.with_dov(new_dov)
    assert new_price.ccy == ccy
    assert new_price.qty == qty
    assert new_price.dov == new_dov

# Generated at 2022-06-18 03:01:02.497531
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import Currency
    from .money import Money
    from .commons.zeitgeist import Date
    from decimal import Decimal
    from datetime import date
    ccy = Currency.of("USD")
    qty = Decimal(100)
    dov = Date.of(date(2020, 1, 1))
    money = Money.of(ccy, qty, dov)
    ccy2 = Currency.of("EUR")
    money2 = money.with_ccy(ccy2)
    assert money2.ccy == ccy2
    assert money2.qty == qty
    assert money2.dov == dov
    assert money2.defined == True
    assert money2.undefined == False
    assert money2.is_equal(money2) == True

# Generated at 2022-06-18 03:01:12.025581
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    from .currency import Currency
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import IncompatibleCurrencyError
    from .money import MoneyTypeError
    from .money import MoneyValueError
    from .money import MoneyCurrencyError
    from .money import MoneyDateError
    from .money import MoneyUndefinedError
    from .money import MoneyOperationError
    from .money import MoneyConversionError
    from .money import MoneyArithmeticError
    from .money import MoneyComparisonError
    from .money import MoneyLookupError
    from .money import MoneyProgrammingError
    from .money import MoneyRuntimeError
    from .money import MoneyStateError
    from .money import MoneyImplementationError
    from .money import MoneyWarning
    from .money import MoneyUserWarning
    from .money import MoneyDep