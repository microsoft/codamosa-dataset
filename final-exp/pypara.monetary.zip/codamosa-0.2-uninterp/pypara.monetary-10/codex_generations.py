

# Generated at 2022-06-18 02:54:42.688724
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    from .currency import Currency
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import IncompatibleCurrencyError
    from .money import UndefinedMoneyError
    from .money import UndefinedMoneyComparisonError
    from .money import UndefinedMoneyOperationError
    from .money import UndefinedMoneyBinaryOperationError
    from .money import UndefinedMoneyUnaryOperationError
    from .money import UndefinedMoneyScalarOperationError
    from .money import UndefinedMoneyScalarBinaryOperationError
    from .money import UndefinedMoneyScalarUnaryOperationError
    from .money import UndefinedMoneyConversionError
    from .money import UndefinedMoneyConversionOperationError
    from .money import UndefinedMoneyConversionBinaryOperationError
    from .money import UndefinedMoneyConversionUnaryOperation

# Generated at 2022-06-18 02:54:53.390396
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    assert Price.of(USD, Decimal("10.0"), Date.today()).scalar_add(Decimal("10.0")) == Price.of(USD, Decimal("20.0"), Date.today())
    assert Price.of(USD, Decimal("10.0"), Date.today()).scalar_add(Decimal("-10.0")) == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("10.0"), Date.today()).scalar_add(Decimal("0.0")) == Price.of(USD, Decimal("10.0"), Date.today())

# Generated at 2022-06-18 02:55:04.274749
# Unit test for method divide of class Money
def test_Money_divide():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05CEILING
    from decimal import ROUND_05FLOOR
    from decimal import ROUND_PRECISION
    from decimal import ROUND_HALF_EVEN
   

# Generated at 2022-06-18 02:55:12.926916
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    from datetime import date
    from pytz import UTC
    from finance.money import Money
    from finance.money import SomeMoney
    from finance.money import NoMoney
    from finance.money import IncompatibleCurrencyError
    from finance.money import FXRateLookupError
    from finance.money import FXRateService
    from finance.money import ProgrammingError
    from finance.money import Price
    from finance.money import SomePrice
    from finance.money import NoPrice
    from finance.money import PriceType
    from finance.money import PriceService
    from finance.money import PriceLookupError
    from finance.money import PriceTypeLookupError
    from finance.money import PriceTypeService
    from finance.money import PriceTypeServiceError
    from finance.money import PriceTypeServiceError
    from finance.money import PriceTypeServiceError

# Generated at 2022-06-18 02:55:20.753759
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from .currencies import USD
    from .money import Money, SomeMoney
    from .zeitgeist import Date

    assert Money.of(USD, 1, Date.today()).with_dov(Date(date(2020, 1, 1))) == SomeMoney(USD, 1, Date(date(2020, 1, 1)))
    assert Money.of(USD, 1, Date.today()).with_dov(Date.today()) == SomeMoney(USD, 1, Date.today())
    assert Money.of(USD, 1, Date.today()).with_dov(Date(date(2020, 1, 1))) != SomeMoney(USD, 1, Date.today())

# Generated at 2022-06-18 02:55:25.026259
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import USD
    from .commons.zeitgeist import Date
    from .money import Money
    from decimal import Decimal
    assert Money.of(USD, Decimal(10), Date.today()).with_qty(Decimal(20)) == Money.of(USD, Decimal(20), Date.today())
    assert Money.of(USD, Decimal(10), Date.today()).with_qty(Decimal(20)) != Money.of(USD, Decimal(10), Date.today())
    assert Money.of(USD, Decimal(10), Date.today()).with_qty(Decimal(20)) != Money.of(USD, Decimal(20), Date.today() + 1)

# Generated at 2022-06-18 02:55:29.506007
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    # Test for method __mul__ of class Price
    from decimal import Decimal
    from datetime import date
    from pymonetdb.exceptions import MonetaryOperationException
    from pymonetdb.sql.elements import Currency
    from pymonetdb.sql.elements import Price
    from pymonetdb.sql.elements import NoPrice
    from pymonetdb.sql.elements import SomePrice
    from pymonetdb.sql.elements import NoMoney
    from pymonetdb.sql.elements import SomeMoney
    from pymonetdb.sql.elements import Money
    from pymonetdb.sql.elements import Date
    from pymonetdb.sql.elements import Numeric
    from pymonetdb.sql.elements import IncompatibleCurrencyError

# Generated at 2022-06-18 02:55:39.161736
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    from money import Money, SomeMoney, NoMoney
    from money.currency import Currency
    from money.price import SomePrice, NoPrice
    from money.fx import FXRateService
    from money.fx.service import FXRateLookupError
    from money.fx.service import IncompatibleCurrencyError
    from money.fx.service import ProgrammingError
    from money.fx.service import FXRateLookupError
    from money.fx.service import IncompatibleCurrencyError
    from money.fx.service import ProgrammingError
    from money.fx.service import FXRateLookupError
    from money.fx.service import IncompatibleCurrencyError
    from money.fx.service import ProgrammingError
    from money.fx.service import FXRateLookupError
    from money.fx.service import IncompatibleCurrencyError
    from money.fx.service import ProgrammingError
   

# Generated at 2022-06-18 02:55:50.662533
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    """
    Tests method __floordiv__ of class SomeMoney
    """
    # Test with undefined money:
    assert NoMoney // NoMoney == NoMoney
    assert NoMoney // SomeMoney(USD, Decimal("1.0"), Date.today()) == NoMoney
    assert SomeMoney(USD, Decimal("1.0"), Date.today()) // NoMoney == NoMoney

    # Test with defined money:
    assert SomeMoney(USD, Decimal("1.0"), Date.today()) // SomeMoney(USD, Decimal("1.0"), Date.today()) == SomeMoney(USD, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 02:55:53.546580
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    assert SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1)).__abs__() == SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("-1.23"), Date(2018, 1, 1)).__abs__() == SomePrice(USD, Decimal("1.23"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:58:19.926813
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from datetime import date
    from money import Currency, USD, EUR, GBP
    from money.money import Money
    from money.price import Price, SomePrice
    from money.fxrates import FXRateService, FXRate, FXRateLookupError

    ## Define a dummy FX rate service:
    class DummyFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Optional[Date] = None, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == USD and ccy2 == EUR:
                return FXRate(USD, EUR, Decimal("0.8"), asof or date.today())

# Generated at 2022-06-18 02:58:26.900157
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("1.0"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) != Price.of(EUR, Decimal("1.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:38.274294
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    from decimal import Decimal
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.price import SomePrice
    from pyexlatex.models.money import Money
    from pyexlatex.models.money import SomeMoney
    from pyexlatex.models.money import NoMoney
    from pyexlatex.models.money import IncompatibleCurrencyError
    from pyexlatex.models.money import FXRateLookupError
    from pyexlatex.models.money import FXRateService
    from pyexlatex.models.money import ProgrammingError
    from pyexlatex.models.money import InvalidOperation
    from pyexlatex.models.money import DivisionByZero
    from pyexlatex.models.money import Numeric

# Generated at 2022-06-18 02:58:40.279589
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert Money.of(Currency.USD, Decimal("100.00"), Date.today()).as_float() == 100.00

# Generated at 2022-06-18 02:58:52.405635
# Unit test for method gt of class Money
def test_Money_gt():
    assert Money.of(Currency.USD, 1, Date.today()).gt(Money.of(Currency.USD, 0, Date.today()))
    assert Money.of(Currency.USD, 1, Date.today()).gt(Money.of(Currency.USD, 1, Date.today()))
    assert Money.of(Currency.USD, 1, Date.today()).gt(Money.of(Currency.USD, 2, Date.today()))
    assert Money.of(Currency.USD, 1, Date.today()).gt(Money.of(Currency.USD, 3, Date.today()))
    assert Money.of(Currency.USD, 1, Date.today()).gt(Money.of(Currency.USD, 4, Date.today()))

# Generated at 2022-06-18 02:58:56.697080
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    assert SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1)) // Decimal("2.00") == SomeMoney(USD, Decimal("0.50"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1)) // Decimal("0.00") == NoMoney
    assert SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1)) // Decimal("0.00") == NoMoney
    assert SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1)) // Decimal("0.00") == NoMoney
    assert SomeMoney(USD, Decimal("1.00"), Date(2020, 1, 1)) // Decimal("0.00") == NoMoney

# Generated at 2022-06-18 02:59:06.422306
# Unit test for method negative of class Price
def test_Price_negative():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).negative() == Price.of(USD, Decimal("-1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("-1.0"), Date(2020, 1, 1)).negative() == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("0.0"), Date(2020, 1, 1)).negative() == Price.of(USD, Decimal("0.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).negative().negative() == Price.of(USD, Decimal("1.0"), Date(2020, 1, 1))
    assert Price

# Generated at 2022-06-18 02:59:18.328531
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, 1, date(2020, 1, 1)).with_dov(date(2020, 1, 2)) == Price.of(USD, 1, date(2020, 1, 2))
    assert Price.of(USD, 1, date(2020, 1, 1)).with_dov(None) == Price.of(USD, 1, date(2020, 1, 1))
    assert Price.of(USD, 1, date(2020, 1, 1)).with_dov(date(2020, 1, 1)) == Price.of(USD, 1, date(2020, 1, 1))
    assert Price.of(USD, 1, date(2020, 1, 1)).with_dov(date(2020, 1, 2)) != Price.of(USD, 1, date(2020, 1, 1))

# Generated at 2022-06-18 02:59:24.543679
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("1.0")) == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("0.0")) == NoPrice
    assert NoPrice.divide(Decimal("1.0")) == NoPrice
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("2.0")) == Price.of(USD, Decimal("0.5"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).divide(Decimal("0.5")) == Price.of(USD, Decimal("2.0"), Date.today())

# Generated at 2022-06-18 02:59:34.529619
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(USD, Decimal("1"), Date.today()).multiply(Decimal("1")) == Price.of(USD, Decimal("1"), Date.today())
    assert Price.of(USD, Decimal("1"), Date.today()).multiply(Decimal("2")) == Price.of(USD, Decimal("2"), Date.today())
    assert Price.of(USD, Decimal("1"), Date.today()).multiply(Decimal("-1")) == Price.of(USD, Decimal("-1"), Date.today())
    assert Price.of(USD, Decimal("1"), Date.today()).multiply(Decimal("0")) == Price.of(USD, Decimal("0"), Date.today())
    assert Price.of(USD, Decimal("1"), Date.today()).multiply