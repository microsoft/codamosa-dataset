

# Generated at 2022-06-18 02:54:08.874121
# Unit test for method subtract of class Price
def test_Price_subtract():
    assert Price.of(USD, Decimal("100"), Date(2018, 1, 1)).subtract(Price.of(USD, Decimal("100"), Date(2018, 1, 1))) == Price.of(USD, Decimal("0"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("100"), Date(2018, 1, 1)).subtract(Price.of(USD, Decimal("200"), Date(2018, 1, 1))) == Price.of(USD, Decimal("-100"), Date(2018, 1, 1))
    assert Price.of(USD, Decimal("200"), Date(2018, 1, 1)).subtract(Price.of(USD, Decimal("100"), Date(2018, 1, 1))) == Price.of(USD, Decimal("100"), Date(2018, 1, 1))
    assert Price

# Generated at 2022-06-18 02:54:13.580902
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) // Decimal("2.0") == Price.of(USD, Decimal("0.5"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) // Decimal("2.0") != Price.of(USD, Decimal("0.5"), Date(2020, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)) // Decimal("2.0") != Price.of(USD, Decimal("0.5"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:54:20.595512
# Unit test for method abs of class Price
def test_Price_abs():
    assert Price.of(USD, Decimal("1.23"), date(2018, 1, 1)).abs() == Price.of(USD, Decimal("1.23"), date(2018, 1, 1))
    assert Price.of(USD, Decimal("-1.23"), date(2018, 1, 1)).abs() == Price.of(USD, Decimal("1.23"), date(2018, 1, 1))
    assert Price.of(USD, Decimal("0"), date(2018, 1, 1)).abs() == Price.of(USD, Decimal("0"), date(2018, 1, 1))
    assert Price.of(USD, Decimal("-0"), date(2018, 1, 1)).abs() == Price.of(USD, Decimal("0"), date(2018, 1, 1))
    assert NoPrice.abs() == NoPrice
# Unit

# Generated at 2022-06-18 02:54:31.331495
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    assert Money.of(Currency.USD, Decimal("100"), Date.today()).__mul__(Decimal("2.0")) == Money.of(Currency.USD, Decimal("200"), Date.today())
    assert Money.of(Currency.USD, Decimal("100"), Date.today()).__mul__(Decimal("0.0")) == Money.of(Currency.USD, Decimal("0"), Date.today())
    assert Money.of(Currency.USD, Decimal("100"), Date.today()).__mul__(Decimal("-2.0")) == Money.of(Currency.USD, Decimal("-200"), Date.today())

# Generated at 2022-06-18 02:54:40.929088
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    # Test with undefined money:
    assert NoMoney <= NoMoney
    assert NoMoney <= SomeMoney(USD, Decimal("1.0"), Date.today())

    # Test with defined money:
    assert SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.0"), Date.today())
    assert SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("2.0"), Date.today())
    assert not SomeMoney(USD, Decimal("2.0"), Date.today()) <= SomeMoney(USD, Decimal("1.0"), Date.today())

    # Test with incompatible currencies:

# Generated at 2022-06-18 02:54:52.590563
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05ODD
    from decimal import ROUND_TRUNCATE
    from decimal import ROUND_ROUND_HALF_EVEN
    from decimal import ROUND_ROUND_

# Generated at 2022-06-18 02:54:57.720242
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert NoPrice.__bool__() == False
    assert SomePrice(USD, Decimal(1), Date(2020, 1, 1)).__bool__() == True
    assert SomePrice(USD, Decimal(0), Date(2020, 1, 1)).__bool__() == False

# Generated at 2022-06-18 02:55:07.143600
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__neg__() == Price.of(USD, Decimal("-1.0"), Date.today())
    assert Price.of(USD, Decimal("-1.0"), Date.today()).__neg__() == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("0.0"), Date.today()).__neg__() == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("-0.0"), Date.today()).__neg__() == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("1.0"), Date.today()).__neg__()

# Generated at 2022-06-18 02:55:14.750759
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) // Decimal("2.0") == Money.of(Currency.USD, Decimal("0.5"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) // Decimal("0.5") == Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) // Decimal("0.0") == NoMoney
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) // Decimal("0.0") == NoMoney
    assert NoMoney // Decimal("0.0") == NoMoney

# Generated at 2022-06-18 02:55:19.347527
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    assert Price.of(USD, Decimal("1"), Date(2020, 1, 1)) / Decimal("2") == Price.of(USD, Decimal("0.5"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1"), Date(2020, 1, 1)) / Decimal("0") == NoPrice
    assert Price.of(USD, Decimal("1"), Date(2020, 1, 1)) / 2 == Price.of(USD, Decimal("0.5"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1"), Date(2020, 1, 1)) / 0 == NoPrice

# Generated at 2022-06-18 02:55:51.830916
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(1) == SomeMoney(USD, Decimal("1.2"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(3) == SomeMoney(USD, Decimal("1.235"), Date(2019, 1, 1))

# Generated at 2022-06-18 02:55:55.493583
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1.23
    assert float(NoMoney) == 0.0

# Generated at 2022-06-18 02:55:59.799408
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(SomeMoney(Currency.USD, Decimal("1.23"), Date.today())) == 1.23
    assert float(NoMoney) == 0.0
    assert float(NoneMoney) == 0.0

# Generated at 2022-06-18 02:56:10.315307
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(USD, Decimal(1), Date.today()).convert(EUR, Date.today()) == Price.of(EUR, Decimal(1), Date.today())
    assert Price.of(USD, Decimal(1), Date.today()).convert(EUR, Date.today()) != Price.of(EUR, Decimal(2), Date.today())
    assert Price.of(USD, Decimal(1), Date.today()).convert(EUR, Date.today()) != Price.of(EUR, Decimal(1), Date.today()+timedelta(days=1))

# Generated at 2022-06-18 02:56:17.648328
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date

    m = Money.of(USD, 1, Date.today())
    assert m.with_dov(Date.of(date(2020, 1, 1))) == Money.of(USD, 1, Date.of(date(2020, 1, 1)))
    assert m.with_dov(Date.of(date(2020, 1, 1))) != Money.of(USD, 1, Date.of(date(2020, 1, 2)))
    assert m.with_dov(Date.of(date(2020, 1, 1))) != Money.of(USD, 2, Date.of(date(2020, 1, 1)))
    assert m.with_dov(Date.of(date(2020, 1, 1))) != Money

# Generated at 2022-06-18 02:56:21.443845
# Unit test for method abs of class Money
def test_Money_abs():
    assert Money.of(Currency.USD, Decimal("-1.23"), Date.today()).abs() == Money.of(Currency.USD, Decimal("1.23"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).abs() == Money.of(Currency.USD, Decimal("1.23"), Date.today())
    assert NoMoney.abs() == NoMoney

# Generated at 2022-06-18 02:56:31.147223
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    """
    Tests the method __mul__ of class Money
    """
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
    # Test case 1
   

# Generated at 2022-06-18 02:56:36.433324
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.of(USD, Decimal(1), Date.today()).floor_divide(Decimal(2)) == Price.of(USD, Decimal(0), Date.today())
    assert Price.of(USD, Decimal(1), Date.today()).floor_divide(Decimal(0)) == NoPrice
    assert Price.of(USD, Decimal(1), Date.today()).floor_divide(Decimal(2)) == Price.of(USD, Decimal(0), Date.today())
    assert Price.of(USD, Decimal(1), Date.today()).floor_divide(Decimal(0)) == NoPrice
    assert NoPrice.floor_divide(Decimal(2)) == NoPrice
    assert NoPrice.floor_divide(Decimal(0)) == NoPrice

# Generated at 2022-06-18 02:56:44.195188
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) < SomePrice(USD, Decimal("2.0"), Date(2018, 1, 1))
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2018, 1, 2))
    assert SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1)) < SomePrice(USD, Decimal("2.0"), Date(2018, 1, 2))
    assert not SomePrice(USD, Decimal("2.0"), Date(2018, 1, 1)) < SomePrice(USD, Decimal("1.0"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:56:49.863382
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert Price.of(USD, Decimal("10.0"), Date.today()).__sub__(Price.of(USD, Decimal("10.0"), Date.today())) == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("10.0"), Date.today()).__sub__(Price.of(USD, Decimal("5.0"), Date.today())) == Price.of(USD, Decimal("5.0"), Date.today())
    assert Price.of(USD, Decimal("10.0"), Date.today()).__sub__(Price.of(USD, Decimal("15.0"), Date.today())) == Price.of(USD, Decimal("-5.0"), Date.today())

# Generated at 2022-06-18 03:00:32.520738
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1
    assert Money.of(Currency.USD, Decimal("1.23"), Date.today()).as_integer() == 1

# Generated at 2022-06-18 03:00:42.364243
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(1) == SomeMoney(USD, Decimal("1.2"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2019, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2019, 1, 1)).round(3) == SomeMoney(USD, Decimal("1.235"), Date(2019, 1, 1))

# Generated at 2022-06-18 03:00:50.849848
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    from datetime import date
    from decimal import Decimal
    from pytest import raises
    from financepy.finutils.FinCurrency import FinCurrency
    from financepy.finutils.FinDate import FinDate
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborFuturesCurve import FinIborFuturesCurve
    from financepy.products.funding.FinIborFuturesConventions import FinIborFuturesConventions

# Generated at 2022-06-18 03:00:59.443285
# Unit test for method __abs__ of class Price
def test_Price___abs__():
    assert Price.of(USD, Decimal("1.0"), Date.today()).__abs__() == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("-1.0"), Date.today()).__abs__() == Price.of(USD, Decimal("1.0"), Date.today())
    assert Price.of(USD, Decimal("0.0"), Date.today()).__abs__() == Price.of(USD, Decimal("0.0"), Date.today())
    assert Price.of(USD, Decimal("-0.0"), Date.today()).__abs__() == Price.of(USD, Decimal("0.0"), Date.today())

# Generated at 2022-06-18 03:01:10.416559
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.price import Price
    from pyexlatex.models.fxrate import FXRate
    from pyexlatex.models.fxrateservice import FXRateService

    ## Create a price:
    price = Price.of(Currency.USD, Decimal(1), date(2020, 1, 1))

    ## Create a service:
    service = FXRateService()

    ## Create a rate:
    rate = FXRate(Currency.USD, Currency.EUR, Decimal(1.1), date(2020, 1, 1))

    ## Register the rate:
    service.register(rate)

    ## Set the service:
    FXRateService.default = service

    ##

# Generated at 2022-06-18 03:01:16.673876
# Unit test for method __le__ of class Money
def test_Money___le__():
    from .currencies import USD
    from .money import Money, SomeMoney
    from .zeitgeist import Date

    assert Money.of(USD, 10, Date.today()).__le__(Money.of(USD, 10, Date.today()))
    assert Money.of(USD, 10, Date.today()).__le__(Money.of(USD, 20, Date.today()))
    assert not Money.of(USD, 20, Date.today()).__le__(Money.of(USD, 10, Date.today()))
    assert not Money.of(USD, 10, Date.today()).__le__(Money.of(USD, 10, Date.today() + 1))
    assert not Money.of(USD, 10, Date.today()).__le__(Money.of(USD, 10, Date.today() - 1))


# Generated at 2022-06-18 03:01:23.161907
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(SomeMoney(Currency.USD, Decimal("0.0"), Date.today())) is False
    assert bool(SomeMoney(Currency.USD, Decimal("1.0"), Date.today())) is True
    assert bool(SomeMoney(Currency.USD, Decimal("-1.0"), Date.today())) is True
    assert bool(NoMoney) is False

# Generated at 2022-06-18 03:01:32.384141
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    assert SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 1)) >= SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 1))
    assert not SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 1)) >= SomeMoney(USD, Decimal("1.01"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.01"), Date(2018, 1, 1)) >= SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 1)) >= SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 2))
    assert SomeMoney(USD, Decimal("1.00"), Date(2018, 1, 2))