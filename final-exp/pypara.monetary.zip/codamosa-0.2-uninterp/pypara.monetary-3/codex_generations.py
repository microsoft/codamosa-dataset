

# Generated at 2022-06-18 02:57:00.792455
# Unit test for method divide of class Money
def test_Money_divide():
    from .currencies import USD, EUR
    from .exchange import FXRateService
    from .money import Money, SomeMoney
    from .zeitgeist import Date

    # Test division by zero
    assert Money.of(USD, 100, Date.today()).divide(0) == Money.NA

    # Test division by non-zero
    assert Money.of(USD, 100, Date.today()).divide(2) == Money.of(USD, 50, Date.today())

    # Test division by Money
    assert Money.of(USD, 100, Date.today()).divide(Money.of(USD, 2, Date.today())) == Money.of(USD, 50, Date.today())

    # Test division by Money with different currency

# Generated at 2022-06-18 02:57:11.600019
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import USD
    from .time import today
    from .money import Money
    from decimal import Decimal
    m = Money.of(USD, Decimal("1.23"), today())
    m1 = m.with_qty(Decimal("1.24"))
    assert m1.ccy == USD
    assert m1.qty == Decimal("1.24")
    assert m1.dov == today()
    assert m1.defined
    assert not m1.undefined
    assert m1.as_boolean()
    assert m1.as_float() == 1.24
    assert m1.as_integer() == 1
    assert m1.abs() == m1
    assert m1.negative() == Money.of(USD, Decimal("-1.24"), today())
    assert m1.positive

# Generated at 2022-06-18 02:57:14.281594
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert SomePrice(USD, Decimal("1.0"), date(2019, 1, 1)) > SomePrice(USD, Decimal("0.0"), date(2019, 1, 1))


# Generated at 2022-06-18 02:57:23.342305
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    from datetime import date
    from pymonad.Maybe import Just, Nothing
    from pymonad.Reader import curry
    from pymonad.tools import identity
    from pymonad.Writer import Writer
    from pymonad.State import State
    from pymonad.List import List
    from pymonad.do import do
    from pymonad.do.Maybe import do_maybe
    from pymonad.do.Reader import do_reader
    from pymonad.do.Writer import do_writer
    from pymonad.do.State import do_state
    from pymonad.do.List import do_list
    from pymonad.do.List import do_list_
    from pymonad.do.List import do_list_
    from pymonad.do.List import do_list_

# Generated at 2022-06-18 02:57:34.246837
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.23456789"), Date(2020, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.23456789"), Date(2020, 1, 1)).round(1) == SomeMoney(USD, Decimal("1.2"), Date(2020, 1, 1))
    assert SomeMoney(USD, Decimal("1.23456789"), Date(2020, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:57:45.022298
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).multiply(Decimal("2.0")) == Price.of(USD, Decimal("2.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).multiply(Decimal("0.0")) == Price.of(USD, Decimal("0.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).multiply(Decimal("-1.0")) == Price.of(USD, Decimal("-1.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2020, 1, 1)).multiply

# Generated at 2022-06-18 02:57:51.298485
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    """
    Tests method __float__ of class SomePrice
    """
    # Test case 1:
    ccy = Currency.of("USD")
    qty = Decimal("1.23")
    dov = Date.today()
    price = SomePrice(ccy, qty, dov)
    assert price.__float__() == 1.23

    # Test case 2:
    ccy = Currency.of("USD")
    qty = Decimal("1.23")
    dov = Date.today()
    price = SomePrice(ccy, qty, dov)
    assert float(price) == 1.23

# Generated at 2022-06-18 02:58:00.062916
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 02:58:06.907429
# Unit test for method subtract of class Price
def test_Price_subtract():
    assert Price.of(USD, Decimal("100"), Date(2020, 1, 1)) - Price.of(USD, Decimal("100"), Date(2020, 1, 1)) == Price.of(USD, Decimal("0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("100"), Date(2020, 1, 1)) - Price.of(USD, Decimal("100"), Date(2020, 1, 1)) == Price.of(USD, Decimal("0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("100"), Date(2020, 1, 1)) - Price.of(USD, Decimal("100"), Date(2020, 1, 1)) == Price.of(USD, Decimal("0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:58:16.187099
# Unit test for method subtract of class Price
def test_Price_subtract():
    assert Price.of(USD, Decimal("10.00"), Date(2020, 1, 1)) - Price.of(USD, Decimal("10.00"), Date(2020, 1, 1)) == Price.of(USD, Decimal("0.00"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10.00"), Date(2020, 1, 1)) - Price.of(USD, Decimal("20.00"), Date(2020, 1, 1)) == Price.of(USD, Decimal("-10.00"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:59:06.698483
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05ODD
    from decimal import ROUND_TOWARD_ZERO
    from decimal import ROUND_TOWARD_POSITIVE
    from decimal import ROUND_TOWARD

# Generated at 2022-06-18 02:59:18.414583
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    from datetime import date
    from decimal import Decimal
    from finance.money import Money
    from finance.currency import Currency
    from finance.price import Price
    from finance.fxrate import FXRateService

    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: Date, strict: bool = False) -> Optional[Money]:
            if ccy1 == Currency.USD and ccy2 == Currency.EUR:
                return Money.of(ccy2, Decimal("0.9"), asof)
            elif ccy1 == Currency.EUR and ccy2 == Currency.USD:
                return Money.of(ccy2, Decimal("1.1"), asof)
            else:
                return None

    FXRateService.default = MockFXRateService()

# Generated at 2022-06-18 02:59:24.531873
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).with_qty(Decimal('2.0')) == Price.of(USD, Decimal('2.0'), Date(2020, 1, 1))
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).with_qty(Decimal('2.0')) != Price.of(USD, Decimal('1.0'), Date(2020, 1, 1))
    assert Price.of(USD, Decimal('1.0'), Date(2020, 1, 1)).with_qty(Decimal('2.0')) != Price.of(USD, Decimal('2.0'), Date(2020, 1, 2))

# Generated at 2022-06-18 02:59:29.346482
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from datetime import date
    from money import Money, SomeMoney, NoMoney, Currency, FXRateService, FXRateLookupError
    from money.fxrateservice import InMemoryFXRateService
    from money.fxrate import FXRate

    ## Create a currency:
    ccy1 = Currency("USD")

    ## Create a money:
    m1 = SomeMoney(ccy1, 100, date(2019, 1, 1))

    ## Create a currency:
    ccy2 = Currency("EUR")

    ## Create a FX rate service:
    fxrs = InMemoryFXRateService()

    ## Add a FX rate:
    fxrs.add(FXRate(ccy1, ccy2, 0.9, date(2019, 1, 1)))

    ## Set the default FX rate service:
    FXRateService.default = fx

# Generated at 2022-06-18 02:59:39.751166
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round() == SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(1) == SomeMoney(USD, Decimal("1.2"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(2) == SomeMoney(USD, Decimal("1.23"), Date(2018, 1, 1))
    assert SomeMoney(USD, Decimal("1.2345"), Date(2018, 1, 1)).round(3) == SomeMoney(USD, Decimal("1.235"), Date(2018, 1, 1))

# Generated at 2022-06-18 02:59:49.342647
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    ccy = Currency.USD
    qty = Decimal("1.23")
    dov = Date.today()
    price = SomePrice(ccy, qty, dov)
    assert price.__le__(price)
    assert price.__le__(SomePrice(ccy, qty, dov))
    assert price.__le__(SomePrice(ccy, Decimal("1.23"), dov))
    assert price.__le__(SomePrice(ccy, Decimal("1.23"), dov))
    assert price.__le__(SomePrice(ccy, Decimal("1.23"), dov))
    assert price.__le__(SomePrice(ccy, Decimal("1.23"), dov))

# Generated at 2022-06-18 02:59:58.536305
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(Currency.USD, Decimal(1), Date.today()) < Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) < Money.of(Currency.USD, Decimal(1), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) < Money.of(Currency.USD, Decimal(1), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) < Money.of(Currency.USD, Decimal(1), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) < Money.of(Currency.USD, Decimal(1), Date.today())

# Generated at 2022-06-18 03:00:09.267115
# Unit test for method __float__ of class Price
def test_Price___float__():
    assert float(Price.of(USD, Decimal("1.23"), Date.today())) == 1.23
    assert float(Price.of(USD, Decimal("1.23"), Date.today()).with_qty(Decimal("2.34"))) == 2.34
    assert float(Price.of(USD, Decimal("1.23"), Date.today()).with_ccy(EUR)) == 1.23
    assert float(Price.of(USD, Decimal("1.23"), Date.today()).with_dov(Date.today() + 1)) == 1.23
    assert float(Price.of(USD, Decimal("1.23"), Date.today()).with_ccy(EUR).with_qty(Decimal("2.34"))) == 2.34

# Generated at 2022-06-18 03:00:17.766688
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    from decimal import Decimal
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.price import SomePrice
    from pyexlatex.models.price import NoPrice
    from pyexlatex.models.price import IncompatibleCurrencyError
    from pyexlatex.models.currency import USD
    from pyexlatex.models.currency import EUR
    from pyexlatex.models.currency import GBP
    from pyexlatex.models.currency import JPY
    from pyexlatex.models.currency import CHF
    from pyexlatex.models.currency import CAD
    from pyexlatex.models.currency import AUD
    from pyexlatex.models.currency import NZD
    from pyexlatex.models.currency import CNY

# Generated at 2022-06-18 03:00:26.178962
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import Currency
    from .commons.zeitgeist import Date
    from .money import Money
    from decimal import Decimal
    ccy = Currency.of("USD")
    qty = Decimal("1.23")
    dov = Date.today()
    money = Money.of(ccy, qty, dov)
    money_new = money.with_qty(Decimal("2.34"))
    assert money_new.ccy == ccy
    assert money_new.qty == Decimal("2.34")
    assert money_new.dov == dov