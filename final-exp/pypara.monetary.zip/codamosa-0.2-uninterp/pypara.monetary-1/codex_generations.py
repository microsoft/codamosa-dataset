

# Generated at 2022-06-18 02:55:05.088454
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from decimal import Decimal
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_UP
    from decimal import ROUND_DOWN
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_05UP
    from decimal import ROUND_05DOWN
    from decimal import ROUND_05EVEN
    from decimal import ROUND_05ODD
    from decimal import ROUND_ROUNDING
    from decimal import ROUND_TRUNCATE
    from decimal import ROUND_PASS_MINUS_ONE

# Generated at 2022-06-18 02:55:13.624048
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from datetime import date
    from pytest import raises
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinFXRateTypes
    from financepy.finutils.FinError import FinIncompatibleCurrencyError
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborCapFloor import FinIborCapFloor

# Generated at 2022-06-18 02:55:18.013567
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    assert NoMoney < NoMoney
    assert NoMoney < SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < SomeMoney(Currency.USD, Decimal("2.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < SomeMoney(Currency.EUR, Decimal("1.0"), Date.today())
    assert SomeMoney(Currency.USD, Decimal("1.0"), Date.today()) < SomeMoney(Currency.USD, Decimal("1.0"), Date.today() + 1)
    assert not NoMoney < NoMoney
    assert not NoMoney < SomeMoney(Currency.USD, Decimal("1.0"), Date.today())
   

# Generated at 2022-06-18 02:55:25.196204
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date

    assert Money.of(USD, Decimal("1.00"), Date.today()).__pos__() == Money.of(USD, Decimal("1.00"), Date.today())
    assert Money.of(USD, Decimal("-1.00"), Date.today()).__pos__() == Money.of(USD, Decimal("1.00"), Date.today())
    assert Money.of(USD, Decimal("0.00"), Date.today()).__pos__() == Money.of(USD, Decimal("0.00"), Date.today())
    assert Money.of(USD, Decimal("-0.00"), Date.today()).__pos__() == Money.of(USD, Decimal("0.00"), Date.today())
   

# Generated at 2022-06-18 02:55:33.828221
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    assert SomePrice(USD, Decimal("1.23"), Date(2019, 1, 1)) - SomePrice(USD, Decimal("1.23"), Date(2019, 1, 1)) == SomePrice(USD, Decimal("0.00"), Date(2019, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2019, 1, 1)) - SomePrice(USD, Decimal("1.23"), Date(2019, 1, 2)) == SomePrice(USD, Decimal("0.00"), Date(2019, 1, 1))
    assert SomePrice(USD, Decimal("1.23"), Date(2019, 1, 2)) - SomePrice(USD, Decimal("1.23"), Date(2019, 1, 1)) == SomePrice(USD, Decimal("0.00"), Date(2019, 1, 2))
    assert SomePrice

# Generated at 2022-06-18 02:55:42.579324
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))) == 1.23
    assert float(SomeMoney(USD, Decimal("-1.23"), Date(2020, 1, 1))) == -1.23
    assert float(SomeMoney(USD, Decimal("0"), Date(2020, 1, 1))) == 0.0
    assert float(NoMoney) == 0.0
    assert float(NoneMoney) == 0.0
    assert float(SomeMoney(USD, Decimal("1.23"), Date(2020, 1, 1))) == 1.23
    assert float(SomeMoney(USD, Decimal("-1.23"), Date(2020, 1, 1))) == -1.23
    assert float(SomeMoney(USD, Decimal("0"), Date(2020, 1, 1))) == 0.0
   

# Generated at 2022-06-18 02:55:47.728211
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert NoMoney.as_boolean() is False
    assert SomeMoney(Currency("USD"), Decimal("0"), Date(2020, 1, 1)).as_boolean() is False
    assert SomeMoney(Currency("USD"), Decimal("1"), Date(2020, 1, 1)).as_boolean() is True


# Generated at 2022-06-18 02:55:59.115302
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) < Money.of(Currency.USD, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 02:56:09.781853
# Unit test for method add of class Money
def test_Money_add():
    assert Money.of(Currency.USD, Decimal(100), Date.today()).add(Money.of(Currency.USD, Decimal(100), Date.today())) == Money.of(Currency.USD, Decimal(200), Date.today())
    assert Money.of(Currency.USD, Decimal(100), Date.today()).add(Money.of(Currency.USD, Decimal(100), Date.today())) != Money.of(Currency.USD, Decimal(100), Date.today())
    assert Money.of(Currency.USD, Decimal(100), Date.today()).add(Money.of(Currency.USD, Decimal(100), Date.today())) != Money.of(Currency.USD, Decimal(300), Date.today())

# Generated at 2022-06-18 02:56:18.301494
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    from datetime import date
    from money import Money, SomeMoney, NoMoney
    from money.currency import Currency
    from money.currency.currency import USD, EUR
    from money.currency.currency import JPY, GBP
    from money.currency.currency import CHF, CAD
    from money.currency.currency import AUD, NZD
    from money.currency.currency import CNY, HKD
    from money.currency.currency import SGD, MYR
    from money.currency.currency import INR, IDR
    from money.currency.currency import PHP, VND
    from money.currency.currency import KRW, THB
    from money.currency.currency import AED, SAR
    from money.currency.currency import ZAR, KES
    from money.currency.currency import BDT, LKR
    from money.currency.currency import PKR

# Generated at 2022-06-18 02:56:35.169185
# Unit test for method gt of class Money
def test_Money_gt():
    assert Money.of(Currency.USD, Decimal(1), Date.today()) > Money.of(Currency.USD, Decimal(0), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) > Money.of(Currency.USD, Decimal(0), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) > Money.of(Currency.USD, Decimal(0), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) > Money.of(Currency.USD, Decimal(0), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) > Money.of(Currency.USD, Decimal(0), Date.today())

# Generated at 2022-06-18 02:56:42.876852
# Unit test for method add of class Money
def test_Money_add():
    assert Money.of(Currency.USD, Decimal(1), Date.today()) + Money.of(Currency.USD, Decimal(1), Date.today()) == Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) + Money.of(Currency.USD, Decimal(1), Date.today()) != Money.of(Currency.USD, Decimal(1), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) + Money.of(Currency.USD, Decimal(1), Date.today()) != Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()) + Money

# Generated at 2022-06-18 02:56:47.664832
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    ccy = Currency.of("USD")
    qty = Decimal("1.23")
    dov = Date.today()
    m1 = SomeMoney(ccy, qty, dov)
    m2 = SomeMoney(ccy, qty, dov)
    assert m1 == m2

# Generated at 2022-06-18 02:57:00.154721
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.of(USD, 1, Date.today()).with_dov(Date.today()) == Price.of(USD, 1, Date.today())
    assert Price.of(USD, 1, Date.today()).with_dov(Date.today() + 1) == Price.of(USD, 1, Date.today() + 1)
    assert Price.of(USD, 1, Date.today()).with_dov(Date.today() - 1) == Price.of(USD, 1, Date.today() - 1)
    assert Price.of(USD, 1, Date.today()).with_dov(None) == Price.of(USD, 1, Date.today())
    assert Price.of(USD, 1, None).with_dov(Date.today()) == Price.of(USD, 1, Date.today())

# Generated at 2022-06-18 02:57:11.127701
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2)) == Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2.0)) == Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(2) == Money.of(Currency.USD, Decimal(2), Date.today())

# Generated at 2022-06-18 02:57:17.695212
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    from .currencies import Currency
    from .money import Money
    from .zeitgeist import Date
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError
    from .exchange import FXRateService
    from .exchange import FXRateLookupError

# Generated at 2022-06-18 02:57:25.141983
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2)) == Money.of(Currency.USD, Decimal(2), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2)) != Money.of(Currency.USD, Decimal(1), Date.today())
    assert Money.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2)) != Money.of(Currency.USD, Decimal(2), Date.today() + 1)

# Generated at 2022-06-18 02:57:29.911936
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from datetime import date
    from finance.models import Currency, SomePrice
    from finance.services import FXRateService

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def query(self, ccy1: Currency, ccy2: Currency, asof: date, strict: bool = False) -> Optional[FXRate]:
            if ccy1 == Currency.USD and ccy2 == Currency.EUR:
                return FXRate(ccy1, ccy2, Decimal("0.9"), asof)
            elif ccy1 == Currency.EUR and ccy2 == Currency.USD:
                return FXRate(ccy1, ccy2, Decimal("1.1"), asof)
            else:
                return None

    ## Set the default FX rate service:

# Generated at 2022-06-18 02:57:36.772939
# Unit test for method as_float of class Money
def test_Money_as_float():
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23
    assert SomeMoney(Currency.USD, Decimal("1.23"), Date.today()).as_float() == 1.23

# Generated at 2022-06-18 02:57:45.834309
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from datetime import date
    from pyexlatex.models.currency import Currency
    from pyexlatex.models.money import Money
    from pyexlatex.models.price import Price
    from pyexlatex.models.quantity import Quantity
    from pyexlatex.models.unit import Unit
    from pyexlatex.models.value import Value
    from pyexlatex.models.variable import Variable
    from pyexlatex.models.variable import VariableValue
    from pyexlatex.models.variable import VariableValueWithUnit
    from pyexlatex.models.variable import VariableWithUnit
    from pyexlatex.models.variable import VariableWithUnitAndValue
    from pyexlatex.models.variable import VariableWithUnitAndValueAndUnit
    from pyexlatex.models.variable import VariableWithUnitAndValueAndUnitAnd

# Generated at 2022-06-18 03:00:29.821626
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) == Money.of(Currency.USD, Decimal("1.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.USD, Decimal("1.0"), Date.today() + 1)
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.USD, Decimal("2.0"), Date.today())
    assert Money.of(Currency.USD, Decimal("1.0"), Date.today()) != Money.of(Currency.EUR, Decimal("1.0"), Date.today())

# Generated at 2022-06-18 03:00:36.983986
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from finance.models import Currency, Date, SomeMoney, NoMoney, FXRateService, FXRateLookupError
    from finance.services import FXRateServiceImpl
    from finance.utils import date
    from finance.utils.testing import assert_money_equal

    ## Set the default FX rate service:
    FXRateService.default = FXRateServiceImpl()

    ## Define some currencies:
    USD = Currency("USD")
    EUR = Currency("EUR")
    GBP = Currency("GBP")

    ## Define some dates:
    d1 = date(2019, 1, 1)
    d2 = date(2019, 2, 1)
    d3 = date(2019, 3, 1)

    ## Define some money values:
    m1 = SomeMoney(USD, 100, d1)

# Generated at 2022-06-18 03:00:38.130113
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(Money.of(Currency.USD, Decimal("1.2345"), Date.today())) == 1.2345

# Generated at 2022-06-18 03:00:47.127496
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    from money import Money, SomeMoney, NoMoney
    from money.currency import Currency, USD, EUR
    from money.price import Price, SomePrice, NoPrice
    from money.quantity import Quantity, SomeQuantity, NoQuantity
    from money.rate import Rate, SomeRate, NoRate
    from money.service import FXRateService
    from money.utils import Date

    ## Define a mock FX rate service:
    class MockFXRateService(FXRateService):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.rates = {
                (USD, EUR): SomeRate(USD, EUR, Decimal("0.89")),
                (EUR, USD): SomeRate(EUR, USD, Decimal("1.12")),
            }


# Generated at 2022-06-18 03:00:52.306145
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(Money.of(None, None, None)) == 0
    assert int(Money.of(None, Decimal(1), None)) == 0
    assert int(Money.of(None, None, Date.today())) == 0
    assert int(Money.of(Currency.USD, None, None)) == 0
    assert int(Money.of(Currency.USD, Decimal(1), None)) == 0
    assert int(Money.of(Currency.USD, None, Date.today())) == 0
    assert int(Money.of(Currency.USD, Decimal(1), Date.today())) == 1

# Generated at 2022-06-18 03:01:00.202350
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    assert Money.of(Currency.USD, Decimal(100), Date.today()).scalar_add(Decimal(100)) == Money.of(Currency.USD, Decimal(200), Date.today())
    assert Money.of(Currency.USD, Decimal(100), Date.today()).scalar_add(Decimal(0)) == Money.of(Currency.USD, Decimal(100), Date.today())
    assert Money.of(Currency.USD, Decimal(100), Date.today()).scalar_add(Decimal(-100)) == Money.of(Currency.USD, Decimal(0), Date.today())

# Generated at 2022-06-18 03:01:11.261332
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    assert Money.of(Currency.USD, Decimal("100"), Date.today()) - Decimal("100") == Money.of(Currency.USD, Decimal("0"), Date.today())
    assert Money.of(Currency.USD, Decimal("100"), Date.today()) - Decimal("-100") == Money.of(Currency.USD, Decimal("200"), Date.today())
    assert Money.of(Currency.USD, Decimal("100"), Date.today()) - Decimal("0") == Money.of(Currency.USD, Decimal("100"), Date.today())
    assert Money.of(Currency.USD, Decimal("100"), Date.today()) - Decimal("100.00") == Money.of(Currency.USD, Decimal("0"), Date.today())

# Generated at 2022-06-18 03:01:17.359604
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    """
    Tests the method with_dov of class Money
    """
    assert Money.of(Currency.USD, Decimal('1.0'), Date.today()).with_dov(Date.today() + 1) == Money.of(Currency.USD, Decimal('1.0'), Date.today() + 1)
    assert Money.of(Currency.USD, Decimal('1.0'), Date.today()).with_dov(Date.today() + 1) != Money.of(Currency.USD, Decimal('1.0'), Date.today())
    assert Money.of(Currency.USD, Decimal('1.0'), Date.today()).with_dov(Date.today() + 1) != Money.of(Currency.USD, Decimal('2.0'), Date.today() + 1)

# Generated at 2022-06-18 03:01:28.148256
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from datetime import date
    from decimal import Decimal
    from financepy.finutils.FinDate import FinDate
    from financepy.finutils.FinGlobalTypes import FinCurrencyTypes
    from financepy.finutils.FinMath import ONE_PERCENT
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborCap import FinIborCap

# Generated at 2022-06-18 03:01:38.929960
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from datetime import date
    from .currencies import USD
    from .money import Money
    from .zeitgeist import Date

    m = Money(USD, 1, Date(date(2020, 1, 1)))
    assert m.with_dov(Date(date(2020, 1, 2))) == Money(USD, 1, Date(date(2020, 1, 2)))
    assert m.with_dov(Date(date(2020, 1, 1))) == m
    assert m.with_dov(Date(date(2020, 1, 3))) != m
    assert m.with_dov(Date(date(2020, 1, 3))) != Money(USD, 1, Date(date(2020, 1, 2)))