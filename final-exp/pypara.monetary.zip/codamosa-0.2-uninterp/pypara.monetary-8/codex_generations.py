

# Generated at 2022-06-18 02:55:20.687303
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    assert Price.of(USD, Decimal("10.0"), Date(2020, 1, 1)) * Decimal("2.0") == Price.of(USD, Decimal("20.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10.0"), Date(2020, 1, 1)) * 2 == Price.of(USD, Decimal("20.0"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("10.0"), Date(2020, 1, 1)) * 2.0 == Price.of(USD, Decimal("20.0"), Date(2020, 1, 1))

# Generated at 2022-06-18 02:55:27.321887
# Unit test for method __mul__ of class Price

# Generated at 2022-06-18 02:55:29.306335
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(NoMoney) is False
    assert bool(SomeMoney(Currency.USD, Decimal("0.0"), Date.today())) is False
    assert bool(SomeMoney(Currency.USD, Decimal("1.0"), Date.today())) is True

# Generated at 2022-06-18 02:55:39.130663
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    """
    Test method __floordiv__ of class SomeMoney
    """
    # Test with a defined money object:
    m1 = SomeMoney(USD, Decimal("100"), Date(2020, 1, 1))
    m2 = m1 // Decimal("2")
    assert m2.ccy == USD
    assert m2.qty == Decimal("50")
    assert m2.dov == Date(2020, 1, 1)
    assert m2.defined
    assert not m2.undefined

    # Test with an undefined money object:
    m1 = NoMoney
    m2 = m1 // Decimal("2")
    assert m2.ccy is None
    assert m2.qty is None
    assert m2.dov is None
    assert not m2.defined
    assert m2.undefined

   

# Generated at 2022-06-18 02:55:50.570842
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import Currency
    from .exchange import FXRateService
    from .money import Money
    from .zeitgeist import Date
    from .commons.numbers import Numeric
    from decimal import Decimal
    from datetime import datetime
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest import TestCase
    import pytest
    import unittest
    import sys
    import os
    import io
    import contextlib
    import sys
    import os
    import io
    import contextlib
    import unittest
    import pytest
    import sys
    import os
    import io
    import contextlib
    import unittest
    import pytest
    import sys
    import os

# Generated at 2022-06-18 02:56:02.763570
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """
    Tests the method __gt__ of class SomeMoney
    """
    # Test case 1:
    ccy1 = Currency.of("USD")
    qty1 = Decimal("100.00")
    dov1 = Date.today()
    ccy2 = Currency.of("USD")
    qty2 = Decimal("100.00")
    dov2 = Date.today()
    money1 = SomeMoney(ccy1, qty1, dov1)
    money2 = SomeMoney(ccy2, qty2, dov2)
    assert money1.__gt__(money2) == False
    # Test case 2:
    ccy1 = Currency.of("USD")
    qty1 = Decimal("100.00")
    dov1 = Date.today()

# Generated at 2022-06-18 02:56:12.155791
# Unit test for method __float__ of class Money
def test_Money___float__():
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00
    assert float(SomeMoney(Currency("USD"), Decimal("100.00"), Date(2018, 1, 1))) == 100.00

# Generated at 2022-06-18 02:56:20.026406
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import USD
    from .money import Money
    from .money import SomeMoney
    from .money import NoMoney
    from .money import NoneMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import UndefinedMoney
    from .money import Undefined

# Generated at 2022-06-18 02:56:28.508250
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).floor_divide(Decimal("2.0")) == Price.of(Currency.USD, Decimal("0.0"), Date.today())
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).floor_divide(Decimal("0.0")) == NoPrice
    assert Price.of(Currency.USD, Decimal("1.0"), Date.today()).floor_divide(Decimal("-1.0")) == Price.of(Currency.USD, Decimal("-1.0"), Date.today())

# Generated at 2022-06-18 02:56:35.146163
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    """
    Tests method __truediv__ of class Money.
    """
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class Money
    # Test for method __truediv__ of class

# Generated at 2022-06-18 03:01:01.352803
# Unit test for method subtract of class Price
def test_Price_subtract():
    # Test for method subtract of class Price
    assert Price.of(USD, Decimal("100.00"), Date(2020, 1, 1)).subtract(
        Price.of(USD, Decimal("100.00"), Date(2020, 1, 1))
    ) == Price.of(USD, Decimal("0.00"), Date(2020, 1, 1))
    assert Price.of(USD, Decimal("100.00"), Date(2020, 1, 1)).subtract(
        Price.of(USD, Decimal("200.00"), Date(2020, 1, 1))
    ) == Price.of(USD, Decimal("-100.00"), Date(2020, 1, 1))

# Generated at 2022-06-18 03:01:11.688341
# Unit test for method convert of class Price
def test_Price_convert():
    assert Price.of(USD, 1, Date.today()).convert(EUR) == Price.of(EUR, 1.1, Date.today())
    assert Price.of(USD, 1, Date.today()).convert(EUR, Date.today()) == Price.of(EUR, 1.1, Date.today())
    assert Price.of(USD, 1, Date.today()).convert(EUR, Date.today() + 1) == Price.of(EUR, 1.2, Date.today())
    assert Price.of(USD, 1, Date.today()).convert(EUR, Date.today() - 1) == Price.of(EUR, 1.0, Date.today())

# Generated at 2022-06-18 03:01:24.407083
# Unit test for method __le__ of class Money
def test_Money___le__():
    assert (SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.0"), Date.today()))
    assert (SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.1"), Date.today()))
    assert (SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.0"), Date.today() + 1))
    assert (SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.1"), Date.today() + 1))
    assert (SomeMoney(USD, Decimal("1.0"), Date.today()) <= SomeMoney(USD, Decimal("1.0"), Date.today() + 1))

# Generated at 2022-06-18 03:01:35.393711
# Unit test for method __le__ of class Price
def test_Price___le__():
    assert Price.of(USD, Decimal("1.0"), Date(2019, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2019, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2019, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2019, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2019, 1, 1)) <= Price.of(USD, Decimal("1.0"), Date(2019, 1, 2))
    assert Price.of(USD, Decimal("1.0"), Date(2019, 1, 1)) <= Price.of(USD, Decimal("2.0"), Date(2019, 1, 2))

# Generated at 2022-06-18 03:01:44.339822
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert Price.of(USD, Decimal("10.00"), Date.today()) - Price.of(USD, Decimal("10.00"), Date.today()) == Price.of(USD, Decimal("0.00"), Date.today())
    assert Price.of(USD, Decimal("10.00"), Date.today()) - Price.of(USD, Decimal("20.00"), Date.today()) == Price.of(USD, Decimal("-10.00"), Date.today())
    assert Price.of(USD, Decimal("20.00"), Date.today()) - Price.of(USD, Decimal("10.00"), Date.today()) == Price.of(USD, Decimal("10.00"), Date.today())