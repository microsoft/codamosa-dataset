

# Generated at 2022-06-12 06:26:30.850501
# Unit test for method lt of class Money
def test_Money_lt():
    mon1 = Money.of(Currency.USD, 100, Date.today())
    mon2 = Money.of(Currency.USD, 200, Date.today())
    mon3 = Money.of(Currency.EUR, 100, Date.today())
    mon4 = Money.of(Currency.EUR, 200, Date.today())
    mon5 = Money.of(Currency.USD, 100, Date.today())
    mon6 = Money.of(Currency.USD, 200, Date.today())
    
    
    assert mon1.lt(mon2)
    assert mon3.lt(mon4)
    assert mon1.lt(mon3)
    assert mon2.lt(mon4)
    
    assert not(mon1.lt(mon5))
    assert not(mon2.lt(mon6))
   

# Generated at 2022-06-12 06:26:37.262509
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from muckr_core.currencies import Currency  # noqa: F401
    from muckr_core.money import Money  # noqa: F401
    ccy = Currency.USD
    money = Money.of(ccy, 10, "2019-01-01")
    assert money.as_integer() == 10


# Generated at 2022-06-12 06:26:41.663195
# Unit test for method add of class Price
def test_Price_add():
    a = Price(CURRENCY_USD, 10, DATE(2020, 3, 3))
    b = Price(CURRENCY_USD, 5, DATE(2020, 3, 3))
    c = a.add(b)
    c.qty == 15

# Generated at 2022-06-12 06:26:52.445819
# Unit test for method __add__ of class Money
def test_Money___add__():
    # Test case 01 (symmetric):
    # + Undefined Money Objects
    assert (0 * NoMoney) == NoMoney
    assert (NoMoney + 0 * NoMoney) == NoMoney
    assert (NoMoney + NoMoney) == NoMoney
    assert (NoMoney + NoMoney + NoMoney) == NoMoney

    # + Undefined Money Object and Defined Money Object
    assert (0 * NoMoney) == NoMoney
    assert (NoMoney + 0 * USD(10)) == NoMoney
    assert (NoMoney + USD(10)) == USD(10)

    # + Defined Money Object and Undefined Money Objects
    assert (0 * USD(10)) == USD(10)
    assert (USD(10) + 0 * NoMoney) == USD(10)
    assert (USD(10) + NoMoney) == USD(10)

# Generated at 2022-06-12 06:27:00.197177
# Unit test for method __gt__ of class Price
def test_Price___gt__():

    # The following code was used to generate the bytecode
    def __gt__(self, other: "Price") -> bool:
        try:
            return (
                self.defined and
                other.defined and
                self.ccy == other.ccy and
                self.qty > other.qty
            )
        except AttributeError:
            if other is None:
                return self.defined
            return False

    # The following code was used to generate the bytecode
    def __gt__(self, other: "Price") -> bool:
        try:
            return (
                self.defined and
                other.defined and
                self.ccy == other.ccy and
                self.qty > other.qty
            )
        except AttributeError:
            if other is None:
                return self.defined
            return False

# Generated at 2022-06-12 06:27:05.075982
# Unit test for method add of class Price
def test_Price_add():
    assert Price.of(CCY_USD, 1, Date.today()).add(Price.of(CCY_EUR, 1, Date.today())) == NoPrice
    assert Price.of(CCY_USD, 1, Date.today()).add(Price.of(CCY_USD, 1, Date.today())) == Price.of(CCY_USD, 2, Date.today())
    assert Price.of(CCY_EUR, 1, Date.today()).add(Price.of(CCY_EUR, 1, Date.today())) == Price.of(CCY_EUR, 2, Date.today())

# Generated at 2022-06-12 06:27:09.117039
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    actual_result = Money.of(Currency.USD, Decimal("1.234"), Date.today()).with_ccy(Currency.EUR)
    expected_result = Money.of(Currency.EUR, Decimal("1.234"), Date.today())
    assert actual_result == expected_result
    return

# Generated at 2022-06-12 06:27:13.369200
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    m1 = Money.NA
    m2 = Money.of(Currency("USD"), 10, Date.today())
    assert (m1 < m2) == True

    m1 = m2
    assert (m1 < m2) == False



# Generated at 2022-06-12 06:27:24.598519
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    with_ccy1 = Price.of(Currency.USD, 10.0, datetime.date(2020, 1, 3)).with_ccy(Currency.GBP)
    with_ccy2 = Price.of(Currency.USD, 10.0, datetime.date(2020, 1, 3)).with_ccy(None)
    with_ccy3 = Price.of(None, 10.0, datetime.date(2020, 1, 3)).with_ccy(None)
    with_ccy4 = Price.of(None, 10.0, datetime.date(2020, 1, 3)).with_ccy(Currency.GBP)
    with_ccy5 = Price.of(None, None, datetime.date(2020, 1, 3)).with_ccy(Currency.GBP)

# Generated at 2022-06-12 06:27:29.904234
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    import gs_quant.markets.portfolio as pf

    positions = pf.create_positions([pf.AssetClass.Equity], 'US', 'EUR', 'GBP', notional=1000)
    # Get current value
    positions_value = positions.resolve().instrument_values()
    # Change the value date of a position
    positions_value_with_dov = positions_value.with_dov(Date.today())

# Generated at 2022-06-12 06:28:14.839938
# Unit test for method times of class Price
def test_Price_times():
    price = Price.of(ccy=USD, qty=Decimal(10), dov=Date.of(2020, 1, 2))
    money = price.times(5)
    assert money == Money.of(ccy=USD, qty=Decimal(50), dov=Date.of(2020, 1, 2))

# Generated at 2022-06-12 06:28:18.825853
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    print('## Unit test for method __gt__ of class Price')

    __prices = [Price.of(Currency.of('USD'), Decimal('1'), TODAY), Price.of(Currency.of('USD'), Decimal('2'), TODAY), Price.of(Currency.of('EUR'), Decimal('1'), TODAY)]
    __result = [False, False, False]

    for i in range(3):
        for j in range(3):
            __result[i] |= __prices[i] > __prices[j]

    assert __result == [False, True, False]



# Generated at 2022-06-12 06:28:22.330337
# Unit test for method __float__ of class Price
def test_Price___float__():
    some_price = Price.of(ccy=Currency.of(code="USD"), qty=Decimal("100.00"), dov=Date.of(2020, 2, 11))
    assert 100.0 == float(some_price)


# Generated at 2022-06-12 06:28:29.094560
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert Price.of('AUD', Decimal(100), pydt.date(2018, 1, 1)).with_ccy('USD') == Price.of('USD', Decimal(100), pydt.date(2018, 1, 1))
    assert Price.of('AUD', Decimal(700), pydt.date(2018, 1, 1)).with_ccy('JPY') == Price.of('JPY', Decimal(700), pydt.date(2018, 1, 1))
    assert Price.of('AUD', Decimal(50.3), pydt.date(2018, 1, 1)).with_ccy('CNY') == Price.of('CNY', Decimal(50.3), pydt.date(2018, 1, 1))



# Generated at 2022-06-12 06:28:39.159142
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    """
    Ensure that the method with_dov of class Money works as expected.
    """
    from ..engine.currencies import USD

    m = Money(USD, 1, Date(2020, 1, 1))
    with Expectation(m.qty, 1):
        with Expectation(m.ccy.code, 'USD'):
            with Expectation(m.dov, Date(2020, 1, 1)):
                with Expectation(m.with_dov(Date(2020, 1, 2)), Money(USD, 1, Date(2020, 1, 2))):
                    pass
    # Ensure that with_dov of NoneMoney must return NoneMoney
    nm = NoneMoney
    with Expectation(nm.with_dov(Date(2020, 1, 2)), nm):
        pass


# Generated at 2022-06-12 06:28:46.859033
# Unit test for method __gt__ of class Money
def test_Money___gt__():

    import pytest

    money = Money.of(EUR, 12.34, TODAY)
    assert money > Money.of(EUR, 10.34, TODAY)

    with pytest.raises(IncompatibleCurrencyError):
        money > Money.of(USD, 10.34, TODAY)

    assert not (money > money)

    assert not (NoMoney > money)

    assert money > NoMoney

    assert money > NoneMoney

    assert not (NoMoney > NoneMoney)

    assert not (NoneMoney > NoMoney)



# Generated at 2022-06-12 06:28:53.919964
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    """
    Test Money.__gt__()

    Test case:
    - Defined
      - Money(ccy=GBP, qty=10, dov=2020-10-01) > Money(ccy=GBP, qty=5, dov=2020-10-01) is True
    - Undefined
      - Money(ccy=None, qty=None, dov=None) > Money(ccy=GBP, qty=10, dov=2020-10-01) is False
    - Incompatible Currencies
      - Money(ccy=GBP, qty=10, dov=2020-10-01) > Money(ccy=USD, qty=10, dov=2020-10-01) raises IncompatibleCurrencyError
    """
    # Defined

# Generated at 2022-06-12 06:29:03.278104
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    """
    Test case verifies the behaviour of ``__bool__`` method of class Money.
    """

    # Test case #1:
    # Test case verifies the behaviour of ``__bool__`` method of class Money.
    #
    # Expected Result:
    # ``__bool__`` method of class Money should return ``True`` for all defined money objects.

    assert(bool(SomeMoney()))
    assert(bool(SomeMoney(ccy=Currency.USD, qty=10.*Currency.USD.precision, dov=Date.today())))
    assert(bool(SomeMoney(ccy=Currency.USD, qty=0.*Currency.USD.precision, dov=Date.today())))

    # Test case #2:
    # Test case verifies the behaviour of ``__bool__`` method of class Money.

# Generated at 2022-06-12 06:29:14.424901
# Unit test for method divide of class Money
def test_Money_divide():
    assert NoMoney.divide(10) == NoMoney
    assert NoMoney.divide(NoMoney) == NoMoney
    assert SomeMoney(EUR, 100, Date(2020, 1, 1)).divide(10) == SomeMoney(EUR, 10, Date(2020, 1, 1))
    assert SomeMoney(EUR, 100, Date(2020, 1, 1)).divide(SomeMoney(EUR, 2, Date(2020, 1, 1))) == SomeMoney(EUR, 50, Date(2020, 1, 1))
    assert SomeMoney(EUR, 100, Date(2020, 1, 1)).divide(SomeMoney(USD, 2, Date(2020, 1, 1))) == NoMoney



# Generated at 2022-06-12 06:29:18.039360
# Unit test for method as_float of class Money
def test_Money_as_float():
    ccy = Currency('XXX', 'Test', '000', '$', -2, 0)
    money = Money.of(ccy, 0.1234, Date.today())
    assert(money.as_float() == 0.1234)
