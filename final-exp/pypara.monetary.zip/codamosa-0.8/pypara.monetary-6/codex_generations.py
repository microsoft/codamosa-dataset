

# Generated at 2022-06-12 06:24:33.629895
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    return True # String

# Generated at 2022-06-12 06:24:44.698011
# Unit test for method gt of class Price
def test_Price_gt():
    assert NoPrice.gt(NoPrice) is False
    assert NoPrice.gt(SomePrice(USD, D("100.00"), Date(2019, 1, 1))) is False
    assert SomePrice(USD, D("100.00"), Date(2019, 1, 1)).gt(NoPrice) is True
    assert SomePrice(USD, D("100.00"), Date(2019, 1, 1)).gt(SomePrice(USD, D("100.00"), Date(2019, 1, 1))) is False
    assert SomePrice(USD, D("100.00"), Date(2019, 1, 1)).gt(SomePrice(USD, D("99.99"), Date(2019, 1, 1))) is True

# Generated at 2022-06-12 06:24:49.747354
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    global ccy
    ccy = Currency()
    value = Price()
    assertNotEqual(value.__ge__(ccy), NotImplemented)
    assertNotEqual(ccy.__ge__(value), NotImplemented)

# Generated at 2022-06-12 06:24:51.999527
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    p1 = Price.of(CCY_USD, 0, TODAY)
    p2 = Price.of(CCY_USD, 1, TODAY)
    assert p1.as_boolean() == False
    assert p2.as_boolean() == True


# Generated at 2022-06-12 06:24:56.073725
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    ccys = [Currency.USD, Currency.EUR, Currency.TRY]
    qss = [Decimal(1), Decimal(2), Decimal(3)]
    dss = [Date.now(), Date.now().shift_days(1), Date.now().shift_days(2)]
    for ccy in ccys:
        for qs in qss:
            for ds in dss:
                for ccy1 in ccys:
                    for qs1 in qss:
                        for ds1 in dss:
                            with raises(IncompatibleCurrencyError):
                                Money.of(ccy, qs, ds).floor_divide(Money.of(ccy1, qs1, ds1))

# Generated at 2022-06-12 06:25:03.448783
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    """ Test for method Money.__truediv__ """
    import pytest
    ccy = Currency("EUR")
    qty = Decimal("1.23456789012345")
    dov = Date("2017-09-04")
    m1 = Money.of(ccy, qty, dov)
    assert m1.__truediv__(m1) == Decimal("1")

# Generated at 2022-06-12 06:25:10.386147
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    '''
    Tests the with_dov method of class Price
    '''
    eur = Currency.of('EUR')
    val1 = Price.of(eur, 1.0, Date.of(2020, 2, 29))
    val2 = Price.of(eur, 1.0, Date.of(2020, 3, 1))
    val3 = Price.of(eur, 1.0, Date.of(2020, 3, 2))

    assert val1.with_dov(Date.of(2020, 3, 1)) == val2
    assert val2.with_dov(Date.of(2020, 2, 29)) == val1
    assert val1.with_dov(Date.of(2020, 3, 2)) != val2
    assert val2.with_dov(Date.of(2020, 3, 2))

# Generated at 2022-06-12 06:25:15.117254
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert SomeMoney(ccy=EUR, qty=Decimal("1.0000"), dov=Date.today()) > SomeMoney(ccy=EUR, qty=Decimal("0.9999"), dov=Date.today())



# Generated at 2022-06-12 06:25:26.050953
# Unit test for method lt of class Money
def test_Money_lt():
    assert NoMoney.lt(NoMoney) == False
    assert NoMoney.lt(SomeMoney(USD, Decimal(10), Date.now())) == True
    assert SomeMoney(USD, Decimal(10), Date.now()).lt(NoMoney) == False
    assert SomeMoney(USD, Decimal(10), Date.now()).lt(SomeMoney(USD, Decimal(11), Date.now())) == True
    assert SomeMoney(USD, Decimal(10), Date.now()).lt(SomeMoney(USD, Decimal(10), Date.now())) == False
    assert SomeMoney(USD, Decimal(10), Date.now()).lt(SomeMoney(USD, Decimal(9), Date.now())) == False


# Generated at 2022-06-12 06:25:37.650959
# Unit test for method lte of class Money
def test_Money_lte():
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert NoneMoney.lte(SomeMoney(Currency("EUR"), 10, Date(2017, 12, 31)))
    assert None

# Generated at 2022-06-12 06:26:59.909590
# Unit test for method times of class Price
def test_Price_times():
    # Test1 : scalar times scalar
    usd_5=Price(5,ccy="USD")
    usd_10=Price(10,ccy="USD")
    assert(usd_5.times(2)==usd_10)
    assert(2*usd_5==usd_10)
    # Test2: scalar times vector 
    usd_5=Price(5,ccy="USD")
    usd_10=Price(10,ccy="USD")
    usd_20=Price(20,ccy="USD")
    usd_30=Price(30,ccy="USD")
    assert(usd_5.times([2,4])==[usd_10,usd_20])

# Generated at 2022-06-12 06:27:05.864199
# Unit test for method lt of class Price
def test_Price_lt():
    eur = Currency.EUR
    dt = Date.today()
    assert (Price.of(eur, Decimal("10"), dt) < Price.of(eur, Decimal("12"), dt)) == True
    assert (Price.of(eur, Decimal("10"), dt) < Price.of(eur, Decimal("10"), dt)) == False
    assert (Price.of(eur, Decimal("10"), dt) < Price.of(eur, Decimal("8"), dt)) == False
    assert (Price.of(eur, Decimal("10"), dt) < Price.of(eur, None, dt)) == False
    assert (Price.of(eur, Decimal("10"), dt) < Price.of(None, Decimal("10"), dt)) == False

# Generated at 2022-06-12 06:27:18.121114
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    """
    Checks if "with_dov" method of class Money works as expected
    """
    # Define a dummy currency object
    ccy = Currency.of("EUR")

    # Define a dummy date object
    date = Date.today()

    # Define a dummy quantity
    quantity = Decimal('10')

    # Create a dummy money object
    money_object = Money.of(ccy,quantity,date)

    # Get a new money object with the same quantity and currency, but different date
    new_money_object = money_object.with_dov(Date.today().add(years=1))

    # Check if the new money object differs from the old one
    assert new_money_object.qty == money_object.qty
    assert new_money_object.ccy == money_object.ccy


# Generated at 2022-06-12 06:27:29.763581
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    some_money1 = SomeMoney(Currency("EUR"), 100, Date(2019, 12, 31))
    some_money2 = SomeMoney(Currency("GBP"), 100, Date(2019, 12, 31))

    # Check some valid cases.
    assert some_money1 // 3 == SomeMoney(Currency("EUR"), 100 / 3, Date(2019, 12, 31))
    assert some_money1 // 3.0 == SomeMoney(Currency("EUR"), 100 / 3, Date(2019, 12, 31))
    assert some_money1 // some_money2 == SomeMoney(Currency("EUR"), 100 / 100, Date(2019, 12, 31))

    # Now check that we raise an exception when trying to divide with an incompatible currency.

# Generated at 2022-06-12 06:27:38.906945
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ccy1 = Currency.get("USD")
    ccy2 = Currency.get("JPY")
    price1 = SomePrice(ccy1, Decimal("100"), Date.today())
    assert price1.convert(ccy2, Date.today()) == SomePrice(ccy2, Decimal("10"), Date.today())
    price2 = SomePrice(ccy2, Decimal("10"), Date.today())
    assert price1.convert(ccy2, Date.today()) == price2



# Generated at 2022-06-12 06:27:48.989697
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert NoMoney >= NoMoney
    assert NoMoney >= NoneMoney
    assert NoMoney >= SomeMoney(ccy=Currency("USD"), qty=Decimal("1.23"), dov=Date.now())
    assert NoneMoney >= NoMoney
    assert NoneMoney >= NoneMoney
    assert NoneMoney >= SomeMoney(ccy=Currency("USD"), qty=Decimal("1.23"), dov=Date.now())
    assert SomeMoney(ccy=Currency("USD"), qty=Decimal("-100.0"), dov=Date.now()) >= NoMoney
    assert SomeMoney(ccy=Currency("USD"), qty=Decimal("-100.0"), dov=Date.now()) >= NoneMoney

# Generated at 2022-06-12 06:28:01.255136
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert NoMoney.is_equal(NoMoney) == True
    assert SomeMoney(Currency("ABC"), 1, Date(2020, 1, 1)).is_equal(NoMoney) == False
    assert NoMoney.is_equal(SomeMoney(Currency("ABC"), 1, Date(2020, 1, 1))) == False
    assert SomeMoney(Currency("ABC"), 1, Date(2020, 1, 1)).is_equal(SomeMoney(Currency("ABC"), 1, Date(2020, 1, 1))) == True
    assert SomeMoney(Currency("ABC"), 1, Date(2020, 1, 1)).is_equal(SomeMoney(Currency("DEF"), 1, Date(2020, 1, 1))) == False

# Generated at 2022-06-12 06:28:07.274296
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(Currency.USD, 10.0, Date.today()) < Money.of(Currency.USD, 10.1, Date.today())
    assert Money.of(Currency.USD, 10.0, Date.today()) < Money.of(Currency.EUR, 10.0, Date.today())
    assert Money.of(Currency.USD, 10.0, Date.today()) < Money.of(Currency.USD, 10.0, Date.today() + 1)

    ## Same currency and dates
    try:
        Money.of(Currency.USD, 10.0, Date.today()) < Money.of(Currency.USD, 10.0, Date.today())
    except ValueError as e:
        e.args[0] == "Can not compare money with itself."
    else:
        raise RuntimeError

# Generated at 2022-06-12 06:28:08.687196
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert False


# Generated at 2022-06-12 06:28:18.431021
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    """
    Tests for method __truediv__ of class Money
    """
    from . import Currency, SomeMoney, NoMoney
    from .currencies.iso import EUR, USD
    from .commons.zeitgeist import Date
    from .commons.numbers import ONE_HUNDRED
    from decimal import Decimal

    assert (SomeMoney(USD, Decimal("100"), Date.now()).__truediv__(ONE_HUNDRED) == SomeMoney(USD, Decimal("1"), Date.now()))
    assert (NoMoney.__truediv__(ONE_HUNDRED) == NoMoney)



# Generated at 2022-06-12 06:28:38.671103
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    result = NoMoney.as_boolean()
    assert False == result

    result = SomeMoney(Currency.USD, Decimal("0E-2"), Date.today()).as_boolean()
    assert False == result

    result = SomeMoney(Currency.USD, Decimal("1E-2"), Date.today()).as_boolean()
    assert True == result

# Generated at 2022-06-12 06:28:49.941094
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert NoPrice.as_boolean() == False
    assert as_boolean(NoPrice) == False
    assert Price.of(USD, 9.9, date.today()).as_boolean() == True
    assert Price.of(None, 9.9, date.today()).as_boolean() == False
    assert Price.of(USD, 0, date.today()).as_boolean() == False
    assert Price.of(USD, None, date.today()).as_boolean() == False
    assert Price.of(USD, 9.9, None).as_boolean() == False
    assert Price.of(USD, Decimal(9.9), date.today()).as_boolean() == True
    assert Price.of(USD, Decimal("9.9"), date.today()).as_boolean() == True

# Generated at 2022-06-12 06:29:00.758151
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    ccy = Currency(code='ARS')
    qty = Decimal(1)
    dov = Date(2019, 4, 12)
    m = Money.of(ccy, qty, dov)
    to = Currency(code='USD')
    asof = dov
    strict = False
    m_c = m.convert(to, asof, strict)
    assert m_c.ccy.code == to.code
    print(m_c.qty)
    assert isinstance(m_c.qty, Decimal)
    assert m_c.dov == dov
    print(m_c.dov)
    assert isinstance(m_c.dov, Date)
    # Test the following functions raise an error
    # Try to convert itself

# Generated at 2022-06-12 06:29:14.004004
# Unit test for method __add__ of class Money
def test_Money___add__():
    from .currencies import USD
    from .dates import date
    from .money import Money
    from .fx import fx_converter
    from .fx import ECBExchangeRateService
    from .exchange import FXRateLookupError

    m1 = Money.of(USD, 10, date(1,1,1))
    m2 = Money.of(USD, 5, date(1,1,1))

    assert Money.of(USD, 15, date(1,1,1)) == m1 + m2

    assert Money.of(USD, -15, date(1,1,1)) == -m1 + m2

    assert isinstance(m1 + Money.NA, Money)
    assert m1 + Money.NA == Money.NA

    assert isinstance(Money.NA + m1, Money)
    assert Money.NA

# Generated at 2022-06-12 06:29:21.295155
# Unit test for method lt of class Money
def test_Money_lt():
    try:
        NoMoney < NoMoney
    except MonetaryOperationException:
        pass
    else:
        AssertionError

    try:
        NoMoney < SomeMoney(Currency.USD, Decimal(5), Date.today())
    except MonetaryOperationException:
        pass
    else:
        AssertionError

    try:
        SomeMoney(Currency.USD, Decimal(5), Date.today()) < NoMoney
    except MonetaryOperationException:
        pass
    else:
        AssertionError

    SomeMoney(Currency.USD, Decimal(5), Date.today()) <= SomeMoney(Currency.USD, Decimal(5), Date.today())


# Generated at 2022-06-12 06:29:31.542607
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    import math
    import datetime
    from decimal import Decimal
    from dataclasses import dataclass, field
    from unittest.mock import sentinel
    from numpy.testing import assert_
    from finstmt.val import _val, _bool, _unit, _price, _money, _date
    from finstmt.val.monetary import Money, Price, SomeMoney, UndefinedValueError, UndefinedCurrencyError, \
        IncompatibleCurrencyError, MonetaryOperationError

    # Test None or undefined values
    assert_(_price(None) < _price(None))
    assert_(_price(None) < _price(0.0))
    assert_(_price(None) < _price(0))
    assert_(_price(None) < _price(0.0))

# Generated at 2022-06-12 06:29:40.909287
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():

    # Arrange
    money1 = Money.of(Currency.JPY, Decimal("1234.56"), Date.today())
    money2 = Money.of(Currency.EUR, Decimal("1234.56"), Date.today())

    # Act
    money3 = money1.with_ccy(Currency.EUR)
    money4 = money1.with_ccy(Currency.JPY)

    # Assert
    assert money4.ccy == Currency.JPY
    assert money4.qty == Decimal("1234.56")

    assert money3.ccy == Currency.EUR
    assert money3.qty == Decimal("1234.56")

    assert money3 == money2


# Generated at 2022-06-12 06:29:45.933096
# Unit test for method __int__ of class Price
def test_Price___int__():
    tests = [
        (Money.EU(100), 100),
        (Money.EU(100.5), 100),
        (Money.US(100.8), 100),
        (Money.US(100.2), 100),
        (Money.NA(), 0),
        (Money.US(Decimal('Nan')), 0),
        (Money.US(Decimal('Infinity')), 0),
    ]
    for money, expected in tests:
        assert int(money) == expected

# Generated at 2022-06-12 06:29:53.127492
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert NotImplementedError is raised(by=lambda: NoPrice.as_boolean())
    assert NotImplementedError is raised(by=lambda: SomePrice(EUR, Decimal(0), Date(2020, 1, 1)).as_boolean())
    assert NotImplementedError is raised(by=lambda: SomePrice(EUR, Decimal(1), Date(2020, 1, 1)).as_boolean())

# Generated at 2022-06-12 06:29:59.712757
# Unit test for method gt of class Price
def test_Price_gt():
    def _test_Price_gt(self, other):
        res = self.gt(other)
        if isinstance(other, Money) and (self.undefined or other.undefined):
            return res == other.undefined
        elif isinstance(other, Price) and (self.undefined or other.undefined):
            return res == other.undefined
        else:
            return res == (self.qty > other.qty)

    return _test_Price_gt


# Generated at 2022-06-12 06:30:46.857250
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    # Arrange
    value = 25
    qty_val = Decimal(value)
    dov_val = Date.today()
    ccy_val = Currency.get('USD')

    # Act
    m_obj = Money.of(ccy_val, qty_val, dov_val)
    bool_val = bool(m_obj)

    # Assert
    assert bool_val



# Generated at 2022-06-12 06:30:55.216810
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert SomeMoney(Currency("EUR"), 1, Date.today()) > NoMoney
    assert SomeMoney(Currency("EUR"), 1, Date.today()) > SomeMoney(Currency("EUR"), 0, Date.today())
    assert not SomeMoney(Currency("EUR"), 0, Date.today()) > SomeMoney(Currency("EUR"), 0, Date.today())

    # Incompatible currencies.
    with pytest.raises(IncompatibleCurrencyError):
        SomeMoney(Currency("EUR"), 1, Date.today()) > SomeMoney(Currency("USD"), 1, Date.today())

    # Undefined money.
    with pytest.raises(MonetaryOperationException):
        NoMoney > SomeMoney(Currency("EUR"), 1, Date.today())