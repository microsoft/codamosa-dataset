

# Generated at 2022-06-12 06:26:44.536627
# Unit test for method as_float of class Price
def test_Price_as_float():
    actual = Price.of(EUR, Decimal(100), Date(2020, 1, 5)).as_float()
    assert actual == 100.


# Generated at 2022-06-12 06:26:55.167109
# Unit test for method divide of class Money
def test_Money_divide():
    assert NoneMoney.divide(NoneMoney) is NoneMoney
    assert NoneMoney.divide(NonePrice) is NonePrice
    assert NoneMoney.divide(1) is NoneMoney
    assert NoneMoney.divide(1.0) is NoneMoney
    assert NoneMoney.divide(None) is NoneMoney
    assert NoneMoney.divide(1 + 0j) is NoneMoney

    assert SomeMoney(ccy=None, qty=None, dov=None).divide(NoneMoney) is NoneMoney
    assert SomeMoney(ccy=None, qty=None, dov=None).divide(NonePrice) is NonePrice
    assert SomeMoney(ccy=None, qty=None, dov=None).divide(1) is NoneMoney

# Generated at 2022-06-12 06:27:02.281398
# Unit test for method add of class Price
def test_Price_add():
  from . import Currency, price, date
  from .price import Price
  from .currency import Currency
  from .date import Date
  from decimal import Decimal as D
  p1 = Price(Currency('USD'), D(40), date(2015, 11, 1))
  p2 = Price(Currency('USD'), D(20), date(2015, 11, 1))
  assert p1.add(p2) == Price(Currency('USD'), D(60), date(2015, 11, 1))
  p3 = Price(Currency('AED'), D(40), date(2015, 11, 1))
  assert p1.add(p2) == Price(Currency('USD'), D(60), date(2015, 11, 1))

# Generated at 2022-06-12 06:27:03.094486
# Unit test for method __le__ of class Money
def test_Money___le__():
    pass

# Generated at 2022-06-12 06:27:08.595052
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert NoMoney.__bool__() is False
    assert SomeMoney(None, None, None).__bool__() is False
    assert SomeMoney(Currency.USD, Decimal("0.0"), Date(2019, 1, 1)).__bool__() is False
    assert SomeMoney(Currency.USD, Decimal("0.0001"), Date(2019, 1, 1)).__bool__() is True

# Generated at 2022-06-12 06:27:20.261466
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    Price.NA.__gt__(Price.of('USD', Decimal(100.0), Date.today()))
    Price.of('USD', Decimal(100.0), Date.today()).__gt__(Price.NA)
    Price.NA.__gt__(Price.NA)
    Price.of('USD', Decimal(100.0), Date.today()).__gt__(Price.of('USD', Decimal(100.0), Date.today()))
    Price.of('USD', Decimal(100.0), Date.today()).__gt__(Price.of('USD', Decimal(200.0), Date.today()))
    Price.of('USD', Decimal(200.0), Date.today()).__gt__(Price.of('USD', Decimal(100.0), Date.today()))
# Unit test

# Generated at 2022-06-12 06:27:23.105370
# Unit test for method __le__ of class Money
def test_Money___le__():
    Money.__le__(MonetaryOperationException, 0)
    Money.__le__(NoMoney, float("nan"))
    Money.__le__(SomeMoney, int("0b11"))



# Generated at 2022-06-12 06:27:27.832243
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    # Test method Money.as_boolean(), method Money.as_boolean() of class Money
    # when Money is defined
    assert isinstance(Money.of(Currency("USD"), 100, Date.today()).as_boolean(), bool)
    # when Money is not defined
    assert Money.NA.as_boolean() == False

# Generated at 2022-06-12 06:27:35.816514
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    a = SomeMoney(Currency.USD, Decimal("100"), Date.today())
    b = SomeMoney(Currency.USD, Decimal("100"), Date.today())
    assert a.is_equal(b) == True
    assert a.is_equal("100") == False
    assert a.is_equal(Money.of(Currency.USD, Decimal("100"), Date.today())) == True

# Generated at 2022-06-12 06:27:43.277475
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from .currencies import XTS

    from .commons.numbers import qty_decimal

    m = Money.of(XTS, qty_decimal(10.0), Date(2017, 10, 1))
    assert m.qty == 10.0
    m = Money.of(XTS, qty_decimal(-10.0), Date(2017, 10, 1))
    assert m.qty == -10.0



# Generated at 2022-06-12 06:28:05.456907
# Unit test for method divide of class Money
def test_Money_divide():
    assert SomeMoney(Currency('CHF'), Decimal(200), Date.current()).divide(Decimal(2)) == SomeMoney(Currency('CHF'), Decimal(100), Date.current())
    assert SomeMoney(Currency('CHF'), Decimal(200), Date.current()).divide(Decimal(200)) == SomeMoney(Currency('CHF'), Decimal(1), Date.current())
    assert SomeMoney(Currency('CHF'), Decimal(200), Date.current()).divide(Decimal(201)) == SomeMoney(Currency('CHF'), Decimal('0.995049504950495'), Date.current())

# Generated at 2022-06-12 06:28:08.970957
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    # given
    obj = Money()
    dov = Date()
    # when
    result = obj.with_dov(dov)
    # then
    assert result is obj

# Generated at 2022-06-12 06:28:20.951275
# Unit test for method times of class Price
def test_Price_times():
    """ Check that method times of class Price returns a Money object
    """
    p = Price.of(AUD, Decimal(100), Date(2000,1,1))
    m = Money.of(AUD, Decimal(100), Date(2000,1,1))
    assert p.times(Decimal(1)) == m
    #
    p = Price.of(None, Decimal(100), Date(2000,1,1))
    m = Money.NA
    assert p.times(Decimal(1)) == m
    #
    p = Price.of(AUD, None, Date(2000,1,1))
    m = Money.NA
    assert p.times(Decimal(1)) == m
    #
    p = Price.NA
    m = Money.NA
    assert p.times(Decimal(1)) == m


# Generated at 2022-06-12 06:28:31.434294
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    from . import EUR, USD
    from .currencies import set_default_currency

    monies = [Money.of(EUR, 1, 1), Money.of(USD, 1, 1), Money.of(EUR, 1, 1).convert(USD, 1), Money.of(USD, 1, 1).convert(EUR, 1)]
    for money in monies:
        assert money.with_qty(2) == Money.of(money.ccy, 2, money.dov)
        set_default_currency(money.ccy)
        assert money.with_qty(2) == Money(2, money.dov)
    assert NoMoney.with_qty(2) == NoMoney
    assert (EUR(1, 1).with_qty(None) == NoMoney)

# Generated at 2022-06-12 06:28:41.039385
# Unit test for method with_qty of class Price
def test_Price_with_qty():
  assert Price.NA.with_qty(1.0) == Price.NA
  assert Price(USD, 1.0, Date.today()).with_qty(1.0) == Price(USD, 1.0, Date.today())
  assert Price(USD, 1.0, Date.today()).with_qty(2.0) == Price(USD, 2.0, Date.today())
  assert Price(USD, 1.0, Date(2018,1,1)).with_qty(1.0) == Price(USD, 1.0, Date(2018,1,1))
  assert Price(USD, 1.0, Date(2018,1,1)).with_qty(2.0) == Price(USD, 2.0, Date(2018,1,1))
test_Price_with_qty()
# Unit test

# Generated at 2022-06-12 06:28:45.990830
# Unit test for method abs of class Price
def test_Price_abs():
    assert (Money.NA.abs() == Money.NA) == True
    assert (Money.of(Currency.USD, 1, today).abs() == Money.of(Currency.USD, 1, today)) == True
    assert (Money.of(Currency.USD, -1, today).abs() == Money.of(Currency.USD, 1, today)) == True


# Generated at 2022-06-12 06:28:46.716038
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    pass

# Generated at 2022-06-12 06:28:49.610212
# Unit test for method lte of class Price
def test_Price_lte():
    
    some_price = Price.of(usd, Decimal(1), Date.of('2019-01-01'))
    assert(some_price.lte(some_price) == True)
    
    assert(some_price.lte(NoPrice) == False)
    assert(NoPrice.lte(some_price) == True)
    
    another_price = Price.of(xxx, Decimal(1), Date.of('2019-01-01'))
    assert(some_price.lte(another_price) == True)

# Generated at 2022-06-12 06:28:55.676902
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    c = Currency.of("USD")
    value = c(Decimal("1.1"))  # type: Money
    r = value // Decimal("1.1")  # type: Money
    assert r.ccy.code == "USD"
    assert r.qty == Decimal("1")
    assert r.dov == value.dov
    assert r.defined is True
    assert r.undefined is False



# Generated at 2022-06-12 06:28:59.683877
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    assert Money.of(CURRENCY.USD, 123.45, DATE.today()).__floordiv__(2.0) == Money.of(CURRENCY.USD, 123.45, DATE.today()).floor_divide(2.0)

# Generated at 2022-06-12 06:29:51.848410
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    assert SomePrice(CCY.EUR, Decimal(1), None).convert(CCY.USD, None, False)

test_SomePrice_convert()

# Generated at 2022-06-12 06:29:59.885577
# Unit test for method lt of class Money
def test_Money_lt():
    #Arrange
    m = Money.of(ccy=Currency.USD, qty=Decimal("0.0"), dov=Date.today())
    m2 = Money.of(ccy=Currency.USD, qty=Decimal("1.0"), dov=Date.today())
    m3 = Money.of(ccy=Currency.USD, qty=Decimal("4.0"), dov=Date.today())
    #Act
    res= m.lt(m2)
    res2= m.lt(m3)
    #Assert
    assert res == True
    assert res2 == True



# Generated at 2022-06-12 06:30:08.223115
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.NA.divide(3) == Price.NA
    assert NoPrice.divide(3) == NoPrice
    assert Price.of(CAD, 3, Date.today()).divide(3) == Price.of(CAD, 1, Date.today())
    assert Price.of(CAD, 3, Date.today()).divide(0) == NoPrice
    assert Price.of(CAD, 3, Date.today()).divide(-3) == Price.of(CAD, -1, Date.today())

    with pytest.raises(TypeError):
        Price.NA.divide("3")

test_Price_divide()


# Generated at 2022-06-12 06:30:08.936134
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    pass

# Generated at 2022-06-12 06:30:17.626526
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    # Arrange
    p1 = SomePrice(Currency.USD, Decimal('0.25'), Date(1, Month.January, 2020))
    p2 = SomePrice(Currency.USD, Decimal('0.75'), Date(1, Month.January, 2020))

    # Act
    p = p1.convert(Currency.EUR, Date(1, Month.January, 2020), True)

    # Assert
    assert p == SomePrice(Currency.EUR, Decimal('0.25'), Date(1, Month.January, 2020))
    assert p1.convert(Currency.EUR, Date(1, Month.January, 2020), False) == NoPrice
    assert p1.__class__ is SomePrice

# Generated at 2022-06-12 06:30:23.186326
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    a = SomeMoney(USD, Decimal('10.00'), Date.today())
    assert a.convert(GBP).ccy == GBP
    assert a.convert(GBP, asof=Date(2020, 1, 1)).dov == Date(2020, 1, 1)
    assert a.convert(GBP, strict=True).__class__ == SomeMoney
    assert a.convert(GBP, strict=True).ccy == GBP



# Generated at 2022-06-12 06:30:31.707928
# Unit test for method lt of class Price
def test_Price_lt():
    Price.NA = Price.of(currencies.USD, Decimal('0'), Date.today())
    Price.NA = Price.of(currencies.USD, Decimal('5'), Date.today())
    Price.of(currencies.USD, Decimal('5'), Date.today())
    Price.of(currencies.USD, Decimal('5'), Date.today())
    Price.of(currencies.USD, Decimal('0'), Date.today())
    Price.NA = Price.of(currencies.USD, Decimal('0'), Date.today())
    Price.of(currencies.USD, Decimal('0'), Date.today())
    Price.of(currencies.USD, Decimal('0'), Date.today())
    Price.NA = Price.of(currencies.USD, Decimal('0'), Date.today())

# Generated at 2022-06-12 06:30:36.263114
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert NoPrice.with_dov(Date.current()) == NoPrice
    assert isinstance(SomePrice(USD, Decimal('1000'), Date.current()).with_dov(Date(2020, 2, 11)), SomePrice)



# Generated at 2022-06-12 06:30:40.379855
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.NA.with_dov(Date.today()) == Price.NA
    a = Price.of(EUR, Decimal(100), Date.new(2019, 12, 31))
    assert a.with_dov(Date.today()) == Price.of(EUR, Decimal(100), Date.today())


# Generated at 2022-06-12 06:30:52.045489
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    undef_price = _Price.of(None, None, None)

    assert not undef_price.is_equal(None)

    USDEUR = _Currency("EUR")
    NYSE = _Exchange("NYSE")
    GBPUSD = _CurrencyPair(None, USDEUR)

    assert undef_price.is_equal(undef_price)

    # Same currency, same quantity, same date
    usd_price1 = _Price.of(USD, Decimal("100"), _Date(2018, 3, 31))
    usd_price2 = _Price.of(USD, Decimal("100"), _Date(2018, 3, 31))
    assert usd_price1.is_equal(usd_price2)

    # Different currencies, different quantities, different dates
    usd_price1 = _