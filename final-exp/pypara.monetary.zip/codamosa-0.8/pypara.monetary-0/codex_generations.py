

# Generated at 2022-06-12 06:24:25.562378
# Unit test for method times of class Price
def test_Price_times():
    ccy = Currency.of("USD")
    qty = Decimal("2.57")
    date = Date.of("2020-04-27")
    price = Price.of(ccy, qty, date)
    money = Money.of(ccy, Decimal("2.57"))
    assert price.times(1) == money
    assert price.times(Decimal("2")) == money * Decimal("2")
    assert price.times(Decimal("0.1")) == money * Decimal("0.1")

    no_price = Price.of(ccy, None, date)
    assert no_price.times(1) == no_price
    assert no_price.times(Decimal("2")) == no_price
    assert no_price.times(Decimal("0.1")) == no_price


# Unit

# Generated at 2022-06-12 06:24:35.391408
# Unit test for method times of class Price
def test_Price_times():
    standard_test_cases = [
        # (price, other: Decimal, expected_result)
        (NoPrice, 1, NoMoney),
        (Price.of(Currency.USD, 1, Date.today()), 0, Money.of(Currency.USD, 0, Date.today())),
        (Price.of(Currency.USD, 1, Date.today()), 1, Money.of(Currency.USD, 1, Date.today())),
        (Price.of(Currency.USD, 1, Date.today()), 2, Money.of(Currency.USD, 2, Date.today())),
    ]

# Generated at 2022-06-12 06:24:37.550454
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    # No test can be written for abstract method.
    pass

# Generated at 2022-06-12 06:24:48.192809
# Unit test for method multiply of class Money
def test_Money_multiply():
    assert Money.of(Currency.USD, 1, Date.today()).multiply(1.0) == Money.of(Currency.USD, 1, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).multiply(0.0) == Money.of(Currency.USD, 0, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).multiply(2) == Money.of(Currency.USD, 2, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).multiply(Decimal(3)) == Money.of(Currency.USD, Decimal(3), Date.today())

# Generated at 2022-06-12 06:24:48.846683
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    pass

# Generated at 2022-06-12 06:24:49.550234
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    return


# Generated at 2022-06-12 06:24:55.118528
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    from money import Money

    assert Money.of(USD, 1).scalar_subtract(Decimal(0.5)) == Money.of(USD, 0.5)
    assert Money.of(USD, 1).scalar_subtract(Decimal(0.5)) <= Money.of(USD, 0.5)
    assert Money.of(USD, 1).scalar_subtract(Decimal(0.5)) <= Money.of(USD, 0.6)
    assert Money.of(USD, 1).scalar_subtract(Decimal(0.5)) <= Money.of(EUR, 0.5)
    assert Money.of(USD, 1).scalar_subtract(Decimal(0.5)) < Money.of(USD, 0.4)

# Generated at 2022-06-12 06:25:06.190179
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    with pytest.raises(TypeError):
        NoPrice.with_ccy(ccy=USD)

    assert NoPrice.with_ccy(ccy=None) is NoPrice

    assert SomePrice(ccy=USD, qty=Decimal(1), dov=Date.today()).with_ccy(
        ccy=USD
    ) == SomePrice(ccy=USD, qty=Decimal(1), dov=Date.today())
    assert SomePrice(ccy=USD, qty=Decimal(1),
                     dov=Date.today()).with_ccy(ccy=EUR) == SomePrice(
                         ccy=EUR, qty=Decimal(1), dov=Date.today())

# Generated at 2022-06-12 06:25:14.046463
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert NoneMoney.as_boolean() is False
    assert NoMoney.as_boolean() is False
    assert SomeMoney(None, 0, None).as_boolean() is True
    assert SomeMoney(Currency("USD"), 0, None).as_boolean() is False
    assert SomeMoney(Currency("USD"), 1, None).as_boolean() is True



# Generated at 2022-06-12 06:25:25.916394
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    # money.NA - 5, money.NA - [5, 5, 5]
    assert Money.NA.scalar_subtract(5) == Money.NA
    assert Money.NA.scalar_subtract([5, 5, 5]) == Money.NA
    # 5 - money.NA, [5, 5, 5] - money.NA
    assert 5 - Money.NA == Money.NA
    assert [5, 5, 5] - Money.NA == Money.NA
    # usd(5) - 5, usd(5) - [5, 5, 5]
    assert usd(5).scalar_subtract(5) == usd(0)
    assert usd(5).scalar_subtract([5, 5, 5]) == usd(0)
    # 5 - usd(

# Generated at 2022-06-12 06:25:49.087925
# Unit test for method gt of class Price
def test_Price_gt():
    x = Price.of(USD, Decimal("1.0"), dt.datetime.now())
    y = Price.of(USD, Decimal("2.0"), dt.datetime.now())
    assert x.gt(y)
    assert not y.gt(x)
    assert not x.gt(x)

# Generated at 2022-06-12 06:25:49.836882
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    pass

# Generated at 2022-06-12 06:25:56.984748
# Unit test for method gte of class Price
def test_Price_gte():
    ccy = "USD"
    ccy2 = "EUR"
    qty = Decimal("12.45")
    qty2 = Decimal("12.46")
    qty3 = Decimal("12.45")
    dov = Date("2018-12-09")
    dov2 = Date("2018-12-10")
    dov3 = Date("2018-12-09")
    m = Money(ccy, qty, dov)
    m2 = Money(ccy2, qty2, dov2)
    m3 = Money(ccy, qty3, dov3)
    p = Price.of(ccy,qty,dov)
    p2 = Price.of(ccy2,qty2,dov2)

# Generated at 2022-06-12 06:26:05.043600
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    from datetime import date
    from decimal import Decimal, ROUND_HALF_EVEN
    from want.currencies import Currency
    from want.scalars.money import Money
    ccy = Currency("USD")
    qty = Decimal("1.12").quantize(Decimal("1."), rounding=ROUND_HALF_EVEN)
    dov = date(2019, 1, 1)
    # Returns True if other is a Money object and all slots are same
    assert Money.of(ccy, qty, dov).is_equal(Money.of(ccy, qty, dov))

# Generated at 2022-06-12 06:26:18.108500
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    ## Create an instance of SomePrice (USD)
    price = SomePrice(
        ccy = Currency(code = "USD", name = "US Dollar", numeric = "840", decimals = 2, is_crypto = False),
        qty = Decimal(1),
        dov = None
    )
    ## Try the method:
    ret_value = price.__add__(
        other = SomePrice(
            ccy = Currency(code = "USD", name = "US Dollar", numeric = "840", decimals = 2, is_crypto = False),
            qty = Decimal(1),
            dov = None
        )
    )
    ## Check return value
    assert(type(ret_value) == SomePrice)
    ## Check number of fields
    assert(len(ret_value) == 3)
   

# Generated at 2022-06-12 06:26:22.587485
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    ccy = Currency("USD")
    qty = Decimal("100")
    dov = Date(2010, 1, 1)
    ccy2 = Currency("EUR")
    price = Price.of(ccy, qty, dov)
    assert price.with_ccy(ccy2) == Price.of(ccy2, qty, dov)
    assert price == Price.of(ccy, qty, dov)

# Generated at 2022-06-12 06:26:23.821284
# Unit test for method __bool__ of class SomeMoney
def test_SomeMoney___bool__(): pass

# Generated at 2022-06-12 06:26:31.004697
# Unit test for method lt of class Money
def test_Money_lt():
    # undefined against defined
    assert (NoneMoney < SomeMoney(Currency.EUR, Decimal(10), Date.today()) is False)

    # defined against defined
    assert (SomeMoney(Currency.EUR, Decimal(0), Date.today()) < SomeMoney(Currency.EUR, Decimal(10), Date.today()) is True)

    # defined against defined but with different currencies
    with pytest.raises(IncompatibleCurrencyError):
        SomeMoney(Currency.EUR, Decimal(0), Date.today()) < SomeMoney(Currency.USD, Decimal(10), Date.today())

    assert (NoneMoney < NoneMoney is False)
    assert (SomeMoney(Currency.EUR, Decimal(0), Date.today()) < NoneMoney is False)

# Generated at 2022-06-12 06:26:42.998298
# Unit test for method gte of class Price
def test_Price_gte():
    assert NoPrice.gte(NoPrice)
    assert NoPrice.gte(SomePrice(USD, 42, Date.today()))
    assert SomePrice(USD, 42, Date.today()).gte(NoPrice)

    assert SomePrice(USD, 42, Date.today()).gte(SomePrice(USD, 42, Date.today()))
    assert not SomePrice(USD, 42, Date.today()).gte(SomePrice(USD, 43, Date.today()))
    assert SomePrice(USD, 43, Date.today()).gte(SomePrice(USD, 42, Date.today()))
    assert not SomePrice(USD, 42, Date.today()).gte(SomePrice(USD, 42, Date.today() + 1))

# Generated at 2022-06-12 06:26:53.596367
# Unit test for method divide of class Price
def test_Price_divide():
    """
    Tests that divide returns a correct result
    """
    # Test defined function
    price1 = SomePrice(Currency.of('USD'), 500, Date.of(2020, 4, 19))
    price2 = SomePrice(Currency.of('USD'), 50, Date.of(2020, 4, 19))
    assert price1.divide(price2) == SomePrice(Currency.of('USD'), 10, Date.of(2020, 4, 19))

    # Test divide by zero
    price1 = SomePrice(Currency.of('USD'), 500, Date.of(2020, 4, 19))
    price2 = SomePrice(Currency.of('USD'), 0, Date.of(2020, 4, 19))
    assert price1.divide(price2) == NoPrice

    # Test with undefined price
    price1 = NoPrice

# Generated at 2022-06-12 06:29:27.040313
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    ccy = Ccy("USD")
    qty = Decimal("1.01")
    dov = Date(2020, 1, 1)
    p1 = SomePrice(ccy, qty, dov)
    ccy = Ccy("USD")
    qty = Decimal("0.01")
    dov = Date(2020, 1, 1)
    p2 = SomePrice(ccy, qty, dov)
    assert (p1 + p2).qty == Decimal("1.02")


# Generated at 2022-06-12 06:29:29.926783
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    """
    Case: undefined operation
    """
    pass

# Generated at 2022-06-12 06:29:31.274047
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert Money.NA > Money.NA


# Generated at 2022-06-12 06:29:34.793692
# Unit test for method negative of class Price
def test_Price_negative():
    assert isinstance(Price.NA.negative(), Price)
    assert isinstance(Price.of(Currency.get('USD'), Decimal('1.0'), Date.today()).negative(), Price)
    
    

# Generated at 2022-06-12 06:29:37.335867
# Unit test for method __float__ of class Price
def test_Price___float__():
    with raises(NotImplementedError):
        Price().__float__()



# Generated at 2022-06-12 06:29:43.639483
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    """Test method as_integer of class Price."""
    price = Price.of(USD, Decimal("1234.56"), Date(2018, 1, 1))
    assert isinstance(price.as_integer(), int)
    assert price.as_integer() == 1234

    price = Price.of(USD, Decimal("0"), Date(2018, 1, 1))
    assert isinstance(price.as_integer(), int)
    assert price.as_integer() == 0

# Generated at 2022-06-12 06:29:55.046807
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert NoneMoney.is_equal(NoneMoney)
    assert NoMoney.is_equal(NoMoney)
    assert SomeMoney(USD, Decimal('1'), TODAY).is_equal(SomeMoney(USD, Decimal('1'), TODAY))
    assert not (SomeMoney(USD, Decimal('1'), TODAY) == NoMoney)
    assert not (SomeMoney(USD, Decimal('1'), TODAY) == NoneMoney)
    assert not (SomeMoney(USD, Decimal('1'), TODAY) == SomeMoney(USD, Decimal('2'), TODAY))
    assert not (SomeMoney(USD, Decimal('1'), TODAY) == SomeMoney(EUR, Decimal('1'), TODAY))
    assert not (SomeMoney(USD, Decimal('1'), TODAY) == SomeMoney(USD, Decimal('1'), TOMORROW))

# Generated at 2022-06-12 06:30:05.122855
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    assert SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 8)).is_equal(SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 8)))
    assert not SomeMoney(USD, Decimal('3.4'), Date(2019, 10, 8)).is_equal(SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 8)))
    assert not SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 8)).is_equal(SomeMoney(CAD, Decimal('3.3'), Date(2019, 10, 8)))
    assert not SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 8)).is_equal(SomeMoney(USD, Decimal('3.3'), Date(2019, 10, 9)))

# Generated at 2022-06-12 06:30:15.959387
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from financepy.products.finutils import FinDate
    from financepy.products.bonds.FinBond import FinBond
    from financepy.products.funding.FinIborSingleCurve import FinIborSingleCurve
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.market.curves.FinDiscountCurve import FinDiscountCurve
    
    ccy = "GBP"
    valueDate = FinDate(2017, 1, 3)
    rate = 0.0350
    
    iborDeposit = FinIborDeposit(valueDate, "1Y", rate, ccy)

    liborCurve = FinIborSingleCurve(valueDate, rate, ccy)
    

# Generated at 2022-06-12 06:30:18.999119
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    obj = Price.of("USD", Decimal("1"), Date.today())
    other = Price.of("HKD", Decimal("2"), Date.today())
    assert (obj < other) is False, "Test failed at line {}".format(inspect.getframeinfo(inspect.currentframe()).lineno)
