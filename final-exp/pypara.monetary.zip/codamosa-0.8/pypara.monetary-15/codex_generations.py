

# Generated at 2022-06-12 06:25:48.781846
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(SomeMoney(USD, 100, Date(2020, 1, 1))) == 100


# Generated at 2022-06-12 06:25:50.537780
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(CCY, 2.00, DATE).round() == SomeMoney(CCY, 2, DATE)
    assert SomeMoney(CCY, 2.475, DATE).round() == SomeMoney(CCY, 2.5, DATE)


# Generated at 2022-06-12 06:25:57.446992
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    import pytest
    # It can convert with fallback enabled
    # ----------------
    x = SomePrice(ccy = Currency('EUR'), qty = Decimal('1000'), dov = Date(2019,1,1))
    x.convert(to = Currency('DKK'), strict = False)
    # It can convert with fallback disabled
    # ----------------
    x = SomePrice(ccy = Currency('EUR'), qty = Decimal('1000'), dov = Date(2019,1,1))
    with pytest.raises(FXRateLookupError):
        x.convert(to = Currency('GBP'), strict = True)
    # It can convert with fallback enabled
    # ----------------
    x = SomePrice(ccy = Currency('EUR'), qty = Decimal('1000'), dov = Date(2019,1,1))

# Generated at 2022-06-12 06:25:59.311786
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(ccy=Currency.of("EUR"), qty=Decimal("1.11"), dov=Date.of(2018, 11, 1)).as_integer() == 1


# Generated at 2022-06-12 06:26:08.093622
# Unit test for method __int__ of class Price
def test_Price___int__():
    import datetime
    import hypothesis.strategies as st
    from hypothesis import given
    from hypothesis.stateful import rule, initialize
    from hypothesis.strategies import composite
    from hypothesis.strategies import integers
    from hypothesis.strategies import floats as flt
    from hypothesis.strategies import decimals
    from fin.money import Money, Price, Currency
    from fin.money import NoMoney, NoPrice
    from fin.currency import Ccy
    from fin.money import SomeMoney, SomePrice
    from fin.money import MonetaryOperationException
    from fin.math import RoundingMethod


# Generated at 2022-06-12 06:26:12.565754
# Unit test for method abs of class Money
def test_Money_abs():
	assert Money.NA.abs() is Money.NA
	assert (~Money(Currency("GBP"), Decimal("-200.00"))).abs() == Money(Currency("GBP"), Decimal("200.00"))

# Generated at 2022-06-12 06:26:19.520705
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    m = SomeMoney(ccy="EUR", qty=10, dov=date(year=2020, month=11, day=15))
    assert m.convert(ccy="USD", asof=date(year=2020, month=11, day=15)) == SomeMoney(ccy="USD", qty=Decimal("11.14571428571429"), dov=date(year=2020, month=11, day=15))



# Generated at 2022-06-12 06:26:29.540847
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    from datetime import date
    from .bank import Bank
    from .exchange import Exchange
    from .fxrate import FXRate
    from .currency import Currency
    from .money import SomeMoney, NoMoney
    from .price import SomePrice, NoPrice
    from .asset import Asset
    from .portfolio import Portfolio

    bank = Bank()
    exchange = Exchange('SGX', bank)
    fxrate = FXRate('SGD/USD', 1.42, date(2017, 11, 6))
    ccy = Currency('SGD', 2, bank)
    asset = Asset('SGD.Z74', ccy, exchange)
    portfolio = Portfolio('test')

    money = SomeMoney(ccy, 100, date(2017, 11, 6))
    money = money.with_dov(date(2017, 11, 7))


# Generated at 2022-06-12 06:26:31.946763
# Unit test for method as_float of class Money
def test_Money_as_float():
    m = Money.of("USD", 100.0, "2020-01-01")
    assert m.as_float() == 100.0

# Generated at 2022-06-12 06:26:44.820738
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    # handle undefined
    assert NoPrice.floor_divide(NoPrice) is NoPrice
    assert NoPrice.floor_divide(SomePrice(USD, Decimal(100), Date())) is NoPrice
    assert SomePrice(USD, Decimal(100), Date()).floor_divide(NoPrice) is NoPrice
    # handle zero
    assert SomePrice(USD, Decimal(0), Date()).floor_divide(SomePrice(USD, Decimal(0), Date())) is NoPrice
    assert SomePrice(USD, Decimal(0), Date()).floor_divide(SomePrice(USD, Decimal(100), Date())) is NoPrice
    assert SomePrice(USD, Decimal(100), Date()).floor_divide(SomePrice(USD, Decimal(0), Date())) is NoPrice
    # currency mismatch

# Generated at 2022-06-12 06:27:13.762523
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    ccy = Currency("USD")
    qty = Decimal("100")
    dov = Date(datetime.date(2019, 11, 15))
    instance = Price.of(ccy, qty, dov)
    result = instance.__gt__(instance)
    assert result == False

# Generated at 2022-06-12 06:27:21.806740
# Unit test for method gte of class Money
def test_Money_gte():
    # Construct the money object that we can operate on:
    m1 = Money.of(Currency.USD, 100, Date.today())
    m2 = Money.of(Currency.USD, 200, Date.today())

    # Perform the comparison:
    assert m1.gte(m2) is False
    assert m1.gte(m1) is True
    assert m2.gte(m1) is True
    assert m1.gte(NoMoney) is True
    assert NoMoney.gte(m1) is False

# Generated at 2022-06-12 06:27:25.042487
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert Price.of(CCY, QTY, DOV).__int__() == int(QTY)

# Generated at 2022-06-12 06:27:30.300755
# Unit test for method __int__ of class Money
def test_Money___int__():
    # m = SomeMoney(ccy, Decimal("2.33"), Date.today())
    # m.__int__() -> raises TypeError
    # m = NoMoney
    # m.__int__() -> raises TypeError
    # m = NoneMoney
    # m.__int__() -> raises TypeError
    pass



# Generated at 2022-06-12 06:27:33.665617
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    with pytest.raises(MonetaryOperationException):
        NoPrice.scalar_add(1)

# Generated at 2022-06-12 06:27:43.326618
# Unit test for method convert of class Price
def test_Price_convert():
    # Test case with default value of argument strict.
    expected_parameters = (NoMoney, 'USD', 'EUR', None)
    assert NoPrice.convert(*expected_parameters) == NoMoney, "NoPrice.convert()"
    # Test case with non-default value of argument strict.
    expected_parameters = (Money(Q(100, 'USD'), 'USD'), 'USD', 'EUR', None, True)
    assert Money(Q(100, 'USD'), 'USD').convert(*expected_parameters) == Money(Q(100, 'USD'), 'EUR'), "Money.convert()"

# Generated at 2022-06-12 06:27:51.100756
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    c1 = Currency.USD
    c2 = Currency.EUR
    d1 = Date(2019,4,1)
    d2 = Date(2019,4,2)
    m1 = SomeMoney(c1, Decimal('1.1'),d1)
    m2 = SomeMoney(c1, Decimal('1.1'),d1)
    m3 = SomeMoney(c1, Decimal('1.0'),d1)
    m4 = SomeMoney(c1, Decimal('1.1'),d2)
    m5 = SomeMoney(c2, Decimal('1.1'),d1)

    assert (m1 <= m2) is True
    assert (m1 <= m3) is False
    assert (m1 <= m4) is True

# Generated at 2022-06-12 06:28:02.939499
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert SomePrice(USD, 1, Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal(1), Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal('1.0'), Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal('1.00'), Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal('1.000'), Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal('1.0000'), Date.today()).as_integer() == 1
    assert SomePrice(USD, Decimal('1.00000'), Date.today()).as_integer() == 1

# Generated at 2022-06-12 06:28:15.455786
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    class SomePrice(Price):

        def is_equal(self, other: Any) -> bool:
            raise NotImplementedError

        def as_boolean(self) -> bool:
            raise NotImplementedError

        def as_float(self) -> float:
            raise NotImplementedError

        def as_integer(self) -> int:
            raise NotImplementedError

        def abs(self) -> "Price":
            raise NotImplementedError

        def negative(self) -> "Price":
            raise NotImplementedError

        def positive(self) -> "Price":
            raise NotImplementedError

        def round(self, ndigits: int = 0) -> "Price":
            raise NotImplementedError

        def add(self, other: "Price") -> "Price":
            raise NotImplemented

# Generated at 2022-06-12 06:28:25.488988
# Unit test for method negative of class Price
def test_Price_negative():
    eur = Currency.of("EUR")
    
    assert Price.of(eur, Decimal("1"), date(2020, 1, 1)).negative() == Price.of(eur, Decimal("-1"), date(2020, 1, 1))
    assert Price.of(eur, Decimal("0.1"), date(2020, 1, 1)).negative() == Price.of(eur, Decimal("-0.1"), date(2020, 1, 1))
    
    assert Price.of(eur, Decimal("-1"), date(2020, 1, 1)).negative() == Price.of(eur, Decimal("1"), date(2020, 1, 1))

# Generated at 2022-06-12 06:30:11.521961
# Unit test for method gt of class Money
def test_Money_gt():
    """
    Tests that the given stub is successfully implemented.
    """
    assert True



# Generated at 2022-06-12 06:30:14.053571
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    ...
    #
    # Test with partially defined values:
    #
    ...
    #
    # Test with fully defined values:
    #
    ...
    # Unit test for method with_qty of class Money

# Generated at 2022-06-12 06:30:23.866408
# Unit test for method gt of class Money
def test_Money_gt():
    # Imports
    from datetime import date
    import pytest
    from typing import Literal
    # Setup
    a = Money.of(Currency.USD, 1, date(2020, 9, 6))
    b = Money.of(Currency.USD, 1, date(2020, 9, 7))
    c = Money.of(Currency.USD, 1, date(2020, 9, 7))
    d = Money.of(Currency.USD, 2, date(2020, 9, 6))
    e = Money.of(Currency.USD, 2, date(2020, 9, 7))
    f = Money.of(Currency.GBP, 2, date(2020, 9, 7))
    # Tests
    assert a.gt(b) is False
    assert a.gt(c) is False

# Generated at 2022-06-12 06:30:31.964197
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    ccy = Currency("USD")
    dov = Date.current()
    qty = Decimal("1.2345")

    # Some vs None
    assert SomeMoney(ccy, qty, dov) != NoMoney
    assert NoMoney != SomeMoney(ccy, qty, dov)

    # Some vs Some
    def _test_SomeMoney_eq(ccy: Currency, dov: Date, qty: Decimal, _eq: bool, _ne: bool) -> None:
        a = SomeMoney(ccy, qty, dov)
        b = SomeMoney(ccy, qty, dov)
        assert a == b if _eq else a != b
        assert b == a if _eq else b != a

# Generated at 2022-06-12 06:30:41.646832
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    pass

    # ## Test for ccy = None:
    # ccy = None
    # qty = Decimal('1')
    # dov = Date(2019, 1, 1)
    # rate = FXRate(Currency('USD'), Currency('EUR'), Decimal('1.2'), dov)
    # price = SomePrice(ccy, qty, dov)

    # expected = NoPrice
    # actual = price.convert(rate.to, rate.asof, strict=True)

    # assert expected.is_equal(actual), f'Expected {expected}, got {actual}'

    ## Test for ccy = USD:
    x = Price
    ccy = Currency('USD')
    qty = Decimal('1')
    dov = Date(2019, 1, 1)

# Generated at 2022-06-12 06:30:52.974336
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    class PriceImpl(Price):
        ccy = None
        qty = None
        dov = None

        def is_equal(self, other: Any) -> bool:
            pass

        def as_boolean(self) -> bool:
            pass

        def as_float(self) -> float:
            pass

        def as_integer(self) -> int:
            pass

        def abs(self) -> "Price":
            pass

        def negative(self) -> "Price":
            pass

        def positive(self) -> "Price":
            pass

        def round(self, ndigits: int = 0) -> "Price":
            pass

        def add(self, other: "Price") -> "Price":
            pass

        def scalar_add(self, other: Numeric) -> "Price":
            pass
