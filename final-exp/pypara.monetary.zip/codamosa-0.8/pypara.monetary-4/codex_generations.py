

# Generated at 2022-06-12 06:24:07.633891
# Unit test for method convert of class Money
def test_Money_convert():
    money_1 = Money.of(ccy = Currency.USD, qty = Decimal(10), dov = Date('2020-02-02'))
    money_2 = Money.of(ccy = Currency.USD, qty = Decimal(20), dov = Date('2020-02-03'))
    money_3 = Money.of(ccy = Currency.USD, qty = Decimal(30), dov = Date('2020-02-04'))
    money_4 = Money.of(ccy = Currency.USD, qty = Decimal(40), dov = Date('2020-02-05'))
    money_5 = Money.of(ccy = Currency.USD, qty = Decimal(50), dov = Date('2020-02-06'))
    

# Generated at 2022-06-12 06:24:14.620157
# Unit test for method convert of class Money
def test_Money_convert():

    from corelib.core.money import Money
    from corelib.core.money import SomeMoney
    from corelib.core.currencies import Currency
    from corelib.core.exchange import CNY_USD_FXRATE
   
    money = SomeMoney(Currency.of("USD"), 1, Date.today())
    money_CNY = money.convert(Currency.of("CNY"), Date.today(), CNY_USD_FXRATE)
    
    assert money_CNY.ccy == Currency.of("CNY")
    assert money_CNY.qty == CNY_USD_FXRATE.convert(Currency.of("USD"), Currency.of("CNY"), Date.today())


# Generated at 2022-06-12 06:24:17.353591
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    price = Price(USD, 1, None)
    assert price // 2 == 0.5



# Generated at 2022-06-12 06:24:19.853811
# Unit test for method scalar_add of class SomeMoney
def test_SomeMoney_scalar_add():
    assert SomeMoney("EUR", 100, asof=Tomorrow) + 10 == SomeMoney("EUR", 110, asof=Tomorrow)



# Generated at 2022-06-12 06:24:31.776579
# Unit test for method lte of class Price
def test_Price_lte():
    assert Price.NA <= Price.NA
    assert Price.NA <= Price(Currency("USD"), Decimal("42"), Date("2019-12-22"))
    assert Price(Currency("USD"), Decimal("42"), Date("2019-12-22")) <= Price(Currency("USD"), Decimal("42"), Date("2019-12-22"))
    assert Price(Currency("USD"), Decimal("42"), Date("2019-12-22")) <= Price(Currency("USD"), Decimal("43"), Date("2019-12-22"))
    assert not (Price(Currency("USD"), Decimal("43"), Date("2019-12-22")) <= Price(Currency("USD"), Decimal("42"), Date("2019-12-22")))

# Generated at 2022-06-12 06:24:37.164580
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    import pytest
    from datetime import date
    from testfixtures import ShouldRaise
    from finance.currencies import USD
    from finance.money import Money, SomeMoney, NoMoney
    from finance.monetary import Numeric
  
    # Test for method as_boolean of class Money
    def test_Money_as_boolean():
        money = Money.of(USD, Numeric("0"), date(2016, 1, 1))
        assert money.as_boolean() == False
        money = Money.of(USD, Numeric("1"), date(2016, 1, 1))
        assert money.as_boolean() == True

# Generated at 2022-06-12 06:24:39.175064
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    assert SomePrice(usd, 1, today) + SomePrice(usd, 1, today) == SomePrice(usd, 2, today)


# Generated at 2022-06-12 06:24:44.849980
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    from datetime import date
    from cr8.currency import Currency
    from cr8.price import Price, SomePrice, NonePrice
    for dov in [date(2021, 4, 1), date(2022, 4, 1)]:
        for price in [Price.of(Currency.USD, 5.0, dov), NonePrice]:
            assert price.with_dov(dov) == price


# Generated at 2022-06-12 06:24:56.880097
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    from nu_star_market.price import Price

    from nu_star_market.market.base import FXRate

    from nu_star_market.market.price_service import PriceServiceImpl
    from nu_star_market.market.fxrate_service import FXRateServiceImpl, FXRateService
    from nu_star_market.market.security import Security, SecurityServiceImpl, SecurityService
    from nu_star_market.market.account import Account, AccountInfo, AccountServiceImpl, AccountService
    from nu_star_market.instrument import Instrument
    from nu_star_market.eod_market_data import EODMarketData
    from nu_star_market.currency import Currency
    import decimal

    ## Set up price service:

# Generated at 2022-06-12 06:25:03.601802
# Unit test for method lte of class Money
def test_Money_lte():
    m1 = Money.of(Currency.USD, Decimal("12.52"), Date(2019, 5, 2))
    m2 = Money.of(Currency.EUR, Decimal("12.52"), Date(2019, 5, 2))
    assert (m1.lte(m1))
    assert (not m1.lte(m2))



# Generated at 2022-06-12 06:27:27.020344
# Unit test for method gte of class Price
def test_Price_gte():
    with_ccy = Price.of(USD, 1.0, date(2020, 1, 1))
    price = Price(USD, 1.0, date(2020, 1, 1))
    assert with_ccy.gte(price)
    assert price.gte(with_ccy)
    assert price.gte(price)
    assert with_ccy.gte(with_ccy)
    assert price >= with_ccy
    assert with_ccy >= price
    assert price >= price
    assert with_ccy >= with_ccy



# Generated at 2022-06-12 06:27:28.836008
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    assert NoPrice.__gt__(NoPrice) == NotImplemented


# Generated at 2022-06-12 06:27:33.667196
# Unit test for method lt of class Price
def test_Price_lt():
    price_1: Price = Price.of(USD, 1, TODAY)
    price_2: Price = Price.of(USD, 2, TODAY)
    assert price_1 < price_2


# Generated at 2022-06-12 06:27:36.009259
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(Price(USD, Decimal("1"), Date(2023, 10, 20))) == 1

# Generated at 2022-06-12 06:27:42.177507
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    MO1 = SomeMoney(GBP, Decimal("123.45"), Date(2018,10,6))
    MO2 = SomeMoney(GBP, Decimal("67.89"), Date(2018,10,7))
    MO1.__add__(MO2) == SomeMoney(GBP, Decimal("123.45"), Date(2018,10,6))


# Generated at 2022-06-12 06:27:50.633670
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    from datetime import date
    from hedgehog.utils.money import Price
    from pytest import raises

    # Given a price object
    price = Price.of(Currency.USD, 1.0, date(2020, 8, 1))

    # Expect it is less than another price object with undefined currency
    assert price.__lt__(Price.of(None, 1.0, date(2020, 8, 1))) is False
    with raises(IncompatibleCurrencyError):
        assert price.__lt__(Price.of(Currency.USD, 1.0, date(2020, 8, 1))) is False

    # Expect it is less than another price object with undefined quantity
    assert price.__lt__(Price.of(Currency.USD, None, date(2020, 8, 1))) is False

# Generated at 2022-06-12 06:27:57.606117
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
    ...
    assert_that(SomePrice('EUR', 4, Date(1, 1, 1)).scalar_subtract(-4), is_(SomePrice('EUR', 8, Date(1,1,1))))
    assert_that(NoPrice.scalar_subtract(4), is_(NoPrice))

test_Price_scalar_subtract()



# Generated at 2022-06-12 06:28:03.101341
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from .currencies import USD

    assert Money.of(USD, 123.456, Date.today()) + 123.456 == Money.of(USD, 246.912, Date.today())
    assert Money.of(USD, 123.456, Date.today()) + NoneMoney == NoneMoney
    assert Money.of(USD, 123.456, Date.today()) + NoMoney == NoMoney



# Generated at 2022-06-12 06:28:15.456743
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    assert True is (SomeMoney(Currency.USDC, Decimal("10"), Date(1981, 12, 4)) > SomeMoney(Currency.USDC, Decimal("9"), Date(1981, 12, 4)))
    assert False is (SomeMoney(Currency.USDC, Decimal("9"), Date(1981, 12, 4)) > SomeMoney(Currency.USDC, Decimal("10"), Date(1981, 12, 4)))
    assert True is (SomeMoney(Currency.USDC, Decimal("10"), Date(1981, 12, 4)) > SomeMoney(Currency.USDC, Decimal("9"), Date(1981, 12, 4)))

# Generated at 2022-06-12 06:28:25.509905
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    # Undefined is never greater than
    assert NoPrice > NoPrice
    assert not (NoPrice > SomePrice('USD', Decimal(10), date(2017, 2, 5)))
    assert SomePrice('USD', Decimal(10), date(2017, 2, 5)) > NoPrice
    # Different currencies cannot be compared
    with pytest.raises(IncompatibleCurrencyError):
        SomePrice('USD', Decimal(10), date(2017, 2, 5)) > SomePrice('EUR', Decimal(10), date(2017, 2, 5))
    # Comparison if currencies match
    assert SomePrice('USD', Decimal(10), date(2017, 2, 5)) > SomePrice('USD', Decimal(10), date(2017, 2, 5))
    assert SomePrice('USD', Decimal(10), date(2017, 2, 5)) > Some

# Generated at 2022-06-12 06:29:41.191975
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    print()
    print(f'{Money.__gt__.__qualname__}')

    from .currencies import USD, GBP, JPY
    from .exchange import FXRateServiceType
    from .prices import Price

    ## Create a foreign exchange rate service:
    fx_rate_service = FXRateService(FXRateServiceType.IN_MEMORY)

    ## Create two money objects:
    m1 = Money.of(USD, Decimal("0.00"), Date.now())
    m2 = Money.of(GBP, Decimal("0.00"), Date.now())

    ## Check:
    assert m1.__gt__(m1) is False
    assert m2.__gt__(m2) is False
    assert m1.__gt__(m2) is False
    assert m2.__

# Generated at 2022-06-12 06:29:47.744481
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    import pytest
    from hydpy import UnitTest, pub
    from hydpy.currency import JPY, EUR
    from hydpy.cythons.autogen import cymoney
    from hydpy.cythons.autogen.cymoney import SomeMoney
    ut = UnitTest(pub)
    # TODO: consider to attach the following two lines to the __init__
    # method of class SomeMoney?
    ut.cymoney = cymoney
    ut.SomeMoney = SomeMoney
    ut.pub.moneyargs = (JPY, 10, None)
    ut.pub.somemoney = SomeMoney(*ut.pub.moneyargs)

# Generated at 2022-06-12 06:29:49.450542
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    assert (NoPrice.NA >= NoPrice.NA) == True



# Generated at 2022-06-12 06:29:52.285249
# Unit test for method as_float of class Money
def test_Money_as_float():
    m = Money.of(Currency("TST"), 5, Date("2001-01-01"))
    assert m.as_float() == 5.0

# Generated at 2022-06-12 06:30:01.172228
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    from .currencies import Currency
    from .exchange import FXRateLookupError, FXRateService
    from .money import Money, SomeMoney
    from .prices import Price, SomePrice
    from .time_series import TimeSeries
    from .utils import as_string
    from .zeitgeist import Date, DateRange
    assert SomeMoney(Currency.USD, Decimal("10"), Date(2017, 1, 1))\
        .is_equal(SomeMoney(Currency.USD, Decimal("10"), Date(2017, 1, 1)))
    assert not SomeMoney(Currency.USD, Decimal("10"), Date(2017, 1, 1))\
        .is_equal(SomeMoney(Currency.USD, Decimal("10.1"), Date(2017, 1, 1)))

# Generated at 2022-06-12 06:30:03.716943
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    # Given a money object
    money = Money()
    # When calling __bool__ method with that object
    value = bool(money)
    # Then the result should be a boolean
    assert isinstance(value, bool) is True

# Generated at 2022-06-12 06:30:13.786061
# Unit test for method convert of class Price
def test_Price_convert():

    # Arrange
    test_setup = SetupTest()
    currency_builder = test_setup.currency_builder
    price_builder = test_setup.price_builder
    fx_rate_builder = test_setup.fx_rate_builder
    before = date(2020, 2, 20)
    after = date(2020, 2, 28)

    fx_rate_builder.with_rate(decimal('0.70')) \
        .with_ccy_pair(currency_builder.with_ccy('EUR').build(), currency_builder.with_ccy('USD').build()) \
        .build(before)


# Generated at 2022-06-12 06:30:16.075132
# Unit test for method convert of class Price
def test_Price_convert():
    # TODO: write unit test
    pass


# Generated at 2022-06-12 06:30:24.436991
# Unit test for method lt of class Price
def test_Price_lt():
    assert Price.NA.lt(Price.NA) == False
    assert Price.of(USD, Decimal('10.00'), Date.today()).lt(Price.NA) == False
    assert Price.NA.lt(Price.of(USD, Decimal('10.00'), Date.today())) == True

    assert Price.of(USD, Decimal('10.00'), Date.today()).lt(Price.of(USD, Decimal('10.00'), Date.today())) == False
    assert Price.of(USD, Decimal('10.00'), Date.today()).lt(Price.of(USD, Decimal('9.9'), Date.today())) == False
    assert Price.of(USD, Decimal('10.00'), Date.today()).lt(Price.of(USD, Decimal('10.1'), Date.today()))

# Generated at 2022-06-12 06:30:25.348457
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass