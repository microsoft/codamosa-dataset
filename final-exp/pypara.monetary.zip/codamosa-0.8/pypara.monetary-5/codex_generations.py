

# Generated at 2022-06-12 06:24:12.497800
# Unit test for method __add__ of class Money
def test_Money___add__():
    # This one is for code coverage.
    assert NoMoney.__add__(1) is NoMoney



# Generated at 2022-06-12 06:24:14.587707
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert Money.of(Currency.of("EUR"), 1, Date.today()).with_qty(2) == Money.of(Currency.of("EUR"), 2, Date.today())


# Generated at 2022-06-12 06:24:27.045303
# Unit test for method negative of class Money
def test_Money_negative():
    assert Money.of(Currency.USD, Decimal('-10.0'), Date('2019-08-26')).negative() == Money.of(Currency.USD, Decimal('10.0'), Date('2019-08-26'))
    assert Money.of(Currency.USD, Decimal('-0.0'), Date('2019-08-26')).negative() == Money.of(Currency.USD, Decimal('0.0'), Date('2019-08-26'))
    assert Money.of(Currency.USD, Decimal('0.0'), Date('2019-08-26')).negative() == Money.of(Currency.USD, Decimal('0.0'), Date('2019-08-26'))
    assert Money.of(Currency.USD, Decimal('10.0'), Date('2019-08-26')).negative()

# Generated at 2022-06-12 06:24:36.180832
# Unit test for method __le__ of class Money
def test_Money___le__():
    '''
    Unit test for method __le__ of class Money
    '''
    import numpy as np
    import pandas as pd

    from decimal import Decimal
    from datetime import date
    from fxstreet import FXStreet, Money, Currency


    # Set the FX provider (default is the official ECB provider)
    FXStreet.configure_fx_provider()

    date_1 = date(2014, 1, 1)
    date_2 = date(2014, 4, 1)
    eur_1 = Money.of(Currency('EUR'), Decimal('100'), date_1)
    eur_2 = Money.of(Currency('EUR'), Decimal('100'), date_2)
    usd_1 = Money.of(Currency('USD'), Decimal('150'), date_1)
    usd

# Generated at 2022-06-12 06:24:42.256733
# Unit test for method convert of class Money
def test_Money_convert():
    m1=Money.of(Currency.of("USD"), Decimal('10'), Date.today())
    assert(m1.convert(Currency.of("EUR"))==Money.of(Currency.of("EUR"), Decimal('11'), Date.today()))
    assert(m1.convert(Currency.of("EUR"), Date.yesterday())==Money.of(Currency.of("EUR"), Decimal('10'), Date.today()))


# Generated at 2022-06-12 06:24:44.775880
# Unit test for method __int__ of class Price
def test_Price___int__():
    assert int(Price.of(Currency.of("USD"), 1, today())) == 1
    assert int(Price.of(Currency.of("USD"), 1.5, today())) == 1
    assert int(Price.of(Currency.of("USD"), 1.1, today())) == 1
    assert int(Price.of(Currency.of("USD"), 1.9, today())) == 1

# Generated at 2022-06-12 06:24:49.470950
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import Currency
    from .money.money import MonetaryOperationException, Money, SomeMoney
    # Test if Currency is imported
    try:
        Currency
        Currency("TRY")
    except NameError:
        print("Need import Currency")
    # Test if MonetaryOperationException is imported
    try:
        MonetaryOperationException
    except NameError:
        print("Need import MonetaryOperationException")
    # Test if Money is imported
    try:
        Money
    except NameError:
        print("Need import Money")
    # Test if SomeMoney is imported
    try:
        SomeMoney
    except NameError:
        print("Need import SomeMoney")
    # Test for subtract operation which takes two money values and returns subtracted value as money
    Money1 = SomeMoney(Currency("USD"), 10, None)

# Generated at 2022-06-12 06:24:56.247606
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    from .currencies import Currency
    from .dates import Date
    from .money import Money
    a: Money = Money.of(Currency("USD"), 1, Date(2020, 5, 30))
    b: Money = Money.of(Currency("USD"), 2, Date(2020, 5, 31))
    assert a.subtract(b) == Money.of(Currency("USD"), -1, Date(2020, 5, 31))



# Generated at 2022-06-12 06:25:05.269185
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    assert Price.NA.__bool__() == False
    assert Price.of(USD, 0.0, Date.today()).__bool__() == False
    assert Price.of(USD, 0.0, Date.today()).__bool__() == False
    assert Price.of(USD, 0.5, Date.today()).__bool__() == True
    assert Price.of(USD, 1.0, Date.today()).__bool__() == True
    assert Price.of(USD, 1.5, Date.today()).__bool__() == True

# Generated at 2022-06-12 06:25:11.513096
# Unit test for method add of class Price
def test_Price_add():
    from datetime import date
    from operator import ne, eq, le, lt, ge, gt
    from fdintra.data import usd, eur, gbp, jpy, mxn, jpy, nzd
    price1 = Price.of(usd, Decimal('100'), date(2010, 1, 1))
    price2 = Price.of(eur, Decimal('100'), date(2010, 1, 1))
    assert price1.add(price1).qty == Decimal('200')
    assert price2.add(price2).qty == Decimal('200')
    assert price1.add(price1).dov == date(2010, 1, 1)
    assert price2.add(price2).dov == date(2010, 1, 1)
    assert price1.add(price1).cc

# Generated at 2022-06-12 06:25:53.012909
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    assert SomeMoney(EUR, Decimal(1), Today).convert(USD, Today).qty == Decimal(1.17)
    assert SomeMoney(EUR, Decimal(1), Today).convert(USD, Today).ccy == USD
    assert SomeMoney(EUR, Decimal(1), Today).convert(USD, Today).dov == Today



# Generated at 2022-06-12 06:25:55.102363
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    class Price:
        def __floordiv__(self, other):
            return self, other
    p = Price()
    result = p // 8
    assert (p, 8) == result


# Generated at 2022-06-12 06:25:59.546537
# Unit test for method as_float of class Money
def test_Money_as_float():
    """
    Unit test for Money.as_float.
    """
    assert SomeMoney(Currency.ZERO, 0, Date.today()).as_float() == 0
    assert NoMoney.as_float() == 0


# Generated at 2022-06-12 06:26:07.033169
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    import random
    from currencies import Currency
    from datetime import date
    from money import Money
    from money import Price
    from money import SomeMoney

    assert SomeMoney(Currency("EUR"), 0, date(2015, 1, 1)).__sub__(SomeMoney(Currency("EUR"), 0, date(2015, 1, 1))) == SomeMoney(Currency("EUR"), 0, date(2015, 1, 1))
    assert SomeMoney(Currency("EUR"), 0, date(2015, 1, 1)).__sub__(SomeMoney(Currency("USD"), 0, date(2015, 1, 1))) == NoMoney
    assert SomeMoney(Currency("EUR"), random.random(), date(2015, 1, 1)).__sub__(SomeMoney(Currency("EUR"), 0, date(2015, 1, 1))) == NoMoney
   

# Generated at 2022-06-12 06:26:19.826485
# Unit test for method __add__ of class Price
def test_Price___add__():
    # Set up some prices
    USD = Currency.of("USD")
    EUR = Currency.of("EUR")
    AUD = Currency.of("AUD")
    GBP = Currency.of("GBP")
    CNY = Currency.of("CNY")
    CHF = Currency.of("CHF")

    price1_USD = Price.of(USD, 100, Date.of(2018, 3, 31))
    price2_USD = Price.of(USD, 50, Date.of(2018, 3, 31))
    price3_USD = Price.of(USD, 100, Date.of(2018, 3, 30))

    assert price1_USD.add(price2_USD) == Price.of(USD, 150, Date.of(2018, 3, 31))
    assert price1_USD.add(price3_USD) == Price

# Generated at 2022-06-12 06:26:28.974749
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    assert SomeMoney(Currency('USD'), Decimal('1'), Date(2012, 2, 1)) >= SomeMoney(Currency('USD'), Decimal('1'), Date(2012, 2, 1))
    assert not (SomeMoney(Currency('USD'), Decimal('1'), Date(2012, 2, 1)) >= SomeMoney(Currency('USD'), Decimal('2'), Date(2012, 2, 1)))
    assert SomeMoney(Currency('USD'), Decimal('2'), Date(2012, 2, 1)) >= SomeMoney(Currency('USD'), Decimal('1'), Date(2012, 2, 1))
    assert not (SomeMoney(Currency('USD'), Decimal('1'), Date(2012, 2, 1)) >= NoMoney)



# Generated at 2022-06-12 06:26:33.006351
# Unit test for method gt of class Money
def test_Money_gt():
    import numpy as np
    s = Money.of(Currency.USD, np.random.random(), np.random.random())
    s.gt(Money.of(Currency.USD, np.random.random(), np.random.random()))
    pass

# Generated at 2022-06-12 06:26:40.562225
# Unit test for method times of class Price
def test_Price_times():
    ccy = USD
    qty = Decimal('100')
    dov = Date(2021, 1, 1)
    p1 = Price.of(ccy, qty, dov)
    p1.times(qty)
    assert p1.money.qty == Decimal('10000')
    assert p1.money.ccy == USD
    assert p1.money.dov == Date(2021, 1, 1)


# Generated at 2022-06-12 06:26:44.863615
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    """
    Unit test for method __ge__ of class Price
    """
    SomePrice = Price.of(GBP, Decimal('1.0'), Date.today())
    assert SomePrice >= SomePrice


## Define mutable price type.

# Generated at 2022-06-12 06:26:55.244573
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert Price.of(USD, Decimal("1.12"), Date(2017, 1, 1)) - Price.of(USD, Decimal("1.12"), Date(2017, 1, 1)) == Price.of(USD, Decimal("0"), Date(2017, 1, 1))
    assert Price.of(USD, Decimal("1.0"), Date(2017, 1, 1)) - Price.of(USD, Decimal("1.12"), Date(2017, 1, 1)) == Price.of(USD, -Decimal("0.12"), Date(2017, 1, 1))

# Generated at 2022-06-12 06:28:34.128030
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    assert (SomePrice(USD, Decimal("98.7"), Date.today()) > SomePrice(USD, Decimal("97.7"), Date.today())) is True
    assert (SomePrice(USD, Decimal("98.7"), Date.today()) > SomePrice(USD, Decimal("98.7"), Date.today())) is False
    assert (SomePrice(USD, Decimal("98.7"), Date.today()) > SomePrice(EUR, Decimal("98.7"), Date.today())) is False
    assert (SomePrice(USD, Decimal("98.7"), Date.today()) > SomePrice(USD, Decimal("99.7"), Date.today())) is False
    assert (SomePrice(USD, Decimal("98.7"), Date.today()) > None) is True


# Generated at 2022-06-12 06:28:36.752652
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    from jedi.api.classes import Module
    from jedi.api.types import Instance


# Generated at 2022-06-12 06:28:47.448167
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    m1 = Money.of(Currency.KRW, 1000, Date.today())
    m2 = Money.of(Currency.EUR, 1, Date.today())

    assert m1 != m2
    assert m1 != 1000
    assert m1 != None
    assert 1000 != m1
    assert m2.convert(Currency.USD, Date.today()) != m2.convert(Currency.USD, Date.today()).negative()

    assert m1 > 1000
    assert m1 < None
    assert 1000 < m1
    assert m2.convert(Currency.USD, Date.today()) > m2.convert(Currency.USD, Date.today()).negative()

    assert m1 >= 1000
    assert m1 <= None
    assert 1000 <= m1

# Generated at 2022-06-12 06:28:57.950335
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    """Unit test for method round of class SomeMoney"""
    currency = Currency("GBP")
    quantizer = currency.quantizer
    money = SomeMoney("GBP", Decimal("12345.6789"), "2020-04-01")
    assert money.round(ndigits=0) == SomeMoney("GBP", Decimal("12345").quantize(quantizer), "2020-04-01")
    assert money.round(ndigits=1) == SomeMoney("GBP", Decimal("12345").quantize(quantizer), "2020-04-01")
    assert money.round(ndigits=2) == SomeMoney("GBP", Decimal("12345").quantize(quantizer), "2020-04-01")

# Generated at 2022-06-12 06:29:02.040836
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    price = Price.of(Currency('USD'),Decimal(10),Date(2020, 6, 3))
    assert price.with_dov(Date(2020, 7, 3)) == Price.of(Currency('USD'),Decimal(10),Date(2020, 7, 3))



# Generated at 2022-06-12 06:29:14.367721
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    check_Money___floordiv__(
        money=SomeMoney(ccy=Currency("USD"), qty=Decimal("0"), dov=Date(2015, 1, 1)),
        other=Decimal("2"),
        expected=SomeMoney(ccy=Currency("USD"), qty=Decimal("0"), dov=Date(2015, 1, 1)),
    )

    check_Money___floordiv__(
        money=SomeMoney(ccy=Currency("USD"), qty=Decimal("1"), dov=Date(2015, 1, 1)),
        other=Decimal("0"),
        expected=NoMoney,
    )


# Generated at 2022-06-12 06:29:16.876637
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    def m(qty: int, ccy: str = "USD") -> Money:
        return Money.of(Currency[ccy], Decimal(qty), Date(2020, 5, 1))

    assert abs(m(-1)) == m(1)



# Generated at 2022-06-12 06:29:28.253427
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Test for Money.gte
    """
    assert NoneMoney >= NoMoney
    assert NoneMoney >= SomeMoney(None, None, None)
    assert NoMoney >= NoMoney
    assert NoMoney >= SomeMoney(None, None, None)
    assert SomeMoney(None, None, None) >= NoMoney
    assert NoneMoney >= 10.0
    assert NoMoney >= 10.0
    assert NoneMoney >= 10
    assert NoMoney >= 10
    assert SomeMoney(None, None, None) >= 10
    assert SomeMoney(None, None, None) >= 10.0
    assert SomeMoney('USD', 10, None) >= 10
    assert SomeMoney('USD', 10, None) >= 10.0
    assert SomeMoney('USD', 10, None) >= 0
    assert SomeMoney('USD', 10, None) >= 0.0

# Generated at 2022-06-12 06:29:34.426585
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    ccy = Currency.USD
    data = [
      (None, False),
      (Decimal(), False),
      (Decimal(1.23), True)
    ]
    for qty, expect in data:
        actual = Price.of(ccy, qty, TODAY)
        assert actual.__bool__() == expect
        assert bool(actual) == expect


# Generated at 2022-06-12 06:29:41.160242
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    from pytest import raises
    from .currencies import USD, EUR

    # Check NoneMoney is False:
    assert bool(NoneMoney) is False

    # Check money object is True if defined and has qty > 0
    assert SomeMoney(USD, 1, Date.today())
    # Check money object is False if defined and has qty == 0
    assert bool(SomeMoney(EUR)) is False

    # Check behaviour of undefined money objects
    assert not SomeMoney(USD).__bool__()
    with raises(MonetaryOperationException):
        assert not True == SomeMoney(USD)

