

# Generated at 2022-06-12 06:22:06.793503
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    ccy = Currency.of("EUR")
    ccy2 = Currency.of("USD")
    qty = Decimal(123)
    dov = Date(2020, 1, 1)
    m = Money.of(ccy, qty, dov)
    assert m.with_ccy(ccy) == m
    assert m.with_ccy(ccy2) == Money.of(ccy2, qty, dov)
    assert m.with_ccy(None) == m
    assert NoMoney.with_ccy(ccy) == NoMoney
    assert NoMoney.with_ccy(None) == NoMoney

# Generated at 2022-06-12 06:22:16.844935
# Unit test for method gte of class Money
def test_Money_gte():
    assert ( Money.of(Currency.USD, qty=10, dov=None) >= Money.of(Currency.USD, qty=20, dov=None) ) == False
    assert ( Money.of(Currency.USD, qty=10, dov=None) >= Money.of(Currency.USD, qty=None, dov=None) ) == False
    assert ( Money.of(Currency.USD, qty=None, dov=None) >= Money.of(Currency.USD, qty=10, dov=None) ) == True
    assert ( Money.of(Currency.USD, qty=None, dov=None) >= Money.of(Currency.USD, qty=None, dov=None) ) == True



# Generated at 2022-06-12 06:22:22.333573
# Unit test for method abs of class Money
def test_Money_abs():
    assert NoMoney.abs() == NoMoney
    assert SomeMoney("USD", 0, Date.today()).abs() == SomeMoney("USD", 0, Date.today())
    assert SomeMoney("USD", -1, Date.today()).abs() == SomeMoney("USD", 1, Date.today())
    assert SomeMoney("USD", 1, Date.today()).abs() == SomeMoney("USD", 1, Date.today())
    assert SomeMoney("USD", -1.1, Date.today()).abs() == SomeMoney("USD", 1.1, Date.today())
    assert SomeMoney("USD", 1.1, Date.today()).abs() == SomeMoney("USD", 1.1, Date.today())



# Generated at 2022-06-12 06:22:32.823475
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    """Unit test for method __le__ of class SomeMoney."""
    m1 = SomeMoney(GBP, Decimal("10"), Date(2020, 10, 1))
    m2 = SomeMoney(GBP, Decimal("20"), Date(2020, 10, 2))
    assert True == m1 <= m2
    m2 = SomeMoney(GBP, Decimal("10"), Date(2020, 10, 2))
    assert True == m1 <= m2
    m2 = SomeMoney(GBP, Decimal("5"), Date(2020, 10, 2))
    assert False == m1 <= m2
    m2 = SomeMoney(EUR, Decimal("5"), Date(2020, 10, 2))
    assert raises(IncompatibleCurrencyError, lambda: m1 <= m2)


# Generated at 2022-06-12 06:22:35.006267
# Unit test for method multiply of class Price
def test_Price_multiply():
    pZero = Price.of(None,0,None) # zero price
    assert(pZero.multiply(1) == pZero)

    pass


# Generated at 2022-06-12 06:22:46.076889
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from .currencies import USD, JPY
    from .helpers import FixedRateFXService
    from .prices import Price

    svc = FixedRateFXService([(USD, USD, Decimal(1)), (USD, JPY, Decimal(111.11))])
    assert Money(USD, Decimal(0), None).as_integer() == 0
    assert Money(USD, Decimal(1), None).as_integer() == 1
    assert Money(USD, Decimal(0.9), None).as_integer() == 0
    assert Money(USD, Decimal(1.3), None).as_integer() == 1
    assert Money(USD, Decimal(1.5), None).as_integer() == 2
    assert Money(USD, Decimal(-1.5), None).as_integer() == -2

# Generated at 2022-06-12 06:22:50.547971
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    from money import Money, some_money, NoMoney
    from pytest import raises
    from decimal import Decimal
    from currency import Currency

    assert some_money('GBP 0.00') - Decimal('0.0') == some_money('GBP 0.00')
    assert some_money('GBP 1.00') - Decimal('1.0') == some_money('GBP 0.00')
    assert some_money('GBP 1.50') - Decimal('1.5') == some_money('GBP 0.00')
    assert some_money('GBP 0.00') - Decimal('0.5') == some_money('GBP -0.5')
    assert some_money('GBP 0.00') - Decimal('1.0') == some_money('GBP -1.0')
    assert some_

# Generated at 2022-06-12 06:22:54.942429
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    assert Price.NA.is_equal(Price.NA)
    assert Price.NA.is_equal(NoPrice)
    assert Price.NA.is_equal(None)
    assert NoPrice.is_equal(Price.NA)

    assert not Price.NA.is_equal(SomePrice(CCY("EUR"), QTY("1000"), DOV("2018-01-01")))
    assert not SomePrice(CCY("EUR"), QTY("1000"), DOV("2018-01-01")).is_equal(Price.NA)

    assert SomePrice(CCY("EUR"), QTY("1000"), DOV("2018-01-01")).is_equal(
        SomePrice(CCY("EUR"), QTY("1000"), DOV("2018-01-01")))


# Generated at 2022-06-12 06:23:01.294880
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    """
    Unit test for method convert of class SomePrice
    """
    from ..currency import Currency
    from ..date import Date
    from ..fx import FXRate

    price_gbp = SomePrice(Currency("GBP"), Decimal("10"), Date.today())
    price_usd = SomePrice(Currency("USD"), Decimal("15"), Date.today())

    usd_gbp = FXRate(Currency("USD"), Currency("GBP"), Decimal("1.5"), Date.today())
    usd_eur = FXRate(Currency("USD"), Currency("EUR"), Decimal("2"), Date.today())

    assert price_gbp.convert(Currency("GBP")) == SomePrice(Currency("GBP"), Decimal("10"), Date.today())

# Generated at 2022-06-12 06:23:05.216121
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    p = SomePrice(USD, Decimal('1.23'), today)
    m = p.times(2)
    assert isinstance(m, Money)
    assert m.ccy == USD
    assert m.qty == Decimal('2.46')
    assert m.dov == today


# Generated at 2022-06-12 06:26:29.230873
# Unit test for method as_integer of class Money
def test_Money_as_integer():
  
  # Defines the mocked class for Money with the minimum number of fields, since most of its methods are abstract.
  class MoneyMock(Money):
    defined = True
    qty = Decimal(100.00)
    undefined = False
    
    def as_integer(self) -> int: 
      return self.qty.to_integral_value(rounding=ROUND_DOWN)

    def as_boolean(self) -> bool:
      return self.defined

    def is_equal(self, other: Any) -> bool:
      return self.qty == other.qty

    def as_float(self) -> float:
      return float(self.qty)

    def abs(self) -> "Money":
      return self

    def negative(self) -> "Money":
      self.qty = -1

# Generated at 2022-06-12 06:26:30.817280
# Unit test for method __int__ of class Price
def test_Price___int__():

    assert NoPrice.__int__() == 0

# Generated at 2022-06-12 06:26:43.578826
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    """
    Test for method round of class SomeMoney
    """
    m = Money.of(Currency.USD, Decimal("100.1"), Date.today())
    assert m.round() == Money.of(Currency.USD, Decimal("100"), Date.today())
    assert m.round(1) == Money.of(Currency.USD, Decimal("100.1"), Date.today())
    assert m.round(2) == Money.of(Currency.USD, Decimal("100.1"), Date.today())
    assert m.round(3) == Money.of(Currency.USD, Decimal("100.1"), Date.today())
    assert m.round(0) == Money.of(Currency.USD, Decimal("100"), Date.today())

# Generated at 2022-06-12 06:26:55.129536
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of("AUD", Decimal("100.00"), date(2012, 12, 12)).times("1.50") == Money.of("AUD", Decimal("150.00"), date(2012, 12, 12))
    assert Price.of("AUD", Decimal("100.00"), date(2012, 12, 12)).times(Decimal("1.50")) == Money.of("AUD", Decimal("150.00"), date(2012, 12, 12))
    assert Price.of("AUD", Decimal("100.00"), date(2012, 12, 12)).times(Decimal("1.5")) == Money.of("AUD", Decimal("150.00"), date(2012, 12, 12))

# Generated at 2022-06-12 06:26:56.234071
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    pass # stub


# Generated at 2022-06-12 06:27:08.005679
# Unit test for method divide of class Price
def test_Price_divide():
    assert Price.of('USD', '5', '2020-01-01').divide('1') == Price.of('USD', '5', '2020-01-01')
    assert Price.of(None, None, None).divide('0') == Price.of(None, None, None)
    assert Price.of('USD', '5', '2020-01-01').divide('0') == Price.of(None, None, None)
    assert Price.of(None, None, None).divide('1') == Price.of(None, None, None)
    assert Price.of(None, None, None).divide(0.0) == Price.of(None, None, None)

# Generated at 2022-06-12 06:27:15.626282
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from .currencies import USD, TRY
    from .exchange import NA_FXRateService
    from .money import Money, SomeMoney
    from .zeitgeist import Date
    # SomeMoney(USD, 20, Date(2018, 1, 1)).with_ccy(TRY, NA_FXRateService)
    assert Money.of(TRY, 20, Date(2018, 1, 1)) == SomeMoney(USD, 20, Date(2018, 1, 1)).with_ccy(TRY, NA_FXRateService)

# Generated at 2022-06-12 06:27:22.871252
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    from ccapi.types import Money

    assert abs(Money.NA) == Money.NA

    assert abs(SomeMoney(Currency.USD, Decimal(0), Date.today())).qty == Decimal(0)
    assert abs(SomeMoney(Currency.USD, Decimal(10), Date.today())).qty == Decimal(10)
    assert abs(SomeMoney(Currency.USD, Decimal(-10), Date.today())).qty == Decimal(10)



# Generated at 2022-06-12 06:27:26.270467
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    # <BLANKLINE>
    assert ( Money.__bool__(Money) is NotImplemented )
    # <BLANKLINE>
    #
    # ###
    # Less than operation

# Generated at 2022-06-12 06:27:39.556224
# Unit test for method divide of class Money
def test_Money_divide():
    assert Money.NA.divide(Money.NA) is Money.NA
    assert Money.NA.divide(Money(None, Decimal("1"), Date.TODAY)) is Money.NA
    assert Money.NA.divide(Decimal(1)) is Money.NA

    assert Money.of(Currency.INR, Decimal(1), Date.TODAY).divide(Decimal(1)) == SomeMoney.of(Currency.INR, Decimal(1), Date.TODAY)

    assert SomeMoney.of(Currency.INR, Decimal(1), Date.TODAY).divide(Decimal(1.0)) == SomeMoney.of(Currency.INR, Decimal(1.0), Date.TODAY)

# Generated at 2022-06-12 06:30:33.970676
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    # test NoneMoney
    assert((NoneMoney.with_ccy(Currency("USD")) == NoneMoney))

    # test SomeMoney
    assert(SomeMoney(Currency("USD"), Decimal(0), Date.today()).with_ccy(Currency("EUR")) == SomeMoney(Currency("EUR"), Decimal(0), Date.today()))

# Generated at 2022-06-12 06:30:40.808220
# Unit test for method __float__ of class Money
def test_Money___float__():
    # Test case data
    none_money = NoMoney
    some_money = SomeMoney(USD, 4.65, Date('2018-06-21'))
    expected_no_money = None
    expected_some_money = 4.65

    # Perform the test
    actual_no_money = float(none_money)
    actual_some_money = float(some_money)

    # Check the result
    assert actual_no_money == expected_no_money
    assert actual_some_money == expected_some_money


# Generated at 2022-06-12 06:30:43.152903
# Unit test for method lt of class Money
def test_Money_lt():
    assert create_Money(ccy, qty, dov) < create_Money(ccy, qty, dov)



# Generated at 2022-06-12 06:30:46.968224
# Unit test for method as_float of class Money
def test_Money_as_float():
    ccy = Currency.of("EUR")
    Money.of(ccy, Decimal("100.0"), Date(2018, 1, 1)).as_float()
