

# Generated at 2022-06-12 06:22:41.760457
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(SomeMoney(Currency("USD"), 1, Date(1))) is True
    assert bool(SomeMoney(Currency("USD"), 0, Date(1))) is False
    assert bool(NoMoney) is False



# Generated at 2022-06-12 06:22:51.997842
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    ccy = Currency.of("USD")
    t = datetime.now()
    dov = Date.from_(t)
    p = SomePrice(ccy = ccy, qty = Decimal(2), dov = dov)
    p1 = p.scalar_add(2)
    assert p1 == SomePrice(ccy = ccy, qty = Decimal(4), dov = dov)
    p2 = p.scalar_add(2.3)
    assert p2 == SomePrice(ccy = ccy, qty = Decimal(4.3), dov = dov)

# Generated at 2022-06-12 06:22:52.817383
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    pass


NoMoney = SomeMoney(None, None, None)



# Generated at 2022-06-12 06:22:57.085454
# Unit test for method abs of class Price
def test_Price_abs():
    assert Price.of(None, None, None).abs() == Price.of(None, None, None)
    assert Price.of(None, 0, None).abs() == Price.of(None, 0, None)
    assert Price.of(None, 1, None).abs() == Price.of(None, 1, None)
    assert Price.of(None, -1, None).abs() == Price.of(None, 1, None)
    assert Price.of(None, -1.5, None).abs() == Price.of(None, 1.5, None)
    assert Price.of(None, -1.0, None).abs() == Price.of(None, 1.0, None)
    assert Price.of(None, -1.5, None).abs() == Price.of(None, 1.5, None)
   

# Generated at 2022-06-12 06:23:07.510638
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    from kiwi.models.fxrates import FXRateService
    from kiwi.models.fxrates.stub import StubFXRateService
    from kiwi.models.prices.base import IncompatibleCurrencyError
    from kiwi.models.prices.stub import NoPrice
    from kiwi.models.prices.stub import SomePrice
    from kiwi.models.prices.stub import convert

    # Arrange:
    ccy1 = Currency.from_iso_code("GBP")
    ccy2 = Currency.from_iso_code("USD")
    qty1 = Decimal("10.0")
    qty2 = Decimal("20.0")
    qty3 = Decimal("30.0")
    qty4 = Decimal("40.0")
    asof = Date

# Generated at 2022-06-12 06:23:11.351800
# Unit test for method __neg__ of class Price
def test_Price___neg__():

    # Arrange
    expected = Price.of(money.USD, -1, dov)

    # Act
    actual = -Price.of(money.USD, 1, dov)

    # Assert
    assert actual == expected



# Generated at 2022-06-12 06:23:14.709872
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    assert SomePrice(EUR, Decimal(1), Date(1, 1, 1)).with_qty(Decimal(2)) == SomeMoney(EUR, Decimal(2), Date(1, 1, 1))


# Generated at 2022-06-12 06:23:21.381797
# Unit test for method lt of class Price
def test_Price_lt():
    import numpy as np
    from hypothesis import given
    from hypothesis.strategies import booleans, integers, floats, randoms, dates, currencies, decimals
    from financepy.finutils.FinGlobalTypes import FinOptionTypes, FinSwapTypes
    from financepy.products.funding.FinIborDeposit import FinIborDeposit
    from financepy.products.funding.FinIborSwap import FinIborSwap
    from financepy.products.funding.FinIborFRA import FinIborFRA
    from financepy.products.funding.FinOIS import FinOIS
    from financepy.products.funding.FinIborFuture import FinIborFuture
    from financepy.products.funding.FinIborSingleBarrierOption import FinIborSingleBarrierOption

# Generated at 2022-06-12 06:23:30.182131
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    ccy = Currency(code="CAD")
    p1 = SomePrice(ccy, Decimal(1.23), Date.now())
    p2 = SomePrice(ccy, Decimal(1.2345), Date.now())
    p3 = SomePrice(ccy, Decimal(1.23), Date.now())
    assert (p1 < p2)
    assert not (p2 < p1)
    assert not (p1 < p3)
    with raises(IncompatibleCurrencyError):
        SomePrice(Currency(code="EUR"), Decimal(1.23), Date.now()) < p1

# Generated at 2022-06-12 06:23:31.869278
# Unit test for method negative of class Money
def test_Money_negative():
    m = Money.of(Currency.USD, 1, Date.today())
    assert m.negative() == Money.of(Currency.USD, -1, Date.today())
    assert -m == Money.of(Currency.USD, -1, Date.today())
    

# Generated at 2022-06-12 06:24:57.690804
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    # Test arguments:
    ccy = Currency.usd
    qty = Decimal('0')
    dov = Date('2018-12-31')
    new_dov = Date('2018-12-31')

    # Execute the tested operation:
    price = SomePrice(ccy, qty, dov)
    actual_output = price.with_dov(new_dov)

    # Verify the results:
    expected_output = SomePrice(ccy, qty, new_dov)
    assert actual_output is not price
    assert actual_output == expected_output



# Generated at 2022-06-12 06:25:08.219985
# Unit test for method gte of class Price
def test_Price_gte():
    # return true if other is undefined
    assert Price.of(None, None, None).gte(Price.of(None, None, None))
    # return true if self is undefined
    assert Price.of(None, None, None).gte(Price('USD', Decimal(1), Date(year=2019, month=1, day=1)))
    # compare
    assert Price.of(Currency.USD, Decimal(1), Date(year=2019, month=1, day=1)).gte(Price('USD', Decimal(1), Date(year=2019, month=1, day=1)))

# Generated at 2022-06-12 06:25:09.001273
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    pass


# Generated at 2022-06-12 06:25:11.387005
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    """
    Tests method __add__ of class SomePrice
    """
    pass


# Generated at 2022-06-12 06:25:19.937196
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney('USD', Decimal('-10.5'), date(2016, 1, 1)).round() == -11
    assert SomeMoney('USD', Decimal('-10.4999'), date(2016, 1, 1)).round() == -10
    assert SomeMoney('USD', Decimal('-10.4951'), date(2016, 1, 1)).round(2) == -10.49
    assert SomeMoney('USD', Decimal('-10.4951'), date(2016, 1, 1)).round(1) == -10.5
    assert SomeMoney('USD', Decimal('-10.49'), date(2016, 1, 1)).round(1) == -10.4
    assert SomeMoney('USD', Decimal('-10.45'), date(2016, 1, 1)).round(1) == -10.4

# Generated at 2022-06-12 06:25:28.749195
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from money import USD
    from money import EUR
    from money import GBP
    from money import JPY
    from money import CAD
    from money.tests.utils import BaseTestCase

    class SomeMoneyConvertTestCase(BaseTestCase):
        def test_SomeMoney_convert_trip(self):
            self.assertEqual(
                Money(10, USD, date(2020, 9, 20)).convert(EUR, date(2020, 9, 20)),
                Money(9.0235, EUR, date(2020, 9, 20)),
            )
            self.assertEqual(
                Money(9.0235, EUR, date(2020, 9, 20)).convert(USD, date(2020, 9, 20)),
                Money(10, USD, date(2020, 9, 20)),
            )

# Generated at 2022-06-12 06:25:34.956868
# Unit test for method lte of class Price
def test_Price_lte():
    global Price
    class Price:
        def __init__(self, qty: Decimal = Decimal("0"), ccy: Currency = USD, dov: Date = Date.today()) -> NoReturn:
            self.qty = qty
            self.ccy = ccy
            self.dov = dov
            self.defined = True
            self.undefined = False
        def __bool__(self) -> bool:
            return True
        def is_equal(self, other: 'Price') -> bool:
            assert isinstance(other, Price)
            return self.dov == other.dov and self.ccy == other.ccy and self.qty == other.qty
        def as_boolean(self) -> bool:
            return True

# Generated at 2022-06-12 06:25:46.011077
# Unit test for method __le__ of class Money
def test_Money___le__():
    # pylint: disable=protected-access
    #
    # Initialize some preconditions
    #
    #    20.00 USD
    # +  30.00 USD
    # -----------
    # == 50.00 USD
    left = Money.of(Currency.USD, Decimal(20), Date.today())
    right = Money.of(Currency.USD, Decimal(30), Date.today())
    #
    # Initialize the expected value
    expected = Money.of(Currency.USD, Decimal(50), Date.today())
    #
    # Call the method under test
    actual = left + right

    # Assert that the expected value is equal to the actual one
    assert expected == actual
    #
    # Assert that the expected and the actual values are instances of Money.

# Generated at 2022-06-12 06:25:55.482770
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    # Preparation
    m1 = SomeMoney(Currency.USD, Decimal('10.00'), None)
    m2 = SomeMoney(Currency.USD, Decimal('20.00'), None)
    m3 = SomeMoney(Currency.USD, Decimal('0.50'), None)
    m4 = SomeMoney(Currency.USD, Decimal('100'), None)
    m5 = SomeMoney(Currency.USD, Decimal('2.00'), None)
    m6 = SomeMoney(Currency.USD, Decimal('-10.00'), None)
    m7 = SomeMoney(Currency.USD, Decimal('-20.00'), None)
    m8 = SomeMoney(Currency.USD, Decimal('-0.50'), None)

# Generated at 2022-06-12 06:25:58.263586
# Unit test for method gte of class Money
def test_Money_gte():
    assert((Money.of("USD", 1, Date.today()) >= Money.of("USD", 2, Date.today())) == False)