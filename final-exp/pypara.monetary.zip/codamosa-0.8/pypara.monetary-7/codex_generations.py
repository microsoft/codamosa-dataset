

# Generated at 2022-06-12 06:24:46.802972
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # arrange
    from datetime import date

    from securify.money import Price
    from securify.money import Currency
    from securify.money import SomePrice
    from securify.money import NoPrice
    from securify.money import NoCurrency

    _value = 123.45
    _dov = date(2020, 7, 27)
    _price_defined = Price.of(Currency.of("USD"), _value, _dov)
    _price_undefined = Price.of(NoCurrency, None, None)

    # act
    _actual_defined = _price_defined.with_dov(_dov)
    _actual_undefined = _price_undefined.with_dov(_dov)

    # assert
    assert isinstance(_actual_defined, SomePrice)
    assert _actual

# Generated at 2022-06-12 06:24:51.198145
# Unit test for method add of class Price

# Generated at 2022-06-12 06:24:56.292002
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    ccy = Currency("USD")
    dov = Date("2019-12-19")

    money = SomeMoney(ccy, 100, dov)

    assert money.with_dov(Date("2020-01-01")) == SomeMoney(ccy, 100, Date("2020-01-01"))

# Generated at 2022-06-12 06:24:57.543403
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    pass



# Generated at 2022-06-12 06:25:08.137509
# Unit test for method divide of class Money
def test_Money_divide():
    from .currencies import USD, GBP
    from .time import Date

    assert USD(10) / 2 == USD(5)
    assert USD(10) / GBP(2) == USD(5)
    assert USD(10) / USD(0) == NoMoney
    assert USD(10) / USD(2) == USD(5)

    assert USD(10).with_dov(Date.today()) / 2 == USD(5).with_dov(Date.today())
    assert USD(10).with_dov(Date.today()) / GBP(2) == USD(5).with_dov(Date.today())
    assert USD(10).with_dov(Date.today()) / USD(0) == NoMoney

# Generated at 2022-06-12 06:25:18.797108
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    ## Given a money object with the following qty
    from decimal import Decimal
    from ..money import Money
    qty = Decimal('1.123456')
    m1 = Money(Currency('EUR'), qty, dov=Date('2020-01-01'))

    ## When I convert it to different currency
    ccy = Currency('USD')
    fxService = FakeFXService()
    m2 = m1.convert(ccy, fxService)

    ## Then quantity should still match the original value
    assert m2.qty == qty

    ## And the value date should be the same as the original money
    assert m1.dov == m2.dov

    ## And the currencies should be different
    assert m1.ccy != m2.ccy


# Generated at 2022-06-12 06:25:23.794103
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    p = Price.of(USD, Decimal("0"), LocalDate.of(2019, 1, 1))
    assert p.with_ccy(EUR) == Price.of(EUR, Decimal("0"), LocalDate.of(2019, 1, 1))



# Generated at 2022-06-12 06:25:30.182890
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    m1 = SomeMoney(GBP, Decimal("100.0000"), Date.today())
    m2 = SomeMoney(GBP, Decimal("0.010000"), Date.today())
    assert m1.__mul__(Decimal("2")) == SomeMoney(GBP, Decimal("200.0000"), Date.today())
    assert m2.__mul__(Decimal("100")) == SomeMoney(GBP, Decimal("1.0000"), Date.today())
    assert m1.__mul__(Decimal("2")) != SomeMoney(GBP, Decimal("2.0000"), Date.today())
    assert m1.__mul__(Decimal("2")) == SomeMoney(GBP, Decimal("200"), Date.today())
    assert m1.__mul__(Decimal("2.000000")) == SomeMoney

# Generated at 2022-06-12 06:25:36.105459
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    """Unit test for method ``__truediv__`` of class ``Price``.
    """
    ccy = Currency(code="GBP")
    price = Price.of(ccy, 5, Date.today())
    price2 = price / 2
    assert price2.ccy == ccy
    assert price2.qty == 2.5
    assert price2.dov == Date.today()



# Generated at 2022-06-12 06:25:42.262087
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    # Arrange
    money1 = Money.of(ccy=None, qty=None, dov=None)
    money2 = Money.of(ccy=None, qty=None, dov=None)

    # Act
    actual = money1 < money2
    expected = True

    # Assert
    assert(actual == expected)



# Generated at 2022-06-12 06:27:05.198193
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    USD = Currency.of('USD')
    GBP = Currency.of('GBP')
    price = SomePrice(USD, Decimal(1), Date.today())
    price2 = SomePrice(USD, Decimal(1), Date.today())
    assert price == price2
    rate = FXRate.of(USD, GBP, Decimal(1.2), Date.today())
    assert rate is not None
    assert rate.from_currency == USD
    assert rate.to_currency == GBP
    assert rate.value == Decimal(1.2)
    assert rate.date == Date.today()
    price3 = price.convert(GBP, Date.today(), False)
    assert price3 == SomePrice(GBP, Decimal(1.2), Date.today())



# Generated at 2022-06-12 06:27:12.664429
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    """Unit test for method __le__ of class SomeMoney."""
    m1: SomeMoney = SomeMoney(Currency.USD, Decimal(10.00), Date.today())
    m2: SomeMoney = SomeMoney(Currency.USD, Decimal(10.00), Date.today())
    m3: SomeMoney = SomeMoney(Currency.JPY, Decimal(10.00), Date.today())

    assert ( m1.__le__(m2) and not m1.__le__(m3) ) == True



# Generated at 2022-06-12 06:27:24.160012
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    """
    Tests :meth:`~Money.__lt__` (less than) operator of :class:`Money`.

    """
    import unittest

    import pandas as pd

    class test_Money___lt__(unittest.TestCase):

        def test_less_than_operator(self):
            """
            Tests :meth:`~Money.__lt__` (less than) operator of :class:`Money`.

            """

# Generated at 2022-06-12 06:27:31.834470
# Unit test for method __sub__ of class Price

# Generated at 2022-06-12 06:27:36.746362
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    mock_instance = Money()
    # __truediv__(self, other: Numeric) -> "Money": ...
    # No exception raised.
    result = mock_instance.__truediv__(Numeric)
    assert type(result) is Money



# Generated at 2022-06-12 06:27:47.808830
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    import datetime
    from finstmt.core.common import Currency
    from finstmt.core.common import Date
    from finstmt.core.common import TimeSpan

    usd = Currency.usd
    gbp = Currency.gbp
    m1 = SomeMoney(usd, Decimal("123456.78"), Date.now().add(TimeSpan(-1, 0, 0)))
    m2 = SomeMoney(gbp, Decimal("123456.78"), Date.now().add(TimeSpan(-1, 0, 0)))
    m3 = m1.round()
    m4 = m1.round(1)
    m5 = m1.round(2)
    m6 = m2.round(2)
    assert m1 == m3
    assert m1 == m4
    assert m1 == m

# Generated at 2022-06-12 06:27:55.115445
# Unit test for method add of class Money
def test_Money_add():
    import pytest
    from dolosse.currencies import USD
    from dolosse.monetary.money import Money
    money = Money.of(USD, 20, Date(2019, 1, 1))
    x = Money.of(USD, 50, Date(2019, 1, 1))
    y = Money.of(USD, 100, Date(2019, 1, 1))
    with pytest.raises(ValueError):
        money.add(x)
    money.add(y)


# Generated at 2022-06-12 06:27:56.925405
# Unit test for method as_float of class Price
def test_Price_as_float():
    """
    price = Price.of(Currency.of("USD"), Decimal("1.00"), Date.of(2018, 11, 1))
    assert price.as_float() == 1.00
    """
    pass

# Generated at 2022-06-12 06:28:05.502888
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    price = Price.of(Currency.of('EUR'), Decimal('2'), Date.now())
    assert price.with_dov(Date.of(2014, 11, 1)).dov == Date.of(2014, 11, 1)
    assert price.with_dov('2014-11-01').dov == Date.of(2014, 11, 1)
    assert price.with_dov(Date.of(2014, 11, 1)).with_dov(Date.of(2014, 11, 2)).dov == Date.of(2014, 11, 2)
    assert price.with_dov(Date.of(2014, 11, 1)).with_dov(Date.of(2014, 11, 2)).with_dov(Date.of(2014, 11, 3)).dov == Date.of(2014, 11, 3)
   

# Generated at 2022-06-12 06:28:17.659426
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    from dateutil.parser import parse
    from xbbg.base import Date
    from xbbg.base import Price
    from xbbg.base import NoPrice

    assert Price.OF(1.2345, 'USD').__bool__()
    assert Price.OF(-1.2345, 'USD').__bool__()
    assert Price.OF(0, 'USD').__bool__()

    assert (not Price.OF(None, 'USD')).__bool__()
    assert (not Price.OF(1.2345, None)).__bool__()
    assert (not Price.OF(1.2345, 'USD', parse('2020-01-01'))).__bool__()

    assert NotImplemented == Price.OF(1.2345, 'USD').__bool__().__eq__(NoPrice)


# Unit test

# Generated at 2022-06-12 06:29:46.068823
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    usd = Currency.of("USD")
    eur = Currency.of("EUR")
    chf = Currency.of("CHF")
    jpy = Currency.of("JPY")

    money = Money(qty=Decimal("10.0"), ccy=usd)
    assert money.scalar_subtract(10) == Money.of(ccy=usd, qty=Decimal("0.0"), dov=money.dov)
    assert money.scalar_subtract(10.0) == Money.of(ccy=usd, qty=Decimal("0.0"), dov=money.dov)

    money = Money(qty=Decimal("10.0"), ccy=eur)

# Generated at 2022-06-12 06:29:47.773150
# Unit test for method __float__ of class Price
def test_Price___float__():
    pass

# Generated at 2022-06-12 06:29:55.714400
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    from .currencies import USD, EUR, GBP, JPY
    from .exchange import FXRateService
    from .market import FXRateLookupError
    from .pricing import Price
    import datetime
    service = FXRateService()
    service.add(EUR, USD, Decimal(1.12), datetime.date(2012, 10, 1))
    service.add(GBP, USD, Decimal(1.22), datetime.date(2012, 11, 1))
    service.add(JPY, USD, Decimal(0.0092), datetime.date(2012, 12, 1))
    assert Money.of(USD, 100, datetime.date(2012,10,1)).is_equal(Money.of(USD, 100, datetime.date(2012,10,1))) == True

# Generated at 2022-06-12 06:29:59.345796
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    price = Price(USD, Decimal("1234.56"), "2019-06-11")
    price2 = Price(USD, Decimal("1233.56"), "2019-06-11")

    result = price - price2
    expected = Price(USD, Decimal("1.00"), "2019-06-11")
    assert result == expected

# Generated at 2022-06-12 06:30:08.955242
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    from finstmt.base.finstmt_base import Price, Money
    from finstmt.base.finstmt_base import NoPrice, SomePrice
    from finstmt.base.finstmt_base import NoMoney
    from finstmt.base.finstmt_base import Currency, Date
    from decimal import Decimal
    from typing import Union, Optional, Any
    from operator import floordiv
    from pytest import raises

    assert NoPrice == NoPrice // Decimal('1e3')
    assert NoPrice // NoPrice == NoPrice
    assert NoPrice // Decimal('1e3') == NoPrice

    with raises(MonetaryOperationException):
        # noinspection PyStatementEffect
        NoPrice // NoMoney


# Generated at 2022-06-12 06:30:16.741103
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .currencies import GBP, USD
    from .exchange import SimpleFXRateService
    from .money import Money, SomeMoney
    from .zeitgeist import Date
    service = SimpleFXRateService()
    service.set_rate('USD', 'GBP', Numeric(0.8))
    assert Money('USD', 10).convert(GBP, Date(2019, 1, 1), service) == SomeMoney(GBP, 8)

    service = SimpleFXRateService()
    service.set_rate('USD', 'GBP', Numeric(0.8))
    assert Money('USD', 10).convert(GBP, Date(2019, 1, 1), service) == SomeMoney(GBP, 8)



# Generated at 2022-06-12 06:30:23.120890
# Unit test for method lte of class Money
def test_Money_lte():
    # Given any two money objects x and y of the same class
    from decimal import Decimal
    from datetime import date
    from finances_automation.money import Money as MoneyCls

    x = MoneyCls(Decimal('1'), date(2018, 1, 1))
    y = MoneyCls(Decimal('2'), date(2018, 1, 1))

    # Then x <= y is True if x is less than or equal to y and False otherwise
    assert(x <= y) == (x < y or x == y)



# Generated at 2022-06-12 06:30:31.706316
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import CAD, USD
    from .exchange import FXRateService
    from .exchange import SomeFXRate
    from .zeitgeist import Date
    service_currency_csv = {
        "CAD": {
            "USD": [
                ("2016-06-06", "1.3452"),
                ("2016-06-07", "1.3465"),
            ],
        },
        "USD": {
            "CAD": [
                ("2016-06-06", "0.74152"),
                ("2016-06-07", "0.74051"),
            ],
        },
    }



# Generated at 2022-06-12 06:30:41.506432
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    from dataclasses import dataclass
    import datetime
    from decimal import Decimal
    @dataclass
    class data:
        price: Price
        other: Price
        expected: bool = False
        error: type = None

# Generated at 2022-06-12 06:30:44.684375
# Unit test for method __float__ of class Money
def test_Money___float__():
    from .currencies import currencies
    m1 = Money.of(currencies['USD'], Decimal('10.5'), Date.today())
    assert float(m1) == 10.5