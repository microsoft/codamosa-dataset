

# Generated at 2022-06-12 06:24:47.858336
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    price = Price.of(Currency.USD, Decimal('1'), Date.today())
    assert price.scalar_add(Decimal('10')) == Price.of(Currency.USD, Decimal('11'), Date.today())



# Generated at 2022-06-12 06:24:51.931385
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    x1 = Money.of(USD,100, date.today())
    x2 = Money.of(USD,10, date.today())
    assert (x1 - x2) == Money.of(USD,90, date.today())


# Generated at 2022-06-12 06:24:56.575732
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    ccy = Currency.EUR
    qty = Decimal("100.00")
    dov = Date.today()
    assert (Money.of(ccy, qty, dov) != Money.of(ccy, qty, None)) is False


# Generated at 2022-06-12 06:25:07.611237
# Unit test for method add of class Money
def test_Money_add():
    """
    Test case for method add
    """
    from .currencies import USD
    from .exchange import InMemoryRateLookupService
    from .money import Money, SomeMoney, NoneMoney
    from datetime import date
    m1 = SomeMoney(USD, 10, date(2020, 1, 1))
    m2 = SomeMoney(USD, 20, date(2020, 1, 2))
    m3 = m1.add(m2)
    assert m3.ccy == USD
    assert m3.qty == 30
    assert m3.dov == date(2020, 1, 2)
    m1 = SomeMoney(USD, 10, date(2020, 1, 1))
    m2 = NoneMoney
    m3 = m1.add(m2)
    assert m3.ccy == USD

# Generated at 2022-06-12 06:25:18.716847
# Unit test for method multiply of class Money
def test_Money_multiply():
    # base cases - error condition
    x = Money.of(ccy=None,qty=None,dov=None)
    x1 = Money.of(ccy=Currency.USD,qty=Decimal(440.0),dov=Date.today())
    y = 2
    y1= Decimal(2)
    try:
        x*y1
    except:
        pass
    try:
        x*y
    except:
        pass
    try:
        x*x1
    except:
        pass
    try:
        x1*x
    except:
        pass
    try:
        x1*x1
    except:
        pass
    try:
        x1.multiply(x1)
    except:
        pass

    # base cases - success transaction

# Generated at 2022-06-12 06:25:28.335498
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    from .currencies import EUR, USD
    from .date import Date
    from .money import Money, SomeMoney

    assert SomeMoney(currency=EUR, quantity=Decimal(1), dov=Date(1, 1, 2020)) < SomeMoney(currency=EUR, quantity=Decimal(2), dov=Date(1, 1, 2020))
    assert SomeMoney(currency=EUR, quantity=Decimal(1), dov=Date(1, 1, 2020)) < SomeMoney(currency=USD, quantity=Decimal(1), dov=Date(1, 1, 2020))
    assert SomeMoney(currency=EUR, quantity=Decimal(1), dov=Date(1, 1, 2020)) < SomeMoney(currency=EUR, quantity=Decimal(1), dov=Date(1, 2, 2020))
    assert Money.NA

# Generated at 2022-06-12 06:25:37.428574
# Unit test for method multiply of class Money
def test_Money_multiply():
    a=Money.of(Currency.USD, Decimal(1), Date.today())
    b=Money.of(Currency.GBP, Decimal(3), Date.today())
    c=Money.of(Currency.GBP, Decimal(10), Date.today())
    d=Money.of(Currency.GBP, Decimal(4), Date.today())
    f=Money.of(Currency.GBP, Decimal(16), Date.today())
    assert b.multiply(4)==c
    assert b.multiply(4)==d.multiply(2)
    assert d.multiply(4)==f

# Generated at 2022-06-12 06:25:45.492143
# Unit test for method lt of class Money
def test_Money_lt():
    assert(NoneMoney < SomeMoney(Currency.USD, Decimal("1"), Date.today()))
    try:
        NoneMoney < NoneMoney
        assert(False)
    except TypeError:
        assert(True)
    assert(SomeMoney(Currency.USD, Decimal("0"), Date.today()) < SomeMoney(Currency.USD, Decimal("1"), Date.today()))
    try:
        SomeMoney(Currency.USD, Decimal("0"), Date.today()) < SomeMoney(Currency.EUR, Decimal("1"), Date.today())
        assert(False)
    except IncompatibleCurrencyError:
        assert(True)



# Generated at 2022-06-12 06:25:55.214249
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    """
    Tests method scalar_add of class Money.
    """
    from .currencies import USD, EUR

    m1 = SomeMoney(USD, 10, Date("2018-01-01"))
    m2 = SomeMoney(EUR, 10, Date("2018-01-01"))
    assert m1.scalar_add(1) == SomeMoney(USD, 11, Date("2018-01-01"))
    assert m2.scalar_add(2) == SomeMoney(EUR, 12, Date("2018-01-01"))
    
    assert m1.scalar_add(1) != SomeMoney(USD, 10, Date("2018-01-01"))
    assert m2.scalar_add(2) != SomeMoney(EUR, 10, Date("2018-01-01"))
    
    assert m1

# Generated at 2022-06-12 06:25:59.287086
# Unit test for method as_boolean of class Money
def test_Money_as_boolean():
    assert Money.NA.as_boolean() == False
    assert Money.EUR(0).as_boolean() == False
    assert Money.EUR(1).as_boolean() == True

# Generated at 2022-06-12 06:27:10.727604
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    """
    Tests method is_equal of class Price
    """
    print("Testing method is_equal of class Price")
    m = Money.of("USD", 100)
    p = Price.of("USD", 100, Date(2019, 1, 1))
    assert p.is_equal(p)
    assert not p.is_equal(m)
    assert not p.is_equal(Price.of("USD", 100, Date(2018, 1, 1)))
    assert not p.is_equal(Price.of("USD", 200, Date(2019, 1, 1)))
    assert not p.is_equal(Price.of("EUR", 100, Date(2019, 1, 1)))
    assert not p.is_equal(None)
    assert not p.is_equal("")
    assert not m.is_equal("")

# Generated at 2022-06-12 06:27:15.814473
# Unit test for method gt of class Money
def test_Money_gt():
  assert Money.NA > Money.NA, "not (Money.NA > Money.NA)"
  assert not (Money.NA >= Money.NA), "Money.NA >= Money.NA"
  assert not (Money.NA < Money.NA), "Money.NA < Money.NA"
  assert Money.NA <= Money.NA, "not (Money.NA <= Money.NA)"
  #
  assert not (Money.NA > SomeMoney(Currency.of("EUR"), Decimal("1"), Date.today())), "Money.NA > SomeMoney(EUR, 1, today)"
  assert not (Money.NA >= SomeMoney(Currency.of("EUR"), Decimal("1"), Date.today())), "Money.NA >= SomeMoney(EUR, 1, today)"

# Generated at 2022-06-12 06:27:19.302024
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(SomeMoney(ccy=Currency("EUR"), qty=Decimal("0.00"), dov=Date("2020-01-04"))) == 0
    assert int(SomeMoney(ccy=Currency("EUR"), qty=Decimal("1.00"), dov=Date("2020-01-04"))) == 1

# Generated at 2022-06-12 06:27:25.271818
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    def with_ccy(self, ccy: Currency) -> "Price":
        if self.undefined:
            return NoPrice
        return SomePrice(ccy, self.qty, self.dov)



# Generated at 2022-06-12 06:27:33.666143
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert Price.NA.with_dov(NaT) == NoPrice
    assert SomePrice(USD, Decimal("0.76"), Date(2018, 9, 17)).with_dov(NaT) == NoPrice
    assert SomePrice(USD, Decimal("0.76"), Date(2018, 9, 17)).with_dov(Date(2018, 9, 1)) == \
           SomePrice(USD, Decimal("0.76"), Date(2018, 9, 1))



# Generated at 2022-06-12 06:27:45.700878
# Unit test for method multiply of class Money
def test_Money_multiply():
    money_ccy = gbp(12)
    price_ccy = gbp / eur(100)
    price_ccy_2 = gbp / eur(120)
    price_ccy_3 = gbp / usd(120)
    price_ccy_4 = eur / usd(120)
    price_ccy_5 = chf / usd(120)

    assert money_ccy.multiply(price_ccy) == eur(12 * 100)
    assert money_ccy.multiply(price_ccy_2) == eur(12 * 120)
    assert money_ccy.multiply(price_ccy_3) == usd(12 * 120)

# Generated at 2022-06-12 06:27:55.873273
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert (SomeMoney(ccy=USD, qty=Decimal("10.00"), dov=Date.today()) > SomeMoney(ccy=USD, qty=Decimal("11.00"), dov=Date.today())) == False
    assert (SomeMoney(ccy=USD, qty=Decimal("10.00"), dov=Date.today()) > SomeMoney(ccy=USD, qty=Decimal("10.00"), dov=Date.today())) == False
    assert (SomeMoney(ccy=USD, qty=Decimal("10.00"), dov=Date.today()) > SomeMoney(ccy=USD, qty=Decimal("9.00"), dov=Date.today())) == True


# Generated at 2022-06-12 06:28:00.902494
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert Price.NA.as_boolean() is False
    assert Price(USD, Decimal(100), Date(2018, 1, 1)).as_boolean() is True
    assert Price(USD, Decimal(0), Date(2018, 1, 1)).as_boolean() is False


# Generated at 2022-06-12 06:28:08.489094
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    """
    Unit test for method scalar_subtract of class Money
    """
    Money.NA.scalar_subtract(0.01)
    
    ccy = Currency(code='USD')
    qty = Decimal(1.00)
    dov = Date(year=2019, month=10, day=18)
    money1 = SomeMoney(ccy, ccy.quantize(qty), dov)
    
    money1.scalar_subtract(0.01)
    

# Generated at 2022-06-12 06:28:19.095418
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    v = SomeMoney(Currency.USD, Decimal('10.0'), Date.today())
    assert (v * 2) == SomeMoney(Currency.USD, v.qty * 2, Date.today())
    assert (2 * v) == SomeMoney(Currency.USD, v.qty * 2, Date.today())
    assert (v * Decimal('2.0')) == SomeMoney(Currency.USD, v.qty * 2, Date.today())
    assert (Decimal('2.0') * v) == SomeMoney(Currency.USD, v.qty * 2, Date.today())
    assert (v * None) == NoMoney
    assert (v * NoMoney) == NoMoney
