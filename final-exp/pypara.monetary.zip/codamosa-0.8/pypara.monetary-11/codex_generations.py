

# Generated at 2022-06-12 06:27:05.028094
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    """
    Test: True, if price is non zero. False otherwise
    """
    assert False == NoPrice.as_boolean()
    assert True == SomePrice(Cad(), Decimal(1), today).as_boolean()
    assert False == SomePrice(Cad(), Decimal(0), today).as_boolean()

# Generated at 2022-06-12 06:27:10.021349
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert SomePrice(USD, Decimal(25.35), date(2020, 5, 18)).as_float() == 25.35
    assert NoPrice.as_float() == pytest.approx(0.0)
    with pytest.raises(MonetaryOperationException):
        NoMoney.as_float()
    assert Money(USD, Decimal(25.35), date(2020, 5, 18)).as_price().as_float() == 25.35
    

# Generated at 2022-06-12 06:27:20.797611
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    """
    Test case for method round of class SomeMoney
    """
    m1 = SomeMoney(Currency("USD"), Decimal("12.345"), Date(2018, 9, 1))
    assert m1.round() == SomeMoney(Currency("USD"), Decimal("12"), Date(2018, 9, 1))
    assert m1.round(1) == SomeMoney(Currency("USD"), Decimal("12.3"), Date(2018, 9, 1))
    assert m1.round(2) == SomeMoney(Currency("USD"), Decimal("12.35"), Date(2018, 9, 1))
    assert m1.round(3) == SomeMoney(Currency("USD"), Decimal("12.345"), Date(2018, 9, 1))

# Generated at 2022-06-12 06:27:31.022628
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    # Undefined singleton
    actual = Price.NA
    assert actual.is_equal(Price.NA)

    # SomePrice (1, EUR, Decimal('1'), datetime.date(2020, 12, 31))
    ccy1: Currency = Currency.EUR
    qty1: Decimal = Decimal('1')
    dov1: datetime.date = datetime.date(2020, 12, 31)
    price1: Price = Price.of(ccy1, qty1, dov1)
    expected1: bool = True
    actual1: bool = price1.is_equal(price1)
    assert expected1 == actual1

    # SomePrice (2, GBP, Decimal('1'), datetime.date(2020, 12, 31))
    ccy2: Currency = Currency.GBP
    qty

# Generated at 2022-06-12 06:27:44.332537
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    """
    Test __ge__ method of SomeMoney class
    """

    # Test unsuccessful case where a is less than b
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager
    from depot.manager.depot import DepotManager

# Generated at 2022-06-12 06:27:53.889936
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    na = Money.NA
    eur = Currency('EUR')
    usd = Currency('USD')
    gbp = Currency('GBP')

    # USD
    assert Money.of(usd, 5, '2019-12-01').floor_divide(2) == Money.of(usd, 2, '2019-12-01')
    assert Money.of(usd, -5, '2019-12-01').floor_divide(2) == Money.of(usd, -3, '2019-12-01')
    assert Money.of(usd, 5, '2019-12-01').floor_divide(-2) == Money.of(usd, -3, '2019-12-01')

# Generated at 2022-06-12 06:28:04.165833
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert Price.of('JPY', 100, Date.today()).as_boolean()
    assert Price.of('JPY', 0, Date.today()).as_boolean() == False
    assert Price.of(None, 100, Date.today()).as_boolean() == False
    assert Price.of('JPY', 100, None).as_boolean() == False
    assert Price.of(None, 100, None).as_boolean() == False
    assert Price.of(None, 0, None).as_boolean() == False
    assert Price.of(None, 0, Date.today()).as_boolean() == False
    assert Price.of('JPY', 0, None).as_boolean() == False
    
test_Price_as_boolean()

# Generated at 2022-06-12 06:28:06.298225
# Unit test for method __int__ of class Money
def test_Money___int__():
    assert int(SomeMoney(USD, Decimal(10), Date.today())) == 10

# Generated at 2022-06-12 06:28:10.153858
# Unit test for method lt of class Price
def test_Price_lt():
    assert Price.of(USDCurr, Decimal("10.10"), LocalDateTime.now(UTC).date()) < Price.of(USDCurr, Decimal("15.10"), LocalDateTime.now(UTC).date())


# Generated at 2022-06-12 06:28:13.817820
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    assert (  # conditional
        NoPrice.__lt__(Money(Currency("XXX"), 1, Date.today()))
        == False
    )


# Generated at 2022-06-12 06:28:37.047919
# Unit test for method __le__ of class Price
def test_Price___le__():
    # Test with a defined price
    actual = SomePrice("USD", "10.00", "2019-01-01") <= SomePrice("USD", "10.00", "2019-01-01")
    assert actual == False

    # Test with an undefined price
    actual = NoPrice <= SomePrice("USD", "10.00", "2019-01-01")
    assert actual == False

    # Test with two undefined prices
    actual = NoPrice <= NoPrice
    assert actual == False


# Generated at 2022-06-12 06:28:47.776523
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    from finquant.data.fxrates import InMemoryFXRateRepo
    from finquant.services.fxrates import FXRateService
    from finquant.utils.timez import get_utc_now
    ## Mock fx rate repo:
    repo = InMemoryFXRateRepo()
    ## Add a rate for USD/GBP for today:
    repo.put(FXRate(Currency.USD, Currency.GBP, 1.25, get_utc_now().date()))
    ## Set FX rate service to mock repo:
    FXRateService.default = FXRateService(repo)

    ## Money to convert from:
    from_mny = Money.of(Currency.USD, 10, get_utc_now().date())

    ## Convert to GBP:

# Generated at 2022-06-12 06:28:58.307625
# Unit test for method scalar_subtract of class Price
def test_Price_scalar_subtract():
  assert Price.of("USD", Decimal("1.50"), Date("2020/01/01")).scalar_subtract(Decimal("1.50")) == Price.of("USD", Decimal("0.00"), Date("2020/01/01"))
  assert Price.of("USD", Decimal("0.00"), Date("2020/01/01")).scalar_subtract(Decimal("0.00")) == Price.of("USD", Decimal("0.00"), Date("2020/01/01"))
  assert Price.of("USD", Decimal("150.00"), Date("2020/01/01")).scalar_subtract(Decimal("150.00")) == Price.of("USD", Decimal("0.00"), Date("2020/01/01"))

# Generated at 2022-06-12 06:29:05.643985
# Unit test for method gte of class Money
def test_Money_gte():
    from .currencies import EUR
    from .money import Money, NoMoney, SomeMoney

    class SampleMoney(Money):
        ccy = EUR
        qty = 1
        dov = "2018-09-01"

        def is_equal(self, other: Any) -> bool:
            return NotImplemented

        def as_boolean(self) -> bool:
            return NotImplemented

        def as_float(self) -> float:
            return NotImplemented

        def as_integer(self) -> int:
            return NotImplemented

        def abs(self) -> Money:
            return NotImplemented

        def negative(self) -> Money:
            return NotImplemented

        def positive(self) -> Money:
            return NotImplemented


# Generated at 2022-06-12 06:29:08.659252
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    obj = Price()
    with pytest.raises(NotImplementedError):
        method = obj.__eq__
        method(obj)

# Generated at 2022-06-12 06:29:19.300239
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    o1 = SomeMoney(CURRENCIES['GBP'], Decimal('10.000000'), Date('20200101'))
    o2 = SomeMoney(CURRENCIES['GBP'], Decimal('10.000000'), Date('20200101'))
    o3 = SomeMoney(CURRENCIES['GBP'], Decimal('10.000001'), Date('20200101'))
    o4 = SomeMoney(CURRENCIES['GBP'], Decimal('10.000000'), Date('20200102'))

    assert not o1.__ge__(o2)
    assert o2.__ge__(o1)
    assert not o1.__ge__(o3)
    assert o3.__ge__(o1)
    assert not o1.__ge__(o4)
    assert o4.__

# Generated at 2022-06-12 06:29:25.742432
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Test with undefined price
    assert Price.NA.with_dov(Date(2019, 12, 31)) is Price.NA

    # Test with defined price
    assert Price.of("USD", 1.0, Date(2014, 1, 1)).with_dov(Date(2019, 12, 31)) \
        == Price.of("USD", 1.0, Date(2019, 12, 31))

# Generated at 2022-06-12 06:29:38.487897
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    instance = SomePrice(
        ccy=USD,
        qty=Decimal("12345.6789"),
        dov=Date(2018, 2, 14),
    )
    assert instance.with_ccy(USD) is instance
    assert instance.with_ccy(EUR) is not instance
    assert instance.with_ccy(EUR) == SomePrice(
        ccy=EUR,
        qty=Decimal("12345.6789"),
        dov=instance.dov,
    )
    assert instance.with_ccy(EUR).ccy == EUR
    assert instance.with_ccy(EUR).qty == instance.qty
    assert instance.with_ccy(EUR).dov == instance.dov

# Generated at 2022-06-12 06:29:46.596692
# Unit test for method gt of class Price
def test_Price_gt():
    price = Price.of(GBP, 10.0, date(2018, 11, 19))

    assert price.gt(Price.of(GBP, 9.0, date(2018, 11, 30))), "gt #1 of Price"
    assert price.gt(Price.of(GBP, 10.0, date(2018, 11, 30))), "gt #2 of Price"
    assert price.gt(Price.of(GBP, 11.0, date(2018, 11, 30))), "gt #3 of Price"

    assert (
        not price.gt(Price.of(GBP, 10.0, date(2018, 11, 19)))
    ), "gt #4 of Price, should be false"

# Generated at 2022-06-12 06:29:55.908727
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    from needle.base import Money, NoMoney, SomeMoney
    from needle.currencies import Currency, USD

    assert abs(Money.of(USD, Decimal("1.00"), Date(2020, 4, 1))) == SomeMoney(USD, Decimal("1.00"), Date(2020, 4, 1))
    assert abs(Money.of(USD, Decimal("-1.00"), Date(2020, 4, 1))) == SomeMoney(USD, Decimal("1.00"), Date(2020, 4, 1))
    assert abs(NoMoney) == NoMoney
    assert abs(Money.of(USD, None, Date(2020, 4, 1))) == NoMoney
    assert abs(Money.of(USD, Decimal("-1.00"), None)) == NoMoney