

# Generated at 2022-06-12 06:26:35.747742
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    fxrate = FXRate(from_=ccy, to=ccy, asof=dov, bid=bid, ask=ask, spot=spot)
    assert SomePrice(ccy, qty, dov) - SomePrice(ccy, qty, dov) == SomePrice(ccy, 0, dov)
    assert SomePrice(ccy, qty, dov) - SomeMoney(ccy, qty, dov) == SomePrice(ccy, 0, dov)
    assert SomeMoney(ccy, qty, dov) - SomePrice(ccy, qty, dov) == SomePrice(ccy, 0, dov)
    assert SomePrice(ccy, qty, dov) - fxrate == SomePrice(ccy, 0, dov)

# Generated at 2022-06-12 06:26:39.969784
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    assert Price.of(USD, 2, today) // 3 == Price.of(USD, 0, today)
    assert Price.of(USD, 2, today) // Decimal('3.0') == Price.of(USD, 0, today)

# Generated at 2022-06-12 06:26:50.854957
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    """
    Unit test for method __mul__ of class Money.
    """
    ## A defined money:
    money = SomeMoney(Currencies.USD, Decimal("1.23"), Date.today())

    ## Multiplication by NoneMoney:
    assert money.__mul__(NoneMoney) is NoneMoney

    ## Multiplication by SomeMoney:
    assert money.__mul__(SomeMoney(Currencies.USD, Decimal("3.45"), Date.today())) is NoneMoney

    ## Multiplication by NonePrice:
    assert money.__mul__(NonePrice) is NoneMoney

    ## Multiplication by SomePrice:
    assert money.__mul__(SomePrice(Currencies.USD, Decimal("3.45"), Date.today())) is NoneMoney

    ## Multiplication by Primitive Number:


# Generated at 2022-06-12 06:26:51.599039
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    pass

# Generated at 2022-06-12 06:26:54.199000
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    assert Price.of(USD, Decimal("30"), None).as_integer() == 30
# Define and attach undefined price singleton.
Price.NA = NonePrice()



# Generated at 2022-06-12 06:27:01.519792
# Unit test for method negative of class Price
def test_Price_negative():
    p = Price.of(Currency.USD, Decimal('100.0000'), Date(2020, 1, 2))
    assert p.negative().qty == Decimal('-100.0000')
    assert p.negative().ccy == Currency.USD
    assert p.negative().dov == Date(2020, 1, 2)
    assert p.negative().defined
    assert not p.negative().undefined
    assert p.negative() == Price.of(Currency.USD, Decimal('-100.0000'), Date(2020, 1, 2))
    assert p.negative().defined
    assert not p.negative().undefined
    assert p.negative().currency == Currency.USD
    assert p.negative().quantity == Decimal('-100.0000')
    assert p.negative().date == Date(2020, 1, 2)

# Generated at 2022-06-12 06:27:10.730498
# Unit test for method lte of class Money
def test_Money_lte():
    from .currencies import AUD, try_get_currency
    from .exchange import FXRateServiceError, FXRatesResolver
    from .money import Money, NoMoney
    from .money.money import SomeMoney
    from .zeitgeist import Date

    assert NoMoney.lte(NoMoney)
    assert NoMoney.lte(SomeMoney(AUD, Decimal(10), Date.today()))

    m1 = SomeMoney(AUD, Decimal(1), Date.today())
    m2 = SomeMoney(AUD, Decimal(2), Date.today())
    assert m1.lte(m2)
    assert m2.lte(m1)
    assert m1 <= m1

    # Incompatible currencies
    with pytest.raises(IncompatibleCurrencyError, match="those two currencies are incompatible"):
        m1

# Generated at 2022-06-12 06:27:22.229755
# Unit test for method gt of class Price
def test_Price_gt():
    p = Price.of(cpp_usd, Decimal(35.1), cpp_today)
    assert p.gt(p) == False
    assert p.gt(Price.of(cpp_usd, Decimal(35.1), cpp_today)) == False
    assert p.gt(Price.of(cpp_usd, Decimal(35.1), cpp_today + 1)) == True
    assert p.gt(Price.of(cpp_usd, Decimal(35.0), cpp_today)) == True
    assert p.gt(Price.of(cpp_usd, Decimal(35.0), cpp_today + 1)) == True
    assert p.gt(Price.of(cpp_usd, Decimal(35.1), cpp_today - 1)) == False
    assert p.defined == True

# Generated at 2022-06-12 06:27:31.548613
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    """
    Tests conversion of a *defined* monetary value from one currency to another.
    """
    ## Initialise FX rate service with some rates:
    FXRateService.default = FXRateService({
        ('USD', 'GBP'): FXRate('USD', 'GBP', Decimal(2)),
        ('GBP', 'USD'): FXRate('GBP', 'USD', Decimal(1 / 2))})

    ## Create some money:
    m: Money = Money.of('USD', Decimal(20), Date.now())

    ## Try to convert it:
    m1: Money = m.convert('GBP')

    ## Assert:
    assert m1 == Money.of('GBP', Decimal(40), Date.now())

    ## Try to convert it again:

# Generated at 2022-06-12 06:27:39.904366
# Unit test for method __int__ of class Money
def test_Money___int__():
    from .currencies import USD, EUR
    from .dates import today

    assert int(Money.of(USD, 1.0, today())) == 1
    assert int(Money.of(USD, 1.5, today())) == 1
    assert int(Money.of(USD, -1.0, today())) == -1
    assert int(Money.of(USD, -1.5, today())) == -1

    ## Test the undefined money:
    assert int(NoMoney) == 0



# Generated at 2022-06-12 06:28:09.776116
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.of(None, None, None).as_float() == 0.0
    assert Price.of(None, 42.0, None).as_float() == 0.0
    assert Price.of(None, '42.0', None).as_float() == 0.0
    assert Price.of(None, Decimal('42.0'), None).as_float() == 0.0
    assert Price.of('USD', None, None).as_float() == 0.0
    assert Price.of('USD', 42.0, None).as_float() == 0.0
    assert Price.of('USD', '42.0', None).as_float() == 0.0
    assert Price.of('USD', Decimal('42.0'), None).as_float() == 0.0

# Generated at 2022-06-12 06:28:15.199224
# Unit test for method __int__ of class Money
def test_Money___int__():
    from .currencies import GBP, USD
    from .money import Money

    assert int(Money.of(GBP, 0.1, Date(2017, 11, 8))) == 0

    assert int(Money.of(USD, 0.123456, Date(2017, 11, 8))) == 0

# Generated at 2022-06-12 06:28:25.314571
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    assert Decimal('0.50') == SomePrice(USD, 20, Date.today()) / Decimal('40')
    assert Decimal('1.00') == SomePrice(USD, 20, Date.today()).__truediv__(20)
    assert Decimal('0.05') == SomePrice(USD, 20, Date.today()).__truediv__(Decimal('400'))
    assert Decimal('0.05') == SomePrice(USD, 20, Date.today()).__truediv__(Decimal('400'), context=Context(prec=6))
    assert Decimal('0.05') == SomePrice(USD, 20, Date.today()).__truediv__(Decimal('400'), context=Context(prec=7))

# Generated at 2022-06-12 06:28:32.981586
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    assert SomeMoney(Currency.EUR, Decimal('5.43'), Date.today()).__le__(NoMoney) == False
    assert NoMoney.__le__(SomeMoney(Currency.EUR, Decimal('5.43'), Date.today())) == True
    assert SomeMoney(Currency.EUR, Decimal('5.43'), Date.today()).__le__(SomeMoney(Currency.USD, Decimal('5.43'), Date.today())) == False


# Generated at 2022-06-12 06:28:41.766999
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    """
    Price.with_dov(DateTz) -> Price
    """
    eur = Currency.of("EUR")
    d1 = DateTz.of(2017, 12, 3, 10, 0, 0, tzinfo=pytz.utc)
    d2 = DateTz.of(2017, 12, 4, 10, 0, 0, tzinfo=pytz.utc)
    p1 = Price(eur, 0.8, d1)
    p2 = Price(eur, 0.8, d2)
    p3 = p1.with_dov(d2)
    p4 = p2.with_dov(d1)
    assert p1 == p4
    assert p2 == p3

# Generated at 2022-06-12 06:28:48.815895
# Unit test for method as_float of class Price
def test_Price_as_float():
    Price_x = Price.of(ccy.NOK, 31, date(2020, 2, 16))
    Price_y = Price(ccy.NOK, 31, date(2020, 2, 16))
    Price_z = Price.of(ccy.NOK, "31", date(2020, 2, 16))
    Price_w = Price.of(ccy.NOK, None, None)
    Price_x.as_float()
    Price_y.as_float()
    Price_z.as_float()
    Price_w.as_float()


# Generated at 2022-06-12 06:28:50.264353
# Unit test for method negative of class Price
def test_Price_negative():
    result = NoPrice.negative()

    assert result is NoPrice

# Generated at 2022-06-12 06:29:00.955466
# Unit test for method times of class Price
def test_Price_times():
    """Unit test for method times of class Price."""
    assert isinstance(NoPrice.times(1), Money)
    assert NoPrice.times(1).undefined
    assert NoPrice.times(1).ccy == Currency.from_string("USD")
    assert NoPrice.times(1).qty == Decimal(0)

    assert isinstance(SomePrice(Currency.from_string("EUR"), Decimal(1), Date.from_string("2019-11-24")).times(3), Money)
    assert SomePrice(Currency.from_string("EUR"), Decimal(1), Date.from_string("2019-11-24")).times(3).ccy == Currency.from_string(
        "EUR")

# Generated at 2022-06-12 06:29:02.929519
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    pass # Will be tested in Price


# Generated at 2022-06-12 06:29:06.620403
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    x = Price.of(Currency.USD, 100, D(2019, 1, 1))
    y = Price.of(Currency.USD, 100, D(2019, 1, 1))
    assert x.is_equal(y)
