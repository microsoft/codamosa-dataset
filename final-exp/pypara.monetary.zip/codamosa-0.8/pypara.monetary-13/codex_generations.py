

# Generated at 2022-06-12 06:24:58.983955
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    """
    Tests that the __sub__ method works correctly.
    """
    obj = Money.of(Currency.USD, 1, Date.today())
    assert obj == obj.__sub__(NoMoney)



# Generated at 2022-06-12 06:25:07.861811
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from .currencies import EUR, USD
    from .dates import TODAY

    assert Money.of(EUR, 4, TODAY).scalar_add(5) == Money.of(EUR, 9, TODAY)
    assert (5 + Money.of(EUR, 4, TODAY)) == Money.of(EUR, 9, TODAY)

    assert Money.of(EUR, 4, TODAY).scalar_add(Money.of(USD, 7, TODAY)) == Money.of(EUR, 4, TODAY)
    assert (Money.of(USD, 7, TODAY) + Money.of(EUR, 4, TODAY)) == Money.of(EUR, 4, TODAY)



# Generated at 2022-06-12 06:25:15.716057
# Unit test for method as_float of class Price
def test_Price_as_float():
    #
    # __float__()
    #
    ccy = Currency.usd
    qty = Decimal('5.5')
    dov = Date(2020, 1, 1)
    price = Price.of(ccy, qty, dov)
    assert price.as_float() == 5.5
    #
    # __round__()
    #
    #
    # __int__()
    #



# Generated at 2022-06-12 06:25:18.810348
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():  # lgtm [py/similar-function]
    assert Money.NA.__floordiv__(1) is Money.NA



# Generated at 2022-06-12 06:25:21.082073
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    # Setup
    price_1 = Price(Currency("USD"), Decimal(4), Date(2018, 1, 1), True)
    price_2 = Price(Currency("USD"), Decimal(4), Date(2018, 1, 1), True)

    # Exercise and verify
    assert (price_1 < price_2) == False


# Generated at 2022-06-12 06:25:29.084149
# Unit test for method gte of class Money
def test_Money_gte():
    from .currencies import Currency
    from .exchange import FXRateService
    from .money import Money
    from .pricing import Price

    fx = FXRateService.get_default()
    usd = Currency.find('USD')
    eur = Currency.find('EUR')
    gbp = Currency.find('GBP')
    assert Money.of(usd, 100, None) >= Money.of(usd, 100, None)
    assert Money.of(usd, 100, None) >= Money.of(usd, 50, None)
    assert Money.of(usd, 100, None) >= Money.of(usd, 0, None)

    assert Money.of(eur, 100, None) >= Money.of(eur, 100, None)
    assert Money.of(eur, 100, None) >= Money.of

# Generated at 2022-06-12 06:25:38.539777
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    p1 = Price.of(GBP, 10, Date(2018, 1, 1))
    p2 = Price.of(GBP, 10, Date(2018, 1, 1))
    assert p1.is_equal(p2)
    assert not p1.is_equal(None)
    assert not p1.is_equal(10)
    assert not p1.is_equal(Price.of(GBP, 10, Date(2018, 1, 2)))
    assert not p1.is_equal(Price.of(EUR, 10, Date(2018, 1, 1)))
    assert not p1.is_equal(Price.of(GBP, 11, Date(2018, 1, 1)))
    assert not p1.is_equal(Price.NA)
    assert Price.NA.is_equal(Price.NA)

# Generated at 2022-06-12 06:25:47.217927
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    # Test cases where the currency is not changed
    assert UA.USD(100.0) == UA.USD(100.0).with_ccy(CURRENCIES.get('USD'))
    assert UA.EUR(100.0) == UA.EUR(100.0).with_ccy(CURRENCIES.get('EUR'))

    # Test case where currency is changed to another one
    assert UA.USD(100.0) == UA.EUR(100.0).with_ccy(CURRENCIES.get('USD'))
    assert UA.EUR(100.0) == UA.USD(100.0).with_ccy(CURRENCIES.get('EUR'))

    # Test case where currency is changed to an undefined one

# Generated at 2022-06-12 06:25:55.799942
# Unit test for method lte of class Price
def test_Price_lte():
    """
    Tests method lte of class Price
    """
    some = Price.of(ccy=Currency.USD,qty=Decimal('1.0'),dov=Date.gmtnow())
    assert(some.lte(some))
    none = Price.of(None, Decimal('1.0'), Date.gmtnow())
    assert(none.lte(some))
    assert(none.lte(none))
    assert(some.lte(none) == False)
    assert(some.is_equal(some.with_qty(Decimal('1.0'))))
    assert(some.lte(some.with_qty(Decimal('1.0'))))
    assert(some.lte(some.with_qty(Decimal('1.1'))))

# Generated at 2022-06-12 06:26:01.184959
# Unit test for method __add__ of class Price
def test_Price___add__():
    # Should return the same price in case of addition with zero
    assert SomePrice(ccy=USD, qty=Decimal(0), dov=Date(19, 12, 31)) + SomePrice(ccy=USD, qty=0, dov=Date(19, 12, 31)) == SomePrice(ccy=USD, qty=Decimal(0), dov=Date(19, 12, 31))
    # Should return undefined price in case of addition with undefined price
    assert SomePrice(ccy=USD, qty=Decimal(0), dov=Date(19, 12, 31)) + NoPrice == NoPrice
    # Should return a price with value date as the future of two actual value dates

# Generated at 2022-06-12 06:27:09.489130
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    from .currencies import USD
    from .commons.zeitgeist import Date
    from .domain.money import Money
    import pytest
    from typing import cast

    with pytest.raises(MonetaryOperationException):
        Money.NA.with_dov(Date(year=2019, month=5, day=5))
    assert Money.of(USD, 100, Date(year=2019, month=5, day=7)).with_dov(Date(year=2019, month=5, day=5)) == Money.of(USD, 100, Date(year=2019, month=5, day=5))

# Generated at 2022-06-12 06:27:12.011906
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    assert SomeMoney(USD, 1.22, None) // 3 == SomeMoney(USD, 0.41, None)

# Generated at 2022-06-12 06:27:14.035828
# Unit test for method round of class Price
def test_Price_round():
    test_Price_round_1()
    print("test_Price_round done")


# Generated at 2022-06-12 06:27:21.211866
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    assert bool(Money(None, None, None)) is False
    assert bool(Money("USD", None, None)) is False
    assert bool(Money("USD", Decimal("-0"), None)) is False
    assert bool(Money("USD", Decimal("-1"), None)) is True
    assert bool(Money("USD", Decimal("-1"), Date.today())) is True
    assert bool(Money("USD", Decimal("0.00"), Date.today())) is False



# Generated at 2022-06-12 06:27:31.150067
# Unit test for method gt of class Money
def test_Money_gt():
    from .currencies import Currency

    CHF = Currency.of("CHF")
    USD = Currency.of("USD")

    ## Undefined Money
    assert NoMoney > NoMoney
    assert NoMoney > SomeMoney(CHF, Decimal("0"), Date.today())
    assert SomeMoney(CHF, Decimal("0"), Date.today()) > NoMoney

    ## Money vs Money
    with Currency.use("CHF"):
        assert Money.of(None, Decimal("0.02"), Date.today())-Money.of(None, Decimal("0.01"), Date.today()) > Money.of(None, Decimal("0"), Date.today())

# Generated at 2022-06-12 06:27:44.333441
# Unit test for method gte of class Money
def test_Money_gte():
    from decimal import Decimal
    from datetime import date
    from pitcoin_modules.currencies import Currency
    from pitcoin_modules.exchange import EUR_USD_EXCHANGE_RATE_LOOKUP

    from src.main.models.money import Money
    from src.main.models.price import Price

    m1 = Money.of(None, Decimal(100), date.today())
    m2 = Money.of(Currency.of("EUR"), Decimal(100), date.today())
    m3 = Money.of(Currency.of("USD"), Decimal(100), date.today())
    m4 = Money.of(Currency.of("EUR"), Decimal(100), date.today())

    m5 = Money.of(None, Decimal(100), date(2014, 12, 31))
    m6

# Generated at 2022-06-12 06:27:50.493363
# Unit test for method __mul__ of class Money
def test_Money___mul__():
    from .currencies import CAD
    from .money import Money, SomeMoney
    from decimal import Decimal
    m = Money.of(CAD, Decimal('1.00'), Date.today())
    n = m * Decimal('1.00')
    assert n.defined is True
    assert n.ccy.code == CAD.code
    assert n.qty == Decimal('1.00')
    assert n.dov == Date.today()
    assert n == SomeMoney(CAD, 1.00, Date.today())



# Generated at 2022-06-12 06:28:02.492273
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    money1 = SomeMoney(Currency.USD, Decimal('100'), Date.today())
    assert money1.__floordiv__(Decimal('10')) == SomeMoney(Currency.USD, Decimal('10'), Date.today())
    assert money1.__floordiv__(Decimal('0')) == NoMoney
    assert money1.__floordiv__(Decimal('0')) == NoMoney
    assert money1.__floordiv__(Decimal('-1')) == SomeMoney(Currency.USD, Decimal('-100'), Date.today())
    assert money1.__floordiv__(Decimal('-1.23')) == SomeMoney(Currency.USD, Decimal('-81'), Date.today())
    assert money1.__floordiv__(Decimal('1.23')) == Some

# Generated at 2022-06-12 06:28:12.450215
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from .currencies import USD
    from .money import Money
    from decimal import Decimal

    Money.of(USD, "5.00", None).scalar_subtract(Decimal("2")) == Money.of(USD, "3.00", None)
    Money.of(USD, None, None).scalar_subtract(Decimal("5")) == Money.of(USD, None, None)
    Money.of(USD, "5.00", None).scalar_subtract(Decimal("0")) == Money.of(USD, "5.00", None)


# Generated at 2022-06-12 06:28:18.863623
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    """
    Test that method __truediv__ of class Price works correctly.
    """
    A_PRICE = PriceFactory.create(ccy = Currency.USD, qty = 10.00, dov = Date.today())
    A_NUMERIC = Decimal(2.00)
    assert float(A_PRICE / A_NUMERIC) == float(A_PRICE.__truediv__(A_NUMERIC))

# Generated at 2022-06-12 06:30:16.771423
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ccy = Currency("USD", "US dollars")
    rate = FXRate(ccy, ccy, Decimal("1.0"), "USD/USD", Date(2017, 9, 18))
    qty = Decimal("1.0")
    dov = Date(2017, 9, 18)
    instance = SomePrice.of(ccy, qty, dov)
    to = Currency("EUR", "Euro")
    asof = None
    strict = False

    with patch.object(FXRateService, "default", None):
        with raises(ProgrammingError, match="^Did you implement and set the default FX rate service\?$"):
            instance.convert(to=to, asof=asof, strict=strict)


# Generated at 2022-06-12 06:30:21.358605
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    USD = Currency.of("USD")
    NA = Money.NA
    assert (NA.scalar_subtract(1) == NA)
    assert (SomeMoney(USD, 100, Date.today()).scalar_subtract(10) == SomeMoney(USD, 90, Date.today()))


# Generated at 2022-06-12 06:30:26.532474
# Unit test for method __gt__ of class Money
def test_Money___gt__():

    from xbbg.core.currencies import USD
    from xbbg.core.money import Money

    assert Money.of(USD, 10, Date.today()) > Money.of(USD, 5, Date.today())  # Test that Money.__gt__(Money) works.



# Generated at 2022-06-12 06:30:38.583326
# Unit test for method gte of class Money
def test_Money_gte():
    from .currencies import USD
    from .money import Money
    from .conventions import DayCount
    
    ZERO = USD(0)
    
    def FCF(date, cashflow):
        return Money.of(USD, cashflow, date)

    def PV_DCF(terminal_value, cashflows, discount_rate):
        return sum(cashflow / (1 + discount_rate)**index for index, cashflow in enumerate(cashflows, start=1)) / (1 + discount_rate)**len(cashflows) * (1 - 1 / (1 + discount_rate)**len(cashflows)) + terminal_value / (1 + discount_rate)**len(cashflows)


# Generated at 2022-06-12 06:30:50.789134
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    from datetime import date
    # test for a defined price
    price1 = SomePrice('EUR', 10.00, date(2019, 1, 1))
    assert str(price1) == 'EUR 10.00 @ 2019-01-01'
    price2 = price1.with_dov(date(2019, 1, 2))
    assert str(price2) == 'EUR 10.00 @ 2019-01-02'
    assert price1 is not price2
    # test for an undefined price
    price3 = NoPrice
    price4 = price3.with_dov(date(2019, 1, 2))
    assert str(price4) == 'NA'
    assert price3 is price4
    assert price4 is NoPrice