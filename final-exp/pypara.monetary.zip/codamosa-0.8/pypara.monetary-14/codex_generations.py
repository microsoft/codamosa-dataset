

# Generated at 2022-06-12 06:28:03.950368
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from .currencies import USD, EUR
    from .exchange import ExchangeRateService
    from .market import FXSpot, FXForward
    from .money import Money, NoMoney, SomeMoney
    from .pricing import Price

    # Default rate service
    rs = ExchangeRateService()

    # Populate with historical EURUSD rates
    rs.put_fxspot(FXSpot(USD, EUR, Date(2018, 5, 1), Decimal("1.2235")))
    rs.put_fxspot(FXSpot(USD, EUR, Date(2018, 5, 2), Decimal("1.2139")))
    rs.put_fxspot(FXSpot(USD, EUR, Date(2018, 5, 3), Decimal("1.2274")))

    # Populate with historical EURUSD forward rates

# Generated at 2022-06-12 06:28:09.613817
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    t1 = SomeMoney(USD, decimal.Decimal('-12.3456'), datetime.date(2018,1,1))
    t2 = SomeMoney(USD, decimal.Decimal('-12.3456'), datetime.date(2018,1,1))
    assert t1.__le__(t2) == True, "test_SomeMoney___le__() failed!"

# Generated at 2022-06-12 06:28:10.798326
# Unit test for method __add__ of class Price
def test_Price___add__():
    pytest.fail("Not implemented")


# Generated at 2022-06-12 06:28:22.420592
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    from .currencies import USD
    from .dates import Date
    from .monetary import Money

    m1 = Money.of(USD, 10, Date(2018, 3, 31))
    assert(m1.is_equal(Money.of(USD, 10, Date(2018, 3, 31))))

    m2 = Money.of(USD, 10, Date(2018, 3, 30))
    assert(not m1.is_equal(m2))

    m3 = Money.of(None, 10, Date(2018, 3, 31))
    assert(not m1.is_equal(m3))

    m4 = Money.of(USD, None, Date(2018, 3, 31))
    assert(not m1.is_equal(m4))

    m5 = Money.of(USD, 10, None)

# Generated at 2022-06-12 06:28:29.401501
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    """
    |descr| : `Unit test for method __gt__ of class SomeMoney`
    |date| : 2020/04/03
    |author| : Mohamed Amine Benzakour

    """
    assert SomeMoney(MoneyCurrency("USD"), Decimal(10), Date(2018, 1, 1)) > SomeMoney(MoneyCurrency("USD"), Decimal(9), Date(2018, 1, 1))
    assert not SomeMoney(MoneyCurrency("USD"), Decimal(10), Date(2018, 1, 1)) > SomeMoney(MoneyCurrency("USD"), Decimal(10), Date(2018, 1, 1))
    assert not SomeMoney(MoneyCurrency("USD"), Decimal(10), Date(2018, 1, 1)) > SomeMoney(MoneyCurrency("USD"), Decimal(11), Date(2018, 1, 1))
    assert not Some

# Generated at 2022-06-12 06:28:39.421521
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert -Price('USD', 1.5, Date.today()).floor_divide(1) == Price('USD', -2, Date.today())
    assert Price('USD', 1.5, Date.today()).floor_divide(0.25) == Price('USD', 6, Date.today())
    assert Price('USD', 0, Date.today()).floor_divide(0.25) == Price('USD', 0, Date.today())
    assert Price('USD', -1.5, Date.today()).floor_divide(0.25) == Price('USD', -7, Date.today())
    assert Price('USD', -1.5, Date.today()).floor_divide(2) == Price('USD', -1, Date.today())
    assert Price('USD', 1.5, Date.today()).floor_divide

# Generated at 2022-06-12 06:28:46.071820
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    usd = currency("USD")
    eur = currency("EUR")
    cny = currency("CNY")
    d = date(2018, 9, 23)
    a = Price.of(usd, Decimal("1.0"), d)
    b = Price.of(cny, Decimal("2.0"), d)
    c = Price.of(eur, Decimal("-3.0"), d)
    d = Price.of(None, Decimal("-3.0"), None)
    assert a.__pos__().ccy == usd and a.__pos__().qty == Decimal("1.0") and a.__pos__().dov == d
    assert b.__pos__().ccy == cny and b.__pos__().qty == Decimal("2.0") and b.__pos__

# Generated at 2022-06-12 06:28:56.659330
# Unit test for method multiply of class Price
def test_Price_multiply():
    zero_eur = Price.of(ccy = 'EUR',qty = Decimal('0.00'), dov = Date(2020,10,1))
    assert(zero_eur.multiply(3) == Price.of(ccy = 'EUR',qty = Decimal('0.00'), dov = Date(2020,10,1)))
    zero_eur = Price.of(ccy = 'EUR',qty = Decimal('0.00'), dov = Date(2020,10,1))
    assert(zero_eur.multiply(Decimal('-3')) == Price.of(ccy = 'EUR',qty = Decimal('0.00'), dov = Date(2020,10,1)))

# Generated at 2022-06-12 06:29:04.848590
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    import pickle
    sp1 = SomePrice(ccy=Currency.of('USD'), qty=Decimal('0.93'), dov=Date.from_string('2018-12-01'), price_source='PriceSource')
    sp2 = SomePrice(ccy=Currency.of('USD'), qty=Decimal('0.98'), dov=Date.from_string('2018-12-01'), price_source='PriceSource')
    sp3 = SomePrice(ccy=Currency.of('USD'), qty=Decimal('0.0025'), dov=Date.from_string('2018-12-01'), price_source='PriceSource')
    assert sp1 - sp2 == sp3

# Generated at 2022-06-12 06:29:11.743255
# Unit test for method negative of class Price
def test_Price_negative():
    money1 = Money.of(Currency.USD, Decimal('10.0'), Date(2018,10,10))
    price1 = money1.price

    price2 = price1.negative()

    assert price2.qty == Decimal('-10.0')
    assert price2.ccy == Currency.USD
    assert price2.dov == Date(2018,10,10)
