

# Generated at 2022-06-12 06:24:11.449958
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    from datetime import date
    from decimal import Decimal
    from src.currencies import Currency
    from src.finmath.money import Money

    m1 = Money.of(Currency.USD, Decimal('10'), date(2020, 1, 1))
    m2 = Money.of(Currency.USD, Decimal('10'), date(2020, 1, 1))
    assert m1 >= m2
    assert not m1 < m2
    m1 = Money.of(Currency.USD, Decimal('10'), date(2020, 1, 1))
    m2 = Money.of(Currency.EUR, Decimal('20'), date(2020, 1, 1))
    try:
        m1 >= m2
        raise AssertionError("IncompatibleCurrencyError expected")
    except IncompatibleCurrencyError:
        pass




# Generated at 2022-06-12 06:24:24.149673
# Unit test for method __add__ of class Price
def test_Price___add__():
    print ("test_Price___add__")
    # Test 2: Defined price object with same ccy and date
    price1 = Price.of(ccy = Currency.of('USD'), qty = Decimal('10.0000'), dov = Date.today())
    price2 = Price.of(ccy = Currency.of('USD'), qty = Decimal('100.0000'), dov = Date.today())
    price3 = price1 + price2
    assert float(price3.qty) == 110.0
    assert price3.dov == Date.today()
    # Test 3: Defined price object with same ccy and date
    price1 = Price.of(ccy = Currency.of('USD'), qty = Decimal('10.0000'), dov = Date.today())

# Generated at 2022-06-12 06:24:34.666891
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    # Test 1: ccy1 < ccy2
    ccy1 = Currency.get('EUR')
    qty1 = Decimal('123.456')
    date = Date.current_date()
    m1 = SomeMoney(ccy1, qty1, date)
    ccy2 = Currency.get('USD')
    qty2 = Decimal('123.456')
    m2 = SomeMoney(ccy2, qty2, date)

    assert m1 < m2

    # Test 2: ccy1 == ccy2, qty1 < qty2
    ccy1 = Currency.get('EUR')
    qty1 = Decimal('123.456')
    date = Date.current_date()
    m1 = SomeMoney(ccy1, qty1, date)
    ccy2 = Currency

# Generated at 2022-06-12 06:24:45.127783
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    sam = Price(ccy=Currency.USD, qty=1, dov=Date.today())
    assert sam.defined
    assert sam.undefined == False
    assert round(sam.as_float(), 2) == 1.0
    assert sam.as_integer() == 1
    assert 1 == 1
    assert sam.money.qty == 1
    assert sam.money.ccy == Currency.USD
    assert sam.money.dov == Date.today()
    assert sam.money.as_float() == 1
    assert sam.money.as_integer() == 1
    assert sam.money.with_qty(10).qty == 10
    assert sam.money.with_qty(10).ccy == Currency.USD
    assert sam.money.with_qty(10).dov == Date.today()
   

# Generated at 2022-06-12 06:24:51.619397
# Unit test for method lte of class Price
def test_Price_lte():
    """
    Tests :meth:`Price.lte` method of :class:`Price` class.
    """
    p1 = Price.of(EUR, 10, date(2020, 1, 1))
    p2 = Price.of(EUR, 10, date(2020, 1, 1))
    p3 = Price.of(EUR, 20, date(2020, 1, 1))
    p4 = Price.of(USD, 10, date(2020, 1, 1))

    assert not (p1.lte(NoPrice))
    assert p2.lte(p1)
    assert p1.lte(p2)
    assert p1.lte(p3)
    with raises(IncompatibleCurrencyError):
        p1.lte(p4)



# Generated at 2022-06-12 06:25:01.078956
# Unit test for method divide of class Money
def test_Money_divide():
    # NA / NA
    assert Money.NA.divide(Money.NA) is Money.NA
    assert Money.NA.divide(0) is Money.NA
    assert Money.NA / Money.NA is Money.NA
    # EUR / USD
    assert Money(EUR, Decimal('10')).divide(Money(USD, Decimal('10'))) is NoneMoney
    assert Money(EUR, Decimal('10')) / Money(USD, Decimal('10')) is NoneMoney
    # EUR / EUR
    assert Money(EUR, Decimal('10')).divide(Money(EUR, Decimal('10'))) == Money(EUR, Decimal('1'))

# Generated at 2022-06-12 06:25:05.954681
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    price1 = Price.of(Currency.USD, Decimal(10), Date(2016, 1, 1))
    assert (price1 >= price1) == True
    price2 = Price.of(Currency.USD, Decimal(20), Date(2016, 1, 1))
    assert (price1 >= price2) == False
    assert (price2 >= price1) == True

# Generated at 2022-06-12 06:25:18.152951
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    # __ge__() -> bool
    assert (SomePrice(USD, 0, None) >= NoPrice) == True
    assert (NoPrice >= SomePrice(USD, 0, None)) == False
    assert (SomePrice(USD, 0, None) >= SomePrice(USD, 0, None)) == True
    assert (SomePrice(USD, 1, None) >= SomePrice(USD, 0, None)) == True
    assert (SomePrice(USD, 0, None) >= SomePrice(USD, 1, None)) == False
    assert (SomePrice(USD, 0, None) >= SomePrice(EUR, 0, None)) == False
    assert (SomePrice(USD, 0, None) >= SomePrice(USD, 0, None)) == True
    assert (SomePrice(USD, 1, None) >= SomePrice(USD, 0, None)) == True

# Generated at 2022-06-12 06:25:28.011802
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    def inner_test(money_1, money_2, expected):
        ## 1. Setup:
        money_1 = SomeMoney(money_1[0], money_1[1], money_1[2])
        money_2 = SomeMoney(money_2[0], money_2[1], money_2[2])
        ## 2. Exercise:
        res = money_1 - money_2
        ## 3. Verify:
        assert res == expected
    inner_test((USD, Decimal("1.0"), Date("2018-01-01")), (USD, Decimal("-1.0"), Date("2018-01-01")), (USD, Decimal("2.0"), Date("2018-01-01")))

# Generated at 2022-06-12 06:25:35.333933
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    ## Test data:
    a = SomePrice(Currency.USD, 123.45, Date(2021, 1, 1))
    r = FXRate(a.ccy, Currency.EUR, Decimal("1.2"), Date(2020, 12, 30))
    assert a.convert(r.to) == SomePrice(r.to, 123.45 * r.value, Date(2021, 1, 1))  # type: ignore



# Generated at 2022-06-12 06:30:42.247435
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    class A(Money):
        _ccy: Currency = Currency("EUR")
        _qty: Decimal = Decimal(0.0)
        _dov: Date = Date()
        @property
        def ccy(self):
            return self._ccy
        @property
        def qty(self):
            return self._qty
        @property
        def dov(self):
            return self._dov
        def is_equal(self, other: Any) -> bool:
            return NotImplemented
        def as_boolean(self) -> bool:
            return NotImplemented
        def as_float(self) -> float:
            return NotImplemented
        def as_integer(self) -> int:
            return NotImplemented
        def abs(self) -> "Money":
            return NotIm

# Generated at 2022-06-12 06:30:53.377454
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    assert Money.of(Currency.GBP, Decimal('1'), Date.today()).with_qty(Decimal('2')) == Money.of(Currency.GBP, Decimal('2'), Date.today())
    assert Money.of(Currency.GBP, Decimal('1'), Date.today()).with_qty(Decimal('-1')) == Money.of(Currency.GBP, Decimal('-1'), Date.today())
    assert Money.of(Currency.GBP, Decimal('1'), Date.today()).with_qty(Decimal('1.23')) == Money.of(Currency.GBP, Decimal('1.23'), Date.today())