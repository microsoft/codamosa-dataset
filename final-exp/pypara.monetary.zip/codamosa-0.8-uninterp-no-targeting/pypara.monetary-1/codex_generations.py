

# Generated at 2022-06-21 20:25:11.982797
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    t=None
    assert -t==t
test_NoneMoney___int__()


# Generated at 2022-06-21 20:25:14.298051
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    assert NoneMoney.of(Currency.USD, None, None).with_ccy(ccy=Currency.USD) == NoneMoney


# Generated at 2022-06-21 20:25:16.989085
# Unit test for method positive of class Price
def test_Price_positive():
    m = Money.of(Currency.of("USD"), 17, Date.today())
    assert m.positive() == m

    m = Money.of(Currency.of("USD"), -17, Date.today())
    assert m.positive() == Money.of(Currency.of("USD"), 17, Date.today())

# Generated at 2022-06-21 20:25:18.793756
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NoPrice.with_qty(1.0) == NoPrice

# Generated at 2022-06-21 20:25:22.398949
# Unit test for method __floordiv__ of class Money
def test_Money___floordiv__():
    assert Money.of(None, 100, Date.today()).__floordiv__(2) == Money.of(None, 50, Date.today())

# Generated at 2022-06-21 20:25:23.195758
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__(): ...

# Generated at 2022-06-21 20:25:28.362202
# Unit test for method __ge__ of class SomePrice
def test_SomePrice___ge__():
    # Test without parameters:
    # Call the method
    assert SomePrice(Currency.USD, 1, Date.now()) >= SomePrice(Currency.USD, 2, Date.now()) is False
    # Test with parameters:
    # Call the method
    assert SomePrice(Currency.USD, 1, Date.now()) >= SomePrice(Currency.USD, 1, Date.now()) is True



# Generated at 2022-06-21 20:25:37.406690
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    price = SomePrice(Currency('USD'), Decimal('1.234567890'), Date(2018, 1, 1))
    assert price.round(ndigits=1) == SomePrice(Currency('USD'), Decimal('1.2'), Date(2018, 1, 1))
    assert price.round(ndigits=-1) == SomePrice(Currency('USD'), Decimal('1.2'), Date(2018, 1, 1))
    assert price.round() == SomePrice(Currency('USD'), Decimal('1'), Date(2018, 1, 1))
    assert price.round(ndigits=0) == SomePrice(Currency('USD'), Decimal('1'), Date(2018, 1, 1))

# Generated at 2022-06-21 20:25:44.143900
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    """Tests :meth:`Money.__abs__` of a :class:`Money` instance."""
    m1 = SomeMoney(Currency.of("EUR"), Decimal("-1"), Date.today())
    m2 = SomeMoney(Currency.of("EUR"), Decimal("1"), Date.today())
    assert abs(m1) == abs(m2)
    assert abs(m1).is_equal(abs(m2))
    assert abs(m1) == m2
    assert abs(m1).is_equal(m2)
    assert abs(m1) == 1
    assert abs(m1) == 0.25
    assert abs(m1).as_float() == 0.25
    assert abs(m1).as_integer() == 0
    assert abs(m1).as_boolean()

# Generated at 2022-06-21 20:25:48.722078
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    """ Unit test for method '__gt__' of class 'NoneMoney' """
    value = NoneMoney
    assert not value.__gt__(value)
    assert not value.__gt__(SomeMoney(USD, Decimal("10.00"), dov))

# Generated at 2022-06-21 20:26:33.946621
# Unit test for method __float__ of class Price
def test_Price___float__():
    ccy = EUR
    ccy_USD = USD

    qty = Decimal('123.45')
    qty_USD = Decimal('123.45')
    qty_zero = Decimal('0.0')

    date = date(year=2020, month=6, day=28)

    mny = Money(ccy, qty, date)
    mny_USD = Money(ccy_USD, qty_USD, date)
    mny_zero = Money(ccy, qty_zero, date)

    price = Price.of(ccy, qty, date)
    price_USD = Price.of(ccy_USD, qty_USD, date)
    price_zero = Price.of(ccy, qty_zero, date)


# Generated at 2022-06-21 20:26:38.079005
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
  # TODO: assert/raise/re-raise
  # TODO: assert type
  # TODO: assert exceptions
  # TODO: assert class
  # TODO: assert method
  # TODO: assert module
  pass

# Generated at 2022-06-21 20:26:45.525887
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    """
    Tests the correct operation of the constructor of the class IncompatibleCurrencyError.
    """
    from .currencies.unit_test import test_eur_usd
    ccy1, ccy2 = test_eur_usd
    ice = IncompatibleCurrencyError(ccy1, ccy2)
    assert ice.ccy1 == ccy1
    assert ice.ccy2 == ccy2



# Generated at 2022-06-21 20:26:54.549339
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    """
    Tests the constructor of class SomeMoney.
    """
    assert SomeMoney(USD, Decimal(2.345), None) == SomeMoney(USD, Decimal(2.34), None)
    assert SomeMoney(USD, Decimal(2.345), None).qty == Decimal(2.34)
    try:
        _ = SomeMoney(USD, Decimal(2.345), None) != SomeMoney(EUR, Decimal(2.34), None)
        raise Exception("Invalid comparison")
    except IncompatibleCurrencyError:
        pass
    try:
        SomeMoney(USD, Decimal(2.345), None) >= SomeMoney(EUR, Decimal(2.34), None)
        raise Exception("Invalid comparison")
    except IncompatibleCurrencyError:
        pass

# Generated at 2022-06-21 20:26:56.765439
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    from .currencies import EUR

    money = EUR(10) // 2

    assert money == EUR(10) // 2



# Generated at 2022-06-21 20:26:58.741394
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    p = NonePrice()

    assert p < SomePrice(USD, 12, today)

# Generated at 2022-06-21 20:27:06.154002
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    class MyPrice(SomePrice):
        @property
        def currency(self) -> Currency:
            return self.ccy

        @property
        def quantity(self) -> Decimal:
            return self.qty

        @property
        def date_of_value(self) -> Date:
            return self.dov

    price = MyPrice(ccy=USD, qty=100, dov=Date(2020, 1, 1))
    assert price.__gt__(price) is False


# Generated at 2022-06-21 20:27:11.695385
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    ## Arrange:
    ccy = Currency.of("EUR")
    dt = Date.today()

    ## Act & Assert:
    with pytest.raises(TypeError) as exc:
        NoneMoney.of(ccy, None, dt)

    assert exc.match("Undefined monetary values do not have quantity information.")

# Generated at 2022-06-21 20:27:16.196213
# Unit test for method __le__ of class Price
def test_Price___le__():
    # Price
    assert Price.of(None, None, None) <= Price.of(None, None, None)
    assert Price.of(None, None, None) <= Price.of(Currency.USD, None, None)
    assert Price.of(None, None, None) <= Price.of(None, Decimal("10"), None)
    assert Price.of(None, None, None) <= Price.of(None, None, Date(2018, 1, 1))
    assert Price.of(Currency.USD, None, None) <= Price.of(None, None, None)
    assert Price.of(Currency.USD, None, None) <= Price.of(Currency.USD, None, None)

# Generated at 2022-06-21 20:27:28.162253
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    # Accepted input types
    p1 = Price.of(ccy=CCY, qty=QTY, dov=DOV)
    p_result = p1.with_dov(DOV_NEW)
    # New DOV should be DOV_NEW
    assert p_result.dov == DOV_NEW
    # CCY and QTY should remain unchanged
    assert p_result.ccy == CCY
    assert p_result.qty == QTY
    # NoMoney returns itself
    assert Price.NA.with_dov(DOV_NEW) is Price.NA
    # Raise TypeError when called with wrong type
    with pytest.raises(TypeError):
        p_result = p1.with_dov(1.3)



# Generated at 2022-06-21 20:27:49.082641
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    Money.NA.__neg__()



# Generated at 2022-06-21 20:28:02.445364
# Unit test for method lte of class Price
def test_Price_lte():
    assert NoPrice.lte(NoMoney)
    assert NoPrice.lte(SomeMoney(USD, Decimal("0"), None))
    assert NoPrice.lte(SomeMoney(USD, Decimal("1.0"), None))
    assert NoPrice.lte(SomeMoney(USD, Decimal("1.0"), date(2019,1,1)))
    assert SomePrice(USD, Decimal("0"), date(2019,1,1)).lte(NoMoney)
    assert SomePrice(USD, Decimal("0"), date(2019,1,1)).lte(SomeMoney(USD, Decimal("0"), None))
    assert SomePrice(USD, Decimal("0"), date(2019,1,1)).lte(SomeMoney(USD, Decimal("1.0"), None))

# Generated at 2022-06-21 20:28:15.032153
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    # Check with undefined price:
    v: Price = NoPrice
    assert v.gt(Price.of(EUR, Decimal(0.5), TODAY))
    # Check with defined price:
    v: Price = Price.of(EUR, Decimal(0.5), TODAY)
    assert not v.gt(v)
    assert not v.gt(Price.of(EUR, Decimal(0.5), TODAY))
    assert not v.gt(Price.of(EUR, Decimal(0.4999), TODAY))
    assert v.gt(Price.of(EUR, Decimal(0.4999), TODAY, strict=True))
    assert not v.gt(Price.of(USD, Decimal(0.5), TODAY))
    # Check with other currency:

# Generated at 2022-06-21 20:28:15.692290
# Unit test for method __int__ of class SomeMoney
def test_SomeMoney___int__():
    raise NotImplementedError()


# Generated at 2022-06-21 20:28:16.842523
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    result = NoneMoney > NoneMoney
    if expected_result != result:
        raise AssertionError("%s != %s")



# Generated at 2022-06-21 20:28:19.630112
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    """
    Unit test for method ``NonePrice.__truediv__``.
    """
    ## Create some price object:
    price: Price = USD(10.5, Date(2017, 12, 31))

    ## Do some divisions:
    assert price / 2 == USD(5.25, Date(2017, 12, 31))

    assert price / price == 1
    assert price / 100*10 == 0.2
    assert price / 100 == 0  # type: ignore
    assert NonePrice / 2 == NoPrice



# Generated at 2022-06-21 20:28:20.686969
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert False is (NoMoney < NoMoney)



# Generated at 2022-06-21 20:28:32.415791
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    m1 = Money.of(USD, Decimal("1"), TOMORROW)
    m2 = Money.of(USD, Decimal("2"), TOMORROW)
    assert m1.scalar_add(Decimal("1")) == m2
    assert m1.scalar_add(1) == m2
    assert m1.scalar_add(1.0) == m2
    m3 = Money.of(EUR, Decimal("1"), TOMORROW)
    m4 = Money.of(EUR, Decimal("2"), TOMORROW)
    assert m3.scalar_add(Decimal("1")) == m4
    assert m3.scalar_add(1) == m4
    assert m3.scalar_add(1.0) == m4




# Generated at 2022-06-21 20:28:34.515395
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    money = Money.of('GBP', 100, Date.today())
    assert money == +money


# Generated at 2022-06-21 20:28:36.189325
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__():
    # Define the arguments:
    other: Numeric = 1

    # Evaluate the function:
    actual: "Money" = NoneMoney().__floordiv__(other)

    # Verify the result against a hard-coded value:
    assert actual == NoMoney