

# Generated at 2022-06-21 20:25:46.404084
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__(): pass

# Generated at 2022-06-21 20:25:50.594700
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    assert SomeMoney('USD', Decimal(100.00), Date.now()).__floordiv__(Decimal(5)) == SomeMoney('USD', Decimal('20'), Date.now())
    assert SomeMoney('USD', Decimal(-100.00), Date.now()).__floordiv__(Decimal(5)) == SomeMoney('USD', Decimal('-20'), Date.now())
    assert SomeMoney('USD', Decimal(100.00), Date.now()).__floordiv__(Decimal(-5)) == SomeMoney('USD', Decimal('-20'), Date.now())
    assert SomeMoney('USD', Decimal(-100.00), Date.now()).__floordiv__(Decimal(-5)) == SomeMoney('USD', Decimal('20'), Date.now())

# Generated at 2022-06-21 20:25:52.153501
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    a = NoneMoney()

NoMoney = NoneMoney()



# Generated at 2022-06-21 20:26:04.039373
# Unit test for method negative of class Money
def test_Money_negative():
    @dataclass
    class DummyMoney(Money):
        ccy: Currency
        qty: Decimal
        dov: Date

        @property
        def defined(self) -> bool:
            return True

        @property
        def undefined(self) -> bool:
            return False

        def is_equal(self, other: Any) -> bool:
            return self is other

        def as_boolean(self) -> bool:
            return self.qty != 0

        def as_float(self) -> float:
            return float(self.qty)

        def as_integer(self) -> int:
            return int(self.qty)

        def abs(self) -> Money:
            return self

        def negative(self) -> Money:
            return self

        def positive(self) -> Money:
            return self

# Generated at 2022-06-21 20:26:16.249110
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    import hypothesis
    import pytest
    from hypothesis import strategies as st
    from numbers import Integral
    from .money import NoneMoney

    @st.composite
    def st_NoneMoney(draw: hypothesis.strategies.data.DataObject) -> NoneMoney:
        return draw(NoneMoney.st_NoneMoney())

    for v in st.integers(min_value=Integral.min, max_value=Integral.max):
        with pytest.raises(TypeError, match="Undefined monetary values do not have quantity information."):
            NoneMoney.of(None, None, None).__int__()

# Generated at 2022-06-21 20:26:21.181572
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    from . import Money, Currency
    m = Money.of(Currency('USD'), Decimal('15'), Date.now())
    assert m.scalar_add(5) == Money.of(Currency('USD'), Decimal('20'), Date.now())
    assert m.scalar_add(-5) == Money.of(Currency('USD'), Decimal('10'), Date.now())
    assert m.scalar_add(5.5) == Money.of(Currency('USD'), Decimal('20.5'), Date.now())
    assert m.scalar_add(-5.5) == Money.of(Currency('USD'), Decimal('9.5'), Date.now())
test_Money_scalar_add()

# Generated at 2022-06-21 20:26:25.348348
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    n = SomePrice(USD, Decimal("12.50"), Date(20201009))
    assert (n / 4) == SomePrice(USD, Decimal("3.13"), Date(20201009))


# Generated at 2022-06-21 20:26:30.589410
# Unit test for method gt of class Money
def test_Money_gt():
    tm = Money.of(Currency.USD, Decimal('1.2'), Date.today())
    bn = Money.NA
    assert tm.gt(bn)
    assert not bn.gt(tm)
    assert not tm.gt(tm)
    assert not bn.gt(bn)


# Generated at 2022-06-21 20:26:33.321899
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    ## Explicitly check the equality of SomePrice and NoPrice.
    assert SomePrice(USD, 1.03) == SomePrice(USD, 1.03)
    assert SomePrice(USD, 1.03) != SomePrice(EUR, 7)
    assert SomePrice(USD, 1.03) != NoPrice
    assert NoPrice == NoPrice
    assert NoPrice != SomePrice(USD, 1.03)


# Generated at 2022-06-21 20:26:46.040574
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    # Setup
    c1 = Currency.get('USD')
    p1 = pd.Timestamp('2015-01-01')
    p2 = pd.Timestamp('2015-01-02')
    p3 = pd.Timestamp('2015-01-03')
    p4 = pd.Timestamp('2015-01-04')
    p5 = pd.Timestamp('2015-01-05')
    e1 = ExchangeRateLookup.of(
        [(c1, c1, p1, 1.0), (c1, c1, p2, 2.0), (c1, c1, p3, 3.0), (c1, c1, p4, 4.0), (c1, c1, p5, 5.0)]
    )

# Generated at 2022-06-21 20:27:44.225082
# Unit test for method abs of class Money
def test_Money_abs():
    """
    Unit test for the method `abs` of the class :class:`Money`.
    """
    assert SomeMoney(Currency.EUR, Decimal("-1.23"), Date.today()).abs() == SomeMoney(Currency.EUR, Decimal("1.23"), Date.today())
    assert SomeMoney(Currency.EUR, Decimal("1.23"), Date.today()).abs() == SomeMoney(Currency.EUR, Decimal("1.23"), Date.today())
    assert NoMoney.abs() == NoMoney
    assert SomeMoney(Currency.EUR, Decimal("-1.23"), Date.today()).abs() == SomeMoney(Currency.EUR, Decimal("1.23"), Date.today())

# Generated at 2022-06-21 20:27:45.251218
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    # no meaningful unit test
    return True


# Generated at 2022-06-21 20:27:53.234247
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert SomePrice(EUR, 100, None) == SomePrice(EUR, 100, None)
    assert SomePrice(EUR, 100, None) == SomePrice(EUR, 100, TOMORROW)
    assert not SomePrice(EUR, 100, None) == SomePrice(EUR, 150, None)
    assert not SomePrice(EUR, 100, None) == SomePrice(USD, 100, None)
    assert not SomePrice(EUR, 100, None) == Money(EUR, 100)
    assert not SomePrice(EUR, 100, None) == Price(None, 100)
    assert not SomePrice(EUR, 100, None) == Price(EUR, 100, None)
    assert NoPrice == NoPrice
    assert not NoPrice == SomePrice(USD, 100, None)


# Generated at 2022-06-21 20:27:57.357803
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert Money(USD, Decimal(0.1)) > Money(USD, Decimal(0.0))
    assert Money(USD, Decimal(0.0)).gt(Money(USD, Decimal(0.0))) == False



# Generated at 2022-06-21 20:28:02.749899
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    ## Init:
    a: Price = NoPrice
    b: Price = NoPrice
    c: Price = NoPrice
    d: Price = NoPrice
    e: Price = NoPrice
    f: Price = NoPrice

    ## Test:
    a = a + b  # type: ignore
    c = d + e  # type: ignore
    e = f + d  # type: ignore

# Generated at 2022-06-21 20:28:07.175702
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert SomePrice(CAD, 123.456, Date.today()).as_boolean()
    assert not SomePrice(CAD, 0.0, Date.today()).as_boolean()
    assert not NoPrice.as_boolean()



# Generated at 2022-06-21 20:28:18.885521
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert (
        Money.of(Currency.USD, Decimal("100.00"), Date(2020, 1, 1)) >=
        Money.of(Currency.USD, Decimal("100.00"), Date(2020, 1, 1))
    )
    assert (
        Money.of(Currency.USD, Decimal("100.01"), Date(2020, 1, 1)) >=
        Money.of(Currency.USD, Decimal("100.00"), Date(2020, 1, 1))
    )
    assert not (
        Money.of(Currency.USD, Decimal("99.99"), Date(2020, 1, 1)) >=
        Money.of(Currency.USD, Decimal("100.00"), Date(2020, 1, 1))
    )

# Generated at 2022-06-21 20:28:21.524196
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    assert float(NoPrice) == 0.0

# Generated at 2022-06-21 20:28:24.474712
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    # Setup
    m = Money(None, None, None)

    # Exercise
    result = m.scalar_add(3)

    # Verify
    assert result is m



# Generated at 2022-06-21 20:28:26.923103
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    pass


# Generated at 2022-06-21 20:31:35.920953
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    from .MON import MON
    from .commons.zeitgeist import Date
    from .currencies import Currency
    from .exchange import FakeRatesService
    from .money import Money
    from .prices import Price
    assert Money.of(Currency(code='USD', eps=0.01), Decimal('1.00'), Date(year=2019, month=8, day=1)).__truediv__(Decimal('2')) == Money.of(Currency(code='USD', eps=0.01), Decimal('0.5'), Date(year=2019, month=8, day=1))

# Generated at 2022-06-21 20:31:43.827030
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    from brownie._types import Price
    for ccy in Price.ccy_sample:
        for qty in Price.qty_sample:
            for dov in Price.dov_sample:
                for other in Price.qty_sample:
                    c, q, d = SomePrice.of(ccy, qty, dov)
                    assert c.scalar_subtract(other) == SomePrice.of(ccy, qty - Decimal(other), dov)
## Tests:



# Generated at 2022-06-21 20:31:44.466200
# Unit test for method __add__ of class Money
def test_Money___add__():
    pass

# Generated at 2022-06-21 20:31:48.452583
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    from finx.data import Currency
    from finx._util import Date
    from finx._models import SomePrice

    price = SomePrice(Currency("USD"), 1.234, Date(2019, 11, 8))
    ## Returns an integer that is the closest representation of the truth value.
    assert price.__int__() == 1
    ## Returns an integer that is the closest representation of the truth value.
    assert int(price) == 1

# Generated at 2022-06-21 20:31:53.057380
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    """
    Unit test for MonetaryOperationException
    """

    try:
        raise MonetaryOperationException('test_MonetaryOperationException')
    except MonetaryOperationException as ex:
        assert ex.args[0] == 'test_MonetaryOperationException'


# Generated at 2022-06-21 20:31:58.147492
# Unit test for method convert of class Price
def test_Price_convert():
    """
    Tests conversion of a currency when no rate can be retrieved
    """
    # Given
    p = Price.of(Currencies.USD, Decimal(2), Date(2020, 1, 1))

    with pytest.raises(FXRateLookupError):
        # When
        p.convert(Currencies.GBP)



# Generated at 2022-06-21 20:32:08.785274
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    import decimal  # noqa
    import enum
    import sys  # noqa
    import typing
    import datetime  # noqa
    import uuid

    class Currency(enum.Enum):
        USD = enum.auto()
        TRY = enum.auto()
        EUR = enum.auto()
        JPY = enum.auto()

    def _cl_0():
        return NoMoney

    def _cl_1():
        return Money(
            ccy=Currency.USD,
            qty=decimal.Decimal("12.234"),
            dov=datetime.date(2020, 2, 1),
        )

    def _cl_2():
        return NoPrice
