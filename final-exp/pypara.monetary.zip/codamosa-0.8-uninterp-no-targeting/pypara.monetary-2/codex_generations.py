

# Generated at 2022-06-21 20:25:24.247318
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    # Arrange
    price = Price.of(USD, 1.0, date(2020, 1, 1))

    # Act
    new_price = price.with_ccy(EUR)

    # Assert
    assert new_price.ccy == EUR
    assert new_price.defined


# Generated at 2022-06-21 20:25:30.165524
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    from decimal import Decimal as D
    from ..currencies import CNY
    import datetime as dt
    b = Money.of(CNY, D(20.14), dt.date(2018, 10, 13))
    assert b.scalar_subtract(D(13)) == Money.of(CNY, D('7.14'), dt.date(2018, 10, 13)), 'Fails in scalar subtraction of money'

# Generated at 2022-06-21 20:25:41.289010
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    """
    Tests the ``__truediv__`` method of the :class:`Price` class.
    """

    def test_method_name_starts_with_test():
        """
        Test if the method name starts with 'test'.
        """
        method_name = inspect.stack()[0][3]
        assert method_name.startswith('test_') == True
    test_method_name_starts_with_test()

    def test_divide_zero_gives_undefined_price_singleton_from_price():
        """
        Test if divide by zero gives undefined price singleton from price.
        """
        price = Price.of(EUR, 1000, Date.now())
        actual_price = price.__truediv__(0.0)
        expected_price = NoPrice

# Generated at 2022-06-21 20:25:50.571465
# Unit test for method gt of class Price
def test_Price_gt():
    assert Price.NA.gt(Price.NA) is False
    assert Price.NA.gt(1.0) is False
    assert Price.NA.gt(SomePrice(USD, 1.0, NA)) is False
    assert Price.NA.gt(NoPrice) is False

    assert SomePrice(USD, 1.0, NA).gt(Price.NA) is True
    assert SomePrice(USD, 1.0, NA).gt(1.0) is True
    assert SomePrice(USD, 1.0, NA).gt(SomePrice(USD, 1.0, NA)) is False
    assert SomePrice(USD, 1.0, NA).gt(NoPrice) is True



# Generated at 2022-06-21 20:25:55.094231
# Unit test for method __add__ of class SomeMoney
def test_SomeMoney___add__():
    assert (SomeMoney(C(0), D(0), D(0)) + SomeMoney(C(0), D(0), D(0))) == SomeMoney(C(0), D(0), D(0))
    assert (SomeMoney(C(1), D(1), D(1)) + SomeMoney(C(1), D(1), D(1))) == SomeMoney(C(1), D(2), D(1))
    assert (SomeMoney(C(1), D(10), D(4)) + SomeMoney(C(1), D(10), D(4))) == SomeMoney(C(1), D(20), D(4))

# Generated at 2022-06-21 20:26:01.624437
# Unit test for method as_float of class Money
def test_Money_as_float():
    qty = Decimal("123.456")
    m = SomeMoney(Currency.USD, qty, Date.today())
    # Make sure qty is returned as a float
    assert isinstance(m.as_float(), float)
    assert isinstance(m.as_float(), Decimal)
    assert m.as_float() == 123.456

# Generated at 2022-06-21 20:26:05.620174
# Unit test for method lt of class Price
def test_Price_lt():
    assert Price.NA.lt(NonePrice())
    assert Price.of(USD, 1, Date(2018, 1, 1)).lt(Price.NA)
    assert Price.of(USD, 1, Date(2018, 1, 1)).lt(Price.of(EUR, 1, Date(2017, 1, 1)))  # dov matters
    assert Price.of(USD, 1, Date(2018, 1, 1)).lt(Price.of(EUR, 2, Date(2018, 1, 1)))  # ccy matters
    assert Price.of(USD, 1, Date(2018, 1, 1)).lt(Price.of(USD, 2, Date(2018, 1, 1)))  # qty matters


## Define and attach undefined price singleton.
Price.NA = NoPrice = NonePrice()



# Generated at 2022-06-21 20:26:14.662078
# Unit test for method lte of class Price
def test_Price_lte():
    assert Price.of('USD', Decimal('1.0'), date(2017, 1, 1)) <= Price.of('USD', Decimal('1.0'), date(2017, 1, 1))
    assert Price.of('USD', Decimal('1.0'), date(2017, 1, 1)) <= Price.of('USD', Decimal('2.0'), date(2017, 1, 1))
    assert Price.of('USD', Decimal('2.0'), date(2017, 1, 1)) <= Price.of('USD', Decimal('1.0'), date(2017, 1, 1)) == False
    assert Price.of('USD', Decimal('1.0'), date(2017, 1, 1)) <= Price.of('USD', Decimal('2.0'), date(2017, 1, 1))

# Generated at 2022-06-21 20:26:19.430515
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    print(Price.of((USD), Decimal('1.00'), (sixth_of_july_2020))).with_ccy(USD)
    # -> <SomePrice USD #1.00 @ 2020-07-06>
    print(Price.of((EUR), Decimal('1.00'), (sixth_of_july_2020))).with_ccy(USD)
    # -> <SomePrice USD #1.14 @ 2020-07-06>
    print(Price.NA.with_ccy(USD))
    # -> <NoPrice>

    # Unit test for method divide of class Price

# Generated at 2022-06-21 20:26:31.421681
# Unit test for method gt of class Price
def test_Price_gt():

    class PriceA(Price):
        def __init__(self, ccy: Currency, qty: Decimal, dov: Date):
            self.ccy = ccy
            self.qty = qty
            self.dov = dov
            self.defined = True
            self.undefined = False

        def is_equal(self, other: Any) -> bool:
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov

        def as_boolean(self) -> bool:
            return bool(self.qty)

        def as_float(self) -> float:
            return float(self.qty)

        def as_integer(self) -> int:
            return int(self.qty)


# Generated at 2022-06-21 20:28:32.176524
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    '''
    Unit test for method __neg__ of class Price
    '''
    assert Price.of(ccy=Currency.USD, qty=Decimal(2), dov=Date(2018, 1, 1)) == -Price.of(ccy=Currency.USD, qty=Decimal(-2), dov=Date(2018, 1, 1))
    assert Price.of(ccy=Currency.USD, qty=Decimal(2), dov=Date(2018, 1, 1)) != -Price.of(ccy=Currency.USD, qty=Decimal(3), dov=Date(2018, 1, 1))

# Generated at 2022-06-21 20:28:35.723095
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    assert NonePrice.round() == NonePrice
    assert NonePrice.round(0) == NonePrice
    try:
        NonePrice.round(3)
        assert False
    except Exception as exc:
        assert isinstance(exc, TypeError)

# Generated at 2022-06-21 20:28:40.333650
# Unit test for method __gt__ of class NonePrice
def test_NonePrice___gt__():
    # Silence pytest warning:
    #    Unit tests for the NonePrice __gt__ method
    #    -------------------------------------------
    #
    #        This function does not have any assertions.
    #        Consider adding assertions to this function.
    #
    #    See https://docs.pytest.org/en/stable/warnings.html#missing-assert
    #
    # This method is purposely written so as it has no assertions.
    pass

# Generated at 2022-06-21 20:28:41.898823
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    ## Initialise expected value
    expected = Money()

    ## Verify value
    assert expected == Money()

# Generated at 2022-06-21 20:28:52.899330
# Unit test for method __round__ of class Price
def test_Price___round__():
    with testcase.TestCase() as suite:
        suite.assertTrue(Price.of(CCY, Decimal("10"), DOV).__round__() == 10.0)
        suite.assertTrue(Price.of(CCY, Decimal("10.56"), DOV).__round__() == 11.0)
        suite.assertTrue(Price.of(CCY, Decimal("10"), DOV).__round__(0) == 10.0)
        suite.assertTrue(Price.of(CCY, Decimal("10.56"), DOV).__round__(0) == 11.0)
        suite.assertTrue(Price.of(CCY, Decimal("10"), DOV).__round__(1) == 10.0)

# Generated at 2022-06-21 20:28:56.960451
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    # Test implementation of __bool__ method of Price
    x = Price(None)
    assert bool(x) is True
    assert x.defined == True
    assert x.undefined == False
    assert x.ccy == None
    assert x.qty == None
    assert x.dov == None

# Generated at 2022-06-21 20:29:10.976208
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    c_usd = Currency.find("USD")
    c_cny = Currency.find("CNY")
    fx = FXRateService.default
    m_usd = SomeMoney(c_usd, Decimal('123.45'), Date(2018, 9, 6))
    assert m_usd.convert(c_usd, Date(2018, 9, 6)) == m_usd
    m_cny = m_usd.convert(c_cny, Date(2018, 9, 6))
    assert m_cny.ccy == c_cny
    assert m_cny.qty == Decimal('865.6095300797')
    assert m_cny.dov == Date(2018, 9, 6)




# Generated at 2022-06-21 20:29:21.122283
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    from beancount.core import data

    inpt_ccy = Currency("USD")
    inpt_qty = Decimal("15.00")
    inpt_dov = Date(2020, 5, 4)

    inpt_money = Money(inpt_ccy, inpt_qty, inpt_dov)
    inpt_price = Price.of(inpt_ccy, inpt_qty, inpt_dov)

    # Test for Money
    assert (-inpt_money).ccy == inpt_ccy
    assert (-inpt_money).qty == -inpt_qty
    assert (-inpt_money).dov == inpt_dov

    # Test for Price
    assert (-inpt_price).ccy == inpt_ccy
    assert (-inpt_price).q

# Generated at 2022-06-21 20:29:26.973253
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():

    assert SomePrice(JPY, 50, date(2018, 1, 1)).with_dov(date(2018, 1, 1)) == SomePrice(JPY, 50, date(2018, 1, 1))
    assert SomePrice(JPY, 50, date(2018, 1, 1)).with_dov(date(2018, 1, 2)) == SomePrice(JPY, 50, date(2018, 1, 2))

    return True

test_SomePrice_with_dov()


# Generated at 2022-06-21 20:29:31.670564
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    assert SomePrice(USD, 1, today).as_boolean() is True
    assert SomePrice(USD, 0, today).as_boolean() is False
    assert SomePrice(USD, 0, today).as_boolean() is False

# Generated at 2022-06-21 20:31:29.734213
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    pass

# Generated at 2022-06-21 20:31:34.133593
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    from .currencies import Currency

    ccy1 = Currency.USD
    ccy2 = Currency.RUB
    operation = "SUM"
    err = IncompatibleCurrencyError(ccy1, ccy2, operation)
    assert f"{ccy1.code} vs {ccy2.code} are incompatible for operation '{operation}'." == err.args[0]
    assert ccy1 == err.ccy1
    assert ccy2 == err.ccy2
    assert operation == err.operation


# Generated at 2022-06-21 20:31:36.173918
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    n = NonePrice()
    assert n.__int__() == 0

# Generated at 2022-06-21 20:31:38.377665
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    assert abs(NoPrice.positive()) == abs(NoPrice.negative())

# Generated at 2022-06-21 20:31:47.704851
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():
    from datetime import date
    from .currency import EUR
    from .money import NoMoney
    from .money import SomeMoney
    from .price import Price
    
    assert NoMoney <= Price(SomeMoney(ccy=EUR, qty=Decimal('-10'), dov=date(2019, 6, 21)), ratio=Decimal('1')) is False
    assert Price(SomeMoney(ccy=EUR, qty=Decimal('-10'), dov=date(2019, 6, 21)), ratio=Decimal('1')) <= NoMoney is True
    assert Price(SomeMoney(ccy=EUR, qty=Decimal('0'), dov=date(2019, 6, 21)), ratio=Decimal('1')) <= NoMoney is True

# Generated at 2022-06-21 20:31:52.513037
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    _ = Money.NA
    _ = SomeMoney(Currency.USD, Decimal("1.0"), Date(2019, 1, 1))
    _ = SomeMoney(Currency.USD, Decimal("-1.0"), Date(2019, 1, 1))
    return None


# Generated at 2022-06-21 20:31:54.020140
# Unit test for method __neg__ of class NoneMoney
def test_NoneMoney___neg__():
    n = NoneMoney
    assert n.__neg__() == n



# Generated at 2022-06-21 20:31:58.982058
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    ccy1 = Currency("USD")
    ccy2 = Currency("USD")
    ccy3 = Currency("EUR")
    op = "I.ADD"
    assert IncompatibleCurrencyError(ccy1, ccy2, operation=op)
    assert IncompatibleCurrencyError(ccy1, ccy3, operation=op)


# Generated at 2022-06-21 20:31:59.615485
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    pass

# Generated at 2022-06-21 20:32:10.297930
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    assert Money.of("USD", Decimal("15.0"), Date("2018-01-01")) // Decimal("3.0") == Money.of("USD", Decimal("5.0"), Date("2018-01-01"))
    assert Money.of("USD", Decimal("15.0"), Date("2018-01-01")) // 3.0 == Money.of("USD", Decimal("5.0"), Date("2018-01-01"))
    assert Money.of("USD", Decimal("15.0"), Date("2018-01-01")) // 3 == Money.of("USD", Decimal("5.0"), Date("2018-01-01"))
    assert Money.of("USD", Decimal("15.0"), Date("2018-01-01")) // Money.of("USD", Decimal("3.0"), Date("2018-01-01")) == Money