

# Generated at 2022-06-21 20:25:06.334848
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    aMoney = Money.of('ABC', Decimal(123), Date.today())
    assert aMoney.__abs__() == aMoney

    aMoney2 = Money.of('ABC', Decimal(-123), Date.today())
    assert aMoney2.__abs__() == Money.of('ABC', Decimal(123), Date.today())

# Generated at 2022-06-21 20:25:15.508756
# Unit test for method __neg__ of class SomeMoney
def test_SomeMoney___neg__():
    from xbbg.core.money import SomeMoney, NoMoney
    from xbbg.core.currency import Currency
    from xbbg.core.date import Date
    from xbbg.core.decimal import Decimal
    from xbbg.core.globals import FXRateService

    assert SomeMoney(Currency("USD"), Decimal("2.5"), Date("2019-12-30")).__neg__() == SomeMoney(Currency("USD"), Decimal("-2.5"), Date("2019-12-30"))

    assert NoMoney.__neg__() == NoMoney

# Generated at 2022-06-21 20:25:16.625196
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    assert NonePrice() != NonePrice()


# Generated at 2022-06-21 20:25:19.408994
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    ## Test method defined
    assert hasattr(NoneMoney(), '__eq__')
    ## Test type
    assert isinstance(NoneMoney().__eq__, MethodType), \
            'Incorrect type of attribute __eq__ of class NoneMoney'

# Generated at 2022-06-21 20:25:30.284212
# Unit test for method abs of class Money
def test_Money_abs():
    m = NoneMoney.abs()
    assert not m.defined
    assert m.undefined
    assert not m.is_equal(NoneMoney)
    assert m.is_equal(SomeMoney(Currency.of("EUR"), Decimal("0.0"), Date.today()))
    m = SomeMoney(Currency.of("USD"), Decimal("-14.32"), Date.today())
    assert m.defined
    assert not m.undefined
    assert m.qty == Decimal("-14.32")
    assert m.abs().qty == Decimal("14.32")
    assert m.abs().ccy.code == "USD"
    assert m.abs().as_integer() == 14
    assert m.abs().as_float() == 14.32
    assert m.abs().as_boolean() is True
   

# Generated at 2022-06-21 20:25:39.658090
# Unit test for method lte of class Money
def test_Money_lte():
    """
    Test for method lte of class Money
    """
    from .currencies import USD, EUR, GBP
    from .exchange import InMemoryFXRateService
    fxsrv = InMemoryFXRateService({"USD/EUR": 1.25, "USD/GBP": 1.5})
    assert Money.of(USD, 10, None) <= Money.of(USD, 10, None)
    assert Money.of(USD, 10, None) <= Money.of(USD, 20, None)
    assert Money.of(USD, 20, None) >= Money.of(USD, 10, None)
    assert Money.of(USD, 20, None) >= Money.of(USD, 20, None)
    assert Money.of(USD, 10, None) <= Money.of(EUR, 8, None)

# Generated at 2022-06-21 20:25:42.592005
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    a = SomePrice(EUR, Decimal(42), today)
    b = NoPrice
    assert (b.with_qty(Decimal(42)) == a)
    assert (b.with_qty(Decimal(42)) == b)

## Unit test for method with_ccy of class NonePrice

# Generated at 2022-06-21 20:25:45.870399
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert SomePrice(GBP, Decimal("0"), Date.today()).as_boolean() == False
    assert SomePrice(GBP, Decimal("1"), Date.today()).as_boolean() == True
    assert NoPrice.as_boolean() == False


# Generated at 2022-06-21 20:25:57.819860
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    assert Price.of(None, None, None).__abs__() == Price.of(None, None, None)
    assert Price.of(None, Decimal("12.34"), None).__abs__() == Price.of(None, Decimal("12.34"), None)
    assert Price.of(None, Decimal("-12.34"), None).__abs__() == Price.of(None, Decimal("12.34"), None)
    assert Price.of(None, Decimal("0.00"), None).__abs__() == Price.of(None, Decimal("0.00"), None)
    assert Price.of(None, Decimal("-0.00"), None).__abs__() == Price.of(None, Decimal("0.00"), None)

# Generated at 2022-06-21 20:26:00.787636
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    m = Money.of(CAD, 10, Date(2020, 7, 1))
    assert m is not None
    money = m.with_qty(10.1)
    assert money is not None
    assert money.ccy == CAD
    assert money.qty == Decimal("10.10")
    assert money.dov == Date(2020, 7, 1)

# Generated at 2022-06-21 20:26:57.643120
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    # Here we test that when we assert that the price object is less that another price object with 
    # the same currency, the result is as expected, and that when we assert that the price object 
    # is less that another price object with a different currency, the appropriate error is raised.
    c = Currency.of("USD")
    q = Decimal('1.2345')
    d = Date(2000, 1, 1)
    sp1 = SomePrice(c, q, d)
    sp2 = SomePrice(c, q+Decimal('1'), d)
    try:
        assert sp1 < sp2
    except:
        assert True==False, "SomePrice.__lt__(self, price): Failed"

# Generated at 2022-06-21 20:27:08.469296
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    from datetime import date
    from ..models.currency import Currency
    from ..models.money import Money

    money_1 = Money(1.1, Currency.USD, date(2008, 12, 25))
    money_2 = Money(1.1, Currency.USD, date(2008, 12, 25))
    money_3 = Money(1.1, Currency.EUR, date(2008, 12, 25))
    money_4 = Money(1.1, Currency.USD, date(2005, 12, 25))

    assert money_1.__pos__() == money_2
    assert money_1.__pos__() != money_3
    assert money_1.__pos__() != money_4

# Generated at 2022-06-21 20:27:11.045091
# Unit test for method __floordiv__ of class SomeMoney
def test_SomeMoney___floordiv__():
    """
    Tests method __floordiv__ of class SomeMoney.
    """
    ## TODO: Implement test_SomeMoney___floordiv__
    raise SkipTest  # noqa


# Generated at 2022-06-21 20:27:17.060108
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    from .money import Money
    from .currency import Currency
    from .date import Date
    from .fxtrates import FXRateService
    from .money import SomeMoney, NoMoney
    currency = Currency()
    date = Date()
    fxtrates = FXRateService()
    x = NonePrice()
    try:
        NonePrice.times(x, currency, date, fxtrates)
    except Exception:
        from .errors import ProgrammingError
        from .errors import InvalidOperation
        from .errors import DivisionByZero
        from typing import Union, Optional, Any, Callable, Tuple
        from decimal import Decimal
        raise InvalidOperation()

# Generated at 2022-06-21 20:27:24.864295
# Unit test for method __truediv__ of class Money
def test_Money___truediv__():
    # NoneMoney / 2.5 -> NoneMoney
    assert (NoneMoney / 2.5) == NoneMoney

    # SomeMoney(GBP, 3, 12.12.2012) / 2.5 -> SomeMoney(GBP, 1.2, 12.12.2012)
    assert SomeMoney(GBP, 3, Date.from_string("12.12.2012")) / 2.5 == SomeMoney(GBP, 1.2, Date.from_string("12.12.2012"))

    # SomeMoney(GBP, 3, 12.12.2012) / 0.0 -> NoneMoney
    assert SomeMoney(GBP, 3, Date.from_string("12.12.2012")) / 0.0 == NoneMoney

    # SomeMoney(GBP, 3, 12.12.2012) / None -> raises MonetaryOperationException

# Generated at 2022-06-21 20:27:33.057761
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    curr = Currency("GBP")
    mon1 = Money.of(curr, 10, Date.today())
    assert (mon1 / 3).qty == Decimal("3.3333")
    assert (mon1 / 3.0).qty == Decimal("3.3333")
    assert (mon1 / "3.0").qty == Decimal("3.3333")
    assert (mon1 / "3").qty == Decimal("3.3333")
    assert (mon1 / curr).qty == Decimal("10.0000")

# Generated at 2022-06-21 20:27:39.238528
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    assert SomeMoney(EUR, Decimal(), Date()) == NoMoney
    assert SomeMoney(USD, Decimal(), Date()).with_dov(Date()) == NoMoney
    assert SomeMoney(EUR, Decimal(), Date(2019, 1, 1)).with_dov(Date(2020, 1, 1)) == SomeMoney(
        EUR,
        Decimal(),
        Date(2020, 1, 1)
    )
    try:
        SomeMoney(GBP, Decimal(), Date(2019, 1, 1)).with_dov(Date(2020, 1, 1))
    except IncompatibleCurrencyError:
        pass
    else:
        assert False


# Generated at 2022-06-21 20:27:44.382893
# Unit test for method subtract of class Money
def test_Money_subtract():
    from decimal import Decimal
    from .currencies import Currency
    from .dates import Date
    from .money import Money
    from .money import SomeMoney
    from .priced import Price
    from .priced import SomePrice
    
    a1 = Money.of(Currency.of("USD"), Decimal('0.00'), Date.of(2019, 8, 20))
    a2 = Money.of(Currency.of("USD"), Decimal('0.00'), Date.of(2019, 8, 20))
    a3 = a1.subtract(a2)
    assert a3.ccy == Currency.of("USD")
    assert a3.dov == Date.of(2019, 8, 20)
    assert a3.qty == Decimal('0.00')

# Generated at 2022-06-21 20:27:48.903073
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    p1 = SomePrice(Currency("USD"), Decimal("1.5"), Date(2018,1,1))
    p2 = SomePrice(Currency("USD"), Decimal("1.5"), Date(2018,1,1))
    p3 = SomePrice(Currency("USD"), Decimal("1.5"), Date(2018,1,1))
    assert p1.scalar_add(1) == p2 == p3


# Generated at 2022-06-21 20:27:53.148469
# Unit test for method abs of class Price
def test_Price_abs():
    with raises(NotImplementedError):
        Price.NA.abs()

# Generated at 2022-06-21 20:29:40.078800
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    assert Price.of(None, None, None).__pos__() is NonePrice
    assert Price.of("USD", None, None).__pos__() is NonePrice
    assert Price.of(None, Decimal("0.0"), None).__pos__() is NonePrice
    assert Price.of(None, Decimal("0.0"), date(2017, 2, 27)).__pos__() is NonePrice

    assert Price.of("USD", Decimal("0.0"), None).__pos__() is NonePrice
    assert Price.of("USD", Decimal("0.0"), date(2017, 2, 27)).__pos__() is NonePrice

    assert Price.of(None, Decimal("1.0"), None).__pos__() is NonePrice

# Generated at 2022-06-21 20:29:43.009870
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    amt = SomeMoney(USD, Decimal(100), Date(2018, 5, 9))
    assert amt == SomeMoney(USD, Decimal(100), Date(2018, 5, 9))



# Generated at 2022-06-21 20:29:43.652937
# Unit test for method scalar_subtract of class NoneMoney
def test_NoneMoney_scalar_subtract():
    pass

# Generated at 2022-06-21 20:29:48.889006
# Unit test for method __neg__ of class SomePrice
def test_SomePrice___neg__():
    c = Currency.get("EUR")
    q = Decimal("100.00")
    d = Date.today()
    price = SomePrice(c, q, d)
    retval = price.__neg__()
    assert retval.ccy == c
    assert retval.qty == -q
    assert retval.dov == d



# Generated at 2022-06-21 20:29:54.553914
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    from pytest import raises
    from .money import NoneMoney
    nm = NoneMoney()
    with raises(TypeError) as excinfo:
        _ = int(nm)
    assert excinfo.value.args == ("Undefined monetary values do not have quantity information.",)

# Generated at 2022-06-21 20:30:03.368240
# Unit test for method with_dov of class SomePrice
def test_SomePrice_with_dov():
    from pybaseball.baseball_statistics import statcast_pitcher
    from pybaseball.baseball_reference_scraper import pitching_stats
    from pybaseball.lahman import *
    from pybaseball.retrosheet import *
    from pybaseball.fangraphs import *
    from pybaseball.config import *
    from pybaseball.statcast import *
    from pybaseball.bbref import *
    from pybaseball.outs import *

    SomePrice(None, None, None).with_dov(None)

# Generated at 2022-06-21 20:30:15.862512
# Unit test for method lte of class Money
def test_Money_lte():
    mon1 = Money.of(ccy = "USD", qty = 1, dov = "2019-01-01")
    mon2 = Money.of(ccy = "USD", qty = 2, dov = "2019-01-01")
    mon3 = Money.of(ccy = "JPY", qty = 1, dov = "2019-01-01")
    mon4 = Money.of(ccy = "USD", qty = 1, dov = "2019-01-02")
    mon5 = some_money(ccy = "USD", qty = 2, dov = "2019-01-01")
    mon6 = some_money(ccy = "JPY", qty = 1, dov = "2019-01-01")

# Generated at 2022-06-21 20:30:26.950104
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    import hypothesis.strategies as st

    @given(st.data())
    def test(data):
        ccy = data.draw(money.ccy)
        qty = data.draw(money.qty(ccy))
        dov = data.draw(money.dov)

# Generated at 2022-06-21 20:30:28.606212
# Unit test for method multiply of class Money
def test_Money_multiply():
    Test.assert_equals(SomeMoney(EUR, Decimal("100"), Date.today()).multiply(2), SomeMoney(EUR, Decimal("200"), Date.today()))



# Generated at 2022-06-21 20:30:39.110574
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():

    ## Default of class SomePrice
    s = SomePrice(ccy=Currency(ccy="A"), qty=Decimal(1), dov=Date(year=2019, month=1, day=1))

    ## Test for equality
    assert (s <= s) is True

    ## Test for less than
    assert (s <= SomePrice(ccy=Currency(ccy="A"), qty=Decimal(2), dov=Date(year=2019, month=1, day=1))) is True
    assert (s <= SomePrice(ccy=Currency(ccy="A"), qty=Decimal(1), dov=Date(year=2019, month=2, day=1))) is True

# Generated at 2022-06-21 20:31:11.826008
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    o = SomeMoney(Currency('USD'),Decimal('100.00'),Date(1,1,1))
    try:
        o / Decimal('0.00')
        assert False
    except Exception as e:
        assert isinstance(e, DivisionByZero)
        assert str(e) == \
            "SomeMoney(ccy=Currency('USD'), qty=Decimal('100.00'), dov=Date(1, 1, 1)) / Decimal('0.00') failed: Division by zero"
    o = SomeMoney(Currency('USD'),Decimal('100.00'),Date(1,1,1))
    try:
        o / Decimal('0')
        assert False
    except Exception as e:
        assert isinstance(e, DivisionByZero)

# Generated at 2022-06-21 20:31:22.087276
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    assert Price.of(ccy="USD", qty=10.0, dov=Date.today()) + 1 == Price.of(ccy="USD", qty=11.0, dov=Date.today())
    assert Price.of(ccy="EUR", qty=10.0, dov=Date.today()) + 1.0 == Price.of(ccy="EUR", qty=11.0, dov=Date.today())
    assert Price.of(ccy="USD", qty=10.0, dov=Date.today()) + Decimal(1) == Price.of(ccy="USD", qty=11.0, dov=Date.today())

# Generated at 2022-06-21 20:31:24.891412
# Unit test for method as_float of class Price
def test_Price_as_float():
    #Test for undefined price
    assert NoPrice.as_float() == 0
    #test for defined price
    assert SomePrice(USD, 1, dt.date.today()).as_float() == 1

# Generated at 2022-06-21 20:31:28.774278
# Unit test for method __gt__ of class SomeMoney
def test_SomeMoney___gt__():
    assert SomeMoney(Currency("USD"), Decimal("10.00"), asof("2019-01-01")) > SomeMoney(Currency("USD"), Decimal("10.00"), asof("2019-01-01"))



# Generated at 2022-06-21 20:31:33.951133
# Unit test for method scalar_add of class Money
def test_Money_scalar_add():
    print()
    print(format(test_Money_scalar_add.__name__, '^40s'))
    ccy1 = Currency.of('USD')
    m = Money.of(ccy1, Decimal('100.00'), Date.today())
    m += Decimal('10')
    print(format('m: ', '<20s'), format(m, '>20s'))
    assert m == Money.of(ccy1, Decimal('110.00'), Date.today())



# Generated at 2022-06-21 20:31:39.317723
# Unit test for constructor of class Money
def test_Money():
    d = Decimal("1234567.89")
    c = Currency("TRY")
    v = Date("2019-01-01")
    x = Money.of(c,d,v)
    assert(isinstance(x, Money))
    return



# Generated at 2022-06-21 20:31:43.749230
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    assert (SomePrice(Currency.USD, Decimal(10), Date(2013, 1, 1)) + Decimal(100)) == SomePrice(Currency.USD,
                                                                                                 Decimal(110),
                                                                                                 Date(2013, 1, 1))

# Generated at 2022-06-21 20:31:47.089281
# Unit test for method negative of class Money
def test_Money_negative():
    time = Date(year=2019, month=4, day=2)
    ccy = Currency.usd()
    qty = Decimal(25)
    m1 = Money.of(ccy, qty, time)
    assert m1.negative().qty == -25

# Generated at 2022-06-21 20:31:58.902171
# Unit test for method subtract of class Money
def test_Money_subtract():
    '''
    test for subtract of class Money
    '''
    USD = Currency.of("USD")
    EUR = Currency.of("EUR")

    # Tests with USD.
    USD_1 = USD.money(100, "2018-01-01")
    USD_2 = USD.money(200, "2018-02-01")
    USD_3 = USD.money(0, "2018-03-01")
    assert USD_1.subtract(USD_1) == USD.money(0, "2018-01-01")
    assert USD_1.subtract(USD_2) == USD.money(-100, "2018-01-01")
    assert USD_1.subtract(USD_3) == USD.money(100, "2018-01-01")

# Generated at 2022-06-21 20:32:02.049716
# Unit test for method add of class Money
def test_Money_add():
    money1 = SomeMoney(ccy=Currency.EUR, qty=Decimal("0.50"), dov=Date.today())
    money2 = SomeMoney(ccy=Currency.USD, qty=Decimal("0.25"), dov=Date.today())
    assert money1.ccy != money2.ccy
    with pytest.raises(IncompatibleCurrencyError):
        money1.add(money2)
    assert money1.add(money2) == IncompatibleCurrencyError
