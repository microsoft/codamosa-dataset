

# Generated at 2022-06-21 20:25:30.547705
# Unit test for method round of class Price
def test_Price_round():
    """
    Test method round of class Price
    """
    price = Price.of(Currency.USD, Decimal("2.34"), Date.now())
    assert price.round(2) == Price.of(Currency.USD, Decimal("2.34"), Date.now())
    assert price.round(1) == Price.of(Currency.USD, Decimal("2.3"), Date.now())
    assert price.round(0) == Price.of(Currency.USD, Decimal("2"), Date.now())
    assert price.round() == Price.of(Currency.USD, Decimal("2"), Date.now())
    assert price.round(ndigits=None) == Price.of(Currency.USD, Decimal("2"), Date.now())

# Generated at 2022-06-21 20:25:35.261662
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    ## Arrange ##
    money = SomeMoney(ccy=EUR, qty=Decimal("1234.5678"), dov=Date(2017, 1, 1))

    ## Act ##
    f = money.__float__()

    ## Assert ##
    assert f == 1234.5678



# Generated at 2022-06-21 20:25:42.652172
# Unit test for method gte of class Price
def test_Price_gte():
    Price.NA = Price.of('USD', 5.0, '2012-01-01')
    Price.NA = Price.of('USD', 0, '2012-01-01')
    
    
    
    # Test if two equal price objects are equal
    price_1 = Price.of('GBP', 10.0, '2019-01-01')
    price_2 = Price.of('GBP', 10.0, '2019-01-01')
    assert price_1 == price_2
    assert price_1.gte(price_2) == True
    assert price_2.gte(price_1) == True
        
    # Test for different currencies
    
    price_3 = Price.of('EUR', 10.0, '2019-01-01')
    assert price_1 == price_3
    #assert

# Generated at 2022-06-21 20:25:47.829814
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    qty = Decimal('10')
    p1 = SomePrice('USD',qty,today())
    p2 = p1.scalar_add(1)
    assert p2.qty == qty + 1
    assert p2.dov == today()
    assert p2.ccy.code == 'USD'


# Generated at 2022-06-21 20:25:51.711097
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    assert Price.of(USD, Decimal("1.0"), Date(2018, 1, 1)).with_ccy(EUR) == Price.of(EUR, Decimal("1.0"), Date(2018, 1, 1))


# Generated at 2022-06-21 20:25:54.182081
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    s = SomeMoney(USD, Decimal(10), Date(1, 1, 1))
    assert s - s == NoMoney
    assert s - NoMoney == s
    assert NoMoney - s == NoMoney

    s2 = SomeMoney(EUR, Decimal(10), Date(1, 1, 1))
    with raises(IncompatibleCurrencyError):
        s - s2



# Generated at 2022-06-21 20:25:56.252095
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    # Given
    ccy = Currency("EUR")
    qty = 1.234
    dov = Date(2017, 1, 1)
    mon = SomeMoney(ccy, qty, dov)

    # When
    mon2 = mon.with_dov(dov)

    # Then
    assert mon is mon2



# Generated at 2022-06-21 20:26:01.109116
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    # When
    actual = SomePrice(CAD, Decimal("100.11"), date(2019, 1, 1)).__pos__()

    # Then
    assert actual == SomePrice(CAD, Decimal("100.11"), date(2019, 1, 1))

# Generated at 2022-06-21 20:26:06.290541
# Unit test for method multiply of class Price
def test_Price_multiply():
    somePrice = SomePrice(Euro, 2.5, Date(2018, 9, 15))
    result_1 = somePrice * 2
    result_2 = somePrice * decimal.Decimal(2)
    assert result_1.ccy == Euro
    assert result_1.qty == 5
    assert result_2.ccy == Euro
    assert result_2.qty == 5


# Generated at 2022-06-21 20:26:07.205691
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    # Python
    pass

# Generated at 2022-06-21 20:26:58.940893
# Unit test for method lt of class Money
def test_Money_lt():
    # Set tests for Money class lt method
    # Given
    m1 = Money.of(Currency.of("EUR"), Decimal("10.49"), Date(2020, 5, 25))
    m2 = Money.of(Currency.of("EUR"), Decimal("10.50"), Date(2020, 5, 25))

    # Then
    assert m1.lt(m2)

# Generated at 2022-06-21 20:26:59.550442
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract(): pass

# Generated at 2022-06-21 20:27:11.537401
# Unit test for method __eq__ of class NoneMoney
def test_NoneMoney___eq__():
    """
    Tests the method `__eq__` of class `NoneMoney`
    """
    ## Test OK case:
    assert NoneMoney.__eq__(NoneMoney(), NoneMoney())
    assert Money.of(ccy=None, qty=None, dov=None).__eq__(NoneMoney())

    ## Test KO cases:
    assert not NoneMoney.__eq__(NoneMoney(), Money.of(ccy=None, qty=None, dov=None))
    assert not NoneMoney.__eq__(NoneMoney(), Money.of(ccy=None, qty=None, dov=Date.today()))
    assert not NoneMoney.__eq__(NoneMoney(), Money.of(ccy=Currency.USD, qty=None, dov=None))

# Generated at 2022-06-21 20:27:14.463559
# Unit test for method as_float of class Price
def test_Price_as_float():
    assert Price.NA.as_float() == Decimal('0.0')
    assert Price(CurrencyISO.USD, Decimal('1.0'), '2008-09-12').as_float() == Decimal('1.0')



# Generated at 2022-06-21 20:27:16.011585
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    ## Arrange ##
    ## Act ##
    res = abs(NoMoney)
    ## Assert ##
    assert res is NoMoney


# Generated at 2022-06-21 20:27:17.696150
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    instance = NonePrice()

    try:
        int(instance)
        raise AssertionError("Unexpected invocation!")
    except TypeError:
        pass
    pass



# Generated at 2022-06-21 20:27:25.776477
# Unit test for method convert of class Money
def test_Money_convert():
    cad=Currency('CAD',datetime.datetime.utcnow())
    chf=Currency('CHF',datetime.datetime.utcnow())
    usd=Currency('USD',datetime.datetime.utcnow())
    january=Date(year=2019,month=1,day=1)
    february=Date(year=2019,month=2,day=1)
    march=Date(year=2019,month=3,day=1)
    april=Date(year=2019,month=4,day=1)
    may=Date(year=2019,month=5,day=1)
    june=Date(year=2019,month=6,day=1)
    july=Date(year=2019,month=7,day=1)

# Generated at 2022-06-21 20:27:29.816032
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    assert 0 == (0).__pos__()
    assert +123 == (+123).__pos__()
    assert -123 == (-123).__pos__()

# Generated at 2022-06-21 20:27:35.895847
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    from .money import Money
    from .price import Price
    from moneypy.money import Money as Money2
    from moneypy.price import Price as Price2
    m = Money.of(ccy=Currency('USD'), value=Decimal(1))
    p = Price.of(ccy=Currency('USD'), qty=Decimal(1), dov=Date(1990, 1, 1))
    assert type(m + p) is Money2
    assert type(p + m) is Price2

# Generated at 2022-06-21 20:27:38.060614
# Unit test for method convert of class Money
def test_Money_convert():
    m = Currency("USD").money(10.0)
    m = m.convert("EUR")
    assert m == Currency("EUR").money(round(10.0 / 1.13, 2))


# Generated at 2022-06-21 20:28:12.031330
# Unit test for method __le__ of class Money
def test_Money___le__():
    assert SomeMoney(Currency(code="USD"), Decimal("1"), Date.today()) <= SomeMoney(Currency(code="USD"), Decimal("1"), Date.today())
    assert SomeMoney(Currency(code="USD"), Decimal("0"), Date.today()) <= SomeMoney(Currency(code="USD"), Decimal("1"), Date.today())
    assert NoMoney <= SomeMoney(Currency(code="USD"), Decimal("1"), Date.today())
    assert SomeMoney(Currency(code="USD"), Decimal("1"), Date.today()) <= NoMoney

# Generated at 2022-06-21 20:28:13.712530
# Unit test for constructor of class Money
def test_Money():
    try:
        m = Money.of(Currency.of("XTS"), Decimal(1.0), Date.today())
        assert m is not None
    except ProgrammingError as e:
        print("test_Money Passed")



# Generated at 2022-06-21 20:28:15.439943
# Unit test for method negative of class Price
def test_Price_negative():
    # Test whether Price.negative(self) works as intended
    return



# Generated at 2022-06-21 20:28:17.501618
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    # Testing NonePrice object of quantity 2 and currency USD
    assert NonePrice().with_qty(Decimal(2)) == NoPrice


# Generated at 2022-06-21 20:28:18.096827
# Unit test for constructor of class NonePrice
def test_NonePrice():
    assert NonePrice()



# Generated at 2022-06-21 20:28:30.628553
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    """
    Unit test for method __eq__ of class Price.
    """

    # |==============================|
    # | Case 1: Equality in action.  |
    # |==============================|

    some_price_1 = Price.of(Currency("USD"), Decimal("1000"), Date.today())
    some_price_2 = Price.of(Currency("USD"), Decimal("1000"), Date.today())

    assert some_price_1 == some_price_2


    # |==============================|
    # | Case 2: Inequality in action.|
    # |==============================|

    some_price_1 = Price.of(Currency("USD"), Decimal("1000"), Date.today())
    some_price_2 = Price.of(Currency("USD"), Decimal("1001"), Date.today())


# Generated at 2022-06-21 20:28:39.939732
# Unit test for method lte of class Money
def test_Money_lte():
    from .currencies import EUR, USD
    from .exchange import FXRateService
    from .money import Money, SomeMoney, NoMoney
    from .zeitgeist import Date
    from .commons.contracts import check_isinstance
    from .commons.numbers import Numeric

    fx = FXRateService({(EUR, USD): 1.6, (USD, EUR): 0.63})  # type: FXRateService
    today = Date.today()  # type: Date

    m1 = Money.of(EUR, 10, today)
    m2 = Money.of(EUR, 10, today)
    assert m1.lte(m2)
    assert m2.lte(m1)

    m3 = Money.of(EUR, 10, today)

# Generated at 2022-06-21 20:28:46.379934
# Unit test for method abs of class Money
def test_Money_abs():
    """
    Tests method abs of class Money
    """
    test_case = [
        {"obj": Money.of(Currency.USD, Decimal("100.05"), Date.today()), "expected": 100.05},
        {"obj": Money.of(Currency.USD, Decimal("100.05"))},
        # {"obj": Money.of(Currency.USD, Decimal("100.05"), Date.today()), "expected": -100.05},
        # {"obj": Money.of(Currency.USD, Decimal("100.05"), Date.today()), "expected": -100.05},
    ]

    for case in test_case:
        if "expected" in case:
            assert case["obj"].abs() == case["expected"]

# Generated at 2022-06-21 20:28:57.458133
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__():
    from .datetimes import DateTime
    from .money import Money
    Mon1 = Money.of("SGD", 1, DateTime.now().date_value)
    Mon2 = Money.of("SGD", 2, DateTime.now().date_value)
    Mon3 = Money.of("SGD", 3, DateTime.now().date_value)
    assert (Mon1 / 2) == Mon2
    assert (Mon1 / 2.0) == Mon2
    assert (Mon1 / Decimal(2)) == Mon2
    assert (Mon1 / Mon2) == 0.5

    assert (Mon2 / 2) == Mon3
    assert (Mon2 / 2.0) == Mon3
    assert (Mon2 / Decimal(2)) == Mon3
    assert (Mon2 / Mon3) == 0.6666666666666666
    # Unit

# Generated at 2022-06-21 20:29:11.438867
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    from .currencies import USD, GBP
    from .dates import Date
    from .exchange import FXRateServiceStub
    from .money import Money

    assert SomeMoney(GBP, 1.23, Date(2020, 1, 1)) < SomeMoney(GBP, 3.21, Date(2020, 1, 1))
    assert SomeMoney(GBP, 1.23, Date(2020, 1, 1)) < SomeMoney(USD, 1.23, Date(2020, 1, 1))
    assert not Money.NA < USD(1.23, Date(2020, 1, 1))
    assert not Money.NA < Money.NA
    assert not SomeMoney(GBP, 1.23, Date(2020, 1, 1)) < USD(1.23, Date(2020, 1, 1))

# Generated at 2022-06-21 20:30:49.195709
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    """
    Tests the method __mul__ overloading
    """

    ## Create local scope:
    usd = FXRateService.default.implementations[0].get_fxccy("USD")

    ## Create some test data:
    money = SomeMoney(usd, 100, Date.today())

    ## These should be fine:
    money * 10
    10 * money
    money * 10.0
    10.0 * money
    money * 10.1
    10.1 * money
    money * 10.01
    10.01 * money
    money * 10.001
    10.001 * money
    money * 10.0001
    10.0001 * money
    money * 10.00001
    10.00001 * money

    ## These should fail:

# Generated at 2022-06-21 20:31:00.542148
# Unit test for method add of class Price
def test_Price_add():
    assert Price.of(USD, 100, date(2013, 12, 31)).add(Price.of(USD, 100, date(2013, 12, 31))).qty == 200
    assert Price.of(USD, 100, date(2013, 12, 31)).add(Price.of(USD, 100, date(2013, 12, 31))).dov == date(2013, 12, 31)
    assert Price.of(USD, 100, date(2013, 12, 31)).add(Price.of(USD, 100, date(2013, 12, 30))).dov == date(2013, 12, 31)
    assert Price.of(USD, 100, date(2013, 12, 30)).add(Price.of(USD, 100, date(2013, 12, 31))).dov == date(2013, 12, 31)

# Generated at 2022-06-21 20:31:09.740995
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    import decimal
    import datetime
    from pyk.model import Price
    for p in Price.of(None, None, None), Price.of('USD', None, None), Price.of('USD', decimal.Decimal('0'), None), Price.of('USD', None, datetime.date(2017, 1, 1)), Price.of('USD', decimal.Decimal('0'), datetime.date(2017, 1, 1)):
        assert p * 1 == p
        assert p * decimal.Decimal('0') == p
        assert p * 0 == p
        assert p * 0.0 == p
        assert 1 * p == p
        assert decimal.Decimal('0') * p == p
        assert 0 * p == p
        assert 0.0 * p == p
    print("Passed all tests for Price.__mul__")



# Generated at 2022-06-21 20:31:20.662751
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    import datetime
    from dataclasses import dataclass
    from decimal import Decimal
    from .currencies import Currency
    from .exchange import FXRateService
    from .models import Money

    @dataclass
    class DummyFXRateService(FXRateService):
        def get(self, _from: Currency, to: Currency, asof: datetime.date) -> Decimal:
            return Decimal(1)

    money1 = Money.of(Currency.USD, Decimal(100), datetime.date.today())
    money2 = Money.of(Currency.USD, Decimal(100), datetime.date.today())
    assert money1.__sub__(money2) == Money.of(Currency.USD, Decimal('0'), datetime.date.today())


# Generated at 2022-06-21 20:31:26.018073
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    from finpy.constants import GBP
    from decimal import Decimal
    from datetime import date
    obj = Money.of(GBP, Decimal(5), date(2020, 8, 1))
    try:
        assert obj.__class__.__name__ == 'SomeMoney'
    except:
        print('SomeMoney constructor is incorrect')


# Generated at 2022-06-21 20:31:27.408831
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    # TODO: What are you going to do?
    pass


# Generated at 2022-06-21 20:31:30.691536
# Unit test for method gt of class Price
def test_Price_gt():
    assert NoPrice > NoPrice
    assert NoPrice > SomePrice(CCY.USD, Decimal(1), Date.now())    
    assert SomePrice(CCY.USD, Decimal(1), Date.now()) > NoPrice

# Generated at 2022-06-21 20:31:34.373456
# Unit test for method __truediv__ of class NoneMoney
def test_NoneMoney___truediv__():
    """Test __truediv__ method of class NoneMoney."""

    ## Arrange:
    m = Money()

    ## Act:
    r1 = (m / 42)
    r2 = (42 / m)

    ## Assert:
    assert isinstance(r1, Money) and r1.undefined
    assert isinstance(r2, Money) and r2.undefined


# Generated at 2022-06-21 20:31:39.318098
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    """
    Test the constructor of class NoneMoney
    """
    temp = NoneMoney()
    print("Test NoneMoney: ", temp)
    assert temp is not None
    assert issubclass(temp.__class__, Money)


# Generated at 2022-06-21 20:31:40.694826
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    pass


## Define a price type.