

# Generated at 2022-06-21 20:25:20.877409
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    # Test that the round method of NoneMoney works as expected.

    # Test case 1:
    assert round(NoMoney) == NoMoney

    # Test case 2:
    assert round(NoMoney, -5) == NoMoney

    # Test case 3:
    assert round(-NoMoney) == NoMoney


# Generated at 2022-06-21 20:25:31.277977
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    ccy = Currency.usd()
    m1 = Money.of(ccy, Decimal('1'), Date(2019, 1, 1))
    m2 = Money.of(ccy, Decimal('2'), Date(2019, 1, 1))
    assert m1 < m2
    assert not m1 > m2
    assert not m2 < m1
    assert m2 > m1

    m3 = Money.of(ccy, Decimal('2'), Date(2018, 1, 1))
    assert m1 < m2
    assert not m1 > m2
    assert not m2 < m1
    assert m2 > m1

    m2 = Money.of(ccy, Decimal('1'), Date(2019, 1, 1))
    assert not m1 < m2
    assert not m1 > m2

# Generated at 2022-06-21 20:25:40.220820
# Unit test for method positive of class Money
def test_Money_positive():
    from .currencies import USD, EUR, TRY
    from .money import Money
    from .commons.zeitgeist import Date
    from .commons.numbers import Decimal
    from .time import days
    from decimal import Decimal
    assert Money.of(USD,1,None)==Money(USD, Decimal('1'), None)
    assert Money.of(EUR,-1,None)==Money(EUR, Decimal('-1'), None)
    assert Money.of(TRY,0,None)==Money(TRY, Decimal('0'), None)
    assert Money.of(None,0,None)==Money(None, Decimal('0'), None)
    assert Money.of(USD,1,None).positive()==Money(USD, Decimal('1'), None)

# Generated at 2022-06-21 20:25:45.973986
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    from datetime import date
    from .types import Currency
    from .types import Decimal
    from .types import NA
    from .types import Date

    assert SomePrice(Currency("USD"), Decimal("7.0"), Date(2019, 3, 1)).__int__() == 7
    assert SomePrice(Currency("USD"), Decimal("7.5"), Date(2019, 3, 1)).__int__() == 7
    assert SomePrice(Currency("USD"), Decimal("8.5"), Date(2019, 3, 1)).__int__() == 8
    assert abs(SomePrice(Currency("USD"), Decimal("-8.5"), Date(2019, 3, 1))) == SomePrice(Currency("USD"), Decimal(
        "8.5"), Date(2019, 3, 1))

# Generated at 2022-06-21 20:25:46.870041
# Unit test for constructor of class NonePrice
def test_NonePrice():
    NonePrice()

NoPrice = NonePrice()


# Generated at 2022-06-21 20:25:58.752378
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    from .currencies import USD, TRY
    from .exchange import ExchangeRateSystem, FXRateType
    from .zeitgeist import now
    import pytest
    from datetime import datetime

    rate_system = ExchangeRateSystem(
        {
            FXRateType.Spot: {
                (USD, TRY): (datetime(2020, 1, 1), 2.0),
            },
        },
        None
    )

    assert Money.of(USD, 1.0, now()) == Money.of(USD, 1.0, now())
    assert Money.of(USD, 1.0, now()) != Money.of(USD, 2.0, now())
    assert Money.of(USD, 1.0, now()) != Money.of(TRY, 1.0, now())


# Generated at 2022-06-21 20:26:04.688849
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    NoneMoney().with_dov(Date(2020, 2, 20))
    NoneMoney().with_dov('2020-02-20')
    NoneMoney().with_dov(20200220)
    NoneMoney().with_dov(date(2020, 2, 20))
    NoneMoney().with_dov(datetime(2020, 2, 20, 3, 5))


# Generated at 2022-06-21 20:26:08.312623
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    price = Price.of(Currency.of('USD'), Decimal(1), Date.today())

    # scalar multiplication
    assert price * Decimal('1.23') == Price.of(Currency.of('USD'), Decimal(1.23), Date.today())

test_Price___mul__()

# Generated at 2022-06-21 20:26:20.056732
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    """
    Test if method SomePrice.__gt__ is working as expected.
    """

# Generated at 2022-06-21 20:26:32.101681
# Unit test for method subtract of class Money
def test_Money_subtract():
    """
    Unit test for method subtract of class Money.
    """
    USD = Currency.of("USD")
    EUR = Currency.of("EUR")

    assert Money.of(USD, 1, Date.today()).subtract(Money.of(USD, 1, Date.today())).is_equal(
        Money.of(USD, 0, Date.today())
    )  # type: ignore

    assert Money.of(USD, 1, Date.today()).subtract(Money.of(USD, 1, Date.today() + 1)).is_equal(
        Money.of(USD, 0, Date.today() + 1)
    )  # type: ignore


# Generated at 2022-06-21 20:27:13.454159
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    """Unit test for method ``__pos__`` of class ``Price``."""
    price = Price.NA
    assert price.__pos__() == Price.NA

    price = Price.of(Currency.of("USD"), Decimal("100.00"), Date.today())
    assert price.__pos__() == Price.of(Currency.of("USD"), Decimal("100.00"), Date.today())


# Generated at 2022-06-21 20:27:16.277006
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    from .ccy import Ccy

    eur = Ccy.of("EUR")
    price1 = Price.of(eur, Decimal("0.12"), Date(2018, 1, 1))
    price2 = Price.of(eur, Decimal("-0.12"), Date(2018, 1, 1))
    assert (price1 - price2) == Price.of(eur, Decimal("0.24"), Date(2018, 1, 1))



# Generated at 2022-06-21 20:27:20.901518
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    for m in (None, SomeMoney(USD, Decimal(2.12), Date(2018, 12, 30))):
        assert (money(m).with_dov(Date(2019, 1, 1)) == m)



# Generated at 2022-06-21 20:27:30.911732
# Unit test for method __floordiv__ of class Price
def test_Price___floordiv__():
    p = Money.of("USD", Decimal("10.0"))
    s = p.price
    assert (s // 2) == Price.of("USD", Decimal("5.0"))
    assert (s // 2.0) == Price.of("USD", Decimal("5.0"))
    assert (Price.of("USD", Decimal("10.00")) // Price.of("USD", Decimal("3.33"))) == Price.of("USD", Decimal("3.0"))
    assert (Price.of("USD", Decimal("10.00")) // Price.of("USD", Decimal("0"))) == Price.NA
    assert (Price.of("USD", Decimal("0.00")) // Price.of("USD", Decimal("3.33"))) == Price.of("USD", Decimal("0.0"))

# Generated at 2022-06-21 20:27:34.590473
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    """
    Test for method with_ccy of class Money
    """
    assert Money.of(Currency.USD, 1, Date.today()) == Money.of(Currency.USD, 1, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).with_ccy(Currency.EUR) == Money.of(Currency.EUR, 1, Date.today())
    assert Money.of(Currency.USD, 1, Date.today()).with_ccy(Currency.EUR).with_ccy(Currency.USD) == Money.of(Currency.USD, 1, Date.today())


# Generated at 2022-06-21 20:27:36.503896
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    assert NoMoney >= NoMoney  # type: ignore
    assert NoMoney >= SomeMoney(CZK, 100, now)
    assert SomeMoney(CZK, 100, now) >= NoMoney
    assert not (SomeMoney(CZK, 100, now) >= NoMoney)


# Generated at 2022-06-21 20:27:44.139379
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    quantity = Decimal(100)
    date = date(2020, 1, 1)
    one_dollar = SomeMoney(Currency.USD, quantity, date)
    two_dollars = SomeMoney(Currency.USD, quantity * 2, date)
    eur = SomeMoney(Currency.EUR, quantity, date)

    assert one_dollar >= one_dollar
    assert not one_dollar >= two_dollars
    with raises(IncompatibleCurrencyError):
        assert one_dollar >= eur




# Generated at 2022-06-21 20:27:55.737062
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    global Price
    global NoPrice
    from datetime import date
    from money import MoneyType, Currency, Money, NoMoney, Price, NoPrice
    from money.currency import USD, EUR, GBP, TRY, CHF, JPY, NZD
    from money.types import MoneyType, Numeric, Union, Optional, Date, Decimal, Literal
    a: Price = Price.of(USD, 10.0, date(2000, 1, 1))
    b: Price = Price.of(USD, 3.0, date(2000, 1, 1))
    assert a.floor_divide(b) == Price.of(USD, 3.0, date(2000, 1, 1))
    assert a.floor_divide(3.0) == Price.of(USD, 3.0, date(2000, 1, 1))
    assert a

# Generated at 2022-06-21 20:27:57.104184
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    assert +NoneMoney == NoneMoney

# Generated at 2022-06-21 20:28:00.558837
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    """
    Test NonePrice.__mul__
    """
    val = NonePrice()
    val = val.__mul__(1)
    assert isinstance(val, NonePrice)
    assert str(val) == "NA"

# Generated at 2022-06-21 20:30:38.386081
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    import decimal
    import datetime
    from ..constants import CURRENCIES, CURRENCY_SYMBOLS, DEFAULT_CURRENCY_SYMBOL
    from ..types import Money, Currency, Quantity, Date
    from ..types import NoPrice, SomePrice, NonePrice
    from ..money import NoMoney, Money, SomeMoney
    from ..money import NoExpense, Expense, SomeExpense
    from ..money import NoIncome, Income, SomeIncome
    from .conftest import p
    from .conftest import P
    from .conftest import q
    from .conftest import Q
    from .conftest import d
    from .conftest import D
    assert NoPrice * 0 == NoPrice
    assert NoPrice * 1 == NoPrice
    assert NoPrice * 5 == NoPrice
    assert NoPrice

# Generated at 2022-06-21 20:30:46.815912
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    """
    Unit test for method __float__ of class SomeMoney
    """

    print("Testing SomeMoney.__float__()")

    ## Define data:
    ccy = USD
    qty = Decimal("123.45")
    dov = Date(2018, 1, 31)

    ## Create an instance of SomeMoney:
    m1 = SomeMoney(ccy, qty, dov)

    ## Test:
    assert m1.__float__() == 123.45

    print(f"{m1[1]} in {m1[0]} is equal to {float(m1)}")



# Generated at 2022-06-21 20:30:49.834011
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    # Test for a defined money object.
    mny = Money.of("USD", 1.23, Date("2020-01-01"))
    mny_pos = mny.__pos__()
    assert mny_pos == mny

    # Test for an undefined money object.
    mny = NoMoney
    mny_pos = mny.__pos__()
    assert mny_pos == mny

# Generated at 2022-06-21 20:30:54.420504
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    assert isinstance(Money.of(Currency.USD, Decimal("100,00"), Date.now()).as_integer(), int)
    assert Money.of(Currency.USD, Decimal("100,00"), Date.now()).as_integer() == 100


# Generated at 2022-06-21 20:31:05.112305
# Unit test for method convert of class Money
def test_Money_convert():
    """
    Unit test for code in method convert of class Money.
    """
    # create fake service instance
    service = fx.FixedFXRateService()

    ccy1 = ccy.USD
    ccy2 = ccy.EUR
    value = mny.Money.of(ccy1, 123.45, dt.Date(2018, 1, 1))

    # add a conversion rate to the fake service
    service.add_fx_rate(ccy.USD, ccy.EUR, 0.8, dt.Date(2018, 1, 1))

    # try converting the value
    converted = value.convert(ccy.EUR, dt.Date(2018, 1, 1), service)

    # verify the conversion was successful
    assert converted.qty == Decimal("98.76")
    assert converted.cc

# Generated at 2022-06-21 20:31:16.506489
# Unit test for method __sub__ of class Money
def test_Money___sub__():

    from moneyonchain.manager import ConnectionManager
    network = 'rdocMainnet'
    connection_manager = ConnectionManager(network=network)
    connection = connection_manager.connection

    from moneyonchain.commission import CommissionSplitter
    commission_splitter = CommissionSplitter(connection_manager)

    commission_splitter.commission_split_demo()

    # Value of the split
    from moneyonchain.token import ROCToken
    r_roc = ROCToken(connection_manager)
    calc = r_roc.roc_to_doc(value=1)

    from moneyonchain.token import RIFToken
    r_rif = RIFToken(connection_manager)
    calc_rif = r_rif.total_supply()





# Generated at 2022-06-21 20:31:18.282009
# Unit test for method __float__ of class NonePrice
def test_NonePrice___float__():
    with pytest.raises(TypeError):
        NonePrice().as_float()

# Generated at 2022-06-21 20:31:20.663504
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    with pytest.raises(NotImplementedError):
        NoneMoney().__abs__()  # type: ignore



# Generated at 2022-06-21 20:31:30.953141
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    from numbers import Number
    from price._price import Price, NoPrice
    from price._currency import Currency, CurrencyCode, CurrencyId
    from price._exceptions import IncompatibleCurrencyError
    from price._data_providers.factory import create_data_provider
    from price._fx_providers.factory import create_fx_rate_provider
    from decimal import Decimal
    from datetime import date
    # None object
    assert NoPrice.is_equal(None) == False
    # Different classes
    assert NoPrice.is_equal(Number(1)) == False
    # Different types
    assert NoPrice.is_equal(Price.of(Currency.USD, Decimal(1), date(2020,1,1))) == False
    # Same object
    assert NoPrice.is_equal(NoPrice) == True

# Generated at 2022-06-21 20:31:35.777395
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    ccy = USD
    qty = Decimal(10.1234)
    dov = Date.today()
    test_obj = SomePrice(ccy, qty, dov)

    rtn = test_obj.round()
    assert rtn == 10

    rtn = test_obj.round(ndigits=2)
    assert rtn == SomePrice(ccy, Decimal(10.12), dov)

