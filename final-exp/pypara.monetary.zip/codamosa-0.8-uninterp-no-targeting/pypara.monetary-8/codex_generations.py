

# Generated at 2022-06-21 20:24:28.621303
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    tester = SomePrice(Currency("ABC"), Decimal(100.0), TODAY)
    assert tester.scalar_subtract(Decimal(100.0)).qty == Decimal(0.0)
    assert tester.scalar_subtract(100.0).qty == Decimal(0.0)


# Generated at 2022-06-21 20:24:31.841925
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    """
    Test method __eq__ of class NonePrice.
    """
    p1=NonePrice()
    p2=NonePrice()
    assert (p1==p2)

# Generated at 2022-06-21 20:24:34.889367
# Unit test for method __truediv__ of class NonePrice
def test_NonePrice___truediv__():
    """
    Test case verifies that method __truediv__ of class NonePrice returns
    instance of class NonePrice.
    """
    u_price = NonePrice()
    assert isinstance(u_price / 1, NonePrice)
    return



# Generated at 2022-06-21 20:24:35.461190
# Unit test for method __bool__ of class SomePrice
def test_SomePrice___bool__():
    return True

# Generated at 2022-06-21 20:24:38.136127
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    assert float(NoMoney) == 0.0

# Generated at 2022-06-21 20:24:45.219599
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    ccy = Currency.usd
    qty = Decimal("100.43")
    dov = Date(2021, 3, 31)
    other = Decimal(3)
    expected = SomeMoney(ccy, Decimal("301.29"), dov)
    actual = SomePrice(ccy, qty, dov).times(other)
    assert expected == actual


# Generated at 2022-06-21 20:24:47.316539
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    """
    # Test method __mul__ of class SomePrice

    """
    pass

# Generated at 2022-06-21 20:24:57.183682
# Unit test for method lt of class Price
def test_Price_lt():
    class TestPrice(Price):
        def __init__(self, ccy, qty, dov):
            self.ccy = ccy
            self.qty = qty
            self.dov = dov
            self.defined = qty is not None and ccy is not None and dov is not None
            self.undefined = not self.defined
            
        def is_equal(self, other):
            return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov
        
        def as_boolean(self):
            return self.qty != Decimal(0)
        
        def as_float(self):
            return float(self.qty)
        
        def as_integer(self):
            return int(self.qty)


# Generated at 2022-06-21 20:25:02.030377
# Unit test for method positive of class Price
def test_Price_positive():
    price = Price.of(USD, D(100), DATE)
    expected = Price.of(USD, D(100), DATE)
    actual = price.positive()
    assert actual == expected and price is not actual and price.dov is actual.dov

# Generated at 2022-06-21 20:25:04.158924
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    pass

# Generated at 2022-06-21 20:27:42.185108
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    val = SomePrice(USD, Decimal(0.1667), TODAY)
    assert(val.round() == SomePrice(USD, Decimal(0), TODAY))
    assert(val.round(2) == SomePrice(USD, Decimal(0.17), TODAY))



# Generated at 2022-06-21 20:27:48.241901
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    from datetime import date as date_cls
    from fnmatch import fnmatch
    from typing import Union
    from pyabc.money.money import Money
    from pyabc.money.currency import Currency
    from pyabc.money.price import Price
    from pyabc.money.prices import SomePrice, NoPrice
    from pyabc.money.fxrate import NoFXRate, SomeFXRate
    from pyabc.money.fxrateservice import FXRateService
    from pyabc.money.money import Money
    from pyabc.money.prices import SomePrice, NoPrice
    from pyabc.money.fxrateservice import FXRateService
    from pyabc.money.fxrate import NoFXRate, SomeFXRate
    from pyabc.money.currency import Currency
    # Type checking of:  (No type checking)
    assert None is None

# Generated at 2022-06-21 20:27:58.768866
# Unit test for method subtract of class Price
def test_Price_subtract():
    assert Price.of(USD, Decimal('1.0'), date(2014, 3, 3)).subtract(Price.of(USD, Decimal('1.0'), date(2014, 3, 3))) == Price.of(USD, (Decimal('1.0') - Decimal('1.0')), date(2014, 3, 3))
    assert Price.of(USD, Decimal('1.0'), date(2014, 3, 3)).subtract(Price.of(GBP, Decimal('1.0'), date(2014, 3, 3))) == NonePrice


# Generated at 2022-06-21 20:28:01.944067
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    price = Price.of(Currency.of('USD'), 1.0, Date.today())
    assert price.as_integer() == 1
    assert isinstance(price.as_integer(), int)



# Generated at 2022-06-21 20:28:07.308081
# Unit test for method __add__ of class Price
def test_Price___add__():
    """
    Tests the addition of two prices with same currency.
    """
    one_eur = Price.of(Currency.EUR, 1, Date.today())
    five_eur = Price.of(Currency.EUR, 5, Date.today())

    assert one_eur + five_eur == Price.of(Currency.EUR, 6, Date.today())



# Generated at 2022-06-21 20:28:14.488052
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    ## Test with a floating point value:
    m = SomeMoney(USD, Decimal(0.1246), Date(2022, 4, 11))
    assert m.__float__() == 0.1246

    ## Test with an integer value:
    m = SomeMoney(EUR, Decimal(123), Date(2022, 4, 11))
    assert m.__float__() == 123.0

# Generated at 2022-06-21 20:28:15.686680
# Unit test for constructor of class Money
def test_Money():
    Money.NA
    pass



# Generated at 2022-06-21 20:28:17.391550
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    ccy = Currency.of("USD")
    qty = Decimal(1.234)
    dov = Date.today()
    p = SomePrice(ccy, qty, dov)
    assert float(p) == 1.234

# Generated at 2022-06-21 20:28:19.026565
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():

    value = NonePrice()
    assert value.scalar_subtract(1) == NonePrice()


# Generated at 2022-06-21 20:28:24.249385
# Unit test for method scalar_add of class Price
def test_Price_scalar_add():
    x: Price = Price.of(EUR, Decimal(1), date(2019, 1, 1))
    y: Price = x.scalar_add(Decimal(1))
    assert y == Price.of(EUR, Decimal(2), date(2019, 1, 1))


# Generated at 2022-06-21 20:31:24.006170
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    assert str(IncompatibleCurrencyError(Currency("EUR"), Currency("USD"), "ADD")) == \
        "EUR vs USD are incompatible for operation 'ADD'."
    try:
        raise IncompatibleCurrencyError(Currency("EUR"), Currency("USD"), "ADD")
    except ProgrammingError as exc:
        assert str(exc) == "EUR vs USD are incompatible for operation 'ADD'."



# Generated at 2022-06-21 20:31:33.488864
# Unit test for method __eq__ of class SomePrice
def test_SomePrice___eq__():
    from .currency import Currency, USD, EUR, GBP, INR
    from .price import NoPrice, SomePrice
    from .model import Date
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class MyPrice(Price):
        qty: Decimal
        ccy: Currency
        dov: Date

    class SomeMyPrice(MyPrice):
        def __init__(self, qty: Decimal, ccy: Currency, dov: Date, price_type: str) -> None:
            super().__init__(qty, ccy, dov, price_type)

        def is_equal(self, other: Any) -> bool:
            return super().is_equal(other)


# Generated at 2022-06-21 20:31:34.250084
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    pass


# Generated at 2022-06-21 20:31:37.605871
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    """
    Tests whether the round method of NoneMoney works.

    >>> m = NoMoney
    >>> m.round()
    NoMoney
    """

# Generated at 2022-06-21 20:31:43.007381
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    # When the money is SomeMoney
    # Then it should return True
    assert SomeMoney(USD, Decimal("10.00"), T0).__bool__()

    # When the money is NoMoney
    # Then it should return False
    assert not NoMoney.__bool__()


# Generated at 2022-06-21 20:31:47.463525
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    """
    Unit test for method floor_divide of class Money
    """
    with pytest.raises(NotImplementedError):
        Money().floor_divide()



# Generated at 2022-06-21 20:31:53.058754
# Unit test for method __bool__ of class Price
def test_Price___bool__():
    global someprice
    global noprice
    someprice = Price.of("USD", Decimal("10"), Date.today())
    noprice = Price.of("USD", Decimal("0"), Date.today())
    assert someprice.as_boolean() == True
    assert noprice.as_boolean() == False


# Generated at 2022-06-21 20:32:02.513037
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    """
    Test method scalar_add
    """
    ccy = Currency("USD")
    qty = Decimal("12.34")
    dov = Date(2018, 12, 31)
    someprice = SomePrice(ccy=ccy, qty=qty, dov=dov)
    scalar = Decimal("2.3")
    new_qty = qty + scalar
    new_someprice = someprice.scalar_add(scalar)
    assert new_someprice.ccy == ccy
    assert new_someprice.qty == new_qty
    assert new_someprice.dov == dov