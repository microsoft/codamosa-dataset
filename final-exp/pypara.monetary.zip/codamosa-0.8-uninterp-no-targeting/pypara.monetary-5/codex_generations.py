

# Generated at 2022-06-21 20:25:57.345297
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert NoPrice.with_dov(Date.today()) is NoPrice
    assert SomePrice(EUR, D('1'), Date.today()).with_dov(Date('2020-05-01')) == SomePrice(EUR, D('1'), Date('2020-05-01'))



# Generated at 2022-06-21 20:25:59.035405
# Unit test for method __abs__ of class NoneMoney
def test_NoneMoney___abs__():
    """
    Unit test for method __abs__ of class NoneMoney
    """
    a = NoMoney
    assert a.__abs__() is a

# Generated at 2022-06-21 20:26:09.624691
# Unit test for method __abs__ of class NonePrice
def test_NonePrice___abs__():
    from dataclasses import dataclass
    from .currency import Currency
    from .units import BaseUnit
    from .money import Money
    from .prices import Price, NonePrice
    from .rates import FXRateService
    from .date import Date
    from decimal import Decimal
    from datetime import date
    @dataclass
    class CurrencyFactory:
        _id: int = 0
        @property
        def id(self)->int:
            return self._id
        def new(self)->Currency:
            self._id += 1
            return Currency(str(self._id), BaseUnit(), Decimal(1), Date(date(month=1, day=1, year=1)))
    currency_factory = CurrencyFactory()
    ## Define currency
    AUD = currency_factory.new()
    ## Define money


# Generated at 2022-06-21 20:26:13.776497
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    """
    Unit test for method ``__gt__`` of class ``NoneMoney``.
    """
    assert NoMoney.__gt__(SomeMoney(Currency.USD, D("1"), Date.today())) is False
    assert NoMoney.__gt__(NoMoney) is False

    # Unit test for method __ge__ of class NoneMoney

# Generated at 2022-06-21 20:26:15.204888
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    pass # unit test for NoneMoney.__add__


# Generated at 2022-06-21 20:26:20.801443
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    assert NoMoney > NoMoney
    assert NoMoney > SomeMoney(USD, Decimal("1.00"))
    assert SomeMoney(USD, Decimal("3.00")) > SomeMoney(USD, Decimal("2.00"))
    assert NoMoney <= SomeMoney(USD, Decimal("1.00"))
    assert SomeMoney(USD, Decimal("3.00")) <= SomeMoney(USD, Decimal("3.00"))
    assert SomeMoney(USD, Decimal("2.00")) <= SomeMoney(USD, Decimal("3.00"))
    assert SomeMoney(USD, Decimal("3.00")) >= SomeMoney(USD, Decimal("3.00"))
    assert SomeMoney(USD, Decimal("3.00")) >= SomeMoney(USD, Decimal("2.00"))

# Generated at 2022-06-21 20:26:31.946064
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    """
    Tests Price.with_dov
    """
    test_obj = Price.of(
        Ccy("USD"),
        Qty("1.5"),
        Dt("2020-04-28")
    )
    assert test_obj.money == Money.of(
        Ccy("USD"),
        Qty("1.5"),
        Dt("2020-04-28")
    ), "test_Price_with_dov: test object creation failed"

    assert test_obj.with_dov(
        Dt("2020-04-29")
    ).dov == Dt("2020-04-29"), "test_Price_with_dov: test failed"



# Generated at 2022-06-21 20:26:43.231861
# Unit test for method __ge__ of class SomeMoney
def test_SomeMoney___ge__():
    from modelx.testing.testutil import SuppressFormulaError

    with SuppressFormulaError():
        model = Model()

        space = model.new_space("Space")

        def Money(x): return space.Money(x)

        def Money_USD(x): return space.Money("USD", x)

        def Money_CAD(x): return space.Money("CAD", x)

        def Money_EUR(x): return space.Money("EUR", x)

        obj = Money("USD", 100)
        assert obj >= Money("USD", 100)

        assert obj >= Money("USD", 50)

        assert not (obj >= Money("USD", 150))

        assert obj >= Money("USD", 100).with_dov("2000-01-01")


# Generated at 2022-06-21 20:26:51.106998
# Unit test for method negative of class Money
def test_Money_negative():
    assert Money.of(None, None, None).negative() == NoMoney
    assert Money.of(Currency.USD(), Decimal(0), None).negative() == NoMoney
    assert Money.of(Currency.USD(), Decimal(12), None).negative() == Money.of(Currency.USD(), Decimal(-12), None)
    assert Money.of(Currency.USD(), Decimal(1), None).negative() == Money.of(Currency.USD(), Decimal(-1), None)
    assert Money.of(Currency.USD(), Decimal(-1), None).negative() == Money.of(Currency.USD(), Decimal(1), None)


# Generated at 2022-06-21 20:26:59.851532
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(EUR, 10, feb14) * 2 == Price.of(EUR, 20, feb14)
    assert Price.of(EUR, 10, feb14) * 2.0 == Price.of(EUR, 20, feb14)
    assert Price.of(EUR, 10, feb14) * Decimal(2) == Price.of(EUR, 20, feb14)
    assert Price.of(GBP, 10, feb14) * 2 == Price.of(GBP, 20, feb14)
    assert Price.of(GBP, 10, feb14) * 2.0 == Price.of(GBP, 20, feb14)

# Generated at 2022-06-21 20:29:19.178432
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    ccy1 = Currency("USD")
    ccy2 = Currency("EUR")
    qty1 = Decimal("1.0")
    qty2 = Decimal("0.0")
    dov = Date("2019-09-01")
    money1 = SomeMoney(ccy1, ccy1.quantize(qty1), dov)
    money2 = SomeMoney(ccy2, ccy2.quantize(qty1), dov)
    money3 = SomeMoney(ccy1, ccy1.quantize(qty2), dov)
    money4 = NoMoney
    assert money1.__gt__(money1) is False
    assert money1.__gt__(money2) is False
    assert money1.__gt__(money3) is False

# Generated at 2022-06-21 20:29:27.993681
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    assert Money.of(Currency.USD, 100.05, Date(2020, 12, 31)) // 9.05 == Money.of(Currency.USD, 11, Date(2020, 12, 31))
    assert (Money.of(Currency.USD, 100.05, Date(2020, 12, 31)) // 9.05).qty == 11
    assert Money.of(Currency.USD, 100.04, Date(2020, 12, 31)) // 9.05 == Money.of(Currency.USD, 11, Date(2020, 12, 31))
    assert (Money.of(Currency.USD, 100.04, Date(2020, 12, 31)) // 9.05).qty == 11

# Generated at 2022-06-21 20:29:30.119432
# Unit test for method __lt__ of class NonePrice
def test_NonePrice___lt__():
    assert not (NoPrice < NoPrice)



# Generated at 2022-06-21 20:29:34.111985
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert (NoMoney < NoMoney) == False
    assert (NoMoney < SomeMoney(Currency.USD, Decimal("3.14"), TODAY)) == True
    assert (SomeMoney(Currency.USD, Decimal("3.14"), TODAY) < NoMoney) == False



# Generated at 2022-06-21 20:29:42.808872
# Unit test for method __floordiv__ of class SomePrice
def test_SomePrice___floordiv__():
    from sark.value import Currency
    from sark.value import Date
    from sark.value import SomePrice
    USDEUR = 'USDEUR'
    USD = Currency.USD
    EUR = Currency.EUR
    assert SomePrice(USD, 1, Date.today()) // SomePrice(EUR, 1, Date.today()).is_equal(
        NoPrice
    )
    def expected_value_to_USDEUR(expected_value):
        return SomePrice(USD, expected_value, Date.today())
    assert SomePrice(USD, 1, Date.today()) // float(USDEUR) // expected_value_to_USDEUR(0)


# Generated at 2022-06-21 20:29:54.879438
# Unit test for method with_dov of class NonePrice
def test_NonePrice_with_dov():
    from datetime import date
    from pypika import Query, Table, Field, Order
    from pypika.functions import Max, Sum
    from qf_lib.containers.dataframe.prices_dataframe import PricesDataFrame
    from qf_lib.containers.dataframe.qf_dataframe import QFDataFrame
    from qf_lib.containers.futures.future_tickers.future_ticker import FutureTicker
    from qf_lib.containers.series.prices_series import PricesSeries
    from qf_lib.containers.series.qf_series import QFSeries
    from qf_lib.documents_utils.excel.excel_api import ExcelApi
    from qf_lib.documents_utils.excel.excel_documents_catalog import Excel

# Generated at 2022-06-21 20:29:56.532120
# Unit test for method __float__ of class Money
def test_Money___float__():
    return Money.NA.__float__()


# Generated at 2022-06-21 20:29:57.949088
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    assert int(SomePrice(USD, "10", None)) == 10



# Generated at 2022-06-21 20:30:04.821630
# Unit test for method __round__ of class Price
def test_Price___round__():
    ccy = USD
    qty = Decimal('10.001')
    dov = Date.today()
    price = Price.of(ccy=ccy, qty=qty, dov=dov)
    assert price.__round__() == 10
    assert price.__round__(None) == 10
    assert price.__round__(1).qty == Decimal('10.0')



# Generated at 2022-06-21 20:30:10.531806
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    assert SomeMoney(USD, ONE, TODAY) == SomeMoney(USD, ONE, TODAY).with_dov(TODAY)
    assert SomeMoney(USD, ONE, TODAY) != SomeMoney(USD, ONE, TODAY).with_dov(TODAY.add(days=1))