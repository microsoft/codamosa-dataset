

# Generated at 2022-06-21 20:25:53.565602
# Unit test for method abs of class Money
def test_Money_abs():
    x = Money(2, 3)
    assert abs(x) == Money(2, 3)
    assert (-x).equals(Money(2, -3))
    print("Method abs of class Money works fine.")

# Generated at 2022-06-21 20:26:01.577012
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    from dpd.currency import Currency
    from dpd.date import Date
    from decimal import Decimal as decimal

    price_1 = SomePrice(ccy=Currency("USD"), qty=decimal("78.32"), dov=Date("2019-05-08"))

    a=price_1/5
    assert a.ccy == Currency("USD")
    assert a.qty == decimal("15.6640")
    assert a.dov == Date("2019-05-08")



# Generated at 2022-06-21 20:26:11.114335
# Unit test for method add of class Price
def test_Price_add():
    price1 = Price.of(USD, 1.0, datetime(2019, 5, 30))
    price2 = Price.of(USD, 1.5, datetime(2019, 5, 30))
    price3 = Price.of(USD, 0.5, datetime(2019, 5, 30))
    price4 = Price.of(GBP, 2.0, datetime(2019, 5, 30))
    price5 = Price.of(USD, 2.0, datetime(2019, 5, 30))

    assert price1.add(price2).qty == 2.5
    assert price1.add(price2).dov == datetime(2019, 5, 30)
    assert price1.add(price2).ccy == USD

    assert price1.add(price3).qty == 1.5
    assert price1.add

# Generated at 2022-06-21 20:26:15.551276
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert not NoMoney < NoMoney
    assert not NoMoney < SomeMoney(USD, 1, Date.today())

    assert NoMoney < SomeMoney(USD, 2, Date.today())
    assert NoMoney < SomeMoney(USD, 2, Date.today())



# Generated at 2022-06-21 20:26:18.722152
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    # Arrange
    price = SomePrice(USD, Decimal("1"), Date.today())

    # Act
    actual = price.__int__()

    # Assert
    assert actual == 1



# Generated at 2022-06-21 20:26:29.686493
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    #  given
    from .currencies import USD

    m_USD_zero = SomeMoney(USD, 0, None)
    m_USD_pos = SomeMoney(USD, 10, None)
    m_USD_neg = SomeMoney(USD, -10, None)

    # and
    abs_USD_zero = SomeMoney(USD, 0, None)
    abs_USD_pos = SomeMoney(USD, 10, None)
    abs_USD_neg = SomeMoney(USD, 10, None)

    # expect
    assert abs(m_USD_zero) == abs_USD_zero
    assert abs(m_USD_pos) == abs_USD_pos
    assert abs(m_USD_neg) == abs_USD_neg



# Generated at 2022-06-21 20:26:32.006119
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    ccy = Currency.AED
    qty = Decimal('1000.00')
    dov = Date(datetime.date(2014, 12, 31))
    money = Money.of(ccy, qty, dov)
    expected = Money.of(ccy, qty, dov)
    assert money, money.__pos__() == expected

# Generated at 2022-06-21 20:26:35.470507
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    noprice = NonePrice()
    ccy = Currency()
    assert isinstance(noprice.with_ccy(ccy), Price)
    assert not noprice.with_ccy(ccy).defined
    assert noprice.with_ccy(ccy).undefined


# Generated at 2022-06-21 20:26:37.784762
# Unit test for constructor of class Money
def test_Money():
    assert Money == Money.NA
    assert Money.NA.undefined
    assert not Money.NA.defined


# Generated at 2022-06-21 20:26:42.433936
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    to_test = Price.of(USD, Decimal(10), dov(2018, 1, 1))
    value = to_test.__gt__(to_test)

    assert value is False

# Generated at 2022-06-21 20:27:35.194017
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    """
    Unit test for method ``__pos__`` of class ``NonePrice``
    """
    assert NonePrice.__pos__(NonePrice()) is NonePrice()



# Generated at 2022-06-21 20:27:35.629760
# Unit test for constructor of class Money
def test_Money():
    pass



# Generated at 2022-06-21 20:27:37.226238
# Unit test for method scalar_subtract of class Money
def test_Money_scalar_subtract():
    for m in [NoneMoney, NoMoney, SomeMoney(USD, 123, "2019-01-01")]:
        assert m.scalar_subtract(0) == m
        assert m.scalar_subtract(123) == m.negative()

# Generated at 2022-06-21 20:27:40.732338
# Unit test for method __mul__ of class SomeMoney
def test_SomeMoney___mul__():
    # call method
    price = no_money()*1
    # get properties
    assert price.ccy == USDCurrency
    assert price.value == no_money().qty



# Generated at 2022-06-21 20:27:42.251335
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    """
    Test method __mul__
    """
    from .classes import Price, NonePrice

    p1: Price = NonePrice
    n: int = 1
    assert p1.__mul__(n) is NonePrice

# Generated at 2022-06-21 20:27:51.028276
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    from finutil.models.currencies import USD, GBP, EUR
    from finutil.models.money import Money, SomeMoney, NoMoney
    from datetime import date
    from decimal import Decimal as D

    def _test_defined_money(qty: D, ccy: Currency) -> None:
        """
        Helper function to test defined money object conversion to ``float``.
        """
        assert float(Money.of(ccy, qty, date(2019, 8, 30))) == qty

    def _test_undefined_money(qty: Optional[D], ccy: Optional[Currency], dov: Optional[date]) -> None:
        """
        Helper function to test undefined money object conversion to ``float``.
        """

# Generated at 2022-06-21 20:27:59.504408
# Unit test for method floor_divide of class Price
def test_Price_floor_divide():
    assert SomePrice("USD", Decimal("100.56"), Year(2020).start).floor_divide(Decimal("2")) == SomePrice("USD", Decimal("50"), Year(2020).start)
    assert SomePrice("USD", Decimal("100.56"), Year(2020).start).floor_divide(2) == SomePrice("USD", Decimal("50"), Year(2020).start)
    assert SomePrice("USD", Decimal("100.56"), Year(2020).start).floor_divide(2.0) == SomePrice("USD", Decimal("50"), Year(2020).start)
    assert SomePrice("USD", Decimal("100.56"), Year(2020).start).floor_divide(2.5) == SomePrice("USD", Decimal("40"), Year(2020).start)

# Generated at 2022-06-21 20:28:07.146272
# Unit test for method lte of class Price
def test_Price_lte():
    from .monetary import Money
    from .currency import Currency
    from .fxrate import FXRate
    from .fxrate import NoFXRate

    assert NoPrice.lte(Money.of(Currency.USD, Decimal('10.23')))

    assert Money.of(Currency.USD, Decimal('10.23')).lte(NoPrice)

    assert NoPrice.lte(NoPrice)

    assert not Money.of(Currency.USD, Decimal('10.23')).lte(Money.of(Currency.EUR, Decimal('10.23')))


# Generated at 2022-06-21 20:28:18.896408
# Unit test for method gte of class Price
def test_Price_gte():
    price1 = Price.of(ccy=Currency('EUR', 1), qty=Decimal(10), dov=Date(2020, 4, 4))
    price2 = Price.of(ccy=Currency('EUR', 1), qty=Decimal(10), dov=Date(2020, 4, 4))
    price3 = Price.of(ccy=Currency('EUR', 1), qty=Decimal(10), dov=Date(2020, 4, 4))
    price4 = Price.of(ccy=Currency('EUR', 1), qty=Decimal(10), dov=Date(2020, 4, 4))

    assert (price1 >= price2, price2 >= price1) == (True, True)
    assert (price1 >= price3, price3 >= price1) == (True, True)

# Generated at 2022-06-21 20:28:22.293838
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert Money.of(Currency.USD, 10, Date.today()) >= Money.of(Currency.USD, 10, Date.today())


# Generated at 2022-06-21 20:29:43.604749
# Unit test for method convert of class NoneMoney
def test_NoneMoney_convert():
    assert NoneMoney.convert(NoneMoney, Currency("USD"), None, False) == NoMoney
    assert NoneMoney.convert("NA", Currency("USD"), None, False) == NoMoney
    assert NoneMoney.convert(10, Currency("USD"), None, False) == NoMoney
    assert NoneMoney.convert(10.0, Currency("USD"), None, False) == NoMoney

# Generated at 2022-06-21 20:29:46.674577
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    assert SomePrice('USD', 12.3, '2018-10-25') + 1 == SomePrice('USD', 13.3, '2018-10-25')
    

# Generated at 2022-06-21 20:29:58.482138
# Unit test for method __gt__ of class Money
def test_Money___gt__():
    from .currencies import USD
    from .enums.dates import Date
    from .enums.money import (
        SomeMoney, NoMoney, Money
    )

    class SomeMoneySubclass(SomeMoney):
        pass


# Generated at 2022-06-21 20:30:00.625455
# Unit test for method __int__ of class NonePrice
def test_NonePrice___int__():
    with raises(TypeError, match=r".*quantity information.*"):
        int(NonePrice())

# Generated at 2022-06-21 20:30:06.684907
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    """
    Test Money.__bool__()
    """
    x, q, d = Currency.USD, Decimal(1.0), Date.now()
    defined = SomeMoney(x, q, d)
    undefined = NoMoney
    assert bool(defined) == True
    assert bool(undefined) == False

# Generated at 2022-06-21 20:30:17.376100
# Unit test for method __round__ of class Money
def test_Money___round__():
    from .currencies import Currency

    ccy = Currency("USD")
    money = SomeMoney(ccy, ccy.quantize(10.23), Date(2020, 1, 1))
    assert money.__round__() == 10
    assert money.__round__(1) == SomeMoney(ccy, ccy.quantize(10.2), Date(2020, 1, 1))
    assert money.__round__(2) == SomeMoney(ccy, ccy.quantize(10.23), Date(2020, 1, 1))
    assert money.__round__(3) == SomeMoney(ccy, ccy.quantize(10.23), Date(2020, 1, 1))



# Generated at 2022-06-21 20:30:28.861654
# Unit test for method __eq__ of class Money
def test_Money___eq__():
    assert (NoMoney == NoMoney) is True
    assert (NoMoney == SomeMoney(ccy="EUR", qty=Decimal(1), dov=Date(day=1, month=1, year=2000))) is False

    assert (SomeMoney(ccy="EUR", qty=Decimal(1), dov=Date(day=1, month=1, year=2000)) == NoMoney) is False
    assert (SomeMoney(ccy="EUR", qty=Decimal(1), dov=Date(day=1, month=1, year=2000)) ==
            SomeMoney(ccy="EUR", qty=Decimal(1), dov=Date(day=1, month=1, year=2000))) is True

# Generated at 2022-06-21 20:30:29.647058
# Unit test for method with_qty of class SomePrice
def test_SomePrice_with_qty():
    ...

# Generated at 2022-06-21 20:30:40.737309
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    assert (Money.of(Currency(0),Decimal('1.123456'),Date(2000,1,1)) >= Money.of(Currency(0),Decimal('1.123456'),Date(2000,1,1)))
    assert (Money.of(Currency(0),Decimal('1.123457'),Date(2000,1,1)) >= Money.of(Currency(0),Decimal('1.123456'),Date(2000,1,1)))
    assert (not (Money.of(Currency(0),Decimal('1.123456'),Date(2000,1,1)) >= Money.of(Currency(1),Decimal('1.123456'),Date(2000,1,1))))

# Generated at 2022-06-21 20:30:44.255425
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    from ..price.base import Price

    assert Price.of(None, None, None).with_ccy(Currency.BDT) == Price.of(None, None, None)