

# Generated at 2022-06-21 20:26:05.242411
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Tests the invariants of `gte` method of money class.
    """
    assert not NoneMoney.gte(NonePrice)
    assert not NoneMoney.gte(NoneMoney)
    assert USD(100).gte(USD(100))
    assert USD(100).gte(NoneMoney)

    # Incompatible currencies.
    try:
        USD(100).gte(EUR(100))
        assert False, "Unexpected compatible currencies for argument EUR"
    except IncompatibleCurrencyError:
        pass

    # Less than
    assert not USD(10).gte(USD(20))

    # Greater than
    assert USD(20).gte(USD(10))
    assert USD(20).gte(NoneMoney)

    # Less than or equal to
    assert USD(10).gte(USD(10))

# Generated at 2022-06-21 20:26:08.445421
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__(): # TODO: unit tests
    _test_NoneMoney___ge__()
    return

# Generated at 2022-06-21 20:26:09.791184
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    x = Money.of(EUR, Decimal(1), TODAY)
    x = SomeMoney(EUR, Decimal(1), TODAY)
    x.scalar_subtract(1)



# Generated at 2022-06-21 20:26:14.507031
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Tests method gte of the Money class.
    """
    usd1 = Money.of(Currency.USD, 1.0, Date.today())
    assert usd1 >= Money.of(None, None, None)

    usd2 = Money.of(None, None, None)
    assert not usd2 >= Money.of(Currency.USD, 1.0, Date.today())


# Generated at 2022-06-21 20:26:16.023409
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    _actual = NoneMoney.__pos__(NoneMoney())
    _expected = NoneMoney()
    assert _actual == _expected



# Generated at 2022-06-21 20:26:21.358686
# Unit test for method __neg__ of class Price
def test_Price___neg__():
    import money
    import money.money as money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    import money.money
    assert money.Money.NA == -money.Money.NA
    assert money.Money.NA == -money.Money(Currency('USD'), Decimal('100'))
    assert money.Money(-100, Currency('USD')) == -money.Money(100, Currency('USD'))
    assert money.Money(100, Currency('USD')) == -money.Money(-100, Currency('USD'))
    assert money

# Generated at 2022-06-21 20:26:29.922923
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    """
    Unit test for constructor of class IncompatibleCurrencyError.
    """
    from .currencies import USD

    ## Initialize:
    ccy1 = USD()
    ccy2 = USD()
    operation = "<Add>"
    exc = IncompatibleCurrencyError(ccy1, ccy2, operation)
    assert exc.ccy1 == ccy1
    assert exc.ccy2 == ccy2
    assert exc.operation == operation
    assert str(exc) == "USD vs USD are incompatible for operation '<Add>'."



# Generated at 2022-06-21 20:26:32.764605
# Unit test for method floor_divide of class Money
def test_Money_floor_divide():
    """
    This is a unit test for :meth:`Money.floor_divide` of class Money
    """
    m1 = Money
    m2 = Money

# Generated at 2022-06-21 20:26:40.425454
# Unit test for method __int__ of class Price
def test_Price___int__():
    import datetime
    from datetime import date
    from pony.orm import db_session
    from decimal import Decimal
    from com.pyxll.abstract.money import Price
    from com.pyxll.abstract.money import Money
    from com.pyxll.abstract.money import NoMoney
    d1 = datetime.date.today()
    d2 = datetime.date.today()
    d3 = datetime.date.today()
    d4 = datetime.date.today()
    d5 = datetime.date.today()
    d6 = datetime.date.today()
    d7 = datetime.date.today()
    d8 = datetime.date.today()
    d9 = datetime.date.today()
    d10 = datetime.date.today()

# Generated at 2022-06-21 20:26:44.367334
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    m = NoneMoney()
    d = Date.today()
    assert m.with_dov(d) is m

# Generated at 2022-06-21 20:27:13.171456
# Unit test for constructor of class NonePrice
def test_NonePrice():
    no_price = NonePrice()
    assert no_price == NoPrice
    assert no_price.abs() == NoPrice
    assert no_price.round() == NoPrice
    assert no_price.negative() == NoPrice
    assert no_price.positive() == NoPrice
    assert bool(no_price) == False
    assert no_price.as_boolean() == False
    assert no_price.is_equal(NonePrice()) == True
    assert no_price.as_float() == None
    assert no_price.as_integer() == None

## Create instance of NonePrice
NoPrice = NonePrice()

## Define a price object:

# Generated at 2022-06-21 20:27:15.644317
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    i = Price.of(ccy=Currency.of('USD'), qty=Decimal(10.0), dov=Date(2013, 12, 31))
    assert i.__mul__(2) == Price.of(ccy=Currency.of('USD'), qty=Decimal(20.0), dov=Date(2013, 12, 31))

     

# Generated at 2022-06-21 20:27:20.585101
# Unit test for method positive of class Money
def test_Money_positive():
    assert Money.NA.positive() is NoMoney
    assert Money.NA.positive() == NoMoney
    assert Money.of(Currency.USD, Decimal('100.00'), Date(2021, 2, 1)).positive() == Money.of(Currency.USD, Decimal('100.00'), Date(2021, 2, 1))
    assert Money.of(Currency.USD, Decimal('100.00'), Date(2021, 2, 1)).positive() != Money.of(Currency.USD, Decimal('10.00'), Date(2021, 2, 1))



# Generated at 2022-06-21 20:27:24.022056
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    # GIVEN
    a: NonePrice = NoPrice
    # WHEN
    b = a.round()
    # THEN
    assert b == NoPrice
    # WHEN
    b = a.round(2)
    # THEN
    assert b == NoPrice


# Generated at 2022-06-21 20:27:34.878067
# Unit test for method __eq__ of class NonePrice
def test_NonePrice___eq__():
    from .currency import Currency
    from .date import Date
    from .decimal import Decimal
    from .price import NoPrice, SomePrice
    from .rate import FXRate, FXRateService
    from .money import SomeMoney, NoMoney
    from decimal import Decimal as D
    import pytest
    ## Give me a price service:
    class SomeFXRateService(FXRateService):
        def __call__(self, ccy1: Currency, ccy2: Currency, asof: Optional[Date] = None) -> FXRate:
            return SomeFXRate(ccy1, ccy2, 1, asof)
    FXRateService.default = SomeFXRateService()
    ## Case: NoPrice is equal to NoPrice:
    assert NoPrice == NoPrice
    assert NoPrice == None
    assert NoPrice == 0
    assert NoPrice

# Generated at 2022-06-21 20:27:36.636585
# Unit test for method with_qty of class NonePrice
def test_NonePrice_with_qty():
    assert NonePrice.with_qty(quantize(Decimal("0.12345678900000000000"))) == NonePrice

# Generated at 2022-06-21 20:27:37.386733
# Unit test for method __ge__ of class NoneMoney
def test_NoneMoney___ge__():
    pass



# Generated at 2022-06-21 20:27:43.792303
# Unit test for method add of class Price
def test_Price_add():
    price1 = Price.of(AUD, Decimal(12), date(2019, 1, 31))
    price2 = Price.of(AUD, Decimal(15), date(2019, 2, 28))
    assert Price.of(AUD, Decimal('27'), date(2019, 3, 31)) == price1.add(price2)


## Define and attach undefined price singleton.
Price.NA = NoPrice = NonePrice()



# Generated at 2022-06-21 20:27:51.845758
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    """
    Unit test for `Price.__mul__` method
    """
    EUR = Currency.of("EUR")
    emp = Price.of(EUR, Decimal(1), Date(2020, 2, 1))
    tw = Price.of(EUR, Decimal(2), Date(2020, 2, 1))
    d = Price.of(EUR, Decimal(1), Date(2020, 2, 1))

    assert emp * tw == tw * d

    assert emp * 2 == tw

    assert tw * 0.5 == d

    assert tw / 2 == d

    assert tw // 2 == d

    assert tw * Decimal(0.5) == d

    assert tw * Fraction(1, 2) == d



# Generated at 2022-06-21 20:27:56.413049
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    some_price = SomePrice(Currency('EUR'), Decimal('6'), date(2010, 10, 10))
    assert some_price * Decimal('3') == SomePrice(Currency('EUR'), Decimal('18'), date(2010, 10, 10))

# Generated at 2022-06-21 20:28:29.610083
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    import datetime
    from mamba import before, context, description, it
    from expects import expect, equal, raise_error
    
    with before.all:
        import pyrfnum.Money
        import pyrfnum.NoneMoney
        self.Money = pyrfnum.Money
        self.NoneMoney = pyrfnum.NoneMoney
    
    with description('Money'):
        with context('when initialized with a quantity and a valid currency code'):
            with it('should return a SomeMoney instance'):
                actual = self.Money.of('EUR', 1000, datetime.date.today())
                expect(type(actual)).to(equal(self.Money.SomeMoney))

# Generated at 2022-06-21 20:28:31.628823
# Unit test for method with_qty of class NoneMoney
def test_NoneMoney_with_qty():
    # 1
    qty = Decimal(0)
    ccy = Currency.from_string("USD")
    some_money = SomeMoney(ccy,qty,dov=Date.today())
    none_money = some_money.with_qty(qty=None)
    assert none_money == NoMoney


# Generated at 2022-06-21 20:28:35.531670
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    price1 = Price(Currency.USD, Decimal('1.1234'), date(2020, 2, 24))
    price2 = Price(Currency.USD, Decimal('1.1234'), date(2020, 2, 24))
    assert price1 < price2 == False


# Generated at 2022-06-21 20:28:37.485858
# Unit test for method __truediv__ of class SomeMoney
def test_SomeMoney___truediv__(): ...

# Generated at 2022-06-21 20:28:44.439190
# Unit test for method subtract of class Money
def test_Money_subtract():
    from .currencies import Currency, USD, EUR
    from .exchange import FXRateService, SimpleFXRateService

    ccy_usd = Currency('USD')
    ccy_eur = Currency('EUR')
    ccy_jpy = Currency('JPY')

    mny_usd_1 = Money.of(ccy_usd, 100, Date.today())
    mny_usd_2 = Money.of(ccy_usd, 200, Date.today())
    mny_eur = Money.of(ccy_eur, 300, Date.today())

    # Different currencies
    mny_usd_3 = mny_usd_1 - mny_eur
    assert mny_usd_3.defined
    assert mny_usd_3.qty == -200

    mny_eur_

# Generated at 2022-06-21 20:28:49.505063
# Unit test for method as_integer of class Money
def test_Money_as_integer():
    from .currencies import TRY, USD

    assert Money.of(TRY, Decimal("1.00000000"), None).as_integer() == 1
    assert Money.of(TRY, Decimal("1.00000000"), Date.today()).as_integer() == 1
    assert Money.of(TRY, Decimal("1.00000000"), Date.today()).with_qty(Decimal("2.00000000")).as_integer() == 2
    assert Money.of(TRY, Decimal("1.00000000"), Date.today()).with_ccy(USD).as_integer() == 1
    assert Money.of(TRY, Decimal("1.00000000"), Date.today()).with_dov(Date(2019, 11, 13)).as_integer() == 1



# Generated at 2022-06-21 20:28:59.644827
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    assert (Price.of(ccy=Currency.of('EUR'), qty=Decimal('100'), dov=Date.of(2020, 1, 1),)
            - Money.of(Currency.of('EUR'), Decimal('50'), Date.of(2020, 1, 1),)
            ) == Price.of(ccy=Currency.of('EUR'), qty=Decimal('50'), dov=Date.of(2020, 1, 1),)

# Generated at 2022-06-21 20:29:06.092873
# Unit test for method multiply of class Price
def test_Price_multiply():
    p1 = Money.of(EUR, 10)
    p2 = Money.of(USD, 20)
    p3 = Money.of(EUR, None)
    assert p1.multiply(p2) == NoMoney
    assert p1.multiply(p3).undefined
    assert p1.multiply(p3).qty == 10

# Generated at 2022-06-21 20:29:17.110906
# Unit test for method convert of class NonePrice
def test_NonePrice_convert():
    from moneypy.money import Money
    from moneypy import Currency
    from moneypy.exchange import FXRateLookupError

    assert NonePrice.convert(Currency.USD, Currency.CAD) == NonePrice
    assert NonePrice.convert(Currency.USD, Currency.CAD, False) == NonePrice

    pr = Money(1, Currency.USD).price()
    assert pr.convert(Currency.CAD) == pr.with_ccy(Currency.CAD)
    assert pr.convert(Currency.CAD, strict = True) == pr.with_ccy(Currency.CAD)

    # Do not use a date in the distant past, because such date may not be convertible.
    # If a date in the distant past is used, an error could occur.
    # For example, an error could occur of

# Generated at 2022-06-21 20:29:18.970559
# Unit test for method __round__ of class Money
def test_Money___round__():
    assert SomeMoney.of('EUR', 3.14159, Date.today).__round__() == 3
