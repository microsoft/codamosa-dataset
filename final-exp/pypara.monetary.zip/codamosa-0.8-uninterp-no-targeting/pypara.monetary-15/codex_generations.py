

# Generated at 2022-06-21 20:25:14.304650
# Unit test for method __lt__ of class NoneMoney
def test_NoneMoney___lt__():
    assert (NoMoney < SomeMoney(Currency.USD, Decimal("100.00"), Date.today())) is False

# Generated at 2022-06-21 20:25:15.636949
# Unit test for method __pos__ of class NonePrice
def test_NonePrice___pos__():
    assert NonePrice().__pos__() is NonePrice


# Generated at 2022-06-21 20:25:20.928132
# Unit test for method scalar_add of class NonePrice
def test_NonePrice_scalar_add():
    """
    Tests the addition of a scalar value to a price value.
    """
    ## Initialize price:
    price = NonePrice

    ## Add a scalar:
    new_price = price.scalar_add(1.0)

    ## Test:
    assert new_price == NoPrice

# Generated at 2022-06-21 20:25:30.118401
# Unit test for method with_ccy of class SomePrice
def test_SomePrice_with_ccy():
    """
    Tests the implementation of method with_ccy of class SomePrice.
    """
    USD = Currency("USD")
    EUR = Currency("EUR")
    GBP = Currency("GBP")
    CHF = Currency("CHF")

    price = SomePrice(USD, 5, Date.today())

    assert price.with_ccy(USD) is price
    assert price.with_ccy(EUR) == SomePrice(EUR, 5, Date.today())
    assert price.with_ccy(GBP) == SomePrice(GBP, 5, Date.today())
    assert price.with_ccy(CHF) == SomePrice(CHF, 5, Date.today())

# Generated at 2022-06-21 20:25:33.678610
# Unit test for method lte of class Money
def test_Money_lte():
    assert Money.NA <= Money.NA
    assert NoMoney <= NoMoney
    assert SomeMoney(USD, Decimal(10), Date.today()) <= SomeMoney(USD, Decimal(10), Date.today())

# Generated at 2022-06-21 20:25:38.861633
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    # Test case data
    ccy = Currency('CHF')
    qty = Decimal(100)
    dov = Date(2020, 11, 10)
    money = Money.of(ccy, qty, dov)
    # Perform the test
    result = -money
    # Post conditions
    assert result.ccy == ccy
    assert result.qty == Decimal('-100')
    assert result.dov == dov


# Generated at 2022-06-21 20:25:40.984441
# Unit test for method __sub__ of class NoneMoney
def test_NoneMoney___sub__():
    # Given
    obj = NoneMoney()
    other = NoneMoney()

    # When
    result = obj.subtract(other)

    # Then
    expected = NoneMoney()
    assert result is expected

# Generated at 2022-06-21 20:25:43.621153
# Unit test for method __float__ of class Money
def test_Money___float__():
    from money.currencies import USD
    from money.money import Money
    from money.money import SomeMoney
    from datetime import date
    money = SomeMoney(USD,Decimal(1, ),date(1, 1, 1))
    assert money.__float__() == 1.0

# Generated at 2022-06-21 20:25:47.909408
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    from .currencies import USD, GBP, EUR
    from decimal import Decimal
    from .commons.zeitgeist import Date

    assert USD(10).__lt__(USD(11))
    assert USD(10).__lt__(USD(10.5))
    assert USD(10).__lt__(GBP(10))  # Incompatible currency!
    assert USD(10).__lt__(NoMoney)  # Undefined money!
    assert NoMoney.__lt__(USD(10))  # Undefined money!
    assert NoMoney.__lt__(NoMoney)  # Undefined money!
    assert NoMoney.__lt__(10)  # Undefined money can not compare with anything other than money!

# Generated at 2022-06-21 20:25:50.367442
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    # Check the invocation and the returned type.
    assert isinstance(NoneMoney().__int__(), int)


# Generated at 2022-06-21 20:27:46.351901
# Unit test for method __pos__ of class SomePrice
def test_SomePrice___pos__():
    price = SomePrice(GBP, Decimal(5), Date(2018, 1, 1))
    assert price.__pos__() is price


# Generated at 2022-06-21 20:27:51.181596
# Unit test for method __pos__ of class Price
def test_Price___pos__():
    def mocked_Price_of(ccy, qty, dov):
        if ccy is None or qty is None or dov is None:
            return NoPrice
        return SomePrice(ccy, qty, dov)
    instance = Price()
    instance.of = mocked_Price_of
    assert isinstance(instance.__pos__(), Price) == (bool(instance.__pos__()) == bool(instance.with_qty(abs(instance.qty))))


# Generated at 2022-06-21 20:28:02.795380
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    ccy = Currency.of("USD")
    dov = Date.today()
    SomeMoney.of(ccy, Decimal("1.234567"), dov).round() == SomeMoney(ccy, Decimal("1.234567"), dov)
    SomeMoney.of(ccy, Decimal("1.234567"), dov).round(15) == SomeMoney(ccy, Decimal("1.234567"), dov)
    SomeMoney.of(ccy, Decimal("1.234567"), dov).round(3) == SomeMoney(ccy, Decimal("1.235"), dov)
    SomeMoney.of(ccy, Decimal("1.234567"), dov).round(2) == SomeMoney(ccy, Decimal("1.23"), dov)



# Generated at 2022-06-21 20:28:04.552012
# Unit test for method __pos__ of class NoneMoney
def test_NoneMoney___pos__():
    pass


# Generated at 2022-06-21 20:28:16.538309
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    dov = Date.from_string("2017-01-01")
    ccy = get_currency("EUR")
    to = get_currency("GBP")
    with patch("financepy.products.financial.fxrateservice.FXRateService.query", return_value=SomeFXRate(ccy, to, dov, Decimal("1.0"))):
        price = SomePrice(ccy, Decimal("100.0"), dov)
        assert price.convert(to, dov) == SomePrice(to, Decimal("100.0"), dov)
        assert price.convert(to, Date.from_string("2017-02-01")) == SomePrice(to, Decimal("100.0"), Date.from_string("2017-02-01"))

# Generated at 2022-06-21 20:28:18.511033
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    assert float(SomePrice(GBP, 12.345, date(2021, 1, 1))) == 12.345

# Generated at 2022-06-21 20:28:24.404996
# Unit test for constructor of class NonePrice
def test_NonePrice():
    price = NonePrice()
    assert price.defined == False
    assert price.undefined == True
    assert price.as_boolean() == False
    assert price.as_float() == -1
    assert price.as_integer() == -1
    assert price.abs() == NonePrice()
    assert price.negative() == NonePrice()
    assert price.positive() == NonePrice()
    assert price.round() == NonePrice()
    assert price.add(NonePrice()) == NonePrice()
    assert price.scalar_add(None) == NonePrice()
    assert price.subtract(NonePrice()) == NonePrice()
    assert price.scalar_subtract(None) == NonePrice()
    assert price.multiply(None) == NonePrice()
    assert price.times(None) == NoMoney()
   

# Generated at 2022-06-21 20:28:36.362093
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    m1 = SomeMoney(Currency.USD, Decimal("1.01"), Date(year=2020, month=10, day=1))
    assert m1 == SomeMoney(Currency.USD, Decimal("1.01"), Date(year=2020, month=10, day=1))
    assert m1 != SomeMoney(Currency.CAD, Decimal("1.01"), Date(year=2020, month=10, day=1))
    assert m1 == SomeMoney(Currency.USD, Decimal("1.010"), Date(year=2020, month=10, day=1))
    assert m1 != SomeMoney(Currency.CAD, Decimal("1.010"), Date(year=2020, month=10, day=1))

# Generated at 2022-06-21 20:28:41.508824
# Unit test for method __ge__ of class Money
def test_Money___ge__():
    try:
        return
        assert False, "Unreachable"  # Incorrect implementation.
    except NotImplementedError:
        assert True  # Correct implementation.


    class Monkey(Money):
        def __ge__(self, other: "Money") -> bool:
            raise NotImplementedError

    m = Monkey()
    try:
        m >= 10  # type: ignore
        assert False, "Unreachable"  # Incorrect implementation.
    except TypeError:
        assert True  # Correct implementation.



# Generated at 2022-06-21 20:28:42.819325
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    assert SomePrice('USD', 1) == SomePrice('USD', 1)

# Generated at 2022-06-21 20:29:11.027081
# Unit test for method __lt__ of class SomeMoney
def test_SomeMoney___lt__():
    ccy, qty, dov = ('EUR', 1.0, date(2017, 12, 1))
    money1 = SomeMoney(*(ccy, qty, dov))
    money2 = SomeMoney(*(ccy, qty + 1, dov))
    assert not money1.__lt__(money1)
    assert money1.__lt__(money2)

# Generated at 2022-06-21 20:29:21.081583
# Unit test for method __gt__ of class NoneMoney
def test_NoneMoney___gt__():
    n = NoneMoney
    assert n.__gt__(Money.of(USD, 212.10, TODAY)) == False
    assert n.__gt__(Money.of(USD, -212.10, TODAY)) == False
    assert n.__gt__(Money.of(EUR, 212.10, TODAY)) == False
    assert n.__gt__(Money.of(EUR, -212.10, TODAY)) == False
    assert n.__gt__(Money.of(GBP, 212.10, TODAY)) == False
    assert n.__gt__(Money.of(GBP, -212.10, TODAY)) == False
    assert n.__gt__(Money.of(EUR, 212.10, YESTERDAY)) == False

# Generated at 2022-06-21 20:29:25.359185
# Unit test for method __abs__ of class SomePrice
def test_SomePrice___abs__():
    ccy, qty, dov = Currency.of("GBP"), Decimal(100).quantize(2), Date(2017, 11, 10)
    price = SomePrice(ccy, qty, dov)
    assert price.abs() == SomePrice(ccy, Decimal(100).quantize(2), dov)



# Generated at 2022-06-21 20:29:34.830356
# Unit test for method abs of class Money
def test_Money_abs():
    assert Money.of(Currency.EUR, Decimal('-10.00'), Date.today()).abs() == Money.of(Currency.EUR, Decimal('10.00'), Date.today())
    assert Money.of(Currency.EUR, Decimal('0.00'), Date.today()).abs() == Money.of(Currency.EUR, Decimal('0.00'), Date.today())
    assert Money.of(Currency.EUR, Decimal('10.00'), Date.today()).abs() == Money.of(Currency.EUR, Decimal('10.00'), Date.today())
    assert NoMoney.abs() == NoMoney

# Generated at 2022-06-21 20:29:40.514852
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    assert Money.of(None, None, None).with_ccy(Currency.of("EUR")) == NoMoney
    assert SomeMoney(Currency.of("EUR"), Decimal(0), Date.today()).with_ccy(Currency.of("USD")) == SomeMoney(Currency.of("USD"), Decimal(0), Date.today())


# Generated at 2022-06-21 20:29:43.445201
# Unit test for method __eq__ of class Price
def test_Price___eq__():
    # Return value of method __eq__ is correct
    assert Price.of(Currency.GBP, 10, Date(20, 8, 2020)) == Price.of(Currency.GBP, 10, Date(20, 8, 2020))



# Generated at 2022-06-21 20:29:48.758096
# Unit test for method with_dov of class Price
def test_Price_with_dov():
    assert SomePrice(EUR, 1000.00000, date(2020, 3, 31)).with_dov(date(2020, 4, 30)) == SomePrice(
        EUR, 1000.00000, date(2020, 4, 30)
    )

Price.NA = NoPrice = NonePrice()
__all__ = ["Money", "Price", "NoMoney", "NoPrice"]

# Generated at 2022-06-21 20:30:01.027498
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    import money
    import money.utils
    import money.utils.types
    import money.utils.types.currency
    import money.utils.types.date
    import money.utils.types.money
    import money.utils.types.price
    import money.utils.types.price
    import numbers
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types.price
    import money.utils.types

# Generated at 2022-06-21 20:30:04.929398
# Unit test for method __mul__ of class SomePrice
def test_SomePrice___mul__():
    assert SomePrice("USD", 3, "2017-09-18").__mul__("1.5") == SomePrice("USD", 4.5, "2017-09-18")

# Generated at 2022-06-21 20:30:16.119209
# Unit test for method with_ccy of class Money
def test_Money_with_ccy():
    from datetime import datetime
    from .currencies import Currency

    assert NoMoney.with_ccy(ccy=Currency.of("USD")) == NoMoney
    assert NoMoney.with_ccy(ccy=None) == NoMoney

    assert SomeMoney(Currency.of("XTS"), Decimal("100"), datetime.today()).with_ccy(ccy=Currency.of("USD")) == NoMoney

    sm = SomeMoney(Currency.of("XTS"), Decimal("100"), datetime.today())
    assert sm.with_ccy(ccy=None) == sm
    assert sm.with_ccy(ccy=Currency.of("XTS")) == sm
