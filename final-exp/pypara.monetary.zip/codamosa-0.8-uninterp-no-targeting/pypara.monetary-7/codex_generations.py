

# Generated at 2022-06-21 20:24:30.527257
# Unit test for method lte of class Price
def test_Price_lte():
    from pricedb import FX_RATE
    from pricedb import Price, Money

    USD_QTY = Decimal("12.230")
    USD_DOV = Date(2015, 1, 1)

    USD_PRICE = Price.of(Currency.USD, USD_QTY, USD_DOV)

    # USD_PRICE < USD_PRICE # Undefined
    assert not USD_PRICE.lt(USD_PRICE)
    assert not USD_PRICE.lte(USD_PRICE)

    # USD_PRICE is less than USD_PRICE
    assert USD_PRICE.lt(USD_PRICE.with_qty(USD_QTY + Decimal("1.0")))

# Generated at 2022-06-21 20:24:32.783767
# Unit test for method round of class NonePrice
def test_NonePrice_round():
    """
    Unit test for method round of class NonePrice
    """
    np = NonePrice()
    assert np.round() is np
    assert np.round(1) is np


# Generated at 2022-06-21 20:24:35.553390
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    assert SomeMoney(USD, 100, date(2018, 1, 1)).__sub__(SomeMoney(USD, 50, date(2018, 1, 2))) == SomeMoney(USD, 50, date(2018, 1, 1))


# Generated at 2022-06-21 20:24:39.545266
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    with pytest.raises(TypeError):
        assert 0 == __int__(NoneMoney)

# Generated at 2022-06-21 20:24:41.642387
# Unit test for method __floordiv__ of class NoneMoney
def test_NoneMoney___floordiv__():
    # fails
    actual = NoMoney.__floordiv__(1)
    assert actual == NoMoney

# Generated at 2022-06-21 20:24:45.714474
# Unit test for method scalar_add of class NoneMoney
def test_NoneMoney_scalar_add():
    n = NoneMoney
    n += 10
    assert n == n
    n -= 10
    assert n == n
    n *= 10
    assert n == n
    n /= 10
    assert n == n


# Generated at 2022-06-21 20:24:51.568431
# Unit test for method __add__ of class NoneMoney
def test_NoneMoney___add__():
    """
    Unit test for method __add__ of class NoneMoney
    """
    ##
    assert SomeMoney(EUR, Decimal("1.00"), date.today()) == NoMoney + SomeMoney(EUR, Decimal("1.00"), date.today())
    ##
    assert NoMoney == NoMoney + NoMoney
    ##
    assert NoMoney == NoMoney + SomeMoney(EUR, Decimal("1.00"), date.today())

# Generated at 2022-06-21 20:24:57.497127
# Unit test for method scalar_subtract of class SomePrice
def test_SomePrice_scalar_subtract():
    c1, q1, d1 = Currency.USD, Decimal(50.54), Date.today()
    assert SomePrice(c1, q1, d1).scalar_subtract(Decimal(50.54)) == SomePrice(c1, Decimal(0.00), d1)
    assert SomePrice(c1, q1, d1).scalar_subtract(Decimal(100.54)) == SomePrice(c1, Decimal(-50.00), d1)
    assert SomePrice(c1, q1, d1).scalar_subtract(Decimal(-50.54)) == SomePrice(c1, Decimal(101.08), d1)

# Generated at 2022-06-21 20:25:05.717666
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    # Arrange
    a = Price.of(Currency.of('GBP'), 1, Date(2018,2,2))
    b = 2

    # Act
    c = a / b

    # Assert
    assert type(c) == SomePrice
    assert c.qty == Decimal(0.5)
    assert c.ccy == Currency.of('GBP')
    assert c.dov == Date(2018,2,2)

# Generated at 2022-06-21 20:25:17.630230
# Unit test for method round of class Money
def test_Money_round():

    ### Define Money Class:
    class Money(Money):
        ccy:Currency
        qty:Decimal
        dov:Date
        def is_equal(self, other: Any) -> bool:
            """
            Checks the equality of two money objects.

            In particular:

            1. ``True`` if ``other`` is a money object **and** all slots are same.
            2. ``False`` otherwise.
            """
            if isinstance(other, Money):
                return self.ccy == other.ccy and self.qty == other.qty and self.dov == other.dov
            return False

# Generated at 2022-06-21 20:30:05.374858
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    # NoPrice
    price = NoPrice
    result = price.__float__()
    assert isinstance(result, float)
    assert (result == NotAvailable)
    assert (type(result) == type(NotAvailable))

    # SomePrice
    price = SomePrice(USD, Decimal("1.35"), None)
    result = price.__float__()
    assert isinstance(result, float)
    assert (result == 1.35)
    assert (type(result) == float)

# Generated at 2022-06-21 20:30:13.012449
# Unit test for method negative of class Price
def test_Price_negative():
    expected_value = SomePrice(ccy="USD",qty=Decimal('-2'),dov=date(year=2020, month=8, day=1))
    input_value = SomePrice(ccy="USD",qty=Decimal('2'),dov=date(year=2020, month=8, day=1))
    actual_value = input_value.negative()
    assert actual_value == expected_value

# Generated at 2022-06-21 20:30:19.575946
# Unit test for method with_qty of class SomeMoney
def test_SomeMoney_with_qty():
    qty = Decimal('1.2345')
    ccy = Currency('USD')
    dov = Date(0)
    sm1 = SomeMoney(ccy, qty, dov)
    qty2 = Decimal('4.5678')
    sm2 = sm1.with_qty(qty2)
    assert sm2.ccy.code == 'USD'
    assert sm2.qty == qty2
    assert sm2.dov == dov



# Generated at 2022-06-21 20:30:30.547621
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    undefined_price = Price.of(USD, None, None)
    defined_price_1 = Price.of(USD, Decimal('1.23'), Date.today())
    defined_price_2 = Price.of(USD, Decimal('1.24'), Date.today())

    assert defined_price_2.__gt__(defined_price_1)
    assert not defined_price_1.__gt__(undefined_price)
    assert not defined_price_1.__gt__(defined_price_1)

    try:
        defined_price_2.__gt__(Price.of(EUR, Decimal('1.23'), Date.today()))
        assert False
    except error.IncompatibleCurrencyError:
        pass

# Generated at 2022-06-21 20:30:31.333368
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    pass

# Generated at 2022-06-21 20:30:35.860705
# Unit test for method times of class SomePrice
def test_SomePrice_times():
    result = SomePrice("USD", "1.0", Date("2020-01-01")).times("2.0")

    assert(result == SomeMoney("USD", "2.0", Date("2020-01-01")))


# Generated at 2022-06-21 20:30:40.892771
# Unit test for method multiply of class Money
def test_Money_multiply():
    mon1 = SomeMoney(USD, 1, datetime.date.today())
    mon2 = SomeMoney(USD, 1, datetime.date.today())
    mon3 = mon1.multiply(2)
    assert mon3.is_equal(mon2)


# Generated at 2022-06-21 20:30:45.049527
# Unit test for method __mul__ of class Price
def test_Price___mul__():
    # assert isinstance(NoPrice, Price)
    # assert isinstance(NoPrice.__mul__, FunctionType)
    assert isinstance(SomePrice.__mul__, FunctionType)
    # assert isinstance(SomePrice(None, None, None).__mul__, FunctionType)

    # NoPrice * SomePrice(None, None, None)
    x = NoPrice
    y = SomePrice(None, None, None)
    actual = x.__mul__(y)
    # assert isinstance(actual, Price)
    assert actual is NoPrice
    # assert actual == NoPrice

    # SomePrice(None, None, None) * NoPrice
    x = SomePrice(None, None, None)
    y = NoPrice
    actual = x.__mul__(y)
    # assert isinstance(actual,

# Generated at 2022-06-21 20:30:48.889174
# Unit test for method __lt__ of class SomePrice
def test_SomePrice___lt__():
    x = SomePrice(USD, Decimal('1.00'), datetime.date(2018, 12, 31))
    y = SomePrice(EUR, Decimal('1.00'), datetime.date(2018, 12, 31))
    assert x < y  # pass


# Generated at 2022-06-21 20:30:57.199594
# Unit test for method __sub__ of class SomeMoney
def test_SomeMoney___sub__():
    """
    
    """
    def __sub__(self, other: "Money") -> "Money":
        if other.undefined:
            return self
        ccy, qty, dov = self
        if ccy != other.ccy:
            raise IncompatibleCurrencyError(ccy1=ccy, ccy2=other.ccy, operation="subtraction")
        return SomeMoney(ccy, qty - other[1], dov if dov > other[2] else other[2])
    pass

