

# Generated at 2022-06-21 20:27:40.219052
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    # Given:
    usd_100 = SomeMoney.of(Currency.USD, Decimal("100.00"), Date(2020, 3, 9))
    jpy_100 = SomeMoney.of(Currency.JPY, Decimal("100.00"), Date(2020, 3, 9))
    jpy_neg_100 = SomeMoney.of(Currency.JPY, Decimal("-100.00"), Date(2020, 3, 9))

    # Then:
    assert usd_100.abs() == usd_100
    assert jpy_100.abs() == jpy_100
    assert jpy_neg_100.abs() == jpy_100

# Generated at 2022-06-21 20:27:40.847265
# Unit test for method __pos__ of class Money
def test_Money___pos__():
    pass


# Generated at 2022-06-21 20:27:50.277858
# Unit test for method __round__ of class Price
def test_Price___round__():
    # 'Fails' if raising an exception
    # 'Fails' if return value does not match
    assert Price.of(None, Decimal('123.3232'), Decimal('0.6567')).__round__() == 123.3232
    assert Price.of(None, Decimal('123.3232'), Decimal('0.6567')).__round__(ndigits=None) == 123.3232
    assert Price.of(None, Decimal('123.3232'), Decimal('0.6567')).__round__(ndigits=2) == Price.of(None, Decimal('123.32'), Decimal('0.6567'))
    # 'Fails' if raising an exception
    assert Price.of(None, Decimal('-123.3232'), Decimal('0.6567')).__round__

# Generated at 2022-06-21 20:27:53.933106
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    with pytest.raises(TypeError):
        q = NoneMoney.__int__(None)

# Generated at 2022-06-21 20:27:59.854131
# Unit test for method __round__ of class Money
def test_Money___round__():

    assert Money.of(Currency("EUR"), 5.12349, Date(2018, 1, 2)).__round__() == 5
    assert Money.of(Currency("EUR"), 5.12349, Date(2018, 1, 2)).__round__(2) == Money.of(
        Currency("EUR"), 5.12, Date(2018, 1, 2)
    )



# Generated at 2022-06-21 20:28:04.458530
# Unit test for method as_integer of class Price
def test_Price_as_integer():
    price1 = Price.of(EUR, Decimal("1234.000"), asof=today)
    price2 = Price.of(None, None, asof=None)

    assert price1.as_integer() == 1234
    assert price2.as_integer() == 0

    with raises(TypeError):
        NoPrice.as_integer()


# Generated at 2022-06-21 20:28:16.378150
# Unit test for method gte of class Money
def test_Money_gte():
  """Testing method gte of class Money"""

  import pytest

  # Unit test for method gte of class Money

  # Raises exception as ccy of second money object is None
  from moneypy.commons.zeitgeist import Date
  from moneypy.currencies import Currency
  from moneypy.money import Money, SomeMoney
  from moneypy.prices import Price, SomePrice

  second_money_object = Money.of(None, Decimal('2'), Date(28, 10, 2006))
  first_money_object = SomeMoney(Currency.of('BRL'), Decimal('1'), Date(28, 10, 2006))
  with pytest.raises(IncompatibleCurrencyError):
      assert first_money_object.gte(second_money_object)
  
  # Unit test for method gte of class Money

 

# Generated at 2022-06-21 20:28:18.071351
# Unit test for method __int__ of class SomePrice
def test_SomePrice___int__():
    assert SomePrice(Currency("USD"), 1, Date(2020, 1, 1)).__int__() == 1

# Generated at 2022-06-21 20:28:19.634293
# Unit test for method __mul__ of class NonePrice
def test_NonePrice___mul__():
    np = NonePrice()
    np1 = np * 5
    assert np1 is np


# Generated at 2022-06-21 20:28:22.240863
# Unit test for method with_ccy of class SomeMoney
def test_SomeMoney_with_ccy():
    # Preparation:
    m = SomeMoney(USD, Decimal("1"), Date(1, 1, 2000))
    # Action and Assertion:
    assert m.with_ccy(EUR) == SomeMoney(EUR, Decimal("1"), Date(1, 1, 2000))

# Generated at 2022-06-21 20:29:14.821123
# Unit test for method __lt__ of class Price
def test_Price___lt__():
    global price_lt_count, price_lt_last_price_arg
    price_lt_count += 1
    price_lt_last_price_arg = other
    return price_lt_count > 5 and (price_lt_count % 3 == 0)


# Generated at 2022-06-21 20:29:24.538819
# Unit test for constructor of class Money
def test_Money():
    class MockMoney(Money):

        def __init__(self, ccy: Currency, qty: Decimal, dov: Date) -> None:
            super().__init__()
            self.ccy = ccy
            self.qty = qty
            self.dov = dov

        def is_equal(self, other: Any) -> bool:
            return False

        def as_boolean(self) -> bool:
            return True

        def as_float(self) -> float:
            return super().as_float()

        def as_integer(self) -> int:
            return super().as_integer()

        def abs(self) -> "Money":
            return super().abs()

        def negative(self) -> "Money":
            return super().negative()

        def positive(self) -> "Money":
            return

# Generated at 2022-06-21 20:29:35.903996
# Unit test for method __sub__ of class Money
def test_Money___sub__():

    assert (SomeMoney("USD", 1, None) - SomeMoney("USD", 1, None) == NoMoney)
    assert (SomeMoney("USD", 1, None) - SomeMoney("USD", 1.0, None) == NoMoney)
    assert (SomeMoney("USD", 1, None) - SomeMoney("USD", Decimal("1.000"), None) == NoMoney)
    assert (SomeMoney("USD", 1, None) - SomeMoney("USD", Decimal("1.000"), None) == NoMoney)
    assert (SomeMoney("USD", 1.0, None) - SomeMoney("USD", 1, None) == NoMoney)
    assert (SomeMoney("USD", 1.0, None) - SomeMoney("USD", 1.0, None) == NoMoney)

# Generated at 2022-06-21 20:29:40.987502
# Unit test for method scalar_add of class SomePrice
def test_SomePrice_scalar_add():
    p = SomePrice("USD", "0.01", Date("20200515"))
    p2 = p.scalar_add(100)
    assert p2.ccy == p.ccy
    assert p2.qty == p.qty + 100
    assert p2.dov == p.dov

# Generated at 2022-06-21 20:29:42.953080
# Unit test for method __truediv__ of class Price
def test_Price___truediv__():
    some_USD_price = Price.of(USD, 50, Date.today())
    assert 0.1 == some_USD_price / 500


# Generated at 2022-06-21 20:29:44.760935
# Unit test for method __sub__ of class Price
def test_Price___sub__():
    # TODO: Define new test here
    raise NotImplementedError



# Generated at 2022-06-21 20:29:56.871327
# Unit test for method with_ccy of class Price
def test_Price_with_ccy():
    # Basic Usage
    assert Price.of("USD", 100, "2020-01-02").with_ccy("EUR") == Price.of("EUR", 100, "2020-01-02")
    assert Price.NA.with_ccy("EUR") is Price.NA

    # If we don't provide enough arguments, should get back Price.NA
    assert Price.of("USD", 100).with_ccy("EUR") is Price.NA
    assert Price.of("USD", 100).with_ccy("EUR", "2020-01-02") is Price.NA
    assert Price.of("USD").with_ccy("EUR") is Price.NA
    assert Price.of("USD").with_ccy("EUR", "2020-01-02") is Price.NA

# Generated at 2022-06-21 20:30:00.393794
# Unit test for method scalar_subtract of class SomeMoney
def test_SomeMoney_scalar_subtract():
    money = SomeMoney(GBP, Decimal('1000.00'), today)
    assert SomeMoney.scalar_subtract(money, 1) == SomeMoney(GBP, Decimal('999.00'), today)


# Generated at 2022-06-21 20:30:01.195308
# Unit test for method __ge__ of class Price
def test_Price___ge__():
    pass

# Generated at 2022-06-21 20:30:14.471794
# Unit test for method lt of class Money
def test_Money_lt():
    currency = Currency("EUR")
    date1 = Date(2018, 10, 10)
    date2 = Date(2018, 11, 10)
    money1 = Money.of(currency, Decimal(10), date1)
    money2 = Money.of(currency, Decimal(5), date1)
    money3 = Money.of(currency, Decimal(5), date2)
    money4 = Money.of(currency, Decimal(10), date2)

    assert money1.lt(money2) == False
    assert money1.lt(money3) == True
    assert money1.lt(money4) == True
    assert money2.lt(money1) == True
    assert money2.lt(money3) == True
    assert money2.lt(money4) == True
    assert money3.lt(money1)