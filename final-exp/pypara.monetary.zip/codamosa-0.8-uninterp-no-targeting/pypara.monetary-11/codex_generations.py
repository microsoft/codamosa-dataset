

# Generated at 2022-06-21 20:28:40.294795
# Unit test for method __float__ of class NoneMoney
def test_NoneMoney___float__():
    assert NoneMoney.__float__.__doc__ is not None

    ## This should raise TypeError:
    try:
        NoneMoney.__float__(NoneMoney())
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 20:28:44.176787
# Unit test for method __neg__ of class NonePrice
def test_NonePrice___neg__():
    assert -Price(None, None, None) == Price(None, None, None)
    assert -Price(None, None, None).__class__ == Price(None, None, None).__class__

    assert -Price.of(Currency.USD, None, None) == Price(None, None, None)
    assert -Price.of(Currency.USD, None, None).__class__ == Price(None, None, None).__class__



# Generated at 2022-06-21 20:28:48.793390
# Unit test for method __float__ of class SomeMoney
def test_SomeMoney___float__():
    assert SomeMoney(USD, 1.2345, Date(2018, 1, 1)).__float__() == 1.2345
    assert SomeMoney(CAD, -1.2345, Date(2018, 1, 1)).__float__() == -1.2345

# Generated at 2022-06-21 20:28:50.737646
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    assert -NoMoney == NoMoney
    assert -SomeMoney(currencies.USD, 10.0, dates.today()) == SomeMoney(currencies.USD, -10.0, dates.today())
    # Unit test for method __pos__ of class Money

# Generated at 2022-06-21 20:28:52.291913
# Unit test for method __float__ of class SomePrice
def test_SomePrice___float__():
    assert float(SomePrice(ccy=Currency("USD"), qty=Decimal("6.2"), dov=Date(year=2018, month=10, day=15))) == 6.2

# Generated at 2022-06-21 20:28:55.532609
# Unit test for method is_equal of class Money
def test_Money_is_equal():
    try:
        # Test case 1
        assert Money.NA.is_equal(Money.NA)
        # Test case 2
        assert Money.NA.is_equal(1)
        # Test case 3
        assert Money.of(Currency.USD, 100, Date.today()).is_equal(Money.of(Currency.USD, 100, Date.today()))
    except:
        # Unit test failed
        assert False


# Generated at 2022-06-21 20:29:02.898627
# Unit test for method multiply of class Price
def test_Price_multiply():
    assert Price.of('INR', 1, dt.date(2020, 1, 1)).multiply(2) == Price.of('INR', 2, dt.date(2020, 1, 1))
    assert Price.of('INR', 2, dt.date(2020, 1, 1)).multiply(2) == Price.of('INR', 4, dt.date(2020, 1, 1))
    assert Price.of('INR', 4, dt.date(2020, 1, 1)).multiply(2) == Price.of('INR', 8, dt.date(2020, 1, 1))
    assert Price.of('INR', 8, dt.date(2020, 1, 1)).multiply(2) == Price.of('INR', 16, dt.date(2020, 1, 1))

# Generated at 2022-06-21 20:29:12.998723
# Unit test for method __abs__ of class Money
def test_Money___abs__():
    assert Money.of("USD", Decimal("-42.0"), Date.today()).__abs__() == Money.of("USD", Decimal("42.0"), Date.today())
    assert Money.of("USD", Decimal("42.0"), Date.today()).__abs__() == Money.of("USD", Decimal("42.0"), Date.today())
    assert Money.of("USD", Decimal("0"), Date.today()).__abs__() == Money.of("USD", Decimal("0"), Date.today())
    assert NoMoney.__abs__() == NoMoney
    assert NoneMoney.__abs__() == NoneMoney


# Generated at 2022-06-21 20:29:16.237633
# Unit test for method __bool__ of class Money
def test_Money___bool__():
    def test1():
        # test case #1
        return bool(SomeMoney(USD, Decimal("1.00"), Date.of(2020, 7, 1)))

    def test2():
        # test case #2
        return bool(NoneMoney)

    assert test1() and not test2()

# Generated at 2022-06-21 20:29:21.813057
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from ccy_finance import Money, SomeMoney
    from datetime import date


    todays_date = date(2019, 5, 20)

    money_1 = SomeMoney("USD", 1, todays_date)
    money_2 = SomeMoney("USD", 10, todays_date)

    result = money_2 - money_1

    assert result == SomeMoney("USD", 9, todays_date)

# Generated at 2022-06-21 20:30:20.215287
# Unit test for method with_qty of class Price
def test_Price_with_qty():
    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal(2)).qty == Decimal(2)

    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal('NaN')).qty == Decimal('NaN')

    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal('Infinity')).qty == Decimal('Infinity')

    assert Price.of(Currency.USD, Decimal(1), Date.today()).with_qty(Decimal('-Infinity')).qty == Decimal(
        '-Infinity')


# Generated at 2022-06-21 20:30:23.381782
# Unit test for method gte of class Money
def test_Money_gte():
    """
    Tests if the "greater than or equal to" comparison can be performed on Money objects.
    """
    raise NotImplementedError

# Generated at 2022-06-21 20:30:34.275459
# Unit test for method __sub__ of class Price
def test_Price___sub__():
	assert Price.of(ccy="USD",qty=Decimal("100"),dov="2020-01-01").__sub__(Price.of(ccy="USD",qty=Decimal("10"),dov="2020-01-01")).qty==Decimal("90")
	assert Price.of(ccy="USD",qty=Decimal("100"),dov="2020-01-01").__sub__(Price.of(ccy="USD",qty=Decimal("-10"),dov="2020-01-01")).qty==Decimal("110")

# Generated at 2022-06-21 20:30:46.058130
# Unit test for method __le__ of class SomeMoney
def test_SomeMoney___le__():

    x = 0

    def __x_increment():
        nonlocal x
        x += 1

    # Testing method:
    # with some_money.ccy = None and other_money.ccy = None
    # expect some_money.ccy < other_money.ccy
    # some_money.qty < other_money.qty
    # some_money.dov < other_money.dov
    # some_money.ccy == other_money.ccy
    # some_money.ccy > other_money.ccy
    # some_money.qty == other_money.qty
    # some_money.qty > other_money.qty
    # some_money.dov == other_money.dov
    # some_money.dov > other_money.dov

    # Ar

# Generated at 2022-06-21 20:30:54.095245
# Unit test for method as_float of class Money
def test_Money_as_float():
    from .currencies import CNY
    from .money import SomeMoney
    from .zeitgeist import Date
    from .exchange import FXRateService
    from .commons.zeitgeist import Date
    from .commons.numbers import Numeric
    from .commons.zeitgeist import Date
    fxrate_service = FXRateService()
    result: Optional[float] = SomeMoney(CNY, Numeric(1), Date(2020, 9, 26)).as_float()
    assert result == 1.0



# Generated at 2022-06-21 20:30:59.550903
# Unit test for method __truediv__ of class SomePrice
def test_SomePrice___truediv__():
    # Setup
    ccy, qty, dov = Currency("USD"), Decimal("14.25"), Date(2016, 10, 10)
    c, q, d = ccy, qty, dov
    p = SomePrice(c, q, d)
    o = Decimal("3")
    r = p / o
    # Verify
    assert r.qty == Decimal("4.75")


# Generated at 2022-06-21 20:31:03.049545
# Unit test for method times of class Price
def test_Price_times():
    with pytest.raises(NotImplementedError, match="No abstract methods"):  # Pass
        assert Price.times(1)
        assert Price().times(1)

# Generated at 2022-06-21 20:31:03.996854
# Unit test for method __bool__ of class NoneMoney
def test_NoneMoney___bool__():
    assert bool(NoneMoney) is False

# Generated at 2022-06-21 20:31:08.273283
# Unit test for method __add__ of class SomePrice
def test_SomePrice___add__():
    v1 = SomePrice(Currency.USD, Decimal("1"), LocalDate.today())
    v2 = SomePrice(Currency.USD, Decimal("2"), LocalDate.today())

    assert v1 + v2 == SomePrice(Currency.USD, Decimal("3"), LocalDate.today())
    assert v1 + NoPrice == v1



# Generated at 2022-06-21 20:31:19.047728
# Unit test for method times of class Price
def test_Price_times():
    assert Price.of(CCY_EUR, QTY_1, DOV).times(QTY_1) == Money.of(CCY_EUR, QTY_1, DOV)
    assert Price.of(CCY_EUR, QTY_1, DOV).times(QTY_2) == Money.of(CCY_EUR, QTY_2, DOV)
    assert Price.of(CCY_EUR, QTY_1, DOV).times(QTY_3) == Money.of(CCY_EUR, QTY_3, DOV)
    assert Price.of(CCY_EUR, QTY_1, DOV).times(QTY_4) == Money.of(CCY_EUR, QTY_4, DOV)