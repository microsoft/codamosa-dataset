

# Generated at 2022-06-21 20:29:16.348686
# Unit test for method __ge__ of class NonePrice
def test_NonePrice___ge__():
    assert NotImplementedError, 'Fail - NonePrice.__ge__ not implemented'


# Generated at 2022-06-21 20:29:25.318618
# Unit test for method __neg__ of class Money
def test_Money___neg__():
    """
    Unit test for method __neg__ of class Money.
    """
    #
    # Given undefined money object
    #
    money = NoMoney
    #
    # When negating
    #
    negated = -money
    #
    # Then
    #
    assert negated == NoMoney

    #
    # Given defined money object
    #
    money = SomeMoney("EUR", 2.0, Date("2017-01-01"))
    #
    # When negating
    #
    negated = -money
    #
    # Then
    #
    assert negated == SomeMoney("EUR", -2.0, Date("2017-01-01"))

    #
    # Given defined money object
    #
    money = SomeMoney("EUR", 0.0, Date("2017-01-01"))


# Generated at 2022-06-21 20:29:27.711339
# Unit test for constructor of class MonetaryOperationException
def test_MonetaryOperationException():
    """
    Tests the constructor of class MonetaryOperationException
    """
    ## Base case:
    assert MonetaryOperationException("message") is not None # noqa: S101
    assert MonetaryOperationException("message").__str__() == "message" # noqa: S101


# Generated at 2022-06-21 20:29:28.595001
# Unit test for method __add__ of class NonePrice
def test_NonePrice___add__():
    pass

# Generated at 2022-06-21 20:29:35.122012
# Unit test for method times of class NonePrice
def test_NonePrice_times():
    n = NonePrice
    assert n.times(0) == NoMoney
    raises(TypeError, lambda: n.times(1))
    raises(TypeError, lambda: n.times(1.1))
    raises(TypeError, lambda: n.times(-1))
    raises(TypeError, lambda: n.times(12345678901234567890))
    raises(TypeError, lambda: n.times(Decimal("0.0000000000000000000001")))


# Generated at 2022-06-21 20:29:44.477200
# Unit test for method convert of class Money
def test_Money_convert():
    from .currencies import USD
    from .exchange import FXRateServiceFixed
    from .zeitgeist import today

    FXRateService.setfxrateservice(FXRateServiceFixed({USD: 1}))
    try:
        m = Money.of(USD, 1, today())
        assert m.convert(USD).defined
        assert m.convert(USD).ccy == USD
        assert m.convert(USD).qty == m.qty
        assert m > 0
    finally:
        FXRateService.setfxrateservice(None)


NoMoney = NoneMoney()
"""
Provides a singleton that represents an *undefined* monetary value.
"""

SomeMoney = NoneMoney().__class__
"""
Provides the type name for a *defined* monetary value.
"""



# Generated at 2022-06-21 20:29:56.746841
# Unit test for method __eq__ of class SomeMoney
def test_SomeMoney___eq__():
    ccy0 = AUD
    qty0 = Decimal('1.23')
    dov0 = Date.today()
    m0 = SomeMoney(ccy0, qty0, dov0)
    m1 = SomeMoney(ccy0, qty0, dov0)
    m2 = SomeMoney(ccy0, qty0, dov0 + timedelta(days=1))
    m3 = SomeMoney(USD, qty0, dov0)
    m4 = SomeMoney(ccy0, Decimal('1.24'), dov0)
    m5 = SomeMoney(ccy0, qty0, dov0 + timedelta(days=1))
    m6 = NoMoney
    assert  m0 == m1
    assert  m1 == m0
    assert  m0 == m2


# Generated at 2022-06-21 20:29:57.910084
# Unit test for method with_dov of class NoneMoney
def test_NoneMoney_with_dov():
    assert (NoMoney.with_dov(Date(2018, 1, 1)) == NoMoney)

# Generated at 2022-06-21 20:30:11.106563
# Unit test for method gt of class Price
def test_Price_gt():
    # These test cases pass when the function is defined
    # They fail when the function is not defined

    some_price_1 = SomePrice(ccy=EUR, qty=Decimal("1"), dov=Date(2018, 1, 1))
    some_price_2 = SomePrice(ccy=EUR, qty=Decimal("1"), dov=Date(2018, 1, 1))
    assert some_price_1.gt(some_price_2) == False
    assert some_price_2.gt(some_price_1) == False
    assert some_price_1.gt(NoPrice) == False
    assert NoPrice.gt(some_price_1) == False


# Generated at 2022-06-21 20:30:16.832177
# Unit test for method round of class NoneMoney
def test_NoneMoney_round():
    actual = NoneMoney.__round__(NoneMoney())
    expected = NoneMoney()
    assert actual == expected
    actual = NoneMoney.__round__(NoneMoney(), 0)
    expected = NoneMoney()
    assert actual == expected
    actual = NoneMoney.__round__(NoneMoney(), 1)
    expected = NoneMoney()
    assert actual == expected

# Generated at 2022-06-21 20:31:13.256282
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    m = NoneMoney()
    assert isinstance(m.__int__(), int)
    with raises(TypeError):
        m.__int__()


# Generated at 2022-06-21 20:31:14.543856
# Unit test for method with_ccy of class NoneMoney
def test_NoneMoney_with_ccy():
    assert NoneMoney.with_ccy(Currency()) == NoneMoney

# Generated at 2022-06-21 20:31:17.959510
# Unit test for method __le__ of class NonePrice
def test_NonePrice___le__():
    """Unit test for method NonePrice.__le__."""
    # --- Positive tests ---
    assert NonePrice().__le__(prices.USD(2.0))
    # --- Negative tests ---
    # --- Edge cases ---



# Generated at 2022-06-21 20:31:20.817472
# Unit test for method lte of class Money
def test_Money_lte():
    '''
    Unit test for method lte of class Money
    '''
    not_implemented_with_None(Money.lte, None, None)



# Generated at 2022-06-21 20:31:26.107343
# Unit test for method with_ccy of class NonePrice
def test_NonePrice_with_ccy():
    with_ccy_1 = NonePrice.with_ccy(Currency.from_local("USD"))
    assert with_ccy_1 == NonePrice

    NonePrice.ccy == None

    with_ccy_2 = NonePrice.with_ccy(Currency.from_local("AUD"))
    assert with_ccy_2 == NonePrice

# Generated at 2022-06-21 20:31:34.570251
# Unit test for method convert of class Price

# Generated at 2022-06-21 20:31:35.377499
# Unit test for method convert of class SomeMoney
def test_SomeMoney_convert():
    pass

# Generated at 2022-06-21 20:31:46.392050
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    # Method result should be equal to a boolean
    assert bool(Price(NZD(10.0)))
    assert bool(Price(EUR(10.0)))
    assert bool(Price(USD(10.0)))
    assert not bool(Price(NZD(0)))
    assert not bool(Price(EUR(0)))
    assert not bool(Price(USD(0)))
    # Method input should be equal to a boolean
    assert isinstance(Price.as_boolean(Price(NZD(10.0))), bool)
    assert isinstance(Price.as_boolean(Price(EUR(10.0))), bool)
    assert isinstance(Price.as_boolean(Price(USD(10.0))), bool)
    assert isinstance(Price.as_boolean(Price(NZD(0))), bool)
   

# Generated at 2022-06-21 20:31:52.910176
# Unit test for method __sub__ of class Money
def test_Money___sub__():
    from .currencies import Currency

    from ..commons.zeitgeist import today

    m1 = Money.of(Currency.USD, 100, today())
    m2 = Money.of(Currency.USD, 50, today())
    assert m1 - m2 == Money.of(Currency.USD, 50, today())
    assert m1 - Money.NA == Money.NA

# Generated at 2022-06-21 20:32:01.890992
# Unit test for constructor of class SomeMoney
def test_SomeMoney():
    assert SomeMoney(USD, 1, Date(2020, 1, 1)) == SomeMoney(USD, 1, Date(2020, 1, 1))
    assert SomeMoney(USD, 1, Date(2020, 1, 1)).ccy == USD
    assert SomeMoney(USD, 1, Date(2020, 1, 1)).qty == 1
    assert SomeMoney(USD, 1, Date(2020, 1, 1)).dov == Date(2020, 1, 1)
    assert SomeMoney(USD, 1, Date(2020, 1, 1)).defined == True
    assert SomeMoney(USD, 1, Date(2020, 1, 1)).undefined == False
