

# Generated at 2022-06-21 20:24:42.956389
# Unit test for method abs of class Price
def test_Price_abs():
    assert Price.of("USD", Decimal("1.23"), Date(2018, 12, 17)).abs() == Price.of("USD", Decimal("1.23"), Date(2018, 12, 17))
    assert Price.of("USD", Decimal("-1.23"), Date(2018, 12, 17)).abs() == Price.of("USD", Decimal("1.23"), Date(2018, 12, 17))
    assert Price.of("USD", Decimal("-123.45"), Date(2018, 12, 17)).abs() == Price.of("USD", Decimal("123.45"), Date(2018, 12, 17))
    assert Price.of("USD", Decimal("-0.00"), Date(2018, 12, 17)).abs() == Price.of("USD", Decimal("0.00"), Date(2018, 12, 17))

# Generated at 2022-06-21 20:24:47.099012
# Unit test for method __add__ of class Money
def test_Money___add__():
    m1 = SomeMoney(Currency("EUR"), Decimal("100.0"), Date(2020, 2, 17))
    m2 = SomeMoney(Currency("EUR"), Decimal("10.0"), Date(2020, 2, 17))
    assert m1 + m2 == SomeMoney(Currency("EUR"), Decimal("110.0"), Date(2020, 2, 17))
    assert m1 + m2.with_ccy(Currency("USD")) == NoMoney


# Generated at 2022-06-21 20:24:48.818859
# Unit test for method __bool__ of class NonePrice
def test_NonePrice___bool__():
    a = NonePrice.zero()
    assert not a

# Generated at 2022-06-21 20:25:00.816830
# Unit test for method lte of class Money
def test_Money_lte():
    assert NoMoney <= NoMoney
    assert NoMoney <= SomeMoney(CAD, 0, Date.today())
    assert NoMoney <= SomeMoney(CAD, 0.0, Date.today())
    assert NoMoney <= SomeMoney(CAD, Decimal("0"), Date.today())
    assert SomeMoney(CAD, 0, Date.today()) <= NoMoney
    assert SomeMoney(CAD, 0.0, Date.today()) <= NoMoney
    assert SomeMoney(CAD, Decimal("0"), Date.today()) <= NoMoney
    assert NoMoney <= SomeMoney(EUR, 0, Date.today())
    assert SomeMoney(EUR, 0, Date.today()) <= NoMoney
    assert SomeMoney(EUR, 0, Date.today()) <= SomeMoney(EUR, 0, Date.today())

# Generated at 2022-06-21 20:25:11.041060
# Unit test for method __add__ of class Money
def test_Money___add__():
    import pytest
    from decimal import InvalidOperation
    from alvi.commons.errors import ProgrammingError
    from alvi.commons.zeitgeist import Date
    from alvi.exchange import FXRateService, FXRateLookupError
    from alvi.currencies import Currency
    #
    # Test: Test the case that two incompatible currencies are summed.
    #
    with pytest.raises(IncompatibleCurrencyError):
        Money.of(Currency.CAD, Decimal("123.45"), Date.today()).add(
            Money.of(Currency.JPY, Decimal("123.45"), Date.today())
        )
    #
    # Test: Test the case that two defined monies are summed up.
    #

# Generated at 2022-06-21 20:25:23.103408
# Unit test for method gt of class Money
def test_Money_gt():
    from nose.tools import assert_true, assert_false
    from .currencies import USD, GBP, EUR
    from .money import Money, SomeMoney
    from .exchange import FXRateService, FXRate, FXRateNotFoundError

    fxs = FXRateService()
    USD, GBP, EUR

    USD_Money = SomeMoney(USD, 10, '2018-01-01')
    USD_Money1 = SomeMoney(USD, 20, '2018-01-01')


# Generated at 2022-06-21 20:25:32.378375
# Unit test for method __pos__ of class SomeMoney
def test_SomeMoney___pos__():
    ## We test this by *trying* to get ``Money`` base class to have a reference to ``SomeMoney``, which will fail
    ## because ``SomeMoney`` is not a base class of ``Money``. In other words, this is a negative test.
    try:
        Money.__pos__(NoMoney)
    except AttributeError as exc:
        if str(exc) == "type object 'Money' has no attribute '__pos__'":
            return
        else:
            raise
    assert False, "Test failed, ``__pos__`` of ``Money`` refers to a method of the same name in ``SomeMoney``."


## Unit tests for method SomeMoney.__pos__
test_SomeMoney___pos__()



# Generated at 2022-06-21 20:25:36.331626
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    # define function inputs
    some_price = Price(Currency("USD"), Decimal("10"), Date(month=1, year=2020))

    # define expected results
    expected = True

    # execute function under test
    actual = some_price.as_boolean()

    assert actual == expected


# Generated at 2022-06-21 20:25:40.470308
# Unit test for method with_qty of class Money
def test_Money_with_qty():
    # Setup
    from .currencies import USD
    from .dateranges import Day
    from .exchange import StaticFXRateService
    from .money import Money
    from .timezones import UTC

    # Setup exchange rate service:
    fx_service = StaticFXRateService({(USD, USD): 1.0}, base_ccy=USD)

    # Test:
    m1 = Money.of(USD, 1.0, Date(2017, 11, 15, tzinfo=UTC))
    assert m1.with_qty(0.5) == Money.of(USD, 0.5, Date(2017, 11, 15, tzinfo=UTC))

# Generated at 2022-06-21 20:25:46.130341
# Unit test for method with_dov of class Money
def test_Money_with_dov():
    BaseTester.run(
        Money.with_dov,
        [
            (NoMoney, Date(2018, 9, 1), NoMoney),
            (SomeMoney(USD, Decimal("100.00"), Date(2018, 9, 1)), Date(2018, 9, 30), SomeMoney(USD, Decimal("100.00"), Date(2018, 9, 30))),
            (SomeMoney(USD, Decimal("100.00"), Date(2018, 9, 1)), Date(2018, 11, 21), SomeMoney(USD, Decimal("100.00"), Date(2018, 11, 21))),
            (SomeMoney(USD, Decimal("100.00"), Date(2018, 9, 1)), Date(2018, 9, 1), SomeMoney(USD, Decimal("100.00"), Date(2018, 9, 1))),
        ],
    )


# Generated at 2022-06-21 20:28:17.715310
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    IncompatibleCurrencyError(Currency("CHF"), Currency("USD"))

## ===== Cache of Zero Money and Zero Prices =====
#: Provides a singleton instance of no money.
NoMoney = NoneMoney(Currency("XXX"))
#: Provides a singleton instance of no price.
NoPrice = NonePrice(Currency("XXX"), Currency("XXX"))

## ===== Cache of Zero Money and Zero Prices =====
#: Provides an abstract base class for value objects representing money.

# Generated at 2022-06-21 20:28:27.339500
# Unit test for method __sub__ of class SomePrice
def test_SomePrice___sub__():
    sp1 = SomePrice(Currency("USD"), 100, Date.today())
    sp2 = SomePrice(Currency("USD"), 200, Date.today())
    sp3 = SomePrice(Currency("USD"), 300, Date.today())
    assert (sp1 - sp2) == SomePrice(Currency("USD"), -100, Date.today())
    assert (sp2 - sp1) == SomePrice(Currency("USD"), 100, Date.today())
    assert (sp1 - sp3) == SomePrice(Currency("USD"), -200, Date.today())

# Generated at 2022-06-21 20:28:37.742054
# Unit test for method __float__ of class Price
def test_Price___float__():
    from datetime import date
    from finance.session import build_session
    from finance.ccy import GBP
    from finance.measure import FOREIGN_EXCHANGE_RATE

    # Import the analytics module for computing FX rates.
    from finance.analytics import fx_rates

    session = build_session(
        start=date(2019, 1, 1),
        end=date(2019, 12, 31),
        ccy_term="GBP",
        ccy_ccy="USD",
        ccy_spot=1.0,
        ccy_rate=fx_rates,
    )

    gbp_spot = Money.of(GBP, 1, session.asof)
    usd_spot = Money.of(USD, 1, session.asof)

    # Compute GBP/USD spot rate.


# Generated at 2022-06-21 20:28:39.231992
# Unit test for constructor of class NonePrice
def test_NonePrice():
    np = NonePrice()
    assert np.defined == False
    assert np.undefined == True



# Generated at 2022-06-21 20:28:41.905114
# Unit test for method round of class SomePrice
def test_SomePrice_round():
    c = Currency('FOO')
    q = Decimal('1.234')
    d = Date.today()
    p = SomePrice(c, q, d)
    r = p.round()
    assert (r == SomePrice(c, Decimal(1), d))


# Generated at 2022-06-21 20:28:47.750277
# Unit test for method lt of class Money
def test_Money_lt():
    assert Money.of(ccy=Currency.of(code="EUR"), qty=Decimal(10), dov=Date.today()) < Money.of(ccy=Currency.of(code="EUR"), qty=Decimal(20), dov=Date.today())
    assert Money.of(ccy=Currency.of(code="EUR"), qty=Decimal(10), dov=Date.today()) < Money.of(ccy=Currency.of(code="USD"), qty=Decimal(10), dov=Date.today())

# Generated at 2022-06-21 20:28:58.165574
# Unit test for method is_equal of class Price
def test_Price_is_equal():
    undefined = Price.NA
    defined = Price(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1))
    assert defined.is_equal(defined)
    assert not defined.is_equal(undefined)
    assert not undefined.is_equal(defined)
    assert undefined.is_equal(undefined)
    assert defined.is_equal(Price(Currency("USD"), Decimal("1.0"), Date(2020, 1, 1)))
    assert not defined.is_equal(Price(Currency("USD"), Decimal("0.99"), Date(2020, 1, 1)))
    assert not defined.is_equal(Price(Currency("USD"), Decimal("1.0"), Date(2020, 1, 2)))

# Generated at 2022-06-21 20:29:12.006922
# Unit test for constructor of class IncompatibleCurrencyError
def test_IncompatibleCurrencyError():
    ccy1 = Currency.EUR
    ccy2 = Currency.USD
    assert IncompatibleCurrencyError(ccy1, ccy2) == IncompatibleCurrencyError(ccy1, ccy2)
    assert IncompatibleCurrencyError(ccy1, ccy2) == IncompatibleCurrencyError(ccy2, ccy1)
    assert IncompatibleCurrencyError(ccy1, ccy2) != IncompatibleCurrencyError(ccy1, ccy1)
    assert IncompatibleCurrencyError(ccy1, ccy2) != IncompatibleCurrencyError(ccy1, ccy1, "foo")
    assert IncompatibleCurrencyError(ccy1, ccy2) != IncompatibleCurrencyError(ccy2, ccy2)

# Generated at 2022-06-21 20:29:21.933826
# Unit test for method convert of class SomePrice
def test_SomePrice_convert():
    #Case 1:
    price = SomePrice(Currency("usd"),Decimal("1"),Date.now())
    to = Currency("eur")
    asof = price.dov # type: ignore
    strict = False
    assert price.convert(to,asof,strict).ccy == Currency("eur")
    assert price.convert(to,asof,strict).qty == Decimal("0.8")
    assert price.convert(to,asof,strict).dov == Date.now()

    #Case 2:
    price = SomePrice(Currency("usd"),Decimal("1"),Date.now())
    to = Currency("eur")
    asof = Date.now()
    strict = True
    assert price.convert(to,asof,strict).ccy == Currency("eur")


# Generated at 2022-06-21 20:29:23.332373
# Unit test for constructor of class NoneMoney
def test_NoneMoney():
    o=NoneMoney()
    assert o.defined == False


# Generated at 2022-06-21 20:31:00.876802
# Unit test for method round of class SomeMoney
def test_SomeMoney_round():
    assert SomeMoney(ccy="USD", qty=10.005, dov=Date.today()) == \
           SomeMoney(ccy="USD", qty=10.00, dov=Date.today())
    assert SomeMoney(ccy="USD", qty=10.005, dov=Date.today()) != \
           SomeMoney(ccy="USD", qty=10.00, dov=Date.today() + timedelta(days=1))
    assert SomeMoney(ccy="USD", qty=10.005, dov=Date.today()) != \
           SomeMoney(ccy="USD", qty=10.01, dov=Date.today())


# Generated at 2022-06-21 20:31:04.845233
# Unit test for method as_boolean of class Price
def test_Price_as_boolean():
    assert NoPrice.as_boolean() == False
    assert SomePrice(USD, 10, dov=None).as_boolean() == True
    assert SomePrice(USD, 0, dov=None).as_boolean() == False



# Generated at 2022-06-21 20:31:06.917233
# Unit test for method divide of class Money
def test_Money_divide():
    money = Money(None, None, None)
    other = Money(None, None, None)
    money.divide(other)



# Generated at 2022-06-21 20:31:09.020462
# Unit test for method __gt__ of class Price
def test_Price___gt__():
    assert Price.NA.__gt__(Price.of(USD, Decimal("1"), Jan1)) == False


# Generated at 2022-06-21 20:31:14.797577
# Unit test for method __lt__ of class Money
def test_Money___lt__():
    # Setup
    m1 = SomeMoney(Currency.USD, Decimal(100.0), Date.today())
    m2 = SomeMoney(Currency.USD, Decimal(200.0), Date.today())

    # Execute
    result = m1 < m2

    # Verify
    assert result is True, "Actual: " + str(result)



# Generated at 2022-06-21 20:31:24.935115
# Unit test for method with_dov of class SomeMoney
def test_SomeMoney_with_dov():
    global SomeMoney
    assert SomeMoney.of(ccy=None, qty=None, dov=None) is NoMoney
    from datetime import date
    assert SomeMoney.of(ccy=None, qty=Decimal("1.23"), dov=None) is NoMoney
    assert SomeMoney.of(ccy=None, qty=None, dov=date.today()) is NoMoney
    assert SomeMoney.of(ccy=USD, qty=None, dov=None) is NoMoney
    assert SomeMoney.of(ccy=USD, qty=Decimal("1.23"), dov=None) is NoMoney
    assert SomeMoney.of(ccy=USD, qty=None, dov=date.today()) is NoMoney
    dt = date(2020, 1, 1)
    assert SomeMoney

# Generated at 2022-06-21 20:31:28.970086
# Unit test for method __int__ of class NoneMoney
def test_NoneMoney___int__():
    no_money: Money = NoMoney
    try:
        no_money.__int__()
        assert False, "assert no_money.__int__() fails not raised"
    except TypeError:
        pass


# Generated at 2022-06-21 20:31:30.868403
# Unit test for method scalar_subtract of class NonePrice
def test_NonePrice_scalar_subtract():
    assert NonePrice().scalar_subtract(1) == NonePrice()
    assert NonePrice().scalar_subtract(Price(Currency.USD, 1.00, Date(1970, 1, 1))) == NonePrice()

# Generated at 2022-06-21 20:31:36.271171
# Unit test for method __le__ of class SomePrice
def test_SomePrice___le__():
    p1 = Price.of(GBP, 1, TODAY)
    p2 = Price.of(GBP, 1, TODAY)
    p3 = Price.of(GBP, 2, TODAY)
    p4 = Price.of(USD, 1, TODAY)
    assert p1 <= p2
    assert p1 <= p3
    assert p1 <= p4
    assert not p2 <= p1
    assert not p3 <= p1
    assert not p4 <= p1

# Generated at 2022-06-21 20:31:46.862749
# Unit test for method __gt__ of class SomePrice
def test_SomePrice___gt__():
    def test_true(price, other):
        assert price > other
    def test_false(price, other):
        assert not price > other
    def test_incompatible_ccy(price, other):
        with pytest.raises(IncompatibleCurrencyError):
            price > other

    #
    # undefined & some
    #
    # no price is never greater than other
    test_false(NoPrice, SomePrice(CAD, 1, Today))

    #
    # defined & undefined
    #
    # some price is always greater than no price
    test_true(SomePrice(CAD, 1, Today), NoPrice)

    #
    # defined & defined (same currency)
    #
    test_true(SomePrice(CAD, 100, Today), SomePrice(CAD, 1, Today))
    test_true