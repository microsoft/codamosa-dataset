

# Generated at 2022-06-25 07:41:43.305893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = test_case_0()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result["rc"] == 0
    assert result["stdout"] == ""
    assert result["stderr"] == ""
    assert result["msg"] == ""
    assert result["start"] == ""
    assert result["end"] == ""
    assert result["delta"] == ""

# Generated at 2022-06-25 07:41:51.208763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'lz\x14\xba\x9d\x07\x8c\xd5\'\x1b\x84\x8a\xbe'
    bytes_0 = b'2\x1d\x17\x08\x1c\x11\xec\x8e\x9c\x1d\xa5'
    float_0 = 3837.7
    dict_0 = {bool_0: str_0}
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, float_0, float_0, dict_0)

    # Actual function call
    result = action_module_0.run(dict_0, dict_0)
    assert result['_raw_params'] == str_0

# Generated at 2022-06-25 07:41:59.822169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'H+L+'
    bytes_0 = b'\xacv\x15n\xbf\xb2\x06\xf5\t\x1f\x18R'
    float_0 = 3579.9
    dict_0 = {str_0: float_0}
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, float_0, float_0, dict_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:09.264855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'H+L+'
    bytes_0 = b'\xacv\x15n\xbf\xb2\x06\xf5\t\x1f\x18R'
    float_0 = 3579.9
    dict_0 = {str_0: float_0}
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, float_0, float_0, dict_0)

    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars) is None


if __name__ == '__main__':
    import pytest
    pytest.main('test_action_module.py')

# Generated at 2022-06-25 07:42:14.585749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'm'
    bytes_0 = b'\xe3\xa0d\x8c~\xd9\x9c\xfa;\xf8\xbd\xe7\x1d5'
    float_0 = 951.0
    dict_0 = {'o': 4463.0, 'w': float_0, '5': float_0, 'V9': float_0, 'P': float_0, '|': str_0}
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, float_0, float_0, dict_0)
    result = action_module_0.run(dict_0, float_0)


# Generated at 2022-06-25 07:42:25.381168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    bool_0 = True
    str_0 = 'H+L+'
    bytes_0 = b'\xacv\x15n\xbf\xb2\x06\xf5\t\x1f\x18R'
    float_0 = 3579.9
    dict_0 = {str_0: float_0}
    dict_1 = {str_0: dict_0}
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, float_0, float_0, dict_1)
    dict_2 = {}
    dict_3 = {'a': dict_2}
    # dict_1 has a problem, it's possible to run without this.

# Generated at 2022-06-25 07:42:26.576917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:27.851686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # stub
    assert True

# Generated at 2022-06-25 07:42:35.376675
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:42:45.349862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'cM5y\xc0'

# Generated at 2022-06-25 07:42:49.640785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run()

# Generated at 2022-06-25 07:42:51.951358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    assert(isinstance(var_0, ansible.plugins.action.ActionBase.ActionBase))

# Generated at 2022-06-25 07:43:01.689346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test: method run of class ActionModule")
    var_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    var_1 = -2453
    var_2 = True
    var_3 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    var_4 = (var_2, var_1, var_0, var_3)
    var_5 = True
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6.run()
    return

# Generated at 2022-06-25 07:43:03.675843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    print("running test case 1")
    test_case_0()
  except:
    print("Error")
 
# Run the unit test
test_ActionModule_run()

# Generated at 2022-06-25 07:43:05.687469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    None


# Generated at 2022-06-25 07:43:06.932306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 07:43:10.054776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cmd_0 = False
    action_module_1 = ActionModule(cmd_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_1.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:43:15.415776
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test type: bool_0
    bool_0 = True
    bool_1 = bool_0
    # assert condition bool_1 == bool_0
    assert (bool_1 == bool_0)

    # Test type: bool_0
    bool_0 = True
    bool_1 = bool_0
    # assert condition bool_1 == bool_0
    assert (bool_1 == bool_0)

test_ActionModule_run()

# Generated at 2022-06-25 07:43:19.819465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    tmp = None
    task_vars = None
    action_module_2 = ActionModule()
    var_4 = action_module_2.run(tmp, task_vars)
    assert var_4 == None
  except Exception as e:
    print(e.args)
  finally:
    print('test_ActionModule_run completed')


# Generated at 2022-06-25 07:43:21.862376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if (bool_1 == True):
       action_run()
    else:
       action_run()

# Generated at 2022-06-25 07:43:26.142482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   assert action_run() == None

# Generated at 2022-06-25 07:43:36.832111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:40.810226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 07:43:50.829646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_1 = -2453
    bool_2 = True
    #Bytes test
    bytes_2 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    #Tuple test
    tuple_2 = None
    str_1 = 'EXAMPLES'
    #Tuple test
    tuple_3 = (bool_2, tuple_2, int_1, str_1)
    action_module_1 = ActionModule(bytes_1, int_1, bool_2, bytes_2, tuple_3, bool_2)
   

# Generated at 2022-06-25 07:43:54.760892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_0 = ActionModule()
    var_0 = input_0.run()

# Generated at 2022-06-25 07:43:56.258695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:44:02.798932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = None
        action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
        var_1 = action_module_0.run()
    except IndexError:
        print("IndexError")
    finally:
        print("Finally")

# Generated at 2022-06-25 07:44:10.583057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x99\xc6\x9a\x17\x80\xf3\xa6\xab\xde\xfc\xfb\xc4\xd9\xe4\xdc'
    int_0 = -10934
    bool_0 = True
    bool_1 = False
    tuple_0 = -16
    tuple_1 = (bool_0, bool_1, int_0, int_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()
    var_1 = action_run()
    var_2 = action_run()

# Generated at 2022-06-25 07:44:19.597758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:44:20.021396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:44:31.438460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(bytes, int, bool, bytes, tuple, bool)
    var_1 = var_0.run()
    assert var_1 == None, "Test is failed"

# Generated at 2022-06-25 07:44:38.541357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {'_uses_shell': True}
    task_vars_0 = {'ansible_check_mode': True, 'ansible_fact_path': '/var/lib/ansible/facts.d'}

    # Create an instance of ActionModule with arguments: bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0
    # action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0 = ActionModule("", 0, True, "", ("", None, 0, "EXAMPLES"), True)

    # Invoke method run of action_module_0
    result = action_module_0.run(None, task_vars_0)
    assert result is None


# Generated at 2022-06-25 07:44:44.694942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(b"e\xff\xac\xd7(A\x91\x1b\xae\xc4\x05", -2960, True, b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99", (True, None, -2453, 'EXAMPLES'), False)
    action_module_0.run()

# Generated at 2022-06-25 07:44:51.757527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    bytes_1 = b"P\xc4\x1d\x8e\x01\x81\xa9o\xac\x1d\xad\xec\x02"
    int_1 = 1828


# Generated at 2022-06-25 07:45:03.613658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'EXAMPLES'
    int_0 = -2453
    str_1 = 'EXAMPLES'
    int_1 = -2453
    dict_0 = dict()
    dict_0['k'] = 'v'
    dict_0['k'] = 'v'
    dict_0['k'] = 'v'
    dict_0['k'] = 'v'
    dict_1 = dict()
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'
    dict_1['k'] = 'v'

# Generated at 2022-06-25 07:45:07.197196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:10.906660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    set_0 = {(0, '', int_0) for int_0 in range(6)}
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_module_0.run(set_0)

# Generated at 2022-06-25 07:45:19.985128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b"EXAMPLE"
    int_1 = 1
    bool_2 = False
    bytes_2 = b"EXAMPLE"
    tuple_2 = (bool_2, bytes_2, int_1, bytes_1)
    bool_3 = True
    action_module_1 = ActionModule(bytes_1, int_1, bool_2, bytes_2, tuple_2, bool_3)
    del int_1
    del tuple_2
    del bool_2
    del bytes_2
    del bytes_1
    del bool_3
    var_1 = action_module_1.run()
    assert var_1 is None

# Test cases for function action_run

# Test case 0

# Generated at 2022-06-25 07:45:25.443998
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:45:26.076450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:49.927276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    task_vars = OrderedDict()
    unittest.main()

# Generated at 2022-06-25 07:45:50.355284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-25 07:45:56.820472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing
    # 1. Calling run with two arguments
    # 2. Calling run with three arguments
    # 3. Calling run with two arguments

    # 1. Calling run method
    # Preconditions

    action_module_0 = ActionModule()
    # Postconditions

    try:
        # Action
        var_0 = action_module_0.run()
        # Assertion
        assert var_0 is None
    except Exception:
        var_0 = None
        pass
    # Action
    # Postconditions

    # 2. Calling run method
    # Preconditions

    action_module_0 = ActionModule()
    # Postconditions


# Generated at 2022-06-25 07:46:00.452217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = create_object(ActionModule, b'\x12n\xca\x03\xcd\xd7\xe5\'\x14\xf6\x91\xe1\x99', -2453, True, b'\x12n\xca\x03\xcd\xd7\xe5\'\x14\xf6\x91\xe1\x99', (True, None, -2453, 'EXAMPLES'), True)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:08.057120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:13.988828
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Imports

    # Instantiate object of class ActionModule
    action_module_0 = ActionModule()

    # Get parameters of method run
    task_vars_0 = None

    # Call method run
    action_module_0.run(task_vars_0)

# Generated at 2022-06-25 07:46:21.470285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    # int_0 = -2453
    # bool_0 = True
    # bool_1 = True
    # tuple_0 = None
    # str_0 = 'EXAMPLES'
    # tuple_1 = (bool_1, tuple_0, int_0, str_0)
    # action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    # var_0 = action_module_0.run()
    pass
#====



# -----

# Generated at 2022-06-25 07:46:30.598611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = None
    var_1 = action_module_0.run(var_0, var_0)

# Generated at 2022-06-25 07:46:34.182239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None, "No exception raised."

# Generated at 2022-06-25 07:46:39.840525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\xe3u\xca\xb6\x17M%\xf6\x83\x9fK'
    int_0 = -1101
    bool_0 = False
    tuple_0 = None
    tuple_1 = (bytes(), )
    tuple_2 = (int_0, int_0, bool_0, tuple_1)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_2, bool_0)
    action_module_0.run(tuple_0)


# Generated at 2022-06-25 07:47:14.968920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:24.317543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99", -2453, True, b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99", (True, None, -2453, 'EXAMPLES'), True)
    assert type(action_module_0.run()) is ActionBase
    assert type(action_module_0.run(tmp=None)) is ActionBase
    assert type(action_module_0.run(task_vars=None)) is ActionBase
    assert type(action_module_0.run(tmp=None, task_vars=None)) is ActionBase



# Generated at 2022-06-25 07:47:27.804955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unittest
    return None


# Generated at 2022-06-25 07:47:35.549191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict = {}
    int_0 = -2966
    float_0 = float(-21.86)
    str_0 = 'EXAMPLES'
    list_0 = [int_0, int_0]
    dict_1 = dict
    dict_0 = dict
    dict['foo'] = dict_0
    dict_0['foo'] = dict_1
    dict_0['foo'] = dict_1
    dict_0['foo'] = dict_1
    dict_1['foo'] = dict_1
    dict_1['foo'] = dict_0
    dict_1['foo'] = dict_0
    dict_1['foo'] = dict_0
    dict_0['foo'] = int_0
    dict_0['foo'] = float_0
    dict_0['foo'] = float_0
    dict

# Generated at 2022-06-25 07:47:36.794980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 =ActionModule()
    result = action_module_0.run()

# Generated at 2022-06-25 07:47:45.927894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0.run(tmp=None, task_vars=None)
    return str_0

# Generated at 2022-06-25 07:47:48.482516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# OLD STUFF from older versions.

# Note: definitely is not a generator which is better for memory footprint.
# This is just for testing the method interaction.
# (I do not have time to refactor this atm)

# Generated at 2022-06-25 07:47:49.046396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:47:56.021477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x97\xb4\x96\x1c\x12\xf2\x07\xb7\x96\x14\x07'
    int_0 = -65
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()
    return var_0

# Generated at 2022-06-25 07:47:57.468914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #assert return_value == expected_value
    assert True == True


# Generated at 2022-06-25 07:49:17.733542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99"
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:21.841189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aModule = ActionModule(b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99", -2453, True, b"\x12n\xca\x03\xcd\xd7\xe5'\x14\xf6\x91\xe1\x99", (True, None, -2453, 'EXAMPLES'), True)
    
    # Test case when tmp=None, task_vars=None
    result = aModule.run(None, None)
    assert result

# Generated at 2022-06-25 07:49:31.667683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module_0 = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module_0 = AnsibleModule()

    # Get the value of variable tmp from ansible_module_0
    var_0 = ansible_module_0.tmp()

    # Get the value of variable tmp from ansible_module_0
    var_1 = ansible_module_0.tmp()

    # Get the value of variable task_vars from ansible_module_0
    var_2 = ansible_module_0.task_vars()

    # Call method run from action_module_0 with arguments var_0, var_1, and var_2
    action_module_0.run(var_0, var_1, var_2)


# pylint: disable=too

# Generated at 2022-06-25 07:49:35.284089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Needs at least one test
    assert False

# Generated at 2022-06-25 07:49:43.357712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x14^\xdb\xa6\xc1\xbbK\xdf\xdf8\x93\x01\x11\xfd'
    int_0 = -2453
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()
    print(var_0)


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:49:44.906266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run().equals("EXAMPLES") == True



# Generated at 2022-06-25 07:49:46.554300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 07:49:51.174650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b'Test for method run in class ActionModule.'
    int_0 = 9543
    tuple_0 = None
    bytes_0 = b'\x11\xcc\xf3\x01\xe2\x17\x97\x9dv\x94\x8c\xc6\xae'
    bytes_1 = b'l\xb3\x9c\x89\x85\xbc\x19\xd7\x97\x8c\x97\x98\xf9\xa5\x1c\x8a'
    int_1 = -4760
    str_0 = 'COMMANDS'
    tuple_1 = (str_0, tuple_0, bytes_0, int_0)

# Generated at 2022-06-25 07:49:59.802617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x95^\xba\xbb\xd6\xd6\xdb\xfb\x94\x14\xe1\xa0\xc2"
    int_0 = -6083
    bool_0 = True
    bool_1 = True
    tuple_0 = None
    str_0 = 'EXAMPLES'
    tuple_1 = (bool_1, tuple_0, int_0, str_0)
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:50:05.695947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, int_0, bool_0, bytes_0, tuple_1, bool_0)
    action_module_0.run(task_vars=var_0)