

# Generated at 2022-06-25 07:41:37.051163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:41:45.211768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1192
    str_0 = ' dt9B}}O,le(EV(B>fW'
    float_0 = 1484.498324
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(int_0, str_0, int_0, str_0, float_0, list_0)

    # Test for case 0

    assert action_module_0.run(task_vars=None) == None

# Generated at 2022-06-25 07:41:50.925244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6287
    str_0 = ')*'
    int_1 = -9227
    str_1 = 'mH<'
    float_0 = -1094.111
    list_0 = [int_1, str_0, int_0, int_1, int_1]
    result = test_case_0.run(int_0, list_0)
    assert result == float_0


# Generated at 2022-06-25 07:41:55.430128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1192
    str_0 = ' dt9B}}O,le(EV(B>fW'
    float_0 = 1484.498324
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(int_0, str_0, int_0, str_0, float_0, list_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp=tmp, task_vars=task_vars)

    assert result == None

# Generated at 2022-06-25 07:42:01.310709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1192
    str_0 = ' dt9B}}O,le(EV(B>fW'
    float_0 = 1484.498324
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(int_0, str_0, int_0, str_0, float_0, list_0)
    task_vars = {}
    result = action_module_0.run(None, task_vars=task_vars)
    assert type(result) is dict
    assert result == {}

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:06.195926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1192
    str_0 = ' dt9B}}O,le(EV(B>fW'
    float_0 = 1484.498324
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(int_0, str_0, int_0, str_0, float_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:42:08.352881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = test_case_0()

    assert isinstance(action_module_0.run(), dict)

# Generated at 2022-06-25 07:42:18.008548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1399
    str_0 = 'r'
    str_1 = ' dt9B}}O,le(EV(B>fW'
    float_0 = 736.38205
    float_1 = 1484.498324
    float_2 = 998.008
    float_3 = 827.7535
    float_4 = 1484.498324
    list_0 = [str_1, str_1]
    list_1 = ['wbs.ab']
    list_2 = ['wbs.ab']
    list_3 = ['wbs.ab']
    list_4 = ['wbs.ab']
    list_5 = ['wbs.ab']
    list_6 = [float_2, float_3]

# Generated at 2022-06-25 07:42:26.984083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1767
    str_0 = '#D6(:dzJfL`lA@n$m3'
    int_1 = -1089
    str_1 = 'zU_d]$'
    float_0 = 8.796028
    list_0 = [str_1, str_1, str_0]
    action_module_0 = ActionModule(int_0, str_0, int_1, str_1, float_0, list_0)
    tmp = 'i)rM'
    dict_0 = {str_0: str_1, tmp: str_0}
    action_module_0.run(tmp, dict_0)


# Generated at 2022-06-25 07:42:28.567400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Test class for ActionModule

# Generated at 2022-06-25 07:42:31.454236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj0 = ActionModule()
    parallel_result = obj.run(None, None)
    assert isinstance(parallel_result, tuple)

# Generated at 2022-06-25 07:42:41.129254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for condition a == b
    action_module_0 = ActionModule()
    var_0 = action_run()
    if var_0 == 0:
        var_0 = action_run()
    # Test for condition a != b
    action_module_0 = ActionModule()
    var_1 = action_run()
    if var_1 != 0:
        var_1 = action_run()
    # Test for condition a >= b
    action_module_0 = ActionModule()
    var_2 = action_run()
    if var_2 >= 0:
        var_2 = action_run()
    # Test for condition a > b
    action_module_0 = ActionModule()
    var_3 = action_run()
    if var_3 > 0:
        var_3 = action_run()
    # Test

# Generated at 2022-06-25 07:42:42.725973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    tmp_2 = None
    var_2 = var_1.run(tmp_2)

# Generated at 2022-06-25 07:42:47.019275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:42:50.119103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    action_module_0 = ActionModule()
    var_0 = ActionBase()
    var_1 = action_module_0.run(tmp=var_0, task_vars=var_0)


# Generated at 2022-06-25 07:42:54.115275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)

# Generated at 2022-06-25 07:42:58.037425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # AssertionError: Result was not a dict, instead was: 'None'
    # Uncomment these to test the method
    # action_module_0.run(tmp=None)
    # action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:43:00.958618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(tmp=var_1, task_vars=var_2)


# Generated at 2022-06-25 07:43:02.531791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case(action_module_0)



# Generated at 2022-06-25 07:43:03.022665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:43:09.019969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        os.remove('test_file.txt')
    except OSError:
        pass
    fd = open('test_file.txt', 'w')
    fd.write(str_3)
    fd.close()

    
    os.remove('test_file.txt')
    test_case_0()

# Generated at 2022-06-25 07:43:15.703274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:43:23.735767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    float_0 = 782.218
    list_0 = []
    int_0 = -134

# Generated at 2022-06-25 07:43:29.101641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:43:34.070117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:43:41.308210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1085.1017
    set_0 = {float_0, float_0, float_0}
    str_0 = 'eWpPvJU'
    dict_0 = {}
    int_0 = -344
    tuple_0 = (int_0, int_0, str_0)
    int_1 = -1366
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:43:50.170089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 4676.349
    int_0 = -389
    str_0 = '-0\x84\x00hv'
    str_1 = 'x'
    bool_0 = False
    list_0 = []
    int_1 = -1667
    str_2 = 'F1Kl]`\x10\x8e'
    action_module_0 = ActionModule(float_0, int_0, str_0, str_1, bool_0, list_0, int_1, str_2)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:44:01.291243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 1259
    str_0 = '#include <stdio.h>\n#include <string.h>\n\nint main () {\nchar szBuffer[] = \'\'#include <stdio.h>\n#include <string.h>\n\nint main () {\nchar szBuffer[] = \'\'Hello from codeeval.com\'\';\nprintf (\'\'%s\'\', szBuffer);\nreturn 0;\n}\n\'\';\nprintf (\'\'%s\'\', szBuffer);\nreturn 0;\n}\n'
    bool_0 = True
    str_1 = '"\nGiLp'
    list_0 = [str_1]
    str_2 = '%s (%s)'
    action_module

# Generated at 2022-06-25 07:44:07.228998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)
    action_module.run(set_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:44:09.442168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    set_0 = set()
    assert False == ActionModule.run(action_module_0, set_0)
    assert None == ActionModule.run(action_module_0)

# Generated at 2022-06-25 07:44:23.457402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = 4844.71002813
    set_0 = {float_0, float_0, float_0}
    str_0 = '?\x85z\n\n'
    dict_0 = {}
    int_0 = 19
    tuple_0 = (int_0, int_0, str_0)
    int_1 = -1900
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_1 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:44:24.413108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    test_case_0()

# Generated at 2022-06-25 07:44:35.511169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -7989.0
    tuple_1 = (float_0, float_0, float_0)
    int_1 = -1407
    str_0 = '\x0eU\x80\xe2\x1d\xfd\xeb\x1b\x81\x00\xab\x17mr'
    bool_0 = True
    list_0 = []
    str_1 = '%s (%s)'
    action_module_1 = ActionModule(tuple_1, int_1, str_0, bool_0, list_0, str_1)
    action_module_1.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()


#========================================

# Generated at 2022-06-25 07:44:43.805688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock object
    tmp_mock = Mock()
    task_vars_mock = Mock()
    ansible.plugins.action.ActionModule.run(tmp_mock, task_vars_mock)
    assert tmp_mock == tmp_mock
    assert task_vars_mock == task_vars_mock


if __name__ == '__main__':
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

    # Unit test for class ActionModule
    test_case_0()

# Generated at 2022-06-25 07:44:46.322586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: How to implement test for the case when the action given is not in the action_loader
    assert False

# Generated at 2022-06-25 07:44:52.293870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:45:03.484560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'nxqfq'}
    str_0 = 'nxqfq'
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)
    set_1 = {int_1}
    action_module_1 = action_module_0.run(set_1)
    return action_module_1

# Generated at 2022-06-25 07:45:04.826290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # <Output>
    # </Output>
    pass


# Generated at 2022-06-25 07:45:12.752074
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test with single argument
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:45:21.590308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:45:30.769898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 07:45:38.594388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xd4\x9c\xfd\xf6\x8d\xa2\x95\xd1\xdb'
    set_0 = {bytes_0, bytes_0, bytes_0}
    action_module_0 = ActionModule(set_0)
    int_0 = -62
    str_0 = '\x18\x15\x1fM\x7f\x17\x9f\x94\xef\x1b'
    dict_0 = {}
    action_module_1 = ActionModule(int_0, str_0, dict_0)
    var_0 = action_module_1.run()



# Generated at 2022-06-25 07:45:48.917995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 15.115
    set_0 = {float_0, float_0, float_0}
    str_0 = '.<YV1Giq'
    dict_0 = {}
    int_0 = 375
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1606
    str_1 = '.\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = 't%sN'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)
    tuple_1 = (float_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 07:45:52.542263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(action_module_1, '\x8f')
    action_module_0.run(action_module_1)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:46:02.144956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1083
    str_1 = '\x1e'
    list_1 = [5926, int_0, '%(']
    bool_0 = True
    dict_1 = {'Sti9a', str_1, int_0}
    float_0 = 5133.0
    action_module_0 = ActionModule(list_1, int_0, bool_0, dict_1, float_0, str_1)
    set_0 = {int_0, list_1, dict_1}
    float_1 = float_0
    try:
        action_module_0.run(float_1, set_0)
    except Exception as exception_0:
        print(exception_0)
    int_0 = -1083

# Generated at 2022-06-25 07:46:12.669706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'\x99\x07\xaa\xe7\x9f\x7f\xa1\x9a\x93', '\x99\x07\xaa\xe7\x9f\x7f\xa1\x9a\x93', '\x99\x07\xaa\xe7\x9f\x7f\xa1\x9a\x93'}
    str_0 = 'h%&k@RS\xfb)\xdfQ'
    dict_0 = {}
    int_0 = -2336
    tuple_0 = ('\xfc\x8c', '\xfc\x8c', str_0)
    int_1 = 2493

# Generated at 2022-06-25 07:46:15.183511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:46:25.106119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declarations
    float_0 = 8272.55769
    set_0 = {float_0, float_0, float_0}
    str_0 = 'flvEi'
    dict_0 = {}
    int_0 = -1910
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1666
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = True
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:46:30.600136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try: test_case_0()
    except: pass


if __name__ == '__main__':
    import sys
    import os

    base_path = os.path.dirname(__file__) + os.sep + '..' + os.sep + '..'
    sys.path.append(base_path)

    # Unit test
    test_ActionModule_run()

# Generated at 2022-06-25 07:46:37.209182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '%c'
    bool_0 = False
    int_0 = -1753
    int_1 = 1681
    str_1 = 'fCzxgMG'
    action_module_0 = ActionModule(str_0, int_0, int_1, bool_0, str_1)
    bytes_0 = b'\xb6\x92\xfeN\xdb\x99\xda\x01w\xf6\xbfG\x9a\x0d'
    int_2 = -766
    list_0 = []
    str_2 = 'jR'
    set_0 = {int_2}
    str_3 = 'zFjM'

# Generated at 2022-06-25 07:47:02.888955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 7648.23
    set_0 = {float_0, float_0, float_0}
    str_0 = 'fU6g47Sw'
    dict_0 = {}
    int_0 = 576
    tuple_0 = (str_0, int_0, int_0)
    int_1 = -1195
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:47:07.881927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -821.800935539
    str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
    list_0 = []
    str_1 = '%s (%s)'
    action_module_0 = ActionModule(float_0, float_0, str_0, float_0, list_0, str_1)
    int_0 = 3920
    dict_0 = {}
    str_2 = 'LtzGvjR'
    tuple_0 = (int_0, int_0, str_2)
    int_1 = -1671
    float_1 = 3920.129
    set_0 = {float_1, float_1, float_1}
    str_3 = '"\nGiLp'

# Generated at 2022-06-25 07:47:17.625559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1045.69351907
    set_0 = {float_0, float_0, float_0}
    str_0 = 'ABCDEFG123456789'
    dict_0 = {str(x): x for x in range(0, 150)}
    int_0 = -865
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 986
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:47:27.946218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:47:34.540901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 9045.060
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:47:45.105698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1402.79121
    set_0 = {float_0, float_0, float_0}
    str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_1 = '%s (%s)'
    action_module_0 = ActionModule(str_0, bool_0, list_0, str_1)
    bytes_0 = b'\x95\xff\xf9+\x7f<\xff\x1e\x07b'
    action_module_1 = ActionModule(bytes_0, action_module_0)
    tuple_0 = (True, bytes_0, float_0)
    var_0 = action_module_1.run(set_0)



# Generated at 2022-06-25 07:47:53.555799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3088.4
    dict_0 = {}
    int_0 = -1710
    tuple_0 = (int_0, int_0, int_0)
    set_0 = {tuple_0, int_0, tuple_0, int_0}
    str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_1 = '%s (%s)'
    action_module_0 = ActionModule(int_0, int_0, str_0, bool_0, list_0, str_1)
    set_1 = {tuple_0, int_0, dict_0, tuple_0, dict_0, int_0}
    dict_1 = {}
    bytes_0

# Generated at 2022-06-25 07:48:00.209760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tuple_0 = ()
  int_0 = 1711
  str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
  # Call method with arguments
  action_module_0 = ActionModule(tuple_0, int_0, str_0, False, list(), '%s (%s)',  )
  action_module_0.run()

# Generated at 2022-06-25 07:48:03.351178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Test method for class ActionModule

# Generated at 2022-06-25 07:48:09.378586
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #  Create an object of the class
    action_module_0 = ActionModule()

    #  Use the run method
    action_module_0.run()

# Generated at 2022-06-25 07:48:57.711341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 6320.95
    set_0 = {float_0, float_0, float_0}
    str_0 = 'u2rHBo'
    dict_0 = {}
    int_0 = -819
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:49:08.599181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:49:15.521370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 88.619
    set_0 = {float_0, float_0, float_0}
    str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
    dict_0 = {}
    int_0 = -1995
    tuple_0 = (int_0, int_0, str_0)
    int_1 = -1892
    str_1 = 'h\x13\xdc\x8e\x9c\xd4\x1a\x8a\xfc\xe5\x05'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'

# Generated at 2022-06-25 07:49:21.291073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set_0 refers to variable set_0
    # Type: set
    dict_0 = {}
    int_0 = 1711
    bool_0 = False
    list_0 = []
    str_0 = '\n# This module does not return anything except plays or tasks to execute.\n'
    action_module_0 = ActionModule(int_0, dict_0, bool_0, list_0, str_0)
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    float_0 = 4449.9
    tuple_0 = (str_1, action_module_0, float_0)
    str_2 = 'jKQP'
    dict_1 = {}
    int_1 = -1051
    list_1 = []
    bool_

# Generated at 2022-06-25 07:49:27.652964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception:
        print("Exception in user code:")
        print("-" * 60)
        traceback.print_exc(file=sys.stdout)
        print("-" * 60)
        raise Exception("Test case 0 failed.")

# Generated at 2022-06-25 07:49:28.409161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:49:32.714719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3920.129
    set_0 = {float_0, float_0, float_0}
    str_0 = 'LtzGvjR'
    dict_0 = {}
    int_0 = -1671
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 1711
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    bool_0 = False
    list_0 = []
    str_2 = '%s (%s)'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, bool_0, list_0, str_2)

# Generated at 2022-06-25 07:49:35.423695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:49:37.172142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This method will be tested via test_case_0
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:49:39.335353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Place your code here
    assert test_case_0() == 1

# Generated at 2022-06-25 07:51:11.974635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {0}
    action_module_0 = ActionModule((0, 0, ''), 0, '\n# This module does not return anything except plays or tasks to execute.\n', False, [], '%s (%s)')
    bytes_0 = b'\x95\xff\xf9+\x7f<\xff\x1e\x07b'
    action_module_1 = ActionModule('', {}, action_module_0, bytes_0, -675, '"\nGiLp')
    var_0 = action_module_1.run(set_0)

# Generated at 2022-06-25 07:51:19.295434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    set_0 = {float_0, float_0, float_0}
    str_0 = 'RHZ'
    dict_0 = {}
    int_0 = -2776
    tuple_0 = (int_0, int_0, str_0)
    int_1 = 2369
    str_1 = '\n# This module does not return anything except plays or tasks to execute.\n'
    str_2 = '\nGiLp\n'
    action_module_0 = ActionModule(tuple_0, int_1, str_1, str_2)
    bytes_0 = b'\xc6\xae\xe1\xda\xe3\x8b\x81\xde\x91\xae'
    action_module_1 = ActionModule

# Generated at 2022-06-25 07:51:20.874956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:51:29.217103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1057
    dict_0 = {}
    int_1 = 1025
    str_0 = 'XHNtgq3'
    action_module_0 = ActionModule(int_0, dict_0, int_1, str_0)
    int_2 = 1617
    str_1 = '\x91\xcf\x1b\x9e\x9f\xe8\xdb\x84\x1d\xaa\x90'
    str_2 = '\xf9\xec\x8d\x12\xcc\xd5\x1a\xe1\xfd\xa5\x9e\xc8\x8c\xcf\xda'
    dict_1 = {}