

# Generated at 2022-06-25 07:41:32.635271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass #TODO: Implement unit test for method run of class ActionModule


# Generated at 2022-06-25 07:41:40.409887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -1320.28961
    str_1 = 'See website for:'
    bool_1 = False
    int_1 = 177
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(float_1, str_1, str_1, str_1, bool_1, int_1)
    result = action_module_1.run(tmp, task_vars)
    assert result['rc'] == 0

# Generated at 2022-06-25 07:41:42.275797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result == None

# Generated at 2022-06-25 07:41:47.762477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1320.28961
    str_0 = 'See website for:'
    bool_0 = False
    int_0 = 177
    action_module_0 = ActionModule(float_0, str_0, str_0, str_0, bool_0, int_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 07:41:51.949661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -176.0485
    str_0 = 'i#'
    str_1 = 'e4-Q'
    str_2 = '5:5'
    bool_0 = True
    int_0 = -19
    action_module_0 = ActionModule(float_0, str_0, str_1, str_2, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:41:54.502864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -5.05212
    str_0 = 'Lueu\\<d'
    bool_0 = False
    int_0 = 90
    action_module_0 = ActionModule(float_0, str_0, str_0, str_0, bool_0, int_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:41:58.556761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1320.28961
    str_0 = 'See website for:'
    bool_0 = False
    int_0 = 177
    action_module_0 = ActionModule(float_0, str_0, str_0, str_0, bool_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 07:42:02.844160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 5299.0
    str_0 = 'B'
    str_1 = 'dll0lgw'
    str_2 = 'H`n+X['
    bool_0 = False
    int_0 = 1
    action_module_0 = ActionModule(float_0, str_0, str_1, str_2, bool_0, int_0)
    tmp__0 = '@@p[G_'
    task_vars__0 = 'Zwh`B/V'
    result = action_module_0.run(tmp__0, task_vars__0)
    assert result == 'H`n+X['

# Generated at 2022-06-25 07:42:08.512835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -398
    str_0 = 's'
    float_0 = -43.54
    str_1 = 'jQUq>|:k)1XA,nEv'
    float_1 = -27.96
    float_2 = 90.0
    action_module_0 = ActionModule(float_0, str_0, str_1, str_1, float_1, float_2)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:42:15.135125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1356
    float_0 = -0.086
    str_0 = 'See website for:'
    str_1 = 'ansible'
    int_1 = 353
    str_2 = 'ansible'
    float_1 = -0.073
    str_3 = 'ansible'
    str_4 = 'ansible'
    int_2 = -1323
    float_2 = -0.212
    str_5 = 'ansible'
    str_6 = 'See website for:'
    str_7 = 'See website for:'
    int_3 = -1232
    str_8 = 'See website for:'
    str_9 = 'ansible'
    str_10 = 'ansible'
    str_11 = 'See website for:'

# Generated at 2022-06-25 07:42:23.317198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    tmp=None
    self=ActionModule()
    task_vars=None
    # expect a TypeError as arguments (tmp,task_vars) are not provided
    expected_err=TypeError
    actual_err=None
    try:
        self.run
    except TypeError as err:
        actual_err=err
    assert actual_err==expected_err

# Generated at 2022-06-25 07:42:32.176985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2540.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'grP:0T'
    str_1 = 'V+8H"&k-^*q,Zg+~V7'
    int_0 = 2054
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10

# Generated at 2022-06-25 07:42:33.506830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = set()
    str_2 = input()

    # Input var

# Generated at 2022-06-25 07:42:37.590766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_run(bool_0)


# Generated at 2022-06-25 07:42:47.107606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    float_1 = float()
    float_1 = float()
    float_1 = float()
    float_1 = float()
    float_1 = float()
    float_1 = float()
    float_1 = float()
    float_1 = float()
    dict_0 = dict()
    dict_0 = dict

# Generated at 2022-06-25 07:42:53.416095
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = 'Rjf?;4A$s]sT|'
    str_2 = 'S:=O y&U0v`3z%c'
    set_0 = {str_0, str_2, str_0, str_0, str_0}
    float_0 = 767.0
    str_1 = 'J%*]g=@O%?^_7k'
    float_2 = 3644.0
    int_0 = 1065
    float_1 = 1754.0
    float_3 = 1582.0
    action_module_0 = ActionModule(str_2, float_1, int_0, str_0, str_1, set_0)
    var_0 = action_run(float_1)


# Generated at 2022-06-25 07:43:00.383510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_run(bool_0)

# Generated at 2022-06-25 07:43:05.422019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = int()
    set_0 = {var_0, var_0, var_0, var_0}
    action_module_0 = ActionModule(var_0, set_0, var_0, set_0, var_0, var_0, set_0)
    var_0 = action_run(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:43:11.622441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test data
    tmp = None
    task_vars = None
    # Set up mock
    with patch.object(ActionBase, 'run', autospec=True) as mock_run:

        # Call method
        args = [tmp, task_vars]
        if len(args) == 1 and isinstance(args[0], list):
            args = args[0]
        result = ActionModule._ActionModule__run(tmp, task_vars)

        # Assert
        assert result == mock_run.return_value
        mock_run.assert_called_with(tmp, task_vars)

# Generated at 2022-06-25 07:43:20.689875
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: move test to a proper place after action plugin is upgraded
    try:
        from ansible.plugins.action.shell import ActionModule
    except ImportError:
        pytest.skip("This test depends on ansible.plugins.action.shell")


# Generated at 2022-06-25 07:43:31.280809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = False
    float_2 = 3
    action_module_1 = ActionModule(float_2, bool_1, bool_1, bool_1, bool_1, bool_1)
    str_2 = 'iT'
    bool_2 = bool_1
    var_1 = 'h'
    float_3 = float_2
    list_0 = list()
    float_4 = float_2
    float_5 = float_3
    list_1 = list()
    set_1 = set()
    var_2 = 'f'

# Generated at 2022-06-25 07:43:36.510430
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Tests for method run

    action_module_0 = ActionModule(set_0, float_0, float_0, float_0, float_0, float_0, float_0)
    var_0 = action_module_0.run(tmp=set_0, task_vars=set_0)

# Generated at 2022-06-25 07:43:39.532996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:43:48.525011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    bool_0 = False
    var_0 = action_module_0.run(bool_0)

# Generated at 2022-06-25 07:43:53.228888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {0.40894004725930023, 0.40894004725930023, 0.40894004725930023, 0.40894004725930023}
    float_0 = 0.40894004725930023
    str_0 = 'dV;x&CpGB*Y0y0:| c'
    str_1 = '0^(Z'
    int_0 = 1988
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    set_1 = set()
    action_module_0.action_run(set_1, set_1)
    action_module_0.action_run(set_1, set_1)


# Generated at 2022-06-25 07:43:55.366452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No parameters for this test

    action_module_0 = ActionModule()
    # This test needs a file to execute
    args = {}
    return_value = action_module_0.run(**args)




# Generated at 2022-06-25 07:44:01.152272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method_0 = ActionModule(bool_0, set_0, str_0, str_1, int_0, set_0)
    method_0.run(bool_0, set_0)
    method_1 = None
    method_2 = None
    var_0 = method_2, method_1, method_2
    method_3 = var_0
    method_4 = bool_0, bool_0
    method_5 = vars(method_4)
    method_6 = 4031
    method_2 = vars(method_6)
    method_7 = filter(method_4, method_4)
    method_8 = filter(method_3, method_3)
    method_9 = filter(method_2, method_2)
    method_10 = filter(method_5, method_5)

# Generated at 2022-06-25 07:44:08.973047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule run')

    # Initialize variables
    tmp = None
    task_vars = None

    # Invoke method
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp, task_vars)

    # Test the result
    assert isinstance(result, dict)
    assert result['rc'] == 0

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()
    print('All tests passed')

# Generated at 2022-06-25 07:44:17.162358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {1.0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(1.0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run()



# Generated at 2022-06-25 07:44:20.376718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 4476.0
    str_0 = '}76'
    str_1 = 'P'
    set_0 = {str_1, float_0, float_0}
    int_0 = 1298
    action_module_0 = ActionModule(str_1, set_0, float_0, str_0, int_0, set_0)
    action_module_0.run(bool_0)


test_ActionModule_run()

# Generated at 2022-06-25 07:44:31.637647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # TODO: implement
    assert False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:44:41.414205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    bool_0 = True
    var_0 = action_module_0.run(bool_0)
    assert (var_0 == bool_0)
    assert (action_module_0.run(bool_0) == bool_0)
    assert (action_module_0.run(bool_0) == bool_0)
    assert (action_module_0.run(bool_0) == bool_0)
    assert (action_module_0.run(bool_0) == bool_0)
    assert (action_module_0.run(bool_0) == bool_0)

# Generated at 2022-06-25 07:44:48.317420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 7984.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = '4t_'
    str_1 = '1T8*'
    int_0 = 2184
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    bool_1 = True
    tmp_0 = None
    task_vars_0 = None
    str_2 = action_module_0.run(bool_1, tmp_0, task_vars_0)
    dict_0 = dict()
    dict_1 = dict()
    test_assert_equal(dict_0, dict_1)


# Generated at 2022-06-25 07:44:49.259730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This is a stub (it does nothing)
    pass

# Generated at 2022-06-25 07:44:52.084512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    bool_0 = True
    var_0 = action_module_0.run(bool_0)
    return var_0

# Generated at 2022-06-25 07:44:56.605888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    
    act_mod = ActionModule(tmp, task_vars)
    act_mod.run(tmp, task_vars)



# Generated at 2022-06-25 07:45:05.025389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 9327.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = '|'
    str_1 = 'Gp&N'
    int_0 = 1380
    task_vars = None
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run(task_vars)
    # Verify that method run is called with correct parameters
    assert action_module_0.call_args == call(float_0, task_vars)

# Generated at 2022-06-25 07:45:12.100312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    task_vars_0 = None
    tmp_0 = None
    var_0 = action_module_0.run(task_vars_0, tmp_0)
    assert var_0 == None

# Generated at 2022-06-25 07:45:20.668411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run()
    output_0 = var_0
    return output_0

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:21.803975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert((action_run(action_module_0) == result))

# Generated at 2022-06-25 07:45:40.319028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Try to ensure that the method is called with the correct parameters
    try:
        action_module_0 = ActionModule()
        action_module_0.run(bool_0)
    except AssertionError: pass
    action_module_0.run(task_vars=var_0)
    action_module_0.run(tmp=var_0)



# Generated at 2022-06-25 07:45:42.418854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:48.392079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = None
    task_vars = None
    obj = ActionModule(tmp, task_vars)

    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    # Exercise
    var_0 = action_run(bool_0)
    # Verify
    assert assertEqual(var_0, 'test')
    assert assertNotEqual(var_0, 'test')

# Generated at 2022-06-25 07:45:52.808993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 823.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = '9YFx0[mm]!TA(l8HUbDj'
    str_1 = 'h:tI'
    int_0 = 2153
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run(bool_0)

# Generated at 2022-06-25 07:45:56.179133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:45:56.696026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-25 07:46:01.857510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run(bool_0)


main()

# Generated at 2022-06-25 07:46:12.675924
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:46:17.049318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 07:46:18.031393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run_0 == test_case_0()

# Generated at 2022-06-25 07:46:49.357255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Do nothing
    pass

# Generated at 2022-06-25 07:46:56.216395
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:01.757914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    class_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    result_0 = action_run(bool_0)
    print("result_0: %s" % result_0)


# Generated at 2022-06-25 07:47:06.087324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:47:06.874792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # These tests will fail without proper mock modules
    pass

# Generated at 2022-06-25 07:47:11.426997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run(bool_0)

# Generated at 2022-06-25 07:47:12.158875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run() == None


# Generated at 2022-06-25 07:47:16.732702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 3470.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'V7&0e0_uV7l"+]Lz'
    str_1 = 'RV'
    int_0 = 2435
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run(action_run(action_run(bool_0)))



# Generated at 2022-06-25 07:47:19.999866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:47:23.117869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (test_case_0())

# Generated at 2022-06-25 07:48:36.041992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run(float_0, set_0)

# Generated at 2022-06-25 07:48:40.735521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 4148.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'X_" YNu|T"o'
    str_1 = 'k)eYnk_Hd)/n~\\M%!@m'
    int_0 = 4501
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:48:43.882883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'B!<dM7>$K|pZq3C@=aO'
    str_1 = '^|f'
    set_0 = {str_0, str_1}
    float_0 = 2.06339924779
    result = action_module_0.run(float_0, set_0)
    assert result == None


# Generated at 2022-06-25 07:48:49.535526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    int_0 = 21
    str_0 = '2Z,*1\x13'
    str_1 = 'Qg'
    str_2 = ''
    float_0 = 2058.0
    set_0 = {str_1, str_1, str_1, str_1}
    bool_0 = False
    action_module_0 = ActionModule(str_1, str_0, str_2, str_1, int_0, set_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:49:00.315924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2213.0
    set_0 = {bool_0, int_0, str_0, action_run, action_run}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.tmp = None
    action_module_0.task_vars = None
    assert action_module_0.run() == None

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 07:49:06.890921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2978.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'bajC+'
    str_1 = 'h<$F'
    int_0 = 2111
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    action_module_0.run(bool_0) # expected exception: SystemError


# Generated at 2022-06-25 07:49:15.728379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('starting unit test for method run of class ActionModule...\n')
    bool_0 = True
    float_0 = 2213.0
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'n7Q;&R(CzMz2VwX6` 4'
    str_1 = '1T8*'
    int_0 = 2065
    action_module_0 = ActionModule(float_0, set_0, str_0, str_1, int_0, set_0)
    var_0 = action_run(bool_0)
    print('unit test successful.\n')


# Generated at 2022-06-25 07:49:17.556926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A testcase when ActionBase.run is called
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(None, None)

# Generated at 2022-06-25 07:49:20.842208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool(bool())
    str_0 = str(0)
    str_1 = '1T8*'
    int_0 = 2065
    set_0 = set([bool(bool()), bool(bool()), bool(bool())])
    action_module_0 = ActionModule(bool_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == False

# Generated at 2022-06-25 07:49:23.003939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, int_0, str_0, str_1, int_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == None, 'Expected value: None. Actual value: ' + str(var_0)
