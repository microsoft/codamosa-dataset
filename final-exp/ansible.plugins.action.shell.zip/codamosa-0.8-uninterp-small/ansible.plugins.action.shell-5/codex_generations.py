

# Generated at 2022-06-25 07:41:46.424324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    str_1 = '-877.910658_raw_raw\x11\xe9j\x81/\xecz'
    str_2 = "shell"
    assert (str_1 == action_module_0.get_option(str_2))
    str_3 = "run"
    str_4 = 'ansible.legacy.command'
    action_module_0.set_option(str_3, str_4)

# Generated at 2022-06-25 07:41:52.109169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 7.450080671601456
    bool_0 = False
    str_0 = '#\x1c\x99\xed\xab\xa5\xe0%\xeb\xc5\xd2\x15\xf0\x0c\xf2\x80\xb8;\xbf\xc59\xec\xd6\x8b\x08\x9b\x1f\\\t\xf2O\xf7\xe3\xb0\xca'

# Generated at 2022-06-25 07:41:56.904342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x7f\x8d\xc7\x88\xf0'
    str_0 = 'string'
    float_0 = -21.468834
    bool_0 = True
    str_1 = '\x00\x00\x00\x00\x00'
    bytes_1 = b'^\x18\\\x8b\x92\x16\xed\x88\x8b\xc7\x91\x9e\xa6\x17\x0b\xce\x18\x01\x8f\xc3\x19A'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_1, bytes_1)
    action_module_0.run(bytes_0)

# Generated at 2022-06-25 07:42:00.433557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert action_module_0.run(None, None) == {}

# Generated at 2022-06-25 07:42:07.464674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    # Make sure it fails to run
    with pytest.raises(NoModuleError):
        action_module_0.run()

# Generated at 2022-06-25 07:42:17.972494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1.222908964
    bool_0 = False
    str_0 = '_raw'
    bytes_0 = b'\xe2\x1d\x9b\x07\x01\xcc\x0e\x1a\x19'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    str_1 = 'X]\xad\x99\x8d\xd0\x1f\xd1\xf8\xc3\x11\x9b\x95=C\x8a\x1a\xab\xd3\xc4\x93\xf4\x9c\xa4\x82\xde\x06'

# Generated at 2022-06-25 07:42:23.021596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2.146413

# Generated at 2022-06-25 07:42:31.918155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case that fails
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    task_vars_0 = {}
    result = action_module_0.run(task_vars_0)
    print(result)
    # Test case that passes
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'

# Generated at 2022-06-25 07:42:40.056585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    task_vars_0 = dict()
    tmp_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    print(result)


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:42:43.220469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -877.910658
    bool_0 = True
    str_0 = '_raw'
    bytes_0 = b'\x11\xe9j\x81/\xecz'
    action_module_0 = ActionModule(float_0, bool_0, bool_0, str_0, str_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:42:48.070849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    TaskModule = ActionModule()
    TaskModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:42:58.841721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.chdir(test_path)
    file_name = 'test_ActionModule_run_test_file0.txt'
    if os.path.isfile(file_name):
        os.remove(file_name)
    with open(file_name, 'w') as f_test_file0:
        f_test_file0.write('''
import os
''')
    with open(file_name, 'r') as f_test_file0:
        test_file0_content = f_test_file0.read()
    with open(file_name, 'w') as f_test_file0:
        f_test_file0.write('''
import os
''')
    with open(file_name, 'r') as f_test_file0:
        test_file0_content

# Generated at 2022-06-25 07:43:07.772263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make instance for class ActionModule
    action_module_0 = ActionModule()
    # Make instance for class NoneType
    none_type_0 = None
    # Make instance for class ClassAttributeMetaClass
    class_attribute_meta_class_0 = ClassAttributeMetaClass()
    # Make instance for class ActionBaseSuperclass
    action_base_superclass_0 = ActionBaseSuperclass()
    # Make instance for class NoneType
    none_type_1 = None
    # Make instance for class ActionBaseSuperclass
    action_base_superclass_1 = ActionBaseSuperclass()
    # Make instance for class ActionBaseSuperclass
    action_base_superclass_2 = ActionBaseSuperclass()
    # Make instance for class ActionBaseSuperclass
    action_base_superclass_3 = ActionBaseSuperclass()
    # Make instance for class Action

# Generated at 2022-06-25 07:43:08.980910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    float_0 = -2.146413

# 

# Generated at 2022-06-25 07:43:10.127760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert test_case_0() == 0

# Generated at 2022-06-25 07:43:11.768714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = float("-inf")


# Generated at 2022-06-25 07:43:13.745010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -1.82277
    float_2 = 1.3025
    assert test_case_0() == 'test_Value'

# Generated at 2022-06-25 07:43:17.710951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing the ActionModule constructor with non-printable characters
    try:
        action_module_0 = ActionModule(None, None, None, None, None, None, None, None, None)
    except TypeError:
        pass # Expected exception
    # Method run have not return type

# Generated at 2022-06-25 07:43:24.209597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -0.913939
    float_0 = 0.460623
    float_2 = -0.782215

    # Parameters
    tmp = None
    task_vars = dict()

    # Call method
    assert float_1 == float_0
    action_module = ActionModule()
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    # Check result
    assert float_0 == float_1
    assert float_2 == float_0

# Generated at 2022-06-25 07:43:31.143429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1.0
    float_1 = 2.419021
    float_2 = -2.886062
    int_0 = 3
    int_1 = 5
    str_0 = "Hello, World!"
    str_1 = "Hello, World!"
    method_return_0 = test_ActionModule_run()
    assert method_return_0 == (("result", "changed", "invocation", "stdout_lines"), ("failed", "ok", "ok", "ok"))
    assert float_0 == -1.0
    assert float_1 == 2.419021
    assert float_2 == -2.886062
    assert int_0 == 3
    assert int_1 == 5
    assert str_0 == "Hello, World!"
    assert str_1 == "Hello, World!"



# Generated at 2022-06-25 07:43:34.673189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -0.708711
    ActionModule(None, None)
    test_case_0()

# Generated at 2022-06-25 07:43:41.619519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    # ToDo:
    # This test is not reproducible as it requires to establish a connection with an external device
    # Add a test case once we have a mock object
    #
    # Expected results:
    #
    # result.get('stdout_lines') == ['The result', 'of the shell command']
    # result.get('stdout') == 'The result\nof the shell command'
    # result.get('cmd') == '/usr/bin/env true'
    # result.get('rc') == 0
    #
    # Result of running this module before the bug fix:
    #
    # result.get('stdout_lines') == ['The result', 'of the shell command']
    # result.get('stdout') == 'The result\\nof the shell command'


# Generated at 2022-06-25 07:43:48.597340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule(tmp, task_vars)
    test_case_0()

#############################################################################
# TEST CASES
#############################################################################


# Generated at 2022-06-25 07:43:52.856397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Application-level parameters
    # AnsibleModule instance
    # A task to execute during the play run
    # Connection information for the hosts
    # Play context for the task to execute
    # Ansible loader is responsible for loading ansible content
    # Templar templating engine
    # Shared loader module, used for reading or writing variables
    # Unit test parameters
    action_module_tmp = None
    action_module_task_vars = None

    # Unit test code
    action_module_obj = ActionModule(action_module_tmp, action_module_task_vars)
    action_module_run_data = action_module_obj.run()
    # Assertion error
    assert action_module_run_data is not None, "Expected assert on action_module_run_data"


# Generated at 2022-06-25 07:44:01.497304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2.146413
    float_1 = -2.146413
    float_2 = -2.146413
    float_3 = -2.146413
    float_4 = -2.146413
    float_5 = -2.146413
    float_6 = -2.146413
    float_7 = -2.146413
    float_8 = -2.146413
    float_9 = -2.146413
    float_10 = -2.146413
    float_11 = -2.146413
    float_12 = -2.146413
    float_13 = -2.146413
    float_14 = -2.146413
    float_15 = -2.146413
    float_16 = -2

# Generated at 2022-06-25 07:44:09.542372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2.215
    float_1 = -3.5174
    float_2 = 2.5704
    float_3 = -4.985
    str_0 = "."
    str_1 = "^"
    str_2 = "|"
    str_3 = "\\"
    str_4 = ":"
    str_5 = "*"
    str_6 = "/"
    str_7 = "\""
    str_8 = "<"
    str_9 = "?"
    str_10 = ">"


# Generated at 2022-06-25 07:44:14.050224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2.146413
    float_1 = -0.0290818


# Generated at 2022-06-25 07:44:21.411143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = function_0()
    task_vars = function_0()
    float_0 = 0.53
    str_0 = '__file'
    str_1 = 'src'
    float_1 = 1.29
    str_2 = 'eav'
    str_3 = '_mode'
    str_4 = 'src'
    float_2 = 3.56
    int_0 = -1
    str_5 = '__file'
    str_6 = 'src'
    float_3 = -1.24
    str_7 = 'src'
    str_8 = '__file'
    str_9 = '_backup_name'
    str_10 = 'str'
    str_11 = 't'
    str_12 = '__file'
    float_4 = 4.69

# Generated at 2022-06-25 07:44:22.099176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:44:31.218001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    float_1 = -0.22761
    float_2 = 0.2503
    float_3 = -0.01133
    float_4 = -5.5
    float_5 = 11.0
    float_6 = -1.2
    float_7 = 5.3
    float_8 = 2.0
    float_9 = 3.1
    float_10 = 1.0
    float_11 = 0.22761
    float_12 = -2.146413
    float_13 = -0.0
    float_14 = 8.5
    float_15 = 1.0
    float_16 = 5.2
    float_17 = -3.0
    float_18 = 3.0
    float_19 = 0.0
    float_20

# Generated at 2022-06-25 07:44:39.127385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '`'
    int_0 = 17450
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:46.318909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bool_0 = True
    dict_1 = {'au': 'au', 'au': 'au', 'au': 'au', 'au': 'au', 'au': 'au'}

    # Testing for exception raised *TypeError*
    try:
        run(dict_0, dict_1)
    except TypeError:
        bool_0 = False

    assert bool_0
    # Testing if the function run calls the function action_load
    mocker.patch('ansible.plugins.action.module_loader.ActionLoader.get', return_value=True)
    assert action_module.run(dict_0, dict_1)


# Generated at 2022-06-25 07:44:47.124764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  global var_0
  assert var_0 == None

# Generated at 2022-06-25 07:44:52.971706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()
    var_1 = action_run()
    var_2 = action_run()
    var_3 = action_run()
    var_4 = action_run()
    var_5 = action_run()
    var_6 = action_run()
    var_7 = action_run()
    var_8 = action_run()
    var_9 = action_run()
    var_10 = action_run()
    var_11 = action_run()
    var_12

# Generated at 2022-06-25 07:44:55.366078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:45:01.315806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Jj;/4_!+F%c'
    int_1 = 0
    tuple_0 = ()
    dict_0 = {str_0: int_1}
    action_module_0 = ActionModule(str_0, str_0, int_1, tuple_0, dict_0, dict_0)
    dict_1 = {}
    var_0 = action_module_0.run(dict_1)

# Generated at 2022-06-25 07:45:04.983212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('apn', 'ansible_service_mgr', 'test_case_0', 'param_0', 'loader=test_func_0', 'attr_0=attr_0')
    var_1 = action_module_0.run()

# Generated at 2022-06-25 07:45:07.799768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    # No logic to test. It is just a "pass"

# Generated at 2022-06-25 07:45:12.623107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:16.591288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)

    # Test cases
    test = action_run()
    assert test == None, "Return is {} and it should be {}".format(test, None)

# Generated at 2022-06-25 07:45:27.125170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'J4'
    int_0 = -4906
    tuple_0 = ()
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    str_1 = 't`'
    var_0 = action_module_0.run(str_1)

# Generated at 2022-06-25 07:45:33.112861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'S_tm:<'
    int_0 = -4498
    tuple_0 = ()
    dict_0 = {}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run(None, None)


if __name__== "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:34.823435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(1)

# Assignment of variable test_ActionModule_run to attribute run of class ActionModule
ActionModule.run = test_ActionModule_run


# Generated at 2022-06-25 07:45:38.402455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:45:41.064910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:45:49.484796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #args [0]
    #kwargs [{}]
    str_0 = 'n5p5r$'
    str_1 = 'n5p5r$'
    int_0 = 7378
    tuple_0 = ()
    dict_0 = {str_0: str_1}
    dict_1 = {str_0: str_1}
    action_module_0 = ActionModule(str_0, str_1, int_0, tuple_0, dict_0, dict_1)
    var_0 = action_module_0.run(str_0, str_1, int_0)


# Generated at 2022-06-25 07:45:50.166833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 07:45:53.641960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'tmp='
    tuple_0 = ()
    dict_0 = {'tuple_0': tuple_0}
    action_module_0 = ActionModule('str_0', 'str_0', 5985, 'tuple_0', dict_0, dict_0)
    var_1 = action_module_0.run(var_0, 'task_vars=')


# Generated at 2022-06-25 07:46:02.216677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init method run of class ActionModule with parameter tmp and task_vars
    # unit test for tmp
    # param: tmp 
    # unit test for task_vars
    # param: task_vars 
    # Init method _task of class ActionModule with parameter _task
    str_0 = 'mts_alh'
    # Init class _task with parameter self, args and module_name
    # Init method _shared_loader_obj of class ActionModule with parameter _shared_loader_obj
    str_1 = 'hb__h#'
    # Init method action_loader of class _shared_loader_obj with parameter self and hostvars
    self._shared_loader_obj.action_loader
    # Init method get of class action_loader with parameter ansible.legacy.command, _task, _connection, _play_context,

# Generated at 2022-06-25 07:46:12.669354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'X#'
    int_0 = -49
    tuple_0 = ()
    dict_0 = {str_0: tuple_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0 = action_run()
    var_0

# Generated at 2022-06-25 07:46:22.538065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for i in range(1,10):
        test_case_0()

# Generated at 2022-06-25 07:46:32.175126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5986
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    assert var_0 is not None
    assert dict_0 is not None
    assert tuple_0 is not None
    assert int_0 is not None
    assert str_0 is not None
    assert action_module_0 is not None
    assert len(dict_0) >= 0
    assert len(tuple_0) >= 0
    assert int_0 >= 0
    assert len(str_0) >= 0

# Generated at 2022-06-25 07:46:36.585064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    str_0 = action_module_0.run()
    print(str_0)


# Generated at 2022-06-25 07:46:41.596351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the test values
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, tmp, tmp, tmp, tmp, tmp)
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:46:42.377226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Implement your tests here
    pass


# Generated at 2022-06-25 07:46:42.968153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-25 07:46:50.372542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 5
    # Create a new instance of the class ActionModule with the following arguments
    arg_0 = 'a'
    arg_1 = 'b'
    arg_2 = 1
    arg_3 = ()
    arg_4 = {}
    arg_5 = {}
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    var_1 = action_module_0.run(var_0)


# Generated at 2022-06-25 07:46:57.412042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_1 = action_module_0.run()



# Generated at 2022-06-25 07:47:01.330146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = 'task_vars'
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(tmp, task_vars)
    assert var_0

# Generated at 2022-06-25 07:47:02.275324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_equal(result, expected)

# Generated at 2022-06-25 07:47:25.945820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ayQ'
    int_0 = 6491
    tuple_0 = (str_0,)
    dict_0 = {str_0: int_0}
    dict_1 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_1)
    var_0 = action_module_0.run(None, None)

# Generated at 2022-06-25 07:47:31.037348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 9629
    str_0 = str()

    # Call action_run method of the class ActionModule to execute the Unit test
    result = action_run(int_0=int_0, str_0=str_0)

    # Compare the result of method action_run to the expected result
    assert result == "expected result"

# Generated at 2022-06-25 07:47:39.243326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init data structures
    tmp_0 = None
    task_vars_0 = None
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None
    arg_4 = None
    arg_5 = None
    arg_6 = None
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)

    # init args
    var_0 = tmp_0
    var_1 = task_vars_0

    # call method
    var_2 = action_module_0.run(var_0, var_1)


if __name__ == '__main__':
    test_ActionModule_run() # Unit Test

# Generated at 2022-06-25 07:47:42.052246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'O'
    str_1 = 'mE'
    int_0 = -39270
    tuple_0 = ()
    dict_0 = {str_0: str_1}
    dict_1 = {str_1: tuple_0}
    action_module_0 = ActionModule(str_1, str_0, int_0, tuple_0, dict_0, dict_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:47:45.643826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not True


# Generated at 2022-06-25 07:47:47.823865
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:52.587958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a'
    int_0 = 4
    tuple_0 = (1, 1)
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run(dict_0, dict_0)

# Generated at 2022-06-25 07:47:57.485334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {}
    action_module_0.run(int_0, tuple_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:48:02.460635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fZ'
    int_0 = 5178
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:48:15.119276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'q '
    int_0 = 7179
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run(dict_0, None)
    assert var_0.get('changed') == True
    assert var_0.get('rc') == 0
    assert var_0.get('stdout') == '"test"'
    assert var_0.get('stdout_lines') == ['"test"']

# Generated at 2022-06-25 07:48:58.283915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    expected_0 = ''
    actual_0 = action_module_0.run
    assert actual_0 == expected_0, 'Run method failed with error: "' + actual_0 + '"'

# Generated at 2022-06-25 07:49:01.786251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5985
    str_0 = 'apn='
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:49:03.138136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  val = None
  # this should pass
  assert None == val


# Generated at 2022-06-25 07:49:11.376588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    object_0 = object()
    object_0 = object()
    int_0 = 5221
    tuple_0 = ()
    dict_0 = {'apn': 'apn'}
    dict_0 = {'apn': 'apn'}
    action_module_0 = ActionModule(object_0, object_0, int_0, tuple_0, dict_0, dict_0)
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()

# Generated at 2022-06-25 07:49:17.674722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'x,vJ+'
    int_0 = 5944
    tuple_0 = ()
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    int_1 = 0
    int_2 = 0
    action_module_0.run(int_0, int_0)
    int_2 = 0
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, str_0, int_1, tuple_0, dict_0, dict_0)
    int_2 = 0
    int_2 = 0
    action_module_0.run(int_0, int_0)


# Generated at 2022-06-25 07:49:20.364196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 07:49:25.806538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'action'
    str_1 = 'command'
    action_module_0 = ActionModule(str_0, str_1)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 07:49:30.557086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '?K@$;'
    int_0 = 17351
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:49:35.235778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # variable declarations
    var_0 = None
    action_module_0 = ActionModule('apn=', 'apn=', 5985, (), {'apn=': 'apn='}, {'apn=': 'apn='})

    # actual test
    result = action_module_0.run(var_0)

if __name__ == "__main__":
    print(test_case_0())
    print(test_ActionModule_run())

# Generated at 2022-06-25 07:49:39.797861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:51:10.634709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == None


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:51:14.832317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # given the class is instantiated correctly
  # given the class's run method is called
  # when all provided parameters is None
  # then run returns false
  pass

# Generated at 2022-06-25 07:51:16.480099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5985
    action_module_run_0 = ActionModule(int_0)
    action_module_run_0.run()


# Generated at 2022-06-25 07:51:17.468986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True # TODO: implement your test here


# Generated at 2022-06-25 07:51:20.208671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f-!w'
    int_0 = 6471
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:51:28.771732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'apn='
    int_0 = 5985
    tuple_0 = ()
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, tuple_0, dict_0, dict_0)
    try:
        var_0 = action_module_0.run()
    except:
        print('Exception caught!')
    # assert var_0 == {'failed': True, 'msg': 'The module did not specify a valid action.\n\nThe module supports the following actions: <value goes here>\n\nThe module also supports `args:` which is a list of arguments to pass to the action. Refer to the documentation for the specific action to see what arguments are allowed.\n\n'}


# Generated at 2022-06-25 07:51:35.386957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f1'
    str_1 = 'YzE='
    str_2 = '^k<2@'
    str_3 = 'dGhlIG'
    str_4 = 'cmd=2;'
    list_0 = [str_4, str_4]
    dict_0 = {str_4: dict_0, str_4: list_0}
    dict_1 = {str_4: str_4}
    dict_2 = {str_4: dict_1, str_4: dict_0}
    dict_3 = {str_2: dict_0, str_2: dict_1}
    dict_4 = {str_2: dict_1}
    var_0 = get_checksum(list_0, str_3, str_3, False)
    list