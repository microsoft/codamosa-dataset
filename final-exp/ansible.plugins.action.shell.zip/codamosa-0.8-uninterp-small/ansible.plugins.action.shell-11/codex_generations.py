

# Generated at 2022-06-25 07:41:38.541669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assign values for class method run of class ActionModule
    set_0 = None
    str_0 = 'Validate TLS certificates: %s'
    bytes_0 = b'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    int_0 = 562
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)
    tmp = None
    task_vars = None
    # Call method run of class ActionModule
    result_0 = action_module_0.run(tmp, task_vars)


if __name__ == '__main__':
    # OptionParser
    pass
    # Setup test_case_0


# Generated at 2022-06-25 07:41:45.890000
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up object
    set_0 = None
    str_0 = 'wC\x1f\xd0\x9d\x8cLZ\xbf\xdb\xc2lz\x1d\x7f\xd3\x9d\x93\x1f\x85K\x82\x1e\x8b\x13\xf4\x9c'

# Generated at 2022-06-25 07:41:52.330305
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    set_0 = None
    str_0 = 'Validate TLS certificates: %s'
    bytes_0 = b'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    int_0 = 562
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)

    action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 07:41:56.864921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    str_0 = 'Validate TLS certificates: %s'
    bytes_0 = b'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    int_0 = 562
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)
    dict_1 = None
    result = action_module_0.run(dict_1)
    assert result == None
    assert True

# Generated at 2022-06-25 07:42:02.635225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    str_0 = '|)1F!\x8b\x85'
    bytes_0 = b'\x8d'
    int_0 = 85
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)
    result = action_module_0.run(tmp=dict_0)
    assert result is None

    set_1 = None
    str_1 = 'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    bytes_1 = b'\x97\xd8'
    int_1 = 814

# Generated at 2022-06-25 07:42:08.367021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    str_0 = 'Validate TLS certificates: %s'
    bytes_0 = b'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    int_0 = 562
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)
    # 'NoneType' object has no attribute 'strip'
    assert not action_module_0.run()



# Generated at 2022-06-25 07:42:17.801623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'p5'}
    str_0 = "The '--force' option is deprecated. In the future, use '--disable-warnings' instead.\n"
    bytes_0 = b'\x1c\x6e\xdb\xc7\x0c\xb5O\x9b\x9d\x82\xbf\xbd\xcf\x99m\xc4\x1b'
    int_0 = 2
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)

    # Call method run of action_module_0
    assert None is action_module_0.run()

# Generated at 2022-06-25 07:42:21.412075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:42:24.245755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = None
    param_1 = None
    action_module_run_0 = ActionModule.run(param_0, param_1)
    assert action_module_run_0 is None


# Generated at 2022-06-25 07:42:32.900266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    str_0 = 'Validate TLS certificates: %s'
    bytes_0 = b'A(U\xcd\xd9\x93\x8f\xdd\xcdB'
    int_0 = 562
    dict_0 = {bytes_0: set_0}
    action_module_0 = ActionModule(set_0, str_0, set_0, bytes_0, int_0, dict_0)
    int_1 = 814
    str_1 = 'echo \'Doing some stuff in here.\''
    dict_1 = {str_1: int_1}
    task_vars_0 = dict_1
    result_0 = action_module_0.run(task_vars=task_vars_0)
    assert result_0 == dict_

# Generated at 2022-06-25 07:42:44.991218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    str_0 = 'wC\x1fÐ\x9d\x8cLZ¿ÛÂlz\x1d\x7fÓ\x9d\x93\x1f\x85K\x82\x1e\x8b\x13ô\x9c'
    str_1 = hashlib.sha256(str_0).hexdigest()
    str_2 = '3f54b7397f2039e8b7e17fce365f0b52e6f552a001823c6b946a7f11d8e031fc'
    bool_0 = str_1 == str_2

# Generated at 2022-06-25 07:42:49.001890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None

    print(test_case_0())


if __name__ == '__main__':
    test_name = 'test_ActionModule_run'

    # If test method name specified then run only that test
    if (len(sys.argv) > 1):
        test_name = sys.argv[1]

    globals()[test_name]()

# Generated at 2022-06-25 07:42:55.838522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    # Call the method
    tmp = None
    task_vars = None
    obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    obj.run(tmp=tmp, task_vars=task_vars)
    # Return value assertion
    assert True

# Generated at 2022-06-25 07:42:56.764067
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_case_0()

# Generated at 2022-06-25 07:43:01.488157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    str_0 = 'wC\x1fÐ\x9d\x8cLZ¿ÛÂlz\x1d\x7fÓ\x9d\x93\x1f\x85K\x82\x1e\x8b\x13ô\x9c'


# Generated at 2022-06-25 07:43:10.091900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'T'
    var_1 = 'N'

# Generated at 2022-06-25 07:43:18.695820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    str_0 = 'wC\x1fÐ\x9d\x8cLZ¿ÛÂlz\x1d\x7fÓ\x9d\x93\x1f\x85K\x82\x1e\x8b\x13ô\x9c'
    str_1 = 'H\x9e\x9e\x91\x1d\x1c?\x8b\x98\x13\xceL\x9e\x1b\xce\x1b\x1c\x90\x92'


# Generated at 2022-06-25 07:43:25.633667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    str_0 = 'wC\x1fÐ\x9d\x8cLZ¿ÛÂlz\x1d\x7fÓ\x9d\x93\x1f\x85K\x82\x1e\x8b\x13ô\x9c'
    module_0 = ansible.plugins.action_.ActionModule(var_0, var_0)
    str_1 = 'wC\x1fÐ\x9d\x8cLZ¿ÛÂlz\x1d\x7fÓ\x9d\x93\x1f\x85K\x82\x1e\x8b\x13ô\x9c'
    var_0 = module_0.run(str_1)

# Generated at 2022-06-25 07:43:36.717392
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1
    tmp_0 = None
    task_vars_0 = None
    f_0 = ActionModule(tmp=tmp_0, task_vars=task_vars_0)
    result_0 = f_0.run()
    assert len(result_0) == 0


# Test 2
    tmp_1 = None
    task_vars_1 = None
    f_1 = ActionModule(tmp=tmp_1, task_vars=task_vars_1)
    result_1 = f_1.run()
    assert len(result_1) == 0


# Test 3
    tmp_2 = None
    task_vars_2 = None
    f_2 = ActionModule(tmp=tmp_2, task_vars=task_vars_2)
    result_2 = f

# Generated at 2022-06-25 07:43:37.078440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:43:40.582760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0()

# Generated at 2022-06-25 07:43:50.829424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    int_0 = 0
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    tuple_0 = (int_0,)
    tuple_1 = (int_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, int_0, str_3, set_0)

# Generated at 2022-06-25 07:43:56.074806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    var_0 = action_module_2.run()
    assert var_0 is None, 'Somehow we did not get None.'
    return None

# Generated at 2022-06-25 07:44:05.285272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:44:06.724338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None, "test_case_0() failed"


# Generated at 2022-06-25 07:44:11.514975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = ''
    task_vars = {}
    var_0 = action_module_1.run()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:44:20.513543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R'
    int_0 = 1
    action_module_0 = ActionModule(str_0, int_0)
    action_module_0._task = mock.MagicMock()
    action_module_0._task.args = {'_uses_shell': False}
    action_module_0._task.args.get = mock.MagicMock(side_effect=[False])
    dict_0 = {}
    action_module_0._shared_loader_obj = mock.MagicMock()
    action_module_0._shared_loader_obj.action_loader = mock.MagicMock()
    action_module_0._shared_loader_obj.action_loader.get = mock.MagicMock(side_effect=[action_module_0._task])
    action_module_0._connection = mock.Magic

# Generated at 2022-06-25 07:44:30.397886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'h\xf4"\x97 \xb4'
    float_0 = 0.895812
    list_0 = ['asgJ']
    set_0 = set()
    str_0 = 'b^\x84\x93y\xfc\xa3Y'
    str_1 = 'Z\\'
    str_2 = '\x05\x11\x85'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)

# Generated at 2022-06-25 07:44:31.137232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:44:34.134660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    action_module_0 = ActionModule(tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0)
    assert action_module_0.run() is None
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:44:40.662660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:44:47.796399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'GsNaM'
    int_0 = 55
    list_0 = [int_0]

# Generated at 2022-06-25 07:44:55.556646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:44:56.282459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:02.529273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 1
    act_mod = ActionModule()
    act_mod.run(None, None)

    # Case 2
    act_mod = ActionModule()
    act_mod.run(None, [])

    # Case 2
    act_mod = ActionModule()
    act_mod.run(None, "test")


if __name__ == '__main__':
    test_case_0()

    # Test the case of the method run
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:12.928925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    float_0 = 596.81189
    float_1 = 645.090227
    set_0 = {'$', 'zB'}
    str_0 = ',{5B?D;'
    str_1 = '!qh%c'
    bytes_0 = b'yCpI+JAdY'
    bytes_1 = b'+/R'
    tuple_0 = (list_0, str_1, set_0)
    action_module_0 = ActionModule(float_0, float_1, list_0, set_0, str_0, tuple_0)
    action_module_1 = None
    tuple_1 = (float_0, set_0)
    tuple_2 = (bytes_0, bytes_1, action_module_1)

# Generated at 2022-06-25 07:45:19.844113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (0,)
    list_0 = []
    action_module_0 = ActionModule(tuple_0, list_0, list_0, list_0, list_0, list_0)
    assert action_module_0.run() == dict(
        msg='',
        changed=False,
        rc=0,
        stderr='',
        stdout='',
    )


# Generated at 2022-06-25 07:45:27.695043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_5 = ActionModule()
    str_0 = 'mBs!@'
    list_0 = []
    bool_0 = False
    list_1 = [str_0, str_0, str_0, str_0, str_0]
    list_0.append(list_1)
    var_0 = action_module_5.run(list_0, bool_0)
    var_1 = action_module_5.run(bool_0, list_0)
    var_2 = action_module_5.run(list_0, list_0)

# Generated at 2022-06-25 07:45:36.435712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'YZ0u'
    float_0 = 285.316081
    list_0 = []
    set_0 = set()
    str_0 = 'H^J%jm!g"'
    str_1 = 'xLExuPf'
    str_2 = '%s3\"'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (float_0,)
    tuple_1 = (bool_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = '../'
    tuple_2 = (bytes_0, action_module_1, list_0, str_3)
    action_module_

# Generated at 2022-06-25 07:45:45.826917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'q\t%'
    float_0 = 8.711
    list_0 = []
    list_1 = []
    set_0 = set()
    str_0 = 'Rk'
    str_1 = '\)F\x08'
    action_module_0 = None
    tuple_0 = (list_0, str_0)
    action_module_1 = ActionModule(bytes_0, float_0, list_0, set_0, tuple_0, action_module_0)
    list_2 = [list_0, list_1, set_0, str_1]
    var_0 = action_module_1.run(list_2)

# Generated at 2022-06-25 07:45:53.766082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule)


# Generated at 2022-06-25 07:46:02.238170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Xn'
    float_0 = 918.5995
    list_0 = []
    set_0 = set()
    str_0 = 'lkZd_&}@'
    str_1 = 'NxO'
    str_2 = 'v'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'u@{h`'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)
    action_module_2 = ActionModule

# Generated at 2022-06-25 07:46:05.450763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:46:09.456663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3'
    str_1 = '3'
    str_2 = '3'
    action_base_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, str_1, str_2, action_base_0, tuple_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:11.896390
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test case 0
    test_case_0()

# Generated at 2022-06-25 07:46:14.545799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_arg_0, float_arg_0, list_arg_0, set_arg_0, tuple_arg_0, tuple_arg_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:24.220958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'T['
    float_0 = 0.7
    list_0 = []
    set_0 = set()
    str_0 = 'CzS.^'
    str_1 = 'Fx&"4m%c~\'"'
    str_2 = '_rmS'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = '%^6U]'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)
    action_module_2

# Generated at 2022-06-25 07:46:24.832896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:46:26.136362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 07:46:29.279700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # given
    tmp=None
    task_vars=None

    # expected
    result = None

    # when
    test_case_0()
    # verify
    assert result == None

# Generated at 2022-06-25 07:46:54.148424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six.moves import queue
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-25 07:46:59.300142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Q_T'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, bool_0)
    str_0 = 'x[D*V'
    action_module_1 = ActionModule(bytes_0, bool_0, str_0)
    var_0 = action_module_1.run()
    return var_0

if __name__ == '__main__':
    var_0 = test_ActionModule_run()

# Generated at 2022-06-25 07:47:06.329546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(bytes_0, float_0, list_0, set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'

# Generated at 2022-06-25 07:47:10.899685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0 = test_case_0
    print("Test Case 0:")
    case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:47:18.120091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:47:28.084983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:47:32.375623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'4'
    list_0 = []
    set_0 = set()
    str_0 = '-t]'
    str_1 = ''
    str_2 = ')T$R'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (bytes_0,)
    tuple_1 = (str_1, str_0, tuple_0, str_2)
    action_module_1 = ActionModule(list_0, set_0, tuple_1, tuple_0, str_2, action_module_0)

    var_0 = action_module_1.run()
    print(var_0)

if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:47:37.130318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:47:40.569886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:47:52.656079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = b'ep"'
    float_0 = 59.342068
    list_0 = []
    set_0 = set()
    str_0 = '%s'
    str_1 = '3qee"|'
    str_2 = 'BJl#'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (float_0,)
    tuple_1 = (bool_0, list_0)
    action_module_1 = ActionModule(tuple_0, float_0, list_0, str_1, str_2, action_module_0)
    set_1 = set(())
    tuple_2 = (float_0, var_0, action_module_1)

# Generated at 2022-06-25 07:48:36.243095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 524.0532
    list_0 = []
    set_0 = set()
    str_0 = 'o_D=hxT,'
    str_1 = 's)'
    str_2 = 'p'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (float_0, bool_0)
    tuple_1 = (str_1, tuple_0)
    action_module_1 = ActionModule(str_0, str_1, list_0, tuple_1, set_0, tuple_0)
    str_3 = '`'
    tuple_2 = (bool_0,)
    tuple_3 = (set_0, tuple_2)
    float_1 = 0.0
    tuple_4 = (str_3, float_1)


# Generated at 2022-06-25 07:48:38.178038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == Code



# Generated at 2022-06-25 07:48:39.054603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the function of the run method
    test_case_0()

# Generated at 2022-06-25 07:48:44.032478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {
        'wir*oSZ0': [
            '9C4qU6',
            '*'
        ],
        'rq3mLr': -643.5729135023233
    }
    dict_2 = {}
    dict_2['o'] = dict_1
    dict_2['8'] = '~HGt:|'
    action_module_0 = ActionModule(list_0=dict_2, tuple_0=dict_2)
    str_0 = 'n-g'
    assert str_0 in action_module_0.run()


# Generated at 2022-06-25 07:48:54.320897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:48:59.840939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'q\x11\x06\xe6\x1d\x1d'
    float_0 = 0.761862
    list_0 = []
    set_0 = set()
    str_0 = 'x\x1c\x00u|\x0b'
    str_1 = 'yw^'
    str_2 = '\x1c\r\\'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (str_0, float_0)
    tuple_1 = (tuple_0, list_0)
    action_module_1 = ActionModule(str_1, str_2, action_module_0, set_0, tuple_0, tuple_1)
    str_3 = '"9\t'
    tuple

# Generated at 2022-06-25 07:49:09.144615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:49:12.951940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    action_module_0 = ActionModule(set_0, 'test', 'test', 'test', None, (set_0,))

    assert action_module_0.run() == dict(changed=False, failed=False, rc=0, stdout='', stderr='', stdout_lines=[], stderr_lines=[])

# Generated at 2022-06-25 07:49:21.581754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'ku]f'
    dict_0 = {}
    float_0 = 92.4739
    list_0 = []
    set_0 = set()
    str_0 = '0rp"gx0y/c'
    str_1 = ')-'
    str_2 = 'NbXi"t'
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, dict_0, float_0, list_0, set_0, str_0, str_1, str_2, action_module_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:49:31.642959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:50:52.254030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialized test
    test_case_0()
    assert True

# Generated at 2022-06-25 07:51:00.592858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)

# Generated at 2022-06-25 07:51:08.683398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'w', 't', 'm', 'Z', 'S'}
    str_0 = 'X#'
    str_1 = '=M~'
    str_2 = '&0'
    action_module_0 = None
    tuple_0 = ({'a', 'w', 'q', 'N', '^'}, set_0, str_0, str_1, str_2, action_module_0, {'q', 'm', 'S', '$', 'Z'})
    action_module_1 = ActionModule(str_1, tuple_0, set_0, str_2)
    result = action_module_1.run()
    assert result.get('failed', {}) == False

# Generated at 2022-06-25 07:51:10.640019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    test_case_0()
  except:
    assert False


# Generated at 2022-06-25 07:51:13.113936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

test_list = [
    test_ActionModule_run
]


# Generated at 2022-06-25 07:51:19.964792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'+1'
    float_0 = 1.098
    list_0 = []
    set_0 = set()
    str_0 = '=kG4e`l'
    str_1 = '[mX$'
    str_2 = '&'
    action_module_0 = None
    bool_0 = True
    tuple_0 = (set_0,)
    tuple_1 = (tuple_0, set_0)
    action_module_1 = ActionModule(bytes_0, float_0, list_0, set_0, str_0, str_1)
    tuple_2 = (str_2,)
    tuple_3 = (action_module_0, action_module_1, list_0, tuple_2)

# Generated at 2022-06-25 07:51:28.608692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xff\x00\x14\x00'
    float_0 = 905.34276746
    list_0 = []
    set_0 = set()
    str_0 = 'nJk'
    str_1 = 'xtQe'
    str_2 = 'P\x88'
    action_module_0 = ActionModule(set_0, str_0, str_1, str_2, list_0, set_0)
    str_3 = ''
    tuple_0 = (action_module_0, set_0, str_3, list_0)
    action_module_1 = ActionModule(bytes_0, float_0, list_0, set_0, tuple_0, list_0)
    var_0 = action_module_1.run()



# Generated at 2022-06-25 07:51:35.370992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'x"'
    float_0 = 602.900982
    list_0 = []
    set_0 = set()
    str_0 = '%s!vault |'
    str_1 = 'KCkGYiVf'
    str_2 = '"MaOziyg"DqG'
    action_module_0 = None
    bool_0 = False
    tuple_0 = (bool_0,)
    tuple_1 = (list_0, tuple_0)
    action_module_1 = ActionModule(set_0, str_0, str_1, str_2, action_module_0, tuple_1)
    str_3 = 'ZsAQ^'
    tuple_2 = (action_module_1, bool_0, str_3, set_0)