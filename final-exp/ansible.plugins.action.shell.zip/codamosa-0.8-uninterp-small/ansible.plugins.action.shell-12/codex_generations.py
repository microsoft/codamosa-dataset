

# Generated at 2022-06-25 07:41:39.952948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test 0")
    int_0 = -417
    float_0 = 2420.434795
    bool_0 = False
    set_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, set_0)
    action_module_0.run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:41:49.756600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.plugins.action.template import ActionModule as template
    from ansible.plugins.action.copy import ActionModule as copy
    from ansible.plugins.action.file import ActionModule as file
    from ansible.plugins.action.lineinfile import ActionModule as lineinfile
    from ansible.plugins.action.synchronize import ActionModule as synchronize
    from ansible.plugins.action.async_status import ActionModule as async_status
    from ansible.plugins.action.raw import ActionModule as raw
    from ansible.plugins.action.assemble import ActionModule as assemble
    from ansible.plugins.action.debug import ActionModule as debug
    from ansible.plugins.action.unarchive import ActionModule as unarchive
    from ansible.plugins.action.script import ActionModule as script

# Generated at 2022-06-25 07:41:59.229236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -255
    float_0 = 0.8373308214479326
    bool_0 = False
    set_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    print("result: ", result)
    expected = None
    assert (result == expected)


# Generated at 2022-06-25 07:42:04.060188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    action_module_0 = ActionModule(False, 8.963, bool_0, 0, False, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 07:42:09.944747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -347
    float_0 = 34.361389148
    bool_0 = False
    action_module_0 = ActionModule(int_0, float_0, bool_0)
    task_vars_0 = {}
    action_module_0.run(tmp, task_vars_0)


# Generated at 2022-06-25 07:42:13.313602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -339
    float_0 = 2391.986538
    bool_0 = False
    set_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, set_0)
    tmp = None
    action_module_0.run(tmp)


# Generated at 2022-06-25 07:42:20.591277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7249
    float_0 = 7.0696733997064
    bool_0 = True
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, None)
    #param_0 should be of type dict
    ansible_arg_0 = dict()
    #param_1 should be of type dict
    ansible_arg_1 = dict()
    result = action_module_0.run(ansible_arg_0, ansible_arg_1)
    #result should be of type dict
    #assert 'result_type' in result
    assert isinstance(result, dict)
    #assert 'success' in result
    assert isinstance(result['success'], bool)
    #assert 'data' in result

# Generated at 2022-06-25 07:42:26.576726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, set_0)
    tmp_0 = None
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()
    name_0 = "ActionModule"

# Generated at 2022-06-25 07:42:34.752302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #**********************************************
    # test_case_0
    int_0 = -151
    float_0 = 2420.434795
    bool_0 = False
    set_0 = None
    action_module_0 = ActionModule(int_0, float_0, bool_0, int_0, bool_0, set_0)
    tmp = None
    task_vars = None
    result_0 = action_module_0.run(tmp, task_vars)
    assert result_0 == None
    #**********************************************
    # test_case_1
    int_0 = -281
    float_0 = 7078.672347
    bool_0 = False
    set_0 = None

# Generated at 2022-06-25 07:42:43.927712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1355
    float_0 = 2420.434795
    bool_0 = False
    int_1 = -1355
    bool_1 = False
    set_0 = None
    action_module_0 = ActionModule(int_1, float_0, bool_0, int_0, bool_1, set_0)

# Generated at 2022-06-25 07:42:48.586674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1036.0
    list_0 = [float_0]
    int_0 = -1
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()
    result_0 = print(var_0)

# Generated at 2022-06-25 07:42:54.734640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    with pytest.raises(Exception):
        action_module_0.run()
    assert False

# Generated at 2022-06-25 07:43:00.560201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        float_0 = 1752.1
        list_0 = [float_0]
        int_0 = -2468
        tuple_0 = ()
        action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
        var_0 = action_run()
    except AttributeError as e:
        log.info(e)
        raise Exception('Unit test failed')

# Generated at 2022-06-25 07:43:03.472823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, tuple_0, list_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run(list_0, list_0)



# Generated at 2022-06-25 07:43:08.494546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run("tmp", "task_vars")

# Generated at 2022-06-25 07:43:14.055529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    tmp_0 = None # No effect
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:43:15.794577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(ActionModule.run() == ActionBase.run())
    assert(ActionModule.run() == ActionBase.run())

# Generated at 2022-06-25 07:43:23.264314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    float_0 = -1837.474
    list_0 = []
    int_0 = -1463
    tuple_0 = (int_0, int_0, float_0)
    str_0 = 'Nf7##'
    var_0 = action_module_0.run(float_0, list_0, int_0, tuple_0, str_0)
    assert var_0 == action_module_0

# Generated at 2022-06-25 07:43:27.496222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -7.8
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 07:43:28.930780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True, 'Test not implemented'

# Generated at 2022-06-25 07:43:37.752073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1514.0
    list_1 = [float_0]
    int_1 = -2057
    tuple_1 = ()
    action_module_1 = ActionModule(float_0, list_1, int_1, tuple_1, int_1, list_1)
    action_module_1.run(float_0, list_1)


# Generated at 2022-06-25 07:43:38.723461
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:43:39.633549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (False)

# Generated at 2022-06-25 07:43:46.860018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    action_run()
    var_1 = action_module_0.run(int_0, tuple_0)
    assert var_1 == action_run()

# Generated at 2022-06-25 07:43:50.552161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -8.6
    list_0 = [float_0]
    int_0 = -1715
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:54.022935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:43:59.289367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run(tmp=(float_0), task_vars=(list_0))
    assert var_0.exit_status == int_0


# Generated at 2022-06-25 07:44:05.492566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = True
    var_1 = True if (var_0) else False
    var_2 = False if (var_1) else True
    long_0 = long(var_2)
    long_1 = long(var_1)
    long_2 = long(var_0)
    action_module_0.run(var_1, long_1)


# Generated at 2022-06-25 07:44:08.450788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    action_run()

# Generated at 2022-06-25 07:44:13.034519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = None
    tmp_0 = 0
    tuple_0 = ()
    list_0 = [tmp_0]
    dict_0 = {}
    int_0 = 2000
    float_0 = 2.5
    int_1 = 8000
    list_1 = (tuple_0, list_0)
    str_0 = '0.57.0'
    action_module_0 = ActionModule(float_0, dict_0, int_0, tuple_0, int_1, list_1)
    var_0 = action_module_0.run(tmp_0)
    assert var_0 == None


# Generated at 2022-06-25 07:44:20.781925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:44:26.978147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object
    # TODO Create the arguments
    action_module_0 = ActionModule()
    # Invoke run with appropriate argument values
    # TODO Invoke run with appropriate argument values
    action_module_0.run()

# Generated at 2022-06-25 07:44:33.556949
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = 306.7684
    list_0 = [float_0]
    int_0 = -15841
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run_0(args)
    assert var_0.has_key(True)

# Generated at 2022-06-25 07:44:41.463711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5
    int_1 = 7
    dict_0 = dict()
    dict_0[int_1] = -4097
    dict_0[int_0] = int_0
    tuple_0 = (dict_0, )
    action_module_0 = ActionModule(11, tuple_0, int_1, tuple_0, int_1, tuple_0)
    var_0 = action_module_0.run(dict_0)
    var_1 = action_module_0.run()
    print(var_0, var_1)
    assert var_0['stdout'] == var_1['stdout']


# Generated at 2022-06-25 07:44:45.163217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    assert not isinstance(action_module_0.run(), dict)

# Generated at 2022-06-25 07:44:48.666185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:49.401430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert result == None


# Generated at 2022-06-25 07:44:58.214411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    with pytest.raises(AnsibleError, match=r"nonetype object has no attribute 'get'"):
        var_0 = action_module_0.run()
        assert var_0 == -2468

# Generated at 2022-06-25 07:45:04.244050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:45:07.963705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert hasattr (ActionModule, 'run'), 'Method run of class ActionModule not defined.'


# Generated at 2022-06-25 07:45:28.088240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = -9274
    list_1 = []
    int_2 = -9322
    tuple_1 = ()
    float_1 = 1793.2
    action_module_1 = ActionModule(int_2, list_1, int_1, tuple_1, int_1, list_1)
    result_0 = action_module_1.run(float_1)
    assert result_0 is None

# Generated at 2022-06-25 07:45:32.645228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -807
    list_0 = [float_0]
    int_0 = -285
    tuple_0 = (float_0, float_0, float_0, float_0, float_0)
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)

# Generated at 2022-06-25 07:45:36.951313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2463.9
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    action_run_0 = action_module_0.run()
    assert(action_run_0 == -2112)

# Generated at 2022-06-25 07:45:38.465279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(None, None)
    assert result == result


# Generated at 2022-06-25 07:45:39.330871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == 0


# Generated at 2022-06-25 07:45:39.748757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:45:50.351293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    float_1 = 1752.1
    list_1 = [float_0]
    int_1 = -2468
    tuple_1 = ()
    action_module_1 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    list_2 = list_1
    int_2 = 252
    str_0 = str(action_module_1.run(float_1, list_2, int_2))
    return int_0


# Generated at 2022-06-25 07:45:58.090771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import io
    import sys
    # Redirect the stdout and stderr
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    try:
        test_case_0()
    finally:
        # Reset redirection
        sys.stdout = stdout
        sys.stderr = stderr

# Generated at 2022-06-25 07:46:01.395612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run() is None

# Generated at 2022-06-25 07:46:09.196365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    float_0 = -46.51
    dict_0 = dict()
    action_run(float_0, dict_0)

# Generated at 2022-06-25 07:46:42.237512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_1 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:49.166006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3468.9
    list_0 = [float_0]
    int_0 = -2577
    tuple_0 = ()
    task_vars = list_0
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run(task_vars=task_vars)

# Generated at 2022-06-25 07:46:53.606421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2276.9
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    action_module_0.run(float_0, list_0)


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:46:57.452220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:59.611003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:47:03.786473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    list_0 = []
    tuple_0 = ()
    int_0 = 0
    action_module_0 = ActionModule(int_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run(dict_0, dict_0)
    assert var_0 == dict_0


# Generated at 2022-06-25 07:47:05.688315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (ActionModule.run()) == False

# Generated at 2022-06-25 07:47:12.418657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -988.05
    list_0 = [float_0]
    int_0 = -1911
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_run()
    assert var_0 == null
    assert action_module_0 == null

# Generated at 2022-06-25 07:47:16.177564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:47:18.916947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [1]
    tuple_0 = ()
    list_1 = ['ls', '-la']
    int_0 = 0
    list_2 = ['id -u']
    action_module_0 = ActionModule(list_0, tuple_0, list_1, int_0, list_2)
    action_module_0.run(0, [])

# Generated at 2022-06-25 07:48:21.483669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:48:25.792565
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # init the ActionModule
    action_module_0 = ActionModule()

    # call the run method.
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    int_0 = action_module_0.run(float_0, list_0, int_0, tuple_0, int_0, list_0)
    print("output is:", int_0, "\n")

# Generated at 2022-06-25 07:48:26.229313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:48:26.882460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:48:29.768406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    str_0 = ''
    action_module_0.run(str_0, str_0)



# Generated at 2022-06-25 07:48:34.393374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:48:40.502027
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for method run of class ActionModule
    def run(self, tmp=None, task_vars=None):
        del tmp  # tmp no longer has any effect

        # Shell module is implemented via command with a special arg
        self._task.args['_uses_shell'] = True

        command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                   task=self._task,
                                                                   connection=self._connection,
                                                                   play_context=self._play_context,
                                                                   loader=self._loader,
                                                                   templar=self._templar,
                                                                   shared_loader_obj=self._shared_loader_obj)
        result = command_action.run(task_vars=task_vars)

# Generated at 2022-06-25 07:48:43.068743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up parameters
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule()
    # execute method
    output_0 = action_module_0.run(tmp_0, task_vars_0)
    # assert return value
    assert output_0 == None
    assert output_0 is None

# Generated at 2022-06-25 07:48:45.115711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

try:
    from module_0 import *
except ImportError as e:
    pass

import unittest


# Generated at 2022-06-25 07:48:47.101240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = mock_run()
  module.run()


# Generated at 2022-06-25 07:51:23.168526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [1603, -1224, -2174, -101, 1185, 2200]
    int_0 = -61
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, list_0, int_0, tuple_0, int_0, list_0)
    list_0 = [(21, -2650), (1, -1340), (None, -2814), (-15, -2755), (None, -2293), (1, -922)]
    int_0 = -1760
    tuple_0 = ()
    # Call the run method with arguments list_0, int_0, tuple_0
    # assert - check the return of the run method
    # assert - check the return of the run method
    # assert - check the return of the run method
    #

# Generated at 2022-06-25 07:51:26.097956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_module_0.run(int_0, int_0)
    assert var_0 == int_0
    assert action_module_0.run() == int_0
    assert int_0 == int_0


# Generated at 2022-06-25 07:51:32.864557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1752.1
    list_0 = [float_0]
    int_0 = -2468
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, list_0, int_0, tuple_0, int_0, list_0)
    var_0 = action_run()