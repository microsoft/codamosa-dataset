

# Generated at 2022-06-25 07:41:37.459031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result is None


# Generated at 2022-06-25 07:41:48.086864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe1\x97\xb0\xce\xc5\x00\x10\x1ej\x9d\x94\x0f\x18\xc1\x8a\x1b'
    set_0 = {bytes_0}

# Generated at 2022-06-25 07:41:48.758827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:41:54.054490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"a\xe8\xce\x18B\x9e\x99\x7f\xaa\x1c\x8e\xde\xa5\x03\xcd\xd8\xba\x9e<\x02\x95\x17\x92'\x83\xd0\x12\x9c\x9a\xf2"
    dict_0 = {}
    dict_1 = {}
    dict_1['connection'] = bytes_0
    dict_0['action_plugin'] = dict_1

# Generated at 2022-06-25 07:42:01.285196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Evaluating method run of class ActionModule")
    bytes_0 = b"\xce\x1e\x93\x06\xa2\x9f\xf0\xce\x91P\x91\x11\x08\x18\x8b\xb0"
    set_0 = {bytes_0}
    str_0 = '`\x80\x1e\x90\x9e\xb2Q\xf1\x98\xd4'
    float_0 = 662.0
    dict_0 = {bytes_0: float_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)

# Generated at 2022-06-25 07:42:06.434106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'str_1': 'str_0'}
    action_module_0 = ActionModule()
    action_module_0.run(task_vars=task_vars)
    assert action_module_0._task.args['_uses_shell'] is True

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:42:11.932598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfc\xce\x07\xfcR\xf6\x14\xa1\x15\x01\x12'
    dict_0 = {}
    str_0 = '\xe1g\xb0\x01\xce\x8b\xbc\x92\xbc\xaa\x8a\xc0\xcc\xb6\x95\x8d\x05\x14\xfe\x9d\xf1\xfb\xc0\x17\x06\xe3\x10\x02\xbd\x9b\x03'
    int_0 = 37682485
    float_0 = 9.0

# Generated at 2022-06-25 07:42:18.542057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {b"\x95\xef\x98\xb6\x8f\xdca\x06\x1c\xcd\x9a\x97\x08\x9d\xe8\x07g\x1d\x15\xff\x08\x1c"}

# Generated at 2022-06-25 07:42:28.567482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test data
    tmp = None
    task_vars = {}

    # create test object
    bytes_0 = b'e\xc9\x8a\xa5\x18\x81\x01\x17\xa0\x16'
    set_0 = {bytes_0}
    str_0 = 'U%\x97\x8d"\xaa\x85\x9b\xfc'
    float_0 = 0.27546037734797
    dict_0 = {'\x9b\x92\x8d\x1b\xba\x01\xe0\xfd\x89\xfd': '\x9b\x92\x8d\x1b\xba\x01\xe0\xfd\x89\xfd'}
   

# Generated at 2022-06-25 07:42:35.656143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\xa1\xc7"
    set_0 = {bytes_0}
    str_0 = 't\xb8\x1f\x82\xdf\xba\x04\xf0\x9a\x9d~\xe8A\xa2\x0b'
    float_0 = 2858.2797
    dict_0 = {str_0: set_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    result_0 = action_module_0.run(str_0, dict_0)
    assert result_0['pid'] == 7949
    assert result_0['rc'] == 0


# Generated at 2022-06-25 07:42:41.997362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case when tmp and task_vars are None
    module_0 = ActionModule()
    module_0.run()


# Generated at 2022-06-25 07:42:47.029083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = b''
    task_vars_0 = {
        'ansible_connection': 'network_cli'
    }
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    # FIXME: need to find a way to test this result, because the module is private
    # assert result_0 == 0
    assert result_0 is None


# Generated at 2022-06-25 07:42:53.373588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe1\x97\xb0\xce\xc5\x00\x10\x1ej\x9d\x94\x0f\x18\xc1\x8a\x1b'
    #bytes_1 = {bytes_0}
    int_0 = 0
    int_1 = 0
    float_0 = -2.7644797467
    float_1 = -5.2
    float_2 = 1.29
    float_3 = -0.0001
    float_4 = 1.0
    float_5 = 0.0
    float_6 = 8.0
    float_7 = 0.819704626
    float_8 = 0.0079098
    float_9 = 0.005817
    int_2 = 2
   

# Generated at 2022-06-25 07:42:56.540473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = b''
    tmp = b''
    action_module = ActionModule()
    ret_val = None
    ret_val = action_module.run(tmp, task_vars)



# Generated at 2022-06-25 07:43:00.203903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg = {}
    task_vars = {}
    action_module = ActionModule()
    result = action_module.run(arg, task_vars)
    assert result is not None
    assert type(result) is dict
    assert 'changed' in result


# Generated at 2022-06-25 07:43:03.091244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=tmp, task_vars=task_vars)
    assert isinstance(result, dict)


# Generated at 2022-06-25 07:43:09.100088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assign parameter task_vars
    task_vars = {'item0': 1, 'item1': 3}
    # Create an instance of class ActionModule with parameter tmp and task_vars
    action_module = ActionModule(tmp=None, task_vars=task_vars)

    # Call method run of action_module
    result = action_module.run(tmp=None, task_vars=task_vars)

    # Check result
    assert result['tmp'] == '/tmp/test'


# Generated at 2022-06-25 07:43:09.934306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   test_case_0()

# Generated at 2022-06-25 07:43:11.037543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0, "Failed: Method not implemented"


# Generated at 2022-06-25 07:43:20.303157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test using a class
    class MockConnection(object):
        pass
    connection = MockConnection()

    # Test using a class
    class MockTemplar(object):
        pass
    templar = MockTemplar()

    # Test using a class
    class MockLoader(object):
        pass
    loader = MockLoader()

    # Test using a class
    class MockSharedLoaderObject(object):
        pass
    shared_loader_obj = MockSharedLoaderObject()

    # Test using a class
    class MockTask(object):
        pass
    task = MockTask()
    # Setting attribute
    task.args = 'foo'
    task_vars = 'foo'

    # Test using a class
    class MockPlayContext(object):
        pass
    play_context = Mock

# Generated at 2022-06-25 07:43:29.969591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = 'm'
    dict_0 = {string_0: string_0}
    float_0 = 3927.0062255859375
    class_0 = type(float_0)
    tuple_0 = (class_0, class_0, float_0, dict_0)
    str_0 = 'F\x19\xdc\xe6\x8f\xdd\x9fL\xd6\x8b\x0e\x0b\x88\xf1\x8b\xaf\xaa'
    dict_1 = {str_0: str_0}
    set_0 = {str_0, str_0, str_0, str_0, str_0}
    float_1 = float_0

# Generated at 2022-06-25 07:43:39.050558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:43.055697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.setup()
    action_module_0.run()
    action_module_0.run()

# Generated at 2022-06-25 07:43:51.312436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:43:51.805341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:43:55.444094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(dict_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:44:04.718691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run(None, None)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:05.319820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:44:14.327436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xcc\x1a\xb6\xc7\xa4\xd5\xbe\xfd\xec\xfd\xe4\x9b"\xf3;l\x1e\xaa\xb2}\xac\xce?\x81\xfc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = '4mz(\x1a(v\nq\x0e\x14.5\x1f\x13\\'
    float_0 = 3303.427290583489
    dict_0 = {str_0: float_0}

# Generated at 2022-06-25 07:44:16.724185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Call method run with arguments tmp=None, task_vars=None
    result = action_module_0.run(tmp=None, task_vars=None)
    assert result is None


# Generated at 2022-06-25 07:44:30.143044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:44:37.087677
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:44:46.843752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_1 = {bytes_1, bytes_1, bytes_1, bytes_1}
    str_1 = 'vX\'mx<\x0b[|NL"'
    float_1 = 2483.109546938472
    dict_1 = {bytes_1: str_1}
    action_module_1 = ActionModule(bytes_1, set_1, str_1, float_1, bytes_1, dict_1)
    var_1 = action_module_1.run(bytes_1)
    assert var_1 == None

# Generated at 2022-06-25 07:44:55.515616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_142 = None
    var_143 = set()
    var_144 = 'wD_eC\x0b|:y\x1d\x1d@\x06\x1d'
    var_145 = 362.86242030268607
    var_146 = b'R\xc9\x90\x0f\x12\x1e\x82\xf4\x0b`\xdf\x9c\xdc\x99\xbe.\xe7\xbe\xee\x1d\x9d\x0c%\x07\xc2'
    var_147 = {var_146: var_144}
    action_module_5 = ActionModule(var_142, var_143, var_144, var_145, var_146, var_147)


# Generated at 2022-06-25 07:44:56.202863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # tmp no longer has any effect
    raise NotImplementedError()


# Generated at 2022-06-25 07:44:57.726328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:45:02.575835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    print('Module path: {}'.format(module_path))
    assert True

# Generated at 2022-06-25 07:45:12.930469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.plugins.action import ActionBase
  # Set up mock
  class ActionModuleMock(ActionBase):
    def __init__(self, *args, **kwargs):
      self._task = (args[0] if len(args) >= 1 else kwargs.get('task'))
      self._connection = (args[1] if len(args) >= 2 else kwargs.get('connection'))
      self._play_context = (args[2] if len(args) >= 3 else kwargs.get('play_context'))
      self._loader = (args[3] if len(args) >= 4 else kwargs.get('loader'))
      self._templar = (args[4] if len(args) >= 5 else kwargs.get('templar'))
      self._shared_loader

# Generated at 2022-06-25 07:45:21.338408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 07:45:28.525956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'yA\xcc\x94\xf9#\xec\xad\xeb\xa1A\xd3\xde\x8c5\xa4\xd4'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'F\xa3o\xb7*\xc0\xee\x02\xb0\xec\x19\x92\x90$X\xca\xed\x04\xa0{'
    float_0 = 883.12703894135
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_

# Generated at 2022-06-25 07:45:39.801034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 07:45:49.489452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:45:55.764101
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:46:03.041174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xec\x97\xa1\x1e\t\xb7a\x9a\x94r\x02\x8fN\x14\x1e`\x99O'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    float_0 = 0.867450734876692
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'U"\x95M\xfb\x9b\x86\x1d)y\x92\xe6.\x01\x8e\x13\x14\x9e\x10'
    task_vars_0 = dict_0
    tmp_0 = dict_0

# Generated at 2022-06-25 07:46:06.134755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:46:12.628231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_1 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:21.768443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe7\x9d\x89\xce\xb6\xd7\xed\xcc\x8bs\xc5\x92\xbe\xae\x8b\xac\x17\x16\x12\x1f\x9e\x13\x81\x91\xf49\x1b\x02\xb2[\x1d\r\x17\xc9\x16.\x8e'
    set_0 = {bytes_0: bytes_0}

# Generated at 2022-06-25 07:46:31.147102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test environment
    temp_var_0 = tempfile.TemporaryDirectory()
    var_0 = temp_var_0.name

    # call the test method
    # var_0: tmp
    # var_1: task_vars
    # Note: _uses_shell is set for this test because it affects the command module which does a lot of the work for
    # shell module. it is set in the constructor
    var_2 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0).run(var_0, var_1)

    # assert return values
    # self._task.args['_uses_shell'] = True

    assert True == False


# Generated at 2022-06-25 07:46:36.521024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_0 = 0.9028850724327363
    var_0 = set()
    var_0 = action_run()

if __name__ == "__main__":
    import sys
    sys.exit(0)

# Generated at 2022-06-25 07:46:44.963228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    # Missing argument tmp
    # Missing argument task_vars
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:47:06.137730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:16.847514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'K\xa0\x14\x84\x81K\xdb\xe1E\x8f\xaa\xb9z\x9d\xd8\x83\xf1'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = '\x85\x13\xda\xc3\x18i\xe9\xd9\x82\xb1\x84\x1a\xaf\x1e\x8b'
    float_0 = 4369.4126605262834
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_

# Generated at 2022-06-25 07:47:17.277098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	print('placeholder')

# Generated at 2022-06-25 07:47:26.993539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:47:33.757316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run()
    action_module_0.run(tmp=None)

# Generated at 2022-06-25 07:47:38.561270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:47:46.662108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    dict_var_tmp = dict()
    dict_var_task_vars = dict()

# Generated at 2022-06-25 07:47:48.757684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:47:56.118708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:48:00.995436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    action_module_0 = ActionModule(dict_0)
    input_var_0 = None
    input_var_1 = {}
    var_0 = action_module_0.run(input_var_0, input_var_1)
    var_1 = None
    assert var_0 == var_1

# Generated at 2022-06-25 07:48:36.142719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert command_action is not None

# Generated at 2022-06-25 07:48:38.324942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:48:48.398312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    dict_1 = {}
    var_0 = action_module_0.run(dict_1)
    assert var_0 == None


# Generated at 2022-06-25 07:48:58.301502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_1 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_

# Generated at 2022-06-25 07:48:59.286686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:49:04.740484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    tmp_0, task_vars_0 = None, None
    action_module_0.run(tmp_0, task_vars_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:49:12.308679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_run()
    action_module_0.run(var_0, var_0)

# Generated at 2022-06-25 07:49:22.276219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    task_vars_0 = None
    var_0 = action_module_0.run(task_vars=task_vars_0)


# Generated at 2022-06-25 07:49:23.912465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actions = ActionModule()
    assert actions.run() == 'hello'

# Generated at 2022-06-25 07:49:27.652660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = '\x03\x8d>\xba\x07|\xfa\xdc\x9b'

# Generated at 2022-06-25 07:50:48.446329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    dict_0 = {}
    float_0 = float()
    str_0 = str()
    bytes_0 = bytes()
    action_module_0 = ActionModule(set_0, dict_0, float_0, str_0, bytes_0, )

# Function call: run
# Arguments: (tmp=None, task_vars=None)
# File: /home/vagrant/ansible/lib/ansible/plugins/action/shell.py
# Start line: unknown
# End line: unknown
# Start column: unknown
# End column: unknown
# Executed command: None
# Executed command arguments: None
# Executed command environment variables: None
# Executed command working directory: None
# Executed command stdout: None
# Executed command stderr: None
# Executed

# Generated at 2022-06-25 07:50:51.475568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 07:51:00.194474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    set_0 = {'\x9d\x9e\x81B\x82\xed\x80\x98Q\xfb\x8b"{\x9d:', '\x9d\x9e\x81B\x82\xed\x80\x98Q\xfb\x8b"{\x9d:', '\x9d\x9e\x81B\x82\xed\x80\x98Q\xfb\x8b"{\x9d:', '\x9d\x9e\x81B\x82\xed\x80\x98Q\xfb\x8b"{\x9d:'}

# Generated at 2022-06-25 07:51:08.933513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    task_vars = {'task_vars': 1}

# Generated at 2022-06-25 07:51:10.411558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   action_module = ActionModule()
   resutlt = action_module.run()

# Generated at 2022-06-25 07:51:19.085425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'S\xfc\xdb\xa4\x80\x90\xbf\xd1\xe4\x94\xe1\x07\xf15\xdc\xb8\x06\xc2\xe5\xca'
    set_0 = {bytes_0, bytes_0}
    str_0 = '&\'\x16\xb5\x0e\xbb\x13r\x1b.\x08\x1b\x01\x17'
    float_0 = 4749.218086901809
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = test_case_1()

# Generated at 2022-06-25 07:51:24.439426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('\xdf\xba\t\x1b\x06\x93\tL\x89\xad\x1d\x93\xf6\xa5\x15\xe5\xf8\\\xfe\xe0\x17\xb7\x8a\xea\xd2\xb2\xee\xb6')
    var_0 = action_run()



# Generated at 2022-06-25 07:51:25.288179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # Just a placeholder for now.

# Generated at 2022-06-25 07:51:25.834342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:51:35.225225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xee|\xe7\xc5B\x9f\xa4h\xc4 \xa4\xf2\xdb`\xe7i\xfe\nD\xbc'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    str_0 = 'vX\'mx<\x0b[|NL"'
    float_0 = 2483.109546938472
    dict_0 = {bytes_0: str_0}
    action_module_0 = ActionModule(bytes_0, set_0, str_0, float_0, bytes_0, dict_0)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_Action