

# Generated at 2022-06-25 07:41:42.925692
# Unit test for method run of class ActionModule
def test_ActionModule_run():# Fold begin
    complex_1 = -85j
    # list_1 = [complex_1, complex_1]
    str_1 = "J:j'N\"."
    # action_module_1 = ActionModule(complex_1, complex_1, complex_1, list_1, str_1, list_1)
    print('ActionModule -> run', type(complex_1), action_module_1)
# Fold end

if __name__ == '__main__':
    test_case_0()

    # test_ActionModule_run()

#     def test_case_1():
#         complex_0 = -26-60j
#         int_0 = -241
#         list_0 = [complex_0, None]
#         str_0 = "Y+?$kJ.1&F"
#

# Generated at 2022-06-25 07:41:48.550945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -407
    list_0 = [complex_0, complex_0]
    str_0 = "::)z>lDT'Cy"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert isinstance(result, dict)
    if result:
        print(result)


# Generated at 2022-06-25 07:41:55.452830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = 2143159041.33
    int_0 = 0
    list_0 = [int_0, 0, -590856417]
    str_0 = "f,Fg1?$E"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    dict_0 = {'succeeded': True, 'msg': "Hello World hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world hello world"}
    assert action_module_0.run() == dict_0


# Generated at 2022-06-25 07:42:00.688639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -407
    list_0 = [complex_0, complex_0]
    str_0 = "::)z>lDT'Cy"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)

    tmp = None
    task_vars = None

    result_expected = dict(changed=False, skipped=False)
    result_actual = action_module_0.run(tmp, task_vars)

    assert (result_expected == result_actual)

# Generated at 2022-06-25 07:42:08.659910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -407
    list_0 = ['lL', 'Z6', 'JO', 'jn', '1X']
    str_0 = "::)z>lDT'Cy"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    action_module_0.run('lL', list_0)
    action_module_0.run()
    action_module_0.run(str_0, str_0)
    action_module_0.run()
    action_module_0.run(str_0, list_0)
    action_module_0.run('lL', str_0)
    action_module_0.run('lL', list_0)
   

# Generated at 2022-06-25 07:42:13.219195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -19
    list_0 = [complex_0, complex_0]
    str_0 = "i3hDj$A9U6"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)

    # The function is called with a set of args
    result_0 = action_module_0.run(None, None)
    assert result_0 is None


# Generated at 2022-06-25 07:42:17.018084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_1 = None
    int_1 = -326
    list_1 = [complex_1, complex_1]
    str_1 = 'X^Sg}(nxv!8'
    action_module_1 = ActionModule(complex_1, complex_1, int_1, list_1, str_1, list_1)
    tmp_1, task_vars_1 = None, None
    result = action_module_1.run(tmp_1, task_vars_1)
    assert result == {'changed': False, 'rc': 0, 'stdout_lines': [], 'warnings': []}

# Generated at 2022-06-25 07:42:26.819461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -407
    list_0 = [complex_0, complex_0]
    str_0 = "::)z>lDT'Cy"
    ansible_module_0 = AnsibleModule(complex_0, complex_0, complex_0, complex_0, complex_0, complex_0, complex_0)
    ansible_module_0.params = dict()
    ansible_module_0.check_mode = True
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    ansible_module_0.async_timeout = 60
    action_module_0.run(ansible_module_0)

# Generated at 2022-06-25 07:42:33.081060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    int_0 = -407
    list_0 = [complex_0, complex_0]
    str_0 = "::)z>lDT'Cy"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    ret = action_module_0.run()
    assert ret == {'changed': False, 'rc': 0, 'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}

# Generated at 2022-06-25 07:42:37.764854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define test inputs and outout
    complex_0 = None
    int_0 = -407
    list_0 = [complex_0, complex_0]
    str_0 = "::)z>lDT'Cy"
    action_module_0 = ActionModule(complex_0, complex_0, int_0, list_0, str_0, list_0)
    tmp = {}
    task_vars = {}
    expected_1 = {}
    
    # Call the method with correct arguments
    result_1 = action_module_0.run(tmp, task_vars)

    # Check if the output is correct
    assert result_1 == expected_1

# Generated at 2022-06-25 07:42:44.850759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    str_0 = 'J:j\'N".'
    str_1 = 'ActionModule -> run'
    tmp_0 = str_0.lower()
    str_2 = 'ActionModule -> run'
    tmp_1 = str_1.lower()
    str_3 = 'J:j\'N".'
    str_3 = str_3.lower()
    str_4 = 'ActionModule -> run'
    str_4 = str_4.lower()
    tmp_2 = tmp_0[:68]
    tmp_3 = tmp_1[:68]
    str_4 = tmp_2 + tmp_3
    print(str_4)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:42:52.881973
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test objects created with mock
    Mock_ActionBase = type('Mock_ActionBase', (), { 'run': test_case_0 })

    mock_args_0 = type('mock_args_0', (), { '_uses_shell': True})
    Mock_ActionModule = type('Mock_ActionModule', (), { 'run': test_case_0, '_task': mock_args_0})

    mock_args_1 = type('mock_args_1', (), { 'action_loader': 'ansible.legacy.command', 'task': Mock_ActionModule, 'connection': Mock_ActionModule, 'play_context': Mock_ActionModule, 'loader': Mock_ActionModule, 'templar': Mock_ActionModule, 'shared_loader_obj': Mock_ActionModule})

# Generated at 2022-06-25 07:42:54.346106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run()
    assert result == None

# Generated at 2022-06-25 07:42:55.700540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None, 'ActionModule -> run failed'


# Generated at 2022-06-25 07:42:59.297434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/8M^=)E'
    str_1 = 'kq&h'
    str_2 = 'ActionModule ->> run'
    str_3 = 'ActionModule ->> run'
    str_4 = 'ActionModule -> run'


# Generated at 2022-06-25 07:43:02.693552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '''Module does not implement wrapper method'''
    # Test case action_Module_0
    # Test case action_Module_1
    # Test case action_Module_2
    # Test case action_Module_3
    # Test case action_Module_4

# Generated at 2022-06-25 07:43:03.554550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_ActionModule_run() == None


# Generated at 2022-06-25 07:43:05.552911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assertions
    str_0 = 'J:j\'N".'
    str_1 = 'ActionModule -> run'


# Generated at 2022-06-25 07:43:13.212634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test the method ActionModule -> run' )

    """Assembles the module and runs it."""

    # self.tmp = tmp
    # self._config_module = None
    # self._task_vars = task_vars
    # self._tmp_path = self._make_tmp_path(self.tmp)
    # self._files = {}
    # self._lock_path = None
    # if self._task.async_val:
    #     self._lock_path = self._connection.shell.join_path(self._connection.shell.tempfile(), 'ansible_'+str(self._connection._new_stdin_path()))
    # self._jid = str(random.randint(0, 999999999999))
    # if self._task.async_val and not C.DEFAULT_

# Generated at 2022-06-25 07:43:16.073571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_obj_0 = ActionModule()
    my_obj_0.run(None, None)
    assert str_1 == str_0

test_ActionModule_run()
test_case_0()

# Generated at 2022-06-25 07:43:21.699053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test for method run of class ActionModule")
    # For test case str_0 of method run of class ActionModule
    print("Test for str_0 of method run of class ActionModule")
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:43:29.784247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    dict_0 = dict()
    dict_0['_ansible_verbosity'] = 3
    dict_0['_ansible_version'] = '2.9.9'
    dict_0['ansible_version'] = dict()
    dict_0['ansible_version']['full'] = '2.9.9'
    dict_0['ansible_version']['major'] = 2
    dict_0['ansible_version']['minor'] = 9
    dict_0['ansible_version']['revision'] = '9'
    dict_0['ansible_version']['string'] = '2.9.9'
    dict_0['ansible_facts'] = dict()

# Generated at 2022-06-25 07:43:31.478438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # FIXME: implement your test here


# Generated at 2022-06-25 07:43:35.107977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    action_module.run()


# Generated at 2022-06-25 07:43:44.494441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a'
    str_1 = 'c'
    str_2 = 'b'
    int_0 = 1
    int_1 = 2
    list_0 = []
    str_3 = 'module'
    list_1 = []
    list_2 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict

# Generated at 2022-06-25 07:43:48.019555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setting up object
    tmp = 'tmp'
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = 'tmp'
    # Calling run() method
    # No output

# Generated at 2022-06-25 07:43:52.819006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader = mock()
    shared_loader_obj = mock()
    shared_loader_obj.action_loader = mock()
    shared_loader_obj.action_loader.get = mock()
    shared_loader_obj.action_loader.get.return_value = mock()
    task = mock()
    task.args = {'args': None}
    task_vars = mock()
    connection = mock()
    play_context = mock()
    templar = mock()

    actionModule = ActionModule(loader=loader,
                                templar=templar,
                                shared_loader_obj=shared_loader_obj,
                                task=task,
                                connection=connection,
                                play_context=play_context)

    actionModule.run()

# Generated at 2022-06-25 07:43:54.349206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True

# Generated at 2022-06-25 07:44:01.863288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_obj = ActionModule()
    fixture_obj._task = ActionBase()
    fixture_obj._task.action = 'ansible.legacy.local'
    fixture_obj._task.args = {'_raw_params': 'ansible.module_utils.basic.AnsibleModule', '_uses_shell': True, '_ansible_module_name': 'get_url', '_ansible_no_log': False, '_uses_delegate': None, '_ansible_check_mode': False, '_ansible_selinux_special_fs': [], '_ansible_debug': False, '_ansible_diff': False, '_ansible_verbosity': 4, '_ansible_version': '2.6.9'}
    fixture_obj._task._role = None
    fixture_obj._task

# Generated at 2022-06-25 07:44:08.460461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0[0] == 'Module does not implement wrapper method'
    assert result_0[1] == 'FAILED!'
    assert result_0[2] == 'Test'

# Generated at 2022-06-25 07:44:18.155040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)
    action_module_0.run(var_0)
    assert true

# Generated at 2022-06-25 07:44:24.974101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        set_0 = set()
        bool_0 = True
        list_0 = [bool_0, bool_0, bool_0, bool_0]
        str_0 = 'k?$m'
        bytes_0 = b''
        bool_1 = True
        action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
        action_module_0.run(set_0)
    except Exception:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-25 07:44:35.869931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)
    var_1 = action_run(set_0)
    var_2 = action_run(set_0)
    var_3 = action_run(set_0)
    var_4 = action_run(set_0)
    var_5 = action_run(set_0)
    var_6 = action_run(set_0)
   

# Generated at 2022-06-25 07:44:36.377547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:44:45.841668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = set(1)
    set_0 = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'}
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars) == 0

# Generated at 2022-06-25 07:44:50.184883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)

# Generated at 2022-06-25 07:45:01.819889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    str_1 = '2%{B1'
    str_2 = 'k!|~'
    str_3 = ':$'
    list_1 = [str_1, bytes_0, str_2, str_3]
    action_base_0 = ActionBase(list_1, bytes_0)

# Generated at 2022-06-25 07:45:05.024848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(False, [False, False, False, False], [False, False, False, False], 'k?$m', b'', True)
    var_1 = var_0.run({})


# Generated at 2022-06-25 07:45:10.603216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = set()
    bool_2 = True
    list_1 = [bool_2, bool_2, bool_2, bool_2]
    str_1 = 'aV'
    bytes_1 = b''
    bool_3 = True
    action_module_1 = ActionModule(bool_2, list_1, list_1, str_1, bytes_1, bool_3)
    tmp = set()
    task_vars = set()
    assert action_module_1.run(tmp, task_vars) == None

# Generated at 2022-06-25 07:45:18.075838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(set_0)
    assert var_0 == None

# Generated at 2022-06-25 07:45:25.803316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:45:32.560547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(None, set_0)



# Generated at 2022-06-25 07:45:39.907621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = {
        'args': {'_raw_params': 'echo something',
                 '_uses_shell': True
                 },
        'update': {},
        'register': ''
    }
    mock_connection = {'encoding': 'utf-8', 'no_log': False, '_shell': None}
    mock_context = {'become_method': None, 'become_user': None}

# Generated at 2022-06-25 07:45:40.436017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:45:44.943628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 07:45:45.739466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule::run')
    test_case_0()

# Generated at 2022-06-25 07:45:50.402419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(set_0)


# Generated at 2022-06-25 07:45:56.890090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of a class
    action_module_0 = ActionModule()
    bool_0 = False
    list_0 = [False, True, False]
    list_1 = [False, False, False]
    str_0 = 'J]33`'
    bytes_0 = b'\x00\x00\x00'
    bool_1 = True
    str_1 = ';i^2\x7f|\x1f'
    str_2 = '^c4d\x7f#\x0fB'
    set_0 = {str_1, str_2, str_0}
    list_3 = [True, True, False]
    bool_2 = True
    # Invoke instance with parameters

# Generated at 2022-06-25 07:46:02.338488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0, bool_0]
    str_0 = 'bU6h'
    bytes_0 = b'bmV0d29yay4='
    bool_1 = False
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)


# Generated at 2022-06-25 07:46:09.849268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'mH<*R'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    action_module_0.run(set_0)

# Generated at 2022-06-25 07:46:19.045907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:46:26.013030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)


# Generated at 2022-06-25 07:46:32.531158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(set_0)
    print(var_0)

# Generated at 2022-06-25 07:46:34.968462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_0 = ActionModule()
    run_0.run()

# Generated at 2022-06-25 07:46:38.839448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:46:42.046483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)

# Generated at 2022-06-25 07:46:43.032518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:46:53.252278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run()')

    set_0 = set(['R', 'mO', 'kc'])
    bool_0 = True
    list_0 = [False, '', True, True]
    list_1 = [bool_0, bool_0, bool_0]
    str_0 = 'eKwAI{<Q'

# Generated at 2022-06-25 07:46:55.430646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:47:04.094664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
      try:
        tmp_fd, tmp_path = tempfile.mkstemp()
        # Python 2 compat: open() returns a file object
        with os.fdopen(tmp_fd, 'wb') as tmp_file:
          tmp_file.write(b'#!/usr/bin/python\nprint("foobar")\n')
        os.chmod(tmp_path, 0o755)
        if 'ansible.module_utils.basic import *' in open(tmp_path).read():
          sys.exit(1)
      finally:
        os.remove(tmp_path)


# Generated at 2022-06-25 07:47:23.827346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()

test_case_0()

# Generated at 2022-06-25 07:47:27.708592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule({})
    var_0 = action_run({})

# Generated at 2022-06-25 07:47:31.522870
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Check the callback
    assert False

    # Check the connection
    assert False

    # Check the action plugin
    assert False

    # Check the takti
    assert False

    # Check the connection plugin
    assert False

    # Check the task_vars
    assert False


# Generated at 2022-06-25 07:47:37.320894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = frozenset()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'JU['
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    result = action_module_0.run(set_0)
    str_1 = 'JU['
    assert str_1 == result[0]
    str_2 = 'y(2'
    assert str_2 == result[1]
    bool_2 = True
    assert bool_2 == result[2]
    str_3 = ']'
    assert str_3 == result[3]
    bool_

# Generated at 2022-06-25 07:47:41.782850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:47:45.242886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result_0 = {}

# Generated at 2022-06-25 07:47:54.386115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    bool_2 = bool_1
    str_1 = str_0
    ansible_facts_0 = AnsibleFacts(str_1, bool_0, bool_2)
    bool_3 = False
    bool_2 = bool_3
    str_2 = str_0
    ansible_facts_0 = AnsibleFacts(str_2, bool_0, bool_2)
    bool_4

# Generated at 2022-06-25 07:47:57.625221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:48:06.880466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    list_0 = [bool_0]
    list_1 = ['ug4p']
    str_0 = 'PQ>8'

# Generated at 2022-06-25 07:48:10.393046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None # type: ActionModule
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(set_0)
    pass

# Generated at 2022-06-25 07:48:58.348246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit tests for the run method of the ActionModule class.
    """
    # Execution requires an instance of the class.
    action_module_0 = ActionModule()

    # First arg is the tmp directory for this run.
    # Second arg is the set of variables set during task execution.
    # Third arg is not used.
    # This method is invoked by the framework's executor.
    # The task object is populated with the test input fields.
    # This test simply returns the task object to allow the caller to verify the results.
    test_case = []
    # test_case_0()
    test_case.append(test_case_0())

    return test_case

# Generated at 2022-06-25 07:49:01.137568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert UnitTestGenerator.action_module_0.run([ ]), "test did not pass"

# Generated at 2022-06-25 07:49:06.800095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_module_0.run(set_0)

# Generated at 2022-06-25 07:49:12.239718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0, var_0)

# Generated at 2022-06-25 07:49:20.714855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)

# Generated at 2022-06-25 07:49:29.631713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)
    assert var_0 == set_0

# Generated at 2022-06-25 07:49:33.008560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    action_module_0 = ActionModule()
    action_run(set_0)

# Generated at 2022-06-25 07:49:41.272598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    action_module_0.run(set_0)


# Generated at 2022-06-25 07:49:42.325027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:49:42.851605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:51:12.274391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiating the class
    action_module_0 = ActionModule()
    # Invoking method run with argument tmp = None, task_vars = None
    action_module_0.run(None, None)

if __name__ == '__main__':
    # No set up code
    # No tear down code
    
    # Testing method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:51:17.420155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    var_0 = action_run(set_0)

# Generated at 2022-06-25 07:51:25.364094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [False, False, False, False]
    list_1 = [False, False, False, False]
    str_0 = '_m*-:7'
    bytes_0 = b'\xc8'
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_1, str_0, bytes_0, bool_1)
    bool_0 = True
    set_0 = set()
    result_0 = action_module_0.run(set_0)
    # assert my_int == expected_int
    # assert my_string == expected_string

# Generated at 2022-06-25 07:51:30.231289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'k?$m'
    bytes_0 = b''
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, list_0, str_0, bytes_0, bool_1)
    
    # call the run method
    result = action_module_0.run(set_0)
    assert result is None