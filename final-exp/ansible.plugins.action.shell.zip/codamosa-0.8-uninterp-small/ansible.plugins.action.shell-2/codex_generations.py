

# Generated at 2022-06-25 07:41:38.235688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9\x0cgt,W5w1#t?ay(jJD'
    int_0 = 217
    float_0 = 95.0
    bytes_0 = b'\xea\xda\xceV\xbe\x92\x88\n\x95\x13\x12\xf8\xb0\xbb\xc9\x86\x81\xb7\xe1'
    action_module_0 = ActionModule(str_0, int_0, float_0, bytes_0, float_0, bytes_0)
    str_1 = 'Imp65ZH6*]<5D;K6'
    str_2 = '^3qK|)#\x19\x7f?p!C'

# Generated at 2022-06-25 07:41:45.858982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

    str_0 = '\x8f\x80\x95\xd4\xce\x9d\xd5'
    int_0 = 229
    float_0 = 81.0

# Generated at 2022-06-25 07:41:54.271993
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:42:01.018641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9\x0cgt,W5w1#t?ay(jJD'
    int_0 = 217
    float_0 = 95.0
    bytes_0 = b'\xea\xda\xceV\xbe\x92\x88\n\x95\x13\x12\xf8\xb0\xbb\xc9\x86\x81\xb7\xe1'
    action_module_0 = ActionModule(str_0, int_0, float_0, bytes_0, float_0, bytes_0)
    del str_0
    del int_0
    del float_0
    del bytes_0
    action_module_0.run()


# Generated at 2022-06-25 07:42:08.872952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x072\x0b\xbe\x02M\x00\xba\x83\x9d+\x8a\x81\xeb.\x03w\xf6\x9d\x90\x17'
    int_0 = 48
    float_0 = 7.0
    bytes_0 = b'\xb9\xfa\x06\x04\xfb\xd2\xa8\x93\xf1\xa9\x07o\x8a\x90\xb1\xa7\xd0\t\xda'
    action_module_0 = ActionModule(str_0, int_0, float_0, bytes_0, float_0, bytes_0)

# Generated at 2022-06-25 07:42:15.362041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!'
    int_0 = 22
    float_0 = 81.0
    bytes_0 = b'\xc8\x07\x85\xaa\x06\x84\x1b\xee\t\x9a\xc9X\xf2\x1e\x14\x1a\x8d\x92\x89'
    action_module_0 = ActionModule(str_0, int_0, float_0, bytes_0, float_0, bytes_0)
    tmp = None
    task_vars = {}
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['rc'] == 0
    assert result['stderr'] == ''

# Generated at 2022-06-25 07:42:26.299205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '\x9f?E\xd1\x99\xc8\xd8\x0f\xc6\xdf\x0c\x9e'
    int_1 = 216
    float_1 = 46.0
    bytes_1 = b'\xd3\x9f?\xed\xb5\xd1\x99\xc8\xd8\x0f\xc6\xdf\x0c\x9e\xc4\xb4\xe8\x98\x81\xef\x97\x8f\xbb\xca'
    str_2 = '\x9f?E\xd1\x99\xc8\xd8\x0f\xc6\xdf\x0c\x9e'
    float_2 = 59.0
    bytes

# Generated at 2022-06-25 07:42:34.535233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x02yG\xed\xdc\x04\x8f\xaf\x1f\xcf\xb7\x9e\x0bs\xe5\xa6\x97\xce\x03\x91\x94\x9b\xd1\xc5\xfe\xfa\xa3\xfe\x03\xa0'
    int_0 = 21
    float_0 = 69.0

# Generated at 2022-06-25 07:42:44.991594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = '\x00mXa\\\x0c6\xd1*\xbd\x85\xf0\x13\xc0\xbfl\x9e\x9c\x00\x12\x00\x00.\x1a'
    int_2 = 259
    float_2 = 16.0
    dict_0 = dict()
    dict_0['vendor'] = 'DellEMC'
    dict_0['model'] = 'PowerEdge R630'
    dict_0['wwn'] = ['10:00:00:00:c9:1b:5b:d5']
    dict_0['id'] = '0'
    dict_0['size'] = 8001563222016
    dict_0['rotational'] = True

# Generated at 2022-06-25 07:42:45.706233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:42:58.397224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_obj = ActionModule()

    s = '\x8f\x80\x95ÔÎ\x9dÕ'
    obj1 = type('',())
    obj1.x = 1
    obj1.y = 1.0
    obj1.z = 'test value'
    obj1.a = [obj1.x,obj1.y, obj1.z]

    # one
    obj2 = type('', ())
    obj2.foo = obj1
    obj2.bar = 'bar'
    # two
    obj3 = type('', ())
    obj3.foo = obj1
    obj3.bar = 'bar'
    # three
    obj4 = type('', ())
    obj4.foo = obj2
    obj4.bar = 'bar'
    obj4.lst

# Generated at 2022-06-25 07:43:07.484804
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:43:09.463535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    expectedValue = generate_output(90.0, 5, 10.0)
    result = ActionModule.run(90.0, 5, 10.0)
    assert expectedValue == result


# Generated at 2022-06-25 07:43:15.102208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj = ActionModule(args = {'_uses_shell', 'True'},
                       task = 'ansible.legacy.command',
                       connection = 'self._connection',
                       play_context = 'self._play_context',
                       shared_loader_obj = 'self._shared_loader_obj')

    class_var_0 = ActionBase
    obj.run()
    return None

# Generated at 2022-06-25 07:43:23.298100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dummy_1 = ActionModule(arg_sn_0=0, arg_sn_1=1, arg_sn_2=2, arg_sn_3=3)
    dummy_2 = ActionModule(arg_sn_0=1, arg_sn_1=1, arg_sn_2=0, arg_sn_3=3)
    dummy_3 = ActionModule(arg_sn_0=2, arg_sn_1=0, arg_sn_2=1, arg_sn_3=3)
    dummy_4 = ActionModule(arg_sn_0=3, arg_sn_1=0, arg_sn_2=2, arg_sn_3=3)

    int_0 = dummy_1.run()
    int_1 = dummy_2.run()
    int_2 = dummy_3.run()

# Generated at 2022-06-25 07:43:24.498466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pytest.skip("TODO")
    assert False

# Generated at 2022-06-25 07:43:27.238655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _tmp = None
    _task_vars = None
    actual = ActionModule(_tmp, _task_vars)
    assert actual is not None


# Generated at 2022-06-25 07:43:37.684182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x8f\x80\x95ÔÎ\x9dÕ'
    str_1 = '\x87\x8f\x8e\x83\x98\x87\x8a\x82'
    float_0 = 81.0
    str_2 = '\x95\x87\x8a\x83\x9d\x98\x93\x8c\x91\x94\x82'
    str_3 = '\x9a\x81\x9a\x94\x8e'
    int_0 = 229
    str_4 = '\x8f\x80\x95ÔÎ\x9dÕ'

# Generated at 2022-06-25 07:43:38.616224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0()


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:43:40.757088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x8f\x80\x95ÔÎ\x9dÕ'
    int_0 = 229
    float_0 = 81.0
    int_1 = 467
    int_2 = 727
    int_3 = 754
    int_4 = 790


# Generated at 2022-06-25 07:43:46.020810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    var_0 = action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:43:49.861443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance_0 = ActionModule('test_name', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')
    instance_0.run('test_tmp', 'test_task_vars')

# Method test_case_0 of class ActionModule

# Generated at 2022-06-25 07:43:54.657239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'


# Generated at 2022-06-25 07:43:56.148145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    return


# Generated at 2022-06-25 07:43:59.022181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run(None, None, None) == None

# Generated at 2022-06-25 07:44:00.053058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Unit Test for class ActionModule

# Generated at 2022-06-25 07:44:05.307212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'TODO'
    cmd_action = CommandAction()


# Generated at 2022-06-25 07:44:08.257157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:44:09.026152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'


# Generated at 2022-06-25 07:44:12.865338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()




# Generated at 2022-06-25 07:44:21.892396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run of class ActionModule')

    # Setup
    args = {
        '_ansible_syslog_facility': 32,
        '_ansible_syslog_facility_logs': False,
        '_ansible_syslog_facility_logs_msg': '',
        '_ansible_syslog_facility_name': 'local0',
        '_ansible_module_name': 'shell',
        '_ansible_no_log': False,
        '_ansible_verbosity': 0,
        '_uses_shell': True
    }
    tmp = None


# Generated at 2022-06-25 07:44:27.108401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with param str_0
    result = test_case_0()

    print('Test of method run is complete!')

# Generated at 2022-06-25 07:44:35.757110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp=tmp_0, task_vars=task_vars_0)
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    return result_0

tmp_0 = None
task_vars_0 = None
action_module_0 = ActionModule(tmp=tmp_0, task_vars=task_vars_0)
result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
print(result_0)

# Generated at 2022-06-25 07:44:42.085116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = test_case_0()
    str_1 = 'TODO'
    assert ( str_0 == str_1 )


# Unit test boilerplate
if __name__ == '__main__':
    test_ActionModule_run()
    print( 'All test cases passed' )

# Generated at 2022-06-25 07:44:48.769921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # str -> ActionModule
    obj_0 = ActionModule()
    # int, str -> ActionModule
    obj_1 = ActionModule(tmp=0, task_vars='')
    # ActionModule, int -> ActionModule
    obj_2 = ActionModule()
    # ActionModule, str -> ActionModule
    obj_3 = ActionModule()
    # ActionModule, ActionModule -> ActionModule
    obj_4 = ActionModule()

# Generated at 2022-06-25 07:44:51.443771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    str_0 = 'TODO'

# Generated at 2022-06-25 07:44:56.500550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    int_0 = 0
    task_vars = ((('TODO', 'TODO'),),)
    assert module.run(None, task_vars) == 0

# Testing with coverage

# Generated at 2022-06-25 07:44:58.717321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'
    # TODO: need a mock
    #assert ActionModule.run(str_0) == str_0

# Generated at 2022-06-25 07:45:00.313178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'


# Generated at 2022-06-25 07:45:05.101961
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate a ActionModule object
    obj = ActionModule()

    # Default values of variables are passed
    tmp = None
    task_vars = None
    result = obj.run(tmp, task_vars)

    # Results and error handling
    if result is None:
        print("Run method of class ActionModule returned None")

    # negative test cases
    test_case_0()

# Generated at 2022-06-25 07:45:12.212526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'

# Generated at 2022-06-25 07:45:15.884713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    del type(action_module_0).loader
    del type(action_module_0).shared_loader_obj

    # TODO: patch below is to bypass the init of ActionBase.__init__
    # TODO: remove this patch once the init is implemented
    with patch('ansible.plugins.action.ActionBase.__init__'):
        action_module_0.run()



# Generated at 2022-06-25 07:45:26.369138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task = {}
    task['action'] = {'__ansible_module__': 'shell'}
    task['args'] = {}
    task['args']['_uses_shell'] = True
    loader = {}
    templar = {}
    task_vars = {}

    # mock command_action
    command_action = {}
    command_action.run = lambda task_vars: task_vars
    action_loader = {}
    action_loader.get = lambda module, task, connection, play_context, loader, templar, shared_loader_obj: command_action
    shared_loader_obj = {}
    shared_loader_obj.action_loader = action_loader

    action_module._shared_loader_obj = shared_loader_obj
    action_module._task = task

# Generated at 2022-06-25 07:45:30.531541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == 'TODO'

if __name__ == '__main__':
    import pytest

    pytest.main([__file__, '-vv'])
    #pytest.main()

# Generated at 2022-06-25 07:45:31.535920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'


# Generated at 2022-06-25 07:45:32.061954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert str_0


# Generated at 2022-06-25 07:45:39.575119
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:45:41.525585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = None
    assert test_case_0() == 'TODO'

# Generated at 2022-06-25 07:45:46.344374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = 'TODO'

    # Invocation
    result_0 = ActionModule.run(str_0)

    # Verification
    assert(result_0 == 'TODO')


# Generated at 2022-06-25 07:45:50.829316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'TODO'


# Generated at 2022-06-25 07:46:00.348597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2194.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 1408.61
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:01.917406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:46:11.428202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_var_0 = 2276.0
    set_var_0 = {float_var_0, float_var_0, float_0}
    float_var_1 = 2365.65
    dict_var_0 = {}
    list_var_0 = []
    tuple_var_0 = (float_var_1, dict_var_0, list_var_0, set_var_0)
    action_module_var_0 = ActionModule(float_var_0, float_var_0, set_var_0, set_var_0, tuple_var_0, set_var_0)
    var_var_0 = action_run()

# Generated at 2022-06-25 07:46:13.791932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # AssertionError: Argument is not a module!
    # assert ActionModule(0.0, 0.0, 0.0, 0.0, 0.0) == 0.0
    pass

# Generated at 2022-06-25 07:46:21.830381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2467.67
    set_0 = {float_0}
    float_1 = 2421.0
    dict_0 = {}
    tuple_0 = (float_1, dict_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_module_0.run()
    var_1 = action_module_0.run(action_module_0)
    var_2 = action_module_0.run(action_module_0, action_module_0)
    var_3 = action_module_0.run(action_module_0, action_module_0, action_module_0)

# Generated at 2022-06-25 07:46:29.281271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    float_2 = float_1
    var_0 = action_module_0.run(float_2)

# Generated at 2022-06-25 07:46:34.471328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:38.172400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_run(set_0)
    var_0 = action_run(set_0, set_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:46:40.207133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    assert action_module_0.run(tmp_0, task_vars_0) == None

# Generated at 2022-06-25 07:46:46.176348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(['\x1f', '\x08', '', '\x0f', '\x13', '\x0e'], ['\x1f', '\x08', '', '\x0f', '\x13', '\x0e'], {'\x1f', '\x08', '', '\x0f', '\x13', '\x0e'}, {'\x1f', '\x08', '', '\x0f', '\x13', '\x0e'}, ('\x1f', '\x08', '', '\x0f', '\x13', '\x0e'), {'\x1f', '\x08', '', '\x0f', '\x13', '\x0e'})


# Generated at 2022-06-25 07:47:03.199950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  var_2 = 3.0
  var_1 = 7.0
  var_0 = 5.0
  set_0 = {var_1, var_1, var_1}
  tuple_0 = (var_0, "hello", var_2, var_2, var_2, var_2)
  class_0 = ActionModule(var_2, var_1, set_0, set_0, tuple_0, True)
  var_3 = class_0.run()
  assert var_3 == 3.0

# Generated at 2022-06-25 07:47:04.401299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 0, 0, 0, 0, 0)
    #TODO: implement test


# Generated at 2022-06-25 07:47:05.314672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:47:12.978771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {-2261.27, -2261.27}
    tuple_0 = (-2261.27, set_0, set_0, -2261.27)
    set_2 = {tuple_0, tuple_0}
    action_module_1 = ActionModule(set_0, tuple_0, set_0, set_2, tuple_0, set_0)
    var_2 = action_module_1.run(tmp=None, task_vars=None)
    return var_2

# Generated at 2022-06-25 07:47:17.909324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:47:28.066212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys

    test_suite = unittest.TestSuite()
    # test_suite.addTest(TestActionModule('test_case_0'))
    test_result = unittest.TestResult()

    test_suite.run(test_result)
    print("Errors: ", test_result.errors)
    print("Failures: ", test_result.failures)
    print("Skipped: ", test_result.skipped)
    print("Passed: ", test_result.passed)
    print("Tests Run: ", test_result.testsRun)

    if not test_result.wasSuccessful():
        sys.exit(1)


if __name__ == '__main__':
    # test_ActionModule_run()
    float_0 = 2207.0

# Generated at 2022-06-25 07:47:32.905257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:36.103115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.705528
    set_0 = {float_0, float_0, float_0}
    float_1 = 0.724292
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    return action_module_0.run()


# Generated at 2022-06-25 07:47:43.887967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 98.12
    set_0 = {float_0, float_0, float_0}
    float_1 = 93.41
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:47:48.574067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        int_0 = random.random()
        int_1 = random.random()
        action_module_0 = test_case_0()
        var_0 = action_module_0.run(float_0, float_0)
        assert (var_0 < int_0)
    except:
        assert False


# Generated at 2022-06-25 07:48:09.174746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1746.74
    set_0 = {1746.74}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:48:17.115996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = 2121.35
    float_3 = 2211.55
    float_4 = 2113.45
    float_5 = 2212.0
    float_6 = 2120.1
    float_7 = 2118.45
    float_8 = 2122.6
    float_9 = 2210.95
    float_10 = 2219.6
    float_11 = 2218.9
    float_12 = 2114.8
    float_13 = 2217.75
    float_14 = 2117.45
    float_15 = 2211.3
    float_16 = 2116.55
    float_17 = 2214.15
    float_18 = 2219.95
    float_19 = 2213.0
    float_20 = 2118.6
    float_21 = 2206.9

# Generated at 2022-06-25 07:48:22.623123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:48:25.041800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src_module_list = ["apt"]
    src_module_set = {src_module_list}
    src_module_list.append(src_module_set)
    assert len(src_module_list) == 2


# Generated at 2022-06-25 07:48:32.797050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_2 = 3266.0
    set_1 = {float_2, float_2, float_2}
    float_3 = 2919.63
    dict_1 = {}
    set_2 = {float_2, float_2, float_2}
    tuple_1 = (float_3, dict_1, dict_1, set_1)
    action_module_1 = ActionModule(float_2, float_2, tuple_1, set_1, tuple_1, set_1)
    dict_0 = {}
    dict_2 = {}
    tuple_0 = (dict_1, dict_0, dict_2)
    test_case_0()

# Generated at 2022-06-25 07:48:38.580704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Parameters: tmp, task_vars
    float_0 = 2269.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2132.70
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    result = action_module_0.run(dict_0, list_0)
    assert result is not None
    assert result == dict_0


# Generated at 2022-06-25 07:48:42.737620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 != var_0, var_0

# Generated at 2022-06-25 07:48:45.050997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing parameter 'tmp'
    string_0 = "tmp"
    # Testing parameter 'task_vars'
    string_1 = "task_vars"
    action_run()

# Generated at 2022-06-25 07:48:50.433134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(2207.0, 2207.0, {2207.0, 2207.0, 2207.0}, {2207.0, 2207.0, 2207.0}, (2126.65, {}, [], {2207.0, 2207.0, 2207.0}), {2207.0, 2207.0, 2207.0}, ActionBase(2207.0, 2207.0, {2207.0, 2207.0, 2207.0}, {2207.0, 2207.0, 2207.0}, (2126.65, {}, [], {2207.0, 2207.0, 2207.0}), {2207.0, 2207.0, 2207.0}))

# Generated at 2022-06-25 07:49:00.872284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    set_0 = set()
    set_1 = set()
    list_0 = list()
    list_1 = list()
    list_2 = list()
    list_3 = list()
    list_4 = list()
    list_5 = list()
    list_6 = list()
    list_7 = list()
    tuple_0 = (float_1, float_3, list_1, list_2, list_3, list_4, list_5, list_6)

# Generated at 2022-06-25 07:49:44.591490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(ActionModule(arg0), ActionModule)


# Generated at 2022-06-25 07:49:48.603593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:49:55.796515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    assert isinstance(action_module_0.run(), dict)

# Generated at 2022-06-25 07:49:59.308194
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Dummy test to verify that testing can be done
    assert True

# Generated at 2022-06-25 07:49:59.938201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0


# Generated at 2022-06-25 07:50:08.966221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2207.0
    set_0 = {float_0, float_0, float_0}
    float_1 = 2126.65
    dict_0 = {}
    list_0 = []
    tuple_0 = (float_1, dict_0, list_0, set_0)
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, tuple_0, set_0)
    task_vars_0 = {}
    tmp_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:50:16.501930
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:50:22.828516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 865.01
    action_run_0 = ActionRun(float_0)
    action_run_1 = ActionRun(float_0)
    float_1 = 643.69
    float_2 = 0.22
    string_0 = "fu"
    float_3 = 743.24
    float_4 = 557.9
    float_5 = 665.2
    float_6 = 798.8
    float_7 = 877.9
    float_8 = 683.4
    float_9 = 547.5
    float_10 = 728.3
    string_1 = "o"
    float_11 = 59.85
    float_12 = 0.86
    float_13 = 668.27
    float_14 = 599.81
    float_15

# Generated at 2022-06-25 07:50:32.141020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 6234.95
    float_1 = 532.1
    float_2 = 906.2
    float_3 = 945.67
    float_4 = 895.42
    float_5 = 821.88
    float_6 = 905.03
    float_7 = 78.2
    float_8 = 627.05
    float_9 = 1140.07
    set_0 = {float_7, float_3, float_0, float_2, float_1, float_4, float_9, float_8, float_5, float_6}
    action_module_0 = ActionModule(float_4, float_7, set_0, set_0, set_0)
    dict_0 = {}

# Generated at 2022-06-25 07:50:33.300571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule("host", "port", "nonce", "delegated_vars", "verbosity", "connection_info")
    action_module_0.run()