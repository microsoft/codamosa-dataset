

# Generated at 2022-06-25 07:41:41.009726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test variables
    tmp = None
    task_vars = None

    # Call method
    obj = ActionModule()
    result = obj.run(tmp, task_vars)
    display(result)

# Generated at 2022-06-25 07:41:50.329174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    tmp = "/tmp/ansible_tmp_5678_zOvGdY"
    task_vars = dict_0
    obj = ActionModule(str_0, dict_0, dict_0, dict_0, dict_0)
    obj.run(tmp, task_vars)
# def test_action_shell():
#     from ansible.plugins.action.shell import ActionModule
#
#     action_module = ActionModule(
#         task=dict(args=dict(
#             chdir='/tmp',
#             executable='/bin/bash -c'
#         )),
#         connection=None,
#         play_context=dict(basedir='/tmp', playbook_basedir='/tmp/pb'),
#         loader=None,
#         templar=None,

# Generated at 2022-06-25 07:41:55.040610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import ActionModule
    action_module = ActionModule()
    action_module.test_case_0()

# Generated at 2022-06-25 07:41:57.672742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit tests for method run of class ActionModule
    str_0 = "f#_g5"
    dict_0 = {list_0: str_0, list_0: dict_0}
    ansible_facts_data_1 = dict_0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:42:03.334488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    str_0 = "!'/"
    action_1 = ActionModule(str_0,str_0,str_0)
    action_1.run(str_0,str_0)
    list_0 = []
    dict_0 = {str_0: str_0, list_0: list_0, str_0: str_0}
    action_1.run(dict_0,dict_0)


# Generated at 2022-06-25 07:42:07.579548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "!'/"
    str_1 = "Lp$D"
    str_2 = "4'X/"
    list_0 = []
    dict_0 = {str_1: str_0, str_2: str_2, list_0: list_0, str_0: str_2}
    test_patterns = [("$"), ("$"), ("$")]


# Generated at 2022-06-25 07:42:17.985515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #print("\n Testing ...")
    str_0 = "!'/"
    list_0 = []
    dict_0 = {str_0: str_0, list_0: list_0, str_0: str_0}
    str_1 = "!"
    str_2 = "2"
    str_3 = "3"
    str_4 = "n"
    str_5 = "o"
    str_6 = "w"
    str_7 = "y"
    dict_1 = {str_5: [str_2], str_7: str_2, str_3: str_2, str_6: str_2, str_4: str_2, str_1: str_2}
    #test_case_0()
    list_1 = []

# Generated at 2022-06-25 07:42:28.330770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "!'/"
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    str_1 = "Shell Module"
    str_2 = "/bin/bash"
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
   

# Generated at 2022-06-25 07:42:29.167993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    assert True


# Generated at 2022-06-25 07:42:30.331432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_ActionModule = ActionModule()
    obj_ActionModule.run()

# Generated at 2022-06-25 07:42:36.219951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    assert action_module.run() is None

# Generated at 2022-06-25 07:42:38.211504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    del action_module_0.run
    # action_module_0.run(tmp='tmp', task_vars='task_vars')



# Generated at 2022-06-25 07:42:42.639013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-25 07:42:47.531907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    res = action_module_0.run()



# Generated at 2022-06-25 07:42:53.565687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_1 = ActionModule()
    del tmp  # tmp no longer has any effect
    # Shell module is implemented via command with a special arg
    action_module_run_1._task.args['_uses_shell'] = True

# Generated at 2022-06-25 07:42:56.675203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    print('In unit test for command module')
    print('Testing run method of class ActionModule')
    action_module.run()

# End of run method test


# Generated at 2022-06-25 07:43:05.858443
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of ActionModule
    action_module_0 = ActionModule()

    # Create an instance of TaskExecutor
    task_executor_0 = TaskExecutor()

    # Create an instance of Task
    task_0 = Task()

    # Create an instance of Connection
    connection_0 = Connection()

    # Create an instance of PlayContext
    play_context_0 = PlayContext()

    # Create an instance of DataLoader
    data_loader_0 = DataLoader()

    # Create an instance of Templar
    templar_0 = Templar()

    # Create an instance of SharedLoaderObj
    shared_loader_obj_0 = SharedLoaderObj()

    action_module_1 = ActionModule()

    # Assign instance of ActionModule created in setup to 'action_module_0'
    action_module_0 = action_module

# Generated at 2022-06-25 07:43:08.413774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-25 07:43:12.357212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_1 = ActionModule()
  tmp = None
  task_vars_1 = {}
  task_vars_1['inventory_hostname'] = 'host1'
  task_vars_1['hostvars'] = {'host1': {'group1': 123}}
  result = action_module_1.run(tmp, task_vars=task_vars_1)

# Generated at 2022-06-25 07:43:13.278436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:43:18.997898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    response = action_module_0.run()



# Generated at 2022-06-25 07:43:20.571653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy test for setup and teardown
    action_module_run_0 = ActionModule()


# Generated at 2022-06-25 07:43:23.245428
# Unit test for method run of class ActionModule
def test_ActionModule_run():


    action_module_0 = ActionModule()
    tmp = undefined
    task_vars = undefined
    assert action_module_0.run(tmp, task_vars) == undefined

# Generated at 2022-06-25 07:43:29.013401
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_object = ActionModule()
    
    task = dict()
    task['parameter1'] = '1'   
    task['parameter2'] = '2'
    task['parameter3'] = '3'

    task_vars = dict()
    task_vars['parameter1'] = '1'   
    task_vars['parameter2'] = '2'
    task_vars['parameter3'] = '3'

    action_module_object.run(task, task_vars)


# Generated at 2022-06-25 07:43:30.588484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    result = action_module_0.run(tmp, task_vars)
    assert result

# Generated at 2022-06-25 07:43:37.690712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a temporary file
    tmp = tempfile.mktemp()

    # Initialize the dictionnary of the task variables
    task_vars = dict()

    # Initialize a new ActionModule instance
    action_module_new = ActionModule()

    # Execute method
    result = action_module_new.run(tmp, task_vars)

    # Check the result with expected output

# Generated at 2022-06-25 07:43:38.673052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert False  # TODO: implement your test here


# Generated at 2022-06-25 07:43:40.409834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:43:47.320798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    try:
        res = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:43:52.632209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    # result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    if result_0 is None:
        print('Test passed!')
    else:
        print('Test failed!')


# Generated at 2022-06-25 07:44:06.908060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Call method run of ActionModule class
    action_module_0.run()

if __name__ == '__main__':
    # Create an object of the class ActionModule
    a0 = ActionModule()
    a0.run()

# Generated at 2022-06-25 07:44:08.655604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:44:11.689439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_1 = ActionModule()
        action_module_1.run()
    except Exception as e:
        print (e)


# Generated at 2022-06-25 07:44:17.754976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_0 = dict()
    task_vars_0 = dict()
    tmp_0 = None
    task_0['args'] = dict()
    task_0['args']['_uses_shell'] = True
    del tmp_0
    command_action_0 = ActionModule()
    task_vars_0 = None
    result_0 = command_action_0.run(task_vars_0)

# Generated at 2022-06-25 07:44:18.796828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:44:21.696191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert True


# Generated at 2022-06-25 07:44:26.648400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result is not None


# Generated at 2022-06-25 07:44:31.342942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    comment = 'Comment'
    free_form = 'Free form'
    action_module_0 = ActionModule()
    ret_value = action_module_0.run()
    assert ret_value is None

# Generated at 2022-06-25 07:44:33.116295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1_run = action_module_1.run(task_vars=None)

# Generated at 2022-06-25 07:44:36.750865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:44:55.052856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:44:57.009552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()

# Generated at 2022-06-25 07:45:00.429219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # using a dict for task_vars
    action_module.run(task_vars={})

    # passing None for task_vars
    action_module.run(task_vars=None)

# Generated at 2022-06-25 07:45:03.399931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    tmp = 1
    task_vars = {'foo': 'bar'}
    action_module_obj.run(tmp, task_vars)

# Generated at 2022-06-25 07:45:07.440665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:45:09.911409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # deferred_to is set to True
    action_module = ActionModule()
    assert action_module.run(tmp="tmp", task_vars="task_vars") == "action_package.command"


# Generated at 2022-06-25 07:45:14.063786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule()
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result_0 == {'ansible_facts': {}}, result_0

# Generated at 2022-06-25 07:45:19.074267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    action_module_1.run()



# Generated at 2022-06-25 07:45:20.912570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-25 07:45:22.333377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:45:39.948348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = var_0
    result = action_module_0.run(task_vars)
    assert result == ''

# Generated at 2022-06-25 07:45:50.453933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -530
    bytes_0 = b'\x8b\xfa\x1d\x9d\xba`\x96\x99\xc6lZ\x84'
    bytes_1 = b'\x9ekv\xca\xd3\x89\xf3\xe2\xb8\x12\x0c\x11\x90\x91\xcb\xaa\xc3\x94\x8e'
    int_1 = -2708
    float_0 = -3032.0
    int_2 = -3744
    float_1 = -272.0
    float_2 = -624.0
    int_3 = -3048

# Generated at 2022-06-25 07:45:58.270457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    var_0 = action_run()
    assert(var_0 == 0)

# Generated at 2022-06-25 07:46:02.256637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()
    assert check_equal(action_module_run.var_0, var_0)

# Generated at 2022-06-25 07:46:10.125561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2168.0
    int_0 = -2146
    bytes_0 = b'\x99\xbc\xa7\xbc\xac\xbc\xac\xbc\xa7'
    float_1 = -854.897
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:11.936819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:46:16.715373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -904.0
    int_0 = -1585
    bytes_0 = b'A'
    float_1 = -1327.94326
    bool_0 = True
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    task_vars_0 = None
    action_module_0.run(int_0, task_vars_0)


# Generated at 2022-06-25 07:46:22.309488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_1 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    var_1 = action_run()
    case_0 = None
    case_0 = ActionResult(var_1.stdout_lines, var_1.stderr_lines, var_1.failed, var_1.changed, var_1.skipped, var_1.rc, var_1.warnings, var_1.exception)
    assert case_0 is not None
    assert var_1.stdout is not None
    assert var_1.st

# Generated at 2022-06-25 07:46:24.080775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Method run of class ActionModule called.')
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:46:25.795829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # TODO: implement test cases


# Generated at 2022-06-25 07:47:02.916267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = ''
    bool_0 = True
    int_1 = 0
    action_module_0 = ActionModule(int_0, str_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.run(int_1)


# Generated at 2022-06-25 07:47:09.609857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tuple_0 = (1,)
    str_0 = str(tuple_0)
    task_vars_0 = {str_0: 'foo'}
    tuple_0 = action_module_0.run(task_vars=task_vars_0)
    action_result_0 = tuple_0[0]
    assert (action_result_0.rc == 0)


# Generated at 2022-06-25 07:47:11.391609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run() == "output"


# Generated at 2022-06-25 07:47:17.494672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    float_0 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)

    # Testing with no parameters

    # Testing with parameter
    tmp = ActionModule.tmp
    action_run()
    tmp = ActionModule.tmp
    task_vars_0 = ActionModule.task_vars
    action_run()

    # Verify
    pass

# Generated at 2022-06-25 07:47:19.605012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for run of ActionModule
    pass


# Generated at 2022-06-25 07:47:22.931545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_2 = -1432.99472
    bool_1 = False
    action_module_0 = ActionModule(float_1, int_0, bytes_0, float_2, int_0, bool_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:47:26.143445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:47:30.008445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 123.0
    int_0 = -873
    bytes_0 = b'\x14\x8e\x1f\x07\xa2\x94\xfa\x9c\x17\xc2\xf0\x4c\x24'
    float_1 = 972.97
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    assert action_module_0.run(var_0) == 0

# Generated at 2022-06-25 07:47:34.638266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  float_0 = -2335.0
  int_0 = -2142
  bytes_0 = b'\x85j.'
  float_1 = -1432.99472
  bool_0 = False
  action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
  task_vars = {}
  action_module_0.run(None, task_vars)

# Generated at 2022-06-25 07:47:41.504327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(var_0)
    var_1 = action_module_run(var_0, var_0)
    try:
        assert (var_0 == var_1)
    except AssertionError:
        print('AssertionError: Run test failed')


# Generated at 2022-06-25 07:49:08.802924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2124.8718
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    # action_module_0.run()
    # ansible 2.9.1
    # command_0 = Command(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    # ansible 2.9.10
    # command_0 = CommandModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)

# Generated at 2022-06-25 07:49:13.140147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2335.0
    int_0 = -2142
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    bool_0 = False
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    var_0 = action_module_0.run()
    assert var_0 == {}

# Generated at 2022-06-25 07:49:20.572389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    var_action_module_0 = action_module_0.run(tmp, task_vars)
    del tmp
    del task_vars
    del action_module_0
    del var_action_module_0

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:49:23.467845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(test_case_0())

# Generated at 2022-06-25 07:49:32.590016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'sFHS,NbcUq)K'
    str_1 = '-h'
    list_0 = ['cboUH=M', 'i', 'a']
    dict_0 = {}
    float_0 = 2763.2554
    list_1 = [1124.528, 'yGtEo#', -2067.4, 'P', 'X9']
    float_1 = -253.25
    dict_1 = {'Pb': '%', 'x.qIa1,': 2235.37, 'jK@!': 'H-v'}
    dict_2 = {'x+': '~f=E', '5t.e+': 'I', 'pvE': list_0, 'FR@Z': 'z$#vA)'}
   

# Generated at 2022-06-25 07:49:42.939975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	global test_ActionModule_run__0
	global test_ActionModule_run__1
	global test_ActionModule_run__2
	global test_ActionModule_run__3
	global test_ActionModule_run__4
	global test_ActionModule_run__5
	global test_ActionModule_run__6
	global test_ActionModule_run__7
	global test_ActionModule_run__8
	global test_ActionModule_run__9
	global test_ActionModule_run__10
	global test_ActionModule_run__11
	global test_ActionModule_run__12
	global test_ActionModule_run__13
	global test_ActionModule_run__14
	global test_ActionModule_run__15
	global test_ActionModule_run__16
	global test_ActionModule_run__17
	

# Generated at 2022-06-25 07:49:50.042054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2335.0
    bytes_0 = b'\x85j.'
    float_1 = -1432.99472
    action_module_0 = ActionModule(float_0, -2142, bytes_0, float_1, -2142, False)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:49:59.552753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_0, int_0, bytes_0, float_1, int_0, bool_0)
    with pytest.raises(TypeError):
        # FIXME
        assert action_module_0.run() == "tmp no longer has any effect\n"
    with pytest.raises(TypeError):
        assert action_module_0.run(tmp=None, task_vars=None) == 'tmp no longer has any effect\n'

    # FIXME
    assert action_module_0.run(tmp=None, task_vars=None) == 'tmp no longer has any effect\n'

# Generated at 2022-06-25 07:50:04.596695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = b'\x7F\xFB\x84'
    int_0 = -2361
    bytes_0 = b'\xB1'
    float_0 = -8915.87186
    float_1 = -2914.3
    bool_0 = False
    action_module_0 = ActionModule(arg_0, int_0, bytes_0, float_0, float_1, bool_0)
    action_module_0.run()



# Generated at 2022-06-25 07:50:13.831355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    '''
    tmp no longer has any effect
    Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)

    return result
    '''