

# Generated at 2022-06-25 07:41:37.249389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = set()
    float_0 = 7339.28
    bool_0 = None
    int_0 = 9122
    str_0 = 'line'
    action_module_0 = ActionModule(dict_0, set_0, float_0, bool_0, int_0, str_0)
    dict_1 = {}
    dict_2 = {}
    str_0 = action_module_0.run(dict_1, dict_2)
    pass


# Generated at 2022-06-25 07:41:45.021940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters:
    tmp_1 = None
    task_vars_1 = None

    # Output parameters:
    result_0 = None

    action_module_0 = ActionModule()
    result_0 = action_module_0.run(tmp=tmp_1, task_vars=task_vars_1)

    # Output assertion
    assert result_0.__class__.__name__ == 'dict'
    assert result_0 == {'box_type': 'AAA'}

# Generated at 2022-06-25 07:41:49.323486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = set()
    float_0 = 6350.499910444486
    bool_0 = None
    int_0 = 9502
    str_0 = 'line'
    action_module_0 = ActionModule(dict_0, set_0, float_0, bool_0, int_0, str_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:41:55.869941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:42:02.465358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = set()
    float_0 = 4250.292358
    bool_0 = True
    int_0 = 4173
    str_0 = 'Buffer'
    action_module_0 = ActionModule(dict_0, set_0, float_0, bool_0, int_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:42:10.071415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()


# Generated at 2022-06-25 07:42:14.380695
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an object for class ActionModule
    action_module_0 = ActionModule((), (), 0, None, 0, '')

    # Call method run of the class ActionModule
    assert action_module_0.run() == None

# Generated at 2022-06-25 07:42:20.888518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = set()
    float_0 = 4257.311
    bool_0 = None
    int_0 = 2351
    str_0 = 'line'
    action_module_0 = ActionModule(dict_0, set_0, float_0, bool_0, int_0, str_0)
    assert action_module_0.run() == None

# Generated at 2022-06-25 07:42:27.885789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = set()
    float_0 = 4257.311
    bool_0 = None
    int_0 = 2351
    str_0 = 'line'
    action_module_0 = ActionModule(dict_0, set_0, float_0, bool_0, int_0, str_0)
    TaskVars_0 = action_module_0.run(dict_0, dict_0)
    assert isinstance(TaskVars_0, dict)
    assert TaskVars_0['failed'] == False


# Generated at 2022-06-25 07:42:35.406395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['conn_params'] = dict()
    dict_0['ansible_version'] = int()
    dict_0['sanitize_passwords'] = None
    dict_0['set_type'] = list()
    dict_0['_fact_cache'] = dict()
    dict_0['tags'] = set()
    dict_0['_role_params'] = dict()
    dict_0['vagrant'] = dict()
    dict_0['_tmpdir'] = str()
    dict_0['_bin_ansible_callbacks'] = float()
    dict_0['ansible_job_id'] = str()
    dict_0['default_vault_id'] = str()
    dict_0['jinja2_native'] = None

# Generated at 2022-06-25 07:42:42.029275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    var_0 = None
    var_1 = None
    action.run(var_0, var_1)

# Generated at 2022-06-25 07:42:44.195219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'ansible.legacy.command'
    var_1 = 'ActionModule'
    var_2 = None
    var_3 = 'run'

    test_case_0()



# Generated at 2022-06-25 07:42:49.642300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(action='ActionModule', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert not result


# Generated at 2022-06-25 07:43:00.068509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_1 = '''command_1'''
    templar_2 = '''templar_2'''
    var_3 = '''var_3'''
    argspec_4 = '''argspec_4'''
    loader_5 = '''loader_5'''
    var_6 = '''var_6'''
    var_7 = '''var_7'''
    task_vars_8 = '''task_vars_8'''
    template_9 = '''template_9'''
    play_context_10 = '''play_context_10'''
    connection_11 = '''connection_11'''
    task_12 = '''task_12'''
    var_13 = '''var_13'''
    tmp_14 = '''tmp_14'''
   

# Generated at 2022-06-25 07:43:03.927078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    var_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Arguments for method run
    tmp = None
    task_vars = None

    # Call method run from class ActionModule
    result = var_0.run(tmp=tmp, task_vars=task_vars)

    # Check that the value of the result is the expected one
    assert result == expected_result

# Generated at 2022-06-25 07:43:06.975228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule
    var_0 = None
    var_0 = action_module_0.run(var_0)
    assert var_0 == None

# Generated at 2022-06-25 07:43:09.348640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None # type = None
    task_vars = None # type = None
    actionmodule = ActionModule(tmp, task_vars)
    var_0 = actionmodule.run(tmp, task_vars)
    assert var_0 == None

# Generated at 2022-06-25 07:43:10.814019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_module_loader = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:43:13.366513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call test_case_0
    if test_case_0() == False:
        return

# Start test suite
test_ActionModule_run()
test_case_0()

# Generated at 2022-06-25 07:43:15.836726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = list()
    var_1.append('ansible.legacy.command')
    var_4 = dict()
    var_4['_uses_shell'] = True

# Generated at 2022-06-25 07:43:27.428278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 276.0
    list_0 = [10.0, float_0]
    tuple_0 = (float_0, 1.0)
    dict_0 = {float_0: float_0, float_0: float_0}
    str_0 = "~"
    int_0 = 8
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    action_module_0.run()
    list_1 = [float_0, float_0, 10.0]
    tuple_1 = (float_0,)
    dict_1 = {float_0: float_0, float_0: float_0}
    str_1 = "~"
    int_1 = 3

# Generated at 2022-06-25 07:43:28.112099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0()

# Generated at 2022-06-25 07:43:32.775760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Note: Not all tests can be run, as we need to run the Ansible Playbook from a Linux/Bash/SSH environment
  # There is not SSH connection from TravisCI to test this functionality
  # However, the code is covered by other tests (confirm!)
  assert false

# Generated at 2022-06-25 07:43:35.219127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()

# Generated at 2022-06-25 07:43:42.665041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  float_0 = -441.0
  list_0 = [float_0, float_0]
  tuple_0 = ()
  dict_0 = {}
  str_0 = '~'
  int_0 = -2076
  action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
  var_0 = action_run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:43:47.404344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_1 = []
    tuple_1 = ()
    dict_1 = {}
    str_1 = ''
    int_1 = 0
    action_module_1 = ActionModule(list_1, tuple_1, dict_1, str_1, int_1)
    var_1 = action_module_1.run()

# Generated at 2022-06-25 07:43:51.870172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -632.0
    list_0 = [float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '/_O'
    int_0 = -1741
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:58.180006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = -2076
    var_1 = [-441.0, -441.0]
    var_2 = ()
    var_3 = {}
    var_4 = '~'
    var_5 = -2076
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_7 = -1480
    var_8 = -2076
    var_9 = ActionModule(var_7, var_1, var_2, var_3, var_4, var_8)
    var_10 = [var_9, var_6]
    var_11 = -5080
    var_12 = [var_11, var_9]
    var_13 = '#+$A'
    var_14 = -8

# Generated at 2022-06-25 07:44:00.327794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result == None


# Generated at 2022-06-25 07:44:04.083785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-25 07:44:12.524853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2076
    action_module_0 = ActionModule(int_0, int_0, int_0, int_0, int_0, int_0)
    var_0 = action_module_0.run(tmp=int_0, task_vars=int_0)

# Generated at 2022-06-25 07:44:20.779630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing
    arg = -162.3
    arg = -504.0
    arg = [arg, arg]
    arg = ()
    arg = {}
    arg = '*'
    arg = 974
    class_obj = ActionModule(arg, arg, arg, arg, arg, arg)
    # Testing real case
    var_arg = -2265.0
    var_arg = -2265.0
    var_arg = [var_arg, var_arg]
    var_arg = ()
    var_arg = {}
    var_arg = '~'
    var_arg = -234
    var_arg = class_obj.run(var_arg, var_arg)
    # Testing real case
    var_arg = -2027.2
    var_arg = -2027.2
    var_

# Generated at 2022-06-25 07:44:26.425044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run')
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    run_test(var_0, '')

# Generated at 2022-06-25 07:44:34.761515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -971.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '&'
    int_0 = -2046
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    task_vars_0 = {}
    tmp_0 = 'P'
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    print(var_0)

# Generated at 2022-06-25 07:44:39.263074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    try:
        # Try to call the run method
        action_module_0.run()
    except:
        # If it fails, print the exception
        import sys
        print("Unexpected error:", sys.exc_info()[0])
        # Raise the exception to get the test to fail
        raise

# Generated at 2022-06-25 07:44:48.631164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    action_module_0 = ansible.plugins.action.__loader__.get('ansible.legacy.shell')
    # TypeError: run() takes at least 2 arguments (1 given)
    result = action_module_0.run()
    assert type(result) is dict
    # test_case_0
    action_module_0 = ansible.plugins.action.__loader__.get('ansible.legacy.shell')
    # TypeError: run() takes at least 2 arguments (1 given)
    result = action_module_0.run()
    assert type(result) is dict

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 07:44:52.275789
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    tmp_0 = None
    var_0 = action_module_0.run(tmp=tmp_0)

# Generated at 2022-06-25 07:44:55.824068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run(1, [[1, 2, 3], [4, 5, 6]]) == [[3, 6, 9], [12, 15, 18]]

# Generated at 2022-06-25 07:45:05.673448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    int_0 = -2076
    list_0 = ['run']
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    float_0 = -441.0
    action_module_0 = ActionModule(int_0, list_0, tuple_0, dict_0, str_0, float_0)
    float_1 = -441.0
    list_1 = [float_0, float_1]
    tuple_1 = ()
    dict_1 = {}
    str_1 = '~'
    int_1 = -2076
    action_module_1 = ActionModule(float_1, list_1, tuple_1, dict_1, str_1, int_1)
    var_0 = action_run()


# Generated at 2022-06-25 07:45:09.066385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    # This test is for stand-alone module, so the param task_vars is not necessary
    param_0 = action_run(task_vars)

# Generated at 2022-06-25 07:45:20.695722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:25.532492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_run()
    print(var_0)


# Generated at 2022-06-25 07:45:27.963720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # must use assert_equals_ with action_run()
    assert_equals_(action_run(), 0)

# Generated at 2022-06-25 07:45:29.795476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:45:33.128931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:45:39.889618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'ansible.legacy.shell.ActionModule.run' in globals()
    if 'ansible.legacy.shell.FileSearch' in globals():
        assert 'ansible.legacy.shell.FileSearch.action_run' not in globals()
    assert 'ansible.legacy.shell.ActionBase' in globals()
    if 'ansible.legacy.shell.ActionBase' in globals():
        assert 'ansible.legacy.shell.ActionBase.run' in globals()
    assert 'ansible.legacy.shell.ActionBase' in globals()
    if 'ansible.legacy.shell.ActionBase.run' not in globals():
        assert 'ansible.legacy.shell.ActionBase.action_run' not in globals()

# Generated at 2022-06-25 07:45:41.524254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:45:47.781916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    action_run()

# Generated at 2022-06-25 07:45:53.211282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    list_0 = list()
    tuple_0 = tuple()
    dict_0 = dict()
    str_0 = str()
    int_0 = int()
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:45:56.324168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:16.833064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    action_module_0 = ActionModule(tuple_0)

# Generated at 2022-06-25 07:46:19.001622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -208.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '2X'
    int_0 = -256
    tmp_0 = None
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_run(tmp_0)

    assert(var_0)

# Generated at 2022-06-25 07:46:23.416221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = int
    action_module_1 = ActionModule(param_0)
    result = action_module_1.run()

# Generated at 2022-06-25 07:46:31.462391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -843.0
    list_0 = [.5, .7, float_0]
    tuple_0 = (None, )
    dict_0 = {}
    str_0 = 'Rgu-i8H'
    int_0 = -935
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_module_run()


# Generated at 2022-06-25 07:46:35.449523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:39.137512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:46:39.688963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run() == None

# Generated at 2022-06-25 07:46:44.007782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -872.0
    list_1 = [float_1, float_1]
    tuple_1 = ()
    dict_1 = {}
    str_1 = '\n'
    int_1 = -2646
    action_module_1 = ActionModule(float_1, list_1, tuple_1, dict_1, str_1, int_1)
    var_0 = action_run()
    return var_0



# Generated at 2022-06-25 07:46:45.521376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionsBase.ActionModule.run()
    assert result == None

# Generated at 2022-06-25 07:46:48.967658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the ActionModule run method
    print('Testing action run method')
    assert True == True

# Test class ActionModule

# Generated at 2022-06-25 07:47:29.553650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    float_0 = -3547.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '}'
    int_0 = -2437
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_module_0.run(tmp, task_vars)
    assert var_0 == True

# Generated at 2022-06-25 07:47:30.322334
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:38.326365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp= None
  task_vars= None
  float_0 = -441.0
  list_0 = [float_0, float_0]
  tuple_0 = ()
  dict_0 = {}
  str_0 = '~'
  int_0 = -2076
  action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
  var_0 = action_module_0.run(tmp, task_vars)
  assert var_0
  assert None

# Generated at 2022-06-25 07:47:44.179108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 92.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '>'
    int_0 = -1227
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:47:51.582335
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Define test parameters
    tmp = None
    task_vars = None

    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:47:54.897752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Start testing ActionModule.run')
    action_module_0 = test_case_0()
    var_0 = action_run()
    print('Testing completed!')

# Run all the tests

if __name__ == '__main__':
    print('Start testing ActionModule')
    test_ActionModule_run()
    print('Testing completed!')

# Generated at 2022-06-25 07:48:00.300523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)

# Generated at 2022-06-25 07:48:06.750365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare parameters
    tmp = None
    task_vars = None

    # Declare target object
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:48:13.672620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -69.0
    list_0 = [float_0, float_0, float_0]
    tuple_1 = ()
    dict_0 = {}
    str_0 = ']]'
    int_0 = 607
    action_module_0 = ActionModule(float_0, list_0, tuple_1, dict_0, str_0, int_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:48:22.631590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(action_module_0.run)
    assert isinstance(action_module_0.run(), (bool, dict))
    assert action_module_0.run() == False
    assert action_module_0.run() == {}
    assert action_module_0.run() == True
    assert type(action_module_0.run(), (bool, dict))
    assert action_module_0.run() == False
    assert action_module_0.run() == {}
    assert action_module_0.run() == True
    assert type(action_module_0.run(), (bool, dict))

# Generated at 2022-06-25 07:49:55.927397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_run = ActionModule.run
    except:
        assert False


# Generated at 2022-06-25 07:49:58.303490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:50:04.252753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    var_0 = action_module_0.run(tmp = None, task_vars = None)
    print(var_0)

# Generated at 2022-06-25 07:50:09.346560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = None
    task_vars = None

    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run(task_vars)
    assert var_0 == None, "Expected <None>, but got <%s>" % type(var_0)

# Generated at 2022-06-25 07:50:13.786356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -441.0
    list_0 = [float_0, float_0]
    tuple_0 = ()
    dict_0 = {}
    str_0 = '~'
    int_0 = -2076
    action_module_0 = ActionModule(float_0, list_0, tuple_0, dict_0, str_0, int_0)
    tmp_0 = None
    task_vars_0 = 740
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:50:22.678955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Declare our arguments
  ansible_1 = {}
  ansible_1['ansible_connection'] = None
  ansible_1['ansible_ssh_pass'] = None
  ansible_1['ansible_ssh_port'] = None
  ansible_1['ansible_ssh_user'] = None
  ansible_1['ansible_ssh_host'] = None
  ansible_1['ansible_python_interpreter'] = '/usr/bin/python'
  ansible_1['ansible_become'] = False
  ansible_1['ansible_become_user'] = ''
  ansible_1['ansible_become_password'] = ''
  ansible_1['ansible_become_method'] = 'sudo'
  ansible_1['ansible_become_exe']

# Generated at 2022-06-25 07:50:24.068482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True

# Generated at 2022-06-25 07:50:32.712093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'action_module_0' == 'action_module_0'
    assert -842 == -842
    assert 'action_module_0' == 'action_module_0'
    assert 'action_run' == 'action_run'
    assert '-0.0' == '-0.0'
    assert -975 == -975
    assert -896.0 == -896.0
    assert 'list_0' == 'list_0'
    assert 'list_0' == 'list_0'
    assert 'action_module_0' == 'action_module_0'
    assert -932.0 == -932.0
    assert '-441.0' == '-441.0'
    assert 'action_run' == 'action_run'
    assert 'list_0' == 'list_0'

# Generated at 2022-06-25 07:50:34.234378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-25 07:50:38.162888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(3.141592653589793, [3.141592653589793, 3.141592653589793], (), dict(), '~', -2076)
    var_0 = action_run()
    #assert var_0 == -441.0

if __name__ == "__main__":
    test_ActionModule_run()