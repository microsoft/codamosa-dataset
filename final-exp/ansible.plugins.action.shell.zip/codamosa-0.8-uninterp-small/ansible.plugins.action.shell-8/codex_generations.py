

# Generated at 2022-06-25 07:41:36.290945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1023
    bool_0 = True
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    action_module_0.run(int_0)


# Generated at 2022-06-25 07:41:43.973286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1023
    bool_0 = True
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)

    action_module_0.run(int_0, dict_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:41:44.788528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:41:50.472404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict({tuple([]): int()})
    action_module_0 = ActionModule(dict_0, dict_0, dict_0, dict_0)
    tmp_0 = None
    dict_1 = dict({u'failed': bool()})
    dict_2 = dict({u'failed': bool()})
    assert action_module_0.run(tmp_0, dict_1) == dict_2


# Generated at 2022-06-25 07:41:53.204804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5
    bool_0 = False
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    action_module_0.run(bool_0, dict_0)


# Generated at 2022-06-25 07:41:57.086629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1023
    bool_0 = True
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:42:01.330837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1023
    bool_0 = True
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    temp_0 = tempfile.TemporaryFile()
    task_vars_0 = {}
    result = action_module_0.run(temp_0, task_vars_0)

# Generated at 2022-06-25 07:42:04.722707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1024
    bool_0 = False
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    action_module_0.run()



# Generated at 2022-06-25 07:42:10.847469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 1023
  bool_0 = True
  dict_0 = {}
  action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
  (tmp, task_vars) = (None, None)
  try:
    action_module_0.run(tmp, task_vars)
  except Exception as exception_0:
    assert False

# Generated at 2022-06-25 07:42:15.438097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 919
    bool_0 = True
    dict_0 = {}
    action_module_0 = ActionModule(int_0, bool_0, int_0, dict_0, dict_0, int_0)
    result = action_module_0.run(dict_0, dict_0)
    assert result != None

# Generated at 2022-06-25 07:42:27.926130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Y'
    int_0 = 354
    bool_0 = True
    dict_0 = {bytes_0: int_0, bool_0: bool_0, bool_0: int_0, bool_0: bool_0}
    str_0 = "Ff|7$QP>gA}$0^]h_)Tp]"
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(str_0, dict_0, int_0, int_0, dict_0, tuple_0)
    float_0 = None
    dict_1 = {}
    var_0 = action_run()
    str_1 = ''

# Generated at 2022-06-25 07:42:33.365977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b'\x9fDy\x80\x81\x1dy\xdb\x13\x03\x01\xc3\x86\xeb*\xf4\xe6\x19\xb5\xcc\xbb\x7f\xaa\xd5\xb9\xcd\xbc\xa1\x98\xe7Z\x8b\x7f\x93\xc6\x15\x1b\x85\xf1\x07\x87\xbf'

# Generated at 2022-06-25 07:42:38.776054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

    assert None == action_

# Generated at 2022-06-25 07:42:47.193474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ',J'
    action_module_0 = ActionModule(str_0, None, None, None, None, None)
    action_module_1 = ActionModule(None, None, None, None, None, None)
    action_module_1.run()
    action_module_0.run()
    action_module_1.run()
    assert action_module_0.run() == 0
    assert action_module_1.run() == 0
    str_1 = 'dM],t{'
    str_2 = '\x10xXz=}`\t'
    # Test legacy action registry
    action_module_2 = ActionModule()
    action_module_2.run()
    action_module_1.run()
    assert action_module_1.run() == 0
    assert action

# Generated at 2022-06-25 07:42:49.479632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule()
        assert False
    except TypeError as var_0:
        print(var_0)

# Main function for testing

# Generated at 2022-06-25 07:42:59.925851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    try:
        action_module_2 = ActionModule(b'O^', {}, {}, {}, None, True)
    except Exception as exce0:
        print(exce0)
    else:
        try:
            action_module_2 = ActionModule('', 3, 3.0, None, '', None)
        except Exception as exce0:
            print(exce0)
        else:
            try:
                action_module_2 = ActionModule('', [3], [3.0], [None], ['', None])
            except Exception as exce0:
                print(exce0)

# Generated at 2022-06-25 07:43:04.462189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    # TODO whatever should

# Generated at 2022-06-25 07:43:08.132670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
        result = action_module_0.run(task_vars=task_vars)
    except:
        result = None

    assert result is None

# Generated at 2022-06-25 07:43:17.341721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'?'
    int_0 = 350
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "z5S7*0X9$uV7DZM0,u4*"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    str_1 = "F<5&%1N$tg1NQt Wg$M"
    float_0 = None
    str_2 = ''

# Generated at 2022-06-25 07:43:18.038229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1



# Generated at 2022-06-25 07:43:28.784223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization of var_0
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    float_0 = None
    
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    
    del(action_module_0)

# Generated at 2022-06-25 07:43:38.378251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'z'
    int_0 = 0
    bool_0 = False
    dict_0 = {bytes_0: float('nan'), bytes_0: float('nan'), bool_0: int_0, bool_0: float('nan')}
    str_0 = "U:aa6A4q3_k\u0095<\u0095"
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    action_run()
    str_1 = ".|\u0082r\u0094\u0094\u0096\u0096\u0091\u0090\u0086u"
    tuple_1 = (tuple_0,)
   

# Generated at 2022-06-25 07:43:40.237050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: test run
    assert(True)


# Generated at 2022-06-25 07:43:50.621053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'D'
    int_1 = 420
    bool_1 = True
    dict_1 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_2 = "iW0',wN_RM3i$rW49&1x"
    tuple_1 = (bool_0,)
    action_module_2 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_1 = action_run()
    float_1 = None
    str_3 = ''
    action_module_3 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    assert action_module_

# Generated at 2022-06-25 07:43:57.420720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'KkWm\x7fS?#\x7f\x1f?'
    tuple_0 = (False,)
    dict_0 = {bytes_0: bytes_0, 'Q(8\x1fb\x1d\x5f': tuple_0, False: tuple_0, False: bytes_0}
    str_0 = "luO!3~+1hm(2\x1bJ(0Y"
    action_module_0 = ActionModule(str_0, tuple_0, dict_0, dict_0, dict_0, True)
    action_module_0.run(tmp=tuple_0)
    bytes_1 = b'\x1f\x14%@\x0f\x04\x04\x10\x1f\x1d'

# Generated at 2022-06-25 07:44:03.726174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:44:13.338531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "854v1&'0]?I$1'=_!ic#odqB\\I$(Z/'{KIc>l9F/@}yC+d[F_I&x<8q~JAP@+f,^Euh(;M9R."
    bytes_0 = b'Q'
    bytes_1 = b'<'
    int_0 = 790
    dict_0 = {bytes_1: int_0, str_0: bytes_1, bytes_1: str_0, bytes_0: bytes_1, str_0: str_0, bytes_1: bytes_0}
    str_1 = '\\NzO+q$/ElE!$)Kj7}{^e'
    tuple_0 = (dict_0,)
    dict_1

# Generated at 2022-06-25 07:44:20.180937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G'
    int_0 = 636
    int_1 = 624
    list_0 = []
    float_0 = None
    str_0 = 'c'
    action_module_0 = ActionModule(bytes_0, int_0, int_1, list_0, float_0, str_0)
    action_module_0.run()
    str_1 = "8392_W#pA566zKjG9YN"
    action_module_1 = ActionModule(str_1, int_1, int_1, list_0, float_0, str_0)
    action_module_1.run()


# Generated at 2022-06-25 07:44:26.074169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()
    float_24 = float()

# Generated at 2022-06-25 07:44:27.969697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert test_case_0() == 0, 'Test case 0 failed.'

# Generated at 2022-06-25 07:44:42.163239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

#Unit test for method

# Generated at 2022-06-25 07:44:51.618749
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:45:03.116584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'8'
    int_0 = 186
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = 'k&hB~YPHn#!l;X[5@x%'
    tuple_0 = (bytes_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    set_0 = set()
    action_module_1 = ActionModule(bytes_0, int_0, dict_0, int_0, set_0, dict_0)

# Generated at 2022-06-25 07:45:07.321064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # str_0 is a dummy argument, just to make sure the combinatorics work
    action_module_0, task_vars_0 = ActionModule("", None, None, 0, 0, None), dict()
    result_0 = action_module_0.run(None, task_vars_0)
    # TODO: Run the command, check the result
    pass


# Generated at 2022-06-25 07:45:14.866395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:45:20.804600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:45:28.329336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    action_module_0 = ActionModule()

    str_0 = "./n\"gN'U_\u00164'\u0017(5;Y%5Q5o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y3o4y"
    str_1 = "iW0',wN_RM3i$rW49&1x"
   

# Generated at 2022-06-25 07:45:36.621699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'j'
    uint_0 = 0
    str_0 = ']S&ay[mvJsD1}C4Y'
    uint_1 = 0
    list_0 = [False]
    str_1 = '/'
    str_2 = 'i{M}'
    dict_0 = {bytes_0: bytes_0, uint_0: list_0, str_0: bytes_0, uint_1: list_0, str_1: bytes_0, str_2: list_0}
    float_0 = None
    str_3 = 'q'
    action_module_0 = ActionModule(str_0, str_2, dict_0, uint_1, str_1, str_3)
    var_0 = action_run()

# Generated at 2022-06-25 07:45:38.154579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() is None


# Generated at 2022-06-25 07:45:48.393667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_2 = b'\x00'
    int_2 = 420
    bool_2 = True
    dict_2 = {bytes_2: bytes_2, bytes_2: int_2, bool_2: bytes_2, bool_2: int_2}
    str_2 = "E/nJ/\x1cg\x1c\x06\x02B\x02\x03\x07\x11\t\x12\x1b\x13(\x04\x07\x11\x0c"
    tuple_2 = (bool_2,)
    action_module_2 = ActionModule(str_2, tuple_2, tuple_2, int_2, int_2, tuple_2)
    var_2 = action_module_2.run()
    float_2 = None
   

# Generated at 2022-06-25 07:46:13.117612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o9|]*R"d"v'
    float_0 = float(0)
    str_1 = '6.^y6<jf4gMh(:aHw"+j'
    str_2 = 'j'
    tuple_0 = (str_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, tuple_0, float_0, str_1)
    int_0 = -20
    int_1 = -27
    str_3 = 'C'
    bool_0 = False
    str_4 = 'aZO^r_m0gKPf#G~M'
    long_0 = long(83)
    str_5 = 'z'
    str_6 = 'v'
    tuple_1

# Generated at 2022-06-25 07:46:18.187864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0
    action_module_0 = ActionModule(float_0, float_0, float_0, float_0, float_0, float_0)
    action_module_0.run()
    # TODO: add asserts

# Generated at 2022-06-25 07:46:19.687669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:46:30.599032
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:46:40.426158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    var_1 = action

# Generated at 2022-06-25 07:46:46.252641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x7F\xC5Y\x8E\x9D\xA2\xE3v\xE3\xD4\xA4'

# Generated at 2022-06-25 07:46:54.838946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)


# Generated at 2022-06-25 07:47:02.890062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare test variables for setUp
    bytes_2 = b'D'
    int_2 = 420
    bool_2 = True
    dict_2 = {bytes_2: bytes_2, bytes_2: int_2, bool_2: bytes_2, bool_2: int_2}
    str_2 = "iW0',wN_RM3i$rW49&1x"
    tuple_2 = (bool_2,)
    action_module_2 = ActionModule(str_2, tuple_2, tuple_2, int_2, int_2, tuple_2)

    # Run the test
    var_2 = action_module_2.run()

    # Assert the result
    assert var_2 == undefined


# Generated at 2022-06-25 07:47:08.731034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    assert action_module_

# Generated at 2022-06-25 07:47:16.222798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:47:46.081180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:47:53.935159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'do'
    int_0 = -865
    bool_0 = True
    dict_0 = {bytes_0: int_0, bytes_0: bytes_0, bool_0: int_0, bool_0: bytes_0}
    str_0 = "e5vd2.py"
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    result_0 = action_module_0.run(dict_0)
    float_0 = float(result_0)
    str_1 = str(float_0)

# Generated at 2022-06-25 07:48:02.904351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    action_module_0

# Generated at 2022-06-25 07:48:09.489782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'c'
    int_0 = 162
    bool_0 = False
    dict_0 = {bytes_0: int_0, bytes_0: bool_0, bool_0: int_0, bool_0: bool_0}
    str_0 = "D@'g]&+ybX2M4-0_[J8"
    tuple_0 = (bytes_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, dict_0, dict_0, tuple_0)
    result_0 = action_module_0.run()
    bytes_1 = b'L'
    int_1 = 161
    bool_1 = True

# Generated at 2022-06-25 07:48:10.083842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:48:17.340445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #assert is not None
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:48:25.268769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)
    action_module_1

# Generated at 2022-06-25 07:48:30.007026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0c'
    int_0 = -562
    bool_0 = False
    dict_0 = {bytes_0: int_0, bool_0: bool_0, bool_0: int_0, bool_0: bool_0}
    str_0 = "UbgB%|GQ>Z+zlY@=Bf]"
    tuple_0 = (dict_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    vars_0 = None
    action_module_0.run(vars_0)

# Generated at 2022-06-25 07:48:38.093524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)


# Generated at 2022-06-25 07:48:44.413695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:50:04.668818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)


# Generated at 2022-06-25 07:50:14.310390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:50:20.219866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # unit-test action_plugin
        return None
    except TypeError:
        print("TypeError caught in method run of class ActionModule")
        print("type(action_run) = " + str(type(action_run)))
    except Exception:
        print("Exception caught in method run of class ActionModule")
        print("type(action_run) = " + str(type(action_run)))

# Generated at 2022-06-25 07:50:30.987718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'0'
    int_0 = 123
    bool_0 = False
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "| |s^]%T-y+u3qKjr:2u"
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = False
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)


# Generated at 2022-06-25 07:50:39.907876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'D'
    int_0 = 420
    bool_0 = True
    dict_0 = {bytes_0: bytes_0, bytes_0: int_0, bool_0: bytes_0, bool_0: int_0}
    str_0 = "iW0',wN_RM3i$rW49&1x"
    tuple_0 = (bool_0, )
    action_module_0 = ActionModule(str_0, tuple_0, tuple_0, int_0, int_0, tuple_0)
    var_0 = action_run()
    float_0 = None
    str_1 = ''
    action_module_1 = ActionModule(bytes_0, int_0, int_0, dict_0, float_0, str_1)

# Generated at 2022-06-25 07:50:48.388318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'g'
    str_0 = "CJ'z^wc/o:)h]Z*rJ\"1x"
    int_0 = 463
    int_1 = -2
    list_0 = [float(), bool(), -2.90685e+307]
    tuple_0 = ("k+R;^z_&", 2.90685e+307, 30.09611)
    action_module_0 = ActionModule(str_0, bytes_0, int_0, tuple_0, list_0, int_1)
    var_0 = action_run()
    bytes_1 = b'01'
    bool_0 = False
    str_1 = "k+R;^z_&"

# Generated at 2022-06-25 07:50:51.543259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 420
    bytes_0 = b'D'
    action_module_0 = ActionModule(int_0, bytes_0, bytes_0, int_0)
    # Method run uses objects from types: bytes, tuple
    test_case_0()
    test_ActionModule_run()
    action_module_0.run(task_vars={})

# Generated at 2022-06-25 07:51:00.233612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "j.w+;<CJ}P'r3q!{9!I"
    float_0 = float("6.6e-06")
    str_1 = ''
    str_2 = "5V7~'Bm{uV7,E"
    float_1 = float("3.3e+05")
    bytes_0 = b'\x00'
    str_3 = "vk8?_|*hR~T;"
    int_0 = 224
    tuple_0 = (bytes_0, int_0, float_0, float_1)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, str_2, float_0, str_3)
    action_module_0.run()



# Generated at 2022-06-25 07:51:03.719655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule("3", ("",), ("",), 4248268025, 4248268025, ("",))
    action_module_0.run()




# Generated at 2022-06-25 07:51:09.015491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule('', (), (), 0, 0, ())
    assert test_ActionModule_run
