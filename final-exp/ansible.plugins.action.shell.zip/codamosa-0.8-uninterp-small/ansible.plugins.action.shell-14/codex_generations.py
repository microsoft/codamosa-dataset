

# Generated at 2022-06-25 07:41:43.618822
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = -2086.0
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    action_module_0 = ActionModule(float_0, float_0, bool_0, dict_0, float_0, float_0)
    result = action_module_0.run(float_0, dict_0)

    assert result is None, "Return type mismatch"

# Generated at 2022-06-25 07:41:47.393754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'bool_0': False}
    action_module_0 = ActionModule(float('-1629'), float('-1629'), False, dict_0, float('-1629'), float('-1629'))
    dict_1 = {'bool_1': False}
    action_module_0.run(dict_1, dict_1)


# Generated at 2022-06-25 07:41:51.104745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3333.0
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    action_module_0 = ActionModule(float_0, float_0, bool_0, dict_0, float_0, float_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 07:41:53.359728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(-1000.0, -968.0, -991.0, {'dict_0': -1000.0}, -999.0, -959.0)
    action_module_0.run(tmp='tmp_0', task_vars=dict())


# Generated at 2022-06-25 07:41:54.314881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert getattr(ActionModule, "run", None) is not None, "No run method found"

# Generated at 2022-06-25 07:41:57.043901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module_0 = ActionModule()

    # Invoke the run method of class ActionModule
    result = action_module_0.run()


# Generated at 2022-06-25 07:41:59.430138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    assert True


# Generated at 2022-06-25 07:42:05.943079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -841.0
    dict_0 = {}
    action_module_0 = ActionModule(float_0, float_0, float_0, dict_0, float_0, float_0)
    action_module_0.run(tmp={}, task_vars={})


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:13.860054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 204.0
    dict_0 = {'foo': float_0}
    bool_0 = False
    task_vars_0 = {'foo': float_0}
    action_module_0 = ActionModule(float_0, float_0, bool_0, dict_0, float_0, float_0)
    result = action_module_0.run(None, task_vars_0)
    assert isinstance(result, dict)
    assert 'invocation' in result
    assert result['invocation']['module_args'] == dict_0
    assert result['invocation']['module_name'] == "shell"
    assert result['invocation']['module_complex_args']['chdir'] == '$HOME'

# Generated at 2022-06-25 07:42:21.095486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1033.8
    bool_0 = True

# Generated at 2022-06-25 07:42:23.609871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:42:29.288584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_var_0 = {
    #     'task_vars': None,
    # }

    # _result_0 = None

    _object_0 = ActionModule(var_0)

#     _result_0 = _object_0.run(tmp=test_var_0['tmp'], task_vars=test_var_0['task_vars'])

    # assert _result_0 == test_var_0['result']


# Generated at 2022-06-25 07:42:31.083192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_object = ActionModule()
    assert isinstance(action_module_object.run(), dict) == True


# Generated at 2022-06-25 07:42:36.820066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = tmp=var_1
    var_3 = None
    var_4 = task_vars=var_3
    var_0.run(tmp=var_2,task_vars=var_4)

# Generated at 2022-06-25 07:42:37.545411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()


# Generated at 2022-06-25 07:42:43.686814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing the class
    action_module_0 = ActionModule()
    # Evaluating assert statements
    try:
        # Calling the run method
        action_module_0.run(tmp = None, task_vars = None)
    except Exception as exception_0:
        assert(False)


# Unit test Cases

# Generated at 2022-06-25 07:42:47.169880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()

# Generated at 2022-06-25 07:42:49.179211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare the test environment
    setup_test_env()

    # Invoke the test procedure
    ActionModule.run(var_0)


# Generated at 2022-06-25 07:42:52.641878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# Default args
    var_0 = dict()
    assert ActionModule(self._execute_module, self._execute_module_with_name, name, args, task_vars).run(tmp=var_0, task_vars=var_0) == None

# Generated at 2022-06-25 07:42:55.375236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_obj = ActionModule(var_0)
    var_obj.run(tmp, task_vars=task_vars)

# Generated at 2022-06-25 07:42:58.664054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    # Act
    # Assert
    test_case_0()

# Generated at 2022-06-25 07:43:07.608152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = '\x80\xe5Y\xd5\xda\x94\xe5\x98\xf0\xca\x8a'
    float_0 = 0.67659
    bool_0 = True
    bytes_0 = b'\x18\xf8\xfe\xf2\x1e\xb8\xcc\xa6\xef\x07\x12\x8f\xdc\x1b\x82^\xfa\xa9'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run()
    action_run()

# Generated at 2022-06-25 07:43:08.054617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:43:09.214113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test method run of class ActionModule')


# Generated at 2022-06-25 07:43:15.837154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    var_1 = action_run(tuple_0)
    var_2 = action_run(tuple_0, dict_0)

# Generated at 2022-06-25 07:43:20.182267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:43:29.104936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}

# Generated at 2022-06-25 07:43:33.111253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tuple_0 = ()
  dict_0 = {tuple_0: tuple_0}
  str_0 = 's\x0c\x0ctQOYX84M'
  float_0 = 617.3974
  bool_0 = True
  bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
  action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
  var_0 = action_run()
  return None

# Generated at 2022-06-25 07:43:39.319617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Checking input param type
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()


# Unit test cases end

# Generated at 2022-06-25 07:43:49.936088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_module_0.run()
    assert var_0 == (dict_0, dict_0, True, bool_0, bool_0)
    # Test other properties of class ActionModule

# Generated at 2022-06-25 07:43:59.952365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run()
    assert action_module_0._task.args['_uses_shell'] == True
    assert len(action_module_0._task.name) == 0

# Generated at 2022-06-25 07:44:09.670370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:18.935784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:23.803281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'kW7\x12\x12\x12\x12\x12\x12\x12'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:24.281398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_equal()

# Generated at 2022-06-25 07:44:35.221261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    assert var_0 == None, 'tests/test_action_plugin.py: failed verification'


# Generated at 2022-06-25 07:44:36.972527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test runtime exceptions
    raise RuntimeError("Error message text")

# Generated at 2022-06-25 07:44:42.163058
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # instantiate object of class ActionModule
    action_module_0 = ActionModule()

    # call function run for method run of class ActionModule
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:44:51.619034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    tuple_1 = (action_module_0, bool_0, bool_0)
    str_1 = 'T\xd7\x9d\x91\xc4\xdc\xc4'
    float_1 = 0.3312

# Generated at 2022-06-25 07:45:02.726638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing method run of class ActionModule')
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    print('Final test results')


# Generated at 2022-06-25 07:45:19.916400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    tuple_1 = ()
    dict_1 = {tuple_0: tuple_1}
    str_1 = '%x5\x19\x8e\x9a\\\x10\x05\xc3\xce\xba\x10'
    float_1 = 25.8509
    bool_1 = True

# Generated at 2022-06-25 07:45:24.416660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'L\xaf\x83\x19\x00\x00'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    result = action_module_0.run()

# Generated at 2022-06-25 07:45:34.137825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    var_0 = action_module_0.run(var_0)

# Generated at 2022-06-25 07:45:39.590935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 07:45:50.210484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    tuple_1 = ()
    dict_1 = {tuple_1: tuple_1}
    var_0 = action_module_0.run(tuple_1, dict_1)
    return var_0

# Generated at 2022-06-25 07:45:55.059111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tuple_0 = ()
  dict_0 = {tuple_0: tuple_0}
  str_0 = 's\x0c\x0ctQOYX84M'
  float_0 = 617.3974
  bool_0 = True
  bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
  action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
  var_0 = action_run()

# Generated at 2022-06-25 07:46:02.499988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = ()
    var_1 = ActionModule.run(action_module_0, var_0, var_0)
    assert isinstance(var_1, dict)

    dict_1 = dict_0

# Generated at 2022-06-25 07:46:11.000825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:16.114080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run(action_module_0)
    test_case_0()

# Generated at 2022-06-25 07:46:24.925072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    assert var_0 == var_0


# Generated at 2022-06-25 07:46:43.846608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_0 = ActionModule()
    tmp = None
    task_vars = None
    result = class_0.run(tmp, task_vars)
    assert result is not None
    assert result == 'None'



# Generated at 2022-06-25 07:46:53.782657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'x': tuple()}
    dict_1 = dict_0
    dict_0['x'] = dict_1
    dict_1['x'] = dict_0
    dict_0['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x']['x'] = dict_0

# Generated at 2022-06-25 07:47:00.216486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:05.866151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {}
    str_0 = '\x13\x01\x00\x11\x1f\x00\x18\x1c\x08\x02\x16P\x0f4\x04\x12\x1c\x1d1F\x07\x13\x0e\x15'
    float_0 = -2.6
    bool_0 = False
    bytes_0 = b'\xc4\x03\x05\x15\x1e\x1f\x08\x06\x0e\x19'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    dict_1 = {}

# Generated at 2022-06-25 07:47:16.405737
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test vars
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    task_vars = {}

    # Call method
    result = action_module_0.run(tmp=None, task_vars=task_vars)
    return result



# Generated at 2022-06-25 07:47:25.133461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    return var_0

# Generated at 2022-06-25 07:47:27.901579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except:
        print('AssertionError')

# Generated at 2022-06-25 07:47:35.549079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule('test_runner', {'test_action': 'ActionModule.test_method'}, 'test_host', 'test_run_data', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')
    module_0.test_method()
    module_1 = ActionModule('test_runner', {'test_action': 'ActionModule.test_method'}, 'test_host', 'test_run_data', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')
    module_1.test_method()

# Generated at 2022-06-25 07:47:45.076501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = '\x8e'
    float_0 = 969.25
    bool_0 = True
    bytes_0 = b'\x81\x8a\xf0\x88\xf7\x86'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    tmp = '\xf7'
    task_vars = {}
    var_0 = action_module_0.run(tmp, task_vars)
    print(var_0)


g_var = 0


# Generated at 2022-06-25 07:47:52.771908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = test_case_0()


# Generated at 2022-06-25 07:48:38.354482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    assert ((var_0 == None)), "return value of ActionModule.run is None"

# Generated at 2022-06-25 07:48:48.397771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)

# Generated at 2022-06-25 07:48:57.491601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run()



# Generated at 2022-06-25 07:49:08.589508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'SZuk5K\x0c\xe5\xe4\xcd\x12\xd5\x1f\xad\x04\x07\x9f\x19\x0e\x07'
    float_0 = 4.04984
    bool_0 = True
    bytes_0 = b'|\xee\x88\xb7\xcd\x0e\xdc!I\x9b\x95\xfa\xd7\x85\x84\xf0\xa8\x0be\x85\x9e\x80\xf0\xd7\x18\x8c\x8f\x05\x17'
    action_module_0

# Generated at 2022-06-25 07:49:14.799905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    task_vars = {}

    var_0 = action_run(action_module_0, task_vars)

# Generated at 2022-06-25 07:49:21.499105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:31.227230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = ':jfh\r2%-%'
    float_0 = 88.19945
    bool_0 = True
    bytes_0 = b'F\x89\x9d\x8a\x1e+\xcc\xf4\xc6\xdf\xdf\x9d\x9aA'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    # Task failed, no need to analyze the result
    assert('"rc": 1' in str(var_0))

# Generated at 2022-06-25 07:49:42.579619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'x2F'
    float_0 = 791.0518
    bool_0 = False

# Generated at 2022-06-25 07:49:50.835859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:56.557621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action_module_0 = ActionModule()
    result = action_module_0.run(task_vars=task_vars)
    # Test assertion for expected result 'dict'
    assert isinstance(result, dict)

# Generated at 2022-06-25 07:51:25.435603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_result = test_case_0()
    assert module_result == 0

test_ActionModule_run()

# Generated at 2022-06-25 07:51:31.147008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 's\x0c\x0ctQOYX84M'
    float_0 = 617.3974
    bool_0 = True
    bytes_0 = b'\xf4|e`\x84\x99\xd3\xe0\xf3H\x96\x8b:\x0e'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    var_0 = action_run()
    assert var_0 == tuple_0


# Generated at 2022-06-25 07:51:35.399221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    str_0 = 'P\rAvp\x7fJ\x17\x824j\x12'
    float_0 = 767.824
    bool_0 = True
    bytes_0 = b'v\xe9\x7f\x00\x95\x0e\x06\x16\x01!\xe8K'
    action_module_0 = ActionModule(tuple_0, dict_0, str_0, float_0, bool_0, bytes_0)
    action_module_0.run(task_vars = None)