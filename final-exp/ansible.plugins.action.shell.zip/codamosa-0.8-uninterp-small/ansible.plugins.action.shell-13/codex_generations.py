

# Generated at 2022-06-25 07:41:45.400483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'foo': 'BAR'}
    dict_1 = {'foo': 'BAR', 'baz': 'QUX'}
    set_0 = {dict_0, dict_1}
    dict_2 = {'foo': 'BAR', 'baz': 'QUX', 'qux': 'QUUX'}
    tuple_0 = (dict_1, dict_2)
    tuple_1 = (set_0, tuple_0)
    tuple_2 = (tuple_1, tuple_0, tuple_1)
    print(tuple_2)
    test_case_0()

# Generated at 2022-06-25 07:41:46.103148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule = ActionBase()
    ActionModule.run()

# Generated at 2022-06-25 07:41:52.297989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    localhost = {'hostname': 'localhost', 'ip': '127.0.0.1'}
    dict_0 = {'hostvars': {'localhost': localhost}}
    action_module = ActionModule(None, None, None, None, None, None, dict_0, None, None)
    result = action_module.run(None, dict_0)
    assert type(result) == dict
    assert result['changed'] == False
    assert result['warnings'] == None


# Generated at 2022-06-25 07:41:59.983519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = None
    # Test case: execution with no arguments
    # Expected result: execution is successful
    tmp = None
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    result = obj.run(tmp, task_vars)
    # Do something ...
    # Test case: execution with arguments
    # Expected result: execution is successful
    tmp = None
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    task_vars = None

# Generated at 2022-06-25 07:42:09.863549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    int_1 = 47
    int_2 = 88
    dict_0 = {int_1: int_1, int_1: int_1}
    dict_1 = {dict_0: int_1}
    dict_2 = {dict_1: int_0}
    dict_3 = {int_1: dict_1, int_0: dict_0}
    dict_4 = {dict_3: int_0}
    dict_5 = {dict_4: int_2}
    dict_6 = {int_2: dict_2, int_2: dict_3}
    dict_7 = {dict_6: int_0}
    dict_8 = {dict_7: dict_2}
    dict_9 = {dict_8: dict_4}
    dict_10

# Generated at 2022-06-25 07:42:15.932640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    int_0 = 28
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_1 = {dict_0: int_0}
    dict_2 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dict_3 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dict_4 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dict_5 = {int_0: int_0}
    dict_6 = {int_0: int_0, int_0: int_0}

# Generated at 2022-06-25 07:42:19.569933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Test function for class ActionModule

# Generated at 2022-06-25 07:42:21.367440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run()


# Generated at 2022-06-25 07:42:30.585833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 28
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_1 = {dict_0: int_0}
    dict_2 = {dict_1: int_0}
    str_0 = "test_ActionModule_run"
    int_1 = 20
    dict_3 = {int_1: int_1, int_1: dict_2}
    dict_4 = {str_0: dict_3}
    dict_5 = {dict_0: dict_4}
    dict_6 = {dict_1: dict_5}
    dict_7 = {dict_2: dict_6}
    dict_8 = {dict_3: dict_7}
    dict_9 = {dict_4: dict_8}

# Generated at 2022-06-25 07:42:35.633297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 22
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_1 = {dict_0: int_0}


# Generated at 2022-06-25 07:42:47.108282
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Parameters:
    # ansible.playbook.play_context.PlayContext
    play_context = None
    # ansible.executor.task_result.TaskResult
    task_result = None
    # ansible.vars.templar.Templar
    templar = None
    # ansible.playbook.play.Play
    play = None
    # ansible.playbook.block.Block
    block = None
    # ansible.playbook.task.Task
    task = None
    # ansible.parsing.dataloader.DataLoader
    loader = None
    # ansible.plugins.loader.ActionModuleLoader
    action_loader = None
    # ansible.plugins.loader.ActionBaseLoader
    shared_loader_obj = None
    # ansible.plugins.connection.ConnectionBase


# Generated at 2022-06-25 07:42:48.615978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:42:50.620290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run("tmp","task_vars")

# Generated at 2022-06-25 07:42:52.040006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del ActionModule.run
    del ActionModule.run


# Generated at 2022-06-25 07:42:55.879389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = null()
    task_vars_0 = null()
    assert (action_module_0.run(tmp_0, task_vars_0)) == null()

# Generated at 2022-06-25 07:42:57.156643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:43:06.336067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Load the module you want to test
    action_module_0 = ActionModule()
    # Create a mock
    class MockActionBase(object):
        def __init__(self, *args, **kwargs):
            self.__args = args
            self.__kwargs = kwargs

        def run(self, *args, **kwargs):
            self.__args += args
            self.__kwargs.update(kwargs)
            return self.__kwargs

    class Mock_shared_loader_obj(object):
        def __init__(self, *args, **kwargs):
            self.__args = args
            self.__kwargs = kwargs
            self.action_loader = MockActionBase()


# Generated at 2022-06-25 07:43:10.037502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize parameters
    tmp = None
    # Replace parameter task_vars to emulate task_vars data
    task_vars = {}

    # Initialize class ActionModule
    action_module_0 = ActionModule()

    # Call method run of class ActionModule
    result = action_module_0.run(tmp, task_vars)

    # Check result
    assert result is None

# Generated at 2022-06-25 07:43:11.415200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_ = ActionModule()
    assert action_module_.run() == None


# Generated at 2022-06-25 07:43:13.324648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert type(action_module_0.run()) is dict

# Generated at 2022-06-25 07:43:20.315567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('mainCase_actionModule_0 start')
    test_case_0()
    print('mainCase_actionModule_0 end')

if __name__ == '__main__':
    print('start main')
    test_ActionModule_run()
    print('end main')

# Generated at 2022-06-25 07:43:26.280235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(task_vars = None)
# class ActionModule:
#     def __init__(self):
#         self._shared_loader_obj = None
#         self._loader = None
#         self._templar = None
#         self._task = None
#         self._connection = None
#         self._play_context = None
#         self._loaded_frm_file = None

# Generated at 2022-06-25 07:43:27.156479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:43:30.461334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run()

# Generated at 2022-06-25 07:43:32.181367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    assert action_module_instance.run() is not None

# Generated at 2022-06-25 07:43:39.950962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    params = {}
    del params['tmp']  # noqa: F841
    assert action_module_obj.run(task_vars=params) == \
        action_module_obj._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=action_module_obj._task,
                                                               connection=action_module_obj._connection,
                                                               play_context=action_module_obj._play_context,
                                                               loader=action_module_obj._loader,
                                                               templar=action_module_obj._templar,
                                                               shared_loader_obj=action_module_obj._shared_loader_obj).run(task_vars={})

# Generated at 2022-06-25 07:43:43.901998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = None
    action_module_1.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-25 07:43:46.522949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(None, None)

    print(result)

# Generated at 2022-06-25 07:43:53.815782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create ActionModule object
    action_module_1 = ActionModule()

    # Try to run method run of ActionModule object
    try:
        result_0 = action_module_1.run()
        error_0 = False
    except Exception as exception_0:
        result_0 = exception_0
        error_0 = True
    assert error_0 == False
    assert result_0 is None

    # Try to run method run of ActionModule object
    try:
        result_1 = action_module_1.run()
        error_1 = False
    except Exception as exception_1:
        result_1 = exception_1
        error_1 = True
    assert error_1 == False
    assert result_1 is None


# Generated at 2022-06-25 07:43:54.761871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 07:44:03.137551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()

test_ActionModule_run()

# Generated at 2022-06-25 07:44:08.282157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(None, None, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:44:13.553672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-25 07:44:18.929192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1AlAP.'
    str_1 = 'y2'
    bool_0 = False
    dict_0 = {}
    str_2 = '1AlAP.'
    set_0 = {str_2}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_1, set_0)
    var_0 = action_run()
    # assert var_0 == expected_result

# Generated at 2022-06-25 07:44:24.027193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}

# Generated at 2022-06-25 07:44:26.562158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert None == action_module_0.run()


# Generated at 2022-06-25 07:44:34.555001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'v.FJ!W'
    str_1 = 'c%v'
    str_2 = 't'
    set_0 = {str_2}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_0, set_0)
    var_0 = None
    var_1 = action_module_0.run(var_0)
    assert len(var_1) == 3
    assert var_1 == {}



# Generated at 2022-06-25 07:44:36.884293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Not implemented
    pass

test_case_0()

# Generated at 2022-06-25 07:44:43.954087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '1lh1Y'
    str_1 = '{;->~'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:49.207789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = false
    dict_0 = {}
    str_0 = '3g'
    str_1 = 'e!E'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    action_module_0.run()
    var_0 = action_run()


# Generated at 2022-06-25 07:45:02.973537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # self.run(self, tmp=None, task_vars=None) → result
    # Executes the command and returns the result.
    # This method uses the `_uses_shell` attribute provided by the ShellModule action plugin to delegate processing to the Command action plugin.
    # @param task_vars: variables from task.
    # @returns result: Execution results.
    # @template: ansible.legacy.shell.exit_json.j2
    assert True


# Generated at 2022-06-25 07:45:06.874144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert true

# Generated at 2022-06-25 07:45:07.401419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:45:11.704793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'shell'
    str_1 = '-m'
    str_2 = 'command'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_2, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:45:18.580140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = 'FJ9'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:45:25.302927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'pkN'
    str_1 = 'y2'
    str_2 = '1AlAP.'
    set_0 = {str_2}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == 0

# Generated at 2022-06-25 07:45:32.275336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '$Pt@'
    str_1 = '&e-Y'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:35.087318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_str_0 = '`;7}SD8qB^V7'
    action_module_obj_0 = ActionModule()
    var_0 = action_module_obj_0.run(task_vars_str_0)

# Generated at 2022-06-25 07:45:38.912134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    action_module_0.run(dict_0, dict_0)



# Generated at 2022-06-25 07:45:49.234213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {}
    str_0 = 'n2'
    str_1 = 'h'
    str_2 = 'l[|'
    set_0 = ({str_1, str_1, str_1}, str_2)
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    action_module_0.run()
    action_run()
    action_module_1 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    action_module_1.run()
    action_run()

# Generated at 2022-06-25 07:46:07.823575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    assert True

# Generated at 2022-06-25 07:46:12.052164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:46:20.189658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task that does not use shell module
    task_without_shell = {'action': {'module': 'command', 'args': {'_uses_shell': False, '_raw_params': 'command'}}}
    task_without_shell_result = ActionModule(task=task_without_shell, connection='connection', play_context='context', templar='templar', shared_loader_obj='loader').run()
    assert task_without_shell_result == {'msg': 'non-zero return code', 'rc': 1, 'stdout': '', 'stderr': ''}

    # Task that uses shell module
    task_with_shell = {'action': {'module': 'command', 'args': {'_uses_shell': True, '_raw_params': 'command'}}}
    task_with_shell_result = Action

# Generated at 2022-06-25 07:46:25.881874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'q'
    str_1 = 'Cf~'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:27.018111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:46:28.678596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:29.210265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:46:31.298521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    action_run()


if __name__ == '__main__':
    print(test_ActionModule_run())

# Generated at 2022-06-25 07:46:40.120778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_2 = False
    dict_2 = {}
    str_5 = 'y2'
    str_6 = '1AlAP.'
    set_2 = {str_6}
    action_module_2 = ActionModule(bool_2, dict_2, str_5, str_5, str_5, set_2)
    cmd = '/etc/ansible/ansible-cmdb /etc/ansible/host_vars /etc/ansible/hosts'
    var_2 = action_module_2.run(cmd)
    assert var_2 is not None


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:46:44.528590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '<'
    str_1 = 'Q0s'
    set_0 = {str_0}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    action_module_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:47:25.012011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {}
    set_0 = {'8'}
    str_0 = 'CRE'
    str_1 = 'zR'
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    str_2 = action_action_loader_get()
    action_module_0.run(str_1, str_2)


# Generated at 2022-06-25 07:47:31.486493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'s'}
    str_0 = '1AlAP.'
    str_1 = 'y2'
    bool_0 = False
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, dict_0, str_1, str_1, str_0, set_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:47:33.511752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = 'Dr.'
    str_1 = ':'
    set_0 = {str_1}
    action_module_0 = ActionModule(True, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:47:36.368935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '9V'
    str_1 = '7n'
    str_2 = './'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_2, set_0)
    var_0 = action_module_run()
    assert var_0 == None, 'Expected None but got ' + type(var_0).__name__


# Generated at 2022-06-25 07:47:36.905899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:47:40.531132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method_run_0 = run(var_0)

# Generated at 2022-06-25 07:47:41.376893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # empty test method
    return


# Generated at 2022-06-25 07:47:48.627504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:47:50.762573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()



# Generated at 2022-06-25 07:47:58.657293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '9X_'
    str_1 = 'YkI'
    str_2 = '4w%c'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_2, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:49:20.213236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = str()
    set_0 = set()
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_1, set_0)
    action_module_0.run()
    action_module_0.run(str_0)
    action_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 07:49:25.806941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'r1': -10, 'r2': -20, 'r3': -30}
    action_module_0 = ActionModule({})
    action_module_0.run(dict_0)


# Generated at 2022-06-25 07:49:31.795715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {}
    str_0 = 'V'
    str_1 = 'hM'
    set_0 = {str_0, str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_1, str_0, set_0)
    dict_0 = {str_1: str_0}
    var_0 = action_module_0.run(dict_0)
    assert 'changed' in var_0
    assert var_0['changed'] == False

# Generated at 2022-06-25 07:49:41.507171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '1AlAP.'
    str_1 = 'y2'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:49:51.446176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assign
    str_0 = 'N'
    str_1 = 'gZ'
    action_module_0 = ActionModule(str_0, str_0, str_1, str_0, str_0, str_1)
    str_2 = '_'
    str_3 = '9'
    list_0 = [str_2, str_2, str_0]
    str_4 = '3'
    str_5 = 'xO$D'
    list_1 = [str_4, str_5, str_5, str_5]
    list_2 = [list_0, list_1]
    str_6 = 'U'
    str_7 = '}'
    tuple_0 = (str_6, str_7, str_1, str_5)
    list_

# Generated at 2022-06-25 07:49:58.310836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'y2'
    str_1 = '1AlAP.'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:50:02.476929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = '2'
    str_1 = 'y2'
    set_0 = {str_1}
    action_module_3 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:50:05.313301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run()

# Generated at 2022-06-25 07:50:11.409922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case to check if given two positive integers, the method returns their sum
    assert sum([1,2]) == 3, "Should be 3"
    # Test case to check if given two positive integers, the method returns their sum
    assert sum([-1,-2]) == -3, "Should be -3"
    # Test case to check if given two positive integers, the method returns their sum
    assert sum([-1,2]) == 1, "Should be 1"

# Generated at 2022-06-25 07:50:15.869728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {}
    str_0 = 'EbY1'
    str_1 = 'x_!k$'
    set_0 = {str_1}
    action_module_0 = ActionModule(bool_0, dict_0, str_0, str_0, str_0, set_0)

    assert action_module_0.run() is None, 'Expected None, but got: %s' % action_module_0.run()

