

# Generated at 2022-06-25 07:41:41.346296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    result = ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 07:41:50.376719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x7fB\xe0\xa7\x8d\xd1\xa6\x89\xe7\x8b\x9a\x9d\x8e\x82\xa6\xaf\xea\x8a\x8c\x99\x88\x8a\x8e\xdc'
    int_0 = 84
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 07:41:56.218451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None # external parameter, type: str
  task_vars = None # external parameter, type: NoneType
  actionmodule_instance = ActionModule()
  actionmodule_instance.run(tmp, task_vars)
 

# Generated at 2022-06-25 07:42:06.444585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We'll use a mock class to generate the returns as
    # we need it to return different things for different
    # invocations.
    class ActionModuleResult:
        def __init__(self, count):
            self.count = count

        def get(self, count):
            if not self.count:
                return "test"
            return "test"

    str_0 = 'run handlers even if a task fails'
    list_0 = [str_0]
    bool_0 = True
    float_0 = 0.0001
    dict_0 = None
    dict_1 = {str_0: list_0, str_0: float_0, list_0: bool_0, bool_0: dict_0}
    obj = ActionModuleResult()

    action = ActionModule()

# Generated at 2022-06-25 07:42:12.922765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    formatter_0 = '{0}'
    formatter_1 = '{0}'
    formatter_2 = '{0}'
    formatter_3 = '{0}'
    formatter_4 = '{0}'
    formatter_5 = '{0}'
    formatter_6 = '{0}'
    formatter_7 = '{0}'
    formatter_8 = '{0}'
    formatter_9 = '{0}'
    formatter_10 = '{0}'
    formatter_11 = '{0}'
    formatter_12 = '{0}'
    formatter_13 = '{0}'
    formatter_14 = '{0}'
    formatter_15 = '{0}'

# Generated at 2022-06-25 07:42:15.947208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Expected values
    expected_result = 'expected'
    expected_exc = None

    # Unit test setup
    tmp, task_vars = 'tmp', 'task_vars'

    # Mock object
    ansible_module_mock = ActionModuleMock(expected_result, expected_exc)

    # Assertions
    assert ansible_module_mock.run(tmp, task_vars) == expected_result


# Generated at 2022-06-25 07:42:26.576191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'run handlers even if a task fails'
    list_0 = [str_0]
    float_0 = 0.0001
    dict_0 = None
    dict_1 = {str_0: list_0, str_0: float_0, list_0: dict_0}
    int_0 = 0
    int_1 = 1

##############################################################################
# Boilerplate code necessary for running unit tests
#
# If you want to change anything below, you should know what you're doing.
#
# DO NOT remove or comment-out the following code, or the test will not run.
#
# To run unit tests:
# - Install Python 2.7
# - Install nose (python setup.py install)
# - Run unit tests with command "nosetests test_module_name.py"
#
################################

# Generated at 2022-06-25 07:42:30.516345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)


# Generated at 2022-06-25 07:42:31.409868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = {}
    arg_1 = {}
    assert ActionModule.run(arg_0, arg_1) == None

# Generated at 2022-06-25 07:42:41.070707
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:42:48.706625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # __init__ of class ActionModule
    action_module_0 = ActionModule()
    var_0 = action_run(action_module_0, action_module_0)
    assert var_0 is None

# Generated at 2022-06-25 07:42:51.997726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run(action_module_0, action_module_0)
    var_1 = action_module_0.run(tmp=var_0)

# Generated at 2022-06-25 07:42:52.542368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:42:55.330071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run(action_module_0, action_module_0)

# Generated at 2022-06-25 07:43:04.441271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = {}
    action_module_0._task.args = {}
    action_module_0._task.args['_uses_shell'] = bool_0
    action_module_0._play_context = ansible.playbook.play_context.PlayContext()
    action_module_0._play_context.remote_addr = string_0
    action_module_0._templar = ansible.template.template.Templar()
    ansible.template.template.Templar.set_available_variables = set_available_variables(action_module_0._templar)
    action_module_0._task.action = string_0
    action_module_0._connection = ansible.plugins.connection.local.Connection()
    action_

# Generated at 2022-06-25 07:43:07.488486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = 'tmp'
    var_0 = action_run(action_module_0, action_module_0, task_vars=task_vars_0)


# Generated at 2022-06-25 07:43:10.071027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action_module_1 = ActionModule()
    var_1 = action_module_1.run(tmp, task_vars)
    print(var_1)

# Generated at 2022-06-25 07:43:12.509229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run(action_module_0, action_module_0)
    assert var_0 == None

# Generated at 2022-06-25 07:43:13.365405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:43:14.371698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:43:24.018174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '%\x1f#t\x0b\x16[\x1f\x0f\x16\x1a\x12\x11\x1d,\x00\x1b\x16\x1a\x1c\x10\x11'
    int_0 = 1
    bytes_0 = b'\x88\x9f\x9f\xfa\xe8\x96\xbb\xfa\xe8\x96\xbb\xfa\xe8\x96\xbb\xfa\xe8\x96\xbb'
    int_1 = 21

# Generated at 2022-06-25 07:43:31.069498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:43:39.412528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|',)
    int_0 = 281
    int_1 = 1785
    bytes_0 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    bytes_1 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    action_module_0 = ActionModule(int_0, int_1, bytes_0, tuple_0, False, tuple_0)
    action_module

# Generated at 2022-06-25 07:43:50.304903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2327
    bytes_0 = b'\x8b\xce\xeb\x9b)\x8c\x80\x04\x01)\xfe\x00\x999\xe7\x1c\x11\x8d'
    int_1 = 1221
    bytes_1 = b'\x9f\x9d\x9b\x18$\x8f\xba\x95$\x8c\xc5\xfe\x9e\xf9\xfb\xdb'
    tuple_0 = (bytes_1,)
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_1, bytes_0, bytes_1, tuple_0, bool_0)
    str_0 = '0-L'
   

# Generated at 2022-06-25 07:44:00.494225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = 986
    str_1 = '\xbe\xa6\x0f\x8f\x0b\x16\xcc\xb5\x1c\x17\x0b\xe4\xf8\xab\x91\xdd'
    int_3 = 1072
    int_4 = 29
    bool_2 = False
    tuple_1 = (str_1,)
    action_module_2 = ActionModule(int_4, int_2, int_3, tuple_1, bool_2, tuple_1)
    tmp = None
    task_vars = None
    var_1 = action_module_2.run(tmp, task_vars)

# Generated at 2022-06-25 07:44:05.080391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    atm = ActionModule()
    assert(atm.run())

# Generated at 2022-06-25 07:44:11.775565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 412
    bytes_0 = b'n\xa2\xf8\x88\x17\x0c\x95\x9b\x0c\xbf\xea\x06\xf6\xe6\x94'
    tuple_0 = (None,)
    str_0 = 'T\xa0\x12\xb8\x01\xb3\xa3\x83\xe9\xef\xd3\x0e\x0c\x8c\x1b'
    tuple_1 = (str_0,)
    action_module_0 = ActionModule(int_0, bytes_0, tuple_1, tuple_0, tuple_0, tuple_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:44:20.542291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (b'\xd2\xcf\x99u.\xee\x14\x97\x1c\x9e\x8a\xbc\x19\xa3\xac\x8d\x1c\x98\x97K\xdd')
    bool_0 = False
    str_0 = 'KFE'
    int_0 = 1747
    bytes_0 = b'\xa7\x93\xf6\x0f\xab\x04\x93\xc6f\x9f\xf9\x1f\xb4\xc6'
    int_1 = 1843
    action_module_0 = ActionModule(int_0, int_1, bytes_0, tuple_0, bool_0, str_0)
    var_0 = action_

# Generated at 2022-06-25 07:44:21.461359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:44:30.893419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 846
    bytes_0 = b'e\x00\xe4\x00\x8f\xb9\xa7\x00\x96\x00\x93\x00\xbf\x00\xb7\x00\x9d\x00\xb4\x00\xb4\x00\xb6\x00\xb4\x00\xa0\x00\xbb\x00\x8c\x00\xb7\x00\xa0\x00\xa9\x00\x97\x00\xa8\x00\xab\x00\x9c\x00'
    int_1 = 919

# Generated at 2022-06-25 07:44:42.127253
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:44:51.618538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1839
    bytes_0 = b'\xb6\xac\x8e\xb0\x82P\xba\xb7\x0f\xda\xf5\xf9+\x99\x00u'
    int_1 = 869
    bytes_1 = b'\xc40\x9f9\x8e\x18\xf3\x02\xd3\x8cI\xdf\x0e'
    tuple_0 = (bytes_1,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_0, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = ';0+M6$F>*D'

# Generated at 2022-06-25 07:45:03.484981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1077
    bytes_0 = b'\xd7\x8b\xd9\x0e\xde\xd4\xe4\xb4L\xa4\x84u\x8a\xb9\xab\xb1\x00'
    int_1 = 1355
    bytes_1 = b'\x8e\x92\x15\xcc\xbe\x8b"\xac\xe6\xe1\x8f\x9a\xab\x15\x96\x83'
    tuple_0 = (bytes_1,)
    bool_0 = True
    action_module_0 = ActionModule(int_1, int_0, bytes_0, tuple_0, bool_0, tuple_0)
    bool_1 = True

# Generated at 2022-06-25 07:45:11.743572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:45:17.980453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8235
    bytes_0 = b'\x16\xfd\xfc\xdf3\xd6\xef\xb4\x9e\xed\xe6\xef\x14\xcf\x1e'
    int_1 = 1706
    bytes_1 = b'?\xe00\xec\xcf\x80\x8a\xaaM\xfb\x9c\x1a\x94[c\xd1'
    tuple_0 = (bytes_0,)
    bool_0 = True
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = True

# Generated at 2022-06-25 07:45:22.494440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    bool_0 = False
    int_0 = ActionModule.run(action_module_0, bool_0)


# Generated at 2022-06-25 07:45:30.254815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('unit test: ActionModule.run()')
    import random
    import sys
    from time import time
    from datetime import datetime, timedelta
    from ansible.utils.color import stringc
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.unicode import to_unicode

    # simple test of the run() method
    #params = {"host":"localhost", "arguments":"-h"}
    #module = ActionModule(1, 1, "", "", "", "", params, "module")
    #print('module.run(): %s' % module.run())

    # execute method
    reference_module = ActionModule(1,1,b'a',(),False,())


# Generated at 2022-06-25 07:45:32.139865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 437
    action_module_0 = ActionModule(int_0)
    var_0 = action_module_0.run()
    assert var_0 is None, var_0

# Generated at 2022-06-25 07:45:39.630563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:45:42.012082
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Call method run of class ActionModule
    test_case_0()

# Generated at 2022-06-25 07:45:55.435638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1876
    bytes_0 = b'\xa6\xbf\x88\xfa\x90\xa1\x9f\x15\x13\xbe\xda\xabP\xf8\xf3\x1f\x9e'
    int_1 = 3797
    bytes_1 = b'\x8c\x86\x80\x87\xd4e\x8e\x02\xe4\x87\x8a\xe4\xdc\x82\x9a\x8c'
    tuple_0 = (int_1,)
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, bytes_1, tuple_0, int_1, int_1, bytes_0)
    bool_1 = False
    str

# Generated at 2022-06-25 07:45:55.946720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	test_case_0()

# Generated at 2022-06-25 07:46:03.151105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:46:05.518407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785

# Generated at 2022-06-25 07:46:12.063135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 15
    bytes_1 = b'\x0b\x03\xd2\xea\xf0\x94\x8b\x86\xb1\x00\x8c\xdd\x17'
    int_0 = 13
    bytes_0 = b'\x0au\x1dc\x8a\xce#\x87\x85\x04\xf8\x9e\xf7\x11\x91\x8d'
    tuple_0 = (bytes_1,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_0, tuple_0, bool_0, tuple_0)
    bool_1 = True

# Generated at 2022-06-25 07:46:20.187035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False

# Generated at 2022-06-25 07:46:22.492126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test: no exception raised
    test_case_0()
    pass

# Generated at 2022-06-25 07:46:23.513350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  test_case_0()

# Generated at 2022-06-25 07:46:32.845949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:46:38.940719
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:00.091218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# The file tests/runner.py contains a runner script which will call test_ActionModule_run() as unit test
# if we're running as a main script or as a unit test
if __name__ == '__main__':
    # Check ansible imports before anything else
    try:
        import ansible
    except ImportError:
        print('failed=True msg="pytest-ansiblelint requires Ansible to be installed on the path"')
        sys.exit(1)
    test_ActionModule_run()

# Generated at 2022-06-25 07:47:05.713287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:47:16.243041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:47:19.602972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 07:47:23.180332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 0
    str_0 = 'qJ!n\xfd\x00\xff\xf2\x1f\x00\x0c\x8f\xd4\x7f\xff\xff\xff'
    int_2 = 0
    action_module_0 = ActionModule(int_1, int_2, str_0, int_1, int_2, int_2)
    test_case_0()

# Generated at 2022-06-25 07:47:23.865845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:47:34.629312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8772
    bytes_0 = b'D\x9e\x7f\xa3\x0e\x95\xa1\x0bx\x06\xb9\x9a%\xd2\x92\x82\x1f\xef\x1f\x19\x94\xcb'
    int_1 = 1775
    bytes_1 = b'\x8bx\x1e|s.\xca\x02\xa2\xf2\\\x1a\xef\xff)\x84\x94'
    tuple_0 = (bytes_0,)
    tuple_1 = (bytes_1,)
    action_module_0 = ActionModule(int_0, tuple_1, bytes_1, tuple_0, int_0, tuple_1)
   

# Generated at 2022-06-25 07:47:45.162664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|',)
    bool_0 = False
    action_module_0 = ActionModule(281, 1785, b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8', tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'

# Generated at 2022-06-25 07:47:53.591370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:48:02.883916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule:
        def __init__(self, int_0, bytes_0, action_module_0, bool_1, str_0, int_1):
            self._action_module = action_module_0
            self._bool_1 = bool_1
            self._bytes_0 = bytes_0
            self._int_0 = int_0
            self._int_1 = int_1
            self._str_0 = str_0

        # Execution logic for method run of class ActionModule
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect
            return self._action_module.run(task_vars=task_vars)
    int_0 = 1785

# Generated at 2022-06-25 07:48:44.677566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:48:54.119613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1216
    bytes_0 = b'\x17\xf8\xeb!\x89\x94M\x9a\xfc\x0fZ\x7f\x10\xc8\xbb\x80'
    int_1 = 381
    bytes_1 = b'\x1b\xba\xc7\xf2\xab\xe3\x19\x8c\xb1.\x91\x97\xa3\xd7\x81'
    tuple_0 = (bytes_1,)
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, int_1, tuple_0, tuple_0, bool_0)
    bool_1 = False
    str_0 = '<)iQ'
    action_

# Generated at 2022-06-25 07:48:56.678640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    map_0 = {}
    action_module_0 = ActionModule(map_0)
    action_module_0.run()

test_case_0()

# Generated at 2022-06-25 07:49:08.589283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:49:16.463190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:49:17.583637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    test_case_0()


# Generated at 2022-06-25 07:49:22.845920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 5
    var_1 = ']x=!_<'
    var_2 = 0
    var_3 = 'T%r-r'
    var_4 = 'x=!_<'
    var_6 = 'z$B\'~1'
    var_7 = 23
    var_8 = '\'y\x1b['
    var_9 = 23
    var_10 = ']x=!_<'
    var_11 = '!_<'
    var_12 = 'T;r-r'
    var_13 = '#\x1bB'
    var_14 = 'z=!_<'
    var_15 = '\x1bB'
    var_16 = 0
    var_17 = 'y\x1b['

# Generated at 2022-06-25 07:49:31.775748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 115
    bytes_0 = b'b\x1b\x04\x88\xbfm\x938\xc6\x0f\x89\xf7\x95\x04'
    int_1 = 1033
    bytes_1 = b'\xfc;\x89\xe6=\x90\x1c"\x9b\xa9\x96\x8c\x10U6'
    tuple_0 = (bytes_1, bytes_0)
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, int_0, tuple_0, bool_0, tuple_0)
    bool_1 = False

# Generated at 2022-06-25 07:49:36.983401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True
    assert test_case_0() == None

# Generated at 2022-06-25 07:49:45.617757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1785
    bytes_0 = b'\xed{\x908\xa0%\x00)\x03#\xa2\x81\x07\xca\xd9\xe9Y|'
    int_1 = 281
    bytes_1 = b'\xfd\xca\xaa$\xae\x97-)\xfd\xb3\x03\xa6\xeb\x1f)\xd4\xb8'
    tuple_0 = (bytes_0,)
    bool_0 = False
    action_module_0 = ActionModule(int_1, int_0, bytes_1, tuple_0, bool_0, tuple_0)
    bool_1 = False
    str_0 = '`7]wU:;,HGE'
    action_module_1 = Action

# Generated at 2022-06-25 07:51:06.161790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for basic functionality of method run of class ActionModule
    test_case_0()


# Generated at 2022-06-25 07:51:10.459250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except:
        return False


# Entry point for unit tests
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:51:17.354570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_0 = test_case_0()
    assert_1 = b'\xae\x82\x06\x1d\xed\x11\x1b\x99\xc6\xac\x8a\x0f\x1d\xdc\xf8\x8b'
    assert assert_0['stdout'] == assert_1

if __name__ == '__main__':
    pytest.main(["--capture=sys", '-s', 'test_ActionModule.py'])

# Generated at 2022-06-25 07:51:26.545300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1369
    bytes_0 = b'\x8f\xcd\x91\x9a\x1b\xf6\x18I\xc4\x1d\x8b\xe4\x9a\xd0\x9e\x1b'
    int_1 = 740
    bytes_1 = b'\x9d\x89\xe2\x8a\x1c\x81\xeb\xca\xb5\xdf\x8a\x05\x9a\xb2\x9a\xa4\x0f\xde\xe4\x8e\x0f\x15'
    tuple_0 = (bytes_1,)
    bool_0 = False

# Generated at 2022-06-25 07:51:32.083681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 is None


# Generated at 2022-06-25 07:51:38.653487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (1, 2, 3)
    bytes_0 = b'\xcc\x15\x85\xf8\xed\xd1\xec\xc1\x8c\xb4\xcb\xb9\xfc\x0f\xbf\xd3\xc0\xe3\xeb\xe5'
    int_0 = 1500
    int_1 = 485
    action_module_0 = ActionModule()
    action_module_0.run(tmp=tuple_0, task_vars=action_module_0)