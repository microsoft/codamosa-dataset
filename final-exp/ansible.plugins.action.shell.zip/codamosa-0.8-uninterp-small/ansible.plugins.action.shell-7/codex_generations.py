

# Generated at 2022-06-25 07:41:42.815630
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:41:50.833716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'queue'
    bool_0 = True
    bytes_0 = b'\xd4\x07;\xa4\xc5\x1d\xfc\xc8D\xbb\x00\t\x9a'
    str_1 = '_aQ\x84\x97\xc8\xbc\xe2\x9b\x10\xb1\xc7\xa0T\x86\x14\x99\x0f\xf1\x9d@\x8d\x9a\x04\xb7d\x8b\x1c'

# Generated at 2022-06-25 07:41:55.734473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    ActionModule.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:42:06.305867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0\x13\xa9Y\x88\x98\x95\xad\xf3'
    bool_0 = True

# Generated at 2022-06-25 07:42:12.333438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tempdir'
    str_1 = 'ansible'
    str_2 = '8\x9eb\x1f\x96}\xe8\xd2H\x1f\x17'
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    int_0 = 6
    action_module_0 = ActionModule(str_0, str_1, str_2, bytes_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:42:17.439022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\x93\xf1\x1e\x1c\x97\xd3(J\x86D\xf0\xece\x9c`'
    dict_0 = {bool_0: bytes_0, str_0: str_0, str_0: bytes_0, str_0: bytes_0, bytes_0: str_0}
    int_1 = 0
    str_1 = ''
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, int_1)
    int_0 = 0
    task_vars = {}
    result = action_module_0.run(int_0, task_vars)

# Generated at 2022-06-25 07:42:26.259801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bool_0, str_0: bool_0, bool_0: bytes_0, str_0: bool_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    result = action_module_0.run()
    print(result)

# Generated at 2022-06-25 07:42:34.500978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'become'
    bool_1 = True
    bytes_1 = b'm\x1c\x9e\x9b\xf3\x03\xbe\x1a\x00\xb3'
    dict_1 = {str_1: bytes_1, str_1: str_1, bytes_1: bytes_1, str_1: str_1}
    int_1 = -13
    action_module_1 = ActionModule(str_1, bool_1, str_1, bytes_1, dict_1, int_1)

    dict_2 = {}
    bytes_2 = b'\x0f\xd0\x94\x18\x13\xe2\xc7]\xdc\xab\xcc'
    dict_2["tmp"] = bytes_2


# Generated at 2022-06-25 07:42:39.434802
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:42:46.334180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bool_0, str_0: bool_0, bool_0: bytes_0, str_0: bool_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run((None), None)

# Generated at 2022-06-25 07:42:52.040348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = None
    param_1 = None
    test_0 = ActionModule(param_0, param_1)
    # Execute method run of class ActionModule
    test_0.run(param_0, param_1)

# Generated at 2022-06-25 07:42:58.888785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a Test ActionModule to use the ActionBase methods
    am=ActionModule()
    # Test ActionModule.run
    str_1 = '\nj{Lq\x1c\x10\x92\xd7\x99\x07\xd6h\xf9D\x01\x10\x05\x81\x00\x00\x0f\x01\x02'
    var_1 = am.run(tmp=str_1)
    assert var_1 == None


# Generated at 2022-06-25 07:43:08.291347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '0\x13©Y\x88\x98\x95\xadó'
    var_1 = '0\x13©Y\x88\x98\x95\xadó'
    var_2 = '0\x13©Y\x88\x98\x95\xadó'
    var_3 = '0\x13©Y\x88\x98\x95\xadó'
    var_4 = '0\x13©Y\x88\x98\x95\xadó'
    var_5 = '0\x13©Y\x88\x98\x95\xadó'
    var_6 = '0\x13©Y\x88\x98\x95\xadó'

# Generated at 2022-06-25 07:43:11.336886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test if an expected exception is raised by the method
    # See http://docs.python.org/library/exceptions.html#exceptions.AssertionError for more details

    assert True == True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:43:20.616651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip
    ApplicationException = None
    AnsibleAction = None
    AnsibleActionModule = None
    AnsibleActionWarnings = None
    AnsibleConnection = None
    AnsibleConnectionFailure = None
    AnsibleError = None
    AnsibleFile = None
    AnsibleFileNotFound = None
    AnsibleFileSkip = None
    Action = None
    Connection = None
    Module = None
    Task = None

# Generated at 2022-06-25 07:43:29.358935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    vard = {'action': 'ansible.legacy.debug'}
    var_0 = None
    vard = {'action': 'shell'}

# Generated at 2022-06-25 07:43:31.566496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == '0\x13©Y\x88\x98\x95\xadó'

# Generated at 2022-06-25 07:43:35.769801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_1 = ActionModule(None, None, None, None, None, None)
    var_2 = obj_1.run(None, None)


# Generated at 2022-06-25 07:43:44.914985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'B6\x9d'
    int_0 = -858976245
    str_0 = '=\x88\x9d¹\x1d'
    str_1 = '\x04\x92\x80\xa3\x8f\x11\x9e\xc0\x8b\xac\x15×¢'
    str_2 = '\x16\x0b>\xa5\xb8'
    dict_0 = {str_2: str_0, str_1: var_0}
    int_1 = -1548335981
    list_0 = [dict_0, int_1, int_0]
    var_1 = {str_0: list_0}
    actionmodule_0 = ActionModule()

# Generated at 2022-06-25 07:43:46.021987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:43:53.938822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'become'
  bool_0 = True
  bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
  dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
  int_0 = -714
  action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
  # case 0
  result = action_module_0.run()


# Generated at 2022-06-25 07:43:54.798607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test_case_0()
    pass

# Generated at 2022-06-25 07:43:57.418546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    action_module_0 = ActionModule(str_0)
    var_0 = action_run()
    assert var_0 == (False, {}, dict)


# Generated at 2022-06-25 07:44:03.535477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '6C#\xdd\xaa\xeb\xef:\xf2\xca\xd5\xfb\x8d\xa9\x87'
    bool_0 = True
    str_1 = 'become'
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:09.442863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'become'
    bool_1 = True
    bytes_1 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_1 = {bool_1: bytes_1, bool_1: bytes_1, bytes_1: bool_1}
    int_1 = -714
    action_module_1 = ActionModule(str_1, bool_1, str_1, bytes_1, dict_1, int_1)

    var_1 = action_run()

# Generated at 2022-06-25 07:44:19.502820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_module_0.run(str_0)
    assert var_0 is not None
    assert type(var_0) == action_run


# Generated at 2022-06-25 07:44:24.900694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bytes_0: bool_0, bytes_0: bytes_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run(tmp=bool_0, task_vars=dict_0)
    if action_module_0.run(tmp=bool_0, task_vars=dict_0) != None:
        pass

# Generated at 2022-06-25 07:44:34.313592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    task_vars_0 = {}
    action_module_0.run()


# Generated at 2022-06-25 07:44:41.122184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'i5\xd1\xc5\x06\x9d\xeb\xcc\x10\x87\xb7\xcdB'
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0, bytes_0: int_1}
    int_0 = -813
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:44:49.468253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # rstrip
        str_0 = "a_string_with_newline\n"
        if str_0.rstrip("\n"):
            pass
        # Regex
        str_2 = "12344556"
        str_1 = r"\d+"
        obj_0 = re.search(str_1, str_2)
        if obj_0:
            pass
        # round
        num_0 = 5.0
        num_1 = round(num_0)
    except Exception:
        raise



# Generated at 2022-06-25 07:45:02.356523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x10'
    bool_0 = False
    str_1 = '\x0e'
    bytes_0 = b'\xce\x8d\xbd\xbd\xbe\x0b\x0c\x1e\xfa\x14\x0d\xa8\x82\xec\x1d;\xd4\xf6\xb4P'
    int_0 = -534
    dict_0 = {bytes_0: str_0, str_0: str_0}
    int_1 = -214
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, int_1, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:45:10.829687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become_user'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    tmp_0 = '/tmp/'
    task_vars_0 = {str_0: bytes_0, 'inventory_hostname': bytes_0}
    test_case_0(action_module_0.run, tmp_0, task_vars_0)

# Generated at 2022-06-25 07:45:14.349009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # TODO: mock tmp and task_vars
  # print('TODO: mock tmp and task_vars')
  action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
  var_0 = action_module_0.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-25 07:45:21.667337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    str_1 = 'become'
    bool_1 = True
    bytes_1 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'

# Generated at 2022-06-25 07:45:25.573965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:45:34.329311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)

    try:
        ret_0 = action_module_0.run()
    except:
        var_0 = True
    else:
        var_0 = False
    assert var_0


# Generated at 2022-06-25 07:45:40.485182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yK)>\xec\x08\x19\xf6'
    bool_0 = True
    str_1 = 'host'
    bytes_0 = b'A\xdb\x13\xd0\x9d\x9c\x87\xdd'
    dict_0 = {bool_0: bytes_0, bool_0: str_1, str_0: bool_0, str_1: str_0}
    int_0 = -6141
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, int_0)
    int_1 = 4
    action_module_0.run(int_1)


# Generated at 2022-06-25 07:45:48.195808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the current value of the variable 'tmp'
    tmp = tmp
    # Create a new instance of class 'ActionModule' with parameter 'tmp'
    action_module_0 = ActionModule(tmp)
    # Run method 'run' of class 'ActionModule'
    var_0 = action_module_0.run()
    # Assert the type of the return value from 'run' of class 'ActionModule'
    assert type(var_0) == type(tmp)

# Generated at 2022-06-25 07:45:50.735718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:45:55.130581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:46:10.942008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    task_vars_0 = {bytes_0: str_0, bytes_0: bytes_0, str_0: str_0, str_0: str_0, bytes_0: int_0, bytes_0: bytes_0, str_0: str_0}
    var_0 = action_module

# Generated at 2022-06-25 07:46:16.822483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_5 = 'become'
    bool_5 = True
    str_6 = 'become'
    bytes_5 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_4 = {bool_5: bytes_5, bool_5: bytes_5, bytes_5: bool_5}
    int_5 = -714
    action_module_11 = ActionModule(str_5, bool_5, str_6, bytes_5, dict_4, int_5)
    str_4 = '<ansible.plugins.action.ActionModule object at 0x7ffa1e853c90>'
    action_module_11.__str__()

# Generated at 2022-06-25 07:46:17.846316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 07:46:27.132377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    str_0 = 'deep'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run(tmp, task_vars)
    pass

# Generated at 2022-06-25 07:46:35.289250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' become '
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    str_1 = 'elasticsearch_plugin'
    bool_1 = False
    bytes_1 = b'\xf4\x96\xad\x12\xb4'
    dict_1 = {str_1: bytes_1, str_1: bytes_1, bytes_1: str_1}


# Generated at 2022-06-25 07:46:43.692382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:46:51.600706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:01.862608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    str_0 = 'tmp'
    str_1 = 'task_vars'
    var_0 = action_module_0.run(str_0, str_1)
    assert var_0 != str_1
    assert var_0 != str_0
    assert var_0 != bytes_0

# Generated at 2022-06-25 07:47:10.637596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'FA\x8fv\x12\x1a\x9e\x8e\xc5\x0e3\xeb'
    bool_0 = True
    bytes_0 = b'\xe0\x03#'
    dict_0 = {str_0: bytes_0, str_0: bytes_0, bytes_0: str_0}
    int_0 = -523
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:47:15.976224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:38.263296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:47:45.685127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:47:48.744359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:47:55.328130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:48:04.375949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'

# Generated at 2022-06-25 07:48:09.018888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call method run of class ActionModule
    assert test_case_0


# Method run invoked 1 times.

# Generated at 2022-06-25 07:48:17.065119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\'n3\x950\x8e\xf5\xa1]\xe4A\x81\x91'
    bytes_0 = b'\x0b\x16\xaa\xa4\x0c\x96S\x99\x9d\xf4\x0b>\xd1\x84'
    str_1 = '\x8b\x02\xac\x9a\x1a\xab\xba;\xd3\xe3\x15\x85\xf3'
    dict_0 = {str_1: str_0, bytes_0: str_0}
    bool_1 = True
    int_0 = -25

# Generated at 2022-06-25 07:48:23.145185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    result = action_module_0.run()
    print(result)

# Generated at 2022-06-25 07:48:27.637846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:48:36.440591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x8c\xf6\xb2\x11\xe7\x9c\xa7\xfc\xefP\x13\xb2\xe7\x19\xdb'
    int_0 = -939
    action_module_0 = ActionModule(str_0, bool_0, str_0, str_0, dict_0, int_0)
    action_module_0.run()
    int_1 = 575
    str_1 = 'Qy\x05\xdf\xb5\x87\x8b\xa4\xbd\xe4H\x87\xb9\x0e\xbf\x89\x03\x8c\xd7'

# Generated at 2022-06-25 07:49:17.392234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)



# Generated at 2022-06-25 07:49:21.464695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:22.834979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(AttributeError):
        # This test is expected to fail
        action_module_0 = ActionModule()
        action_module_0.run()


# Generated at 2022-06-25 07:49:24.355668
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule(None, None, None, None, None, None)
    bool_0 = action_module_0.run(None)
    assert bool_0 == False



# Generated at 2022-06-25 07:49:29.075729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)

# Generated at 2022-06-25 07:49:36.066537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '~:|\n\x8d\xfc'
    bool_0 = False
    bytes_0 = b'\x0f&\xdf\xc8\x82\x00\x85\xd0\x1d\xa5\xa4\xc5'
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    int_0 = -928
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:40.163509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check if you can run the run method of ActionModule
    action_module_0 = ActionModule(False, False, 'become', 'become', {'bool_0': 'bytes_0', 'bool_1': 'bytes_1', b'bytes_0': False}, -714)
    action_run()


# Generated at 2022-06-25 07:49:47.700265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_1, bool_0, str_1, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:49:56.414294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'become'
    bool_0 = True
    bytes_0 = b'\xa6K\xc7\x7fR2\x8aj\x1a\xcb8'
    dict_0 = {bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    int_0 = -714
    action_module_0 = ActionModule(str_0, bool_0, str_0, bytes_0, dict_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:50:04.900690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -320412464
    dict_0 = {int_0: str_0, str_0: int_0, int_0: bytes_0}
    bool_0 = True
    bytes_0 = b'\x8e~\xb6\x1b\x12\xa8\xd7\xf6\x13\x96\xfa\x1b'
    str_0 = 'become'
    action_module_0 = ActionModule(str_0, bool_0, bytes_0, str_0, dict_0, int_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:51:33.015463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'become'
    var_1 = True
    var_2 = 'ansible_become_password'
    var_3 = b'\xe2\xa7W8\xb2\x90\xcf\x96\x13n\x1b\xc7\xe6\xaaW'
    var_4 = {var_1: var_3, var_1: var_3, var_3: var_1}
    var_5 = -724
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    def action_run(self, tmp=None, task_vars=None):
        del tmp # tmp no longer has any effect
        # Shell module is implemented via command with a special arg
       