

# Generated at 2022-06-23 08:39:25.315923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:39:35.935537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    command = 'echo "BAR"'
    shell = '/bin/sh'

    # Create task and args to be used by run method
    task = {
        'action': {
            'name': command,
            'shell': shell
        }
    }
    args = {
        '_raw_params': command,
        '_uses_shell': True,
        '_executable': shell
    }

    #  Create a connection for use by run method
    connection = 'local'

    # Create play context for use by run method

# Generated at 2022-06-23 08:39:36.892889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:39:37.964711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:39:41.139359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    x = ansible.plugins.action.ActionModule()
    assert type(x) is ansible.plugins.action.ActionModule

# Generated at 2022-06-23 08:39:43.054215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-23 08:39:44.708926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:39:53.468775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    import ansible.template as template
    import ansible.vars.manager as vars_manager
    import ansible.vars.hostvars as hostvars

    context = play_context.PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='shell', args='whoami'), register='shell_out'),
        ]
    )
    play = play.Play().load

# Generated at 2022-06-23 08:39:54.744645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-23 08:39:55.941234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:40:01.167727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Invoke constructor of class ActionModule with a valid module name
    # which is not in the same package, but in action module.
    result=ActionModule('invalid_module_name')
    assert True

# Generated at 2022-06-23 08:40:05.984645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    cmd = 'echo hi'
    action_plugin = ansible.plugins.action.shell.ActionModule(cmd, {}, {}, {}, {}, {})
    action_plugin._task.args['_uses_shell'] == True
    assert cmd in str(action_plugin)

# Generated at 2022-06-23 08:40:16.924894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

    # Another module to perform tests
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    #print(task_include.task)

    # Another module to perform tests
    from ansible.plugins.connection import ConnectionBase
    ConnectionBase = ConnectionBase()

    # Another module to perform tests
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

    # Another module to perform tests
    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)

    # Another module to perform tests
    from ansible.plugins.loader import PluginLoader
    loader = PluginLoader('/home/test/test', '/home/test/test')


    # Loading modules to perform tests
    # Another

# Generated at 2022-06-23 08:40:20.649038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    assert ansible.plugins.action.shell.ActionModule  # if class exist, this will pass

# Generated at 2022-06-23 08:40:22.952798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    res = mod.run(tmp='dummy', task_vars=None)
    assert res['failed'] == False

# Generated at 2022-06-23 08:40:26.938164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Run test ...')

    task_vars = dict()
    action_module = ActionModule()
    action_module.run(task_vars=task_vars)

if __name__ == '__main__':
    # test_ActionModule_run()
    print('Nothing is done!')

# Generated at 2022-06-23 08:40:27.471208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:40:32.712373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor
    module = ActionModule(
        task='task',
        connection='connection',
        play_context='context',
        loader='loader',
        templar='templar',
        shared_loader_obj='shared_obj'
    )
    assert module._task == 'task'
    assert module._connection == 'connection'
    assert module._play_context == 'context'
    assert module._loader == 'loader'
    assert module._templar == 'templar'
    assert module._shared_loader_obj == 'shared_obj'


# Generated at 2022-06-23 08:40:40.823496
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock task object
    task_args = dict()
    my_task = dict()
    my_task['args'] = task_args

    # Create a mock action object
    my_action = dict()

    # Create a mock connection object
    my_connection = dict()

    # Create a mock play_context object
    my_play_context = dict()

    # Create a mock loader object
    my_loader = dict()

    # Create a mock templar object
    my_templar = dict()

    # Create a mock shared_loader_obj object
    my_shared_loader_obj = dict()
    my_shared_loader_obj['action_loader'] = dict()

    # Create a mock ansible.legacy.command object and add to the mock shared_loader_obj
    my_action_command = dict()


# Generated at 2022-06-23 08:40:51.249052
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:40:52.228131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    return True

# Generated at 2022-06-23 08:40:54.486703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    a = ActionModule()
    # Check that object is an instance of the correct class
    assert type(a) is ansible.plugins.action.ActionModule

# Generated at 2022-06-23 08:40:58.125685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = 'command'
    attrs = {'_uses_shell': True}
    assert ActionModule._create_action(module, attrs) == True

# Generated at 2022-06-23 08:41:00.435579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({}, {}, {}, {})
    assert '_uses_shell' in action_module._task.args

# Generated at 2022-06-23 08:41:05.194217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_module_args({'_uses_shell': True})
    module = AnsibleModule(argument_spec={})
    assert module.run_command() == (0, '', '')

# Generated at 2022-06-23 08:41:14.137225
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule('bad.yml')
    action_module._connection = 'local' # mock connection
    action_module._task = 'task' # mock task
    action_module._play_context = 'play_context' # mock play_context
    action_module._loader = 'loader' # mock loader
    action_module._templar = 'templar' # mock templar
    action_module._shared_loader_obj = 'shared_loader_obj' # mock shared_loader_obj

    # Check if method run has been called
    assert action_module.run()

# Generated at 2022-06-23 08:41:18.105982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-23 08:41:24.245203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test Init with None
    test_init_action_module_object = ActionModule(name=None, task=None, connection=None,
                                                  play_context=None, loader=None, templar=None,
                                                  shared_loader_obj=None)
    assert test_init_action_module_object.runner_type == 'shell'
    assert not test_init_action_module_object.noop_on_check(task_vars={})


# Generated at 2022-06-23 08:41:34.111354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.command import ActionModule
    import json
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli.adhoc import AdHocCLI
    from io import StringIO
    from ansible.utils.vars import combine_vars

    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleError

    # Create a temporary file to store the data
    tmpfile = tempfile.NamedTemporaryFile()
    filename = tmpfile.name

    # Create a fake task
    task_vars = dict(
        temp_file=filename
    )

    # Create a fake play context
    play_context = PlayContext()

    # Create options


# Generated at 2022-06-23 08:41:43.103076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action.ansible import ActionModule

    # First time is apparently necessary to have the module instance loaded from plugin
    from ansible.plugins.loader import module_loader
    module_loader.get(module_name='ansible.legacy.shell')

    # After that, we can build an instance, which is what we need to test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Act
    result = action_module.run(tmp=None, task_vars=None)

    # Assert
    assert result is None

# Generated at 2022-06-23 08:41:44.817095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionBase = ActionBase()
    actionModule = ActionModule()
    assert(actionModule._shared_loader_obj == actionBase)


# Generated at 2022-06-23 08:41:51.337498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_action = 'ansible.legacy.shell'
    action_loader = None
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    action_module = ActionModule(action_loader, task, connection, play_context, loader, templar, shared_loader_obj)
    action_module.run()

# Generated at 2022-06-23 08:41:57.492301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AnsibleModule argument `task` is required by class ActionBase.
    # Just use a mock object.
    task = object()
    action = ActionModule(task=task, connection=None)

    assert action._task is task
    assert action._shared_loader_obj is None

# Generated at 2022-06-23 08:42:05.388554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj._task.args = {'_raw_params': 'foo'}
    obj._task.action = 'shell'
    # Unit test for method run of class ActionBase
    def test_ActionBase_run():
        obj = ActionBase()
        obj._task = 'foo'
        obj._task.args = {'_raw_params': 'foo'}
        obj._connection = 'foo'
        obj._play_context = 'foo'
        obj._loader = 'foo'
        obj._templar = 'foo'
        obj._shared_loader_obj = 'foo'
        obj.connection = 'foo'
        # Unit test for method run of class ConnectionBase
        def test_ConnectionBase_run():
            obj = ConnectionBase()
            obj._play_context = 'foo'

# Generated at 2022-06-23 08:42:05.923340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:42:06.438196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:42:07.539928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = AnsibleModule()
    assert(mod.run() == {})

# Generated at 2022-06-23 08:42:13.104439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the ActionModule
    test_actionModule = ActionModule()
    
    
    # Assert equal
    assert test_actionModule.run == ActionModule.run
    # Assert equal
    assert test_actionModule.run == ActionModule.run
    # Assert equal
    assert test_actionModule.run == ActionModule.run

# Generated at 2022-06-23 08:42:18.002906
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins import action

    class MyClass(action.ActionBase):
        pass

    task = MyClass()

    actionmodule = ActionModule(
        task=task,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert type(actionmodule) == ActionModule



# Generated at 2022-06-23 08:42:19.848034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()


# Generated at 2022-06-23 08:42:20.449853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:42:22.727967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an ActionModule without error
    action_module = ActionModule()

# Generated at 2022-06-23 08:42:27.139456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'args': {'_uses_shell': True}}
    cls = ActionModule(task, None, None, None, None, None)
    assert cls.run(task_vars={}) == {'changed': False, 'rc': 0, 'stderr': '', 'stdout': '', 'stdout_lines': [], 'warnings': []}

# Generated at 2022-06-23 08:42:28.509801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()


# Generated at 2022-06-23 08:42:30.274032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None,  None)
    assert am is not None

# Generated at 2022-06-23 08:42:34.962750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Import module to be tested
    from ansible.plugins.action.script import ActionModule

    # Create object of class ActionModule
    awx_script = ActionModule('shell', '/tmp/foo', '127.0.0.1', 'root', '5672')
    # Check if awx_script is a object of class ActionModule
    assert isinstance(awx_script, ActionModule)
    # Check if _task attr of awx_script is a shell
    assert awx_script._task == 'shell'
    # Check if _connection attr of awx_script is a 127.0.0.1
    assert awx_script._connection == '127.0.0.1'
    # Check if _play_context attr of awx_script is a 5672

# Generated at 2022-06-23 08:42:41.665063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    collection_name = 'awx.awx'
    collection_namespace = 'awx'
    collection_dirs = [
        os.path.join(os.path.dirname(__file__), os.pardir, 'test_data', 'fixtures', 'ansible_collections', 'awx',
                     'awx'),
        os.path.join(os.path.dirname(__file__), os.pardir, 'test_data', 'fixtures', 'ansible_collections', 'namespace',
                     'collection')
    ]
    loader

# Generated at 2022-06-23 08:42:42.923349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    result = a.run()
    assert(result)

# Generated at 2022-06-23 08:42:44.085578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:42:51.533658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.executor.task_result import TaskResult
    import ansible.plugins.loader as loader
    import ansible.plugins.action as action_loader
    import os
    import pwd
    import re
    import sys
    import yaml
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-23 08:42:52.448782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t is not None

# Generated at 2022-06-23 08:43:02.125893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    mock_ActionBase = MagicMock(spec=ActionBase)
    mock_ActionModule = MagicMock(spec=ActionModule)
    mock_ActionModule_inst = mock_ActionModule.return_value
    mock_ActionModule_run = MagicMock()
    mock_ActionBase.run = mock_ActionModule_run
    mock_ActionModule_inst.run = mock_ActionModule_run
    mock_ActionModule_inst.tmp = MagicMock()
    mock_ActionModule_inst._task.args = {'_uses_shell':True}
    mock_ActionModule_inst._shared_loader_obj = MagicMock()
    mock_ActionModule_inst._shared_loader_obj.action_loader = MagicMock()
    mock_get_action = MagicMock()
    mock_ActionModule_inst._

# Generated at 2022-06-23 08:43:07.144151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    ansible.plugins.action.ActionBase = lambda: None
    x = ansible.plugins.action.ActionBase()
    x.__init__ = lambda a: None
    x.run = lambda a: None

# Generated at 2022-06-23 08:43:13.523127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    action_plugin = Mock()
    action_plugin.task = Mock()
    action_plugin.task.args = {'_uses_shell': True}
    action_plugin._shared_loader_obj = Mock()
    action_plugin._shared_loader_obj.action_loader = Mock()
    action_plugin._shared_loader_obj.action_loader.get = Mock(return_value=Mock(run=Mock(return_value=0)))
    assert action_plugin.run(task_vars=Mock()) == 0

# Generated at 2022-06-23 08:43:19.303710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    assert action_module
    assert action_module.tmp == None
    assert action_module.shared_loader_obj == None
    assert action_module.templar == None
    assert action_module.loader == None

# Generated at 2022-06-23 08:43:20.656358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert(mod)


# Generated at 2022-06-23 08:43:21.633194
# Unit test for constructor of class ActionModule
def test_ActionModule():
	module = ActionModule()
	assert type(module) == ActionModule, "ActionModule constructor"

# Generated at 2022-06-23 08:43:22.447168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 08:43:23.673023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This function is used to test the run method of class ActionModule
    '''

# Generated at 2022-06-23 08:43:27.674920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    data = {}
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'
    task_vars = 'task_vars'
    
    instance = ActionModule(tmp, data, connection, play_context, loader, templar, shared_loader_obj)
    instance.run(task_vars)

# Generated at 2022-06-23 08:43:29.976725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  amd = ActionModule(None, None, None, None, None, None)
  assert amd.run(None, None) == None

# Generated at 2022-06-23 08:43:31.491914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, {})

# Generated at 2022-06-23 08:43:42.414076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask:
        def __init__(self, args):
            self.args = args

    class MockActionBase:
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    class MockLoader:
        def get(self, action, task, connection, play_context, loader, templar, shared_loader_obj):
            self.action = action
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader

# Generated at 2022-06-23 08:43:54.213607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(action_name='shell',
                                     action_value='/bin/true',
                                     action_module='shell',
                                     action_args=None,
                                     task=None,
                                     shared_loader_obj=None,
                                     connection=None,
                                     play_context=None,
                                     loader=None,
                                     templar=None,
                                     ansible_job_dir=None)
    import sys
    import os.path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    lib_dir = os.path.abspath(os.path.join(current_dir, '..'))
    sys.path.append(lib_dir)

# Generated at 2022-06-23 08:43:55.143741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:43:55.684220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:43:56.568993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run_ActionModule_run() == True

# Generated at 2022-06-23 08:44:00.147994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()
    assert action_plugin_loader.package not in act_mod.__class__.__dict__



# Generated at 2022-06-23 08:44:08.496149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Create a single instance of ActionModule '''
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import PY3

    # Instantiate the ActionModule class
    action_module_obj = ActionModule('test')

    # Check the type of action_module_obj
    if isinstance(action_module_obj, ActionBase):
        if PY3:
            print("Success: Instantiation of ActionModule class returns an object of type ActionBase")
        else:
            print("Success: Instantiation of ActionModule class returns an object of type ActionBase(__metaclass__)")
    else:
        print("Failed: Instantiation of ActionModule class did not return an object of type ActionBase")



# Generated at 2022-06-23 08:44:09.467697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:17.741076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    shell = {
        "module_name": "shell",
        "module_args": "-c \"ls\"",
        "aliases": {},
        "warnings": [],
        "changed": False,
        "skipped": False,
        "failed": False,
        "parsed": True,
        "invocation": {
            "module_args": "-c \"ls\""
        }
    }
    ansible_result = {
        'ansible_loop_var': 'item',
        'changed': False,
        'item': {},
        '_ansible_no_log': False,
        '_ansible_parsed': True,
        'stderr': '',
        'stdout': '',
        'stdout_lines': []
    }

# Generated at 2022-06-23 08:44:19.870594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    print(type(a))

# Generated at 2022-06-23 08:44:28.862784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing variable
    dict_args = dict()
    dict_args['_ansible_verbosity'] = 10
    dict_args['stderr_lines'] = [
        'This is stderr line 1',
        'This is stderr line 2',
    ]
    dict_args['stdout_lines'] = [
        'This is stdout line 1',
        'This is stdout line 2',
    ]
    dict_args['warnings'] = [
        'This is warning 1',
        'This is warning 2',
    ]
    dict_args['changed'] = True
    dict_args['_ansible_parsed'] = True
    dict_args['_ansible_item_result'] = False
    dict_args['_ansible_no_log'] = False

    # Initializing task object


# Generated at 2022-06-23 08:44:36.359740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, tempdir=None)
    assert action_module is not None


# Generated at 2022-06-23 08:44:37.464388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()



# Generated at 2022-06-23 08:44:38.190764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:44:40.673152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    at = ActionModule(connection = None, adapter = None, task = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert at.__class__ == ActionModule

# Generated at 2022-06-23 08:44:41.785447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:44:45.472029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    # We do not check the 'run' method as it is already fully tested
    # in test_command.py
    assert True

# Generated at 2022-06-23 08:44:48.945002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None).module_utils == 'ansible.module_utils.basic'

# Generated at 2022-06-23 08:44:59.411502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-23 08:45:07.758074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = {
        'name': 'shell',
        'type': 'shell',
        '_uses_shell': True,
        'args': {
            '_raw_params': '',
            '_uses_shell': True,
            '_ansible_no_log': False
        }
    }
    tmp_path = 'tmp-path'
    task_vars = {'a': 'b'}
    action_base = ActionBase()
    action_module = ActionModule(action_base.connection, action_base.play_context, action_base.loader, action_base.templar, action_base.shared_loader_obj)
    action_module._task = test_module

# Generated at 2022-06-23 08:45:16.118347
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:45:27.110763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ModuleStub:
        def __init__(self):
            self.params = dict()

    class PlayContextStub:
        def __init__(self):
            self.check_mode = 'false'
            self.diff = 'false'

    class TaskStub:
        def __init__(self):
            self.args = dict()

    class ActionBaseStub:
        def __init__(self):
            self._templar = None
            self._task = TaskStub()
            self._shared_loader_obj = None
            self._loader = None

    class ConnectionStub:
        def __init__(self, ansible_connection):
            self.module = ModuleStub()
            self.play_context = PlayContextStub()
            self.ansible_connection = ansible_connection


# Generated at 2022-06-23 08:45:29.049081
# Unit test for constructor of class ActionModule
def test_ActionModule():

  assert(1 == 1)

# Generated at 2022-06-23 08:45:33.580610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
#     tmp = '/tmp/tmp'
#     task_vars = {'key': 'value'}
    
#     a = ActionModule()
#     result = a.run(tmp=tmp, task_vars=task_vars)
#     assert result == {'rc': 0, 'stdout': '', 'stdout_lines': [], 'stderr': '', 'stderr_lines': [], 'changed': False}


# Generated at 2022-06-23 08:45:37.935477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_obj = ActionModule(connection=None, play_context=None, task=None, loader=None, templar=None, shared_loader_obj=None)
    assert(mock_obj._shared_loader_obj == None)

# Generated at 2022-06-23 08:45:38.660617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-23 08:45:39.904232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1

# Generated at 2022-06-23 08:45:42.947819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    n1 = ActionModule()
    n2 = ActionModule(ActionBase())

    print(n1.__dict__)
    print(n2.__dict__)


# Generated at 2022-06-23 08:45:51.630464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Test:
        def __init__(self):
            self.name = 'test'

    task = Test()
    task.args = {'_uses_shell': True}
    action_loader = Test()
    action_loader.get = lambda *args, **kwargs: Test()
    connection = Test()
    play_context = Test()
    loader = Test()
    templar = Test()
    shared_loader_obj = Test()
    shared_loader_obj.action_loader = action_loader
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert action_module.run(None, None) is not None

# Generated at 2022-06-23 08:45:52.174753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:45:53.073531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 08:45:53.908679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:45:58.166039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule(None, {}, {}, {}, {}, {})
    result = action_plugin.run(None, True)
    assert result == True

# Generated at 2022-06-23 08:46:01.162815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #This function is to test the constructor of class ActionModule
    module = ActionModule()
    assert module._play_context.shell == '/bin/sh'

# Generated at 2022-06-23 08:46:07.301994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = None
    task = dict(
        args = dict(_uses_shell=True),
        action = 'shell',
        )

    tmp = None
    task_vars = {}

    loader = None
    shared_loader_obj = None
    play_context = None
    connection = None

    module = ActionModule(None, loader=loader, play_context=play_context, connection=None, shared_loader_obj=shared_loader_obj)
    assert module.run(tmp, task_vars) is None

# Generated at 2022-06-23 08:46:14.196093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Test public instance variables of class ActionModule
    assert action._shared_loader_obj is not None
    assert action._loader is None
    assert action._templar is None
    assert action._task is not None
    assert hasattr(action, '_display')
    assert hasattr(action, '_connection')
    assert hasattr(action, '_play_context')

# Generated at 2022-06-23 08:46:15.847820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    @param tmp=None, task_vars=None
    @return result
    """
    pass

# Generated at 2022-06-23 08:46:17.974740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.legacy_shell as legacy_shell
    actionModule = legacy_shell.ActionModule()


# Generated at 2022-06-23 08:46:18.551301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:46:19.841323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-23 08:46:31.610334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule(object):
        def __init__(self, args):
            self.args = args
    class AnsibleTask(object):
        module_args = dict()
    class Connection(object):
        pass
    class AnsibleLoader(object):
        class AnsibleFileLoader(object):
            pass
    class AnsiblePlayContext(object):
        pass
    class Loader(object):
        pass
    class AnsibleTemplar(object):
        def template(self, arg):
            return arg
    class AnsibleAction(object):
        def __init__(self, args):
            self.args = args
    class SharedLoaderObj(object):
        def get(self, args, kwargs):
            return AnsibleAction(kwargs)

# Generated at 2022-06-23 08:46:40.855079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestAction_init():
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
        def get(self, module, args):
            self.module = module
            self.args = args
            return self
        def run(self, tmp, task_vars):
            return self.__dict__

    class Test_init:
        def __init__(self):
            self._task = {}
            self._connection = {}
            self._play_context = {}
            self._loader = {}

# Generated at 2022-06-23 08:46:51.393040
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:46:52.822126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-23 08:46:53.635502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:46:54.243526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:46:58.586001
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Case 1: Run the module without parameters
    a = ActionModule()
    
    # Case 2: test if the run method works
    a.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:46:59.463762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:47:09.269780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'action_plugins.shell' in globals()

    def get_loader_mock(type_name):
        return None

    class TaskMock:
        def __init__(self):
            self.args = dict()

        def copy(self):
            return self

    class SharedLoaderObjMock:
        def __init__(self):
            self.action_loader = None

    def get_action_mock(name, task, connection, play_context, loader, templar, shared_loader_obj):
        assert name == 'ansible.legacy.command'
        assert type(task) == TaskMock
        assert connection is None
        assert play_context is None
        assert loader == get_loader_mock
        assert templar is None
        assert type(shared_loader_obj) == SharedLoaderObjM

# Generated at 2022-06-23 08:47:15.747073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule()
    action_mod._shared_loader_obj = object()
    action_mod._task = object()
    action_mod._connection = object()
    action_mod._play_context = object()
    action_mod._loader = object()
    action_mod._templar = object()
    assert action_mod.run()

# Generated at 2022-06-23 08:47:25.558640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestTask:
        def __init__(self, args):
            self.args = args

    class TestLoader:
        pass

    class TestConnection:
        pass

    class TestPlayContext:
        pass

    class TestSharedLoaderObj:
        action_loader = TestLoader()

    module = ActionModule(TestTask({}), TestConnection(), TestPlayContext(), TestLoader(), TestSharedLoaderObj())
    assert(isinstance(module._task.args, dict))
    assert('_uses_shell' not in list(module._task.args.keys()))
    assert(module._task.args['_uses_shell'] is False)
    assert(isinstance(module._loader, TestLoader))

# Generated at 2022-06-23 08:47:34.500171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleTask(object):
        args = {}
    class AnsibleConnection(object):
        def __init__(self, host):
            self.host = host
    class AnsibleLoader(object):
        pass
    class AnsibleTemplar(object):
        pass
    class AnsibleAction(ActionBase):
        def __init__(self, host, task_vars):
            self.host = host
            self.task_vars = task_vars
            self.result = {}
        def run(self):
            self.result = {'result': 'pass'}
            return self.result
    class AnsibleSharedLoaderObj(object):
        action_loader = {
            'ansible.legacy.command': AnsibleAction
        }
    class AnsiblePlayContext(object):
        pass
        
   

# Generated at 2022-06-23 08:47:39.658558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temporary class that has all required attributes for ActionModule
    class Temp:
        def __init__(self):
            self.args = {
                '_raw_params': 'echo 1',
            }
            self.action = 'echo'

    # Create an object for class ActionModule
    obj = ActionModule()

    # Define a temp attribute for class ActionModule
    tmp = Temp()

    # Call the run method to action on the raw parameters
    obj.run(tmp=tmp)

# Generated at 2022-06-23 08:47:40.817869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:47:50.240378
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:47:55.331883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test_action', 'localhost', 'test_loader', 'test_shared_loader', 'test_templar')
    assert action_module._name == 'test_action'
    assert action_module._loader == 'test_loader'
    assert action_module._shared_loader_obj == 'test_shared_loader'
    assert action_module._templar == 'test_templar'

# Generated at 2022-06-23 08:47:55.862182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:48:01.182711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    task_vars = dict()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)
    assert result == {'failed': False, 'rc': 0, 'stderr': '', 'stdout': ''}

# Generated at 2022-06-23 08:48:07.148284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._shared_loader_obj is not None
    assert module._loader is not None
    assert module._task is not None
    assert module._connection is not None
    assert module._play_context is not None
    assert module._templar is not None
    assert module._templar._available_variables is not None
    assert module._templar._vault is not None


# Generated at 2022-06-23 08:48:18.043499
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:48:18.574622
# Unit test for constructor of class ActionModule
def test_ActionModule():
	t=ActionModule()

# Generated at 2022-06-23 08:48:25.388639
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:48:33.255749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    context._init_global_context()

    from ansible.utils.display import Display
    display = Display()

    from ansible.plugins.loader import module_loader
    module_loader._load_plugins()


    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.legacy.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.legacy.task.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible import constants as C
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes, to

# Generated at 2022-06-23 08:48:38.377407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Used to test run method of ActionModule Class"""
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print("Hello Testing")
    test_run = TestActionModule()
    test_run.run()


# Generated at 2022-06-23 08:48:42.146292
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ['ansible.legacy.shell']

    #ActionBase class have a get_action_plugin method
    action_plugin = ActionModule.get_action_plugin('shell', action_module,
                                                   None, None, None, None,
                                                   None, None, None)

    assert action_plugin == ActionModule

# Generated at 2022-06-23 08:48:43.946333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    _test_ActionModule(ansible.plugins.action.shell.ActionModule)


# Generated at 2022-06-23 08:48:51.427248
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.common._collections_compat import MutableMapping

    class MockModuleReturn(MutableMapping):

        def __init__(self, **kwargs):
            self.dict = kwargs
            super(MockModuleReturn, self).__init__()

        def __getitem__(self, item):
            return self.dict[item]

        def __setitem__(self, item, value):
            self.dict[item] = value

        def __delitem__(self, key):
            del self.dict[key]

        def __iter__(self):
            return iter(self.dict)

        def __len__(self):
            return len(self.dict)


# Generated at 2022-06-23 08:49:04.565579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake task
    task = {
        'action': {
            '__ansible_module__': 'ansible.legacy.shell',
        }
    }

    # create a fake connection (an object which is a member of ConnectionBase class)
    connection = object()

    # create a play context
    play_context = {'check_mode': False}

    # create a fake loader object
    loader = object()

    # create a fake templar object
    templar = object()

    # create a fake shared loader object
    shared_loader_obj = object()

    # create a fake action base object
    action = ActionBase(task, connection, play_context, loader, templar, shared_loader_obj)

    # create an instance of ActionModule

# Generated at 2022-06-23 08:49:10.660229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    module_args = {
        '_uses_shell': True,
        '_raw_params': 'echo hello',
        'chdir': '/',
        'creates': None,
        'executable': None,
        'removes': None,
        'warn': True
    }
    task = {'args': module_args}
    action = ActionModule(task, {})
    task_vars = {}

    # Act
    result = action.run(task_vars=task_vars)

    # Assert
    assert result['rc'] == 0

# Generated at 2022-06-23 08:49:11.801774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:49:20.271237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with a fake connection and fake loader object
    test_con = {
        'ips': [
            '1.1.1.1',
            '2.2.2.2'
        ],
        'hosts': [
            'host1',
            'host2'
        ]
    }
    test_loader_obj = {
        'name': 'fake_loader_obj'
    }

    # Basic instantiation test
    test_module = ActionModule(
        fake_task={},
        connection=test_con,
        play_context={},
        loader={},
        templar={},
        shared_loader_obj=test_loader_obj
    )

    # Check that instantiation was successful

# Generated at 2022-06-23 08:49:30.844166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._task = {}
    actionModule._loader = None
    actionModule._shared_loader_obj = None
    actionModule._connection = None
    actionModule._play_context = None
    actionModule._templar = None
    result = actionModule.run(tmp=None, task_vars=None)
    assert result == None