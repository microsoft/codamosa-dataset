

# Generated at 2022-06-23 08:39:31.302247
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:39:38.807042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

    action_shell = shell_loader.get('shell')
    assert action_shell is not None
    assert isinstance(action_shell, ActionModule)

    action_shell._shared_loader_obj.action_loader.get = MagicMock(
        return_value=MagicMock()
    )
    action_shell._shared_loader_obj.action_loader.get().run = MagicMock()

    action_shell._task = Task.load(dict(
        action=dict(
            module='shell',
            args='echo pwd',
        )
    ))
    action_shell._connection = connection_loader.get('local')
    action_shell._play_context = Magic

# Generated at 2022-06-23 08:39:44.261701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct
    m_ansible_action_module_instance = ansible_action_module.ActionModule()

    # Obtain the args needed to run the method
    tmp=None
    task_vars=None

    # Call
    m_ansible_action_module_instance.run(tmp=tmp, task_vars=task_vars)

    # Check
    assert True

# Generated at 2022-06-23 08:39:53.181857
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:39:55.819937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Return value of method run of class ActionModule defined
    in action_plugins/shell.py.
    """

    # Create an object of class ActionModule
    act_obj = ActionModule()


# Generated at 2022-06-23 08:40:05.291507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    from ansible.plugins.action import ActionBase

    class FirstAction(ActionBase):
        def run(self, task_vars=None):
            return task_vars

    class SecondAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return task_vars

    connection = Mock()
    play_context = Mock()
    loader = Mock()
    templar = Mock()
    shared_loader_obj = Mock()


    action_module = FirstAction(
        task=Mock(),
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj,
    )

    result = action_module.run()


# Generated at 2022-06-23 08:40:08.564718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of AnsibleModule
    am = ActionModule()

    print("Vars: ")
    print(am._task.args)
    print("Object: ")
    print(am)

# Generated at 2022-06-23 08:40:15.347048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN: object of class ActionModule
    action_module = ActionModule('test', 'localhost', {}, None)
    action_module._task.args = {'_raw_params': 'something'}
    action_module._shared_loader_obj = 'something'

    # WHEN: call run method
    ret = action_module.run()

    # THEN: correct return value is set
    assert ret['changed'] is False
    assert ret['rc'] == 0
    assert ret['msg'] == ''
    assert ret['stdout'] is None
    assert ret['stderr'] is None

# Generated at 2022-06-23 08:40:18.545785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:40:19.711358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action

# Generated at 2022-06-23 08:40:20.983271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-23 08:40:22.534739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-23 08:40:23.484508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass




# Generated at 2022-06-23 08:40:24.171916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:40:32.690286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for ActionModule class takes 4 required arguments
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import context
    from ansible.playbook.block import Block

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_source

# Generated at 2022-06-23 08:40:33.351032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:40:34.958109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:40:37.175825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:40:47.720380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for `ansible.plugins.action.shell.ActionModule.run` method."""
    # Build fake data
    fake_task = {
        'args': {
            '_uses_shell': True,
        },
    }
    fake_result = {
        'fake_result': 'fake_result',
    }
    fake_task_vars = {
        'fake_task_vars': 'fake_task_vars',
    }
    # Build fake objs
    fake_command_action = {
        'run': lambda task_vars: fake_result,
    }

# Generated at 2022-06-23 08:40:50.988169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
 
  # set up
  # create an object of class ActionModule
  example = ActionModule()
  # create an empty object variable
  result = ''

  # check that the returned object variable contains the key 'stdout'
  assert 'stdout' in result

# Generated at 2022-06-23 08:40:58.105678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_args = {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True,
                 '_raw_params': u'/bin/echo hello', '_uses_shell': True, '_uses_delegate_to': False,
                 '_raw_params_at_creation': u'/bin/echo hello'}

# Generated at 2022-06-23 08:40:59.379573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:41:06.483849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    action_loader = ActionModuleLoader(play=None)
    task = Task()
    connection = None
    play_context = None
    loader = None
    templar = Templar(loader=loader, variables=VariableManager())
    shared_loader_obj = None
    shell = ActionModule(action_loader=action_loader, task=task, connection=connection, play_context=play_context,
                                loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

# Generated at 2022-06-23 08:41:13.217072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict(contacted=dict())
    data = dict(ansible_job_id='',
                _ansible_no_log=False,
                _ansible_verbosity=0,
                _ansible_version='',
                _ansible_version_major_minor_string='')
    obj = ActionModule(result, data)
    assert obj is not None

# Generated at 2022-06-23 08:41:14.418271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:41:23.708701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect

    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)

# Generated at 2022-06-23 08:41:24.967246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod is not None

# Generated at 2022-06-23 08:41:34.392274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.playbook import play_context
    from ansible.playbook.task import Task

    pc = play_context.PlayContext()
    task = Task()
    task_ds = {
        'name': 'shell-module-with-args',
        'action': 'shell',
        'args': {
            '_raw_params': 'my shell command',
            '_uses_shell': True,
        }
    }
    task.deserialize(task_ds)
    task_vars = {}


# Generated at 2022-06-23 08:41:35.549851
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule is not None, "Action module not found."

# Generated at 2022-06-23 08:41:45.780862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #from ad_hoc.command import ansible.legacy.shell
    from ansible.plugins.action import ActionBase
    import sys
    import __builtin__ as builtins
    # mock input args
    tmp = None
    task_vars = {}
    # create instance
    actionModule_instance = ActionModule(None, None, None)
    # patching
    #patch_ansible_module = patch.object(ansible.shell, 'ActionModule')
    #mock_ansible_module = patch_ansible_module.start()
    # create object
    #actionModule_object = ansible.shell.ActionModule(None, None, None)
    # Execute method
    #result = actionModule_instance.run(task_vars=task_vars)

# Generated at 2022-06-23 08:41:54.086968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    
    ansible_play_context = ImmutableDict(dict())
    
    ansible_module_args = ImmutableDict(dict(
      _raw_params='top',
      _uses_shell=True,
    ))
    
    ansible_connection = ImmutableDict(dict(
      connection='network_cli',
      host='localhost',
    ))
    
    ansible_task = ImmutableDict(dict(
      args=ansible_module_args,
      loop='',
      name='Auxiliary Test Case',
    ))
    

# Generated at 2022-06-23 08:42:00.620823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    am = ActionModule()
    
    assert am.run() == {}
    assert am.run(task_vars={}) == {}
    assert am.run(task_vars={"ansible_all_ipv4_addresses": { "lo": [ "127.0.0.1" ], 
                                                             "eth0": [ "192.168.0.1" ],
                                                             "eth1": []}}) == {}

# Generated at 2022-06-23 08:42:11.523456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = MagicMock()
    _connection = MagicMock()
    _play_context = MagicMock()
    _loader = MagicMock()
    _templar = MagicMock()
    _shared_loader_obj = MagicMock()
    _shared_loader_obj.action_loader.get.return_value = MagicMock()
    _shared_loader_obj.action_loader.get.return_value.run = MagicMock()
    _shared_loader_obj.action_loader.get.return_value.run.return_value = "return_value"
    obj = ActionModule(_task, _connection, _play_context, _loader, _templar, _shared_loader_obj)

    assert obj.run() == "return_value"

# Generated at 2022-06-23 08:42:12.679143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run()

    assert result

# Generated at 2022-06-23 08:42:21.325648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        def __init__(self):
            self.args = {}
            self.action = 'command'

    class MockPlayContext(object):
        def __init__(self):
            self.remote_addr = None

    class MockActionLoader(object):
        def __init__(self):
            self.action = 'command'

        def get(self, *args):
            return self.action

    class MockTemplar(object):
        def __init__(self):
            pass

    class MockLoader(object):
        def __init__(self):
            pass

    class MockConnection(object):
        def __init__(self):
            pass

    task = MockTask()
    play_context = MockPlayContext()
    action_loader = MockActionLoader()
    templar = MockTem

# Generated at 2022-06-23 08:42:26.020034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=MockTask(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module != None
    assert action_module._task != None
# end of test_ActionModule method


# Generated at 2022-06-23 08:42:27.617011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:42:28.803445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m

# Generated at 2022-06-23 08:42:34.262467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.ansible_legacy_shell import ActionModule

    actionModuleInstance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actionModuleInstance.run(tmp=None, task_vars=None)
    assert actionModuleInstance.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:42:42.188911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.cli.playbook.playbook_cli import PlaybookCLI
    from ansible.playbook import Playbook

    PlaybookCLI()

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['ansible/tests/inventory'])



# Generated at 2022-06-23 08:42:48.768366
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:42:49.792318
# Unit test for constructor of class ActionModule
def test_ActionModule():
	print( "Testing Constructor" )
	assert( 1 == 1 )


# Generated at 2022-06-23 08:43:00.114591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks
    class MockActionBase():
        def __init__(self):
            pass
        def run(self, tmp=None, task_vars=None):
            return 'Mock run'
    class MockAction():
        def __init__(self):
            self.action_loader = 'Mock action loader'
        def get(self, prompt, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            return MockActionBase()
    class MockTask():
        def __init__(self):
            self.args = {'_uses_shell': True}
    class MockPlayContext():
        def __init__(self):
            self.prompt = 'Mock prompt'

# Generated at 2022-06-23 08:43:11.268747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create expected results for test
    expected_result =  {"cmd": ["bash -c echo foo"], "rc": 0, "stdout": "foo", "stdout_lines": ["foo"]}

    # Get the actual result
    actual_result = action_module.run(tmp=None, task_vars={"ansible_shell_type": "cmd",
                                                           "ansible_shell_executable": "bash",
                                                           "ansible_command_executable": "echo"})

    assert expected_result == actual_result



# Generated at 2022-06-23 08:43:12.665291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a

# Generated at 2022-06-23 08:43:23.674148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = Mock()
    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.action_loader = Mock()
    mock_shared_loader_obj.action_loader.get = Mock(return_value='ansible.legacy.command')
    mock_templar = Mock()
    mock_loader = Mock()
    mock_play_context = Mock()
    mock_task = Mock()
    mock_task.args = {'_uses_shell': True}

# Generated at 2022-06-23 08:43:24.094341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()

# Generated at 2022-06-23 08:43:27.305067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ACTION_MODULE = ActionModule()
    assert ACTION_MODULE != None


# Generated at 2022-06-23 08:43:29.047393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, None, None, None, None), ActionModule)


# Generated at 2022-06-23 08:43:40.383035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(loader=None, connection=None, play_context=None)

    # test with wrong command

# Generated at 2022-06-23 08:43:46.226542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing method run of class ActionModule
    """

    # Mock tmp
    tmp = None

    # Mock task_vars
    task_vars = dict({"ansible_connection": "local"})

    # Mock _task
    _task = dict({"action": "shell"})

    # Initialize object ActionModule
    action_module = ActionModule()

test_ActionModule_run()

# Generated at 2022-06-23 08:43:56.778014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = {
        'parameters': {
            'command': 'ls -l'
        },
        '_ansible_sys_path': '/path/to/ansible',
        '_ansible_module_name': 'shell',
        '_ansible_no_log': False,
        '_ansible_verbosity': 3,
        '_ansible_version': '2.5',
        '_ansible_version_full': '2.5.0'
    }


# Generated at 2022-06-23 08:43:59.425621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'action_module' in dir(ActionModule)


# Generated at 2022-06-23 08:44:08.555174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import mock
    import ansible.utils
    import ansible.plugins.action

    # No need to test anon_vars and host_vars because they are set to None in constructor
    # anon_vars and host_vars are only used in the run_safely() method, where the class is run
    # There is no need to check if the other arguments have been assigned to the class
    # because the constructor is just that
    am = ansible.plugins.action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None,
                                             shared_loader_obj=None)

    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._

# Generated at 2022-06-23 08:44:17.446853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    test_task_vars = dict()

    test_task_vars["test_TaskVars_var"] = "test_TaskVars_value"
    
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = test_action_module.run(tmp=None, task_vars=test_task_vars)

    assert(result["warnings"] is not None)

    assert(result["warnings"] == [])

    assert(result["invocation"]["module_args"]["warn"] == True)

    assert(result["invocation"]["module_args"]["_uses_shell"] == True)


# Generated at 2022-06-23 08:44:20.132074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None


# Generated at 2022-06-23 08:44:28.957923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #######################################################################################################
    # args for test cases
    #######################################################################################################
    action_module_test_case1 = {"test_type": "unit",
                                "tmp": None,
                                "task_vars": {"ansible_check_mode": False},
                                "task": {"args": {}}
                                }

    action_module_test_case2 = {"test_type": "unit",
                                "tmp": None,
                                "task_vars": {"ansible_check_mode": False},
                                "task": {"args": {'_uses_shell': True}}
                                }

    #######################################################################################################
    # Start the test cases
    #######################################################################################################
    # Create a fake instance
    am = ActionModule()
    am._task = action_module_test

# Generated at 2022-06-23 08:44:29.732856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:30.248657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:44:43.493650
# Unit test for constructor of class ActionModule
def test_ActionModule():
	test = 1 # change the test variable to 0 for the real test
	if test:
		task = dict()
		connection = dict()
		play_context = dict()
		loader = dict()
		templar = dict()
		shared_loader_obj = dict()
		task_vars = dict()
		tmp = dict()
		
		action = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
		result = action.run(tmp, task_vars)
		assert "stdout" in result.keys()
		assert "stderr" in result.keys()
		assert "msg" in result.keys() 
		assert "rc" in result.keys()
		assert "cmd" in result.keys()



# Generated at 2022-06-23 08:44:44.530947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:44:52.585242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_spec = dict(
        chdir=dict(type='path'),
        _raw_params=dict(type='str'),
        _uses_shell=dict(type='bool', default=True),
        executable=dict(type='path', default=None),
        removes=dict(type='list'),
        creates=dict(type='path'),
        warn=dict(type='bool', default=True),
        stdin=dict(type='str'),
        stdin_add_newline=dict(type='bool', default=True)
    )
    # FROM ansible_f5_modules.plugins.module_utils.facts import Facts

# Generated at 2022-06-23 08:44:56.683418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(loader=None,
                        connection=None,
                        play_context=None,
                        new_stdin='',
                        share_loader=None,
                        task_vars=None,
                        disable_lookup=False,
                        task=None,
                        args=None) is not None

# Generated at 2022-06-23 08:45:04.588669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create mock objects
    task_vars = []
    templar = []
    shared_loader_obj = []
    loader = []
    connection = []
    play_context = []
    action_loader = []
    task = []
    module_name = []
    connection_info = []
    config = []
    shared_loader_obj = []
    task_vars = []

    # create ActionModule object with args from mock objects
    obj = ActionModule(task=task, connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

    # call run function of class ActionModule
    obj.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-23 08:45:06.677399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:45:07.406252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:45:09.066869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict(), dict(), dict(), dict(), dict())

# Generated at 2022-06-23 08:45:15.188779
# Unit test for constructor of class ActionModule
def test_ActionModule():
  task = {'action': 'shell', 'args': {'changed_when': ['foo']}, 'changed_when': ['bar']} # TODO: 'foo' and 'bar' are temporary
  connection = None
  play_context = None
  loader = None
  templar = None
  shared_loader_obj = None
  action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
  return action_module

# Generated at 2022-06-23 08:45:26.134902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_source =  dict

# Generated at 2022-06-23 08:45:29.457414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {
        "action": {
            "__ansible_module__": "shell",
            "__ansible_arguments__": "",
            "__ansible_action_args__": {}
        }
    }

    action_obj = ActionModule(config)

    assert type(action_obj) == ActionModule

# Generated at 2022-06-23 08:45:35.303539
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:45:41.444798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    with mock.patch("ansible.plugins.action.ActionBase") as action_base:
        am = ActionModule(action_base)
        am.run()
        action_base.assert_called_once_with()
        args = {'_uses_shell': True}
        action_base.call_args[1]['task'].args.setdefault.assert_called_once_with('_uses_shell', True)

# Generated at 2022-06-23 08:45:52.993402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    args['_uses_shell'] = True
    args['_raw_params'] = 'echo hello world'
    task = dict()
    task['args'] = args
    task['_ansible_parsed'] = True
    ansible_run_command_mock = dict()
    ansible_run_command_mock['rc'] = 0
    ansible_run_command_mock['stdout'] = 'hello world'
    connection = dict()
    connection['ansible_run_command'] = ansible_run_command_mock
    play_context = dict()
    play_context['become'] = False
    play_context['become_user'] = 'root'
    ansible_shell_executable = '/bin/sh'


# Generated at 2022-06-23 08:45:53.528133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:45:56.138797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.CommandAction
    comm_act_obj = ansible.plugins.action.CommandAction.ActionModule()
    import ansible.plugins
    ansible.plugins.ActionBase()
    #comm_act_obj.run()

# Generated at 2022-06-23 08:46:08.091124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class action_loader_obj:
        def get(self,str1,str2,str3,str4,str5,str6,str7):
            class ansible_command:
                def run(self,str1):
                    return 1
            return ansible_command()
    class shared_loader_obj:
        def __init__(self):
            self.action_loader = action_loader_obj()
    class connection_obj:
        def __init__(self):
            self.name = 'local'
    class task_obj:
        def __init__(self):
            self.args = {'_uses_shell':True}
    class play_context_obj:
        def __init__(self):
            self.connection = 'local'

# Generated at 2022-06-23 08:46:15.727265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    m_action_base = ActionBase()
    m_task_vars = {}

    # Act
    action_module = ActionModule(m_action_base._task, m_action_base._connection, m_action_base._play_context, m_action_base._loader, m_action_base._templar, m_action_base._shared_loader_obj)
    result = action_module.run(task_vars=m_task_vars)

    # Assert
    assert True



# Generated at 2022-06-23 08:46:20.694475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is a catch-all test for the constructor of class ActionModule.
    #
    # The constructor is somewhat complex, involving a mix of both
    # positional and keyword arguments, so we want to be sure all of
    # those use cases work.
    #
    # This also tests the setup of `self._task`, which is being used
    # in `ansible-doc -t action` to display the documentation.  We
    # want to be sure the documentation is available without
    # unexpected problems.

    # Constructor with task, connection, play_context, loader, templar, and shared_loader_obj as positional arguments
    task = dict(name='test_task', action=dict(module='test_module', args=dict(test_arg='test_value')))
    connection = object()
    play_context = object()

# Generated at 2022-06-23 08:46:21.163434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:46:26.418716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import is_exclusive_fact
    from collections import namedtuple

    from ansible.module_utils._text import to_text

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # create tasks that can be used to define a test play
    Tasks = namedtuple('Tasks', ['TASKS'])
    # create a list of tasks to perform

# Generated at 2022-06-23 08:46:31.373002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = Ansible()
    test_server = ansible.create_host(host_ip=socket.gethostbyname(socket.getfqdn()))
    play_context = PlayContext()
    actionModule = ActionModule()
    assert isinstance(actionModule, ActionBase)
    assert actionModule._task.args == {'_uses_shell': True}


# Generated at 2022-06-23 08:46:40.790351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule, AnsibleExitJson, AnsibleFailJson
    from ansible.module_utils._text import to_text
    from ansible.utils.command_loading import get_command_details

    class ModuleMock:

        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=None,
                     supports_check_mode=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_

# Generated at 2022-06-23 08:46:50.635399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class action_plugin():
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
        def run(self, tmp=None, task_vars=None):
            return

    action_module = ActionModule(action_plugin)

    func_list = dir(action_plugin)
    func_list.append('run')

    class_list = dir(action_module)

    for func in func_list:
        assert func in class_list

# Generated at 2022-06-23 08:46:54.623171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run is not None
    assert am._task.args['_uses_shell'] is True

# Generated at 2022-06-23 08:47:01.468251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a dict for task.args
    task_args = {}
    # Initialize a dict for task_vars
    task_vars = {}

    # Create an instance of class ActionModule
    cmd = ActionModule(task_args, task_vars)

    # invoke method run of class ActionModule
    # and assert the result for testing success
    assert cmd.run(task_vars=task_vars) == {}

# Generated at 2022-06-23 08:47:11.787783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run method"""
    # set up test objects
    class result:
        changed = True
        skipped = False
        failed = False
    class ansible_task:
        args = {'_uses_shell': True,
                'chdir': '/tmp',
                'creates': '/tmp/out.txt',
                'executable': None,
                'removes': '/tmp/out.txt',
                #'stdin': None,
                'stdin_add_newline': False,
                #'stdout': None,
                'warn': True}

    class ansible_connection:
        def __init__(self, orig_module_name, task, task_vars):
            self.orig_module_name = orig_module_name
            self.task = task

# Generated at 2022-06-23 08:47:12.591040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:47:14.748597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    proj = FakeProject()
    act = ActionModule(proj, {}, {}, 'test_connection')
    assert act is not None

# Generated at 2022-06-23 08:47:20.759533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert(module.run(tmp=1, task_vars=1) == 1)

# Generated at 2022-06-23 08:47:22.852231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule())

# Generated at 2022-06-23 08:47:33.802723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_object = ActionModule(connection=None,
                                       play_context=None,
                                       loader=None,
                                       templar=None,
                                       shared_loader_obj=None)

    ActionModule_object._shared_loader_obj.action_loader.get = mock.MagicMock()
    command_action_object = mock.MagicMock()
    command_action_object.run = mock.MagicMock()
    ActionModule_object._shared_loader_obj.action_loader.get.return_value = command_action_object
    ActionModule_object._task.args = {'cmd': 'echo $HOME'}

    result = ActionModule_object.run(task_vars=None)

    assert ActionModule_object._task.args['_uses_shell']
    ActionModule_object._shared_loader_

# Generated at 2022-06-23 08:47:41.457062
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.shell as shell

    wdir = "/tmp/ansible_test"
    command = ["ls", "-la", wdir]

    # Create test env
    setup_testenv(wdir)

    # Create test ActionModule
    action = shell.ActionModule(dict(command=command), None)

    # Create test task_vars
    task_vars = dict()

    # Execute test run
    result = action.run(None, task_vars)

    # Remove test env
    cleanup_testenv(wdir)

    # assert
    assert result["rc"] == 0
    assert result["changed"] == False
    assert result["cmd"] == " ".join(command)
    assert result["stdout"] != ""



# Generated at 2022-06-23 08:47:50.539492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization of test case
    x = dict(a=1,b=2,c=dict(d=4,e=5))
    tmp = "/tmp/test/test_action_test.sh"
    task_vars = dict(a_list=[1,2,3],b_list=[4,5,6],a_dict=x)
    module_loader = dict(name="command",args=dict(_uses_shell=True))
    connection = dict(name="local",args="", _update=dict(ansible_shell_executable="shell_name", ansible_python_interpreter="python_interpreter",ansible_shell_type="shell_type"))

# Generated at 2022-06-23 08:48:01.347275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    from ansible.plugins.action.script import ActionModule as script_constructor
    from ansible.plugins.action.command import ActionModule as command_constructor
    fd, fname = tempfile.mkstemp()

    # Test the constructor
    script_object = script_constructor(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert script_object._task == None
    assert script_object._connection == None
    assert script_object._play_context == None
    assert script_object._loader == None
    assert script_object._templar == None
    assert script_object._shared_loader_obj == None


# Generated at 2022-06-23 08:48:10.614926
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import os
    test_dir = os.path.dirname(__file__)
    sys.path.append(test_dir + "/../../../../")
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import StringIO

    # Create a class object for testing
    action_module = ActionModule()
    action_module._shared_loader_obj = StringIO()

    # Create a class object for testing
    test_task = StringIO()
    test_task._uuid = "test_uuid"
    test_task.args = {}
    test_task.args['_uses_shell'] = True

    action_module._task = test_task

    # Create a class object for testing with side effect
    test_connection = StringIO()

# Generated at 2022-06-23 08:48:21.850427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = "127.0.0.1"
    path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/action')
    module_utils_path = [path + '/module_utils']
    variable_manager = ansible.vars.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    connection = ansible.executor.connection_factory.create_connection(loader=loader, variable_manager=variable_manager)
    play_context = ansible.playbook.play_context.PlayContext()
    options = ansible.cli.CLI.base_parser(None, None, None, None, None).parse_args([])
    display = Display()

# Generated at 2022-06-23 08:48:30.570388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task_vars = {"temp_var":"Test Value"}

    # testing constructor
    test_action_module = ActionModule()
    assert test_action_module._task == None
    assert test_action_module._connection == None
    assert test_action_module._play_context == None
    assert test_action_module._loader == None
    assert test_action_module._shared_loader_obj == None
    assert test_action_module._templar == None
    assert test_action_module._task_vars == None
    assert test_action_module._tmp == None



# Generated at 2022-06-23 08:48:33.170870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("test_loader",
                        "test_connection",
                        "test_play_context",
                        "test_loader",
                        "test_templar",
                        "test_shared_loader_obj",
                        "test_task")

# Generated at 2022-06-23 08:48:35.570157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    abc = ActionModule()
    return True

# Generated at 2022-06-23 08:48:36.777714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-23 08:48:46.557244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars=dict(
        ansible_connection='local',
        ansible_ssh_common_args='-F /Users/kjones/.ssh/config',
        ansible_tmp_dir='/Users/kjones/.ansible/tmp',
        ansible_python_interpreter='/usr/local/bin/python',
        ansible_verbosity='0',
        ansible_version='2.4.2.0'
    )
    am = ActionModule(
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    r = am.run(
        tmp = None,
        task_vars=task_vars
    )
    print("r", r, type(r))

# Generated at 2022-06-23 08:48:53.659268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'default'


# Generated at 2022-06-23 08:49:04.628568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake action module
    class ActionModule(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self._task.args = {'_uses_shell': False}
            
        def run(self, tmp=None, task_vars=None):
            return {'results': task_vars['results']}
    # Create a fake action command

# Generated at 2022-06-23 08:49:11.108954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate class ActionModule
    action_module = ActionModule()

    # Check for class variables that may be changed during class initialization
    # pylint: disable=protected-access
    # Check instance variables
    assert action_module._shared_loader_obj == None
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    # Check class variables
    assert action_module._plugin_name == 'command'

# Generated at 2022-06-23 08:49:19.784188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.default import CallbackModule
    from ansible.parsing.dataloader import DataLoader

    class TestResult(TaskResult):

        def __init__(self, host, task, return_value=None, result=None):
            super(TestResult, self).__init__(host, task, return_value)
            self.result = result


# Generated at 2022-06-23 08:49:33.963279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager


    play_context = PlayContext()
    play_context.check_mode = True
    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager()
