

# Generated at 2022-06-23 08:39:36.766869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Create a mock task and mock args
  task_mock = Mock()
  task_mock.args = dict()
  task_mock.args['_uses_shell'] = True

  # Create a mock taskvars
  task_vars_mock = Mock()

  # Create a mock shared_loader_obj
  shared_loader_obj_mock = Mock()

  # Create a mock loader, templar and connection
  loader_mock = Mock()
  templar_mock = Mock()
  connection_mock = Mock()

  # Create a mock play_context
  play_context_mock = Mock()

  # Instantiate ActionModule class

# Generated at 2022-06-23 08:39:46.723782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up mocks
    tmp = None
    task_vars = None
    temp_action_base = ActionBase()
    temp_task = Mock()
    temp_task.args = {'_uses_shell': True}
    temp_connection = Mock()
    temp_play_context = Mock()
    temp_loader = Mock()
    temp_templar = Mock()
    temp_shared_loader_obj = Mock()
    temp_action_module = ActionModule(temp_task, temp_connection, temp_play_context, temp_loader, temp_templar, temp_shared_loader_obj)
    temp_command_action = temp_shared_loader_obj.action_loader.get.return_value

# Generated at 2022-06-23 08:39:51.710967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AnsibleModule = AnsibleModuleMock
    AnsibleModuleMock.run_command_return_value = 'value'

    task = TaskMock(['/home/ansible/ansible/lib/ansible/modules/commands/command.py'],{'name':'/bin/date'})
    loaderMock = mock()
    runner = RunnerMock()
    runner.runner_set_retval('ansible.legacy.command')

    connection = ConnectionMock(task, loaderMock, runner)
    playcontext = PlayContext()

    # test the method run of class ActionModule
    action = ActionModule(task, connection, playcontext, loaderMock, None, None, runner)
    assert action.run() == 'value'

    #test the method run_command

# Generated at 2022-06-23 08:39:55.140021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    am = ansible.plugins.action.shell.ActionModule(None, None, None, None, None)

    assert(isinstance(am,ansible.plugins.action.ActionBase))

# Generated at 2022-06-23 08:39:56.639833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule(None, None, None, None, None, None, None, None))

# Generated at 2022-06-23 08:40:02.162524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.name == 'debug'
    assert action.short_description == 'Print statements during execution'
    assert action.version == 1.0
    assert action.enabled_by_default == True
    assert action.action_type == 'normal'
    assert action.deprecated_action == 'command'
    assert action.deprecated_args == {'_uses_shell': True}


# Generated at 2022-06-23 08:40:07.281493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _task = object()
    _connection = object()
    _play_context = object()
    _loader = object()
    _shared_loader_obj = object()
    _templar = object()
    result = ActionModule(_task, _connection, _play_context, _loader, _shared_loader_obj, _templar)
    assert result

# Generated at 2022-06-23 08:40:17.085079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global conn
    global task
    global play
    global options
    global load
    global temp
    global action_loader
    global shared_loader_obj
    options = NamedDict()
    options.become = False
    options.become_user = 'root'
    play = NamedDict()
    play.options = options
    task = NamedDict()
    task.environment = {}
    task.args = {}
    task.environment['ANSIBLE_ACTION_PLUGINS'] = ''
    task.environment['ANSIBLE_CACHE_PLUGINS'] = ''
    task.environment['ANSIBLE_CALLBACK_PLUGINS'] = ''
    task.environment['ANSIBLE_CLI_COLOR'] = '1'
    task.environment['ANSIBLE_CONFIG'] = ''

# Generated at 2022-06-23 08:40:18.455790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of ActionModule class
    :return:
    """
    assert ActionModule('ActionModule')

# Generated at 2022-06-23 08:40:19.670635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:40:29.340678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test shell action with special arg and then the run method of ansible.command
    # action will be called.
    # But ansible.command action is out of scope, so we mock it.
    with patch(target='ansible.plugins.action.ActionBase.run') as mock_run:
        mock_run.return_value = '返回值'

        tmp = '/path/to/tmp'
        task_vars = dict()
        task_args = dict()
        task_args['_uses_shell'] = 'True'
        loader = ''
        templar = ''
        shared_loader_obj = ''

        task = Task()
        task.args = task_args

        action = ActionModule(task, 'connection', 'play_context', loader, templar,
                              shared_loader_obj)

# Generated at 2022-06-23 08:40:33.773723
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module is not None

# This module was originally a combined action plugin, but has since been split into two parts.
# This test verifies that the run function still works as expected.

# Generated at 2022-06-23 08:40:34.390925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:40:34.959169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:40:35.797844
# Unit test for constructor of class ActionModule
def test_ActionModule():
	my_action = ActionModule()

# Generated at 2022-06-23 08:40:36.303910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:40:44.881348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = dict(a=1, b=2, c=dict(d=3, e=4))
    m = ActionModule(b,
                     b,
                     "ansible.plugins.test_action_module",
                     "connection",
                     "play_context",
                     "loader",
                     "templar",
                     "shared_loader_obj")
    assert m._shared_loader_obj.a == b["a"]
    assert m._shared_loader_obj.b == b["b"]
    assert m._shared_loader_obj.c.d == b["c"]["d"]
    assert m._shared_loader_obj.c.e == b["c"]["e"]

# Generated at 2022-06-23 08:40:46.047821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ensure_passing_testcase(ActionModule, 'run', False)

# Generated at 2022-06-23 08:40:54.995056
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # SETUP
    #
    # The method run has as argument a dictionary with the keys
    # tmp and task_vars. The value of the key tmp is not used in
    # the method run. The value of the key task_vars is a dictionary
    # containing the variable for the task.

    # This is a first test. The variable AnsibleModule_shell_test1 has
    # the value foo.
    action_module_test1 = ActionModule(
        action_plugin_name='shell',
        action_plugin_getattr=None,
        action_plugin_args={'chdir': None},
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

# Generated at 2022-06-23 08:41:04.885094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

    from ansible.plugins.action.shell import ActionModule

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types

    from ansible.plugins.loader import ActionModuleLoader

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)

    action_module_loader = ActionModuleLoader()
    assert isinstance(action_module_loader, object)


# Generated at 2022-06-23 08:41:06.711271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(loader=None, shared_loader_obj=None, path=None)
    assert True == a.bypass_checks

# Generated at 2022-06-23 08:41:12.824202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # a simple unit test to confirm that constructor of ActionModule
    # has not been changed
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-23 08:41:20.908405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test constructor of class ActionModule'''
    import copy

    # Create a simple module arguments format

# Generated at 2022-06-23 08:41:29.335625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {"args": {"echo": "Hello world"}}
    play_context = {"check_mode": False}
    ansible_connection_mock = object()
    shared_loader_obj = object()

    action_module = ActionModule(task, play_context, ansible_connection_mock, shared_loader_obj)

    assert action_module._task == task
    assert action_module._play_context == play_context
    assert action_module._connection == ansible_connection_mock
    assert action_module._shared_loader_obj == shared_loader_obj

# Generated at 2022-06-23 08:41:31.393967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    class ActionModule_Task():
        pass
    action_module._task = ActionModule_Task()

# Generated at 2022-06-23 08:41:32.238854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-23 08:41:35.113115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Used to test the different code paths in the run method of class ActionModule.
    """

    pass


# Generated at 2022-06-23 08:41:36.916600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    ActionModule()
    #assert

# Generated at 2022-06-23 08:41:42.584631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(connection=None,
                              task=None,
                              play_context=None,
                              loader=None,
                              templar=None,
                              shared_loader_obj=None)
    assert(action_mod != None)

# Generated at 2022-06-23 08:41:45.140396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action

# Generated at 2022-06-23 08:41:47.421774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert len(module) > 0


# Generated at 2022-06-23 08:41:52.039222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        obj = ActionModule('ansible_temp_dir', 'delegated_vars', 'display', 'task', 'loader', 'templar', 'shared_loader_obj', 'connection', 'play_context')
    except Exception as e:
        assert(False)
    else:
        assert(True)


# Generated at 2022-06-23 08:41:57.629705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell as sh
    try:
        s = sh.ActionModule(None, None, None, None, None, 'local')
    except Exception as e:
        print("***FAIL***: Unexpected exception! {}".format(str(e)))

# Generated at 2022-06-23 08:42:01.642151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self):
        pass
    actionmodule = ActionModule()
    assert actionmodule._shared_loader_obj is None
    assert actionmodule._loader is None
    assert actionmodule._templar is None
    assert actionmodule._connection is None
    assert actionmodule._play_context is None
    assert actionmodule._task is None
    assert actionmodule._loader_name is None

# Generated at 2022-06-23 08:42:12.002333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    fact_collector = DistributionFactCollector()
    distribution = fact_collector.collect(dict(), dict())
    distribution_name = distribution['distribution']
    # 'distribution' has a value of 'None' under both Windows and OS X.
    # On Windows, the value of 'distribution' is 'Windows' for some reason.
    if not distribution_name:
        distribution_name = 'Windows'
    elif distribution_name == 'None':
        distribution_name = 'Darwin'

    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(ansible_facts=dict(distribution=distribution_name)))

    my_module = ActionModule

# Generated at 2022-06-23 08:42:14.128650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Start')
    module = ActionModule()
    task_vars = dict()
    module.run(task_vars=task_vars)
    print('End')

# Generated at 2022-06-23 08:42:22.239344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO

    # Mock an TaskExecutor in order to call the method run of ActionModule class
    class MockTaskExecutor(object):
        def __init__(self):
            self.loader = None
            self.connection = None
            self.play_context = None
            self.shared_loader_obj = None

        def get(loader, task=None, connection=None, play_context=None, templar=None, shared_loader_obj=None):
            self.loader = loader
            self.connection = connection
            self.play_context = play_context
            self.shared_loader_obj = shared_loader_obj
            return MockActionModule()
        p= MockTaskExecutor()
        return p


# Generated at 2022-06-23 08:42:23.081776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-23 08:42:28.018118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up
    task_vars_input = {'greet': 'hello'}
    action_base_input = {'templar': 'pytest.slave'}
    action_module_input = {'_task': {'args': {'_uses_shell': True}}}
    # excute
    action_module = ActionModule(**action_base_input)
    action_module.run(task_vars=task_vars_input, **action_module_input)
    # verify
    # - no assert



# Generated at 2022-06-23 08:42:30.274415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert not module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:42:39.710724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    import os
    import sys

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    test_string = 'Hello World'

    # Make sure we are in the right directory
    this_file = os.path.abspath(__file__)
    if os.path.dirname(this_file).endswith('test/unit/plugins/strategies'):
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(this_file))))
        sys.path.append(base_dir)

    from ansible.module_utils.remote_management.common.shell import ShellError

# Generated at 2022-06-23 08:42:41.539290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-23 08:42:44.656711
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an instance of class ActionModule
    action_module = ActionModule()

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:42:50.154484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    actionmodule._task.args = {'_uses_shell': True}
    actionmodule._shared_loader_obj = 'shared_loader_obj'
    actionmodule._task = '_task'
    actionmodule._connection = '_connection'
    actionmodule._play_context = '_play_context'
    actionmodule._loader = '_loader'
    actionmodule._templar = '_templar'
    result = actionmodule.run(tmp='tmp', task_vars='task_vars')
    assert result == 'result'

# Generated at 2022-06-23 08:43:00.317019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test ansible.modules.system.service.Service Module
    import ansible.modules.system.service as service
    import ansible.modules.system.user as user
    import ansible.modules.system.group as group
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import module_loader

    # Initialize needed objects
    loader = None
    variable_manager = VariableManager()
    variable_manager._extra_vars = {
        "ansible_ssh_user": "vagrant",
        "ansible_ssh_pass": "vagrant",
        "ansible_ssh_host": "localhost",
        "ansible_ssh_port": 2222,
    }
    inventory

# Generated at 2022-06-23 08:43:00.969042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    return a

# Generated at 2022-06-23 08:43:12.444684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit tests for method 'run' of class 'ActionModule'."""
    # # TODO: Provide a real test here.
    # def test_template(in_file, out_file, in_vars):
    #     '''
    #     Template something.
    #     '''
    #     from ansible import template
    #     with open(in_file, 'r') as f:
    #         text = f.read()
    #     t = template.AnsibleTemplate(text, in_vars)
    #     with open(out_file, 'w') as f:
    #         f.write(t.template())
    #
    # test_template('ActionModule_run_test.j2', 'ActionModule_run_test.out', {})

# Generated at 2022-06-23 08:43:17.741838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        _action_module = ActionModule(
            task=None,
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None
        )
    except Exception as e:
        print(e)


# Generated at 2022-06-23 08:43:19.745720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:43:25.842801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell as shell

    # __init__() returns a shell.ActionModule object
    obj = shell.ActionModule(
        {
            'name': 'test',
            '_ansible_verbosity': 3,
            '_ansible_version': (2, 4, 0),
            '_ansible_no_log': False
        },
        "test",
        "test",
        "test",
        "test",
        "test",
        "test"
    )

    assert isinstance(obj, shell.ActionModule) is True

# Generated at 2022-06-23 08:43:27.843721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: unit test this
    pass

# Generated at 2022-06-23 08:43:36.958215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(args={'_uses_shell': True}),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    context = dict(
        runner=dict(
            action_loader={
                'get': lambda *args, **kwargs: dict(
                    run=lambda *args, **kwargs: dict(
                        changed=False,
                    )
                )
            }
        )
    )
    with patch.dict('ansible.plugins.action.ActionModule.__dict__', context):
        result = module.run()

    assert result == dict(changed=False)

# Generated at 2022-06-23 08:43:44.208306
# Unit test for constructor of class ActionModule
def test_ActionModule():
   action_module = ActionModule(
       task=1,
       connection=2,
       play_context=3,
       loader=4,
       templar=5,
       shared_loader_obj=6)
   assert type(action_module) == ActionModule
   assert action_module._task == 1
   assert action_module._connection == 2
   assert action_module._play_context == 3
   assert action_module._loader == 4
   assert action_module._templar == 5
   assert action_module._shared_loader_obj == 6

# Generated at 2022-06-23 08:43:47.024190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create ActionModule class object
    obj = ActionModule(
        task = None,
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    # check the instance
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-23 08:43:47.712381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:43:50.929058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    print("test_ActionModule: ", am)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:43:54.624133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(task=dict(action=dict(module_name="shell", args=dict(a="b"))), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module_return = mod.run()

# Generated at 2022-06-23 08:43:57.977705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None, 'constructor returned object reference of None'
    assert isinstance(action, ActionModule), 'constructor did not return object of type ActionModule'

# Generated at 2022-06-23 08:44:07.861619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    expected_response = {
        'async': 0,
        'changed': False,
        'cmd': u'/bin/true',
        'delta': '0:00:00.002388',
        'end': '2017-09-15 22:52:27.682681',
        'failed': False,
        'invocation': {
            'module_args': {}
        },
        'rc': 0,
        'start': '2017-09-15 22:52:27.680293',
        'stderr': '',
        'stdout': '',
        'warnings': []
    }
    action_task = ActionModule()
    task_vars = {
        'ansible_play_batch': '1'
    }

# Generated at 2022-06-23 08:44:09.079132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:11.802195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None, None, None)
    assert a is not None
    assert isinstance(a, ActionBase)


# Generated at 2022-06-23 08:44:12.356401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:13.596186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action = ActionModule(None, None)
  action.run(None, None)

# Generated at 2022-06-23 08:44:14.645978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:44:15.312792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:16.421066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:20.130463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:44:20.665892
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    am = ActionModule()

# Generated at 2022-06-23 08:44:29.175164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil

    # The test dir
    test_dir = os.path.dirname(os.path.abspath(__file__))

    # The source dir
    test_modules_dir = os.path.join(test_dir, '..', '..', 'lib', 'ansible', 'modules', 'commands')
    test_module_name = os.path.join(test_modules_dir, 'shell.py')

    # Copy the module to the test dir
    test_module_tmp = os.path.join(test_dir, os.path.basename(test_module_name))
    shutil.copyfile(test_module_name, test_module_tmp)

    # Change the cwd to the test dir
    cwd = os.getcwd

# Generated at 2022-06-23 08:44:30.765956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule()
    assert ac.run is not None

# Generated at 2022-06-23 08:44:33.860333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.ActionModule import ActionModule
    from ansible.plugins.action.ActionModule import _DEFAULT_TIMEOUT
    from ansible.plugins.loader import find_plugin
    action_module = find_plugin('action', 'ActionModule')
    assert action_module == ActionModule

# Generated at 2022-06-23 08:44:36.546092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(MyActionModule, self).run(tmp, task_vars)

    am = MyActionModule()
    assert am.run() == None

# Generated at 2022-06-23 08:44:37.156514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:44.757964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.solr.utils import dict_merge
    from ansible.solr.launcher import SolrLauncher
    from solrcloudpy import SolrConnection
    from solrcloudpy.connection import SolrConnection
    import tempfile
    import time
    import json

    fake_loader = Data

# Generated at 2022-06-23 08:44:45.151770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:44:57.147006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # has no effect
    tmp = {'ansible_facts': {'a': 1}}

    task_vars = {'ansible_facts': {'a': 1}}

    result = {'failed': False, 'changed': False}
    import inspect
    import sys

    # Gather module parameters
    task_args = {'_uses_shell': True}

    # Perform the action
    action = ActionModule()
    current_dir = inspect.getfile(inspect.currentframe())
    current_dir = os.path.dirname(os.path.abspath(current_dir))
    sys.path.append(current_dir)
    import ansible.plugins

# Generated at 2022-06-23 08:44:59.781504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("testing ActionModule()")
    action_module = AnsibleModule()
    assert(action_module.test == True)
    print("test complete for ActionModule()")

# Generated at 2022-06-23 08:45:04.053870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(loader=None,
                     connection=None,
                     play_context=None,
                     new_stdin=None,
                     new_stdout=None,
                     new_stderr=None,
                     task_uuid=None)
    assert a is not None

# Generated at 2022-06-23 08:45:04.530491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:45:16.222530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_mock = {'run': lambda self, task_vars=None: task_vars}
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Set the command module
    action_module._shared_loader_obj.action_loader.get = \
        lambda a, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None: command_mock
    task_vars = {'test': 'var'}
    result = action_module.run(None, task_vars=task_vars)
    assert result == task_vars

# Generated at 2022-06-23 08:45:27.138071
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create a instance mock for class ModuleUtils
    # class ModuleUtils
    class mock_ModuleUtils:
        def __init__(self):
            pass

    # create a instance mock for class ComplexCore()
    # class ComplexCore
    class mock_ComplexCore:
        def __init__(self):

            # Specify ansible version
            self.ANSIBLE_VERSION = '2.9.6'

            # Specify ansible version as string
            self.ansible_version = '2.9.6'

    # create instance mock for class Connection
    # class Connection
    class mock_Connection:
        def __init__(self):
            pass

    # create instance mock for class AnsibleLoader
    # class AnsibleLoader
    class mock_AnsibleLoader:
        def __init__(self):
            pass



# Generated at 2022-06-23 08:45:34.316352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test that the constructor of ActionModule does not throw an exception"""
    hostvars = dict()
    tmp = None
    task_vars = dict(hostvars=hostvars)

    # NOTE: The values of these parameters do not matter, as long as they are not None
    task = dict()
    connection = dict()
    play_context = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()

    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    action_module.run(task_vars=task_vars)

# Generated at 2022-06-23 08:45:37.058501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test constructor of ActionModule """
    action_module = ActionModule(None, None, None)
    assert action_module is not None


# Generated at 2022-06-23 08:45:37.782420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(True)

# Generated at 2022-06-23 08:45:38.342503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:45:49.439379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook import role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import playbook_executor

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    from sys import argv

    options = argv
    options[C.DEFAULT_MODULE_NAME] = 'shell'

# Generated at 2022-06-23 08:45:53.164871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_ActionModule = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert True == m_ActionModule.run()

# Generated at 2022-06-23 08:45:54.781451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-23 08:45:56.448160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(ActionModule().run() == None)

# Generated at 2022-06-23 08:46:03.219910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock 
    class MockAction(ActionModule):
        def __init__(self, *args, **kwargs):
            pass
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect
            return 0
    # execute
    action = MockAction()
    # assert
    assert action.run() == 0

# Generated at 2022-06-23 08:46:08.291092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    tmp_action = ansible.plugins.action.ActionBase()
    action = ansible.plugins.action.ActionModule(tmp_action._shared_loader_obj,
                                                 tmp_action._connection,
                                                 tmp_action._play_context,
                                                 tmp_action._loader,
                                                 tmp_action._templar,
                                                 tmp_action._task)
    assert action is not None


# Generated at 2022-06-23 08:46:09.674129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:46:19.349155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import sys
    import unittest
    from mock import MagicMock
    from compiler.syntax import check
    import ansible.plugins.action as action
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    #from ansible.plugins.action import ActionBase

    sys.modules['ansible.plugins.action.ActionBase'] = MagicMock(ActionBase)
    sys.modules['ansible.plugins.action.ActionBase'].ActionBase = ActionBase
    sys.modules['ansible.plugins.action.ActionBase'].ActionBase.__name__ = 'ActionBase'


    # ToDo : add unittest for all the methods

# Generated at 2022-06-23 08:46:25.115032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._task.args = {"_uses_shell": False}
    mod._shared_loader_obj.action_loader.get = lambda x, **kwargs: x
    ret = mod.run(task_vars={"ansible_check_mode": False})
    assert ret == "ansible.legacy.command"

# Generated at 2022-06-23 08:46:27.922298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None, None)
    assert isinstance(actionModule, ActionModule)

# Generated at 2022-06-23 08:46:28.603442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-23 08:46:35.761359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    result = {"failed" : True, "msg" : "Sample Msg"}
    
    instance = ActionModule()
    instance._task = None
    instance._connection = None
    instance._play_context = None
    instance._loader = None
    instance._templar = None
    instance._shared_loader_obj = None
    instance._task.args = {"_uses_shell" : True}

    class FakeActionModule_Run:
        def run(self, task_vars):
            return result
    instance._shared_loader_obj.action_loader.get = lambda x, task, connection, play_context, loader, templar, shared_loader_obj: FakeActionModule_Run()
    
    assert instance.run() == result

# Generated at 2022-06-23 08:46:36.457274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:46:42.233984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None,task_vars=None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:46:46.483184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Create an ActionModule object, then call the run method with test values '''

    # Create an object of class ActionModule and store it in variable obj
    obj = ActionModule()
    # Test run method of class ActionModule with test values
    result = obj.run()
    # Check the results
    assert result == "Test Result"

# Generated at 2022-06-23 08:46:53.515042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import connection_loader, action_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.dataloader import DataLoader

    #
    #  Setup a class containing the definition of a single task
    #     { "action": { "module": "parkme_module" } }
    #     As an alternative to the definition below, we could use
    #        the following definition which is the equivalent
    #        datastructure (but not a pythonic definition).
    #     {


# Generated at 2022-06-23 08:47:04.578851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global ActionModule
    from ansible.module_utils.ansible_modlib_shell import ShellModule

    # Create instance of class ActionModule
    obj = ActionModule(None, dict(temp='Molokai', _uses_shell=False, _ansible_no_log=False), None, None,
                       None, None, None)
    assert obj is not None

    # Mocking private method
    def _execute_remote_command(self, cmd, tmp_path, sudo_user=None, sudoable=False, executable='/bin/sh'):
        return 'done'

    setattr(obj, '_execute_remote_command', _execute_remote_command)

    # Test method run with params wants_json=False and use_unsafe_shell=False

# Generated at 2022-06-23 08:47:12.872182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ModuleResult(object):
        def __init__(self):
            self.invocation = dict()
            self.invocation['module_name'] = "shell"


    class Task(object):
        def __init__(self):
            self.args = dict()
            self.args['_uses_shell'] = True


    class MockModuleLoader(object):
        def __init__(self):
            self._module_path = None
            self._no_local_paths = None
            self.get_patterns = None
            self.has_plugin = False
            self._find_plugin = None


    class MockModule(object):
        def __init__(self):
            self.check_mode = False
            self.no_log = False
            self.run_command = None
            self.handle_aliases

# Generated at 2022-06-23 08:47:26.207408
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeProxy

    from ansible.module_utils.common.removed import RemovedInAnsible30Module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    class AnsibleModule_user_group(AnsibleModule):
        def fail_json(self, **kwargs):
            assert 'msg' in kwargs, \
                   "fail_json() was called, but there is no 'msg' key in the arguments"

        def exit_json(self, **kwargs):
            assert 'changed' in kwargs, \
                   "exit_json() was called, but there is no 'changed' key in the arguments"

            args={'result': kwargs}
            return args

    module = Ans

# Generated at 2022-06-23 08:47:32.087918
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_action = ActionModule(connection=None,
                               play_context=None,
                               loader=None,
                               templar=None,
                               shared_loader_obj=None)

    assert test_action._shared_loader_obj is None
    assert test_action._connection is None
    assert test_action._play_context is None
    assert test_action._loader is None
    assert test_action._templar is None

# Generated at 2022-06-23 08:47:33.481698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    assert True

# Generated at 2022-06-23 08:47:41.512882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook import Play
    import ansible.constants as C
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible import context
    import json
    import pytest
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-23 08:47:42.222888
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass

# Generated at 2022-06-23 08:47:43.963387
# Unit test for constructor of class ActionModule
def test_ActionModule():

  # Test for initialization
  test_ActionModule = ActionModule()
  assert test_ActionModule != None

# Generated at 2022-06-23 08:47:44.829022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:47:52.846513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.templating import Templar
    from ansible.playbook import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.executor.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-23 08:48:04.005914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test for ActionModule constructor')
    module = ActionModule(
            {
                'name': 'test',
                'module_args': 'test_args'
            },
            {
                '_ansible_no_log': False,
                '_ansible_debug': False,
                '_ansible_verbosity': 4,
            },
            {
                'playbook_dir': 'playbook_dir'
            },
            {

            },
            {

            },
            {

            },
            None,
            'ansible'
        )
    task_vars = {
        'inventory_hostname': 'localhost'
    }

    try:
        module.run(task_vars=task_vars)
    except AttributeError:
        print('This test has failed')

# Generated at 2022-06-23 08:48:05.507559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case not implemented
    assert False

# Generated at 2022-06-23 08:48:06.898496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-23 08:48:08.770602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Build arguments for test
    # Build class instance
    obj = ActionModule()
    # Test method
    obj.run()

# Generated at 2022-06-23 08:48:10.484179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:48:13.076939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:18.020395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    # Test object type
    assert isinstance(a, object)
    # Test inheritance
    assert isinstance(a, ActionBase)
    # Test class of object
    assert a.__class__.__name__ == 'ActionModule'
    # Test number of methods
    assert len(dir(a)) == 2

# Generated at 2022-06-23 08:48:18.659247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:19.491274
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: implement test
    pass

# Generated at 2022-06-23 08:48:25.948549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class test_task(object):
        def __init__(self, args, task_vars, name):
            self.args = args
            self.task_vars = task_vars
            self.name = name
        def _execute(self):
            pass

    class ActionModule_class(ActionModule):
        def run(self):
            pass

    task = test_task('args', {'task_vars': 'var'}, 'test_name')
    am = ActionModule_class(task, 'connection', 'play_context', 'loader', 'templar', 'shared_loader_obj')
    assert am._task == 'args'
    assert am._connection == 'connection'
    assert am._play_context == 'play_context'
    assert am._loader == 'loader'

# Generated at 2022-06-23 08:48:28.589125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    assert mod.run() == 0

# Generated at 2022-06-23 08:48:29.474508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:30.729090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-23 08:48:31.332309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:48:42.107992
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class MockTemplar:
        pass

    mock_loader = [1]
    mock_connection = [2]
    mock_tqm = [3]
    mock_shared_loader_obj = [4]
    mock_task = [5]
    mock_variable_manager = [6]
    mock_loader_obj = [7]

    test_obj = ActionModule(mock_loader, mock_connection, mock_tqm, mock_shared_loader_obj, mock_task, mock_variable_manager, mock_loader_obj)
    assert test_obj._loader == mock_loader
    assert test_obj._connection == mock_connection
    assert test_obj._tqm == mock_tqm
    assert test_obj._shared_loader_obj == mock_shared_loader_obj
    assert test_obj._task

# Generated at 2022-06-23 08:48:44.601352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(None,None,None,None,None,None)
    result = mod.run()
    assert result['rc'] == 0

# Generated at 2022-06-23 08:48:53.577289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_tmp = Mock()
    m_task_vars = {}
    m_task = Mock()
    m_task.args = {'_raw_params': 'echo hi'}

    m_connection = Mock()
    m_play_context = Mock()
    m_loader = Mock()
    m_templar = Mock()
    m_shared_loader_obj = Mock()
    action_module = ActionModule(task=m_task, connection=m_connection,
                                 play_context=m_play_context, loader=m_loader,
                                 templar=m_templar, shared_loader_obj=m_shared_loader_obj)

    command_action = Mock()
    command_action.run = Mock(return_value='ok')
    m_shared_loader_obj.action_loader.get

# Generated at 2022-06-23 08:48:56.409069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-23 08:48:57.234763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:58.990208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Method run() has no test for now.")

# Generated at 2022-06-23 08:49:06.318949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.cli.playbook import PlaybookCLI

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import action_loader

    #setup
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["test_hosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 08:49:16.229378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Describe the argument:
    tmp = '1'
    task_vars = '2'
    action_base_obj = ActionBase()
    action_module_obj = ActionModule(action_base_obj._task, action_base_obj._connection, action_base_obj._play_context, action_base_obj._loader, action_base_obj._templar, action_base_obj._shared_loader_obj)
    action_module_obj._task.args = {}
    action_module_obj.run(tmp, task_vars)
    # Verify if the argument '_task' size is one:
    assert len(action_module_obj._task.args) == 1


test_ActionModule_run()

# Generated at 2022-06-23 08:49:22.525904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import b
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    module_name = 'nop'
    fixture_path = 'v2_playbook_plugins/action_plugins/'
    t1 = Task()
    t1.action = 'debug'
    t1.args['msg'] = 'test_action_module'
    t1._role = None
    t1._block = None
    t1._loader = action_loader
    t1.dep_chain = None
    t1.loop = None
    t1._parent = None
    t1._play = Play().load({}, variable_manager=None, loader=None)

# Generated at 2022-06-23 08:49:23.619493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run'), "ActionModule has no method 'run'"

# Generated at 2022-06-23 08:49:33.465393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))
    variable_manager._extra_vars = load_extra_vars(loader=loader, options=options)
    variable_manager.set_vars({'var': 'value'})

    command_action = ActionModule(
        task=Task(),
        connection=Connection(),
        play_context=PlayContext(),
        loader=loader,
        templar=Templar(loader=loader),
        shared_loader_obj=None)

    assert command_action is not None