

# Generated at 2022-06-23 08:39:30.386281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:39:38.136141
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:39:39.330488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None)

# Generated at 2022-06-23 08:39:40.361513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:39:41.027551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-23 08:39:48.406087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    module = mock.MagicMock()
    module.check_mode = False
    delattr(module, 'exit_after_cli')
    delattr(module, 'modeswitch_async')
    module.ems_logging = False
    module.auto_commit = True
    module.running_config = None
    module.default_output = 'text'
    module.parse_output = 'json'
    task = mock.MagicMock()
    task_vars = dict(
        hostvars=dict(
            localhost=dict(ansible_facts=dict(ansible_net_hostname='test_host'))
        )
    )
    task.args = dict(
        _uses_shell=True
    )
    connection = mock.MagicMock()
   

# Generated at 2022-06-23 08:39:50.437920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=object(), connection=object(), play_context=object(), loader=object(),
                          templar=object(), shared_loader_obj=object()) is not None

# Generated at 2022-06-23 08:40:00.531009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection(object):
        def __init__(self, play_context):
            self.play_context = play_context

    class Loader(object):
        pass

    class PlayContext(object):
        pass

    class Task(object):
        def __init__(self, args=None):
            self.args = args

    class Templar(object):
        pass

    class SharedLoaderObj(object):
        def __init__(self):
            class ActionLoader(object):
                def get(self, name, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
                    return name

            self.action_loader = ActionLoader()

    ansible_connection = Connection(PlayContext())
    ansible_loader = Loader()
    ansible_tem

# Generated at 2022-06-23 08:40:04.056146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Create an instance of ActionModule
    actionModule = ActionModule()
    
    # Call method run of class ActionModule
    actionModule.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:40:05.938056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    mod = ActionModule()
    assert mod is not None

# Generated at 2022-06-23 08:40:11.907115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(
        play_context=None,
        connection=None,
        task=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    task_vars = dict()
    result = mod.run(task_vars=task_vars)
    print(result)

# Generated at 2022-06-23 08:40:15.340622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for method run of class ActionModule
    # test #1
    a = ActionModule()
    command_action = a.run()
    assert(a is not None)
    assert(command_action is not None)


# Run all the tests
test_ActionModule_run()

# Generated at 2022-06-23 08:40:28.429534
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:40:39.162871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C

    class MockTask(object):
        pass

    class MockConnection(object):
        pass

    class MockActionBase(object):
        pass

    class MockTemplar(object):
        pass

    class MockLoader(object):
        pass

    class MockSharedLoaderObj(object):
        pass

    class MockPlayContext(object):
        pass

    class MockActionLoaderObject(object):
        pass

    class MockLegacyCommand(object):
        pass

    module = ActionModule(
        task=MockTask(),
        connection=MockConnection(),
        play_context=MockPlayContext(),
        loader=MockLoader(),
        templar=MockTemplar(),
        shared_loader_obj=MockSharedLoaderObj()
    )

    # create mocks
    task

# Generated at 2022-06-23 08:40:48.294280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating a mock connection object and assigning it to an instantiated class
    temp1 = ActionBase._load_params()
    temp2 = ActionBase(connection=None,
                       play_context=None,
                       loader=None,
                       templar=None,
                       shared_loader_obj=None)
    temp2._task = temp1.copy()

    temp3 = ActionModule(connection=None,
                         play_context=None,
                         loader=None,
                         templar=None,
                         shared_loader_obj=None)
    temp3._task = temp1.copy()

    assert temp2._task == temp3._task
test_ActionModule()

# Generated at 2022-06-23 08:40:50.713068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run = lambda x, y: x + y

    assert action_module.run(3, 2) == 5

# Generated at 2022-06-23 08:40:52.474880
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    assert module.run() == 'action.run'

# Generated at 2022-06-23 08:41:02.096074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'args': {'_uses_shell': True}}
    loader = None
    connection = None
    play_context = None
    templar = None
    shared_loader_obj = None
    am = ActionModule(task, loader, connection, play_context, templar, shared_loader_obj)
    assert (am.task == task)
    assert (am.loader == loader)
    assert (am.connection == connection)
    assert (am.play_context == play_context)
    assert (am.templar == templar)
    assert (am._shared_loader_obj == shared_loader_obj)



# Generated at 2022-06-23 08:41:09.198208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule should set the attributes
    # "_task", "_connection", "_play_context", "_loader", "_templar" and "_shared_loader_obj"
    action_module = ActionModule()
    task = action_module._task
    connection = action_module._connection
    play_context = action_module._play_context
    loader = action_module._loader
    templar = action_module._templar
    shared_loader_obj = action_module._shared_loader_obj


# Generated at 2022-06-23 08:41:09.818709
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    return 0

# Generated at 2022-06-23 08:41:10.678914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:41:13.512530
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test
    action_module = ActionModule()

    result = action_module.run(tmp=None, task_vars=None)

    assert (result is None)

# Generated at 2022-06-23 08:41:15.582449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    shared_loader_obj = {}
    ac = ActionModule(task, shared_loader_obj)
    assert ac.name == 'shell'

# Generated at 2022-06-23 08:41:17.643877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({'name': 'shell_module'})
    assert action_module is not None

# Generated at 2022-06-23 08:41:19.453474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    result = ActionModule.run(args)
    assert result == 'ActionModule'

# Generated at 2022-06-23 08:41:20.067999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:41:30.599610
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action
    import ansible.plugins.action.command
    from ansible.plugins.action import command

    import ansible.module_utils.basic
    import ansible.module_utils.six
    from ansible.module_utils.basic import AnsibleModule

    import ansible.constants
    from ansible.constants import DEFAULT_MODULE_NAME
    from ansible.constants import DEFAULT_MODULE_ARGS

    from ansible.template import Templar

    from ansible.plugins.loader import action_loader

    from ansible.plugins.loader import module_loader

    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.connection_plugins.local
    import ansible.inventory.manager
    import ansible.playbook.play_context
    import ansible

# Generated at 2022-06-23 08:41:39.041523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	from ansible.plugins.action.shell import ActionModule


	task = 1
	connection = 1
	play_context = 1
	loader = 1
	templar = 1
	shared_loader_obj = 1

	am = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

	tmp = 1
	task_vars = 1
	result = am.run(tmp, task_vars)

	# Check that result is None, which would be the case when calling ActionModule.run
	assert (result is None), "should be None - result of action.run()"

# Generated at 2022-06-23 08:41:46.889858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	actionModule = ActionModule()
	print ("Starting test for method: run")
	print ("test 1")
	actionModule.run(tmp=None, task_vars=None)
	print ("test 2")
	actionModule.run(tmp=None, task_vars=[])
	print ("test 3")
	actionModule.run(tmp=None, task_vars=[None])
	print ("test 4")
	actionModule.run(tmp=1, task_vars=None)
	print ("test 5")
	actionModule.run(tmp=1, task_vars=[])
	print ("test 6")
	actionModule.run(tmp=1, task_vars=[None])
	print ("Finished test for method: run")

test_ActionModule_run()

# Generated at 2022-06-23 08:41:48.201952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # Nothing to test

# Generated at 2022-06-23 08:41:48.788131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-23 08:41:49.739189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-23 08:41:50.688442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-23 08:41:51.250984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:42:02.451609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.connection.local import Connection
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.executor.play_context import PlayContext
    from ansible.executor.process.result import ResultCallback
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import connection_loader, module_loader
    import collections

    loader_obj = collections.namedtuple('loader_obj', ['module_loader', 'connection_loader'])
    loader_obj.module_loader = module_loader
    loader_obj.connection

# Generated at 2022-06-23 08:42:07.518830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action='unit_test', args={'a': 1}),
        connection=None,
        play_context=dict(play_hosts=None),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    action_module.run()

# Generated at 2022-06-23 08:42:09.648074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionModule is not None

# Generated at 2022-06-23 08:42:13.505060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    import ansible.plugins.action
    action_module = ActionModule()
    assert isinstance(action_module, ansible.plugins.action.ActionModule)

# Generated at 2022-06-23 08:42:21.989748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.dir import InventoryDirectory
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create Task object with arguments
    task_args = dict()
    task_args['_raw_params'] = 'ls -l'
    task_args['_uses_shell']

# Generated at 2022-06-23 08:42:27.854846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.command import ActionModule as cm
   
    import ansible.plugins.loader as loader
    import ansible.plugins.action.command as action_command

    ansible_instance = cm(loader.ActionModuleLoader,
                          connection=cm.connection,
                          templar=None,
                          task_vars=None)

    assert type(ansible_instance) == action_command.ActionModule

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:42:28.510712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:42:38.012588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    os.environ['ANSIBLE_IGNORE_PLUGINS'] = 'action'
    import tempfile
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import TaskStrategyBase
    from ansible.inventory.host import Host
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-23 08:42:40.395348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('a', 'b', 'c', 'd', 'e', 'f', 'g')

# Generated at 2022-06-23 08:42:41.995350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:42:49.852930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    print("Unit test method 'run'")
    print("test with empty input")
    result = am.run(task_vars={})
    print("expected: {'failed': 1, 'msg': 'shell requires executable argument'}")
    print("actual: " + str(result))
    print()
    print("test with valid input, no additional parameters")

# Generated at 2022-06-23 08:42:50.568132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:43:00.317956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of ActionModule """
    # pylint: disable=no-member
    #
    # [Test Case]
    # 1. Constructor of ActionModule will create an object of ActionBase.
    #    - If the object of ActionBase is created successfully,
    #      the test will pass.
    #
    # [Expected Result]
    # 1. An object of ActionBase will be created successfully.
    #
    # pylint: enable=no-member
    dummy_task = dict()
    #assert isinstance(ActionModule(dummy_task, dict()), ActionBase), 'Constructor of ActionModule does not create an object of ActionBase.'
    print(isinstance(ActionModule(dummy_task, dict()), ActionBase))


# Generated at 2022-06-23 08:43:05.307942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an action module object
    ActionModule_obj = ActionModule(None, None, None, None, None, None)

    # Test the method run of class ActionModule
    ActionModule_obj.run(None)



# Generated at 2022-06-23 08:43:14.536120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import ansible.plugins.action.shell
    from ansible.plugins.action.command import ActionModule as CommandActionModule
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 08:43:24.948673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_vars
    from ansible.plugins.action.command import ActionModule

    class DummyCommandModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            del tmp
            return super(DummyCommandModule, self).run(task_vars=task_vars)

    class DummyShellModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            del tmp
            self._task.args['_uses_shell'] = True
            return super(DummyShellModule, self).run(task_vars=task_vars)


# Generated at 2022-06-23 08:43:36.911263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    If we had any unit tests for the shell action, they would go here.
    """
    # First, create a "mock" task...
    task = FakeTask()
    task._task = FakeTask()
    task._connection = FakeConnection()
    task._play_context = FakePlayContext()
    task._loader = FakeLoader()
    task._templar = FakeTemplar()
    task._shared_loader_obj = FakeSharedLoaderObj()

    # Next, create a "mock" action plugin...
    action_plugin = FakeBaseActionPlugin()

    # And now, create our ActionModule instance.
    action_module = ActionModule(task=task, connection=action_plugin, shared_loader_obj=action_plugin)

    # And run it, with our expected FakeTask as the first parameter.
    result = action

# Generated at 2022-06-23 08:43:46.360860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible_collections.ansible.community.plugins.module_utils.basic
    from ansible.plugins.action import ActionBase

    module_utils = ansible_collections.ansible.community.plugins.module_utils.basic

    # Mock 'ActionBase' class
    class ActionBaseMock:
        def __init__(self):
            pass

    # Mock 'ActionBase()._shared_loader_obj' class
    class SharedLoaderObj:
        def __init__(self):
            pass

    # Mock 'ActionBase()._shared_loader_obj.action_loader' class
    class ActionLoader:
        def __init__(self):
            pass

        def get(self, module_name, task, connection, play_context, loader, templar, shared_loader_obj):
            return module_name

    # Mock

# Generated at 2022-06-23 08:43:47.054596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-23 08:43:57.277271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.module_utils.six import StringIO

    class DummyModule():
        def __init__(self):
            self.params = {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True, 'stdin': '',
                           'warn': False, 'warn_binary_comments': False}

    class DummyTask():
        def __init__(self):
            self.action = 'command'
            self.args = {'_raw_params': 'echo "hello world"; exit 1;', '_uses_shell': True}

    class DummyConnection():
        def __init__(self):
            self.module_implementation_preferences = [1, 2, 3]

    class DummyPlayContext():
        pass

# Generated at 2022-06-23 08:44:07.758218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    module = ActionModule(loader=None, play_context=None, new_stdin="", connection=None, shell=None, module_name="shell", module_args="", task_uuid=None, disable_fragment=None, task_vars=None, tmp=None, delete_remote_tmp=None, remote_tmp=None, module_compression=None, remote_user=None, remote_pass=None, transport=None, become_method=None, become_user=None, become_pass=None, become=None, become_flags=None, become_exe=None, become_ask_pass=None, become_info=None, no_log=False, verbosity=0, check=None, diff=None, run_additional_commands=None, run_tree=None, exclusions=None)

   

# Generated at 2022-06-23 08:44:17.179413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from collections import namedtuple
    from tests.unit.compat import unittest
    from tests.unit.compat.mock import patch


# Generated at 2022-06-23 08:44:17.724843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:20.828596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:44:29.222391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN the results of a legacy shell module
    result = {
        'stdout': 'result',
        'stderr': 'error',
        'rc': 'status',
        'delta': 'time'
    }

    # WHEN run is called for an ActionModule
    fake_task = 'fake_task'
    fake_connection = 'fake_connection'
    fake_play_context = 'fake_play_context'
    fake_loader = 'fake_loader'
    fake_templar = 'fake_templar'
    fake_shared_loader_obj = 'fake_shared_loader_obj'


# Generated at 2022-06-23 08:44:34.848302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, {}, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-23 08:44:36.358612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()


# Generated at 2022-06-23 08:44:44.336599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins import action
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes

    # Dummy class for an AnsibleModule object
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True, mutually_exclusive=(), required_together=(), required_one_of=(), add_file_common_args=False, supports_check_mode=False, required_if=()):
            self.check_mode = False
            self.params = {}

        def exit_json(self, *args, **kwargs):
            print('exit_json')
            print(args)
           

# Generated at 2022-06-23 08:44:44.709501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:45.109592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:44:52.785321
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:45:02.232375
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Setup some fake parameters which is what __init__ of ActionModule is expecting
    class FakeConn:
        def connect(self, host, port):
            pass
        def exec_command(self):
            pass
    class FakeConnPlugin:
        def get(self, conn_name, host, port, user, password, private_key_file, *args, **kwargs):
            return FakeConn()
    class FakeTask:
        def __init__(self):
            self.args = {}
    class FakeLoaderObj:
        pass
    class FakeSharedObj:
        pass
    class FakePlayContext:
        pass
    class FakeTemplar:
        pass
    class FakeLoader:
        pass
    class FakeTaskVars:
        pass
    class FakeOptions:
        pass

    task = FakeTask()
    loader_obj

# Generated at 2022-06-23 08:45:02.803255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-23 08:45:05.702647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._shared_loader_obj = None
    mod._connection = None
    mod._play_context = None
    mod._task = None
    mod._loader = None
    mod._templar = None
    assert mod.run() == None

# Generated at 2022-06-23 08:45:16.423174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            self.to_write = {
                'path': 'test',
                'data': 'test'
            }
            return None

    class TestActionModule(ActionModule):
        def _run_module(self):
            return dict()

    class TestActionModule_v2(ActionModule):
        VERSION = '2.0'

        def run(self, tmp=None, task_vars=None):
            return dict()

    # Case: ActionModule
    # Case: 1-1. tmp and task_vars are None

    t = TestActionModule(None, None)
    v = t.run()
    assert v == dict()

    # Case: 1-2. tmp is not None but task_vars

# Generated at 2022-06-23 08:45:21.329461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    object = ansible.plugins.action.shell.ActionModule(connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    assert hasattr(object, 'run')

# Generated at 2022-06-23 08:45:21.986593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-23 08:45:27.100384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule('ActionModule',None, None, None, None, None, None)
    result = action_module.run(task_vars='task_vars')
    assert result['name'] == "Command"
    assert result['rc'] == 0
    assert result['stderr_lines'] == 0
    assert result['warnings'] == 0

# Generated at 2022-06-23 08:45:27.637112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-23 08:45:34.225866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of a dummy class for testing
    class DummyClass(object):
        pass
    task = DummyClass()
    task.args = {'echo': {'_uses_shell': True}}
    task_vars = {}

    mock_loader = None

    # Create an instance of the class to test
    action_module = ActionModule(task=task,
                                 connection=None,
                                 play_context=None,
                                 loader=mock_loader,
                                 templar=None,
                                 shared_loader_obj=None)

    # Mock the action ansible.legacy.command.ActionModule
    # __main__.ActionModule

# Generated at 2022-06-23 08:45:37.582141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, None, None)
#    assert(True == False)


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:45:40.854531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Testing successful execution of method run of class ActionModule
    assert True == action_module.run()

    # Testing successful execution of method run of class ActionModule
    assert True == action_module.run()

# Generated at 2022-06-23 08:45:52.647185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # simulate a task and load the shell module
    module = 'shell'
    mock_task = MagicMock(module_args=module)
    mock_ansible_module = ModuleBuilder('ansible.builtin.shell',
                                        task=mock_task).module

    # mock_ansible_module needs 'module_utils'
    mock_module_utils = {}
    sys.modules['ansible.module_utils'] = mock_module_utils
    sys.modules['ansible.module_utils.basic'] = mock_module_utils
    sys.modules['ansible.module_utils.basic.module_common'] = mock_module_utils

    # instantiate the ActionModule class  with fake args
    # args = {'task':mock_task}
    mock_connection = MagicMock()
    mock_play_context = Magic

# Generated at 2022-06-23 08:45:53.783353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:45:54.307101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:46:06.332451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    FakeOptions = namedtuple('FakeOptions', 'connection')
    FakeOptions.connection = 'local'
    FakePlay = namedtuple('FakePlay', ['options'])
    FakePlay.options = FakeOptions

    FakeTask = namedtuple('FakeTask', ['args', 'play'])
    FakeTask.play = FakePlay

    FakeLoader = namedtuple('FakeLoader', 'shared_loader_obj')
    FakeSharedLoaderObj = namedtuple('FakeSharedLoaderObj', 'action_loader')

    FakeAction = namedtuple('FakeAction', ['run'])

    task_args = namedtuple('task_args', ['_uses_shell'])
    task_args._uses_shell = True

    task_ansible_fact_cache = dict()

# Generated at 2022-06-23 08:46:15.400935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    command_module_mock = ActionBase._get_action_plugin_mock('command', ['run'])

    action_module_obj = ActionModule(command_module_mock,
                                     AnsibleModule,
                                     connection=None,
                                     play_context=None,
                                     loader=None,
                                     templar=None,
                                     shared_loader_obj=None)
    result = action_module_obj.run(tmp=None, task_vars=[])


# Generated at 2022-06-23 08:46:23.416479
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Init class instance and setup needed parameters
    a = ActionModule()
    tmp = None
    task_vars = { 'command_action' : 'ansible.legacy.command', 'connection' : 'connection', 'play_context' : 'play_context', 'loader' : 'loader', 'templar' : 'templar', 'shared_loader_obj' : 'shared_loader_obj' }
    a._task = { 'args' : { '_uses_shell' : True } }

# Generated at 2022-06-23 08:46:24.797457
# Unit test for constructor of class ActionModule
def test_ActionModule():
  amobj = ActionModule()  
  assert amobj is not None

# Generated at 2022-06-23 08:46:34.460461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import become_loader

    # Tests ActionModule class constructor
    a = ActionModule()
    assert(a._task == None)
    assert(a._shared_loader_obj == None)
    assert(a._connection == None)
    assert(a._play_context == None)
    assert(a._loader == None)
    assert(a._templar == None)
    assert(a._identifier == None)

    # Tests ActionModule class constructor
    a = ActionModule(connection=connection_loader.get('local'))
    assert(a._task == None)
    assert(a._shared_loader_obj == None)
    assert(a._connection == connection_loader.get('local'))
    assert(a._play_context == None)


# Generated at 2022-06-23 08:46:36.414817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    action_module = ActionModule()
    tmp= None
    task_vars=None
    # Calling the method
    action_module.run(tmp, task_vars)

# Generated at 2022-06-23 08:46:40.505634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_Obj = ActionModule()
    assert ActionModule_Obj.run() == None

# Generated at 2022-06-23 08:46:42.414856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._connection.connection == 'local'


# Generated at 2022-06-23 08:46:53.355031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule as TestActionModule
    import ansible.plugins.action.command
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

# Generated at 2022-06-23 08:46:54.323403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == "ActionModule"



# Generated at 2022-06-23 08:46:59.140137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_run_result = '''{"test_param": "test_val"}'''

    m_tmp = None
    m_task_vars = {"test_param": "test_val"}

    m_actionModule = ActionModule(
        connection=None, _connection_info=None,  _task=None,
        _loader=None, _templar=None, _shared_loader_obj=None,
        _play_context=None, _task_vars=None
    )
    m_ActionModule_run_result = json.loads( m_actionModule.run(m_tmp, m_task_vars) )

    assert m_run_result == m_ActionModule_run_result

# Generated at 2022-06-23 08:47:07.080276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None)
    action._task.args['_uses_shell'] = True

    command_action = action._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                   task=action._task,
                                                                   connection=action._connection,
                                                                   play_context=action._play_context,
                                                                   loader=action._loader,
                                                                   templar=action._templar,
                                                                   shared_loader_obj=action._shared_loader_obj)
    result = command_action.run(task_vars={})

    assert result['failed'] == True
    assert result['msg'] == 'TESTFAIL'

# Generated at 2022-06-23 08:47:14.006443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.role.include import Include
    from ansible.playbook.task import Task

    from collections import namedtuple

    host = namedtuple('Host', '')

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            self.run_called_with = (tmp, task_vars)
            self.run_called = True

            self.called_with = (tmp, task_vars)
            self.called = True
            return dict(failed=False, changed=True)

    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            pass


# Generated at 2022-06-23 08:47:21.108955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    main = {
        "action_plugins": ["plugins/actions", "my_plugins/my_action_plugins"],
        "defaults_plugins": "plugins/defaults",
        "callback_plugins": "plugins/callbacks"
    }
    config = {
        "bin_ansible_callbacks": True,
        "bin_ansible_callbacks_whitelist": ["profile_tasks"]
    }
    loader = DictDataLoader({
        'main.yml': yaml.dump(main),
        'config.yml': yaml.dump(config),
    })
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {}}
    variable_manager.options_vars = {'hostvars': {}}

# Generated at 2022-06-23 08:47:24.709316
# Unit test for constructor of class ActionModule
def test_ActionModule():

   action_module = ActionModule()
   assert action_module != None

# Generated at 2022-06-23 08:47:26.096743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fixme: move to unit tests
    pass

# Generated at 2022-06-23 08:47:27.887743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule()
    assert module is not None


# Generated at 2022-06-23 08:47:32.870257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    #print(action_module.run('tmp','task_vars'))
    print(action_module.run())

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 08:47:36.342386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    action_module = ActionModule(fake_action_base)
    action_module.run({'_ansible_verbose_always' : True}, task_vars = {'ansible_verbose_always' : True})



# Generated at 2022-06-23 08:47:42.263797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test expects to import ansible.legacy.command.ActionModule
    # and to call the run() method of this class.
    # The import of ansible.legacy.command.ActionModule is mocked,
    # and the run() method is replaced by a lambda.
    # The run() method is then called.
    # If the javascript code in class ActionModule is correct,
    # this lambda will get called without error and without exception.
    import ansible.legacy.command as command
    m = mock.MagicMock()
    m.side_effect = lambda x: x
    command.ActionModule.run = m
    a = ActionModule()
    a.run()

# Generated at 2022-06-23 08:47:48.218448
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # create a task
  task = dict()
  task['args'] = dict()

  # create a play_context
  play_context = dict()
  play_context['prompt'] = dict()
  play_context['password'] = dict()
  
  # create a AnsibleModule
  m = dict()
  m['params'] = dict()

  ActionModule(m, task, play_context, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:47:52.186984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule(connection=None, task_vars=dict(), templar=None, shared_loader_obj=None,
                                     tmp=None, task=dict(args=dict(_uses_shell=True)), connection_loader=None,
                                     play_context=dict(), loader=None)
    assert test_ActionModule.run() != None

# Generated at 2022-06-23 08:47:54.157233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ansbile.plugins.action.ActionBase
    action_base = ActionBase()
    assert(action_base)

    # ansbile.plugins.action.ActionModule
    action_module = ActionModule()
    assert(action_module)

# Generated at 2022-06-23 08:48:02.184120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    # Create a host
    h = Host(name="test-host")

    # Create a variable_manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=DataLoader(), sources=[]))

# Generated at 2022-06-23 08:48:11.033661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_loader_obj = FakeLoader()
    fake_task = FakeTask('/etc/group')
    fake_connection = FakeConnection()
    fake_task.args['warn'] = False
    fake_task.args['_raw_params'] = 'cat /etc/group'
    fake_play_context = FakePlayContext()
    fake_play_context.shell = '/bin/sh'
    
    fake_action_module = ActionModule(fake_task, fake_connection, fake_play_context, 
            fake_loader_obj, fake_loader_obj, fake_loader_obj)
    result = fake_action_module.run(task_vars={'is_root': True})

# Generated at 2022-06-23 08:48:16.320042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.modules.action import ActionModule  # import here to avoid circular import

    # test with invalid task input
    task_input = [{}]
    actionModule = ActionModule(task_input)
    assert(actionModule is not None)

# Generated at 2022-06-23 08:48:19.683502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-23 08:48:24.883422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating a module object
    module = ActionModule(
        task=dict(
            args=dict(
                _uses_shell=True
            )
        ),
        play_context=dict(),
        connection=dict(),
        shared_loader_obj=dict(
            action_loader=dict()
        )
    )

    # Testing the run method
    result = module.run(task_vars=dict())

    # Asserting the run method returns a dictionary with keys msg and changed
    assert(type(result) == dict)
    assert('msg' in result)
    assert('changed' in result)

# Generated at 2022-06-23 08:48:33.223262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Defining a shell action task with a command
    task = {
        'action': 'shell',
        '_uses_shell': True,
        'args': {
            'chdir': '/tmp',
            'creates': '/tmp/test.txt',
            'executable': None,
            '_raw_params': 'echo hello',
            'removes': '/tmp/test.txt',
            'warn': 'yes'
        }
    }

    # Defining a temporary injector object with attributes loaded with appropriate values

# Generated at 2022-06-23 08:48:35.901373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert hasattr(module, 'run')

# Generated at 2022-06-23 08:48:37.003017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(None, None, None, None, None).__doc__)

# Generated at 2022-06-23 08:48:43.870453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    import ansible.plugins
    import ansible.plugins.action
    import ansible.utils.vars

    t = ansible.plugins.action.ActionModule(connection=None, play_context=None,
                                            new_stdin=None, loader=None,
                                            templar=None, shared_loader_obj=None)
    assert type(t) == ansible.plugins.action.ActionModule
    assert t.BYPASS_HOST_LOOP == False

# Generated at 2022-06-23 08:48:45.086191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None)
    assert actionModule is not None

# Generated at 2022-06-23 08:48:53.633230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import textwrap
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible_collections.ansible.legacy.plugins.modules.shell import ActionModule

    class MockModule(object):
        def __init__(self):
            self.params = {
                "shell": "/bin/bash"
            }

        def fail_json(self, **kwargs):
            raise RuntimeError("poop")

    class MockTask(object):
        def __init__(self):
            self.args = {
                '_raw_params': 'echo {{ a }} && echo {{ b }}',
                '_uses_shell': False,
                'creates': None,
                'executable': None,
                'removes': None
            }


# Generated at 2022-06-23 08:48:54.979215
# Unit test for constructor of class ActionModule
def test_ActionModule():
	module = ActionModule()

# Generated at 2022-06-23 08:48:57.470836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule), "Assertion failed"

# Generated at 2022-06-23 08:48:58.046198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:49:01.280004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule(loader=None, connection=None, play_context=None, loader_obj=None, templar=None)



# Generated at 2022-06-23 08:49:03.591008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:49:04.493085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()


# Generated at 2022-06-23 08:49:12.448975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.json_utils import AnsibleJSONDecoder
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.command import ActionModule as CommandAction

    # Test with the command module
    module_name = 'command'
    task_args = {'_uses_shell': True}
    task_vars = {}
    b_host = 'localhost'
    task_path = 'shell.yaml'
    play_context = PlayContext()
    loader = None
    templar = None
    shared_loader_obj = None

    mock_ac = CommandAction(task=None, connection=None, play_context=play_context, loader=loader, templar=templar,
                            shared_loader_obj=shared_loader_obj)


# Generated at 2022-06-23 08:49:20.743320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {'_uses_shell': True}
    action = 'ansible.legacy.shell'
    # method run: test 1
    kwargs = {'task_vars': {'test_var': 'test_value', 'foo': 'bar'}, 'tmp': '/tmp/test1', '_uses_shell': True}
    result = {}
    result['ansible_facts'] = {'test_var': 'test_value', 'foo': 'bar'}
    result['module_name'] = 'shell'
    result['module_args'] = {'_uses_shell': True}
    result['_ansible_verbosity'] = 0
    result['warnings'] = ['test_warning']
    result['deprecations'] = ['test_deprecation']

# Generated at 2022-06-23 08:49:24.641856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:49:25.420273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:49:27.502062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:49:28.970243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert am.ACTION_VERSION == '2.0'
    assert am.BYPASS_HOST_LOOP == True
    assert am.NO_TARGET_SYSLOG == True
    assert am.REPLACEMENTS == {'SHELL': 'command'}

# Generated at 2022-06-23 08:49:30.152915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass