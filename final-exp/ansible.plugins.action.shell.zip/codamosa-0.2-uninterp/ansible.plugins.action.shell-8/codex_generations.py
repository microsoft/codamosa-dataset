

# Generated at 2022-06-17 09:53:59.223451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_args = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result == {'_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_version': '2.9.9', 'changed': False, 'invocation': {'module_args': {'_uses_shell': True}}, 'rc': 0, 'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}

    # Test with args
    task_args = {'_uses_shell': True}

# Generated at 2022-06-17 09:54:01.647358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:07.212913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module argument spec
    ansible_module_argument_spec

# Generated at 2022-06-17 09:54:16.613585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the mock action loader's get method to return the mock command action
    action_loader.get = Mock(return_value=command_action)

    # Set the mock shared loader object's action_loader attribute to the mock action loader
    shared_loader_obj

# Generated at 2022-06-17 09:54:17.125402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:22.371622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:54:29.951728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module_result = MockAns

# Generated at 2022-06-17 09:54:30.416273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:36.527055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module argument spec
    ansible_module_argument_spec

# Generated at 2022-06-17 09:54:45.247167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:54:56.156215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            _raw_params='echo "Hello World"',
            _uses_shell=True
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_loader_obj
    shared_loader_obj = dict()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:55:04.370083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'_uses_shell': True}

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play_context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared_loader_obj
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock command_action
    mock_command_action = MockCommandAction()

    # Create a mock result
    mock_result = MockResult()

    # Create a mock action_base
    mock_action_base = MockActionBase()

    # Create a mock action

# Generated at 2022-06-17 09:55:04.949811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:05.550914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:06.202645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:17.787465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()

    # create a mock connection
    connection = MockConnection()

    # create a mock play_context
    play_context = MockPlayContext()

    # create a mock loader
    loader = MockLoader()

    # create a mock templar
    templar = MockTemplar()

    # create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # create a mock action_loader
    action_loader = MockActionLoader()

    # create a mock command_action
    command_action = MockCommandAction()

    # create a mock result
    result = MockResult()

    # create a mock action_base
    action_base = MockActionBase()

    # create a mock action_module

# Generated at 2022-06-17 09:55:28.230918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:55:32.191745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:32.674311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:40.363861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a

# Generated at 2022-06-17 09:55:54.242994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

   

# Generated at 2022-06-17 09:56:01.994334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a

# Generated at 2022-06-17 09:56:15.740275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create

# Generated at 2022-06-17 09:56:22.766524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a mock action module

# Generated at 2022-06-17 09:56:34.021363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:56:45.032622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            _uses_shell=True
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_loader_obj
    shared_loader_obj = dict()

    # Create a mock action_loader

# Generated at 2022-06-17 09:56:55.384857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock ansible.legacy.command

# Generated at 2022-06-17 09:57:02.496710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    # Create a mock command action
    command_action = MockCommandAction()
    # Set the command action in the action loader
    action_loader.set_command_action(command_action)
    # Set the action loader in the shared loader object
    shared_loader_obj.set_action_loader(action_loader)

    # Create

# Generated at 2022-06-17 09:57:08.277613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = mock.Mock()

    # Create a mock play_context
    play_context = mock.Mock()

    # Create a mock loader
    loader = mock.Mock()

    # Create a mock templar
    templar = mock.Mock()

    # Create a mock shared_loader_obj
    shared_loader_obj = mock.Mock()

    # Create a mock action_loader
    action_loader = mock.Mock()

    # Create a mock command_action
    command_action = mock.Mock()

    # Set the return value of method get of mock action_loader
    action_loader.get.return_value = command_action

    #

# Generated at 2022-06-17 09:57:09.923491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:20.828641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:21.781473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:35.171893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock action_loader
    shared_loader_obj.action_loader = action_loader

    #

# Generated at 2022-06-17 09:57:35.687252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:45.046309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader
    action_loader = MockActionLoader()
    # Create a mock command action
    command_action = MockCommandAction()
    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action loader of the

# Generated at 2022-06-17 09:57:52.880159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:57:53.372886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:54.520393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:59.541968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_equals
    from ansible.module_utils.parsing.splitter import parse_to_list

# Generated at 2022-06-17 09:58:00.074690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:15.967933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:16.906576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:17.972822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:18.880241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:28.405840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader
    action_loader = MockActionLoader()
    # Create a mock command action
    command_action = MockCommandAction()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # Set the action

# Generated at 2022-06-17 09:58:29.300481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:29.802272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:41.226280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class AnsibleLoader
    loader = AnsibleLoader()

    # Create an instance of class AnsibleTemplar
    templar = AnsibleTemplar()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance of class ActionBase
    action_base_1 = ActionBase()

    # Create an instance of class ActionBase
    action_base_2 = ActionBase()

   

# Generated at 2022-06-17 09:58:41.853638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:42.453545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:23.981596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    shared_loader_obj.action_loader = action_loader

    # Create a mock command action
    command_action = MockCommandAction()
    action_loader.get_return_value = command_action

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar

# Generated at 2022-06-17 09:59:31.943751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Test the run method

# Generated at 2022-06-17 09:59:33.439066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:33.964663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:34.859269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:42.185320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

# Generated at 2022-06-17 09:59:49.208748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    action_module = ActionModule()
    # create an instance of the class
    action_module._task = {'args': {'_uses_shell': True}}
    action_module._shared_loader_obj = {'action_loader': {'get': lambda *args, **kwargs: {'run': lambda *args, **kwargs: {'changed': True}}}}
    result = action_module.run()
    assert result['changed'] == True

# Generated at 2022-06-17 09:59:49.726354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:50.279308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:59.562693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock ansible.legacy.command
    command_action = MockCommandAction()

    # Create a mock ansible.legacy.command.run
    command_action_run = MockCommandActionRun()

    # Create a mock ansible.plugins.action.ActionBase
    action_base = MockActionBase()

    #

# Generated at 2022-06-17 10:01:21.187036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:01:33.669705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader
    action_loader = MockActionLoader()
    # Create a mock command action
    command_action = MockCommandAction()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # Set the action

# Generated at 2022-06-17 10:01:43.195899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleSharedLoaderObj
    ansible_shared_loader_obj = AnsibleSharedLoaderObj()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleTaskVars
    ans

# Generated at 2022-06-17 10:01:52.343818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command
    command = MockCommand()

    # Set the action_loader.get method to return the mock command
    action_loader.get = Mock(return_value=command)

    # Set the shared_loader_obj.action_loader to the mock action_loader
    shared_loader_obj.action

# Generated at 2022-06-17 10:01:52.859750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:02.902970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of the ActionModule class
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Call the run method of the ActionModule class
    result = action_module.run(task_vars=task_vars)

    #

# Generated at 2022-06-17 10:02:03.342597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:11.783848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class TaskVars
    task_vars = TaskVars()

    # Set the attributes of the instance of class Task
    task.args = {'_uses_shell': True}

    # Set the attributes of the instance of class SharedPluginLoaderObj
    shared_loader_obj

# Generated at 2022-06-17 10:02:21.430115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Check the

# Generated at 2022-06-17 10:02:22.274852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass