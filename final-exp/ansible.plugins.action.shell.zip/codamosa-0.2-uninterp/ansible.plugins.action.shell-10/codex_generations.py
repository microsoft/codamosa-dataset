

# Generated at 2022-06-17 09:53:59.467035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    # Create a mock result
    mock_result = MockResult()

    # Create a new

# Generated at 2022-06-17 09:54:08.474200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

   

# Generated at 2022-06-17 09:54:18.139273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:54:31.300287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create

# Generated at 2022-06-17 09:54:42.606206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock module
    module = MockModule()

    # Create a mock module result
    module_result = MockModuleResult()

    # Create a mock command result
    command

# Generated at 2022-06-17 09:54:52.001692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_from_argspec

# Generated at 2022-06-17 09:54:52.415544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:53.348807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:56.298150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:57.138446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:11.138533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_

# Generated at 2022-06-17 09:55:20.606380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class SharedLoaderObj
    shared_loader_obj = SharedLoaderObj()

    # Create an instance of class Loader
    loader = Loader()

    # Create an instance of class Templar
    templar = Templar()

    # Create an instance of class ActionLoader
    action_loader = ActionLoader()

    # Create an instance of class Command
    command = Command()

    # Set the attributes of the class Command
    command._task = task
    command._connection = connection
    command._play_context = play_context

# Generated at 2022-06-17 09:55:22.558933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:29.229521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 09:55:39.830600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='shell',
            module_args=dict(
                _raw_params='echo "Hello World"',
                _uses_shell=True
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_loader_obj
    shared_loader_obj = dict()

    # Create a mock action_loader
    action_loader = dict()

    # Create a mock command_action
    command_action = dict()



# Generated at 2022-06-17 09:55:47.696225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell as shell
    import ansible.plugins.action.command as command
    import ansible.plugins.loader as loader
    import ansible.plugins.connection.local as local
    import ansible.plugins.connection.network_cli as network_cli
    import ansible.plugins.connection.network_cli as network_cli
    import ansible.plugins.connection.paramiko_ssh as paramiko_ssh
    import ansible.plugins.connection.ssh as ssh
    import ansible.plugins.connection.winrm as winrm
    import ansible.plugins.connection.docker as docker
    import ansible.plugins.connection.docker_unix as docker_unix
    import ansible.plugins.connection.kubectl as kubectl
    import ansible.plugins.connection.kubectl_local as k

# Generated at 2022-06-17 09:55:56.072475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method

# Generated at 2022-06-17 09:56:03.343148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_string
    from ansible.module_utils.parsing.splitter import parse_kv_list
    from ansible.module_utils.parsing.splitter import parse

# Generated at 2022-06-17 09:56:15.872918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Set the attributes of the mock shared_loader_obj
    shared_loader_obj.action_loader = action_loader

    # Set the attributes of the mock action_loader


# Generated at 2022-06-17 09:56:16.538340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:33.427784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result

# Generated at 2022-06-17 09:56:44.365331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible

# Generated at 2022-06-17 09:56:54.966518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:56:55.482883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:04.577773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule()
    action_module._task = {}
    action_module._task['args'] = {}
    action_module._shared_loader_obj = {}
    action_module._shared_loader_obj.action_loader = {}
    action_module._shared_loader_obj.action_loader.get = lambda *args, **kwargs: {}
    action_module._connection = {}
    action_module._play_context = {}
    action_module._loader = {}
    action_module._templar = {}
    action_module.run()

# Generated at 2022-06-17 09:57:04.981804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:05.401645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:10.496268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a ActionModule object
    action_module = ActionModule()

    # Initialize a task object
    task = {
        'args': {
            '_uses_shell': True
        }
    }
    action_module._task = task

    # Initialize a connection object
    connection = {}
    action_module._connection = connection

    # Initialize a play_context object
    play_context = {}
    action_module._play_context = play_context

    # Initialize a loader object
    loader = {}
    action_module._loader = loader

    # Initialize a templar object
    templar = {}
    action_module._templar = templar

    # Initialize a shared_loader_obj object
    shared_loader_obj = {}
    action_module._shared_loader_obj = shared_

# Generated at 2022-06-17 09:57:20.402703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse

# Generated at 2022-06-17 09:57:21.173280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:33.395008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:33.899714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:34.391742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:44.953547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import zip_longest
    from ansible.module_utils.six.moves import _thread
    from ansible.module_utils.six.moves import _threading_local
    from ansible.module_utils.six.moves import _dummy_thread
    from ansible.module_utils.six.moves import _dummy_threading

# Generated at 2022-06-17 09:57:47.805801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:48.848941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:59.590387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    # Setup
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_list
    from ansible.module_utils.parsing.splitter import parse_a_list

# Generated at 2022-06-17 09:58:00.456866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:12.936511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    action_module = ActionModule()
    action_module._task = {'args': {}}
    action_module._shared_loader_obj = {}
    action_module._task = {}
    action_module._connection = {}
    action_module._play_context = {}
    action_module._loader = {}
    action_module._templar = {}
    action_module._shared_loader_obj = {}
    action_module.run()

    # Test with args
    action_module = ActionModule()
    action_module._task = {'args': {'_uses_shell': True}}
    action_module._shared_loader_obj = {}
    action_module._task = {}
    action_module._connection = {}
    action_module._play_context = {}
    action_module._loader = {}

# Generated at 2022-06-17 09:58:25.457064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleSharedLoaderObj
    ansible_shared_loader_obj = AnsibleSharedLoaderObj()

    # Set the attributes of the ActionModule instance
    action_module._task = ansible_task
    action_module._connection = ansible_connection


# Generated at 2022-06-17 09:58:41.955080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:42.551759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:43.272129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:43.605484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:54.042299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class Templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of the class ActionModule
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context
   

# Generated at 2022-06-17 09:58:54.572459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:02.898080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:59:13.079752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_string

# Generated at 2022-06-17 09:59:13.706303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:22.890675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Set the attributes of the mock shared_loader_obj
    shared_loader_obj.action

# Generated at 2022-06-17 10:00:09.653370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create an instance of the action module

# Generated at 2022-06-17 10:00:10.558555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:15.336282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleTaskVars
    ansible_task_vars = AnsibleTaskVars()

    # Call method run of class ActionModule
    result = action_module.run(ansible_task, ansible_task_vars)

    # Check the result
    assert result == 'result'


# Generated at 2022-06-17 10:00:15.795893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:23.594736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a ActionModule object

# Generated at 2022-06-17 10:00:34.056602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of class AnsibleTaskVars
    ansible_task_vars = AnsibleTaskVars()

    # Create an instance of class AnsibleTaskArgs
    ansible_task_args = AnsibleTaskArgs()

    # Create an instance of class AnsibleTaskArgsUsesShell
    ansible_task_args_uses_shell = AnsibleTaskArgsUsesShell()

    # Create an instance of class AnsibleTaskArgsUsesShellTrue
    ansible_task_args_uses_shell_true = AnsibleTaskArgsUsesShellTrue()

    # Create an instance of class AnsibleTaskArgsUsesShellFalse
    ansible_task_args_uses_shell

# Generated at 2022-06-17 10:00:41.678650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 10:00:48.254277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 10:00:48.795565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:57.103352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = {}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:02:34.714608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of the action module

# Generated at 2022-06-17 10:02:44.682122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    # Create a mock result
    mock_result = MockResult()

    # Create an instance

# Generated at 2022-06-17 10:02:45.535144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:54.207068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Set the attributes of the ActionModule instance
    action_module._task = ansible_task
    action_module._connection = ansible_connection
    action_module._play_context = ans

# Generated at 2022-06-17 10:03:01.801120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:03:02.419549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:03:02.924359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 10:03:10.481798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create an

# Generated at 2022-06-17 10:03:20.736396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    import sys

    # Create a mock task
    class MockTask:
        def __init__(self):
            self.args = {}

    # Create a mock connection
    class MockConnection:
        def __init__(self):
            self.transport = 'local'

    # Create a mock play context
    class MockPlayContext:
        def __init__(self):
            self.connection = 'local'

    # Create a mock loader
    class MockLoader:
        def __init__(self):
            self.path_exists = lambda x: True

    # Create a mock templar

# Generated at 2022-06-17 10:03:21.647817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass