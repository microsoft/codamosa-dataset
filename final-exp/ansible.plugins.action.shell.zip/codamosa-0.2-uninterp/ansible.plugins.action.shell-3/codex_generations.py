

# Generated at 2022-06-17 09:53:58.663389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule()

    # Create a mock object of class Task
    task = Task()

    # Create a mock object of class Connection
    connection = Connection()

    # Create a mock object of class PlayContext
    play_context = PlayContext()

    # Create a mock object of class DataLoader
    loader = DataLoader()

    # Create a mock object of class Templar
    templar = Templar()

    # Create a mock object of class SharedLoaderObj
    shared_loader_obj = SharedLoaderObj()

    # Create a mock object of class ActionLoader
    action_loader = ActionLoader()

    # Create a mock object of class Command
    command = Command()

    # Set the attributes of the mock object of class ActionModule
    action_module._task = task
    action_module._connection = connection

# Generated at 2022-06-17 09:54:08.043951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Run the method run of class ActionModule
    result = action_module.run()

    # Assert that the result is not None
    assert result is not None


# Generated at 2022-06-17 09:54:17.691159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 09:54:21.450831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:21.928608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:22.332756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:29.876076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_args = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=None)
    assert result['_uses_shell'] == True
    assert result['_ansible_no_log'] == False
    assert result['_ansible_verbosity'] == 0
    assert result['_ansible_version'] == '2.4.3.0'
    assert result['_ansible_syslog_facility'] == 'LOG_USER'
    assert result['_ansible_selinux_special_fs'] == ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p', 'vfat']
   

# Generated at 2022-06-17 09:54:30.573298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:31.070767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:39.026432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock play_context
    play_context = MockPlayContext()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock action_loader
    action_loader = MockActionLoader()
    # create a mock command
    command = MockCommand()
    # create a mock ansible.legacy.command
    ansible_legacy_command = MockAnsibleLegacyCommand()
    # create a mock task_vars
    task_vars = MockTask

# Generated at 2022-06-17 09:54:51.869516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task variable
    task_vars = MockTaskVars()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method run of class ActionModule

# Generated at 2022-06-17 09:54:59.721894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class Templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of the object action_module
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context


# Generated at 2022-06-17 09:55:01.528955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:11.618170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    action_loader.get = MockActionLoaderGet()

    # Create a mock command action
    command_action = MockCommandAction()
    command_action.run = MockCommandActionRun()

    # Set the mock action loader get return value

# Generated at 2022-06-17 09:55:12.314383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:14.760479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:20.934932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module argument spec
    ansible_module_argument_spec

# Generated at 2022-06-17 09:55:32.865515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock action module
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Create a mock task
    task = {
        'args': {
            '_uses_shell': True
        }
    }

    # Create a mock command action
    command_action = {
        'run': lambda task_vars: {
            'changed': True,
            'failed': False,
            'rc': 0,
            'stderr': '',
            'stdout': '',
            'stdout_lines': [],
            'warnings': []
        }
    }

    # Create a mock shared loader object
    shared_loader_obj

# Generated at 2022-06-17 09:55:33.381806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:42.784493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible

# Generated at 2022-06-17 09:55:51.630761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock command action run result
    mock_command_action_run_result = MockCommandActionRunResult()

    # Create a mock action base
    mock_action_base = Mock

# Generated at 2022-06-17 09:55:59.637466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action
    action = MockAction()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance

# Generated at 2022-06-17 09:56:00.078198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:01.984429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:08.518474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the command action to the action loader
    action_loader.set_command_action(command_action)

    # Set the action loader to the shared loader object
    shared_loader_obj.set_action_loader(action_loader)

    # Create a mock task vars
    task_vars = MockTaskVars()

# Generated at 2022-06-17 09:56:09.890519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:10.786468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:11.384941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:20.770795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task variables
    task_vars = dict()

    # Execute method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is equal to

# Generated at 2022-06-17 09:56:33.428194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:56:48.586146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    shared_loader_obj.action_loader = action_loader

    # Create a mock command action
    command_action = MockCommandAction()
    action_loader.get.return_value = command_action

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars

# Generated at 2022-06-17 09:56:59.271480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of the action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task variables
    task_vars = dict()

    # Call the run method of the action module
    result = action_module.run(task_vars=task_vars)

    # Assert the result is as expected

# Generated at 2022-06-17 09:57:05.073387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 09:57:10.313244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of class ActionBase
    action_base = ActionBase()

    # Create a mock of class ActionBaseLoader
    action_base_loader = ActionBaseLoader()

    # Create a mock of class Connection
    connection = Connection()

    # Create a mock of class PlayContext
    play_context = PlayContext()

    # Create a mock of class DataLoader
    data_loader = DataLoader()

    # Create a mock of class Templar
    templar = Templar()

    # Set attributes of mock objects
    action_base._task = 'task'
    action_base._connection = connection
    action_base._play_context = play_context
    action_base._loader = data_loader
    action_base._templar = templar
    action_base

# Generated at 2022-06-17 09:57:20.404547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a mock action module

# Generated at 2022-06-17 09:57:34.085802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = mock.Mock()

    # Create a mock play context
    play_context = mock.Mock()

    # Create a mock loader
    loader = mock.Mock()

    # Create a mock templar
    templar = mock.Mock()

    # Create a mock shared loader object
    shared_loader_obj = mock.Mock()

    # Create a mock command action
    command_action = mock.Mock()
    command_action.run.return_value = {'changed': True}

    # Create a mock action loader
    action_loader = mock.Mock()
    action_loader.get.return_value = command_action

    # Create a

# Generated at 2022-06-17 09:57:44.765014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 09:57:52.670991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:58:02.216830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class Templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of the instance of class ActionModule
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play

# Generated at 2022-06-17 09:58:03.035286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:18.879486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:19.505606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:33.630482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a ActionModule object

# Generated at 2022-06-17 09:58:44.685522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:58:55.159821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:59:03.337432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class Templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Set the attributes of 'action_module'
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context


# Generated at 2022-06-17 09:59:13.678522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = {}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action

# Generated at 2022-06-17 09:59:22.889614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of the action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task variables
    task_vars = dict()

    # Run the action module
    result = action_module.run(task_vars=task_vars)

    # Assert that the run method of the command action was

# Generated at 2022-06-17 09:59:30.581350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_vars = dict()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars)
    assert result == dict(changed=False, msg='', rc=0, stderr='', stderr_lines=[], stdout='', stdout_lines=[])

    # Test with args
    task_vars = dict(ansible_shell_type='csh')
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:59:31.039161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:09.023751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:17.043307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a ActionModule object
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

   

# Generated at 2022-06-17 10:00:24.306480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 10:00:24.691412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:25.223447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 10:00:25.629994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:26.010703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:36.289405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 10:00:46.746280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class AnsibleLoader
    loader = AnsibleLoader()

    # Create an instance of class AnsibleTemplar
    templar = AnsibleTemplar()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance

# Generated at 2022-06-17 10:00:55.758959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:02:23.607255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Loader
    loader = Loader()

    # Create an instance of class Templar
    templar = Templar()

    # Create an instance of class SharedLoaderObj
    shared_loader_obj = SharedLoaderObj()

    # Create an instance of class ActionLoader
    action_loader = ActionLoader()

    # Set the attributes of the class ActionLoader
    action_loader.action_loader = {}

    # Set the attributes of the class SharedLoaderObj
    shared_loader_obj.action_loader = action_loader

    # Set the attributes of

# Generated at 2022-06-17 10:02:24.434283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:34.813893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an action module object
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the command

# Generated at 2022-06-17 10:02:36.112397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:36.852942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:45.926840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create an

# Generated at 2022-06-17 10:02:46.433905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:56.008391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set

# Generated at 2022-06-17 10:03:06.497788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create

# Generated at 2022-06-17 10:03:16.562287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'_uses_shell': True}

    # Create a mock task_vars
    task_vars = mock.Mock()

    # Create a mock connection
    connection = mock.Mock()

    # Create a mock play_context
    play_context = mock.Mock()

    # Create a mock loader
    loader = mock.Mock()

    # Create a mock templar
    templar = mock.Mock()

    # Create a mock shared_loader_obj
    shared_loader_obj = mock.Mock()

    # Create a mock command_action
    command_action = mock.Mock()

    # Create a mock result
    result = mock.Mock()

    # Create a mock action_loader