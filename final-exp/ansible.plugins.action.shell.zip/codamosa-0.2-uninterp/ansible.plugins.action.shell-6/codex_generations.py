

# Generated at 2022-06-17 09:54:09.229530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method

# Generated at 2022-06-17 09:54:18.616451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task
    task = Task()
    task.action = 'shell'
    task.args = {'_uses_shell': True}

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play

# Generated at 2022-06-17 09:54:21.523757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:28.904854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock play context
    mock_play_context = MockPlayContext()
    # Create a mock loader
    mock_loader = MockLoader()
    # Create a mock templar
    mock_templar = MockTemplar()
    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader
    mock_action_loader = MockActionLoader()
    # Create a mock command action
    mock_command_action = MockCommandAction()
    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:54:29.771680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:30.246846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:36.400222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_

# Generated at 2022-06-17 09:54:45.132918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:54:53.747902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module
    mock_module = type('', (), {})()
    mock_module.params = {'_raw_params': 'echo "Hello World"'}
    mock_module._ansible_no_log = False
    mock_module._ansible_verbosity = 0
    mock_module._ansible_debug = False
    mock_module._ansible_diff = False
    mock_module._ansible_check_mode = False
    mock_module._ansible_selinux_special_fs = []
    mock_module._ansible_shell_executable = '/bin/sh'
    mock_module._ansible_shell_type = 'sh'
    mock_module._ansible_shell_executable = '/bin/sh'
    mock_module._ansible_shell_type = 'sh'
   

# Generated at 2022-06-17 09:55:04.164822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = Mock()

    # Create a mock play context
    play_context = Mock()

    # Create a mock loader
    loader = Mock()

    # Create a mock templar
    templar = Mock()

    # Create a mock shared loader object
    shared_loader_obj = Mock()

    # Create a mock action loader
    action_loader = Mock()

    # Create a mock command action
    command_action = Mock()
    command_action.run = Mock(return_value={"rc": 0, "stdout": "", "stderr": ""})

    # Set the action loader to return the command action
    action_loader.get = Mock(return_value=command_action)

# Generated at 2022-06-17 09:55:17.618025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method

# Generated at 2022-06-17 09:55:28.173381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Set the attributes of the class Task
    task.args = {'_uses_shell': True}

    # Set the attributes of the class TaskExecutor
    task_executor._task = task

    # Set the attributes of the class ActionModule
    action_module._task = task
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None

    # Call the method run of class ActionModule

# Generated at 2022-06-17 09:55:32.186036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:40.081010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:55:47.113948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert that result is equal to expected_result
    assert result == expected_result


# Generated at 2022-06-17 09:55:47.598830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:55.952845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

# Generated at 2022-06-17 09:55:56.469640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:03.584157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import split_args
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-17 09:56:04.076431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:09.474786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:10.230646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:20.191463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleTaskVars
    ansible_task_vars = AnsibleTaskVars()

    # Set the attributes of the AnsibleTask object
    ansible_task

# Generated at 2022-06-17 09:56:33.279418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create the action module object
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task variables
    task_vars = dict()

    # Run the method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert the result

# Generated at 2022-06-17 09:56:42.326514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an

# Generated at 2022-06-17 09:56:42.838762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:43.332804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:53.747879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = {}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:56:54.276745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:01.655418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command
    command = MockCommand()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a ActionModule object

# Generated at 2022-06-17 09:57:20.296756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()

    # Create an instance of AnsibleTask
    at = AnsibleTask()

    # Create an instance of AnsibleTaskVars
    atv = AnsibleTaskVars()

    # Create an instance of AnsibleTaskResult
    atr = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    atr2 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    atr3 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    atr4 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    atr5 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    atr6 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult


# Generated at 2022-06-17 09:57:21.100189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:22.183345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:23.124803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:24.267339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:25.351185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:36.563475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='shell',
            module_args=dict(
                _raw_params='echo "Hello World!"'
            )
        )
    )

    # Create a mock loader
    loader = dict(
        action_loader=dict(
            get=lambda *args, **kwargs: dict(
                run=lambda *args, **kwargs: dict(
                    rc=0,
                    stdout='Hello World!',
                    stderr='',
                    changed=True
                )
            )
        )
    )

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_

# Generated at 2022-06-17 09:57:43.706889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugins import get_all_plugin_loaders, get_all_plugins
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleError, AnsibleParserError


# Generated at 2022-06-17 09:57:54.430386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            _uses_shell=True
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_loader_obj
    shared_loader_obj = dict(
        action_loader=dict(
            get=lambda action, task, connection, play_context, loader, templar, shared_loader_obj: dict(
                run=lambda task_vars: dict(
                    changed=True
                )
            )
        )
    )



# Generated at 2022-06-17 09:57:55.182422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:17.405255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the mock action loader's get method to return the mock command action
    action_loader.get = Mock(return_value=command_action)

    # Set the mock shared loader object's action_loader attribute to the mock action loader
    shared_loader_obj.action_loader = action_loader

    # Create a mock task vars

# Generated at 2022-06-17 09:58:27.399796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the mock command action to the mock action loader
    action_loader.get.return_value = command_action

    # Set the mock action loader to the mock shared loader object
    shared_

# Generated at 2022-06-17 09:58:28.289919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:31.970848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module.run() == {}

    # Test with arguments
    action_module = ActionModule()
    assert action_module.run(tmp=None, task_vars=None) == {}

# Generated at 2022-06-17 09:58:43.175997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class Loader
    loader = Loader()

    # Create an instance of class Templar
    templar = Templar()

    # Create an instance of class ActionLoader
    action_loader = ActionLoader()

    # Create an instance of class Command
    command = Command()

    # Set attributes of objects
    task.args = {'_uses_shell': True}
    shared_plugin_loader_obj.action_loader = action

# Generated at 2022-06-17 09:58:53.625015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input

# Generated at 2022-06-17 09:59:02.307893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command
    command = MockCommand()

    # Set the action_loader attribute of the shared_loader_obj
    shared_loader_obj.action_loader = action_loader

    # Set the command attribute of the action_loader
    action_loader.command = command

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:59:02.927346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:03.656981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:04.189489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:39.326416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:50.420877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['_uses_shell'] = True

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock shared_loader_obj
    shared_loader_obj = dict()

    # Create a mock command_action
    command_action = dict()
    command_action['run'] = dict()
    command_action['run']['return_value'] = dict()
    command_action['run']['return_value']['changed']

# Generated at 2022-06-17 09:59:50.946700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:59:51.629461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:00.756016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import to_nice_yaml

# Generated at 2022-06-17 10:00:07.550060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {}
    action_module._task['args'] = {}
    action_module._task['args']['_uses_shell'] = True
    action_module._shared_loader_obj = {}
    action_module._shared_loader_obj.action_loader = {}
    action_module._shared_loader_obj.action_loader.get = lambda x, task, connection, play_context, loader, templar, shared_loader_obj: {}
    action_module._connection = {}
    action_module._play_context = {}
    action_module._loader = {}
    action_module._templar = {}
    action_module.run()

# Generated at 2022-06-17 10:00:08.964894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:09.764721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:10.808095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:17.757579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module

# Generated at 2022-06-17 10:01:41.886831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:01:51.049028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible

# Generated at 2022-06-17 10:02:01.559774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Shell module is implemented via command with a special arg
            self._task.args['_uses_shell'] = True


# Generated at 2022-06-17 10:02:07.061069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-17 10:02:07.596673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:08.103114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:09.897775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:10.943783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:21.096829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:02:22.186526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass