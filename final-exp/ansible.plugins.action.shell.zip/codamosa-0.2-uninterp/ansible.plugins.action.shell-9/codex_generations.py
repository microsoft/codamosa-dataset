

# Generated at 2022-06-17 09:53:58.689096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:54:08.374941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module

# Generated at 2022-06-17 09:54:18.148528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    action_loader.get.return_value = MockCommandAction()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action base object
    action_base = ActionBase()

    # Create a mock action module object

# Generated at 2022-06-17 09:54:18.623574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:28.599425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:54:37.922521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Call method

# Generated at 2022-06-17 09:54:43.571171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no parameters
    action_module = ActionModule()
    result = action_module.run()
    assert result == {'failed': True, 'msg': 'invalid action detected: ansible.legacy.shell'}

    # Test with parameters
    action_module = ActionModule()
    result = action_module.run(tmp=None, task_vars=None)
    assert result == {'failed': True, 'msg': 'invalid action detected: ansible.legacy.shell'}

# Generated at 2022-06-17 09:54:44.862019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:45.363681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:45.843325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:56.661529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    # Create a mock result
    mock_result = MockResult()

    # Create an instance

# Generated at 2022-06-17 09:55:04.406228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 09:55:04.995931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:55:14.370231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an ActionModule object

# Generated at 2022-06-17 09:55:14.945293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:22.138174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:55:29.033458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock play context object
    play_context = MockPlayContext()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader object
    action_loader = MockActionLoader()
    # Create a mock command action object
    command_action = MockCommandAction()
    # Create a mock task vars object
    task_vars = MockTaskVars()

    # Create an instance of class ActionModule

# Generated at 2022-06-17 09:55:39.830464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock command action run result
    command_action_run_result = MockCommandActionRunResult()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action base run result
    action_base_run

# Generated at 2022-06-17 09:55:40.320911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:40.805794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:46.965613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:55.223984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command
    command = MockCommand()

    # Set the command attribute of the action_loader
    action_loader.command = command

    # Set the action_loader attribute of the shared_loader_obj
    shared_loader_obj.action_loader = action_loader

    # Create an instance of the Action

# Generated at 2022-06-17 09:55:56.035944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:03.323421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the command action to the action loader
    action_loader.set_action('ansible.legacy.command', command_action)

    # Set the action loader to the shared loader object
    shared_loader_obj.set_action_loader(action_loader)

    # Create a mock connection
    connection = MockConnection()



# Generated at 2022-06-17 09:56:09.334577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_string
    from ansible.module_utils.parsing.splitter import split_args
    from ansible.module_utils.parsing.splitter import unquote

# Generated at 2022-06-17 09:56:09.844570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:10.735009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:20.429094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    action_loader.get = MockActionLoaderGet()

    # Create a mock command action
    command_action = MockCommandAction()
    command_action.run = MockCommandActionRun()

    # Set the mock action loader get method to return the mock command action
    action_

# Generated at 2022-06-17 09:56:21.521805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:22.409322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:30.575203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:31.144146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:39.507184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModule
    ansible

# Generated at 2022-06-17 09:56:41.128275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:48.445670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:56:52.685323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module.run() == None


# Generated at 2022-06-17 09:57:00.593762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native


# Generated at 2022-06-17 09:57:08.232199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_loader_obj = SharedPluginLoaderObj()

    # Set the attributes of the class ActionModule
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context
    action_module._loader = loader

# Generated at 2022-06-17 09:57:19.956474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:57:33.935089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the

# Generated at 2022-06-17 09:57:59.589547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args['_uses_shell'] = True
    action_module._task.args['_raw_params'] = 'ls -l'
    action_module._task.args['chdir'] = '/tmp'
    action_module._task.args['creates'] = '/tmp/test'
    action_module._task.args['executable'] = '/bin/bash'
    action_module._task.args['removes'] = '/tmp/test'
    action_module._task.args['warn'] = True
    action_module._task.args['_raw_params'] = 'ls -l'
    action_module._task.args['_uses_shell'] = True
    action_module._task.args['_uses_shell'] = True

# Generated at 2022-06-17 09:58:05.594217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task variables
    task_vars = {}

    # Run method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is equal to the expected

# Generated at 2022-06-17 09:58:07.263867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:16.363167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:58:26.581872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            '_uses_shell': True
        }
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock connection
    connection = {}

    # Create a mock play_context
    play_context = {}

    # Create a mock loader
    loader = {}

    # Create a mock templar
    templar = {}

    # Create a mock shared_loader_obj
    shared_loader_obj = {}

    # Create a mock action_loader

# Generated at 2022-06-17 09:58:29.748955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module.run(None, None) == None

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module.run(None, None) == None

# Generated at 2022-06-17 09:58:41.179595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a mock task
    task_args = ImmutableDict(
        {'_uses_shell': True, '_raw_params': 'echo "Hello World"'})
    task = ImmutableDict(
        {'args': task_args, 'action': 'shell', 'delegate_to': None})

    # Create a mock connection

# Generated at 2022-06-17 09:58:51.920732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of a class ActionModule
    action_module = ActionModule()
    # Create an instance of a class Task
    task = Task()
    # Create an instance of a class PlayContext
    play_context = PlayContext()
    # Create an instance of a class Connection
    connection = Connection()
    # Create an instance of a class SharedLoaderObj
    shared_loader_obj = SharedLoaderObj()
    # Create an instance of a class Loader
    loader = Loader()
    # Create an instance of a class Templar
    templar = Templar()

    # Set the attributes of the class ActionModule
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context
    action_module._loader = loader
    action_module._templar = templar
    action_

# Generated at 2022-06-17 09:59:00.934977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock object
    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.run_called = False
            self.run_called_with = None
            self.run_called_result = None

        def run(self, *args, **kwargs):
            self.run_called = True
            self.run_called_with = args
            self.run_called_result = kwargs
            return self.run_called_result

    # create object
    action_module = MockActionModule()

    # call run
    result = action_module.run()

    # check result
    assert result == action_module.run_called_result
    assert action_module.run_called
    assert action_module.run_called_with == (None, )

# Generated at 2022-06-17 09:59:11.862036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleModule
    ansible

# Generated at 2022-06-17 09:59:56.601799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 10:00:05.810510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 10:00:06.682899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:16.663298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()
    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()
    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()
    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()
    # Create an instance of AnsibleActionLoader
    ansible_action_loader = AnsibleActionLoader()
    # Create an instance of AnsibleModuleLoader
    ansible_module_loader = AnsibleModuleLoader()
    # Create an instance of AnsibleModuleUtils
    ansible_

# Generated at 2022-06-17 10:00:24.073420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import PY3

    # Create a mock task
    task = {
        'action': 'shell',
        'args': {
            '_uses_shell': True,
            'chdir': '/tmp',
            'creates': '/tmp/foo',
            'executable': '/bin/bash',
            'removes': '/tmp/bar',
            'warn': True
        },
        'async': 3600,
        'delegate_to': 'localhost',
        'delegate_facts': True,
        'register': 'shell_out'
    }

    # Create a mock loader

# Generated at 2022-06-17 10:00:33.221233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

   

# Generated at 2022-06-17 10:00:33.755937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:34.536088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:35.585060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:46.411337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    # Create a mock result
    mock_result = MockResult()

    # Create a mock

# Generated at 2022-06-17 10:02:08.029757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:08.638329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:20.408769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()

    # Create an instance of AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleTaskVars
    ansible_task_vars

# Generated at 2022-06-17 10:02:33.573651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse

# Generated at 2022-06-17 10:02:44.044119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 10:02:44.580666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:45.369591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:45.852940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:54.491811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    # Create a mock task

# Generated at 2022-06-17 10:03:01.933253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    action_module = ActionModule()
    # create an instance of the class
    action_module._task = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._connection = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._play_context = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._loader = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._templar = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._shared_loader_obj = 'ansible.legacy.shell'
    # create an instance of the class
    action_module._task.args