

# Generated at 2022-06-17 09:54:09.270773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create an action module

# Generated at 2022-06-17 09:54:18.651352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Set the action_loader attribute of the shared_loader_obj
    shared_loader_obj.action_loader

# Generated at 2022-06-17 09:54:21.522732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:28.897195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of the action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a mock task args
    task_args = {'_uses_shell': True}
    # Assign the mock task args to the task
    task.args = task_args

    # Create a mock command action

# Generated at 2022-06-17 09:54:29.772308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:38.373031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Templar
    templar = Templar(loader=data_loader, variables=variable_manager)

    # Create an instance of class Command
    command = Command()

    # Set the attributes of the class SharedPluginLoaderObj

# Generated at 2022-06-17 09:54:49.242172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv

# Generated at 2022-06-17 09:54:49.701477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:54:52.925373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:55:00.252744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test setup
    import ansible.plugins.action.shell
    import ansible.plugins.action.command
    import ansible.plugins.loader
    import ansible.plugins.connection.local
    import ansible.plugins.connection.ssh
    import ansible.plugins.connection.paramiko_ssh
    import ansible.plugins.connection.netconf
    import ansible.plugins.connection.winrm
    import ansible.plugins.connection.docker
    import ansible.plugins.connection.docker_unix
    import ansible.plugins.connection.docker_py
    import ansible.plugins.connection.kubectl
    import ansible.plugins.connection.kubectl_python
    import ansible.plugins.connection.ssh_connection
    import ansible.plugins.connection.accelerate

# Generated at 2022-06-17 09:55:11.584218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task = {'args': {}}
    task_vars = {}
    action = ActionModule(task, {})
    result = action.run(task_vars=task_vars)
    assert result['_uses_shell'] == True
    assert result['_ansible_no_log'] == False

    # Test with args
    task = {'args': {'_uses_shell': False, '_ansible_no_log': True}}
    task_vars = {}
    action = ActionModule(task, {})
    result = action.run(task_vars=task_vars)
    assert result['_uses_shell'] == False
    assert result['_ansible_no_log'] == True

# Generated at 2022-06-17 09:55:20.630660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-17 09:55:22.600228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:23.211398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:24.042451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:28.626052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    #
    # This test is not implemented.
    #
    # TODO: Implement this test.
    pass

# Generated at 2022-06-17 09:55:39.802156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_string

# Generated at 2022-06-17 09:55:40.320744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:55:48.135370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a mock action module

# Generated at 2022-06-17 09:55:48.643776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:02.168034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Run the method run of class ActionModule
    result = action_module.run()

    # Assert

# Generated at 2022-06-17 09:56:15.732125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule

# Generated at 2022-06-17 09:56:16.392883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:23.018986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:56:34.073871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 09:56:45.326176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 09:56:48.041689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:48.550493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:56:55.897512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:57:07.188752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock task_vars
    task_vars = {}

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock command_action.run

# Generated at 2022-06-17 09:57:15.436945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:15.945200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:25.912735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action loader
    action_loader = MockActionLoader()
    # Create a mock command action
    command_action = MockCommandAction()
    # Create a mock result
    result = MockResult()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action loader of the

# Generated at 2022-06-17 09:57:36.762270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler import HandlerTask
    from ansible.playbook.handler import HandlerInclude

# Generated at 2022-06-17 09:57:38.217428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:38.725089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:39.242026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:57:49.258547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_kv_list

# Generated at 2022-06-17 09:57:59.669748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Set the command action to be returned by the action loader
    action_loader.get.return_value = command_action

    # Set the action loader to be returned by the shared loader object
   

# Generated at 2022-06-17 09:58:00.197541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:15.903750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:16.849608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:17.561531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:27.435894
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:58:28.726746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:58:39.849150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'_uses_shell': True}

    # Create a mock connection
    connection = mock.Mock()

    # Create a mock play context
    play_context = mock.Mock()

    # Create a mock loader
    loader = mock.Mock()

    # Create a mock templar
    templar = mock.Mock()

    # Create a mock shared loader object
    shared_loader_obj = mock.Mock()

    # Create a mock action loader
    action_loader = mock.Mock()

    # Create a mock command action
    command_action = mock.Mock()

    # Create a mock task_vars
    task_vars = mock.Mock()

    # Create a mock result
    result = mock.Mock()

# Generated at 2022-06-17 09:58:40.374816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:41.029923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:58:51.779515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()
    action_loader.get = MockActionLoaderGet()
    shared_loader_obj.action_loader = action_loader

    # Create a mock command_action
    command_action = MockCommandAction()
    command_action.run = MockCommandActionRun()
    action_loader.get.return_value = command_action

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = Mock

# Generated at 2022-06-17 09:59:01.163768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class ActionBase
    action_base = ActionBase()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class Templar
    templar = Templar()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Set the attributes of action_module
    action_module._shared_loader_obj = shared_plugin_loader_obj
    action_module._task = task
    action_module._connection = connection
    action

# Generated at 2022-06-17 09:59:37.335390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:37.853608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:59:49.528559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action
    action = MockAction()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock result
    result = MockResult()

    # Create a mock action module

# Generated at 2022-06-17 09:59:58.895440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play_context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_loader
    action_loader = MockActionLoader()

    # Create a mock command_action
    command_action = MockCommandAction()

    # Create a mock command_action.run
    command_action.run = MockCommandActionRun()

    # Create a mock shared_loader_

# Generated at 2022-06-17 10:00:06.894025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    mock_action_loader = MockActionLoader()

    # Create a mock command action
    mock_command_action = MockCommandAction()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

   

# Generated at 2022-06-17 10:00:08.903339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:09.700146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:10.615103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:11.250409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:00:11.852709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:01:33.590846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:01:43.127719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a ActionModule object

# Generated at 2022-06-17 10:01:43.952179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:01:52.713383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

# Generated at 2022-06-17 10:02:02.791529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()

    # Create a mock command action
    command_action = MockCommandAction()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # Set the action

# Generated at 2022-06-17 10:02:07.622987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Set the attributes of the instance of class ActionModule
    action_module._task = task
    action_module._connection = connection
    action_module._play_context = play_context
    action_module._loader = loader

# Generated at 2022-06-17 10:02:13.973223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'_uses_shell': True}

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action loader
    action_loader = MockActionLoader()
    shared_loader_obj.action_loader = action_loader

    # Create a mock command action
    command_action = MockCommandAction()
    action_loader.get_return_value = command_action

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create an instance of ActionModule
    action_module = ActionModule(task, MockConnection(), MockPlayContext(), MockLoader(), MockTemplar(), shared_loader_obj)

    # Call method run of class ActionModule

# Generated at 2022-06-17 10:02:14.595587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:15.297114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:02:23.172510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionModule as CommandModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_