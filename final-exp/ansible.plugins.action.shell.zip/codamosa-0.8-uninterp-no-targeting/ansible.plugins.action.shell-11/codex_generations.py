

# Generated at 2022-06-21 03:00:21.481580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:00:23.549694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:00:33.070708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = "127.0.0.1"
    port = 22
    user = "root"
    password = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    task_vars = None
    _action_module = ActionModule(host, port, user, password, connection, play_context, loader, templar, shared_loader_obj, task_vars)
    assert _action_module is not None

# Generated at 2022-06-21 03:00:45.135219
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    new_action_module = ActionModule(ActionBase._shared_loader_obj)
    result = new_action_module.run()

# Generated at 2022-06-21 03:00:46.235730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:48.180578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None) != None

# Generated at 2022-06-21 03:00:48.949047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run

# Generated at 2022-06-21 03:00:50.797466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(None,None)


# Generated at 2022-06-21 03:00:59.736832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import required to pass unit test
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.plugin_docs import read_docstring

    # Create instance of ActionModule
    # ActionBase.__init__ is called from __init__ of ActionBase
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # mock tmp object since it has no effect here
    tmp = None

    # mock task_vars object since they are not required to test run method of ActionModule
    task_vars = {
        'ansible_fact': {}
    }

    # call run method of ActionModule

# Generated at 2022-06-21 03:01:00.490743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:04.123564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-21 03:01:06.833032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test.playbook', 'test.play', 'test.task', {})


# Generated at 2022-06-21 03:01:15.638995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {'chdir': '/root', '_raw_params': '/bin/foo', '_uses_shell': False, '_uses_delegate': True, '_uses_async': False, 'creates': None, 'removes': None, 'chdir': None, 'executable': None}

# Generated at 2022-06-21 03:01:19.688013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    connection = {}
    play_context = {}
    loader = {}
    shared_loader_obj = {}
    templar = {}
    m = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert m is not None

import mock

# Generated at 2022-06-21 03:01:20.252730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:01:20.804675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:23.590015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test ActionModule'''

    action_module = ActionModule()

    assert action_module._task.args['_uses_shell'] is True, "Not the expected output"

# Generated at 2022-06-21 03:01:35.035623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, task=None)

    result = module.run(tmp=None, task_vars=None)

    assert result['_ansible_verbose_override'] is False
    assert result['_ansible_no_log'] is False
    assert result['_ansible_parsed'] is True

    assert result['_ansible_version'] is not None
    assert result['_ansible_syslog_facility'] is None
    assert result['_ansible_syslog_facility'] is None
    assert result['_ansible_shell_executable'] is None
    assert result['_ansible_no_log'] is False
    assert result['_ansible_diff'] is False


# Generated at 2022-06-21 03:01:35.892962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 03:01:45.964492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Ensure that ActionModule(...) does not work as there is no such class
    from ansible.plugins.action.command import ActionModule as ActionCommand
    from ansible.plugins.action.setup import ActionModule as ActionSetup
    from ansible.plugins.action.copy import ActionModule as ActionCopy
    from ansible.plugins.action.ping import ActionModule as ActionPing
    from ansible.plugins.action.win_ping import ActionModule as ActionWinPing

    # Define parameter-arguments for the test
    fake_task = lambda : None
    fake_connection = lambda : None
    fake_play_context = lambda : None
    fake_loader = lambda : None
    fake_templar = lambda : None
    fake_shared_loader_obj = lambda : None

    with pytest.raises(TypeError):
        action_module = ActionModule

# Generated at 2022-06-21 03:01:52.744936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:01:55.792570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()

    assert result == "test"

# Generated at 2022-06-21 03:02:03.405889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'ansible.legacy.shell'
    _shared_loader_obj = None
    _connection = None
    _play_context = None
    _loader = None
    _templar = None
    _task = None
    action = ActionModule(module_name, _shared_loader_obj, _connection, _play_context, _loader, _templar, _task)
    print(action)


# Generated at 2022-06-21 03:02:09.598823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Set up equivalent of module parameters
  tmp = None
  task_vars = { 'ansible_facts': { 'ansible_shell_type': 'ansible.shell.sh.ShModule' } }

  # Set up mock_task
  mock_task = MagicMock()
  mock_task.args = {}

  # Set up mock_connection
  mock_connection = MagicMock()

  # Set up mock_play_context
  mock_play_context = MagicMock()

  # Set up mock_loader
  mock_loader = MagicMock()

  # Set up mock_templar
  mock_templar = MagicMock()

  # Set up mock_shared_loader_obj
  mock_shared_loader_obj = MagicMock()

  # Set up mock_action_loader
  mock_action_loader

# Generated at 2022-06-21 03:02:10.536159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME Implement this test
    pass

# Generated at 2022-06-21 03:02:18.584171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN: Test arguments and instantiated AnsibleModule object
    module = AnsibleModule(argument_spec={})
    command_action = CommandActionModule()
    module.connection = 'ssh'
    module.loader = DictDataLoader({
        'async': 0
    })
    module.tmp = ''
    module.task_vars = {
        'ansible_check_mode': False
    }

    # WHEN: Method run of ActionModule class is called
    command_action.run(tmp=module.tmp, task_vars=module.task_vars)
    tmp = command_action.run(tmp=module.tmp, task_vars=module.task_vars)

    # THEN: Ensure that method run of class CommandActionModule did not return error
    assert tmp['failed'] is False



# Generated at 2022-06-21 03:02:29.462211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.block import Block

    loader = DataLoader()
    play_context = PlayContext()
    play_context._connection = 'local'
    play_context._play_context = play_context
    task_vars = {}
    hosts = 'localhost'

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = Variable

# Generated at 2022-06-21 03:02:30.040003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:02:31.357778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    result = actionModule.run()
    assert result != None

# Generated at 2022-06-21 03:02:32.510296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert not action
    pass

# Generated at 2022-06-21 03:02:42.800747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, dict(), dict(), dict(), dict(), dict(), dict())
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 03:02:54.975348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'test_ActionModule_run'

    print('\nTest module: %s' % module_name)

    # Setup
    _task = {
        'args': {
            '_raw_params': 'chmod -u+x /etc/ansible/ansible.cfg'
        },
        'module_name': 'shell',
    }
    _connection = 'local'
    _play_context = {
        'become': False,
        'become_method': 'sudo',
        'become_user': '',
        'check_mode': False,
        'diff': False,
        'environment': {},
    }
    _play_context_for_task = {}
    _loader = 'test_loader'
    _shared_loader_obj = ''

# Generated at 2022-06-21 03:02:57.963957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert a

# Generated at 2022-06-21 03:03:03.198515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor should not raise any exception
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 03:03:08.052375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""

    action_module = ActionModule(
        task = None,
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    assert action_module is not None


# Generated at 2022-06-21 03:03:08.989910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:03:18.972459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    test_task = dict(
        name="Test task",
        args={'_uses_shell': True},
        register='foo',
    )

    fake_play_context = dict(
        play=None,
    )

    fake_task_vars = dict(
        foo="bar",
    )

    fake_task_result = dict(
        changed=False,
        cmd="echo 'foo'",
        msg="",
    )

    fake_command_action = dict(
        run=lambda task_vars: dict(
            changed=False,
            cmd="echo 'foo'",
            msg="",
        ),
    )


# Generated at 2022-06-21 03:03:24.946398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    task_vars = dict()
    result = True
    ip = None
    port = None

    am = ActionModule(connection, play_context, loader, templar, shared_loader_obj)
    
    # test run method
    print(am.run(task_vars=task_vars))

    # test get_wins function
    am.get_wins(ip, port)

    # test is_available function
    am.is_available(ip)

    # test save_result function
    am.save_result(result, ip)

# Generated at 2022-06-21 03:03:25.538757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:29.816370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule("test_loader", "test_action_plugin", "test_connection", "test_play_context", "test_loader", \
    "test_templar", "test_shared_loader_obj", "test_task"))

# Generated at 2022-06-21 03:03:56.409723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None

    #Shell module is implemented via command with a special arg
    #_task.args['_uses_shell'] = True

    #command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
    #                                                           task=self._task,
    #                                                           connection=self._connection,
    #                                                           play_context=self._play_context,
    #                                                           loader=self._loader,
    #                                                           templar=self._templar,
    #                                                           shared_loader_obj=self._shared_loader_obj)
    #result = command_action.run(task_vars=task_vars)

    #return result

# Generated at 2022-06-21 03:04:03.836384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(
        task=dict(
            args=dict(
                _raw_params='ls'
            ),
            uuid='125e43fb-10dc-4ba1-b35c-0fe9c9bf933e',
            name='shell',
            delegate_to='127.0.0.1',
            action='shell'
        ),
        connection=None,
        play_context=dict(
            network_os='linux',
            port=22,
            remote_addr='127.0.0.1'
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert mod.run()

# Generated at 2022-06-21 03:04:10.308543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'fake_key': 'fake_value'}
    module._task.action = 'fake_action'
    module._connection = 'fake_connection'
    module._play_context = 'fake_play_context'
    module._loader = 'fake_loader'
    module._templar = 'fake_templar'
    module._shared_loader_obj = 'fake_shared_loader_obj'
    assert module.run() == None

# Generated at 2022-06-21 03:04:13.926468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert type(c) is type(ActionModule)

# Generated at 2022-06-21 03:04:23.751672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run method for valid action module results"""

    class FakeModule:
        def __init__(self):
            self.action_loader = None
            self.module_loader = None
            self.connection_loader = None
            self.filter_loader = None
            self.lookup_loader = None
            self.test_loader = None

    class FakeActionLoader:
        def get(self, *args):
            return FakeAction(args)

    class FakeAction:
        def __init__(self, call):
            self.call = call
            self.action_name = 'ansible.legacy.command'

        def run(self):
            if self.action_name == 'ansible.legacy.command':
                Result = dict()
                Result['foo'] = 'bar'
                return Result

# Generated at 2022-06-21 03:04:25.904541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    This method is for testing the constructor action module
    '''

    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-21 03:04:36.322745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    am = ActionModule(
        action_loader,
        'test_args',
        {
            '_ansible_no_log': False,
            '_ansible_verbosity': 2,
            '_ansible_debug': False
        },
        'test_connection',
        'test_play_context',
        'test_loader',
        'test__templar',
        'test__shared_loader_obj'
    )

    assert am.action_loader == action_loader
    assert am._task.name == 'test_args'
    assert am._task.args == {
        '_ansible_no_log': False,
        '_ansible_verbosity': 2,
        '_ansible_debug': False
    }
    assert am._connection

# Generated at 2022-06-21 03:04:41.736881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an object of class ActionModule
    obj = ActionModule(
        task=dict(
            args=dict(
                _raw_params='echo $HOME'
            )
        ),
        task_vars=dict(
            ansible_user='fry',
            ansible_env=dict(
                HOME='/home/fry'
            )
        )
    )

    # run the method
    obj.run()

# Generated at 2022-06-21 03:04:42.608488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-21 03:04:45.517255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:05:26.129818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class A(ActionModule):
        def __init__(self):
            self._task = None

# Generated at 2022-06-21 03:05:26.629655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:36.693831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
            argument_spec=dict()
        )


# Generated at 2022-06-21 03:05:38.180639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None
# /Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:05:39.014594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:05:47.058977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action.shell import ActionModule
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole

    from ansible.template import Templar

    from ansible.plugins.loader import action_loader
   

# Generated at 2022-06-21 03:05:58.041018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(_raw_params='ls -la'), delegate_to='localhost'),
        connection=dict(),
        play_context=dict(become=True, become_user='root'),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # ActionModule is an instance of class ActionBase
    assert(type(module) == ActionBase)
    assert(True == module.get_become_option()['become'])
    assert('root' == module.get_become_option()['become_user'])
    assert('localhost' == module._play_context.delegate_to)
    assert(None == module._loader)
    assert('ls -la' == module._task.args['_raw_params'])

# Generated at 2022-06-21 03:05:58.566741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:06:03.838012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({'playbook_dir': 'playbook', 'verbosity': 0}, {}, {})

    assert action_module._task.args['_uses_shell']  # pylint: disable=protected-access
    assert action_module._loader.get_basedir() == "playbook"  # pylint: disable=protected-access
    assert action_module._task.args['_raw_params'][0] == 'echo "hello"'  # pylint: disable=protected-access

# Generated at 2022-06-21 03:06:13.802245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from tempfile import mkdtemp

    from ansible.executor.task_result import TaskResult
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    module_name = 'my_module'
    module_args = 'my_args'
    tmp = mkdtemp()

    task = {
        'args': {
            '_raw_params': module_args,
            '_uses_shell': True,
            'chdir': None,
            'creates': None,
            'executable': None,
            'removes': None,
            'stdin': None,
        },
        'delegate_to': 'localhost'
    }

    ActionModule_run(module_name, module_args, tmp, task)

    # Asserts

# Generated at 2022-06-21 03:07:43.076649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:07:45.145154
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:07:51.839328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    foo_loader, ansible_loader, path_backup = MockLoader.mock_all()

    jdict = {
        "_attributes": {
            "no_log": False, "use_unsafe_shell": False, "creates": None, "removes": None,
            "executable": None, "warn": True, "chdir": None, "stdin": None
        },
        "argv": "echo foo",
        "_uses_shell": True
    }

    mock_task = FakeTask(jdict)
    mock_connection = mock.MagicMock()
    mock_play_context = mock.MagicMock()

    # patch out the command action to just check the result
    mock_action = 'ansible.legacy.command'


# Generated at 2022-06-21 03:07:54.814829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestTask:
        def __init__(self):
            self.args = {}

    test_task = TestTask()

    # True test
    test_task.args['_uses_shell'] = True
    assert ActionModule.run(test_task) is None

    # False test
    test_task.args['_uses_shell'] = False
    assert ActionModule.run(test_task) is None

# Generated at 2022-06-21 03:08:03.362151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task and connection
    task = type('FakeTask', (object,), {})
    connection = type('FakeConnection', (object,), {})
    # Load the required resources
    loader = type('FakeLoader', (object,), {})
    templar = type('FakeTemplar', (object,), {})
    shared_loader_obj = type('FakeSharedLoaderObj', (object,), {})
    # Create the module to test
    module = ActionModule(task, connection, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)
    # Check
    assert module._task is task
    assert module._connection is connection
    assert module._loader is loader
    assert module._templar is templar
    assert module._shared_loader_obj is shared_loader_

# Generated at 2022-06-21 03:08:10.012747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Patching the dispatcher and get_connection modules, since they are handled in a way that they are not
    # normally available from AnsibleAction
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.utils.plugin_docs import docstring_trim

    # Create a dummy class for module_utils, which is required by the plugins, but not directly available
    class DummyModuleUtils:
        def get_module_path(self, module_name):
            return '/path/to/module/' + module_name

    module_utils = DummyModuleUtils()

    # Create a dummy dispatcher class, which needs to have access to the module_utils
    class DummyDispatcher:
        def __init__(self):
            self._module_utils_loader = module_utils

# Generated at 2022-06-21 03:08:11.890976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    assert actionModule.run() is None

# Generated at 2022-06-21 03:08:14.278203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(None, MockTask(), None, None, None, None, None)
    result = m.run(None)
    assert result['rc'] == 0

# Generated at 2022-06-21 03:08:22.370119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch, PropertyMock

    # Used to invoke unit tests because AnsibleModule.__init__ is having issues

# Generated at 2022-06-21 03:08:24.100011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test actionbase in ansible.module_utils.basic.py
    # test command in ansible.module_utils.basic.py
    pass