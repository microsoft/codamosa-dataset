

# Generated at 2022-06-21 03:00:32.580996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''

    action_module = ActionModule(loader=None,
                                 connection=None,
                                 play_context=None,
                                 new_stdin=None,
                                 module_name='action',
                                 module_args={'_raw_params': 'echo "Hello!"'},
                                 task_uuid='3cc1f991-2678-46c0-ab13-759284bc8e0e')
    print(action_module.async_val)


# Generated at 2022-06-21 03:00:41.664445
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Sources:
    # type(ActionBase)
    # https://github.com/ansible/ansible/blob/v2.6.3/lib/ansible/plugins/action/command.py#L24
    tmp = None
    task_vars = dict()
    command_action = object()
    result = object()
    class ActionBase_inst(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

# Generated at 2022-06-21 03:00:48.890702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Copy data into a new dict
    data = dict(ANSIBLE_MODULE_ARGS=dict(a=1, b=2))
    FauxSelf = {}
    FauxSelf['_task'] = data
    FauxSelf['_connection'] = None
    FauxSelf['_play_context'] = None
    FauxSelf['_loader'] = None
    FauxSelf['_templar'] = None
    FauxSelf['_shared_loader_obj'] = None
    # Create an instance of ActionModule
    A = ActionModule(FauxSelf)
    # Create a FauxAnsibleAction
    FA = FauxAnsibleAction()
    A._shared_loader_obj = FA
    # Call run method of ActionModule
    ret = A.run(None, None)
    assert ret == FA.results


# Generated at 2022-06-21 03:00:55.086938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()

    assert action_mod._play_context == {'_use_shell': True, '_uses_shell': True}
    assert action_mod._task.args == {'_uses_shell': True}

# Generated at 2022-06-21 03:01:05.582905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with argument _uses_shell = False
    action_module = ActionModule()
    action_module._task = {
        "name": "test_action_module_executing_shell_module",
        "args": {
            "chdir": None,
            "creates": None,
            "executable": None,
            "removes": None,
            "warn": True,
            "module": "shell",
            "stdin": None,
            "stdin_add_newline": True,
            "strip_empty_ends": True,
            "strip_empty_errors": True,
            "shell": "/bin/sh",
            "stop_on_failed": True,
            "_raw_params": "echo \"Hello World\"",
            "_uses_shell": False
        }
    }
    expected_result

# Generated at 2022-06-21 03:01:08.845490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    print("Unit test for method run of class ActionModule")

# Generated at 2022-06-21 03:01:11.659841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if the ActionModule constructor is become a class of type "type"
    action = ActionModule()
    assert type(action) == type


# Generated at 2022-06-21 03:01:15.648960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None, connection=None, play_context=None)
    assert module is not None

# Generated at 2022-06-21 03:01:16.865444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:01:24.408469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, action_loader=None)
    module.shared_loader = None
    module.action_loader = None
    module.task = None
    module.connection = None
    module.play_context = None
    module.loader = None
    module.templar = None
    module.shared_loader_obj = None
    module._shared_loader_obj = None
    module._task = None
    module._connection = None
    module._play_context = None
    module._loader = None
    module._templar = None
    module._shared_loader_obj = None
    result = module.run(tmp=None, task_vars=None)
    assert result == None

# Generated at 2022-06-21 03:01:29.751032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    shell_module = ActionModule()
    shell_module.run(task_vars={'ansible_fake_module': True})

# Generated at 2022-06-21 03:01:31.147226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a model object
    module = ActionModule()


# Generated at 2022-06-21 03:01:44.047701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""

    # Mock a task with a shell module
    module_name = 'shell'
    task_args = {'_raw_params': 'ls', '_uses_shell': True, '_original_basename': 'shell'}
    task = MockTask(module_name, task_args)
    # Mock a connection
    connection = MockConnection()

    # Create the ActionModule instance
    action_module = ActionModule(task, connection, play_context=mock.Mock(), loader=mock.Mock(), templar=mock.Mock(),
                                 shared_loader_obj=mock.Mock())

    # Unit test run

# Generated at 2022-06-21 03:01:54.815924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.connection import Connection

    class Loader:
        def __init__(self):
            pass

        def get_basedir(self, *args, **kwargs):
            return '/tmp'

        def path_dwim(self, *args, **kwargs):
            return '/tmp/ansible'

    class Connection:
        def __init__(self):
            pass

        def _build_command(self, cmd, in_data=None, executable=None):
            return cmd

        def exec_command(self, cmd, in_data=None, sudoable=False, executable=None):
            return 1, b'', b''


# Generated at 2022-06-21 03:01:59.769044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None, connection=None,
                          play_context=None, task=None,
                          shared_loader_obj=None, templar=None)
    assert not module


# Generated at 2022-06-21 03:02:01.212371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-21 03:02:03.284062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_result = action_module.run()
    assert action_result == "ActionModule.run"

# Generated at 2022-06-21 03:02:14.393213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import os
    import shutil
    import tempfile
    import sys

    current_working_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.join(current_working_path, "../"))
    sys.path.insert(0, os.path.join(current_working_path, "../ansible/"))

    # Reminder: ansible.plugins.action.ActionBase is ansible.plugins.action.ActionBase
    # Reminder: ansible.plugins.action.ActionBase.run is ansible.plugins.action.ActionBase.run
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.ActionBase import run

    assert run

    # Reminder: ansible.plugins.action

# Generated at 2022-06-21 03:02:25.591074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule - run \n")

    yaml_obj = YAML()
    module_obj = ActionModule()
    
    # Case 1
    # Test Case: testing when task_vars is None
    # Input: None
    # Output: result
    # Expected Output: Test failed
    result = module_obj.run(task_vars=None)
    print("")
    print("Testing Case 1")
    assert result == None, "Test failed"
    
    # Case 2
    # Test Case: testing when task_vars is provided
    # Input: task_vars
    # Output: result
    # Expected Output: Test failed
    result = module_obj.run(task_vars=None)
    print("")
    print("Testing Case 2")

# Generated at 2022-06-21 03:02:36.679417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # initialize needed objects
    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=[])
    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

# Generated at 2022-06-21 03:02:40.858043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:48.600669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object of class ActionModule
    actionModule_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # invoke method run on object actionModule_obj
    result = actionModule_obj.run(tmp=None,task_vars=None)
    # check if result is an instance of class `dict`
    assert isinstance(result, dict)
    # check if result['failed'] is False
    assert result['failed'] == False

# Generated at 2022-06-21 03:02:58.467030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    context = PlayContext()

    connection_loader.get('local')
    module_loader.get('ping')
    module_utils_loader.get('basic')
    lookup_loader.get('file')

# Generated at 2022-06-21 03:03:09.409008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection import network_cli


# Generated at 2022-06-21 03:03:09.905222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:12.367385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("BEGIN test_ActionModule")

    action_module = ActionModule()

    print("END test_ActionModule")


# Generated at 2022-06-21 03:03:13.278662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:21.638050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mytask = dict()
    mytask['args'] = dict()
    mytask['args']['_uses_shell'] = True

    mytaskvars = dict()
    mytaskvars['ansible_shell_type'] = 'csh'
    mytaskvars['ansible_shell_executable'] = '/bin/csh'

    mytaskvars['ansible_python_interpreter'] = '/usr/bin/python'

    result_stdout = """START:
    # Module was called with: '_uses_shell=True'
    # Changed working directory to /root

    END:
    # Ansible raw module (as opposed to 'command' module) took 0.14s to run
    # Shell module invocation was canceled due to filtered error message: 'python is required on target hosts'
"""
    myresult = dict

# Generated at 2022-06-21 03:03:32.261375
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:03:33.865582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Assert that the constructor of class ActionModule works
    """
    assert True

# Generated at 2022-06-21 03:03:51.639145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.command import ActionModule as CommandActionModule
  
    from ansible.executor.task_result import TaskResult

    from ansible_collections.ansible.community.tests.unit.plugins.action.data import config_data
    from ansible_collections.ansible.community.tests.unit.plugins.action.data import task_vars_data

    module = 'ansible.community.crypto.crypto_modes.crypto_mode_base'

    shared_loader_obj = MagicMock()
    shared_loader_obj.action_loader = MagicMock()
    shared_loader_obj.action_loader.get = MagicMock(return_value=CommandActionModule)


    task = MagicMock()
   

# Generated at 2022-06-21 03:03:56.088696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = am.run(tmp=None, task_vars=None)

    assert result is not None

# Generated at 2022-06-21 03:03:57.334314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModuleObject = ActionModule()
    assert actionModuleObject.run() == None

# Generated at 2022-06-21 03:03:59.173431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test unit for method run of class ActionModule.
    '''
    obj = ActionModule()
    assert obj.run() == dict()

# Generated at 2022-06-21 03:04:02.157690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input parameters for constructor of class ActionModule
    tmp = None
    task_vars = None

    # Set up object used to test the constructor
    am = ActionModule(tmp, task_vars)
    assert am is not None

# Generated at 2022-06-21 03:04:08.091690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import _ActionModule

    class FakeModule(object):
        def __init__(self, name=None, args=None):
            self.name = name
            self.args = args

        def to_bytes(self, text):
            return to_bytes(text)

    # Create a module
    module = FakeModule(name='test_module', args='args')

    # Create a Loader object and put the module into it
    class FakeLoader(object):
        def __init__(self):
            self.module_name = 'test_module'
            self.action_plugin = {}

        def add_directory(self, a, b, c):
            pass


# Generated at 2022-06-21 03:04:16.914504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestException(Exception):
        pass

    class TestTask():
        def __init__(self):
            self.args = {}
            self.args['_uses_shell'] = True

    module = ActionModule()

    # Test when command_action.run() raises an exception
    class TestCommand():
        def run(self, task_vars=None):
            raise TestException("Test exception raised when command_action.run() raises an exception")

    setattr(module, '_shared_loader_obj', TestCommand())
    setattr(module, '_task', TestTask())
    with pytest.raises(TestException):
        module.run(None, None)

# Generated at 2022-06-21 03:04:18.986743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None, "Test instance creation"

# Generated at 2022-06-21 03:04:22.323674
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# test values
	tmp = "tmp"
	task_vars = {"task_vars":"task_vars"}

	# instantiate the module
	am = ActionModule()
	am.run(tmp, task_vars)

# Generated at 2022-06-21 03:04:27.565997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Create an object of class ActionBase
    t = ActionBase()
    #Create an object of class ActionModule
    test_obj = ActionModule()
    #Create a dummy tmp and task_vars for parameter passing
    tmp = 1
    task_vars = 2
    #Call the run function to execute the above functions and test its return value
    assert test_obj.run(tmp, task_vars) == t.run(task_vars)

# Generated at 2022-06-21 03:04:49.149803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_tmp_path(*args, **kwargs):
        return '/'

    def mock_action_getter(*args, **kwargs):
        print(args[0])
        print(kwargs)
        return mock_command

    def mock_command(*args, **kwargs):
        return 'Hey'

    action = dict()
    action['action'] = 'shell'
    action['_uses_shell'] = True

    inv = dict()
    inv['ansible_play_hosts'] = ['localhost']

    taskvars = dict()
    taskvars['ansible_inventory'] = inv
    taskvars['ansible_facts'] = dict()
    taskvars['ansible_facts']['ansible_default_ipv4'] = dict()

# Generated at 2022-06-21 03:04:50.199150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule is not None

# Generated at 2022-06-21 03:04:53.424976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell
    my_shell = ansible.plugins.action.shell.ActionModule(
        task = {},
        connection = {},
        play_context = {},
        loader = {},
        templar = {},
        shared_loader_obj = {},
    )

    assert my_shell is not None


# Generated at 2022-06-21 03:04:54.455333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:05:00.182840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    # Make the class object
    a = ActionModule()
    # Make fake it's parameters
    tmp = 1
    task_vars = 'test'
    # Call the actual class method with the fake parameters
    if a.run(tmp, task_vars):
        print("test_ActionModule_run - Passed")
    else:
        print("test_ActionModule_run - Failed")

# Generated at 2022-06-21 03:05:00.692225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 03:05:01.163820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:11.346030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    host = MockConnection()
    class MockPlayContext(object):
        become = False
        become_method = 'sudo'
        become_user = 'root'
        check_mode = False
        connection = 'ssh'
        def __init__(self):
            self.tags = ['all']
        def update_vars(self, task_vars):
            return task_vars

    play_context = MockPlayContext()
    loader = None
    templar = None
    shared_loader_obj = None


# Generated at 2022-06-21 03:05:11.858327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:05:12.728878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:05:53.173738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = __import__("ansible.modules.shell")

    act_mod_inst = ActionModule(connection=module)
    assert act_mod_inst is not None

# Generated at 2022-06-21 03:05:54.726244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-21 03:06:03.180588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_base_obj = ActionBase()
    action_module_obj = ActionModule(action_base_obj._shared_loader_obj,
                                     action_base_obj._connection,
                                     action_base_obj._play_context,
                                     action_base_obj._loader,
                                     action_base_obj._templar,
                                     action_base_obj._task)
    task_vars = {'ansible_facts': {'os_family': 'Debian', 'ansible_ssh_host': 'localhost', 'ansible_ssh_port': 22}}
    result = action_module_obj.run('tmp', task_vars)

# Generated at 2022-06-21 03:06:09.421377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Testing with a real object of ActionModule class
    actionModule = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, task_vars=None)

    # Filename: first_file.yml
    # Add method unit tests here
    # Testing method run
    assert False == actionModule.run()

# Generated at 2022-06-21 03:06:16.084053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct task with module arguments
    task_args = dict(command=['echo', 'hello'])

    # Construct task with connection arguments
    task_connection = dict(executable='/bin/bash', chdir='/tmp')

    # Construct task with additional play context arguments
    task_context = dict(user='ubuntu')

    # Construct ansible task
    task_meta = dict()

    # Construct ansible task instance
    task = dict(action=dict(module_name='shell', args=task_args))

    # Run method run of class ActionModule
    action_mod_inst = ActionModule()
    result = action_mod_inst.run(task_vars=dict(), tmp=None)
    assert result['rc'] == 0, "Failed"

# Generated at 2022-06-21 03:06:24.429111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def fake_Action_run(class_self, tmp, task_vars):
        return True

    import ansible.plugins.action.shell
    ansible.plugins.action.shell.ActionModule.run = fake_Action_run

    module_name = 'ansible.plugins.action.shell'
    src, importer, is_pkg = imp.find_module(module_name, ['lib/ansible/plugins/action'])
    module = imp.load_module(module_name, src, importer, is_pkg)
    class_instance = module.ActionModule(None)
    assert class_instance.run(None)

# Generated at 2022-06-21 03:06:25.278375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionBase()
    del action_module

# Generated at 2022-06-21 03:06:25.831267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 03:06:26.348538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1

# Generated at 2022-06-21 03:06:26.918861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(True)

# Generated at 2022-06-21 03:08:03.283937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(load_path='foo', task=None, connection='local', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a._shared_loader_obj is None
    assert a._task is None
    assert a._connection == 'local'
    assert a._play_context is None
    assert a._action_plugin_name == 'shell'
    assert a._loader is None
    assert a._templar is None
    assert a._display is None

# Generated at 2022-06-21 03:08:04.345851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionModule) == True

# Generated at 2022-06-21 03:08:08.020080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {'ansible_facts': {'shell_output': 'test'}}
    ansible_module_test_obj = Ansiblemodule(result)

    module_test = ActionModule(ansible_module_test_obj,
                               tmp=None,
                               task_vars=None)

    module_test.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:08:09.414041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None

# Generated at 2022-06-21 03:08:10.334929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:08:15.873088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.legacy import ActionModule as LegacyActionModule
    module = 'ansible.plugins.action.legacy.shell'
    module_path = 'ansible.plugins.action.legacy.shell'

    # When
    result = ActionModule.get_action_class(module, module_path)

    # Then
    assert result is LegacyActionModule

# Generated at 2022-06-21 03:08:24.822951
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("test_ActionModule_run")

    # Simple test with minimal parameters
    module_result = {"changed": False, "failed": False, "invocation": {"module_args": {"chdir": None, "creates": None, "executable": None, "removes": None, "_raw_params": "g++ -o myfile myfile.cpp", "_uses_shell": True, "warn": True}, "module_name": "shell"}, "rc": 0, "stderr": "", "stderr_lines": [], "stdout": "", "stdout_lines": []}

# Generated at 2022-06-21 03:08:31.078275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to_text

    import json
    if not PY3:
        try:
            import simplejson as json
        except ImportError:
            pass

    json_dict = dict()
    json_dict['_ansible_verbosity'] = 0
    json_dict['_ansible_version'] = '2.7.0.dev0'
    json_dict['_ansible_syslog_facility'] = 20
    json_dict['_ansible_no_log'] = False
    json_dict['_ansible_debug'] = False
    json_dict['_ansible_diff'] = False

# Generated at 2022-06-21 03:08:35.324778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test action module works if it is imported
    result = module.run(task_vars=dict(test_key='test_value'))

    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'test_key' in result
    assert result['test_key'] == 'test_value'
    assert 'changed' in result

# Generated at 2022-06-21 03:08:44.587073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection

    class FakeConnection(Connection):
        def __init__(self, runner, host, port=None, *args, **kwargs):
            self.runner = runner
            super(FakeConnection, self).__init__(runner, host, port, *args, **kwargs)

    class FakeRunner(object):
        def __init__(self):
            self.connection = None
            self.module_name = None
            self.module_args = None
            self.result = None
            self.shell = None
            self.package_mgr = None

        def run(self, conn, module_name, module_args, inject=None, complex_args=None, **kwargs):
            self.connection = conn
            self.module_name