

# Generated at 2022-06-21 03:00:23.697751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:00:35.159322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    del tmp  # tmp no longer has any effect

    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)

    return result

# Generated at 2022-06-21 03:00:35.707214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:36.705289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()



# Generated at 2022-06-21 03:00:44.973445
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module_name = "ansible.legacy.shell"

    mock_runner = MagicMock()

    mock_loader = MagicMock()

    action_base_obj = ActionBase(mock_runner, mock_loader)

    action_module_obj = ActionModule(mock_runner, mock_loader, action_base_obj)

    # call the run method
    action_module_obj.run()

    # ActionModule.run method calls the ActionBase.run method with the default arguments
    action_base_obj.run.assert_called_with(tmp=None, task_vars=None)

    # ActionModule.run method calls the ActionBase.run method with module name set to shell
    mock_runner.module_name.assert_called_with(module_name)

# Generated at 2022-06-21 03:00:49.630312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(action_plugin=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(result) == ActionModule

# Generated at 2022-06-21 03:00:56.222308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\nUNIT TESTS FOR METHOD run OF class ActionModule:')
    # Usage: ansible-test units --python tests/units/test_action_plugins.py --testcase test_ActionModule_run
    # test_action_plugins.py shall contain a class called ActionModule with method run
    class ActionModule(object):
        def run(self):
            return 'Hello world'
    ans = ActionModule()
    print('Output of run() method: '+str(ans.run()))

# Generated at 2022-06-21 03:01:06.038509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader, connection_loader, module_loader
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    p = action_loader._get_plugin_loader(class_only=True)
    assert p is not None
    assert p.__name__ == 'ActionModule'

    # Attempt to instantiate ActionModule
    p = action_loader.get(class_only=True)
    assert p.__name__ == 'ActionModule'

    # No module loader
    q = connection_loader.get('shell')
    assert q is None
    mod = module_loader.get(q)

# Generated at 2022-06-21 03:01:13.113159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    #Constructor test
    test_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    #Constructor test with args
    assert test_instance
    test_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)



# Generated at 2022-06-21 03:01:15.176558
# Unit test for constructor of class ActionModule
def test_ActionModule():
        action_module = ActionModule('setup', 'connect')
        print(action_module)



# Generated at 2022-06-21 03:01:24.806167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect

    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)

    return result

# Generated at 2022-06-21 03:01:35.670480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context
    from ansible.inventory.manager import InventoryManager
    import ansible.vars as vars
    import ansible.template as template
    import ansible.plugins.loader_factory as loader_factory
    import ansible.parsing.dataloader as dataloader
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory.data as data
    import ansible.plugins.task_loader as task_loader
    import ansible.plugins.connection as connection
    import ansible.plugins.action as action
    import ansible.playbook.block as block
    import ansible.playbook.role.include as role_include
    import ansible

# Generated at 2022-06-21 03:01:45.880899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dr = { '_ansible_no_log': False,
           '_ansible_verbose_always': True,
           'ansible_loop_var': 'item',
           'changed': False,
           'item': 'Test Task'}
    command_name = 'test_command'
    loader_mock = None
    task_mock = None
    connection_mock = None
    play_context_mock = None
    templar_mock = None
    shared_loader_obj_mock = None

    # create object of ActionModule class

# Generated at 2022-06-21 03:01:51.496288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(args=dict(arg1='foo', arg2='bar')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

# Generated at 2022-06-21 03:01:52.537263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 03:01:54.717639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__bases__[0].__name__ == 'ActionBase'

# Generated at 2022-06-21 03:02:06.361601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock run to replace the original run
    mock_run = MagicMock()
    package = ActionModule.__module__
    # Create a mock command to replace the original command
    mock_command = MagicMock()
    module_command = "ansible.legacy.command"
    # Return the mock objects when invoked
    with patch("%s.ActionModule.run" % package, mock_run):
        with patch("%s.%s" % (package, module_command), mock_command):
            # Create a mock loader
            mock_loader = MockLoader.createMockLoader()
            tmp = None
            task_vars = dict()
            mock_play_context = MockPlayContext.createMockPlayContext()
            # Create a mock task object

# Generated at 2022-06-21 03:02:10.128302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of class ActionModule, which has not been defined anywhere
    action_module = ActionModule()
    assert action_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:02:12.359566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test ActionModule constructor')
    action_module = ActionModule()
    print('ActionModule constructor passed')


# Generated at 2022-06-21 03:02:19.442386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    import ansible.constants as C
    import sys
    import json
    import os
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple
    from ansible.executor.playbook_executor import Play

# Generated at 2022-06-21 03:02:24.534834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-21 03:02:26.261844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of class ActionModule
    actionModule = ActionModule()

# Generated at 2022-06-21 03:02:27.298579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod

# Generated at 2022-06-21 03:02:38.399244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock a task for testing
    task = MockTask()
    # mock task arguments
    task.args = {
        '_uses_shell': False
    }

    # mock a connection for testing
    connection = MockConnection()

    # mock a play_context for testing
    play_context = MockPlayContext()

    # mock a loader for testing
    loader = MockLoader()

    # mock a task_vars for testing
    task_vars = MockTaskVars()

    # mock shared_loader_obj for testing
    shared_loader_obj = MockSharedLoaderObj()

    # create a ActionModule object under testing

# Generated at 2022-06-21 03:02:41.162196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionBase = ActionBase()
    actionModule = ActionModule(actionBase.task, actionBase.connection, actionBase.play_context, actionBase._loader, actionBase._templar, actionBase._shared_loader_obj)
    assert isinstance(actionModule, ActionModule)

# Generated at 2022-06-21 03:02:42.466775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule,ActionBase)

# Generated at 2022-06-21 03:02:43.098703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return 0

# Generated at 2022-06-21 03:02:52.879199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.playbook_context import PlaybookContext

    res = TaskResult(host=None, task=None)
    res.setup = {'task': {}}
    res.task_fields = {}
    res.cleanup = {}
    res.host_fields = {}
    res.failed = False
    res.failed_when_result = False
    res.changed = False
    res.skipped = False

    pc = PlayContext()
    pbc = PlaybookContext()
    am = ActionModule(res, pc, pbc)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 03:03:01.272853
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()

    command_action_object = object()
    command_action_run_return_value = object()

    # Mock class and instances
    tmp = None
    task_vars = dict()

    class AnsibleMock():
        def __init__(self, *args):
            return None

    class AnsibleActionLoaderMock():
        def __init__(self, *args):
            return None

        def get(self, *args):
            return command_action_object

    class CommandActionMock():
        def __init__(self, *args):
            return None

        def run(self, *args):
            return command_action_run_return_value

    class ConnectionMock():
        def __init__(self, *args):
            return None


# Generated at 2022-06-21 03:03:03.917211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionBase = ActionBase()
    actionModule = ActionModule(actionBase)
    assert isinstance(actionModule,ActionModule)
    assert isinstance(actionModule,ActionBase)

# Generated at 2022-06-21 03:03:13.228310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:03:17.066086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    a = action_loader.get('shell', task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:03:18.399500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert a is not None

# Generated at 2022-06-21 03:03:24.315789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import io
    import io
    import io
    import io
    import io
    import io
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import binary_type
    import pytest
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = mystdout = StringIO()
    sys.stderr = mystderr = StringIO()
    x = Action

# Generated at 2022-06-21 03:03:31.880827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test setup stuff
    # TODO: Replace with proper mocking
    import ansible.module_utils.basic  # temporary import
    ansible.module_utils.basic.AnsibleModule = AnsibleModule

    # Test work (single line)
    from ansible.plugins.action.command import ActionModule  # temporary import
    try:
        result = ActionModule().run(tmp=None, task_vars=None)
    except SystemExit:
        result = None
    assert result == 'ActionModule.run()'



# Generated at 2022-06-21 03:03:32.452667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:03:33.373028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:03:33.907130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 03:03:42.004035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_loader = 'loader'
    input_connection = 'connection'
    input_play_context = 'play_context'
    input_shared_loader_obj = 'shared_loader_obj'

    actionModule = ActionModule(input_loader, input_connection, input_play_context, '/path/to/original/file.yml', input_shared_loader_obj)

    # check results
    assert actionModule._loader==input_loader
    assert actionModule._connection==input_connection
    assert actionModule._play_context==input_play_context
    assert actionModule._shared_loader_obj==input_shared_loader_obj
    assert actionModule._original_file=='/path/to/original/file.yml'

    # also check the relationship with 'parent'
    assert actionModule.parent == actionModule
    assert actionModule._

# Generated at 2022-06-21 03:03:52.111541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeAlias(object):
        pass

    class FakeDataLoader(object):
        pass

    class FakeVarsPlugin(object):
        pass

    class FakeTask(object):

        def __init__(self):
            self.args = {'_uses_shell': True}
            self.action = 'command'
            self.name = ''
            self.vars = {}
            self.delegate_to = None

        def set_loader(self, loader):
            self.loader = loader

        def set_delegate(self, host):
            self.delegate_to = host

    class FakeOptions(object):

        def __init__(self):
            self.connection_type = ''
            self.accelerate = ''
            self.accelerate_port = ''
            self.diff = ''
            self.ssh

# Generated at 2022-06-21 03:04:12.893503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell as shell
    mock_loader = Mock()
    mock_play_context = Mock()
    mock_connection = Mock()
    mock_task = Mock()
    action_module = shell.ActionModule(mock_loader, mock_play_context, mock_connection, mock_task)



# Generated at 2022-06-21 03:04:13.800231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 03:04:14.333877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:15.635478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass # For now, nose tests do not work.

# Generated at 2022-06-21 03:04:16.223330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:04:20.184461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action =  ActionModule(play_context=play_context, task=task, connection=connection, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)
    assert type(action) == ActionModule

# Generated at 2022-06-21 03:04:23.257242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule._shared_loader_obj == None
    assert actionModule._task == None
    assert actionModule._connection == None
    assert actionModule._play_context == None
    assert actionModule._loader == None
    assert actionModule._templar == None

# Generated at 2022-06-21 03:04:29.413306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Check that the run method works"""

    import ansible.plugins.action as actionmodule

    a = actionmodule.ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    try:
        a.run()
    except TypeError:
        pass
    except:
        assert False



# Generated at 2022-06-21 03:04:39.393434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        from ansible.plugins.loader import action_loader
    except ImportError:
        # ansible < 2.3
        import ansible.runner.action_plugins.action as action_loader

    m = action_loader.ActionModule.run

    class FauxTask(object):
        def __init__(self, args=None):
            self.args = args or {}
            self.action = 'shell'

    class FauxTaskVars(object):
        pass

    class FauxConnection(object):
        def __init__(self, connection=None):
            if connection is None:
                connection = {}
            self.__dict__.update(connection)


# Generated at 2022-06-21 03:04:48.434409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new ActionModule instance
    m_task_vars = {'ansible_los': ['windows', 'darwin', 'freebsd']}
    m_action_module = ActionModule(task=m_task,
                                   connection=m_connection,
                                   play_context=m_play_context,
                                   loader=m_loader,
                                   templar=m_templar,
                                   shared_loader_obj=m_shared_loader_obj)
    # Test run method
    test_result = m_action_module.run(task_vars=m_task_vars)
    assert test_result['failed'] == False
    assert test_result['ansible_facts']['ansible_message'] == 'Hello from shell'

# Generated at 2022-06-21 03:05:33.707586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action._connection is None
    assert action._loader is None
    assert action._shared_loader_obj is None
    assert action._templar is None
    assert action._task is None



# Generated at 2022-06-21 03:05:35.833512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_action = ActionModule()
    ans = command_action.run()
    assert ans == "success"

# Generated at 2022-06-21 03:05:44.740389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.utils.vars import combine_vars

    # Dummy config
    config = {
        '_ansible_no_log': False,
        'ansible_verbosity': 0,
        'ansible_host': 'localhost',
        'ansible_user': 'root',
        'raises_type_error': 'string'
    }
    # Dummy module_name
    module_name = 'ansible.legacy.shell'
    # Dummy arguments
    args = {
        '_uses_shell': True
    }
    # Dummmpy module_args

# Generated at 2022-06-21 03:05:55.899144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        {},
        "action_plugins/other/shell.py",
        {"action_plugins/other/shell.py": "", "action_plugins/other/__init__.py": ""}
    )

    assert type(action_module) == ActionModule
    assert action_module._task.args == {}
    assert type(action_module._task.async_val) == int
    assert action_module._task.async_val == 0
    assert action_module._task.async_jid == None
    assert type(action_module._task.attributes) == dict
    assert action_module._task.attributes == {}
    assert type(action_module._task.block) == int
    assert action_module._task.block == -1
    assert action_module._task.changed_

# Generated at 2022-06-21 03:06:04.054023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = dict(action=dict(module='shell', args=dict(chdir='testdir', _raw_params='testparams')))
    test_connection = dict()
    test_play_context = dict(become=False, become_user='testbecome_user', check_mode=False, 
        diff_mode=False, directory='testdir', environment=dict(PATH='testpath'), 
        forked=False, ignore_unreachable=False, log_path='testlog_path', 
        remote_addr='testremote_addr', remote_user='testremote_user', 
        shell='/bin/sh', stdin=False)
    test_loader = dict()
    test_tempalar = dict()
    test_shared_loader_obj = dict()


# Generated at 2022-06-21 03:06:05.570178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-21 03:06:14.591681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    b_open = builtins.open

    import mock

    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.legacy_shell import ActionModule

    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Shell module is implemented via command with a special arg
            self._task.args['_uses_shell'] = True


# Generated at 2022-06-21 03:06:15.311117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:06:17.769608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    f = ActionModule('ansible.module_utils.basic')
    assert f._loader.get_basedir() == 'ansible.module_utils.basic'

# Generated at 2022-06-21 03:06:19.630866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """test for constructor of class ActionModule"""
    a = ActionModule()
    assert a is not None


# Generated at 2022-06-21 03:07:57.007697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.adhoc import AdHocCLI

    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    results_callback = AdHocCLI.results_callback
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    loader = DataLoader()

    play_

# Generated at 2022-06-21 03:08:05.534814
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:08:11.348302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Module-specific argument added to get
    # a built-in module with a specific action
    def setup_module_mock(self, task_vars=None):
        module_name = self._task.action
        self._task.args['_uses_shell'] = True
        module_path = self._task.action_loader.get_basedir(module_name)
        module_args = self._task.args.copy()

        return (module_name, module_path, module_args, task_vars)

    from ansible.plugins import action
    import ansible.plugins.action
    from unittest.mock import patch


# Generated at 2022-06-21 03:08:12.505898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    print(obj)

# Generated at 2022-06-21 03:08:20.918763
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate a mock task
    mock_task = MagicMock()

    # Instantiate a mock shared_loader_obj
    mock_shared_loader_obj = MagicMock()

    # Instantiate a mock connection
    mock_connection = MagicMock()

    # Instantiate a mock play_context
    mock_play_context = MagicMock()

    # Instantiate a mock loader
    mock_loader = MagicMock()

    # Instantiate a mock templar
    mock_templar = MagicMock()

    # Instantiate a ActionModule object
    action_module = ActionModule(mock_task,
                                 mock_connection,
                                 mock_play_context,
                                 mock_loader,
                                 mock_templar,
                                 mock_shared_loader_obj)

    # Instantiate a mock command_action

# Generated at 2022-06-21 03:08:21.723806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a

# Generated at 2022-06-21 03:08:29.358186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.my_test_module import my_test_module

    import ansible.plugins.action.shell as shell

    a = shell.ActionModule()

    am = my_test_module()

    am.templar = a._templar
    am.templar.environment = a._templar.environment

    a._loader = am._loader
    a._connection = am._connection
    a._shared_loader_obj = am._shared_loader_obj
    a._task = am._task


# Generated at 2022-06-21 03:08:29.831632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:08:38.619761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    localhost = dict(
        ansible_host='localhost',
        ansible_connection='local',
        ansible_user='root',
        ansible_password='root',
    )

    ansible = dict(
        ansible_host='ansible',
        ansible_connection='ssh',
        ansible_user='ansible',
        ansible_ssh_pass='ansible',
    )

    inventory = [localhost, ansible]

    play = dict(
        hosts=[localhost['ansible_host']],
        gather_facts='no',
        tasks=[dict(
            action=dict(
                module='shell',
                args='ls /'
            )
        )]
    )

    playbook = [play]

    # Generate a task structure

# Generated at 2022-06-21 03:08:46.393706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    # Create action plugin
    action = action_loader.get('debug', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(action) == ActionModule
    assert action._task is None
    assert action._play_context is None
    assert action._connection is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj

    # action._task is set after call of run
    action.run(None, None)
    assert action._task is not None
    assert type(action._task) == Task

    action.run(None, None)