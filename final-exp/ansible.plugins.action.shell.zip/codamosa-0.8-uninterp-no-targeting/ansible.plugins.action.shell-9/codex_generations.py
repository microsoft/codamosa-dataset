

# Generated at 2022-06-21 03:00:22.643888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert(isinstance(a, ActionModule))

# Generated at 2022-06-21 03:00:35.239359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    p = ActionModule()

# Generated at 2022-06-21 03:00:44.165318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    task = Mock(default_args={})
    task.args = {'_uses_shell': False}
    play_context = Mock(default_args={})
    play_context.check_mode = False
    connection = Mock(default_args={})
    loader = Mock(default_args={})
    templar = Mock(default_args={})
    shared_loader_obj = Mock(default_args={})
    shared_loader_obj.action_loader = Mock(default_args={})
    shared_loader_obj.action_loader.get = Mock(return_value={'run': Mock(return_value={})})

    # Create instance of action plugin.

# Generated at 2022-06-21 03:00:46.653908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: better mocking of ActionModule for test
    pass

# Generated at 2022-06-21 03:00:47.416404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:00:51.482593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule({})
    # Create an instance of class Task
    task = {}
    # Declare a dictionary
    task_args = {
        '_uses_shell': True,
    }
    task['args'] = task_args
    action_module._task = task
    # Create an instance of class Connection
    connection = {}
    action_module._connection = connection
    # Create an instance of class PlayContext
    play_context = {}
    action_module._play_context = play_context
    # Create an instance of class DataLoader
    loader = {}
    action_module._loader = loader
    # Create an instance of class Templar
    templar = {}
    action_module._templar = templar
    # Create an instance of class SharedPluginLoaderObj
   

# Generated at 2022-06-21 03:00:56.252452
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_ActionModule = ActionModule("test_loader", "test_connection", "test_play_context", "test_loader", "test_templar")
    test_ActionModule._task.args = {"_shell": "ansible-shell", "_raw_params": "ls -l",
                                    "_uses_shell": True, "_executable": "/bin/sh"}
    print(test_ActionModule.run())

# Generated at 2022-06-21 03:00:57.706532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None

# Generated at 2022-06-21 03:00:58.505720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:01:06.842996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)
    class TestVarManager(object):
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return dict()
    class TestTemplar(object):
        def __init__(self):
            self.var_manager = TestVarManager()
        def set_available_variables(self, variables):
            self.variables = variables
        def template(self, datastring):
            return datastring

# Generated at 2022-06-21 03:01:09.705802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:14.279242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    result = module.run(tmp=None, task_vars=None)

    assert result is not None

# Generated at 2022-06-21 03:01:14.949655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:01:24.016629
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:01:24.795613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:25.665228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:26.454012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:01:36.297882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the mock object
    task_vars = {'ansible_ssh_pass': 'test_ansible_ssh_pass', 'test_task_vars1': 'test_value1'}
    tmp = None
    test_instance = ActionModule(None, None, None, None, None, None, None)

    # Run method with valid data
    result = test_instance.run(tmp, task_vars)
    assert type(result) is dict
    assert 'module_args' in result
    assert result['module_args']['_uses_shell'] == True

    # Run method with empty task_vars
    result = test_instance.run(tmp)
    assert type(result) is dict
    assert 'module_args' in result
    assert result['module_args']['_uses_shell'] == True

# Generated at 2022-06-21 03:01:42.524454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """it should load an action module"""
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    module_loader = ActionBase._shared_loader_obj.module_loader
    templar = Templar(loader=module_loader)
    variable_manager = VariableManager()
    variable_manager.set_inventory(module_loader.get_inventory(loader=module_loader))
    variable_manager.set_loader(module_loader)

# Generated at 2022-06-21 03:01:52.828692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None,
                      play_context=None,
                      action=None,
                      task=None,
                      result=None)
    assert am.connection is None
    assert am.play_context is None
    assert am.action is None
    assert am.task is None
    assert am.result is None
    assert am.task_vars is None
    assert am.tmp is None
    assert am._shared_loader_obj is None
    assert am._loader is None
    assert am._templar is None
    assert am._task is None
    assert am._connection is None

# Generated at 2022-06-21 03:01:58.145844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None

# Generated at 2022-06-21 03:02:07.571811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar, Jinja2TemplateModule
    from ansible import constants as C
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    # create some expensive objects we can re-use across calls
    templar = Templar(loader=None, variables={})

    # we assume that the shell module plugin is available, we can use
    # action_loader to load it
    from ansible.plugins.loader import action_loader

    # Mock Task
    class Task:
        def __init__(self):
            self.args = {'_uses_shell': False}
            self.warnings = []
            self.deprecations = []
            self.notified_handlers = []
            self.failures = []
            self.no_log = []
            self.deprecations_raw

# Generated at 2022-06-21 03:02:09.492344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-21 03:02:15.830636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = None
    task = MockTask()
    loader = None
    shared_loader_obj = MockLoader()
    play_context = MockPlayContext()
    templar = None

    action_module = ActionModule(conn,
                                 task,
                                 loader,
                                 templar,
                                 shared_loader_obj)
    result = action_module.run(task_vars=None)

    assert result is not None
    assert result == {'ansible_facts': {'command': 'ansible.legacy.command'}}


# Generated at 2022-06-21 03:02:17.201282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-21 03:02:21.353358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule(None,'/usr/bin/ansible-vault')
    ActionModule_instance.run(
        tmp='Test_tmp',
        task_vars='Test_task_vars'
    )

# Generated at 2022-06-21 03:02:22.096219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:02:22.727027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:33.184004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class FakeTask(object):
        def __init__(self, args):
            self.args = args

    class FakeTaskQueueManager(object):
        pass

    class FakeLoader(object):
        pass

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.params['remote_user'] = 'root'
            self.params['remote_pass'] = '123456'
            self.params['key_file'] = '/root/.ssh/id_rsa'

    # Construct one instance of class ActionModule

# Generated at 2022-06-21 03:02:36.633266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module_obj = ActionModule()

    # Check if object is instance of module ActionModule
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-21 03:02:44.358046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:02:55.075277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TmpMock:
        def __init__(self):
            pass
    class TmpMock2:
        def __init__(self):
            pass

    class ObjShell:
        def __init__(self):
            self.shell_action = ActionModule(task=TmpMock(), connection=TmpMock(), play_context=TmpMock(), loader=TmpMock(), templar=TmpMock(), shared_loader_obj=TmpMock())
            self.shell_action._task.args = {'_uses_shell': True}
            self.result = False
            self.result = self.shell_action._execute_module(module_name='ansible.legacy.command', module_args=TmpMock2(), task_vars=TmpMock(), wrap_async=False)

# Generated at 2022-06-21 03:03:06.604046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import patch
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import PropertyMock

    loader_mock = MagicMock()

    templar_mock = Templar(loader=loader_mock, variables={})

# Generated at 2022-06-21 03:03:11.491088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(action_pointer = {'args': {'_raw_params': 'pwd', '_uses_shell': True}}, connection_info = {}, task_info = {}, task_uuid =  '', task_vars = {}, loader =  None, templar =  None, shared_loader_obj =  None)
    a.play_context = {'prompt': None}
    a.task = {'register': {}}
    assert a.run()


# Generated at 2022-06-21 03:03:18.664701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'command'
    test_item = {}
    test_item['action'] = module
    test_item['_uses_shell'] = True
    #print("test_item = %s" % test_item)

    fake_task = {'action': module}
    fake_task_args = {}

    #test_class = ActionModule(task=fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    #test_class.run()
    assert True

# Generated at 2022-06-21 03:03:20.042889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    print("test_ActionModule")
    assert actionModule != None

# Generated at 2022-06-21 03:03:28.336298
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:03:29.279252
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    my_object = ActionModule()

# Generated at 2022-06-21 03:03:31.034622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert module._task.args['_uses_shell'] is True

# Generated at 2022-06-21 03:03:36.773229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("")
    print("****************************************************************")
    print("**** Test Start: test_ActionModule_run ****")
    print("****************************************************************")

    # Creating a class object
    actionmodule = ActionModule()

    # Empty Variables
    my_tmp = None
    my_task_vars = None

    # Calling the method run
    actionmodule.run(my_tmp, my_task_vars)

    print("**** Test End: test_ActionModule_run ****")



# Generated at 2022-06-21 03:03:56.452478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test without required parameters
    try:
        ActionModule()
        assert False, "Missing required parameters should have thrown an exception"
    except TypeError:
        assert True
    # Test with required parameters
    ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert True


# Generated at 2022-06-21 03:04:04.681963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.legacy.shell.action as shell_action
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import PluginLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import ActionModuleComponent

    action_module = shell_action.ActionModule()
    assert action_module._shared_loader_obj is None
    assert action_module._task is None

# Generated at 2022-06-21 03:04:14.691216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from io import StringIO
    from ansible import context
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar

    setattr(context, 'CLIARGS', {'module_path': '', 'forks': 10, 'become': False, 'become_method': 'sudo', 'become_user': None, 'check': False, 'diff': False})

    class FakeSharedLoaderObj(object):
        def __init__(self):
            self.action_loader = FakeActionLoader()

    class FakeActionLoader(object):
        def __init__(self):
            self.actions = dict()

        def get(self, action_name, *args, **kwargs):
            return FakeAction(**kwargs)

    class FakeConnection(object):
        _shell = True
       

# Generated at 2022-06-21 03:04:20.141307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None,
                          _shared_loader_obj=None,
                          connection=None,
                          play_context=None,
                          new_stdin=None,
                          _task=None,
                          _shell_executable=None,
                          _shell_excutable=None)
    assert module != None

# Generated at 2022-06-21 03:04:22.404062
# Unit test for constructor of class ActionModule
def test_ActionModule():
   action_module = ActionModule()
   return action_module

if __name__ == "__main__":
   action_module = test_ActionModule()
   print(action_module)

# Generated at 2022-06-21 03:04:23.821677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-21 03:04:24.875964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:04:27.307150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None, task=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-21 03:04:36.362579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import shared_loader_obj

    # Create an instance of ActionModule in order to execute the method run
    action_module_instance = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=shared_loader_obj)

    # Define a mock value for tmp
    tmp = None

    # Define a mock value for task_vars
    task_vars = None

    result = action_module_instance.run(tmp=tmp, task_vars=task_vars)

    # Assert that the result corresponds to the expected one
    assert result == None

# Generated at 2022-06-21 03:04:45.101236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    g = globals()
    g['cls.a'] = ActionModule(single_value=['test'],
                              boolean=True,
                              integer=3,
                              list_of_values=['1', '2'],
                              list_of_integers=[1, 2, 3],
                              key_value=dict(key1='value1', key2='value2'),
                              dict_of_dicts=dict(key1=dict(key2='value2')))

    assert g['cls.a'].single_value == 'test'
    assert g['cls.a'].boolean is True
    assert g['cls.a'].integer == 3
    assert g['cls.a'].list_of_values == ['1', '2']

# Generated at 2022-06-21 03:05:24.651669
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_name = 'ansible.legacy.shell'
    action_class = 'ansible.legacy.shell.ActionModule'

    assert_contains_no_none(action_name, action_class)

    # Task and connection information
    task = {
        'action': 'shell',
        'args': {
            '_raw_params': 'date +"TZ=%Z"'
        },
        'name': 'shell test'
    }

    tmp = '/tmp'

    # Create and instance of the class we test
    action_module = ActionModule(task, tmp, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Returns and instance of action plugin
    command_action = action_module._shared_loader_obj.action_loader.get

# Generated at 2022-06-21 03:05:33.824936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host

    host = Host(name='dummy')

# Generated at 2022-06-21 03:05:43.412399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import json

    import pytest
    from mock import Mock, patch

    json_output = {
        'rc': 0,
        'stdout': 'xxx',
        'stdout_lines': [],
        'results': 'xxx'
    }

    module_return_value = copy.deepcopy(json_output)
    module_return_value['changed'] = True

    task_args = {'_uses_shell': True}

    action_base = ActionBase()

    loader_mock = Mock()
    action_loader_mock = Mock()
    action_loader_mock.get = Mock(return_value=action_base)

    command_module_mock = Mock()
    command_module_mock.run = Mock(return_value=module_return_value)


# Generated at 2022-06-21 03:05:44.549197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run(None, None) is None



# Generated at 2022-06-21 03:05:55.641628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import merge_hash
    from ansible.vars.hostvars import HostVars

    # Prepare test data
    class DummyVarsModule:
        def __init__(self):
            self.hostvars = HostVars(loader=DataLoader(), variable_manager=VariableManager())

# Generated at 2022-06-21 03:06:03.869357
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of class ActionModule
    # Argument temporary directory
    tmp_dir = '/nas/home/adb/test_module_action/test_action_module.py/test_ActionModule_run/'

    # Argument temporary variables

# Generated at 2022-06-21 03:06:13.834183
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action.shell import ActionModule
    import ansible.plugins.action.shell


    # New ActionModule object
    #  args: {'_uses_shell': True}
    #  task: action_shell_task
    #  connection: local
    #  play_context: PlayContext()
    #  loader: DataLoader()
    #  templar: Templar()
    #  shared_loader_obj: None
    def action_shell_task(self):
        return ansible.plugins.action.shell.ActionModule

    action_shell_task = action_shell_task(ActionModule)

# Generated at 2022-06-21 03:06:24.721131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule
    '''
    ###########################################################################
    # Setupmock objects
    ###########################################################################
    module_spec = {'argument_spec': {}, 'supports_check_mode': True}
    loader_mock = MagicMock()
    templar_mock = MagicMock()
    shared_loader_obj = MagicMock()
    task_mock = MagicMock()
    connection_mock = MagicMock()
    play_context_mock = MagicMock()
    # End of Setupmock objects
    ###########################################################################

    ###########################################################################
    # Setupmock objects
    ###########################################################################
    task_mock.args = {'_uses_shell': True}
    command_action = MagicMock()
    #

# Generated at 2022-06-21 03:06:34.355152
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionBase

    # Mock class for ansible.plugins.action.ActionBase
    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {'results': 'fake results'}

    # Create instance of the class to be tested
    am = ActionModule()

    # Replace attributes of the mocked ActionBase with the class to be tested
    am._shared_loader_obj = MockActionBase()
    am._task = MockActionBase()
    am._connection = MockActionBase()
    am._play_context = MockActionBase()
    am._loader = MockActionBase()
    am._templar = MockActionBase()

    # Call the 'run' method and get the results

# Generated at 2022-06-21 03:06:35.919275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
        assert False
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-21 03:08:09.195249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:08:18.537180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = mock.Mock()
    conn.shell = '/path/to/ansible/shell'
    Task = mock.Mock()
    Task.args = {
        '_ansible_shell_executable': '/path/to/ansible/shell'
    }
    Task.action = 'shell'
    variable_manager = mock.Mock()
    loader = mock.Mock()
    play_context = mock.Mock()
    play_context.check_mode = False
    variable_manager = mock.Mock()
    shared_loader_obj = mock.Mock()

    am = ActionModule(Task, conn, play_context, loader, variable_manager, 'path/to/ansible/plugins/support', shared_loader_obj)
    assert am is not None

# Generated at 2022-06-21 03:08:20.697262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 03:08:28.612705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test of constructor
    """
    # Constructor ActionModule already called by ansible.plugins.action.ActionBase.load_action_plugin
    # task = {'args': {'_uses_shell': True}}
    # shared_loader_obj = ansible.plugins.loader.ActionLoader(None)
    # loader = ansible.parsing.dataloader.DataLoader()
    # templar = ansible.parsing.yaml.objects.AnsibleTemplar(None)
    # connection = ansible.plugins.connection.Connection()
    # play_context = ansible.playbook.play_context.PlayContext(None)
    # action_module = ActionModule(
    #     task=task,
    #     connection=connection,
    #     play_context=play_context,
    #

# Generated at 2022-06-21 03:08:37.366866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = "test"
    connection = "localhost"
    play_context = 1
    loader = "loader"
    templar = "templar"
    shared_loader_obj = "loader_obj"

    a = ActionModule(task=task, connection=connection, play_context=play_context, loader=loader,
                     templar=templar, shared_loader_obj=shared_loader_obj)

    assert a._task == task
    assert a._connection == connection
    assert a._play_context == play_context
    assert a._loader == loader
    assert a._templar == templar
    assert a._shared_loader_obj == shared_loader_obj
    # This will fail because we do not have a real ansible.legacy.command.ActionModule available
    # assert a.command_action == "

# Generated at 2022-06-21 03:08:45.657013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Mock the connection, things to test:
    1. Working of command action in action module
    2. Check the items that are generated
    """
    from ansible.module_utils.six.moves import StringIO
    from ansible.modules.system import ping as Ping_Module
    from ansible.plugins.action import ActionBase

    ping_module = Ping_Module()
    task_vars = dict()
    result = dict(changed=False, msg="Ping worked")
    setattr(ping_module, 'run', lambda *x, **y: result)

    # Create action class object
    action_obj = ActionModule()
    setattr(action_obj, '_templar', None)
    setattr(action_obj, '_task', None)
    setattr(action_obj, '_connection', None)


# Generated at 2022-06-21 03:08:46.102739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod=ActionModule()

# Generated at 2022-06-21 03:08:49.632556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit tests for method run of class ActionModule """
    module = ActionModule()
    task_vars = {}

    assert module.run(task_vars=task_vars) is not None

# Generated at 2022-06-21 03:08:53.605585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        from ansible.plugins.action import ActionModule
        ActionModule()
        assert True
    except:
        assert False


# Generated at 2022-06-21 03:09:01.628544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(shell='/bin/false', test_param=True, arg1=1, arg2=2, arg3=3)
    task = dict(name='test', action='shell', args=args)
    play_context = dict(remote_user='test_user')
    new_stdin = False
    connection = 'local'
    shared_loader_obj = None
    loader = None
    templar = None
    hostvars = dict()

    am = ActionModule(task, play_context, new_stdin, connection, loader=loader,
                      templar=templar, shared_loader_obj=shared_loader_obj)
    am.run(task_vars=dict(hostvars=hostvars))