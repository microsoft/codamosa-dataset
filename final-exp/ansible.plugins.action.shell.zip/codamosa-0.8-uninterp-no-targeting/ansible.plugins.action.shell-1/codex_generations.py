

# Generated at 2022-06-21 03:00:33.014052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect

    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)


    # Unit tests for method "run"
    # Unit test for statement "del tmp  # tmp no longer has any effect"
    assert tmp is None

    # Unit test for statement "self._task.args['

# Generated at 2022-06-21 03:00:39.154055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    The constructor ActionModule should use the name provided.
    '''
    # Create class without name
    action_module = ActionModule()

    assert action_module.name is None, "Name of ActionModule should be 'None' but is " + action_module.name


# Generated at 2022-06-21 03:00:47.006415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext(remote_user='dummy', connection='local')

# Generated at 2022-06-21 03:00:48.077393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(runner=None)

# Generated at 2022-06-21 03:00:48.637163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert not module

# Generated at 2022-06-21 03:00:49.098438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:53.639244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the ActionModule
    module = ActionModule()
    assert isinstance(module, ActionModule)
    assert module.__module__ == 'ansible.plugins.action.shell'
    assert module.__doc__.startswith('EXPERIMENTAL.')



# Generated at 2022-06-21 03:00:58.433692
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.shell
    tmp = None
    ansible.plugins.action.shell.ActionModule(None, None, tmp, None, None, None, None)


# Generated at 2022-06-21 03:01:00.292818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action


# Generated at 2022-06-21 03:01:07.490600
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import tempfile

    # Constructor of ActionBase does not require any arguments
    from ansible.plugins.action.shell import ActionModule
    action_object = ActionModule(None, None, None, None, None)

    # Check for method/member existence
    assert action_object.run != None
    assert action_object.run_command != None
    assert action_object.run_command.__name__ == "run_command"

    # Check for data member existence
    assert action_object._task != None
    assert action_object._connection != None
    assert action_object._play_context != None
    assert action_object._loader != None
    assert action_object._shared_loader_obj != None
    assert action_object._loader_name != None
    assert action_object._templar != None
    assert action_object._tmp != None

# Generated at 2022-06-21 03:01:19.604742
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:01:27.481245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.constants as C
    from collections import namedtuple
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import merge_hash
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-21 03:01:36.453621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.builtin import ActionModule
    class Args(object):

        def __init__(self, args=None):
            self.args = args

        def __call__(self):
            return self.args

    from ansible.plugins.action import ActionBase
    class ActionBase(ActionBase):

        def run(self, tmp=None, task_vars=None):
            pass

    am = ActionModule(Args(args={'_uses_shell': True}),
                      task=ActionBase(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None),
                      connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am

# Generated at 2022-06-21 03:01:46.187839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._task.args['_uses_shell'] = True
    actionModule._task.args['_raw_params'] = "ls"
    actionModule._task.args['_raw_params'].split()
    actionModule._task.args['chdir'] = None
    actionModule._task.args['executable'] = None
    actionModule._task.args['_uses_shell'] = True


# Generated at 2022-06-21 03:01:46.618412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:49.498028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = {
        'shell': 'echo',
        'args': 'Hello, world'
    }

    action_module = ActionModule(fake_task, '/tmp/', '', '', '', '', '', '', '')
    assert action_module is not None

# Generated at 2022-06-21 03:01:54.330005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Task()
    task.args['_uses_shell'] = True
    action = ActionModule(task, Connection(), 'loader', 'templar', 'shared_loader')
    task_vars = {'vars': "value"}
    assert action.run(task_vars=task_vars) == {'changed': False, 'failed': False, 'rc': 0, 'stderr': '', 'stdout': ''}


# Generated at 2022-06-21 03:02:04.051777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.command import ActionModule as CommandModule

    my_action_module = CommandModule(
        {},
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    task_vars = {}

    result = my_action_module.run(task_vars=task_vars)

    assert isinstance(result, dict) is True
    assert result['rc'] != 0
    assert 'stdout' in result

# Generated at 2022-06-21 03:02:15.136352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import Facts
    from ansible.plugins.action.shell import ActionModule
    from ansible.utils.sentinel import Sentinel
    ansible_module_installed_shell = Sentinel()
    ansible_module_installed_command = Sentinel()
    ansible_module_installed_service = Sentinel()
    ansible_module_installed_service_mgr = Sentinel()
    ansible_module_installed_system = Sentinel()
    ansible_module_installed_copy = Sentinel()
    ansible_module_installed_script = Sentinel()
    ansible_module_installed_raw = Sentinel()
    ansible_module_installed_synchronize = Sentinel()
    ansible_module_installed_setup = Sentinel()
    ansible_module_installed_patch = Sentinel()
    ansible_module_installed_user = Sentinel()

# Generated at 2022-06-21 03:02:26.434759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # import unit test modules
        from ansible_collections.ansible.community.plugins.tests.unit.plugins.actions import test_action_base as action_base
        from ansible_collections.ansible.community.plugins.tests.unit.plugins.module_utils import test_runner as runner

        from ansible_collections.ansible.community.plugins.modules.network.icx.icx_command import ActionModule as action_module
    except ImportError as e:
        print('ImportError: {0}'.format(e))
        raise ImportError

    # create object of AnsibleModule class
    am = action_base.ActionBase()

    # create object of ActionModule class
    sm = action_module(am)

    # create object of Runner class
    t = runner.Runner(am)

    # call method

# Generated at 2022-06-21 03:02:39.587513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule
    def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
        self._task = task
        self._connection = connection
        self._play_context = play_context
        self._loader = loader
        self._templar = templar
        self._shared_loader_obj = shared_loader_obj
        self._add_cleanup_task = False
        self._cleanup_task = None
        if task.action in ('setup', 'include_role', 'include_tasks'):
            # If a module uses a tmp path, make sure it is cleaned up
            self._add_cleanup_task = True

# Generated at 2022-06-21 03:02:50.001622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = Ansible()
    ansible.play = Play()
    ansible.play.playbook = Playbook()
    ansible.play.playbook.loader = DictDataLoader({})
    connection = MockConnection()
    task = Task()
    task.action = 'shell'
    task.args = {'cmd': 'echo hello'}
    action = ActionModule(task, connection, ansible._loader, '/tmp/', task.args)
    assert action.action == 'shell'
    assert action.task == task
    assert action.task_vars == {}
    assert action.connection == connection
    assert action._loader == ansible._loader
    assert action._templar == ansible._templar
    assert action._shared_loader_obj == ansible._shared_loader_obj
    assert action._connection == connection


# Generated at 2022-06-21 03:02:51.743861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    f = ActionModule()

    assert isinstance(f, ActionBase)

# Generated at 2022-06-21 03:02:53.894739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an ActionModule object for testing
    am = ActionModule(None, None, None, None, None, None)

    assert am

# Generated at 2022-06-21 03:02:58.344440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = MagicMock()
    connection = MagicMock()
    play_context = MagicMock()
    loader = MagicMock()
    templar = MagicMock()
    shared_loader_obj = MagicMock()
    am = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert am is not None

# Generated at 2022-06-21 03:03:01.393200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule('ansible')
    assert x.name == 'ansible'


# Generated at 2022-06-21 03:03:02.014711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:03:10.577951
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:03:13.067245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,None,{},None).__class__.__name__ == "ActionModule"

# Generated at 2022-06-21 03:03:14.079752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule, 'The ActionModule class exists'

# Generated at 2022-06-21 03:03:23.676885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 03:03:24.192786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:25.059142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 03:03:36.090276
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:03:37.568871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test that the constructor returns a valid instance of the class
    """
    assert ActionModule is not None

# Generated at 2022-06-21 03:03:43.849241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.test_action = action_loader.get('ansible.legacy.shell', task=None)
            self.test_action._connection = 'conn'
            self.test_action._loader = 'loader'
            self.test_action._play_context = 'play_context'
            self.test_action._shared_loader_obj = 'shared_loader_obj'
           

# Generated at 2022-06-21 03:03:45.049674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    assert ActionModule

# Generated at 2022-06-21 03:03:51.800363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import cli

    from ansible.plugins.loader import shared_loader_obj

    from lib.mock_connection import MockConnection

    from lib.mock_play_context import MockPlayContext

    from lib.mock_task import MockTask

    action_module = ActionModule(shared_loader_obj, MockTask(), MockConnection('local'), MockPlayContext())

    action_module.run(task_vars={'test': 'task_vars'})

# Generated at 2022-06-21 03:03:57.635717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
            {"name":"setup","subset":"all"},
            connection={"host": "", "user": "", "password": ""},
            play_context={"check_mode": False, "accept_hostkey": False, "verbosity": 0, "extra_vars":{}, "start_at_task": None},
            loader=None,
            templar=None,
            shared_loader_obj=None)
    assert am

# Generated at 2022-06-21 03:03:58.187580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()


# Generated at 2022-06-21 03:04:14.927050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run of class ActionModule")

    # TODO: Implement

# Generated at 2022-06-21 03:04:24.876343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    testPath = os.path.dirname(os.path.abspath(__file__))
    testDir = os.path.join(testPath, 'test_action_plugin')
    parser = argparse.ArgumentParser(description='Test Ansible plugin')
    parser.add_argument('--test-inventory', dest='test_inventory',
                        action='store', required=True,
                        help='Directory of test inventory')
    parser.add_argument('--host-pattern', dest='host_pattern',
                        action='store', default='all',
                        help='Host pattern to run the test play against')
    args = parser.parse_args()

    inventory = ansible.inventory.Inventory(args.test_inventory)
    variable_manager = ansible.inventory.VariableManager(inventory)
    loader = ansible.parsing.datal

# Generated at 2022-06-21 03:04:25.361041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:27.896716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    task_vars = dict()
    result = action.run(task_vars=task_vars)
    assert result == dict()

# Generated at 2022-06-21 03:04:39.392402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import plugin_loader
    from ansible.module_utils.common.text.converters import to_text
    from ansible.playbook.task import Task

    mock_task = Task()
    mock_task.args = {}
    action = ActionModule(loader=plugin_loader, task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert type(action) is ActionModule
    assert type(action.run(None, None)) is dict
    assert action.action_name == 'ansible.legacy.shell'
    assert action.action_loader.__class__.__name__ == 'ActionModuleLoader'

# Generated at 2022-06-21 03:04:44.997360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = '127.0.0.1'
    port = 80
    username = 'root'
    password = 'password'
    private_key_file = ''
    become_method = 'sudo'
    become_user = 'root'
    become_pass = 'password'
    result = None

    # TODO: Unit test not implemented
    # https://github.com/ansible/ansible/issues/21401
    # https://github.com/ansible/ansible/issues/22498

    assert result == None

# Generated at 2022-06-21 03:04:49.901190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell

    class dummy_ActionModule_has_run(ansible.plugins.action.shell.ActionModule):
        def run(self, tmp=None, task_vars=None):
            return False

    dummy = dummy_ActionModule_has_run(None, None, None, None, None)
    result = dummy.run(tmp=None, task_vars=None)
    assert result == False

# Generated at 2022-06-21 03:04:55.381415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize test variables.
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # test that the class was initialized properly
    assert action_module.task == None
    assert action_module.connection == None
    assert action_module.play_context == None
    assert action_module.loader == None
    assert action_module.templar == None
    assert action_module.shared_loader_obj == None
    # ActionModule does not need to be tested since it is just a wrapper for command
    # and ansible.legacy.command has been tested.

# Generated at 2022-06-21 03:05:00.143766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestTask:
        def __init__(self):
            self.args = dict()

    class TestConnection:
        def __init__(self):
            self.connection_info = dict()

        def connect(self):
            return None, None

        def close(self):
            return None

    class TestPlayContext:
        def __init__(self):
            self.remote_user = None
            self.connection = None
            self.password = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.become_pass = None
            self.no_log = None
            self.network_os = None

    class TestLoader:
        def __init__(self):
            self.searchpath = None


# Generated at 2022-06-21 03:05:05.789997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        import ansible.plugins.action.shell
        from ansible.plugins.action.shell import ActionModule
        obj = ActionModule('module_args', 'task_vars')
        assert obj is not None
    except Exception as e:
        print("Exception in test_ActionModule: %s" % str(e))
        assert True == False


# Generated at 2022-06-21 03:05:56.148366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell

    # Constructor
    args_mock = {'_ansible_selinux_special_fs': False,
                 '_ansible_check_mode': False,
                 '_ansible_no_log': False,
                 '_ansible_verbosity': 4,
                 '_uses_shell': True,
                 'chdir': None,
                 'creates': None,
                 'executable': None,
                 'removes': None}

    ans_mock = ActionBase()
    ans_mock.task = {'args': args_mock}
    shell_action = ansible.plugins.action.shell.ActionModule(ans_mock)

    # Assert
    assert shell_action._shell_type == 'sh'
    assert shell_action._shell_executable

# Generated at 2022-06-21 03:05:59.787343
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule('ansible.legacy.shell',
      task = None, 
      connection = None, 
      play_context = None, 
      loader = None, 
      templar = None,
      shared_loader_obj = None)

  assert am


# Generated at 2022-06-21 03:06:00.491560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:06:01.347981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:06:12.037584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import json
    import pytest
    import mock
    import shutil
    import ansible.legacy.action

    
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.plugins.action import Shell
    from ansible.plugins.action import Command
    from ansible.errors import AnsibleActionFail
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import iteritems
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to

# Generated at 2022-06-21 03:06:12.572644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1

# Generated at 2022-06-21 03:06:23.613907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.action import ActionBase

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook.task import Task

    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.utils.display import Display
    display = Display()

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-21 03:06:27.319445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock config object, ActionBase requires this
    mock_config = dict()
    mock_config['ANSIBLE_LIBRARY'] = '/path/to/ansible/library'
    mock_config['ANSIBLE_MODULE_UTILS'] = '/path/to/ansible/module/utils'
    mock_config['DEFAULT_MODULE_UTILS_PATH'] = '/path/to/default/module/utils'

    # Create a mock task object
    mock_task = dict()
    mock_task['action'] = 'shell'
    mock_task['args'] = {'chdir': '/path/to/cwd', 'executable': '/bin/bash', '_raw_params': 'ls -al /tmp'}
    mock_task['async'] = 3600
    mock_task['async_val'] = 36

# Generated at 2022-06-21 03:06:28.317031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()

# Generated at 2022-06-21 03:06:35.059849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    fake_task = Task()
    fake_task.action = 'shell'

    action = action_loader._create_action(
        'ansible.legacy.shell',
        fake_task,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action is not None
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 03:08:13.110361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    myActionModule = ActionModule()
    myActionModule.run(tmp, task_vars)

# Generated at 2022-06-21 03:08:13.611280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:08:21.970776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing if the module run method is called with the expected arguments
    """
    # Arrange
    command_mock = Mock()
    command_mock.run.return_value = None
    task = Mock()
    task.args = {}
    connection = None
    play_context = Mock()
    loader = Mock()
    templar = Mock()
    shared_loader_obj = Mock()
    shared_loader_obj.action_loader.get.return_value = command_mock
    action_module = ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj
    )

# Generated at 2022-06-21 03:08:29.516498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_text

    # Create a class instance passing the constructor
    # Test class import, instantiation and passing constructor to class
    class_instance = ActionModule()

    if PY2:
        stderr = sys.stderr
    else:
        stderr = StringIO()

    # Create class_instance with ActionBase using constructor, action_loader and task.
    # Test the first use of super on ActionBase.
    # Since we are passing the constructor we need to use the metaclass hack
    # This is just one way of doing it.
    class_instance = ActionBase.__new__(ActionModule)
    class_instance.__

# Generated at 2022-06-21 03:08:31.605881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-21 03:08:32.154696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:08:34.539855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_name = 'ansible.legacy.shell'
    args = {}
    assert ActionModule(class_name, args) is not None


# Generated at 2022-06-21 03:08:44.103776
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # define test options
    options = {
        '_ansible_verbosity': 0,
        '_ansible_check_mode': False,
        '_ansible_no_log': False,
        '_raw_params': 'echo "hello world"',
        '_uses_shell': True,
    }

    # define test task dictionary
    from ansible.module_utils._text import to_text
    task_dic = {}
    task_dic['args'] = options
    # define test task
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_key': 'test_value'}

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-21 03:08:47.129560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test valid case
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.run(tmp=None, task_vars=None) != None

# Generated at 2022-06-21 03:08:56.828300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    from units.mock.loader import DictDataLoader

    args = dict(
        _raw_params='echo -n foo',
        _uses_shell=True,
        chdir=None,
        _raw_args='echo -n foo',
        creates=None,
        executable=None,
        removes=None,
        warn=True,
    )
