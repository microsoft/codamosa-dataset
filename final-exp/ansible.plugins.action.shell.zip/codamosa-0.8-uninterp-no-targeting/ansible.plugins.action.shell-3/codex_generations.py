

# Generated at 2022-06-21 03:00:26.864241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    am = ActionModule()
    xtest = ActionBase()
    xtest.test = 'Test'
    test = copy.deepcopy(xtest)
    am.set_loader(xtest)
    assert(test.test == 'Test')
    assert(am.test == 'Test')
    assert(not hasattr(am, 'templar'))


# Generated at 2022-06-21 03:00:33.060834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test object
    task = {}
    args = {}
    task_vars = {}
    temp = None
    connection = None
    play_context = {}
    loader = None
    templar = None
    shared_loader_obj = None

    obj = ActionModule(task,args,task_vars,temp,connection,play_context,loader,templar,shared_loader_obj)

    # test successful run with debug disabled
    #args['_ansible_debug'] = False
    #assert obj.run(tmp=temp, task_vars=task_vars) is None

    # test successful run with debug enabled
    args['_ansible_debug'] = True
    assert obj.run(tmp=temp, task_vars=task_vars) is None

# Generated at 2022-06-21 03:00:37.492318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None
    assert am._task is not None

# vim: set noexpandtab ts=4 sw=4:

# Generated at 2022-06-21 03:00:45.842528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import builtins
    import ansible.plugins
    import ansible.plugins.action
    import ansible.module_utils
    import ansible.module_utils.connection

    class TestActionModule(object):
        execution_path = pathlib.Path('.')
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

        def run(self, task_vars):
            del task_vars

            self._task.args['_uses_shell'] = True

            command_

# Generated at 2022-06-21 03:00:55.722225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.connection import Connection
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    opts = PlaybookExecutor.load_default_options()
    loader = DataLoader()
    inventories = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventories)
   

# Generated at 2022-06-21 03:01:05.836319
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:01:11.337376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing 'ansible.legacy.shell' module's constructor
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m is not None


# Generated at 2022-06-21 03:01:21.307942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct a task, task_vars based on real tasks
    task_vars = {"_ansible_check_mode": False,
                 "_ansible_verbosity": 0,
                 "role_path": "/etc/ansible/roles",
                 "ansible_loop_var": "item",
                 "ansible_limit_name": "all",
                 "ansible_diff": False,
                 "_ansible_no_log": False,
                 "role_name": "generic"}


# Generated at 2022-06-21 03:01:28.709059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    if sys.version_info[0] < 3:
        from mock import mock_open
    else:
        from unittest.mock import mock_open

    def get_mock_task(self, args):
        args['_uses_shell'] = True
        return self._loader.load_from_file(args['_original_file'], args)

    with mock.patch(
        'ansible.plugins.loader.ActionModuleLoader.get',
        new=mock.Mock(return_value=get_mock_task)
    ):
        with mock.patch(
            'ansible.plugins.loader.ActionModuleLoader.add_directory',
            new=mock.Mock(return_value=None)
        ):
            loader = DictDataLoader(dict())
            tmp_path = os

# Generated at 2022-06-21 03:01:37.118203
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from mock import Mock, patch
    from ansible.plugins.loader import ActionLoader

    # Test creation
    action_module = ActionModule(
        task=Mock(),
        connection=Mock(),
        play_context=Mock(),
        loader=Mock(),
        templar=Mock(),
        shared_loader_obj=Mock())

    # Test run
    action_loader = ActionLoader()

    action_module._task.args = {
        '_uses_shell': False,
        'chdir': '/a/fake/path',
        'free_form': 'ls -la',
    }

    action_loader.get.return_value._templar.template.return_value = '/a/fake/path'


# Generated at 2022-06-21 03:01:43.738748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.connection import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import PluginLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    mod_action = ActionModule(connection=Connection(),
                              play_context=PlayContext(),
                              loader=PluginLoader(),
                              templar=Templar(loader=PluginLoader(),
                                              variables=VariableManager()),
                              shared_loader_obj=None)
    assert isinstance(mod_action, ActionModule)

# Generated at 2022-06-21 03:01:54.888913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.command import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.task_result import TaskResultProcess
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.utils.vars import combine_vars
    import os
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)


# Generated at 2022-06-21 03:02:06.427287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests.mock import MagicMock

    class ActionMock(MagicMock):
        pass

    class CommandActionMock(MagicMock):
        def run():
            return None

    am = ActionModule()
    am._task = ''
    am._task.args = {}
    am._shared_loader_obj = ActionMock()
    am._task = ActionMock()
    am._connection = ActionMock()
    am._play_context = ActionMock()
    am._loader = ActionMock()
    am._templar = ActionMock()
    am._shared_loader_obj = ActionMock()
    am._shared_loader_obj.action_loader = ActionMock()

# Generated at 2022-06-21 03:02:16.778417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    task = ansible.plugins.action
    task.args = {'_uses_shell': True, '_raw_params': 'ls -l'}
    task.action = 'shell'
    task.async_val = None
    task.async_jid = None
    task.become = False
    task.delegate_to = None
    task.environment = None
    task.first_available_file = None
    task.forced_handlers = None
    task.loop = None
    task.loop_args = None
    task.name = None
    task.no_log = False
    task.notify = None
    task.poll = 0
    task.sudo = False
    task.sudo_user = None
    task.tags = []
    task.until = None


# Generated at 2022-06-21 03:02:23.422168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    try:
        action_module.run()
    except AttributeError:
        pass
    except Exception as exception:
        assert False, "Unexpected exception raised: %s" % exception

    action_module._task.args['command'] = 'echo'
    action_module._task.args['args'] = {'stdout': 'yes', 'stderr': 'yes'}
    assert action_module.run()

# Generated at 2022-06-21 03:02:34.817144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	task_vars = {'ansible_check_mode': False, 'ansible_connection': 'local', 'ansible_play_batch': '18', 'ansible_play_hosts': 'localhost', 'ansible_playbook_python': '/usr/bin/python', 'ansible_verbosity': 0, 'a': 'b', 'c': 'd'}
	action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:02:38.398682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Required for creating an instance of connectsion
    import ansible.plugins.connections as connections
    from ansible.plugins.loader import _find_action_plugin

    _find_action_plugin("setup")
    connection = connections.create("local", None, None, None)
    a = ActionModule(connection, None, None, None, None, None)

# Generated at 2022-06-21 03:02:38.879901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:02:48.206025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()");
    #pass;
    
    #create objects
    task_vars = None;
    command_action = ActionModule();
    
    #call method
    result = command_action.run(tmp=None, task_vars = task_vars);
    #test
    assert(result['rc'] == 0);
    assert(result['stdout'] == '');
    assert(result['stderr'] == '');
    assert(result['stdout_lines'] == []);
    assert(result['stderr_lines'] == []);
    assert(result['stdout_lines_original'] == []);
    assert(result['stderr_lines_original'] == []);


# Generated at 2022-06-21 03:02:58.157121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = dict()
    # Mock task
    t['args'] = dict()
    t['args']['_uses_shell'] = True

    # Mock connection, play_context, loader, templar, shared_loader_obj
    c = dict()
    pc = dict()
    l = dict()
    tem = dict()
    slo = dict()

    # Mock task_vars
    tv = dict()

    # Mock command_action
    ca = dict()
    ca['run'] = dict()
    ca['run']['return_value'] = dict()
    ca['run']['return_value']['rc'] = 0
    ca['run']['return_value']['stdout'] = 'some string'

# Generated at 2022-06-21 03:03:01.215053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test code
    assert True

# Generated at 2022-06-21 03:03:01.866392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:09.702010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_args = dict(
        _raw_params='ls',
        _uses_shell=True,
        _tmpdir='/tmp',
        _ansible_tmpdir='/tmp'
    )
    test_task = dict(args=test_args)
    test_task_vars = dict()
    test_connection = dict()
    test_play_context = dict()
    test_loader = dict()
    test_templar = dict()
    test_shared_loader_obj = dict()

    ActionModule.run(test_task, test_task_vars, test_connection, test_play_context, test_loader, test_templar, test_shared_loader_obj)

# Generated at 2022-06-21 03:03:13.716254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection='connection',
                          play_context='play_context',
                          loader='loader',
                          templar='templar',
                          shared_loader_obj='shared_loader_obj')
    assert module != None

# Generated at 2022-06-21 03:03:16.826992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
            task=None,
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 03:03:23.656795
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Note: This unit test is run only if ansible-test is used

    test_object=ActionModule()
    # Input parameters
    # In the real code, these are defined in './units/plugins/action/shell.py'
    # In this unit test, we need to set them explicitly
    test_object._task_fields = {
        'args': {},
        'environment': {},
        'register': None,
        'when': True,
        'delegate_to': None,
        'delegate_facts': None,
        'run_once': False,
        '_ansible_ignore_errors': None,
        '_ansible_no_log': False,
        '_ansible_verbosity': 0,
        '_ansible_version': None,
        '_uses_shell': False
    }



# Generated at 2022-06-21 03:03:30.019576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(loader=None, connection=None, templar=None, task=None)

    assert actionModule is not None
    assert actionModule._templar is not None
    assert actionModule._loader is not None
    assert actionModule._task is not None
    assert actionModule._connection is not None
    assert actionModule._shared_loader_obj is not None
    assert actionModule._play_context is not None


# Generated at 2022-06-21 03:03:39.504316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = {'command': 'echo hello', '_uses_shell': True, 'creates': '/tmp/test', 'warn': True}


# Generated at 2022-06-21 03:03:40.064661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule.run()

# Generated at 2022-06-21 03:03:50.905791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.errors import AnsibleError
  from ansible.plugins.action.default import ActionModule
  from ansible.module_utils.common._collections_compat import Mapping
  from ansible.module_utils._text import to_bytes
  from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

  # Test 1: Test if the command is executed properly

# Generated at 2022-06-21 03:04:04.079530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Here we mock up the needed arguments 
    test_task = 'ansible.builtin.command'
    test_connection = 'local'
    test_play_context = dict(
        become=False,
        become_method=None,
        become_user=None,
        check_mode=None,
        diff=None,
        gather_facts='smart',
        parallel=None,
        remote_addr=None,
        remote_user=None,
        shell=None
    )
    test_loader = dict(
        all_vars=dict(),
        options=dict(
            ansible_play_hosts=['localhost'],
            connection='local',
            gather_facts='smart',
            inventory=dict()
        )
    )

# Generated at 2022-06-21 03:04:06.899346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare test variables
    tmp = None
    task_vars = None
    # Execute the method under test
    ret = ActionModule.run(tmp, task_vars)
    assert ret == ''

# Generated at 2022-06-21 03:04:08.684636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    f1 = ActionModule()
    assert(f1 != None)

# Generated at 2022-06-21 03:04:11.734039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.connection == None
    assert module.play_context == None
    assert module.module_vars == {}
    assert module.task_vars == {}

# Generated at 2022-06-21 03:04:12.327879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:17.499332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ UnitTest for ActionModule Constructor """
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert(action_module)
    # The following test failed due to a refactoring of how the class was created.
    # assert(action_module.__dict__ == {})

# Generated at 2022-06-21 03:04:25.482595
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import json
    import unittest

    class TestActionModule(unittest.TestCase):

        class MockActionBase():

            def __init__(self):
                return

            def get(self):
                return

            def run(self):
                return

        # Rule for setting up unit test
        def setUp(self):
            self.old_cwd = os.getcwd()

            # Change to test directory
            os.chdir(os.path.dirname(os.path.realpath(__file__)))

            with open('../../../../lib/ansible/plugins/action/shell.py', 'r') as f:
                self.shell_data = f.read()


# Generated at 2022-06-21 03:04:26.972573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False  # TODO: implement your test here


# Generated at 2022-06-21 03:04:27.565574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:28.440419
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:04:38.120617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 03:04:39.395927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:04:48.791099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    action_module._task = []
    action_module._connection = []
    action_module._play_context = []
    action_module._loader = []
    action_module._templar = []
    action_module._shared_loader_obj = []
    action_module._task.args = {'test_key': 'test_value'}
    class TestCommandAction(object):
        def __init__(self):
            self.run = lambda *args, **kwargs: dict(test_command_key='test_command_value')

    action_module._shared_loader_obj.action_loader = {}
    action_module._shared_loader_obj.action_loader['ansible.legacy.command'] = TestCommandAction()

    result = action_module.run()


# Generated at 2022-06-21 03:04:49.253050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:52.393605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result._play_context == None
    assert result._loader == None
    assert result._tqm == None
    assert result._connection == None
    assert result._templar == None
    assert result._task == None
    assert result._shared_loader_obj == None
    assert result._display == None

# Generated at 2022-06-21 03:04:53.916902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 03:05:04.897474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    from ansible.playbook.task import Task
    from ansible.playbook import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 03:05:13.720598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    pActionModule = ActionModule()
    assert pActionModule is not None
    
    # in class ActionModule
    # def _task_fields(self):
    #     # return all fields that are part of a task, not fields common to all action plugins
    #     all_fields = [
    #         'args',
    #         'any_errors_fatal',
    #         'block',
    #         'changed_when',
    #         'check_mode',
    #         'connection',
    #         'delegate_to',
    #         'delegate_facts',
    #         'deprecate_msg',
    #         'environment',

# Generated at 2022-06-21 03:05:14.756813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:21.864629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict(
        _raw_params='hostname',
        _uses_shell=True,
    )
    task_name = "Shell"
    task_args = dict(
        _raw_params='hostname',
        _uses_shell=True,
    )
    host_name = "ansible_test"
    templar = DictData({'vars': dict()})

    def ansible_module_run_command(self, task_vars=None):
        return dict(changed=True, stdout="ansible_test")
    mock_command_action = MagicMock(spec=ActionBase)
    mock_command_action.run = ansible_module_run_command

    mock_command_action_loader = MagicMock(spec=ActionBase)

# Generated at 2022-06-21 03:05:51.454495
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a class object of ActionModule class
    ActionModule_obj = ActionModule()

    # Mock method run of class ActionModule with the options passed to it as arguments
    ActionModule.run = MagicMock(return_value=['a', 'b'])

    # Store the result returned by method run of class ActionModule in result variable
    result = ActionModule_obj.run()

    # Assert that the result returned by method run of class ActionModule is same as the value in result variable
    assert result == ['a', 'b']

# Generated at 2022-06-21 03:06:01.233303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.cleaner import VarsCleaner
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible_collections.ansible.windows.plugins.action.win_shell import ActionModule
    import json

    # Create a fake PlayContext object
    fake_loader = DataLoader()
    fake_inventory = {}
    fake_variable_manager = VariableManager()
    fake_play_context = PlayContext()
    fake_play_context.network_os = 'fake_os_name'
    fake_play

# Generated at 2022-06-21 03:06:07.000297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\nInside method run of class ActionModule")
    print("Executing unit test")
    task_vars = {'ansible_facts': {'test':'test'}, 'ansible_check_mode': False}
    task = {'args': {'_raw_params': 'test', '_uses_shell': True}}
    command_module = {'run': lambda task_vars: {'test': 'test'}}
    loader = {'action_loader': {'get': lambda task_obj, task_vars: command_module}}
    class_obj = ActionModule('ansible/plugins/action/shell.py', task, None, None, None, None, loader, None)
    res = class_obj.run(task_vars=task_vars)
    assert res == {'test': 'test'}

# Generated at 2022-06-21 03:06:14.749477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule()
   
    module.PlayContext = PlayContext()

    module.TaskExecutor = TaskExecutor()

    module.TaskExecutor.get_connection = MagicMock(
        return_value=Connection()
    )
    module.TaskExecutor.action_loader = MagicMock(
        return_value=ActionModule()
    )

    module.Templar = MagicMock(
        set_available_variables = MagicMock(),
        template = MagicMock(
            return_value = 'template'
        ),
        __getattribute__ = MagicMock(
            return_value=TestAnsibleModule()
        )
    )

    module.Runner = Runner()

# Generated at 2022-06-21 03:06:17.322623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # check that ActionModule implements method run
    assert (hasattr(ActionModule(), 'run') and callable(getattr(ActionModule(), 'run')))

# Generated at 2022-06-21 03:06:17.856681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:18.606898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:25.698191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=False
    )

    module.run_command = MagicMock(return_value=[0, '', ''])
    sut = ActionModule(
            module=module,
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None
    )

    sut.run()

    assert module.run_command.called

# Generated at 2022-06-21 03:06:28.546874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    confirm, constructor is exist.
    '''
    print('test_ActionModule()')
    try:
        action_module = ActionModule()
    except Exception as e:
        raise e
           

# Generated at 2022-06-21 03:06:30.574682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed_module

    assert issubclass(removed_module(), Exception)

# Generated at 2022-06-21 03:07:29.513313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test ActionModule constructor
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['arg'] = 'value'
            self.operation = 'remote'

    class MockConnection(object):
        pass

    class MockTask(object):
        def __init__(self):
            self.args = dict()
            self.args['arg'] = 'value'

    task = MockTask()
    connection = MockConnection()
    module = MockModule()

    obj = ActionModule(task, connection, module)

# Generated at 2022-06-21 03:07:31.227386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:07:31.970813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 03:07:32.642349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule("ansible.legacy.shell")

# Generated at 2022-06-21 03:07:33.363682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:07:34.031504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-21 03:07:39.211304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = 'connection'
    task = 'task'
    play_context = 'play_context'
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'
    test_tmp = 'test_tmp'
    test_task_vars = {'test_task_vars': 'test_task_vars'}
    test_result = {'test_result': 'test_result'}
    mock_ActionBase_init = mocker.patch('ansible.plugins.action.ActionBase.__init__')
    mock_ActionModule_run = mocker.patch('ansible.plugins.action.ActionModule.run', mocker.Mock(return_value=test_result))

# Generated at 2022-06-21 03:07:40.506422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 03:07:48.704017
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ##############################################################################################################
    #
    # Mock data for creating an instance of class ActionModule
    #
    mock_task = dict()
    mock_task['name'] = 'AnsibleModuleTestActionModule'
    mock_task['action'] = 'shell'
    mock_task['loop'] = '{{ range(0, 2) }}'
    mock_task['args'] = dict()
    mock_task['args']['chdir'] = '/home'
    mock_task['args']['executable'] = '/bin/bash'
    mock_task['args']['creates'] = '/home/django/file'
    mock_task['args']['removes'] = '/home/django/file'
    mock_task['args']['warn'] = True

# Generated at 2022-06-21 03:07:49.624611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    foo = ActionModule()
    assert foo.ACTION_VERSION == 2.0

# Generated at 2022-06-21 03:09:27.653573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:09:28.956158
# Unit test for constructor of class ActionModule
def test_ActionModule(): # pylint: disable=R0903
    """ Constructor test """
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:09:38.543521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell as am
    import ansible.executor.task_queue_manager as tqm
    import ansible.executor.playbook_executor as pe
    import ansible.executor.task_executor as te
    import ansible.playbook.play as p
    import ansible.playbook.task as t
    import ansible.playbook.block as b
    import ansible.inventory.host as h
    import ansible.inventory.group as g
    import ansible.inventory.inventory as i
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-21 03:09:45.155689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    prefix = 'ansible.legacy.action.'
    # ActionModule
    action_module = ActionModule(None, None, None, None, None, None)
    assert isinstance(action_module, ActionModule)
    # ActionBase
    assert isinstance(action_module, ActionBase)
    # ActionBase.run()
    # command_action : ansible.plugins.action.command.ActionModule
    command_action = action_module.run(None, None)
    assert isinstance(command_action, ActionModule)
    assert command_action.__module__ == prefix + 'command'

# Generated at 2022-06-21 03:09:50.026957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class mock_self:
        def __init__(self):
            self._task = None
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    # Construct arguments
    tmp = None
    task_vars = None

    # Instantiate a MockRunner
    mock_runner = mock_self()

    # Invoke method
    mock_runner.run(tmp, task_vars)

# Generated at 2022-06-21 03:09:53.801718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import ansible.plugins.action.shell

    class FakeModule:
        pass

    class TestAnsibleShellAction(unittest.TestCase):
        def test_action_module(self):
            a = ansible.plugins.action.shell.ActionModule(FakeModule())
            self.assertIsInstance(a, ansible.plugins.action.shell.ActionModule)

# Generated at 2022-06-21 03:09:55.249206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    print("ActionModule: ", am)


# Generated at 2022-06-21 03:09:56.588543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:10:05.114755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    import ansible.plugins.action.shell
    import ansible.playbook.task
    import ansible.template
    import ansible.vars
    import ansible.utils.vars

    class TestConnection(object):
        def __init__(self, host):
            self.host = host

        def get_option(self, name):
            if name == 'ansible_shell_type':
                return 'sh'
            elif name == 'ansible_shell_executable':
                return None
            elif name == 'ansible_shell_executable_arg':
                return '-c'
            else:
                return None

    class TestPlayContext(object):
        def __init__(self):
            self._attributes = {}


# Generated at 2022-06-21 03:10:11.241156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # monkeypatch AnsibleShellModule to make it iterable
    class AnsibleShellModule(object):
        def __init__(self, *args, **kwargs):
            self.args = kwargs

        def __iter__(self):
            for key, value in self.args.items():
                yield key, value

    class AnsibleContext(object):
        def __init__(self, *args, **kwargs):
            self.shell = AnsibleShellModule(*args, **kwargs)

    # create dummy task object and execute constructor
    task = object()
    action = ActionModule(task, AnsibleContext(), '/tmp/ansible_shell_payload_as_source', False, 10)

    # assert that _uses_shell was set in args
    assert action._task.args['_uses_shell'] == True

    # assert