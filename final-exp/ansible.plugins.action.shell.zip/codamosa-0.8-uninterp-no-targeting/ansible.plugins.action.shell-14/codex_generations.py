

# Generated at 2022-06-21 03:00:19.651841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-21 03:00:24.232793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict()),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action is not None


# Generated at 2022-06-21 03:00:28.097026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:00:38.746033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = {
        'args': {
            '_uses_shell': False
        }
    }
    mock_task_vars = {}

    # Arrange
    _tmp = None
    action_module = ActionModule(loader=None,
                                 connection=None,
                                 play_context=None,
                                 task=mock_task,
                                 templar=None,
                                 shared_loader_obj=None)

    # Act
    result = action_module.run(tmp=_tmp, task_vars=mock_task_vars)

    # Assert
    assert('_uses_shell' in mock_task['args'] and mock_task['args']['_uses_shell'] == True)

# Generated at 2022-06-21 03:00:39.503244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-21 03:00:41.330508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-21 03:00:48.344561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.utils.connection import Connection
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    connection = Connection()

    host = Host(name="foobar")
    group = Group(name="foobar")
    group.add_host(host)
    inventory = InventoryManager(
        loader=None,
        sources=[
            ("foobar", [group])
        ])


# Generated at 2022-06-21 03:00:54.558140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module._shared_loader_obj.action_loader.get = Mock(return_value='command_action')
    module._task.args = {'_uses_shell': False}
    result = module.run(tmp='tmp', task_vars='task_vars')
    assert result == 'command_action'



# Generated at 2022-06-21 03:00:57.347973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert isinstance(action_module, ActionBase)


# Generated at 2022-06-21 03:00:58.721572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:01:03.778932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, task_vars=[1,2,3,4,5])
    print(test_ActionModule.run())

# Generated at 2022-06-21 03:01:08.272674
# Unit test for constructor of class ActionModule
def test_ActionModule():
   '''
   Test object creation for ActionModule
   '''
   test_data = { "foo":"bar" }
   am = ActionModule(None, None, test_data)
   assert am is not None

# Generated at 2022-06-21 03:01:10.304767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({})
    result = action.run()
    print(result)

# Generated at 2022-06-21 03:01:10.836273
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert ActionModule()

# Generated at 2022-06-21 03:01:20.841703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task = {
        'name': 'test_task',
        'args': {
            '_uses_shell': False,
            '_raw_params': 'echo "Hello World"',
            '_uses_shell': True,
        },
        'vars': {},
    }
    test_connection = {
        'name': 'test_connection',
    }
    test_play_context = {
        'name': 'test_play_context',
    }

    test_loader = None
    test_templar = None

# Generated at 2022-06-21 03:01:24.806943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_vars = get_ansible_vars()
    ansible = AnsibleModule( argument_spec={'command':{}} )
    action = ActionModule(ansible,ansible_vars)
    result = action.run()
    if result["stdout_lines"][0] == "hello":
        return True
    return False


# Generated at 2022-06-21 03:01:32.396290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup mock
    task_vars = {'var1':'value1'}
    tmp = None
    testobj = ActionModule(task=1, connection=2, play_context=3, loader=4, templar=5, shared_loader_obj=6)
    testobj.templar._available_variables = task_vars
    testobj.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-21 03:01:38.580162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    module_test = {'name': 'command', 'args': {'_uses_shell': True}}
    action_test = action_loader._get_action_class(module_test)()

    assert action_test._task.args['_uses_shell']

# Generated at 2022-06-21 03:01:47.053699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = {}
    mock_connection = {}
    mock_play_context = {}
    mock_loader = {}
    mock_templar = {}
    mock_shared_loader_obj = {}

    module = ActionModule(task=mock_task,
                          connection=mock_connection,
                          play_context=mock_play_context,
                          loader=mock_loader,
                          templar=mock_templar,
                          shared_loader_obj=mock_shared_loader_obj)

    module._task = mock_task
    module._connection = mock_connection
    module._play_context = mock_play_context
    module._loader = mock_loader
    module._templar = mock_templar
    module._shared_loader_obj = mock_shared_loader_obj

# Generated at 2022-06-21 03:01:55.261953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {'_username': 'user', '_password': 'pass', '_uses_shell': True,
            'argv': '->', 'executable': '/bin/sh', 'chdir': '',
            'creates': None, 'removes': None, 'stdin': None,
            'stdout': '/tmp/stdout', 'stderr': '/tmp/stderr', 'warn': True}
    am = ActionModule(args, {})

# Generated at 2022-06-21 03:02:00.483624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with callable parameters
    assert ActionModule(None, None, None, None, None, None) is not None

    # Test with non-callable parameters
    assert ActionModule(False, False, False, False, False, False) is not None

# Generated at 2022-06-21 03:02:00.951134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:05.840762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_result = {'ansible_facts': {}, 'warnings': []}
    # Test __init__ function
    test_action_module = ActionModule()
    assert isinstance(test_action_module, ActionModule)
    assert isinstance(test_action_module.run(tmp=None, task_vars=None), dict)
    assert test_action_module.run(tmp=None, task_vars=None) == test_result

# Generated at 2022-06-21 03:02:15.375271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing for calling ActionModule __init__()
    action_module = ActionModule(action_plugin_class=None, action_plugin_config=None, action_plugin_args=None,
                                 executor_config=None, executor_internal_proxy=None, executor_internal_playbook=None,
                                 executor_vars=None, task_uuid=None, task_vars=None, play=None, connection=None,
                                 play_context=None, loader=None, templar=None, shared_loader_obj=None,
                                 plugin_deps=None, action=None, task_include=None, wrap_async=None)

# Generated at 2022-06-21 03:02:26.638972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Making a test object of class ActionModule

# Generated at 2022-06-21 03:02:38.398997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.compat import win_unrepr
    from ansible.module_utils.six import string_types

    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    task = dict(action=dict(module='shell'))

    args = dict()
    args['_uses_shell'] = True
    task['args'] = args

    fake_connection = 'fake_connection'

    play_context = dict(
        remote_addr='127.0.0.1',
        port=22,
        remote_user='username'
    )

# Generated at 2022-06-21 03:02:48.310643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from lib_units import setup_loader_for_testing
    setup_loader_for_testing(ActionModule)

    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

# Generated at 2022-06-21 03:02:58.231866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy class for test
    class Dummy_Connection:
        def __init__(self):
            self.name = 'DummyConnection'

    # Arrange
    from ansible.plugins.loader import shared_loader_obj
    from ansible.playbook.play_context import PlayContext

    shared_loader_obj._loader = None
    task = {
        'args': {},
        'action': 'ansible.legacy.shell',
        'connection': 'local',
        'delegate_to': None,
        'environment': {},
    }
    runner = ActionModule(task, 'local', 'test', shared_loader_obj, 'ansible.legacy.shell',
                          connection=Dummy_Connection(), play_context=PlayContext())

    task_vars = dict()

    # Act

# Generated at 2022-06-21 03:03:08.904459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_result = dict(
       msg=dict(
            changed=False,
            skip_reason='Conditional result was False',
            rc=0,
            stdout='{"status": "OK","reason": "Successfully updated value"}',
            stderr='',
            stdout_lines=['{"status": "OK","reason": "Successfully updated value"}'],
            stderr_lines=[],
            results=dict(
                status='OK',
                reason='Successfully updated value'
            )
        )
    )

# Generated at 2022-06-21 03:03:10.167906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor of class ActionModule
    action_module = ActionModule()

# Generated at 2022-06-21 03:03:18.551475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule( {}, {}, {} )
    print (a)

# Generated at 2022-06-21 03:03:22.873218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    # TODO: check if these calls can be replaced by mock call
    module._loader = True
    module._connection = True
    module._templar = True
    module._task = True
    module._loader = True
    module._shared_loader_obj = True
    module._play_context = True
    module._templar.template = lambda x: x
    assert module.run()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-21 03:03:23.777571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # put here your code

    pass


# Generated at 2022-06-21 03:03:24.977849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    r = ActionModule()
    assert r.action_type == 'shell'

# Generated at 2022-06-21 03:03:25.577617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:03:36.530458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeActionBase:
        def __init__(self, *args, **kwargs):
            self.result = {}
            self.task = dict(args=dict(command='foo'))
            self._play_context = dict(become=False, become_user='root')
            self._shared_loader_obj = dict(action_loader=dict(action_loader=dict(foo=dict(bar='barvalue'))))

    class FakeShellModule:
        def __init__(self, *args, **kwargs):
            self.result = dict(rc=0, stdout='', stderr='')

    shell = FakeShellModule()
    action = FakeActionBase()

    from ansible.plugins import action as action_plugins
    action_plugins._action_plugins['shell'] = (ActionModule, shell)

    result = action

# Generated at 2022-06-21 03:03:43.175596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json

    sys.stderr.write("Test for method run of class ActionModule\n")


    # if len(sys.argv) > 1:
    #     ret = json.loads(sys.argv[1])
    #     if ret != None and isinstance(ret, int):
    #         sys.exit(ret)
    #     sys.stderr.write("Unexpected type of sys.argv: " + str(type(ret)) + "\n")
    #     sys.exit(1)

    am = ActionModule()

    x = am.run()
    print(json.dumps(x))
    sys.exit(json.dumps(x))
    #sys.exit(0)

test_ActionModule_run()

# Generated at 2022-06-21 03:03:43.727611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:55.089289
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:03:55.673257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:15.717033
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default=''),
            _uses_shell=dict(type='bool', default=False)
        ),
        supports_check_mode=False,
    )

    # test if method run successfully
    result = module.run_command()
    assert result.get('stdout_lines') == ['I ran ansible-command']

# Generated at 2022-06-21 03:04:17.131316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action) == ActionModule

# Generated at 2022-06-21 03:04:19.779625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:04:22.099291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate ActionModule class
    obj = ActionModule()
    assert(obj != None)

    # Test run function
    assert(obj.run() == None)

# Generated at 2022-06-21 03:04:31.922747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task        = dict(name="test", args=dict())
    action      = dict(name="test", shell="echo")
    ansible_vars= dict(test="test")
    task_vars   = dict(test="test")
    task_vars.update(ansible_vars)
    tmp         = dict(name="test")

    mock_task   = Mock()
    mock_task.__getitem__.side_effect = (lambda k: task[k])
    mock_task.__setitem__.side_effect  = (lambda k, v: task.setdefault(k,v))
    mock_task.copy.side_effect         = (lambda : task.copy())

    mock_connection   = Mock()
    mock_play_context = Mock()
    mock_loader       = Mock()
    mock_tem

# Generated at 2022-06-21 03:04:41.568664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    stdout = "stdout test"
    #stderr = "stderr test"
    stdout_lines = stdout.splitlines()
    #stderr_lines = stderr.splitlines()
    changed = False
    failed = False
    rc = 0
    module_stdout = ""
    module_stderr = ""

    result = {
        "changed": changed,
        "failed": failed,
        "rc": rc,
        "stdout": stdout,
        "stdout_lines": stdout_lines,
        #"stderr": stderr,
        #"stderr_lines": stderr_lines,
        "module_stdout": module_stdout,
        "module_stderr": module_stderr,
    }

    tmp = "tmp test"


# Generated at 2022-06-21 03:04:42.113709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:46.940161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input data for the test
    tmp = None
    task_vars = None

    # Create a mock instance of ActionModule to call run method
    actionModule = ActionModule()
    actionModule._task = 'Test'
    actionModule._connection = 'Test'
    actionModule._play_context = 'Test'
    actionModule._loader = 'Test'
    actionModule._templar = 'Test'
    actionModule._shared_loader_obj = 'Test'

    # Unit test the method run
    actionModule.run(tmp, task_vars)

# Generated at 2022-06-21 03:04:48.982591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    this method is to test the run method of class ActionModule
    '''
    #setup mock data and test method
    actionmodule_obj = ActionModule()

    #assert return value
    #assert actionmodule_obj.run() == 0
    return

# Generated at 2022-06-21 03:04:49.446760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:05:26.410370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule('foo', 'bar', 'baz', 'biz', 'boz')
    assert obj is not None

# Generated at 2022-06-21 03:05:27.188852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x

# Generated at 2022-06-21 03:05:37.287500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import MagicMock, patch

    # Mock classes for module tests
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, a):
            return a

    class MockLoader(object):
        def __init__(self):
            self._templar = MockTemplar()

    class MockTask(object):
        def __init__(self):
            self.args = {}

    class MockCommand(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader


# Generated at 2022-06-21 03:05:45.392880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare a mock class
    class ActionBaseMock():
        def __init__(self):
            self._task = {'args':{}}

        def run(self, tmp=None, task_vars=None):
            assert task_vars is not None
            return {}
    # Declare a mock class
    class ActionModuleMock(ActionModule):
        _shared_loader_obj = {
            'action_loader': {
                'ansible.legacy.command':ActionBaseMock(),
            }
        }

    action_mock = ActionModuleMock()
    action_mock.run(tmp=None, task_vars=None)
    assert action_mock._task.args.get('_uses_shell') is True

# Generated at 2022-06-21 03:05:56.595676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.command import ActionModule as ActionModule_command
    from ansible.plugins.loader import find_plugin

    def _get_path(path):
        return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', path))

    _loader, _module, _action_plugin = find_plugin('action', 'command')

    # This is a lot of work to simply instantiate a class, but the class was not designed to be instantiated outside the
    # action plugin framework

# Generated at 2022-06-21 03:06:03.312839
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Stub class to make pass in test
    class StubClass:
        pass

    # Create an instance of argparse to pass
    argparse_obj = StubClass()

    # Create an instance of class ActionModule
    actionmodule_obj = ActionModule(
        connection='connection',
        task_vars='task_vars',
        play_context='play_context',
        loader='loader',
        templar='templar',
        shared_loader_obj='shared_loader_obj'
    )

    # Call the run method of ActionModule
    result = actionmodule_obj.run(argparse_obj,'task_vars')

    assert result == 0

# Generated at 2022-06-21 03:06:06.218467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    unittest.TestCase.assertTrue()

if __name__ == "__main__":
    #test_ActionModule()
    unittest.main()

# Generated at 2022-06-21 03:06:13.567687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # data for constructor
    data = dict(
        action='ansible.legacy.shell',
        args=dict(
            _raw_params='ls'
        )
    )
    # create object with data
    obj = ActionModule(data, None, None, None, None, None, None)
    # check type of object
    assert isinstance(obj, ActionModule)
    # check value of private variables
    assert obj._task_vars == None
    assert obj._task.action == 'ansible.legacy.shell'
    assert obj._task.args['_raw_params'] == 'ls'

# Generated at 2022-06-21 03:06:24.360679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import platform
    import re

    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch

    from ansible.module_utils._text import to_text

    from ansible.plugins import connection_loader
    from ansible.plugins import module_loader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule

    if platform.system() == 'Windows':
        pytest.skip("windows does not support the shell module")

    mock_task = MagicMock()
    mock_task.args = {'_uses_shell': True}

    mock_connection = MagicMock()
    mock_connection_class = MagicMock(return_value=mock_connection)
    mock_connection_loader = Magic

# Generated at 2022-06-21 03:06:25.871729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """The call to the action module constructor is tested by the unit tests
    for the command module."""
    pass

# Generated at 2022-06-21 03:07:50.593900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action) is ActionModule

# Generated at 2022-06-21 03:07:55.770420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = AnsibleFakeTask()
    fake_task.args = {'hosts': 'node1'}
    fake_connection = AnsibleFakeConnection()
    fake_play_context = AnsibleFakePlayContext()
    fake_loader = AnsibleFakeLoader()
    fake_templar = AnsibleFakeTemplar()
    fake_shared_loader_obj = AnsibleFakeSharedLoaderObj()
    action_module = ActionModule(task=fake_task, connection=fake_connection, play_context=fake_play_context, loader=fake_loader, templar=fake_templar, shared_loader_obj=fake_shared_loader_obj)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 03:07:56.214810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:07:58.172346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleClass(ActionModule):
        def __init__(self):
            pass

    action_module = ActionModuleClass()
    assert action_module


# Generated at 2022-06-21 03:08:01.210655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class under test
    obj = ActionModule(connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

    # call the method under test.
    obj.run()

# Generated at 2022-06-21 03:08:04.685068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1, "This test module needs to be implemented"
    # Constructor: ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # function run(self, tmp=None, task_vars=None):

# Generated at 2022-06-21 03:08:08.320540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        {'action': {'__ansible_arguments__': [''],
                    '__ansible_action__': 'shell',
                    '__ansible_module__': 'action'}},
        connection={},
        play_context={},
        loader={},
        templar={},
        shared_loader_obj={}
    )

    assert action_module

# Generated at 2022-06-21 03:08:08.986767
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    a = ActionModule()



# Generated at 2022-06-21 03:08:10.252724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate an object of class ActionModule
    #action_module_obj = ActionModule()

    # Assertion 1
    assert ActionModule.run

# Generated at 2022-06-21 03:08:17.260920
# Unit test for constructor of class ActionModule
def test_ActionModule():
	data = """
- name: Run whois against a domain.
  command: whois {{ lookup('env','ANSIBLE_WHOIS_DOMAIN') }}
  register: whois_result

- name: Show whois results.
  debug:
    var: whois_result
"""
	doc = yaml.load(data, Loader=yaml.RoundTripLoader)
	# print (doc)
	for i in range(len(doc)):
		t = doc[i]
		task = Task( t, i )
		print(task)
