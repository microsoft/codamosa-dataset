

# Generated at 2022-06-21 03:00:36.360767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible_fake_command import AnsibleFakeCommand
    from ansible_fake_module import AnsibleFakeModule
    from ansible_fake_connection import AnsibleFakeConnection
    from ansible_fake_loader import AnsibleFakeLoader
    from ansible_fake_context import AnsibleFakeContext
    from ansible_fake_task import AnsibleFakeTask
    from ansible_fake_config import AnsibleFakeConfig

    task = AnsibleFakeTask(module_name='shell', module_args="echo some args")
    action = AnsibleFakeAction(task=task)

# Generated at 2022-06-21 03:00:41.062851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import pytest
    import ansible.plugins.action as action
    action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:00:42.824557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Uses default ansible.plugins.action.ActionBase.run()
    assert True

# Generated at 2022-06-21 03:00:54.794929
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import command
    from ansible.module_utils.six.moves import SimpleMock
    from ansible.module_utils.six.moves import mock

    # Mock out the get handler, as we don't really care about it here
    mock_get_handler = mock.MagicMock()
    mock_get_handler.return_value = command

    # Create mock arguments
    mock_task_args = {'_uses_shell': True}
    mock_task_vars = {}

    # Create the instantiated object
    mock_obj = ActionModule()

    # Mock out the run handler
    mock_run_handler = mock.MagicMock()


# Generated at 2022-06-21 03:01:02.647216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that run() method of command.ActionModule() is called
    action = ActionModule(
        task=dict(action=dict(module_name='command', _raw_params='echo hi')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    result = action.run()

    assert result == dict(invocation=dict(module_args='echo hi'))

# Generated at 2022-06-21 03:01:04.786338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base = ActionBase()
    action_module = ActionModule(action_base)

# Generated at 2022-06-21 03:01:13.662310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {'action':'shell', 'tmp':'a', 'task_vars':['a', 'b']}

    actionmodule = ActionModule(data, data)
    actionmodule.templar = 'do not care'
    actionmodule.loader = 'do not care'
    actionmodule.play_context = 'do not care'
    actionmodule.connection = 'do not care'
    actionmodule.task = {'args': {'_uses_shell': True, 'uchildren':'children' , 'container':'yes'}}
    actionmodule.shared_loader_obj = 'do not care'

# Generated at 2022-06-21 03:01:14.281877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:14.947799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()

# Generated at 2022-06-21 03:01:22.834028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_task_args = {'_uses_shell': True}
    input_task_vars = {'ansible_check_mode': False}
    input_play_context = {'check_mode': False}

    test_instance = setup_legacy_shell_test_instance(input_task_args, input_task_vars, input_play_context)

    test_instance.action.run(task_vars=input_task_vars)

    expected_call_args = {'tmp': None, 'task_vars': input_task_vars}
    test_instance.action.command.run.assert_called_with(**expected_call_args)


# Generated at 2022-06-21 03:01:25.735296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:26.522194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('here')

# Generated at 2022-06-21 03:01:27.284009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()

# Generated at 2022-06-21 03:01:28.434431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:32.318330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module


# Generated at 2022-06-21 03:01:44.459687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Create a test task to work with
    task = type('', (), {})()
    task.args = {'_uses_shell': True}

    # Create test objects
    class TestObject(object):
        def __init__(self, name):
            self.name = name

    connection = TestObject('connection')
    play_context = TestObject('play_context')
    loader = TestObject('loader')
    templar = TestObject('templar')
    shared_loader_obj = loader

    # Create fake method to return a command module
    def fake_action_loader_get(action, *args):
        if action == 'ansible.legacy.command':
            ansible_command = type('', (), {})()
            ansible_command.run = lambda *args: None


# Generated at 2022-06-21 03:01:54.952489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import ansible.plugins.action.shell as action
    from ansible.plugins.action import ActionBase
    global result
    global tmp
    global task_vars
    result = {'rc': 0, 'stdout': "stdout", 'stdout_lines': ["line1", "line2"], 'stderr': "stderr", 'start': "start",
              'end': "end", 'msg': ""}
    tmp = None
    task_vars = {'ansible_facts': {'module_setup': True}}
    shell = action.ActionModule(None, None, None, None, None, None, None)
    command_action = ActionBase(None, None, None, None, None, None, None)

# Generated at 2022-06-21 03:01:59.556853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(None, None, None, None, None, None)
    class fake_task:
        def __init__(self):
            self.args = {}
            self.vars = {}
    class fake_conn:
        def __init__(self):
            self.defer_results = False
    class fake_play_context:
        def __init__(self):
            self.defer_results = False
    class fake_loader:
        def __init__(self):
            self.filters = {}
    class fake_templar:
        def __init__(self):
            self.filters = {}
    class fake_shared_loader_obj:
        def __init__(self):
            self.action_loader = fake_action_loader()

# Generated at 2022-06-21 03:02:08.055004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vault import VaultLib

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    import os

    class Play():
        name = "Ansible Play"
        hosts = "all"
        roles = []

    class Options():
        connection = "ssh"


# Generated at 2022-06-21 03:02:14.476577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_variables = {}
    my_action_module = ActionModule(None, None, my_variables, None, None)
    assert my_action_module._task == None
    assert my_action_module._connection == None
    assert my_action_module._play_context == None
    assert my_action_module._loader == None
    assert my_action_module._shared_loader_obj == my_variables
    assert my_action_module._task_vars == None

# Generated at 2022-06-21 03:02:29.464583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Task()
    t.args['foo'] = 'bar'
    t.action = 'test_action_name'

    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    am = ActionModule(task=t, connection=None, play_context=None, loader=None,
                      templar=templar, shared_loader_obj=None)

    assert am
    assert am._task == t
    assert 'foo' in am._task.args
    assert am._task.args['foo'] == 'bar'

# Generated at 2022-06-21 03:02:30.040030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:32.981581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_action_base = {}
    am = ActionModule(mock_action_base)
    assert am._play_context == {}, 'test_ActionModule assert#1 has failed.'



# Generated at 2022-06-21 03:02:36.396931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = 1
    task_vars = ["one", "two", "three"]
    command_action = ActionModule(tmp, task_vars)
    assert command_action

# Generated at 2022-06-21 03:02:44.487338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import ansible.utils.vars as ans_vars

# Generated at 2022-06-21 03:02:46.108275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False  # TODO: implement your test here



# Generated at 2022-06-21 03:02:52.253820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({"name":"test","action":"ansible.legacy.shell"})
    assert "ansible.legacy.shell" == m._task.action
    assert "_uses_shell" in m._task.args
    assert True == m._task.args['_uses_shell']
    assert "ansible.legacy.command" == m._shared_loader_obj.action_loader.get('ansible.legacy.command')._task.action

# Generated at 2022-06-21 03:02:57.332671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = {}
    play_context = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}

    task = {}
    task['args'] = {}

    action_module = ActionModule(task, connection, play_context,
                                 loader, templar, shared_loader_obj)
    action_module.run(task_vars={}, tmp=None)

    assert(True)

# Generated at 2022-06-21 03:03:01.769751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    task_vars = dict()
    action_module.run(tmp='/tmp/', task_vars=task_vars)

# Generated at 2022-06-21 03:03:10.427933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_self = mock.MagicMock()
    m_self._task = mock.MagicMock()
    m_self._task.args = {
        '_uses_shell': True,
    }
    m_self._task.action = 'command'
    m_self._task.reject_handler = None
    m_self._task.always_run = False
    m_self._task.register = None
    m_self._task.async_val = None
    m_self._task.async_jid = None
    m_self._task.environment = None
    m_self._task.no_log = False
    m_self._task.when = None
    m_self._task.delegate_to = None
    m_self._task.loop_control = None

# Generated at 2022-06-21 03:03:22.318016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    am = ansible.plugins.action.shell.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    command_action = {'_uses_shell': True}
    t_vars = {}
    ans = am.run(tmp=None, task_vars=t_vars)
    print(ans)
    assert ans == command_action

# Generated at 2022-06-21 03:03:26.367983
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()

    result = action.run(tmp='/tmp', task_vars={})

    assert result == {
        'warnings': [
            'Consider using ansible.legacy.command instead of ansible.legacy.shell.  The latter will be '
            'deprecated in version 2.14.'
        ]
    }

# Generated at 2022-06-21 03:03:28.241035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    assert True

# Generated at 2022-06-21 03:03:30.776295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_module = ActionModule(load_plugins=False)
    # TODO: change this test
    my_module.run(None, None)

# Generated at 2022-06-21 03:03:31.384618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:03:40.318401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import mock

    this_file = os.path.abspath(__file__)
    cur_dir = os.path.dirname(this_file)
    path_xml = os.path.join(cur_dir, '../../')
    old_path = list(sys.path)
    sys.path.append(cur_dir)
    sys.path.append(path_xml)

    from ansible.plugins.action.shell import ActionModule

    fake_task = mock.Mock()
    fake_task_vars = {}
    fake_connection = mock.Mock()

    fake_play_context = mock.Mock()
    loader_obj = mock.Mock()
    templar_obj = mock.Mock()
    shared_loader_obj = mock.Mock()



# Generated at 2022-06-21 03:03:51.383342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.command import ActionModule as CommandModule

    class module_mock():
        def __init__(self):
            self.params = {}
            self.user = 'foo'
            self.user_uid = '1042'
            self.user_gid = '1042'
            self.tmpdir = '/tmp'
            self.environment = {}
            self.log = ''
            self.stdin = None
            self.stdin_add_newline = True
            self.no_log = False

    action_mock = module_mock()

    am = ActionModule(action_mock, '', '', '')


# Generated at 2022-06-21 03:03:56.536589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Task = namedtuple('Task', ['args'])
    task = Task(args={
        '_uses_shell': True
    })
    tmp = None
    task_vars = {}

    obj = ActionModule(task, tmp, task_vars)
    assert obj.run(tmp, task_vars) is None

test_ActionModule_run()

# Generated at 2022-06-21 03:03:57.420509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:04:05.385394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # --------------------------------------------------------------------------
    #  Applying action module for playbook command.yml
    # --------------------------------------------------------------------------
    test_command1 = '/bin/netstat'
    test_command2 = '/etc/ansible/playbooks/playbooks/command.yml'

    # Before the action module starts executing the task, it initializes its
    # own attributes. Ie, it fetches the argument, environment,
    # connection from the task.

    # Test the following.
    # The argument, ie, the command
    # The environment, ie, the shell
    # The connection, ie, the connection

    # For testing Environment
    test_shell = 'bash'

    # For testing Arguments
    test_command = 'ls -l'

    # For testing connection

# Generated at 2022-06-21 03:04:21.433393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:04:22.328186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)



# Generated at 2022-06-21 03:04:25.545067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The run method of ActionModule is not explicitly tested as it is tested via unit tests
    # defined in test/units/plugins/modules/test_testmodule.py and
    # test/units/plugins/modules/test_testmodule_non_ascii.py
    pass

# Generated at 2022-06-21 03:04:27.051977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    shell = ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-21 03:04:37.130231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types
    import unittest
    import ansible.plugins.action.shell

    class DevNull(object):
        def write(self, msg):
            pass

    class dummy_loader(object):
        def get(self, *args, **kwargs):
            class dummy_action(object):
                def run(self, *args, **kwargs):
                    return object()
            return dummy_action()

    am = ansible.plugins.action.shell.ActionModule({}, None, None, None, None, DevNull())
    am._shared_loader_obj = dummy_loader()

    def test_class_ActionModule_run__success(self):
        task = ansible.plugins.action.shell.ActionModule.run(self, tmp=None, task_vars=None)

# Generated at 2022-06-21 03:04:45.646845
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:04:53.582256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import unittest
    import os

    def get_fixture(file_name):
        fixture_path = os.path.join('test/unit/modules/shell/fixtures', file_name)
        return os.path.abspath(fixture_path)

    def get_fixture_content(file_name):
        with open(get_fixture(file_name), 'r') as f:
            return f.read()

    # Create a mock for the BaseLoader class
    class BaseLoader(object):
        def __init__(self, runner):
            pass
    BaseLoader_mock = mock.Mock(side_effect=BaseLoader)

    # Create a mock for the ActionLoader class
    # NOTE: The ActionLoader class is a Singleton, so we have to mock it here

# Generated at 2022-06-21 03:04:55.332922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule."""

    # No need for test for this abstract class

    return

# Generated at 2022-06-21 03:04:55.895459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Generated at 2022-06-21 03:04:56.836486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO: implement test


# Generated at 2022-06-21 03:05:36.446668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:45.221868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import playbook
    import ansible.plugins.action
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash

# Generated at 2022-06-21 03:05:45.862990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:05:54.144092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = Actions()
    action_module = ActionModule(task=action, connection=action, play_context=action, loader=action, templar=action, shared_loader_obj=action)
    assert type(action_module) == ActionModule
    assert action_module._task == action
    assert action_module._connection == action
    assert action_module._play_context == action
    assert action_module._loader == action
    assert action_module._templar == action
    assert action_module._shared_loader_obj == action


# Generated at 2022-06-21 03:05:54.774205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1

# Generated at 2022-06-21 03:05:55.686635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 03:06:03.905999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeActionBase(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj
            self._task.args['_uses_shell'] = False

        def run(self, tmp=None, task_vars=None):
            assert self._task.args['_uses_shell'] == True
            return 'command'


# Generated at 2022-06-21 03:06:12.754428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ab = ActionBase()
    assert hasattr(ab, '_config')
    assert hasattr(ab, '_connection')
    assert hasattr(ab, '_shell')
    assert hasattr(ab, '_loader')
    assert hasattr(ab, '_templar')
    assert hasattr(ab, '_task')
    assert hasattr(ab, '_shared_loader_obj')
    assert hasattr(ab, '_play_context')
    assert hasattr(ab, '_delegate_to')
    assert hasattr(ab, '_task_vars')
    assert hasattr(ab, '_tmp')
    assert hasattr(ab, '_provider')

# Generated at 2022-06-21 03:06:23.612971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #  kwargs_args):
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import iteritems
    #from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_param': 12}
    variables = variable_manager.get_vars(loader=None, play=None)
    templar = Templar(loader=None, variables=variables)

    task = Task()
    #task.args = {'_uses_shell': True}

# Generated at 2022-06-21 03:06:26.472815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    asdf = ActionModule(task_vars='asdf', play_context='asdf')
    assert asdf.task_vars == 'asdf'
    assert asdf.play_context == 'asdf'



# Generated at 2022-06-21 03:07:58.886669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule('ansible/plugins/action/shell.py', 'root', 'vagrant', 'local')
    assert act is not None


# Generated at 2022-06-21 03:08:07.313333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action = ansible.plugins.action.ActionModule(
        {'PARAMETERS': {}}, load_plugins=False, connection=None, play_context=None,
        loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

    task = {
        'action': 'test.test_action_module',
        'args': {}
    }
    task_vars = {}

    # Returns Not Implemented
    result = action.run(tmp=None, task_vars=task_vars)
    assert result['failed'] is True

    # Replaces action field of task
    task['action'] = 'ansible.legacy.shell'
    # Returns Not Implemented

# Generated at 2022-06-21 03:08:09.663250
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:08:10.885069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()  # Instantiate the ActionModule class

# Generated at 2022-06-21 03:08:12.221425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 03:08:17.605564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a._shared_loader_obj.action_loader.get = MagicMock(return_value=None)
    a.run(tmp=None, task_vars=None)
    a._shared_loader_obj.action_loader.get.assert_called_with('ansible.legacy.command', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:08:18.375746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass


# Generated at 2022-06-21 03:08:19.067913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 03:08:27.577479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    arg_dict_1 = dict(a="aValue", b = "bValue")
    arg_dict_2 = dict(c="cValue", d = "dValue")

    tmp=None
    task_vars={"hostvars": {"host1": {}, "host2": {}}}

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None)

    # _task.args = arg_dict_1
    action_module._task.args = arg_dict_1
    action_module._shared_loader_obj.action_loader.get = Mock(return_value="action_result")

    # _task.args = arg_dict_2
    action_module._task.args = arg_dict_2

# Generated at 2022-06-21 03:08:35.837172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Snippet from /usr/lib/python2.7/site-packages/ansible/playbook/play_context.py
    class PlayContext:
        def __init__(self, connection=None, network_os=None, remote_addr=None, remote_user=None, port=None, become=False,
                     become_method=None, become_user=None, become_ask_pass=False, verbosity=3, check=False,
                     diff=False, environment=None, module_name=None, module_paths=None):
            self.connection = connection
            self.network_os = network_os
            self.remote_addr = remote_addr
            self.remote_user = remote_user
            self.port = port
            self.become = become
            self.become_method = become_method
           