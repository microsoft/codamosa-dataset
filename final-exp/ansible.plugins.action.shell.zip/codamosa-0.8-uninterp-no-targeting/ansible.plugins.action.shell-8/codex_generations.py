

# Generated at 2022-06-21 03:00:35.669037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.command import ActionModule
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.strategy import StrategyBase


# Generated at 2022-06-21 03:00:36.423114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:37.018956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:41.481903
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:00:42.509177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method = ActionModule(None, None, None, None, None).run
    # This test uses command action to perform the same validation
    print(method(None))

# Generated at 2022-06-21 03:00:42.854604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:00:55.088385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This set of tests requires the action plugin to be already loaded so we can test the result of the run method
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionModule as CommandActionModule

    fixture = [
        '#!/bin/sh'
        '\necho "hello world"',
        '#!/bin/sh\n'
        'this is a comment\n'
        '\n'
        'echo hello world',
        'hello world',
        '#!/bin/sh'
    ]

    # Test without extra_args
    for f in fixture:
        task_args = {
            '_raw_params': f,
            '_uses_shell': True
        }

# Generated at 2022-06-21 03:00:57.204509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None

# Generated at 2022-06-21 03:01:00.165054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    assert type(action_loader.get('ansible.legacy.shell', '')) == ActionModule

# Generated at 2022-06-21 03:01:00.818623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Example 1
    assert False


# Generated at 2022-06-21 03:01:13.078522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.compat import mock

    foo_action_module = ActionModule()
    foo_action_module._task = mock.MagicMock()
    foo_action_module._connection = mock.MagicMock()
    foo_action_module._loader = mock.MagicMock()
    foo_action_module._shared_loader_obj = mock.MagicMock()
    foo_action_module._play_context = mock.MagicMock()
    foo_action_module._templar = mock.MagicMock()
    foo_action_module.run()

    assert foo_action_module._task.args

# Generated at 2022-06-21 03:01:24.806618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib import module_common_shell_argv
    from ansible.module_utils.ansible_modlib import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import shared_loader_obj
    from ansible.utils.vars import combine_vars

    vault_id = '2b40e71c61d7e377'
    vault_secrets = {'vault_password': 'specialpass'}

    temp_dir = tempfile.mkdtemp()

    args = module_common_shell_argv('/usr/bin/python', ['ifconfig'])

    ansible_args_command = []
    for a in args:
        if isinstance(a, basestring):
            a = ''.join

# Generated at 2022-06-21 03:01:35.670975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize objects for ActionModule
    mock_loader = "sample_loader"
    mock_task = "sample_task"
    mock_connection = "sample_connection"
    mock_play_context = "sample_play_context"
    mock_loader = "sample_loader"
    mock_templar = "sample_templar"
    mock_shared_loader_obj = "sample_shared_loader_obj"

    # Create instance of ActionModule
    ActionModule_instance = ActionModule(loader=mock_loader, task=mock_task, connection=mock_connection, play_context=mock_play_context, loader=mock_loader, templar=mock_templar, shared_loader_obj=mock_shared_loader_obj)

    # Verify instace of ActionModule

# Generated at 2022-06-21 03:01:41.999494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments={'_uses_shell': True}
    task_vars = dict(ansible_all_ipv4_addresses=['10.0.0.1'], ansible_default_ipv4=dict(address='10.0.0.1'), ansible_facts=dict(devices=dict(eth0=dict(ipv4=dict(address='10.0.0.1')))), ansible_local=dict(hostvars=dict()), ansible_play_hosts=['10.0.0.1'], ansible_playbook_python='/usr/bin/python3', ansible_user_id='root', ansible_version=dict(full='2.9.6', major=2, minor=9, revision=6, string='2.9.6'))

# Generated at 2022-06-21 03:01:42.963921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:52.927419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global command_action_run_result

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return command_action_run_result

    command_action_run_result = dict(changed=True, failed=False)
    testActionModule = TestActionModule(
        task_vars=dict(
            ansible_shell_type='sh',
            ansible_shell_executable='/bin/sh'
        ),
        connection='network_cli'
    )
    testResult = testActionModule.run()

    assert testResult == command_action_run_result

# Generated at 2022-06-21 03:01:53.740823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

# Generated at 2022-06-21 03:02:06.010929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_loader = DictDataLoader({})
    fake_play_context = DictData()
    fake_play_context._options = DictData()
    fake_play_context._attributes = DictData()
    fake_play_context._attributes['connection_user'] = 'root'
    fake_play_context._attributes['become_user'] = 'root'
    fake_play_context._attributes['remote_addr'] = '127.0.0.1'
    fake_play_context._attributes['port'] = 22
    fake_play_context._options.connection = 'ssh'
    fake_play_context._options.remote_user = 'root'
    fake_play_context._options.network_os = 'default'
    fake_play_context._options.become = False
    fake_play

# Generated at 2022-06-21 03:02:07.575886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:02:17.141645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock objects
    module = type('module', (object,), dict())
    shared_loader_obj = type('shared_loader_obj', (object,), dict())
    loader = type('loader', (object,), dict())
    action_loader = type('action_loader', (object,), dict())
    ansible_legacy_command = type('ansible_legacy_command', (object,), dict())
    ansible_legacy_command.return_value = action_loader
    task = type('task', (object,), dict())
    connection = type('connection', (object,), dict())
    play_context = type('play_context', (object,), dict())
    templar = type('templar', (object,), dict())

    # Mock initializations
    shared_loader_obj.action_loader = action_

# Generated at 2022-06-21 03:02:23.894631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of class ActionModule
    action_module = ActionModule()



# Generated at 2022-06-21 03:02:32.508533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test that the run method of ActionModule returns result of call to command_module.run
    # First instantiate the module that is being tested.
    action_module = ActionModule()

    # Create mock ActionBase object to pass to the run call

    # Create mock ActionBase object to pass to the run call
    action_base = MagicMock()

    # Get method run from ActionModule object
    method_run = getattr(action_module, 'run')

    # Invoke the run method
    result_run = method_run(task_vars=dict(a=1, b=2))

    assert result_run == dict(a=1, b=2)

# Generated at 2022-06-21 03:02:34.233173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.shell as shell
    actionModule = shell.ActionModule()

# Generated at 2022-06-21 03:02:43.229681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class MockTask(Task):
        pass

    class MockPlay(PlaybookExecutor):
        def __init__(self):
            pass

    # Mock data for play_context
    play_context_mock = PlayContext()

    # First test with: task = None
    action_module_mock = ActionModule(task=None, connection=None, play_context=play_context_mock, loader=None,
                                      templar=None, shared_loader_obj=None)
    assert action_module_mock._shared_loader_obj is None
   

# Generated at 2022-06-21 03:02:44.087156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.run

# Generated at 2022-06-21 03:02:46.064832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # assert that method run returns a type of dict
    assert isinstance(ActionModule.run(), dict)

# Generated at 2022-06-21 03:02:47.476035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_action = ActionModule()
    command_action.run()

# Generated at 2022-06-21 03:02:57.612612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This function covers the test for method run of class ActionModule. It covers the
    positive scenario of the method.
    """
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.inventory import Host
    from ansible.vars.manager import VariableManager

    # Defining the setup objects
    variable_manager = VariableManager()
    host = Host(name='my-host')
    variable_manager.set_inventory(host)
    self = Playbook()

# Generated at 2022-06-21 03:03:01.022592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None)
    assert action is not None



# Generated at 2022-06-21 03:03:02.062689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run()

# Generated at 2022-06-21 03:03:19.898023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        {},
        {},
        {},
        'Ansible Core',
        'test',
        'ansible.legacy.shell',
        'ansible.legacy.shell',
        'ansible.legacy.shell',
        'ansible.legacy.shell',
        '.ansible.legacy.shell_yaml'
    )
    assert module.__class__.__name__ == 'ActionModule'
    assert module.action_loader.__class__.__name__ == 'AggregateLoader'
    assert module._task == {}
    assert module._connection == {}
    assert module._play_context == {}
    assert module._loader == 'Ansible Core'
    assert module._templar == 'test'

# Generated at 2022-06-21 03:03:30.413714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import ActionLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VarManager
    from ansible.parsing.dataloader import DataLoader

    yaml_loader = DataLoader()
    task = yaml_loader.load(dict(
        name="test task",
        action=dict(module="raw", args="echo foo")
    ))

    hostvars = dict(ansible_connection="local")
    variable_manager = VarManager()
    variable_manager.set_host_variable(hostvars, "myhost")
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote

# Generated at 2022-06-21 03:03:31.035702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:33.787530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor ActionModule is not implemented
    # assert ActionModule

    #TODO: return a created instance of ActionModule
    print("Method ActionModule is not implemented")
    return None


# Generated at 2022-06-21 03:03:38.782169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct an instance of the class to test.
    def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
        self._task = task
        self._connection = connection
        self._play_context = play_context
        self._loader = loader
        self._templar = templar
        self._shared_loader_obj = shared_loader_obj

# Generated at 2022-06-21 03:03:47.303976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import imp
    import os
    import shutil
    import tempfile
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests import unittest
    module_name = 'test_shell'
    module_path = os.path.join('test', 'units', 'modules', 'network', 'cloudengine', 'ce_config', module_name)
    output_path = os.path.join(os.path.dirname(module_path), 'output')
    if os.path.isdir(output_path):
        shutil.rmtree(output_path)
    os.mkdir(output_path)
    my_module = imp.load_source(module_name, module_path)
    sys.path.append

# Generated at 2022-06-21 03:03:57.664640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.script import ActionModule
    from ansible.module_utils.six import StringIO

    import os
    import sys
    import pytest
    import mock

    def retcode(code):
        returncode = code

        def mock_retcode(tmp, task_vars=None):
            # print("ActionModule.run() called")
            del tmp  # tmp no longer has any effect
            return {'rc': returncode}

        return mock.MagicMock(side_effect=mock_retcode)


# Generated at 2022-06-21 03:04:00.134359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import AnsibleActionModuleTest
    result = AnsibleActionModuleTest.test_do_run("action.ActionModule")
    #print("results:", result)


# Run unit tests
if __name__ == '__main__':
    import AnsibleActionModuleTest
    AnsibleActionModuleTest.test_run("action.ActionModule")
    test_ActionModule_run()

# Generated at 2022-06-21 03:04:01.493498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """action_plugins/test.py:test_ActionModule()
    """
    pass

# Generated at 2022-06-21 03:04:03.217997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    print("testing:    ansible.plugins.action.shell")

# Generated at 2022-06-21 03:04:26.062877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import connection_loader, action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.display import Display

    display = Display()
    connection_loader._substitution_loader = False
    action_loader._substitution_loader = False
    display.verbosity = 3
    options = PlaybookExecutor.load_extra_vars({})
    options['verbosity'] = 3

# Generated at 2022-06-21 03:04:36.488874
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of class ActionModule
    # for testing method run.
    action_module = ActionModule()

    # Create an instance of class ActionBase
    # for testing method run.
    action_base = ActionBase()

    # Create an instance of class ModuleLoader
    # for testing method run.
    module_loader = ModuleLoader()

    # Create an instance of class ActionLoader
    # for testing method run.
    action_loader = ActionLoader()

    # Create an instance of class PlayContext
    # for testing method run.
    play_context = PlayContext()

    # Set attributes needed for testing method run.
    action_base._task.args = 'test'
    action_module._task = action_base._task
    action_module._connection = 'test'
    action_module._play_context = play_context

    # Testing

# Generated at 2022-06-21 03:04:38.120970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = AnsibleActionModule(None, None, None)
    assert mod is not None


# Generated at 2022-06-21 03:04:40.415365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for absence of "self._task.args['_uses_shell'] = True"
    assert ActionModule.run() == result

# Generated at 2022-06-21 03:04:43.589870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._display == {}
    assert a._task is None
    assert a._connection is None
    assert a._play_context is None
    assert a._loader is None
    assert a._templar is None
    assert a._shared_loader_obj is None

# Generated at 2022-06-21 03:04:48.398776
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	from ansible.plugins.action import ActionBase

	class ActionBase_test(ActionBase):
		def run(self, tmp=None, task_vars=None):
			return 'test'

	test_action = ActionBase_test()

	assert test_action.run(tmp=None, task_vars=None) == 'test'

# Generated at 2022-06-21 03:04:53.582141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = "test"
    fake_connection = "connection"
    fake_play_context = "play_context"
    fake_loader = "loader"
    fake_templar = "templar"
    fake__shared_loader_obj = "shared_loader_obj"
    action_module = ActionModule(fake_task, fake_connection, fake_play_context, fake_loader, fake_templar, fake__shared_loader_obj)
    assert action_module

# Generated at 2022-06-21 03:04:54.212042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 03:04:54.626465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:04:55.218835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:38.139196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()


# Generated at 2022-06-21 03:05:38.524521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:05:46.769870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('TEST 1: Create ActionModule instance')

    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.raw import ActionModule as ActionRawModule
    from ansible.plugins.action.command import ActionModule as ActionCommandModule
    from ansible.plugins.action.copy import ActionModule as ActionCopyModule

    from ansible.plugins.loader import action_loader
    from ansible.plugins.connection.local import Connection as ConnectionLocal

    from ansible_collections.community.general.plugins.action.command import ActionModule as ActionGeneralCommandModule

    action_module = ActionModule('Command', action_loader, ConnectionLocal())

    # Create instance of raw module
    action_module_raw = ActionRawModule('Command', action_loader, ConnectionLocal())

    # Create instance of copy module
    action_module_copy = ActionCopyModule

# Generated at 2022-06-21 03:05:57.728557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class ActionModule
    class MockActionModule:

        def __init__(self):
            self._task = {'args':{}}
            self._connection = "connection"
            self._play_context = "play_context"
            self._loader = "loader"
            self._templar = "templar"
            self._shared_loader_obj = "shared_loader_obj"

    # Mock class CommandAction
    class MockCommandAction:

        def __init__(self):
            self.run_result = None

        def run(self, task_vars=None):
            return self.run_result

    # Unit test for method run of class ActionModule
    action_module_instance = MockActionModule()
    command_action_instance = MockCommandAction()

# Generated at 2022-06-21 03:06:05.229907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict(
        _ansible_shell_executable='/bin/sh',
        _ansible_shell_type='csh',
    )
    args = dict(
        _uses_shell=True,
        chdir='/home/foo',
        executable='/bin/sh',
    )
    connection = dict(
        module=dict(
            device='/home/foo',
        ),
        transport='ssh',
        remote_host='host.example.com',
    )
    loader = dict(
        basedir='/home/foo',
    )

    # Mock
    task = dict(
        module_vars=dict(
            ansible_connection='ssh',
            ansible_user='foo',
        ),
        task_vars=dict(),
    )

# Generated at 2022-06-21 03:06:06.519931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == ActionBase.__doc__

# Generated at 2022-06-21 03:06:07.523823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:08.321157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()

# Generated at 2022-06-21 03:06:11.057049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sut = ActionModule('127.0.0.1', 'ansible', 'local', 'command', '2', 'ansible 123')
    assert sut.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:06:12.279663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase), "ActionModule is a subclass of ActionBase"

# Generated at 2022-06-21 03:07:48.159560
# Unit test for constructor of class ActionModule
def test_ActionModule():
	
	# Define temp data structures
	tmp = None 
	task_vars = None

	# Define test variables
	_task = {'args': 'echo "#!/usr/bin/env python" > foo.py'}
	_connection = None
	_play_context = None
	_loader = None
	_templar = None
	_shared_loader_obj = None

	# Instantiate test object
	am = ActionModule(None, self._task, self._connection, self._play_context, self._loader, self._templar, self._shared_loader_obj)

	am.run(tmp, task_vars)

	# Test ansible.legacy.command

# Generated at 2022-06-21 03:07:53.819618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate class ActionModule
    test_args = dict()
    test_args['_task'] = dict()
    test_args['_task']['args'] = dict()
    test_args['_task']['args']['_uses_shell'] = True

    test_args['_shared_loader_obj'] = dict()
    test_args['_shared_loader_obj']['action_loader'] = dict()

    test = ActionModule(test_args)

    # Set up values for the test
    test_args = dict()
    test_args['_task'] = dict()
    test_args['_task']['args'] = dict()

    test_args['_connection'] = dict()
    test_args['_play_context'] = dict()
    test_args['_loader'] = dict()
   

# Generated at 2022-06-21 03:07:55.108367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()

    assert result == None

# Generated at 2022-06-21 03:08:03.634598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_name = "shell"
    module_name = "ansible.legacy.shell"
    action_test = ActionModule()
    action_test._task.args["_uses_shell"] = True
    action_test._task.args["_raw_params"] = "echo hello"

    class command_action(object):
        def run(self, ansible_variables=None):
            return "ansible_shell"
    
    action_test._shared_loader_obj.action_loader.get.return_value = command_action()
    expected_result = "ansible_shell"
    actual_result = action_test.run()


# Generated at 2022-06-21 03:08:06.347400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, dict(), None, None, None, None, None)
    action_module._task = dict(module_args = dict())
    result = action_module.run_()
    assert result['msg'] == 'Shell is not supported for this platform!'

# Generated at 2022-06-21 03:08:08.021940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:08:10.457786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test for the method run of the class ActionModule.

    Arguments:
        - self: The object pointer.
    Returns:
        - result: The result of the method run of the class ActionModule.
    """

    result = None
    return result


# Generated at 2022-06-21 03:08:11.131835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

# Generated at 2022-06-21 03:08:19.802775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys
    import command_action_module

    command_action = command_action_module.ActionModule()

    print("Running unit test for Ansible Shell Action Module.\n")
    print("Python version: {0}\n".format(sys.version))
    print("ActionModule object: {0}\n".format(command_action))

    print("ActionModule vars(): {0}\n".format(vars(command_action)))
    print("ActionModule __dict__: {0}\n".format(command_action.__dict__))

    # Check if the values in the object are correctly created
    assert(command_action.connection == None)
    assert(str(command_action.loader) == "<DummyLoader for None>")
    assert(str(command_action.play_context) == "<PlayContext>")


# Generated at 2022-06-21 03:08:28.174436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.executor import module_common
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import find_action_plugin
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play