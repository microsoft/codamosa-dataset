

# Generated at 2022-06-21 03:00:20.327238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None, 'ActionModule is empty'

# Generated at 2022-06-21 03:00:32.044711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test ActionModule._task_vars
    f_module = ActionModule()
    f_module._task_vars = {}
    # Test ActionModule._task
    f_module._task = {}
    f_module._task.args = {}
    f_module._task.args['_raw_params'] = "command line raw"
    f_module._task.args['_uses_shell'] = False
    f_module._task.args['chdir'] = "/path/to/change/to"
    f_module._task.args['creates'] = "/path/to/create"
    f_module._task.args['executable'] = "/usr/bin/python"
    f_module._task.args['removes'] = "/path/to/remove"
    f_module._task.args['warn'] = False
   

# Generated at 2022-06-21 03:00:32.838166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()

# Generated at 2022-06-21 03:00:34.094035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Should never be called on this module
    assert(False)


# Generated at 2022-06-21 03:00:39.765791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor of class ActionModule"""
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:00:47.730379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import context
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # test variable manager

# Generated at 2022-06-21 03:00:56.277605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    import ansible.plugins.action.command
    # Instantiate an object of class ActionModule with paramters
    action_module = ansible.plugins.action.shell.ActionModule(
            task=None,
            connection=None,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None
    )
    # Check that the method _get_shebang returns the correct value

# Generated at 2022-06-21 03:01:00.295593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task = {'args': 'echo this is the shell module'}, 
        connection = None, 
        play_context = None, 
        loader = None, 
        templar = None, 
        shared_loader_obj = None
    )
    assert module._task.get('args') == 'echo this is the shell module'


# Generated at 2022-06-21 03:01:07.489346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = {'var1': "val1"}
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'

    data = {'args': {'_uses_shell': True}}
    action = ActionModule(
        tmp=tmp,
        task_vars=task_vars,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj,
        task_ds=data,
    )

    args = {'_raw_params': 'ls', '_uses_shell': True}

# Generated at 2022-06-21 03:01:10.678868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(
            argument_spec={},
            register='shell_out'
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 03:01:24.805246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task_vars = {"var1": "value1", "var2": "value2"}

    m_module_args = dict(
        _raw_params="echo 'foo'",
        _uses_shell=False,
        _debug_parse=False,
        executable=None,
        chdir=None,
        _uses_shell=False,
        _ansible_check_mode=False,
        _ansible_no_log=False
    )


# Generated at 2022-06-21 03:01:35.186410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = "ActionModule"
    import sys
    from io import StringIO
    from ansible.plugins.action.command import ActionModule
    sys.modules['ansible.plugins.action.command'] = ActionModule
    from ansible.plugins.action.shell import ActionModule
    from unittest.mock import patch
    with patch.dict('sys.modules', {'ansible.plugins.action.command': ActionModule}):
            capturedOutput = StringIO()
            sys.stdout = capturedOutput
            actionmodule = ActionModule()
            actionmodule.run(tmp=None, task_vars=None)
            sys.stdout = sys.__stdout__
            assert "ansible.legacy.command" in capturedOutput.getvalue()

# Generated at 2022-06-21 03:01:45.668316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tests.data.multivolumecommand as mvc
    import tests.data.command_test_data as test_data
    import os

    dummyaction = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    cmd_result_validator = mvc.CommandResultValidator()
    dummyaction._task.args['_raw_params'] = mvc.COMMAND_TO_EXECUTE
    dummyaction._task.args['_raw_params'] = test_data.command_params
    os.environ["ANSIBLE_TEST_MULTIVOLUME_COMMANDS"] = "True"
    result = None
    result = dummyaction.run(tmp=None, task_vars=None)
    assert cmd

# Generated at 2022-06-21 03:01:47.028814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:55.261400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    task = dict(action=dict(module='shell', args=dict(_uses_shell=True)))
    ansible_connection = object()
    ansible_play_context = object()
    ansible_loader = object()
    ansible_templar = object()
    ansible_shared_loader_obj = object()
    plugin_loader = object()

    # act
    action_module = ActionModule(task, ansible_connection, ansible_play_context, ansible_loader, ansible_templar, ansible_shared_loader_obj, plugin_loader)
    result = action_module.run(task_vars=dict(ansible_check_mode=True))

    # assert
    assert result.is_changed() == False
    assert result.get_result()['rc'] == 0
    assert result

# Generated at 2022-06-21 03:02:01.657107
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule.ActionModule(connection='connection',
                                 task=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
  assert type(am) == ActionModule.ActionModule


# Generated at 2022-06-21 03:02:12.013843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    #disabling log capture
    import logging
    logging.disable(logging.CRITICAL)

    #setting up test data
    class ActionBaseClass:
        def run(self, *args):
            #empty method
            pass

    class Task:
        args = {'_uses_shell': True}
    class Connection:
        shared_loader_obj = None
    class PlayContext:
        play_context = None
    class Loader:
        pass
    class Templar:
        pass

    #creating a temproray class for test
    class ActionModule:
        def __init__(self):
            self.tmp = None
            self.task_vars = {'key1': 'value1', 'key2': 'value2'}
            self._task = Task

# Generated at 2022-06-21 03:02:13.685941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    assert issubclass(ansible.plugins.action.ActionModule, object)

# Generated at 2022-06-21 03:02:16.050541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_action = ActionModule()

    assert mod_action._task.args['_uses_shell'] is True

# Generated at 2022-06-21 03:02:27.347508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the method ActionModule.run of the class ActionModule"""

    # Creation of a dummy task

# Generated at 2022-06-21 03:02:41.408924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1) set up
    actionModule = ActionModule()

    # 1.1) create mock modules
    import unittest.mock

    mock_ActionBase = unittest.mock.Mock()

    # mock the "run" method
    mocked_cmd_run_method = mock_ActionBase.run
    mocked_cmd_run_method.return_value = {"stdout": "test_stdout", "rc": 0, "stderr": "test_stderr"}

    # 2) action
    def do_command(tmp=None):
        del tmp
        return None, {"stdout": "test_stdout", "rc": 0, "stderr": "test_stderr"}


# Generated at 2022-06-21 03:02:46.376037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Keep in sync with constructor of the class
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-21 03:02:47.846780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Create ActionModule object
    :return:
    """
    tas

# Generated at 2022-06-21 03:02:48.891993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 03:02:58.682655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    
    class TestActionModule(ActionModule):
        def run(self):
            return super(TestActionModule, self).run()

    class TestActionBase(ActionBase):
        def run(self, task_vars=None):
            return dict(test=True)

    setattr(ActionModule, '_shared_loader_obj', TestActionBase)
    mod = TestActionModule(None, {})
    mod.run(task_vars=dict(a='b'))

# Generated at 2022-06-21 03:03:09.409049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Replace class 'connection.Connection' with 'connection.ConnectionNoop'
    # 'connection.ConnectionNoop' is a subclass to 'connection.Connection',
    # which is only used for testing.
    import sys
    import ansible.playbook.play_context
    from ansible_collections.ansible.plugins.connection import ConnectionNoop
    sys.modules[ansible.playbook.play_context.__name__] = ConnectionNoop

    # Create a class object for ActionModule
    from ansible_collections.ansible.plugins.action.shell import ActionModule
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test variable 'result'
    result = obj.run()

    # Test data type

# Generated at 2022-06-21 03:03:10.349057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj is not None

# Generated at 2022-06-21 03:03:20.160908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' ansible.test/test_ansible.test/test_ansible.test/test_ansible.test/test_ansible.test/test_ansible.test/test_ansible.test/test_ansible.test/test_ansible.test '''
    if True:
        class FOO():
            def __init__(self, bar='dog'):
                self.bar=bar
        class BAR():
            def __init__(self, foo='cat'):
                self.foo=foo
        class CMD():
            def __init__(self, command='echo "hello"'):
                self.command=command
        class _task():
            def __init__(self, args={}):
                self.args=args

# Generated at 2022-06-21 03:03:22.916368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Call run method and verify output object
  am = ActionModule()
  result = am.run(None, None)
  assert(result.get('_ansible_no_log') is True)

# Generated at 2022-06-21 03:03:33.618297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of ActionModule
    tester = ActionModule(connection=None, loader=None, play_context=None,
                          new_stdin=None, shared_loader_obj=None, templar=None,
                          task=None, task_vars=None, tmp=None)

    assert(tester is not None)

    # create a dict to hold the test input data
    test_args = {}
    test_args['tmp'] = 'tmp1'
    test_args['task_vars'] = 'task_vars1'

    # test a positive case
    result = tester.run(**test_args)
    assert(result is not None)

    # test a negative case
    test_args['tmp'] = None
    test_args['task_vars'] = None
    result = tester

# Generated at 2022-06-21 03:03:51.677754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule

    fake_action_base = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    fake_task = {'args': {'_someshellkey': 'someshelldata', '_someothershellkey': 'someothershelldata'}}
    fake_action_base._task = fake_task

    # Test when no shell arg exists, _uses_shell should be False
    fake_action_base._task.args = {'somekey': 'someval'}
    task_vars = None
    result = fake_action_base.run(task_vars=task_vars)
    assert result == None
    assert '_uses_shell' not in fake_action_base._

# Generated at 2022-06-21 03:03:56.133792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is a test description.
    """
    task_vars = dict()
    assert(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run(task_vars=task_vars) == None)

# Generated at 2022-06-21 03:04:00.979834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define class
    class ActionModule_run:
        def __init__(self, ansible_module):
            self.ansible_module = ansible_module

    # Create object
    params = {'task_action': 'shell'}
    tmp_ansible_module = ActionModule_run(params)

    # Run method
    result = ActionModule.run(tmp_ansible_module)

    # Assert
    assert result

# Generated at 2022-06-21 03:04:02.603497
# Unit test for constructor of class ActionModule
def test_ActionModule():
	s = ""
	a = ActionModule()
	s = a.__str__()


# Generated at 2022-06-21 03:04:03.694707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._shared_loader_obj is not None

# Generated at 2022-06-21 03:04:04.468286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule



# Generated at 2022-06-21 03:04:10.393401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(connection=None, play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)

    # Test error case when task_vars argument is missing
    result = module.run()
    assert result['failed'] == True

    # Test error case when task_vars argument is empty
    result = module.run(task_vars={})
    assert result['failed'] == True

# Generated at 2022-06-21 03:04:20.894856
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:04:21.526261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:04:24.844009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action_base = ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule
    action_module.__bases__ = (action_base.ActionBase,)
    print(action_module.run)
    print(action_base.ActionBase.run)

# Generated at 2022-06-21 03:04:40.982455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-21 03:04:43.197795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    _action = ActionModule(None, None, None, None, None, None)
    _action.run(tmp, task_vars)

# Generated at 2022-06-21 03:04:47.026843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {"_ansible_no_log": False, "changed": True}
    result = {'invocation': {'module_name': 'shell', 'module_args': 'grep -v "^HostKey" /etc/ssh/ssh_config >> /etc/ssh/ssh_config'}, 'file': '/etc/ssh/ssh_config'}
    print(result)
    assert result == data

test_ActionModule_run()

# Generated at 2022-06-21 03:04:56.397274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader_mock = MagicMock()
    templar_mock = MagicMock()
    task_mock = MagicMock()
    play_context_mock = MagicMock()
    connection_mock = MagicMock()
    shared_loader_obj_mock = MagicMock()
    
    task_mock.args = {'_uses_shell':True}
    
    action_module = ActionModule(loader=loader_mock, templar=templar_mock, task=task_mock,
                                 connection=connection_mock, play_context=play_context_mock, 
                                 shared_loader_obj=shared_loader_obj_mock)
    
    command_action_loader_mock = MagicMock()

# Generated at 2022-06-21 03:05:01.229234
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    my_args = {}

    my_args['_uses_shell'] = True

    my_task = {
        'args': my_args
    }

    tmp = None
    task_vars = {}

    my_action_module = ActionModule(my_task, tmp, task_vars)

    my_action_module.run(tmp, task_vars)
    assert True

# Generated at 2022-06-21 03:05:06.978442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an action module object
    action_module = ActionModule(connection=None,
                                 _play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None,
                                 _task=None)

    assert action_module.run(tmp=None, task_vars=None) is not None

# Generated at 2022-06-21 03:05:16.368901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.command import ActionModule
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self
    class Service:
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return self.name

# Generated at 2022-06-21 03:05:20.127421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # For some reason, "import ansible.plugins.action" does not import the
    # ActionModule class
    from ansible.plugins.action import ActionModule
    action_module = ActionModule()
    assert action_module is not None
    assert isinstance(action_module, ActionModule)
    assert action_module.__class__ is ActionModule
    assert type(action_module) is ActionModule

# Generated at 2022-06-21 03:05:25.731615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance = ActionModule()
    m_instance = mock.Mock(autospec=instance)
    m_instance._task.args = {}
    m_instance._task.args['_uses_shell'] = True
    m_instance._shared_loader_obj.action_loader.get.return_value = m_instance
    m_instance.run.return_value = "test"

    test_result = m_instance.run(tmp=None, task_vars=None)

    assert "test" == test_result
    assert m_instance._task.args['_uses_shell'] == True

# Generated at 2022-06-21 03:05:35.704248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule
    """
    # Build a mock task and connection
    mock_task = Mock()
    mock_connection = Mock()
    mock_loader = Mock()
    mock_templar = Mock()
    mock_shared_loader_obj = Mock()
    mock_task.args = {'_uses_shell': True}
    mock_command_action = Mock(return_value='test')
    mock_shared_loader_obj.action_loader.get.return_value = mock_command_action

    action_module = ActionModule(mock_task,
                                 mock_connection,
                                 mock_play_context,
                                 mock_loader,
                                 mock_templar,
                                 mock_shared_loader_obj)


# Generated at 2022-06-21 03:06:09.421601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert(module!=None)

# Generated at 2022-06-21 03:06:10.004945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:16.722489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for class ActionModule"""

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase

    class TestModule(ActionBase):
        """An ActionBase subclass for testing purposes"""

        BYPASS_HOST_LOOP = True
        TRANSFERS_FILES = False

        def run(self, tmp=None, task_vars=None):
            """An action call that returns a static value"""
            del tmp  # tmp no longer has any effect
            del task_vars  # task_vars no longer has any effect
            return True

    test_name = 'test_name'
    test_args = 'test_args'
    test

# Generated at 2022-06-21 03:06:22.233111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {'args': {}}
    mock_play_context = {'become': False}
    am = ActionModule(mock_task, mock_play_context, 'ansible.legacy.shell')

    assert am._task == mock_task
    assert am._play_context == mock_play_context
    assert am._name == 'ansible.legacy.shell'

# Generated at 2022-06-21 03:06:31.728732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.common._collections_compat import Mapping
    from nose2.tools import params

    # test ActionModule class

# Generated at 2022-06-21 03:06:32.589483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:06:33.136332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:41.493100
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Task definition (mock)
    Task = {
        'args': {
            '_uses_shell': True,
            'chdir': False,
            'creates': None,
            'executable': None,
            'removes': None,
            'warn': True
        },
        'name': 'shell'
    }

    # Action definition (mock)
    Action = {
        'name': 'shell'
    }

    # Role definition (mock)
    Role = {
        'name': 'shell'
    }

    # Play definition (mock)
    Play = {
        'hosts': 'localhost',
        'name': 'shell'
    }

    # PlayContext definition (mock)

# Generated at 2022-06-21 03:06:48.187582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = get_module(params=dict())

    assert module.run() == ({'changed': False, 'cmd': [''], 'delta': '0:00:00.008530', 'end': '2018-04-16 21:28:18.027496', 'invocation': {'module_args': {'_raw_params': '', '_uses_shell': True, 'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True}}, 'rc': 0, 'start': '2018-04-16 21:28:18.018966', 'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}, {})


# Generated at 2022-06-21 03:06:55.086153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleActionFail
    import ansible.utils.template as template

    tmp_result_obj = template.AnsibleModuleResult()
    tmp_task_obj = ActionBase._task_class(None, None)

    ActionModule.run(None, None, tmp_task_obj, None, None)

    # Unit tests for run() method
    try:
        tmp_result_obj = ActionModule.run(None, None, tmp_task_obj, None, None)
    except Exception as e:
        print(e.__dict__)
        raise AnsibleActionFail()

# Generated at 2022-06-21 03:08:29.665638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test for method run with success")
    pass

# Generated at 2022-06-21 03:08:38.037205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect
    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)

    return result

# Generated at 2022-06-21 03:08:38.532237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:08:46.108270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six.moves import cPickle

    results = dict(
        ansible_facts=dict(
            ansible_module_run=dict(
                module_stdout='',
                module_stderr='',
            )
        ),
        changed=False,
        failed=False,
        stderr='',
        stdout='',
        stdout_lines='',
        stderr_lines='',
        msg=''
    )

    pickled_task_vars = cPickle.dumps(dict())

    pickled_results = cPickle.dumps(results)
    assert pickled_results == pickled_task_vars

# Generated at 2022-06-21 03:08:47.064709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1

# Generated at 2022-06-21 03:08:48.312693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__

# Generated at 2022-06-21 03:08:49.073461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass # TODO

# Generated at 2022-06-21 03:08:57.988454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MagicMock()
    mock_connection = MagicMock()
    mock_play_context = MagicMock()
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    mock_action = MagicMock()
    mock_shared_loader_obj = MagicMock()

    # Define function attributes
    mock_action.run.return_value = {"ansible_facts": {"foo": "bar"}}
    mock_shared_loader_obj.action_loader.get.return_value = mock_action

    test_obj = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, mock_templar, mock_shared_loader_obj)


# Generated at 2022-06-21 03:08:58.964352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 03:09:01.663274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule.
    """
    actmod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actmod.run()
