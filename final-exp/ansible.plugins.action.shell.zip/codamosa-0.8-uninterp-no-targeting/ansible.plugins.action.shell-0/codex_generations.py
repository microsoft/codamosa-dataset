

# Generated at 2022-06-21 03:00:20.351337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert type(action_mod) == ActionModule

# Generated at 2022-06-21 03:00:21.165095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:27.013172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    # To instantiate ActionModule, it requires _play_context, which is not
    # passed in. But in this unit test, we don't need _play_context.
    act = ansible.plugins.action.ActionModule(task=None, connection=None,
                                              play_context=None, loader=None,
                                              templar=None, shared_loader_obj=None)
    # e.g., assert isinstance(act, ansible.plugins.action.ActionModule)

# Generated at 2022-06-21 03:00:33.757059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test to execute the module ActionModule with the method run
    """
    import sys
    import unittest

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            """ Definition of the module ActionModule with 
                a mockup for the connection and loader
            """
            class MockActionBase(ActionBase):
                def run(self,tmp=None,task_vars=None):
                    del tmp #tmp no longer has any effect
                    
                    self._task.args['_uses_shell']=True


# Generated at 2022-06-21 03:00:35.098611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:42.803014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO: write a unit test
    # command_action = ActionModule._shared_loader_obj.action_loader.get('ansible.legacy.command',
    #                                                                    task=ActionModule._task,
    #                                                                    connection=ActionModule._connection,
    #                                                                    play_context=ActionModule._play_context,
    #                                                                    loader=ActionModule._loader,
    #                                                                    templar=ActionModule._templar,
    #                                                                    shared_loader_obj=ActionModule._shared_loader_obj)
    # result = command_action.run(ActionModule._task_vars)

# Generated at 2022-06-21 03:00:54.052175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   # Test with a task which uses shell module.
   # This test assumes the task shell.yml is present in the directory.
   play_context = _read_yaml_file('../../test/units/module_utils/shell_test.yml')
   task = _read_yaml_file('../../test/units/module_utils/shell.yml')
   task_vars = dict()
   shellAction = ActionModule(play_context, task, shared_loader_obj=None)
   actions = dict()
   result = shellAction.run(actions, task_vars)
   assert result['rc']==0 and result['stdout']=='file1\nfile2\n'


# Generated at 2022-06-21 03:01:05.257016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader
    from ansible.executor.play_iterator import PlayIterator
    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-21 03:01:11.733625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action_module = action_loader.get('ansible.legacy.shell', task=None, connection=None,
                                      play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:01:15.022783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing for method run of class ActionModule')
    assert True

# Generated at 2022-06-21 03:01:17.510601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:25.985952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
     from ansible.plugins.action import ActionBase
     from ansible.plugins.action.command import ActionModule
     from ansible.module_utils._text import to_bytes
     from collections import namedtuple
     ActionModule.run = to_bytes(ActionModule.run)
     setattr(ActionModule, '_shared_loader_obj', ActionBase._shared_loader_obj)
     task_vars = {'ansible_ssh_user': 'fasdf', 'ansible_ssh_pass': 'asdfa'}
     am = ActionModule(task=namedtuple('_Task', 'args')(), connection=None, play_context=None, loader=None, shared_loader_obj=None, templar=None)
     am._task.args = {}
     am._task.args['_raw_params'] = 'ls'


# Generated at 2022-06-21 03:01:36.132561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test for method run of class ActionModule")

    # test case 1
    print("Test case 1: ")
    arg1 = {}
    arg2 = {}
    arg3 = {}
    arg4 = {}
    arg5 = {}
    arg6 = {}
    arg7 = {}
    arg8 = {}
    arg9 = {}
    arg10 = {}
    arg11 = {}
    arg12 = {}
    arg13 = {}
    arg14 = {}
    arg15 = {}
    arg16 = {}
    arg17 = {}
    arg18 = {}
    arg19 = {}
    arg20 = {}
    arg21 = {}
    arg22 = {}
    arg23 = {}
    arg24 = {}
    arg25 = {}
    arg26 = {}
    arg27 = {}

    #1st function call
   

# Generated at 2022-06-21 03:01:41.093281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(loader=None, shared_loader_obj=None, path=None, connection=None, play_context=None, templar=None, task_vars=None, _task=None)
    assert x._task is None

# Generated at 2022-06-21 03:01:48.287696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_task = dict(name="test task", action=dict())
    temp_play_context = dict(become=False, become_method="", become_user="")
    temp_connection = dict(connection="connection", network_os="network_os", remote_addr="remote_addr", transport="transport")
    temp_loader = dict()
    temp_templar = dict()
    temp_shared_loader_obj = dict()
    temp_module = ActionModule(temp_task, temp_connection, temp_play_context, temp_loader, temp_templar, temp_shared_loader_obj)
    
    assert temp_module._task == temp_task
    assert temp_module._connection == temp_connection
    assert temp_module._play_context == temp_play_context
    assert temp_module._loader == temp_loader

# Generated at 2022-06-21 03:01:51.184495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("In subroutine: test_ActionModule_run()")

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 03:01:57.372701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1: If a task execution result is passed, then it is returned
    # Setup required variables:
    # Mock the task execution result
    task_exec_result = {'status': 'ok', 'msg': 'No error'}
    # Mock the module object
    am = ActionModule(connection=None,
                      task=None,
                      play_context=None,
                      loader=None,
                      templar=None,
                      shared_loader_obj=None)
    # Call the method
    results = am.run(task_vars=task_exec_result)
    # Assert
    assert results == task_exec_result

    # Test 2: If no task execution result is passed, None is returned
    # Setup required variables:
    # Make task execution result None
    task_exec_result = None
    # Mock the module object

# Generated at 2022-06-21 03:02:07.254129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.cli.arguments import CLIArgumentParser
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    manager = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=manager)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='echo 123'), register='shell_out'),
            ]
        )
   

# Generated at 2022-06-21 03:02:07.869185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:02:14.352673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = dict(ansible_connection = "local")
    load_module = dict(module_name = "shell", module_args = "/bin/sleep 30")
    task = dict(
        task_vars=hostvars,
        action=load_module
    )
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return action_module

# Generated at 2022-06-21 03:02:29.327496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import sys
    #sys.path.append("..")
    import pytest
    from ansible.plugins.action import ActionBase
    import json
    import sys, os
    import __main__ as main
    import ansible.playbook
    import ansible.playbook.play
    import ansible.utils.vars

    my_vars = ansible.utils.vars.VariableManager()
    loader = DataLoader()
    my_inventory = Inventory(loader=loader)
    task = ansible.playbook.task.Task()
    task_vars = ansible.utils.vars.VariableManager()

    #return tmp no longer has any effect
    tmp = 'tmp'
        
    #return Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True
    command_

# Generated at 2022-06-21 03:02:39.764125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    log_results_to_terminal = False
    log_results_to_json_file = True
    target_playbook_file = 'test_playbooks/test_playbook_action_shell.yml'
    target_playbook_dir = target_playbook_file.split('/')
    # remove test_playbook_file from target_playbook_dir
    target_playbook_dir.pop()
    target_playbook_dir = '/'.join(target_playbook_dir)

    target_playbook_file_json = target_playbook_file + '.json'
    # Create a list of test cases
    test_cases = list()
    # This one runs the script and checks that the output of the script is in the Ansible output

# Generated at 2022-06-21 03:02:50.248622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("test_ActionModule_run")
  # 1) setup a task
  from ansible.playbook.task import Task
  from ansible.playbook.task_include import TaskInclude
  from ansible.template import Templar
  from ansible.vars.unsafe_proxy import AnsibleUnsafeText
  import json
  
  t = Task()
  t._role = None
  t._block = None
  t.action = 'command'
  t.args = {'_raw_params':'echo kalle anka'}
  t._parent = None
  t._play = None
  t._play = None
  t._ds = None
  t._task_include = TaskInclude()
  t._task_include._args = {}
  t._task_include._task_args = {}
  t._task

# Generated at 2022-06-21 03:02:59.796611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._shared_loader_obj = None
    ActionModule._templar  = None
    ActionModule._loader = None
    ActionModule._connection = None
    ActionModule._play_context = None
    ActionModule._task = None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-21 03:03:00.788993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base = ActionBase()
    action_base.run()

# Generated at 2022-06-21 03:03:02.244163
# Unit test for constructor of class ActionModule
def test_ActionModule():  # lgtm[py/similar-function]
    assert ActionModule()

# Generated at 2022-06-21 03:03:02.808689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:11.117361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_mocked_object():
        def __init__(self):
            self.task = {}
            self.task['args'] = {}
    am = ActionModule_mocked_object()
    assert am.task['args'] == {}
    # Testing the run method of class ActionModule
    class Mock():
        def run(self):
            pass
    am.task['args']['_uses_shell'] = True
    am.task['action'] = 'ansible.legacy.command'
    am.task['args']['action'] = 'ansible.legacy.command'
    am.task['connection'] = 'connection'
    am.task['play_context'] = 'play_context'
    am.task['loader'] = 'loader'
    am.task['templar'] = 'templar'


# Generated at 2022-06-21 03:03:20.781125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask():
        def __init__(self):
            self.args = {'_uses_shell': True}

    class MockPlayContext():
        def __init__(self):
            self.connection = 'chicago.il.us.example.com'
            self.remote_addr = '10.25.1.1'
            self.remote_user = 'admin'
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.port = '5309'
            self.network_os = 'firepower'
            self.check_mode = False

    class MockActionBase():
        def __init__(self):
            self._task = MockTask()
            self._connection = 'chicago.il.us.example.com'
           

# Generated at 2022-06-21 03:03:22.017499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setattr(ActionModule, 'run', run)

# Generated at 2022-06-21 03:03:36.932445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule._task = "task"
    test_ActionModule._connection = "connection"
    test_ActionModule._play_context = "context"
    test_ActionModule._loader = "loader"
    test_ActionModule._templar = "templar"
    test_ActionModule._shared_loader_obj = "shared_loader_obj"
    assert ActionModule(test_ActionModule._task, test_ActionModule._connection,
                        test_ActionModule._play_context, test_ActionModule._loader,
                        test_ActionModule._templar, test_ActionModule._shared_loader_obj
                        ) is not None

# Generated at 2022-06-21 03:03:40.106686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action
    res = action.ActionModule('module', 'name', 'parameters')
    assert res.called_module == 'module'
    assert res.name == 'name'
    assert res.params == 'parameters'


# Generated at 2022-06-21 03:03:46.844773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self):
            self.args = {'_uses_shell': True}
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    obj = ActionModule(Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return obj

# Generated at 2022-06-21 03:03:57.205139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.shell import ActionModule
    
    # Create dummy action module class
    class DummyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(DummyActionModule, self).run(tmp, task_vars)

    # Create dummy object for ActionModule   
    class DummyActionModuleObj:
        def __init__(self):
            self._task = {}
            self._task['args'] = {}
            self._shared_loader_obj = {}
            self._shared_loader_obj.action_loader = {}
            self._connection = {}
            self._play_context = {}
            self._loader = {}
            self._templar = {}

    # Get class for command action


# Generated at 2022-06-21 03:04:05.237102
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ############################################################################
    # Monkey patch the module to remove dependency on __salt__ variable
    ############################################################################
    from ansible.plugins.action import shell
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    import os

    def shell_exec_command(command, args, stdin, runas, shell):
        """
        Execute a command given as a parameter
        """

        salt_bin_dir = "/root/salt-master/bin"
        salt_bin_path = os.path.join(salt_bin_dir, command)

        if not salt_bin_path.startswith(salt_bin_dir):
            return None, None, "Skipping external command execution."

        if args:
            salt_bin_path = salt_bin_

# Generated at 2022-06-21 03:04:06.504459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert "Test Not Implemented"

# Generated at 2022-06-21 03:04:07.675221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp = {}
    ActionModule(temp, {}, {})

# Generated at 2022-06-21 03:04:18.526038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This action doesn't have any effect; it only exists to wrap command
    # but it is a substitute for the deprecated module ansible.modules.shell
    # that is now deprecated.
    #
    # We test this because this module is used in a lot of playbooks as of
    # 2.3.0.
    #
    from ansible.plugins.action.shell import ActionModule as ShellActionModule
    from ansible.playbook.play_context import PlayContext
    task = object()

    # Sanity check for testing
    assert task is not None

    # Instantiate the ActionModule object
    action_module = ShellActionModule(task=task, connection=None,
        play_context=PlayContext(), loader=None, templar=None,
        shared_loader_obj=None)

    # Run the ActionModule
    result = action_

# Generated at 2022-06-21 03:04:26.003303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_action = ActionModule()

# Generated at 2022-06-21 03:04:26.844169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()

# Generated at 2022-06-21 03:04:46.492729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None


# Generated at 2022-06-21 03:04:47.148546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_mod = ActionModule()

# Generated at 2022-06-21 03:04:47.949495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:57.705786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_loader = MagicMock()
    mock_shared_loader_obj = MagicMock()
    mock_command_action = MagicMock()

    test_module = ActionModule(
        task=MagicMock(),
        connection=MagicMock(),
        play_context=MagicMock(),
        loader=mock_loader,
        templar=MagicMock(),
        shared_loader_obj=mock_shared_loader_obj
    )

    mock_shared_loader_obj.action_loader.get.return_value = mock_command_action
    mock_command_action.run.return_value = 'test_command_action_result'

    result = test_module.run(
        task_vars=MagicMock()
    )

    assert result == 'test_command_action_result'


# Unit test

# Generated at 2022-06-21 03:04:58.901960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 03:05:08.944767
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m_action_loader = mocker.patch('ansible.plugins.ActionBase._shared_loader_obj.action_loader', new_callable=mocker.PropertyMock)
    m_action_loader.return_value = mocker.MagicMock()

    m_connection = mocker.patch('ansible.plugins.action.ActionModule._connection', new_callable=mocker.PropertyMock)
    m_play_context = mocker.patch('ansible.plugins.action.ActionModule._play_context', new_callable=mocker.PropertyMock)

    m_task = mocker.patch('ansible.plugins.action.ActionModule._task', new_callable=mocker.PropertyMock)
    m_task.args = {'_uses_shell': True}


# Generated at 2022-06-21 03:05:18.169825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_vars = {
        "target": "test_target",
        "template_version": "test_template_version",
        "template_name": "test_template_name",
        "template_path": "test_template_path",
        "template_content": "test_template_content",
        "template_type": "test_template_type",
        "os_type": "test_os_type"
    }

    # Create mock object.
    class MockActionBase:
        def __init__(self):
            self._task = {
                "args": {
                    "_uses_shell": False
                }
            }

        def get_loader(self):
            return "MockLoader"


# Generated at 2022-06-21 03:05:18.942533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 03:05:19.910072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module._task.args['_uses_shell'] == True

# Generated at 2022-06-21 03:05:25.005984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run() is None

# Generated at 2022-06-21 03:06:04.253632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ AnsibleModule(argument_spec=dict(), supports_check_mode=True).run()
    Unit test for AnsibleModule.run method with _uses_shell=True.

    AnsibleModule(argument_spec=dict(), supports_check_mode=True)
        Initialize self.

    AnsibleModule.run(task_vars)
        Run module.

    Note:
    - AnsibleModule.run(task_vars) has already been unit tested in
    test_AnsibleModule_run()
    """
    module = BaseModule()

    action_plugin = ActionModule(module, module._shared_loader_obj)
    action_plugin.run(task_vars=dict())

# Generated at 2022-06-21 03:06:05.709933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("google")


# Generated at 2022-06-21 03:06:06.605003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 03:06:07.970107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 03:06:09.102283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:06:09.685328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:10.264205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:06:11.191352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)


# Generated at 2022-06-21 03:06:12.078785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:06:12.525386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:07:34.310765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mc = ActionModule(1, 2, 3, 4)
    assert mc is not None


# Generated at 2022-06-21 03:07:34.836966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # nothing to test

# Generated at 2022-06-21 03:07:36.745012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.command import ActionModule
    result = ActionModule.run(task_vars=dict(ansible_lsb=dict(distrib_id='Fedora')))
    assert 'Fedora' in result['stdout']

# Generated at 2022-06-21 03:07:37.754692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule.run()

# Generated at 2022-06-21 03:07:46.434522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test Case: ActionModule:run")
    # Initialize variables for test
    valid_results = {
        '_ansible_parsed': True,
        '_ansible_no_log': False,
        '_ansible_item_result': False,
        '_ansible_verbose_always': True,
        '_ansible_version': 2}


# Generated at 2022-06-21 03:07:47.931186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is to test the constructor of class ActionModule"""
    a = ActionModule()
    return a


# Generated at 2022-06-21 03:07:48.353114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:07:50.993401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(
        task=dict(action=dict(module_name='shell')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert test is not None


# Generated at 2022-06-21 03:07:56.445923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict()
    # args = {'_ansible_parsed': False, '_ansible_no_log': False}
    # task = {'action': {'__ansible_module__': 'ansible.builtin.shell'},
    #         'name': 'shell test',
    #         'args': args,
    #         'delegate_to': None}

    # parser = Mock()
    # connection = Mock()
    # play_context = Mock()
    # tmp = Mock()
    # loader = Mock()
    # templar = Mock()
    # shared_loader_obj = Mock()

    # action_base = ActionBase(task=task, connection=connection, play_context=play_context,
    #                          loader=loader, templar=templar, shared_loader_

# Generated at 2022-06-21 03:07:58.837752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert actionModule.run(tmp=None, task_vars=None) == {}