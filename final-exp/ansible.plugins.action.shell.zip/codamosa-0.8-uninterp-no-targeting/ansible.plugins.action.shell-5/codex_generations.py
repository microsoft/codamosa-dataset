

# Generated at 2022-06-21 03:00:25.446112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    return True

# Generated at 2022-06-21 03:00:27.441817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert 'ansible.legacy.shell' == module._name

# Generated at 2022-06-21 03:00:31.204976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task='task', connection='connection', play_context='play_context', loader='loader', shared_loader_obj='shared_loader_obj') is not None

# Generated at 2022-06-21 03:00:34.666921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(connection=None, play_context=None,
                          loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp=None, task_vars=None)
    assert result == None

# Generated at 2022-06-21 03:00:39.975872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    args = dict()
    args['_uses_shell'] = True
    task = dict()
    task['args'] = args

    module._task = task
    module._shared_loader_obj = dict()
    module._task = dict()
    module._connection = dict()
    module._play_context = dict()
    module._loader = dict()
    module._templar = dict()

    assert module.run()

# Generated at 2022-06-21 03:00:42.607689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data_source = {"shell": "/bin/sh"}
    ActionModule('/bin/sh', 'test_connection', data_source, 'ansible.legacy.shell.ActionModule.test_ActionModule', None)

# Generated at 2022-06-21 03:00:43.341946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_ = ActionModule()

# Generated at 2022-06-21 03:00:44.625645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 03:00:45.980281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:00:55.766610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Check that:
    - class ActionModule is properly instantiated.
    - run method of ActionModule class raise a failure.
    - run method of ActionModule class raise a error.
    - run method of ActionModule class raise a success.
    """
    from ansible.module_utils.network.ftd.module_nsobjects import FtdConfigurationError

    yaml_config = {'host': 'host', 'username': 'username', 'password': 'password', 'validate_certs': 'validate_certs',
                   'workspace': 'workspace', 'port': 'port'}

    import ansible.plugins.loader as plugin_loader
    import ansible.module_utils.network.ftd.connection as connection



# Generated at 2022-06-21 03:01:00.327551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module is not None

# Generated at 2022-06-21 03:01:07.480538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    sys.path.append(os.getcwd())
    print(sys.path)
    from src.action_module import ActionModule
    from src.fakes.fake_connection import FakeConnection
    from src.fakes.fake_loader import FakeLoader
    from src.fakes.fake_play_context import FakePlayContext
    from src.fakes.fake_task import FakeTask
    from src.fakes.fake_shared_loader_obj import FakeSharedLoaderObj
    connection = FakeConnection()
    loader = FakeLoader()
    play_context = FakePlayContext()
    task = FakeTask(connection)
    shared_loader_obj = FakeSharedLoaderObj()
    action_module = ActionModule(connection, loader, play_context, task, shared_loader_obj)
    action_module.run

# Generated at 2022-06-21 03:01:15.837555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader
    mock_loader = ansible.plugins.loader.ActionLoader({}, '', None)
    mock_task = MockTask()
    mock_connection = MockConnection()
    mock_play_context = MockPlayContext()
    mock_loader = MockLoader()
    mock_templar = MockTemplar()
    mock_shared_loader_obj = MockSharedLoaderObj()

    test_subject = ansible.plugins.action.ActionModule(mock_loader,
                                                       mock_task,
                                                       mock_connection,
                                                       mock_play_context,
                                                       mock_loader,
                                                       mock_templar,
                                                       mock_shared_loader_obj)

    assert test_subject._loader is mock_loader
    assert test_subject._task is mock_task


# Generated at 2022-06-21 03:01:18.247739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ShellActionModule(ActionModule):
        pass
    assert 'ShellActionModule' == ShellActionModule

# Generated at 2022-06-21 03:01:26.207435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = '$HOME/.ansible/tmp/ansible-tmp-1528846228.36-135471449021756/command.py'
    module = action_plugins.action_tmp.ActionModule({'_uses_shell': True}, tmp, dict, dict, dict)
    assert module.run(tmp, dict) == {'cmd': 'ls', 'delta': '0:00:00.001596', 'end': '2018-06-13 14:10:30.185701', 'invocation': {'module_name': 'command'}, 'rc': 0, 'start': '2018-06-13 14:10:30.184101', 'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}

# Generated at 2022-06-21 03:01:28.507344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert hasattr(module, 'run')


# Generated at 2022-06-21 03:01:30.329629
# Unit test for constructor of class ActionModule
def test_ActionModule():
   module = AnsibleModule(argument_spec={'cmd': {'type': 'list', 'required': True}}, supports_check_mode=True)
   # main function is run when this module is called in playbook
   if __name__ == '__main__':
      main()

# Generated at 2022-06-21 03:01:30.933479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    pass

# Generated at 2022-06-21 03:01:38.365983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, shared_loader_obj=None,
                          connection=None, play_context=None,
                          task=None, templar=None)

    tmp = None
    task_vars = None
    result = module.run(tmp=tmp, task_vars=task_vars)

    assert result.dump() == '{"stdout": "", "stderr": "", "cmd": "", "rc": 0, "_ansible_verbose_override": false, "invocation": {"module_args": {"_ansible_check_mode": false, "_ansible_diff": false, "_uses_shell": true, "_ansible_verbosity": 0}}, "changed": false, "stdout_lines": [], "rc": 0}', 'ActionModule.run did not return expected value'

# Generated at 2022-06-21 03:01:43.914319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor
    action_module = ActionModule(
        task=dict(),                                                   # task
        connection=None,                                               # connection
        play_context=None,                                             # play_context
        loader=None,                                                   # loader
        templar=None,                                                  # templar
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-21 03:01:49.299525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = AnsibleModule()
    assert a.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-21 03:01:56.432936
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestArg:
        def get(self, key):
            return 'test_module'

    class TestTask:
        def __init__(self):
            self.args = TestArg()

        def get_name(self):
            return 'test_task'


    class TestActionBase:
        def __init__(self):
            self._task = TestTask()
            self._connection = 'test_connection'
            self._play_context = 'test_play_context'
            self._loader = 'test_loader'
            self._templar = 'test_templar'
            self._shared_loader_obj = 'test_shared_loader_obj'

        def args(self):
            return self._task.args


    test_ActionModule = ActionModule(connection='test', play_context='test')
    test

# Generated at 2022-06-21 03:01:57.390747
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:01:57.905413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-21 03:01:59.292583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(arg=3)


# Generated at 2022-06-21 03:02:00.141374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:01.582106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module= ActionModule()
    assert action_module

# Generated at 2022-06-21 03:02:05.076747
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock of object ActionBase
    action_base = ActionBase()

    # Create a mock of object ActionModule
    action_module = ActionModule()

    # Test the method run of class ActionModule. The object action_base must be used.
    assert(action_module.run(action_base))

# Generated at 2022-06-21 03:02:12.109528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        connection=None,
        task_vars={},
        tmp='/tmp',
        _task=None,
        _play_context=None,
        _loader=None,
        _templar=None,
        _shared_loader_obj=None,
        loader=None,
        action_loader=None,
        )
    assert module.run() == {}

# Generated at 2022-06-21 03:02:12.683401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:02:21.506051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise TypeError('unsupported')



# Generated at 2022-06-21 03:02:22.580964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 03:02:32.381049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    loader = None
    task = Task()
    task._role = None
    task._task_vars = {}
    task._variable_manager = variable_manager
    play_context = PlayContext()
    play_context._options = {}
    action = ActionModule(loader=loader, task=task, play_context=play_context, connection=None)
    action.run()

# Generated at 2022-06-21 03:02:42.223027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    task = dict(action=dict(module='shell',
                            args=dict(free_form='true',
                                      _uses_shell='true')))
    play_context = PlayContext()
    connection = {}

    _loader = 'ansible.parsing.dataloader.DataLoader'
    _templar = 'ansible.parsing.vault.VaultLib'
    _shared_loader_obj = 'ansible.vars.manager.VarsManager'
    play_context = PlayContext()
    task_vars = dict()

    action

# Generated at 2022-06-21 03:02:42.885719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:47.531225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    task['args'] = {}
    task['args']['_uses_shell'] = True
    ta = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert ta is not None

# Generated at 2022-06-21 03:02:49.368640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 03:02:54.975238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = {}
    am['ansible_job_id'] = '123456789'
    am['ansible_facts'] = dict(fact1='factvalue1')
    am['ansible_inject'] = dict(module_setup=True, module_defaults=True, become_setup=True)

# Generated at 2022-06-21 03:02:56.146464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass a fake self to the constructor
    action_module = ActionModule()

# Generated at 2022-06-21 03:03:07.644349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import unittest
    from ansible.connection import Connection

    class TestActionModule(unittest.TestCase):
        def test_formatter(self):
            # Test of method _format_output with specified parameters
            result = ActionModule()._format_output(tmp=tempfile.TemporaryFile(),
                                                   stdout="stdout",
                                                   stderr="stderr",
                                                   parsed="parsed",
                                                   rc="rc",
                                                   cmd="cmd",
                                                   start="start",
                                                   end="end",
                                                   delta="delta",
                                                   stdout_lines="stdout_lines",
                                                   stderr_lines="stderr_lines")

# Generated at 2022-06-21 03:03:34.011931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {}
    task["args"] = {}
    task["args"]["_uses_shell"] = True
    task["name"] = "shell"

    module_args = {}

    shared_loader_obj = {}
    connection = {}

    command_action_module = {}
    command_action_module["run"] = lambda **kwargs: "run"

    command_loader = {}
    command_loader["get"] = lambda **kwargs: command_action_module

    task_vars = {}

    action_loader = {}
    action_loader["action_loader"] = {}
    action_loader["action_loader"]["get"] = lambda **kwargs: command_loader


# Generated at 2022-06-21 03:03:42.058758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    import json
    import sys

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    results = []
    results_command = []

    class TestModule(object):
        def run(self, tmp=None, task_vars=None):
            results.append(dict(changed=False, ansible_facts=dict(test='ok')))
            return results


# Generated at 2022-06-21 03:03:42.912761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_object = ActionModule()

# Generated at 2022-06-21 03:03:53.331492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    task_queue_manager = TaskQueueManager(None, None, None, None, None, None)
    my_task = task_queue_manager.get_initial_task_for_host('test_host')
    my_task.action = 'ansible.legacy.shell'
    my_task.args = dict()
    my_task.args['_raw_params'] = 'echo "test echo"'
    my_task.args['_uses_shell'] = True
    my_task.args['chdir'] = '/home/fake_user'
    my_task.args['creates'] = '/etc/fake_file'
   

# Generated at 2022-06-21 03:04:00.824524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object with a parameterized constructor
    actionModule = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Test call to method run with no parameters
    # TODO: Update for new API
    #result = actionModule.run(tmp=None, task_vars=None)

    # Print out the result
    #print("The result of calling ActionModule.run() is:")
    #print(result)

    # Verify that the result is correct
    assert 1 == 1



# Generated at 2022-06-21 03:04:02.754016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(connection=None, play_context=None, loader=None,
                        templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:04:06.510862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Read data from YAML
    import yaml
    data = yaml.load(open('./test/unit/plugins/actions/test_action_module.yml'))

    action_module = ActionModule()
    result = action_module.run()

    # Print data set in JSON format
    import json
    assert json.dumps(result, indent=4) == json.dumps(data['result'], indent=4)

# Generated at 2022-06-21 03:04:07.095558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:04:07.597936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:18.442636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager  # noqa
    from ansible.module_utils.connection import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    action_module = ActionModule()
    host = "localhost"
    host2 = "1.2.3.4"
    name = "shell"
    module_name = "ansible.legacy.shell"
    task = Task(name="test_task", action=module_name)
    module_loader = ActionModuleLoader(DataLoader(), None)
   

# Generated at 2022-06-21 03:04:55.802778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections
    import os
    from ansible.plugins.loader import action_loader

    action_plugin = action_loader.get('shell')
    fake_task = collections.defaultdict(lambda: None)
    print(type(action_plugin))
    print(type(fake_task))
    action_module = action_plugin(fake_task, connection=None, play_context=None, loader=None, templar=None,
                                  shared_loader_obj=None)
    assert type(action_module) is type(action_plugin)
    print(action_module)
    print(action_plugin)
    module_path = os.path.dirname(action_plugin.__code__.co_filename)

    assert module_path.endswith('shell')

# Generated at 2022-06-21 03:05:06.591329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    before unit test, we need to make some preparations:
    """
    # 1) prepare a test connection
    conn = "test_connection"
    # 2) prepare a test task object
    test_task = "test_task"
    # 3) prepare a test play_context
    test_play_context = "test_play_context"
    # 4) prepare a test loader
    test_loader = "test_loader"
    # 5) prepare a test templar
    test_templar = "test_templar"
    # 6) prepare a test shared_loader_obj
    test_shared_loader_obj = "test_shared_loader_obj"

    # define ActionModule object by using the parameters above.

# Generated at 2022-06-21 03:05:09.012089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj is not None

# Generated at 2022-06-21 03:05:18.238858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'test.test_action_plugin'
    module_args = {
        'echo': '"RUNNING %s"' % module_name,
        '_uses_shell': True
    }

    sdk = AnsibleCollectionSDK([module_name])
    task = TaskMock(module_args, ActionModule, sdk=sdk)
    connection = ConnectionMock()
    module = ActionModule(task, connection)

    msg = 'plugin unable to run module "test.test_action_plugin"'

    result = module.run()
    assert result['rc'] == 0
    assert result['stderr'] == ''
    assert result['stdout'] == 'RUNNING test.test_action_plugin\n'
    assert result['stdout_lines'] == ['RUNNING test.test_action_plugin']

# Generated at 2022-06-21 03:05:18.581903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:19.037553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:05:25.005840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test 1')
    tmp = None
    task_vars = None
    action_module = ActionModule(loader=None, templar=None, shared_loader_obj=None, connection=None, play_context=None, task=None, _shared_loader_obj=None)
    action_module._task.args['_uses_shell'] = True
    command_action = action_module._shared_loader_obj.action_loader.get('ansible.legacy.command', task=action_module._task, connection=action_module._connection, play_context=action_module._play_context, loader=action_module._loader, templar=action_module._templar, shared_loader_obj=action_module._shared_loader_obj)
    command_action.run(task_vars=task_vars)


# Generated at 2022-06-21 03:05:34.611886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    reload(action)
    import ansible.executor.task_result as task_result
    import ansible.executor.task_result as task_result
    from ansible.plugins.action import ActionBase
    from ansible.compat.tests import unittest

    class MockTask(object): 
        def __init__(self): 
            self.args = {}
    class MockTemplar(object): 
        def __init__(self): 
            pass
        def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, default_var_templar=None, default_var_render=None, allow_unsafe=False, templatevars=None): 
            pass

# Generated at 2022-06-21 03:05:35.401201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:36.656296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 03:06:45.757400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:46.533195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 03:06:47.502482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("ActionModule constructor")
    test_actionmodule = ActionModule()

# Generated at 2022-06-21 03:06:48.451717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 03:06:56.240797
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:07:04.677209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action='shell', module_args=dict(command='ls', _raw_params='-al'))
    connection = dict(module_implementation_preferences=list())
    play_context = dict(basedir='/home/ansible/playbooks')
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()
    tmp = dict()
    task_vars = dict()

    action_module = ActionModule(task=task,
                                 connection=connection,
                                 play_context=play_context,
                                 loader=loader,
                                 templar=templar,
                                 shared_loader_obj=shared_loader_obj)

    result = action_module.run(tmp=tmp, task_vars=task_vars)

    assert result is not None

# Generated at 2022-06-21 03:07:05.178126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:07:05.640397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-21 03:07:09.121119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=ActionModule,
        connection=ActionModule,
        play_context=ActionModule,
        loader=ActionModule,
        templar=ActionModule,
        shared_loader_obj=ActionModule)
    action_module.run()

# Generated at 2022-06-21 03:07:12.199437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up a mock Task object
    TaskMock = unittest.mock.Mock()

    # Use the mocked Task object for the test
    test_instance = ActionModule(TaskMock)

    assert isinstance(test_instance, ActionModule)

    # Overwrite the _task object with the mock object
    assert test_instance._task == TaskMock


# Generated at 2022-06-21 03:10:24.381816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Note that this module is about testing the constructor of ActionModule
    # class. This is a functional test, so we need functional imports.
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule

    a = ActionBase()
    b = ActionModule()

    assert a is not b
    assert a.__class__ is not b.__class__
    assert isinstance(b, ActionBase)

    # Both 'a' and 'b' should be instance of ActionBase class.
    assert isinstance(a, ActionBase)
    assert isinstance(b, ActionBase)
    # ActionBase is the parent of ActionModule.
    assert issubclass(ActionModule, ActionBase)