

# Generated at 2022-06-21 03:00:34.708282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    import os
    import tempfile
    import yaml

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp ansible.cfg
    ansible_cfg = os.path.join(tmpdir, "ansible.cfg")
    f = open(ansible_cfg, "w")
    f.write("[defaults]\nroles_path=%s\n" % tmpdir)
    f.close()

    # Create a temp playbook
    playbook_path = os.path.join(tmpdir, "test.yml")
    f = open(playbook_path, "w")

# Generated at 2022-06-21 03:00:38.795474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = MagicMock()
    pc = MagicMock()
    l = MagicMock()
    t = MagicMock()
    slo = MagicMock()
    task = MagicMock()
    action = ActionModule(task, conn, pc, l, t, slo)
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 03:00:46.849441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeTask:
        def __init__(self):
            self.args = {'_uses_shell': True}

    class FakeActionModule:
        def __init__(self):
            self._task = FakeTask()
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    class FakeActionBase:
        def __init__(self):
            self._task = FakeTask()
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

        def run(self, task_vars=None): pass

    class FakeActionLoader:
        def __init__(self):
            self

# Generated at 2022-06-21 03:00:49.329459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing action object
    action_Module = ActionModule()

    # Unused variables to initialize action object
    task_vars = None
    tmp = None

    # Calling method run with arguments
    # Unused variables to initialize action object
    action_Module.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-21 03:00:58.964901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import PluginLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    play_context = PlayContext()
    play_context.network_os = 'nxos'
    loader = PluginLoader(class_name='NxosModule', 
                          package='ansible.modules.network.nxos',
                          config=None,
                          subdir=None)
    inventory = InventoryManager(loader=loader,
                                sources=None)
    variable_

# Generated at 2022-06-21 03:01:02.379554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    action = ActionModule()
  except TypeError as e:
    print(e)
    return 1
  if action:
    return 0
  else:
    return 1

# Generated at 2022-06-21 03:01:12.646502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module_instance = AnsibleModule(
    #     argument_spec={'fail': {'type': 'bool', 'default': False}})
    # module_result = action_module_instance.run()
    # assert module_result['failed'] is False
    # assert module_result['rc'] == 0
    # assert module_result['_ansible_parsed'] is True
    # assert module_result['_ansible_no_log'] == False
    # assert module_result['_ansible_delegated_vars'] == {}
    # assert len(module_result['changed']) == 0
    pass

# Generated at 2022-06-21 03:01:24.089754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Provided parameters
    tmp = None
    task_vars = None
    
    # Return from method call
    return_from_run = None
    
    # Create object
    action_module = ActionModule()

    # Assign values to AnsibleModule and AnsibleAction objects
    action_module._task = None
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._shared_loader_obj = None
    action_module._templar = None

    # Mocking Callable
    def mocked_run_ActionModule_run(tmp, task_vars):
        return return_from_run

    action_module.run = mocked_run_ActionModule_run

    # Call method

# Generated at 2022-06-21 03:01:24.855847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 03:01:35.699397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import connection_loader
    from ansible.vars.persist import BaseVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible import context
    import os
    import yaml

# Generated at 2022-06-21 03:01:38.506530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:01:41.096022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_ActionModule = ActionModule()
    assert my_ActionModule is not None


# Generated at 2022-06-21 03:01:43.068982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('temp', 'ansible.legacy.modules.shell')
    assert action_module._templar == 'temp'

# Generated at 2022-06-21 03:01:51.820730
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionBase

    from ansible.playbook.task import Task

    from ansible.plugins.loader import action_loader
    action_loader.add_directory('./test/action_plugins')

    # Not sure if this is the right one to test on but it doesn't seem to be an issue?
    task = Task()
    task.action = 'ActionModule_test'

    action = ActionBase()
    action._task = task

    action.run()

# Generated at 2022-06-21 03:01:58.204536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(_uses_shell=True)),
        connection="",
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-21 03:02:07.598788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = action_module.run(None, None)


# Generated at 2022-06-21 03:02:16.024523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None,connection=None,play_context=None,task_vars=None,tmp=None)
    module.result = dict(rc=0,msg='',stdout='',stderr='')
    command_action_module = dict(rc=0,msg='',stdout='',stderr='')
    command_action_module['rc'] = 1
    module_result = module.run(dict(rc=0,msg='',stdout='',stderr=''),dict(rc=0,msg='',stdout='',stderr=''))
    assert command_action_module['rc'] == module_result['rc']

# Generated at 2022-06-21 03:02:27.349844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import types

    class ShellActionModuleMock:

        class ActionBaseMock:
            def __init__(self, *args, **kwargs):
                self.args = {}
                self.kwargs = kwargs
                self._task = {}

            def _run_module(self, *args, **kwargs):
                return True, args, kwargs

        class PluginLoaderMock:
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs
                self.action_loader = None

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.ActionBase = ShellActionModuleMock.ActionBaseMock
            self.PluginLoader = Shell

# Generated at 2022-06-21 03:02:27.928155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:02:29.596530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    command_action = ActionModule()
    print(command_action)

# Generated at 2022-06-21 03:02:38.134349
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run(tmp=None, task_vars=None) == None

# Generated at 2022-06-21 03:02:39.399756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    l = ActionModule()
    assert l

# Generated at 2022-06-21 03:02:49.776127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task of type command with one argument that would be processed by command
    task_data = {
        'version': 2,
        'action': {
            '__ansible_module__': 'shell',
            '__ansible_arguments__': 'echo "Hello world"'
        }
    }
    # Create fake temporary directory, task variables, and connection
    tmp = 'fake/tmp/directory'
    task_vars = {}
    connection = 'ansible.legacy.command.Connection.Local'
    # Create a fake task object with above data
    task = ansible.legacy.task.Task(task_data)
    # Create a fake loader object, templar object, and shared loader object
    loader = ansible.legacy.loader.DataLoader()

# Generated at 2022-06-21 03:02:59.498759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar
    from ansible.context import ConnectionContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json
    import pytest


    class TestTask(object):
        def __init__(self):
            self.args = dict()
            self.loop = None

        def maybe_add_host_list_to_loop(self, loop):
            self.loop = loop

    class TestTaskQueueManager(object):
        def __init__(self, loader, variable_manager, inventory, context, options, passwords, stdout_callback=None):
            self

# Generated at 2022-06-21 03:03:09.239154
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock TaskExecutor
    task_executor = MockTaskExecutor()

    # Create a mock Task
    task = MockTask({
        'args': {'_uses_shell': True}
    })

    # Create mock AnsibleConnection
    connection = MockAnsibleConnection()

    # Create mock PlayContext
    play_context = MockPlayContext()

    # Create a mock ActionModule object
    action_module = ActionModule(task=task, connection=connection, play_context=play_context)

    # Create a mock AnsibleLoader
    ansible_loader = MockAnsibleLoader()

    # Create a fake templar
    templar = MockTemplar()

    # Create a mock SharedLoaderObj
    shared_loader_obj = MockSharedLoaderObj(ansible_loader)

    # Mock ansible_loader.

# Generated at 2022-06-21 03:03:19.190031
# Unit test for constructor of class ActionModule
def test_ActionModule():

    hostvars = dict(ansible_facts=dict(distribution="Debian"), ansible_all_ipv4_addresses=[], ansible_all_ipv6_addresses=[])
    module_utils = dict(AGENT_DATA_DIR="/tmp/agent", AGENT_VERSION="1.0")


# Generated at 2022-06-21 03:03:20.303262
# Unit test for constructor of class ActionModule
def test_ActionModule():
	x = ActionModule()
	assert x is not None

# Generated at 2022-06-21 03:03:23.075885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionModule as CommandModule
    from ansible.plugins.loader import ActionLoader
    from ansible.template import Templar

    am = ActionModule(ActionLoader(), CommandModule(), Templar())

    assert am.__class__ == ActionModule



# Generated at 2022-06-21 03:03:23.947862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO write
    assert False

# Generated at 2022-06-21 03:03:34.643008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.action.command import ActionModule
    
    args = [ 'cmd', 'echo', 1]
    task = AnsibleUnicode({'args': args })
    loader = AnsibleUnicode({'passed': 1 })
    tmp = AnsibleUnicode({'passed': 1 })
    templar = AnsibleUnicode({'passed': 1 })
    shared_loader_obj = AnsibleUnicode({'passed': 1 })
    connection = AnsibleUnicode({'passed': 1 })
    play_context = AnsibleUnicode({'passed': 1 })
    am = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    am._task

# Generated at 2022-06-21 03:03:44.240295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None, None)
    assert am  # So pylint will not complain

# Generated at 2022-06-21 03:03:44.774005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:45.290117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

# Generated at 2022-06-21 03:03:47.142445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ansible.plugins.action.ActionBase()
    assert module

# Generated at 2022-06-21 03:03:48.790553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO: Implement tests for test_ActionModule_run

# Generated at 2022-06-21 03:03:49.652795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 03:03:50.572549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:03:51.601730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor
    print("Unit test: constructor of class ActionModule")
    class_instance = ActionModule()
    print("Unit test: finish")

# Generated at 2022-06-21 03:04:01.018912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult

    action_module = ActionModule()
    action_module._loader = {}
    action_module._templar = {}
    action_module._shared_loader_obj = {}
    action_module._task = {}
    action_module._play_context = {}
    action_module._connection = {}

    # test for exception when command is None
    action_module._task.args = {"command": None}
    result = action_module.run()
    assert type(result) == TaskResult, 'test failed'

    # test for exception when command is empty
    action_module._task.args = {"command": ""}
    result = action_module.run()
    assert type(result) == TaskResult, 'test failed'

    # test for exception when command is string
    action_

# Generated at 2022-06-21 03:04:02.003799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test

# Generated at 2022-06-21 03:04:18.110789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 03:04:22.718110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action_plugin
    expected = 'some result'
    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            tmp = expected
            return tmp
    action_plugin.ActionModule = ActionModule
    assert action_plugin.ActionModule.run(object, tmp=None, task_vars=None) == expected

# Generated at 2022-06-21 03:04:23.439608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Generated at 2022-06-21 03:04:25.828220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor")
    action_module = ActionModule()
    # assert isinstance(action_module, ActionModule)
    assert action_module is not None

# Generated at 2022-06-21 03:04:26.724184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:04:27.648980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()
    assert act is not None

# Generated at 2022-06-21 03:04:32.826989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        assert am.__class__.__name__ == 'ActionModule'
    except AssertionError:
        print('Error: ActionModule did not return the expected class')


# Generated at 2022-06-21 03:04:36.241593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(add_plugin_dir)
    list_modules = action_module.run()
    assert len(list_modules) == 1
    assert action_module.run()[0]['name'] == 'nose'

# Generated at 2022-06-21 03:04:43.588864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# get the command that is trying to execute.
    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                   task=self._task,
                                                                   connection=self._connection,
                                                                   play_context=self._play_context,
                                                                   loader=self._loader,
                                                                   templar=self._templar,
                                                                   shared_loader_obj=self._shared_loader_obj)
    # run the command
    result = command_action.run(task_vars=task_vars)
    assert result
    return result

# Generated at 2022-06-21 03:04:52.712161
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:05:38.463563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the parameters that will be passed to the run method of
    # class ActionModule
    tmp = None
    task_vars = [ {'some_var': 'foobar'} ]

    # Initialize the class ActionModule
    action_module = ActionModule()

    # Call the method run of class ActionModule passing the proper
    # parameters
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    # Assert the result of calling the method run of class ActionModule
    # is not null
    assert(result is not None)

# Generated at 2022-06-21 03:05:46.718789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hosts_str = """
    [group1]
    host1 ansible_ssh_host=10.244.0.3 ansible_ssh_user='root' ansible_ssh_pass='pass'
    host2 ansible_ssh_host=10.244.0.4 ansible_ssh_user='root' ansible_ssh_pass='pass'
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()


# Generated at 2022-06-21 03:05:57.649034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialization of an object of class ActionModule for testing:
    task = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = object()
    myactionmodule = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    
    # initialization of the inputs:
    # None
    
    # initialization of the corresponding outputs with None
    tmp = None
    task_vars = None
    
    # call the method
    result = myactionmodule.run(tmp=tmp,task_vars=task_vars)
    
    # check the obtained result

# Generated at 2022-06-21 03:06:04.572473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #  case when tmp is not used
    #  case when task_vars is not used
    def my_run(command_action):
        command_action.run()

    #  case when tmp is used
    #  case when task_vars is used
    def my_run(command_action):
        command_action.run('tmp')

    #  case when tmp is used
    #  case when task_vars is used
    def my_run(command_action):
        command_action.run('tmp', 'task_vars')

    #  case when tmp is used
    #  case when task_vars is used
    def my_run(command_action, tmp, task_vars):
        command_action.run(tmp, task_vars)

    #  case when tmp is used
    #  case

# Generated at 2022-06-21 03:06:14.287743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    class ActionModule(ActionBase):

        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Shell module is implemented via command with a special arg
            self._task.args['_uses_shell'] = True

            command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                       task=self._task,
                                                                       connection=self._connection,
                                                                       play_context=self._play_context,
                                                                       loader=self._loader,
                                                                       templar=self._templar,
                                                                       shared_loader_obj=self._shared_loader_obj)

# Generated at 2022-06-21 03:06:16.057027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''ActionModule.__init__()'''



# Generated at 2022-06-21 03:06:17.894083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test #1')
    action = ActionModule()
    print(action)
    

# Generated at 2022-06-21 03:06:18.652962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:06:28.815068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize parameters
    my_obj = dict()
    my_obj['task'] = dict()
    my_obj['task']['args'] = dict()
    my_obj['task']['args']['_uses_shell'] = True
    my_obj['_shared_loader_obj'] = dict()
    my_obj['_shared_loader_obj']['action_loader'] = dict()
    my_obj['_shared_loader_obj']['action_loader']['get'] = dict()
    my_obj['_shared_loader_obj']['action_loader']['get']['return_value'] = dict()
    my_obj['_shared_loader_obj']['action_loader']['get']['return_value']['run'] = dict()

# Generated at 2022-06-21 03:06:31.153761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = ActionModule(None, None, None, None, None)
    assert b, "Object is null"
    assert isinstance(b, ActionModule), "Need a ActionModule class"

# Generated at 2022-06-21 03:08:01.483703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # @TODO: Implement
  pass

# Generated at 2022-06-21 03:08:03.570355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run(tmp='hello')

# Generated at 2022-06-21 03:08:10.170904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

    del ActionBase

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class AnsibleExitJson(Exception):
        def __init__(self, value):
            super(AnsibleExitJson, self).__init__()
            self.ob = value
        def __str__(self):
            return str(self.ob)
        __repr__ = __str__

    class AnsibleFailJson(Exception):
        def __init__(self, value):
            super(AnsibleFailJson, self).__init__()
            self.ob = value
        def __str__(self):
            return str(self.ob)
        __repr__ = __str__


# Generated at 2022-06-21 03:08:14.769557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = {'args': {'_uses_shell': False}}
    module._shared_loader_obj = {'action_loader': {'get': ActionModule_get}}
    result = module.run(None, None)

    assert result['rc'] == 0

# Stub for method get of class ActionModule

# Generated at 2022-06-21 03:08:15.945567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-21 03:08:16.726725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.run()

# Generated at 2022-06-21 03:08:24.822465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __builtin__
    from ansible.compat.tests.mock import patch, MagicMock

    action_module = ActionModule(
        task=MagicMock(),
        connection=MagicMock(),
        play_context=MagicMock(),
        loader=MagicMock(),
        templar=MagicMock(),
        shared_loader_obj=MagicMock())

    assert action_module.run(tmp=MagicMock(), task_vars=MagicMock()) == \
        action_module._shared_loader_obj.action_loader.get.return_value.run.return_value


# Generated at 2022-06-21 03:08:27.266615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We may have to have a mock class for ActionBase to implement this test
    # Unit tests for other action classes will be added in coming days
    pass

# Generated at 2022-06-21 03:08:34.953502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import constants as C

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import StringIO
    if PY3:
        import io
        StringIO = io.StringIO

    # In Python 3 ActionBase and ActionModule are defined in the same file but import the
    # latter from the former and that's what makes it possible to pickle an instance of
    # ActionBase. In Python 2 things are split among several files but have the same
    # structure, so we can pickle an instance of ActionModule.
    ActionModuleInstance = ActionModule
    if not PY3:
        from ansible.plugins.action.ActionModule import ActionModule as ActionModuleInstance

    fake_loader, fake_

# Generated at 2022-06-21 03:08:44.375388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Response(object):
        pass

    # 1. Mock _task
    class MockTask(object):
        def __init__(self):
            self.args = {
                '_uses_shell': True
            }

    _task = MockTask()

    # 2. Mock _connection
    _connection = None

    # 3. Mock _play_context
    _play_context = None

    # 4. Mock _loader
    _loader = None

    # 5. Mock _templar
    _templar = None

    # 6. Mock _shared_loader_obj
    class MockSharedLoaderObj(object):
        def __init__(self):
            self.action_loader = MockActionLoader()

    class MockActionLoader(object):
        def __init__(self):
            self.get_result = Response()

       