

# Generated at 2022-06-11 12:39:11.882991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init ActionModule
    a = ActionModule()

    # Init dictionary task_vars
    task_vars = {}

    # Assert run with tmp=None and task_vars={}
    assert a.run(tmp=None, task_vars=task_vars) == 1, "ActionModule run should return 1."

# Generated at 2022-06-11 12:39:12.404062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:21.383077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell

    # Expected call: ansible.plugins.action.command.ActionModule.run(tmp=None, task_vars=None)
    # AnsibleConfig will trigger a call to get_config to determine the config object
    # This would be in the __init__ of the class, but we are bypassing __init__ for this test
    mock_config = MagicMock()
    mock_config.get_config.return_value = '/some/path/ansible.cfg'
    with patch('ansible.plugins.action.command.AnsibleConfig', mock_config):
        # AnsibleConfig.get_config needs to return a configured config object
        # This would be in the __init__ of the class, but we are bypassing __init__ for this test
        mock_config.return_value = mock_

# Generated at 2022-06-11 12:39:21.959471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:23.920120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Guessing that nothing is going to be going on in a unit test
    # Here it is, a test that does nothing.
    pass

# Generated at 2022-06-11 12:39:24.471802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:33.725278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.action.raw import ActionModule
    from ansible.plugins.action.command import ActionModule as ActionCommandModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    class AnsiblePlaybookRun(object):
        def __init__(self):
            self.task_vars = dict()
            self.RESULT = Sentinel()
    class AnsiblePlaybook(object):
        def __init__(self):
            self.run = AnsiblePlaybookRun()

# Generated at 2022-06-11 12:39:43.823725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Method to test the run method of ActionModule
    """

    module_args = {"shell": "echo helloworld", "executable": "/bin/bash"}
    action_obj = ActionModule()

    result = action_obj.run(task_vars=None, module_args=module_args)

# Generated at 2022-06-11 12:39:53.615203
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create real (not mocks) for the following objects:
    # LoaderModule, Task, ActionBase, PlayContext, ActionLoader, TaskResult
    # and store them in variables
    import ansible.plugins.loader as loader_m
    from ansible.cli.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task_include import TaskInclude
    loader = loader_m.LoaderModule()
    context = PlayContext()
    action = ActionBase()
    task = TaskInclude()
    connection_mock = MockConnection()

    # create a mock for module class defined above
    from ansible.plugins.action.shell import ActionModule
    mock_class = MockActionModule(loader, connection_mock, context, task)

    # create expected values for mocks (

# Generated at 2022-06-11 12:40:05.184539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = {'args':{}}
    action_module._task.args = {'_uses_shell': True}

    action_module._shared_loader_obj = None
    action_module._shared_loader_obj.action_loader = {'ansible.legacy.command':{}}
    action_module._shared_loader_obj.action_loader.ansible.legacy.command = {'run':{}}
    action_module._shared_loader_obj.action_loader.ansible.legacy.command.run = {'task_vars':{}}


# Generated at 2022-06-11 12:40:07.805275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:12.419803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ficticious action plugin that returns a fake result for testing purposes.
    result = {'test': 1}

    class FakeAction():
        def run(self, tmp=None, task_vars=None):
            return result

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert module.run() == result

# Generated at 2022-06-11 12:40:24.337302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    import json
    import os
    import shutil
    import tempfile
    import unittest

    class MockConnection(object):
        def __init__(self):
            self.transport = None

        def connect(self):
            return True

    class MockCommandAction(object):
        def __init__(self):
            self.result = namedtuple('Result', 'stdout_lines')
            self.result.stdout_lines = []

        def run(self, **kwargs):
            return self.result

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockTemplar(object):
        def __init__(self):
            self.template_data = None


# Generated at 2022-06-11 12:40:24.937206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:36.176172
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:40:37.810076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# unit test for method run of class Command

# Generated at 2022-06-11 12:40:39.181481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == None

# Generated at 2022-06-11 12:40:40.060336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    test_action = ActionModule()

    # Test run method
    assert test_action.run()

# Generated at 2022-06-11 12:40:46.838785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hosts, loaded_action_plugins, module_executor = test_ansible_module()

    # create an instance of the action plugin
    action_plugin_instance = ActionModule(
        task=get_task(),
        connection=get_connection(),
        play_context=get_play_context(),
        loader=get_loader(),
        templar=get_templar(),
        shared_loader_obj=get_shared_loader_obj()
    )

    assert action_plugin_instance._shared_loader_obj == get_shared_loader_obj()

    # create a 'mock' command action plugin
    command_action_plugin = MagicMock()

    # a mock expected result
    expected_result = dict(rc=0, stdout='test', stderr='test')

    # mock the run method of the command action plugin


# Generated at 2022-06-11 12:40:56.718453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import ansible.plugins.loader
    except ImportError:
        exit("Unable to import ansible.plugins.loader")

    try:
        import ansible.plugins.action
    except ImportError:
        exit("Unable to import ansible.plugins.action")

    try:
        import ansible.module_utils.six
    except ImportError:
        exit("Unable to import ansible.module_utils.six")

    try:
        from ansible.executor.task_result import TaskResult
    except ImportError:
        exit("Unable to import ansible.executor.task_result.TaskResult")


# Generated at 2022-06-11 12:41:01.412629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:41:04.607380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = None
    expected_result = None

    # No setup necessary for the module action plugin
    # Executes method run of the class action plugin
    # with the given params
    # Checks if the result of the method run
    # is the expected result
    assert result == expected_result

# Generated at 2022-06-11 12:41:05.199433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:09.212221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create context for test
    ansible_instance = AnsibleActionModule.AnsibleActionModule()
    # call method run of class ActionModule with pre-created context
    r = ansible_instance.run()
    # check result of method run
    assert r == {}
    return r


# Generated at 2022-06-11 12:41:18.683515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.command import ActionModule

    data = {'ansible_loop_var': 'item', 
            'ansible_ssh_host': '127.0.0.1',
            'ansible_ssh_port': '22',
            'ansible_ssh_user': 'root',
            'ansible_ssh_pass': '',
            'ansible_sudo_pass': '',
            'ansible_connection': 'local',
            'ansible_python_interpreter': '/usr/bin/python',
            'ansible_ssh_strict_host_key_checking': 'yes',
            'ansible_ssh_shell': '/bin/sh',
            'ansible_ssh_extra_args': '',
            'ansible_ssh_common_args': ''}


# Generated at 2022-06-11 12:41:21.572556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp="tmp_value", task_vars="task_vars_value")
    action_module._task.args['_uses_shell'] = True



# Generated at 2022-06-11 12:41:22.516742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:41:32.106424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = AnsibleMock()
    mock_task.args = {'_uses_shell': True}

    mock_loader = AnsibleMock()

    mock_connection = AnsibleMock()

    mock_play_context = AnsibleMock()

    mock_action_loader = AnsibleMock()
    mock_command_action = AnsibleMock()
    mock_action_loader.get.return_value = mock_command_action

    mock_command_result = AnsibleMock()
    mock_command_action.run.return_value = mock_command_result

    mock_module = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, AnsibleMock(), AnsibleMock())
    mock_module.run(None, None)

    assert mock_action_loader.get

# Generated at 2022-06-11 12:41:32.731093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:38.077030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_common_loader_obj = None
    fake_task = None
    fake_play_context = None
    fake_loader = None
    fake_templar = None
    fake_connection = None

    tmp_action_module = ActionModule(fake_common_loader_obj, fake_task, fake_connection, fake_play_context, fake_loader, fake_templar)
    assert tmp_action_module.run(tmp=None, task_vars=None) is None

# Generated at 2022-06-11 12:41:55.790008
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # unit test setting up Mock objects
    mock_loader = Mock()
    mock_loader_obj = Mock()
    mock_task = Mock()
    mock_task_args = dict(cmd=["echo", "Hello"])
    mock_task.args = mock_task_args
    mock_connection = Mock()
    mock_play_context = Mock()
    mock_templar = Mock()
    mock_loader_obj.action_loader = Mock()
    mock_command_action = Mock()
    mock_command_action.run = Mock()
    mock_loader_obj.action_loader.get = Mock(return_value=mock_command_action)

    # unit test for class ActionModule

# Generated at 2022-06-11 12:41:56.306463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # TODO

# Generated at 2022-06-11 12:41:58.159725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    assert(ActionModule.run(ActionModule(), task_vars=task_vars) == True)

# Generated at 2022-06-11 12:42:07.808997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # The default module_utils (default) path is hardcoded for unit testing.
    module_utils_path_default_tmp = os.path.abspath('./test/unit/module_utils')
    sys.path.insert(0, module_utils_path_default_tmp)

    #
    # The path for the module(s) to be executed is hardcoded for unit testing.
    module_path_tmp = os.path.abspath('./test/unit/library')
    sys.path.insert(1, module_path_tmp)

    #
    # The default library path is hardcoded for unit testing.
    library_path_default_tmp = os.path.abspath('./test/unit/library')
    sys.path.insert(2, library_path_default_tmp)

    #

# Generated at 2022-06-11 12:42:16.858614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action.shell import ActionModule
    import ansible.plugins.action.command

    class FakeAction(ansible.plugins.action.command.ActionModule):
        def run(self, task_vars):
            return {"failed": True}

    module = ActionModule({"_uses_shell": "True"}, {"connection": "", "play_context": "", "loader": "", "templar": ""}, shared_loader_obj="")
    module._shared_loader_obj.action_loader.get = lambda name: FakeAction()

    # Execute
    result = module.run(tmp="", task_vars={})

    # Verification
    assert result == {"failed": True}

# Generated at 2022-06-11 12:42:17.718166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

# Generated at 2022-06-11 12:42:24.267575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.append('.')
    sys.path.append('..')
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.module_utils._text import to_bytes
    tmp = 'tmp'
    task_vars = 'task_vars'

    # Create a new ActionModule object

# Generated at 2022-06-11 12:42:26.451216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(None, None)
    assert actionModule.run(tmp=None, task_vars=None) == None

# Generated at 2022-06-11 12:42:36.512018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a basic test, which checks the module ActionModule.
    It checks the function run, which returns a json object.
    """
    # Creating a mockup
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {
                'somekey': 'somevalue',
                'someotherkey': 'someothervalue'
            }

    # Creating an instance of the mockup
    test = MockActionModule()

    # Checking if running the function returns a json object, and if the object
    # is correct.
    assert test.run() == {
        'somekey': 'somevalue',
        'someotherkey': 'someothervalue'
    }

# Generated at 2022-06-11 12:42:46.094501
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initializing the test
    task = {'args': {'chdir': '/tmp', '_raw_params': 'ls', '_uses_shell': True}}
    tmp = '/tmp'
    task_vars = {}

    # Creating the action_module object
    action_module = ActionModule(task, tmp, task_vars)
    action_module._task = task
    action_module._tmp = tmp
    action_module._task_vars = task_vars
    action_module._connection = None
    action_module._play_context = {}
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None

    # Testing the run method
    result = action_module.run()

    assert result == 'ls'

# Generated at 2022-06-11 12:43:08.262693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    module = ActionModule()
    module._task = {}
    module._connection = None
    module._loader = None
    module._templar = None
    module._shared_loader_obj = None

    module._task.args = {'_raw_params': 'echo "Hello world"'}

    # When
    result = module.run(tmp=None, task_vars={})

    # Then
    assert result['stdout'] == 'Hello world\n'
    assert result['stdout_lines'] == ['Hello world']

# Generated at 2022-06-11 12:43:09.862664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ action_plugins/test_shell.py:test_ActionModule_run """
    pass


# Generated at 2022-06-11 12:43:12.939570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule()
    result = action_module.run(tmp, task_vars)
    print(result)

# Unit test
test_ActionModule_run()

# Generated at 2022-06-11 12:43:13.551403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:43:15.110602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("ActionModule run method is called.")

# Generated at 2022-06-11 12:43:20.403020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._shared_loader_obj = object()
    action_module._task = object()
    action_module._connection = object()
    action_module._play_context = object()
    action_module._loader = object()
    action_module._templar = object()

    result = action_module.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-11 12:43:29.099428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class MockTask(object):
        def __init__(self, *args, **kwargs):
            self._role_params = {
                'command': "rm -rf /",
            }
            self.args = {}

    class MockLoader(object):
        def __init__(self, *args, **kwargs):
            pass

    class MockPlayContext(object):
        def __init__(self, *args, **kwargs):
            self._path_adjustment_details = {}

    class MockCommand(object):
        def __init__(self, *args, **kwargs):
            self._connection = None
            self._task = MockTask

# Generated at 2022-06-11 12:43:40.515953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test that if '_uses_shell' is set, the result is returned as expected
    # (not changed and not cast to an integer)
    _, ActionModule = _make_mocks(
        _task_args={'_uses_shell': True},
        _command_action_result={'rc': False, 'stdout': 'stdout_text', 'stderr': 'stderr_text'},
    )
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=None)
    assert result == {'rc': False, 'stdout': 'stdout_text', 'stderr': 'stderr_text'}


# Unit tests for module ansible.

# Generated at 2022-06-11 12:43:51.872941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest

    # TODO: mock external module ansible.plugins.action.command
    # command is an external module, cannot be mocked by Mock
    # class can be tested if shell module is imported in another module
    # which can be mocked.
    #
    # because we cannot mock command module, test_result variable
    # is hardcoded to test whether the function return value is correct
    #

# Generated at 2022-06-11 12:44:00.701010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    import os
    import tempfile
    import pprint
    import copy

    # initialization
    temp_dir = tempfile.mkdtemp(prefix='ansible_test_ActionModule-')
    os.environ['HOME'] = temp_dir
    os.environ['ANSIBLE_CONFIG'] = temp_dir + 'test.cfg'
    temp_filename = temp_dir + 'test.cfg'
    with open(temp_filename, 'w') as temp_file:
        temp_file.write('')

    # create a basic temporary file
    temp_filename = temp_dir + 'test'
    with open(temp_filename, 'w') as temp_file:
        temp_file.write('test\n')

# Generated at 2022-06-11 12:44:46.225156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test code
    am = ActionModule()
    #test code


# Generated at 2022-06-11 12:44:53.738149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    import ansible.plugins.action.command
    from ansible.executor.task_result import TaskResult

    def action_loader_get_mock(plugin_name, *args, **kwargs):
        assert plugin_name == 'ansible.legacy.command'
        plugin = ansible.plugins.action.command.ActionModule()

        def run_mock(task_vars):
            assert task_vars == {'var': 1}
            return TaskResult()

        plugin.run = run_mock
        return plugin

    obj = ActionModule()
    obj.run = ActionBase.run.__get__(obj)

# Generated at 2022-06-11 12:44:56.328116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myargs = {'_uses_shell': True}
    mytask = {'id': 'test',
              'action': 'shell',
              'args': myargs}
    assert ActionModule.run(mytask)

# Generated at 2022-06-11 12:45:04.260805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    from ansible.plugins.action.shell import ActionModule

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection


    tempdir = tempfile.TemporaryDirectory()
    class MyVars:
        def __init__(self):
            self.omit = ['omitkey']
            self.ansible_check_mode = False
            self.ansible_internal_cache = tempdir.name
            self.ansible_test_test_key1 = 'test_test_value1'
            self.ansible_test_test_key2 = 'test_test_value2'
            self.no_log = 'nologmessage'



# Generated at 2022-06-11 12:45:04.834547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:13.450831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run()')

    # Arrange
    from ansible.plugins.action.shell import ActionModule
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class ActionModuleProxy:
        class _ansible_task_vars:
            class _ansible_connection:
                def __init__(self):
                    self.winrm = None
                    self.become_pass = None
                    self.get_option = None

        def __init__(self):
            self._ansible_task_vars = ActionModuleProxy._ansible_task_vars()

# Generated at 2022-06-11 12:45:21.492438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection = MagicMock()
    mock_play_context = MagicMock()
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    mock_shared_loader_obj = MagicMock()

    mock_task_loader = MagicMock()
    mock_task_loader.get.return_value = None
    mock_shared_loader_obj.task_loader = mock_task_loader

    # Create instance of class ActionModule
    action_module = ActionModule(
        task=MagicMock(),
        connection=mock_connection,
        play_context=mock_play_context,
        loader=mock_loader,
        templar=mock_templar,
        shared_loader_obj=mock_shared_loader_obj
    )

    # The run() method

# Generated at 2022-06-11 12:45:30.670706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    
    action = ActionModule()
    
    action._task.args = {'_uses_shell' : True}
    
    ansible_options = {}
    ansible_options['become'] = False
    ansible_options['become_method'] = None
    ansible_options['become_user'] = None
    ansible_options['diff'] = None
    ansible_options['forks'] = 100
    ansible_options['remote_user'] = None

    action._task.options = ansible_options
    
    action._task.vars = {'ansible_check_mode' : False}
    
    tmp = {}
    task_vars = {}


# Generated at 2022-06-11 12:45:39.928309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager

    this_module = sys.modules[__name__]
    module_utils = {
        'ansible.legacy.command': this_module,
    }
    mock_loader = mock.MagicMock()
    mock_loader.action_loader.get.return_value = this_module
    task = mock.MagicMock()
    task.args = {
        '_original_file': u'/usr/local/bin/ansible-playbook',
        '_uses_shell': True,
        '_raw_params': u'/bin/false',
    }
    connection = mock.MagicMock()
    play_context = mock.Magic

# Generated at 2022-06-11 12:45:49.070350
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ActionModule._task = Task()
    ActionModule._task.args = {'_uses_shell': True}

    action_command = ActionModule._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                       task=ActionModule._task,
                                                                       connection=ActionModule._connection,
                                                                       play_context=ActionModule._play_context,
                                                                       loader=ActionModule._loader,
                                                                       templar=ActionModule._templar,
                                                                       shared_loader_obj=ActionModule._shared_loader_obj)
    action_command.run = lambda *args, **kwargs: True
    assert ActionModule.run() == True

# Stub for class AnsibleAction

# Generated at 2022-06-11 12:47:30.321425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor import task_result
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 12:47:38.102013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Loader_module_mock:
        def __init__(self, path):
            self.path = path

        def get(self, plugin_name, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            return plugin_name

    class Task_module_mock:
        def __init__(self, action):
            self.action = action
            self.args = {}

    class ActionBase_module_mock:
        def __init__(self, task):
            self._task = task
            self._shared_loader_obj = Loader_module_mock(path=None)
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None


# Generated at 2022-06-11 12:47:47.187081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Basic unit test for method run of class ActionModule. 
    It mocks class AnsibleConnection and AnsibleActionModule
    """
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action import AnsibleActionModule
    from ansible.plugins.action import AnsibleConnection
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import ModuleLoader

    module_loader = ModuleLoader()

    import __builtin__
    __builtin__.__dict__['MODULES'] = module_loader
    __builtin__.__dict__['CONNECTION'] = AnsibleConnection()
    __builtin__.__dict__['ACTION'] = AnsibleActionModule()

    play_context = PlayContext()
    action_module = ActionModule(play_context, None)
   

# Generated at 2022-06-11 12:47:55.001464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule

    Test code for run method of class ActionModule

    :return:
    """
    #define testcase

# Generated at 2022-06-11 12:48:02.452729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext

    class AnsibleMock:
        class plugins:
            class action:
                class ActionBase:
                    def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
                        self._task = task
                        self._connection = connection
                        self._play_context = play_context
                        self._loader = loader
                        self._templar = templar
                        self._shared_loader_obj = shared_loader_obj

                    def run(self, tmp=None, task_vars=None):
                        pass

        class loader:
            class ansible_loader:
                def __init__(self):
                    pass


# Generated at 2022-06-11 12:48:03.094117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:48:03.703731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:48:04.599307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:48:13.540060
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock_loader_obj is a mock object for object ActionModule
    mock_loader_obj = mock.Mock()

    # mock_action_loader is a mock object for object ActionModule.action_loader
    mock_action_loader = mock.Mock()
    mock_action_loader.get.return_value = 'returned value of get'
    mock_loader_obj.action_loader = mock_action_loader

    # mock_task is a mock object for object ActionModule._task
    mock_task = mock.Mock()
    mock_task.args = {'_uses_shell': True}
    mock_loader_obj._task = mock_task

    # mock_command_action is a mock object for object ActionModule._connection
    mock_command_action = mock.Mock()
    mock_loader_obj._connection = mock_

# Generated at 2022-06-11 12:48:14.347940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()