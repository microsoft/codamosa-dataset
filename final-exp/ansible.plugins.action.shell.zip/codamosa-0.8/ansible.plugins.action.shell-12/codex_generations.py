

# Generated at 2022-06-11 12:39:22.425570
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MyActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj


# Generated at 2022-06-11 12:39:24.754806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    action = ansible.plugins.action.shell.ActionModule({}, {}, False, '/c/d')
    action.run(None, None)

# Generated at 2022-06-11 12:39:33.999152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from action_plugins.actions import ActionModule
    from ansible.utils.sentinel import Sentinel

    am = ActionModule()

    class MyActionBase(ActionBase):
        pass

    am._shared_loader_obj = MyActionBase()
    am._shared_loader_obj._action_loader = dict()
    t = dict(foo=1)
    am._task = t
    am._connection = Sentinel()
    am._play_context = Sentinel()
    am._loader = Sentinel()
    am._templar = Sentinel()

    am._shared_loader_obj._action_loader['ansible.legacy.command'] = MyActionBase()

# Generated at 2022-06-11 12:39:44.032985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = mock.mock_open(read_data='data')
    out = []
    m.return_value.__enter__ = lambda s: s
    m.return_value.__exit__ = lambda *exc: True

# Generated at 2022-06-11 12:39:50.620977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock of module ActionBase
    class MockActionBase(object):
        def run(self, tmp, task_vars):
            # Test the content of parameter task_vars
            assert task_vars == {'test': 123}
            pass

    # Call the method run of class ActionModule
    ActionModule(MockActionBase()).run(task_vars={'test': 123})

if __name__ == "__main__":
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-11 12:40:01.983291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    if sys.version_info[:2] == (2, 6):
        from unittest2 import TestCase, skipIf
    else:
        from unittest import TestCase, skipIf
    from nose.plugins.skip import Skip, SkipTest

    class fake_class(object):
        def __init__(self, *args, **kwargs):
            self.calls = []

        def __getattr__(self, name):
            def method(*args, **kwargs):
                self.calls.append('%s%r' % (name, args))
                return name
            return method

    class fake_module_loader(object):
        def __init__(self, *args, **kwargs):
            self.calls = []


# Generated at 2022-06-11 12:40:02.587597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:12.022204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from st2common.runners.base_action import Action
    action = Action()
    action.config = {}
    action.logger = mock.Mock()
    action.action_service = mock.Mock()
    action.action_service.get_by_ref.return_value = {'id': 'foo', 'name': 'shell'}
    action.runner_type = 'ansible-shell'
    action.entry_point = '/foo/bar'
    task = mock.Mock()
    connection = mock.Mock()
    play_context = mock.Mock()
    loader = mock.Mock()
    templar = mock.Mock()
    shared_loader_obj = mock.Mock()
    obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

# Generated at 2022-06-11 12:40:16.657587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    res = mod.run(tmp="test_tmp", task_vars={"test_vars": "test_vars"})
    assert res['failed'] == False
    assert mod._task.args['_uses_shell'] == True

# Generated at 2022-06-11 12:40:19.564932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    result = am.run(tmp=None, task_vars=None)
    assert result == None

# Generated at 2022-06-11 12:40:31.749939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Importing module to test
    from ansible.plugins.action import ActionModule

    # Instantiating module
    host_list = [
        [None, "foo@localhost"],
        ["'bar'", "bar@localhost"]
    ]
    task_list = [
        "org.foo.bar.Task1",
        "org.foo.Task2"
    ]
    task_vars = {
        "ansible_user": "foo",
        "ansible_host": "localhost"
    }
    module = ActionModule(host_list, task_list)

    # Call method run
    expected_result = {
        "key1": 1,
        "key2": 2
    }
    assert expected_result == module.run(None, task_vars)

# Generated at 2022-06-11 12:40:42.373320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    
    # Mock objects

# Generated at 2022-06-11 12:40:44.235812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    The test case is checking the run method of class ActionModule.
    '''
    actionmod = ActionModule()
    res = actionmod.run()
    assert res == None

# Generated at 2022-06-11 12:40:47.478621
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:40:50.097688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	data = 'test'
	action_module = ActionModule(data,data,data,data,data,data,data)
	assert action_module.run(data,data) == [data]

# Generated at 2022-06-11 12:40:50.682074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:00.865721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import BytesIO

    # Create a mock ansible.legacy.command.ActionModule

# Generated at 2022-06-11 12:41:10.028241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    
    item = dict(
        module='shell',
        exec_command='',
        exec_shell=None,
        remote_loc='',
        remote_cmd='',
        args='',
        when='',
        until='',
        creates='',
        removes='',
        chdir='',
        executable='',
        shell='',
        _uses_shell=True,
        _raw_params='',
        _uses_delegate_to=False,
        _environment=None,
        _bin_path=[]
    )
    play_context = PlayContext()

# Generated at 2022-06-11 12:41:19.519703
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:41:22.514514
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    # Instantiating an instance of class ActionModule
    action_module_instance = ActionModule()
    
    # Call method run of class ActionModule instance
    result = action_module_instance.run()
 
    assert result is not None

# Generated at 2022-06-11 12:41:26.743195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del ActionModule

# Generated at 2022-06-11 12:41:36.072006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import shutil
    import tempfile
    import types
    import unittest

    class InitTmpPath(unittest.TestCase):
        """Create temp path and initilize tmp dir
        """
        def setUp(self):
            self.temp_path = tempfile.mkdtemp()
            self.temp_dir = self.temp_path + "/tmp"
            os.mkdir(self.temp_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_path)

    class InitTestObject(InitTmpPath):
        def setUp(self):
            super(InitTestObject, self).setUp()

# Generated at 2022-06-11 12:41:39.068843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert type(result) is dict
    assert result.get('invocation').get('module_args').get('_uses_shell') is True

# Generated at 2022-06-11 12:41:49.878886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display

    module_loader = action_loader._create_loader()
    Task = namedtuple('Task', 'action args')
    Options = namedtuple('Options', 'connection remote_user')
    play_context = PlayContext()
    variable_manager = VariableManager()
    inventory = InventoryManager()
    task = Task('ansible.builtin.shell', dict(command='echo hello'))

    display = Display()


# Generated at 2022-06-11 12:41:58.420362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common.collections import ImmutableDict

    # Create a new _task object which can be used for unit testing.
    # The _task is created and initialized to None.
    _task = ImmutableDict(action='script', args={})

    # Create a new action module object and pass all the required parameters
    # which are initialized to None. Eventually they will be initialized with
    # the values defined in the context.
    action_module_obj = action_loader.get('script',task=None,
                                          connection=None,
                                          play_context=None,
                                          loader=None,
                                          templar=None,
                                          shared_loader_obj=None)


# Generated at 2022-06-11 12:42:04.337932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(loader=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    action._task.args = {'_uses_shell': True}
    action._shared_loader_obj.action_loader.get = MagicMock()
    action._shared_loader_obj.action_loader.get().run = MagicMock(return_value='result')

    assert action.run(tmp=None, task_vars=None) == 'result'

# Generated at 2022-06-11 12:42:15.068924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins import action_loader
    from task import Task
    from ansible.module_utils.facts import Facts
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 12:42:22.817409
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create instance of class ActionModule
    # Possibly your test class(es) should inherit from unittest.TestCase instead
    action_module_instance = ActionModule()

    # Prepare test input data for method run
    test_tmp = None
    test_task_vars = {"key1": "value1", "key2": "value2"}

    # Run method run of class ActionModule with prepared input data
    test_result = action_module_instance.run(test_tmp, test_task_vars)

    # Make assertions on output of method run
    assert len(test_result) == 3
    assert test_result["invocation"] == {'module_name': 'command', 'module_args': {'warn': True, '_uses_shell': True}, 'module_kwargs': {}}
    assert test_result["changed"] == False

# Generated at 2022-06-11 12:42:33.287410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  fake_tmp = "/tmp/ansible_shell_payload.sh.1326Ss1.sh"

# Generated at 2022-06-11 12:42:43.610946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    import sys
    sys.path.append(".")
    from ansible.utils.hashed_dynamic_vars import HashedDynamicVars
    from ansible.vars.manager import VariableManager

    class FakeTask(object):
        def __init__(self, args):
            self.args = args

    class FakeConnection(object):
        def __init__(self, task):
            self._task = task


# Generated at 2022-06-11 12:43:00.085500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # If a temporary directory must be used, the following line will create
    # one and return its name.
    tmp = '/tmp/ansible-tmp-1441589476.7-235511949570404'

    #copy argument task_vars from class PlayContext
    task_vars = dict()
    task_vars['ansible_check_mode'] = False
    task_vars['ansible_verbosity'] = 0
    task_vars['ansible_version'] = dict()
    task_vars['ansible_version']['full'] = '2.2.0.0'
    task_vars['ansible_version']['major'] = 2
    task_vars['ansible_version']['minor'] = 2

# Generated at 2022-06-11 12:43:00.895273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    ActionModule.run(params)

# Generated at 2022-06-11 12:43:09.719222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock options as argument for ansible.runner
    options = argparse.Namespace()
    options.listtags = False
    options.listtasks = False
    options.listhosts = False
    options.syntax = False
    options.connection = 'local'
    options.module_path = None
    options.forks = 5
    options.remote_user = 'root'
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = True
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.verbosity = None
    options.check = False
   

# Generated at 2022-06-11 12:43:10.713594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  """ Unit test for method run of class ActionModule """

# Generated at 2022-06-11 12:43:11.314373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:12.937820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tm = ActionModule()

    # This unit test doesn't pass because it requires a 'connection object' which is not available

# Generated at 2022-06-11 12:43:17.183317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, shared_loader_obj=None, connection=None, play_context=None,
                                 variable_manager=None, task=None)

    assert action_module.run(tmp=None, task_vars=None) == None



# Generated at 2022-06-11 12:43:19.482788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = ""
    task_vars = {}
    a = ActionModule(tmp, task_vars)

    assert a.run(tmp, task_vars) == ""

# Generated at 2022-06-11 12:43:28.373261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.plugins.action import ActionBase
  from ansible.plugins.action.shell import ActionModule
  from ansible.utils.sentinel import Sentinel
  import ansible.plugins.loader as plugin_loader
  from ansible.vars.manager import VariableManager
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible import context
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.play import Play
  import yaml
  from ansible.playbook.block import Block
  from ansible.playbook.task import Task
  import ansible.constants as C
  import ansible.cli.adhoc
  from ansible.inventory.manager import InventoryManager
 

# Generated at 2022-06-11 12:43:31.194817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n")
    # The first parameter is the class to be instantiated. The rest are
    # constructor parameters.
    obj = ActionModule(1, 2, 3, None, None)
    # Access a method of the object
    obj.run(4, 5)
    return

# Generated at 2022-06-11 12:43:56.322376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test without a task or shared loader obj, should fail
    with pytest.raises(ValueError) as excinfo:
        ActionModule(loader=DictDataLoader({}), connection=None, play_context=PlayContext(),
                     task_vars=dict(),
                     templar=None).run(task_vars=dict())
    assert 'missing required arguments' in str(excinfo.value)

    # Test with a task, shared loader obj and valid params, should succeed
    mock_shared_loader_obj = MagicMock()
    mock_task = MagicMock()
    mock_task.args = {}

# Generated at 2022-06-11 12:44:03.869766
# Unit test for method run of class ActionModule
def test_ActionModule_run():	
	import unittest.mock

	mock_task = unittest.mock.MagicMock()
	mock_connection = unittest.mock.MagicMock()
	mock_play_context = unittest.mock.MagicMock()
	mock_loader = unittest.mock.MagicMock()
	mock_templar = unittest.mock.MagicMock()
	mock_shared_loader_obj = unittest.mock.MagicMock()

	action_module = ActionModule(task=mock_task, connection=mock_connection, play_context=mock_play_context, loader=mock_loader, templar=mock_templar, shared_loader_obj=mock_shared_loader_obj)


# Generated at 2022-06-11 12:44:04.333810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:11.830679
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = {'debug': True}

    class Fake_Task:
        def __init__(self, args):
            self.args = args

    class Fake_Loader:
        def get(loader_get_name, task, connection, play_context, loader, templar, shared_loader_obj):
            if loader_get_name == 'ansible.legacy.command':
                return Fake_ActionBase()
            return None

    class Fake_ActionBase:
        def __init__(self):
            pass

        def run(self, tmp=None, task_vars=None):
            return task_vars

    fake_task = Fake_Task({'_uses_shell': True})
    fake_loader = Fake_Loader()

# Generated at 2022-06-11 12:44:19.363538
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:44:27.442194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run of class ActionModule.
    # Test case for action module command
    # Example:
    # | test_ActionModule_run |
    # Note: Please ensure that sample test case is not commented before running test.
    # This is a test comment.
    # Task:
    task = {'action': {'__ansible_module__': 'command', '__ansible_arguments__': 'ls -la'}}
    # Task Variables:
    task_vars = {'ansible_play_batch': ['test_play']}
    action_module = ActionModule()
    ans = action_module.run(task_vars=task_vars, task=task)
    # Check Point:
    # check if result is as expected

# Generated at 2022-06-11 12:44:27.943866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:44:28.417952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-11 12:44:29.738259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # no test at this moment because of using command module directly

# Generated at 2022-06-11 12:44:32.189039
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test1: Empty constructor of class ActionModule
    print('Test1')
    print(ActionModule().run())


# script execution entry point
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-11 12:45:13.731813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = {}
    module._play_context = {}
    module._connection = {}
    module._loader = {}
    module._shared_loader_obj = {}
    module._task.args = {}
    module._templar = {}
    module._task.args['_uses_shell'] = True
    class tmp:
        def get(self, action_name, task, connection, play_context, loader, templar, shared_loader_obj):
            return {}
    command_action = tmp()
    class res:
        def run(self, task_vars=None):
            return {}
    result = res()
    command_action.run = result.run
    module._loader.get = command_action.get
    module.run()

# Generated at 2022-06-11 12:45:21.772773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test instance of ActionModule
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    playbook = {
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {
                'name': 'test task',
                'shell': 'echo hello world',
                'register': 'test',
            }
        ]
    }

    loader, inventory, variable_manager = ActionBase._load_env(playbook)

    variable_manager.set_inventory(inventory)

    task = Task()
    task._role = None
    task.load(playbook['tasks'][0], loader=loader, variable_manager=variable_manager)



# Generated at 2022-06-11 12:45:26.571602
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.ansible.module_common import AnsibleModule

    mod = AnsibleModule()

    mod.run_command = lambda *args, **kwargs: 'echo "bar"'

    action_module = ActionModule(module_args={}, task=None, shared_loader_obj=mod)
    ret = action_module._execute_module()

    assert ret == {'msg': 'bar', 'rc': 0}



# Generated at 2022-06-11 12:45:36.273657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    TaskVars = {}
    TaskVars['ansible_job_id'] = 'job_id'
    TaskVars['ansible_check_mode'] = False
    TaskVars['ansible_no_log'] = False
    TaskVars['ansible_verbosity'] = 0


# Generated at 2022-06-11 12:45:41.323420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    action_module_obj._task = {"args": {"_raw_params": ""}}
    action_module_obj._connection = {}
    action_module_obj._play_context = {}
    action_module_obj._loader = {}
    action_module_obj._shared_loader_obj = {}
    action_module_obj._templar = {}
    result = action_module_obj.run()
    assert result

# Generated at 2022-06-11 12:45:51.386014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    class TestActionModule(unittest.TestCase):
        def test_case(self):
            import json

            TEST_OUTPUT = 'TEST_OUTPUT'
            TEST_OUTPUT_TO_COMM_RESULT = 'TEST_OUTPUT_TO_COMM_RESULT'
            TEST_TASK_VARS = 'TEST_TASK_VARS'
            TEST_TASK_VARS_RESULT = 'TEST_TASK_VARS_RESULT'
            TEST_TASK_VARS_TO_COMM_RESULT = 'TEST_TASK_VARS_TO_COMM_RESULT'
            TEST_COMM_RESULT = 'TEST_COMM_RESULT'
            TEST_COMM_RESULT_TO

# Generated at 2022-06-11 12:45:52.761264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run function of class ActionModule
    """
    module = ActionModule()

# Generated at 2022-06-11 12:45:57.672563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    m._task.args = {'_uses_shell': True}
    m._shared_loader_obj.action_loader.get.return_value.run.return_value = 'correct'
    assert m.run() == 'correct'

# Generated at 2022-06-11 12:46:07.726844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    class ActionModuleSubclass(ActionModule):
        pass

    class ActionBaseSubclass(ActionBase):
        TRANSFERS_FILES = False

        def run(self, tmp=None, task_vars=None):
            return super().run(tmp, task_vars)

    action_module = ActionModuleSubclass()

    action_base_subclass = ActionBaseSubclass()

    variable_manager = None
    loader = DataLoader()
    play_context = None
    connection = None
    variable_manager = None
    templ

# Generated at 2022-06-11 12:46:11.611890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()

    taskvars = dict()
    result["_task_args"] = dict()
    result["_task_args"]["_uses_shell"] = None
    taskvars["result"] = None
    taskvars["result"] = result

    assert result["_task_args"]["_uses_shell"] is not True

# Generated at 2022-06-11 12:47:45.228370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_get_method(object, method):
        return mock_method

    # Test direct run of ansible.legacy.shell:
    class TestActionModule_run():
        def __init__(self):
            self.args = {}
            self.task = {'args': self.args}
            self.connection = None
            self.play_context = None
            self.loader = None
            self.templar = None
            self.shared_loader_obj = None
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect
            self.args['_uses_shell'] = True

# Generated at 2022-06-11 12:47:53.578307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import json


# Generated at 2022-06-11 12:48:00.776356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define module parameters
    params = {}
    # Define task parameters
    args = {}
    args['_uses_shell'] = True

    # Mock task
    task = MockTask()
    task._task = MockTask_params()
    task._task.args = args

    # Mock task_vars
    task_vars = {}

    # Create action object
    action = ActionModule(task, {})
    # Mock _loader, config_data and connection
    action._loader = MockLoader()
    action._connection = MockConnection()
    action._shared_loader_obj = MockClass()
    action._shared_loader_obj.action_loader = MockClass()
    # Mock shell module class
    action._shared_loader_obj.action_loader.get = MockClass()

# Generated at 2022-06-11 12:48:01.689748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:48:10.509049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Test run returns back the same result as wrapped command module. In case of
    # using dynamic inventory script this is a hostvars.
    #
    # This method is more a integration test than a unit test.
    #
    from ansible.plugins.action.shell import ActionModule

    hostvars = {'some_key': 'some_value'}

    class MockCommandAction(object):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj


# Generated at 2022-06-11 12:48:16.630513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    t = Task()
    t._role = None
    t.args = {'_uses_shell':True}

    m = ActionModule(t, None, None, None, None, None)
    assert m.run()['changed'] == False



# Generated at 2022-06-11 12:48:17.115341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:48:18.175217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert type(action) == ActionModule

# Generated at 2022-06-11 12:48:19.134889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()



# Generated at 2022-06-11 12:48:25.198998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(action=dict(module='test_module', args=dict(test='test'))),
        connection=dict(host='host'),
        play_context=dict(remote_addr='remote_addr'),
        loader=object(),
        templar=object(),
        shared_loader_obj=object()
    )

    try:
        module.run()
    except AttributeError as error:
        assert error.message == "ActionModule instance has no attribute '_task'"
    except TypeError as error:
        assert error.message == "'ActionModule' object is not callable"