

# Generated at 2022-06-11 12:39:13.742813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with invalid parameters
    task_vars = dict()
    action = ActionModule(loader=None,
                          templar=None,
                          shared_loader_obj=None,
                          connection=None,
                          play_context=None,
                          task=dict())
    result = action.run(tmp=None, task_vars=task_vars)
    assert result == dict()

# Generated at 2022-06-11 12:39:23.133806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_run(tmp=None, task_vars=None):
        del tmp
        return task_vars

    mock_args = {'_uses_shell': True}

    action_module = ActionModule()
    action_module._connection = None
    action_module._task = mock(ActionBase._task)
    action_module._task.args = mock_args
    action_module._task.deprecated_args = None
    action_module._task.action = 'command'
    action_module._task.async_val = None
    action_module._task.async_days = None
    action_module._task.async_hours = None
    action_module._task.async_last_poll = None
    action_module._task.async_poll_interval = None

# Generated at 2022-06-11 12:39:32.399355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    import ansible.config.manager
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.template
    import ansible.vars.manager

    class MyActionBase(ActionBase):
        def get_connection(self, task_vars, play_context): pass
        def load_attr_from_file(self, attr_path, task_vars=None): pass

    config = ansible.config.manager.ConfigManager()
    play_context = ansible.playbook.play_context.PlayContext(config=config, options=dict(user=1), passwords=dict(conn_pass=2))
    mytask = ansible.playbook.task.Task()


# Generated at 2022-06-11 12:39:33.313884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run_ActionModule_run()['rc'] == 0

# Generated at 2022-06-11 12:39:43.407039
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Note that this test does not check whether the command_action will be called
    # with the correct arguments.

    # Test 1:
    # Test ActionModule.run() with a non-boolean value for 'changed'.
    _task = FakeTask()
    _connection = FakeConnection()
    _play_context = FakePlayContext()
    _loader = FakeLoader()
    _templar = FakeTemplar()
    _shared_loader_obj = FakeSharedLoaderObj()

    _command_action = FakeActionModule()
    _shared_loader_obj.action_loader = {'ansible.legacy.command': _command_action}

    _action_module = ActionModule(_task, _connection, _play_context, _loader, _templar, _shared_loader_obj)


# Generated at 2022-06-11 12:39:53.019762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_args=None):
            del task_args # task_args no longer has any effect

            _uses_shell = self._task.args['_uses_shell']
            return {'stdout': _uses_shell, 'stderr': '', 'rc': 0, 'start': '',
                    'end': '', 'delta': '', 'msg': '', 'invocation': {},
                    'stdout_lines': [_uses_shell]}

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(MockActionBase, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._task = task


# Generated at 2022-06-11 12:39:53.662413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:56.171145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run(tmp=None, task_vars=None)
    """
    for test in [1, 2, 3]:
        print(test)

# Generated at 2022-06-11 12:40:02.689852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize action module
    action = ActionModule(
        {'ansible_loop_var': 'inventory_hostname',
        'ansible_ssh_host': '1.2.3.4'},
        loaders=[],
        templar=None,
        shared_loader_obj={})

    # Call run
    result = action.run(tmp='', task_vars=None)
    assert result == []

# Generated at 2022-06-11 12:40:12.134551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    from ansible.executor.task_result import TaskResult

    class ConnectionMock():
        class ConnectionError(errors.AnsibleError):
            pass

    host_name = "test_host"
    task_name = "test_task"
    args = {u'_uses_shell': True}
    action_name = "test_action"
    connections = ConnectionMock()
    module_name = "ansible.legacy.command"

    class LoaderMock():
        def get(self, name, *args, **kwargs):
            if name == module_name:
                module = ModuleMock()
                module.run = run
                return module
            else:
                return None

    class TaskMock():
        def __init__(self):
            self.args = args
           

# Generated at 2022-06-11 12:40:15.663107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    pass

# Generated at 2022-06-11 12:40:17.832930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # input is dict of dicts
    # task_vars is dict
    # output is dict of dicts
    
    return

# Generated at 2022-06-11 12:40:29.302902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_action = {}

# Generated at 2022-06-11 12:40:33.429884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  """Unit test for method run of class ActionModule."""
  # It is not possible to instantiate a class with a constructor
  # that has arguments with default values. It is necessary to have
  # a no argument constructor for the instantiation.
  assert False



# Generated at 2022-06-11 12:40:43.527813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    any_string = "any string"
    any_int = 1
    any_dict = dict()
    any_dict['any_key'] = any_string
    any_dict['any_int'] = any_int

    any_tmp = "any tmp"
    any_task_vars = dict()
    any_task_vars['any_vars'] = any_string

    # Return values for mocked function
    mock_values = dict()
    mock_values['get_action_loader_get_command'] = "any command"

    class MockConnection(object):
        def __init__(self):
            pass

    class MockTemplar(object):
        def __init__(self):
            pass

    class MockLoader(object):
        def __init__(self):
            pass


# Generated at 2022-06-11 12:40:43.999946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:53.289326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    import ansible.constants
    import os
    import json

    display = Display()
    options = dict()
    options['connection'] = 'ssh'

# Generated at 2022-06-11 12:40:53.824183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:56.189335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Test with no arguments
    a = ActionModule()
    assert_raises(TypeError, a.run)



# Generated at 2022-06-11 12:40:56.766712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:41:09.825950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test ActionModule.run'''

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import ACTION_ALL
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager

    import __main__
    import ansible.constants
    import ansible.plugins.loader
    import ansible.plugins.connection.ssh
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.systemd
    import ansible.plugins.action.setup
    import ans

# Generated at 2022-06-11 12:41:10.357488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:19.838253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def runner(tmp=None, task_vars=None):
        _task_vars = {'ansible_python_interpreter': '/path/to/python'}
        if task_vars:
            _task_vars.update(task_vars)

        _shared_loader_obj = Mock()
        _task = Mock()
        _connection = Mock()
        _play_context = Mock()
        _loader = Mock()
        _templar = Mock()

        # Make a ActionModule instance
        am = ActionModule(_shared_loader_obj, _task, _connection, _play_context, _loader, _templar)

        # Make the run of the ActionModule instance
        result = am.run(tmp, _task_vars)

        # Return the result
        return result

    # Test with command "

# Generated at 2022-06-11 12:41:26.614570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.shell'
    class_name = 'ActionModule'
    expected_result = {}
    action_module = ActionModule(loader=None, shared_loader_obj=None, templar=None, config=None)

    result = action_module.run(tmp=None, task_vars=expected_result)

    assert result == expected_result, "%s.%s() failed, expected result: '%s', got result: '%s'" % \
                                       (module_name, class_name, expected_result, result)

# Generated at 2022-06-11 12:41:27.535557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test here
    pass

# Generated at 2022-06-11 12:41:36.846001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.processors import popen_facts
    from ansible_collections.notstdlib.moveitallout.plugins.modules.shell import ActionModule
    from ansible.playbook import Play, PlayContext, Task
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader
    import os
    import sys
    import copy
    import tempfile
    import json

    if sys.version_info[0] < 2 or (sys.version_info[0] == 2 and sys.version_info[1] < 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

# Generated at 2022-06-11 12:41:47.485337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_task = '''
    name: [no-change]
    command: ls
    '''
    tmp_context = {}
    tmp_loader = '''
    command: ls
    '''
    task = {}
    task['name'] = 'test_task_name'
    task['args'] = {}
    task['args']['_uses_shell'] =  True
    task_vars = {}
    connection = {}
    play_context = {}
    loader = {}
    shared_loader_obj = {}
    shared_loader_obj['action_loader'] = {}
    shared_loader_obj['action_loader'] = ActionBase()
    shared_loader_obj['action_loader']._shared_loader_obj = shared_loader_obj
    
    # Test for normal execution
    action = ActionModule()
   

# Generated at 2022-06-11 12:41:53.963587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object of class ActionModule
    obj = ActionModule()

    # define the arguments of method run
    tmp = None
    task_vars = {'hostvars': {'host': {'ansible_ssh_host': '192.168.0.3'}}}

    # call method run with arguments
    result = obj.run(tmp, task_vars)

    # assert the return value
    assert result['invocation']['module_args']['_raw_params'] == 'ls -l /home'

# Generated at 2022-06-11 12:42:00.991503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_inventory_file
    from ansible.utils.vars import load_extra_vars_

# Generated at 2022-06-11 12:42:11.671937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action import Command
    import ansible.plugins.action
    import ansible.plugins
    import ansible.vars
   
    ansible.plugins.action.ActionBase = ActionBase
    
    
    
    
    test_task_vars = {"some_key": "some_value", "some_other_key": "some_other_value"}
    test_task_vars["var"] = 'value'
    test_task_vars["var2"] = 'value2'
    test_task_vars['ansible_facts'] = {}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-11 12:42:28.366348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli import CLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars
    from io import StringIO
    import yaml
    import json
    import os

    loader = DataLoader()
    variable_

# Generated at 2022-06-11 12:42:30.919792
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    module._task.args = {'_uses_shell':True}

# Generated at 2022-06-11 12:42:37.980566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an action module
    am = ActionModule()

    # Create a task with arguments
    task_args = {}

    # Mock the AnsibleModule class
    actual_ansible_module_class = am._shared_loader_obj.action_loader.actual_ansible_module_class
    with mock.patch.object(actual_ansible_module_class, 'run') as mock_run:
        am.run(tmp=None, task_vars=None)
        mock_run.assert_called_once_with()

# Generated at 2022-06-11 12:42:47.216402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as ans_plugin_loader
    import ansible.plugins.action as ans_plugin_action

    # Set up module arguments.
    args = dict()
    args['_uses_shell'] = True

    # Set up connection
    connection = ans_plugin_loader.ConnectionLoader().get('local', None, {}, None)

    # Set up task_vars.
    task_vars = dict()
    task_vars['a'] = 'b'

    # Set up task
    task = ans_plugin_action.Task()
    task._connection = connection
    task.args = args

    # Set up shared loader object
    shared_loader_obj = ans_plugin_loader.ModuleLoader()

    # Set up action module.

# Generated at 2022-06-11 12:42:47.668788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:42:48.997155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    test_instance = ActionModule()
    assert test_instance is not None

# Generated at 2022-06-11 12:42:58.458587
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # tmp no longer has any effect
    tmp = 'test'
    task_vars = {}

    # Build a mock ansible.legacy.command.ActionModule object
    class ActionModule_Mock:
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Shell module is implemented via command with a special arg
            self._task.args['_uses_shell'] = True

# Generated at 2022-06-11 12:43:06.977983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import shared_loader_obj
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    task_vars = dict(foo='bar')
    play_context = PlayContext()
    new_stdin = dict()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=task_vars)
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources=[]))

# Generated at 2022-06-11 12:43:11.109126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(args=dict(_uses_shell=None)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    module.run(tmp=None, task_vars=dict())

# Generated at 2022-06-11 12:43:11.711914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:28.267614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:33.686489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.connection import ConnectionBase
    # Mock Module management as a class
    class ActionPluginsActionModuleUnits(ActionBase):
        def __init__(self):
            self._shared_loader_obj = None
            self._connection = None
            self._task = None
            self._play_context = None
            self._loader = None
            self._templar = None
    # Mock Module management as a class
    class ActionPluginsActionBaseUnits(object):
        def __init__(self):
            self.action_loader = None
    # Mock Module management as a class
    class ActionPluginsCommandUnits(ActionBase):
        def __init__(self):
            self._shared_loader_obj = None
            self._connection = None
            self._task

# Generated at 2022-06-11 12:43:44.052661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:43:55.350096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = Mock()
    mock_task.args = {}
    mock_task.args['_uses_shell'] = True

    mock_connection = Mock()
    mock_play_context = Mock()
    mock_loader = Mock()
    mock_templar = Mock()
    mock_shared_loader_obj = Mock()
    mock_action_loader = Mock()

    mock_command_action = Mock()
    mock_action_loader.get.return_value = mock_command_action

    mock_shared_loader_obj.action_loader = mock_action_loader

    mock_command_action.run.return_value = "Successful test run"

    action_module = ActionModule()
    action_module._task = mock_task
    action_module._connection = mock_connection
    action_module._play_context = mock

# Generated at 2022-06-11 12:44:01.782375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager

    mock_task = dict(action=dict(module='shell', args='echo hello world'))

    mock_task_vars = dict(ansible_user='default', ansible_password='default', ansible_port='default')

    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write("""
    - hosts: localhost
      tasks:
        - name: Ansible Task 1
          shell: echo hello world
    """)
    tmpfile.flush()

    mock_inventory = dict()

    mock

# Generated at 2022-06-11 12:44:09.070773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(
        _raw_params = 'echo this is a test',
    )
    _task = dict(
        args = task_args
    )

    at = ActionModule()
    at.templar = 'templar'
    at.loader = 'loader'
    at.connection = 'connection'
    at.play_context = 'play_context'
    at.shared_loader_obj = 'shared_loader_obj'
    at._task = _task

    com = mock.MagicMock()
    com.run = mock.Mock(return_value=0)

    al = mock.MagicMock()
    al.get = mock.Mock(return_value=com)
    at._shared_loader_obj.action_loader = al


# Generated at 2022-06-11 12:44:12.320856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for ActionModule.run method"""

    action = ActionModule(None, None, None, None, None, None, None)
    action._shared_loader_obj.action_loader.get = fake_action_loader
    result = action.run(tmp=None, task_vars=None)
    assert result == 'fake_result'



# Generated at 2022-06-11 12:44:16.481117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	
	# Initialization of the test parameters
    tmp = None
    task_vars = None
    
    # Create the object for ActionModule
    action_module_obj = ActionModule.ActionModule()
    
    # Test the method run with parameters
    result = action_module_obj.run(tmp, task_vars)
    
    # Check the result of test
    assert result == 'result'

# Generated at 2022-06-11 12:44:24.324621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task args
    task_args = dict(
        _raw_params='ls -l',
        executable=None,
        _uses_shell=True,
        _raw_params_list=['ls', '-l']
    )

    # Task
    task_obj = dict(
        action='shell',
        args=task_args,
        loop=None,
        loop_args=None,
        loop_control=None,
        register=None,
        with_items=None,
        with_loop=None
    )

    # Ansible task object

# Generated at 2022-06-11 12:44:32.362744
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:45:07.815884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    assert False, "TODO"

# Generated at 2022-06-11 12:45:16.704789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Mock_task():
        def __init__(self):
            self.args = {'_uses_shell': False}

    class Mock_ActionBase():
        def __init__(self):
            self._task = Mock_task()
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    class Mock_action_loader():
        def get(self, url, task=None, connection=None, play_context=None, loader=None, templar=None,
                shared_loader_obj=None):
            mock_command_action = Mock_command_action()
            return mock_command_action


# Generated at 2022-06-11 12:45:19.266247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    try:
        action.run(None, None)
    except Exception:
        pass

# Generated at 2022-06-11 12:45:19.743159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:22.758769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The method run of class ActionModule should return result from command_action.run()
    # Input: when self._task.args is {'_raw_params': 'ls -l'}
    # Expected output: result from command_action.run()
    # TODO
    pass

# Generated at 2022-06-11 12:45:25.574494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No-op test: just make sure it doesn't blow up
    module = ActionModule(
        task=dict(
            args=dict(
                _raw_params='mycommand'
            )
        )
    )
    module.run()

# Generated at 2022-06-11 12:45:35.294213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock task
    task = mock.Mock()
    task.args = dict()
    task.args['_uses_shell'] = True
    task.args['_raw_params'] = '/bin/true'

    # Mock task vars
    task_vars = dict()
    task_vars['ansible_verbosity'] = 0

    # Mock loader
    loader = mock.Mock()
    loader.filter_loader.get.return_value.run.return_value = 'some_result'

    # Mock templar
    templar = mock.Mock()

    # Mock object of class SharedPluginLoader
    shared_plugin_loader_obj = mock.Mock()
    shared_plugin_loader_obj.action_loader = mock.Mock()

    # Mock object of class ActionBase

# Generated at 2022-06-11 12:45:41.328989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    self = ActionModule()

    class MockActionBase(object):

        class MockTask(object):
            args = {}

            def __init__(self):
                self.args['_uses_shell'] = False

        _task = MockTask()

        _play_context = {}
        _connection = {}
        _shared_loader_obj = {}
        _loader = {}
        _templar = {}

    self.__class__ = MockActionBase

    self.run()

    assert self._task.args['_uses_shell'] == True

# Generated at 2022-06-11 12:45:51.385792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  import sys
  from ansible.module_utils._text import to_bytes, to_text
  try:
    from ansible.module_utils.basic import _load_params
  except ImportError:
    from ansible.module_utils.basic import _load_params as load_params
  from ansible.vars.unsafe_proxy import AnsibleUnsafeText
  from ansible.module_utils.common._collections_compat import MutableMapping
  from ansible.parsing.vault import VaultLib
  from ansible.module_utils.six import string_types
  from ansible.module_utils.six.moves import shlex_quote
  import ansible.utils.module_docs as module_docs
  from ansible.utils.module_docs import get_docstring

# Generated at 2022-06-11 12:45:51.999308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:47:31.792290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Test data
    # First test
    test_data_one = [
        "ansible.legacy.command",
        "ansible.legacy.command",
        {
            "changed": False,
            "failed": False,
            "rc": 0,
            "stderr": "",
            "stdout": "ansible demo hello ansible"
        },
        "ansible.legacy.command",
        {
            "changed": False,
            "failed": False,
            "rc": 0,
            "stderr": "",
            "stdout": "ansible demo hello ansible"
        }
    ]

    # Second test

# Generated at 2022-06-11 12:47:39.780721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_module_args({
        'creates': '/tmp/foo',
        'executable': '/bin/sh',
        '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p', 'vfat'],
        '_raw_params': 'id',
        '_uses_shell': True,
        'removes': '/tmp/bar'
    })

    result = my_obj.run()

# Generated at 2022-06-11 12:47:43.134546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.run('/var/tmp', {'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-11 12:47:50.025186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  test_task = 4
  test_connection = 5
  test_play_context = 6
  test_loader = 7
  test_templar = 8
  test_shared_loader_obj = 9
  test = ActionModule(test_task, test_connection, test_play_context, test_loader, test_templar,
                      test_shared_loader_obj)
  test_tmp = 10
  test_task_vars = 11
  test_result = (test.run(test_tmp, test_task_vars))
  assert test_result

# Generated at 2022-06-11 12:47:54.140116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(templar=None,shared_loader_obj=None)
    module._task.args = {'_uses_shell': True}
    module._shared_loader_obj.action_loader.get = Mock(return_value=Mock(run=Mock(return_value={'rc': 1})))
    assert module.run(None, None) == {'rc': 1}


# Generated at 2022-06-11 12:47:54.852071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test
    pass

# Generated at 2022-06-11 12:48:02.321211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule()
  task = {}
  task['args'] = {}
  task['args']['_uses_shell'] = True
  module._task = task
  module._play_context = {}
  module._play_context['shell'] = '/bin/sh'
  module._play_context['executable'] = None
  module._play_context['run_as'] = None
  module._play_context['run_as_user'] = None
  module._play_context['run_as_/bin/sh'] = None
  module._play_context['sudo'] = False
  module._play_context['sudo_user'] = None
  module._play_context['sudo_flag'] = '-S'
  module._play_context['become'] = False

# Generated at 2022-06-11 12:48:03.448808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement
    pass

# Generated at 2022-06-11 12:48:04.674715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    pass

# Generated at 2022-06-11 12:48:09.213369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(connection=FakeConnection(), 
        play_context=FakePlayContext(), 
        loader=None, 
        templar=None, 
        shared_loader_obj=FakeSharedLoaderObj())
    result = module.run(task_vars={"a": 1, "b": 2})
    assert result == {"result": {"a": 1, "b": 2}}
