

# Generated at 2022-06-11 12:39:15.384667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    import json
    assert True

    # created tests for inputs:
    #tmp: None
    #task_vars: None

# Generated at 2022-06-11 12:39:16.154754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:19.602222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(action=dict(module_name='shell'))
    module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module.run()

# Generated at 2022-06-11 12:39:29.097164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.plugins
    c = ansible.plugins.action.ActionModule(
        namedtuple('Connection', 'host port remote_user'),
        PlayContext()
    )
    task = Task()
    task.hosts = "localhost"
    task.connection = namedtuple('Connection', 'host port remote_user')(None, None, None)
    task.action = 'shell'

# Generated at 2022-06-11 12:39:37.937104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._task = AnsibleModuleMock()
    m._task.args = {'_raw_params': '*', '_uses_shell': True}
    m._task.action = 'ansible.legacy.shell'
    m._shared_loader_obj.action_loader.get = AnsibleCommandActionMock()
    m._connection = ConnectionMock()
    m._play_context = PlayContext()
    m._loader = DataLoader()
    m._templar = Templar()
    m._shared_loader_obj = AnsibleBase()
    result = m.run(task_vars={})
    assert result.get('rc') == 0


# Mocks

# Generated at 2022-06-11 12:39:47.329047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.plugins.action.action_base import add_to_task_vars
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action.shell import ActionModule
    from ansible.utils.task_docs import get_action_documentation

    def get_share_loader_obj(action_plugins=None, lookup_plugins=None, cache=None):
        return PluginLoader(action_plugins, lookup_plugins, cache)

    # TODO: Change this test to work with Ansible 2.x
    pytest.skip("Cannot test in Ansible 2.x, because the class ActionBase has been moved to a different file.")

# Generated at 2022-06-11 12:39:57.190366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.constants as C
    from ansible.module_utils.common.collections import ImmutableDict
    import yaml
    import pytest
    import sys

    # (c) 2017, Ansible Project
    # GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
    YAML_IN = """
- hosts: localhost
  gather_facts: no
  tasks:
  - name: >
      test gather_subset for multiple facts
    command: /bin/true
    """


# Generated at 2022-06-11 12:39:57.804535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:58.621969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:59.188203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:40:03.512322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    task = {'args': {'_uses_shell': True}}
    module._task = task
    module._shared_loader_obj = {'action_loader': {'get': lambda x, y: ActionModule}}
    module._loader = None

    result = module.run(None, None)

    assert result is None
    assert task == {'args': {'_uses_shell': True}}

# Generated at 2022-06-11 12:40:12.525596
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock return of run method of command_action
    # assign a return value to the mocked object
    command_action_mock_object = command_action_Mock()
    command_action_mock_object.run = MagicMock(return_value=copy.copy(command_action_mock_object.result))

    # mock return value of get method of action_loader
    def side_effect(*args, **kwargs):
        return command_action_mock_object
    action_loader_mock_object = action_loader_Mock()
    action_loader_mock_object.get = MagicMock(side_effect=side_effect)

    # mock return value of action_loader @ shared_loader_obj

# Generated at 2022-06-11 12:40:24.435423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # Redefined method run of class ActionModule
    def run(self, tmp=None, task_vars=None):
        return dict(ok=True)

    # Redefined method _run_task of class ActionModule
    def _run_task(self, task_vars=None):
        return dict(ok=True)

    # Redefined method _execute_module of class ActionBase
    def _execute_module(self, task_vars=None):
        return dict(ok=True)

    # Redefined method _load_params of class ActionBase
    def _load_params(self):
        return dict(ok=True)

    # Create an object of class ActionModule
    # Need to import class ActionBase
    from ansible.plugins.action import ActionBase
    action

# Generated at 2022-06-11 12:40:25.444716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ShellModule = ActionModule()
    assert True

# Generated at 2022-06-11 12:40:26.052432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-11 12:40:32.295343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.removed import removed
    removed('This is for test purpose')

    # Task has been removed in Ansible 2, so just pass None here
    action_module = ActionModule(None, None, None, None, None, None)
    assert {'skipped': True, 'skipped_reason': 'pdb(1) invoked for debug'} == action_module.run()

# Generated at 2022-06-11 12:40:42.695657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    import ansible.plugins
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic
    import sys
    import os
    import __main__ as main
    import unittest
    import yaml
    import inspect
    import doctest


# Generated at 2022-06-11 12:40:51.336600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n\nTest: run() of class ActionModule\n")
    # create instance of class ActionModule
    action_module =  ActionModule()
    task = object()
    loader = object()
    play_context = object()
    shared_loader_obj = object()
    connection = object()
    templar = object()

    # create instance of class ActionBase
    command_action =  ActionModule()

    # initialize private variables
    action_module._task = task
    action_module._shared_loader_obj = shared_loader_obj
    action_module._connection = connection
    action_module._play_context = play_context
    action_module._loader = loader
    action_module._templar = templar
    print("\n\nTest: run() passed\n")

# Generated at 2022-06-11 12:40:52.838699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule_run")
    assert True == True

# Generated at 2022-06-11 12:41:02.842713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Pass """
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import test_loader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    import mock
    import ansible.constants as C
    import ansible.plugins.action.shell as shell


# Generated at 2022-06-11 12:41:06.989686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:14.844151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sc = {}
    sc['shell'] = "echo hello"
    sc['key'] = {'changed': False, 'rc': 0, 'stderr': '', 'stdout': 'hello\n', 'stdout_lines': ['hello'], 'warnings': []}
    sc['l'] = [{'changed': False, 'rc': 0, 'stderr': '', 'stdout': 'hello\n', 'stdout_lines': ['hello'], 'warnings': []}]
    sc['t1'] = {'ansible_facts': {'shell_out': 'hello\n'}, 'changed': False, 'shell_out': 'hello\n', 'warnings': []}

# Generated at 2022-06-11 12:41:16.350935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionBase = ActionBase()
    actionModule = ActionModule()

# Generated at 2022-06-11 12:41:25.384527
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def create_dict_func(ignore_errors=None):
        return {'ignore_errors': ignore_errors}

    def create_string_func(cmd):
        return cmd

    class MockTask:

        def __init__(self, args, action):
            self.args = args
            self.action = action

    class MockActionLoader:

        def __init__(self, args, action_name, action):
            self.args = args
            self.action_name = action_name
            self.action = action

    class MockActionBase:

        def run(self, tmp=None, task_vars=None):
            return {'result': 'run'}

    def mock_get_action(action_loader, task):
        return action_loader.action


# Generated at 2022-06-11 12:41:34.887866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up the mock AnsibleRunner class used in the module to test the code
    class mock_AnsibleRunner():
        class Options():
            def __init__(self):
                self.connection = 'local'
                self.module_path = None
                self.forks = 5
                self.become = None
                self.become_method = None
                self.become_user = None
                self.check = False
                self.diff = False
        def __init__(self, hostfile=None, inventory=None, module_name=None, module_path=None, forks=None,
                     become=False, become_method=None, become_user=None, check=False, diff=False, verbosity=None):
            self.inventory = None
            self.become_user = None
            self.check = False

# Generated at 2022-06-11 12:41:38.914942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task_vars = dict()
    m_task = dict(action=dict(args=dict(_uses_shell=True)))

    action_module = ActionModule(m_task, dict(play_context=None, connection=None, loader=None, templar=None, shared_loader_obj=None))
    action_module.run(m_task_vars)
    assert 'ansible.legacy.command' == m_task['action']['dest']
    assert '_uses_shell' not in m_task['action']['args']

# Generated at 2022-06-11 12:41:48.917169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TemporaryPlugin(ActionModule):
        def run(self, result):
            super(TemporaryPlugin, self).run(result)

    class Connector():
        def __init__(self):
            self.run_command = lambda x: 0

    task = {'args': {}}
    templar = None
    play_context = None
    loader = None
    connection = Connector()
    shared_loader_obj = None

    plugin = TemporaryPlugin(templar, task, play_context, loader, connection, shared_loader_obj)
    result = templar.run(task, play_context, loader, connection)
    assert plugin.run(result)
    assert task['args'] == {'_uses_shell': True}

# Generated at 2022-06-11 12:41:53.884271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    # Create a class object of ActionModule
    action_module = ActionModule()

    # Test method run with tmp and task_vars as parameters
    # Test if method run actually returns a dictionary.
    assert isinstance(action_module.run(tmp="tmp cannot have any effect", task_vars="task_vars cannot have any effect"), dict)

# Generated at 2022-06-11 12:41:57.429443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    shell = 'cat /etc/centos-release'
    a = ActionModule()
    a._task.args['_raw_params'] = shell
    a._task.args['_uses_shell'] = False
    # Giving wrong task_vars i.e. None
    assert a.run(task_vars=None)['rc'] != 0

# Generated at 2022-06-11 12:42:06.610825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell as shell
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-11 12:42:14.713750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:18.044490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {
        '_uses_shell': True
    }
    action = ActionModule(task_args, None, None, None, None, None, None, None)

    action.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:42:22.950649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = None
    tmp = 'test'
    task_vars = {'ansible_version': {'full': '2.9.0'}}
    result = ActionModule(module_mock, tmp, task_vars).run(tmp, task_vars)
    assert result == {'command': '_uses_shell=True',
                      '_ansible_check_mode': False,
                      '_ansible_no_log': False,
                      '_ansible_verbosity': 0,
                      'changed': False}

# Generated at 2022-06-11 12:42:26.970760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ansible.plugins.action.shell
    ~~~~~~~~~~~~~~~~~~~~~~~

    Unit test for method run of class ActionModule

    """
    from test_common_shell import TestActionModule
    from ansible.plugins.action.shell import ActionModule

    assert True == isinstance(TestActionModule(ActionModule), ActionModule)

# Generated at 2022-06-11 12:42:27.495711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-11 12:42:38.904252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule.run()")
    _task_args = {
        '_uses_shell': False,
        '_raw_params': 'grep test',
        '_uses_delegate_to': False,
        '_attrs': {},
        '_ansible_check_mode': False
    }
    # Initialize task object.
    _task = ansible.legacy.plugins.action.shell.ActionModule(_task_args, 'localhost')
    # Initialize ActionModule object.
    _actionModule = ActionModule(_task, 'localhost', ansible.legacy.plugins.loader._find_plugin('action'))
    # Excute run() method.
    _result = _actionModule.run(task_vars={})

# Generated at 2022-06-11 12:42:39.690112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test function for module run of class ActionModule
    """
    actionModule_obj = ActionModule()
    actionModule_obj.run()

# Generated at 2022-06-11 12:42:41.343779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import doctest
    doctest.testmod(name="test_ActionModule_run", module="runner_module_shell")

# Generated at 2022-06-11 12:42:41.906453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:49.741785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import filecmp
    import json
    import unittest

    module_name = 'test_action_shell'
    action_name = 'test_action_shell'
    action_module = 'ansible.legacy.shell'
    action_command = 'echo "test" > test_data/test_action_shell/test_action_echo.txt'

    # Create instance of ActionModule class and set its attributes with test data
    subject = __import__(module_name).ActionModule()
    subject.validate_args = lambda x: type(x) == dict
    subject._task = lambda: None
    subject._task.action = lambda: None
    subject._task.action.name = action_name
    subject._task.action.get_name = lambda: action_name

# Generated at 2022-06-11 12:43:05.709545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:43:15.576948
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.shell as shell
    from ansible.module_utils.basic import AnsibleModule

    shell_new = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict()
        )
    )

    task_args = dict(
        _raw_params="ls -lrt",
        _uses_shell="echo hello world"
    )

    shell_new.params = task_args

    assert shell.ActionModule(shell_new, connection=None,
        play_context=None, loader=None, templar=None, shared_loader_obj=None
    ).run()

    task_args = dict(
        _raw_params="df -h"
    )

    shell_new.params = task_args

    assert shell.Action

# Generated at 2022-06-11 12:43:24.749411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define a test for method run
    def test():
        # Create an instance of class ActionModule without specifying any parameters
        action_module_instance = ActionModule()

        # Mock attributes of action_module_instance
        action_module_instance._task = "task"
        action_module_instance._connection = "connection"
        action_module_instance._play_context = "play_context"
        action_module_instance._loader = "loader"
        action_module_instance._templar = "templar"
        action_module_instance._shared_loader_obj = "shared_loader_obj"

        # Call method run of action_module_instance with the following parameters
        result = action_module_instance.run(tmp=None,
                                            task_vars="task_vars")

        # Check the result

# Generated at 2022-06-11 12:43:32.028700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.basic import ActionModule
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    action_base = ActionBase()
    action_module = TestActionModule(action_base._task, action_base._connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    tmp = None
    task_vars = {}
    action_module_run_output = action_module.run(tmp, task_vars)

# Generated at 2022-06-11 12:43:33.029743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()

# Generated at 2022-06-11 12:43:34.061681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:43:35.383128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This is an auto-generated test yet to be implemented.
    return None

# Generated at 2022-06-11 12:43:36.002113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:47.367965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil
    import os
    fd, path = tempfile.mkstemp(suffix='.yml', prefix='test_ActionModule')
    with os.fdopen(fd, 'w') as f:
        f.write('---\n- hosts: my_hosts\n  tasks:\n')
        f.write('    - name: "Test install command"\n')
        f.write('      shell: /usr/bin/pwd | grep -q /root/ansible || ( yum -y upgrade && yum -y install ansible )\n')
    from ansible.cli.adhoc import AdHocCLI as adhoc
    import ansible.constants as C

# Generated at 2022-06-11 12:43:48.038382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:30.344141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest

    class TestActionModule_run(unittest.TestCase):
        pass


# Generated at 2022-06-11 12:44:32.430174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  import ansible.plugins.loader as loader
  from ansible.vars.manager import VariableManager
  print (dir(loader))
  print (dir(VariableManager))

# Generated at 2022-06-11 12:44:33.514194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.set_loader(ArgvLoader())

# Generated at 2022-06-11 12:44:40.847666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Patch items
    import ansible.plugins.action.shell
    class MockActionBase:
        def run(self, tmp=None, task_vars=None):
            return None
    class MockAction(ansible.plugins.action.shell.ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(MockAction, self).run(tmp=tmp, task_vars=task_vars)
    ansible.plugins.action.shell.ActionBase = MockActionBase
    ansible.plugins.action.shell.ActionModule = MockAction

    # Mock items
    import ansible.plugins.action.shell
    old_get = ansible.plugins.action.shell.ActionBase.get
    old_run = ansible.plugins.action.shell.ActionBase.run

# Generated at 2022-06-11 12:44:48.009816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for module run action: ansible.actions.shell.ActionModule.run(tmp, task_vars)
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible_collections.ansible.community.plugins.module_utils.network.junos.argspec.shell.shell import ShellArgs
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            self._task.args['_uses_shell'] = True

# Generated at 2022-06-11 12:44:48.488791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:56.637631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Replaces use of AnsibleAction plugin
  action = ActionModule(
    connection = True,
    play_context = True,
    loader = True,
    templar = True,
    task = None,
    shared_loader_obj = None
  )
  # Unit test for method run of class ActionModule
  # Asserts: If a _uses_shell key is present in task.args and the value is True, then a command is generated and an action_plugin is returned.
  from ansible.plugins.action.command import ActionModule as ActionModuleCommand
  assert isinstance(action.run(task_vars=True),ActionModuleCommand)
  # Asserts: If a _uses_shell key is present in task.args and the value is False, then a command is generated and an action_plugin is returned.

# Generated at 2022-06-11 12:44:57.424411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test")


# Generated at 2022-06-11 12:44:59.675828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize an ActionModule
    am = ActionModule()

    # Fake parameters for method run
    result = am.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-11 12:45:02.741454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, templar=None,
                                 shared_loader_obj=None)

    assert action_module.run(tmp=None, task_vars=None) is None

# Generated at 2022-06-11 12:46:13.693496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:46:14.161535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO

# Generated at 2022-06-11 12:46:22.055978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input params
    tmp = None

# Generated at 2022-06-11 12:46:23.508413
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:46:31.668401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    

# Generated at 2022-06-11 12:46:38.465107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temporary file with the content of the module
    from tempfile import mkstemp
    from shutil import move
    from os import fdopen, remove

    with open('/ansible/legacy/actions/shell.py') as shell_module:
        data = shell_module.read()
    fh, abs_path = mkstemp()
    with fdopen(fh, 'w') as new_file:
        new_file.write(data)

    # Move new file
    move(abs_path, '/ansible/legacy/actions/shell.py')

    # Create a task
    from ansible.playbook.task import Task
    task = Task()

# Generated at 2022-06-11 12:46:47.632050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('### start of test_ActionModule_run ###')
    print('')

    task_args = {}

    from AnsibleModule import AnsibleModule
    from ansible.template import Templar

    module = AnsibleModule(
        argument_spec = dict(
        ),
    )

    tmp = None
    task_vars = {}
    connection = None
    play_context = None
    loader = None
    shared_loader_obj = None

    # Create the ActionModule instance to test
    am = ActionModule(
        module=module,
        task=None,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=Templar(loader=loader),
        shared_loader_obj=shared_loader_obj,
    )

    # Call method run

# Generated at 2022-06-11 12:46:56.395351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import yaml
    from ansible.modules._mock import ActionModule as Mock_ActionModule
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader() # Data loader for tests

    # Data for test

# Generated at 2022-06-11 12:46:59.121377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	params = {
		'param1': {'arg': 1}
	}
	# Initialize objects of class ActionModule
	action_module = ActionModule(params, None)
	# Call method run
	result = action_module.run()
	print(result)


# Generated at 2022-06-11 12:47:08.568495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule(loader=None,
                                      connection=None,
                                      play_context=None,
                                      loader=None,
                                      templar=None,
                                      shared_loader_obj=None)
    test_action_module._task.args['_uses_shell'] = True
    test_action_module._task.args['creates'] = None
    test_action_module._task.args['executable'] = None
    test_action_module._task.args['chdir'] = None
    test_action_module._task.args['stdin'] = None
    test_action_module._task.args['stdin_add_newline'] = None
    test_action_module._task.args['strip_empty_ends'] = True