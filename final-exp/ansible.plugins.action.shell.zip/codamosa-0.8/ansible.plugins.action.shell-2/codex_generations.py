

# Generated at 2022-06-11 12:39:22.343255
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.errors import AnsibleUndefinedVariable

    from ansible.module_utils.six import StringIO

    import contextlib
    import json
    import os
    import sys
    import tempfile

    # class AnsibleModuleFake
    class AnsibleModuleFake:

        def __init__(self):
            self.params = {}

    # class ConnectionFake
    class ConnectionFake:

        def __init__(self):
            self.protocol = 'ssh'

    # class ConnectionTest
    class ConnectionTest:

        def __init__(self):
            self.connection = ConnectionFake()

            self.task = AnsibleModuleFake()

            self.task_vars = {}

            self.args = {
                '_uses_shell': False
            }

    from ansible.module_utils.common.collections import ImmutableD

# Generated at 2022-06-11 12:39:30.222471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test for method run of class ActionModule")
    # Test for case when tmp(no longer has any effect) and task_vars are not passed
    action_module_obj = ActionModule()
    action_module_obj.run()

    # Test for case when tmp(no longer has any effect) is passed and task_vars are not passed
    action_module_obj.run(tmp='/var/tmp')

    # Test for case when tmp(no longer has any effect) is passed and task_vars also passed
    action_module_obj.run(tmp='/var/tmp',task_vars={})

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:39:40.190203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO

    module_name = 'shell'
    action_name = 'shell'

    # Set up data used for the tests
    loader = DictDataLoader({
        'shell': '#!/usr/bin/python\n',
        'shell.py': '#!/usr/bin/python\n',
    })
    runner = TestRunner(
        action=ActionModule,
        action_name=action_name,
        module_name=module_name,
        task_vars={
            'ansible_shell_executable': '/usr/bin/python',
        },
        loader=loader)

# Generated at 2022-06-11 12:39:49.640397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    play_context = {'port':'10101'}
    connection = None
    loader = None
    task_vars = {'inventory_hostname':'host1'}
    templar = None
    shared_loader_obj = None
    task = {
        'name':'test_task',
        'tags':['test_tag'],
        'debug':'enabled',
        'args':{
            '_raw_params':'expr 1 + 1',
            'chdir':'/tmp/'
        }
    }
    action_module = ActionModule(play_context=play_context, connection=connection, loader=loader, task_vars=task_vars, templar=templar, shared_loader_obj=shared_loader_obj)
    action_module._task = task
    result = action_

# Generated at 2022-06-11 12:39:53.752668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_result import TaskResult
    task_result = TaskResult(host=None, task=None)
    task_result._result = {'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}
    task_result._host = 'localhost'
    task_result._task = 'test'
    task_result._result['rc'] = 0

    import ansible.plugins.action
    action_base = ansible.plugins.action.ActionBase()
    action_base._connection = None
    play_context = PlayContext()
    action_base._play_context = play_context

# Generated at 2022-06-11 12:40:05.336626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mocks for Class ActionBase
    class MockActionBase:
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

        def run(self, task_vars=None):
            pass
    class MockActionLoader:
        def get(self, name, task, connection, play_context, loader, templar, shared_loader_obj):
            return MockActionBase(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create mock for Class ActionModule
    task = MockActionBase

# Generated at 2022-06-11 12:40:13.572251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    from ansible.plugins.action.script import ActionModule
    from ansible.module_utils.common._collections_compat import Mapping

    class FakeActionBase:
        class FakeTask:
            class FakeArgs:
                _uses_shell = False
            args = FakeArgs

        class FakeConnection:
            def __init__(self):
                self.port = None

        def __init__(self):
            self._task = self.FakeTask()
            self._connection = self.FakeConnection()
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None
            
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                return False

# Generated at 2022-06-11 12:40:19.620196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Given an action module
  action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

  # When I execute method run
  result = action_module.run(tmp=None, task_vars=None)

  # Then it should return result
  assert result

# Generated at 2022-06-11 12:40:20.232648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:31.038000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.plugins.action.shell import ActionModule

    AM = ActionModule({"name": "shell",
                       "action": {"__ansible_module__": "shell.py"},
                       "args": {"chdir": "/",
                                "executable": "/bin/sh",
                                "creates": "/does/not/exist",
                                "removes": "/tmp/foo",
                                "stdin": "Hello",
                                "stdin_add_newline": True,
                                "strip_empty_ends": True,
                                "warn": False}})

    # Unit test 1:
    # Check that a method run() works correctly, i.e. that it returns a
    # dictionary containing two keys: changed and rc. The

# Generated at 2022-06-11 12:40:34.342795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # print "Method run of class ActionModule"
    pass

# Generated at 2022-06-11 12:40:44.139138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   # Setup
   task_args = dict(
      _raw_params='id',
      _uses_shell=True,
      _raw_params_expanded='id -u',
      _uses_shell_expanded=True
   )
   task_vars = dict( test_variable='test_var_value' )
   tmp = None
   task_action = dict( task_action='shell' )
   connection = None
   play_context = None
   loader = None
   templar = None
   shared_loader_obj = None

   command_action = dict(
      run=lambda task_vars: dict(
         skipped=False,
         changed=False,
         failed=False,
         msg='',
         stdout='',
         stderr=''
      )
   )

   action_plugin = dict

# Generated at 2022-06-11 12:40:44.656503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:54.121724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = Mock()
    mock_task.args = {'_uses_shell': True}
    mock_task.action = 'shell'
    mock_task.args = {'_uses_shell': True}

    mock_connection = Mock()

    mock_play_context = Mock()

    mock_loader = Mock()

    mock_templar = Mock()

    mock_shared_loader_obj = Mock()

    mock_legacy_command_action = Mock()

    # Create a proper return value
    mock_legacy_command_action.run = Mock(return_value = {'msg': 'Hello World'})

    mock_shared_loader_obj.action_loader.get = Mock()
    mock_shared_loader_obj.action_loader.get.return_value = mock_legacy_command_action

    action_

# Generated at 2022-06-11 12:40:55.168143
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Method run of class Shell
    pass

# Generated at 2022-06-11 12:41:04.811529
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    class FakeTask:
        pass

    class FakeAnsibleModule:
        def __init__(self):
            self.task = FakeTask()

    am = ActionModule(FakeAnsibleModule())
    am._task.args = {
        '_raw_params': 'echo TEST',
        '_tmp_path': '/tmp/ansible_test/',
        '_uses_shell': True
    }
    am._shared_loader_obj.action_loader.get = create_mock_get_return_value({
        'ansible.legacy.command': create_mock_command_return_value()
    })

    # Exercise and Verify

# Generated at 2022-06-11 12:41:05.900051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    pass

# Generated at 2022-06-11 12:41:09.742264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a method object for class ActionModule
    method = ActionModule()
    # Create a dict object which can hold the arguments
    args = dict()
    # assign values to the arguments
    args['_uses_shell'] = True
    # call the method run of class ActionModule with argments
    result = method.run(args)

# Generated at 2022-06-11 12:41:10.277167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:15.411987
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # First we create a context for testing
    ActionModule_instance = ActionModule()

    tmp = None
    task_vars = {}

    # Then we call the method run of class ActionModule with the context above
    result = ActionModule_instance.run(tmp, task_vars)

    # Finally, we check if the result is as we expect
    assert result == """{'msg': 'test'}"""

# Generated at 2022-06-11 12:41:20.274379
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    c = command()
    print(c.run())

# Generated at 2022-06-11 12:41:21.417399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# no test case at present
	pass



# Generated at 2022-06-11 12:41:30.759316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # replace with implementation calling run method of ActionModule

    print ("\nUnit test for method run of class ActionModule\n")

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.six import iteritems

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import get_module_name
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig

# Generated at 2022-06-11 12:41:32.280687
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    assert module.run() == None

# Generated at 2022-06-11 12:41:32.824222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()

# Generated at 2022-06-11 12:41:33.378255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:34.301531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()


# Generated at 2022-06-11 12:41:43.304090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult

    action_module = ActionModule()

    action_module._connection = None
    action_module._task = None
    action_module._loader = None
    action_module._put_file()
    action_module._task_vars = None
    action_module._tmp_path()
    action_module._play_context = None
    action_module._add_cleanup_task()
    action_module._remove_tmp_path()
    action_module._load_name_to_path_map()
    action_module._execute_module(module_name='shell', module_args={}, task_vars=None, wrap_async=None)

# Generated at 2022-06-11 12:41:53.809768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task object
    class mock_task:
        def __init__(self, args):
            self.args = args
    task = mock_task({'_raw_params': 'foo', '_uses_shell': False, '_uses_delegate_to': False})

    # create a mock shared loader object
    class mock_shared_loader_obj:
        def __init__(self, action_loader):
            self.action_loader = action_loader
    class mock_action_loader:
        def __init__(self, task):
            self.task = task
        def get(self, *args, **kwargs):
            return 'get({args}, {kwargs})'.format(
                args=repr(args),
                kwargs=repr(kwargs)
            )
    shared_loader_obj

# Generated at 2022-06-11 12:42:00.657949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_class_name = 'ansible.module_utils.ansible_release.AnsibleModule'
    command_action_class_name = 'ansible.legacy.command.ActionModule'
    shell_action_class_name = 'ansible.legacy.shell.ActionModule'

    # import statements in a function
    import ansible.module_utils.ansible_release
    import ansible.legacy.command
    import ansible.legacy.shell

    module = ansible.module_utils.ansible_release.AnsibleModule
    command = ansible.legacy.command.ActionModule
    shell = ansible.legacy.shell.ActionModule

    # mock of AnsibleModule __init__

# Generated at 2022-06-11 12:42:19.005894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mytmp = "testtmp"
    mytaskvars = {"testvar1": "testvalue1", "testvar2": "testvalue2"}
    # test of correct method run of ActionModule using mocked objects
    #prepare()
    #run(self, tmp=None, task_vars=None)
    test_obj = ActionModule()
    test_obj._task.args['_uses_shell'] = True
    test_obj._task.args['echo'] = "echo"
    test_obj._connection = None
    test_obj._play_context = None
    test_obj._loader = None
    test_obj._templar = None
    test_obj._shared_loader_obj = None
    test_obj._task.args['chdir'] = None
    test_obj._task.args['creates'] = None


# Generated at 2022-06-11 12:42:19.503665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:42:28.482931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest, mock
    from ansible.module_utils.six import PY3
    if not PY3:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils._text import to_bytes

    # Python2 and Python3 compatibility
    if not PY3:
        builtin_open = '__builtin__.open'
    else:
        builtin

# Generated at 2022-06-11 12:42:29.905264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:34.769311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp=None
  task_vars=None
  obj=ActionModule()
  obj._task=None
  obj._connection=None
  obj._play_context=None
  obj._loader=None
  obj._templar=None
  obj._shared_loader_obj=None
  assert obj.run(tmp,task_vars)

# Generated at 2022-06-11 12:42:36.725624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-11 12:42:41.765546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Try run method of class ActionModule with no task_vars specified
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run(task_vars=None) == None

# Generated at 2022-06-11 12:42:42.324483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:42.637063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:43.201871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:08.303115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = object()
    task = dict(key1='value1', key2='value2')
    args = dict(key3='value3', key4='value4')
    tmp = 'tmp'
    task_vars = dict(key5='value5', key6='value6')
    action_module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    action_command = dict(key7='value7', key8='value8')
    action_command_instance = type('action_command_instance', (object,), dict(run=lambda self, task_vars: action_command))
    action_loader_get

# Generated at 2022-06-11 12:43:13.138390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    task_vars['module_name'] = 'setup'
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp=None, task_vars=task_vars)
    assert result['cmd'] == 'setup'

# Generated at 2022-06-11 12:43:22.772536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Args setup
    tmp = {'foo': 'bar'}
    task_vars = {'foo': 'bar'}
    module._task.args = {'_uses_shell': True}

    module._shared_loader_obj = FakeSharedLoaderObj()
    module._task = FakeTask()
    module._connection = FakeConnection()
    module._play_context = FakePlayContext()
    module._loader = FakeLoader()
    module._templar = FakeTemplar()
    module._connection.connection = FakeConnectionObj()

    # When I run the action module
    result = module.run(tmp, task_vars)

    # Then it should have ran the command module
    assert result['action'] == 'command'


# Generated at 2022-06-11 12:43:24.032845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-11 12:43:24.581924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:25.105279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:25.617747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:29.943371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = Runner(module_name='some_shell', module_args={'_ansible_shell_executable': 'python'})
    with mock.patch('ansible.plugins.action.ActionBase.run',
                    new_callable=mock.MagicMock(return_value=runner)) as mock_run:
        action_module = ActionModule()
        result = action_module.run()
        assert result == runner

# Generated at 2022-06-11 12:43:30.688200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:41.283873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class
    class ActionModuleMock():
        def __init__(self):
            self.args = {
                "a": "1",
                "b": "2",
                "c": "3"
            }
            self.result = {}

        def set_result(self, status, msg, data):
            self.result["status"] = status
            self.result["msg"] = msg
            self.result["data"] = data

        def get_result(self):
            return self.result

    # Init class
    action_module = ActionModule()
    action_module._task = ActionModuleMock()

    # Test action_module.run() with empty args
    action_module.run()

    # Check result

# Generated at 2022-06-11 12:44:29.147215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'_uses_shell': True}
    task = {'hosts': 'host', 'args': args}
    connection = {'name': 'local', 'host': 'host'}
    play_context = {}

    # Creating object of class ActionModule
    # and passing required objects and parameters
    action_obj = ActionModule(task, connection, play_context, {}, {}, {}, {})
    action_obj._shared_loader_obj.action_loader.get = lambda *args, **kwargs: {'run': lambda *args, **kwargs: {}}
    # Calling run method of class ActionModule
    result = action_obj.run({}, {})

    assert result == {'_ansible_verbose_always': True, '_ansible_no_log': False}

# Generated at 2022-06-11 12:44:36.679493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    # Test data
    action_task_vars = {'test_var': 'value1'}
    command_task_vars = {'test_var': 'value2'}
    host_vars = {'test_var': 'value3'}
    host_group_vars = {'test_var': 'value4'}
    task_vars = combine_vars(host_vars, host_group_vars, action_task_vars)
    assert task_vars['test_var'] == 'value1'

    # Setup
    context._init_global_context(mock_options=None)
    action = action_loader.get('shell')


# Generated at 2022-06-11 12:44:38.784280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    expected = {}
    actual = module.run(tmp=None, task_vars=None)
    assert actual == expected, "test_ActionModule_run() failed"

# Generated at 2022-06-11 12:44:43.034687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task = dict(
        module_args=dict(
            _uses_shell=True
        )
    )

    am = ActionModule(task=fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert 'ansible.legacy.command' == am.run(task_vars=None)['_ansible_action_plugin']

# Generated at 2022-06-11 12:44:50.371452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader = DictDataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager._extra_vars = load_fixture('extra_vars')
    variable_manager.set_vault_secrets(["vault.secret"])
    variable_manager._vault = VaultLib(variable_manager._extra_vars, loader)
    option_manager = Options()
    option_manager.connection = 'local'
    defaults = C.load_configuration_file()
    defaults['vault_password_file'] = 'vault.secret'
    constants._CONNECTION_PLUGIN_PATH = 'unittest'
    ansible_config = defaults
    options = {'tags': ['collective.monsanto']}
    options['listtags']

# Generated at 2022-06-11 12:44:51.168323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	print("test ActionModule.run is called")

# Generated at 2022-06-11 12:44:59.228769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockSummary
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.results import AnsibleRunnerCallbacks
    from ansible.utils.encrypt import do_encrypt
    from ansible.utils.encrypt import do_decrypt
    from ansible.utils.encrypt import encrypt

# Generated at 2022-06-11 12:45:07.282662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {
        "module_name": "ansible.module_test",
        "task_path": "/a/test/path/test_module.py",
        "args": {
            "print_method": "json"
        }
    }
    play_context = {
        "password": "123"
    }
    templar = {}
    module_name = 'test_module'
    connection = {}
    loader = {}
    shared_loader_obj = {}

    action = ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj)


# Generated at 2022-06-11 12:45:13.780203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {"args": {"_raw_params": "ls -la"}}
    action_module._shared_loader_obj = "action_loader"
    action_module._connection = "connection"
    action_module._play_context = "play_context"
    action_module._loader = "loader"
    action_module._templar = "templar"
    result = action_module.run(tmp="tmp", task_vars="task_vars")
    assert result["result"]["stdout"] == "stdout"

# Generated at 2022-06-11 12:45:14.305242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-11 12:46:47.631998
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup assertions
    class ActionBase(object):
        def run(self, tmp=None, task_vars=None):
            assert tmp == None
            assert task_vars == None
            return 0

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Shell module is implemented via command with a special arg
            self._task.args['_uses_shell'] = True


# Generated at 2022-06-11 12:46:56.394907
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: need to define class for _shared_loader_obj
    _shared_loader_obj = None
    # FIXME: need to instantiate class for _play_context
    _play_context = None
    # FIXME: need to instantiate class for _loader
    _loader = None
    # FIXME: need to instantiate class for _templar
    _templar = None

    # FIXME: need to instantiate class for _task
    _task = None
    # FIXME: need to instantiate class for _connection
    _connection = None

    # create the object of the class
    obj = ActionModule(_task, _connection, _play_context, _loader, _templar, _shared_loader_obj)

    # call the method
    result = obj.run()

    # FIXME: assert the results


# Generated at 2022-06-11 12:46:57.043181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:46:57.552482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:46:58.166780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:47:01.432161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock

    with unittest.mock.patch.object(ActionBase, 'run', autospec=True) as action_base_run_mock:
        instance = ActionModule()
        result = instance.run()

        action_base_run_mock.assert_called_once_with(tmp=None, task_vars=None)
        assert result == action_base_run_mock.return_value

# Generated at 2022-06-11 12:47:10.808643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None, None)
    play = Play().load({'name': 'test_play', 'hosts': ['foo'],
                        'tasks': [{'name': 'test_task', 'action': {'module': 'shell',
                                                                   'args': 'echo ansible'},
                                   'async': 0, 'poll': 0}]}, loader=tqm._loader, variable_manager=tqm._variable_manager)
    block = Block().load(play.get_block_list()[0], play=play)
    task

# Generated at 2022-06-11 12:47:11.962781
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:47:12.702748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule run method:")
    assert True

# Generated at 2022-06-11 12:47:20.323939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil

    from ansible.plugins.action import ActionBase

    # Create a temporary directory
    tmp = tempfile.mkdtemp()
    # Create a temporary inventory
    path = tmp + '/ansible_hosts'
    with open(path, 'w') as f:
        f.write("""
    # Group all
    [all]
    localhost ansible_connection=local

    [ungrouped]
    """)

    # Create a temporary shell script
    path = tmp + '/shell.sh'
    with open(path, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('MYVAR=OK\n')
        f.write('echo "$MYVAR"\n')

    # Create a temporary playbook