

# Generated at 2022-06-11 12:39:11.048998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result

# Generated at 2022-06-11 12:39:19.427631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import merge_hash


# Generated at 2022-06-11 12:39:21.201595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    :param tmp:
    :param task_vars:
    :return:
    '''
    pass

# Generated at 2022-06-11 12:39:25.640539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    action_module = ActionModule()

    # Add your test cases here.
    # TestCase: 'method run'
    # test_case = action_module.run(
    #     tmp=None, task_vars=None
    # )
    # assert command_action.run(task_vars=task_vars) is result

# Generated at 2022-06-11 12:39:34.858199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.plugins.action.shell import ActionModule

    action_plugins = action.ActionBase._plugins  # pylint: disable=protected-access

    action_module = action_plugins.get('shell')
    assert isinstance(action_module, ActionModule)

    action_module._task.args['_raw_params'] = 'pwd'  # pylint: disable=protected-access
    action_module._task.args['_uses_shell'] = True  # pylint: disable=protected-access


# Generated at 2022-06-11 12:39:36.898949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Unit test for method run of class ActionModule
    pass

# Generated at 2022-06-11 12:39:46.181326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = ansible_task
    action_module._play_context = ansible_play_context
    action_module._shared_loader_obj = ansible_shared_loader_obj

    result = action_module.run(tmp=None, task_vars=None)
    pprint.pprint(result)


if __name__ == '__main__':
    import json
    import pprint
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-11 12:39:54.865862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    obj = ActionModule()
    # Set test values of attributes of obj
    obj._task = dict()
    obj._task['args'] = dict()
    obj._task['args']['_uses_shell'] = True
    obj._task['name'] = "remote_shell"
    obj._shared_loader_obj = dict()
    obj._shared_loader_obj.action_loader = dict()
    obj._shared_loader_obj.action_loader.get = lambda x: 'dummy'

    # Run the unit test on method run of class ActionModule
    result = obj.run(tmp=None, task_vars=None)
    assert result == 'dummy'

# Generated at 2022-06-11 12:39:55.474852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:07.116394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action.command import ActionModule
    import ansible.plugins
    import ansible.constants
    import tempfile
    import random
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.parsing.convert_datetime
    import ansible.module_utils.parsing.convert_ips
   

# Generated at 2022-06-11 12:40:09.391779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-11 12:40:20.648746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = Mock()
    task.args = {
        '_uses_shell': True
    }

    # Create a mock loader object
    loader = Mock()

    # Create a mock templar object
    templar = Mock()

    # Create a mock shared loader object
    shared_loader_obj = Mock()
    shared_loader_obj.action_loader = Mock()
    shared_loader_obj.action_loader.get = Mock(return_value=Mock())

    # Create a mock command_action object
    command_action = Mock()

    # Create a mock connection
    connection = Mock()

    # Create a mock play_context
    play_context = Mock()

    # Create a mock ActionModule object

# Generated at 2022-06-11 12:40:31.446588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  class MockTask():
    def __init__(self, **kwargs):
      self.result = dict()
      self.args = dict()
      self.vars = dict()
      self.action = 'ansible.legacy.shell'
      self.name = 'shell module test'
      self.action_args = dict()
      self.action_vars = dict()
      self.tags = None

  class MockPb():
    def __init__(self, **kwargs):
      self.connection = None
      self.become = False
      self.become_method = None
      self.become_user = None
      self.no_log = False
      self.remote_user = None
      self.sudo = False
      self.sudo_user = None
      self.su = False
      self.su_

# Generated at 2022-06-11 12:40:42.127041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import module_loader
    import copy, json, os

# Generated at 2022-06-11 12:40:42.655292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:48.566988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}

    ActionModule.run(tmp, task_vars)

    del tmp  # tmp no longer has any effect

    # Shell module is implemented via command with a special arg
    _task = {}
    _task.args = {}
    _task.args['_uses_shell'] = True

    command_action = {}
    command_action.run = True

    _shared_loader_obj = {}
    _shared_loader_obj.action_loader = {}
    _shared_loader_obj.action_loader.get = True

    action_module = ActionModule()
    action_module.run(tmp, task_vars)

# Generated at 2022-06-11 12:40:49.750628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-11 12:40:50.680492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO: write an actual unit test

# Generated at 2022-06-11 12:41:00.867795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()


# Generated at 2022-06-11 12:41:10.029497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(ansible_user_dir='/home/user/ansible/',
                     ansible_user_id='user',
                     ansible_user_shell='/bin/bash',
                     inventory_hostname='host1.example.com',
                     inventory_hostname_short='host1',
                     inventory_dir='/home/user/ansible/inventory',
                     inventory_file='/home/user/ansible/inventory/inventory.ini')
    print(task_vars['ansible_user_dir'])
    runner_args = dict(
        patterns=['tëst'],
    )
    runner_args.update(task_vars)
    runner_args['private_data_dir'] = task_vars['ansible_user_dir']
    runner_args['host_pattern_key']

# Generated at 2022-06-11 12:41:17.287216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task_vars = {}
  actionmodule = ActionModule()
  actionmodule._task.args = {}
  actionmodule._task.args['_uses_shell'] = True
  actionmodule.run(task_vars=task_vars)

# Generated at 2022-06-11 12:41:26.408522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager()
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 12:41:26.985036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   pass

# Generated at 2022-06-11 12:41:27.877487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No unit test written"

# Generated at 2022-06-11 12:41:37.163393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the action module
    action_module = __import__('ansible.plugins.action.shell').ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Initialize the result to be returned by the shell command

# Generated at 2022-06-11 12:41:47.884088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    kwargs = dict()
    task = object()
    kwargs['task'] = task
    connection = object()
    kwargs['connection'] = connection
    play_context = object()
    kwargs['play_context'] = play_context
    loader = object()
    kwargs['loader'] = loader
    templar = object()
    kwargs['templar'] = templar
    shared_loader_obj = object()
    kwargs['shared_loader_obj'] = shared_loader_obj
    test = ActionModule(**kwargs)

    try:
        from unittest.mock import Mock
    except:
        from mock import Mock

    kwargs = dict()
    tmp = object()
    kwargs['tmp'] = tmp
    task_vars = object()
    k

# Generated at 2022-06-11 12:41:54.601904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    from ansible.plugins.action.legacy import ActionModule
    from ansible.utils.vars import merge_hash

    # Init action class
    am = ActionModule(loader=None,
                      task=None,
                      connection=None,
                      play_context=None,
                      loader_args=None,
                      templar=None,
                      shared_loader_obj=None)



# Generated at 2022-06-11 12:41:57.186426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ansible.plugins.action.ActionModule
    actionModule = ActionModule()

    print("Returned value of method run is: ")

    # Invoke method to test
    result = actionModule.run()

    print(result)


# Generated at 2022-06-11 12:41:59.612174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ShellModule = ActionModule(
        task=dict(action=dict(module_name='shell', module_args='cd /tmp; ls')),
        connection=None,
        shared_loader_obj=None)
    assert not ShellModule.run()

# Generated at 2022-06-11 12:42:01.316090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule_run")
    assert False == True

# Generated at 2022-06-11 12:42:09.718822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:42:12.316768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_instance_ActionModule = ActionModule()
    data = {}
    result = test_instance_ActionModule.run(data)
    assert result == {}

# Generated at 2022-06-11 12:42:16.037682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method with all valid parameters
    action_module = ActionModule()
    # Method run returns a dictionary
    dictionary = action_module.run()
    assert dictionary == {u"rc": "", u"stdout": "", u"stdout_lines": [], u"stderr": "", u"msg": ""}

# Generated at 2022-06-11 12:42:16.370949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO

# Generated at 2022-06-11 12:42:16.897578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:17.397176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:24.091522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock ActionBase
    ActionBase_mock = MagicMock()
    ActionBase_mock.run = lambda self, tmp, task_vars, *args, **kwargs : {
        'failed': False,
        'rc': 0,
        'stdout': 'stdout',
        'stderr': 'stderr',
        'stdout_lines': ['stdout_lines']
    }
    ActionBase_mock.__setattr__ = lambda self, name, value : None
    ActionBase_mock.__getattr__ = lambda self, name : None

    # mock _shared_loader_obj
    _shared_loader_obj_mock = MagicMock()
    _shared_loader_obj_mock.action_loader = MagicMock()
    _shared_loader_obj_mock.action_loader

# Generated at 2022-06-11 12:42:35.218079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for testing
    action_mod = ActionModule(load_strategy='foo',
                              templar='bar',
                              shared_loader_obj='baz',
                              connection='qux',
                              play_context='quux',
                              loader='corge',
                              action_loader='grault',
                              task='garply',
                              args='waldo',
                              name='fred')
    # Create a mock object for testing
    action_mod._shared_loader_obj.action_loader.get = Mock(return_value='quux')
    action_mod._task.args = {'_uses_shell': False}
    # Create a mock object for testing
    action_mod._task.args['_uses_shell'] = True

    # Run the function

# Generated at 2022-06-11 12:42:35.829139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:37.333414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    assert type(am) == ActionModule


# Generated at 2022-06-11 12:43:00.859798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook import play
    from ansible.plugins.loader import find_plugin, PluginLoader, module_loader
    from ansible.plugins.action import ActionBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_iterator import PlaybookIterator
    from ansible.executor.stats import AggregateStats
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

# Generated at 2022-06-11 12:43:05.747309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = {
        '_uses_shell': True
    }

    loader_mock = {
        'shared_loader_obj': {
            'action_loader': {
                'get': lambda *args, **kwargs: {}
            }
        },
        '_loader': {}
    }

    action_module = ActionModule(loader=loader_mock, task=loader_mock)

    assert action_module.run() == {}

# Generated at 2022-06-11 12:43:15.619273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test Method: run of class ActionModule")

    #test with no arguments
    command_action = ansible.plugins.action.ActionModule(loader=None,connection=None,play_context=None,task_vars=None,templar=None)
    result = command_action.run(tmp=None, task_vars=None)

    #run_args = command_action.run(tmp=None, task_vars=None)
    #print(run_args)

    #test with arguments
    #command_action = ansible.plugins.action.ActionModule(loader=None,connection=None,play_context=None,task_vars=None,templar=None)
    #result = command_action.run()

    #run_args = command_action.run(tmp=None, task_vars=

# Generated at 2022-06-11 12:43:24.793218
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.legacy.action.command
    import ansible.legacy.action
    import ansible.utils.vars
    import sys
    import os

    # Test for existance of method "run"
    assert hasattr(ansible.legacy.action.command.ActionModule, 'run')
    assert callable(ansible.legacy.action.command.ActionModule.run)

    # Test for expected return values
    assert ansible.legacy.action.command.ActionModule.run(ansible.legacy.action.command.ActionModule) == None
    assert ansible.legacy.action.command.ActionModule.run(ansible.legacy.action.command.ActionModule) is None
    assert ansible.legacy.action.command.ActionModule.run(ansible.legacy.action.command.ActionModule)

# Generated at 2022-06-11 12:43:31.253619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init mock objects
    fake_task, fake_connection, fake_play_context, fake_loader, fake_templar, fake_shared_loader_obj = (
        object(), object(), object(), object(), object(), object())

    action_module = ActionModule(fake_connection, fake_play_context, fake_loader, fake_templar, fake_shared_loader_obj)
    action_module._task = {'args': {'cmd': 'echo "hello"'}}

    # check that method run of class ActionModule is called without errors
    result = action_module.run(None, None)
    if result is None:
        raise Exception("ActionModule.run failed")

# Generated at 2022-06-11 12:43:31.952094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:42.312299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    file_name = os.path.basename(sys.argv[0])
    # Specify name to use for input and output files
    if os.path.isfile(file_name + '.in'):
        input_file = file_name + '.in'
    elif os.path.isfile(file_name[:-3] + '.in'):
        input_file = file_name[:-3] + '.in'
    else:
        print('Input file doesn\'t exist')
        exit(1)
    if os.path.isfile(file_name + '.out'):
        output_file = file_name + '.out'
    elif os.path.isfile(file_name[:-3] + '.out'):
        output_file = file_name[:-3] + '.out'

# Generated at 2022-06-11 12:43:50.128673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Read input variables
    action_module = ActionModule(loader=None, shared_loader_obj=None, path_info=None)
    tmp = None
    task_vars = {'data1':123, 'data2':456, 'data3':789}

    # Call method run
    result = action_module.run(tmp, task_vars)
    print(result)


if __name__ == '__main__':
    # Preparing to call method run
    test_ActionModule_run()

# Generated at 2022-06-11 12:43:59.412200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeModule(object):
        # Fake get method
        def get(self, *args, **kwargs):
            return []

    class FakeAction(object):
        # Fake run method
        def run(self, *args, **kwargs):
            return dict()

    class FakeLoader(object):
        # Fake action_loader
        action_loader = FakeModule()

    class FakeTask(object):
        # Fake args variable

        args = dict()

    class FakeTemplar(object):
        # Fale method
        def __init__(self):
            self.shared_loader_obj = FakeLoader()

        def template(self, *args, **kwargs):
            return ""

    action_module = ActionModule()
    action_module._task = FakeTask()
    action_module._templar = FakeTemplar()

# Generated at 2022-06-11 12:44:00.324747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'hostname'
    z = ActionModule(hostname)
    assert z

# Generated at 2022-06-11 12:44:41.383620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    #self.assertEqual(True, False)
    pass

# Generated at 2022-06-11 12:44:48.278636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    test_args = dict(cmd='echo 1')
    task = dict(action=dict(module='shell', args=test_args))
    task_vars = dict()
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    action_plugin = ansible.plugins.action.shell.ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=shared_loader_obj
    )
    result = action_plugin.run(task_vars=task_vars)
    assert result['stdout'] == '1'

# Generated at 2022-06-11 12:44:56.256732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test setup
    task_args = {'_uses_shell': True}
    class MockTask:
        def __init__(self):
            self.args = task_args
    class MockTemplar:
        def __init__(self):
            self.template_result = None
        def template(self, variable):
            return variable
    class MockCommandAction:
        def __init__(self):
            self.run_result = None
        def run(self, task_vars=None):
            return self.run_result

    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._templar = MockTemplar()
    action_module._shared_loader_obj = MockCommandAction()

    # Test action module run

# Generated at 2022-06-11 12:44:59.568652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, shared_loader_obj=None, task=None, connection=None,
                                 play_context=None, loader_path=None, templar=None,
                                 passwords=None)
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:45:02.021138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    test_object = ActionModule()
    test_object.run(task_vars={'ansible_check_mode': False})

# Generated at 2022-06-11 12:45:04.042224
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    command_action_object = command_action()
    assert command_action_object.test_run() == {'msg': 'hello world', 'rc': 0}



# Generated at 2022-06-11 12:45:12.715120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'HOME': '/', 'PATH': '/usr/bin'}
    task_vars['ansible_shell_type'] = 'csh'
    class FakeActionBase:
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

# Generated at 2022-06-11 12:45:20.739934
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockTask:
        args = {'_uses_shell': True}

    class MockSharedLoaderObj:
        def __init__(self):
            self.action_loader = None

    class MockTemplar:
        def __init__(self):
            self.template = 'template'
            self.template_ds = 'template_ds'

        def template(self, template, **kwargs):
            return 'template'

    class MockLoader:
        def __init__(self):
            self.get_basedir = 'get_basedir'
            self.path_dwim = 'path_dwim'

    class MockPlayContext:
        def __init__(self):
            self.become_user = None
            self.become_method = None
            self.connection = None
            self.remote_

# Generated at 2022-06-11 12:45:23.806077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    #create the object
    am = ActionModule(None, None, None, None, None, None)
    
    tmp = None
    task_vars = {}
    
    # Invoke run method of class ActionModule
    assert am.run(tmp, task_vars) == {}

# Generated at 2022-06-11 12:45:24.316721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:46:45.188721
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:46:54.100384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes

    from ansible.plugins.loader import connection_loader
    from ansible.plugins.connection.local import Connection as LocalConnection

    from ansible.module_utils.six.moves.queue import Queue
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.action.command import ActionModule as CommandModule

    from ansible.utils.display import Display

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.template import Templar

    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrack

# Generated at 2022-06-11 12:47:01.013839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule

    def test_load_module_spec(self, task_vars=None):
        del task_vars  # not used
        return None

    import json

    m_dict = {
                "ansible_job_id": "1277543730.5285",
                "ansible_facts": {
                    "discovered_interpreter_python": "/usr/bin/python"
                },
                "changed": False,
                "ping": "pong"
            }

    m_json = json.dumps(m_dict)

    import ansible.plugins.loader as plugin_loader

    m_collection_loader = plugin_loader.ActionModuleLoader
    m_shared_loader_obj = m_collection_loader._create_shared_loader_obj()


# Generated at 2022-06-11 12:47:04.302873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actionModule.run()

# Generated at 2022-06-11 12:47:05.113539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:47:12.986044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test case.
    test_task = {
        'action': {
            '__ansible_module__': 'ansible.legacy.shell'
        },
        'args': {
            '_uses_shell': True
        }
    }
    # Create a class.
    test_class = ActionModule(
        task=test_task,
        connection='connection',
        play_context='play_context',
        loader='loader',
        templar='templar',
        shared_loader_obj='shared_loader_obj'
    )
    # Call method run.
    result = test_class.run()
    # Check the result.

# Generated at 2022-06-11 12:47:20.667872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    import ansible.utils.vars
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.inventory import MockInventory
    from units.mock.connection import MockConnection
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    mock_connection = MockConnection(play_context=PlayContext(), new_stdin=None)
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context

# Generated at 2022-06-11 12:47:28.004622
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.command import ActionModule as command_ActionModule

    # Test variables
    tmp = None
    task_vars = {}
    play_context = PlayContext()
    task = {
        'id' : '',
        'name' : 'shell',
        'args' : {
            '_raw_params' : 'echo "hello, world"',
            '_uses_shell' : True,
        },
        'module_name' : 'command',
        'module_vars' : {},
        'action_args' : {},
        'action' : 'echo "hello, world"',
    }

    # Test Code

# Generated at 2022-06-11 12:47:35.915508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        pass
    mock_taskvars = {
        'ansible_facts': {
            'ansible_os_family': 'Debian',
            'ansible_distribution_major_version': '9'
        },
        'ansible_pkg_mgr': 'apt',
        'ansible_all_ipv4_addresses': ['192.168.1.1']
    }
    class MockTask():
        def __init__(self):
            self.action = 'shell'
            self.async_val = 0
            self.async_jid = None

# Generated at 2022-06-11 12:47:39.219177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task={'args': {'_raw_params': 'uptime'}}, connection={}, play_context={}, loader={}, templar=None, shared_loader_obj={})
    result = am.run(task_vars={})
    print(result)
    assert result