

# Generated at 2022-06-11 12:39:13.670535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:39:23.004419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    parameters = []
    parameters.append(['shell', 'whoami', 'tty', 'whoami'])
    parameters.append(['shell', 'whoami && echo hello', 'tty', 'whoami'])

    for i in range(0, len(parameters)):
        action_module = ActionModule()
        task = {
            'name': parameters[i][0],
            'args': {
                '_raw_params': parameters[i][1].strip()
            }
        }
        task_vars = {
            'ansible_check_mode': True,
            'ansible_shell_executable': parameters[i][2]
        }
        result = action_module.run(task_vars=task_vars, task=task)
        print('')

# Generated at 2022-06-11 12:39:32.271201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    import io
    import sys
    import yaml
    class Module1(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

# Generated at 2022-06-11 12:39:36.063628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    data = [ "mkdir", "ls"]
    # no parameters , inheriting
    result = actionModule.run(data,None)
    assert result == "test"

test_ActionModule_run()

# Generated at 2022-06-11 12:39:37.803046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    r = a.run({},{})
    assert r['failed'] == True

# Generated at 2022-06-11 12:39:47.185504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_args = {}
    mock_task = {'args': mock_args}
    mock_connection = {}
    mock_play_context = {}
    mock_loader = {}
    mock_shared_loader_obj = {}
    mock_tmp = {}
    mock_task_vars = {}
    # 
    am = ActionModule(name='mock_action', task=mock_task, connection=mock_connection,
        play_context=mock_play_context, loader=mock_loader, shared_loader_obj=mock_shared_loader_obj)
    #
    mock_command_action = {'run': lambda task_vars: task_vars}

# Generated at 2022-06-11 12:39:57.056930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_module = 'ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule'
    mock_action_base = 'ansible_collections.ansible.builtin.plugins.action.ActionBase'
    mock_command = 'ansible_collections.ansible.builtin.plugins.action.command.ActionModule'

    # Testcase 1: 
    # Tested method: run() of class ActionModule
    # Action: 
    # 1. Create an instance of class AnsibleModule
    # 2. Create an instance of class ActionBase
    # 3. Create an instance of class Command
    # 4. Create an instance of class ActionModule
    # 5. Invoke run() method of class ActionModule
    # Verification:
    # 1. Assert that result is not None
    # 2.

# Generated at 2022-06-11 12:39:57.666188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:09.185874
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:40:20.378570
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create action module
    action_module = ActionModule()
    
    # Create task
    task = {'args': {'_uses_shell': True}}
    action_module._task = task

    # Create command action
    command_action = {'run': lambda task_vars: True}
    action_module._loader = None
    action_module._connection = None
    action_module._play_context = None
    action_module._templar = None
    action_module._shared_loader_obj = {'action_loader': {'get': lambda task, connection, play_context, loader, templar, shared_loader_obj: command_action}}
    
    # Test method run
    assert action_module.run(tmp=None, task_vars=None) == True



# Generated at 2022-06-11 12:40:33.112589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.legacy.plugins.action.shell as shell
    from ansible.legacy.plugins.action.command import ActionModule as CommandActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence

    display = Display()
    display.verbosity = 0
    loader = DataLoader()

# Generated at 2022-06-11 12:40:34.566329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_self = MagicMock()
    m_self.run.return_value = 'test_result'
    m_instance = ActionModule(m_self)

    result = m_instance.run()

    assert result == 'test_result'
    m_self.assert_called_once_with()

# Generated at 2022-06-11 12:40:44.286921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_action = ActionModule()
    my_action._task.args['_uses_shell'] = True
    my_action._task.action = 'shell'
    my_action._task.args = dict()
    my_action._task.args['_raw_params'] = 'exit 0'
    my_action._task.args['chdir'] = 'test_dir'
    my_action._task.args['creates'] = 'test_file'
    my_action._task.args['executable'] = '/bin/sh'
    my_action._task.args['removes'] = 'test_file'
    my_action._task.args['warn'] = False
    my_action._play_context = dict()
    my_action._play_context['prompt'] = None
    my_action._play_context['password']

# Generated at 2022-06-11 12:40:46.797604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ra = ActionModule()
    task_vars = {}
    result = ra.run(None, task_vars)
    assert result == {'foo': 'bar', 'language': 'python'}

# Generated at 2022-06-11 12:40:47.386710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:48.270658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "FIXME"

# Generated at 2022-06-11 12:40:49.442379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run()

# Generated at 2022-06-11 12:40:50.014491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:00.178732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_text

    mock_self = ImmutableDict({
        # self._task.args['_uses_shell']
        '_task': ImmutableDict({'args': ImmutableDict({})}),
        '_connection': ImmutableDict(),
        '_play_context': ImmutableDict(),
        '_loader': ImmutableDict(),
        '_templar': ImmutableDict(),
        '_shared_loader_obj': None
    })

    real_result = None


# Generated at 2022-06-11 12:41:01.872564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit test for method run of class ActionModule'''

    # Add your unit test here
    # assert ...

# Generated at 2022-06-11 12:41:15.090846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import the module
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.loader import action_loader

    # import fabric connection
    from ansible.connection import Connection
    from ansible.context import context

    # create a mock task
    task = dict()
    # create a mock task args
    task['args'] = dict()
    # mock task args contains "command"
    task['args']['command'] = "echo Hello World"

    # create a mock host
    host = dict()
    host['hostname'] = 'localhost'
    connection = dict()

    # create a mock inventory
    inventory = dict()
    inventory['hosts'] = dict()
    # host should be in inventory hosts
    inventory['hosts']['localhost'] = host

    # create a mock connection
    connection = Connection

# Generated at 2022-06-11 12:41:24.170121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a._connection = 'local'
    a._task = dict()
    a._task['args'] = dict()
    a._task['args']['_uses_shell'] = False
    a._shared_loader_obj = 'obj'
    a._loader = 'loader'
    a._templar = 'templar'
    a._task = dict()
    a._task['args'] = dict()
    a._task['args']['_uses_shell'] = False
    tmp = 'tmp'
    task_vars = dict()
    task_vars['test'] = 'test'

# Generated at 2022-06-11 12:41:25.573944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO(retr0h): Implement unit tests
    pass

# Generated at 2022-06-11 12:41:35.056018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Connection(object):
        def __init__(self):
            pass

    class ModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return task_vars

    class TaskTest(object):
        def __init__(self):
            pass

    class PlayContextTest(object):
        def __init__(self):
            pass

    class LoaderTest(object):
        def __init__(self):
            pass

    class TemplarTest(object):
        def __init__(self):
            pass

    class SharedLoaderObjTest(object):
        def __init__(self):
            pass

    connection = Connection()
    module = ModuleTest(connection=connection)
    task = TaskTest()
    task.args = {'_uses_shell': True}
    module._

# Generated at 2022-06-11 12:41:40.479997
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    return_value = '{"changed": false, "invocation": {"module_name": "ansible.legacy.shell"}, "ansible_loop_var": "item", "item": {"key": "value"}}'

    class FakeConnection():
        pass

    class FakeLoader():
        pass

    class FakeTask():

        def __init__(self):
            self.args = {
                'commands': ['command'],
                'creates': None,
                'executable': '/bin/sh',
                'removes': None,
                'warn': True,
                '_uses_shell': True,
                'chdir': None
            }


# Generated at 2022-06-11 12:41:51.011066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_dict=[{"_ansible_ignore_errors": None, "_ansible_no_log": [], "_ansible_parsed": True,
    "_ansible_facts": None, "_ansible_item_result": False, "_ansible_diff": {}, "_ansible_delegated_vars": {},
    "stderr": "/bin/sh: 1: cannot create /tmp/ansible-tmp-1464124438.22-152834592862854/command.sh: Directory nonexistent\r\n",
    "stdout": "", "stdout_lines": [], "warnings": []}]


# Generated at 2022-06-11 12:41:52.013153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-11 12:41:57.499777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = Task(args={'_uses_shell': True})
    action_module._shared_loader_obj = SharedLoader(exit_msg=None)
    command_action = ActionModule()
    command_action.run = lambda x: True
    action_module._shared_loader_obj.action_loader.get = lambda x, y, z, a, b, c, d: command_action
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:41:59.338605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\nChecking method run of class module ActionModule for class ActionModule')
    actionModule = ActionModule()
    actionModule.run()


# Generated at 2022-06-11 12:42:02.690547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to do a bit of fancy footwork to construct a valid task.
    import ansible.plugins.action
    ActionModule.run(ansible.plugins.action.ActionBase)
# Test if the unit test is working
test_ActionModule_run()

# Generated at 2022-06-11 12:42:11.217289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:11.888308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:20.577369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    import mock

    mock_tmp = None

    class MockModule(object):
        """This is a mock object for module"""

    class MockTask(object):
        """This is a mock object for task"""

        def __init__(self):
            self.args = {}
            self.module = MockModule()
            self.action = 'shell'

    class MockResult(object):
        """This is a mock object for result"""

        def __init__(self):
            self.result = {}
            self.rc = 0
            self.stdout = ''

    class MockTaskVars(object):
        """This is a mock object for task_vars"""

        def __init__(self):
            self.result = {}


# Generated at 2022-06-11 12:42:30.796953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.compat.tests.mock import patch
    from ansible.plugins.loader import action_loader

    test_task = dict(
        action='shell',
        args={'_uses_shell': True},
        delegate_to=None,
        delegate_facts=None,
        free_form=None,
    )

    test_task_vars = dict()

    test_result = dict(
        rc=0,
        stdout="",
        stderr="",
        stdout_lines=[],
        stderr_lines=[],
        changed=False,
        ansible_facts={},
    )


# Generated at 2022-06-11 12:42:38.284976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.Shell import ActionModule
    actionModule = ActionModule()
    actionModule._task = dict()
    actionModule._task['args'] = dict()
    actionModule._task['args']['_uses_shell'] = False
    actionModule._shared_loader_obj = dict()
    actionModule._shared_loader_obj.action_loader = dict()
    actionModule._shared_loader_obj.action_loader.get = lambda *args, **kwargs : 'Shell'
    print(actionModule.run())

# Generated at 2022-06-11 12:42:47.404023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task = {},
        connection = {},
        play_context = {},
        loader = {},
        templar = {},
        shared_loader_obj = {}
    )

    # Testing when _uses_shell is set as True
    # Setting args of task as _uses_shell
    action_module._task.args["_uses_shell"] = True
    # Setting AnsibleModule of class ActionBase to mock_command
    action_module.mock_command = mock_object()
    # Setting AnsibleModule of class ActionBase to mock_ansible_module_get
    action_module.mock_ansible_module_get = mock_object()
    # Calling the run method of class ActionModule which returns the result
    result = action_module.run()
    # Asserting the result

# Generated at 2022-06-11 12:42:56.551404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.ActionBase.checksum_succeeded = True
    mod.ActionBase._get_diff_data = True
    mod.ActionBase._low_level_execute_command = True
    mod.ActionBase._low_level_execute_command_with_prompt = True
    mod.ActionBase._run_checks = True
    mod.ActionBase.add_path_info = True
    mod.ActionBase.activate_connection = True
    mod.ActionBase.become = True
    mod.ActionBase.become_method = True
    mod.ActionBase.cleanup = True
    mod.ActionBase.deactivate_connection = True
    mod.ActionBase.display = True
    mod.ActionBase.execute_command = True
    mod.ActionBase.get_checksum = True
    mod.Action

# Generated at 2022-06-11 12:42:58.955236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  am = ActionModule( mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock())
  am.run(mock.Mock())

# Generated at 2022-06-11 12:43:07.624342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import callback_whitelist
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins import connection_loader
    from ansible.plugins import action_loader
    from ansible.plugins import module_loader
    from ansible.plugins import callback_loader
    from ansible.plugins import callback_whitelist
    from ansible.plugins import filter_

# Generated at 2022-06-11 12:43:17.556508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test.
    obj = ActionModule({})
    # TODO: We may be able create a mock for _task, _connection, _play_context,
    #       _loader, and _templar, without having to hard code.
    obj._task = {'action': {'name': 'shell'}, 'args': {'_uses_shell': True}}
    obj._connection = 'connection'
    obj._play_context = 'play_context'
    obj._loader = 'loader'
    obj._templar = 'templar'
    obj._shared_loader_obj = 'shared_loader_obj'
    # Setting up the following mock is a workaround for the lack of the
    # actual implementations of ActionBase, Command, and AnsibleAction.
    # The mocks are based on the current implementations of ActionBase,
    #

# Generated at 2022-06-11 12:43:42.498730
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockTask(object):
        def __init__(self):
            self.args = {'_uses_shell': False}

    class MockTaskVars(object):
        def __init__(self):
            self.hostvars = {}

    class MockActionBase(object):
        def __init__(self):
            self._task = MockTask()
            self._loader = None
            self._connection = None
            self._play_context = None
            self._templar = None
            self._shared_loader_obj = None

    class MockSharedLoaderObj(object):
        def __init__(self):
            self.action_loader = None

    class MockActionLoader(object):
        def __init__(self):
            self.command = None


# Generated at 2022-06-11 12:43:43.109332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:51.750986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test to get the action plugin for 'command'
    """
    tmp = None
    task_vars = None
    test = ActionModule(tmp, task_vars)
    res = test.run(tmp, task_vars)
    assert res == {'_ansible_no_log': False, '_ansible_module_generated': True, '_ansible_parsed': True, '_ansible_verbose_always': True, '_ansible_version': '2.6.3', '_ansible_module_name': 'command'}

# Generated at 2022-06-11 12:43:53.770665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    a=ActionModule()
    a.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:43:55.220278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test set up

    # Test run
    result = ActionModule()

# Generated at 2022-06-11 12:43:55.736476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:56.122188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:57.397904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	#from action_plugins.lib.actions_module import 
	return True

# Generated at 2022-06-11 12:44:04.598072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_options = {'connection': 'smart',
                       'module_path': '/path/to/mymodules',
                       'forks': 10,
                       'become': None,
                       'remote_user': 'myuser',
                       'private_key_file': None,
                       'ssh_common_args': '',
                       'ssh_extra_args': '',
                       'sftp_extra_args': '',
                       'scp_extra_args': '',
                       'become_method': 'sudo',
                       'become_user': None,
                       'verbosity': 3,
                       'check': False,
                       'diff': False}
    ansible_host = 'host1'
    ansible_play_name = 'test_play'
    ansible_play_id = '1'
    ansible_play

# Generated at 2022-06-11 12:44:12.096558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import basic_plugins

    cls = basic_plugins.ActionModule
    # initialize the object
    obj = cls()

    # register the object in the registry
    registry.register(obj)

    cls = action.ActionModule
    # initialize the object
    obj = cls()

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)

    # register the object in the registry
    registry.register(obj)


# Generated at 2022-06-11 12:44:59.562359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest.mock import Mock, patch
    from ansible import constants as C

    module_name = __name__
    if module_name.endswith(".py"):
        module_name = module_name[:-3]

    tmp = '/tmp'
    command_module = 'ansible.legacy.command'
    task_vars = Mock()
    action_base = Mock(task_vars=task_vars)
    task_base = Mock(args={'_uses_shell': True})
    connection_base = Mock()
    play_context_base = Mock()
    loader_base = Mock()
    templar_base = Mock()
    shared_loader_obj_base = Mock()
    action_loader_base = Mock(get=Mock(return_value=action_base))
    shared

# Generated at 2022-06-11 12:45:07.626445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell as shell
    import ansible.plugins.action.command as command
    import ansible.plugins.loader as loader
    import ansible.plugins.action as action
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    test_host = Host(name='test_host', port=2222)
    test_host.set_variable('ansible_connection', 'ssh')
    test_host.set_variable('ansible_user', 'joe')
    test_host.set_variable('ansible_ssh_private_key_file', 'key_file.txt')
    test_host.set_variable('ansible_ssh_args', '-C -o ControlMaster=auto -o ControlPersist=60s')

# Generated at 2022-06-11 12:45:16.485554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule"""
    # Create a mock AnsibleModule object
    ansible_mod = AnsibleModuleMock()
    # Create a mock AnsibleModule argument spec
    arg_spec = {
        'command': {"type": "str", "required": False}
    }
    # Create a mock AnsibleModule argument check
    check_args = MagicMock()
    ansible_mod.check_args = check_args
    # Create a mock AnsibleModule argument parse
    parse_args = MagicMock()
    ansible_mod.parse_args = parse_args
    # Create a mock AnsibleModule argument exit
    exit_json = MagicMock()
    ansible_mod.exit_json = exit_json
    # Create an instance of the class ActionModule

# Generated at 2022-06-11 12:45:17.542340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule('tmp', 'task_vars')
    print(am)

# Generated at 2022-06-11 12:45:25.534339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    import logging

    class FakeActionLoader(object):
        def __init__(self):
            self.commands = {'ansible.legacy.command': FakeCommandAction()}
    class FakeCommandAction(object):
        def __init__(self):
            self.run = lambda task_vars: {'msg': 'fake'}

    FORCE_COLOR = False
    FIXTURES_PATH = './tests/unit/plugins/action/fixtures/'

    task = AnsibleModule(argument_spec=dict(),
                         supports_check_mode=True)


# Generated at 2022-06-11 12:45:26.453438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:45:32.312759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock a ActionModule instance
    am = ActionModule()

    # mock a Connection instance
    c = Connection()
    c.connection_lock = False
    c.set_options()

    # mock a Task instance
    t = Task()

    # mock a task_vars dict
    task_vars = dict()

    # call method run of class ActionModule
    print(am.run(tmp=None, task_vars=task_vars))

# Generated at 2022-06-11 12:45:41.210016
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:45:51.275905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #create mock
    test_am = ActionModule('module_name', 'action_name', 'task', 'connection', 'play_context', 'loader', 'templar', 'shared_loader_obj')
    test_am._task.args = {'_uses_shell': False}

    #run method with mocked data
    result = test_am.run()

# Generated at 2022-06-11 12:45:52.194568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run()

# Generated at 2022-06-11 12:47:19.881617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:47:27.320909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple

    MockConnection = namedtuple('MockConnection', ('_play_context', '_loader'))
    connection = MockConnection(
        _play_context=namedtuple('PlayContext', ('become', 'become_user', 'become_method', 'become_flags')),
        _loader=namedtuple('Loader', ('get_basedir'))
    )

# Generated at 2022-06-11 12:47:34.003825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.ansible_modlib._text import to_bytes

    from ansible.plugins.action import ActionModule

    action_module = ActionModule()

    # Make some fake data about the module and its execution environment
    fake_task = {
        'args': {},
    }
    action_module.__dict__.update(fake_task)
    fake_task_vars = {}

    # Call the method being tested
    action_module.run(task_vars=fake_task_vars)

    # Assert that the '_uses_shell' key was set in the task args
    assert '_uses_shell' in action_module.args

# Generated at 2022-06-11 12:47:35.338181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
   # assert module.run() == 'test string'


# Generated at 2022-06-11 12:47:35.880891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    

# Generated at 2022-06-11 12:47:42.409781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task = {}
    fake_action_loader = {}
    fake_connection = {}
    fake_play_context = {}
    fake_loader = {}
    fake_templar = {}
    fake_shared_loader_obj = {}
    fake_task_vars = {}

    action_module = ActionModule(fake_task, fake_action_loader, fake_connection, fake_play_context, fake_loader, fake_templar, fake_shared_loader_obj)
    action_module_result = action_module.run(tmp='fake_tmp', task_vars=fake_task_vars)
    assert action_module_result is not None

# Generated at 2022-06-11 12:47:51.594661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types
    import unittest
    import unittest.mock as mock
    import ansible.plugins.action
    import ansible.plugins.action.legacy_command
    import ansible.plugins.action.shell

    class ModuleUnderTest(ansible.plugins.action.shell.ActionModule):
        def __init__(self):
            self._task = mock.Mock()
            self._connection = mock.Mock()
            self._play_context = mock.Mock()
            self._loader = mock.Mock()
            self._templar = mock.Mock()
            self._shared_loader_obj = mock.Mock()

    class ActionLoader:
        def __init__(self):
            self.action_loader = mock.Mock()


# Generated at 2022-06-11 12:47:58.870374
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.connection.local import Connection
    from ansible.plugins.loader import PluginLoader
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.display import Display

    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.mock import patch


# Generated at 2022-06-11 12:48:02.321749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module1 = ActionModule(
                           task = None,
                           connection = None,
                           play_context = None,
                           loader = None,
                           templar = None,
                           shared_loader_obj = None
                          )
    assert module1.run(tmp=None, task_vars=None) == None

# Generated at 2022-06-11 12:48:11.274043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method with wrong parameters
    """

    class MockActionModule:
        def __init__(self, action, task, connection, play_context, loader, templar, shared_loader_obj):
            pass

        def run(self, tmp=None, task_vars=None):
            pass

    class MockActionBase:
        def get(self, name, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            return MockActionModule(name, task=task, connection=connection, play_context=play_context,
                                    loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)
