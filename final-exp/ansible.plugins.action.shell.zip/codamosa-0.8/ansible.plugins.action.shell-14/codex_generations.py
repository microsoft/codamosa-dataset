

# Generated at 2022-06-11 12:39:16.596601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    test_ActionModule_run is a test for method run of class ActionModule
    """
    # setup test variables
    tmp = None
    task_vars = None
    action_module_object = ActionModule(connection=None, play_context=None, task=None, loader=None, templar=None, shared_loader_obj=None)
    
    # test regular use of method run
    res = action_module_object.run(tmp, task_vars)
    assert res is not None

# Generated at 2022-06-11 12:39:25.824004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    args = dict(
        _uses_shell = True,
        chdir = '/',
        executable = None,
        removes = None,
        warn = True,
        args = 'pwd',
        creates = None,
        removes = None,
        executable = None,
        chdir = None,
        _raw_params = 'pwd',
        _uses_shell = True,
        _uses_shell = None,
        _uses_shell = False,
        _uses_shell = True
    )
    _task = dict(
        args = args
    )
    action._task = _task


# Generated at 2022-06-11 12:39:35.768018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Setup
    connection = 'local'
    play_context = {
        'play': {},
        'task': {},
        'variable_manager': None,
        'loader': None,
    }
    expanded = {
        'ansible_facts': {},
        '_ansible_verbs': [],
        '_ansible_no_log': False,
        '_ansible_no_log_posts': [],
    }
    tmp = None
    task_vars = {
        'var': 'value',
    }
    loader = None
    templar = None
    shared_loader_obj = None
    _ansible_version = '2.7.0.dev0'

# Generated at 2022-06-11 12:39:44.319173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test run() without error conditional
    action = ActionModule()
    task = get_fake_task('shell')
    task._shared_loader_obj = get_fake_loader()
    task._loader = get_fake_loader()
    task._connection = 'local'
    task._play_context = get_fake_play_context()
    action._task = task

    action._task.args['_uses_shell'] = False
    action._task.args['creates'] = None
    action._task.args['removes'] = None
    res = action.run(task_vars={})
    assert res['rc'] == 0
    assert res['_ansible_verbose_always'] is True


# generate fake object

# Generated at 2022-06-11 12:39:54.086593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Setup testing environment
    class ActionModuleTest:
        def __init__(self, task_vars):
            self._task_vars = task_vars
        @property
        def _connection(self):
            return None
        @property
        def _loader(self):
            return None
        @property
        def _templar(self):
            return None
        @property
        def _play_context(self):
            return None
        @property
        def _shared_loader_obj(self):
            return None

    class Task:
        def __init__(self, task_args):
            self.args = task_args
    task_args = {'_uses_shell':True}
    task_vars = {}
    task_vars['_raw_params'] = 'ls -l'
   

# Generated at 2022-06-11 12:40:05.671633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(connection='connection',
                      play_context='play_context',
                      loader='loader',
                      templar='templar',
                      shared_loader_obj='shared_loader_obj',
                      task_vars='task_vars')
    tmp = 'tmp'
    task_vars = dict(ansible_play_hosts=['localhost'], ansible_connection='local', ansible_python_interpreter='/usr/bin/python', ansible_python_version='2.7.5')
    am._task.args = dict(_ansible_parsed=False, _uses_shell=True, chdir=None, creates='', executable='/bin/bash', removes='', stdin='', warn=True)
    am._task.action = 'shell'

# Generated at 2022-06-11 12:40:11.157808
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module            = ActionModule()
    module._task      = None
    module._connection= None
    module._play_context = None
    module._loader    = None
    module._templar   = None
    module._shared_loader_obj = None
    task_vars         = dict()

    task_vars         = dict()

    result = module.run(tmp=None,task_vars=task_vars)

    assert (result['failed'] > 0)

# Generated at 2022-06-11 12:40:15.478166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None

    action_module = ansible_runner.ActionModule(tmp, task_vars)
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    assert result == True

# Generated at 2022-06-11 12:40:26.651222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import doctest
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils._text import to_bytes

    doctest.testmod(sys.modules[ActionBase.__module__])
    doctest.testmod(sys.modules[ActionModule.__module__])

    command_action = ActionModule()

# Generated at 2022-06-11 12:40:27.687077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    obj = ActionModule()
    # Invoke method run of the class
    result = obj.run()
    # Assert the result
    assert True == result

# Generated at 2022-06-11 12:40:30.259080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:37.353327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    t = TaskInclude()
    p = PlayContext()
    t._task.args['_raw_params'] = 'echo this is a test'

    action_module = ActionModule(t,p)

    result = action_module.run()

    assert result is not None
    assert result['failed'] == False

# Generated at 2022-06-11 12:40:45.933548
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task = {
        'args': {
            '_uses_shell': True
        }
    }

    module = ActionModule()

    tmp = None

    with patch.object(ActionBase, 'run', return_value=task) as mock_run:
        module.run(tmp, task_vars=None)
        mock_run.assert_called_once_with(task_vars=None)

# Generated at 2022-06-11 12:40:55.844358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.six import StringIO

    tmp = tempfile.mkdtemp()
    task_vars = dict()
    connection = StringIO()
    play_context = StringIO()
    loader = StringIO()
    templar = StringIO()
    shared_loader_obj = StringIO()

    task = dict()

    am = action_loader.get('shell', task=task, connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)
    results = am.run(tmp, task_vars)

    assert(results['_ansible_verbose_always'] == True)

# Generated at 2022-06-11 12:40:56.456188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:06.116123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialising test objects for test_ActionModule_run
    test_ActionModule_run_action_module = ActionModule()
    test_ActionModule_run_action_module._task = object()
    test_ActionModule_run_action_module._task.args = {'_uses_shell': True}
    test_ActionModule_run_action_module._shared_loader_obj = object()
    test_ActionModule_run_action_module._shared_loader_obj.action_loader = object()
    test_ActionModule_run_action_module._shared_loader_obj.action_loader.get = lambda *args: test_ActionModule_run_action_module
    test_ActionModule_run_action_module._connection = object()
    test_ActionModule_run_action_module._play_context = object()
    test_ActionModule

# Generated at 2022-06-11 12:41:10.596979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ac = ActionModule()
    vm = VariableManager()

# calling run with argument tmp=None and task_vars=None
    ac.run(None, None)
    ac.run()

# Generated at 2022-06-11 12:41:12.463506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    print(ansible.plugins.action.ActionModule)
    # TODO: This test is incomplete

# Generated at 2022-06-11 12:41:13.065660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:22.674103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.vars.reserved import DEFAULT_VAULTROLE
    # First, let's mock the object
    tmp = None


# Generated at 2022-06-11 12:41:34.218799
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Create objects for unit testing.

# Generated at 2022-06-11 12:41:43.935035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_action = CommandAction(None, None, None, None, None)
    result = command_action.run(None)

# Generated at 2022-06-11 12:41:54.361127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup arguments passed to module
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import ActionModuleLoader

    fake_task_vars = dict()
    fake_task_vars['ansible_connection'] = 'local'
    fake_task_vars['ansible_inventory_hostname'] = 'localhost'
    fake_task_vars['ansible_host'] = '127.0.0.1'
    fake_task_vars['ansible_working_dir'] = '/home/user/ansible'
    fake_task_vars['ansible_config'] = u'/etc/ansible/ansible.cfg'
    fake_task_vars['ansible_playbook'] = 'testfile.yml'


# Generated at 2022-06-11 12:41:55.147602
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pdb; pdb.set_trace()
    pass

# Generated at 2022-06-11 12:41:58.821696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = common.AnsibleModule({}, {}, [], True, None, None, {}, 'ansible.legacy.shell')
    module.command = 'echo'
    module.params = {
        '_raw_params': ['echo'],
    }

    module_result = ActionModule.run(None, None)

    assert module_result['cmd'] == ['echo']

# Generated at 2022-06-11 12:41:59.269449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:09.345325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = dict()
    module._task.args['_uses_shell'] = True
    module._loader = dict()
    module._loader['paths'] = []
    module._shared_loader_obj = dict()
    module._shared_loader_obj['action_loader'] = dict()

    module._connection = dict()
    module._connection['transport'] = 'local'
    module._connection['module_implementation_preferences'] = ['local']

    module._play_context = dict()
    module._play_context['become_method'] = 'become'
    module._play_context['become_user'] = 'become'
    module._play_context['network_os'] = 'network_os'

    command_action = dict()
    command_action['run']

# Generated at 2022-06-11 12:42:19.125625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash


    class _loader_mock(object):

        def __init__(self):
            self.path_cache = {'selftest': ['/selftest/path']}


    class _shared_loader_obj_mock(object):

        def __init__(self):
            self.action_loader = _action_loader_mock()


    class _action_loader_mock(object):

        def __init__(self):
            pass


# Generated at 2022-06-11 12:42:25.455160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test if method run return correct value with no args
    """
    # Arrange
    class MockActionBase(object):
        def __init__(self):
            pass

        def run(self, tmp=None, task_vars=None):
            return True

    action_module = ActionModule()
    # check if tmp has any affect on run
    action_module._task.args['_uses_shell'] = False
    action_module._shared_loader_obj = MockActionBase()
    # Act
    result = action_module.run()
    # Assert
    assert result == True

# Generated at 2022-06-11 12:42:27.494089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule instance
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-11 12:42:41.904291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionBaseStub:
        def __init__(self):
            self._task = {
                'args': {}
            }

    class ActionModuleTest(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = ActionBaseStub()._task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    mod = ActionModuleTest(None, None, None, None, None, None)
    # Blank task_vars should be fine.
    mod.run(task_vars={})
    # Use some dummy variables

# Generated at 2022-06-11 12:42:47.127512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_runner import Runner
    import os
    import json
    test_path = os.path.join(os.path.dirname(__file__), 'test_data', 'TEST_ActionModule_run')
    r = Runner(os.path.join(test_path, 'test.yml'), os.path.join(test_path, 'inventory'), module_path=None)
    r.run_async()
    while r.status == 'running':
        pass
    assert r.status == 'finished'

# Generated at 2022-06-11 12:42:49.535152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule

    # Test for class ActionModule exists
    assert('ActionModule' in globals())

    # Test for method run of class ActionModule exists
    assert('run' in dir(ActionModule))

# Generated at 2022-06-11 12:42:59.070376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import pytest
    import unittest.mock as mock
    from ansible.plugins.action.shell import ActionModule
    from ansible.parsing import PluginLoader, DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager
    from ansible.utils.vars import merge_hash
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    from collections import namedtuple

# Generated at 2022-06-11 12:43:00.199119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run(None, None)

# Generated at 2022-06-11 12:43:04.751424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input args
    tmp = None

    # When
    test_action = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    actual_result = test_action.run(tmp=tmp)

    # Then
    assert actual_result is None

# Generated at 2022-06-11 12:43:14.089536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    
    actions = ["ansible.legacy.shell"]
    playbook_entry = dict()
    playbook_entry['action'] = actions[0]
    playbook_entry['register'] = 'some_result'
    playbook_entry['hosts'] = 'localhost'
    playbook_entry['args'] = dict()
    playbook_entry['args']['testarg'] = 'Hello'
    playbook_entry['args']['_uses_shell'] = 'Nope'
    playbook = [playbook_entry]
    mock = MockModule()
    task_vars = dict()
    mock_play_context = MockPlayContext()
    mock_play_context.become = False
    mock_play_context.become_user = 'root'
    mock_play_context.become

# Generated at 2022-06-11 12:43:15.064269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:19.941007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up units to be tested
    module = ActionModule(loader=None,
                          connection=None,
                          play_context=None,
                          loader_obj=None,
                          templar=None,
                          shared_loader_obj=None,
                          **{'task': None})

    # Assert units
    assert module.run(tmp=None, task_vars=None) == None

# Generated at 2022-06-11 12:43:26.286805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    module = mock.MagicMock()
    module.run.return_value = None

    command_action = mock.MagicMock()

    action_base = mock.MagicMock()
    action_base._task.args = {'_uses_shell': True}
    action_base._shared_loader_obj.action_loader.get.return_value = command_action

    action_module = ActionModule(action_base)
    result = action_module.run(task_vars=None)

    assert command_action.run.called

# Generated at 2022-06-11 12:43:44.278925
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: updates needed
    return

    import json
    from cStringIO import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleError

    class TestCallbackModule(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__(*args, **kwargs)
            self.events = []
            self.runner_results = []
            self.host_

# Generated at 2022-06-11 12:43:51.821811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check that run returns an exit_status
    action_module = core.ActionModule()
    task = core.Task()
    action_module.set_loader(core.DictDataLoader({}))
    action_module.set_task(task)

    task.args = {'_uses_shell': True}
    task.action = 'ansible.legacy.shell'
    result = action_module.run()

    assert 'exit_status' in result


# Generated at 2022-06-11 12:43:53.870379
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # execute the method run
    result = module.run()

    print("test result:", result)

# Generated at 2022-06-11 12:43:56.670287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action = ActionModule()

    result = action.run(task_vars=task_vars)

    assert result is not None
    assert result['failed'] is False


# Generated at 2022-06-11 12:43:57.917109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #This test is only needed here to bypass pylint checks
    pass

# Generated at 2022-06-11 12:44:04.930689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN a random module to mock
    import ansible.plugins.__init__ as plugins

    mock_ActionBase = MockModule(
        run=MagicMock(),
    )

    mock_ActionBase.run.return_value = "Return value for ActionModule.run"
    mock_mark_host_failed = MagicMock()

    # GIVEN a module to mock
    import ansible.executor.__init__ as executor

    mock_executor = MockModule(
        task_executor=MagicMock(
            mark_host_failed=mock_mark_host_failed,
        ),
    )

    # GIVEN a module to mock
    import ansible.plugins.loader as plugins_loader
    from ansible.plugins.loader import shared_loader_obj


# Generated at 2022-06-11 12:44:12.394972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import module_kwargs
    from ansible.module_utils import common
    from ansible.module_utils._text import to_bytes
    def FailModule_run(self, tmp=None, task_vars=None):
        print("test failure message")

    def SuccessModule_run(self, tmp=None, task_vars=None):
        return "test success message"

    test_action_module = ActionModule()
    assert hasattr(test_action_module, 'run')

    # Mock module_utils.module_kwargs.module_kwargs to test failure case
    module_kwargs.module_kwargs = FailModule_run
    test_action_module.run()
    test_action_module._shared_loader_obj.action_loader.run = FailModule_run
    test_action

# Generated at 2022-06-11 12:44:20.056696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    from ansible.plugins.action import ActionBase
    import ansible.playbook.task
    import ansible.template
    import ansible.utils.vars
    import ansible.vars.manager

    # Create a temporary plugin path for testing.
    fake_plugin_path = tempfile.mkdtemp()
    # Set the ANSIBLE_ACTION_PLUGINS environment variable to the temporary plugin path.
    os.environ[ansible.plugins.ACTION_PLUGIN_PATH] = fake_plugin_path
    # Enable caching of the plugin loaders.
    ansible.plugins.ACTION_CACHE = True

    yml_dict = dict()

# Generated at 2022-06-11 12:44:27.747154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader, connection, play_context, templar, shared_loader_obj = (1, 2, 3, 4, 5)
    actionmodule_instance = ActionModule(loader, connection, play_context, templar, shared_loader_obj)
    actionmodule_instance._task = {
        'args': {
            'arg1': 'value1',
            'arg2': 'value2',
            'arg3': 'value3'
        }
    }
    actionmodule_instance._shared_loader_obj = {
        'action_loader': {
            'get': get_action_loader_get_mock
        }
    }
    actionmodule_instance.run()
    assert actionmodule_instance._task['args']['_uses_shell'] == True

# Mocks

# Generated at 2022-06-11 12:44:28.275974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:56.002563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(name='ansible.legacy.shell',
                args={'_uses_shell': True},  # Shell module is implemented via command with a special arg
                )
    task_vars = dict()
    tmp = None
    action_module = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None,
                                 shared_loader_obj=None)

    result = action_module.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-11 12:44:56.712839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:44:58.384329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.run() == {}

# Generated at 2022-06-11 12:44:58.861645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:06.901820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock modules
    def mock_get(name, *args, **kwargs):
        if name == 'ansible.legacy.command':
            # Mock command action
            class mock_action():
                task = {}
                connection = None
                play_context = None
                loader = None
                templar = None
                shared_loader_obj = None

                def run(self, task_vars=None):
                    return self

            return mock_action()
        else:
            raise Exception("Not mocked: " + name)

    import ansible.plugins.action
    ansible.plugins.action.ActionBase.get = mock_get

    # Mock ActionModule
    class mock_ActionModule(ansible.plugins.action.ActionModule):
        _connection = None
        _task = {}
        _play_context = None
        _

# Generated at 2022-06-11 12:45:10.497407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Mock(spec=ActionModule)
    task._task.args = {}
    a = ActionModule(task, '/tmp/ansible_1bz22T/ansible_tmpptAKhV', '127.0.0.1', 'test')
    assert a.run() == None


# Generated at 2022-06-11 12:45:11.199244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:15.862897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    class Task:
        def __init__(self, args):
            self.args = args
    task = Task({})
    tmp = None
    task_vars = None
    action = ActionModule(task, None, None, None, None, None)
    result = action.run(tmp, task_vars)
    assert(result is not None)


# Generated at 2022-06-11 12:45:16.704554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:45:24.511734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    
    # patching
    class MockTask:
        def __init__(self, args):
            self.args = args
    
    class MockSharedLoaderObj:
        def __init__(self, action_loader, task, connection, play_context, loader, templar, shared_loader_obj):
            self.action_loader = action_loader
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
            
    class MockActionLoader:
        def __init__(self, action_loader):
            self.action_loader = action_loader
            

# Generated at 2022-06-11 12:46:10.402964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import inspect

    class MockConnection(object):
        def __init__(self):
            pass

    class MockPlayContext(object):
        def __init__(self):
            pass

    class MockTemplar(object):
        def __init__(self):
            pass

    class MockSharedLoaderObj(object):
        def __init__(self):
            self.action_loader = MockActionLoader()

    class MockActionLoader(object):
        def __init__(self):
            pass

        def get(self, name, task=None, connection=None, play_context=None, loader=None,
                templar=None, shared_loader_obj=None):
            self.obj = MockCommandAction()
            param_order = inspect.getargspec(self.obj.run)


# Generated at 2022-06-11 12:46:18.645463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.plugins.action.command import ActionModule
    from ansible_collections.ansible.community.tests.unit.plugins.action.stubs import StubActionModule, StubCommandActionModule
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    # Test with ansible.legacy.shell.ShellModule
    declared_module = 'ansible.legacy.shell'
    action_module = ActionModule(StubActionModule.Empty_Shell_Module, play_context, declared_module)
    expected_result = {
        'failed': True,
        'msg': 'One of the parameters: cmd or free_form is required',
        'unreachable': False
    }
    result = action_module.run()
   

# Generated at 2022-06-11 12:46:19.217101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:46:25.964715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init an object of class ActionModule()
    # Defined in file lib/ansible/plugins/action/shell.py
    x = ActionModule()

    # Init an object of class Command()
    # Defined in file lib/ansible/modules/commands/command.py
    command = Command()

    # Init an object of class Command()
    # Defined in file lib/ansible/plugins/action/__init__.py
    # class ActionBase(object):
    #     def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    ActionBase(command, connection, play_context, loader, templar, shared_loader_obj)

# Generated at 2022-06-11 12:46:26.485647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:46:30.390682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._shared_loader_obj = None
    module._loader = None
    module._templar = None
    module._task = None
    module._connection = None
    module._play_context = None
    result = module.run(tmp='a', task_vars='b')
    assert result == {'k':'v'}


# Generated at 2022-06-11 12:46:37.429932
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:46:46.256036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell as shell
    import ansible.executor.task_result as task_result

    # Create a fake task, that doesn't require a tmp path.
    test_task = Task()
    test_task.args = {'_uses_shell' : 'yes'}

    # Create a shell ActionModule and test if run method yields
    # a TaskResult instance.
    shell_am = ActionModule()
    shell_am._task = test_task
    shell_am._loader = None #TODO: Loader instance
    shell_am._templar = None #TODO: Templar instance
    shell_am._shared_loader_obj = None #TODO: SharedLoader obj
    shell_am._connection = None #TODO: Connection obj
    shell_am._play_context = None #T

# Generated at 2022-06-11 12:46:55.147973
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup a fake task which is used by the action module
    class FakeTask(object):
        def __init__(self):
            self.args = {}
    task_fake = FakeTask()

    class FakeModule(object):
        def __init__(self):
            self.params = {}
    module_fake = FakeModule()

    class FakeLoader(object):
        def load_from_file(self, path, *args, **kwargs):
            return module_fake
    loader_fake = FakeLoader()

    class FakeDb(object):
        def __init__(self):
            self.nodes = []
    db_fake = FakeDb()

    class FakeConnection(object):
        def __init__(self):
            self.host = 'localhost'
    connection_fake = FakeConnection()


# Generated at 2022-06-11 12:46:55.592997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:48:24.547820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    return NotImplementedError("TODO: Implement test_ActionModule_run")


# Generated at 2022-06-11 12:48:29.113787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    tmp = "n/a"
    task_vars = {"ansible_connection": "local",
                 "myvar": "myval"}
    result = module.run(tmp, task_vars)
    assert result == {"changed": True, "invocation": {"module_args": "_uses_shell=True", "module_name": "shell"}, "rc": 0, "stderr": "", "stderr_lines": []}

# Generated at 2022-06-11 12:48:29.538262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:48:36.640577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import time
    import copy
    import tempfile
    import os
    import shutil
    import sys
    import sysconfig
    import itertools
    import json
    import platform
    import stat

    import pytest

    from ansible.module_utils.six.moves import StringIO

    ansible_module_name = "unittest"
    ansible_module_args = "{'publish_time': '%d', 'delay': '5sec', 'echo': 'Hello world'}" % (int(time.time()))
    ansible_module_args = ansible_module_args.replace("'", '"')

    # Define test data

# Generated at 2022-06-11 12:48:40.540421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            args=dict(
                _uses_shell=True,
            ),
        ),
    )

    module._task.args['_uses_shell'] = True

    res = module.run()
    assert isinstance(res, dict)
    assert res['command'] == 'shell'

# Generated at 2022-06-11 12:48:47.854610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
        An unit test for method run of class ActionModule
    '''
    import json
    import re
    import subprocess
    from ansible.plugins.action import ActionBase
#   from ansible.plugins.action.command import ActionModule
    from ansible.plugins.action.systemd import ActionModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import shlex_quote
    mod_action = ActionBase()
    mod_action.__dict__['action_name'] = 'systemd'


# Generated at 2022-06-11 12:48:56.015702
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create an object to from class object ActionModule
    action_module_instance = ActionModule(
        task=MagicMock(),
        connection=MagicMock(),
        play_context=MagicMock(),
        loader=MagicMock(),
        templar=MagicMock(),
        shared_loader_obj=MagicMock()
    )

    # execute method run with value None
    action_module_instance.run(tmp=None, task_vars=None)

    # check if method run has been called correctly
    action_module_instance._task.copy.assert_called_with()
    action_module_instance._task.module_args.copy.assert_called_with()

# Generated at 2022-06-11 12:49:03.819075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule

    import unittest
    import sys
    import ansible.errors
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    class TestActionModule(unittest.TestCase):

        def setUp(self):

            self.task_vars = dict()

            # Test code gets this from the environment variable
            self.task_vars["ansible_connection"] = "local"

            # Test code gets this from the PlayContext
            self.task_vars["ansible_check_mode"] = False

            self.loader = None

            self.connection = None


# Generated at 2022-06-11 12:49:12.509267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=missing-docstring
    from ansible.plugins.action.shell import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext

    from ansible.utils.vars import merge_hash

    class TestRunner(object):

        def __init__(self, host_name):
            self.host_name = host_name

    class TestTask(object):
        # pylint: disable=too-many-arguments
        def __init__(self, args=dict(), action=None, task_vars=dict(), task_action=None,
                     runner_name='localhost', loader_name='DummyLoader', templar=None,
                     shared_action_plugin=None, action_loader=None):
            self.args = args