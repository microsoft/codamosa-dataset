

# Generated at 2022-06-11 12:39:08.999230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:10.303763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    r = ActionModule(load_plugins=False).run()
    assert r is None


# Generated at 2022-06-11 12:39:13.744580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    reload(action)
    import ansible.plugins.action.shell as shell

    test_action = action.ActionModule(None, None, None, None)
    test_module = shell.ActionModule(None, None, None, None)

    assert test_module.run() == test_action.run()

# Generated at 2022-06-11 12:39:23.129866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'hosts': ['localhost'],
        'hostvars': {'localhost': {'ansible_hostname': 'localhost'}}
    }
    module = 'shell'
    args = {
        '_raw_params': 'echo 123',
        '_uses_shell': True,
        'chdir': None,
        'creates': None,
        'executable': None,
        'removes': None,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    }
    connection = 'local'

# Generated at 2022-06-11 12:39:23.702363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:39:24.263598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:33.519022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    full_path_name = "/Users/bird/ansible-test/lib/ansible_collections/ansible/builtin/action_plugin/command.py"
    tmp = "/private/var/folders/xn/n8yw1jy93_757p087_trdr300000gn/T/"
    task_vars = {}

    with open(full_path_name, 'rt') as f:
        file_content = f.read()

    for line in file_content.split('\n'):
        if "class ActionModule" in line:
            class_name = line.split()[1].split('(')[0]
            break

    module_name = '.'.join(full_path_name.split('/')[-2:]).replace('.py', '')
    module_class = __

# Generated at 2022-06-11 12:39:39.625169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({'no_log': False}, {}, {'args': {'_uses_shell': True}, 'name': 'shell'}, {}, {}, {}, {'loader': {'module_utils': {'basic': {'AnsibleModule': {}}}}},)
    print(module.run(task_vars={}))
    return True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:39:49.160755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Load the action plugin to test
    action_plugin_name = 'ansible.legacy.shell'
    action_plugin_path = '/home/mark/git/ansible/lib/ansible/plugins/actions'
    module_utils_path = os.path.join(action_plugin_path, '__init__.py')
    module_utils = imp.load_source('module_utils', module_utils_path)
    action_plugin = imp.load_source(action_plugin_name, os.path.join(action_plugin_path, action_plugin_name + '.py'))

    # Create a non-abstract instance of ActionModule
    action_instance = action_plugin.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:39:56.815031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = None
    pc = None
    loader = None
    templar = None
    shared_loader_obj = None
    tmp = None
    task_vars = None

    # Make instance of class ActionModule
    actionmodule = ActionModule(task=None, connection=conn, play_context=pc, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

    # Call method run without parameters
    result = actionmodule.run(tmp=tmp, task_vars=task_vars)

    # AssertionError if method returned None
    assert result is not None

# Generated at 2022-06-11 12:40:00.034240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-11 12:40:00.782974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:40:01.564821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('unit test run')


if __name__ == '__main__':

    test_ActionModule_run()

# Generated at 2022-06-11 12:40:05.560399
# Unit test for method run of class ActionModule
def test_ActionModule_run():


    # Test ActionModule with shell module
    task = dict(action=dict(module="shell"))
    play_context = dict(executable="",
                        shell="/bin/bash",
                        env={},
                        shell_type="ansi",
                        become=False,
                        become_method=None,
                        become_user=None)
    connection = dict(name="local",
                      port=22,
                      user="",
                      password=None,
                      host=None,
                      local_target=None,
                      host_keys=None)

    action_plugin = ActionModule(task=task,
                                 connection=connection,
                                 play_context=play_context,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)

    task_vars = dict()
    expected_

# Generated at 2022-06-11 12:40:13.694043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.shell
    import ansible.plugins.action.command
    import ansible.plugins.connection.local
    import ansible.plugins.loader
    import ansible.plugins.loader.powershell


    # Create a mock of the TaskExecutor class, which will replace TaskExecutor when TaskExecutor is used
    # to instantiate an object of class ActionModule.  The mock will have attribute _runner_path with
    # value mock_runner_path.
    #
    # The mock must be in a module.  Therefore, this module is imported in the class definition of class
    # ActionModule so that the mock can be created by the setUp() method of this test.
    class  TaskExecutor_mock():

        def __init__(self):
            self._runner_path = mock_runner_path

    # Create

# Generated at 2022-06-11 12:40:25.089712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionModule as CommandActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import mock
    loader = mock.Mock(spec=DataLoader)
    inventory = mock.Mock(spec=InventoryManager)
    variable_manager = mock.Mock(spec=VariableManager)

# Generated at 2022-06-11 12:40:36.320853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='list', elements='str', required=True),
            _uses_shell=dict(type='bool', required=False),
        ),
        supports_check_mode=True,
    )
    result = ActionModule.run(module)
    module.exit_json(**result)

# Generated at 2022-06-11 12:40:40.298879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert action_module.run(tmp = None, task_vars = None) is not None

# Generated at 2022-06-11 12:40:40.872798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:40:41.482731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-11 12:40:54.867842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_ssh_pass='password',
        ansible_vsftpd_user='vsftpd',
        ansible_vsftpd_passwd='password',
        ansible_become='False'
    )
    tmp = '/tmp'

    # class MockConnection:
    #     host = '127.0.0.1'
    #     port = 22
    #     def connect(self, *args, **kwargs):
    #         pass
    #
    # conn = MockConnection()
    #
    # action = ActionModule(task=dict(), connection=conn, play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    #
    # result = action.run(tmp, task_vars)

    assert True

# Generated at 2022-06-11 12:40:55.464746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:05.073911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {u'vars': {u'ansible_user': u'root', u'ansible_password': u'Passw0rd', u'ansible_port': 22}, u'action': u'shell', u'args': {u'chdir': None, u'executable': None, u'_raw_params': u'python --version', u'_uses_shell': True, u'removes': None}, u'run_once': False, u'connection': u'local', u'name': u'Command python --version', u'_ansible_no_log': False}
    # Create a mock task_vars

# Generated at 2022-06-11 12:41:12.095204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.__class__._shared_loader_obj = ActionModule._shared_loader_obj
    action.__class__._connection = ActionModule._connection
    action.__class__._play_context = ActionModule._play_context
    action.__class__._loader = ActionModule._loader
    action.__class__._templar = ActionModule._templar
    action.__class__._task = ActionModule._task
    action.__class__._task.args = {'_uses_shell': True}

    result = action.run()
    assert result['rc'] == 0

# Generated at 2022-06-11 12:41:12.630781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-11 12:41:19.797839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import shell

    # Initializing the class to be instantiated
    shell_base = shell.ActionModule( MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock())

    # Now creating an instance of class
    shell_base_instance = shell_base.run(None, None)

    assert shell_base_instance == None

# Generated at 2022-06-11 12:41:22.118892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run(tmp=None, task_vars=None)
    assert type(result) is dict, "wrong action result"

# Generated at 2022-06-11 12:41:31.602038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data
    module_path = "ansible.plugins.action.shell"
    module_name = "shell"
    module_args = ""
    module_kwargs = "python -c 'import sys ; print(sys.version_info[:])'"
    task_args = dict(
        _raw_params=module_name,
        _uses_shell=True,
        _uses_delegate_to=False,
        argv=None,
        args=dict(python=-c,import_date=None,sys='print(sys.version_info[:])')
    )

# Generated at 2022-06-11 12:41:32.197269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:41:35.872798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    dummy_class = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Act
    dummy_class.run()

    # Assert

# Generated at 2022-06-11 12:41:53.506370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    call_command_A1 = {'test_stderr': False, 'test_rc': False, 'test_stderr_lines': [], 'test_stdout': False, 'test_stdout_lines': []}
    module = AnsibleModule(argument_spec={}, bypass_checks=True)
    module.check_mode = False
    ins = ActionModule(task=DummyTask(), connection=DummyConnection(), play_context=DummyPlayContext(), loader=DummyLoader(), templar=DummyTemplar(), shared_loader_obj=DummySharedLoaderObj())
    assert ins.run(tmp=None, task_vars=call_command_A1) == {'stderr': u'', 'stderr_lines': [], 'stdout': u'', 'stdout_lines': []}

#

# Generated at 2022-06-11 12:41:59.835718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    task_vars = HostVars({"var": "foo"}, "localhost")
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory_manager = InventoryManager(loader, sources=['localhost'])
    variable_manager.set_inventory(inventory_manager)
    variable_manager.extra_vars = {"var": "foo"}


# Generated at 2022-06-11 12:42:10.406801
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a dummy action module
    class MyActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(MyActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

    # Create a dummy class for ActionBase
    class DummyActionBase(ActionBase):

        def get_loader(self, varname):
            print("In get_loader(): " + varname)

        def add_cleanup_file(self, file):
            print("In add_cleanup_file(): " + file)

    # Create a dummy connection class
    class DummyConnection:

        def get_shell_plugin(self):
            print("In get_shell_plugin()")

# Generated at 2022-06-11 12:42:12.100957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule()
  module.run()

# Generated at 2022-06-11 12:42:19.277555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule({}, None).run() == {'ansible_facts': {}, 'changed': False, '_ansible_verbose_always': True, '_ansible_no_log': False, '_ansible_parsed': True, 'invocation': {'module_args': {'_uses_shell': True}}, '_ansible_item_label': None, 'stderr': '', '_ansible_failed_result': True, '_ansible_item_result': True, 'stdout': '', '_ansible_notify': None, '_ansible_no_log_values': {}}



# Generated at 2022-06-11 12:42:28.158336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # using mock to link the modules
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../'))
    action_loader.add_directory(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../action_plugins'))

    import ansible.modules.legacy.system
    old_command_action = ansible.modules.legacy.system.ActionModule.run
    ansible.modules.legacy.system.ActionModule.run = lambda self, tmp=None, task_vars=None: (True, tmp)
    # setup module
    from ansible.modules.legacy.shell import ActionModule
    test_shell

# Generated at 2022-06-11 12:42:38.337048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check if the module does not return anything if the check mode is enabled
    module = ActionModule(connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert module.run() is None

    # Check if the module returns something if the check mode is not enabled
    play_context = AnsiblePlay()
    play_context.check_mode = False
    module = ActionModule(connection=None,
                          play_context=play_context,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert module.run() is not None

# Generated at 2022-06-11 12:42:38.952136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:39.719206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:42:48.301395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  """
  Test for method ActionModule.run
  """
  print("Testing ActionModule.run")
  # 1. Test returns the same dictionary

  # Test with empty dictionary
  result = ActionModule.run({}, None)
  print("result - ", result)
  assert(result == {'ansible_facts': {}})

  # Test with non-empty dictionary
  result = ActionModule.run({}, {'a': 3})
  print("result - ", result)
  assert(result == {'ansible_facts': {}})

  # 2. Test returns the same task_vars

  # Test with empty task_vars
  result = ActionModule.run({'tmp': 1}, {})
  print("result - ", result)
  assert(result == {'ansible_facts': {}})

  # Test with non-

# Generated at 2022-06-11 12:43:03.932454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:04.674168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:09.030047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Method call asserts
    #
    # _task
    # _shared_loader_obj
    # run(task_vars=task_vars)
    #
    # _task.args
    # _task.args['_uses_shell'] = True
    #
    # command_action.run(task_vars=task_vars)
    #
    assert True

# Generated at 2022-06-11 12:43:09.550878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:19.524519
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Get and set variables for arguments of method run
    test_vars = dict()

    def mock_task_vars(key=None, *args, **kwargs):
        if key:
            return test_vars.get(key)
        return test_vars

    def mock_task_args(key=None, *args, **kwargs):
        if key:
            return test_vars.get(key)
        return dict()

    class FakeConnection(object):
        def __init__(self, *args, **kwargs):
            pass

    class FakeTask(object):
        def __init__(self, *args, **kwargs):
            pass

        def set_loader(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 12:43:21.939170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test
    module = ActionModule(None, task_vars=None)
    module.run(tmp=None, task_vars=None)
    print(module.run)

# Generated at 2022-06-11 12:43:23.245908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test ActionModule_run')
    a = ActionModule()
    a.run()

# Generated at 2022-06-11 12:43:31.137258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example taken from ansible sources
    task_vars = dict(
        ansible_user='root',
        ansible_password='strongpassword',
        ansible_ssh_pass='strongpassword',
        ansible_become='yes',
        ansible_become_pass='strongpassword',
        ansible_become_method='su',
        ansible_become_user='root',
        ansible_shell_type='csh',
        ansible_shell_executable=None,
        ansible_shell_python=None,
    )
    tmp = None
    task = dict(
        args=dict(
            _raw_params='ifconfig',
            #_raw_params='ifconfig',
            #_uses_shell=True,
        )
    )

# Generated at 2022-06-11 12:43:33.019468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Method run of class ActionModule should return a dict
    assert isinstance(ActionModule.run, dict)

# Generated at 2022-06-11 12:43:43.476162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.test.test_utils.test_runner import TestTask as TestTask
    from ansible_collections.test.test_utils.test_runner import TestConnection as TestConnection
    from ansible_collections.test.test_utils.test_runner import TestLoader as TestLoader
    from ansible_collections.test.test_utils.test_runner import TestPlayContext as TestPlayContext
    from ansible_collections.test.test_utils.test_runner import TestTaskResult as TestTaskResult
    import os
    import json

    # Define test data

# Generated at 2022-06-11 12:44:22.882521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None, connection=None, play_context=None)
    print(type(module.run()))

# Generated at 2022-06-11 12:44:23.354245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:44:31.137114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case to test the run method of class ActionModule
    # Arrange
    import ansible.plugins.action.shell
    FakeTask = MagicMock()
    FakeTask.args = dict()
    FakeTask.args['_uses_shell'] = True
    FakeTask.run_module = dict()
    FakeTask.run_module['_uses_shell'] = True
    module = ansible.plugins.action.shell.ActionModule(FakeTask, connection=FakeTask, play_context=FakeTask, loader=FakeTask, templar=FakeTask, shared_loader_obj=FakeTask)
    tmp = None
    task_vars = None
    # Act
    result = module.run(tmp, task_vars)
    # Assert
    assert result is None

# Generated at 2022-06-11 12:44:38.388083
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.shell import ActionModule

    class MockActionModule(ActionModule):

        def _execute_module(self, result, **kwargs):
            return dict(shell_result=result)

    args = dict(chdir='~', executable='/bin/bash', environment='FOO=bar,BAR=foo', umask='022', _raw_params='ls')
    test_module = MockActionModule(task=dict(args=args), connection=None, play_context={}, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:44:39.148030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Use for testing
    pass

# Generated at 2022-06-11 12:44:46.492004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Start to build up the parameters
    module_args = {"arg1": "val1", "arg2": "val2"}
    task_ds = {"args": module_args}

    # Calling the run method under test
    action_module = ActionModule(None, None)
    result = action_module.run(task_ds)

    assert result is not None
    assert result.get("skipped") is False

    # TODO - The below is a placeholder that should provide an example of how to
    # check the results of the run method.
    # Some checks on result
    #assert result["result"]["filename"] == "test-file.txt"
    #assert result["result"]["state"] == "file"
    #assert result["result"]["stat"]["isdir"] == False
    #assert result["result"][

# Generated at 2022-06-11 12:44:54.021608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_loader = 'fake_loader'
    fake_shared_loader_obj = 'fake_shared_loader_obj'
    fake_task_vars = 'fake_task_vars'
    fake_action_loader = 'fake_action_loader'
    fake_task = 'fake_task'
    fake_connection = 'fake_connection'
    fake_play_context = 'fake_play_context'
    fake_loader = 'fake_loader'
    fake_templar = 'fake_templar'
    fake_result = 'fake_result'

    # Create class instances to test
    a = ActionModule(fake_loader, fake_shared_loader_obj, fake_task_vars)

    # Create mocks
    p = mock.patch("ansible.plugins.action.ActionModule.run")

# Generated at 2022-06-11 12:44:59.449677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'ansible_loop_var': 'item', 'ansible_facts': {}}
    args = {'shell': 'echo {{ansible_loop_var}}'}
    action = ActionModule(task=dict(args=args), connection=None, play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)
    result = action.run(task_vars=task_vars)
    assert result['cmd'] == 'echo item'

# Generated at 2022-06-11 12:45:03.703568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	tmp = False
	task_vars = dict()
	task_vars['comp_a'] = 'component_u'

	action_module=ActionModule(task=None,
		connection=None,
		play_context=None,
		loader=None,
		templar=None,
		shared_loader_obj=None)


	action_module.run(tmp, task_vars)

# Generated at 2022-06-11 12:45:12.317818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.utils.context_objects import AnsibleContext
    from ansible.utils.context_objects import AnsibleVars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


    loader = DataLoader()
    play_context = PlayContext()

# Generated at 2022-06-11 12:46:26.805369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:46:28.069502
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    args = ('')
    assert module.run(args) == None

# Generated at 2022-06-11 12:46:35.043450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    del tmp  # tmp no longer has any effect
    # Shell module is implemented via command with a special arg
    self._task.args['_uses_shell'] = True

    command_action = self._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                               task=self._task,
                                                               connection=self._connection,
                                                               play_context=self._play_context,
                                                               loader=self._loader,
                                                               templar=self._templar,
                                                               shared_loader_obj=self._shared_loader_obj)
    result = command_action.run(task_vars=task_vars)
    return result

# Generated at 2022-06-11 12:46:36.274892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ansible.plugins.action.ActionModule()
    result = module.run()
    assert result == None

# Generated at 2022-06-11 12:46:44.150412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import inspect

    from ansible.plugins.action import ActionBase
    from ansible.module_utils.basic import AnsibleModule

    module_name = "test_ansible_module"
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    tmpdir = module._debug_dir
    display.display("tmpdir={0}".format(tmpdir))

    # Create an instance of class ActionModule
    action_module = ActionModule("test_action_module",
                                 "test_connection",
                                 "test_play_context",
                                 "test_loader",
                                 "test_templar",
                                 "test_shared_loader_obj")

    # set debug dir
    action_module._debug_dir = tmpdir

    # run method

# Generated at 2022-06-11 12:46:53.412410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    response = {}
    response["stdout"] = "hello"
    response["stderr"] = ""
    response["rc"] = 0
    response["start"] = "2018-09-27 08:23:52.792170"
    response["end"] = "2018-09-27 08:23:52.812172"
    response["delta"] = "0:00:00.020001"
    response["msg"] = "non-zero return code"
    response["invocation"] = {
        "module_args": "useradd testing",
        "_raw_params": "useradd testing",
        "_uses_shell": True
    }

    """Record the response"""
    results = response

    """Record the results"""

# Generated at 2022-06-11 12:46:55.050987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule("ActionModule")
    t.run("tmp", "task_vars")

# Generated at 2022-06-11 12:47:01.548103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n")
    # arguments_for_playbook_module
    connection = 'local'
    only_if = None
    free_form = 'sudo ls -l'
    _uses_shell = True
    _raw_params = None
    _uses_delegate = False
    executable = None
    _attributes = {'cd': '', 'chdir': '', 'creates': '', 'executable': '', 'removes': '', 'warnerrors': '', 'warnings': ''}
    args = {'_uses_shell': _uses_shell, '_raw_params': _raw_params, '_uses_delegate': _uses_delegate, 'free-form': free_form, 'executable': executable, '_attributes': _attributes}

# Generated at 2022-06-11 12:47:05.550850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    res = obj.run(tmp=None, task_vars={})
    assert type(res) == dict
    assert res['msg'] == "No command given" 
    assert res['failed'] == True

# Generated at 2022-06-11 12:47:13.276280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n## In test_ActionModule_run")

    action_mod = ActionModule()