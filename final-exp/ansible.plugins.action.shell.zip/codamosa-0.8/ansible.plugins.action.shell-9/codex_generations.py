

# Generated at 2022-06-11 12:39:11.398507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:19.898146
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:39:24.131304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(loader=None,
                          shared_loader_obj=None,
                          connection=None,
                          play_context=None,
                          loader_obj=None,
                          templar=None,
                          task=None)

    result = module.run(task_vars=None)
    assert result >= 0

# Generated at 2022-06-11 12:39:24.710982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:39:33.935787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Assert that '_uses_shell' is False
    assert not action_module._task.args['_uses_shell']

    # call method run of class ActionModule
    result_action_module = action_module.run(tmp=None, task_vars=None)

    # Assert that '_uses_shell' is now set to True
    assert action_module._task.args['_uses_shell']

    # test to see if result_action_module has a valid value for changed
    assert result_action_module['changed'] == False

    # test to see if result_action_module has a valid value for st

# Generated at 2022-06-11 12:39:41.253996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup_mock_command is a function that creates mock objects that can be used in unittests
    # As a default it uses the 'ansible.legacy.command' class
    command_action = setup_mock_command()

    # setup the actionplugin object
    # this is the object that will be tested
    actionplugin = setup_mock_actionplugin(command_action)

    result = actionplugin.run(task_vars={})
    assert result == {'stdout': 'test output', 'stderr': 'test output', 'rc': 0}

# Generated at 2022-06-11 12:39:41.806763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:39:51.087090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    options = {'foo': 42}
    loader = 'test_loader'
    task_vars = {}
    play_context = 'test_play_context'
    templar = 'test_templar'
    connection = 'test_connection'
    shared_loader_obj = 'test_shared_loader_obj'
    action_base = ActionBase.__new__(ActionBase)
    action_base.task = 'test_task'
    action_base._task = 'test_task'
    action_base._shared_loader_obj = shared_loader_obj
    action_base._loader = loader
    action_module = ActionModule.__new__(ActionModule)
    action_module._task = 'test_task'
    action_module._shared_loader_obj = shared_loader_obj
    action_module._loader

# Generated at 2022-06-11 12:39:52.141163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_ActionModule = ActionModule()

# Generated at 2022-06-11 12:39:53.207098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass


# Generated at 2022-06-11 12:39:56.171866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:39:57.145365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False,"Not implemented"

# Generated at 2022-06-11 12:40:08.739312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_to_bytes = lambda x: bytes(x.encode())
    tmpdir = os.path.dirname(os.path.dirname(__file__))

    ActionModule_obj = ActionModule(connection=None,
                                    play_context=None,
                                    loader=None,
                                    templar=None,
                                    shared_loader_obj=None)

# Generated at 2022-06-11 12:40:12.826179
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock class for ActionModule
    class TestActionModule(ActionModule):
        def __init__(self):
            self.param = 'Test'

    iut = TestActionModule()

    for arg in (None, {}):
        print('arg:', arg)
        result = iut.run(arg)

    return True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:40:24.583119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule.run()
    # Should return a result with a defined value for changed and exit code
    #
    # Input arguments:
    #     tmp: no longer has any effect
    #     task_vars: Ansible variables set
    #
    # Output:
    #     Dictionary with keys 'changed' and 'rc'
    #
    # Test cases:
    #     No input arguments
    #     No Ansible variables set
    #     Ansible variable is set for a variable name
    #     Ansible variable is not set for a variable name
    #     Ansible variable is set as an empty string
    #     Invalid input
    #     Invalid Ansible variables
    #
    # Expected function calls:
    #     None

    # Input arguments:
    tmp = None
    task_vars = {}

    # Output:
   

# Generated at 2022-06-11 12:40:35.793640
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #Set up test variables
    class ActionBase():
        def __init__(self):
            self.connection = None
            self.play_context = None
            self.loader = None
            self.templar = None
            self.shared_loader_obj = None
            self.args = {'_uses_shell' : True}
            
        def run(self, task_vars=None):
            return (0, 'path')
            
    class ActionModule():
        def __init__(self):
            self._task = ActionBase()
            self._connection = None
            self._play_context = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None
            self._task_vars = None

            #Set up action_loader
            self._shared_loader

# Generated at 2022-06-11 12:40:38.252940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating an instance of class ActionModule
    actionModule = ActionModule()

    # Calling run without required arguments
    assert actionModule.run() == None

# Generated at 2022-06-11 12:40:45.461679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # given
    class ActionModule:
        def __init__(self):
            self.task = dict(args=dict(_uses_shell=True))
            self.connection = [dict(ip="10.98.1.1"), dict(ip="10.98.1.1")]
            self.play_context = [dict(ip="10.98.1.1"), dict(ip="10.98.1.1")]
            self.loader = dict(name="test")
            self.templar = dict(name="test")

    # when
    test_action_module = ActionModule()
    result = test_action_module.run()

    # then
    assert result is not None

# Generated at 2022-06-11 12:40:46.750140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act_module = ActionModule()
    result = act_module.run()

# Generated at 2022-06-11 12:40:47.694274
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:41:01.827392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule(loader=None,
                      connection=None,
                      play_context=play_context,
                      loader=loader,
                      templar=templar,
                      shared_loader_obj=None)
    AM._task.args = {'_uses_shell': 'True'}
    task_vars = dict()
    command_action = AM._shared_loader_obj.action_loader.get('ansible.legacy.command',
                                                                    task=AM._task,
                                                                    connection=AM._connection,
                                                                    play_context=AM._play_context,
                                                                    loader=AM._loader,
                                                                    templar=AM._templar,
                                                                    shared_loader_obj=AM._shared_loader_obj)

# Generated at 2022-06-11 12:41:10.840469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.shell import ActionModule

    fake_loader = DictDataLoader({
        "test.yml": """
        - hosts: all
          gather_facts: no
          tasks:
          - shell: /usr/bin/mycmd
        """
    })

    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list='test_hosts')
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    # Get object of class ActionModule

# Generated at 2022-06-11 12:41:20.431830
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Auxiliary classes and functions for testing
    from ansible.plugins.action.shell import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.command import ActionModule as CommandModule
    import ansible.module_utils.basic

    class MockConnection():
        def __init__(self, transport):
            self.transport = transport

        def close(self):
            pass

    class MockTask():
        def __init__(self):
            pass

    class MockPlayContext():
        def __init__(self):
            pass

    class MockLoader():
        def __init__(self):
            pass

    class MockTemplar():
        def __init__(self):
            pass

    class MockSharedLoaderObj():
        def __init__(self):
            pass

       

# Generated at 2022-06-11 12:41:24.541676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    result = mod.run()
    assert result['msg'] == 'Ansible FAILED! => {u"failed": true, u"rc": 1, u"stderr": u"", u"stderr_lines": [], u"stdout": u"", u"stdout_lines": []}'

# Generated at 2022-06-11 12:41:28.051281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {}
    task["args"] = {}
    task["args"]["_uses_shell"] = True
    task_vars = {}

    action = ActionModule(task)
    assert action.run(task_vars=task_vars) is None

# Generated at 2022-06-11 12:41:28.595557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:37.849870
# Unit test for method run of class ActionModule
def test_ActionModule_run():

  fake_loader = FakeLoader()
  fake_task = FakeTask()
  fake_task.args = {
    '_raw_params': 'ansible-playbook -i ansible/inventories/development aws-deploy.yml',
    '_uses_shell': True
  }
  fake_play_context = FakePlayContext()
  fake_play_context.become = True
  fake_play_context.become_user = 'ansible'
  fake_play_context.remote_addr = '127.0.0.1'
  fake_play_context.network_os = 'darwin'
  fake_play_context.become_method = 'sudo'
  fake_play_context.port = 22
  fake_connection = FakeConnection()
  fake_loader_obj = FakeLoaderObj()
 

# Generated at 2022-06-11 12:41:40.253968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_action = ActionModule()
    action_module = command_action.run()
    print(action_module)


# Generated at 2022-06-11 12:41:40.852176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:41:51.459382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase as abst
    from ansible.plugins.action import _action_plugin_loaders

    class ActionBaseMock(abst):
        """Mock class for ActionBase"""
        is_missing_required_args = False
        connection = None
        _templar = None
        _task = None
        _play_context = None
        _loader = None
        _shared_loader_obj = None
        def get_connection(self):
            return ActionBaseMock.connection

    class CommandPluginMock(ActionBaseMock):
        """Mock class for command plugin"""
        def run(self, tmp, task_vars):
            return None

    class ActionLoaderMock:
        """Mock class for action_loader"""

# Generated at 2022-06-11 12:41:59.507898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-11 12:42:09.981877
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:42:19.428252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
      Unit test for method run of class ActionModule
      The test assumes that the command module has been tested.
      Purpose of this unit test is to test the functionality of
      the class method run.
    '''
    from ansible.plugins.action.shell import ActionModule
    from ansible.plugins.action.command import ActionModule as command_action_module
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Dict object for

# Generated at 2022-06-11 12:42:25.015475
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:42:26.405324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-11 12:42:30.871181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aa=ActionModule(connection='connection', task='task', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    aa.run(tmp='tmp', task_vars='task_vars')

# Generated at 2022-06-11 12:42:34.078975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_tmp = None
    m_task_vars = {}
    obj = ActionModule(m_tmp, m_task_vars)
    assert obj.run(m_tmp, m_task_vars) == None

# Generated at 2022-06-11 12:42:44.210658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type

    import ast
    import inspect
    import json

    # python 2.6 requires argspec instead of getargspec
    if PY3:
        argspec = inspect.getfullargspec
    else:
        argspec = inspect.getargspec

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            del tmp # tmp no longer has any effect
            self

# Generated at 2022-06-11 12:42:49.402749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run:")
    
    # Initial variables
    actionModule = ActionModule()
    actionModule._loader = None
    actionModule._connection = None
    actionModule._templar = None
    actionModule._task = None
    actionModule._shared_loader_obj = None
    actionModule._play_context = None

    expected_action_loader = None
    expected_result = None
    actual_result = actionModule.run()

    # Check that the expected result is equal to the actual result
    assert expected_action_loader == actual_result

# Generated at 2022-06-11 12:42:55.578383
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = sys.modules['ansible.plugins.action.shell']
    shell = module.ActionModule(
        task=dict(action=dict(module='shell', args='ls')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    results = shell.run(None, None)

    assert results['cmd'] == 'ls'
    assert results['rc'] == 0

# Generated at 2022-06-11 12:43:10.897794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:20.830626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_tmp = MagicMock()
    m_task_vars = MagicMock()

    m_task = MagicMock()
    m_task.args = dict()

    m_self = MagicMock(
        _task=m_task,
        _shared_loader_obj=MagicMock()
    )

    command_action = MagicMock()
    command_action.run.return_value = dict()

    m_command_action_loader = MagicMock()
    m_command_action_loader.get.return_value = command_action

    m_action_loader = MagicMock()
    m_action_loader.action_loader = m_command_action_loader

    m_self._shared_loader_obj.action_loader = m_action_loader


# Generated at 2022-06-11 12:43:29.448658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'host'
    module_name = 'shell'
    module_args = {'executable': '/bin/sh', '_uses_shell': True, 'chdir': None, 'creates': None, 'removes': None, 'warn': True, 'stdin': '', 'stdin_add_newline': True, 'strip_empty_ends': True, '_raw_params': 'ifconfig', '_tmp_path': '/tmp/ansible-tmp-1495114197.37-182533374482339/shell', '_uses_delegate': False, '_uses_flat_keys': False, '_uses_unsafe_shell': True}

# Generated at 2022-06-11 12:43:31.952467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    result = actionModule.run()
    assert result == "pass"

# Generated at 2022-06-11 12:43:42.317816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Data for testing method run of class ActionModule
    module_args = dict(
        _raw_params='echo "hi"',
        _uses_shell=True,
        _raw_params_list=['echo "hi"'],
        chdir=None,
        executable=None,
        _uses_shell=True,
        _raw_params='echo "hi"',
    )

# Generated at 2022-06-11 12:43:49.276351
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()
    action_module._task.args = {}
    action_module._task.args['_uses_shell'] = True

    action_command = ActionCommand()
    action_module._shared_loader_obj.action_loader.get = MagicMock(return_value=action_command)

    result = action_module.run(task_vars={})
    
    assert result == 'result'


# Generated at 2022-06-11 12:43:50.333296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Generated at 2022-06-11 12:43:51.001970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:43:53.463452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("in the test")
    print(ActionModule.run.__doc__)
    assert ActionModule.run.__doc__ is not None
    print("end of the test")

# Generated at 2022-06-11 12:43:59.337172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #create a mock task with args, module_name and action name
    task = mock_task
    task.args = dict()
    task.args['_uses_shell'] = True
    assert task.args['_uses_shell'] == True
    task.action = 'shell'
    action_module = ActionModule(task, task.connection, task.play_context, task.loader, task.templar, task.shared_loader_obj)
    action_module.run(task_vars={})

# Generated at 2022-06-11 12:44:43.070308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleActionModule()
    assert module.run() == None

# Generated at 2022-06-11 12:44:50.405363
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:44:51.168423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (True == True)

# Generated at 2022-06-11 12:44:54.022405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = actionModule.run(tmp=None, task_vars=None)
    assert result['rc'] != 0

# Generated at 2022-06-11 12:45:02.288599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock required class attributes
    import collections
    import copy

    module = os.path.basename(__file__)
    setattr(ActionModule, '_Display', collections.namedtuple('_Display', ['display', 'verbosity']))

    test_counter = 0

    class LazyLoader():
        def get(self, action, **kwargs):
            if action == 'ansible.legacy.command' and kwargs['task']._task.action.name == 'shell':
                return ActionModule
        def all(self, **kwargs):
            return [ActionModule]

    # mock required function
    def _get_async_timeout(task_vars):
        return None

    def get_bin_path(app, required=False, opt_dirs=[]):
        return '/bin/'+app

   

# Generated at 2022-06-11 12:45:10.576614
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:45:19.000444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from ansible.utils.vars import combine_vars

    # Test with an empty playbook
    play_path = 'tests/fixtures/shell-module.yml'
    loader, inventory, variable_manager = PlaybookExecutor._load_playbook_from_file(play_path)

    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=dict(),
    )

    task = Task()
    task.action = 'shell'
    task

# Generated at 2022-06-11 12:45:23.573787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run()
    """
    import ansible.plugins.action.debug
    action = ansible.plugins.action.debug.ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = action.run()
    assert result['_ansible_module_name'] == 'debug'

# Generated at 2022-06-11 12:45:29.739921
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import module_utils
    module_utils.COMMUNITY_URL= 'www.ansible.com'

    import ansible.plugins
    ansible.plugins.action.ActionBase=ActionModule()

    print(ansible.plugins.action)

    import ansible.plugins.action.shell
    ansible.plugins.action.shell.ActionModule=ActionModule()

    shell_action = ansible.plugins.action.shell.ActionModule()

    print(shell_action)

    shell_action.run()

# Generated at 2022-06-11 12:45:30.376143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:46:57.189073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = MyActionModule()
    module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:47:00.774766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {}
    host = "testhost"
    task_vars = {}
    tmp = ""
    module_name = "shell"
    test_instance = ActionModule(task_args, host, task_vars, tmp, module_name)
    result = test_instance.run(tmp="", task_vars={})
    assert 'rc' in result
    assert result['rc'] == 0


# Generated at 2022-06-11 12:47:10.444859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    
    import ansible
    import ansible.legacy.plugins.action.shell as shell
    import ansible.plugins.action.command as command
    import ansible.template as template
    import ansible.plugins.loader as loader
    import ansible.vars.manager as vars_manager
    
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 12:47:13.185340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run(tmp='ansible/plugins/action/__init__.py', task_vars='[ansible_facts, ansible_env]') == "['ansible_facts', 'ansible_env']"

# Generated at 2022-06-11 12:47:20.967412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module_obj = ActionModule(connection=None, action=None, task=None,
                                     play_context=None, loader=None,
                                     templar=None, shared_loader_obj=None)

    # Override the value of attribute _task.args of instance action_module_obj
    action_module_obj._task.args = {'_uses_shell': True}

    # Override the value of attribute _task.args of instance action_module_obj
    action_module_obj._task.action = 'ansible.legacy.command'

    # Create an instance of class Command

# Generated at 2022-06-11 12:47:28.327458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    from ansible.errors import AnsibleError, AnsibleActionFail
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.shell import ActionModule as ShellModule

    # Mock ActionBase class
    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return task_vars

    # Mock AnsibleError and AnsibleActionFail classes
    class MockAnsibleError(AnsibleError):
        pass

    class MockAnsibleActionFail(AnsibleActionFail):
        pass

    # Mock loading of ActionBase class
    class MockBaseLoader(object):
        def get(self, *args, **kwargs):
            return MockActionBase(self, *args, **kwargs)

    # Mock ActionBase.

# Generated at 2022-06-11 12:47:32.537338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Default initialization
    my_module = ActionModule(None)
    assert my_module.run({'_ansible_no_log': False, '_ansible_verbosity': 3}) is None

    # Non default initialization
    my_module = ActionModule(None)
    my_module._connection = None
    assert my_module.run({'_ansible_no_log': False, '_ansible_verbosity': 3}) is None

# Generated at 2022-06-11 12:47:40.835825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock action_base class
    class MOCK_ACTION_BASE(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return 'success'
    # Create a mock ansible.legacy.command class
    class MOCK_LEGACY_COMMAND(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return 'success'

    # Create an instance of action module class
    action_module_obj = ActionModule(None, {}, {}, None, None, None)

    # Create an instance of mock ansible.legacy.command class
    mock_legacy_command_obj = MOCK_LEGACY_COMMAND(None, {}, {}, None, None, None)

    # Set a mock action_base class to _shared_

# Generated at 2022-06-11 12:47:46.579943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    results = action_module.run(task_vars = {
        'foo': 'bar'
    })
    print(results['rc'])
    print(results['stderr'])
    print(results['stdout'])
    assert results['rc'] == 0
    assert results['stderr'].strip() == 'cat: foo: No such file or directory'
    assert results['stdout'].strip() == ''

# Generated at 2022-06-11 12:47:50.840509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict()
    host['name'] = 'localhost'
    host['connection'] = 'local'
    connection = 'local'

    class Task():
        def __init__(self):
            self.args = {}

    action = ActionModule()
    action._shared_loader_obj = dict()
    action._connection = connection
    action._task = Task()
    action.run()