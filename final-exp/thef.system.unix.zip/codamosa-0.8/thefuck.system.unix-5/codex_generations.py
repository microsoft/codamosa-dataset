

# Generated at 2022-06-12 12:33:21.181970
# Unit test for function open_command
def test_open_command():
    assert open_command('--version') == 'xdg-open --version'

# Generated at 2022-06-12 12:33:21.645482
# Unit test for function getch
def test_getch():
    pass



# Generated at 2022-06-12 12:33:22.428387
# Unit test for function getch
def test_getch():
    assert getch() == 'q'


# Generated at 2022-06-12 12:33:24.355739
# Unit test for function get_key
def test_get_key():
    print("Test function get_key: ")
    print("\tpress any key: ")
    key = get_key()
    print("\tresult: ", key)


# Unit Test for function open_command

# Generated at 2022-06-12 12:33:27.067360
# Unit test for function get_key
def test_get_key():
    for key in const.KEY_MAPPING:
        sys.stdin.write(key)
        assert(get_key() == const.KEY_MAPPING[key])



# Generated at 2022-06-12 12:33:29.181378
# Unit test for function get_key
def test_get_key():
    # assert get_key() == const.KEY_ENTER
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN

# Generated at 2022-06-12 12:33:30.368200
# Unit test for function getch
def test_getch():
    assert getch() == '\x1b'


# Generated at 2022-06-12 12:33:32.397665
# Unit test for function getch
def test_getch():
    print_str = "Please input your name: "
    print(print_str)
    name = input()
    print("Your name is: " + name)
    return


# Generated at 2022-06-12 12:33:34.389598
# Unit test for function get_key
def test_get_key():
    from . import patch_stdout

    with patch_stdout():
        print(get_key())

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:33:38.562093
# Unit test for function get_key
def test_get_key():
    for k in const.KEY_MAPPING.keys():
        ch = getch()
        try:
            assert ch == k
        except AssertionError:
            tty.setraw(sys.stdin.fileno())
            raise

# Generated at 2022-06-12 12:33:45.767083
# Unit test for function getch
def test_getch():
    assert get_key() == 'j'
    assert get_key() == 'k'
    assert get_key() == 'C-c'
    assert get_key() == 'C-v'
    assert get_key() == 'C-k'
    assert get_key() == 'q'

# Generated at 2022-06-12 12:33:52.212521
# Unit test for function get_key
def test_get_key():
    print('Asserting all keys in KEY_MAPPING')
    print(const.KEY_MAPPING)
    for key in const.KEY_MAPPING:
        print(get_key(), const.KEY_MAPPING[key])
        assert get_key() == const.KEY_MAPPING[key]
    print('Passed!')
    print()

    print('Press UP, DOWN, CTRL+c, CTRL+j, CTRL+k')
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN
    assert get_key() == const.KEY_CTRLC
    assert get_key() == const.KEY_CTRLJ
    assert get_key() == const.KEY_CTRLK
    print('Passed!')



# Generated at 2022-06-12 12:33:53.309363
# Unit test for function getch
def test_getch():
    assert getch() == 'a'

# Generated at 2022-06-12 12:33:56.260482
# Unit test for function getch
def test_getch():
    init_output()
    colorama.deinit()
    print("Enter 'q' to test_getch")
    temp = getch()
    if temp == 'q':
        return True
    else:
        return False

# Generated at 2022-06-12 12:34:02.410378
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'
    assert get_key() == const.KEY_UP
    assert get_key() == 'q'
    assert get_key() == '\r'
    assert get_key() == const.KEY_ENTER
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'B'
    assert get_key() == const.KEY_DOWN

# Generated at 2022-06-12 12:34:03.491321
# Unit test for function open_command
def test_open_command():
    assert open_command("test") == "xdg-open test"

# Generated at 2022-06-12 12:34:06.364514
# Unit test for function get_key
def test_get_key():
    def print_return_type(key):
        print(key)
        print(type(key))

    print_return_type(get_key())
    print_return_type(get_key())
    print_return_type(get_key())

test_get_key()

# Generated at 2022-06-12 12:34:09.067188
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'

# Generated at 2022-06-12 12:34:10.591447
# Unit test for function open_command
def test_open_command():
    result = 'xdg-open http://google.com'
    assert open_command('http://google.com').strip().endswith(result)

# Generated at 2022-06-12 12:34:11.371372
# Unit test for function getch
def test_getch():
    assert getch() == 'f'


# Generated at 2022-06-12 12:34:22.776797
# Unit test for function getch
def test_getch():
    # key "i"
    assert getch() == 'i'
    # key "Enter"
    assert getch() == '\n'
    # key "Esc"
    assert getch() == '\x1b'
    # key "Up"
    assert getch() == '\x1b'
    assert getch() == '['
    assert getch() == 'A'
    # key "Down"
    assert getch() == '\x1b'
    assert getch() == '['
    assert getch() == 'B'
    # key "Esc"
    assert getch() == '\x1b'

# Generated at 2022-06-12 12:34:25.862490
# Unit test for function getch
def test_getch():
    print('Test getch()')
    print('Enter \'x\' for exit')

    while True:
        c = getch()
        print(c, end='')
        if c == 'x':
            break


if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-12 12:34:30.173577
# Unit test for function getch
def test_getch():
    import mock
    import sys

    orig_getch = getch

    mock_in = mock.Mock()
    mock_in.read.return_value = 'a'
    sys.stdin = mock_in

    assert getch() == 'a'
    assert getch() == 'a'

    getch = orig_getch
    sys.stdin = sys.__stdin__

# Generated at 2022-06-12 12:34:31.378496
# Unit test for function get_key
def test_get_key():
    # TODO
    assert get_key() == None


# Generated at 2022-06-12 12:34:32.215237
# Unit test for function getch
def test_getch():
    assert getch() == 't'



# Generated at 2022-06-12 12:34:37.988540
# Unit test for function open_command
def test_open_command():
    if sys.platform == 'win32':
        assert open_command('www.google.com') == 'start www.google.com'
    elif sys.platform == 'darwin':
        assert open_command('www.google.com') == 'open www.google.com'
    else:
        assert open_command('www.google.com') == 'xdg-open www.google.com'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 12:34:44.602494
# Unit test for function get_key
def test_get_key():
    class _Getch:
        def __init__(self):
            import sys, tty, termios
        def __call__(self):
            import sys, tty, termios
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            return ch

    inkey = _Getch()

    import sys
    import tty
    import termios

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)


# Generated at 2022-06-12 12:34:46.001407
# Unit test for function getch
def test_getch():
    from .unit_tests import getch as getch_test
    getch_test()


# Generated at 2022-06-12 12:34:52.150552
# Unit test for function get_key
def test_get_key():
    print('Testing get_key(). Press \'u\' (up arrow), \'d\' (down arrow) and \'q\' (exit)')

    while True:
        k = get_key()
        if k == 'u':
            print('up')
        elif k == 'd':
            print('down')
        elif k == 'q':
            print('Quitting...')
            break
        else:
            print('Other key')

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:34:55.858198
# Unit test for function get_key
def test_get_key():
    init_output()
    assert get_key() != ''
    assert get_key() == 'q'
    assert get_key() == 'Q'
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN
    assert get_key() == const.KEY_ESC

# Generated at 2022-06-12 12:35:09.766385
# Unit test for function get_key
def test_get_key():
    try:
        # Test for normal keys
        for key in const.KEY_MAPPING:
            assert get_key() == const.KEY_MAPPING[key]

        # Test for arrows
        assert get_key() == const.KEY_UP
        assert get_key() == const.KEY_DOWN
    finally:
        # Re-init terminal
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)


# Generated at 2022-06-12 12:35:16.140534
# Unit test for function get_key
def test_get_key():
    import unittest


# Generated at 2022-06-12 12:35:23.865843
# Unit test for function open_command
def test_open_command():
    import unittest

    class TestOpenCommand(unittest.TestCase):
        def test_open_command_on_mac(self):
            import subprocess
            import platform
            import os

            default_open_command = 'open'
            os.name = 'mac'
            self.assertEqual(open_command(''), default_open_command)

        def test_open_command_on_linux(self):
            import subprocess
            import platform
            import os

            default_open_command = 'xdg-open'
            os.name = 'linux'
            self.assertEqual(open_command(''), default_open_command)

        def test_open_command_on_linux_without_xdg_open(self):
            import subprocess
            import platform
            import os

            default_open_

# Generated at 2022-06-12 12:35:24.557819
# Unit test for function getch
def test_getch():
    assert getch() is not None

# Generated at 2022-06-12 12:35:27.163182
# Unit test for function getch
def test_getch():
    key = getch()

# Generated at 2022-06-12 12:35:27.957107
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'q'

# Generated at 2022-06-12 12:35:28.989555
# Unit test for function get_key
def test_get_key():
    assert get_key() == 't'

# Generated at 2022-06-12 12:35:29.804943
# Unit test for function getch
def test_getch():
    assert getch() == 'a'


# Generated at 2022-06-12 12:35:31.796220
# Unit test for function get_key
def test_get_key():
    import getpass
    getpass.getpass = lambda prompt: prompt
    assert get_key() == "a"

# Generated at 2022-06-12 12:35:38.320048
# Unit test for function get_key
def test_get_key():
    test_list = list(const.KEY_MAPPING.keys())
    test_list.append('\x1b')
    test_list.append('\x1b[A')
    test_list.append('\x1b[B')
    for i in range(0, len(test_list)):
        sys.stdin.buffer.write(bytearray(test_list[i], encoding='utf-8'))
        sys.stdin.buffer.flush()
        if i < len(test_list) - 1:
            res = get_key()
            assert res == const.KEY_MAPPING[test_list[i]]
        else:
            res = get_key()
            assert res == const.KEY_UP


# Generated at 2022-06-12 12:36:00.741736
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:36:06.396417
# Unit test for function get_key
def test_get_key():
    test_key_list = list(map(ord, 'abcdefghijklmnopqrstuvwxyz'))
    test_key_list.extend(list(map(ord, '0123456789')))
    test_key_list.extend(list(map(ord, '~!@#$%^&*()_+{}|:"<>?')))

    for item in test_key_list:
        print(item, get_key())

    # Test arrow key
    print(const.KEY_UP, get_key())
    print(const.KEY_DOWN, get_key())

# Generated at 2022-06-12 12:36:11.160211
# Unit test for function open_command
def test_open_command():
    if get_platform() in ['Linux', 'FreeBSD', 'OpenBSD', 'NetBSD']:
        assert open_command('/tmp') == 'xdg-open /tmp'
    elif get_platform() == 'Darwin':
        assert open_command('/tmp') == 'open /tmp'
    else:
        assert open_command('/tmp') == 'xdg-open /tmp'



# Generated at 2022-06-12 12:36:11.881576
# Unit test for function getch
def test_getch():
    assert getch() == 'q'

# Generated at 2022-06-12 12:36:18.486586
# Unit test for function get_key
def test_get_key():

    import sys
    import mock

    sys.stdin.fileno = mock.Mock(return_value=0)
    sys.stdin.read = mock.Mock(return_value='a')

    assert get_key() == 'a'
    sys.stdin.read = mock.Mock(return_value=const.BACKSPACE)
    assert get_key() == const.BACKSPACE
    sys.stdin.read = mock.Mock(return_value='b')
    assert get_key() == 'b'
    sys.stdin.read = mock.Mock(return_value='\x1b')
    sys.stdin.read.return_value = '['
    sys.stdin.read.return_value = 'A'
    assert get_key() == const.KEY_UP
    sys.std

# Generated at 2022-06-12 12:36:21.277261
# Unit test for function get_key
def test_get_key():
    import sys
    import tty
    import termios
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)

# Generated at 2022-06-12 12:36:22.157679
# Unit test for function getch
def test_getch():
    assert getch() == 'q'

if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-12 12:36:23.235938
# Unit test for function get_key
def test_get_key():
    key = get_key()
    assert key in const.KEY_LIST

# Generated at 2022-06-12 12:36:24.946833
# Unit test for function getch
def test_getch():
    sys.stdin = open('/dev/null')
    assert getch() == '\x03'



# Generated at 2022-06-12 12:36:27.296751
# Unit test for function getch
def test_getch():
    if len(sys.argv) > 1:
        print(getch())
        # Just testing the function getch
        assert getch() == 'a'
    else:
        print('run me with a command line argument')

# Generated at 2022-06-12 12:37:10.197268
# Unit test for function get_key
def test_get_key():
    assert const.KEY_UP == get_key()

# Generated at 2022-06-12 12:37:13.084450
# Unit test for function open_command
def test_open_command():
    if sys.platform.startswith('darwin'):
        assert open_command('file') == 'open file'
    elif sys.platform.startswith('linux'):
        assert open_command('file') == 'xdg-open file'

# Generated at 2022-06-12 12:37:17.440077
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'
    assert get_key() == 'B'
    assert get_key() == 'C'
    assert get_key() == 'D'
    assert get_key() == ' '
    assert get_key() == 'a'

# Generated at 2022-06-12 12:37:22.408700
# Unit test for function get_key
def test_get_key():
    print('Please move cursor up, down and press enter button')
    while True:
        key = get_key()
        sys.stdout.write(key)
        if key == '\n':
            break

# Test example in test_get_key
# $ python
#  ...
#  >>> from __future__ import print_function
#  ...
#  >>> from pathlib2 import Path
#  ...
#  >>> from cli_ui import output
#  ...
#  >>> from cli_ui import ui
#  ...
#  >>> output.init_output()
#  ...
#  >>> ui.test_get_key()
#  Please move cursor up, down and press enter button
#  \x1b[A\x1b[B\n
#  >>>

# Generated at 2022-06-12 12:37:28.495538
# Unit test for function get_key
def test_get_key():
    print("\n Test unitaire de la fonction get_key")
    print(" Appuiez sur 'a'")
    print("Resultat attendu : a")
    print("Resultat obtenu : " + get_key())

    print("\n Appuiez sur les touches flèches")
    print("Resultat attendu : flèche haut, flèche bas")
    print("Resultat obtenu : " + get_key() + get_key())

# test_get_key()

# Generated at 2022-06-12 12:37:29.886142
# Unit test for function open_command
def test_open_command():
    assert open_command('http://google.com') in [
        'xdg-open http://google.com',
        'open http://google.com'
    ]

# Generated at 2022-06-12 12:37:38.166667
# Unit test for function get_key
def test_get_key():
    from msvcrt import getch as getch_win

    def getch_linux():
        import tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

    def test_case():
        def getch_posix():
            import sys
            import tty
            import termios
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)

# Generated at 2022-06-12 12:37:40.430122
# Unit test for function open_command
def test_open_command():
    cmd = open_command("file:///a/b/c")
    assert cmd == 'xdg-open file:///a/b/c'



# Generated at 2022-06-12 12:37:44.745981
# Unit test for function get_key

# Generated at 2022-06-12 12:37:46.987474
# Unit test for function getch
def test_getch():
    init_output()
    print('Press key to get it\'s code (Press q to exit):')
    while True:
        ch = get_key()
        if ch == 'q':
            break
        print(ch)


# Generated at 2022-06-12 12:38:37.855860
# Unit test for function getch
def test_getch():
    print("getch test1", getch())
    print("getch test2", getch())
    print("getch test3", getch())
    print("getch test4", getch())
    print("getch test5", getch())
    print("getch test6", getch())
    print("getch test7", getch())
    print("getch test8", getch())
    print("getch test9", getch())
    print("getch test10", getch())
    print("getch test11", getch())
    print("getch test12", getch())
    print("getch test13", getch())
    print("getch test14", getch())
    print("getch test15", getch())


# Generated at 2022-06-12 12:38:40.322441
# Unit test for function open_command
def test_open_command():
    assert open_command('http://www.baidu.com') == 'open http://www.baidu.com' or open_command('http://www.baidu.com') == 'xdg-open http://www.baidu.com'

# Generated at 2022-06-12 12:38:41.889907
# Unit test for function getch
def test_getch():
    while True:
        print(getch())
    return 0


if __name__ == '__main__':
    exit(test_getch())

# Generated at 2022-06-12 12:38:48.914889
# Unit test for function getch
def test_getch():
    from ..key_mapping import KEY_MAPPING
    import os

    input_stream = os.dup(sys.stdin.fileno())

# Generated at 2022-06-12 12:38:51.387755
# Unit test for function open_command
def test_open_command():
    if os.name == 'nt':
        assert open_command('abc') == 'start abc'
    elif os.name == 'posix':
        assert open_command('abc') == 'xdg-open abc'

# Generated at 2022-06-12 12:38:52.393797
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'

# Generated at 2022-06-12 12:38:56.336064
# Unit test for function open_command
def test_open_command():
    """
    Test if open command is run properly on different platforms
    """
    import subprocess

    exec_list = [open_command('notepad.exe'), open_command('/etc/passwd')]

    for cmd in exec_list:
        subprocess.Popen(cmd, shell=True)

# Generated at 2022-06-12 12:38:58.248942
# Unit test for function getch
def test_getch():
    sys.stdout.write("Please press any key(CTRL+C to exit):")
    sys.stdout.flush()
    while 1:
        ch = getch()

# Generated at 2022-06-12 12:39:00.239947
# Unit test for function get_key
def test_get_key():
    assert get_key() == ' '
    assert get_key() == '\n'
    assert get_key() == '\x1b'



# Generated at 2022-06-12 12:39:03.093952
# Unit test for function get_key
def test_get_key():
    import unittest

    class TestKey(unittest.TestCase):

        def test_up(self):
            self.assertEqual(get_key(), const.KEY_UP)

        def test_down(self):
            self.assertEqual(get_key(), const.KEY_DOWN)

    unittest.main()

# Generated at 2022-06-12 12:39:49.639005
# Unit test for function get_key
def test_get_key():
    class DummyFile(object):
        def __init__(self, data):
            import StringIO
            self.buffer = StringIO.StringIO(data)

        def fileno(self):
            return self.buffer.fileno()

    sys.stdin = DummyFile("a\x1b[A\x1b[B\x1b]x")
    assert get_key() == 'a'
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN
    assert get_key() == 'x'

# Generated at 2022-06-12 12:39:56.740745
# Unit test for function get_key
def test_get_key():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
    input_str = """\x1b[B1234567890-=\x1b\x7f\x1b[AQWERTYUIOP[]\x1b\x1b[DASDFGHJKLM;'\x1b[CZXCVBNM,./"""
    sys.stdin = io.StringIO(input_str)
    while True:
        key = get_key()
        print(key)
        if key == '\x1b':
            break
    sys.stdin = sys.__stdin__
    return None

# test_get_key()


# Generated at 2022-06-12 12:40:04.614313
# Unit test for function get_key
def test_get_key():
    # getch()
    # ch = getch()
    # assert ch == 'I', 'I\'m a test'  # This test pass
    #
    # ch = getch()
    # assert ch == '\'', 'I\'m a test'  # This test pass
    #
    # ch = getch()
    # assert ch == '1', 'I\'m a test'  # This test pass
    #
    # ch = getch()
    # assert ch == '\'', 'I\'m a test'  # This test pass
    #
    # ch = getch()
    # assert ch == '!', 'I\'m a test'  # This test pass

    # get_key()
    ch = get_key()
    assert ch == 'I', 'I\'m a test'  # This test pass

   

# Generated at 2022-06-12 12:40:12.223932
# Unit test for function get_key
def test_get_key():
    init_output(convert=True)
    print('Press \'a\' key')
    key = get_key()
    assert key == const.KEY_A, 'Expected \'a\', got {}'.format(key)
    print('Passed')
    print('Press \'up\' key')
    key = get_key()
    assert key == const.KEY_UP, 'Expected \'up\', got {}'.format(key)
    print('Passed')
    print('Press \'down\' key')
    key = get_key()
    assert key == const.KEY_DOWN, 'Expected \'down\', got {}'.format(key)
    print('Passed')
    print('Press \'space\' key')
    key = get_key()

# Generated at 2022-06-12 12:40:13.813601
# Unit test for function open_command
def test_open_command():
    assert open_command('http://www.example.com/') == 'xdg-open http://www.example.com/'

# Generated at 2022-06-12 12:40:18.577258
# Unit test for function get_key
def test_get_key():
    import unittest

    # Test case: User enter a character
    class TestGetKeyCase(unittest.TestCase):
        def test_get_key(self):
            sys.stdin = open('tests/data/input.txt', 'r')
            self.assertEqual(get_key(), 'a')
            sys.stdin = sys.__stdin__

    unittest.main()


if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:40:20.396304
# Unit test for function get_key
def test_get_key():
    print('\nTest function get_key')
    while True:
        print(get_key())

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:40:26.669181
# Unit test for function get_key
def test_get_key():
    print('Testing get_key():')
    print('\twrite Q for quit')
    print('\tand y for yes')
    print('\tand n for no')
    func = get_key
    while True:
        print('Q = quit, y = yes, n = no')
        r = func()
        if r in 'yY':
            print('yes')
        elif r in 'nN':
            print('no')
        elif r in 'Qq':
            print('Quit')
            break


# Generated at 2022-06-12 12:40:27.407738
# Unit test for function getch
def test_getch():
    assert getch() == 'a'

# Generated at 2022-06-12 12:40:31.278768
# Unit test for function get_key
def test_get_key():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_key(self):
            self.assertEqual(const.KEY_W, get_key())

# Generated at 2022-06-12 12:41:56.629536
# Unit test for function get_key
def test_get_key():
    assert get_key() == const.KEY_B

# Generated at 2022-06-12 12:41:59.633379
# Unit test for function get_key
def test_get_key():
    print('Testing get_key()')
    for i in 'abcdefghijklmnopqrstuvwxyz':
        print(get_key())
    for i in '0123456789':
        print(get_key())
    for i in '`-=[]\\;\'\",./':
        print(get_key())



# Generated at 2022-06-12 12:42:03.626287
# Unit test for function getch
def test_getch():
    print("Testing getch function...")
    const.KEY_MAPPING = {
        "a": "a",
        "b": "b",
        "c": "c",
        "d": "d",
    }
    if getch() in const.KEY_MAPPING:
        print("Test passed")
        return True
    else:
        print("Test failed")
        return False



# Generated at 2022-06-12 12:42:07.947759
# Unit test for function get_key
def test_get_key():
    assert getch() == '\x1b'
    assert get_key() == const.KEY_ESCAPE
    assert getch() == '\x01'
    assert get_key() == const.KEY_CONTROL_A
    assert get_key() == const.KEY_UP
    sys.exit(0)

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:42:11.524379
# Unit test for function open_command
def test_open_command():
    assert sys.platform.startswith('linux') is True or  sys.platform.startswith('darwin') is True
    cmd = open_command('www.google.com')
    if sys.platform.startswith('linux'):
        assert cmd == 'xdg-open www.google.com'
    elif sys.platform.startswith('darwin'):
        assert cmd == 'open www.google.com'
    else:
        assert False

# Generated at 2022-06-12 12:42:13.648254
# Unit test for function get_key
def test_get_key():
    import json
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(json.loads(open("rules.json", "r").read()))

# Generated at 2022-06-12 12:42:15.104711
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'

if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-12 12:42:20.185578
# Unit test for function get_key
def test_get_key():
    os.system('stty -echo')
    init_output()

    print()
    print('* Testing function get_key ')
    print('After 3 seconds, start testing')
    print('Press Tab to test, if test is completed then press q')
    for i in range(3):
        print('{}s'.format(3 - i))
        time.sleep(1)
    print()

    print('Testing Tab:')
    print('Press Tab')
    assert get_key() == '\t'

    print()
    print('Testing Up:')
    print('Press Up')
    assert get_key() == const.KEY_UP

    print()
    print('Testing Down:')
    print('Press Down')
    assert get_key() == const.KEY_DOWN

    print()
    print('Testing Enter:')


# Generated at 2022-06-12 12:42:21.365657
# Unit test for function getch
def test_getch():
    os.system('clear')
    print('Press any key, please.')
    ch = get_key()
    os.system('clear')
    print('You have pressed', repr(ch))

# Generated at 2022-06-12 12:42:23.459022
# Unit test for function getch
def test_getch():
    sys.stdin = open('./test/data/stdin.txt')
    assert getch() == 'h'
    assert getch() == 'e'
    assert getch() == 'l'