

# Generated at 2022-06-26 07:10:53.064870
# Unit test for function get_key
def test_get_key():
    try:
        pass
    except NameError:
        assert True



# Generated at 2022-06-26 07:10:55.010268
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()
    assert var_0 == '\n'



# Generated at 2022-06-26 07:10:56.203589
# Unit test for function get_key
def test_get_key():
    assert (test_case_0() == 'a'), 'Get key'


# Generated at 2022-06-26 07:10:58.107811
# Unit test for function open_command
def test_open_command():
    assert open_command('google.com').lower() == 'xdg-open google.com'


# Generated at 2022-06-26 07:11:00.386828
# Unit test for function get_key
def test_get_key():
    print("[][][] Running tests for function get_key:")

    test_case_0()

test_get_key()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 07:11:01.959613
# Unit test for function getch
def test_getch():
    getch()


# Generated at 2022-06-26 07:11:03.783825
# Unit test for function getch
def test_getch():
    assert(get_key() == 'm')


# Generated at 2022-06-26 07:11:14.087668
# Unit test for function getch
def test_getch():
    configuration = {'function_name': 'getch',                        # string
                     'test_cases': [                                   # list
                         {'input': '', 'expected': ''},
                        ]
                     }

    path_0 = None if find_executable('clear') else Path('.')

    for test_case in configuration['test_cases']:
        sys.stdout = sys.__stdout__
        sys.stdout.flush()
        sys.stdin = sys.__stdin__
        sys.stdin.flush()
        sys.stdin = open(os.devnull)
        global_variables = {}
        local_variables = {}
        exec('from utils import '+configuration['function_name']+'\nfrom colorama import init', global_variables)

# Generated at 2022-06-26 07:11:16.712462
# Unit test for function open_command
def test_open_command():
    var_0 = open_command('test')
    assert var_0 == "xdg-open test"

if __name__ == "__main__":
    print(open_command('test'))

# Generated at 2022-06-26 07:11:20.464305
# Unit test for function open_command
def test_open_command():
    assert open_command('www.baidu.com') == 'xdg-open www.baidu.com' or 'open www.baidu.com'


# Generated at 2022-06-26 07:11:25.381840
# Unit test for function get_key
def test_get_key():
    text_0 = var_0


# Generated at 2022-06-26 07:11:29.113298
# Unit test for function get_key
def test_get_key():
    try:
        setattr(sys.modules[__name__], "__unittest", True)
        test_case_0()
    except Exception as e:
        print('Test case 0 failed', e)
    finally:
        delattr(sys.modules[__name__], '__unittest')

# Generated at 2022-06-26 07:11:31.501632
# Unit test for function getch
def test_getch():
    var_0 = get_key()


# Generated at 2022-06-26 07:11:32.873687
# Unit test for function get_key
def test_get_key():
    assert True


# Generated at 2022-06-26 07:11:35.149602
# Unit test for function open_command
def test_open_command():
    assert open_command('') == 'xdg-open '
    assert open_command('a') == 'xdg-open a'


# Generated at 2022-06-26 07:11:39.060102
# Unit test for function open_command
def test_open_command():
    assert open_command('arg') == 'xdg-open arg'
    assert open_command('arg') != 'xdg-open arg1'
    assert open_command('arg') != 'open arg'


# Generated at 2022-06-26 07:11:41.998094
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()
    assert var_0 == '\x1b[A'
    assert var_0 == '\x1b[B'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 07:11:43.709086
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()



# Generated at 2022-06-26 07:11:45.522355
# Unit test for function getch
def test_getch():
    expected_result = "ab"
    result = test_case_0()

    assert result == expected_result

# Generated at 2022-06-26 07:11:46.578276
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()
    assert True

# Generated at 2022-06-26 07:11:58.271982
# Unit test for function open_command
def test_open_command():
    assert open_command("www.example.com") == "xdg-open www.example.com"

test_case_0()
test_open_command()

# Generated at 2022-06-26 07:11:59.462807
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()


# Generated at 2022-06-26 07:12:01.712748
# Unit test for function get_key
def test_get_key():
    print('Testing function get_key')

    var_0 = get_key()
    # TODO: add assertion

# Generated at 2022-06-26 07:12:03.117679
# Unit test for function get_key
def test_get_key():
    global var_0
    var_0 = get_key()



# Generated at 2022-06-26 07:12:04.841933
# Unit test for function getch
def test_getch():
    assert getch() == '\x03', 'Input any character and press enter'


# Generated at 2022-06-26 07:12:06.126359
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == None


# Generated at 2022-06-26 07:12:07.356364
# Unit test for function get_key
def test_get_key():
    assert const.KEY_UP == test_case_0()


# Generated at 2022-06-26 07:12:10.915985
# Unit test for function open_command
def test_open_command():
    try:
        assert open_command("test_files/test.mp3") == "xdg-open " + "test_files/test.mp3"
    except Exception:
        return False
    return True


# Generated at 2022-06-26 07:12:12.308590
# Unit test for function get_key
def test_get_key():
    # Assert
    assert test_case_0() == 'a'



# Generated at 2022-06-26 07:12:14.204873
# Unit test for function open_command
def test_open_command():
    pass
if __name__ == '__main__':
    test_open_command()
    test_case_0()

# Generated at 2022-06-26 07:12:37.619137
# Unit test for function get_key
def test_get_key():
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
    assert get_key() == ""
   

# Generated at 2022-06-26 07:12:41.619617
# Unit test for function get_key
def test_get_key():
    cases = [
            test_case_0,
    ]
    fail_count = 0
    for case in cases:
        try:
            case()
        except AssertionError:
            fail_count += 1
    if fail_count > 0:
        return False
    return True


# Generated at 2022-06-26 07:12:42.507577
# Unit test for function get_key
def test_get_key():
    test_case_0()

# Generated at 2022-06-26 07:12:44.786485
# Unit test for function open_command
def test_open_command():
    assert open_command('file.txt') == 'xdg-open file.txt' or open_command('file.txt') == 'open file.txt'


# Generated at 2022-06-26 07:12:47.611075
# Unit test for function getch
def test_getch():
    assert getch() == None


# Generated at 2022-06-26 07:12:48.982436
# Unit test for function get_key
def test_get_key():
    assert get_key() == ('E', [])


# Generated at 2022-06-26 07:12:49.568902
# Unit test for function getch
def test_getch():
    assert 0 == 0

# Generated at 2022-06-26 07:12:52.509188
# Unit test for function open_command
def test_open_command():
    print("Testing open_command(arg)")
    if open_command("") == "xdg-open ":
        print("Successful !")
    else:
        print("Failed !")


# Generated at 2022-06-26 07:12:54.447412
# Unit test for function get_key
def test_get_key():
    # Set up test values
    arg_0 = get_key()
    arg_1 = ''

    # Call the function
    test_case_0(arg_0, arg_1)

    # Check the results



# Generated at 2022-06-26 07:12:55.698321
# Unit test for function get_key
def test_get_key():
    test_case_0()

# Generated at 2022-06-26 07:13:19.768506
# Unit test for function getch
def test_getch():
    var_0 = getch()
    var_1 = getch()
    var_2 = getch()
    var_3 = getch()


# Generated at 2022-06-26 07:13:21.329110
# Unit test for function get_key
def test_get_key():
    assert test_case_0() is not None
    return 0

# Generated at 2022-06-26 07:13:22.693513
# Unit test for function open_command
def test_open_command():
    assert open_command('somedir') == 'open somedir'


# Generated at 2022-06-26 07:13:26.766415
# Unit test for function getch
def test_getch():
    # For function getch, I would test whether it is successful to get a key value
    # With 1/10 probability, a key value is returned
    var_0 = get_key()
    assert var_0 is not None


# Generated at 2022-06-26 07:13:28.406163
# Unit test for function getch
def test_getch():
    assert getch() is not None


# Generated at 2022-06-26 07:13:30.622271
# Unit test for function open_command
def test_open_command():
    assert_equals(open_command("https://www.google.com"), "open https://www.google.com")

# Generated at 2022-06-26 07:13:31.614809
# Unit test for function get_key
def test_get_key():
    get_key()


# Generated at 2022-06-26 07:13:36.055917
# Unit test for function getch
def test_getch():
    assert os.environ == {"PAGER": "less", "PATH": "/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/Users/loy/opt/miniconda3/bin"}


# Generated at 2022-06-26 07:13:38.518190
# Unit test for function open_command
def test_open_command():
    assert type(open_command('./')) == str,  "return is not str"
    assert len( open_command('./')) != 0,    "return len is 0"

# Generated at 2022-06-26 07:13:40.835565
# Unit test for function get_key
def test_get_key():

    with mock.patch("builtins.input", side_effect=["a"]):
        test_case_0()

# Generated at 2022-06-26 07:14:03.701543
# Unit test for function getch
def test_getch():
    pass

# Generated at 2022-06-26 07:14:05.003267
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == True


# Generated at 2022-06-26 07:14:06.833005
# Unit test for function getch
def test_getch():
    assert callable(getch)
    var_0 = getch()
    assert True


# Generated at 2022-06-26 07:14:11.110912
# Unit test for function get_key
def test_get_key():
    try:
        test_case_0()
    except (Exception) as ex:
        print('[x] test_case_0 failed!')


if __name__ == '__main__':
    try:
        test_get_key()
    except (Exception) as ex:
        print('[x] test.py failed!')

# Generated at 2022-06-26 07:14:19.424766
# Unit test for function getch
def test_getch():
    import random
    for _ in range(10):
        ch_0 = random.randint(0, 255)
        var_0 = os._exists_()

# Generated at 2022-06-26 07:14:20.263595
# Unit test for function get_key
def test_get_key():
    assert get_key() != None

# Generated at 2022-06-26 07:14:22.254553
# Unit test for function open_command
def test_open_command():
    var_0 = open_command()
    if var_0 is None:
        raise Exception


# Generated at 2022-06-26 07:14:24.598129
# Unit test for function open_command
def test_open_command():
    assert open_command("/usr/bin/env python") == "xdg-open /usr/bin/env python"
    
    

# Generated at 2022-06-26 07:14:26.527189
# Unit test for function getch
def test_getch():
    if hasattr(getch, 'unit_test'):
        getch.unit_test()


# Generated at 2022-06-26 07:14:28.935812
# Unit test for function get_key
def test_get_key():
     
    # Test case 0
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 07:14:52.049151
# Unit test for function get_key
def test_get_key():
    pass


# Generated at 2022-06-26 07:14:53.504489
# Unit test for function get_key
def test_get_key():
    assert_equals(test_case_0(), test_case_0())

# Generated at 2022-06-26 07:15:01.284911
# Unit test for function open_command
def test_open_command():
    # Unrecognised path
    assert open_command('some_file_or_dir') == \
        'xdg-open some_file_or_dir'

    # Path is a directory
    assert open_command('/some_dir') == 'xdg-open /some_dir'

    # Path is a file
    assert open_command('/some_file') == 'xdg-open /some_file'

    # Windows path
    assert open_command(r'C:\some_file') == 'xdg-open C:\\some_file'

    # Proper path
    assert open_command('') == 'xdg-open '



# Generated at 2022-06-26 07:15:04.051152
# Unit test for function getch
def test_getch():
    assert(len(getch()) == 1)


# Generated at 2022-06-26 07:15:05.807229
# Unit test for function open_command
def test_open_command():
    assert open_command.__doc__ is not None


# Generated at 2022-06-26 07:15:10.611078
# Unit test for function getch
def test_getch():
    print('Testing getch')
    # FIXME: This test is failing on Windows. Figure out why.
    #assert getch() == chr(27)
    assert getch() == '\x1b'
    assert getch() == '\x1b'
    assert getch() == '\x1b'


# Generated at 2022-06-26 07:15:12.275944
# Unit test for function getch
def test_getch():
    var_0 = getch()
    assert(var_0 == 'q');


# Generated at 2022-06-26 07:15:13.240836
# Unit test for function getch
def test_getch():
    print("Testing getch() function")
    test_case_0()



# Generated at 2022-06-26 07:15:18.950459
# Unit test for function get_key
def test_get_key():

    if(sys.version_info < (3, 0)):
        fp = open('tests/get_key_test_input_0.txt', 'w')
        fp.write('\x1b[A\n')
        fp.close()
        sys.stdin = open('tests/get_key_test_input_0.txt')

        test_case_0()
    else:
        fp = open('tests/get_key_test_input_0.txt', 'wb')
        fp.write(const.KEY_UP)
        fp.close()
        sys.stdin = open('tests/get_key_test_input_0.txt', 'rb')

        test_case_0()

# Generated at 2022-06-26 07:15:19.987196
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'q'

# Generated at 2022-06-26 07:15:49.508659
# Unit test for function getch
def test_getch():
    # Define a variable
    var_0 = getch()
    assert var_0 == '\x1b'
    var_0 = getch()
    assert var_0 == '['
    var_0 = getch()
    assert var_0 == 'A'
    var_0 = getch()
    assert var_0 == '\x1b'
    var_0 = getch()
    assert var_0 == '['
    var_0 = getch()
    assert var_0 == 'B'
    var_0 = getch()
    assert var_0 == '\x1b'
    var_0 = getch()
    assert var_0 == '['
    var_0 = getch()
    assert var_0 == 'C'
    var_0 = getch()

# Generated at 2022-06-26 07:15:51.754335
# Unit test for function getch
def test_getch():
    test_case_0()

# Generated at 2022-06-26 07:15:53.543510
# Unit test for function get_key
def test_get_key():
    print('Running unit test for function get_key...')
    test_case_0()



# Generated at 2022-06-26 07:15:55.132855
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b[A'

# Generated at 2022-06-26 07:15:58.049790
# Unit test for function open_command
def test_open_command():
    os.system(open_command("http://facebook.com"))
    os.system(open_command("facebook.com"))
    os.system(open_command("http://9gag.com"))

# Generated at 2022-06-26 07:16:00.686492
# Unit test for function open_command
def test_open_command():
    global args
    assert open_command('*') == 'xdg-open *'
    assert open_command('*') == 'xdg-open *'



# Generated at 2022-06-26 07:16:01.533008
# Unit test for function get_key
def test_get_key():
    test_case_0()

# Generated at 2022-06-26 07:16:03.899865
# Unit test for function getch
def test_getch():
    assert getch() is not None


# Generated at 2022-06-26 07:16:07.998715
# Unit test for function get_key
def test_get_key():

    # Test 1: Test whether is_upper_triangle_matrix returns True when input
    # is a lower triangle matrix
    var_0 = get_key()
    if var_0 == '\x1b':
        return True

    return False


# Generated at 2022-06-26 07:16:09.953962
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'q'


# Generated at 2022-06-26 07:16:33.427251
# Unit test for function open_command
def test_open_command():
    assert find_executable('xdg-open')

# Generated at 2022-06-26 07:16:35.300905
# Unit test for function getch
def test_getch():
    try:
        getch()
        return 0
    except:
        return 1


# Generated at 2022-06-26 07:16:40.068078
# Unit test for function get_key
def test_get_key():
    # expected: p
    var_1 = get_key()
    assert var_1 == "p"
    # expected: k
    var_2 = get_key()
    assert var_2 == "k"
    # expected: q
    var_3 = get_key()
    assert var_3 == "q"
    # expected: c
    var_4 = get_key()
    assert var_4 == "c"

# Generated at 2022-06-26 07:16:40.853808
# Unit test for function get_key
def test_get_key():
    test_case_0()

# Generated at 2022-06-26 07:16:43.786043
# Unit test for function get_key

# Generated at 2022-06-26 07:16:45.113734
# Unit test for function get_key
def test_get_key():
    var_1 = get_key()


# Generated at 2022-06-26 07:16:47.335481
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == 1


# Generated at 2022-06-26 07:16:48.237087
# Unit test for function getch
def test_getch():
    assert 1 == 1



# Generated at 2022-06-26 07:16:49.322875
# Unit test for function get_key
def test_get_key():
    test_case_0()
    assert True

# Generated at 2022-06-26 07:16:50.874420
# Unit test for function get_key
def test_get_key():
    ch = get_key()
    assert (ch != None)


# Generated at 2022-06-26 07:17:14.323414
# Unit test for function get_key
def test_get_key():
    var_1 = get_key()

# Generated at 2022-06-26 07:17:15.589028
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == None



# Generated at 2022-06-26 07:17:16.855233
# Unit test for function get_key
def test_get_key():
    assert get_key.__name__ == 'get_key'



# Generated at 2022-06-26 07:17:17.578692
# Unit test for function open_command
def test_open_command():
    assert open_command("local/path") == "xdg-open local/path"


# Generated at 2022-06-26 07:17:18.228343
# Unit test for function getch
def test_getch():
    assert getch() == get_key()


# Generated at 2022-06-26 07:17:19.054424
# Unit test for function getch
def test_getch():
    assert getch() == 'q'


# Generated at 2022-06-26 07:17:27.159187
# Unit test for function get_key
def test_get_key():
    # Check constants
    assert const.KEY_UP == "KEY_UP"
    assert const.KEY_DOWN == "KEY_DOWN"
    assert const.KEY_NEXT == "KEY_NEXT"
    assert const.KEY_PREV == "KEY_PREV"
    assert const.KEY_DELETE == "KEY_DELETE"
    assert const.KEY_SWITCH == "KEY_SWITCH"
    assert const.KEY_QUIT == "KEY_QUIT"
    assert const.KEY_RETURN == "KEY_RETURN"
    assert const.KEY_TAB == "KEY_TAB"

    assert const.KEY_MAPPING['A'] == "KEY_UP"
    assert const.KEY_MAPPING['B'] == "KEY_DOWN"

# Generated at 2022-06-26 07:17:29.529683
# Unit test for function get_key
def test_get_key():
    var_0 = get_key()
    assert var_0 == b'\x1b', 'Returned value check failed: ' + var_0

# Generated at 2022-06-26 07:17:31.459822
# Unit test for function get_key
def test_get_key():
    init_output()
    assert get_key() in const.KEY_MAPPING


# Generated at 2022-06-26 07:17:42.198393
# Unit test for function getch
def test_getch():
    from subprocess import call
    from subprocess import Popen, PIPE
    import sys
    import random
    import string

    leet = string.ascii_letters + string.digits

    # Generate random string to simulate user input
    input_0 = ''.join([random.choice(leet) for n in range(0, random.randrange(10))])

    # Open new process to execute function
    function_name = "getch"
    p = Popen([sys.executable, "-c",
               "from __main__ import " + function_name + "; " + function_name + "()"],
              stdout=PIPE, stdin=PIPE)

    # Send user input to process
    p.stdin.write(bytes(input_0 + "\n", 'UTF-8'))
   

# Generated at 2022-06-26 07:18:12.732680
# Unit test for function get_key
def test_get_key():
    var_1 = getch()
    print('key pressed: ')
    print(var_1)


if __name__ == "__main__":
    print('*****Running tests*****')
    test_case_0()
    test_get_key()

# Generated at 2022-06-26 07:18:16.275045
# Unit test for function get_key
def test_get_key():
    print('Testing function get_key')

    var_0 = get_key()
    assert var_0 == '\x1b[A', 'Return not as expected, returned: "{}"'.format(var_0)


# Generated at 2022-06-26 07:18:17.251270
# Unit test for function get_key
def test_get_key():
    assert get_key() == None


# Generated at 2022-06-26 07:18:18.691109
# Unit test for function get_key
def test_get_key():
    assert test_case_0()

print("test_1")

# Generated at 2022-06-26 07:18:21.623393
# Unit test for function get_key
def test_get_key():
    assert get_key() == "a" or get_key() == "b"


# Generated at 2022-06-26 07:18:22.885201
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'q' or 'Q' or 'e' or 'E' or const.KEY_UP or const.KEY_DOWN or const.KEY_CTR_C

# Generated at 2022-06-26 07:18:25.014111
# Unit test for function getch
def test_getch():
    # Create test case
    var_0 = getch()

    # Check
    assert var_0 == 'not_implemented'


# Generated at 2022-06-26 07:18:25.709584
# Unit test for function get_key
def test_get_key():
    pass

# Generated at 2022-06-26 07:18:27.476799
# Unit test for function get_key
def test_get_key():
    assert get_key() is None
    


# Generated at 2022-06-26 07:18:29.597087
# Unit test for function open_command
def test_open_command():
    assert open_command('') == 'xdg-open ' or \
        open_command('') == 'open '


# Generated at 2022-06-26 07:19:18.376114
# Unit test for function open_command
def test_open_command():
    var_0 = open_command('http://www.google.com')


# Generated at 2022-06-26 07:19:19.459818
# Unit test for function get_key
def test_get_key():
    assert test_case_0() is None


# Generated at 2022-06-26 07:19:21.937339
# Unit test for function open_command
def test_open_command():
    assert open_command("baidu.com") == 'xdg-open baidu.com' or open_command("baidu.com") == 'open baidu.com'

# Generated at 2022-06-26 07:19:23.107269
# Unit test for function get_key
def test_get_key():
    assert get_key() == ' '

# Generated at 2022-06-26 07:19:27.080831
# Unit test for function get_key
def test_get_key():
    var_1 = get_key()
    assert var_1 == " ", "get_key"
    assert var_1 == "j", "get_key"
    assert var_1 == "k", "get_key"
    assert var_1 == "q", "get_key"



# Generated at 2022-06-26 07:19:27.612774
# Unit test for function get_key
def test_get_key():
    return

# Generated at 2022-06-26 07:19:32.118022
# Unit test for function getch
def test_getch():
    if sys.platform.startswith('linux'):
        assert getch() == 'a'
    elif sys.platform == 'darwin':
        assert getch() == '\x03'
    elif sys.platform == 'win32':
        assert getch() == '\x1b'
    else:
        raise


# Generated at 2022-06-26 07:19:35.176292
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == '\x1b[A'
    assert test_case_0() == '\x1b[B'
    assert test_case_0() == 'm'
    assert test_case_0() == 'b'


# Generated at 2022-06-26 07:19:37.902347
# Unit test for function get_key
def test_get_key():
    print("Testing get_key...")
    g_test_cases = (
        test_case_0
    )

    for test_case in g_test_cases:
        test_case()

    print("Done!")



# Generated at 2022-06-26 07:19:38.753379
# Unit test for function get_key
def test_get_key():
    assert test_case_0() == '\x1b'

# Generated at 2022-06-26 07:20:35.665274
# Unit test for function getch
def test_getch():
    # If assert is true, the test is passed
    print(getch())
    assert getch() != None


# Generated at 2022-06-26 07:20:45.944843
# Unit test for function getch
def test_getch():
    """
    Tests getch

    :return:
    """
    # Get key
    var_0 = get_key()

    # Check if key is in key mapping
    if var_0 in const.KEY_MAPPING:
        # Return const
        var_1 = const.KEY_MAPPING[var_0]
    elif var_0 == '\x1b':
        # Get next key
        var_1 = getch()
        # Check if next key is [
        if var_1 == '[':
            # Get last key
            var_2 = getch()
            # Check if last key is A
            if var_2 == 'A':
                pass
                # Return const key up
            elif var_2 == 'B':
                pass
                # Return const key down
    # Return key
    var_

# Generated at 2022-06-26 07:20:49.175358
# Unit test for function open_command
def test_open_command():
    var_0 = open_command('/home/')
