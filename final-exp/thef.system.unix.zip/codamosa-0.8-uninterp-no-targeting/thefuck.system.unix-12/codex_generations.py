

# Generated at 2022-06-22 02:48:24.364333
# Unit test for function get_key
def test_get_key():
    print('press keys to test function get_key')
    while True:
        print(get_key())


if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-22 02:48:28.753881
# Unit test for function getch
def test_getch():
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, termios.tcgetattr(sys.stdin))
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, termios.tcgetattr(sys.stdin))
    sys.stdin.read(1)
    colorama.init(autoreset=True)


if __name__ == "__main__":
    test_getch()

# Generated at 2022-06-22 02:48:30.269925
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'h'

# Generated at 2022-06-22 02:48:34.400956
# Unit test for function getch
def test_getch():

    for key in const.KEY_MAPPING.keys():
        assert(getch() == key)

    for key in const.KEY_MAPPINGS.keys():
        assert(getch() == key)


if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-22 02:48:37.955608
# Unit test for function getch
def test_getch():
    print('='*40)
    print('Testing function getch')
    print('='*40)
    print('Press key \'a\'')
    assert(getch() == 'a')

# Generated at 2022-06-22 02:48:39.384802
# Unit test for function getch
def test_getch():
    assert getch() == '1'
    assert getch() == '2'

# Generated at 2022-06-22 02:48:41.624519
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'

# Generated at 2022-06-22 02:48:42.904467
# Unit test for function getch
def test_getch():
    assert getch() is not None

# Generated at 2022-06-22 02:48:52.556990
# Unit test for function getch
def test_getch():
    # Some functional tests for getch()
    # This is a very basic test for getch()
    # Please run it in a VT100 terminal or a terminal emulator
    #
    # Use the arrow keys to test for the escape sequence.
    # Use PgUp and PgDown to test for the escape sequence.
    # Press "A" to test for single character.
    # Press "F1" to test for function key.
    # Press "ctrl + d" to exit.

    print('Testing getch()...')
    while True:
        print()
        print('Please press "F1", "A", "PgUp", "PgDown", "up arrow", "down arrow" or "ctrl + d".')
        ch = getch()
        print(repr(ch))

        if ch == '\x04':
            print('EOF')

# Generated at 2022-06-22 02:48:53.194722
# Unit test for function get_key
def test_get_key():
    pass

# Generated at 2022-06-22 02:49:02.735939
# Unit test for function getch
def test_getch():
    import os
    import sys
    import tempfile
    import unittest

    class GetchTests(unittest.TestCase):
        def setUp(self):
            self.null_fd = os.open(os.devnull, os.O_RDWR)
            self.save_stdin = os.dup(sys.stdin.fileno())
            self.save_stdout = os.dup(sys.stdout.fileno())
            self.save_stderr = os.dup(sys.stderr.fileno())
            os.dup2(self.null_fd, sys.stdin.fileno())
            os.dup2(self.null_fd, sys.stdout.fileno())

# Generated at 2022-06-22 02:49:05.269976
# Unit test for function get_key
def test_get_key():
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN

# Generated at 2022-06-22 02:49:09.827780
# Unit test for function getch
def test_getch():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

    return ch


# Generated at 2022-06-22 02:49:12.259874
# Unit test for function getch
def test_getch():
    from .testutil import get_input

    with get_input('a') as input_func:
        assert getch() == 'a'



# Generated at 2022-06-22 02:49:14.560787
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'i'
    assert get_key() == 'q'



# Generated at 2022-06-22 02:49:16.343252
# Unit test for function get_key
def test_get_key():
    tty_path = '/dev/tty'
    assert isinstance(get_key(tty_path), str)

# Generated at 2022-06-22 02:49:17.441272
# Unit test for function getch
def test_getch():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 02:49:26.117236
# Unit test for function open_command
def test_open_command():
    platform_name = sys.platform
    if platform_name == "darwin":
        assert open_command('https://www.google.com') == 'open https://www.google.com'
    elif platform_name == "linux":
        assert open_command('https://www.google.com') == 'xdg-open https://www.google.com'
    elif platform_name == "win32":
        assert open_command('https://www.google.com') == 'cmd.exe /C start https://www.google.com'


# Generated at 2022-06-22 02:49:27.603063
# Unit test for function get_key
def test_get_key():
    # getch and get_key has been tested manually
    pass

# Generated at 2022-06-22 02:49:32.768512
# Unit test for function get_key
def test_get_key():
    assert const.KEY_LEFT == get_key()
    assert const.KEY_UP == get_key()
    assert const.KEY_DOWN == get_key()
    assert const.KEY_RIGHT == get_key()
    assert const.KEY_TAB == get_key()
    assert const.KEY_ENTER == get_key()
    assert const.KEY_DELETE == get_key()

# Generated at 2022-06-22 02:49:36.706865
# Unit test for function getch
def test_getch():
    assert getch() == '\x1b'

# Generated at 2022-06-22 02:49:39.327368
# Unit test for function open_command
def test_open_command():
    assert open_command('/etc/passwd') == 'open /etc/passwd'
    assert open_command('/etc/passwd') != 'open /etc/passwd'


# Generated at 2022-06-22 02:49:40.594626
# Unit test for function getch
def test_getch():
    key = getch()
    print(key)



# Generated at 2022-06-22 02:49:41.503468
# Unit test for function get_key
def test_get_key():
    assert get_key == b"\x1b"

# Generated at 2022-06-22 02:49:53.761669
# Unit test for function get_key
def test_get_key():
    key_result = []
    key_expected = []
    
    print("test_get_key...CTRL+C to exit")
    try:
        while True:
            key_result.append(get_key())
    except KeyboardInterrupt:
        print()
        print(key_result)

    key_expected.append(u'\x1b')
    key_expected.append(u'[')
    key_expected.append(u'A')
    key_expected.append(u'\x1b')
    key_expected.append(u'[')
    key_expected.append(u'B')
    key_expected.append(u'\x1b')
    key_expected.append(u'[')
    key_expected.append(u'A')

# Generated at 2022-06-22 02:50:05.382668
# Unit test for function getch
def test_getch():
    tests = (
        '\x1b',
        '\x1b[',
        '\x1b[A',
        '\x1b[B',
        '\x1b[C',
        '\x1b[D',
        '\r',
        '\n',
        '\t',
        ' ',
        'i',
        'j',
        'k',
        'l',
        'u',
        'v',
        'q',
        'g',
        'x',
        'a',
        'b',
        'd',
        'A',
        'B',
        'C',
        'D',
        '\x7f',
    )


# Generated at 2022-06-22 02:50:11.423218
# Unit test for function get_key
def test_get_key():
    import curses

    def __get_key(stdscr):
        stdscr.addstr("Press 'Esc' or 'q' to exit")
        while True:
            ch = get_key()
            if ch == 'q' or ch == '\x1b':
                break
            stdscr.addstr("\nKey pressed: " + str(ch))

    curses.wrapper(__get_key)

# Generated at 2022-06-22 02:50:12.208286
# Unit test for function getch
def test_getch():
    assert getch() == 'k'


if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-22 02:50:22.647366
# Unit test for function open_command
def test_open_command():
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'

# Generated at 2022-06-22 02:50:23.667459
# Unit test for function getch
def test_getch():
    assert getch() in const.KEY_MAPPING

# Generated at 2022-06-22 02:50:30.352107
# Unit test for function open_command
def test_open_command():
    assert open_command('img.png') == 'xdg-open img.png'

# Generated at 2022-06-22 02:50:33.105320
# Unit test for function getch
def test_getch():
    print(get_key())


if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-22 02:50:34.668649
# Unit test for function getch
def test_getch():
    from .. import views
    import builtins
    builtins.getch = getch
    assert views.getch() == '\n'

# Generated at 2022-06-22 02:50:37.484916
# Unit test for function getch
def test_getch():
    print('Press "q" to quit the test')
    for i in range(10):
        ch = getch()
        print('You pressed: ', ch)
        if ch == 'q':
            break

# Generated at 2022-06-22 02:50:44.074364
# Unit test for function get_key
def test_get_key():
    init_output()

# Generated at 2022-06-22 02:50:52.034843
# Unit test for function getch
def test_getch():
    pass
    # out = sys.stdout
    # try:
    #     open('test_getch.txt', 'a').close()
    #     sys.stdout = open('test_getch.txt', 'w')
    #
    #     for i in range(0, 255):
    #         ch = getch()
    #         if ch == '\x03':
    #             break
    #         print(ch)
    # finally:
    #     sys.stdout = out

# Generated at 2022-06-22 02:50:55.015460
# Unit test for function open_command
def test_open_command():
    assert open_command('/tmp') == 'xdg-open /tmp'
    assert open_command('/tmp') == 'xdg-open /tmp'



# Generated at 2022-06-22 02:51:01.748102
# Unit test for function get_key
def test_get_key():
    # test case 1
    assert get_key() == const.KEY_ENTER
    # test case 2
    assert get_key() == const.KEY_UP
    # test case 3
    assert get_key() == const.KEY_DOWN
    # test case 4
    assert get_key() == 'a'
    # test case 5
    assert get_key() == 'c'


# Generated at 2022-06-22 02:51:12.040500
# Unit test for function get_key
def test_get_key():
    def test(data, expected_result):
        assert get_key() == expected_result

    test('\x1b\x5b\x41', 'KEY_UP')  # Up arrow
    test('\x1b\x5b\x42', 'KEY_DOWN')  # Down arrow
    test('\r', 'ENTER')  # Enter key
    test('\x1b\x5b\x33\x7e', 'DELETE')  # Delete key
    test('\x7f', 'BACKSPACE')  # Backspace
    test('\x1b\x1b', 'ESC')  # Escape Key
    test('\x1b', 'ESC')  # Escape Key

# Generated at 2022-06-22 02:51:13.900329
# Unit test for function open_command
def test_open_command():
    assert open_command('test') == 'xdg-open test'

# Generated at 2022-06-22 02:51:23.022048
# Unit test for function open_command
def test_open_command():
    import subprocess
    if os.name == "nt":
        assert open_command(r"http://google.com") == "start http://google.com"
    else:
        assert open_command("http://google.com") in ("xdg-open http://google.com", "open http://google.com")



# Generated at 2022-06-22 02:51:24.276383
# Unit test for function get_key
def test_get_key():
    assert get_key() == const.KEY_DOWN

# Generated at 2022-06-22 02:51:28.268787
# Unit test for function open_command
def test_open_command():
    if os.name == 'nt':
        assert open_command('a.txt') == 'start a.txt'
    else:
        assert open_command('a.txt') in ['open a.txt', 'xdg-open a.txt']


# Generated at 2022-06-22 02:51:29.548456
# Unit test for function getch
def test_getch():
    getch()


# Generated at 2022-06-22 02:51:35.365870
# Unit test for function getch
def test_getch():
    input_list = [
        const.KEY_ESCAPE,
        const.KEY_UP,
        const.KEY_DOWN,
        const.KEY_ENTER,
    ]

    for c in input_list:
        print('Press key: ' + c)
        res = getch()
        assert res == c



# Generated at 2022-06-22 02:51:38.385652
# Unit test for function get_key
def test_get_key():
    init_output()
    print("Test get_key function:")
    print("Input '1' in 1 seconds")
    time.sleep(1)
    key = get_key()
    assert key == '1'

# Generated at 2022-06-22 02:51:39.674925
# Unit test for function open_command
def test_open_command():
    assert True



# Generated at 2022-06-22 02:51:41.989938
# Unit test for function get_key
def test_get_key():
    assert get_key() == '\x1b'
    assert get_key() == '['
    assert get_key() == 'A'

# Generated at 2022-06-22 02:51:52.520523
# Unit test for function get_key
def test_get_key():
    keys = {'a': 'a', 'b': 'b', '\x1b': '\x1b', '\x1b[A': 'KEY_UP',
            '\x1b[B': 'KEY_DOWN'}

    def get_key_fake(value):
        def faketmp():
            return value
        return faketmp

    getch_backup = getch

    for k, v in keys.items():
        getch.side_effect = get_key_fake(k)
        # getch.side_effect = get_key_fake(k)
        assert get_key() == v

    getch = getch_backup



# Generated at 2022-06-22 02:51:54.477236
# Unit test for function get_key
def test_get_key():
    for i in range(4):
        key = get_key()
        print(key)

# Generated at 2022-06-22 02:52:14.412796
# Unit test for function getch
def test_getch():
    import unittest
    os.unlink('.test_getch')

    class TestGetChar(unittest.TestCase):
        def setUp(self):
            self.original = sys.stdin
            self.file = open('.test_getch', 'w')
            sys.stdin = self.file

        def tearDown(self):
            self.file.close()
            sys.stdin = self.original

        def test_getch(self):
            self.file.write('b')
            self.file.flush()
            self.assertEqual(getch(), 'b')

    unittest.main()

# Generated at 2022-06-22 02:52:18.039915
# Unit test for function open_command
def test_open_command():
    assert open_command('https://github.com/avelino/awesome-go') == 'open https://github.com/avelino/awesome-go'

# Generated at 2022-06-22 02:52:21.561746
# Unit test for function getch
def test_getch():
    print ('Testing function getch')
    while True:
        ch = getch()
        if ch == 'q' or ch == 'Q':
            break
        print ('You pressed ' + ch)


# Generated at 2022-06-22 02:52:23.596552
# Unit test for function getch
def test_getch():
    getch()

if __name__ == '__main__':
    test_getch()

# Generated at 2022-06-22 02:52:27.591925
# Unit test for function open_command
def test_open_command():
    test_str = 'http://www.baidu.com'
    assert 'xdg-open' in open_command(test_str)
    assert 'open' in open_command(test_str)
    assert test_str in open_command(test_str)

# Generated at 2022-06-22 02:52:32.174281
# Unit test for function get_key
def test_get_key():
    from . import mocks
    assert len(mocks.ARROW_KEYS) == 4
    for key, val in mocks.ARROW_KEYS:
        assert get_key() == val


if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-22 02:52:35.037888
# Unit test for function open_command
def test_open_command():
    assert find_executable('xdg-open')
    command = open_command('http://www.google.com')
    assert command == 'xdg-open http://www.google.com'

# Generated at 2022-06-22 02:52:38.321554
# Unit test for function open_command
def test_open_command():
    import os
    assert open_command("/tmp/") == "xdg-open /tmp/"
    assert open_command("/tmp/") == "open /tmp/"

# Generated at 2022-06-22 02:52:42.162249
# Unit test for function getch
def test_getch():
    ch = '\x1b'
    assert ch == getch()

    ch = '['
    assert ch == getch()

    ch = 'A'
    assert ch == getch()



# Generated at 2022-06-22 02:52:54.214401
# Unit test for function getch
def test_getch():
    import mock
    import sys
    import tty

    with mock.patch('sys.stdin', spec=sys.stdin):
        sys.stdin.fileno.return_value = "xxx"
        with mock.patch('termios.tcgetattr', return_value="yyy") as tcgetattr:
            with mock.patch('tty.setraw', return_value=None) as setraw:
                with mock.patch('sys.stdin.read') as read:
                    read.return_value = 'a'
                    assert getch() == 'a'
                    setraw.assert_called_with('xxx')
                    sys.stdin.read.assert_called_with(1)
                    tcgetattr.assert_called_with('xxx')
                    sys.stdin.fileno.assert_called_with()

# Generated at 2022-06-22 02:53:16.840637
# Unit test for function get_key
def test_get_key():
    pass
    # print(get_key())

# Generated at 2022-06-22 02:53:18.613938
# Unit test for function getch
def test_getch():
    # TODO
    pass

# Generated at 2022-06-22 02:53:19.686618
# Unit test for function open_command
def test_open_command():
    assert open_command('fd') == 'open fd'

# Generated at 2022-06-22 02:53:24.707610
# Unit test for function get_key
def test_get_key():
    import tempfile
    with tempfile.TemporaryFile() as f:
        print >> f, "q\r"
        f.flush()
        f.seek(0)
        sys.stdin = f

# Generated at 2022-06-22 02:53:27.647435
# Unit test for function open_command
def test_open_command():
    import subprocess
    try:
        subprocess.Popen([open_command('--version')])
    except Exception:
        raise RuntimeError(
            "`open_command` function is not working, please file a bug report")

# Generated at 2022-06-22 02:53:33.718004
# Unit test for function getch
def test_getch():
    from io import StringIO
    from contextlib import nested

    def mock_stdin(mock):
        return nested(
            mock.patch('sys.stdin', StringIO('a')),
            mock.patch('os.isatty', lambda x: True),
        )

    with mock_stdin(unittest.mock):
        assert getch() == 'a'

# Generated at 2022-06-22 02:53:39.078346
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'a'
    assert get_key() == 'b'
    assert get_key() == const.KEY_UP
    assert get_key() == const.KEY_DOWN


if __name__ == "__main__":
    test_get_key()

# Generated at 2022-06-22 02:53:41.328922
# Unit test for function get_key
def test_get_key():
    colorama.init()
    print('\nPress arrow keys to test')
    while True:
        print('\n', get_key(), end='')
    colorama.deinit()

# Generated at 2022-06-22 02:53:46.334328
# Unit test for function get_key
def test_get_key():
    for key in const.KEY_MAPPING.keys():
        print("Input %s and you should get %s" % (key, const.KEY_MAPPING[key]))
        assert get_key() == const.KEY_MAPPING[key]

# Generated at 2022-06-22 02:53:48.396881
# Unit test for function getch
def test_getch():
    print ('Press the key')
    key = getch()
    print (key)

# python -c 'from output import *; test_getch()'

# Generated at 2022-06-22 02:54:11.470192
# Unit test for function open_command
def test_open_command():
    assert open_command('https://google.com') is not None

# Generated at 2022-06-22 02:54:16.571161
# Unit test for function open_command
def test_open_command():
    # Test for Linux platform
    if sys.platform == 'linux':
        assert open_command('test') == 'xdg-open test'
    else:
        assert open_command('test') == 'open test'

# Generated at 2022-06-22 02:54:18.230213
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'j'
    assert get_key() == 'n'

# Generated at 2022-06-22 02:54:21.463205
# Unit test for function get_key
def test_get_key():
    const.KEY_UP = 'A'
    assert get_key() == 'A'

    init_output()
    const.KEY_MAPPING = {'j': 'B'}
    assert get_key() == 'B'

# Generated at 2022-06-22 02:54:23.120549
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'q'


if __name__ == '__main__':
    test_get_key()

# Generated at 2022-06-22 02:54:26.254488
# Unit test for function open_command
def test_open_command():
    assert(open_command('test.pdf') == 'xdg-open test.pdf')


# Generated at 2022-06-22 02:54:36.387167
# Unit test for function get_key
def test_get_key():
    # type: () -> None
    from .. import __version__
    from .base import print_version

    print_version()
    print(__version__)

    print('Backspace:')
    print(get_key())
    print(get_key())
    print(get_key())
    print('Right arrow:')
    print(get_key())
    print('Left arrow:')
    print(get_key())
    print(get_key())
    print('Up arrow:')
    print(get_key())
    print(get_key())
    print('Down arrow:')
    print(get_key())
    print(get_key())
    print('a')
    print(get_key())
    print('b')
    print(get_key())
    print('c')

# Generated at 2022-06-22 02:54:38.747337
# Unit test for function get_key
def test_get_key():
    a = get_key()
    print(a)

# test_get_key()

# Generated at 2022-06-22 02:54:44.849533
# Unit test for function open_command
def test_open_command():
    assert open_command('https://github.com/simeonfranklin/nerdbank-git-versioning') == 'xdg-open https://github.com/simeonfranklin/nerdbank-git-versioning'
    assert open_command('https://github.com/simeonfranklin/nerdbank-git-versioning') == 'open https://github.com/simeonfranklin/nerdbank-git-versioning'

# Generated at 2022-06-22 02:54:45.433389
# Unit test for function getch
def test_getch():
    pass

# Generated at 2022-06-22 02:55:11.001616
# Unit test for function open_command
def test_open_command():
    args = 'http://www.baidu.com'
    assert open_command(args) == ('xdg-open ' + args) or \
           open_command(args) == ('open ' + args)

# Generated at 2022-06-22 02:55:11.654723
# Unit test for function get_key

# Generated at 2022-06-22 02:55:19.799812
# Unit test for function open_command
def test_open_command():
    print(open_command('"test file name.txt"'))
    print(open_command('test file name.txt'))
    print(open_command('test file name'))
    print(open_command('/test file name.txt'))
    print(open_command('/test file name'))
    print(open_command('/test file name/'))
    print(open_command('file://test file name'))
    print(open_command('http://test file name'))
    print(open_command('"/test file name"'))

# Generated at 2022-06-22 02:55:22.971355
# Unit test for function get_key
def test_get_key():
    for key in const.KEY_MAPPING:
        ch = get_key()
        assert ch == const.KEY_MAPPING[key]

# Generated at 2022-06-22 02:55:31.490991
# Unit test for function open_command
def test_open_command():
    import platform
    import subprocess
    import unittest
    import io
    if platform.system() == 'Windows':
        return 'Not run on Windows'
    class Test(unittest.TestCase):
        def test(self):
            if platform.system() == 'Windows':
                return 'Not run on Windows'
            script_path = os.path.join(os.path.dirname(__file__), 'file.txt')
            f = io.open(script_path, 'w+')
            f.write(u'hello world!')
            f.close()
            subprocess.Popen(open_command(script_path).split())
    unittest.main(argv=['Test'], exit=False)
# Run unit test
if __name__ == '__main__':
    test_open_command

# Generated at 2022-06-22 02:55:41.420255
# Unit test for function getch
def test_getch():
    init_output()

    print("Press any key")
    print("Press enter")
    print("Press esc")
    print("Press up")

    while(1):
        key = getch()

        if key == '\x1b':
            key = getch()
            if key == '[':
                key = getch()
                if key == 'A':
                    print("Up arrow detected")
                elif key == 'B':
                    print("Down arrow detected")
        elif key == '\n':
            print("Enter detected")
        else:
            print("You pressed " + key)
            break



# Generated at 2022-06-22 02:55:47.882106
# Unit test for function getch
def test_getch():
    boson_home = os.environ['BOSONHOME']
    _raw_input = raw_input
    _input = input
    _os_system = os.system

    os.environ['BOSONHOME'] = ''
    raw_input = lambda x: 'y'
    input = lambda x: '1'
    os.system = lambda x: True

    from . import utils
    utils.set_all()

    assert os.environ['BOSONHOME'] == os.path.abspath(os.path.expanduser('~/.boson'))
    assert utils.has_boson_home() == True
    assert utils.has_config() == True
    assert utils.has_sources() == True
    assert utils.is_valid_boson_home() == True

   

# Generated at 2022-06-22 02:55:49.120649
# Unit test for function get_key
def test_get_key():
    assert get_key() == 'a'

# Generated at 2022-06-22 02:55:50.472151
# Unit test for function getch
def test_getch():
    print ("Press key to continue . . .")
    print (get_key())

# Generated at 2022-06-22 02:55:52.459494
# Unit test for function getch
def test_getch():
    assert getch() == '\x03'
    assert get_key() == const.KEY_CTRL_C

# Generated at 2022-06-22 02:56:39.129542
# Unit test for function getch
def test_getch():
    char = getch()
    if char == '\x03':
        print('^C')
    elif char == '\x1a':
        print('^Z')
    elif char == '\r':
        print('^M')
    else:
        print('char = ' + char)


# Generated at 2022-06-22 02:56:40.362442
# Unit test for function getch
def test_getch():
    assert getch() == 'a'

# Generated at 2022-06-22 02:56:42.759684
# Unit test for function getch
def test_getch():
    print("(Press a key... then enter if desired)")
    c = getch()
    print("You pressed", c)
    return True



# Generated at 2022-06-22 02:56:49.894912
# Unit test for function open_command
def test_open_command():
    assert type(find_executable('xdg-open')) == str \
        or type(find_executable('xdg-open')) == bytes
    assert type(find_executable('open')) == str or type(find_executable('open')) == bytes
    assert open_command('./') == 'xdg-open ./' or open_command('./') == 'open ./'

# Generated at 2022-06-22 02:56:53.101260
# Unit test for function get_key
def test_get_key():
    char = get_key()
    assert char == const.KEY_ESCAPE
    char = get_key()
    assert char == 'q'
    assert char != const.KEY_ESCAPE

# Generated at 2022-06-22 02:56:54.234782
# Unit test for function getch
def test_getch():
    print(get_key())



# Generated at 2022-06-22 02:56:55.234333
# Unit test for function getch
def test_getch():
    assert getch() == 'q'

# Generated at 2022-06-22 02:56:56.896557
# Unit test for function open_command
def test_open_command():
    assert find_executable('xdg-open') or find_executable('open')
    assert open_command('/tmp')

# Generated at 2022-06-22 02:56:58.459523
# Unit test for function get_key
def test_get_key():
    #getch()
    print(get_key())

# Generated at 2022-06-22 02:57:04.761612
# Unit test for function get_key
def test_get_key():
    import unittest
    import time
    import sys
    import select

    class GetKeyTest(unittest.TestCase):

        def test_get_key(self):
            def read_key(expected, timeout=1):
                r, w, e = select.select([sys.stdin], [], [], timeout)
                if not r:
                    raise Exception('No input')

                key = get_key()
                if key != expected:
                    raise Exception('Unexcepted key, expected: %s, actual: %s' % (expected, key))

            read_key(const.KEY_CTRL_C)
            # 1s timeout to wait for key
            time.sleep(1)
            read_key(const.KEY_CTRL_D)

    test_case = GetKeyTest()
    test_case.test