

# Generated at 2022-06-23 18:58:19.621655
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
	# Add your test code here
	a = ConfigFileError()


# Generated at 2022-06-23 18:58:25.655326
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    home_dir = Path.home()

    def get_base_config_dict(config_dir: Path) -> BaseConfigDict:
        config_dict = BaseConfigDict(
            path=config_dir
        )
        return config_dict

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        config_dict = get_base_config_dict(Path(env_config_dir))
        return config_dict

    # 2. Windows
    if is_windows:
        config_dict = get_base_config_dict(DEFAULT_WINDOWS_CONFIG_DIR)
        return config_dict

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_REL

# Generated at 2022-06-23 18:58:32.409467
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dict = {"foo": "bar", "baz": "qux"}
    temp_file = Path(tempfile.NamedTemporaryFile(prefix='httpie_test_').name)
    test_config = BaseConfigDict(temp_file)
    with temp_file.open(mode='w') as f:
        json.dump(test_dict, f)
    test_config.load()
    assert test_config == test_dict


# Generated at 2022-06-23 18:58:37.815526
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Test for method ensure_directory of class BaseConfigDict
    """
    test_config_dir = Path("~/.httpie").expanduser()
    test_dir = test_config_dir / Path("test_dir")
    test_config = BaseConfigDict(test_dir)
    test_config.ensure_directory()
    assert test_config_dir.exists() == True
    rmtree(str(test_config_dir))

# Generated at 2022-06-23 18:58:39.828182
# Unit test for constructor of class Config
def test_Config():
    print(Config().default_options)
    print(Config('/home/liuzeyu/httpie/').default_options)

# Generated at 2022-06-23 18:58:50.953134
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    class Test(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

        def __init__(self, path: Path):
            super().__init__(path)

    tmp_path = Path('./test')
    dct = Test(tmp_path/'test.json')
    assert dct.is_new() is True
    dct.save()
    assert dct.is_new() is False
    dct = Test(tmp_path/'test.json')
    assert dct.is_new() is False
    dct['key'] = 'value'
    dct.save()
    assert dct.is_new() is False
    dct = Test(tmp_path/'test.json')
    assert dct['key'] == 'value'

# Generated at 2022-06-23 18:58:59.918676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # path does not exist
    config_dict = BaseConfigDict('/path/to/config')
    config_dict.ensure_directory()
    assert Path('/path/to/config').exists()

    # path and directory exist
    config_dict = BaseConfigDict('/path/to/config')
    config_dict.ensure_directory()
    assert Path('/path/to/config').exists()
    
    # path and directory exist, but only the path has read permission
    config_dict = BaseConfigDict('/path/to/config')
    config_dict.ensure_directory()
    assert Path('/path/to/config').exists()
    
    # path and directory exist, but only the path has write permission
    config_dict = BaseConfigDict('/path/to/config')
   

# Generated at 2022-06-23 18:59:02.693637
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    os.makedirs(config_dir, exist_ok=True)
    config_file = open(Path(config_dir, 'config.json'), 'w')
    config_file.write(Config().load())
    config_file.close()


# Generated at 2022-06-23 18:59:05.848711
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test message')
    except ConfigFileError as e:
        assert str(e) == 'test message'


# Generated at 2022-06-23 18:59:09.615326
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert issubclass(BaseConfigDict, dict)
    test = BaseConfigDict("test")
    assert test.name is None
    assert test.helpurl is None
    assert test.about is None


# Generated at 2022-06-23 18:59:16.688706
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict

    class ConfigDict(BaseConfigDict):
        name = 'test'

    with TemporaryDirectory() as tmpdirname:
        path = Path(tmpdirname) / 'test'
        config = ConfigDict(path)
        config['test'] = 1
        config.save()
        assert config.path.exists()
        config.delete()
        assert config.path.exists() == False

test_BaseConfigDict_delete()

# Generated at 2022-06-23 18:59:19.287042
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        pass
    except Exception as e:
        print('Exception:',e)


# Generated at 2022-06-23 18:59:21.774622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path(''))
    try:
        config_dict.load()
    except ConfigFileError:
        assert False, "should not raise"

# Generated at 2022-06-23 18:59:26.738839
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    conf = BaseConfigDict('/tmp/httpie_config.json')
    conf["default_options"] = []
    assert conf.is_new()
    conf.save()
    assert not conf.is_new()
    os.unlink('/tmp/httpie_config.json')
    assert conf.is_new()
    conf['default_options'] = []
    conf.save(fail_silently=True)
    assert conf.is_new()

# Generated at 2022-06-23 18:59:34.911842
# Unit test for constructor of class Config
def test_Config():
    # constructor for $HOME/.httpie/config.json
    config = Config()
    assert config['default_options'] == []
    assert config.path.name == 'config.json'

    # constructor for config file given in path
    config = Config('/path/to/httpie/config')
    assert config.path == Path('/path/to/httpie/config/config.json')

    # constructor for config file given in Path object
    config = Config(Path('/path/to/httpie/config'))
    assert config.path == Path('/path/to/httpie/config/config.json')



# Generated at 2022-06-23 18:59:42.597148
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # The path .config/httpie/config.json doesn't exist
    config = Config()
    assert config.is_new()

    # The path /root/config.json doesn't exist
    config2 = Config(path="/root/config.json")
    assert config2.is_new()

    # The path /root/config.json exists
    Path("/root").mkdir(mode=0o700, parents=True)
    config3 = Config(path="/root/config.json")
    assert config3.is_new() == False

# Generated at 2022-06-23 18:59:52.560954
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from shutil import rmtree

    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    path_test_dir = "test_config"
    path_test_sub_dir = "test_subconfig"
    path_test_file = "test.json"
    path_test_sub_file = "test_subfile.json"

    if is_windows:
        path_test_dir = DEFAULT_WINDOWS_CONFIG_DIR
        path_test_sub_dir = DEFAULT_WINDOWS_CONFIG_DIR / path_test_sub_dir

    test_dir = Path(path_test_dir)
    test_sub_dir = Path(path_test_sub_dir)
    test_file = Path(path_test_file)
    test

# Generated at 2022-06-23 18:59:54.438879
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict.name is None
    assert BaseConfigDict.helpurl is None
    assert BaseConfigDict.about is None


# Generated at 2022-06-23 18:59:56.877469
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict('./config.json')
    assert not BaseConfigDict('./config.json').path.exists()



# Generated at 2022-06-23 19:00:03.257516
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    temp_config_dir = temp_dir_path / 'httpie'

    temp_config_file = temp_config_dir / 'config.json'

    temp_config_dict = BaseConfigDict(temp_config_file)

    assert temp_config_dict.is_new()
    temp_config_dict.save()
    assert not temp_config_dict.is_new()

# Generated at 2022-06-23 19:00:08.604679
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('temporary/test_load.json')
    path.parent.mkdir(parents=True)
    with path.open('wt') as f:
        json.dump({'test': 1}, f)

    config = BaseConfigDict(path)
    config.load()
    assert config['test'] == 1
    path.parent.rmdir()



# Generated at 2022-06-23 19:00:11.851593
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """ test_get_default_config_dir()

    Test function get_default_config_dir()
    """
    assert get_default_config_dir() == get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-23 19:00:20.514176
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import shutil
    import tempfile
    import time
    import unittest

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 19:00:30.692159
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_path = DEFAULT_CONFIG_DIR / Config.FILENAME
    def test_config_path_exists():
        return config_path.is_file()
    # Delete the config file if it exists.
    if test_config_path_exists():
        config_path.unlink()
    # Test that calling ensure_directory() on a non-existing path
    # will generate the config file.
    config = Config(directory=DEFAULT_CONFIG_DIR)
    assert not test_config_path_exists()
    config.ensure_directory()
    assert test_config_path_exists()
    # Test that calling ensure_directory() on an existing path
    # will not cause an exception.
    config.ensure_directory()
    assert test_config_path_exists()


# Generated at 2022-06-23 19:00:32.085926
# Unit test for constructor of class Config
def test_Config():
    Config()
    Config(directory="D:/")



# Generated at 2022-06-23 19:00:42.399223
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Initialize a empty config with no directory
    config = BaseConfigDict(path=Path('/test.json'))
    config.save()
    assert config.path.exists()

    config_content = json.loads(config.path.read_text())
    # Check if the metadata was written correctly
    assert config_content['__meta__']
    assert config_content['__meta__']['httpie'] == __version__
    assert config_content['__meta__']['about'] == config.about
    assert config_content['__meta__']['help'] == config.helpurl

    # Remove the created file
    config.delete()


# Unit test to see if a new config is new

# Generated at 2022-06-23 19:00:44.274773
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/rhe/.config/httpie')



# Generated at 2022-06-23 19:00:46.833631
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    directory = DEFAULT_CONFIG_DIR
    config = Config(directory)
    assert config.is_new() == True


# Generated at 2022-06-23 19:00:58.542688
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import platform
    if platform.system() != 'Linux':
        raise AssertionError("The test can only be run on Linux")
    print("Testing method ensure_directory of class BaseConfigDict")
    test_file = Path("/tmp/httpie/test/is/httpie.json")
    test_directory = test_file.parent
    if test_directory.exists():
        test_directory.rmdir()
    if test_directory.parent.exists():
        test_directory.parent.rmdir()
    if test_directory.parent.parent.exists():
        test_directory.parent.parent.rmdir()
    assert not test_directory.exists()
    bcd = BaseConfigDict(path=test_file)
    bcd.ensure_directory()
    assert test_directory.exists

# Generated at 2022-06-23 19:01:01.090804
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path('./Fixtures')
    config = Config(directory=config_dir)
    config.delete()



# Generated at 2022-06-23 19:01:09.730215
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_dir = '/home/index/projects/httpie/test/testfiles'
    fake_path = Path(f'{test_dir}/fake_config.json')
    real_path = Path(f'{test_dir}/config.json')
    test_dict = BaseConfigDict(fake_path)
    result1 = test_dict.is_new()
    real_dict = BaseConfigDict(real_path)
    result2 = real_dict.is_new()
    return result1, result2

if __name__ == '__main__':
    print(test_BaseConfigDict_is_new())

# Generated at 2022-06-23 19:01:14.524624
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        # create a ConfigFileError exception
        raise ConfigFileError("ConfigFileError")
    except ConfigFileError as e:
        assert str(e) == "ConfigFileError", "Error string error"
    else:
        assert False, "Failed to raise a ConfigFileError exception"


# Generated at 2022-06-23 19:01:22.214840
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Expect ConfigFileError
    good_path = "~/.httpie/config.json"
    bad_path = "~/.httpie/foobar"
    try:
        cfg = Config()
        cfg.ensure_directory()
        assert cfg.path == good_path
    except ConfigFileError:
        assert False
    try:
        cfg = Config(bad_path)
        cfg.ensure_directory()
        assert False
    except ConfigFileError:
        assert True
# Unit testing for the load() method of class BaseConfigDict

# Generated at 2022-06-23 19:01:28.330472
# Unit test for constructor of class Config
def test_Config():
    # Create an object of class Config
    config = Config()
    # Check that the object's directory attribute is of type PosixPath or WindowsPath
    assert isinstance(config.directory, (Path, PosixPath, WindowsPath))
    # Check that the object's path attribute is of type PosixPath or WindowsPath
    assert isinstance(config.path, (Path, PosixPath, WindowsPath))

# Generated at 2022-06-23 19:01:33.601534
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
	# something = BaseConfigDict()
	# Something = BaseConfigDict("test\testconfig.json")
	Something = BaseConfigDict("test\testconfig.json")
	Something.load()
	Something.save("test\testconfig.json")
	Something.delete("test\testconfig.json")


# Generated at 2022-06-23 19:01:41.533631
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from pathlib import Path
    from unittest.mock import patch
    import os

    def mock_mkdir_side_effect(*args, **kwargs):
        x = [
            OSError(errno.EACCES, 'Permission denied'),
            OSError(errno.EACCES, 'Permission denied'),
            None
        ]
        y = x.pop(0)
        if y:
            raise y
        return y

    x = BaseConfigDict(path=Path("./test_config"))
    with patch('httpie.config.BaseConfigDict.ensure_directory') as mock_mkdir:
        mock_mkdir.side_effect = mock_mkdir_side_effect
        assert x.ensure_directory() is None
        assert x.path.parent.exists()

# Generated at 2022-06-23 19:01:43.030501
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert type(config) == Config


# Generated at 2022-06-23 19:01:46.782009
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert(config.directory == DEFAULT_CONFIG_DIR)
    assert(config.path == DEFAULT_CONFIG_DIR/Config.FILENAME)
    assert(config["default_options"] == Config.DEFAULTS["default_options"])


# Generated at 2022-06-23 19:01:47.885991
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    conf = Config()
    assert conf.is_new()

# Generated at 2022-06-23 19:01:49.430157
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    temp_file = BaseConfigDict('/tmp/config.json')
    assert temp_file.path == '/tmp/config.json'

# Generated at 2022-06-23 19:01:50.995621
# Unit test for constructor of class Config
def test_Config():
    test_config = Config(directory='/tmp')
    assert test_config.directory == Path('/tmp')



# Generated at 2022-06-23 19:02:01.001450
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/etc/httpie/'
    assert get_default_config_dir() == Path('/etc/httpie/')


# Generated at 2022-06-23 19:02:05.580654
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    my_directory = Path(DEFAULT_CONFIG_DIR)
    my_config = BaseConfigDict(directory=my_directory)
    my_config.save(fail_silently=False)
    assert my_config.is_new()==False


# Generated at 2022-06-23 19:02:08.738049
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == (
        Path.home() / '.config' / 'httpie'
    )



# Generated at 2022-06-23 19:02:13.028808
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config['__meta__'] = {'httpie': __version__}
    config['logging'] = ""
    config.save()
    config.load()
    assert config['__meta__']['httpie'] == __version__
    config.delete()


# Generated at 2022-06-23 19:02:15.582026
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    config = BaseConfigDict(path=Path('./tmp/config.json'))
    config.delete()

# Generated at 2022-06-23 19:02:23.362075
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    os.name = 'nt'
    assert get_default_config_dir() == Path(
        os.path.expandvars('%APPDATA%')
    ) / DEFAULT_CONFIG_DIRNAME

    # Legacy
    os.name = 'posix'
    with mock.patch('httpie.config.Path.home') as path_home:
        path_home.return_value.joinpath.return_value.exists.return_value = True
        assert get_default_config_dir() == Path.home() / Path(
            '.httpie'
        )

    # XDG
    with mock.patch('httpie.config.os.environ') as environ:
        environ.get.return_value = None  # XDG_CONFIG_HOME

# Generated at 2022-06-23 19:02:28.305125
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    bcd = BaseConfigDict(path=temp_dir)
    bcd['test_key'] = 'test_value'
    bcd.save()
    assert os.path.exists(temp_dir)
    assert bcd == json.load(open(temp_dir))

# Generated at 2022-06-23 19:02:39.886453
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    assert BaseConfigDict.is_new('C:/Users/hp/AppData/Roaming/httpie/config.json')
    assert BaseConfigDict.is_new('C:/Users/hp/AppData/Roaming/httpie/config.json')
    assert BaseConfigDict.is_new(
        "C:/Users/hp/AppData/Roaming/Python/Python36/site-packages/httpie/config.json")
    assert BaseConfigDict.is_new("C:/Users/hp/AppData/Roaming/Python/Python36/site-packages/httpie/config.json")
    assert BaseConfigDict.is_new("C:/Users/hp/AppData/Roaming/Python/Python36/site-packages/httpie/config.json")

# Generated at 2022-06-23 19:02:41.664222
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(Path('path'))
    assert config.path == Path('path')


# Generated at 2022-06-23 19:02:44.123634
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Method delete of class BaseConfigDict

    This method is intended to delete the config file in the user's directory
    """
    Config().delete()


# Generated at 2022-06-23 19:02:46.537110
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert str(ConfigFileError('test')) == 'test'



# Generated at 2022-06-23 19:02:49.864263
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_file = BaseConfigDict(path = Path.home() / 'config.json')
    return config_file.is_new()

# Generated at 2022-06-23 19:02:52.412646
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        name = 'TestConfig'
        helpurl = 'https://example.com'
        about = 'This is a test'

    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        path = Path(tempdir) / 'test.json'
        config = TestConfigDict(path)
        config.save()

        assert path.exists()
        assert config == json.load(path.open())



# Generated at 2022-06-23 19:02:56.903069
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = DEFAULT_CONFIG_DIR / 'test_file.txt'
    user_config = BaseConfigDict(path)
    assert not path.exists()
    user_config.ensure_directory()
    assert path.parent.exists()
    path.parent.rmdir()


# Generated at 2022-06-23 19:03:06.360145
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    """
    A test function for class BaseConfigDict
    """
    fd, fname = tempfile.mkstemp()
    try:
        test_data = {
            'key1': 'value1',
            'key2': 'value2'
        }
        os.write(fd, json.dumps(test_data).encode('utf-8'))
        os.close(fd)
        config_dict = BaseConfigDict(Path(fname))
        config_dict.load()
        for key in test_data:
            assert test_data[key] == config_dict[key]
    finally:
        os.remove(fname)



# Generated at 2022-06-23 19:03:13.874843
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_file_name = 'temp.tmp'
    content = 'my test'
    f = open(temp_file_name, 'wt')
    f.write(content)
    f.close()
    f2 = open(temp_file_name, 'rt')
    assert f2.read() == content
    assert os.path.isfile(temp_file_name) == True
    os.remove(temp_file_name)
    assert os.path.isfile(temp_file_name) == False


# Generated at 2022-06-23 19:03:17.379261
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    # Arrange
    test = ConfigFileError

    # Act
    try:
        test("test message")
    except Exception as e:
        actual = str(e)

    # Assert
    expected = 'test message'
    assert actual == expected


# Generated at 2022-06-23 19:03:19.086068
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfe = ConfigFileError("error message")
    assert cfe.args[0] == "error message"

# Generated at 2022-06-23 19:03:30.242713
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def _test_on_unix(home, xdg_config_home, expected):
        assert xdg_config_home == None or isinstance(xdg_config_home, str)
        os.environ["HOME"] = home
        if xdg_config_home != None:
            os.environ["XDG_CONFIG_HOME"] = xdg_config_home
        if '' in os.environ:
            del os.environ['']
        cd = get_default_config_dir()
        assert cd == expected

    _test_on_unix("/home/alice", "/home/alice/.config", "/home/alice/.config/httpie")

# Generated at 2022-06-23 19:03:32.221857
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME

# Generated at 2022-06-23 19:03:35.154940
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path='/tmp/test-httpie-config-json')
    assert config.is_new()
    config.load()
    assert not config.is_new()

# Generated at 2022-06-23 19:03:45.480168
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pytest import raises
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import os
    from os import path
    with TemporaryDirectory() as tempdir:
        for file in ('config.json', 'auth.json', 'cookies.json'):
            testfile = Path(tempdir).joinpath(file)
            testfile.touch()
        config = Config(tempdir)
        auth = Auth(tempdir)
        cookies = Cookies(tempdir)
        for f in (config, auth, cookies):
            assert path.isfile(f.path)
            f.delete()
            with raises(ConfigFileError):
                f.load()
            assert not path.isfile(f.path)



# Generated at 2022-06-23 19:03:47.640834
# Unit test for constructor of class Config
def test_Config():
    config = Config()

    assert config.FILENAME == 'config.json'
    assert config.DEFAULTS == {'default_options': []}
    assert config.directory == DEFAULT_CONFIG_DIR


# Generated at 2022-06-23 19:03:50.857313
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory=Path('test_file')
    config_dict=BaseConfigDict(directory)
    config_dict.ensure_directory()
    abs_path=os.path.abspath(directory)
    assert(os.path.exists(abs_path))


# Generated at 2022-06-23 19:03:52.901234
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    '''Test for method delete of class BaseConfigDict'''
    config = BaseConfigDict("config.json")
    assert config.delete()


# Generated at 2022-06-23 19:03:56.678363
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError(
            'original exception message'
        )
    except ConfigFileError as e:
        assert str(e) == 'original exception message'



# Generated at 2022-06-23 19:04:01.460338
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    BaseConfigDict_test = BaseConfigDict(Path('../Examples/config.json'))
    assert BaseConfigDict_test.is_new() == True 


if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-23 19:04:07.239585
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import pytest
    from tempfile import TemporaryDirectory
    dir = TemporaryDirectory()
    path = dir.name + '/config.json'
    config = BaseConfigDict(path)
    assert(config.is_new() == True)
    config.save()
    assert(config.is_new() == False)
    dir.cleanup()



# Generated at 2022-06-23 19:04:10.925499
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("testing")
    except ConfigFileError as e:
        assert e.__str__() == "testing"


# Generated at 2022-06-23 19:04:19.570941
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Setup
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / 'foo')
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / '.config2')

    # Test
    assert get_default_config_dir() == Path.home() / 'foo'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    assert get_default_config_dir() == Path.home() / '.config2' / DEFAULT_CONFIG_DIRNAME

    # Teardown
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-23 19:04:30.717824
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os, json
    from httpie.config import BaseConfigDict
    from pathlib import Path

    temp_dir = Path('temp')
    # If the directory exists already, delete it in order to store new file
    if temp_dir.is_dir():
        for file in temp_dir.iterdir():
            os.remove(file)
        os.rmdir(temp_dir)

    temp_dir.mkdir(mode=0o700, parents=True)
    config_file = temp_dir / 'config.json'
    config = BaseConfigDict(path = config_file)
    config["test"] = "test"
    config.save()
    with config_file.open('rt') as f:
        config_file_content = json.load(f)

# Generated at 2022-06-23 19:04:33.303293
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    if config is not None:
        print("Config test passed")
    else:
        raise AssertionError



# Generated at 2022-06-23 19:04:37.266465
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('error in reading config file:')
    except ConfigFileError:
        print('error found')


# Generated at 2022-06-23 19:04:39.489477
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ['HOME'] = '/home/test'
    expected_config_dir = '/home/test/.config/httpie'
    assert get_default_config_dir() == Path(expected_config_dir)



# Generated at 2022-06-23 19:04:44.065408
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class Test(BaseConfigDict):
        pass

    d = Test(path=Path('test.json'))
    d['key'] = 'value'
    d.save()

    with open('test.json', 'r') as f:
        assert '"key": "value"' in f.read()

    os.remove('test.json')

# Generated at 2022-06-23 19:04:47.225028
# Unit test for constructor of class Config
def test_Config():
    config = Config("../httpie/")
    print("Test for constructor of class Config")
    assert config.directory == "../httpie/"
    assert config.path == "../httpie/config.json"


default_config = Config()



# Generated at 2022-06-23 19:04:51.853534
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import tempfile
    with tempfile.TemporaryDirectory() as h:
        class DummyConfig(BaseConfigDict):
            DEFAULTS = {}
        p = Path(h) / 'test.json'
        c = DummyConfig(path=p)
        c.save()
        assert p.exists()
        c.delete()
        assert not p.exists()



# Generated at 2022-06-23 19:04:55.346036
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # no such directory
    config = BaseConfigDict(Path('/no/such/directory'))
    assert config.is_new()

    # empty
    config = BaseConfigDict(Path('/tmp'))
    assert config.is_new()

    # content exists
    config = BaseConfigDict(Path('/etc/passwd'))
    assert not config.is_new()



# Generated at 2022-06-23 19:05:02.631093
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    cfg = BaseConfigDict(Path('./new_config_file'))
    assert cfg.is_new() is True
    # cfg.save()
    cfg2 = BaseConfigDict(Path('./new_config_file'))
    assert cfg2.is_new() is False

    # Clean up
    os.remove('./new_config_file')


# Generated at 2022-06-23 19:05:06.040617
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    '''
    delete test file
    '''
    test_path = Path('/tmp/a.txt')
    bcfg = BaseConfigDict(test_path)
    bcfg.delete()
    assert not test_path.exists()

# Generated at 2022-06-23 19:05:11.635288
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    t = TempDir()
    cfg_path = t.path + '/config'
    cfg = BaseConfigDict(cfg_path)
    cfg.load()
    cfg['test'] = 'test'
    cfg.save()
    cfg = BaseConfigDict(cfg_path)
    cfg.load()
    if cfg['test'] != 'test':
        raise Exception("Wrong load for BaseConfigDict.")
    t.cleanup()


# Generated at 2022-06-23 19:05:22.441266
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    def createDirectory():
        try:
            os.mkdir("test-load")
        except OSError:
            print("Creation of the directory failed")
        else:
            print("Successfully created the directory")

    json_string = json.dumps(
        obj={'key': 'value'},
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    createDirectory()
    config = BaseConfigDict("test-load/config.json")
    config.save()
    config = BaseConfigDict("test-load/config.json")
    config.load()
    config.update({"key1": "value1"})
    assert config["key1"] == "value1"
    os.rmdir("test-load")


# Generated at 2022-06-23 19:05:29.030981
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path.home() / '.config' / 'httpietest'
    config_path = Path(config_dir) / 'config.json'
    try:
        config_dir.mkdir(mode=0o700)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    try:
        config_path.unlink()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    config = Config(directory=config_dir)
    config['default_options'] = ['-v']
    config['testcase'] = 'test-case'
    config.save()
    if not config_path.exists():
        raise Exception('JSON file not saved')
    config.delete()

# Generated at 2022-06-23 19:05:33.814744
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME

    home_dir = Path.home()

    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # 1. explicitly set through env

# Generated at 2022-06-23 19:05:38.644457
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('cannot read config file')
    except ConfigFileError as e:
        print("exception class : ", e.__class__)
        print("exception args : ", e.args)

test_ConfigFileError()


# Generated at 2022-06-23 19:05:42.447450
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cf1 = ConfigFileError
    cf2 = ConfigFileError(
        'invalid auth file: Expecting property name enclosed in double quotes:'
        ' line 1 column 2 (char 1) [%APPDATA%\\httpie\\auth.json]')
    asser

# Generated at 2022-06-23 19:05:44.332573
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert(c['default_options'] == [])
    assert(c.default_options == [])



# Generated at 2022-06-23 19:05:50.431611
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    path1 = 'tests/fixtures/default/'
    path2 = 'tests/fixtures/cookies.json'
    path3 = 'tests/fixtures/unexisted_cookies.json'
    assert BaseConfigDict(path1).is_new() == False
    assert BaseConfigDict(path2).is_new() == False
    assert BaseConfigDict(path3).is_new() == True



# Generated at 2022-06-23 19:05:54.328994
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    conf = BaseConfigDict(Path('/tmp/a_new_file'))
    assert conf.is_new() == True
    conf = BaseConfigDict(Path('/tmp/not_a_new_file'))
    assert conf.is_new() == False


# Generated at 2022-06-23 19:06:05.124316
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Set env var
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(
        Path.home() / 'my_new_config')
    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / 'my_new_config'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # If on windows, return $APPDATA
    if is_windows:
        config_dir = get_default_config_dir()
        assert config_dir == DEFAULT_WINDOWS_CONFIG_DIR

    # Return the home directory if no config exists
    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / '.config' / DEFAULT_CONFIG_DIRNAME

    # Return .httpie if it

# Generated at 2022-06-23 19:06:15.711301
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def set_environ(**kwargs):
        os.environ.update(kwargs)
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
        return get_default_config_dir()

    # OS environment
    assert set_environ(HTTPIE_CONFIG_DIR='/httpie-config') == Path('/httpie-config')
    assert set_environ(XDG_CONFIG_HOME='/xdg-config-home') == Path('/xdg-config-home') / DEFAULT_CONFIG_DIRNAME

    # Windows
    assert set_environ() == DEFAULT_WINDOWS_CONFIG_DIR

    # Unix
    assert set_environ() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    # XDG

# Generated at 2022-06-23 19:06:18.568097
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
    assert config.is_new()

# Generated at 2022-06-23 19:06:24.580145
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil
    test_dir = Path('testdir')

    if test_dir.exists():
        shutil.rmtree(test_dir)
    test_dir.mkdir()
    test_dict = BaseConfigDict(path=test_dir/'test.txt')
    with pytest.raises(OSError):
        test_dict.ensure_directory()
    shutil.rmtree(test_dir)


# Generated at 2022-06-23 19:06:30.217258
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(ConfigFileError) as exception_info:
        raise ConfigFileError()
    assert str(exception_info.value) == ''

    with pytest.raises(ConfigFileError) as exception_info:
        raise ConfigFileError('Happy')
    assert str(exception_info.value) == 'Happy'

    with pytest.raises(ConfigFileError) as exception_info:
        raise ConfigFileError('Happy', 'Sad')
    assert str(exception_info.value) == 'Happy Sad'

# Generated at 2022-06-23 19:06:35.401175
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    if is_windows:
        assert DEFAULT_CONFIG_DIR == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert DEFAULT_CONFIG_DIR == DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-23 19:06:38.304822
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('Test')
    except ConfigFileError as e:
        assert str(e) == 'Test'


# Generated at 2022-06-23 19:06:48.527112
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from .__init__ import __version__
    from pathlib import Path
    import json
    import os

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'test.helpurl'
        about = 'test.about'

    TestConfigDict(Path(os.getcwd()) / 'TestConfig').save()
    with open('TestConfig/config.json', 'r') as f:
        config = json.load(f)
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'test.helpurl'
    assert config['__meta__']['about'] == 'test.about'
    os.remove('TestConfig/config.json')
    os.rmdir('TestConfig')

#

# Generated at 2022-06-23 19:07:01.182340
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_root = "/tmp/httpie/test/config"
    config_path = f"{config_root}/config.json"
    if os.path.exists(config_root):
        os.system(f"rm -rf {config_root}")
    os.system(f"mkdir -p {config_root}")
    os.system(f"chmod -R 700 {config_root}")
    assert os.path.exists(config_root) == True
    base = BaseConfigDict(Path(config_path))
    assert base.path.parent.exists() == True
    os.system(f"rm -rf {config_path}")
    assert base.path.parent.exists() == False
    assert base.is_new() == True
    base.load()
    

#

# Generated at 2022-06-23 19:07:07.730659
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    tempdir = TemporaryDirectory()
    tempdir_path = Path(tempdir.name)
    new_config = BaseConfigDict(path=tempdir_path / 'newconfig.json')
    assert new_config.is_new()
    new_config.save(fail_silently=True)
    not_new_config = BaseConfigDict(path=tempdir_path / 'newconfig.json')
    assert not not_new_config.is_new()

# Generated at 2022-06-23 19:07:12.948276
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dummy_path = Path('dummy_file.json')
    dummy_config = BaseConfigDict(dummy_path)
    dummy_config.load()
    assert dummy_config == {}
    dummy_path.touch()
    dummy_config.load()
    assert dummy_config == {}
    dummy_path.write_text(json.dumps({"foo": "bar"}))
    dummy_config.load()
    assert dummy_config == {"foo": "bar"}


# Generated at 2022-06-23 19:07:16.090144
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(ConfigFileError) as excinfo:
        raise ConfigFileError()
    assert excinfo


# Generated at 2022-06-23 19:07:19.172349
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    """Test if constructor of BaseConfigDict works."""
    test_config = BaseConfigDict(Path('test_BaseConfigDict.json'))
    assert test_config.path == Path('test_BaseConfigDict.json')


# Generated at 2022-06-23 19:07:21.652779
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    f = ConfigFileError("Wrong config file")
    assert f.args[0] == "Wrong config file"

# Generated at 2022-06-23 19:07:24.931804
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path(__file__).parent / 'test.json')
    assert config.is_new()
    config['key'] = 'value'
    config.save()
    assert not config.is_new()
    config.delete()


# Generated at 2022-06-23 19:07:29.250930
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-23 19:07:32.681088
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # An exception should be raised if parent directory is not writeable
    path = Path('/not_writeable/config.json')
    config = BaseConfigDict(path)
    try:
        config.ensure_directory()
    except Exception as e:
        assert type(e) == OSError and e.errno == errno.EACCES

# Generated at 2022-06-23 19:07:44.565003
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
        return

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert '/tmp/foo' == get_default_config_dir()
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()

    # 3. legacy ~/.httpie
    legacy_config_dir = os.path.expanduser(
        DEFAULT_RELATIVE_LEGACY_CONFIG_DIR.as_posix())
    os.mkdir(legacy_config_dir)
    assert legacy_config_dir == get_default

# Generated at 2022-06-23 19:07:46.133413
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass



# Generated at 2022-06-23 19:07:54.455229
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a fake config file
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        # Temporarily change base directory
        orig_dir = DEFAULT_CONFIG_DIR
        DEFAULT_CONFIG_DIR = Path(tmpdir)

        # Create config file
        config = Config()
        config.save()
        config.update({'test_key': 'test_value'})
        config.save()

        # Recover base directory
        DEFAULT_CONFIG_DIR = orig_dir

        # Test for method load
        config = Config()
        config.update({'test_key': 'test_value'})
        config.load()
        assert(config.get('test_key') == 'test_value')


# Generated at 2022-06-23 19:08:01.387039
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_file = Config()
    # Create a temprory config file
    with tempfile.NamedTemporaryFile() as f:
        config_file.path = Path(f.name)
        if config_file.path.exists():
            config_file.path.unlink()
        # The file should not exist
        assert not config_file.path.exists()
        # Create the directory
        config_file.ensure_directory()
        # The file should exist
        assert config_file.path.exists()

    # Create a temprory config file
    with tempfile.NamedTemporaryFile() as f:
        config_file.path = Path(f.name)
        config_file.path.mkdir()
        # The file should exist
        assert config_file.path.exists()

# Generated at 2022-06-23 19:08:07.618591
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    ''' Document: (be a test):
        Expected result: a config file is created in the directory
    '''
    directory = './'
    file_name = 'test_config.json'
    save_path = os.path.join(directory, file_name)
    b = BaseConfigDict(save_path)
    b.save()


# Generated at 2022-06-23 19:08:14.009122
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    config_file = Path(temp_dir) / "test-config-file.txt"
    config_file.touch()
    config_test = BaseConfigDict(config_file)
    config_test['default_options'] = ['abc']
    config_test.save()
    config_file.unlink()
    Path(temp_dir).rmdir()


# Generated at 2022-06-23 19:08:20.518234
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('test')
    config.save()
    assert config.path.exists()
    assert config.path.read_text() == '{\n    "__meta__": {\n        "httpie": "0.3.3"\n    }\n}\n'
    config.delete()
    assert not config.path.exists()