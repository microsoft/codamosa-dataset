

# Generated at 2022-06-23 18:58:21.349423
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('test')
    config = BaseConfigDict(path)
    assert config.path == Path('test'), 'Path is not being updated'


# Generated at 2022-06-23 18:58:27.186134
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    assert config.is_new()
    config.save()
    assert not config.is_new()
    config.delete()
    assert config.is_new()
    config.save()
    config['default_options'] = ['-H', 'Accept:application/json']
    config.save()
    config.delete()
    config.save()
    config['default_options'] = ['-H', 'Accept:application/json']
    config.save()
    config.delete()
    config.save()


# Generated at 2022-06-23 18:58:30.752490
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path('./path/to/file')
    obj = BaseConfigDict(path)
    obj.ensure_directory()
    assert obj.path.parent.is_dir()

# Generated at 2022-06-23 18:58:35.198800
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    # should throw an error if passed in something that isn't a string
    try:
        raise ConfigFileError(4)
    except ConfigFileError:
        assert True
    else:
        assert False
    try:
        raise ConfigFileError(4.2)
    except ConfigFileError:
        assert True
    else:
        assert False
    try:
        raise ConfigFileError(True)
    except ConfigFileError:
        assert True
    else:
        assert False
    # should not throw an error if string is passed in
    try:
        raise ConfigFileError('Invalid config file.')
    except ConfigFileError:
        assert True


# Generated at 2022-06-23 18:58:40.247271
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a directory path without parent.
    no_parent_path = Path('test/test.json')
    no_parent_config = BaseConfigDict(path=no_parent_path)

    # Ensure that the directory of no_parent_path is created
    no_parent_config.ensure_directory()
    assert no_parent_path.parent.exists() == True

    # Delete the created directory.
    no_parent_path.parent.rmdir()


# Generated at 2022-06-23 18:58:42.523357
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert True 



# Generated at 2022-06-23 18:58:44.829236
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    BaseConfigDict(Path('config.json')).delete()
    BaseConfigDict(Path()).delete()


# Generated at 2022-06-23 18:58:49.770990
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # arrange
    path = Path('../../test_data/config.json')
    config = BaseConfigDict(path)
    
    # assert
    try:
        # act
        config.load()
        assert config['httpie']==__version__
        assert config['help']=='https://httpie.org/docs'
        assert config['about']=='HTTPie %s by Jakub Roztocil' % __version__
        assert len(config)==3
    except:
        assert False

# Generated at 2022-06-23 18:58:53.609558
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_path = Path(__file__).parent / 'test_data' / 'config.json'
    test_case = BaseConfigDict(test_path)
    test_case.load()
    assert test_case['__meta__'] == {'httpie': __version__}

# Generated at 2022-06-23 18:59:01.911753
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import tempfile

    def create_temp_file(config_home_dir, file_name):
        with open(config_home_dir / file_name, 'a'):
            pass

    with tempfile.TemporaryDirectory() as tmpdir:
        config_home_dir = Path(tmpdir)
        create_temp_file(config_home_dir, '.httpie')

        # No environment var HTTPIE_CONFIG_DIR nor XDG_CONFIG_DIR should be
        # set.
        assert get_default_config_dir() == \
               Path(str(config_home_dir) + '/.httpie')

        # HTTPIE_CONFIG_DIR is set.
        os.environ[ENV_HTTPIE_CONFIG_DIR] = str(config_home_dir / 'special')
        assert get_default_

# Generated at 2022-06-23 18:59:07.820324
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == Path(os.environ.get('HOME')).resolve() / '.config' / 'httpie'
    assert os.environ.get('HTTPIE_CONFIG_DIR') == None
    assert os.environ.get('XDG_CONFIG_HOME') == None

# Generated at 2022-06-23 18:59:10.070611
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    a = BaseConfigDict(Path('/a.json'))
    a.ensure_directory()
    assert True



# Generated at 2022-06-23 18:59:18.776501
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows: nothing in ENVIRONMENT
    assert is_windows
    home_dir = Path.home()
    assert get_default_config_dir() == home_dir / Path('AppData/Roaming') / DEFAULT_CONFIG_DIRNAME

    # Windows: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(home_dir / Path('AppData/Local'))
    assert get_default_config_dir() == home_dir / Path('AppData/Local')

    # Linux: nothing in ENVIRONMENT
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert not is_windows
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir

# Generated at 2022-06-23 18:59:20.435889
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    msg = 'test_ConfigFileError'
    e = ConfigFileError(msg)



# Generated at 2022-06-23 18:59:23.938346
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    baseconfigdict = BaseConfigDict("abc")
    assert baseconfigdict.path == "abc"
    assert baseconfigdict.is_new() is True
    assert baseconfigdict.load()
    assert baseconfigdict.save()
    assert baseconfigdict.delete()



# Generated at 2022-06-23 18:59:34.827182
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a non-existent file path
    base_path_to_create = Path('/non/existent/test/env/file')
    base_path_to_create.mkdir(parents=True, exist_ok=True)
    base_path_to_create.rmdir()

    # Mock-up a BaseConfigDict-class inherited object
    class BaseConfigDictMock(BaseConfigDict):
        name = None
        helpurl = None
        about = None

    # Create a missing file using the BaseConfigDict
    path_to_file = base_path_to_create / 'file.json'
    baseConfigDictMock = BaseConfigDictMock(path_to_file)

# Generated at 2022-06-23 18:59:46.050422
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Check what happens when config filename is too long
    """
    config_dir = DEFAULT_CONFIG_DIR
    # Make sure the directory is not already there (otherwise the test won't run)
    assert not config_dir.exists()
    # Try to use a filename that is too long for the directory
    c = Config(directory=config_dir)
    c['default_options'] = ['--auth-type=basic', '--auth=user:pass']
    # Try to create the directory but catch the possible exception
    try:
        c.ensure_directory()
    except OSError as e:
        pass
    # Make sure the directory was not created
    assert not config_dir.exists()
    # Make sure the correct exception was raised
    assert e.errno == errno.ENAMETOOLONG

# Generated at 2022-06-23 18:59:47.795278
# Unit test for constructor of class Config
def test_Config():
    assert Config(directory=os.path.abspath('.')).directory == os.path.abspath('.')
    assert Config(directory='.').directory == os.path.abspath('.')


# Generated at 2022-06-23 18:59:49.284366
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-23 18:59:56.946741
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # $XDG_CONFIG_HOME is set without trailing slash
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar/httpie')

    # $XDG_CONFIG_HOME is set with a trailing slash
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar/'
    assert get_default_config_dir() == Path('/foo/bar/httpie')

    # $XDG_CONFIG_HOME is not set and $HOME is set without trailing slash
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ['HOME'] = '/foo/bar'

# Generated at 2022-06-23 19:00:05.573498
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test_httpie_config_dir_env
    try:
        x = os.getenv('HTTPIE_CONFIG_DIR')
        os.environ['HTTPIE_CONFIG_DIR'] = '/tmp/httpie'
        assert (get_default_config_dir() == '/tmp/httpie')
    finally:
        if x is not None:
            os.environ['HTTPIE_CONFIG_DIR'] = x
        else:
            del os.environ['HTTPIE_CONFIG_DIR']

    # test_windows
    if sys.platform == 'win32':
        assert (get_default_config_dir() ==
                Path(os.path.expandvars('%APPDATA%')) / 'httpie')

    # test_xdg_config_home_env

# Generated at 2022-06-23 19:00:06.595726
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    ConfigFileError('Testing')



# Generated at 2022-06-23 19:00:15.670097
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/t'
    assert get_default_config_dir() == Path('/tmp/t')

    # 2. Windows
    os.environ = {}
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    file_path = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    file_path.touch()
    assert get_default_config_dir() == file_path
    file_path.unlink()

    # 4. XD

# Generated at 2022-06-23 19:00:22.581572
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Create the configuration directory and its parents if they don't exist
    """
    # Check if configuration directory exists before calling ensure_directory
    if not DEFAULT_CONFIG_DIR.exists():
        assert str(DEFAULT_CONFIG_DIR) + " doesn't exist before calling ensure_directory"
    # Call ensure_directory
    Config().ensure_directory()
    # Check if configuration directory exists after calling ensure_directory
    if DEFAULT_CONFIG_DIR.exists():
        assert str(DEFAULT_CONFIG_DIR) + " exits after calling ensure_directory"
    else:
        assert str(DEFAULT_CONFIG_DIR) + " doesn't exit after calling ensure_directory"

# Generated at 2022-06-23 19:00:26.423428
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir

# Generated at 2022-06-23 19:00:32.044562
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class T(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    assert T(Path('/dev/null')).is_new() == True

    Path('/tmp/jose.txt').write_text('Lisen to me\n')
    assert T(Path('/tmp/jose.txt')).is_new() == False



# Generated at 2022-06-23 19:00:35.601885
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test = BaseConfigDict(path="test.txt")
    try:
        test.ensure_directory()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-23 19:00:44.334698
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    TEST_DIR = Path('/tmp')
    TEST_FILENAME = 'test_save.json'
    test_data = [{'test_key':'test_value'}]

    test_obj = BaseConfigDict(TEST_DIR/TEST_FILENAME)
    test_obj.update(test_data)
    test_obj.save()

    loaded_obj = BaseConfigDict(TEST_DIR/TEST_FILENAME)
    loaded_obj.load()
    assert loaded_obj.path == TEST_DIR/TEST_FILENAME
    loaded_obj.delete()

# Generated at 2022-06-23 19:00:51.148061
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    json_data = json.dumps({'a': 1, 'b': 2})
    config = BaseConfigDict('/path/to/config')
    config.load = mock.Mock()
    with mock.patch('builtins.open', return_value=StringIO(json_data)):
        config._load()
    config.load.assert_called_once_with({'a': 1, 'b': 2})


# Generated at 2022-06-23 19:01:00.012820
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    mock_env = {
        ENV_XDG_CONFIG_HOME: os.path.join(os.getcwd(), 'tests', 'mock-data', 'xdgconfig'),
        ENV_HTTPIE_CONFIG_DIR: os.path.join(os.getcwd(), 'tests', 'mock-data', 'httpconfig'),
    }
    with mock.patch.dict(os.environ, mock_env):
        config = Config()
        config.load()
        assert config['default_options'] == ['--headers']
        config.delete()
        assert not config.path.exists()

# Generated at 2022-06-23 19:01:03.718248
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    c = BaseConfigDict(path = Path('/tmp/testfile.json'))
    c.save(fail_silently = True)
    assert c.path.exists()
    os.unlink('/tmp/testfile.json')

# Generated at 2022-06-23 19:01:13.592803
# Unit test for constructor of class ConfigFileError

# Generated at 2022-06-23 19:01:24.225324
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.utils import env
    import os

    test_dir = env.temp_dir / "temp_config"

    if not test_dir.exists():
        test_dir.mkdir(mode=0o700)

    test_dir = test_dir / "test_config"

    config_test = BaseConfigDict(test_dir)

    if is_windows:
        assert config_test.path.parent.exists()
    else:
        assert not config_test.path.parent.exists()

    config_test.save()
    os.remove(config_test.path)

    assert config_test.path.parent.exists()
    assert config_test.path.parent.is_dir()



# Generated at 2022-06-23 19:01:26.052608
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dir = ConfigFileError('abcd')
    

# Generated at 2022-06-23 19:01:37.664283
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # create a temporary directory for the test
    dir_path = os.path.join(os.curdir, "tmp_test_httpie")
    try:
        os.mkdir(dir_path)
    except OSError:
        if not os.path.isdir(dir_path):
            raise

    # create a temporary file in the directory
    temp_file = os.path.join(dir_path, "tmp_test.file")
    with open(temp_file, "w") as f:
        f.write("")

    assert os.path.isfile(temp_file)

    # delete the file
    BaseConfigDict(temp_file).delete()
    assert not os.path.isfile(temp_file)

    # remove the temporary directory
    os.rmdir(dir_path)

# Generated at 2022-06-23 19:01:41.807265
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    assert conf.directory == DEFAULT_CONFIG_DIR
    assert conf.path == DEFAULT_CONFIG_DIR / Config.FILENAME

# Generated at 2022-06-23 19:01:46.151476
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    # assert that the save method stores the metadata
    metameta = config['__meta__']
    assert metameta['httpie'] == __version__
    # assert that the save method stores the custom data
    customdata = config['default_options']
    assert customdata == ['--json']



# Generated at 2022-06-23 19:01:47.628455
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict.__init__.__class__.__name__ == 'instancemethod'


# Generated at 2022-06-23 19:01:53.600390
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestClass(BaseConfigDict):
        name = None
        helpurl = None
        about = None

    test_dir = "httpie/tests/test_config_dir/"
    test_file = "httpie/tests/test_config_dir/test/test.json"
    test_dict = {'test_key': 'test_value'}

    t = TestClass(test_file)
    t.save()

    assert Path(test_file).exists()

    with Path(test_file).open('rt') as f:
        data = json.load(f)

    assert data == test_dict

# Generated at 2022-06-23 19:01:55.837348
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path='./data/config.json')
    assert config.is_new() == False


# Generated at 2022-06-23 19:02:00.197948
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    >>> config = BaseConfigDict(Path(__file__))
    >>> config.ensure_directory()
    >>> config.path.parent.exists()
    True
    >>> config.ensure_directory()
    >>> config.path.parent.exists()
    True
    """
    pass

# Generated at 2022-06-23 19:02:06.432018
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    basedict = BaseConfigDict(Path('/home/mengyao/Documents/GitHub/httpie/tests/fixtures/config/config.json'))
    basedict.load()
    assert basedict['__meta__']['httpie'] == 'clien-httpie-v0.0.2'
    assert basedict['__meta__']['about'] == 'https://httpie.org/about'

# Generated at 2022-06-23 19:02:12.864146
# Unit test for constructor of class Config
def test_Config():
    test_object = Config(directory='test_httpie')
    assert test_object['default_options'] == []
    assert test_object.directory == Path('test_httpie')
    assert test_object.path == Path('test_httpie/config.json')
    assert test_object.name is None
    assert test_object.helpurl is None
    assert test_object.about is None



# Generated at 2022-06-23 19:02:24.031385
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    a = BaseConfigDict(Path('/tmp/httpie/a/b/c/config.json'))

    with patch.object(BaseConfigDict, 'path') as mocked:
        mocked.parent.mkdir = MagicMock(side_effect = [OSError(errno.EEXIST, 'error message'), None])
        a.ensure_directory()
        assert mocked.parent.mkdir.called == 2
        # Test the error message, when try to create a file, but that path exist
        mocked.parent.mkdir.assert_raised_with(mode=0o700, parents=True)

    with patch.object(BaseConfigDict, 'path') as mocked:
        mocked.parent.mkdir = MagicMock(side_effect = OSError(errno.ENOENT, 'error message'))
       

# Generated at 2022-06-23 19:02:27.354616
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    config_file_error = ConfigFileError('test')
    assert str(config_file_error) == 'test'


if __name__ == '__main__':
    test_ConfigFileError()

# Generated at 2022-06-23 19:02:29.588563
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("hello")
    except ConfigFileError as e:
        assert str(e) == "hello"

# Generated at 2022-06-23 19:02:36.706159
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_dict = {
        'default_options': ['--pretty=all'],
        '__meta__': {
            'httpie': __version__
        }
    }

    path = Path(os.path.dirname(__file__)) / '../../httpie_dir/config.json'
    config = BaseConfigDict(path)
    config.update(test_config_dict)
    config.save()
    assert config == test_config_dict



# Generated at 2022-06-23 19:02:38.555802
# Unit test for constructor of class Config
def test_Config():
    C = Config()
    assert C['default_options'] == []



# Generated at 2022-06-23 19:02:45.471078
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class Test_Configfile(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path=path)
    with TemporaryDirectory() as tmpdirname:
        temp_file = Path(tmpdirname) / 'config.json'
        test = Test_Configfile(temp_file)
        test.update({'hello': 'world'})
        assert not test.path.exists()
        test.save()
        assert test.path.exists()
        test.delete()
        assert not test.path.exists()



# Generated at 2022-06-23 19:02:57.289047
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    from httpie import config
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie import tests
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    if is_windows:
        directory_for_test = Path(temp_dir) / 'config'
    else:
        directory_for_test = Path(temp_dir) / '.config/httpie'
    config.DEFAULT_CONFIG_DIR = directory_for_test
    path_for_test = directory_for_test / 'config.json'
    # Initialize class, file does not exist
    test_config = BaseConfigDict(path_for_test)
    tests.assert_true(test_config.is_new())
    # Create file

# Generated at 2022-06-23 19:03:08.003150
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    home_dir = Path.home()
    xdg_config_home_dir = os.environ.get(ENV_XDG_CONFIG_HOME)
    DEFAULT_XDG_CONFIG_HOME = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    if xdg_config_home_dir is None:
        xdg_config_home_dir = DEFAULT_XDG_CONFIG_HOME
    directory = xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME
    test_BaseConfigDict = BaseConfigDict(directory / Config.FILENAME)
    assert isinstance(test_BaseConfigDict, dict)
    assert test_BaseConfigDict['__meta__'] is None


# Generated at 2022-06-23 19:03:19.371753
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    class test(BaseConfigDict):
        name = 'test'
        helpurl = 'http://httpbin.org/'
        about = 'testing'

    tmp_dir = Path(tempfile.mkdtemp())
    file_name = tmp_dir / 'test_config.json'
    my_dict = {
        "test": "true",
        "test2": "false"
    }

# Generated at 2022-06-23 19:03:20.672925
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config('/tmp')
    assert config.is_new()


# Generated at 2022-06-23 19:03:32.180758
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def assert_default_config_dir(env_config_dir, expected_path):
        os.environ[ENV_HTTPIE_CONFIG_DIR] = env_config_dir
        if is_windows:
            assert get_default_config_dir() == expected_path
        else:
            assert get_default_config_dir() == Path.home() / expected_path
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

    assert_default_config_dir('', '.config/httpie')
    assert_default_config_dir('/config', '/config')
    assert_default_config_dir('/config/', '/config')
    assert_default_config_dir('./config', './config')
    assert_default_config_dir('./config/', './config')

# Generated at 2022-06-23 19:03:38.963074
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tempdir = Path('test_BaseConfigDict_save')
    if not tempdir.is_dir():
        tempdir.mkdir()
    temp_file = tempdir / 'test.json'
    if temp_file.exists():
        temp_file.unlink()
    temp_dict = BaseConfigDict(temp_file)
    temp_dict.save()
    assert temp_file.exists()


# Generated at 2022-06-23 19:03:43.587207
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict('/tmp/toto.json')
    try:
        config.delete()
    except OSError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 19:03:53.666701
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import random
    import shutil
    # create a random dir path
    tmp_dir = os.path.join('/tmp', 'httpie-test-%s' % random.randint(0, 100000))
    # create this dir
    os.mkdir(tmp_dir)
    # generate a file called config.json
    config_file = os.path.join(tmp_dir, 'config.json')
    with open(config_file, 'w') as f:
        f.write('{}')
    cls = BaseConfigDict(path=tmp_dir)
    try:
        cls.load()
        assert len(cls) == 0
    finally:
        # remove temp dir
        shutil.rmtree(tmp_dir)


# Generated at 2022-06-23 19:03:59.815714
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file = Path('./test.json')
    try:
        config_file.unlink()
    except:
        pass
    a = BaseConfigDict(path=config_file)
    a.save()
    assert config_file.exists()
    assert isinstance(json.load(open(config_file,'r')),dict)
    config_file.unlink()


# Generated at 2022-06-23 19:04:10.849078
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class DummyConfigDict(BaseConfigDict):
        name = 'name'
        helpurl = 'helpurl'
        about = 'about'

    c = DummyConfigDict(Path('/tmp/config.json'))
    c.ensure_directory()

    load_data = {
        '__meta__': {
            'httpie': '1.0.0',
            'help': 'helpurl',
            'about': 'about',
        },
        'default_options': ['a', 'b', 'c']
    }

    with open('/tmp/config.json', 'w') as f:
        json.dump(load_data, f)

    c.load()
    assert c['default_options'] == ['a', 'b', 'c']

# Generated at 2022-06-23 19:04:19.999795
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_directory = Path('config') / 'path'
    assert not config_directory.exists()
    try:
        config_directory.mkdir(mode=0o700, parents=False)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    config_directory_file = config_directory.resolve() / 'config.json'
    f = open(config_directory_file, 'w+')
    f.close()
    config_directory_object = BaseConfigDict(config_directory_file)
    config_directory_object.ensure_directory()
    assert config_directory_file.exists()
    config_directory.unlink()


# Generated at 2022-06-23 19:04:31.131541
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    assert get_default_config_dir().parts == (Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME).parts

    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / 'foo')

    assert get_default_config_dir().parts == (Path.home() / 'foo' / DEFAULT_CONFIG_DIRNAME).parts

    if is_windows:
        os.environ.pop(ENV_XDG_CONFIG_HOME, None)
        assert get_default_config_dir().parts == DEFAULT_WINDOWS_

# Generated at 2022-06-23 19:04:39.346241
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os

    config_dict = BaseConfigDict(Path("/no/such/file"))
    config_dict.ensure_directory()

    assert not os.path.exists("/no")
    assert not os.path.exists("/no/such")

    # make a temp directory that we can easily remove
    tmp = Path(tempfile.mkdtemp())
    tmp_config_dict = BaseConfigDict(tmp / "config")

    assert tmp_config_dict.path.parent.exists()
    assert not tmp_config_dict.path.exists()

    tmp_config_dict.ensure_directory()

    assert tmp_config_dict.path.parent.exists()
    assert not tmp_config_dict.path.exists()

    # clean up
   

# Generated at 2022-06-23 19:04:43.164136
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir in (Path.home() / 'httpie', Path.home() / '.config' / 'httpie')


if __name__ == '__main__':
    test_get_default_config_dir()

# Generated at 2022-06-23 19:04:43.760496
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass

# Generated at 2022-06-23 19:04:54.108621
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # if dir exists, do nothing
    original_path = Path.cwd()
    try:
        config_diir = original_path.parent / "httpie_config"
        config_diir.mkdir(parents=True, exist_ok=True)
        file = config_diir / "config.json"
        c = Config(config_diir)
        open(file, 'a').close()
        c.ensure_directory()
        assert file.exists()
    finally:
        shutil.rmtree(config_diir)

    # if dir doesn't exist, create it
    file = original_path / 'config.json'
    c = Config(original_path)
    c.ensure_directory()
    assert file.exists()

    # if dir is root, fail

# Generated at 2022-06-23 19:04:55.855784
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    base_config_dict = BaseConfigDict(path=Path(os.getcwd()) / 'file.json')
    assert not base_config_dict.is_new()



# Generated at 2022-06-23 19:04:59.414807
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    test_string = '''{
    "__meta__": {
        "help": "xxx",
        "httpie": "xxx",
        "about": "xxx"
    }
}'''
    with open("test.json", 'wt', encoding='utf-8') as f:
        f.write(test_string)
    config = BaseConfigDict("test.json")
    config.delete()
    assert not os.path.exists("test.json")
    if os.path.exists("test.json"):
        os.remove("test.json")

# Generated at 2022-06-23 19:05:09.088822
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_env = os.environ.get(ENV_XDG_CONFIG_HOME)
    old_cwd = os.getcwd()
    try:
        os.environ[ENV_XDG_CONFIG_HOME] = '/config/home'
        os.chdir('/')
        print('config_dir', get_default_config_dir())
    finally:
        if old_env:
            os.environ[ENV_XDG_CONFIG_HOME] = old_env
        else:
            del os.environ[ENV_XDG_CONFIG_HOME]
        os.chdir(old_cwd)

# Generated at 2022-06-23 19:05:09.520650
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    pass

# Generated at 2022-06-23 19:05:12.039031
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    A = BaseConfigDict('abc')
    assert A.path == 'abc'



# Generated at 2022-06-23 19:05:21.210021
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        FILENAME = 'test.json'
        DEFAULTS = {
            'default_options': []
        }
    config_path = '/tmp/test.json'
    config = TestConfigDict(path=config_path)
    config.save()
    with open(config_path, 'rt') as f:
        data = f.read()
        assert data == ('{\n'
                        '    "__meta__": {\n'
                        '        "httpie": "0.9.9"\n'
                        '    }\n'
                        '}\n')
    os.remove(config_path)

# Generated at 2022-06-23 19:05:22.424414
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path.home() / 'httpie.json'
    bd = BaseConfigDict(path)
    bd.load()
    print(bd)


# Generated at 2022-06-23 19:05:27.343686
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path_name = "config_file"
    config_dict = BaseConfigDict(path_name)
    try:
        config_dict.delete()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    except:
        raise


# Generated at 2022-06-23 19:05:32.124761
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    cfg = BaseConfigDict(Path(DEFAULT_CONFIG_DIR))
    print('cfg.is_new():', cfg.is_new())
    if cfg.is_new():
        print('cfg is new')
    else:
        print('cfg is', cfg)

import argparse


# Generated at 2022-06-23 19:05:39.469274
# Unit test for constructor of class Config
def test_Config():
    # test init with dir path
    config_dir = Path('~').expanduser()
    config = Config(config_dir)
    assert config.directory == config_dir
    assert config.path == config_dir / 'config.json'
    assert config.DEFAULTS == {'default_options': []}
    assert config == {}
    assert config.path.is_absolute()
    assert config.DEFAULTS['default_options'] == config.default_options
    # test init with dir str
    config_dir = str(Path('~').expanduser())
    config = Config(config_dir)
    assert config.directory == Path(config_dir)
    assert config.path == Path(config_dir) / 'config.json'
    assert config.DEFAULTS == {'default_options': []}
    assert config == {}

# Generated at 2022-06-23 19:05:47.493907
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import sys
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    if is_windows:
        return
    @staticmethod
    def create_tmp_path():
        dir = tempfile.mktemp()
        os.mkdir(dir)
        return Path(dir)
    @staticmethod
    def delete_tmp_path(path):
        shutil.rmtree(path)
    def test_save_new(self):
        path = self.create_tmp_path()
        cls = BaseConfigDict(path / 'cls.json')
        cls['key'] = 'value'
        cls.save()
        assert (path / 'cls.json').is_file

# Generated at 2022-06-23 19:05:54.595532
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def not_exist_dir():
        path_dir=Path('/home/user/dir/dir2/dir3/dir4')
        path_dir.parent.mkdir(parents=True, exist_ok=True)
    not_exist_dir()
    assert Path('/home/user/dir/dir2/dir3').exists() == True
    assert Path('/home/user/dir/dir2/dir3/dir4').exists() == True


# Generated at 2022-06-23 19:06:00.231193
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    parent_path = './tmp_httpie_test'
    child_path = './tmp_httpie_test/a/b'

    a = BaseConfigDict('file')
    a.path = child_path
    a.ensure_directory()
    assert Path(parent_path).exists()
    assert Path(child_path).exists()

    a.path = child_path
    a.ensure_directory()
    assert Path(parent_path).exists()
    assert Path(child_path).exists()


# Generated at 2022-06-23 19:06:07.526713
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    bcd = BaseConfigDict(None)
    bcd['foo'] = 'bar'
    bcd.update({'baz': 'qux'})
    output_string = json.dumps(
        obj=bcd,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )

    assert output_string == '{\n    "foo": "bar",\n    "baz": "qux"\n}'


# Generated at 2022-06-23 19:06:15.350533
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = '/tmp/test_httpie_config_delete'
    bd = BaseConfigDict(path)
    if os.path.exists(path):
        os.remove(path)
    bd.delete()  #deletaing a non existant file shouldn't raise an exception

    with open(path, 'w'):
        pass

    bd.delete()
    assert(not os.path.exists(path))
    # but the directory should still exist
    assert(os.path.exists(os.path.dirname(path)))



# Generated at 2022-06-23 19:06:26.395632
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Test for deleting config file with the right path
    p = Path(DEFAULT_CONFIG_DIR) / Config.FILENAME
    path_test1 = str(p)
    if p.exists():
        p.unlink()
    config_test1 = BaseConfigDict(p)
    with open(path_test1, "w") as f:
        json.dump(config_test1, f)
    config_test1.delete()
    assert not p.exists()

    # Test for deleting config file with the wrong path
    p2 = Path(DEFAULT_CONFIG_DIR) / "test2.json"
    path_test2 = str(p2)
    if p2.exists():
        p2.unlink()
    config_test2 = BaseConfigDict(p)

# Generated at 2022-06-23 19:06:28.749742
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    print("Testing: ConfigFileError")
    try:
        raise ConfigFileError('test')
    except ConfigFileError as e:
        print(e)


# Generated at 2022-06-23 19:06:29.909669
# Unit test for constructor of class Config
def test_Config():
    config_dir = "../config"
    Config(config_dir)


# Generated at 2022-06-23 19:06:32.442803
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    delete_if_exists(Config().path)
    assert Config().is_new()



# Generated at 2022-06-23 19:06:43.382984
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    if os.name == 'nt':
        return 'Passed'
    test_path = DEFAULT_CONFIG_DIR / "httpie.test"
    expected_path = os.path.normpath(str(DEFAULT_CONFIG_DIR))
    try:
        p1 = BaseConfigDict(test_path)
        p1.ensure_directory()
        if os.path.normpath(str(DEFAULT_CONFIG_DIR)) != expected_path:
            return False
        return True
    finally:
        try:
            os.rmdir(test_path)
        except: pass
        try:
            os.rmdir(DEFAULT_CONFIG_DIR)
        except: pass


# Generated at 2022-06-23 19:06:47.730132
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    t_BaseConfigDict = BaseConfigDict('/abc.json')
    t_BaseConfigDict.save()
    assert t_BaseConfigDict.path.is_file()
    t_BaseConfigDict.delete()
    assert not t_BaseConfigDict.path.is_file()

# Generated at 2022-06-23 19:06:49.260970
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test')
    except ConfigFileError:
        assert True


# Generated at 2022-06-23 19:07:01.328290
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from httpie.plugins import standard

    config_dir = Path('.test_httpie')

    class TestConfig(BaseConfigDict):
        name = 'Test'
        FILENAME = 'test_config.json'
        DEFAULTS = {
            'test_config': None
        }
        helpurl = 'help'
        about = 'about'

        def __init__(self, directory: Path = config_dir):
            super().__init__(path=directory / self.FILENAME)
            self.update(self.DEFAULTS)
            self['__meta__'] = {
                'httpie': __version__
            }

    config = TestConfig()

    def reset():
        try:
            config_dir.unlink()
        except:
            pass

    reset()



# Generated at 2022-06-23 19:07:08.243917
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('configdir')
    config_dir.mkdir()
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_dict = BaseConfigDict(path=config_file)
    config_dict.save()
    assert config_file.exists()
    assert config_dict['__meta__']['httpie'] == __version__
    config_dict.delete()
    config_dir.rmdir()


# Generated at 2022-06-23 19:07:14.761529
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # data = {'a':1, 'b':3.4, 'c':None}
    test_cfg = Config(directory='./test_config')
    test_cfg['test'] = {"test1": 1, "test2": 2, "test3": 3}
    test_cfg.save()
    with open(test_cfg['__meta__']['path'], 'r') as f:
        test_json = json.load(f)
    print(test_json['__meta__']['path'])


if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-23 19:07:24.046478
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Path will be changed
    config_path = os.path.join(str(DEFAULT_CONFIG_DIR), 'test.json')
    config = BaseConfigDict(path=config_path)

    try:
        # The file does not exist so the content of the file is {}
        assert isinstance(config, BaseConfigDict)
        assert config == {}
    finally:
        os.remove(config_path)


# Generated at 2022-06-23 19:07:34.090163
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a BaseConfigDict-object for creating a config file
    directory = Path('./configfiles')
    baseConfigDictObject = BaseConfigDict(directory)
    assert baseConfigDictObject.path == Path('./configfiles')

    # parent directory exists
    pathForTest = Path('./configfiles/parentDirExists')
    baseConfigDictObject.path = pathForTest
    baseConfigDictObject.ensure_directory()
    assert pathForTest.parent.exists()

    # parent directory is created by a parent directory
    pathForTest = Path('./configfiles/parentDirCreatedByAnotherParentDir/foo')
    baseConfigDictObject.path = pathForTest
    baseConfigDictObject.ensure_directory()
    assert pathForTest.parent.exists()

    # parent directory will

# Generated at 2022-06-23 19:07:38.648442
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # create temp file
    test_file = Path('temp.json')
    test_file.write_text('{"default_options": []}')
    test_config = BaseConfigDict(test_file)
    test_config.delete()
    assert test_file.exists() is False

# Generated at 2022-06-23 19:07:42.894410
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict(path=Path('config.json'))
    assert config.__class__ == BaseConfigDict
    assert config.path == Path('config.json')

    try:
        config.delete()
    except FileNotFoundError:
        pass



# Generated at 2022-06-23 19:07:49.090913
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # test not equal
    baseConfigDict = BaseConfigDict("./test.json")
    assert baseConfigDict.path != "./test.json"
    # test equal
    assert baseConfigDict.path == Path("test.json")
    # test new
    assert baseConfigDict.is_new()
    # test ensure directory
    try:
        baseConfigDict.ensure_directory()
    except OSError as e:
        assert False



# Generated at 2022-06-23 19:07:58.728480
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    import json
    import os

    # Get the template for a new config.json
    template = BaseConfigDict.DEFAULTS.copy()
    template["__meta__"] = {"httpie": "1.0"}

    with TemporaryDirectory() as d:
        path = Path(d)

        # Case 1: config.json doesn't exists
        test_config_dict = BaseConfigDict(path / "config.json")
        test_config_dict.load()
        assert test_config_dict == template

        # Case 2: config.json exists with correct format
        with open(path / "config.json", "w") as f:
            json.dump(data, f)
        test_config_dict = BaseConfig

# Generated at 2022-06-23 19:08:07.068755
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import platform

    # test there are no default where config directory will be ~/.config/httpie
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    # test windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    if platform.system() != 'Windows':
        # test legacy ~/.httpie
        path = os.path.join(os.path.expanduser('~'), '.httpie')
        os.environ[ENV_HTTPIE_CONFIG_DIR] = path
        assert get_default_config_dir() == path

        # test XDG

# Generated at 2022-06-23 19:08:16.177429
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Case1: DEFAULT_CONFIG_DIR is type of Path
    test_config = Config(DEFAULT_CONFIG_DIR)
    test_config.save()
    
    # Case2: DEFAULT_CONFIG_DIR is type of str
    DEFAULT_CONFIG_DIR = str(DEFAULT_CONFIG_DIR)
    test_config = Config(DEFAULT_CONFIG_DIR)
    test_config.save()
    
    # Case3: DEFAULT_CONFIG_DIR dir is not exists
    DEFAULT_CONFIG_DIR = 'a/b'
    test_config = Config(DEFAULT_CONFIG_DIR)
    test_config.save()

# Generated at 2022-06-23 19:08:19.486847
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    DEFAULT_CONFIG_DIRNAME = 'httpie'
    config = BaseConfigDict(DEFAULT_CONFIG_DIRNAME)
    assert config.path is not None