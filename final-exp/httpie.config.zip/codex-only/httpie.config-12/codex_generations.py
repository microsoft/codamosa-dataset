

# Generated at 2022-06-23 18:58:23.680756
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path("/tmp/foo"))
    config.delete()

    assert config.is_new() == True

    config.save()
    assert config.is_new() == False

    config.delete()



# Generated at 2022-06-23 18:58:27.457827
# Unit test for constructor of class Config
def test_Config():
    test_config_dir = Path('/tmp/config_dir')
    test_config = Config(directory=test_config_dir)
    assert test_config.directory == test_config_dir
    assert test_config.default_options == []
    assert test_config.path == Path('/tmp/config_dir/config.json')




# Generated at 2022-06-23 18:58:30.491710
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict('./test_config_file')
    config.load()
    assert config.is_new()

# Generated at 2022-06-23 18:58:36.920449
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    global DEFAULT_CONFIG_DIR
    DEFAULT_CONFIG_DIR = DEFAULT_CONFIG_DIR + '/test'
    config = Config()
    config.save()
    with open(DEFAULT_CONFIG_DIR + '/' + config.FILENAME, 'r') as fin:
        content = fin.read()
        assert content == '{"__meta__": {"about": null, "help": null, "httpie": "1.0.3"}, "default_options": []}\n'

# Generated at 2022-06-23 18:58:48.343524
# Unit test for constructor of class Config
def test_Config():
    # ===========test for environment variable==========
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie import __version__
    from pathlib import Path
    #make sure the directory exists
    os.mkdir(DEFAULT_CONFIG_DIR)
    #environment variable is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = DEFAULT_CONFIG_DIR
    #constructor is invoked
    config = Config()
    #make sure the expected value is obtained
    assert config.path == DEFAULT_CONFIG_DIR / config.FILENAME
    #test the manual creation of __meta__
    assert config.get('__meta__') == {
        'httpie': __version__
    }
    #test the manual creation of default_options
    assert config.get('default_options')

# Generated at 2022-06-23 18:58:57.694729
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/path/to/httpie/config/directory'
    assert str(get_default_config_dir()) == '/path/to/httpie/config/directory'

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    # 2. Windows
    if is_windows:
        assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-23 18:58:59.087780
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    bc = BaseConfigDict(Path('test.json'))
    bc.delete()



# Generated at 2022-06-23 18:59:09.264914
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    A test written to test functionality of method ensure_directory of class BaseConfigDict
    """
    
    dir_path = ".test_directory" # path to directory that we want to create
    if os.path.exists(dir_path):
        shutil.rmtree(dir_path)
    config_dict = BaseConfigDict(Path(dir_path+"/temp.json")) # we create instance of BaseConfigDict
    config_dict.ensure_directory() # now we call ensure_directory method
    assert os.path.exists(dir_path) # and check if .test_directory/ dir exists on filesystem



# Generated at 2022-06-23 18:59:13.981718
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    print(config.DEFAULTS)
    config.DEFAULTS.update({'default_options': ['a', 'b', 'c']})
    config.save()
    print(config.DEFAULTS)


if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-23 18:59:20.894212
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """get_default_config_dir()
    """
    with os.environ.copy():
        del os.environ['XDG_CONFIG_HOME']
        del os.environ['HTTPIE_CONFIG_DIR']

        if is_windows:
            assert get_default_config_dir().as_posix() == os.path.normcase(
                Path(os.environ['APPDATA']) / DEFAULT_CONFIG_DIRNAME).as_posix()
        else:
            # Legacy (pre-XDG) default config dir
            legacy_config_dir = Path('~') / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-23 18:59:21.865455
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert str(ConfigFileError("test")) == "test"

# Generated at 2022-06-23 18:59:25.116621
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Initialization of a BaseConfigDict object
    config = BaseConfigDict(path = DEFAULT_CONFIG_DIR)
    if config.is_new():
        assert True
    else:
        assert False

test_BaseConfigDict_is_new()


# Generated at 2022-06-23 18:59:28.627184
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class Test_BaseConfigDict(BaseConfigDict):
        pass

    baseConfigDict = Test_BaseConfigDict(Path(DEFAULT_CONFIG_DIR))
    assert baseConfigDict.path



# Generated at 2022-06-23 18:59:38.640319
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    """
    Checks if the is_new function works properly.
    """
    def create_file(self):
        try:
            self.path.parent.mkdir(mode=0o700, parents=True)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
        with self.path.open('wt', encoding='utf-8') as f:
            f.write('')

    test_file = 'test.json'
    config = BaseConfigDict(path=test_file)
    assert config.is_new()
    # Create test file
    create_file(config)
    assert not config.is_new()
    # Remove test file
    config.path.unlink()
    assert config.is_new()


# Generated at 2022-06-23 18:59:41.145034
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    fd, path = tempfile.mkstemp()
    bcd = BaseConfigDict(path=path)
    bcd.delete()
    os.close(fd)


# Generated at 2022-06-23 18:59:48.701083
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from pathlib import Path
    
    class MockBaseConfigDict(BaseConfigDict):
        name = 'name'
        helpurl = 'helpurl'
        about = 'about'

    mock_config_dict = MockBaseConfigDict(
        Path('./tmp/mock_config_dict'))
    try:
        mock_config_dict.save()
        # if save success,
        # the code will not throw any exception
    finally:
        try:
            shutil.rmtree('./tmp')
        except:
            pass


# Generated at 2022-06-23 18:59:51.953444
# Unit test for constructor of class Config
def test_Config():
    # call construtor of Config without parameters
    config = Config()
    assert config['default_options'] == []
    assert config.directory == DEFAULT_CONFIG_DIR
    # call construtor of Config with parameters
    config = Config(directory = '/tmp/1')
    assert config.directory == '/tmp/1'



# Generated at 2022-06-23 18:59:53.316779
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    f = BaseConfigDict.save
    a = f()
    assert a == None

# Generated at 2022-06-23 18:59:55.901015
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # predefined path
    b = BaseConfigDict(path=Path('test.json'))
    assert b.path.name == 'test.json'
    assert b.path.exists() == False


# Generated at 2022-06-23 19:00:02.662375
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('/home/yzy/test/config.json')
    config_dict = BaseConfigDict(path)
    config_dict.update({'test':'test'})
    config_dict.save()
    config_dict.update({'test2':'test2'})
    config_dict.load()
    if config_dict['test'] == 'test':
        print("BaseConfigDict load test passed")
    else:
        print("BaseConfigDict load test failed")


# Generated at 2022-06-23 19:00:04.705890
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict({'foo': 'bar'})
    assert config == {'foo': 'bar'}

# Generated at 2022-06-23 19:00:11.628441
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path = Path("test"))
    old_path = config.path
    new_config = config.is_new()
    assert new_config == True
    config.path = Path("test")
    config.path.touch()
    new_config = config.is_new()
    assert new_config == False
    config.path.unlink()
    config.path = old_path
    if os.path.exists("test"):
        os.rmdir("test")


# Generated at 2022-06-23 19:00:18.510345
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    tempdir = Path(tempfile.mkdtemp())
    config_dir = tempdir / DEFAULT_CONFIG_DIR
    config_file = config_dir / Config.FILENAME

    config_file_content = '{"foo": "bar"}'
    config_file.write_text(config_file_content)

    config = Config(directory=config_dir)
    config.load()
    assert config == {'foo': 'bar'}

    config.delete()
    config.save(fail_silently=True)
    assert config_file.read_text() == config_file_content

# Generated at 2022-06-23 19:00:28.391540
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import subprocess
    import pathlib

    def run_in_subprocess(*, env: dict, home_dir_path: pathlib.Path) -> subprocess.CompletedProcess:
        env = dict(env,
                   HTTPIE_CONFIG_DIR=None,
                   XDG_CONFIG_HOME=None)
        args = f'import httpie.config; print(repr(httpie.config.get_default_config_dir()))'
        return subprocess.run(['python', '-c', args],
                              env=env,
                              check=True,
                              cwd=str(home_dir_path))


# Generated at 2022-06-23 19:00:30.299276
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path("~/path/to/config.json"))
    assert config.is_new()

# Generated at 2022-06-23 19:00:35.811592
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = Path('tests/unit/test_BaseConfigDict_delete.json')
    test_dict = {
        'a': 1,
        'b': 2
    }
    config = BaseConfigDict(path)
    config.update(test_dict)
    config.save()
    assert path.exists()
    config.delete()
    assert not path.exists()

# Generated at 2022-06-23 19:00:36.887390
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    c = Config()
    c.delete()



# Generated at 2022-06-23 19:00:38.065341
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = '~/.httpie/config.json'
    config = BaseConfigDict(path)
    config.load()
    # print(config.load())
    print(config)



# Generated at 2022-06-23 19:00:41.036713
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config['default_options'] == []
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-23 19:00:46.293380
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    config_dir = get_default_config_dir()
    assert config_dir.name == DEFAULT_CONFIG_DIRNAME
    assert config_dir.parent.name == DEFAULT_RELATIVE_XDG_CONFIG_HOME


test_get_default_config_dir()

# Generated at 2022-06-23 19:00:49.750169
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    assert conf.directory == DEFAULT_CONFIG_DIR
    assert conf.FILENAME == 'config.json'
    assert conf.DEFAULTS == {'default_options': []}


# Generated at 2022-06-23 19:00:52.844343
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    f = BaseConfigDict(path=Path("/home/travis/build/jakubroztocil/httpie/tests/data"))
    assert f.is_new() == True

# Generated at 2022-06-23 19:01:04.155910
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    import time
    import uuid
    import tempfile
    
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path=path)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_config_path = Path(tmpdir) / 'test_config.json'
        test_config = TestConfigDict(test_config_path)

        print("test_config.is_new()", test_config.is_new())
        test_config.save()
        print("test_config.is_new()", test_config.is_new())

        test_config = TestConfigDict(test_config_path)

# Generated at 2022-06-23 19:01:10.098379
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('test_dir')
    config_dir.mkdir()
    config_file = config_dir / 'config'
    assert not config_file.exists()
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_file.exists()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-23 19:01:11.409533
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    config = Config(directory = '../')



# Generated at 2022-06-23 19:01:13.931718
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(ConfigFileError):
        raise ConfigFileError('foo')

# Generated at 2022-06-23 19:01:24.492386
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir1 = Path('test_dir')
    config_dir1.mkdir(mode=0o700, parents=True)
    config_dir2 = Path('test_dir/test_dir')
    config_dir2.mkdir(mode=0o700, parents=True)
    config_file = Path('test_dir/test_dir/config.json')
    config_file.touch()
    config = Config(config_dir1)

    config['default_options'] = ['--form']
    config.save()

    config_file_path = config_dir1 / 'config.json'
    config2 = Config(config_dir2)
    config2.load()
    config3 = Config()
    config3.load()
    assert config2['default_options'] == ['--form']

# Generated at 2022-06-23 19:01:36.575582
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test XDG
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = os.path.abspath('/non/existent')
    assert get_default_config_dir() == Path('/non/existent') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

# Generated at 2022-06-23 19:01:39.691398
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('anypath'))
    config.ensure_directory()

# Generated at 2022-06-23 19:01:48.331689
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # from pathlib import Path
    from httpie import __version__
    from io import StringIO
    import json
    import os

    temp_config_file = StringIO()
    temp_config = BaseConfigDict(temp_config_file)
    helpurl = "TEST_HELP_URL"
    about = "TEST_ABOUT_TEXT"
    temp_config['help'] = helpurl
    temp_config['about'] = about
    temp_config['__meta__'] = {
        'httpie': __version__
    }
    temp_config.save()
    with temp_config_file as file_object:
        data = json.load(file_object)
        assert data['help'] == helpurl
        assert data['about'] == about
    file_object.close()


# Generated at 2022-06-23 19:01:54.638017
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # create a temp dir for testing
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    assert config_dir.exists()
    config_path = config_dir / Config.FILENAME

    # test is_new() when config file does not exist
    config = Config(directory=config_dir)
    assert config.is_new() is True

    # test is_new() after loading for the first time
    config.load()
    assert config.is_new() is False

    # delete the config file and try again
    config.delete()
    assert config.is_new() is True

    # remove the temp dir
    import shutil
    shutil.rmtree(config_dir)



# Generated at 2022-06-23 19:01:58.562530
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path_str = os.path.join(str(DEFAULT_CONFIG_DIR), "test_config.json")
    path = Path(path_str)
    config = BaseConfigDict(path)
    config.load()


# Generated at 2022-06-23 19:02:01.822538
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    try:
        test = BaseConfigDict('tests/fixtures/config/config.json')
        test.delete()
    except IOError as e:
        assert e.errno != errno.ENOENT
    else:
        assert True

# Generated at 2022-06-23 19:02:02.365791
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    assert True

# Generated at 2022-06-23 19:02:14.253010
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    
    config_dir_1 = Path('test_dir_1')
    config_dir_2 = Path('test_dir_2')

    if config_dir_1.is_dir():
        os.rmdir(config_dir_1)
    if config_dir_2.is_dir():
        os.rmdir(config_dir_2)

    config = Config(config_dir_1)
    config.load()
    config_dir_1.mkdir()
    try:
        config.load()
        assert False
    except ConfigFileError:
        assert True
    
    os.rmdir(config_dir_1)

    config_dir_2.mkdir()
    config.load()
    assert config == Config.DEFAULTS

    os.rmdir(config_dir_2)

# Generated at 2022-06-23 19:02:25.272505
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Set environment variables
    xdg_key = ENV_XDG_CONFIG_HOME
    httpie_key = ENV_HTTPIE_CONFIG_DIR
    home_dir = Path.home()
    # Clear the keys
    if xdg_key in os.environ:
        del os.environ[xdg_key]
    if httpie_key in os.environ:
        del os.environ[httpie_key]
    # Case 1: Windows, and expected result
    old_win_dir = DEFAULT_WINDOWS_CONFIG_DIR
    win_dir = home_dir / Path('.win_httpie')
    DEFAULT_WINDOWS_CONFIG_DIR = win_dir
    assert get_default_config_dir() == win_dir
    # Restore windows variable
    DEFAULT_WINDOWS_

# Generated at 2022-06-23 19:02:28.831789
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    c=Config()
    print(c.is_new())
    c.load()
    print(c.is_new())

if __name__ == "__main__":
    test_BaseConfigDict_is_new()

# Generated at 2022-06-23 19:02:33.247766
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TestConfigDict(BaseConfigDict):
        name = None
        helpurl = None
        about = None
    config = TestConfigDict(path = Path('test/test.json'))
    assert config.is_new() == True


# Generated at 2022-06-23 19:02:43.997899
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pprint import pprint
    # In range, insert a directory and a file, then call the method,
    # and check if it works properly.
    for i in range(3):
        if i == 0:
            config_dir = '/tmp/httpie/config'
            file_name = 'config.json'
        elif i == 1:
            config_dir = '/tmp/httpie/config/aaa'
            file_name = 'config.json'
        else:
            config_dir = '/tmp/httpie/config/bbb'
            file_name = 'config.json'
        config_path = config_dir + '/' + file_name
        config_temp = BaseConfigDict(config_path)

        config_temp.ensure_directory()
        assert config_temp.path.parent.exists()

# Generated at 2022-06-23 19:02:54.343547
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    import os
    import json

    json_string = json.dumps(
        obj={'foo': 'bar', 'baz': 'qux'},
        indent=4,
        sort_keys=True,
        ensure_ascii=True
    )
    path = Path('/tmp/test_config.json')
    path.write_text(json_string + '\n')
    assert os.path.exists('/tmp/test_config.json')
    b = BaseConfigDict(path)
    b.delete()
    assert os.path.exists('/tmp/test_config.json') == False

# Generated at 2022-06-23 19:03:05.690098
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    original_env = copy.copy(os.environ)
    from httpie.config import get_default_config_dir
    import sys
    if sys.platform == 'win32':
        expected_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        home_dir = Path.home()
        expected_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / \
            DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == expected_dir
    HOME_DIR = str(Path.home())
    os.environ[ENV_HTTPIE_CONFIG_DIR] = HOME_DIR
    assert get_default_config_dir() == HOME_DIR

# Generated at 2022-06-23 19:03:07.895522
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict(Path('./testconfig.json'))
    config['test1'] = 'test1'
    config.ensure_directory()
    config.save()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-23 19:03:11.092670
# Unit test for constructor of class Config
def test_Config():
    path = '~/.config/httpie/'
    config_dir = Config(path)
    assert config_dir.directory == path
    
    

# Generated at 2022-06-23 19:03:15.517334
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory = Path("./test")
    path = directory / "config.json"
    config_dict = BaseConfigDict(path)
    config_dict.save(fail_silently=True)
    Path(directory).mkdir(mode=0o700, parents=True)
    assert config_dict.is_new() == True


# Generated at 2022-06-23 19:03:19.444293
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_directory = Path('/tmp/httpie/config')
    config_path = config_directory / Config.FILENAME
    config = Config(config_directory)
    config.save()

    loaded_config = Config(config_directory)
    loaded_config.load()
    assert loaded_config == config



# Generated at 2022-06-23 19:03:20.619087
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("test")
    except ConfigFileError:
        pass

# Generated at 2022-06-23 19:03:32.063772
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. Test explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/tests_env'
    assert get_default_config_dir() == Path('/tmp/tests_env')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Test Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() != DEFAULT_WINDOWS_CONFIG_DIR

    # 3. Test legacy ~/.httpie
    (Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).mkdir()
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CON

# Generated at 2022-06-23 19:03:35.128507
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Test for method delete of class BaseConfigDict
    """

    temp_config = BaseConfigDict(path="/test/test.json")
    temp_config.delete()



# Generated at 2022-06-23 19:03:39.205803
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class TestClass(BaseConfigDict):
        name = 'test'
        helpurl = 'helpurl'
        about = 'about'
    TestClass(Path('test.json')).delete()
    assert True



# Generated at 2022-06-23 19:03:41.084417
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_config = BaseConfigDict("./test.config")
    assert test_config.is_new() == False

# Generated at 2022-06-23 19:03:47.128638
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil

    path = Path("./test_BaseConfigDict_ensure_directory")
    if path.exists():
        shutil.rmtree(path)
    bc = BaseConfigDict("./test_BaseConfigDict_ensure_directory")
    bc.ensure_directory()

    assert(not bc.is_new())
    bc.delete()



# Generated at 2022-06-23 19:03:52.106134
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pathname = 'httpie/config/test_BaseConfigDict_load.json'
    with open(pathname, 'w') as f:
        json.dump(
            obj={},
            fp=f,
            indent=4,
            sort_keys=True,
            ensure_ascii=True,
        )
    with open(pathname) as f:
        assert(BaseConfigDict(Path(pathname)).load() == {})

# Generated at 2022-06-23 19:03:55.228121
# Unit test for constructor of class Config
def test_Config():
    # test constructor
    c = Config()
    print(c.directory)
    print(c.path)
    print(c.default_options)



# Generated at 2022-06-23 19:03:56.325211
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    BaseConfigDict(Path('./config.json'))

# Generated at 2022-06-23 19:04:03.691306
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Test case 1: the config file exist
    path = Path('test/test.json')
    path.write_text('test')
    config = BaseConfigDict(path)
    assert config.is_new() == False 
    path.unlink()
    # Test case 2: the config file does not exist
    path = Path('test/test.json')
    config = BaseConfigDict(path)
    assert config.is_new() == True


# Generated at 2022-06-23 19:04:12.175979
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TestConfigDict(BaseConfigDict):
        name = 'TestConfigDict'

    # create a test folder and config file
    current_dir = os.getcwd()
    config_folder = os.path.join(current_dir, 'httpie-test')
    config_file = os.path.join(config_folder, 'config.json')
    os.mkdir(config_folder)

    test_config_dict = TestConfigDict(config_file)
    assert test_config_dict.is_new()

    # when the config file exists, method is_new will return False
    open(config_file, 'a').close()
    test_config_dict2 = TestConfigDict(config_file)
    assert not test_config_dict2.is_new()

    # remove the test folder
   

# Generated at 2022-06-23 19:04:16.612943
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    bcd = BaseConfigDict(Path())
    assert isinstance(bcd, BaseConfigDict)
    assert isinstance(bcd, dict)
    assert bcd.name is None
    assert bcd.helpurl is None
    assert bcd.about is None


# Generated at 2022-06-23 19:04:20.933835
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    dir_path = Path('/tmp/httpie_config/test_is_new')
    if dir_path.exists():
        dir_path.rmdir()
    assert not Config(dir_path).is_new()


# Generated at 2022-06-23 19:04:21.927669
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    config = Config()


# Generated at 2022-06-23 19:04:25.522062
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.path = Path('test')
    config.ensure_directory()
    assert os.path.isdir('test')
    shutil.rmtree('test')



# Generated at 2022-06-23 19:04:35.922353
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(os.environ):
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        del os.environ[ENV_XDG_CONFIG_HOME]
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

        os.environ[ENV_HTTPIE_CONFIG_DIR] = 'A'
        assert get_default_config_dir() == Path('A')

        os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_

# Generated at 2022-06-23 19:04:38.734219
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict("config.json")
    assert config.load() == None


# Generated at 2022-06-23 19:04:46.389925
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from unittest.mock import mock_open, patch
    from io import StringIO
    m = mock_open(read_data = StringIO('{"a": 1, "b": 2, "c": 3}').read())
    m.return_value.__iter__ = lambda self: self
    m.return_value.__next__ = lambda self: next(iter(self.readline, ''))
    with patch('builtins.open', m):
        c = BaseConfigDict('./test')
        c.load()
        assert c == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-23 19:04:51.462877
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    p = Path('output.json')
    config = BaseConfigDict(path=p)
    assert config.is_new()

    p.mkdir()
    config = BaseConfigDict(path=p)
    assert config.is_new()

    p.mkdir()
    p.write_text('output')
    config = BaseConfigDict(path=p)
    assert not config.is_new()


# Generated at 2022-06-23 19:04:59.541596
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import shutil
    import tempfile
    import json
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = tempfile.mkdtemp()
    _test_dict = BaseConfigDict(Path(os.environ[ENV_HTTPIE_CONFIG_DIR]) / Config.FILENAME)
    assert os.path.exists(_test_dict.path), f"Config file does not exist in {os.environ[ENV_HTTPIE_CONFIG_DIR]}/{Config.FILENAME}"
    # 2. Windows
    if is_windows:
        _test_dict = BaseConfigDict(DEFAULT_WINDOWS_CONFIG_DIR / Config.FILENAME)

# Generated at 2022-06-23 19:05:02.092549
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.get('default_options') == [], "config's default_options got wrong"


# Generated at 2022-06-23 19:05:04.138484
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	config = BaseConfigDict(path=Path('tests/abcd'))
	assert config.is_new()
	assert config == {}
	config.load()
	config.save()
	config.path.unlink()


# Generated at 2022-06-23 19:05:10.186652
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    fname="myconfig.json"
    path=Path("/tmp")
    bc=BaseConfigDict(path=path/fname)
    f=bc.save()
    assert f == None
    with open(path/fname, 'r') as fd:
        data = json.load(fd)
        assert data["__meta__"] == {"httpie":__version__}
    os.remove(path/fname)

# Generated at 2022-06-23 19:05:19.196440
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():  # pragma: no cover
    class TestConfigDict(BaseConfigDict):
        def __init__(self):
            dirname = Path('.config') / DEFAULT_CONFIG_DIRNAME
            super().__init__(path=dirname / 'test.json')

    test_config_dict = TestConfigDict()
    test_config_dict.delete()
    test_config_dict.ensure_directory()
    assert Path('.config').exists()
    assert (Path('.config') / DEFAULT_CONFIG_DIRNAME).exists()

# Generated at 2022-06-23 19:05:25.939866
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from . import utils
    temp_dir = utils.temp_dir(prefix="test_BaseConfigDict_delete")
    config = BaseConfigDict(Path(temp_dir) / "test.json")
    config.save(fail_silently=True)
    assert Path(temp_dir) / "test.json".exists()
    config.delete()
    assert not Path(temp_dir) / "test.json".exists()

# Generated at 2022-06-23 19:05:32.912431
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ.copy()

# Generated at 2022-06-23 19:05:35.657976
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    directory = Path('config')
    path = directory / 'config.json'
    obj = BaseConfigDict(path)
    assert obj.path.name == 'config.json'


# Generated at 2022-06-23 19:05:45.643777
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = os.path.expanduser('~')
    assert get_default_config_dir() == Path(home_dir + '/.httpie')

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config'
    assert get_default_config_dir() == Path('/xdg/config/httpie')
    os.environ.pop(ENV_XDG_CONFIG_HOME)

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/env/config'
    assert get_default_config_dir() == Path('/env/config')
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    Path(home_dir + '/.config').mkdir(parents=True)
    assert get_default_config_

# Generated at 2022-06-23 19:05:47.534608
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    msg = "test error message"
    cfe = ConfigFileError(msg)
    assert cfe.__str__() == msg


# Generated at 2022-06-23 19:05:53.504499
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    p = Path(str(DEFAULT_CONFIG_DIR) + '/DEFAULT_CONFIG_DIR/DEFAULT_CONFIG_DIR')
    p.mkdir(parents=True, exist_ok=True)
    if p.exists():
        p.rmdir()
    bcdf = BaseConfigDict(p)
    bcdf.delete()
    assert not p.exists()

# Generated at 2022-06-23 19:06:01.088278
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class test_class(BaseConfigDict):
        pass
    cwd = os.getcwd()
    tmp_dir = Path('~/tmp').expanduser()
    tmp_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chdir(tmp_dir)
    # Fail silently
    test_class(Path('config.json')).save(fail_silently=True)
    # Fail loudly
    try:
        test_class(Path('/config.json')).save()
        assert False, "It should raise IOError when save to a non-existent path"
    except IOError:
        pass
    os.chdir(cwd)
    tmp_dir.rmdir()

# Generated at 2022-06-23 19:06:04.903802
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class TestConfig(BaseConfigDict):
        name = 'TestConfig'
    path = Path('test-tmp-file.tmp')
    config = TestConfig(path)
    path.write_text('dummy-content')
    config.delete()
    assert not path.exists()

# Generated at 2022-06-23 19:06:08.403113
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(
        path = "File path"
    )
    assert config.path == 'File path'
    assert config.name is None
    assert config.helpurl is None
    assert config.about is None


# Generated at 2022-06-23 19:06:13.838661
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        config_file = BaseConfigDict(f.name)
        config_file['a'] = 'b'
        config_file.save()
        config_file.load()
        assert config_file['a'] == 'b'


# Generated at 2022-06-23 19:06:16.874537
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path=Path("/tmp/my_config.json"))
    assert config.is_new() == True


# Generated at 2022-06-23 19:06:26.949953
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    from httpie.config import BaseConfigDict

    class test_config(BaseConfigDict):
        name = 'test'
        helpurl = None
        about = None
    test_path = 'temp.json'
    test_config_dict = test_config(test_path)
    test_config_dict.save()
    with open(test_path, 'r', encoding='utf-8') as f:
        test_config_json = json.loads(f.read())
    if os.path.exists(test_path):
        os.remove(test_path)
    if '__meta__' not in test_config_json:
        raise ValueError('BaseConfigDict.save() failed')



# Generated at 2022-06-23 19:06:29.289704
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path("/tmp/test"))
    config.ensure_directory()
    assert(os.path.exists("/tmp/test"))


# Generated at 2022-06-23 19:06:32.443248
# Unit test for constructor of class Config
def test_Config():
    assert Config().is_new() is True
    assert Config(directory="test-directory").is_new() is True


# Generated at 2022-06-23 19:06:39.912023
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    d = {'a': 1, 'b': 2}

    class DummyConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(path=Path.cwd() / 'config.json')
            self.update(d)

    c = DummyConfig()
    c.save()
    c.clear()
    c.load()
    c.delete()
    assert d == c



# Generated at 2022-06-23 19:06:48.444038
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from httpie.compat import is_windows

    config_dict = BaseConfigDict()
    config_dict['a'] = 'b'

    temp_dir = Path(tempfile.mkdtemp())
    config_dict.path = temp_dir / 'config.json'

    config_dict.save()
    assert config_dict.path.read_text() == '{\n    "a": "b"\n}\n'
    if not is_windows:
        assert config_dict.path.stat().st_mode == 0o600

    os.remove(config_dict.path)
    os.rmdir(temp_dir)



# Generated at 2022-06-23 19:06:56.116045
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    print(c)
    c = Config('/Users/qiaoyunyun/.httpie')
    print(c)
    print(c.DEFAULTS)
    print(c.directory)
    print(c.path)
    print(c.default_options)

if __name__ == '__main__':
    test_Config()

# Generated at 2022-06-23 19:07:03.858088
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dir = Path(os.path.dirname(__file__))
    config_dir = test_dir / ".." / "fixtures" / "config"
    class TestConfig(BaseConfigDict):
        name = "Test"
        helpurl = "https://github.com/jkbrzt/httpie"
        about = "HTTPie Test"

    config = TestConfig(path=config_dir / TestConfig.FILENAME)
    assert not config.is_new()
    assert config['foo'] == 'bar'
    assert config['__meta__'] == {
        'httpie': '0.9',
        'help': 'https://github.com/jkbrzt/httpie',
        'about': 'HTTPie Test'
    }

# Generated at 2022-06-23 19:07:08.428927
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    config = BaseConfigDict()
    config['hello'] = 'World'
    with tempfile.TemporaryDirectory() as tempdir:
        config.path = Path(tempdir) / '.config.json'
        config.save()
        config.load()
    assert config['hello'] == 'World'



# Generated at 2022-06-23 19:07:14.939420
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_config_dir = Path('/tmp/httpie-test-1/config.json')
    test_config_dict = BaseConfigDict(test_config_dir)
    test_config_dict.ensure_directory()
    assert test_config_dict.is_new() is True
    test_config_dict.save()
    assert test_config_dict.is_new() is False
    test_config_dict.delete()


# Generated at 2022-06-23 19:07:17.238010
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfe = ConfigFileError('testing')
    assert cfe is not None
    assert cfe.args[0] == 'testing'


# Generated at 2022-06-23 19:07:23.775282
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil
    import tempfile

    # Creating temporary directory
    temp_dir = tempfile.gettempdir()

    # Creating path to file
    path = Path(temp_dir) / DEFAULT_CONFIG_DIRNAME / 'config.json'

    # Creating object of BaseConfigDict class
    config = BaseConfigDict(path=path)

    # Ensuring directory
    config.ensure_directory()

    assert os.path.exists(str(path.parent))

    # Removing temporary directory
    shutil.rmtree(str(path.parent))

# Generated at 2022-06-23 19:07:26.525666
# Unit test for constructor of class Config
def test_Config():
    cfg = Config()
    assert cfg.default_options == ['--pretty=all']

# Generated at 2022-06-23 19:07:27.909643
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(path='config.json')



# Generated at 2022-06-23 19:07:29.092739
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    x = BaseConfigDict('/tmp/test')
    x.save()

# Generated at 2022-06-23 19:07:32.809796
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config = BaseConfigDict("/home/susan/Desktop/HTTPie/httpie/config/temp.json")
    test_config.save()
    # load the saved file, and should be the same
    with test_config.path.open('rt') as f:
       data = json.load(f)
    assert(data == test_config)



# Generated at 2022-06-23 19:07:44.563748
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test try except for load method of BaseConfigDict class
    # fail_silently is true
    config = Config()
    config.update({'a':3})
    config.save(fail_silently=True)
    config_1 = Config()
    config_1.load()
    assert config == config_1
    config_1.delete()

    # fail_silently is false
    config = Config()
    config.update({'a':3})
    config.save()
    config_1 = Config()
    config_1.load()
    assert config == config_1
    config_1.delete()

    # cannot load config file
    config = Config()
    try:
        config.load()
    except ConfigFileError:
        pass


test_BaseConfigDict_load()

# Generated at 2022-06-23 19:07:54.277948
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create test data
    import tempfile  # tempfile -- Generate temporary files and directories
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_f = tempfile.NamedTemporaryFile(mode='w+t',
                                        dir=tmp_dir.name,
                                        delete=False)
    tmp_f.write('{"key":"value"}')
    tmp_f.close()
    # Create test case
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path):
            self.path = path
            super().__init__(self.path)
    # Testing
    control_dict = {'key': 'value'}
    test_dict = TestConfigDict(tmp_f.name)
    test_dict.load()
    assert test_dict == control_dict

# Generated at 2022-06-23 19:08:01.206423
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Check load() function
    file_path = 'test.txt'
    file_content = '''{
        "test_int": 1,
        "test_str": "test string"
    }'''
    with open(file_path, 'w') as f:
        f.write(file_content)

    config = BaseConfigDict(file_path)
    config.load()
    assert config['test_int'] == 1
    assert config['test_str'] == 'test string'

    # Check save() function
    new_file_path = 'test2.txt'
    config.path = new_file_path
    config.save()

    with open(new_file_path, 'r') as f:
        assert f.read() == file_content

    # Check delete() function
    config.delete()

# Generated at 2022-06-23 19:08:13.416037
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def mock_env(name, value):
        return_values = {name: value}
        def mock_get(name, default=None):
            return return_values.get(name, default)
        return mock_get

    def mock_is_windows(value):
        return_values = {True: value}
        def mock_is_windows():
            return return_values[True]
        return mock_is_windows


# Generated at 2022-06-23 19:08:19.948055
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = "./test_BaseConfigDict_load"
    os.makedirs(config_dir, exist_ok=True)
    config_path = config_dir + "/config.json"
    file_handler = open(config_path, "w")
    file_handler.write(json.dumps({"default_options": ["-v"]}))
    file_handler.close()
    config = BaseConfigDict(Path(config_path))
    config.load()
    assert config["default_options"] == ["-v"]
    os.remove(config_path)
    os.rmdir(config_dir)


# Generated at 2022-06-23 19:08:28.158829
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    class TestVars:
        PATH = ''
        HTTPIE_CONFIG_DIR = ''
        XDG_CONFIG_HOME = ''

    test_vars = TestVars()

    def get_env_var(key):
        if key == 'PATH':
            return test_vars.PATH

        if key == ENV_HTTPIE_CONFIG_DIR:
            return test_vars.HTTPIE_CONFIG_DIR

        if key == ENV_XDG_CONFIG_HOME:
            return test_vars.XDG_CONFIG_HOME

        return None

    def reset_vars():
        test_vars.HTTPIE_CONFIG_DIR = ''
        test_vars.XDG_CONFIG_HOME = ''
