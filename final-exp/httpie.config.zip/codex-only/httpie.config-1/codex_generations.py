

# Generated at 2022-06-23 18:58:20.935189
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    err1 = ConfigFileError('test')
    assert(str(err1) == 'test')



# Generated at 2022-06-23 18:58:24.180197
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    c = BaseConfigDict(Path('.config/httpie/test_is_new.json'))
    assert c.is_new()
    c['test_key'] = 'test_value'
    c.save()
    assert not c.is_new()
    c.delete()

# Generated at 2022-06-23 18:58:25.058487
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError()
    assert error != None

# Generated at 2022-06-23 18:58:27.496726
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():    
    config = Config()
    print(config.default_options)
    config.save(fail_silently=True)

if __name__ == "__main__":
    test_BaseConfigDict()

# Generated at 2022-06-23 18:58:38.074852
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import DEFAULT_CONFIG_DIR

    home_dir = Path.home()
    xdg_config_home_dir = os.environ.get(
        ENV_XDG_CONFIG_HOME,
        home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    )
    xdg_dir = Path(xdg_config_home_dir) / DEFAULT_CONFIG_DIRNAME
    xdg_dir.mkdir()

    test_file = xdg_dir / 'config.json'
    test_file.write_text('{"test": "test_string"}')
    config = Config(directory=xdg_dir)
    config.load()
    assert config.get('test') == 'test_string'
    config.delete()
    xd

# Generated at 2022-06-23 18:58:47.083406
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Test(BaseConfigDict):
        name = 'Test'
        helpurl = 'https://github.com/HTTPie/httpie'
        about = 'A Test'

    test = Test(Path('.') / 'test.json')

    assert test.is_new()

    test['test'] = 'test'
    test.save()

    assert not test.is_new()

    test.load()
    assert test.get('__meta__') is not None
    assert test.get('test') == 'test'

    assert test.get('test') is not None
    assert test.get('test1') is None

# Generated at 2022-06-23 18:58:52.655147
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    try:
        config = BaseConfigDict(path="/some/path")
        os.makedirs("/some/path/")
        os.mknod("/some/path/test.json")
        config.delete()
        assert not os.path.isfile("/some/path/test.json")
    finally:
        os.remove("/some/path/test.json")
        os.removedirs("/some/path/")

# Unit tests for method ensure_directory of class BaseConfigDict

# Generated at 2022-06-23 18:59:01.258861
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    import json
    import os

    config_dir = tempfile.TemporaryDirectory()
    path = os.path.join(config_dir.name, "config.json")
    config = BaseConfigDict(path)
    data = {
        '__meta__': {
            'httpie': '1.0.2'
        },
        'date': 'May 13, 2020'
    }
    config.update(data)
    config.save()


# Generated at 2022-06-23 18:59:02.745038
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    if not config.is_new():
        config.delete()

# Generated at 2022-06-23 18:59:05.082680
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    basedict = BaseConfigDict("test")
    assert basedict.path == "test"



# Generated at 2022-06-23 18:59:07.553528
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError("test")
    assert str(error) == "test"


# Generated at 2022-06-23 18:59:09.470411
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config("tests/fixtures/config")
    assert config.is_new() is True

# Generated at 2022-06-23 18:59:14.174084
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """Check if directories are created correctly"""
    config = Config()
    config.ensure_directory()
    assert config.path.parent.exists()
    assert config.path.parent.is_dir()
    assert config.path.parent.parent.exists()
    assert config.path.parent.parent.is_dir()


# Generated at 2022-06-23 18:59:21.019549
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Test whether the path of the config file is generated correctly
    os.environ[ENV_XDG_CONFIG_HOME] = 'test_path'
    config_dir = get_default_config_dir()
    config_dir.mkdir(mode=0o700, parents=True)
    config = Config(config_dir)
    assert config.directory == config_dir
    assert config.path == Path(os.environ[ENV_XDG_CONFIG_HOME]) / DEFAULT_CONFIG_DIRNAME / Config.FILENAME
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    
    # Test whether the attribute "update" can be assigned
    config_dir = config_dir / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-23 18:59:29.320920
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    from os import makedirs
    from os import path
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_base:
        # defaults to ~/.httpie

        # temp_base does not exist yet
        home_dir = Path.home()
        legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir(mode=0o700, parents=True)

        # ^ temp_base/.config exists, but temp_base/.config/httpie does not
        config = Config('~/.config')
        assert config.is_new()
        config.save()

        # ^ temp_base/.config/httpie exists
        assert not config.is_new()
        config.delete()

        # ^ temp_base

# Generated at 2022-06-23 18:59:36.867261
# Unit test for constructor of class Config
def test_Config():
	# if no directory is given, using default directory
	c1 = Config()
	assert c1.directory == DEFAULT_CONFIG_DIR	

	# given directory with string or Path as argument
	c2 = Config('test')
	assert c2.directory == Path('test')
	c3 = Config(Path('test'))	
	assert c3.directory == Path('test')

	# the default configuration is taken from DEFAULTS
	assert c1['default_options'] == c2['default_options'] == c3['default_options'] == c1.DEFAULTS['default_options']


# Generated at 2022-06-23 18:59:43.759485
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():

    class MockConfig(BaseConfigDict):
        """Mock class for testing"""
        def __init__(self):
            path = Path("test_mock-config.json")
            super().__init__(path)

    mock_config = MockConfig()
    assert mock_config.is_new() is True

    with mock_config.path.open('w') as f:
        json.dump({}, f)

    assert mock_config.is_new() is False

    mock_config.delete()
    assert mock_config.is_new() is True

# Generated at 2022-06-23 18:59:51.981652
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from py.path import local
    from httpie.config import Config

    with TemporaryDirectory() as temp_dir_path:
        temp_dir_path = local(temp_dir_path)
        config_dict = Config(directory=temp_dir_path)
        config_dict.ensure_directory()
        config_dict_path = temp_dir_path.join(Config.FILENAME)

        with config_dict_path.open('wb') as f:
            f.write(b'test')

        with config_dict_path.open('rb') as f:
            assert f.read() == b'test'

# Generated at 2022-06-23 18:59:53.000248
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()

# Generated at 2022-06-23 18:59:56.225452
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('/tmp/config')
    assert not test_dir.exists()
    test_obj = BaseConfigDict(path=test_dir)
    test_obj.ensure_directory()
    assert test_dir.exists()


# Generated at 2022-06-23 18:59:59.123000
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict("config.json")
    config.load()
    # No exception should be raised for this test to be passed


# Generated at 2022-06-23 19:00:00.820497
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test')
    except Exception as e:
        assert str(e) == 'test'

# Generated at 2022-06-23 19:00:04.156024
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path.cwd() / 'test_conf_dir'
    if not test_dir.exists():
        test_dir.mkdir(parents=True)

    dic = BaseConfigDict(test_dir / 'test.json')
    dic.ensure_directory()


# Generated at 2022-06-23 19:00:06.989310
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Test for constructor with no path
    path = "~/.httpie"
    d1 = BaseConfigDict(path)
    assert d1.path == path


# Generated at 2022-06-23 19:00:16.015547
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Legacy
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~'
    assert (
        get_default_config_dir() ==
        Path.home() / DEFAULT_CONFIG_DIRNAME
    )
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # XDG
    os.environ[ENV_XDG_CONFIG_HOME] = '~/test'
    assert (
        get_default_config_dir() ==
        Path.home() / 'test' / DEFAULT_CONFIG_DIRNAME
    )
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-23 19:00:23.714723
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir

    config_dir = get_default_config_dir()

    # User has HTTPIE_CONFIG_DIR
    os.environ['HTTPIE_CONFIG_DIR'] = '/user/config/dir'
    assert get_default_config_dir() == Path('/user/config/dir')
    del os.environ['HTTPIE_CONFIG_DIR']

    # User has XDG_CONFIG_HOME
    os.environ['XDG_CONFIG_HOME'] = '/user/config/dir'
    assert get_default_config_dir() == Path('/user/config/dir/httpie')
    del os.environ['XDG_CONFIG_HOME']


# Generated at 2022-06-23 19:00:24.697428
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert str(ConfigFileError)


# Generated at 2022-06-23 19:00:26.378313
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    a = BaseConfigDict("test.json")
    assert a.path == "test.json"


# Generated at 2022-06-23 19:00:32.804138
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('./test_dir')
    # 1. Create a directory and save something
    config = Config(directory=test_dir)
    config['a'] = 1
    config['b'] = 2
    config.save()

    # 2. Load the existing file
    config = Config(directory=test_dir)
    config.load()
    print(config)

    # 3. Remove the test directory
    shutil.rmtree(test_dir)

# Generated at 2022-06-23 19:00:36.775594
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Test building object of class Config
    config = Config()

    # Test building object with customized directory
    config = Config('./config')

    # Test building object with customized directory
    config = Config('/config')


# Generated at 2022-06-23 19:00:38.780579
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    t = BaseConfigDict(Path('./config.json'))
    assert t.is_new() == False

# Generated at 2022-06-23 19:00:46.346004
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict('test_data/config')
    config.load()
    assert config == {
        "__meta__": {
            "httpie": "0.9.9",
            "help": "https://github.com/jakubroztocil/httpie#config",
            "about": "https://github.com/jakubroztocil/httpie"
        },
        "default_options": [
            "--form",
            "--json"
        ]
    }

# Generated at 2022-06-23 19:00:48.283103
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path=Path("."))
    assert config.is_new()



# Generated at 2022-06-23 19:00:49.490822
# Unit test for constructor of class Config
def test_Config():
    assert Config.__init__ != None



# Generated at 2022-06-23 19:00:59.852653
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    from httpie.config import BaseConfigDict
    d = tempfile.TemporaryDirectory()
    p = Path(d.name) / "f"
    p.touch()
    assert p.exists()
    config = BaseConfigDict(p)
    config.load()
    assert config.is_new() == False
    config.save()
    config.load()
    assert config.is_new() == False
    config.delete()
    assert p.exists() == False
    config.load()
    assert config.is_new() == True
    config.save()
    assert p.exists() == True
    config.delete()
    d.cleanup()

# Generated at 2022-06-23 19:01:09.397777
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    
    try:
        dirpath = tempfile.mkdtemp()
        cfg_file = os.path.join(dirpath, 'config.json')
        cfg_json = '''
        {
            "default_options": ["--ignore-stdin", "--follow", "-b"]
        }
        '''

        with open(cfg_file, 'w') as f:
            f.write(cfg_json)
        config = Config(directory=dirpath)
        config.load()

        assert config.default_options == ['--ignore-stdin', '--follow', '-b']
    finally:
        os.rmdir(dirpath)


# Generated at 2022-06-23 19:01:14.135866
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    d = BaseConfigDict(Path('foo.json'))
    assert not d.path.exists()
    assert d.delete() is None
    d.path.touch()
    assert d.path.exists()
    assert d.delete() is None
    assert not d.path.exists()


# Generated at 2022-06-23 19:01:17.028199
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    d = BaseConfigDict(Path('test'))
    assert d.__class__.__name__ == 'BaseConfigDict'
    assert d.path == 'test'


# Generated at 2022-06-23 19:01:28.335953
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
        tempFile = Path('./temp_file.json')
        data = {'a': '1'}
        config_type = 'config'

        # Create a class simulating BaseConfigDict
        class MyConfig(BaseConfigDict):
            name = None
            helpurl = None
            about = None
        config = MyConfig(tempFile)
        config.update(data)

        # Set fail_silently to True and make sure IOError is not raised
        config.save(fail_silently=True)
        with tempFile.open() as f:
            assert json.load(f) == {'a': '1', '__meta__': {'httpie': __version__}}
        tempFile.unlink()

        # Set fail_silently to False and make sure IOError is raised
        tempFile.touch()
       

# Generated at 2022-06-23 19:01:31.986050
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    d = BaseConfigDict(Path('tests/data/config.json'))
    d.load()
    assert 'default' in d.keys()
    assert d.load() == d


# Generated at 2022-06-23 19:01:34.657468
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR/'test.json')
    config.ensure_directory()
    assert DEFAULT_CONFIG_DIR.exists()

# Generated at 2022-06-23 19:01:37.188581
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dict = BaseConfigDict(Path('test_file'))
    assert not config_dict.is_new()



# Generated at 2022-06-23 19:01:43.982283
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'helpurl'
        about = 'about'

    defaults_path = Path.cwd() / 'config.json'
    test_config = TestConfig(path=defaults_path)
    test_config.ensure_directory()
    test_config.save()

# Generated at 2022-06-23 19:01:52.846527
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from tempfile import mkdtemp
    
    print("\n=== test save() method of class BaseConfigDict ===")
    temp_dir = mkdtemp()
    save_file = os.path.join(temp_dir, 'config.json')
    print("\n--- create a test file --- ")
    # create a test file
    assert os.path.isdir(temp_dir) # assert directory exists
    with open(save_file, 'w') as f:
        f.write("{\"default_options\": []}")
    assert os.path.isfile(save_file) # assert file exists


    print("\n--- load the test file ---")
    # load the test file
    config = Config(temp_dir)
    config.load()


# Generated at 2022-06-23 19:02:02.398964
# Unit test for method load of class BaseConfigDict

# Generated at 2022-06-23 19:02:03.772429
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError('test message')


# Generated at 2022-06-23 19:02:10.017916
# Unit test for constructor of class Config
def test_Config():
    config = Config(DEFAULT_CONFIG_DIR)
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == DEFAULT_CONFIG_DIR / Config.FILENAME
    assert config.DEFAULTS == config.__dict__
    assert config.default_options == config.DEFAULTS['default_options']


# Generated at 2022-06-23 19:02:11.577289
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    assert config.ensure_directory() == None


# Generated at 2022-06-23 19:02:15.548139
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert isinstance(c, dict)
    assert c['default_options'] == []
    assert c['__meta__']['httpie'] == __version__
    assert c['__meta__']['help'] == 'https://github.com/jkbr/httpie#config'


# Generated at 2022-06-23 19:02:18.098926
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path("./test_config.json"))
    config.load()
    assert config['default_options'] == ["--verbose"]

# Generated at 2022-06-23 19:02:20.739042
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfe = ConfigFileError(str(1))
    assert type(cfe) == ConfigFileError
    assert str(cfe) == str(1)


# Generated at 2022-06-23 19:02:22.952191
# Unit test for constructor of class Config
def test_Config():
    directory = Path('~/.config/httpie')
    config = Config(directory)
    assert config.directory == Path(directory)


# Generated at 2022-06-23 19:02:25.614741
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError('Wrong path!')
    assert e.__str__() == 'Wrong path!'


# Generated at 2022-06-23 19:02:29.185073
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    dir = "test"
    test_path = Path(dir)
    config = BaseConfigDict(test_path)
    assert config.path == "test" and isinstance(config, BaseConfigDict) == True

test_BaseConfigDict()

# Generated at 2022-06-23 19:02:31.853482
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('Exception raised')
    except ConfigFileError as e:
        assert e.args == ('Exception raised',)

# Generated at 2022-06-23 19:02:39.412446
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    #create a text file
    test_file = Path('./test_config.txt')
    f = open('./test_config.txt', 'w')
    f.close()
    config_dict = BaseConfigDict(test_file)
    assert config_dict.path.exists()
    assert test_file.exists()

    #delete the text file
    config_dict.delete()
    assert not config_dict.path.exists()
    assert not test_file.exists()

# Generated at 2022-06-23 19:02:40.088992
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass

# Generated at 2022-06-23 19:02:47.720676
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path("tests_httpie_config")
    config_dir.mkdir(0o700, exist_ok=True)
    filename = "test_config.json"
    filepath = config_dir / filename
    if filepath.is_file():
        filepath.unlink()
    with open(filepath, 'w+') as f:
        json.dump({'__meta__': {'httpie': __version__}}, f)
    c = BaseConfigDict(filepath)
    assert c.is_new() is False
    c.delete()
    assert c.is_new() is True

if __name__ == "__main__":
    test_BaseConfigDict_delete()

# Generated at 2022-06-23 19:02:58.307766
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a config path
    config_path = Path(os.path.expandvars('%APPDATA%')) / 'httpie_test' / 'config.json'

    # create a config dictionary and initialize it as a test config
    config_dict = BaseConfigDict(config_path)
    config_dict['a'] = 1
    config_dict['b'] = 2

    # ensure the config directory exists
    config_dict.ensure_directory()

    # save the config file
    config_dict.save()

    # check the existence of config file and directory
    assert config_path.exists()
    assert config_path.parent.exists()

    # remove the config file and directory
    config_path.parent.rmdir()
    config_path.unlink()

# Generated at 2022-06-23 19:03:05.922721
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # 1. test default_config_dir
    config = Config()
    config.ensure_directory()
    assert config.path.parent.exists()

    # 2. test custom_config_dir
    custom_dir = '/tmp/httpie'
    config = Config(custom_dir)
    config.ensure_directory()
    assert config.path.parent.exists()
    assert config.directory == Path(custom_dir)

    # remove file
    config.path.parent.rmdir()

# Generated at 2022-06-23 19:03:14.513384
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test/')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    try:
        # Delete config_dir and its contents recursively
        shutil.rmtree(config_dir)
    except FileNotFoundError:
        pass
    assert not config_dir.exists(), 'Directory to be deleted already exists'
    assert not config_file.exists(), 'File to be deleted already exists'
    config.ensure_directory()
    assert config_dir.is_dir(), 'Config directory was not created'
    assert config_file.is_file(), 'Config file was not created'

# Generated at 2022-06-23 19:03:17.097581
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('welcome to httpie!')
    except Exception as e:
        assert e.args[0] == 'welcome to httpie!'

# Generated at 2022-06-23 19:03:27.306185
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, config_dir):
            super().__init__(path=config_dir)
    test_config_dir = Path('test_dir')
    config_dict = TestConfigDict(test_config_dir)

    # test when file exists
    test_config_dir.mkdir(parents=True, exist_ok=True)
    with open('test_dir/config.json', 'w') as f:
        f.write('{}')
    config_dict.load()

    # test when file doesn't exist
    try:
        os.remove('test_dir/config.json')
    except FileNotFoundError:
        pass

    config_dict.load()


# Generated at 2022-06-23 19:03:39.012499
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # use default:
    assert str(DEFAULT_CONFIG_DIR) == "~/.config/httpie"

    # set env HTTPIE_CONFIG_DIR:
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp/user-config"
    assert str(DEFAULT_CONFIG_DIR) == "/tmp/user-config"

    # set env XDG_CONFIG_HOME:
    os.environ[ENV_XDG_CONFIG_HOME] = 'xdg_config_home'
    assert str(DEFAULT_CONFIG_DIR) == "xdg_config_home/httpie"

    # set env HTTPIE_CONFIG_DIR and XDG_CONFIG_HOME:

# Generated at 2022-06-23 19:03:40.518092
# Unit test for constructor of class Config
def test_Config():
    return Config(directory = DEFAULT_CONFIG_DIR)


# Generated at 2022-06-23 19:03:47.444958
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Path is read-only
    assert os.path.exists(os.path.expanduser('~')+'/.config') == True
    config = Config()
    config.ensure_directory()
    assert os.path.exists(os.path.expanduser('~')+'/.config/httpie') == True
    assert os.path.exists(os.path.expanduser('~')+'/.config/httpie/config.json') == True



# Generated at 2022-06-23 19:03:55.193791
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dir = os.getcwd()
    c = BaseConfigDict(Path(dir+'/config.json'))

    # Loading a file that does not exist
    assert c.load() == None

    # Loading an invalid file
    with open('config.json', 'w') as f:
        f.write('foo') # This is invalid json
    with pytest.raises(ConfigFileError):
        c.load()

    # Loading a valid file
    with open('config.json', 'w') as f:
        f.write('{"foo": "bar"}')
    assert c.load() == None
    assert c.get('foo') == "bar"


# Generated at 2022-06-23 19:03:57.873422
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.load()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()



# Generated at 2022-06-23 19:03:59.604847
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.default_options == []

# Generated at 2022-06-23 19:04:02.141230
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict('/home/jhegedus/.httpie/config.json')
    assert config['__meta__']['help'] == 'https://httpie.org/doc'

# Generated at 2022-06-23 19:04:06.468873
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path='/home/ftdy/local/httpie-0.9.3/httpie/__init__.py')
    assert config.is_new() == True

    config = BaseConfigDict(path='./__init__.py')
    assert config.is_new() == False

# Generated at 2022-06-23 19:04:08.307952
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfErr = ConfigFileError("Test")
    assert cfErr.__str__() == "Test"

# Generated at 2022-06-23 19:04:19.344632
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
  from pathlib import Path
  from os import environ
  from os import makedirs

  try:
    environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('/tmp/env_httpie_config_dir'))
    assert get_default_config_dir() == Path('/tmp/env_httpie_config_dir')

    makedirs(DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)
    assert get_default_config_dir() == DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
  finally:
    # Clear the environment variable
    environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    # Delete directory if exist
    if DEFAULT_RELATIVE_LEGACY_CONFIG_DIR.exists():
      DEFAULT_RELATIVE_

# Generated at 2022-06-23 19:04:20.342338
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config is not None

# Generated at 2022-06-23 19:04:29.557834
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = {"arg": "true"}

    with tempfile.TemporaryDirectory() as tmpdirname:
        with open("test_save.json", 'w') as fp:
            json.dump(config, fp)

        with open("test_save.json", 'r') as fp:
            data = json.load(fp)

        #Assert content is ok
        assert data == config

        try:
            os.remove("test_save.json")
        except OSError as e:
            print("Error: {}: {!s}".format(e.filename, e.strerror))


# Generated at 2022-06-23 19:04:30.905281
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    err = ConfigFileError('Something went wrong')
    print(err)


# Generated at 2022-06-23 19:04:39.225312
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    tmp_dir = Path('.tmp/config')
    tmp_dir.mkdir(parents=True, exist_ok=True)
    filename = tmp_dir / 'config.txt'
    config_dict = BaseConfigDict(path=filename)

    try:
        config_dict.ensure_directory()
        assert True
    except:
        print('Error: cannot create directory: ', tmp_dir)
        assert False

    try:
        config_dict.load()
        assert True
    except:
        print('Error: file not exist: ', filename)
        assert False

    try:
        config_dict.save()
        assert True
    except:
        print('Error: cannot write to file: ', filename)
        assert False

    try:
        config_dict.delete()
        assert True
    except:
        print

# Generated at 2022-06-23 19:04:42.305908
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        f = open('asdf.txt', 'r')
    except IOError as error:
        raise ConfigFileError('cannot read asdf file: %s' % error)

ConfigFileError()

# Generated at 2022-06-23 19:04:44.739123
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config= Config()
    print(config['default_options'])
    assert(config['default_options'] == [])

test_BaseConfigDict_load()

# Generated at 2022-06-23 19:04:48.008847
# Unit test for constructor of class Config
def test_Config():
    try:
        config_dir = Path('~') / '.httpie'
        Config(config_dir)
    except ConfigFileError as e:
        assert e.args[0].startswith('cannot read config file')




# Generated at 2022-06-23 19:04:54.108693
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/test/httpie_config_dir"
    os.environ[ENV_XDG_CONFIG_HOME] = "/test/xdg_config_home"
    assert get_default_config_dir() == Path("/test/httpie_config_dir")
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    assert get_default_config_dir() == Path("/test/xdg_config_home/httpie")
    os.environ.pop(ENV_XDG_CONFIG_HOME)

# Generated at 2022-06-23 19:04:55.112737
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(ConfigFileError):
        raise ConfigFileError("throw ConfigFileError")


# Generated at 2022-06-23 19:05:02.673715
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(Path.home() / '.config' / 'httpie')

    if is_windows:
        assert str(get_default_config_dir()) == str(Path(os.path.expandvars('%APPDATA%')) / 'httpie')
    else:
        assert str(get_default_config_dir()) == str(Path.home() / '.config' / 'httpie')

# Generated at 2022-06-23 19:05:05.288467
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-23 19:05:12.270154
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_directory_name = "test_directory"
    temp_directory = Path(temp_directory_name)
    try:
        temp_directory.mkdir()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    temp_filename = "test_file.txt"
    temp_path = temp_directory / temp_filename
    b = BaseConfigDict(path=temp_path)
    b.ensure_directory()
    if os.path.exists(temp_directory_name):
        print("directory created")
    else:
        print("directory not created")



# Generated at 2022-06-23 19:05:18.860088
# Unit test for constructor of class Config
def test_Config():
    cfg = Config()
    assert cfg['default_options'] == [], "Should have expected default"
    assert cfg.default_options == [], "Should have expected default"
    assert cfg.directory == DEFAULT_CONFIG_DIR, "Should have expected default"
    assert cfg.path == DEFAULT_CONFIG_DIR / "config.json", "Should have expected default"


# Generated at 2022-06-23 19:05:31.298709
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as d:
        path = Path(d) / 'config.json'
        config = BaseConfigDict(path)
        config.save()
        file_content = path.read_text()
        assert file_content == '{}'

        config = BaseConfigDict(path)
        config.update({'first': 1})
        config.save()
        file_content = path.read_text()
        assert file_content == '{"first": 1}'

        config = BaseConfigDict(path)
        config.update({'second': 2})
        config.save()
        file_content = path.read_text()
        assert file_content == '{"first": 1, "second": 2}'


# Generated at 2022-06-23 19:05:33.320848
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert config.path.exists() == False


# Generated at 2022-06-23 19:05:39.726482
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dir = Path('/home/xx/')
    bcd = BaseConfigDict(config_dir / 'test.json')
    assert bcd.path.name == 'test.json'
    assert bcd.path.parent.name == 'home'
    assert bcd.name is None and bcd.helpurl is None and bcd.about is None and len(bcd.items()) == 0



# Generated at 2022-06-23 19:05:42.881065
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = str(DEFAULT_CONFIG_DIR) + "/" + Config.FILENAME
    config = Config(DEFAULT_CONFIG_DIR)
    config.delete()
    assert path not in os.listdir(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-23 19:05:48.545649
# Unit test for constructor of class ConfigFileError

# Generated at 2022-06-23 19:05:51.242888
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    exc = ConfigFileError("Test")
    assert str(exc) == "Test"


# Generated at 2022-06-23 19:05:56.683761
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dir_name = "test_dir"
    file_path = Path(dir_name) / "test_file.json"
    class TestConfigDict(BaseConfigDict):
        name = 'test_config'
    c = TestConfigDict(file_path)
    c.ensure_directory()
    assert file_path.parent.exists()
    file_path.parent.rmdir()


# Generated at 2022-06-23 19:05:58.457347
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_path = Path('./test')
    config = BaseConfigDict(config_path)
    assert config.path == Path('./test')

# Generated at 2022-06-23 19:06:10.144958
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmp_dir = Path('tmp_dir')
    tmp_path = tmp_dir / 'test_file.json'
    test_dic = BaseConfigDict(tmp_path)
    test_dic.ensure_directory()
    assert not tmp_dir.exists()
    assert not tmp_path.exists()
    test_dic['test_key'] = 'test_value'
    test_dic.save()
    assert tmp_dir.exists()
    assert tmp_path.exists()
    tmp_dir.rmdir()

    tmp_dir = Path('tmp_dir')
    tmp_dir.mkdir()
    tmp_path = tmp_dir / 'test_file.json'
    test_dic = BaseConfigDict(tmp_path)
    test_dic['test_key']

# Generated at 2022-06-23 19:06:13.096682
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        ConfigFileError()
    except TypeError:
        print('Pass the unit test for constructor of class ConfigFileError')


# Generated at 2022-06-23 19:06:24.482393
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test with a new directory
    class TestConfigDict(BaseConfigDict):
        pass
        
    config = TestConfigDict(Path('./test_dir/test_config.json'))
    assert not os.path.exists('./test_dir')
    config.ensure_directory()
    assert os.path.exists('./test_dir')
    os.rmdir('./test_dir')

    # Test with an existing directory
    class TestConfigDict(BaseConfigDict):
        pass

    config = TestConfigDict(Path('./test_dir/test_config.json'))
    os.makedirs('./test_dir')
    config.ensure_directory()
    assert os.path.exists('./test_dir')
    os.rmdir

# Generated at 2022-06-23 19:06:27.773625
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    # Check if the config file is present
    assert(config.path.exists())
    # Delete the file
    config.delete()
    # Check if config file is deleted
    assert(not config.path.exists())

# Generated at 2022-06-23 19:06:30.549987
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('./test_config/config.json')
    config['test_key'] = 'test_value'
    config.save()
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-23 19:06:36.454266
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # create a test base config dict
    test_config = BaseConfigDict(Path("../test/.httpie/config.json"))
    # delete the file
    test_config.delete()
    # assert that the file was deleted
    assert not test_config.path.exists()


# Generated at 2022-06-23 19:06:39.222945
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("foo")
    except ConfigFileError as e:
        assert e.args[0] == "foo"



# Generated at 2022-06-23 19:06:44.206577
# Unit test for constructor of class Config
def test_Config():
    default_values = {
        'default_options': []
    }
    test_Config = Config()
    assert test_Config['default_options'] == default_values['default_options']
    assert test_Config.directory == DEFAULT_CONFIG_DIR
    assert test_Config.path == DEFAULT_CONFIG_DIR / 'config.json'


# Generated at 2022-06-23 19:06:48.955274
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_dir = os.path.join(tempfile.gettempdir(), 'httpie')
    os.mkdir(temp_dir)
    assert os.path.exists(temp_dir)
    path = os.path.join(temp_dir, '.config')
    assert not os.path.exists(path)
    test_config_dir = BaseConfigDict(path)
    test_config_dir.ensure_directory()
    assert os.path.exists(path)

# Generated at 2022-06-23 19:06:53.031482
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config['default_options'] == []


# Generated at 2022-06-23 19:06:54.728481
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == DEFAULT_CONFIG_DIR / 'config.json'
    assert config.default_options == []


# Generated at 2022-06-23 19:06:58.960894
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    configPath = Path("./test/test.json")
    config = BaseConfigDict(configPath)
    config["key"] = "value"
    config.save(fail_silently=False)
    assert configPath.exists()
    configPath.unlink()

# Generated at 2022-06-23 19:07:01.530890
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    for test_case in ['hello!', '!world', '!world!']:
        try:
            raise ConfigFileError(test_case)
        except ConfigFileError as e:
            assert test_case in str(e)

# Generated at 2022-06-23 19:07:07.121593
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    """Should fail for invalid json"""
    config_filename = 'config_test.json'
    config_content = "invalid json data {"
    config_path = Path(config_filename)
    config_path.write_text(config_content)
    config = BaseConfigDict(config_path)
    with pytest.raises(ConfigFileError):
        config.load()
    config_path.unlink()

# Generated at 2022-06-23 19:07:09.011045
# Unit test for constructor of class Config
def test_Config():
	config_obj = Config()
	assert config_obj.directory == DEFAULT_CONFIG_DIR


# Generated at 2022-06-23 19:07:12.501187
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import sys
    import platform
    import httpie
    import webbrowser
    p = httpie.get_default_config_dir()
    if os.name == 'nt':
        print("test_get_default_config_dir: pass")
    else:
        print("test_get_default_config_dir: fail")


# Generated at 2022-06-23 19:07:14.871160
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    fpath = Path('test_path')
    config_dict = BaseConfigDict(fpath)
    fpath.touch()
    config_dict.delete()
    assert not fpath.exists()


# Generated at 2022-06-23 19:07:16.764927
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/dbg/.config/httpie')

# Generated at 2022-06-23 19:07:20.933853
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / Config.FILENAME
    config_dict = BaseConfigDict(config_path)
    assert True == config_dict.load()


# Generated at 2022-06-23 19:07:29.717407
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Test to determine if method delete() deletes a file
    """
    # set up a fake config file
    d = DEFAULT_CONFIG_DIR
    if d.exists():
        if (d / 'config.json').exists():
            (d / 'config.json').unlink()
        else:
            d.rmdir()
    d.mkdir()
    (d / 'config.json').touch()

    # ensure that the file was created
    assert (d / 'config.json').exists()
    
    config = Config()

    # ensure the file exists before being deleted, then ensure it doesn't exist after
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

    # clean up after test

# Generated at 2022-06-23 19:07:34.567004
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    temp_file = tempfile.NamedTemporaryFile('w+t')
    temp_file.write('{"key": "value"}')
    temp_file.flush()
    temp_file_path = Path(temp_file.name)

    class MyConfigDict(BaseConfigDict):
        pass

    config_dict = MyConfigDict(path=temp_file_path)
    config_dict.load()

    assert config_dict == {'key': 'value'}

    temp_file.close()


# Generated at 2022-06-23 19:07:46.358352
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    test_config = BaseConfigDict(path=Path('test.json'))
    test_config['name'] = 'test1'
    test_config['url'] = 'test2'
    test_config.save()
    try:
        assert Path('test.json').is_file()
    except AssertionError:
        raise AssertionError('Test failed because file test.json does not exist.')
    with open('test.json', 'rb') as f:
        data=json.loads(f.read())
        assert data['name'] == 'test1', 'test.json does not have filename \'test1\''
        assert data['url'] == 'test2', 'test.json does not have url \'test2\''
    os.remove('test.json')



# Generated at 2022-06-23 19:07:49.289136
# Unit test for constructor of class Config
def test_Config():
    directory = Path('/')
    config = Config(directory=directory)
    assert config == {'default_options': []}
    assert config.directory == directory
    assert config.path == Path('/config.json')



# Generated at 2022-06-23 19:07:52.267674
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    class BaseConfigDict2(BaseConfigDict):
        def __init__(self):
            super().__init__(path='./config.json')

    bcd = BaseConfigDict2()
    bcd.load()



# Generated at 2022-06-23 19:07:56.601007
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        try:
            cfg = Config(d)
            assert cfg['default_options'] == []
        except:
            assert False

if __name__ == '__main__':
    test_BaseConfigDict()

# Generated at 2022-06-23 19:07:58.309163
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError('error')
    assert str(e) == 'error'



# Generated at 2022-06-23 19:08:05.997436
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    import io

    class TestBaseConfigDict(BaseConfigDict):
        pass

    mydata = dict(
        a=1234,
        b='some_string',
        test=json.loads('{"foo": "bar", "baz": ["one", 2, "three"]}')
    )
    fd, jsonfile = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        json.dump(mydata, f)
    myconfig = TestBaseConfigDict(path=jsonfile)
    myconfig.load()

    assert myconfig == mydata
    os.remove(jsonfile)


# Generated at 2022-06-23 19:08:15.173925
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    assert get_default_config_dir() == \
        os.getenv('HOME') + '/.config/httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == '/tmp/httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == '/tmp'

# Generated at 2022-06-23 19:08:22.830873
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('/tmp/test_BaseConfigDict_save')
    old_content = None
    if path.exists():
        old_content = path.read_text()
    d = BaseConfigDict(path)
    d['a'] = 'b'
    d.save()
    assert 'b' == d['a']
    assert d['a'] == json.loads(path.read_text())['a']
    if old_content:
        path.write_text(old_content)
    else:
        path.unlink()