

# Generated at 2022-06-23 18:58:21.043581
# Unit test for constructor of class Config
def test_Config():
    DEFAULT_CONFIG_DIR = get_default_config_dir()
    x = Config(directory = DEFAULT_CONFIG_DIR)

if __name__ == "__main__":
    test_Config()

# Generated at 2022-06-23 18:58:22.284276
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError()
    assert error.args == ('',)

# Generated at 2022-06-23 18:58:30.321198
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # This test only runs on Unix.
    if is_windows:
        return

    # Setup
    import tempfile
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    # Run the function
    result = get_default_config_dir()

    # Assert
    expected = tmp_dir_path / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    assert result == expected, result

    # Teardown
    tmp_dir.cleanup()

    # Should work even if the directory exists.
    expected.mkdir()
    result = get_default_config_dir()
    assert result == expected, result

    # Revert to the default value
    del os.environ[ENV_XDG_CONFIG_HOME]
    expected = Path

# Generated at 2022-06-23 18:58:38.116078
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Test case: is new
    new_config = "/tmp/xxx"
    # Create a new object of BaseConfigDict,
    # the object is not yet in the file system
    test_obj = BaseConfigDict(path=new_config)
    assert test_obj.is_new()
    # Test case: is not new
    # Create a new object of BaseConfigDict,
    # the object is in the file system
    config_dir = get_default_config_dir()
    test_obj = BaseConfigDict(path=config_dir / Config.FILENAME)
    assert not test_obj.is_new()



# Generated at 2022-06-23 18:58:49.168829
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # GIVEN
    json_string = json.dumps(
        obj={
            '__meta__': {
                'httpie': __version__
            },
            'default_options': []
        },
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )

    # In order to test the invalid edge case, we need to mock the file system
    # http://mock.readthedocs.io/en/latest/mock.html#mock-open
    # First, we need to open a file
    # Second, we need to use a with statement
    # Third, we need to mock the readline function of the object returned by open
    # Reference: https://stackoverflow.com/questions/19243875/mocking-a-file-with-m

# Generated at 2022-06-23 18:58:53.604949
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    try:
        assert BaseConfigDict(Path("test_cases_file/test_is_new.json")).is_new()
        assert not BaseConfigDict(Path("test_cases_file/test_is_new.json")).is_new()
    except:
        BaseConfigDict(Path("test_cases_file/test_is_new.json")).delete()


# Generated at 2022-06-23 18:58:59.521104
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class BaseConfigDict_test(BaseConfigDict):
        def __init__(self):
            self.path = Path('/tmp/') / 'test.json'
    tmp = BaseConfigDict_test()
    tmp.save()
    assert Path('/tmp/') / 'test.json' in os.listdir('/tmp')
    tmp.delete()
    assert Path('/tmp/') / 'test.json' not in os.listdir('/tmp')



# Generated at 2022-06-23 18:59:02.009565
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert 'ConfigFileError' in str(ConfigFileError('error test'))


# Generated at 2022-06-23 18:59:11.590591
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config = BaseConfigDict(Path('test.json'))
    if not test_config.is_new():
        temp = test_config.copy()
        test_config.clear()
        test_config.update(temp)
        test_config['__meta__']['http'] = '0.3.3'
        test_config.save()
    else:
        test_config['__meta__'] = {'http': '0.3.3'}
        test_config.save()

    test_config.load()
    assert test_config == {'__meta__': {'http': '0.3.3'}}



# Generated at 2022-06-23 18:59:18.648446
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # file doesn't exist yet
    path = Path('/tmp/test')
    configdict = BaseConfigDict(path)
    assert(configdict.path == path)
    assert(configdict.is_new())

    # file exists
    path = Path.cwd() / 'httpie' / '__init__.py'
    configdict = BaseConfigDict(path)
    assert(not configdict.is_new())


# Generated at 2022-06-23 18:59:21.179318
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():

    config = Config()
    is_new = config.is_new()
    assert is_new == True
test_BaseConfigDict_is_new()


# Generated at 2022-06-23 18:59:28.028187
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file_name = 'test.txt'
    filepath = Path(file_name)
    with open(file_name,'w') as f:
        f.write('Incomprehensibilities')

    dict_1 = BaseConfigDict(filepath)
    dict_1.ensure_directory()
    dict_1.update({'name':'Jiaxing He'})
    dict_1.save()

    dict_2 = BaseConfigDict(filepath)
    dict_2.load()
    assert dict_2.get('name') == 'Jiaxing He'

    dict_1.delete()

# Generated at 2022-06-23 18:59:33.007371
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TestConfig(BaseConfigDict):
        pass

    config = TestConfig(path=os.path.dirname(__file__) + '/test_is_new')

    assert config.is_new()


if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-23 18:59:44.056411
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    except KeyError:
        pass

    try:
        os.environ.pop(ENV_XDG_CONFIG_HOME)
    except KeyError:
        pass

    assert get_default_config_dir() == Path.home() / '.config' / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_XDG_CONFIG_HOME] = '/var/lib/xdg'
    assert get_default_config_dir() == Path('/var/lib/xdg') / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')



# Generated at 2022-06-23 18:59:46.519466
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    tst = BaseConfigDict(Path('a.json'))
    tst.delete()
    assert 1 == 1


# Generated at 2022-06-23 18:59:55.142414
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a config file for testing
    config_path = DEFAULT_CONFIG_DIR / Config.FILENAME
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.mkdir(mode=0o700)
    # write a config file with illegal data
    with open(config_path,"w") as f:
        json_string = '{"a":1}'
        f.write(json_string + '\n')
    # load file and should raise exception
    config = Config()
    try:
        config.load()
        print("failed")
    except ConfigFileError as e:
        print("success")
    print("=============================")
    # write a config file with legal data

# Generated at 2022-06-23 19:00:00.777885
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        shutil.rmtree("/tmp/test_httpie_config")
    except Exception:
        pass
    default_config_dir = BaseConfigDict(path="/tmp/httpie/config.json")
    default_config_dir.ensure_directory()
    assert "/tmp/httpie" in os.listdir("/tmp")

# Generated at 2022-06-23 19:00:04.915150
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Unit test for function get_default_config_dir
    """
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == \
            Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-23 19:00:06.797484
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError("something wrong")
    assert str(e)=="something wrong"


# Generated at 2022-06-23 19:00:10.170203
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict(Path('~/.config/httpie/config.json'))
    assert config_dict.path == Path(os.path.expanduser('~/.config/httpie/config.json'))

# Generated at 2022-06-23 19:00:19.191559
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Ensure user's home directory is set
    assert Path.home()

    # No env variable set
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Env variable empty
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Env variable set to something
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/should/be/returned'

# Generated at 2022-06-23 19:00:20.783206
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert path == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-23 19:00:30.586686
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test case 1: ~/.config/httpie
    directory = Path(os.environ.get(ENV_XDG_CONFIG_HOME, Path.home() / '.config')) / 'httpie'
    if not directory.exists():
        directory.mkdir(parents=True)

    # Test case 2: ~/.httpie
    directory = Path(os.environ.get(ENV_XDG_CONFIG_HOME, Path.home())) / 'httpie'
    if not directory.exists():
        directory.mkdir(parents=True)

    # Test case 3: Windows
    directory = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    if not directory.exists():
        directory.mkdir(parents=True)

# Generated at 2022-06-23 19:00:32.818444
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert isinstance(config, Config)
    assert isinstance(config['default_options'], list)


# Generated at 2022-06-23 19:00:41.072353
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import unittest

    import shutil
    import tempfile

    from httpie.config import BaseConfigDict

    class BaseConfigDictTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_is_new(self):
            config_file_path = Path(self.temp_dir) / 'config.json'
            config_dict = BaseConfigDict(path=config_file_path)
            config_dict.load()
            self.assertTrue(config_dict.is_new())
            config_dict.save()
            self.assertFalse(config_dict.is_new())

    unittest.main()

#

# Generated at 2022-06-23 19:00:48.767530
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    fake_xdg_config_home = 'foo'
    fake_httpie_config_dir = 'bar'

    os.environ[ENV_XDG_CONFIG_HOME] = fake_xdg_config_home

    # Set XDG_CONFIG_HOME and HTTPIE_CONFIG_DIR,
    # and expect XDG_CONFIG_HOME to win.
    os.environ[ENV_HTTPIE_CONFIG_DIR] = fake_httpie_config_dir
    assert get_default_config_dir() == fake_xdg_config_home / DEFAULT_CONFIG_DIRNAME

    # Unset HTTPIE_CONFIG_DIR to test the rest of this function
    # (which is what get_default_config_dir does in the real world).

# Generated at 2022-06-23 19:01:00.546642
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from os import remove, rename
    from tempfile import mkstemp


# Generated at 2022-06-23 19:01:03.041458
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    # Path.exists() returns True if the file at the given path exists.
    assert config.is_new() == True
    # When the file is not exist, os.path.exists(path) returns False
    # When the file is exist, os.path.exists(path) returns True


# Generated at 2022-06-23 19:01:13.109633
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # if not exist
    bcd = BaseConfigDict('~/.httpie/config')
    assert bcd.path == "/Users/mmb/.httpie/config"
    assert bcd.is_new() == True
    assert bcd.ensure_directory() == None

    # if exist
    bcd1 = BaseConfigDict('~/.httpie/config')
    assert bcd1.path == "/Users/mmb/.httpie/config"
    assert bcd1.is_new() == True
    assert bcd1.ensure_directory() == None
    with open('~/.httpie/config', 'w') as f:
        f.write('{"test": "1"}')
    bcd1.load()
    assert bcd1["test"] == "1"

    # if not exist
    bcd_

# Generated at 2022-06-23 19:01:15.030971
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert(BaseConfigDict('/path/to/file'))

# Generated at 2022-06-23 19:01:23.049837
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # set up
    test_dir = Path('tests/httpie/')
    test_dir.mkdir(mode=0o750, parents=True, exist_ok=True)
    path = test_dir / 'test_config.json'

    # tear down
    try:
        with path.open('wt') as f:
            f.write('some text')

        # test
        base_config = BaseConfigDict(path)
        base_config.ensure_directory()
        assert path.parent.exists()
    finally:
        shutil.rmtree(test_dir)


# Generated at 2022-06-23 19:01:28.179858
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        baseconfigdict = BaseConfigDict(Path('test-BaseConfigDict-load.json'))
        baseconfigdict.load()
    except ConfigFileError as e:
        print('Error:', e)
    else:
        print(baseconfigdict)



# Generated at 2022-06-23 19:01:30.572791
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    d = BaseConfigDict(Path('~/.httpie/config.json'))
    d.ensure_directory()

# Generated at 2022-06-23 19:01:38.460829
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME / 'config.json'
    config = Config(config_path)
    with config_path.open('wt') as f:
        f.write("""{
        "test": 1,
        "__meta__": {
            "httpie": "1.0.1"
        },
        "default_options": [
            "--form",
            "--auth="
        ]
    }
    """)
    config.load()
    assert config['test'] == 1

# Generated at 2022-06-23 19:01:50.093943
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Test 1: Create an empty file config.json
    # Result 1: is_new() should return False
    temp_dir = tempfile.mkdtemp()
    path = Path(temp_dir) / 'config.json'
    config = Config(path)
    path.touch()
    assert config.is_new() is False
    shutil.rmtree(temp_dir)

    # Test 2: Create directory with no config.json
    # Result 2: is_new() should return True
    temp_dir = tempfile.mkdtemp()
    path = Path(temp_dir) / 'config.json'
    config = Config(path)
    assert config.is_new() is True
    shutil.rmtree(temp_dir)

    # Test 3: Create an empty file config.json with an empty directory as
   

# Generated at 2022-06-23 19:02:00.274718
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    path = tempfile.mkdtemp()
    # create files to simulate an allowed operation
    path_allow = os.path.join(path, "httpie")
    os.makedirs(path_allow)
    # create files to simulate a forbiden operation
    path_forbidden = os.path.join(path, "httpie/forbidden")
    os.makedirs(path_forbidden)
    os.chmod(path_allow, 0o444)
    # test allow
    assert os.path.isdir(path_allow)
    assert os.access(path_allow, os.W_OK)
    # test forbidden
    assert os.path.isdir(path_forbidden)
    assert not os.access(path_forbidden, os.W_OK)

# Generated at 2022-06-23 19:02:02.319631
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path("config.json")
    config = BaseConfigDict(path)
    assert config.path == path


# Generated at 2022-06-23 19:02:06.380466
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path().cwd() / 'test.json'
    base = BaseConfigDict(path=path)
    base.ensure_directory()
    assert path.parent.chmod(mode=0o700)

# Generated at 2022-06-23 19:02:09.537317
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        e = ConfigFileError("dir")
        return True
    except ConfigFileError:
        return False


# Generated at 2022-06-23 19:02:17.250959
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test data
    test_dict = {'test1': 'test2'}

    # Create BaseConfigDict
    test_config_dir = Path('./test')
    test_path = test_config_dir / 'config.json'
    test_config = BaseConfigDict(test_path)

    # Create test file
    test_config_dir.mkdir(parents=True, exist_ok=True)
    with test_path.open('wt') as f:
        json.dump(test_dict, f)

    # Call method load and verify result
    test_config.load()
    assert test_dict == test_config



# Generated at 2022-06-23 19:02:23.652951
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dirname = '.httpie'
    pathname = '.httpie/config.json'

    try:
        os.mkdir(dirname)
        if os.path.exists(pathname):
            os.remove(pathname)

        config = Config()
        config.save()
        assert os.path.exists(pathname)

    except IOError as e:
        if e.errno != errno.ENOENT:
            raise

    finally:
        if os.path.exists(pathname):
            os.remove(pathname)
        if os.path.exists(dirname):
            os.rmdir(dirname)


# Generated at 2022-06-23 19:02:34.886121
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tempdir:
        path = Path(tempdir) / 'x.json'
        path.parent.mkdir(mode=0o700, parents=True)
        path.write_text('{"a": 42}')
        conf = BaseConfigDict(path)
        conf.load()
        assert conf['a'] == 42
        path.write_text('{"a": 43}')
        conf.load()
        assert conf['a'] == 43
        path.write_text('invalid json')
        try:
            conf.load()
        except ConfigFileError as e:
            assert 'invalid baseconfigdict file' in e.args[0]
        path.unlink()

# Generated at 2022-06-23 19:02:36.555130
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-23 19:02:44.165528
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/test_dict.json'))
    assert config_dict.path.exists()
    config_dict['name'] = 'yunwei'
    assert config_dict['name'] == 'yunwei'
    config_dict.ensure_directory()
    assert config_dict.path.exists()
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.load()
    assert config_dict['name'] == 'yunwei'


# Generated at 2022-06-23 19:02:47.144910
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class FooConfig(BaseConfigDict):
        pass

    path = Path('~/.config/httpie/foo.json')
    config = FooConfig(path)
    assert config.path == Path('~/.config/httpie/foo.json')



# Generated at 2022-06-23 19:02:50.471681
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_path = "/path/to/config"
    new_config = BaseConfigDict(config_path)
    assert new_config.path == config_path


# Generated at 2022-06-23 19:02:51.578613
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError('Error')



# Generated at 2022-06-23 19:02:54.942459
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class ConfigDict(BaseConfigDict):
        FILENAME = 'config.json'

    c = ConfigDict(DEFAULT_CONFIG_DIR / 'config.json')
    c.load()
    assert isinstance(c, dict)



# Generated at 2022-06-23 19:03:06.411684
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test explicit dir
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test existing legacy config dir
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # Test Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test XDG config home followed by default

# Generated at 2022-06-23 19:03:08.882073
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert type(BaseConfigDict(path=Path.home() / DEFAULT_CONFIG_DIRNAME / 'config.json')) == BaseConfigDict
    assert type(Config()) == BaseConfigDict

# Generated at 2022-06-23 19:03:09.390522
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert True

# Generated at 2022-06-23 19:03:11.568389
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    b = BaseConfigDict('config.json')
    assert b.is_new() == True


# Generated at 2022-06-23 19:03:17.097680
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    BaseConfigDict_example = BaseConfigDict('')
    if BaseConfigDict_example.delete():
        print('Unit test for method delete of class BaseConfigDict succeed!')
    else:
        print('Unit test for method delete of class BaseConfigDict failed!')


if __name__ == '__main__':
    test_BaseConfigDict_delete()

# Generated at 2022-06-23 19:03:26.564221
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dirpath = "{0}/foo/bar".format(DEFAULT_CONFIG_DIR)
    dirpath = Path(dirpath)
    try:
        dirpath.mkdir(parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    data = {
        "some":
            {
                "key": "value"
            },
        "another":
            {
                "entry": "here"
            }
    }

    filepath = dirpath / 'config.json'

# Generated at 2022-06-23 19:03:27.722427
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config['default_options'] == []



# Generated at 2022-06-23 19:03:31.139299
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    base_config_dict = BaseConfigDict('fake')
    assert_equal(base_config_dict.path, 'fake')

if __name__ == '__main__':
    from pytest import main
    main()

# Generated at 2022-06-23 19:03:34.553300
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path()
    self = BaseConfigDict(path)
    self['key'] = 'value'
    self.save()
    self.load()
    assert self['key'] == 'value'

# Generated at 2022-06-23 19:03:46.126808
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    """
    Check whether the load method works as expected.
    """
    dirname = "haha"
    filename = "test_config.json"
    path = Path(dirname).resolve() / filename
    path.mkdir(mode=0o777, parents=True, exist_ok=True)
    test_config = BaseConfigDict(path)

    # Non-exist file, test whether the KeyError exists
    test_config.load()

    # Create and write the file
    test_json_string = '{ "hello": "world" }'
    path.write_text(test_json_string)

    # Load the file, check whether the load works
    test_config.load()
    assert test_config['hello'] == 'world'

    # Remove the folder
    shutil.rmtree(dirname)

# Generated at 2022-06-23 19:03:48.852594
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path = "config.json")
    config.load()

    assert config['__meta__']['httpie'] == __version__

# Generated at 2022-06-23 19:03:55.342849
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmp_dir = Path(tempfile.mkdtemp())
    tmp_config_dir = tmp_dir / DEFAULT_CONFIG_DIRNAME
    tmp_config_path = tmp_config_dir / Config.FILENAME
    try:
        tmp_config_path.parent.mkdir.assert_not_called()
        tmp_config_path.parent.mkdir(mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    tmp_config_path.parent.assert_called()

# Generated at 2022-06-23 19:03:58.013175
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert str(ConfigFileError()) == ''
    assert str(ConfigFileError("error")) == "error"
    assert str(ConfigFileError("error", "another error")) == "another error"

# Generated at 2022-06-23 19:04:09.399485
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # No base dir
    assert BaseConfigDict(path=Path('~/.httpie/config.json')).is_new() is True
    assert BaseConfigDict(path=Path('~/.httpie/config.json')).path.exists() is False
    assert BaseConfigDict(path=Path('~/.config/httpie/config.json')).is_new() is True
    assert BaseConfigDict(path=Path('~/.config/httpie/config.json')).path.exists() is False
    assert BaseConfigDict(path=Path('~/AppData/Roaming/httpie/config.json')).is_new() is True
    assert BaseConfigDict(path=Path('~/AppData/Roaming/httpie/config.json')).path.exists() is False

    # Unrelated base dir

# Generated at 2022-06-23 19:04:10.239690
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass



# Generated at 2022-06-23 19:04:17.023752
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():

    test_file = Path('/tmp/test_config.json')
    test_config = BaseConfigDict(test_file)

    try:
        test_file.write_text('{}\n')
        test_config.delete()
        assert not test_file.exists()
        test_config.delete()
    finally:
        if test_file.exists():
            test_file.unlink()



# Generated at 2022-06-23 19:04:21.022916
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    if config.is_new():
        pass
    else:
        config['about'] = 'about'
        config['default_options'] = []
        config.save()
        config.delete()

# Generated at 2022-06-23 19:04:31.874214
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    os.mkdir('test_config')
    test_config = BaseConfigDict(path=Path('test_config/configfile.json'))
    test_config['test'] = 'test'
    test_config['test2'] = 'test2'
    test_config.save()
    with open('test_config/configfile.json') as f:
        s = f.read()
    assert 'test' in s, "нет ключа test в конфиге"
    assert 'test2' in s, "нет ключа test2 в конфиге"



# Generated at 2022-06-23 19:04:39.489593
# Unit test for constructor of class Config
def test_Config():
    # Normal case
    result = Config().__dict__
    assert result["directory"] == Path(DEFAULT_CONFIG_DIR)
    # Since Config is a sub class of BaseConfigDict, the check of self.path is ignored.
    assert result["path"] == Path(DEFAULT_CONFIG_DIR) / "config.json"
    assert result["update"] == dict.update
    assert result["__init__"] == dict.__init__
    assert result["update"] == dict.update
    assert result["delete"] == BaseConfigDict.delete
    assert result["ensure_directory"] == BaseConfigDict.ensure_directory
    assert result["is_new"] == BaseConfigDict.is_new
    assert result["load"] == BaseConfigDict.load
    assert result["save"] == BaseConfigDict.save

# Generated at 2022-06-23 19:04:44.120998
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    test_dict = TestDict(Path('/tmp/httpie_test'))
    test_dict['name'] = 'kevin';
    test_dict['helpurl'] = 'helpurl';
    test_dict['about'] = 'about';
    test_dict.save()



# Generated at 2022-06-23 19:04:48.912684
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Config().directory
    path = config_dir / 'dir'
    try:
        os.rmdir(path)
    except:
        pass
    base_config_dict = BaseConfigDict(path)
    base_config_dict.ensure_directory()
    assert os.stat(path).st_mode == 0o40700
    os.rmdir(path)

# Generated at 2022-06-23 19:04:58.577894
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os.path
    import unittest
    import tempfile
    test_dir_name = tempfile.mkdtemp()
    test_dir = os.path.dirname(test_dir_name)
    test_file = os.path.join(test_dir_name, 'config.json')
    new_dir = os.path.join(test_dir, 'test')
    new_file = os.path.join(new_dir, 'config.json')

    class BaseTest(unittest.TestCase):
        def test_ensure_directory(self):
            config = BaseConfigDict(test_file)
            config.ensure_directory()
            self.assertEqual(test_dir, config.path.parent)
            self.assertFalse(os.path.exists(new_dir))
            config

# Generated at 2022-06-23 19:05:00.626036
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path(".config") / "httpie"

# Generated at 2022-06-23 19:05:11.091628
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # if there are no files and the current folder does not exist, the path should be the default path
    assert BaseConfigDict(Path('./') / DEFAULT_CONFIG_DIRNAME / 'config.json').path == \
           Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME / 'config.json'

    # if there are no files and the current folder does not exist and there is a $XDG_CONFIG_HOME,
    # the path should be $XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME / 'config.json'
    os.environ[ENV_XDG_CONFIG_HOME] = "/home/user/myconfigs"

# Generated at 2022-06-23 19:05:17.315958
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    t = BaseConfigDict(
        Path('tests/demo/')
    )
    t.update(
        {
            "a": 1,
            "b": 2,
            '__meta__': {
                'httpie': __version__,
            }
        },
    )
    t.save()



# Generated at 2022-06-23 19:05:21.247508
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    def handle_exception_1():
        raise ConfigFileError('test-msg')
    def handle_exception_2():
        raise ConfigFileError('test-msg', 'test-error')
    handle_exception_1()
    handle_exception_2()

#Unit test for constructor of class BaseConfigDict

# Generated at 2022-06-23 19:05:22.781966
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path = "httpie/config.json")
    config.load()
    assert config["hosts"] == "127.0.0.1"
    assert config["port"] == 8888

# Generated at 2022-06-23 19:05:34.428537
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test with HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('/foo/bar'))
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # test with XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path('~/foo'))
    assert get_default_config_dir() == Path('~/foo/httpie')

    del os.environ[ENV_XDG_CONFIG_HOME]

    # without XDG_CONFIG_HOME
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # with legacy ~/.httpie


# Generated at 2022-06-23 19:05:40.653652
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_file = DEFAULT_CONFIG_DIR / Config.FILENAME
    config_file.write_text('{}')

    config = Config(DEFAULT_CONFIG_DIR)
    assert not config.is_new()

    # Remove the config file, so that is_new will return True
    os.remove(config_file)
    assert config.is_new()

# Generated at 2022-06-23 19:05:43.907775
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    temp_path = Path("temp_file")
    temp_path.touch()
    assert(temp_path.exists())
    temp_baseconfigdict = BaseConfigDict(temp_path)
    temp_baseconfigdict.delete()
    assert(not temp_path.exists())



# Generated at 2022-06-23 19:05:54.232966
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import os
    import warnings
    import tempfile
    import json

    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        tmpdir = tempfile.mkdtemp()
        dirpath = os.path.join(tmpdir, 'httpie')
        os.makedirs(dirpath)

    configPath = os.path.join(dirpath, Config.FILENAME)
    configJsonContents = json.dumps(
            {
                "default_options": [],
                "__meta__": {
                    "httpie": __version__,
                    "help": "http://httpie.org/",
                    "about": "http://github.com/jakubroztocil/httpie/"
                }
            }
    )

# Generated at 2022-06-23 19:06:04.260072
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    print("Test for method save of class BaseConfigDict")
    test_directory = Path("test_BaseConfigDict_save")
    test_filename = test_directory / 'test_file.json'
    print("Creating test directory: " + str(test_directory))
    test_directory.mkdir(parents=True, exist_ok=True)
    print("Creating test file: " + str(test_filename))
    test_obj = BaseConfigDict(test_filename)
    test_obj.helpurl = "http://www.google.com"
    test_obj.about = "just simple test"
    test_obj.save()
    print("Check that file is created")
    assert(test_filename.is_file())


# Generated at 2022-06-23 19:06:11.574086
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    config_directory = TemporaryDirectory()
    config_directory_path = Path(config_directory.name)
    config_file_path = config_directory_path / 'config.json'

    test_config = Config(config_directory_path)

    # Test if config file is created
    assert config_file_path.exists()
    test_config.delete()
    # Test if config file is deleted
    assert not config_file_path.exists()



# Generated at 2022-06-23 19:06:16.405974
# Unit test for constructor of class Config
def test_Config():
    ctx = Config()
    assert ctx.directory == DEFAULT_CONFIG_DIR, "Config() gives wrong directory"
    assert ctx.directory / ctx.FILENAME == DEFAULT_WINDOWS_CONFIG_DIR / Config.FILENAME, "Config() gives wrong path"
    assert ctx['default_options'] == [], "Config() doesn't have default options"


# Generated at 2022-06-23 19:06:23.162150
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import json
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdirname:
        dirname = Path(tmpdirname)
        filename = dirname / 'config.json'
        with open(filename, 'w+') as f:
            f.write('''
{
    "default_options": ["-a", "user-agent", "httpie/1.0.3"],
    "__meta__": {
    "help": "http://httpie.org/docs",
    "about": "httpie is a command line HTTP client"
}
}
''')
        config = Config(directory=dirname)
        config.load()

# Generated at 2022-06-23 19:06:28.454106
# Unit test for constructor of class Config
def test_Config():
    cfg = Config("/tmp/test_httpie_config")
    assert cfg.directory == Path("/tmp/test_httpie_config")
    assert cfg.path == Path("/tmp/test_httpie_config/config.json")
    assert cfg.DEFAULTS["default_options"] == []
    assert cfg.default_options == []

# Generated at 2022-06-23 19:06:32.338996
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.FILENAME == 'config.json'
    assert 'default_options' in config.DEFAULTS
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == Path('/home/yc/.config/httpie/config.json')
    assert config.name == None
    assert config.helpurl == None
    assert config.about == None



# Generated at 2022-06-23 19:06:43.239399
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path('.config/httpie')
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/pawel/.config'
    assert get_default_config_dir() == Path('/home/pawel/.config/httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/pawel/.config/httpie/'
    assert get_default_config_dir() == Path('/home/pawel/.config/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('/home/pawel/.config/httpie')

# Generated at 2022-06-23 19:06:47.226782
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from subprocess import check_output
    output = check_output(['python3', 'httpie/config.py']).decode('utf8').split('\n')
    path = [x for x in output if x.startswith('Default config dir:')][0].split(': ')[1]
    assert path == str(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-23 19:06:52.101189
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path.home() / 'test')
    config['__meta__'] = {'test': 'test'}
    config.ensure_directory()
    assert config.is_new() == True
    config.save(fail_silently=True)
    assert config.is_new() == False

    old_content = config.path.read_text()
    config.save(fail_silently=True)
    new_content = config.path.read_text()

    assert old_content == new_content
    config.path.unlink()


# Generated at 2022-06-23 19:07:00.244947
# Unit test for constructor of class Config
def test_Config():
    print("* config: test_Config")
    httpie_config_dir = 'httpie_test' + os.path.sep
    config_file = httpie_config_dir + 'config.json'
    config = Config(httpie_config_dir)
    if os.path.isfile(config_file) == True:
        os.unlink(config_file)
    config.save()
    assert os.path.isfile(config_file) == True
    config.delete()
    assert os.path.isfile(config_file) == False


# Generated at 2022-06-23 19:07:05.590531
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import DEFAULT_CONFIG_DIR
    if is_windows:
        assert str(DEFAULT_CONFIG_DIR.parent) == os.environ.get('APPDATA')
    else:
        assert str(DEFAULT_CONFIG_DIR.parent) == str(Path.home())


# Generated at 2022-06-23 19:07:08.610185
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("test error")
    except ConfigFileError as e:
        assert str(e) == "test error"

# Unit tests for class BaseConfigDict

# Generated at 2022-06-23 19:07:10.956203
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = f'{os.getcwd()}/Httpie'
    config = Config(directory=config_dir)
    config.delete()
    print(config)

# Generated at 2022-06-23 19:07:17.375094
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path("./test-httpie")
    if config_dir.is_dir():
        shutil.rmtree(config_dir)
    config = Config(config_dir)
    config.save()
    config.delete()
    assert not (config_dir / 'config.json').exists()


# Generated at 2022-06-23 19:07:19.427517
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    config.save()
    config.delete()


# Generated at 2022-06-23 19:07:25.226282
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with temp_config_dir() as config_dir:
        config_file = config_dir / 'config.json'
        dict = BaseConfigDict(path=config_file)
        dict.save()

        assert config_file.exists()

        with config_file.open('rt') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__



# Generated at 2022-06-23 19:07:27.007431
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().endswith('.config/httpie')



# Generated at 2022-06-23 19:07:31.954463
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    test for method ensure_directory of class BaseConfigDict
    """
    config_dir = Path('/')
    config_path = config_dir / 'test'
    config = BaseConfigDict(config_path)
    config.ensure_directory()

    assert os.path.isdir(str(config_dir / 'test'))

    os.rmdir(str(config_dir / 'test'))



# Generated at 2022-06-23 19:07:43.830782
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.getenv('XDG_CONFIG_HOME',
                                                      os.path.expanduser('~/.config'))).joinpath(DEFAULT_CONFIG_DIRNAME)
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg_config_home/'
    assert get_default_config_dir() == Path('/tmp/xdg_config_home/').joinpath(DEFAULT_CONFIG_DIRNAME)
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie_config_dir/'

# Generated at 2022-06-23 19:07:47.061866
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        assert True
        print('test_ConfigFileError passed')
    else:
        assert False


# Generated at 2022-06-23 19:07:57.155071
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from json.decoder import JSONDecodeError
    from contextlib import redirect_stdout
    
    def capture_stdout(func):
        with redirect_stdout(open(os.devnull, "w")):
            func()

    def capture_stdout_raise(func):
        with open(os.devnull, "w") as devnull:
            with redirect_stdout(devnull):
                try:
                    func()
                except Exception as e:
                    return isinstance(e, ConfigFileError)
    
    config_dir = Path("./tests/configs/json_file")

# Generated at 2022-06-23 19:08:00.960975
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path('./test/config.json'))
    assert config.is_new()

    config = BaseConfigDict(Path('./httpie/config.py'))
    assert not config.is_new()



# Generated at 2022-06-23 19:08:03.943588
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    new_config_dict_instance = BaseConfigDict(
        path=DEFAULT_CONFIG_DIR / DEFAULT_CONFIG_DIRNAME / 'test.json'
    )

# Generated at 2022-06-23 19:08:15.540394
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_path = "./test_config"
    print("Testing BaseConfigDict_save")
    class FakeConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            self.path = path
    fake_config = FakeConfigDict(config_path)
    fake_config.ensure_directory()
    fake_config["key"] = "value"
    fake_config.save()
    with open(config_path) as f:
        fake_config_json = json.load(f)
    os.remove(config_path)
    os.rmdir('test')
    if fake_config_json["__meta__"]["httpie"] == __version__ and fake_config_json["key"] == "value":
        print("Test passed")



# Generated at 2022-06-23 19:08:21.418441
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import DEFAULT_CONFIG_DIR as dir
    from httpie.config import BaseConfigDict as cfg
    from httpie.plugins.builtin import BuiltinPlugin

    file = dir / 'plugins' / 'foo.json'
    cfg(file).save()
    result = cfg(file).load()
    assert result == {}

