

# Generated at 2022-06-25 18:15:37.211394
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    # Be sure that the directory is created
    assert config_1.directory.exists() == False
    config_1.ensure_directory()
    # Be sure that the directory is created
    assert config_1.directory.exists() == True
    # Be sure that the temporary folder is deleted after the test
    os.rmdir(str(config_1.directory))


# Generated at 2022-06-25 18:15:39.058763
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()


# Generated at 2022-06-25 18:15:45.293641
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_path = get_default_config_dir()
    if Path.home() == Path('/home/user1'):
        assert default_path == Path('/home/user1/.config/httpie')
    elif Path.home() == Path('/Users/user1'):
        assert default_path == Path('/Users/user1/Library/Preferences/httpie')
    else:
        # Unknown home directory.
        pass


# Generated at 2022-06-25 18:15:50.347873
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()
    assert config_0.__dict__  # To ensure that nothing has been removed
    assert config_0.path.exists()
    config_0.path.unlink()



# Generated at 2022-06-25 18:15:54.383499
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    home = Path.home()
    config = BaseConfigDict(path=home / 'httpie'.join(['/httpie/config.json', '/httpie/config.json']))
    assert config.load() == None


# Generated at 2022-06-25 18:15:57.095795
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = "/tmp/httpie/"
    os.makedirs(path)
    config_dict_0 = BaseConfigDict(path)
    config_dict_0.ensure_directory()



# Generated at 2022-06-25 18:16:06.986527
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from shutil import copyfile, rmtree

    # Create a temporary directory
    with TemporaryDirectory() as tempdir:
        # Copy file from current directory to the temporary directory
        copyfile('../httpie/__main__.py', f'{tempdir}/__main__.py')
        # Instantiate a config object and save it in the temporary directory
        config = Config(directory=tempdir)
        config.save(fail_silently=True)

        # Remove the saved config file
        config.delete()
        # Remove the temporary directory
        rmtree(tempdir)


# Generated at 2022-06-25 18:16:09.876751
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path(DEFAULT_CONFIG_DIR / 'config.json'))
    assert config['httpie'] == __version__


# Generated at 2022-06-25 18:16:14.545066
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1
    # Test result should be ~/.config/httpie
    config_1 = get_default_config_dir()
    # Case 2
    # Test result should be /home/user/.config/httpie
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/user'
    config_2 = get_default_config_dir()

# Generated at 2022-06-25 18:16:18.638638
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class MyConfigDict(BaseConfigDict):
        name = 'config'
        helpurl = ''
        about = ''
        def __init__(self):
            path = Path("tests/unit-test/config.json")
            super().__init__(path)
    config_dict = MyConfigDict()
    config_dict.load()
    assert isinstance(config_dict, BaseConfigDict)

# Generated at 2022-06-25 18:16:22.615051
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


# Generated at 2022-06-25 18:16:27.472585
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert os.path.exists(config_0.directory.parent)
    os.removedirs(config_0.directory.parent)
    assert not(os.path.exists(config_0.directory.parent))



# Generated at 2022-06-25 18:16:31.661895
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    base_config_dict_0 = BaseConfigDict(Path("test_data/test_json_file_0.json"))
    base_config_dict_0.save()
    assert os.path.isfile(str(base_config_dict_0.path))


# Generated at 2022-06-25 18:16:40.783245
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    BASE_CONFIG_DICT_PATH = "./test_BaseConfigDict_ensure_directory.json"
    config_test = BaseConfigDict(path=BASE_CONFIG_DICT_PATH)
    config_test.ensure_directory()
    if os.path.exists(os.path.abspath(os.path.join(BASE_CONFIG_DICT_PATH, '..'))):
        pass
    else:
        # Raise error when creating the directory
        raise ConfigFileError(f'Cannot create the directory of {BASE_CONFIG_DICT_PATH}')


# Generated at 2022-06-25 18:16:47.231494
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = BaseConfigDict("test.txt")

    # Case 0: Normal Case
    config_0.save()
    assert os.path.isfile("test.txt") == True
    os.remove("test.txt")

    # Case 1: Wrong path
    config_1 = BaseConfigDict("/test/test.txt")
    try:
        config_1.save()
    except Exception:
        assert True


# Generated at 2022-06-25 18:16:55.902923
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = os.path.join(os.path.dirname(__file__), 'test-config-dir')
    path_to_file = os.path.join(config_dir, 'config.json')
    delete_file = False
    if os.path.isfile(path_to_file):
        os.unlink(path_to_file)
    else:
        delete_file = True
    try:
        config_dict = BaseConfigDict(path=path_to_file)
        config_dict.ensure_directory()
        config_dict.save()
        assert os.path.isfile(path_to_file) == True
    finally:
        if delete_file:
            os.unlink(path_to_file)

# Generated at 2022-06-25 18:17:06.965380
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Expected output: 
    # 1. If the environment variable is set, should return the path set in variable.
    # 2. If the variable is not set, should return the default path.
    # 3. Same as 2 for Windows.
    def test_case_1():
        # Set the variable
        os.environ['HTTPIE_CONFIG_DIR'] = '/path/to/httpie'
        assert get_default_config_dir() == '/path/to/httpie'

    def test_case_2():
        # Unset the variable
        os.environ.pop('HTTPIE_CONFIG_DIR')
        assert get_default_config_dir() == Path('/home/user/.config/httpie')


# Generated at 2022-06-25 18:17:08.948620
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('.config') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:17:10.669544
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base = BaseConfigDict(path="path.json")
    base.ensure_directory()


# Generated at 2022-06-25 18:17:19.340116
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    temp_config_dir = Path('temp_config_dir')

    def cleanup():
        if legacy_config_dir.exists():
            legacy_config_dir.unlink()
        if temp_config_dir.exists():
            shutil.rmtree(temp_config_dir)
        if xdg_config_home:
            os.environ[ENV_XDG_CONFIG_HOME] = xdg_config_home
        else:
            os.environ.pop(ENV_XDG_CONFIG_HOME)



# Generated at 2022-06-25 18:17:22.922777
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()



# Generated at 2022-06-25 18:17:25.327499
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert (get_default_config_dir() == Path(os.path.expanduser('~')) / Path('.config') / Path('httpie'))

# Generated at 2022-06-25 18:17:28.594382
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    config_1.save()


# Generated at 2022-06-25 18:17:34.207252
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import unittest

    class TestBaseConfigDictLoad(unittest.TestCase):
        def test_load_with_invalid_json(self):
            path = Path('divias.txt')
            path.write_text('invalid json')
            config = BaseConfigDict(path)
            with self.assertRaises(ConfigFileError):
                config.load()

    unittest.main()

# Generated at 2022-06-25 18:17:36.819285
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.load()

# Generated at 2022-06-25 18:17:37.882371
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-25 18:17:47.204965
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    real_config_dir = get_default_config_dir()
    real_config_dir_string = str(real_config_dir)

    # test case 1: no env variable
    config_1 = get_default_config_dir()
    config_1_string = str(config_1)

    # test case 2: with env variable
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/tester/.config/httpie'
    config_2 = get_default_config_dir()
    config_2_string = str(config_2)

    # test case 3: with env variable
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/tester/testing'
    config_3 = get_default_config_dir()
    config_3_string = str

# Generated at 2022-06-25 18:17:52.040055
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.getenv(ENV_HTTPIE_CONFIG_DIR, None) != None:
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    assert(get_default_config_dir().as_posix() == DEFAULT_WINDOWS_CONFIG_DIR.as_posix())
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp/myconfig"
    assert(get_default_config_dir().as_posix() == "/tmp/myconfig")
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp/httpie/.config"
    assert(get_default_config_dir().as_posix() == "/tmp/httpie/.config/" + DEFAULT_CONFIG_DIRNAME)

# Generated at 2022-06-25 18:17:53.852257
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-25 18:18:01.599515
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('test')
    my_file = path/'config.json'
    config = BaseConfigDict(my_file)
    # Test for exception in case file does not exist
    try:
        config.load()
    except ConfigFileError:
        pass
    # Test for exception in case file is not a JSON file
    open(my_file, 'a')
    my_file.write_text('abc')
    try:
        config.load()
    except ConfigFileError:
        pass
    # Test for normal case
    my_file.write_text('{"default_options": ["test"]}')
    config.load()
    assert config['default_options'] == ['test']
    my_file.unlink()


# Generated at 2022-06-25 18:18:13.226555
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # corner case 1: no file exists
    config_0 = Config()
    if config_0.is_new():
        config_0.load()
    # corner case 2: file exists but is empty
    config_1 = Config()
    if config_1.is_new():
        config_1.ensure_directory()
        Path(config_1.path).touch()
        config_1.load()
    # corner case 3: file exists but is invalid
    config_2 = Config()
    if config_2.is_new():
        config_2.ensure_directory()
        Path(config_2.path).write_text('{')
        config_2.load()


# Generated at 2022-06-25 18:18:24.227922
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Windows
    if os.name == 'nt':
        default_dir = DEFAULT_WINDOWS_CONFIG_DIR
        assert get_default_config_dir() == default_dir
        return

    # home directory
    home_dir = Path.home()
    assert get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    assert get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:18:28.406818
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = 'config.json'
    path_json = open(path, 'r')
    data = json.load(path_json)  # loads json data from config.json
    config_dict = BaseConfigDict(path)
    config_dict.update(data)
    return config_dict


# Generated at 2022-06-25 18:18:29.556242
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('config.json')
    config.save()

# Generated at 2022-06-25 18:18:30.907052
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(Path.home() + '/.config/httpie')

# Generated at 2022-06-25 18:18:38.297522
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    os.environ[ENV_HTTPIE_CONFIG_DIR] = r'C:\Temp\Httpie'
    config_dir = get_default_config_dir()
    assert config_dir == Path(r'C:\Temp\Httpie')

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    config_dir = get_default_config_dir()
    assert config_dir == Path(r'C:\Users\xuanqi\AppData\Roaming\httpie')

# Generated at 2022-06-25 18:18:47.243860
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create tmp file
    tmp_path = os.getcwd() + "/tmp.json"
    tmp = open(tmp_path, 'w+')
    tmp.write("""{
        "default_options": []
    }""")
    tmp.close()
    # Test for valid json
    config_tmp = Config(tmp_path)
    assert config_tmp.load() is None
    assert config_tmp['default_options'] == []
    # Test for invalid json
    tmp = open(tmp_path, 'w+')
    tmp.write("""{
        "default_options": []
    """)
    tmp.close()
    config_tmp = Config(tmp_path)
    assert config_tmp.load() is not None


# Generated at 2022-06-25 18:18:49.151906
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config(directory='/tmp')
    with pytest.raises(ConfigFileError):
        config_1.load()
    assert config_1.get('__meta__') is None


# Generated at 2022-06-25 18:18:51.432017
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    p = Path(DEFAULT_WINDOWS_CONFIG_DIR)
    assert get_default_config_dir() == p



# Generated at 2022-06-25 18:18:56.633401
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Case 1.1
    config_3_1 = BaseConfigDict(path=Path("/test/test-config-3"))
    config_3_1.save(fail_silently=False)
    # Case 1.2
    config_3_2 = BaseConfigDict(path=Path("/test/test-config-3"))
    config_3_2.save(fail_silently=True)



# Generated at 2022-06-25 18:19:06.552277
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    if not is_windows:
        config_0 = Config()
        assert not config_0.path.parent.exists()
        config_0.path.write_text('test')
        config_0.ensure_directory()
        assert config_0.path.parent.exists()
        config_0.path.unlink
        config_0.path.parent.rmdir()


# Generated at 2022-06-25 18:19:07.384196
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()


# Generated at 2022-06-25 18:19:16.273623
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # This test case is derived from the code in load method in BaseConfigDict class. 
    def load(self):
        config_type = type(self).__name__.lower()
        try:
            with self.path.open('rt') as f:
                try:
                    data = json.load(f)
                except ValueError as e:
                    raise ConfigFileError(
                        f'invalid {config_type} file: {e} [{self.path}]'
                    )
                self.update(data)
        except IOError as e:
            if e.errno != errno.ENOENT:
                raise ConfigFileError(f'cannot read {config_type} file: {e}')



# Generated at 2022-06-25 18:19:22.182422
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dir_0 = Path(__file__).parent
    config_0 = Config(dir_0)
    assert (dir_0 / DEFAULT_CONFIG_DIRNAME).exists()
    assert (dir_0 / DEFAULT_CONFIG_DIRNAME).is_dir()
    config_0.delete()
    assert not (dir_0 / DEFAULT_CONFIG_DIRNAME).exists()


# Generated at 2022-06-25 18:19:25.336822
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class Config(BaseConfigDict):
        def save(self):
            return super().save(fail_silently=True)

    config = Config(Path("./config.json"))
    assert config.save() is None



# Generated at 2022-06-25 18:19:27.782961
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    config.delete()
    config.save(True)


# Generated at 2022-06-25 18:19:30.863063
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config('/tmp')
    config.ensure_directory()
    assert config.path.parent.is_dir()


# Generated at 2022-06-25 18:19:38.256410
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test 1
    config_dir = Path("./tests/config/")
    path = config_dir / Config.FILENAME
    config_dict = BaseConfigDict(path)
    config_dict.load()
    assert config_dict.get("default_options") == ["--pretty=all"]

    # Test 2
    home_dir = Path.home()
    config_dir = home_dir / Path(".httpie")
    path = config_dir / Config.FILENAME
    config_dict = BaseConfigDict(path)
    config_dict.load()
    assert config_dict.get("default_options") == ["--pretty=all"]

    # Test 3
    config_dir = Path('.config/httpie')
    path = config_dir / Config.FILENAME
    config_dict = BaseConfigD

# Generated at 2022-06-25 18:19:40.121595
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base = BaseConfigDict()


# Generated at 2022-06-25 18:19:51.024656
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # load with no file
    config_1 = Config()
    try:
        config_1.load()
        assert False
    except ConfigFileError:
        assert True

    # load with empty file
    config_2 = Config()
    config_2.path = config_2.path + '.tmp'
    config_2.save(fail_silently=True)
    config_2.load()

    # load with non-empty file
    config_3 = Config()
    config_3.path = config_3.path + '.tmp'
    config_3.update({'tmp_key': 'tmp_value'})
    config_3.save(fail_silently=True)
    config_3.load()
    assert config_3['tmp_key'] == 'tmp_value'



# Generated at 2022-06-25 18:20:03.087309
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_0 = get_default_config_dir()
    config_0 = get_default_config_dir()
    assert config_0 == Path(config_0)


# Generated at 2022-06-25 18:20:14.035312
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with patch.dict(os.environ, {ENV_HTTPIE_CONFIG_DIR: 'foo'}):
        assert get_default_config_dir() == 'foo'

    with patch('httpie.config.is_windows', True):
        assert get_default_config_dir() == 'C:\\Users\\httpie\\AppData\\Roaming\\httpie'

    with patch('httpie.config.Path.home', return_value='foo'):
        assert get_default_config_dir() == 'foo\\.config\\httpie'

    with patch('httpie.config.Path.home', return_value='foo'):
        assert get_default_config_dir() == 'foo\\.config\\httpie'

    with patch('httpie.config.Path.home', return_value='foo'):
        _mock_path

# Generated at 2022-06-25 18:20:15.588642
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict()
    config_dict.load()
    
test_BaseConfigDict_load()

# Generated at 2022-06-25 18:20:17.062239
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        config_3 = Config('/tmp')
        if not config_3.is_new():
            assert False, 'Config file exists'
    except OSError:
        pass



# Generated at 2022-06-25 18:20:23.061844
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    def test_func():
        config_0.save()
    def expected_func():
        config_0.ensure_directory()
        json_string = json.dumps(obj=config_0, indent=4, sort_keys=True, ensure_ascii=True, )
        config_0.path.write_text(json_string + '\n')
    assert test_func.__name__ == expected_func.__name__


# Generated at 2022-06-25 18:20:33.781229
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # set HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    config_dir = get_default_config_dir()
    assert config_dir == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Legacy config dir
    legacy_config_dir = Path(Path.home()).joinpath('.httpie')
    legacy_config_file = legacy_config_dir.joinpath('config.json')
    legacy_config_file.parent.mkdir()
    legacy_config_file.touch()
    if legacy_config_file.exists():
        config_dir = get_default_config_dir()
        assert config_dir == legacy_config_file.parent
        config_dir.rmdir()

# Generated at 2022-06-25 18:20:38.612141
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    try:
        config.load()
    except IOError as e:
        print(e)
    assert config.get('default_options'), 'default_options is missing in Config'


# Generated at 2022-06-25 18:20:46.739070
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # On windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # 1. If env var HTTPIE_CONFIG_DIR is set, it takes precedence
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')

        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2. Legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir(mode=0o700, parents=True)

        new_config_dir = get_default_config_dir()
        assert new_

# Generated at 2022-06-25 18:20:49.293622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict_0 = BaseConfigDict(Path('/tmp/httpie/config.json'))
    base_config_dict_0.load()


# Generated at 2022-06-25 18:21:00.071366
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 0: $HTTPIE_CONFIG_DIR is not set
    if ENV_HTTPIE_CONFIG_DIR not in os.environ:
        config_0 = get_default_config_dir()

        home_dir = Path.home()
        legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        xdg_config_home_dir = os.environ.get(
            ENV_XDG_CONFIG_HOME,  # 4.1. explicit
            home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
        )


# Generated at 2022-06-25 18:21:42.129681
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test default path in linux
    os.environ[ENV_XDG_CONFIG_HOME] = '~'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.path.expandvars('~')
    assert str(get_default_config_dir()) == '/home/travis/.config/httpie'
    # test default path in warning
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert str(get_default_config_dir()) == '/home/travis/.config/httpie'
    # test path from HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/test'

# Generated at 2022-06-25 18:21:54.911346
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for existing relative path
    assert get_default_config_dir() == Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME

    # Test for non-existing relative path
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME

    # Test for absolute path
    os.environ[ENV_XDG_CONFIG_HOME] = '/var/tmp'
    assert get_default_config_dir() == Path('/var/tmp') / DEFAULT_CONFIG_DIRNAME

    # Test for empty path
    os.environ[ENV_XDG_CONFIG_HOME] = ''

# Generated at 2022-06-25 18:22:06.833841
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # case for windows
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
    else:
        # case for linux
        from httpie.config import ENV_HOME, ENV_XDG_CONFIG_HOME
        xdg_config_home_dir = os.environ.get(
            ENV_XDG_CONFIG_HOME,  # 4.1. explicit
            Path(str(os.environ.get(ENV_HOME))) / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
        )
        assert (Path(xdg_config_home_dir) / DEFAULT_CONFIG_DIRNAME) == get_default_config_dir()



# Generated at 2022-06-25 18:22:18.165433
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_config_0_path = Path(tmp_dir) / 'config_0.json'
        config_0 = BaseConfigDict(tmp_config_0_path)
        config_0['test_key_0'] = 'test_value_0'
        config_0.save()
        # test created config file exists
        assert tmp_config_0_path.exists()
        with open(tmp_config_0_path) as f:
            read_config_0 = json.load(f)
        # test key-value can be read from config file correctly
        assert read_config_0['test_key_0'] == 'test_value_0'


# Generated at 2022-06-25 18:22:26.245580
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1: $HTTPIE_CONFIG_DIR is set
    os.environ['HTTPIE_CONFIG_DIR'] = '/tmp/httpie-config'
    assert get_default_config_dir() == '/tmp/httpie-config'
    del os.environ['HTTPIE_CONFIG_DIR']

    # Windows:
    if is_windows:
        assert get_default_config_dir() == \
            'C:\\Users\\UserName\\AppData\\Roaming\\httpie'

    # Case 2: $XDG_CONFIG_HOME is set
    os.environ['XDG_CONFIG_HOME'] = '/tmp/xdg-config-home'
    assert get_default_config_dir() == '/tmp/xdg-config-home/httpie'

# Generated at 2022-06-25 18:22:36.679347
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    temp_dir = Path('/tmp/httpie/config')
    home_dir = Path('/tmp/httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(temp_dir)
    assert get_default_config_dir() == temp_dir
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    os.environ[ENV_XDG_CONFIG_HOME] = str(temp_dir)
    assert get_default_config_dir() == temp_dir / DEFAULT_CONFIG_DIRNAME
    del os.environ[ENV_XDG_CONFIG_HOME]

    home_dir.mkdir(parents=True)

# Generated at 2022-06-25 18:22:38.000299
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.load()


# Generated at 2022-06-25 18:22:40.340159
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = BaseConfigDict(Path('./config.json'))
    config_1.load()


# Generated at 2022-06-25 18:22:42.928747
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:22:44.414762
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)


# Generated at 2022-06-25 18:23:24.945060
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # test 1: no ENV_HTTPIE_CONFIG_DIR set
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR
        # test 2: $HTTPIE_CONFIG_DIR set
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/test_httpie_config'
        assert get_default_config_dir() == Path('/tmp/test_httpie_config')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        # test 3: $XDG_CONFIG_HOME set

# Generated at 2022-06-25 18:23:26.950018
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == '$HOME/.config/httpie'


# Generated at 2022-06-25 18:23:33.783604
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    #create a config.json file with dummy json data
    config_0 = Config()
    json_string = json.dumps(
        obj=config_0,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    config_0.path.write_text(json_string + '\n')
    config_0.load()

    #check if the file is loaded correctly
    assert(config_0.path.exists())


# Generated at 2022-06-25 18:23:35.035085
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert isinstance(DEFAULT_CONFIG_DIR, Path), 'Should be a Path object'

# Generated at 2022-06-25 18:23:37.604189
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert (config_0.path.parent / config_0.directory).exists()


# Generated at 2022-06-25 18:23:44.728033
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Setup the test environment
    env_xdg_config_home_path = '/tmp/xdg_config_home'
    env_httpie_config_dir_path = '/tmp/httpie_config_dir'

    # Test 1
    # Test case: No env variables
    # Expected results: DEFAULT_WINDOWS_CONFIG_DIR for windows, and
    #                   ~/.config/httpie for Linux
    test_path = get_default_config_dir()
    if is_windows:
        assert test_path == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert test_path == Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME

    # Test 2
    # Test case: set $XDG_CONFIG_HOME
    # Expected results: value of $XDG_

# Generated at 2022-06-25 18:23:47.169168
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.load()
    assert config_0['default_options'], 'Test failed'


# Generated at 2022-06-25 18:23:49.804072
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.path.expanduser('~/.config/httpie/config.json'))

# Generated at 2022-06-25 18:23:51.310768
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_2 = Config()
    config_2.save()
    config_2.save(fail_silently=True)
    config_2.save(fail_silently=False)


# Generated at 2022-06-25 18:24:01.684434
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home_dir = os.environ.get(
        ENV_XDG_CONFIG_HOME)
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        return legacy_config_dir
    else:
        assert xdg_config_home_dir == os.environ.get(ENV_XDG_CONFIG_HOME)
        assert DEFAULT_RELATIVE_XDG_CONFIG_HOME == Path('.config')
        assert xdg_config_home_dir == (
            home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME)



# Generated at 2022-06-25 18:25:08.445087
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config(directory='/tmp/test_directory')
    config_1.ensure_directory()


# Generated at 2022-06-25 18:25:16.017885
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/non-existing/path'
    assert str(get_default_config_dir()) == '/some/non-existing/path'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/relative/.config'
    assert str(get_default_config_dir()) == '/some/relative/.config/httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-25 18:25:25.584010
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    class MockException(Exception):
        def __init__(self, *args, **kwargs):  # real signature unknown
            pass

    class MockPath:
        def __init__(self, *args):
            self._parent = MockPath(1)
            self._parent.mkdir = lambda *args, **kwargs: OSError(1, "a")

        def __truediv__(self, other):
            return MockPath(1)

        def write_text(self, *args):
            raise MockException()

        def unlink(self):
            pass

    dic = BaseConfigDict(MockPath())
    dic.ensure_directory = lambda: None
    dic.save(fail_silently=1)