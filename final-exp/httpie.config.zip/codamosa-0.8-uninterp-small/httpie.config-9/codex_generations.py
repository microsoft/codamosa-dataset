

# Generated at 2022-06-25 18:15:30.068511
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    baseConfigDict_0 = BaseConfigDict()
    class0_0 = BaseConfigDict
    bool_0 = bool()
    class0_0.delete(baseConfigDict_0)
    bool_0 = bool()


# Generated at 2022-06-25 18:15:38.354557
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Test for case 1
    # Testing for environment variable HTTPIE_CONFIG_DIR
    os.environ['HTTPIE_CONFIG_DIR'] = '/home/temp/config'
    path_1 = get_default_config_dir()
    assert path_1 == Path('/home/temp/config')

    # Test for case 2
    # Testing for windows
    del os.environ['HTTPIE_CONFIG_DIR']
    path_2 = get_default_config_dir()
    assert path_2 == DEFAULT_CONFIG_DIR

    # Test for case 3
    # Testing for legacy ~/.httpie
    path_3 = get_default_config_dir()
    assert path_3 == DEFAULT_CONFIG_DIR

    # Test for case 4
    # Testing for xdg

# Generated at 2022-06-25 18:15:44.729219
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # To be consistent with other test cases, set the directory to be
    # /tmp/test_httpie.
    path = Path('/tmp/test_httpie/config.json')
    config = Config(path.parent)
    config.ensure_directory()
    assert path.parent.exists()
    assert path.parent.is_dir()
    os.system('rm -rf /tmp/test_httpie')



# Generated at 2022-06-25 18:15:53.442945
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    print("Run unit test for method load of class BaseConfigDict")
    path_0 = Path.home() / ".httpie"
    path_1 = Path.home() / "test.json"
    path_1.write_text("{\"test\":\"test\"}")
    config = BaseConfigDict(path_1)
    assert(config['test'] == "test")
    assert(config.is_new() == False)


# Generated at 2022-06-25 18:15:56.374046
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # function get_default_config_dir() should return path to the httpie configuration directory
    config_dir = get_default_config_dir()
    assert isinstance(config_dir, Path)


# Generated at 2022-06-25 18:15:58.096328
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_default = Config()
    config_default.delete()
    assert(not config_default.is_new())


# Generated at 2022-06-25 18:16:04.010229
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config = Config()
    test_config['Test'] = {'Test_key':'Test_value'}
    test_config.save()
    test_config.load()
    assert test_config['Test']['Test_key'] == 'Test_value'
    test_config.delete()


# Generated at 2022-06-25 18:16:09.221041
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()
    assert type(path_0) == Path
    assert path_0 == DEFAULT_WINDOWS_CONFIG_DIR

    path_1 = get_default_config_dir()
    assert type(path_1) == Path
    assert path_1 == DEFAULT_WINDOWS_CONFIG_DIR



# Generated at 2022-06-25 18:16:12.983332
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(path=Path('/home/user/test/testfile.json'))
    config_dict.ensure_directory()
    assert os.path.exists('/home/user/test')
    os.rmdir('/home/user/test')

# Generated at 2022-06-25 18:16:18.308298
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_home = Path("/tmp/test-home")
    config_dir = test_home / DEFAULT_CONFIG_DIRNAME
    filename = 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_dir.is_absolute()
    assert (config_dir / filename).exists()


# Generated at 2022-06-25 18:16:28.999351
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    # Create a temporary directory
    with TemporaryDirectory() as td:
        # Create a temporary file and save it in a config
        with tempfile.NamedTemporaryFile() as f:
            config = BaseConfigDict(Path(td) / 'config.json')
            config.update({'key': 'value'})
            config.save()

            # Test if the config has the key and value
            assert 'key' in config.keys()
            assert config.get('key') == 'value'



# Generated at 2022-06-25 18:16:40.496688
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # clear environment
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    # Test environment variables
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'TestDir'
    assert get_default_config_dir() == 'TestDir'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'TestDir2'
    os.environ[ENV_XDG_CONFIG_HOME] = 'TestDir3'
    assert get_default_config_dir() == 'TestDir2'

    # Test default config dir
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-25 18:16:51.388333
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Check that the method delete of class BaseConfigDict works as expected. We
    do not test the case when path.unlink raises OSError (errno == ENOENT) as
    this would require to modify the file system which is not always possible
    in terms of permissions.
    """
    # Create a temporary directory outside the httpie repository and make sure
    # we remove it when the test is finished
    temp_folder = tempfile.mkdtemp()
    this_file = inspect.getfile(inspect.currentframe())
    this_directory = Path(os.path.dirname(os.path.abspath(this_file)))

    test_file = this_directory / 'test_delete.tmp'
    test_file.touch()

    # Create a dummy instance to test

# Generated at 2022-06-25 18:16:55.750167
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        c1 = Config()
        c1.ensure_directory()

        c2 = Config()
        c2.ensure_directory()
    finally:
        shutil.rmtree(DEFAULT_CONFIG_DIR)
        if DEFAULT_CONFIG_DIR != DEFAULT_WINDOWS_CONFIG_DIR:
            shutil.rmtree(DEFAULT_WINDOWS_CONFIG_DIR)


# Generated at 2022-06-25 18:17:01.153191
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_dict = {
        '__meta__': {
            'httpie': __version__
        },
        'default_options': []
    }
    test_obj = BaseConfigDict(path=Path("testcase/baseconfigdict.json"))
    test_obj.save()
    assert test_obj == test_config_dict

# Generated at 2022-06-25 18:17:06.122427
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert get_default_config_dir() == env_config_dir
    else:
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-25 18:17:13.283161
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    if path_0.exists():
        print('Delete path {}'.format(path_0))
        path_0.rmdir()
    try:
        path_0.mkdir()
        assert True
    except AssertionError:
        assert False
    except OSError as exc:
        if exc.errno == errno.EEXIST and path_0.is_dir():
            print('Directory {} already exists.'.format(path_0))
            assert True
        else:
            raise


# Generated at 2022-06-25 18:17:19.085760
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    p = Path('/tmp/test_BaseConfigDict_save/dir')
    p.mkdir(exist_ok=True)
    c = BaseConfigDict(path=p/'test')
    c.save()
    f = Path('/tmp/test_BaseConfigDict_save/dir/test')
    assert f.exists()
    c.save()
    d = p.glob('test')
    for i in d:
        i.unlink()
    p.rmdir()


# Generated at 2022-06-25 18:17:30.545564
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Check default config directory when environment variable is not setted
    old_env = os.environ.copy()
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if not is_windows:
        # Check when XDG_CONFIG_HOME is also not setted
        if ENV_XDG_CONFIG_HOME in os.environ:
            del os.environ[ENV_XDG_CONFIG_HOME]

        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

        # Check when XDG_CONFIG_HOME is setted

# Generated at 2022-06-25 18:17:33.531974
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    path_json = path_0 / 'config.json'
    config = Config()
    try:
        config.load()
    except ConfigFileError:
        pass



# Generated at 2022-06-25 18:17:42.344057
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = Path.home() / '.httpie' / 'config.json'

    # Test for when the path exists
    BaseConfigDict.load(BaseConfigDict(path_1))

    # Test for when the path does not exist
    path_2 = Path.home() / '.httpie' / 'file.json'
    try:
        BaseConfigDict.load(BaseConfigDict(path_2))
    except ConfigFileError as e:
        assert type(e) == ConfigFileError



# Generated at 2022-06-25 18:17:43.952635
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config(directory = DEFAULT_CONFIG_DIR)
    config.ensure_directory()

# Generated at 2022-06-25 18:17:45.646019
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_case_0()
    print("test_get_default_config_dir: success")

# Generated at 2022-06-25 18:17:47.893408
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    try:
        config.save()
        config.save(fail_silently=True)
    except IOError:
        assert False, 'Config file save failed'


# Generated at 2022-06-25 18:17:54.147466
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_dir = os.environ.get(ENV_XDG_CONFIG_HOME)
    if xdg_dir:
        assert get_default_config_dir() == Path(xdg_dir) / DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir() == get_home_dir() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-25 18:17:56.870653
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    testBaseConfigDict = BaseConfigDict(Path('readme.md'))
    testBaseConfigDict.ensure_directory()
    assert (Path('readme.md').parents[0].exists())


# Generated at 2022-06-25 18:17:59.633859
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # print(get_default_config_dir())
    # print(get_default_config_dir())
    # print(get_default_config_dir())
    # print(get_default_config_dir())
    assert get_default_config_dir().exists()



# Generated at 2022-06-25 18:18:10.858231
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    import os
    import pytest
    from pathlib import Path

    test_dir = ".test_config"
    test_file = Path('test_file.json')
    base_config = BaseConfigDict(test_file)

    # Create a directory for the test
    try:
        os.mkdir(test_dir)
    except OSError:
        pass
    os.chdir(test_dir)

    base_config["test"] = "test"

    try:
        base_config.save()
    except IOError:
        # Raise IOError: If path is not a directory.
        base_config.save()

    # If a file is not found, save method should fail
    with pytest.raises(ConfigFileError):
        base_config.save

# Generated at 2022-06-25 18:18:14.593013
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path = Path('/tmp/httpie/config.json'))
    try:
        config.ensure_directory()
        assert os.path.isdir('/tmp/httpie')
    finally:
        shutil.rmtree('/tmp/httpie')


# Generated at 2022-06-25 18:18:16.926654
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert os.path.isdir(config_0.directory)


# Generated at 2022-06-25 18:18:27.171749
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path("config_test.json"))
    config.path.write_text("")
    config.ensure_directory()
    config.path.unlink()
    if not config.path.parent.exists():
        raise Exception("File not created")



# Generated at 2022-06-25 18:18:30.425850
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert BaseConfigDict.save({}) == {}

# Generated at 2022-06-25 18:18:36.363970
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    configdict = BaseConfigDict(Path(DEFAULT_CONFIG_DIR))
    try:
        configdict.ensure_directory()
    except IOError:
        # If a directory already exists, method ensure_directory would throw IOError
        # the exception is handled when method ensure_directory is called,
        # so in this case, we don't need to handle the exception again
        # this is an intended behavior and not a bug
        pass

# Generated at 2022-06-25 18:18:43.538862
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    data = {
        "key_a_1": 1,
        "key_a_2": 2,
        "key_a_3": 3,
        "key_b_1": 1,
        "key_b_2": 2,
        "key_b_3": 3
    }

    bc = BaseConfigDict(path=Path('tmp/config.json'))
    bc.update(data)
    bc.save()


if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-25 18:18:47.593987
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    path = get_default_config_dir()
    print(path)
    if is_windows:
        assert path.as_posix() == os.environ['APPDATA']+'\\httpie\\config.json'
    else:
        assert path.as_posix() == os.environ['HOME']+'/.config/httpie/config.json'

# Generated at 2022-06-25 18:18:57.195025
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_dir = tempfile.TemporaryDirectory()
    d = BaseConfigDict(Path(temp_dir.name) / 'config.json')
    d['default_options'] = ["a"]
    d.save()
    if d['default_options'] != ["a"]:
        print("\nError in BaseConfigDict_save method, default_options not saved correctly.")
        return False
    if d['__meta__']['httpie'] != __version__:
        print("\nError in BaseConfigDict_save method, __meta__['httpie'] not saved correctly: " + __version__ + ' vs. ' + d['__meta__']['httpie'])
        return False

# Generated at 2022-06-25 18:19:03.662641
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path0 = DEFAULT_CONFIG_DIR
    tmp_path0 = path0 / 'tmp'
    tmp_path0.mkdir(mode=0o700, parents=True)
    tmp_path1 = tmp_path0 / 'tmp1'
    tmp_path2 = tmp_path1 / 'tmp2'
    tmp_path2.mkdir(mode=0o700, parents=True)
    tmp_path2.rmdir()
    tmp_path1.rmdir()
    tmp_path0.rmdir()


# Generated at 2022-06-25 18:19:09.463471
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = "test/test_BaseConfigDict/config.json"
    with open(path_0, "w", encoding="utf-8") as f:
        f.write("{'foo': 'bar'}\n")
    config_dict = BaseConfigDict(path_0)
    config_dict.load()
    assert config_dict["foo"] == "bar"

# Generated at 2022-06-25 18:19:11.144653
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert os.path.isdir(config.path)

# Generated at 2022-06-25 18:19:15.487093
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # import pdb; pdb.set_trace()
    test_dir = Path(__file__).resolve().parent / 'tests'
    filename = 'test_file_0.json'
    path = test_dir / filename
    config = BaseConfigDict(path=path)
    config.save()
    assert path.exists()

# Generated at 2022-06-25 18:19:22.910332
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()
    print(path_0)
    pass

if __name__ == '__main__':
    test_get_default_config_dir()
    pass

# Generated at 2022-06-25 18:19:25.035164
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = 'testconfig'
    dict_0 = BaseConfigDict(path_0)
    dict_0.save()

# Generated at 2022-06-25 18:19:28.774287
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    x = BaseConfigDict(path_1)
    x.ensure_directory()
    assert(os.path.exists(path_1))


# Generated at 2022-06-25 18:19:31.746613
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.environ['XDG_CONFIG_HOME'])/DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-25 18:19:34.092700
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config('/home')
    try:
        config.ensure_directory()
    except ConfigFileError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:19:37.061340
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('./config.json'))
    config_dict['test1'] = 'test2'
    config_dict.save(fail_silently=False)


# Generated at 2022-06-25 18:19:38.593669
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir() == DEFAULT_CONFIG_DIR)


# Generated at 2022-06-25 18:19:44.895572
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(path=Path(__file__).parent / 'config' / 'config.json')
    config_dict.ensure_directory()
    assert (config_dict.path.parent).exists() == True
    shutil.rmtree(config_dict.path.parent)


# Generated at 2022-06-25 18:19:47.035281
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_base_cd = BaseConfigDict("path")
    test_base_cd.ensure_directory()



# Generated at 2022-06-25 18:19:50.262027
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

if __name__ == '__main__':
    test_get_default_config_dir()

# Generated at 2022-06-25 18:19:56.649865
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.path.expanduser('.config/httpie'))


# Generated at 2022-06-25 18:20:02.361078
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    base_dir = get_default_config_dir()
    test_dir = base_dir / DEFAULT_CONFIG_DIRNAME
    assert test_dir.exists()
    assert test_dir.is_dir()


# Generated at 2022-06-25 18:20:07.082302
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    path_2 = Path(str(path_1) + "/test/")
    config = Config(directory=path_2)
    config.save()
    assert config.path.exists() == True
    assert config.path.name == Config.FILENAME
    config.delete()


# Generated at 2022-06-25 18:20:09.819375
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    result_0 = config_0.ensure_directory()
    assert isinstance(result_0, object)


# Generated at 2022-06-25 18:20:20.555627
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    assert (path_0.parent) == (path_0 / '..')
    assert not path_0.exists()
    path_0.mkdir(parents=True)
    assert path_0.exists()
    path_0.rmdir()
    config_0 = Config(directory=path_0)
    config_0.load()
    config_0.save()
    config_0.delete()
    path_0.mkdir(parents=True)
    path_0.chmod(mode=0o400)
    config_0.load()
    config_0.save()
    config_0.delete()
    os.chmod(path_0, mode=0o600)
    path_0.chmod(mode=0o400)


# Generated at 2022-06-25 18:20:22.066109
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    a=Config()
    BaseConfigDict.ensure_directory(a)


# Generated at 2022-06-25 18:20:28.262781
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir() / '__CASES__' / 'ensure_directory'
    if path_1.exists():
        path_1.unlink()
    bcd_0 = BaseConfigDict(path=path_1)    # Type of variable bcd_0 is BaseConfigDict
    bcd_0.ensure_directory()
    assert bcd_0.path.exists()


# Generated at 2022-06-25 18:20:32.609560
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1: Check when environment variable is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/user/.config/httpie'
    path_1 = get_default_config_dir()

# Generated at 2022-06-25 18:20:36.215326
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        config = Config()
        config.ensure_directory()
    except OSError as e:
        assert e.errno == errno.EEXIST

# Generated at 2022-06-25 18:20:39.550440
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # for base_config_dir = config_dir = Path().home()
    config = Config(Path().home())
    config['default_options'] = []
    config.save()
    config.delete()



# Generated at 2022-06-25 18:20:51.799148
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_file_path = Path(__file__).parent / 'test' / 'test_save' / 'test_save.txt'
    temp = BaseConfigDict(temp_file_path)
    temp['key1'] = 'value1'
    temp['key2'] = 'value2'
    temp.save()
    temp2 = BaseConfigDict(temp_file_path)
    temp2.load()
    assert temp2['key1'] == 'value1'
    assert temp2['key2'] == 'value2'
    assert temp2['__meta__']['httpie'] == '2.2.0'


# Generated at 2022-06-25 18:21:02.235561
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from pathlib import Path
    from os import environ
    from httpie import compat
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Case 0: No ENV_HTTPIE_CONFIG_DIR and no ENV_XDG_CONFIG_HOME
    # expected: $HOME/.config/httpie  
    del environ[ENV_HTTPIE_CONFIG_DIR]
    del environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / 'httpie'

    # Case 1: No ENV_HTTPIE_CONFIG_DIR, but ENV_XDG_CONFIG_HOME set to '/tmp'
    # expected: '/tmp/

# Generated at 2022-06-25 18:21:11.443336
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Path to config dir that doesn't exist
    directory_path = path_0 / "test_directory"
    directory_path.mkdir(parents=True, exist_ok=True)

    config_file_path = directory_path / "test_config_file.json"

    # Create a config file that doesn't exist
    if not config_file_path.exists():
        config_file = BaseConfigDict(config_file_path)
        config_file['key'] = "value"
        config_file.save(fail_silently=True)
    else:
        raise FileExistsError(f"File {config_file_path} already exists")

    # Check that file is saved
    assert(True == config_file_path.exists())

    # Remove that path
    directory_path.rmdir()




# Generated at 2022-06-25 18:21:21.032590
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import sys
    import os

    # Case 0: Windows
    if sys.platform == 'win32':
        assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)

    # Case 1: Legacy config file
    assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)

    # Case 2: $HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'HTTPIE_CONFIG_DIR'
    assert str(get_default_config_dir()) == 'HTTPIE_CONFIG_DIR'



# Generated at 2022-06-25 18:21:22.567115
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert(config_dir)

# Generated at 2022-06-25 18:21:24.620906
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.parent.exists()



# Generated at 2022-06-25 18:21:30.240396
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = './'
        assert DEFAULT_CONFIG_DIR == Path('./')
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/'
        assert DEFAULT_CONFIG_DIR == Path('/tmp/')
    except Exception as e:
        print(f'Test failed: {e}')
        return False
    else:
        return True

# Generated at 2022-06-25 18:21:38.722696
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from unittest import mock
    from httpie.config import BaseConfigDict
    from httpie.config import ConfigFileError
    import os
    import errno
    from httpie.compat import is_windows
    config = BaseConfigDict('abc')
    with mock.patch.object(os, 'makedirs') as mock_makedirs:
        try:
            config.ensure_directory()
        except ConfigFileError:
           pass
        mock_makedirs.assert_called_with(mode=0o700, parents=True)


# Generated at 2022-06-25 18:21:42.170589
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    test_1 = BaseConfigDict(path=path_1.parent / 'test_1.json')
    return test_1.save()


# Generated at 2022-06-25 18:21:52.054417
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.path.exists('/etc/xdg') is False and is_windows is False:
        assert get_default_config_dir() == Path('/home/test/.config/httpie')
    elif is_windows is True:
        assert get_default_config_dir() == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir() == Path('/etc/xdg/httpie')


# Generated at 2022-06-25 18:22:02.921062
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    del os.environ[ENV_XDG_CONFIG_HOME]
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        assert(get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR)
    else:
        assert(get_default_config_dir() == DEFAULT_CONFIG_DIR)


# Generated at 2022-06-25 18:22:05.830454
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 0
    assert os.path.expanduser('~/.config/httpie') == get_default_config_dir()



# Generated at 2022-06-25 18:22:11.368230
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create config file object
    testPath = Path("test")
    data = {'test': 1}
    testFile = BaseConfigDict(testPath)
    testFile.update(data)
    testFile.save()

    # read config file
    with testPath.open('r') as reader:
        dataFile = json.loads(reader.read())

    # assert
    assert '__meta__' in dataFile
    assert 'httpie' in dataFile['__meta__']
    assert dataFile['__meta__']['httpie'] == __version__
    assert data == dataFile


# Generated at 2022-06-25 18:22:17.892570
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_path = DEFAULT_CONFIG_DIR
    try:
        config_path.parent.mkdir(mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise ConfigFileError(f'cannot read config file: {e}')



# Generated at 2022-06-25 18:22:19.466038
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import pytest
    get_default_config_dir()
    assert True
    #assert False


# Generated at 2022-06-25 18:22:27.082412
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    Input:
    {
        "key_0": "value_0",
        "key_1": "value_1"
    }
    Expected:
    {
        "__meta__": {
            "httpie": "x.x.x"
        },
        "key_0": "value_0",
        "key_1": "value_1"
    }
    """
    config_path = Path(os.getcwd()) / 'config.json'
    config_dict = BaseConfigDict(config_path)

    config_dict.update({
        "key_0": "value_0",
        "key_1": "value_1"
    })

    config_dict.save()

    result_config_dict = {}


# Generated at 2022-06-25 18:22:30.961735
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_BaseConfigDict_load_0()
    test_BaseConfigDict_load_1()
    test_BaseConfigDict_load_2()


# Generated at 2022-06-25 18:22:33.297113
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_test = BaseConfigDict('temp.json')
    config_test.ensure_directory()
    config_test.delete()


# Generated at 2022-06-25 18:22:36.025349
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    d_0 = BaseConfigDict(path_0)
    
    d_0['name'] = 'hello'
    d_0.save()



# Generated at 2022-06-25 18:22:37.877642
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save(fail_silently=False)


# Generated at 2022-06-25 18:22:53.302403
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = '/home/sami/.config/httpie'
    path_1 = get_default_config_dir()
    if path_0 == path_1:
        print("get_default_config_dir() function is working. Test 1 passed")
    else:
        print("get_default_config_dir() function is not working. Test 1 failed")



# Generated at 2022-06-25 18:23:03.472589
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_d = get_default_config_dir()
    config_d.mkdir(mode=0o700, parents=True)
    path_0  = config_d / 'config.json'
    default_c = BaseConfigDict(path_0)
    default_c.ensure_directory()
    #case:1
    try:
        with path_0.open('rt') as f:
            data = json.load(f)
            default_c.update(data)
    except IOError as e:
            if e.errno != errno.ENOENT:
                raise ConfigFileError(f'cannot read config file: {e}')
    assert default_c.is_new() == False
    #case:2

# Generated at 2022-06-25 18:23:07.984453
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    #TODO: fix this
    pass
#    try:
#        os.rmdir(str(DEFAULT_CONFIG_DIR))
#    except OSError:
#        pass
#
#    c = BaseConfigDict(str(DEFAULT_CONFIG_DIR/ 'config.json'))
#    assert c.ensure_directory()
#    assert os.path.isdir(str(DEFAULT_CONFIG_DIR))
#    try:
#        os.rmdir(str(DEFAULT_CONFIG_DIR))
#    except OSError:
#        pass

# Generated at 2022-06-25 18:23:09.525070
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/travis/.config/httpie')

# Generated at 2022-06-25 18:23:10.934039
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()

# Generated at 2022-06-25 18:23:13.454537
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    bcd = BaseConfigDict(path=path_0)
    bcd.ensure_directory()

# Generated at 2022-06-25 18:23:15.037218
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_case_0()
    print("test case 0 passed")

# Generated at 2022-06-25 18:23:17.214233
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    obj_0 = BaseConfigDict('../httpie/config.json')
    obj_0.save()


# Generated at 2022-06-25 18:23:21.486950
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('test_config.json')
    bcd = BaseConfigDict(path)
    bcd.save({'test': ['a','b']})
    assert bcd['test'] == ['a','b']
    bcd.load()
    assert bcd['test'] == ['a','b']
    os.remove(path)


# Generated at 2022-06-25 18:23:31.115477
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    # Verifying the return type of get_default_config_dir()
    path_0 = get_default_config_dir()
    assert type(path_0) == Path
    # Verifying the case when environment variable HTTPIE_CONFIG_DIR is explicitly set

# Generated at 2022-06-25 18:23:41.949656
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    baseconfigdict=BaseConfigDict(Path)
    baseconfigdict.save()

if __name__ == "__main__":
    test_case_0()
    test_BaseConfigDict_save()

# Generated at 2022-06-25 18:23:44.514768
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    config_1.ensure_directory()
    config_1_path = config_1.path
    assert config_1_path.exists()
    config_1_parent = config_1_path.parent
    assert config_1_parent.stat().st_mode == 16895


# Generated at 2022-06-25 18:23:47.333876
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()
    assert config_0.is_new() == False
    config_0.delete()


# Generated at 2022-06-25 18:23:58.860405
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # When json file is empty
    data = {}
    with open('config_test.json','w') as f:
        json.dump(data,f)
    config_0 = Config('.')
    assert config_0.load() == None
    os.remove('config_test.json')
    # When json file is invalid
    with open('config_test.json','w') as f:
        print('}',file=f)
    config_1 = Config('.')
    try:
        config_1.load()
    except:
        assert True
        os.remove('config_test.json')
    else:
        assert False
    # When json file has some error
    os.chmod('.',0o200)

# Generated at 2022-06-25 18:24:08.338167
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().name == 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/'
    assert get_default_config_dir() == Path('/httpie')

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg_config_home'
    assert get_default_config_dir() == Path('/xdg_config_home/httpie')

    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == Path(str(Path.home()) + '/.config/httpie')

    os.environ.pop(ENV_XDG_CONFIG_HOME)


# Generated at 2022-06-25 18:24:09.810751
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert os.path.exists(config.path)


# Generated at 2022-06-25 18:24:11.093952
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)


# Generated at 2022-06-25 18:24:18.548494
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    print("httpie config dir is: " + str(config_dir))

# It is possible that ~/.config is not exist when test_case_1 is called
# The first run of test_case_1 will create config file and cause error
# 
# Run test_case_1 twice to avoid error

# Generated at 2022-06-25 18:24:26.506003
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Probably not in a directory named 'test'
    assert 'test' not in get_default_config_dir().as_posix()
    # Probably not in a directory named 'home'
    assert 'home' not in get_default_config_dir().as_posix()
    # Probably not in a directory named 'config'
    assert 'config' not in get_default_config_dir().as_posix()
    # Probably not in a directory named 'httpie'
    assert 'httpie' not in get_default_config_dir().as_posix()


# Generated at 2022-06-25 18:24:30.822987
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    try:
        config_1.ensure_directory()
    except Exception as e:
        print(e)

    # test for existing file instead of existing directory.
    config_2 = Config('config.json')
    try:
        config_2.ensure_directory()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:24:45.239737
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test Case 1: unset config file saving 
    config_1 = Config()
    assert config_1.is_new()

    # Test Case 2: set config file saving
    config_2 = Config(directory='./test')
    config_2['test'] = 1
    config_2.save()
    assert config_2.path.exists()



# Generated at 2022-06-25 18:24:51.859062
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("Testing get_default_config_dir")
    expected_dir = '/home/httpie/.config/httpie'
    if os.environ.get('HOME', None) != '/home/httpie':
        print("Test Case ignored: HOME != /home/httpie")
        return
    if os.environ.get('XDG_CONFIG_HOME', None) is not None:
        print("Test Case ignored: XDG_CONFIG_HOME is not None")
        return
    result_dir = get_default_config_dir()
    assert(expected_dir == str(result_dir))


# Generated at 2022-06-25 18:25:02.317478
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import unittest.mock as mock

    # Windows
    with mock.patch('httpie.config.is_windows', True):
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Not Windows
    with mock.patch('httpie.config.is_windows', False):
        with mock.patch('httpie.config.os.environ') as environ:
            with mock.patch('httpie.config.Path') as Path_:
                Path_.home.return_value = home_dir = Path('/home')

                # 1. explicitly set through env
                environ.get.return_value = env_config_dir = '/foo/bar'
                assert get_default_config_dir() == env_config_dir

                environ.get.return_value = None
                Path_.ex

# Generated at 2022-06-25 18:25:04.178349
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()


# Generated at 2022-06-25 18:25:08.731556
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-25 18:25:13.712012
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import pathlib
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as cdir:
        cdir = pathlib.Path(cdir)
        config_1 = Config(cdir)
        assert config_1.is_new()
        config_1.save(fail_silently=True)
        assert config_1.path.exists()
        assert config_1.path.stat().st_mode == 24576
        # Check to see if json is properly formatted.
        with config_1.path.open('rt') as f:
            lines = f.readlines()
        assert len(lines) == 5
        end_pos = lines[-1].find('\n')
        assert end_pos >= 0

# Generated at 2022-06-25 18:25:16.016891
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.getenv('APPDATA')) / 'httpie'


# Generated at 2022-06-25 18:25:18.070399
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.path.parent.exists()



# Generated at 2022-06-25 18:25:25.007634
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/path/to/config'
    assert get_default_config_dir() == Path('/path/to/config')

    # Delete variable from environment
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test case 2
    assert str(get_default_config_dir()) == 'C:\\Users\\user\\AppData\\Roaming\\httpie'