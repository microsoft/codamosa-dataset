

# Generated at 2022-06-25 18:15:45.844729
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Ensure directory created
    path = '/tmp/httpietest/'
    dir = os.path.dirname(path) 
    if not os.path.isdir(dir):
        os.makedirs(dir)
    config_file = open(path, 'w')
    config_file.close()

    # Test passes if config file from path is removed
    try:
        os.remove(path)
    except OSError as e:
        print ("Error: %s - %s." % (e.filename, e.strerror))


# Generated at 2022-06-25 18:15:53.883393
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_path = Path("/tmp/httpie-config-test/test")
    temp_path.parent.mkdir(exist_ok=True)

    test_config = BaseConfigDict(path=temp_path)
    assert temp_path.parent.exists()
    test_config.ensure_directory()
    assert temp_path.parent.exists()

    test_config.path.unlink()
    test_config.path.parent.rmdir()

# Generated at 2022-06-25 18:16:01.024343
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # get default config directory using environment variable
    env_0 = os.environ
    if ENV_HTTPIE_CONFIG_DIR in env_0:
        os.environ = os.environ.copy()
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    # get default config directory using environment variable
    path_0 = get_default_config_dir()
    path_1 = path_0 / 'aaa' / 'bbb'
    dir_c = path_1.parent
    dir_c.mkdir(parents=True)
    config_0 = BaseConfigDict(path = path_1)
    # save to file
    config_0.save()
    assert path_1.exists()
    assert path_1.is_dir() == False

    # get default config directory using environment

# Generated at 2022-06-25 18:16:07.542683
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class testConfigDict(BaseConfigDict):
        FILENAME = 'config.json'
        DEFAULTS = {
            'default_options': []
        }

    path_0 = Path('/tmp/test')
    config_dict = testConfigDict(path_0)

    config_dict.save()
    assert os.path.exists(path_0)


# Generated at 2022-06-25 18:16:12.662305
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_test = get_default_config_dir()
    config_test = Config(path_test)
    config_test_copy = Config(path_test)
    config_test.save()
    config_test_copy.load()
    assert config_test == config_test_copy
    os.remove(get_default_config_dir() / 'config.json')



# Generated at 2022-06-25 18:16:20.349276
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    temp_env = os.environ.copy()

    # Case 0: Windows
    os.environ = {
        'XDG_CONFIG_HOME': None,
        'HTTPIE_CONFIG_DIR': None
    }
    os.environ['XDG_CONFIG_HOME'] = None
    os.environ['HTTPIE_CONFIG_DIR'] = None
    path_0 = get_default_config_dir()
    assert path_0 == r'C:\Users\zhaohaodang\AppData\Roaming\httpie'

    # Case 1: Explicit HTTPIE_CONFIG_DIR
    os.environ['HTTPIE_CONFIG_DIR'] = '/tmp/httpie'
    path_1 = get_default_config_dir()
    assert path_1 == Path('/tmp/httpie')

    #

# Generated at 2022-06-25 18:16:30.603472
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = '/tmp/config_test/'
    try:
        os.makedirs(path_0, mode=0o777)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    path_1 = path_0 + '/' + 'a.json'
    dict_0 = {
            'name': 'test1',
            'sex': 'man'
    }
    config_0 = BaseConfigDict(path_1)
    config_0.update(dict_0)
    config_0.save(fail_silently=False)



# Generated at 2022-06-25 18:16:31.879235
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass



# Generated at 2022-06-25 18:16:37.088898
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import BaseConfigDict
    from pathlib import Path
    from unittest.mock import patch
    from os import makedirs

    ex = {'path': Path('test/testfile.json')}
    with patch('os.makedirs'):
        BaseConfigDict(**ex).ensure_directory()


# Generated at 2022-06-25 18:16:48.791682
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    
    config_dic = {'aaa': 'aaa'}
    filename = 'test_data.json'
    path = Path(filename)
    path.write_text('initial content')
    assert path.stat().st_size == 15
    
    
    bcd = BaseConfigDict(path)
    bcd.update(config_dic)
    bcd.save()
    assert path.stat().st_size == 24
    with open(filename) as json_file:
        data = json.load(json_file)
        assert data == bcd
    
    bcd['aaa'] = 'bbb'
    bcd.save()
    assert path.stat().st_size == 23
    with open(filename) as json_file:
        data = json.load(json_file)
       

# Generated at 2022-06-25 18:17:03.283939
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import platform
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from uuid import uuid4

    config_dir = get_default_config_dir()
    assert Path(config_dir) == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    temp_dir = TemporaryDirectory()
    os.environ[ENV_XDG_CONFIG_HOME] = temp_dir.name

    config_dir = get_default_config_dir()
    assert config_dir == Path(temp_dir.name) / DEFAULT_CONFIG_DIRNAME

    win_config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    random_str = str(uuid4())

# Generated at 2022-06-25 18:17:10.719723
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json

    temp_filename = tempfile.mktemp()
    with open(temp_filename, "w") as f:
        json_str = '{"name": "Alice", "age": 20}'
        f.write(json_str)
    
    path_0 = Path(temp_filename)
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()
    assert base_config_dict_0['age'] == 20

    os.remove(temp_filename)

# Generated at 2022-06-25 18:17:14.903952
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('./data/BaseConfigDict/load.json')
    base_config_dict = BaseConfigDict(path)
    base_config_dict.load()
    assert base_config_dict['__meta__']['httpie'] == '1.0.0'
    path.unlink()



# Generated at 2022-06-25 18:17:22.289842
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Path to which the config file is to be saved
    path = Path('/tmp/httpie')
    # Non-existing path on which to test
    path_for_test = path / 'unit_test'
    # Data to be saved
    data = {'field1': 'value1', 'field2': 'value2'}

    base_config_dict = BaseConfigDict(path_for_test)

    # Case where the path does not exist
    with pytest.raises(ConfigFileError):
        base_config_dict.load()

    # Case where the file is present but has invalid json
    with path.open('wt') as f:
        f.write('{"field1:}')
    with pytest.raises(ConfigFileError):
        base_config_dict.load()
    path.unlink()



# Generated at 2022-06-25 18:17:24.506925
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_config_dir = get_default_config_dir()
    test_config_dir.exists()


# Generated at 2022-06-25 18:17:33.682727
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(
        'os.environ',
        {ENV_HTTPIE_CONFIG_DIR: '/httpie/config/dir'},
        clear=True):
        assert get_default_config_dir() == Path('/httpie/config/dir')
    with mock.patch('httpie.config.is_windows', return_value=True):
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    with mock.patch(
        'httpie.config.Path.home', return_value=Path('/home/dummy')
    ), mock.patch('httpie.config.is_windows', return_value=False):
        assert get_default_config_dir() == Path(
            '/home/dummy/.config/httpie')



# Generated at 2022-06-25 18:17:38.475733
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.save()


# Generated at 2022-06-25 18:17:40.253930
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert isinstance(path, Path)


# Generated at 2022-06-25 18:17:49.935615
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    This test should pass if get_default_config_dir function works as expected
    """
    # clean the enviroment
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    if ENV_XDG_CONFIG_HOME in os.environ:
        del os.environ[ENV_XDG_CONFIG_HOME]
    # test case 1: no env defined
    path_1 = get_default_config_dir()
    assert path_1 == Path.home() / '.config/httpie'
    # test case 2: $HTTPIE_CONFIG_DIR defined
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "abcd"
    path_2 = get_

# Generated at 2022-06-25 18:17:55.601569
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    expected_0 = {'key1':'value1', 'key2':'value2'}
    base_config_dict_0 = BaseConfigDict('test_BaseConfigDict_load.json')
    with open('test_BaseConfigDict_load.json', 'wt') as fout:
        json.dump(expected_0, fout)
    base_config_dict_0.load()
    actual = base_config_dict_0
    assert expected_0 == actual


# Generated at 2022-06-25 18:18:02.672334
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()


# Generated at 2022-06-25 18:18:08.949424
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)

    # Test the if condition
    base_config_dict_0.is_new = lambda: False
    base_config_dict_0.__getitem__ = lambda self, x: "string"
    try:
        base_config_dict_0.save()

    except IOError:
        pass


# Generated at 2022-06-25 18:18:11.633206
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()

# Generated at 2022-06-25 18:18:15.163936
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    test_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    test_path = get_default_config_dir()
    assert test_path == test_config_dir


# Generated at 2022-06-25 18:18:18.923618
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()
    print(base_config_dict_0.path)


# Generated at 2022-06-25 18:18:21.972258
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-25 18:18:28.564022
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    file_path = Path('tmp_save.json')
    if file_path.exists():
        file_path.unlink()
    config_0 = BaseConfigDict(file_path)
    config_0.save()
    assert file_path.exists()
    data = json.loads(file_path.read_text())
    assert data['__meta__']
    assert data['__meta__']['httpie'] == __version__
    file_path.unlink()


# Generated at 2022-06-25 18:18:31.166429
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load() # This method would display the config.json file content if available


# Generated at 2022-06-25 18:18:39.010465
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # XDG Base Directory Specification
    assert get_default_config_dir() == Path(Path.home()).joinpath('.config').joinpath(DEFAULT_CONFIG_DIRNAME)

    # Windows
    assert get_default_config_dir() == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

    # Legacy
    assert get_default_config_dir() == Path.home().joinpath(DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)


# Generated at 2022-06-25 18:18:48.086966
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # first set XDG_CONFIG_HOME to env_config_dir
    # env_config_dir isn't set
    # return path from DEFAULT_WINDOWS_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/home/test1"
    path_1 = get_default_config_dir()
    assert path_1 == Path('/home/test1')

    # set XDG_CONFIG_HOME to env_config_dir
    # env_config_dir is set
    # return path from env_config_dir
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/home/test2"
    path_2 = get_default_config_dir()
    assert path_2 == Path('/home/test2')

    # set XDG_CONFIG_

# Generated at 2022-06-25 18:19:02.395524
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test get_default_config_dir()

    """
    import os

    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / 'config')
    assert get_default_config_dir() == Path('~/config/httpie')

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / 'config')
    assert get_default_config_dir() == Path('~/config')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('~/.config/httpie')

# Generated at 2022-06-25 18:19:13.505079
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # When neither $HTTPIE_CONFIG_DIR nor $XDG_CONFIG_HOME is set,
    # get_default_config_dir returns the default.
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # The function also uses $XDG_CONFIG_HOME.
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME

    # The function also uses $HTTPIE_CONFIG_DIR.
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/my-dir'
    assert get_default_config_dir() == Path('/tmp/my-dir')



# Generated at 2022-06-25 18:19:16.781148
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_path = Path(
        os.path.expandvars(
            '%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

    if is_windows:
        assert get_default_config_dir() == expected_path
    else:
        assert get_default_config_dir() != expected_path

# Generated at 2022-06-25 18:19:18.097794
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path('.config') / 'httpie'

# Generated at 2022-06-25 18:19:20.736929
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a new BaseConfigDict
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    # Call the save method
    try:
        base_config_dict_0.save()
        assert False
    except ConfigFileError:
        assert True

# Generated at 2022-06-25 18:19:31.167727
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 0: Windows
    os.environ['SystemRoot'] = 'WINDOWS'
    path_0 = get_default_config_dir()
    if path_0 != Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME:
        raise Exception(f'Test case 0 failed: {path_0}')
    del os.environ['SystemRoot']

    # Case 1: Linux
    path_1 = get_default_config_dir()
    if path_1 != Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME:
        raise Exception(f'Test case 1 failed: {path_1}')

    # Case 2: Linux with XDG_CONFIG_HOME defined

# Generated at 2022-06-25 18:19:37.026494
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Test 1: HTTPIE_CONFIG_DIR not set
    assert get_default_config_dir() == Path('.config/httpie')

    # Test 2: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)


# Generated at 2022-06-25 18:19:39.940297
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    print("Path to config dict: ", path_0)
    base_config_dict_0.save()


# Generated at 2022-06-25 18:19:44.557173
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.save()
    except EnvironmentError as exception:
        assert False


# Generated at 2022-06-25 18:19:54.550567
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    
    # Test 1
    assert is_windows == False
    assert ENV_HTTPIE_CONFIG_DIR in os.environ
    assert ENV_XDG_CONFIG_HOME in os.environ
    assert os.environ[ENV_HTTPIE_CONFIG_DIR] == '/home/ubuntu/.httpie'
    assert os.environ[ENV_XDG_CONFIG_HOME] == '/home/ubuntu/.config/httpie/'
    assert DEFAULT_CONFIG_DIRNAME == 'httpie'
    assert DEFAULT_RELATIVE_XDG_CONFIG_HOME == Path('.config')
    assert DEFAULT_RELATIVE_LEGACY_CONFIG_DIR == Path('.httpie')

# Generated at 2022-06-25 18:20:10.209883
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    print(default_config_dir)


# Generated at 2022-06-25 18:20:15.548666
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tempdir = Path(tempfile.mkdtemp())
    path_0 = tempdir / 'config.json'
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()
    assert path_0.exists()
    os.system('rm -rf ' + str(tempdir))



# Generated at 2022-06-25 18:20:19.069483
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()


# Generated at 2022-06-25 18:20:20.675248
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test the default value of the second parameter
    test_case_0()


# Generated at 2022-06-25 18:20:22.179335
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == "/home/hanhan/Desktop/.config/httpie"


# Generated at 2022-06-25 18:20:33.640480
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a directory for testing
    test_dir = Path.home() / 'test'
    test_dir.mkdir(0o700, parents=True)

    test_config_file_name = test_dir / 'config'
    test_config_file = test_config_file_name.open('w')
    test_config_file.write('{}')
    test_config_file.close()

    # Test case: Load a non-existent config file
    base_config_dict = BaseConfigDict(test_dir / 'non-existent-file')
    config_dict = base_config_dict.copy()
    base_config_dict.load()
    assert base_config_dict == config_dict

    # Test case: Load an empty config file

# Generated at 2022-06-25 18:20:42.045133
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows():
        path = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        path = Path(os.getenv(ENV_XDG_CONFIG_HOME)) / DEFAULT_CONFIG_DIRNAME
        if not path.exists():
            path = Path(Path.home()) / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == path



# Generated at 2022-06-25 18:20:43.524169
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.environ["HOME"]) / ".config" / "httpie"

# Generated at 2022-06-25 18:20:50.362432
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch('httpie.config.os.environ', {'XDG_CONFIG_HOME': '/test'}):
        assert get_default_config_dir() == Path('/test/httpie')
    with mock.patch('httpie.config.is_windows', True):
        assert get_default_config_dir() == Path('C:\\Users\\defaultuser\\AppData\\Roaming\\httpie')
    with mock.patch('httpie.config.is_windows', False):
        assert get_default_config_dir() == Path('/home/defaultuser/.config/httpie')

# Generated at 2022-06-25 18:20:55.381796
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Purpose: Checks if the function get_default_config_dir returns the same value
        before and after the function is invoked
    Expect:  Returns the same value
    :return: None
    """
    current_path = get_default_config_dir()
    get_default_config_dir()
    assert current_path == get_default_config_dir()



# Generated at 2022-06-25 18:21:31.745475
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0['__'] = __
    base_config_dict_0.save()
    assert path_0.joinpath(BaseConfigDict.FILENAME).read_text() == "{\n    \"__\": \"<module '__main__' (built-in)>\"\n}\n"
    assert path_0.exists()
    base_config_dict_0.delete()
    assert path_0.joinpath(BaseConfigDict.FILENAME).exists() == False


# Generated at 2022-06-25 18:21:32.275615
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert True

# Generated at 2022-06-25 18:21:37.744183
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    try:
        base_config_dict_0 = BaseConfigDict(Path(".httpie/config.json"))
        base_config_dict_0.save()
    except TypeError as e:
        print("TypeError:", e)
    except ConfigFileError as e:
        print("ConfigFileError:", e)


# Generated at 2022-06-25 18:21:42.970392
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os.path
    import os
    base_config_dict_1 = BaseConfigDict("Output")
    base_config_dict_1.save()
    assert os.path.exists(base_config_dict_1.path)==True
    base_config_dict_1.delete()


# Generated at 2022-06-25 18:21:54.947826
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ
    env['XDG_CONFIG_HOME'] = os.path.expanduser('~/.config')
    path_1 = get_default_config_dir()
    assert(path_1 == Path('.config/httpie'))
    env['XDG_CONFIG_HOME'] = os.path.expanduser('~/config')
    path_2 = get_default_config_dir()
    assert(path_2 == Path('config/httpie'))
    env['HTTPIE_CONFIG_DIR'] = os.path.expanduser('~/httpie')
    path_3 = get_default_config_dir()
    assert(path_3 == Path('httpie'))
    del env['XDG_CONFIG_HOME']

# Generated at 2022-06-25 18:21:56.879445
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
  assert callable(get_default_config_dir)



# Generated at 2022-06-25 18:22:02.920782
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test for windows
    if is_windows():
        assert get_default_config_dir() == Path('C:\\Users\\Administrator\\AppData\\Roaming\\httpie\\config.json')
    # test for linux
    else:
        assert get_default_config_dir() == Path('/home/ding/.config/httpie/config.json')


# Generated at 2022-06-25 18:22:09.880758
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.about = ""
    base_config_dict_0.helpurl = ""
    base_config_dict_0.path = get_default_config_dir()
    base_config_dict_0.save()
    assert base_config_dict_0.path.exists()
    assert base_config_dict_0.path.is_file()
    base_config_dict_0.delete()


# Generated at 2022-06-25 18:22:21.304850
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    if sys.platform == 'linux' or sys.platform == 'darwin':
        tmp_dir_0 = Path('/tmp/tmp-httpie-XA1yVM')
        tmp_dir_0.mkdir(mode=0o700, parents=True)
    else:
        tmp_dir_0 = Path('C:\\Users\\Administrator\\AppData\\Local\\Temp\\tmp-httpie-XA1yVM')
        tmp_dir_0.mkdir(mode=0o700, parents=True)
    path_0 = tmp_dir_0 / 'config.json'
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()
    tmp_dir_0.rmdir()


# Generated at 2022-06-25 18:22:23.646109
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file_0 = Config()
    config_file_0.save(fail_silently=True)
    config_file_0.save(fail_silently=False)


# Generated at 2022-06-25 18:23:24.996644
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:23:35.332873
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    path_1 = Path('/home/user/.config/httpie')
    path_2 = Path('/home/user/.httpie')
    path_3 = Path(os.path.expandvars('%APPDATA%')) / 'httpie'

    # Case 1: $HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(path_1)
    assert get_default_config_dir() == path_1
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    # Case 2: ~/.httpie
    path_2.mkdir()
    assert get_default_config_dir() == path_2
    path_2.rmdir()

    # Case 3: $XDG_CONFIG_HOME/httpie
   

# Generated at 2022-06-25 18:23:37.016100
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert is_windows == (DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir())



# Generated at 2022-06-25 18:23:43.042634
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import copy
    import json
    import random
    import string
    random.seed(0)
    my_path_0 = os.path.join(tempfile.gettempdir(), ''.join(random.choices(string.ascii_letters + string.digits, k = 5)))
    config_0 = BaseConfigDict(my_path_0)
    tmp_0 = copy.deepcopy(config_0)
    config_0.save()
    tmp_1 = copy.deepcopy(config_0)
    assert tmp_0 == tmp_1


# Generated at 2022-06-25 18:23:54.640639
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR) is None
    assert not os.path.exists(str(DEFAULT_WINDOWS_CONFIG_DIR))
    assert not os.path.exists(str(DEFAULT_CONFIG_DIR))

    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    config_dir_1 = Path('./') / 'config-dir-1'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(config_dir_1)
    assert get_default_config_dir() == config_dir_1

    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(config_dir_1)

# Generated at 2022-06-25 18:23:58.554420
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        c = BaseConfigDict('/tmp/test.json')
        c.load()
    except ConfigFileError:
        assert True
    except:
        assert False


# Generated at 2022-06-25 18:24:05.716804
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_base_config_dict_instance_0 = BaseConfigDict(Path('test/test_config_httpie/config.json'))
    test_config_instance_0 = Config('test/test_config_httpie')
    assert test_config_instance_0.default_options == []
    test_config_instance_1 = Config('test/test_config_httpie')
    assert test_config_instance_1.default_options == []
    test_config_instance_2 = Config('test/test_config_httpie')
    assert test_config_instance_2.default_options == []


# Generated at 2022-06-25 18:24:09.091386
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)

    try:
        base_config_dict_0.save()
        assert False
    except ConfigFileError:
        assert True



# Generated at 2022-06-25 18:24:09.998258
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:24:12.269656
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    global DEFAULT_CONFIG_DIR
    DEFAULT_CONFIG_DIR = get_default_config_dir()
    assert isinstance(DEFAULT_CONFIG_DIR, Path)
    assert DEFAULT_CONFIG_DIR.exists()
