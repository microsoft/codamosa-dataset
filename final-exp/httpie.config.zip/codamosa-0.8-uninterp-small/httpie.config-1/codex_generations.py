

# Generated at 2022-06-25 18:15:29.534388
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = get_default_config_dir()
    test_config_dict = BaseConfigDict(path_1)
    test_config_dict.load()

# Generated at 2022-06-25 18:15:36.533459
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    # Assert that the file has been created and has the expected content
    assert Path(f'{str(DEFAULT_CONFIG_DIR)}/config.json').exists()
    with open(f'{str(DEFAULT_CONFIG_DIR)}/config.json') as config_file:
        config_file_content = config_file.read()
    with open('test_config.json') as test_config_file:
        test_config_file_content = test_config_file.read()
    assert config_file_content == test_config_file_content



# Generated at 2022-06-25 18:15:39.167361
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Config( directory=DEFAULT_CONFIG_DIR )
    config_dir.save()

# Generated at 2022-06-25 18:15:47.429626
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test cases:
    # 1. normal cases
    # 2. abnormal cases: default_options is not a list
    # 3. abnormal cases: default_options is not a dict

    # Test case 1
    data = {"default_options": []}
    test_cases = []
    for value in data.values():
        test_cases.append(value)
    test_BaseConfigDict_save_helper(test_cases)
    # Test case 2
    data = {"default_options": {"a": 1}}
    for value in data.values():
        with pytest.raises(Exception):
            test_BaseConfigDict_save_helper(value)



# Generated at 2022-06-25 18:15:49.641796
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'


# Generated at 2022-06-25 18:15:53.442904
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("Unit test: default config dir is " + str(get_default_config_dir()))
    assert get_default_config_dir() == Path('/home/gaoxiang/.config/httpie')



# Generated at 2022-06-25 18:16:00.794073
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    from pathlib import Path

    class BaseConfigDict_Fake(dict):
        """
        Fake BaseConfigDict class
        """
        name = None
        helpurl = None
        about = None

        def __init__(self, path: Path):
            super().__init__()
            self.path = path


    # Create a temporary directory for testing
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        assert d
        dir = Path(d)

        config = BaseConfigDict_Fake(path=dir / 'test.json')
        config['key_1'] = 'value_1'
        config['key_2'] = 'value_2'
        config.save(fail_silently=False)

        assert config.path.exists()

        # Check

# Generated at 2022-06-25 18:16:02.016298
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass

# Generated at 2022-06-25 18:16:12.554155
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        os.system('rm -rf ~/.httpie_test/config.json')
        path_0 = get_default_config_dir()
        path_1 = path_0.parent / '~' / '.httpie_test' / 'config.json'
        # Ensuring that no file exists
        assert not path_1.exists()
        dic_0 = BaseConfigDict(path_1)
        dic_0.ensure_directory()
        # Ensuring that the directory does exist
        assert path_1.parent.exists()
        os.system('rm -rf ~/.httpie_test')
    except PermissionError:
        print('Insufficient permission. Skipping the test.')


# Generated at 2022-06-25 18:16:18.196419
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()
    path_string = str(path_0)
    if path_string == str(Path().home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME):
        print("Pass test for get_default_config_dir()")
    else:
        print("Fail test for get_default_config_dir()")


# Generated at 2022-06-25 18:16:32.896663
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # Test for Windows
    else:
        # Test for ENV_HTTPIE_CONFIG_DIR
        os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home())
        assert get_default_config_dir() == Path.home()
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        # Test for ENV_HTTPIE_CONFIG_DIR
        # Test for ENV_XDG_CONFIG_HOME
        os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home())
        assert get_default_config_dir() == Path.home()

# Generated at 2022-06-25 18:16:44.568232
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # First set the environment variable HTTPIE_CONFIG_DIR to the value of
    # path_0
    path_0 = Path('./test_config_dir')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(path_0)
    assert get_default_config_dir() == str(path_0)

    # set the environment variable HTTPIE_CONFIG_DIR to empty
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ' '

    # set the environment variable XDG_CONFIG_HOME to the value of path_1
    if ENV_XDG_CONFIG_HOME in os.environ:
        del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-25 18:16:49.138533
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    path_0.mkdir(parents=True, exist_ok=True)
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


test_case_0()

# Generated at 2022-06-25 18:16:51.346936
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path.home()
    test = BaseConfigDict(path)
    test.save(fail_silently=True)


# Generated at 2022-06-25 18:16:53.754871
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict_0 = BaseConfigDict('./BaseConfigDictConfig.json')
    # The file does not exist yet
    base_config_dict_0.load()


# Generated at 2022-06-25 18:16:59.442805
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    path_1 = path_0.joinpath("test_BaseConfigDict")
    base_config_dict_0 = BaseConfigDict(path_1)
    base_config_dict_0.ensure_directory()
    # test the existence of the directory
    path_0.is_dir()

# Generated at 2022-06-25 18:17:09.977981
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home_dir = DEFAULT_RELATIVE_XDG_CONFIG_HOME.as_posix()
    os.environ[ENV_XDG_CONFIG_HOME] = xdg_config_home_dir
    # 1. explicitly set though env
    home_dir = Path.home()
    # default config dir
    default_config_dir = home_dir / xdg_config_home_dir
    assert get_default_config_dir() == default_config_dir
    assert os.environ[ENV_XDG_CONFIG_HOME] == default_config_dir.as_posix()

    # set ENV_HTTPIE_CONFIG_DIR = ~/.config
    os.environ[ENV_HTTPIE_CONFIG_DIR] = default_config_dir.as_

# Generated at 2022-06-25 18:17:12.416666
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert type(get_default_config_dir()) == Path
    assert str(get_default_config_dir()).endswith('httpie')


# Generated at 2022-06-25 18:17:20.684098
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1: In Windows
    os.environ['PATHEXT'] = '.COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.CPL;.HTA;.SCR'
    os.environ['HTTPIE_CONFIG_DIR'] = ''
    os.environ['XDG_CONFIG_HOME'] = ''
    expected_dir = str(Path.home() / Path('.config') / 'httpie').replace('\\', '/')
    assert expected_dir == str(get_default_config_dir()).replace('\\', '/')
    # Case 2: In Linux
    os.environ['PATHEXT'] = ''
    os.environ['HOME'] = '/Users/myname'

# Generated at 2022-06-25 18:17:31.955784
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from os.path import join
    from typing import Dict
    from typing import Any
    from json import dumps
    from httpie import __version__
    from httpie.config import BaseConfigDict
    from httpie.config import DEFAULT_CONFIG_DIR
    from os.path import exists
    from os import remove

    # Create a temporary directory in current working directory
    from tempfile import mkdtemp
    tmp_dir = mkdtemp()
    path = Path(join(tmp_dir, 'config.json'))
    base_config_dict_0 = BaseConfigDict(path)
    base_config_dict_0['__meta__'] = {'httpie': __version__}

# Generated at 2022-06-25 18:17:40.959170
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    json_string = json.dumps(
        obj=config,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    print(type(json_string))


# Generated at 2022-06-25 18:17:44.235236
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    abc = Path('/usr/bin')
    base_config_dict_0 = BaseConfigDict(abc)
    try:
        base_config_dict_0.ensure_directory()
    except:
        pass


# Generated at 2022-06-25 18:17:47.026597
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()
    assert path_0.exists()



# Generated at 2022-06-25 18:17:56.074821
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = Path('/tmp/httpie_test_BaseConfigDict_ensure_directory')
    path_1.mkdir(parents=True, exist_ok=True)
    with pytest.raises(ConfigFileError):
        path_1.mkdir(parents=True, exist_ok=True)

    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()

    path_2 = Path('/tmp/httpie_test_BaseConfigDict_ensure_directory/test')
    base_config_dict_2 = BaseConfigDict(path_2)
    base_config_dict_2.ensure_directory()

    shutil.rmtree(path_1)



# Generated at 2022-06-25 18:17:59.222182
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir().joinpath('test_ensure_directory')
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()
    path_0.parent.rmdir()


# Generated at 2022-06-25 18:18:05.045574
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = Path.home() / 'test_BaseConfigDict_load.json'
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1['test'] = True
    base_config_dict_1.save()
    base_config_dict_1.load()
    assert base_config_dict_1['test'] == True

# Generated at 2022-06-25 18:18:07.221125
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_output = Path(
        '/home/johndoe/.config/'
        'httpie'
    )
    assert(expected_output == get_default_config_dir())
# test_get_default_config_dir()


# Generated at 2022-06-25 18:18:16.174474
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Mock paths
    mock_default_config_dir = 'mock_config_dir'
    mock_default_xdg_config_home = 'mock_xdg_config_home'
    mock_home_dir = ''
    mock_app_data = ''

    # Paths
    path_0 = get_default_config_dir()

    # Test empty env
    os.environ.clear()
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR) == None

    # Test set env with 'set' command on windows
    os.environ.update(HTTPIE_CONFIG_DIR=mock_default_config_dir)
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR) == mock_default_config_dir

    # Test set env with 'export'

# Generated at 2022-06-25 18:18:23.728419
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dir_path = Path(__file__).parent
    path = test_dir_path / 'test_data' / 'test_save_data'
    assert path.is_dir()
    config_dict = BaseConfigDict(path / 'config.json')
    config_dict.load()
    assert config_dict['test_key'] == 'test_value'
    assert config_dict['test_key_2'] == 'test_value_2'


# Generated at 2022-06-25 18:18:31.772021
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test if the method of load function works when the file is missing
    path_1 = "test_filename.json"
    read_test_1 = BaseConfigDict(path_1)
    with pytest.raises(ConfigFileError):
        read_test_1.load()

    # Test if the method works when the file exists
    path_2 = "test_filename2.json"
    write_test_2 = BaseConfigDict(path_2)
    write_test_2.update({"test_data": 0})
    write_test_2.save()
    read_test_2 = BaseConfigDict(path_2)
    assert read_test_2.load() == {"test_data": 0}


# Generated at 2022-06-25 18:18:45.895020
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.load()
    except ConfigFileError:
        pass


# Generated at 2022-06-25 18:18:54.851731
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # on Windows it should be "%APPDATA%\httpie"
    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    # on other platforms it should be "$XDG_CONFIG_HOME/httpie" if it's defined, or "$HOME/.config/httpie" otherwise
    else:
        assert get_default_config_dir().name == DEFAULT_CONFIG_DIRNAME
        if ENV_XDG_CONFIG_HOME in os.environ:
            assert get_default_config_dir().parent == Path(os.environ[ENV_XDG_CONFIG_HOME])
        else:
            assert get_default_config_dir().parent.name == DEFAULT

# Generated at 2022-06-25 18:18:58.844899
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # /home/user/.config/httpie
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()
    assert base_config_dict_0 == {}


# Generated at 2022-06-25 18:19:06.400309
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path("~/.httpie/test_file.txt")
    base_config_dict = BaseConfigDict(path)

    # assert that the parent directory does not exist at the beginning
    assert not os.path.exists(path.parent)
    base_config_dict.ensure_directory()
    # assert that the parent directory exists after calling ensure_directory
    assert os.path.isdir(path.parent)
    # remove parent directory
    os.rmdir(path.parent)


# Generated at 2022-06-25 18:19:15.985690
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # check when windows
    assert is_windows == True
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # mock is_windows
    is_windows = False
    # check when xdg_config_home is None
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_RELATIVE_XDG_CONFIG_HOME
    # check when xdg_config_home is specified
    os.environ[ENV_XDG_CONFIG_HOME] = 'xdg_config_home'
    assert get_default_config_dir() == Path('xdg_config_home') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:19:18.444897
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()
    print(base_config_dict_0)



# Generated at 2022-06-25 18:19:29.990813
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    DEFAULT_CONFIG_DIR = get_default_config_dir()
    config_path = DEFAULT_CONFIG_DIR / 'config.json'
    base_config_dict_0 = BaseConfigDict(config_path)
    
    # Test if you can load existing file
    # Work as expected
    with open(config_path) as json_input:
        config_dict = json.load(json_input)
    
    base_config_dict_0.update(config_dict)
    assert base_config_dict_0 == config_dict

    # Test if can load empty file
    # it can load empty file, but won't change anything
    base_config_dict_1 = BaseConfigDict(config_path)
    base_config_dict_1.load()
    assert base_config_dict_1 == base

# Generated at 2022-06-25 18:19:35.787622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1['key_1'] = 'value_1'
    base_config_dict_1.save()

    path_2 = get_default_config_dir()
    base_config_dict_2 = BaseConfigDict(path_2)
    base_config_dict_2.load()

    assert base_config_dict_1 == base_config_dict_2



# Generated at 2022-06-25 18:19:41.029613
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_1 = get_default_config_dir()
    assert path_1 == '/home/travis/.config/httpie', \
    'test_case_1: get_default_config_dir fails'

    path_2 = get_default_config_dir()
    assert path_2 == '/home/travis/.config/httpie', \
    'test_case_2: get_default_config_dir fails'

    path_3 = get_default_config_dir()
    assert path_3 == '/home/travis/.config/httpie', \
    'test_case_3: get_default_config_dir fails'

    path_4 = get_default_config_dir()

# Generated at 2022-06-25 18:19:42.211566
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test number of arguments: 0, 1
    test_case_0()

# Generated at 2022-06-25 18:20:20.299777
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    # test_case_1
    base_config_dict_1.ensure_directory()
    # test_case_2
    base_config_dict_1.ensure_directory()
    # test_case_3
    base_config_dict_1.ensure_directory()



# Generated at 2022-06-25 18:20:23.942783
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    param0 = 'base_config_dict_1.save()'
    result0 = base_config_dict_1.save()
    assert type(result0) is None
    assert result0 is None
    assert True


# Generated at 2022-06-25 18:20:29.618764
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == Path(DEFAULT_WINDOWS_CONFIG_DIR)
    else:
        default_home_dir = Path.home()
        assert get_default_config_dir() == default_home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-25 18:20:34.024953
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory_name = "test_dir"
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()
    path_0 = get_default_config_dir()
    assert path_0.exists()
    path_0.rmdir()


# Generated at 2022-06-25 18:20:36.615030
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:20:45.969679
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    # Set up the test environment
    path_0 = DEFAULT_CONFIG_DIR
    path_0.mkdir(exist_ok = True)


    # Path to the file to be tested
    path_1 = path_0 / 'testfile.txt'

    # Initialize the object
    base_config_dict_0 = BaseConfigDict(path_1)

    # Initialize the data to be written
    data_0 = json.dumps({'default_options':['a', 'b', 'c']})


    # Call the method to be tested
    base_config_dict_0.save()


    # Check whether the data are written to the file correctly
    f = open(path_1, 'r')
    data_1 = f.read()
    f.close()
    assert data_0 == data_1

# Generated at 2022-06-25 18:20:56.415334
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Case when config file does not exist
    test_0 = BaseConfigDict(Path('/tmp'))
    assert not test_0.path.exists()
    assert not test_0.path.is_dir()
    test_0.ensure_directory()
    assert test_0.path.exists()
    assert test_0.path.is_dir()
    # Remove
    os.removedirs(test_0.path)

    # Case when config directory exists
    test_1 = BaseConfigDict(Path('/tmp'))
    Path('/tmp/test').mkdir(mode=0o700, parents=True)
    assert Path('/tmp/test').exists()
    assert Path('/tmp/test').is_dir()
    test_1.ensure_directory()

# Generated at 2022-06-25 18:21:07.280154
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from os import path
    from pathlib import Path
    from unittest.mock import Mock, call, patch
    
    # unit test for ensure_directory()
    path_0 = Path(path.join(path.expanduser("~"), "httpie"))
    base_config_dict_0 = BaseConfigDict(path_0)

    # Mock object for pathlib.Path.mkdir()
    mkdir_mock = Mock(side_effect = [OSError(errno.EEXIST), None])
    mkdir_patch = patch.object(Path, 'mkdir', mkdir_mock)

    with mkdir_patch:
        # Test case 0: Directory already exists
        base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:21:08.715622
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(DEFAULT_CONFIG_DIR)


# Generated at 2022-06-25 18:21:14.947641
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Config directory does not exist
    path_1 = Path('/config/dir/does/not/exist')
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.save()
    assert base_config_dict_1.path.exists()
    base_config_dict_1.delete()

    # Config file and directory exist
    path_2 = Path('/tmp/path/config.json')
    base_config_dict_2 = BaseConfigDict(path_2)
    base_config_dict_2.save()
    assert base_config_dict_2.path.exists()

    # Config file exists, directory does not
    path_3 = Path('/tmp/path/config.json')

# Generated at 2022-06-25 18:21:38.623398
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert get_default_config_dir() != Path('anywhere')
    assert get_default_config_dir() != Path('.')
    assert get_default_config_dir() != Path('..')

# Generated at 2022-06-25 18:21:48.233912
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    def get_default_config_dir_return_path(self):
        path = get_default_config_dir()
        self.assertIsInstance(path, Path)

    def get_default_config_dir_return_path_for_cfc(self):
        path = get_default_config_dir() / 'config.json'
        self.assertIsInstance(path, Path)

    def get_default_config_dir_return_path_for_cuc(self):
        path = get_default_config_dir() / 'cookies'
        self.assertIsInstance(path, Path)


# Generated at 2022-06-25 18:21:54.505354
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/test'
    assert get_default_config_dir() == Path('/test') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test'
    assert get_default_config_dir() == Path('/test')



# Generated at 2022-06-25 18:22:06.530086
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    path_1 = path_0.parent
    path_1.mkdir(mode=0o700, parents=False)
    assert path_1.exists()
    base_config_dict_0.ensure_directory()
    assert path_1.exists()
    path_2 = path_0.parent.parent
    path_2.mkdir(mode=0o700, parents=False)
    assert path_2.exists()
    base_config_dict_0.ensure_directory()
    assert path_2.exists()
    path_3 = path_0.parent.parent.parent
    path_3.mkdir(mode=0o700, parents=False)


# Generated at 2022-06-25 18:22:12.715134
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = Path("/test_1.json")
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()
    assert path_1.exists()
    path_1.unlink()

    path_2 = Path("/test_2.json")
    base_config_dict_2 = BaseConfigDict(path_2)
    base_config_dict_2.ensure_directory()
    assert path_2.exists()
    path_2.unlink()

    path_3 = Path("/test_3/test_3.json")
    base_config_dict_3 = BaseConfigDict(path_3)
    base_config_dict_3.ensure_directory()
    assert path_3.exists()


# Generated at 2022-06-25 18:22:13.412214
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:22:15.065029
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()

# Generated at 2022-06-25 18:22:24.080749
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # if xdg is not set, check that the expected config dir is created
    # In this case $XDG_CONFIG_HOME is not set
    # This may be done using a context manager
    # with mock.patch.dict(os.environ, {ENV_XDG_CONFIG_HOME: None}):
    # The env var is unset
    if ENV_XDG_CONFIG_HOME in os.environ:
        del os.environ[ENV_XDG_CONFIG_HOME]
    # Delete config dir recursively
    # so that we can check that it is created
    path = get_default_config_dir()
    if path.exists():
        shutil.rmtree(path)
    # Call BaseConfigDict.ensure_directory
    # to create config dir

# Generated at 2022-06-25 18:22:27.122552
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()

# Generated at 2022-06-25 18:22:33.010654
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    def test(data, expected):
        try:
            BaseConfigDict(path=path_0).load(data=data)
        except Exception as e:
            assert e.args == expected
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)


# Generated at 2022-06-25 18:23:02.662492
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Case 0
    path_0 = get_default_config_dir()
    print(path_0)
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()
    assert path_0.exists()

    # Case 1
    path_1 = Path('/tmp/httpie/test_config_ensure_directory')
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()
    assert path_1.exists()
    print(path_1)


# Generated at 2022-06-25 18:23:08.270504
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_dict = {'key1': 'val1',
                 'key2': 'val2',
                 'key3': 'val3'}
    test_json = json.dumps(test_dict,
                           indent=4,
                           sort_keys=True,
                           ensure_ascii=True)
    dir = Path('./')
    cfg = BaseConfigDict(dir / 'test.json')
    cfg.update(test_dict)
    cfg.save()
    json_file = open('test.json', 'r')
    json_file_content = json_file.read()
    assert(test_json == json_file_content)
    os.remove('test.json')



# Generated at 2022-06-25 18:23:11.465919
# Unit test for function get_default_config_dir

# Generated at 2022-06-25 18:23:19.548300
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ.copy()
    env[ENV_HTTPIE_CONFIG_DIR] = '/home/nico/config'
    path = get_default_config_dir(env)
    assert str(path) == 'Path(/home/nico/config)'

    path = get_default_config_dir({})
    assert str(path) == 'Path(/.config/httpie)'

    path = get_default_config_dir({ENV_XDG_CONFIG_HOME: '/etc/xdg2'})
    assert str(path) == 'Path(/etc/xdg2/httpie)'



# Generated at 2022-06-25 18:23:23.346599
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows case
    if is_WINDOWS:
        path = get_default_config_dir()
        assert path == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Mac/Linux cases
        path = get_default_config_dir()
        assert path == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:23:27.247638
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path

    path_1 = Path('/home/nakit/.config/httpie/config.json')
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()
    pass


# Generated at 2022-06-25 18:23:34.519531
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_path = Path('/home/zhaozhao/Work/httpie-1.0.1/httpie/tests/configs')
    test_path.mkdir(exist_ok=True)
    test_path = test_path / 'test.json'

    base_config_dict_0 = BaseConfigDict(test_path)
    base_config_dict_0['test'] = 'test'
    base_config_dict_0.save()

if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-25 18:23:43.136679
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test if it can save empty json file
    test_directory = Path('./test_output')
    config_test = Config(test_directory)
    config_test.save()
    assert test_directory.exists()
    assert (test_directory / 'config.json').exists()

    # Test if it can save json with contents
    config_test['key'] = 'value'
    config_test.save()
    assert json.loads((test_directory / 'config.json').read_text()) == {'key': 'value', 'default_options': []}
    assert json.loads((test_directory / 'config.json').read_text()).__contains__('key')
    assert json.loads((test_directory / 'config.json').read_text()).__contains__('default_options')

    # Test if

# Generated at 2022-06-25 18:23:47.044152
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()



# Generated at 2022-06-25 18:23:49.016338
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    BaseConfigDict(Path('config.json')).load()

# Generated at 2022-06-25 18:24:10.723248
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    assert False



# Generated at 2022-06-25 18:24:12.639315
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    assert base_config_dict_0.path.exists()


# Generated at 2022-06-25 18:24:17.593002
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = '/home/fj2/tests/.config/httpie/config.json'
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()

# Generated at 2022-06-25 18:24:21.853164
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_env = {
        'HOME': '/home/test',
        'XDG_CONFIG_HOME': '/home/test/.config'
    }
    path_0 = get_default_config_dir()
    assert path_0 == '/home/test/.config/httpie'
    test_env = {
        'HOME': '/home/test',
    }
    path_0 = get_default_config_dir()
    assert path_0 == '/home/test/.config/httpie'


# Generated at 2022-06-25 18:24:31.252810
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os

    # Test default return value of function
    default_config_dir = get_default_config_dir()
    assert(default_config_dir==Path(os.environ[ENV_XDG_CONFIG_HOME])/DEFAULT_CONFIG_DIRNAME)

    # Test that the value is correct if the environment variable $XDG_CONFIG_HOME is set
    os.environ[ENV_XDG_CONFIG_HOME] = "/test_path"
    assert(get_default_config_dir()==Path("/test_path")/DEFAULT_CONFIG_DIRNAME)

    # Test that the default value is returned if the environment variable $XDG_CONFIG_HOME is unset
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-25 18:24:37.202847
# Unit test for function get_default_config_dir

# Generated at 2022-06-25 18:24:41.681495
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    assert base_config_dict_0.load() == None 
    assert base_config_dict_0.get('__meta__') == {
        'httpie': __version__
        }



# Generated at 2022-06-25 18:24:43.666159
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("Testing function get_default_config_dir()")
    assert isinstance(get_default_config_dir(), Path)


# Generated at 2022-06-25 18:24:49.448787
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1
    if os.getenv(ENV_HTTPIE_CONFIG_DIR) is not None:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = ""

    def_config_dir_1 = get_default_config_dir()
    assert def_config_dir_1.exists() or def_config_dir_1.parts[-1] == ".config"

    # Test 2
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/config"
    def_config_dir_2 = get_default_config_dir()
    assert def_config_dir_2 == "/config"

    # Test 3

# Generated at 2022-06-25 18:24:59.804898
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # test without Env variable HTTPIE_CONFIG_DIR and XDG_CONFIG_HOME
    config_dir = get_default_config_dir()
    expected = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert type(config_dir) == Path
    assert config_dir == expected

    # test with Env variable HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    config_dir = get_default_config_dir()
    expected = Path('/tmp')
    assert type(config_dir) == Path
    assert config_dir == expected

    # test with Env variable XDG_CONFIG_HOME
    os.environ[ENV_HTTPIE_CONFIG_DIR]