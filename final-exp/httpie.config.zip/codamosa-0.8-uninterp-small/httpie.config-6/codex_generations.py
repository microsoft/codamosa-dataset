

# Generated at 2022-06-25 18:15:44.196657
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_dir = Path(__file__).parent
    # Mock config_dir_override in ENV
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(test_dir)
    config_0 = Config(test_dir)
    assert config_0.directory == test_dir

    # Clean up
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-25 18:15:47.254185
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tempdir = tempfile.TemporaryDirectory()
    path = os.path.join(tempdir.name, "fake_file")
    c = BaseConfigDict(path)
    c.ensure_directory()
    assert os.path.exists(c.path)



# Generated at 2022-06-25 18:15:49.404019
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = BaseConfigDict(path="test.json")
    config_1.ensure_directory()



# Generated at 2022-06-25 18:15:56.525949
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    home_dir = Path.home()
    default_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    config_path = default_config_dir / DEFAULT_CONFIG_DIRNAME / Config.FILENAME
    config = BaseConfigDict(config_path)
    try:
        config.ensure_directory()
        assert config_path.parent.exists()
    finally:
        config_path.parent.rmdir()


# Generated at 2022-06-25 18:15:58.239218
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print('======== Unit test result : get_default_config_dir() ========')
    print(get_default_config_dir())


# Generated at 2022-06-25 18:16:02.664762
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config_dir = config.directory
    if (config_dir/'__meta__').exists():
        print("folder already exists")
    else:
        config.ensure_directory()


# Generated at 2022-06-25 18:16:13.866637
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print ('Unit test for get_default_config_dir')
    print ('TEST CASE 1')
    print ('Default value of config directory is', DEFAULT_CONFIG_DIR)
    assert (DEFAULT_CONFIG_DIR == Path.home() / Path('.config') / Path('httpie'))
    print ('TEST CASE 2')
    print ('Overwrite default config directory by setting environment variable XDG_CONFIG_HOME')
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / Path('new_config'))
    config_dir = get_default_config_dir()
    assert (config_dir == Path.home() / Path('new_config') / Path('httpie'))
    print ('TEST CASE 3')

# Generated at 2022-06-25 18:16:15.364996
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    print(config_0)

# Generated at 2022-06-25 18:16:27.472481
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for the default case
    dir_0 = get_default_config_dir()
    assert dir_0 == Path('/home/farooq/.config/httpie')
    
    # Test for the case where $HTTPIE_CONFIG_DIR is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/farooq/.my_httpie'
    dir_1 = get_default_config_dir()
    assert dir_1 == Path('/home/farooq/.my_httpie')
    
    # Test for the case where $XDG_CONFIG_HOME is set
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/farooq/.my_xdg'
    xdg_config_home_dir = os.environ.get

# Generated at 2022-06-25 18:16:29.852190
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert DEFAULT_CONFIG_DIR == config_dir


# Generated at 2022-06-25 18:16:44.043387
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    if os.environ.get(ENV_HTTPIE_CONFIG_DIR):
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        if os.environ.get(ENV_XDG_CONFIG_HOME):
            del os.environ[ENV_XDG_CONFIG_HOME]

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'unit_test'
    assert get_default_config_dir() == 'unit_test'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == 'C:\\Users\\Administrator\\AppData\\Roaming\\httpie'



# Generated at 2022-06-25 18:16:45.653549
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:16:47.980388
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    conf = BaseConfigDict(Path(DEFAULT_CONFIG_DIR, 'config.json'))
    conf.save()



# Generated at 2022-06-25 18:16:51.754254
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    
    config_1=BaseConfigDict(path=Path('./conf.json'))
    config_1.ensure_directory()
    assert (config_1.path.parent.exists())
    config_1.path.parent.rmdir()


# Generated at 2022-06-25 18:16:52.113819
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
  pass


# Generated at 2022-06-25 18:16:53.434134
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    my_BaseConfigDict = BaseConfigDict('config.json')
    assert my_BaseConfigDict.save() == True


# Generated at 2022-06-25 18:16:58.450563
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = BaseConfigDict(Path.cwd() / 'config.json')
    config_1['default_options'] = []
    config_1['default_options'].append('--form')
    config_1['default_options'].append('--json')
    config_1.save()


# Generated at 2022-06-25 18:17:05.948895
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    os.environ[ENV_XDG_CONFIG_HOME] = '~'
    assert get_default_config_dir() == Path.home() / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:17:08.597764
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_path = Path.home() / ".config" / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == default_path


# Generated at 2022-06-25 18:17:12.141891
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config(directory="test_config_dir")
    config_0["test"] = "test_value"
    config_0.save(fail_silently=True)
    assert config_0["test"] == "test_value"


# Generated at 2022-06-25 18:17:16.301801
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    config_1.ensure_directory()


# Generated at 2022-06-25 18:17:18.003973
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / ".config" / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:17:29.616863
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: get_default_config_dir should return the XDG config directory
    # when the environment variable is set to such a directory.
    config_dir = 'test/test/test'
    os.environ[ENV_XDG_CONFIG_HOME] = config_dir
    assert get_default_config_dir() == Path(config_dir) / DEFAULT_CONFIG_DIRNAME
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    
    # Test 2: get_default_config_dir should return the XDG config directory
    # when the environment variable is not set.
    home_dir = os.getenv('HOME')
    assert get_default_config_dir() == Path(home_dir) / 'config' / DEFAULT_CONFIG_DIRNAME
    
    #

# Generated at 2022-06-25 18:17:32.151616
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_dict = BaseConfigDict(Path('/home/test/.httpie/config.json'))
    test_config_dict.save()


# Generated at 2022-06-25 18:17:33.605503
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-25 18:17:38.763384
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config = BaseConfigDict(path=Path('./test_case/test_case_1.json'))
    base_config.ensure_directory()
    assert base_config.path.parent.exists()


# Generated at 2022-06-25 18:17:47.823476
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Step 1:
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "./test"
    response_1 = get_default_config_dir()
    assert response_1 == "./test"
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Step 2:
    if is_windows:
        response_2 = get_default_config_dir()
        assert response_2 == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Step 3:
        response = get_default_config_dir()
        assert response == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

        # Step 4:

# Generated at 2022-06-25 18:17:53.726663
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert isinstance(path, Path)
    assert path == Path().home() / '.config' / 'httpie'
    assert path.exists()
    assert path.is_dir()
    assert path.parent.exists()
    assert path.parent.is_dir()
    assert path.parent.parent.exists()
    assert path.parent.parent.is_dir()


# Generated at 2022-06-25 18:17:55.880014
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = BaseConfigDict()
    config_0.path = Path('test_BaseConfigDict_load.json')
    config_0.load()


# Generated at 2022-06-25 18:17:58.168316
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

if __name__ == '__main__':
    test_case_0()
    test_get_default_config_dir()

# Generated at 2022-06-25 18:18:05.440705
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    os.rmdir(str(DEFAULT_WINDOWS_CONFIG_DIR))
    config_1 = Config()
    config_1.ensure_directory()
    assert(os.path.exists(DEFAULT_WINDOWS_CONFIG_DIR) == True)


# Generated at 2022-06-25 18:18:07.815038
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.path.parent.exists() is True


# Generated at 2022-06-25 18:18:10.946864
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    if config_0.ensure_directory():
        config_0.delete()
    else:
        raise PermissionError('')


# Generated at 2022-06-25 18:18:13.805248
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    rst = get_default_config_dir()
    assert path == rst


# Generated at 2022-06-25 18:18:19.864840
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dir_path = Path(os.path.split(os.path.abspath(__file__))[0])
    test_base_config_dict = BaseConfigDict(dir_path / 'test_base_config_dict.json')
    test_base_config_dict['__meta__'] = {
        'httpie': __version__
    }
    test_base_config_dict.save(fail_silently=False)
    test_base_config_dict.delete()

# Generated at 2022-06-25 18:18:23.860508
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print(f'\n1. Test get_default_config_dir(). \n')
    print(f'\tOutput is {get_default_config_dir()} \n')


# Generated at 2022-06-25 18:18:32.763751
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # On Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # On non-Windows

    # 1. explicitly set through env
    config_dir = get_default_config_dir()
    assert config_dir == Path('/tmp/config')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/config'

    # 2. legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/config/sub'
    config_path = Path('/home/user/.httpie')
    config_path.mkdir()
    assert get_default_config_dir() == config_path

# Generated at 2022-06-25 18:18:41.062069
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a test directory
    test_directory = Path('test_httpie')
    # Create a new config file in test directory
    config_file = test_directory / 'test_config.json'
    config_dict = BaseConfigDict(config_file)
    # Ensure test directory is created
    config_dict.ensure_directory()
    # Check if test directory exists
    assert os.path.exists(test_directory)
    # Delete test directory to clean up
    os.rmdir(test_directory)



# Generated at 2022-06-25 18:18:44.759847
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    filename = 'test.json'
    testconfig = BaseConfigDict(config.directory / filename)
    testconfig.ensure_directory()
    assert testconfig.path.parent == config.directory
    Path.unlink(testconfig.path)


# Generated at 2022-06-25 18:18:50.319222
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory = tempfile.TemporaryDirectory()
    directory_path = Path(directory.name)
    filename = 'test.config'
    path = directory_path / filename
    data_key = 'test_key'
    config = BaseConfigDict(path)
    try:
        config[data_key] = 'test_value'
        config.save()
        assert path.is_file()
        with path.open('r') as config_in:
            config_dict = json.load(config_in)
            assert data_key in config_dict.keys()
            assert config_dict[data_key] == 'test_value'
    finally:
        directory.cleanup()

# Generated at 2022-06-25 18:19:05.541324
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.getenv("XDG_CONFIG_HOME") is None:
        assert(not os.path.exists("~/.config/httpie"))
        assert(os.path.exists("~/.httpie"))
        assert(get_default_config_dir() == "~/.httpie")
    else:
        assert(os.path.exists("~/.config/httpie"))
        assert(not os.path.exists("~/.httpie"))
        assert(get_default_config_dir() == "~/.config/httpie")


# Generated at 2022-06-25 18:19:14.442884
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / ".config" / "httpie"
    os.environ[ENV_XDG_CONFIG_HOME] = "/tmp/foo"
    assert get_default_config_dir() == Path("/tmp/foo") / "httpie"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp/bar"
    assert get_default_config_dir() == Path("/tmp/bar")
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]


# Generated at 2022-06-25 18:19:25.050598
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    xdg_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # 0. legacy
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)

    assert get_default_config_dir() == legacy_config_dir

    legacy_config_dir.rmdir()

    # 0. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/where'
    assert get_default_config_dir() == Path

# Generated at 2022-06-25 18:19:31.168157
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_data_path = PurePath(os.path.dirname(__file__))
    config_test_file_path = test_data_path / "config_test.json"

    config = Config(directory=PurePath(os.path.dirname(__file__)))
    config.path = config_test_file_path
    config.load()
    assert config["default_options"] == ["--pretty=format", "--print=b"]

# Generated at 2022-06-25 18:19:36.277541
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    test_file_path = Path('BaseConfigDict_save_test')
    test_case = {"test":"save"}
    test_json_string = json.dumps(
            obj=test_case,
            indent=4,
            sort_keys=True,
            ensure_ascii=True,
        )
    test_file_path.write_text(test_json_string + '\n')
    test_file_path.unlink()


# Generated at 2022-06-25 18:19:38.739317
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir_path = get_default_config_dir()
    # print(default_config_dir_path)
    assert default_config_dir_path == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-25 18:19:41.391815
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert type(get_default_config_dir()) == Path



# Generated at 2022-06-25 18:19:44.229254
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    config_1['TestOption'] = 'TestValue'
    config_1.save()


# Generated at 2022-06-25 18:19:54.274671
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_path = Path('.httpie/config.json')
    def create_dir(dir):
        try:
            if not os.path.exists(dir):
                os.mkdir(dir)
        except OSError:
            print ("Creation of the directory %s failed" % dir)
        else:
            print ("Successfully created the directory %s " % dir)
    create_dir('.httpie')
    config_dict = {
        "default_options": [
            "--ignore-stdin",
            "--body",
            "--print bBhH"
        ],
        "__meta__": {
            "httpie": __version__
        }
    }

# Generated at 2022-06-25 18:20:01.938382
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_output = os.path.join(os.path.expanduser('~'), '.config/httpie')
    assert get_default_config_dir() == Path(expected_output)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'httpie-test'
    assert get_default_config_dir() == Path(expected_output)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'httpie-test'
    os.environ[ENV_XDG_CONFIG_HOME] = 'test'
    assert get_default_config_dir() == Path(expected_output)
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path(expected_output)

# Generated at 2022-06-25 18:20:09.422489
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    directory = get_default_config_dir()
    assert os.path.isdir(directory)
    assert directory.joinpath('config.json').exists()

# Generated at 2022-06-25 18:20:20.341861
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Verify that it returns the expected value given no environment variables
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Verify that it returns the expected value given an environment variable for
    # XDG config dir
    os.environ.update({
        'XDG_CONFIG_HOME': '/usr/local/etc'
    })
    assert get_default_config_dir() == Path('/usr/local/etc/httpie')

    # Verify that it returns the expected value given an environment
    # variable for httpie config dir
    os.environ.update({
        'HTTPIE_CONFIG_DIR': '/usr/local/etc/personal'
    })
    assert get_default_config_dir() == Path('/usr/local/etc/personal')

    # Verify that it returns the expected value given environment variables

# Generated at 2022-06-25 18:20:21.523998
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory = Path('test')
    assert directory.exists() == False


# Generated at 2022-06-25 18:20:22.650382
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()


# Generated at 2022-06-25 18:20:31.995794
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # This is the case to test for the usage in the final script
    # the XDG_CONFIG_HOME exists and is explicitly set
    XDG_CONFIG_HOME_dir = '/mnt/c/Users/andre/.config/httpie'
    try:
        os.environ[ENV_XDG_CONFIG_HOME] = XDG_CONFIG_HOME_dir
    except OSError as e:
        raise

    # the default config directory should be set to the XDG_CONFIG_HOME
    assert XDG_CONFIG_HOME_dir == get_default_config_dir()

    # check if the directory is valid
    assert os.path.exists(XDG_CONFIG_HOME_dir)



# Generated at 2022-06-25 18:20:33.566603
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_save = BaseConfigDict(Path('test'))
    test_save.save()

# Generated at 2022-06-25 18:20:37.053051
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path='config.json')
    isinstance(config_dict.save(), bool)



# Generated at 2022-06-25 18:20:41.834532
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict('./config.json')
    config_dict.save()
    # Try to save to a location without permissions
    config_dict = BaseConfigDict('/root/config.json')
    config_dict.save()


# Generated at 2022-06-25 18:20:47.869714
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.environ.get('XDG_CONFIG_HOME'):
        del os.environ['XDG_CONFIG_HOME']

    if is_windows:
        assert get_default_config_dir() == Path('%APPDATA%') / DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    os.environ['XDG_CONFIG_HOME'] = '/path/to/XDG_CONFIG_HOME'
    assert get_default_config_dir() == Path('/path/to/XDG_CONFIG_HOME') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:20:58.705297
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir()  # default httpie config dir without env
    assert get_default_config_dir() == get_default_config_dir()  # cache

    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''  # empty
    assert get_default_config_dir()

    os.environ[ENV_HTTPIE_CONFIG_DIR] = os.path.expanduser('~')  # exists
    assert get_default_config_dir()

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)  # restore
    if env_config_dir:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = env

# Generated at 2022-06-25 18:21:20.938634
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1
    # All environment variables are unset
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test 2
    xdg_config_home = Path.home() / 'test' / 'xdg_config_home'
    os.environ[ENV_XDG_CONFIG_HOME] = str(xdg_config_home)
    assert get_default_config_dir() == xdg_config_home / DEFAULT_CONFIG_DIRNAME

    # Test 3

# Generated at 2022-06-25 18:21:30.789759
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # test on Linux
    if not is_windows:
        # test on Linux
        # current user's home directory
        home_dir = os.path.expanduser('~')

        # the default environment variable $XDG_CONFIG_HOME
        xdg_config_dir = DEFAULT_RELATIVE_XDG_CONFIG_HOME

        # config directory (obtained through function get_default_config_dir)
        config_dir = home_dir + '/' + str(xdg_config_dir) + '/' + DEFAULT_CONFIG_DIRNAME

        # the default version of config directory (specified in the variable DEFAULT_CONFIG_DIR in the file config.py)
        default_config_dir = str(DEFAULT_CONFIG_DIR)

        # check whether the function get_default_config_dir can get the correct

# Generated at 2022-06-25 18:21:42.170112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        # XDG case is not supported on Windows
        default_config_dir = Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        assert get_default_config_dir() == default_config_dir
    else:
        # On Linux, the default config directory is
        #   $HOME/.config/httpie if $XDG_CONFIG_HOME is not set
        #   $XDG_CONFIG_HOME/httpie if $XDG_CONFIG_HOME is set
        home_dir = Path.home()
        default_xdg_config_home_dir = home_dir / '.config'
        default_config_dir = default_xdg_config_home_dir / 'httpie'
        assert get_default_config

# Generated at 2022-06-25 18:21:54.910591
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    d = {}
    d['__meta__'] = {'Httpie': __version__}
    d['help'] = 'https://httpie.org'
    d['about'] = 'https://github.com/jakubroztocil/httpie'
    d['default_options'] = []
    json_string = json.dumps(d)

    # Create test directory and test file
    dirTest = os.getcwd() + "/test/config_directory"
    fileTest = os.getcwd() + "/test/config_directory/config.json"
    if not os.path.exists(dirTest):
        os.makedirs(dirTest)
    f = open(fileTest, "w+")
    f.close()

    config_test = Config(dirTest)
    config_test.save()

# Generated at 2022-06-25 18:22:03.358565
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_dir = './.httpie'
    config_path = Path(test_dir) / 'config.json'
    if config_path.exists():
        print (f"[Warning] {config_path} already exists")
        print (f"          You might want to delete it manually before proceeding")
    else:
        print (f"          {config_path} is not found")
        print (f"          Proceeding to create a new file")

    bc = BaseConfigDict(config_path)
    bc.save()


# Generated at 2022-06-25 18:22:10.854555
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    #print('test case 0')
    #test_case_0()
    #print('test case 1')
    test_case_1()
    #print('test case 2')
    #test_case_2()
    #print('test case 3')
    test_case_3()
    #print('test case 4')
    test_case_4()
    #print('test case 5')
    #test_case_5()
    #print('test case 6')
    #test_case_6()
    #print('test case 7')
    test_case_7()
    #print('test case 8')
    #test_case_8()

# test case 1

# Generated at 2022-06-25 18:22:14.313469
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:22:20.069932
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test case 1:
    # os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    # os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    # config_1 = get_default_config_dir()
    # assert config_1.endswith('httpie')

    # test case 2:
    # os.environ[ENV_XDG_CONFIG_HOME] = '/home/user/.config'
    # config_2 = get_default_config_dir()
    # assert config_2.endswith('httpie')

    # test case 3:
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/user/.config/httpie'
    config_3 = get_default_config_dir()


# Generated at 2022-06-25 18:22:21.695928
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(DEFAULT_WINDOWS_CONFIG_DIR)



# Generated at 2022-06-25 18:22:27.653897
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if DEFAULT_CONFIG_DIR.exists():
        print(f'DEFAULT_CONFIG_DIR: {DEFAULT_CONFIG_DIR}')
        assert (DEFAULT_CONFIG_DIR.exists())
        assert isinstance(DEFAULT_CONFIG_DIR, Path)
        assert str(DEFAULT_CONFIG_DIR) == '/home/lab/.config/httpie'
    else:
        print('WARNING: config dir does not exist, defaults to XDG Base Directories')
        assert (DEFAULT_CONFIG_DIR) == Path('/home/lab/.config/httpie')
        assert str(DEFAULT_CONFIG_DIR) == '/home/lab/.config/httpie'
        


# Generated at 2022-06-25 18:23:01.035160
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    """Tests that function load in class BaseConfigDict raises the
    proper errors."""

    # File is not found
    config_0 = Config()
    config_0.load()
    assert config_0 == {}

    # File is not in json format
    config_1 = Config()
    with open(config_0.path, 'wt') as config_file:
        config_file.write('NOT JSON')
    try:
        config_1.load()
    except ConfigFileError as e:
        assert e.args[0] == "invalid config file: Expecting value: line 1 column 1 (char 0) [{}]".format(config_1.path)
    else:
        raise AssertionError('ConfigFileError not raised')


# Unit tests for method save of class BaseConfigDict

# Generated at 2022-06-25 18:23:06.662958
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    os.environ['XDG_CONFIG_HOME'] = 'XDG_CONFIG_HOME'
    os.environ['APPDATA'] = 'APPDATA'
    assert get_default_config_dir() == Path('XDG_CONFIG_HOME') / 'httpie'
    del os.environ['XDG_CONFIG_HOME']
    assert get_default_config_dir() == Path('APPDATA') / 'httpie'



# Generated at 2022-06-25 18:23:09.205071
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:23:19.590259
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # start with no env variables set
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    if ENV_XDG_CONFIG_HOME in os.environ:
        del os.environ[ENV_XDG_CONFIG_HOME]

    # test default path with env vars unset
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Linux and Mac
        assert get_default_config_dir() == (Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)

    # set config dir explicitly
    # os.environ[ENV_HTTPIE_

# Generated at 2022-06-25 18:23:22.557273
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR.name == DEFAULT_CONFIG_DIRNAME
    assert str(DEFAULT_CONFIG_DIR.parent) == DEFAULT_RELATIVE_XDG_CONFIG_HOME


# Generated at 2022-06-25 18:23:24.714863
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    b = BaseConfigDict(Path('test_file'))
    b.save()
    assert b.path.exists()
    b.path.unlink()


# Generated at 2022-06-25 18:23:35.036597
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Note: on a fresh, default system, ~/.config should already exist,
    # (and on Windows %APPDATA%/httpie should, too).
    get_default_config_dir()
    os.environ['XDG_CONFIG_HOME'] = '/tmp/.config'
    get_default_config_dir()
    os.environ['XDG_CONFIG_HOME'] = '/notexisting'
    get_default_config_dir()
    os.environ['XDG_CONFIG_HOME'] = '/tmp/.config'
    get_default_config_dir()
    os.environ['XDG_CONFIG_HOME'] = '/notexisting'
    os.environ['HTTPIE_CONFIG_DIR'] = '/tmp'
    get_default_config_dir()

# Generated at 2022-06-25 18:23:37.603813
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Unit test for get_default_config_dir
    """
    # 1. explicitly set through env
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()

# Generated at 2022-06-25 18:23:39.457186
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-25 18:23:40.867142
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(str(get_default_config_dir()) == 'C:\\Users\\xuey2\\.config\\httpie')

# Generated at 2022-06-25 18:24:27.392282
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    assert default_config_dir == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:24:35.280300
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class ConfigDict(BaseConfigDict):
        FILENAME = 'testConfigDict.json'
        DEFAULTS = {
            'data': [
                ['127.0.0.1', '8443', 'der', 'key.pem'],
                ['127.0.0.1', '8443', 'p12', 'cert.p12', 'key.p12'],
            ]
        }
    path = Path('/tmp').expanduser() / ConfigDict.FILENAME
    config_dict = ConfigDict(path)
    config_dict.save()
    assert config_dict.DEFAULTS['data'] == config_dict.load()
    path.unlink(missing_ok=True)

# Generated at 2022-06-25 18:24:37.335755
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir() == Path(os.path.expanduser("~/.config/httpie")))


# Generated at 2022-06-25 18:24:40.331465
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config(directory='../temp')
    try:
        config_1.save()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:24:43.591080
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict
    config_dict['test']={'test1':'test1','test2':'test2','test3':'test3','test4':'test4','test5':'test5'}
    config_dict.save()


# Generated at 2022-06-25 18:24:45.444853
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        config_0 = Config()
    except ConfigFileError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 18:24:54.904840
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows case 1, with env vars
    os.environ['HTTPIE_CONFIG_DIR'] = 'C:\\Users\\Test\\AppData\\Local\\httpie'
    assert get_default_config_dir() == Path('C:\\Users\\Test\\AppData\\Local\\httpie')

    # Windows case 2, without env vars
    os.environ['HTTPIE_CONFIG_DIR'] = ''
    assert get_default_config_dir() == Path('C:\\Users\\Test\\AppData\\Local\\httpie')

    # Legacy case 1, with env vars
    os.environ['HTTPIE_CONFIG_DIR'] = '/home/test/.httpie'
    assert get_default_config_dir() == Path('/home/test/.httpie')

    # Legacy case 2, without env vars
    os.environ

# Generated at 2022-06-25 18:25:05.156317
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmp_dir = Path('./tmp')
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_file = tmp_dir / 'config_new.json'
    base_config_dict_0 = BaseConfigDict(path=tmp_file)
    try:
        base_config_dict_0['a'] = 1
        base_config_dict_0.save()
        base_config_dict_0['b'] = 2
        base_config_dict_0.save(fail_silently=True)
    except:
        print(f'Error in line {sys.exc_info()[2].tb_lineno}')
    finally:
        tmp_file.unlink()
        tmp_dir.rmdir()


# Generated at 2022-06-25 18:25:08.826444
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('config.json'))
    config_dict['foo'] = 'bar'
    config_dict.save()

    dict_object = BaseConfigDict(Path('config.json'))
    dict_object.load()

    assert dict_object['foo'] == 'bar'
    os.remove('config.json')


# Generated at 2022-06-25 18:25:11.620109
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    httpie_config_dir = get_default_config_dir()
    path = httpie_config_dir / 'config.json'
    config = Config(path)
    config.load()
    if "default_options" in config:
        return True
    else: 
        return False
