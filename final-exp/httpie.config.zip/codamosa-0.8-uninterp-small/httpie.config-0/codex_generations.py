

# Generated at 2022-06-25 18:15:36.674192
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    global test_counter
    test_case_0()
    test_counter += 1
    path_0 = get_default_config_dir()
    with path_0.open('rt') as f:
        data = json.load(f)


# Generated at 2022-06-25 18:15:39.597285
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = './config/config.json'
    c = Config(path_0)
    c.save()


# Generated at 2022-06-25 18:15:48.577206
# Unit test for method load of class BaseConfigDict

# Generated at 2022-06-25 18:15:50.738335
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == '~/.config/httpie'


# Generated at 2022-06-25 18:15:56.203622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '.'
    if test_env_config_dir:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = test_env_config_dir



# Generated at 2022-06-25 18:16:01.956350
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # tets for windows platform
    for env in ['', 'path', 'path/']:
        path = get_default_config_dir()
        path_win = Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        assert path == path_win
        # test for linux platform
        if env == '':
           path = get_default_config_dir()
           path_linux = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
           assert path == path_linux
        elif env == 'path':
           path = get_default_config_dir()
           path_linux = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-25 18:16:09.361729
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dir_httpie = get_default_config_dir()
    path_0 = dir_httpie / "config.json"
    path_1 = dir_httpie / "proxies.json"
    path_2 = dir_httpie / "storage/storage.json"
    BaseConfigDict.load(path_0)
    BaseConfigDict.load(path_1)
    BaseConfigDict.load(path_2)
    return 0


# Generated at 2022-06-25 18:16:13.822507
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path.cwd() / 'httpie'
    config_file = config_dir / 'config.json'
    if config_dir.exists() and config_file.exists():
        config = Config(Path.cwd())
        config.load()
    else:
        assert(False)



# Generated at 2022-06-25 18:16:21.040982
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # TestCase 1: is_windows is True, using default path
    with patch('httpie.config.is_windows') as mock_is_windows:
        mock_is_windows.return_value = True
        path_1 = get_default_config_dir()
        assert path_1 == Path(os.path.expandvars('%APPDATA%')) / 'httpie'

    # TestCase 2: os.environ has 'HTTPIE_CONFIG_DIR', using
    # 'HTTPIE_CONFIG_DIR"
    with patch("os.environ.get", return_value="/tmp"):
        path_2 = get_default_config_dir()
        assert path_2 == "/tmp"

    # TestCase 3: is_windows is False, os.environ.get('HTTPIE_CONFIG_DIR')


# Generated at 2022-06-25 18:16:27.558210
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("Running Unit test for function get_default_config_dir")
    # Test case 0
    print("Running Test case 0")
    path_0 = get_default_config_dir()
    if(path_0.endswith('httpie')):
        print("Passed Test case 0")
    else:
        print("Failed Test case 0")


# Generated at 2022-06-25 18:16:34.882512
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    if DEFAULT_CONFIG_DIR.is_dir():
        path_0 = DEFAULT_CONFIG_DIR
        path_0.joinpath('config.json').touch()
        path_0.joinpath('config.json').write_text('{"a":"b"}')
        path_0.joinpath('config.json').write_text('{"c":"d"}')
    return 0

# Generated at 2022-06-25 18:16:40.149320
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.ensure_directory()
    if config.path.exists():
        config.path.unlink()
    config.load()
    config.save()
    assert config.path.exists()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 18:16:42.693126
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dc = Config()
    dc.ensure_directory()
    assert dc.path.parent.exists()
    assert dc.path.parent.is_dir()


# Generated at 2022-06-25 18:16:49.330293
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        with open('config.json', 'r') as f:
            data = json.load(f)
    except IOError as e:
        if e.errno != errno.ENOENT:
            raise ConfigFileError(f'cannot read {config_type} file: {e}')
    config = BaseConfigDict("config.json")
    config.update(data)
    assert config == data


# Generated at 2022-06-25 18:16:53.421378
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    if config.is_new():
        config.save()

    config_copy = Config()
    config_copy.load()
    if config == config_copy:
        print ("Test case passed")
    else:
        print ("Test case failed")
        return 0
    return 1


# Driver code

# Generated at 2022-06-25 18:16:56.957523
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config(directory='./tests/integration')
    assert config['default_options'] == ['--debug']

test_BaseConfigDict_load()

# Generated at 2022-06-25 18:17:00.359722
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    c = Config()
    assert c.path.exists()
    c.ensure_directory()
    assert c.path.exists()
    c.delete()
    assert not c.path.exists()  


# Generated at 2022-06-25 18:17:03.337488
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert (get_default_config_dir() == Path.home() / '.config' / 'httpie')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:17:04.761682
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()


# Generated at 2022-06-25 18:17:14.606947
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a directory that doesn't exist so that the method creates it.
    path_1 = DEFAULT_CONFIG_DIR / "test"
    path_1.mkdir(parents=True, exist_ok=True)
    config_1 = Config(directory=DEFAULT_CONFIG_DIR)
    config_1.ensure_directory()

    # Create a directory that exists.
    path_2 = DEFAULT_CONFIG_DIR / "test2"
    path_2.mkdir(parents=True, exist_ok=True)
    config_2 = Config(directory=DEFAULT_CONFIG_DIR)
    config_2.ensure_directory()

    # Create a file instead of a directory.
    path_3 = DEFAULT_CONFIG_DIR / "test3"
    path_3.touch()

# Generated at 2022-06-25 18:17:17.650660
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-25 18:17:19.802417
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path("./test_config_dir")
    config = BaseConfigDict(path=path / 'test_temp.json')
    config.save()


# Generated at 2022-06-25 18:17:31.155356
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Mock environment variables
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''

    # Windows
    if is_windows:
        assert(get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR)
        return

    # Linux
    path_0 = os.path.join(os.path.expanduser('~'), '.config', 'httpie')
    assert(get_default_config_dir() == path_0)
    
    # 2. Linux: $XDG_CONFIG_HOME is set
    os.environ[ENV_XDG_CONFIG_HOME] = 'a'
    path_1 = os.path.join('a', 'httpie')

# Generated at 2022-06-25 18:17:33.454209
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(r'C:\Users\Placido\AppData\Roaming\.httpie\httpie\config.json')
    config_dict.save()

# Generated at 2022-06-25 18:17:38.121819
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = Path.home() / '.httpie' / 'config.json'
    config_1 = Config(path_1)
    config_1.load()
    assert config_1


# Generated at 2022-06-25 18:17:39.878631
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()
    assert os.path.exists(path_0)



# Generated at 2022-06-25 18:17:47.205209
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = Path('./test_case/test_BaseConfigDict_save')
    path_0.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_dict = BaseConfigDict(path=path_0 / 'test.json')
    config_dict['key'] = 'value'
    config_dict.save()
    config_dict_saved = BaseConfigDict(path=path_0 / 'test.json')
    config_dict_saved.load()
    assert config_dict == config_dict_saved
    shutil.rmtree(path_0)



# Generated at 2022-06-25 18:17:50.515281
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_instance = BaseConfigDict(get_default_config_dir() / Config.FILENAME)
    try:
        test_instance.load()
    except ConfigFileError:
        pass

# Generated at 2022-06-25 18:17:54.883372
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # We do not know what your HOME is, so just check that the value is sane
    # I.e. we do not want it to be on a remote drive or any other crazy location
    path_0 = get_default_config_dir()
    assert os.path.isdir(path_0)
    assert os.path.samefile(path_0, str(path_0))

# Generated at 2022-06-25 18:17:58.132268
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    bcdfile=Path('./test.json')
    bcdfile.touch()
    bcdfile.write_text('{"key":3}')
    bcfile = BaseConfigDict(bcdfile)
    bcfile.load()
    assert bcfile['key'] == 3

# Generated at 2022-06-25 18:18:11.856030
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    dict_1 = {'key0':'value0'}
    def __init__(self, path: Path):
        super().__init__()
        self.path = path

    def ensure_directory(self, dict_t=dict_1):
        try:
            self.path.parent.mkdir(mode=0o700, parents=True)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

    def is_new(self) -> bool:
        return not self.path.exists()

    def load(self):
        config_type = type(self).__name__.lower()

# Generated at 2022-06-25 18:18:14.325981
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    # This file doesn't exist before so it will return False
    assert(not config_0.is_new())



# Generated at 2022-06-25 18:18:23.070920
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    tmp_config_dir = Path(os.getcwd()) / "tmp"
    tmp_config_file = tmp_config_dir / Config.FILENAME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(tmp_config_dir)
    os.environ[ENV_XDG_CONFIG_HOME] = str(tmp_config_dir)
    assert get_default_config_dir() == tmp_config_dir
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR



# Generated at 2022-06-25 18:18:26.168986
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dic = BaseConfigDict()
    config_dic['a'] = 'b'
    config_dic.load()
    assert 'a' in config_dic.keys()


# Generated at 2022-06-25 18:18:28.786429
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0['abc'] = 123
    config_0.save()
    config_1 = Config()
    assert config_1['abc'] == 123

# Generated at 2022-06-25 18:18:34.348597
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    # 1. should load config file with valid json data
    json_file_path_1 = os.path.join(os.path.dirname(__file__), 'httpie.json')
    config_1 = Config(directory=os.path.dirname(json_file_path_1))
    config_1.load()

    # 2. should throw exception when config file contains invalid json data
    json_file_path_2 = os.path.join(os.path.dirname(__file__), 'invalid_httpie.json')
    config_2 = Config(directory=os.path.dirname(json_file_path_1))
    with pytest.raises(ConfigFileError):
        config_2.load()



# Generated at 2022-06-25 18:18:37.710269
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	test_config = BaseConfigDict("/tmp/test.json")
	test_config.load()

test_BaseConfigDict_load()

# Generated at 2022-06-25 18:18:40.398682
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    config_1.save()
    assert config_1.is_new() == False
    config_1.delete()


# Generated at 2022-06-25 18:18:44.508912
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config()
    assert len(config_1.keys()) == 1
    assert config_1['default_options'] == []
    config_1.load()
    assert len(config_1.keys()) == 1
    assert config_1['default_options'] == []


# Generated at 2022-06-25 18:18:47.469758
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config(directory='/tmp/httpie')
    config['a'] = 'b'
    config.save()
    config2 = Config(directory='/tmp/httpie')
    config2.load()
    assert config2['a'] == 'b'


# Generated at 2022-06-25 18:18:53.070359
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config('..')
    config_1.ensure_directory()
    assert config_1.path == Path('..') / 'config.json'
    assert 'httpie' not in os.listdir('..')


# Generated at 2022-06-25 18:19:01.444112
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    # test for invalid file
    config_0['__meta__'] = {
        'httpie': '0.9.2' 
    }
    print(config_0)
    config_0.save()
    print('config_0.path={}'.format(config_0.path))
    assert (os.path.exists(config_0.path))
    config_0.load()
    assert (config_0.is_new() == False)
    


if __name__ == '__main__':
    # test_case_0()
    test_BaseConfigDict_load()
    # config_0 = Config()
    # print('config_0.path={}'.format(config_0.path))

# if __name__ == '__main__':
#    

# Generated at 2022-06-25 18:19:06.504599
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # default case
    assert get_default_config_dir() == Path(DEFAULT_CONFIG_DIR)

    # ENV_HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

# Generated at 2022-06-25 18:19:09.796137
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict_base = BaseConfigDict()
    assert config_dict_base['path'] == os.path.join(os.path.expanduser('~'),'.httpie/config.json')


# Generated at 2022-06-25 18:19:16.852636
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path('test_files/test_config.json')
    config_dict = BaseConfigDict(config_path)
    config_dict.load()
    assert config_dict['__meta__']['httpie'] == "1.0.3"
    assert config_dict['__meta__']['help'] == "https://httpie.org"
    assert config_dict['__meta__']['about'] == "https://github.com/jakubroztocil/httpie"
    assert config_dict['default_options'] == ['--form']


# Generated at 2022-06-25 18:19:23.811903
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dict_0 = BaseConfigDict(Path("C:\\Users\\Mines\\.httpie\\config.json"))
    dict_0['__meta__'] = {'httpie': '2.0.0'}
    dict_0['__meta__']['help'] = 'https://www.google.com/'
    dict_0['__meta__']['about'] = 'https://www.google.com/'
    dict_0.save()
    dict_0.delete()


# Generated at 2022-06-25 18:19:28.468986
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_file = 'test_BaseConfigDict.json'
    test_dir = 'test_dir'
    c = BaseConfigDict(test_file)
    print('input:')
    print(c)
    c.load()
    print('output:')
    print(c)


# Generated at 2022-06-25 18:19:30.762549
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = BaseConfigDict(Path('~/.httpie/config.json'))


# Generated at 2022-06-25 18:19:32.286664
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert "/home/user/.config/httpie" == get_default_config_dir()


# Generated at 2022-06-25 18:19:35.330256
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config('sample')
    path = config_0.path
    config_0.ensure_directory()
    assert path.parent.exists()


# Generated at 2022-06-25 18:19:50.898932
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Use HTTPIE_CONFIG_DIR env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = './httpie'
    assert get_default_config_dir() == './httpie'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Use legacy config path
    legacy_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_dir.mkdir()
    assert get_default_config_dir() == legacy_dir

    # Use XDG_CONFIG_HOME
    xdg_dir = os.environ[ENV_XDG_CONFIG_HOME] = str(Path.cwd() / '.local')
    assert get_default_config_dir() == xdg_dir / DEFAULT_CONFIG_

# Generated at 2022-06-25 18:19:56.974782
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import mock
    config_dict = BaseConfigDict("/home/httpie/.httpie/config.json")
    with mock.patch('httpie.config.DEFAULT_CONFIG_DIR', config_dict.path.parent.parent):
        config = Config()
    assert(os.path.exists("/home/httpie/.httpie") == True)
    os.rmdir("/home/httpie/.httpie")


# Generated at 2022-06-25 18:20:03.559187
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # load correct json file
    json_string = json.dumps({'x': 10})
    temp_path = Path('temp.json')
    temp_path.write_text(json_string + '\n')
    config_dict = BaseConfigDict(path=temp_path)
    config_dict.load()
    assert config_dict.get('x') == 10
    # restore temp file
    temp_path.write_text('')

    # invalid json
    json_string = json.dumps({'x': 10})
    temp_path = Path('temp.json')
    temp_path.write_text(json_string[:8] + '\n')

# Generated at 2022-06-25 18:20:06.144124
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = BaseConfigDict(path='./')
    try:
        config_1.load()
    except Exception:
        assert True


# Generated at 2022-06-25 18:20:16.668460
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print('===== test_get_default_config_dir =====')
    # default (not set)
    config_dir = get_default_config_dir()
    print('config_dir: %s' % config_dir)
    # explicitly set through env
    print('httpie path: %s' % os.environ['HTTPIE_CONFIG_DIR'])
    config_dir = get_default_config_dir()
    print('config_dir: %s' % config_dir)
    # Windows
    # TODO:
    # 4. XDG
    print('XDG: %s' % os.environ['XDG_CONFIG_HOME'])
    config_dir = get_default_config_dir()
    print('config_dir: %s' % config_dir)



# Generated at 2022-06-25 18:20:18.846745
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    bcd = BaseConfigDict('test.json')
    bcd.load()


# Generated at 2022-06-25 18:20:24.743385
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Configure environment for testing Windows
    os.environ['APPDATA'] = "C:\\Users\\User\\AppData\\Roaming"
    os.environ['XDG_CONFIG_HOME'] = "C:\\Users\\User/.config"
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Configure environment for testing Linux
    os.environ['HOME'] = "/home/user"
    os.environ['XDG_CONFIG_HOME'] = "/home/user/.config"
    assert get_default_config_dir() == Path("/home/user/.config/httpie")


# Generated at 2022-06-25 18:20:26.964922
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict_0 = BaseConfigDict(Path(""))
    base_config_dict_0.load()


# Generated at 2022-06-25 18:20:31.915391
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('test'))
    with open('test.json', 'w') as f:
        f.write('{"aaa": 1, "bbb": 2, "ccc": 3}')
    config.load()
    assert config['aaa'] == 1
    assert config['ccc'] == 3
    os.remove('test.json')

# Generated at 2022-06-25 18:20:39.009739
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test for linux and mac
    if not is_windows:
        assert (get_default_config_dir() == Path('/home/user/.config/httpie')), "Linux/MAC test failed"
    # test for windows
    else:
        assert (get_default_config_dir() == Path('C:/Users/user/AppData/Roaming/httpie')), "Windows test failed"

# Unit test to check the existance of config.json file

# Generated at 2022-06-25 18:20:59.156744
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    home_dir = Path.home()

    # Legacy
    legacy_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    assert not legacy_dir.exists()

    # Without env
    xdg_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    assert not xdg_dir.exists()
    assert config_dir == xdg_dir / DEFAULT_CONFIG_DIRNAME

    # With env
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/path'
    config_dir = get_default_config_dir()
    assert config_dir == Path('/some/path') / DEFAULT_CONFIG_DIRNAME

    # Windows


# Generated at 2022-06-25 18:21:08.940368
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file_content = '{ "__meta__": {"httpie": "0.9.9", "help": "help", "about": "about"} }'
    root_path = Path('/tmp/httpie-root')
    config_dir = root_path / Config.FILENAME
    config_dir_path = config_dir.parent

    try:
        config_dir_path.mkdir(mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    try:
        config_dir.write_text(config_file_content)
    except IOError:
        raise

    config = Config(directory=root_path)

    if config['__meta__']['help'] == "help":
        return True


# Generated at 2022-06-25 18:21:15.068696
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for error when input is not in json format
    class NonJsonConfigDict(BaseConfigDict):
        pass
    non_json_config_dict = NonJsonConfigDict(Path('/tmp/test.json'))
    content = '{"key":"value"}{"key2":"value3"}'
    non_json_config_dict.path.write_text(content)
    with pytest.raises(ConfigFileError):
        non_json_config_dict.load()

    # Test for error when file is not a dictionary
    class NonDictConfigDict(BaseConfigDict):
        pass
    non_dict_config_dict = NonDictConfigDict(Path('/tmp/test.json'))
    content = '["abc", "def", "ghi"]'
    non_dict_config_

# Generated at 2022-06-25 18:21:26.830383
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    # Test load of nonexist config file
    try:
        config_0.load()
    except ConfigFileError as e:
        if e.args[0] == "cannot read config file: [Errno 2] No such file or directory: '{}'".format(str(config_0.path)):
            print('test_load_nonexist_config_file: passed')
        else:
            raise
    # Test load of empty config file

# Generated at 2022-06-25 18:21:29.932944
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    assert config_0.is_new()
    config_0.load()
    assert config_0.default_options == []
    #config_0.save()
    #config_0.save()

# Generated at 2022-06-25 18:21:32.348438
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config(directory='httpie_config/')
    config_1.load()
    print(config_1)


# Generated at 2022-06-25 18:21:34.190046
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    assert default_config_dir.exists()

# Generated at 2022-06-25 18:21:44.394455
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = '/tmp/httpie/.root/a.json'
    path_2 = '/tmp/httpie/.root/b/b.json'

    config_1 = BaseConfigDict(path_1)
    config_2 = BaseConfigDict(path_2)

    try:
        config_1.ensure_directory()
    except OSError as e:
        assert e.errno == errno.EEXIST
    else:
        print("OSError not raised")

    try:
        config_2.ensure_directory()
    except OSError as e:
        assert e.errno == errno.EEXIST
    else:
        print("OSError not raised")

# Generated at 2022-06-25 18:21:52.503340
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test case 1
    # 设置XDG_CONFIG_HOME环境变量
    os.environ['XDG_CONFIG_HOME'] = '~/.config'
    p = get_default_config_dir()
    assert p == Path('~/.config') / 'httpie'

    # test case 2
    # Windows下，设置环境变量 
    x = is_windows()
    os.environ['APPDATA'] = os.path.expanduser('%APPDATA%')
    p = get_default_config_dir()
    assert p == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

    # test case 3


# Generated at 2022-06-25 18:21:54.443045
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    d = {'hello':'world'}
    config_dict = BaseConfigDict()
    config_dict.load(d, 'test.json')

# Generated at 2022-06-25 18:22:22.675153
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert (get_default_config_dir() ==
            Path.home() / '.config' / 'httpie')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/mydir'
    assert (get_default_config_dir() ==
            Path('~/mydir').expanduser())

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/my/path'
    assert (get_default_config_dir() ==
            Path('~/my/path').expanduser())

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/my/path/'
    assert (get_default_config_dir() ==
            Path('~/my/path').expanduser())

# Generated at 2022-06-25 18:22:29.076932
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    # When the file does not exist, no exception is raised.
    path_does_not_exist = Path('./file_does_not_exist.json')
    assert not path_does_not_exist.exists()

    config_0 = BaseConfigDict(path=path_does_not_exist)
    config_0.load()

    # When the file is not a valid JSON file, an exception is raised.
    path_not_a_valid_json = Path('./file_not_a_valid_json.json')
    path_not_a_valid_json.write_text(text='foo')

    config_0 = BaseConfigDict(path=path_not_a_valid_json)
    with pytest.raises(ConfigFileError) as excinfo:
        config_0.load()

# Generated at 2022-06-25 18:22:34.475819
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'test_BaseConfigDict_save.json'
        config = BaseConfigDict(path)
        config['default_options'] = ''
        config.save()
        assert path.exists()

# Generated at 2022-06-25 18:22:44.532543
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('./test_config.json'))
    config['default_options'] = ['--ignore-stdin']
    config.save()
    load_config = BaseConfigDict(Path('./test_config.json'))
    load_config.load()
    if load_config['default_options'] != ['--ignore-stdin']:
        raise AssertionError

    os.remove('./test_config.json')
        
if __name__ == '__main__':
    test_case_0()
    test_BaseConfigDict_save()

# Generated at 2022-06-25 18:22:48.095772
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_path_default = get_default_config_dir()
    home_dir = Path.home()
    config_path_default_expected = home_dir / Path('.config/httpie')

    # easy to check, so just print it
    print("default config path is: " + str(config_path_default))
    
    assert config_path_default == config_path_default_expected


# Generated at 2022-06-25 18:22:50.495174
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:22:51.584991
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass


# Generated at 2022-06-25 18:22:58.061440
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    temp_dir = TemporaryDirectory()
    path = Path(temp_dir.name).joinpath('test.json')
    base = BaseConfigDict(path)
    base.ensure_directory()
    assert path.parent.exists()
    assert os.access(path.parent, os.R_OK | os.W_OK)
    temp_dir.cleanup()

# Generated at 2022-06-25 18:23:00.559190
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    with pytest.raises(ConfigFileError):
        config_0.load()


# Generated at 2022-06-25 18:23:03.490780
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()


# Generated at 2022-06-25 18:23:28.064980
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test with path that is not directory
    obj = BaseConfigDict('testDir')
    obj.ensure_directory()
    assert(os.path.isdir('testDir'))
    # Test with path that is directory
    obj = BaseConfigDict('testDir')
    obj.ensure_directory()
    assert(os.path.isdir('testDir'))


# Generated at 2022-06-25 18:23:38.562107
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1
    # Case 1.1: neither $XDG_CONFIG_HOME nor $HTTPIE_CONFIG_DIR is set
    # Case 1.2: $XDG_CONFIG_HOME is set
    # Case 1.3: $HTTPIE_CONFIG_DIR is set
    # Case 1.4: $XDG_CONFIG_HOME is set to ''
    # Case 1.5: $XDG_CONFIG_HOME is set to '/'

    # Test case 1.1: neither $XDG_CONFIG_HOME nor $HTTPIE_CONFIG_DIR is set
    from os import environ
    environ1 = environ.copy()
    path = get_default_config_dir()
    if is_windows:
        pass

# Generated at 2022-06-25 18:23:40.883581
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_test = Config()
    assert config_test.ensure_directory() is None
    assert config_test.ensure_directory() is None



# Generated at 2022-06-25 18:23:41.967975
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()


# Generated at 2022-06-25 18:23:44.226740
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.load()


# Generated at 2022-06-25 18:23:55.058627
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    path = Path(temp_dir.name + '/config.json')
    config_dict = BaseConfigDict(path)
    assert (config_dict.is_new() == True)
    json_string = json.dumps(
        obj={'default_options': ["-v"]},
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    path.write_text(json_string + '\n')
    config_dict.load()
    assert (config_dict.is_new() == False)
    temp_dir.cleanup()


if __name__ == '__main__':
    test_case_0()
    test_BaseConfigDict_load()

# Generated at 2022-06-25 18:23:59.292258
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = BaseConfigDict(Path.cwd()/'test_case_1.json')
    config_1.load()
    assert config_1 == {'__meta__': {'httpie': __version__}}


# Generated at 2022-06-25 18:24:00.661410
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    assert config_0.save()


# Generated at 2022-06-25 18:24:04.322206
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('./../test_config.json'))
    config['default_options'] = ["--form"]
    config.save()
    os.remove(config.path)
    config.load()
    assert config['default_options'] == ["--form"]


# Generated at 2022-06-25 18:24:05.824448
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:24:56.762314
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Run the function with no environment variable set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    default_config_dir = get_default_config_dir()
    assert default_config_dir.name == DEFAULT_CONFIG_DIRNAME
    
    if is_windows:
        # This is not defined on a mac
        assert default_config_dir.parent.name == 'AppData'
    else:
        # This is not defined on Windows
        assert default_config_dir.parent.name == '.config'
    
    # Run the function with a non-windows env variable set and try again
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/something'
    default_config_dir = get_default_config_dir()

# Generated at 2022-06-25 18:24:59.727611
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.exists()


# Generated at 2022-06-25 18:25:01.560220
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(Path.home() / '.config' / 'httpie')



# Generated at 2022-06-25 18:25:05.674152
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    Base_config_dict = BaseConfigDict(Path('./test_load/config.json'))
    Base_config_dict.load()
    Base_config_dict.save()

if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-25 18:25:11.249349
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # First check if it returns expected path when XDG_CONFIG_HOME not set
    assert(get_default_config_dir() == Path.home()/DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)

    # Second check if it returns expected path when XDG_CONFIG_HOME is set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert(get_default_config_dir() == Path('/foo') / DEFAULT_CONFIG_DIRNAME)

    # Resetting
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-25 18:25:21.521761
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Case 0: Normal Case
    config_0 = Config()
    config_0['default_options'] = ['--verbose']
    config_0.save()
    config_0 = Config()
    config_0.load()
    assert config_0['default_options'] == ['--verbose']

    # Case 1: No config file
    config_0 = Config()
    config_0.load()
    assert config_0['default_options'] == []

    # Case 2: Config file is not JSON format
    config_0 = Config()
    config_0.path.write_text('not json')
    try:
        config_0.load()
    except ConfigFileError as e:
        assert 'invalid config file:' in str(e)
        assert 'not json' in str(e)


# Generated at 2022-06-25 18:25:25.897575
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for case that name = None
    config_1 = BaseConfigDict(Path('/some/fake/path/config.json'))
    config_1.load()

    # Test for case that name != None
    config_2 = BaseConfigDict(Path('/another/fake/path/config.json'))
    config_2.name = 'test'
    config_2.load()


# Generated at 2022-06-25 18:25:27.701508
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
