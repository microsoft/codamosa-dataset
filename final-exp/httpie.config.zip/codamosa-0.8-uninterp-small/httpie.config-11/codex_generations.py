

# Generated at 2022-06-25 18:15:38.024450
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmp:
        config_dir = Path(tmp)
        os.environ['XDG_CONFIG_HOME'] = str(config_dir)
        assert get_default_config_dir() == config_dir / DEFAULT_CONFIG_DIRNAME

        shutil.rmtree(config_dir)
        os.environ['XDG_CONFIG_HOME'] = str(config_dir)
        assert get_default_config_dir() == config_dir / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-25 18:15:42.328767
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == DEFAULT_CONFIG_DIR
    assert str(get_default_config_dir()) != 'abc'
    assert str(get_default_config_dir()) != 'abc.txt'


# Generated at 2022-06-25 18:15:45.806412
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    try:
        os.mkdir(os.path.join(os.path.expanduser('~'), '.config'))
    except OSError:
        pass
    assert config_0.ensure_directory() == None


# Generated at 2022-06-25 18:15:47.916607
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:15:52.142858
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("\n===== TEST FOR FUNCTION get_default_config_dir: =====")
    print("Should be ~/.config/httpie:\n" + str(get_default_config_dir()))



# Generated at 2022-06-25 18:15:56.485658
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    from shutil import rmtree
    testdir = "testdir"
    path = Path(testdir)
    config = BaseConfigDict(path)
    config.ensure_directory()
    assert(path.is_dir())
    assert(path.exists())
    rmtree(testdir)


# Generated at 2022-06-25 18:15:59.691491
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    if is_windows:
        assert config_dir.as_posix() == DEFAULT_WINDOWS_CONFIG_DIR.as_posix()
    else:
        assert config_dir.as_posix() == (Path.home() / '.config' / 'httpie').as_posix()

# Generated at 2022-06-25 18:16:08.578028
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Should be failed
    try:
        config_1 = Config(directory="/not/a/valid/path")
        config_1.ensure_directory()
    except OSError:
        assert True
    else:
        assert False

    # Create directory
    config_2 = Config(directory="./test")
    config_2.ensure_directory()

    assert config_2.path.parent.exists()

    # Clean up
    config_2.delete()
    config_2.path.parent.rmdir()



# Generated at 2022-06-25 18:16:10.859479
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    actual = config.ensure_directory()
    expected = None
    assert actual == expected


# Generated at 2022-06-25 18:16:19.193099
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/test_httpie_config_dir'
    assert get_default_config_dir() == '/tmp/test_httpie_config_dir'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.makedirs(os.path.expanduser('~/.httpie'), mode=0o700, exist_ok=True)
    assert get_default_config_dir() == os.path.expanduser('~/.httpie')
    os.rmdir(os.path.expanduser('~/.httpie'))



# Generated at 2022-06-25 18:16:26.517984
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class BaseConfigDict_unittest(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
    BaseConfigDict_unittest(Path('.')).ensure_directory()


# Generated at 2022-06-25 18:16:28.760136
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    example = Config("test/test_httpie")
    example.load()
    assert example['test_key'] == 'test_value'


# Generated at 2022-06-25 18:16:40.260327
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path().home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'XXX'
    assert get_default_config_dir() == 'XXX'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = 'YYY'
    assert get_default_config_dir() == Path('YYY') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'YYY'
    assert get_default_config_dir() == 'YYY'

# Generated at 2022-06-25 18:16:42.013516
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    
    config_1.save()
    
    assert True

# Generated at 2022-06-25 18:16:44.281724
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = BaseConfigDict('config.json')
    config_1.save()


# Generated at 2022-06-25 18:16:46.245316
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/user/.config/httpie')

# Generated at 2022-06-25 18:16:51.469916
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Case 1: Config file is empty or not exist
    config_0 = Config()

    # Case 2: Config file is exist and not empty
    config_1 = Config()
    config_1.update({'default_options': ['--headers']})
    config_1.save()
    config_1.load()
    assert config_1['default_options'] == ['--headers']

# Generated at 2022-06-25 18:16:58.226572
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    HOME = str(Path.home())
    XDG_CONFIG_HOME = str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME)

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert get_default_config_dir() == env_config_dir
    else:
        # 2. Windows
        if is_windows:
            assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        else:
            # 3. legacy ~/.httpie
            legacy_config_dir = HOME + '/.httpie'

# Generated at 2022-06-25 18:17:00.552588
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.parent.exists()


# Generated at 2022-06-25 18:17:05.549508
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = BaseConfigDict(path="./test/test_config_stub.json")
    config_1.save()
    data = json.loads(open("./test/test_config_stub.json").read())
    assert data["__meta__"]["httpie"] == __version__


# Generated at 2022-06-25 18:17:12.556929
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    for directory in (None, '/tmp', 'httpie_test'):
        print('Saving file to', directory, '...')
        if directory == 'httpie_test':
            os.mkdir(directory)
            
        base_config_dict = BaseConfigDict(directory)
        base_config_dict.save()
    return

# Generated at 2022-06-25 18:17:14.562126
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Unit test to test loading of config file

# Generated at 2022-06-25 18:17:15.813375
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()



# Generated at 2022-06-25 18:17:17.563214
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.directory.is_dir() == True


# Generated at 2022-06-25 18:17:23.801391
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    # Test that config file exists in default location
    assert config.path.exists()
    config.delete()
    # Test that config.save() creates a config file if it doesn't exist
    config.save()
    assert config.path.exists()
    # Test that saving a config file creates all of its parent directories
    config.path.unlink()
    config_dir = config.path.parent
    config_dir.rmdir()
    assert not config_dir.exists()
    config.save(fail_silently=True)
    assert config.path.exists()
    assert config_dir.exists()
    # Test that saving a config file sets the correct permissions
    assert oct(config_dir.stat().st_mode)[-3:] == '700'

# Generated at 2022-06-25 18:17:28.338569
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.path.exists()
    config_0.delete()



# Generated at 2022-06-25 18:17:40.253847
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test for the docker image which only has default variables
    os.environ.clear()
    assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()

    # test for linux os
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME)
    assert Path(os.environ[ENV_XDG_CONFIG_HOME]) / DEFAULT_CONFIG_DIRNAME == get_default_config_dir()

    # test for the Windows os
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
    else:
        assert Path(os.environ[ENV_XDG_CONFIG_HOME]) / DEFAULT_CONFIG

# Generated at 2022-06-25 18:17:43.245483
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config('./')
    config_0.ensure_directory()
    assert os.path.isdir('./config')
    shutil.rmtree('./config')

# Generated at 2022-06-25 18:17:47.379625
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    config_1["test_var"] = 12345
    config_1.save("_test_config.json")
    with open("_test_config.json") as json_file:
        data = json.load(json_file)
        assert data == config_1
        os.remove("_test_config.json")


# Generated at 2022-06-25 18:17:50.722606
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    try:
        config_0.ensure_directory()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


# Generated at 2022-06-25 18:18:01.755500
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test case 1: create a temporary new directory and call
    # method  ensure_directory of class BaseConfigDict
    config_1 = Config()
    random_user_config_dir = Path(
        os.getenv('HOME'),
        '.httpie',
        'user-config-{}'.format(str(uuid.uuid4()))
    )
    # if config_1.is_new():
    #     config_1.path.parent.mkdir(mode=0o700, parents=True)
    config_1.path = random_user_config_dir
    config_1.ensure_directory()
    assert random_user_config_dir.is_dir()

    # Test case 2: create a temporary new file
    #  and call method ensure_directory of class BaseConfigDict
    random_user_

# Generated at 2022-06-25 18:18:12.847981
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    default_config_dir = DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie/config'
    config_0 = Config()
    assert config_0.directory == '/tmp/httpie/config'
    if env_config_dir == None:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    else:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = env_config_dir
    assert config_0.directory == default_config_dir

    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    default_config_dir = DE

# Generated at 2022-06-25 18:18:23.802915
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'testdir1'
    assert get_default_config_dir() == 'testdir1'
    # Case 2: HTTPIE_CONFIG_DIR not set, but XDG_CONFIG_HOME is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = 'testdir2'
    assert get_default_config_dir() == 'testdir2/httpie'
    # Case 3: HTTPIE_CONFIG_DIR not set, but XDG_CONFIG_HOME is not set
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default

# Generated at 2022-06-25 18:18:30.789914
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    from pathlib import Path
    class DummyBaseConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
            self.update({
                "__meta__": {
                    "about": "This is a dummy dictionary used for testing pytest.",
                    "httpie": "1.0.0",
                    "help": "https://google.com"
                },
                "foo": "bar",
            })
    dummy = DummyBaseConfigDict(Path('/tmp/dummy.json'))
    dummy.save()

# Generated at 2022-06-25 18:18:37.177676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # scenario 0: directory does not exists
    config_0 = Config()
    try:
        config_0.ensure_directory()
    except:
        print("scenario 0: Directory already exists")
    # scenario 1: directory exists
    config_1 = Config()
    try:
        config_1.ensure_directory()
    except OSError as e:
        assert(e.errno == errno.EEXIST)



# Generated at 2022-06-25 18:18:38.695529
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    a = Config()
    a.load()


# Generated at 2022-06-25 18:18:42.588834
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config(directory='.')
    with open(config_1.path, 'wt') as f:
        f.write('This file is not JSON-formatted.')
    with pytest.raises(ConfigFileError):
        config_1.load()


# Generated at 2022-06-25 18:18:47.697495
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path):
            self.path = path
            super().__init__(path)
            self['key'] = 'value'

    path = Path('config_test.json')
    c = TestConfigDict(path)
    c.save()

    with path.open() as f:
        json_dict = json.load(f)

    assert json_dict['key'] == 'value'

# Generated at 2022-06-25 18:18:54.648315
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_get_default_config_dir_0()
    test_get_default_config_dir_1()
    test_get_default_config_dir_2()
    test_get_default_config_dir_3()
    test_get_default_config_dir_4()
    test_get_default_config_dir_5()
    test_get_default_config_dir_6()
    test_get_default_config_dir_7()
    test_get_default_config_dir_8()
    test_get_default_config_dir_9()


# Generated at 2022-06-25 18:19:02.354678
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """Ensuring that the function get_default_config_dir returns the
    expected path on different platforms and values of environment
    variables."""

    # windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # mac or linux (non-xdg)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path(
        Path.home() / ".config" / DEFAULT_CONFIG_DIRNAME)

    # mac or linux (xdg with $XDG_CONFIG_HOME set)
    os.environ[ENV_XDG_CONFIG_HOME] = "/some/dir"
    assert get_default_config_dir() == Path('/some/dir') / DEFAULT_CONFIG_

# Generated at 2022-06-25 18:19:07.498845
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = BaseConfigDict('./config.json')
    config_0.save(fail_silently=True)


# Generated at 2022-06-25 18:19:10.115563
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path('test.json')
    BaseConfigDict(path).ensure_directory()
    assert path.parent.is_dir()


# Generated at 2022-06-25 18:19:12.291890
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.parent.exists()



# Generated at 2022-06-25 18:19:15.222030
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(Path("./test/test_dir/test_file.json"))
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()


# Generated at 2022-06-25 18:19:18.270039
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.path_exists = False
    assert config_0.path.exists() == False
    config_0.ensure_directory()
    assert config_0.path.exists() == True
    config_0.path.unlink()


# Generated at 2022-06-25 18:19:23.280299
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    dirname = get_default_config_dir()

    if not is_windows:
        if os.getenv(ENV_HTTPIE_CONFIG_DIR):
            assert dirname == Path(os.getenv(ENV_HTTPIE_CONFIG_DIR))
        elif os.getenv(ENV_XDG_CONFIG_HOME):
            assert dirname == (Path(os.getenv(ENV_XDG_CONFIG_HOME)) / DEFAULT_CONFIG_DIRNAME)
        elif Path('/home/').exists():
            home_dir = Path('/home/')
            legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
            if legacy_config_dir.exists():
                assert dirname == legacy_config_dir

# Generated at 2022-06-25 18:19:28.622587
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert os.path.exists(config_0.path.parent) == True # Since the directory is created, it should return true
    assert os.path.exists(config_0.path) == False # Since the default file config.json is not created, it should return false


# Generated at 2022-06-25 18:19:30.066162
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-25 18:19:38.082271
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    #Test if get_default_config_dir function works on Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    #Test if get_default_config_dir function works on Linux
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_CONFIG_DIR)
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    #Test if get_default_config_dir function works if $HTTPIE_CONFIG_DIR env is not set
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:19:41.132969
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    assert get_default_config_dir() == home_dir / '.config' / 'httpie'



# Generated at 2022-06-25 18:19:50.645239
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    results = []
    if is_windows:
        results.append(DEFAULT_WINDOWS_CONFIG_DIR)
    else:
        home_dir = Path.home()
        legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        if legacy_config_dir.exists():
            results.append(legacy_config_dir)
        else:
            results.append(home_dir / '.config' / 'httpie')
    assert results == [get_default_config_dir()]


# Generated at 2022-06-25 18:19:51.530067
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass


# Generated at 2022-06-25 18:19:55.745916
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class Test(BaseConfigDict):
        def __init__(self):
            super().__init__(Path('test_BaseConfigDict_ensure_directory.json'))

    try:
        os.remove('test_BaseConfigDict_ensure_directory.json')
    except OSError as e:
        pass

    test = Test()
    test.ensure_directory()

    assert os.path.exists('test_BaseConfigDict_ensure_directory.json')

    os.remove('test_BaseConfigDict_ensure_directory.json')

    try:
        os.rmdir('test_BaseConfigDict_ensure_directory.json.d')
    except OSError as e:
        pass


# Generated at 2022-06-25 18:20:02.973945
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1. Explicitly set through ENV_HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = './httpie-config'
    assert get_default_config_dir() == Path('./httpie-config')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    # Case 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # Case 3. Legacy ~/.httpie
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-25 18:20:08.543099
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # $XDG_CONFIG_HOME is set and it is a directory
    xdg_config_home = Path('./xdg_config_home')
    os.environ[ENV_XDG_CONFIG_HOME] = str(xdg_config_home)
    xdg_config_home.mkdir()
    print(get_default_config_dir())

test_get_default_config_dir()

# Generated at 2022-06-25 18:20:12.248077
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert os.path.isdir(os.path.join(str(DEFAULT_CONFIG_DIR), "httpie"))


# Generated at 2022-06-25 18:20:22.326198
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = str(get_default_config_dir())

    # Test on Linux
    if not is_windows:
        assert config_dir.endswith('.config/httpie')
        # Test with ~/.config/httpie set
        os.environ[ENV_XDG_CONFIG_HOME] = '~/.config/httpie'
        assert get_default_config_dir() == Path.home() / '.config/httpie'
        # Test with HTTPIE_CONFIG_DIR set
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/.config/httpie'
        assert get_default_config_dir() == Path.home() / '.config/httpie'

    # Test on Windows

# Generated at 2022-06-25 18:20:30.972148
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_BaseConfigDict = BaseConfigDict(None)
    test_BaseConfigDict['__meta__'] = {'httpie': '2.0.0'}
    test_BaseConfigDict.helpurl = 'default'
    test_BaseConfigDict.about = 'default'
    test_BaseConfigDict.ensure_directory()
    test_BaseConfigDict.is_new()
    test_BaseConfigDict.save()
    test_BaseConfigDict.delete()

# Generated at 2022-06-25 18:20:32.799225
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert is_windows == (get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR)

# Generated at 2022-06-25 18:20:44.269381
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import os.path
    # Test cases with $XDG_CONFIG_HOME set
    xdg_config_home_cases = [
        {
            'env': {
                'XDG_CONFIG_HOME': '/tmp/foo',
            },
            'expected_config_dir': '/tmp/foo/httpie'
        },
        {
            'env': {
                'XDG_CONFIG_HOME': 'C:\tmp\foo',
            },
            'expected_config_dir': 'C:\tmp\foo\httpie'
        },
    ]
    for test_case in xdg_config_home_cases:
        for k, v in test_case['env'].items():
            os.environ[k] = v

# Generated at 2022-06-25 18:20:50.966636
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    BaseConfigDict.test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-25 18:20:53.622793
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test for function get_default_config_dir
    """
    
    assert(get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR)

# Generated at 2022-06-25 18:21:04.966453
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import pytest
    from httpie.config import (
        get_default_config_dir,
        DEFAULT_CONFIG_DIR,
        ConfigFileError,
        BaseConfigDict,
    )

    config_dir = Path(get_default_config_dir()).resolve()
    assert config_dir == DEFAULT_CONFIG_DIR

    # Create the directory

    p = config_dir / 'a' / 'b' / 'c'
    p.parent.mkdir(parents=True)
    assert p.parent.exists() and p.parent.is_dir()

    # Create a file

    art = '{"a":"r","t":""}'
    p.write_text(art)
    assert p.exists() and p.is_file()
    assert p.read_text() == art

    #

# Generated at 2022-06-25 18:21:12.610815
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert (get_default_config_dir() == Path.home() / '.config' / 'httpie'), "Failed initial test for get_default_config_dir"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = Path.home() / 'newConfig'
    if is_windows:
        assert (get_default_config_dir() == Path.home() / '.config' / 'httpie'), "Failed test for get_default_config_dir when $HTTPIE_CONFIG_DIR is set"

# Generated at 2022-06-25 18:21:17.615999
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'test_config.json')
    config.save()
    # test fail_silently option
    config.save(fail_silently=True)
    del config['__meta__']
    config.save()


# Generated at 2022-06-25 18:21:28.392575
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()

    assert not config_0.is_new()

    config_0.ensure_directory()
    assert config_0.path.parent.exists()
    config_0.path.parent.rmdir()
    assert not config_0.path.parent.exists()

    if not is_windows:
        # pylint: disable=anomalous-backslash-in-string
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/test/test/test'
        try:
            config_1 = Config()
            config_1.ensure_directory()
            assert config_1.path.parent.exists()
        finally:
            os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
            config_1.path.parent

# Generated at 2022-06-25 18:21:31.712631
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    current_OS = os.name
    if current_OS == "posix":
        assert os.path.basename(str(DEFAULT_CONFIG_DIR)) == "httpie"
    else:
        assert os.path.basename(str(DEFAULT_CONFIG_DIR)) == "Httpie"

# Generated at 2022-06-25 18:21:37.847679
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_directory = Path('/tmp/httpie/test/subdir')
    # create base directory and check if it exists
    base_config_dict = BaseConfigDict(path=test_directory)
    base_config_dict.ensure_directory()
    assert test_directory.parent.exists()
    # delete base directory if it exists
    base_config_dict.path.parent.unlink()



# Generated at 2022-06-25 18:21:47.772338
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # test case 1
    try:
        config_1 = BaseConfigDict(path="filepath")
    except FileNotFoundError as e:
        assert str(e) == "No such file or directory: 'filepath'"

    try:
        config_1.save()
    except FileNotFoundError as e:
        assert str(e) == "[Errno 2] No such file or directory: 'filepath'"

    # test case 2: success
    class my_config(BaseConfigDict):
        name = None
    config_2 = my_config(path="./test_json_file")
    config_2.save()
    assert config_2.path.exists() == True
    assert config_2.path.name == "test_json_file"
    os.remove("test_json_file")



# Generated at 2022-06-25 18:21:56.198259
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    if is_windows:
        # DEFAULT_WINDOWS_CONFIG_DIR is '%APPDATA%\httpie'
        config_dir = get_default_config_dir()
        assert isinstance(config_dir, Path)
        assert str(config_dir) == os.path.expandvars('%APPDATA%') + '\\httpie'
        assert not config_dir.exists()
    else:
        # For Linux
        # 1. DEFAULT_WINDOWS_CONFIG_DIR is '.config/httpie'
        if os.path.isdir('.config'):
            config_dir = get_default_config_dir()
            assert isinstance(config_dir, Path)
            assert str(config_dir) == '.config/httpie'
            assert not config_dir.exists()



# Generated at 2022-06-25 18:22:08.957508
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir() == Path.home() / '.config' / 'httpie')



# Generated at 2022-06-25 18:22:11.118584
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 18:22:22.642048
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path("/home/temporary_httpie_test_folder/config")
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = Path("/home/temporary_httpie_test_folder/config/config.json")
    # create empty file
    config_path.touch()

    class TestConfig(BaseConfigDict):
        name = None
        helpurl = None
        about = None

        def __init__(self, path: Path):
            super().__init__(path)
            self.path = path


# Generated at 2022-06-25 18:22:25.418955
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    httpie_dir = Path.cwd() / "src/httpie"
    httpie_dir = Path(httpie_dir)
    config_0 = BaseConfigDict(path=httpie_dir / "config.json")
    config_0.load()


# Generated at 2022-06-25 18:22:27.615691
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config(directory = DEFAULT_CONFIG_DIR)
    config.save()



# Generated at 2022-06-25 18:22:31.688065
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    try:
        config_dict.save()
    except:
        assert False
    assert True


# Generated at 2022-06-25 18:22:33.788525
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('./config.json'))
    config.save()


# Generated at 2022-06-25 18:22:38.026311
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a new instance of BaseConfigDict
    config_1 = BaseConfigDict(get_default_config_dir() / "test.json")

    # check whether the 'httpie' directory exists under the default config
    # directory
    assert not config_1.directory.parent.exists()

    # run the method ensure_directory
    config_1.ensure_directory()

    # check whether the 'httpie' directory has been created
    assert config_1.directory.parent.exists()



# Generated at 2022-06-25 18:22:45.702417
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()

    config_1['default_options'] = ["--json"]
    config_1.save()

    with open(config_1.path, 'rt') as temp_file:
        temp_file_content = temp_file.read()

    assert temp_file_content == '{\n    "default_options": [\n        "--json"\n    ],\n    "__meta__": {\n        "httpie": "1.0.3"\n    }\n}\n' # noqa: E501


# Generated at 2022-06-25 18:22:49.780725
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # directory does not exist
    config_1 = Config(directory=Path('/tmp/path/to/config'))
    config_1.ensure_directory()
    assert config_1.path.parent.exists()
    config_1.path.parent.rmdir()

    # directory exists
    config_2 = Config(directory=DEFAULT_CONFIG_DIR)
    config_2.ensure_directory()
    assert config_2.path.parent.exists()
    assert config_2.path.parent.is_dir()

# Generated at 2022-06-25 18:23:24.555983
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    username = getpass.getuser()
    home = Path.home()
    xdg_config_home = os.path.join(home, '.config')
    xdg_config_home_with_env = os.path.join(home, 'xdg-home')
    httpie_config_dir_with_env = os.path.join(home, '.httpie')

    # Windows tests
    if is_windows:
        windows_config_dir = Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        assert get_default_config_dir() == windows_config_dir

    # OSX/Linux tests
    else:
        httpie_path = os.path.join(home, '.httpie', 'config.json')

        # Case 1:

# Generated at 2022-06-25 18:23:30.891635
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config_dir = config.directory
    assert config_dir.exists() == True
    try:
        os.remove(str(config_dir))
    except:
        pass
    assert config_dir.exists() == False
    assert config_dir.parent.exists() == False
    config.save()
    assert config_dir.exists() == True
    assert config_dir.parent.exists() == True


# Generated at 2022-06-25 18:23:31.444161
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass

# Generated at 2022-06-25 18:23:41.189647
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for:
    # - creating a new file
    # - loading the file (which will be empty)
    temp_dir = Path('temp_dir')
    config_file_name = 'test_config_file.json'
    config_file_path = temp_dir / config_file_name
    config = BaseConfigDict(path=config_file_path)
    # creating a new file
    assert not config_file_path.exists()
    config.save()
    assert config_file_path.exists()
    # loading the file (which will be empty)
    empty_config = BaseConfigDict(path=config_file_path)
    empty_config.load()
    assert empty_config == {}
    # Test for:
    # - loading from a non-existent file
    # - loading from a file

# Generated at 2022-06-25 18:23:52.255120
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Cases:
    # OS Windows:
    # 1. HTTPIE_CONFIG_DIR not specified
    # 2. HTTPIE_CONFIG_DIR specified
    # 3. HTTPIE_CONFIG_DIR specified as empty string
    # OS Linux/macOS:
    # 1. HTTPIE_CONFIG_DIR not specified
    # 2. HTTPIE_CONFIG_DIR specified
    # 3. HTTPIE_CONFIG_DIR specified as empty string
    # 4. ~/.httpie exists
    # 5. XDG_CONFIG_HOME not specified
    # 6. XDG_CONFIG_HOME specified
    # 7. XDG_CONFIG_HOME specified as empty string
    if is_windows:
        # Case 1
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        # Case 2

# Generated at 2022-06-25 18:24:03.002106
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Ensure that the default directory .config/httpie exists
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.path.parent.exists() == True
    config_0.path.parent.rmdir()
    assert config_0.path.parent.exists() == False
    config_0.ensure_directory()
    assert config_0.path.parent.exists() == True
    config_0.path.parent.rmdir()
    # Ensure that if xdg config dir is not found, use the legacy dir
    config_1 = Config('~/.httpie')
    assert config_1.path.parent.exists() == False
    assert config_1.path.parent == Path.home()/DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
   

# Generated at 2022-06-25 18:24:07.544262
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    json_string = json.dumps(
        obj=config_0,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    assert  config_0.path.write_text(json_string + '\n')


# Generated at 2022-06-25 18:24:11.893066
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Test that default value of XDG_CONFIG_HOME should return ~/.config
    assert list(get_default_config_dir().parts) == [Path.home(), '.config', 'httpie']

    # Test that a custom value of XDG_CONFIG_HOME should return the same
    os.environ[ENV_XDG_CONFIG_HOME] = 'test'
    assert list(get_default_config_dir().parts) == ['test', 'httpie']

# Generated at 2022-06-25 18:24:20.157635
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('test_dir')
    os.makedirs(test_dir, mode=0o700)
    assert os.path.exists(test_dir)
    test_config_dict = BaseConfigDict(Path(test_dir) / 'test_file.txt')
    test_config_dict.ensure_directory()
    assert os.path.exists(test_dir)
    os.rmdir(test_dir)
    assert not os.path.exists(test_dir)


# Generated at 2022-06-25 18:24:21.596166
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    config_0.save()



# Generated at 2022-06-25 18:25:23.215085
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(Path.home()) + "/.config/httpie"
    os.environ['XDG_CONFIG_HOME'] = '/huang/shan'
    assert str(get_default_config_dir()) == "/huang/shan/httpie"
    assert get_default_config_dir() == Path('/huang/shan/httpie')