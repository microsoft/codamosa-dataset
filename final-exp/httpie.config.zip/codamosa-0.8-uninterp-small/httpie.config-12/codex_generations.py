

# Generated at 2022-06-25 18:15:39.534412
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:15:40.134456
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    pass

# Generated at 2022-06-25 18:15:46.142041
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Test attribute ensure_directory of class BaseConfigDict by verifying that
    when calling the method an error is thrown.
    """
    path_0 = module_0.Path()
    config_dict_0 = BaseConfigDict(path_0)
    try:
        config_dict_0.ensure_directory()
        assert False
    except Exception as e:
        assert type(e) == ConfigFileError


# Generated at 2022-06-25 18:15:50.011104
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:15:53.788310
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:15:56.567938
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:15:57.777627
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


# Generated at 2022-06-25 18:16:02.009954
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = module_0.Path("path_0")
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()


# Generated at 2022-06-25 18:16:05.532428
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = pathlib.Path()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.load()


# Generated at 2022-06-25 18:16:09.173336
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = pathlib.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.ensure_directory()
    except IOError:
        pass


# Generated at 2022-06-25 18:16:12.983573
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:16:14.930035
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = module_0.Path()
    base_config_dict_1 = BaseConfigDict(path_1)


# Generated at 2022-06-25 18:16:26.802085
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import pytest
    # TODO: benchmark against simple if cascading
    def get_default_config_dir():
        """
        Return the path to the httpie configuration directory.

        This directory isn't guaranteed to exist, and nor are any of its
        ancestors (only the legacy ~/.httpie, if returned, is guaranteed to exist).

        XDG Base Directory Specification support:

            <https://wiki.archlinux.org/index.php/XDG_Base_Directory>

            $XDG_CONFIG_HOME is supported; $XDG_CONFIG_DIRS is not

        """
        # 1. explicitly set through env
        env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
        if env_config_dir:
            return Path(env_config_dir)

        # 2

# Generated at 2022-06-25 18:16:28.124982
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().samefile(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-25 18:16:31.571102
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()


# Generated at 2022-06-25 18:16:34.881089
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    directory_0 = get_default_config_dir()
    config_0 = Config(directory_0)
    path_0 = config_0.path
    base_config_dict_0 = BaseConfigDict(path_0)


# Generated at 2022-06-25 18:16:46.505413
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        tmpdir_factory = pytest.importorskip('pytest-env')
        # https://github.com/pytest-dev/pytest/pull/3523
        KWARGS = {}
    except ImportError:
        tmpdir_factory = None
        KWARGS = {'scope': 'function'}

    if tmpdir_factory:
        @pytest.fixture(scope='function')
        def tmpdir():
            return Path(tmpdir_factory.tmpdir)

    @pytest.fixture(scope='function')
    def real_xdg_config_home_dir(tmpdir):
        return tmpdir / 'xdg_config'

# Generated at 2022-06-25 18:16:50.170319
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict_0 = BaseConfigDict(module_0.Path())
    base_config_dict_0.ensure_directory()
    assert isinstance(base_config_dict_0, BaseConfigDict)


# Generated at 2022-06-25 18:16:52.557267
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    base_config_dict_0 = BaseConfigDict(config_0.directory)
    base_config_dict_0.save()

# Generated at 2022-06-25 18:16:58.803484
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    class BaseConfigDict_0(BaseConfigDict):

        def __init__(self, path: Path):
            self.path = path
            super().__init__(path=self.path)

        def save(self, fail_silently=False):
            self['__meta__'] = {
                'httpie': __version__
            }
            if self.helpurl:
                self['__meta__']['help'] = self.helpurl

            if self.about:
                self['__meta__']['about'] = self.about

            self.ensure_directory()

            json_string = json.dumps(
                obj=self,
                indent=4,
                sort_keys=True,
                ensure_ascii=True,
            )

# Generated at 2022-06-25 18:17:07.817279
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Module mock
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.ensure_directory()
    except OSError as e:
        e.errno = errno.EEXIST
        raise


# Generated at 2022-06-25 18:17:10.450364
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Asserts that we can get the default config dir
    default_config_dir = get_default_config_dir()
    assert default_config_dir is not None


# Generated at 2022-06-25 18:17:16.663576
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test case 1: try-except block
    path_1 = module_0.Path()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.load()
    # Test case 2: raise ConfigFileError
    path_2 = module_0.Path()
    base_config_dict_2 = BaseConfigDict(path_2)
    try:
        base_config_dict_2.load()
    except ConfigFileError:
        return
    assert(False)



# Generated at 2022-06-25 18:17:23.128654
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if (is_windows):
        if (not os.path.exists(Path('C:/Users/T0405/AppData/Roaming/httpie/config.json'))):
            assert 0
        if (not os.path.exists(Path('C:/Users/T0405/AppData/Roaming/httpie/config.json'))):
            assert 0
    else:
        if ((Path.home().name != 'T0405')):
            return
        if (not os.path.exists(Path('/home/T0405/.config/httpie/config.json'))):
            assert 0
        if (not os.path.exists(Path('/home/T0405/.config/httpie/config.json'))):
            assert 0
    assert 1


# Generated at 2022-06-25 18:17:33.157855
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    base_config_dict_0 = BaseConfigDict(pathlib.Path("C:\\Windows\\system32\\cmd.exe"))
    base_config_dict_0.save(True)
    assert base_config_dict_0["__meta__"]["httpie"] == __version__
    assert base_config_dict_0.name is None
    assert base_config_dict_0.helpurl is None
    assert base_config_dict_0.about is None
    assert base_config_dict_0['default_options'] == []
    assert base_config_dict_0.directory == pathlib.Path("C:\\Windows\\system32\\cmd.exe")
    assert base_config_dict_0.path == pathlib.Path("C:\\Windows\\system32\\cmd.exe")
    assert base_config_dict_0

# Generated at 2022-06-25 18:17:38.953304
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.ensure_directory()
        assert False
    except NotADirectoryError:
        assert True


# Generated at 2022-06-25 18:17:42.036584
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        BaseConfigDict.ensure_directory(self)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise



# Generated at 2022-06-25 18:17:44.851335
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()



# Generated at 2022-06-25 18:17:46.302911
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == \
        get_default_config_dir()


# Generated at 2022-06-25 18:17:48.386427
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    base_config_dict_0 = BaseConfigDict(config_0)
    try:
        base_config_dict_0.load()
    except ConfigFileError as e_0:
        pass


# Generated at 2022-06-25 18:18:00.466393
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:18:04.585439
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = pathlib.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    test_boolean = base_config_dict_0.save()
    assert test_boolean == None


# Generated at 2022-06-25 18:18:06.110030
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # No test case for method load of class BaseConfigDict
    pass


# Generated at 2022-06-25 18:18:10.202102
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_base_config_dict_path = Path(DEFAULT_CONFIG_DIRNAME)
    actual_base_config_dict_path = get_default_config_dir()
    assert type(expected_base_config_dict_path) == type(actual_base_config_dict_path)

# Generated at 2022-06-25 18:18:13.503115
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    # Should raise an exception
    with raises(ConfigFileError):
        base_config_dict_0.load()


# Generated at 2022-06-25 18:18:14.343430
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_case_0()


# Generated at 2022-06-25 18:18:17.084249
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = module_0.Path()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()


# Generated at 2022-06-25 18:18:19.007296
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict_0 = Config()

test_case_0()
test_BaseConfigDict_save()

# Generated at 2022-06-25 18:18:22.478090
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:18:24.833400
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_home = Path.home()
    assert get_default_config_dir() == test_home / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-25 18:18:45.219032
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = pathlib.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    assert base_config_dict_0.ensure_directory() == None



# Generated at 2022-06-25 18:18:47.617474
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()


# Generated at 2022-06-25 18:18:57.194638
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test a default value
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Test when AppData defined
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foobar'
    assert get_default_config_dir() == 'foobar'

    # Test when windows and AppData is not defined
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test when config_dir defined
    config_dir = Path('foobar')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(config_dir)
    assert get_default_config_dir() == config_dir



# Generated at 2022-06-25 18:18:58.542313
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory_0 = pathlib.Path()
    config_0 = Config(directory_0)

# Generated at 2022-06-25 18:19:01.283313
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    pass
    # default_config_dir_0 = get_default_config_dir()

import pathlib as module_1


# Generated at 2022-06-25 18:19:04.605676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:19:09.589363
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test case with command type of "delete"
    path_1 = module_0.Path("C:\WINDOWS\system32\stdole2.tlb")
    base_config_dict_1 = BaseConfigDict(path_1)
    assert base_config_dict_1.ensure_directory() == None


# Generated at 2022-06-25 18:19:14.205341
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.ensure_directory()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


# Generated at 2022-06-25 18:19:15.451012
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_BaseConfigDict_save_0()


# Generated at 2022-06-25 18:19:17.132006
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


config = Config()
config.load()


# Generated at 2022-06-25 18:19:52.127819
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    assert base_config_dict_0.ensure_directory() == None


# Generated at 2022-06-25 18:19:54.756178
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:19:57.640230
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save(True)


# Generated at 2022-06-25 18:19:59.113979
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    result = get_default_config_dir()

    assert isinstance(result, Path)

# Generated at 2022-06-25 18:20:03.851101
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()


# Generated at 2022-06-25 18:20:07.697117
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file_error_0 = ConfigFileError()
    path_0 = module_0.Path()
    base_config_dict_1 = BaseConfigDict(path_0)
    base_config_dict_1.save()
    return base_config_dict_1



# Generated at 2022-06-25 18:20:11.660115
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Arrange
    expected_path = Path.home() / Path('.config') / Path('httpie')
    # Act
    result = get_default_config_dir()
    # Act
    assert result == expected_path


# Generated at 2022-06-25 18:20:14.117407
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test that the function returns an instance of class Path
    assert isinstance(get_default_config_dir(), Path)


# Generated at 2022-06-25 18:20:18.185180
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    # Verify that the method that BaseConfigDict calls does not fail
    base_config_dict_0.save()


# Generated at 2022-06-25 18:20:20.546782
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = module_0.Path()
    base_config_dict = BaseConfigDict(path)
    assert not base_config_dict.ensure_directory()


# Generated at 2022-06-25 18:21:38.312584
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    #### Call base_config_dict_0.save
    base_config_dict_0.save()


# Generated at 2022-06-25 18:21:40.010258
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir()

# Generated at 2022-06-25 18:21:44.291950
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pathlib_0 = module_0.Path('./httpie/tests/test_config.json')
    base_config_dict_0 = BaseConfigDict(pathlib_0)
    base_config_dict_0.save()


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-25 18:21:47.378706
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir()


# Generated at 2022-06-25 18:21:49.194758
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    base_config_dict_0 = config_0
    base_config_dict_0.save()


# Generated at 2022-06-25 18:21:51.929742
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test
    # Case 1:
    assert len(get_default_config_dir().parts) >= 2
    # Case 2:
    assert len(get_default_config_dir().parts) < 2


# Generated at 2022-06-25 18:21:55.284070
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    return_value_0 = config_0.ensure_directory()
    if pathlib.Path('/home/user/.config/httpie').exists():
        assert return_value_0 is None
    else:
        assert False


# Generated at 2022-06-25 18:22:06.081095
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError

import json as module_1
import os as module_2

# Generated at 2022-06-25 18:22:09.616184
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir.parent.exists()
    assert config_dir.exists()
    assert str(config_dir) == '/home/hazal/.config/httpie'

# Generated at 2022-06-25 18:22:14.264536
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    base_config_dict_0 = config_0
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:23:41.718320
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # The path to the httpie configuration directory.

    # 1. explicitly set through env
    env_config_dir = os.environ.get("HTTPIE_CONFIG_DIR")
    if env_config_dir:
        return Path(env_config_dir)

    # 2. Windows
    if is_windows:
        return Path("/home/michael/.config/httpie")

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / ".httpie"
    if legacy_config_dir.exists():
        return legacy_config_dir

    # 4. XDG

# Generated at 2022-06-25 18:23:42.929656
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    
    assert get_default_config_dir() == Path(Path.home(), '.config/httpie')


# Generated at 2022-06-25 18:23:45.896120
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir()
    #assert get_default_config_dir() == "a"

# Generated at 2022-06-25 18:23:47.168308
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir().is_dir())

# Generated at 2022-06-25 18:23:50.767943
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() in ['.config/httpie', '.httpie',
                                        'c:\\users\\peter\\appdata'
                                        '/roaming/httpie']

# Generated at 2022-06-25 18:23:54.163926
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # BaseConfigDict.__init__ with no arguments
    base_config_dict_0 = BaseConfigDict()

    # None is the expected output
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:23:55.382855
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_case_0()

import json as module_1


# Generated at 2022-06-25 18:23:58.319268
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 18:24:00.736578
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = pathlib.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()


# Generated at 2022-06-25 18:24:03.375319
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = module_0.Path()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()
