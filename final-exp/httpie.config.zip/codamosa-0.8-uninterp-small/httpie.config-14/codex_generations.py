

# Generated at 2022-06-25 18:15:39.983857
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    print('\n======= Testing =======')
    print('Unit test for method load of class BaseConfigDict')
    print('=======================')

    # ===========================
    # Test the main functionality
    # ===========================
    # (1) Test for success
    print('\n---Start testing for success---')
    test_dir = Path(os.getcwd())
    config = Config(test_dir)
    config.load()
    # Test whether the number of items in the Config is correct
    if len(config) != 1:
        print('Succeeded: The number of items in the config is', len(config))
    else:
        print('Failed: The number of items in the config should be 1, but is', len(config))
    # Test whether the expected key is present in the Config

# Generated at 2022-06-25 18:15:43.622400
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir().name == DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir().name == DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:15:45.922789
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict_instance = BaseConfigDict(Path('test_BaseConfigDict_load.json'))
    config_dict_instance.load()


# Generated at 2022-06-25 18:15:57.400927
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/foo/.httpie2'
    path_1 = get_default_config_dir()
    assert os.path.exists(path_1)

    # 2. Windows
    path_2 = DEFAULT_WINDOWS_CONFIG_DIR
    assert path_2 == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        path_3 = get_default_config_dir()
        assert os.path.exists

# Generated at 2022-06-25 18:16:05.779142
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = DEFAULT_CONFIG_DIR / 'config.json'
    path_2 = DEFAULT_CONFIG_DIR / 'config_1.json'
    config_1 = Config(DEFAULT_CONFIG_DIR)
    config_2 = Config(DEFAULT_CONFIG_DIR)
    config_1.save()
    assert not config_2.load()
    assert config_1.load()
    config_1.delete()



# Generated at 2022-06-25 18:16:11.394681
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = Config().path
    Config().save()
    with open(str(path_0), 'r') as f:
        assert f.read().startswith('{\n    "__meta__": {\n')
    Config().delete()
    try:
        with open(str(path_0), 'r') as f:
            pass
    except FileNotFoundError:
        pass



# Generated at 2022-06-25 18:16:15.207348
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert not get_default_config_dir() / '.httpie' / 'config.json'
    assert get_default_config_dir() / 'httpie' / 'config.json'
    assert not get_default_config_dir() / '.config' / '.httpie' / 'config.json'

# Generated at 2022-06-25 18:16:20.674671
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create test file
    config_1 = Config(directory="./")
    config_1_path = config_1.path
    # set file permission to 000
    os.chmod(config_1_path.parent.parent, 0o000)
    try:
        # create directory
        config_1.ensure_directory()
    except Exception:
        assert True
    finally:
        # delete test file
        config_1_path.unlink()
        # set permission back to 777
        os.chmod(config_1_path.parent.parent, 0o777)


# Generated at 2022-06-25 18:16:23.591359
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    #TODO:  implement
    pass


# Generated at 2022-06-25 18:16:25.478048
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create the config.json file in the default directory
    c = Config()
    c.save()


# Generated at 2022-06-25 18:16:29.388283
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    assert True



# Generated at 2022-06-25 18:16:31.524713
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert isinstance(config, BaseConfigDict)


# Generated at 2022-06-25 18:16:33.103138
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    var_1 = config_1.ensure_directory()


# Generated at 2022-06-25 18:16:36.519440
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    var_1 = config_1.save(fail_silently = True)
    assert var_1 == None

test_BaseConfigDict_save()
test_case_0()

# Generated at 2022-06-25 18:16:39.104064
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    var_1 = config_1.save()


# Generated at 2022-06-25 18:16:40.922837
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    var = config.save()
    assert var is None
    pass


# Generated at 2022-06-25 18:16:43.334555
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    path_0 = './content'
    var_0 = config_0.load()


# Generated at 2022-06-25 18:16:50.033845
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_path = 'test_file.json'
    with open(file_path, 'w') as f:
        f.write('{"name":"httpie"}')
    config_0 = BaseConfigDict(Path(file_path))
    config_0_load = config_0.load()
    assert config_0_load == None
    assert config_0['name'] == 'httpie'
    os.remove(file_path)
    return



# Generated at 2022-06-25 18:16:53.682519
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('test_dir')
    if test_dir.exists():
        test_dir.rmdir()
    test_dir.mkdir()
    config = Config(directory=test_dir)
    config.ensure_directory()
    test_dir.rmdir()


# Generated at 2022-06-25 18:16:57.674537
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = Config()
    # save with invalid argument fails
    try:
        config_0.save(fail_silently="a")
        assert 0
    except:
        pass


# Generated at 2022-06-25 18:17:09.345817
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "set_env"
    assert get_default_config_dir() == "set_env"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ""
    assert get_default_config_dir() != "set_env"
    if is_windows:
        default_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        default_dir = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == default_dir



# Generated at 2022-06-25 18:17:11.022951
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    var_0 = config_0.load()


# Generated at 2022-06-25 18:17:13.093817
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir() == Path('/home/zhangkun/.config/httpie'))


# Generated at 2022-06-25 18:17:15.077820
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert isinstance(get_default_config_dir(), Path)
    assert get_default_config_dir().is_dir()


# Generated at 2022-06-25 18:17:17.890710
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config()
    var_1 = config_1.ensure_directory()
    var_2 = config_1.save()
    config_2 = Config()
    var_3 = config_2.load()


# Generated at 2022-06-25 18:17:18.417533
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert 1 == 1

# Generated at 2022-06-25 18:17:20.713817
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_config_dir = Path('/tmp') / 'httpie'
    config_0 = Config(temp_config_dir)
    var_0 = config_0.save()


test_BaseConfigDict_save()

# Generated at 2022-06-25 18:17:29.693058
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Check if win dir is returned
    if sys.platform == 'win32':
        cdir = str(Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME)
        assert cdir == get_default_config_dir()
    # Check if linux .config dir is returned
    else:
        cdir = str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)
        assert cdir == get_default_config_dir()

# Generated at 2022-06-25 18:17:40.959707
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = ConfigFileError()
    var_0 = config_0.args
    var_1 = config_0.__cause__
    var_2 = config_0.__context__
    var_3 = config_0.__traceback__
    config_1 = ConfigFileError(
        var_0,
        var_1,
        var_2,
        var_3,
        )
    config_2 = Config(
        '/home/donjajo/.config/httpie/config.json',
        )
    config_3 = Config(
        '/home/donjajo/.config/httpie/config.json',
        )
    var_4 = config_3.get('default_options')
    config_3['default_options'] = var_4

# Generated at 2022-06-25 18:17:44.236068
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path("/tmp/config.json"))
    try:
        config.load()
    except IOError as e:
        if e.errno != errno.ENOENT:
            raise


# Generated at 2022-06-25 18:17:51.303276
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(Path.home() / '.config' / 'httpie')

# Generated at 2022-06-25 18:17:58.668403
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home())
    assert get_default_config_dir() == Path.home()
    #
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ':;'
    assert get_default_config_dir() == ':;'
    #
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/'
    assert get_default_config_dir() == '~/'
    #
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '\\\\remote_host\\path'
    assert get_default_config_dir() == '\\\\remote_host\\path'

# Generated at 2022-06-25 18:18:06.815048
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        f = open("./httpie/config.json", 'w+')
        f.write('{"default_options": [false]}')
        f.close()
        config_0 = Config()
        var_0 = config_0.load()
        var_1 = config_0.get('default_options')
        f.close()
        assert var_1 == [False]
    except:
        print('test_BaseConfigDict_load FAILED')
    else:
        print('test_BaseConfigDict_load PASSED')


# Generated at 2022-06-25 18:18:07.693973
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    BaseConfigDict()



# Generated at 2022-06-25 18:18:16.463478
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Case 0: Check that ensure_directory creates the correct directory
    # delete the test directory
    if 'tests' in os.listdir('.'):
        shutil.rmtree('tests')

    # Make a temporary copy of the configuration directory
    shutil.copytree('tests_config_directory', 'tests')
    os.chdir('tests/')

    # Make a new instance of the BaseConfigDict class
    config_0 = BaseConfigDict(Path('config.json'))
    config_0.ensure_directory()

    # Check that the directory created is correct
    assert os.path.isdir(os.path.abspath(config_0.path.parent))

    # Clean up
    os.chdir('../')
    # delete the test directory

# Generated at 2022-06-25 18:18:22.289416
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config("/httpie/tests/dummy-config-dir")
    config_1.ensure_directory()
    # The dummy-config-dir is created by mkdir in the above line
    # Remove the dummy-config-dir
    os.removedirs("/httpie/tests/dummy-config-dir")


# Generated at 2022-06-25 18:18:27.802175
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    #  Create a mock object for class BaseConfigDict
    mock_object = BaseConfigDict(path='/home/mock_path/.mock_file.txt')
    # Ensure that the mock path already exists
    mock_object.ensure_directory()
    # Test the execution of the function
    mock_object.ensure_directory()
    # Assert that function is successful
    assert True


# Generated at 2022-06-25 18:18:32.084915
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # First, we test for default case when no env variables are set
    default_config_dir = get_default_config_dir()
    assert default_config_dir == DEFAULT_CONFIG_DIR
    # Then we test for env variable set case
    os.environ['HTTPIE_CONFIG_DIR'] = 'test_dir'
    new_config_dir = get_default_config_dir()
    assert new_config_dir == Path('test_dir')

# Generated at 2022-06-25 18:18:34.746581
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.path.expanduser('~')) / '.config' / 'httpie'

# Generated at 2022-06-25 18:18:38.788655
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    # Test case 1
    # Not providing parameters
    try:
        config.ensure_directory()
    except Exception:
        raise AssertionError('This statement should have not raised any Exception')


# Generated at 2022-06-25 18:18:45.282291
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('~/.config/httpie')


# Generated at 2022-06-25 18:18:51.566072
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Test 2: Test if the return value is a Path object

    config_dir = get_default_config_dir()
    assert isinstance(config_dir, Path) is True

    # Test 3: Test if the directory is in the home directory when the
    # environment variable is not set

    assert Path.home() in config_dir
    assert DEFAULT_CONFIG_DIRNAME in str(config_dir)

    # Test 4: Test if the directory is in the specified directory
    # when the environment variable is set

    env_var = 'C:\\Users\\Group1\\Documents\\GitHub\\httpie-extended'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = env_var
    config_dir = get_default_config_dir()
    assert Path(env_var) in config_dir

# Generated at 2022-06-25 18:19:00.468477
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case when environment variable HTTPIE_CONFIG_DIR is not set
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    # Test case when environment variable HTTPIE_CONFIG_DIR is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('./test_dir'))
    assert get_default_config_dir() == Path('./test_dir')
    # Test case when environment variable HTTPIE_CONFIG_DIR is not a path
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'NotPath'
    try:
        get_default_config_dir()
    except ConfigFileError:
        pass
    # Test case when environment variable HTTPIE_CONFIG_DIR is empty

# Generated at 2022-06-25 18:19:04.809363
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    filepath_0 = get_default_config_dir()
    assert isinstance(filepath_0, Path)
    filepath_1 = get_default_config_dir()
    assert isinstance(filepath_1, Path)
    assert filepath_0 == filepath_1



# Generated at 2022-06-25 18:19:09.463234
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0['default_options'] = ['--verbose']
    config_0.save()
    config_0['default_options'] = []
    config_0.load()
    assert config_0['default_options'] == ['--verbose']


# Generated at 2022-06-25 18:19:11.921356
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict = BaseConfigDict(path='$HOME/.httpie/config.json')
    try:
        base_config_dict_load(base_config_dict)
    except IOError as e:
        if e.errno != errno.ENOENT:
            raise


# Generated at 2022-06-25 18:19:14.052511
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    var_1 = config_1.ensure_directory()
    assert var_1 == None, "assertion error"


# Generated at 2022-06-25 18:19:15.486758
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.parent != None


# Generated at 2022-06-25 18:19:23.935471
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    
    # test case 0:
    default_config_dir_0 = get_default_config_dir()
    config_0 = Config()
    #if platform.system() == "Windows":
    if is_windows:
        assert (config_0.directory == DEFAULT_WINDOWS_CONFIG_DIR), "The default configuration directory is not equal to %APPDATA%/httpie"
    else:
        assert (config_0.directory == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME), "The default configuration directory is not equal to ~/.config/httpie"



# Generated at 2022-06-25 18:19:25.710624
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.path.exists()

# Generated at 2022-06-25 18:19:36.838073
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_env_httpie_config_dir = os.environ.copy()
    test_env_httpie_config_dir["HTTPIE_CONFIG_DIR"] = "/home/user"
    assert get_default_config_dir() == Path("/home/user")

    test_env_xdg_config_home = os.environ.copy()
    test_env_xdg_config_home["XDG_CONFIG_HOME"] = "/home/.config"
    assert get_default_config_dir() == Path("/home/.config/httpie")


# Generated at 2022-06-25 18:19:37.522891
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-25 18:19:39.870883
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_WINDOWS_CONFIG_DIR == Path('C:/Users/user/AppData/Roaming/httpie')
    # TODO: How to test file path across different OS?
    assert DEFAULT_CONFIG_DIR == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-25 18:19:41.554927
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_case_0()
    
    

# Generated at 2022-06-25 18:19:44.790794
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
    var = config.load()
    assert var == None


# Generated at 2022-06-25 18:19:46.954134
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()
    assert config_0.path.parent.exists()


# Generated at 2022-06-25 18:19:50.814440
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test = BaseConfigDict({
        'a': 1,
        'b': 2,
        'c': 3
    })
    assert test.update == {
        'a': 1,
        'b': 2,
        'c': 3
    }


# Generated at 2022-06-25 18:19:53.133828
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Case defaults
    case_save_x_0()
    # Case fail_silently=True
    case_save_x_1()


# Generated at 2022-06-25 18:20:01.197136
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():

    config_0 = Config()
    # Forcefully delete any directory containing the config file
    config_dir_0 = os.path.dirname(config_0.directory)
    file_path = config_0.directory / config_0.FILENAME
    try:
        os.remove(file_path)
    except OSError:
        pass
    try:
        os.rmdir(config_dir_0)
    except OSError:
        pass

    # Test that the config directory is created for config_0
    config_0.ensure_directory()
    assert os.path.isdir(config_dir_0) == True

    # Test that ensure_directory does not throw any error
    # if the directory exists
    config_0.ensure_directory()


# Generated at 2022-06-25 18:20:04.034539
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    config_0.ensure_directory()


# Generated at 2022-06-25 18:20:10.992622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    var_0 = config_0.load()

# Generated at 2022-06-25 18:20:13.868497
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    assert type(default_config_dir) == Path


# Generated at 2022-06-25 18:20:15.424726
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    tmp = Config()
    tmp.load()
    assert tmp.get('__meta__') is not None


# Generated at 2022-06-25 18:20:19.645785
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Method load will raise ConfigFileError if it fail to load the config file
    config_0 = Config()
    var_0 = config_0.save()
    with pytest.raises(ConfigFileError):
        config_0.load()


# Generated at 2022-06-25 18:20:23.280666
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config_directory = config.directory
    # Test config directory exists
    config.ensure_directory()
    assert config_directory.exists()
    # Test config directory not exists
    config_directory.rmdir()
    config.ensure_directory()
    assert config_directory.exists()


# Generated at 2022-06-25 18:20:28.780793
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        config = Config()
        config.path = Path('config.json')
        config.ensure_directory()
        assert os.path.exists(config.path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


# Generated at 2022-06-25 18:20:31.604280
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    if not config_1.is_new():
        path_1 = config_1.path
        assert path_1.is_file()




# Generated at 2022-06-25 18:20:39.048529
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # -- GIVEN --
    config_0 = Config()
    var_0 = config_0.is_new()

    if var_0 is False:
        config_0.delete()
        var_0 = config_0.is_new()

    # -- WHEN --
    var_1 = config_0.ensure_directory()

    # -- THEN --
    try:
        assert var_1 is None
    finally:
        config_0.delete()


# Generated at 2022-06-25 18:20:42.649120
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    var_1 = config_1.save()
    assert var_1 is None
    var_1 = config_1
    assert var_1 is not None
    config_1.save()

# Generated at 2022-06-25 18:20:46.020068
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Dummy value for some variables
    directory = DEFAULT_CONFIG_DIR
    data = {}
    config_0 = BaseConfigDict(directory)
    config_1 = Config()
    # Create a new instance of BaseConfigDict
    config_0.update(data)
    # No exception is raised
    assert config_0 == config_1



# Generated at 2022-06-25 18:20:59.874567
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    var_0 = config_0.load()


# Generated at 2022-06-25 18:21:02.609826
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = BaseConfigDict(path=Path('/home/benkotto/pbr/pbr-0.10.8/pbr/version.py'))
    config_0.load()


# Generated at 2022-06-25 18:21:11.715957
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    # 1.1. valid
    os.environ[HTTPIE_CONFIG_DIR] = 'C:/Users/lanjin/Desktop/httpie'
    assert get_default_config_dir() == 'C:/Users/lanjin/Desktop/httpie'
    assert os.path.isdir(get_default_config_dir())
    # 1.2. invalid
    os.environ[HTTPIE_CONFIG_DIR] = 'C:/Users/lanjin/Desktop/httpi'
    try:
        assert get_default_config_dir()
    except Exception as e:
        assert e.errno == errno.ENOENT
    # 1.3. valid(with "~")
    os.environ[HTTPIE_CONFIG_DIR] = '~'
    assert get_default

# Generated at 2022-06-25 18:21:13.804339
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    var_0 = config_0.load()
    assert var_0 == None


# Generated at 2022-06-25 18:21:16.908676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    var_0 = config_0.ensure_directory
    assert var_0 == None


# Generated at 2022-06-25 18:21:19.178017
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save(fail_silently=True)
    config.save()


# Generated at 2022-06-25 18:21:20.839945
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:21:30.719803
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for other os
        home_dir = Path.home()

        # Test for legacy ~/.httpie
        path = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        if path.exists():
            assert get_default_config_dir() == path
        else:
            # Test for XDG
            xdg_config_home_dir = os.environ.get(ENV_XDG_CONFIG_HOME)
            if xdg_config_home_dir:
                assert get_default_config_dir() == Path(
                    xdg_config_home_dir) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:21:32.426358
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    var_0 = config_0.ensure_directory()


# Generated at 2022-06-25 18:21:37.898543
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_1 = Config()
    path_1 = config_1.directory
    var_1 = config_1.ensure_directory()
    if path_1.exists():
        config_1.delete()
        path_1.rmdir()
    else:
        print("Path does not exist")


# Generated at 2022-06-25 18:21:54.009675
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = Config()
    parent_dir = Path(config_0.directory).parent
    if not os.path.exists(str(parent_dir)):
        assert not os.path.exists(str(parent_dir))
        config_0.ensure_directory()
        assert os.path.exists(str(parent_dir))



# Generated at 2022-06-25 18:21:55.631624
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    var = config.load()
    assert var is None


# Generated at 2022-06-25 18:22:00.748886
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_WINDOWS_CONFIG_DIR == Path(
        os.path.expandvars('%APPDATA%/httpie'))
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()
    assert type(DEFAULT_CONFIG_DIR) == Path


# Generated at 2022-06-25 18:22:05.376097
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    print('default_config_dir: %s' % default_config_dir)
    assert(default_config_dir == Path.home() / 'httpie')


# Generated at 2022-06-25 18:22:06.787266
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = Config()
    var_1 = config_1.save()


# Generated at 2022-06-25 18:22:09.374584
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME, '')
    assert get_default_config_dir() == Path(xdg_config_home) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:22:20.851207
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_0 = BaseConfigDict()
    print("config_0.path.parent is: ", config_0.path.parent)
    print("config_0.path.parent.parent is: ", config_0.path.parent.parent)
    p_path = Path(config_0.path)
    print("p_path is: ", p_path)
    print("p_path.parent is: ", p_path.parent)
    print("p_path.parent.parent is: ", p_path.parent.parent)

    for p in p_path.parent.parents:
        print("p.name is: ", p.name)


if __name__ == '__main__':
    config = Config()
    test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-25 18:22:27.733051
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert os.environ[ENV_HTTPIE_CONFIG_DIR] == get_default_config_dir()
        os.environ.unsetenv(ENV_HTTPIE_CONFIG_DIR)
    elif is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
    elif Path.home() == '/root':
        assert Path('/root/.' + DEFAULT_CONFIG_DIRNAME) == get_default_config_dir()
    elif Path.home() == '/home/john':
        assert Path('/home/john/.' + DEFAULT_CONFIG_DIRNAME) == get_default_config_dir()
   

# Generated at 2022-06-25 18:22:31.139580
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.save()
    var_0 = config_0.load()



# Generated at 2022-06-25 18:22:34.854707
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert(config_dir != None)
    assert(config_dir.exists() == True)


if __name__ == '__main__':
    test_case_0()
    test_get_default_config_dir()

# Generated at 2022-06-25 18:23:18.492938
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config = get_default_config_dir()
    assert(config == '/root/.config/httpie')


# Generated at 2022-06-25 18:23:21.328657
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # The test environment should have $XDG_CONFIG_HOME=/tmp/x
    assert get_default_config_dir() == Path('/tmp/x/httpie')


# Generated at 2022-06-25 18:23:25.488987
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    dir_0 = 'test'
    # dir_1 = config_0.ensure_directory()
    var_0 = config_0.load()
    var_1 = config_0['__meta__']
    var_2 = var_1['httpie']
    var_3 = '1.0.2'
    assert var_2 == var_3

# Generated at 2022-06-25 18:23:27.481841
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_1 = Config()
    var_1 = config_1.load()


# Generated at 2022-06-25 18:23:32.863196
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    assert config_0.is_new()
    config_0.save()
    assert not config_0.is_new()
    config_1 = Config()
    var_0 = config_1.load()
    assert config_1 != config_0
    assert config_1['__meta__'] == {'httpie': __version__}


# Generated at 2022-06-25 18:23:37.079752
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    if is_windows:
        default_config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        default_config_dir = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    assert default_config_dir == get_default_config_dir()

# Generated at 2022-06-25 18:23:39.686768
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print('get_default_config_dir: ', get_default_config_dir())


# Generated at 2022-06-25 18:23:42.753666
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test TypeError exception
    assert_raises(TypeError, BaseConfigDict, 1)
    # Test ConfigFileError exception
    assert_raises(ConfigFileError, BaseConfigDict.load, BaseConfigDict('./test/test_path/test_config_file'))


# Generated at 2022-06-25 18:23:46.974914
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_path = Path('.') / 'config.json'
    config_dict_0 = BaseConfigDict(file_path)
    string_0 = config_dict_0.load()


# Generated at 2022-06-25 18:23:51.310183
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict()
    try:
        result = config.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid basiconfigdict file: Expecting value: line 1 column 1 (char 0) [None]'


# Generated at 2022-06-25 18:24:45.914725
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    # Testing empty configuration file
    config_0 = BaseConfigDict(Path('unit_test_dir/config_0.json'))
    var_0 = config_0.save()
    var_1 = config_0.path.read_text()

    # Testing non-empty configuration file
    config_1 = BaseConfigDict(Path('unit_test_dir/config_1.json'))
    config_1.update({'test_var': 'test'})
    var_2 = config_1.save()
    var_3 = config_1.path.read_text()



# Generated at 2022-06-25 18:24:47.687426
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_1 = BaseConfigDict(path=Path("config.json"))
    var_1 = config_1.save()


# Generated at 2022-06-25 18:24:50.259278
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path(DEFAULT_CONFIG_DIR / 'config.json'))
    var_0 = config.load()


# Generated at 2022-06-25 18:24:51.473099
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:24:53.565576
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_1 = config_0.load()
    return config_1



# Generated at 2022-06-25 18:24:55.912153
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_1 = get_default_config_dir()
    path_2 = Path.home() / '.config' / 'httpie'
    assert path_1 == path_2



# Generated at 2022-06-25 18:24:58.781159
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == get_default_config_dir()


# Generated at 2022-06-25 18:25:00.211522
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config.is_new() == True


# Generated at 2022-06-25 18:25:01.827594
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_0 = BaseConfigDict()
    var_0 = config_0.save()


# Generated at 2022-06-25 18:25:04.561028
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory = 'my-directory'
    config_1 = Config(directory)
    config_1.save()
