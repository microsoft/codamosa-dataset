

# Generated at 2022-06-25 18:15:34.175427
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test_case_0
    config_test_0 = BaseConfigDict('/test/.test')
    config_test_0.load()
    assert config_test_0.is_new()



# Generated at 2022-06-25 18:15:36.982197
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    path_1 = path_0 / str("config.json")
    config_dict_1 = BaseConfigDict(path=path_1)
    config_dict_1.save()


# Generated at 2022-06-25 18:15:42.280252
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_file_path = '/tmp/httpie-test-config.json'
    test_config = BaseConfigDict(Path(test_config_file_path))
    test_config.save()
    assert test_config.path.exists()
    test_config.delete()


# Generated at 2022-06-25 18:15:44.021938
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)



# Generated at 2022-06-25 18:15:45.000215
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert True


# Generated at 2022-06-25 18:15:53.088477
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Check all the possible exceptions
    try:
        with mock.patch('os.makedirs', side_effect=OSError) as os_makedirs_mock:
            base_config_dict = BaseConfigDict(Path('something'))
            base_config_dict.ensure_directory()
            os_makedirs_mock.assert_called_once()
    except:
        pass

# Generated at 2022-06-25 18:15:56.977206
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_file = Path('./test_temp.json')
    test_case_dict = BaseConfigDict(temp_file)
    test_case_dict.ensure_directory()
    assert temp_file.parent.exists()
    temp_file.parent.rmdir()


# Generated at 2022-06-25 18:15:58.884909
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(DEFAULT_CONFIG_DIR)
    config_dict.save()
    assert config_dict.path.exists()


# Generated at 2022-06-25 18:16:10.956399
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Creating an instance of the BaseConfigDict class
    config_dict = BaseConfigDict(DEFAULT_CONFIG_DIR)
    # Creating a file in the path config_dict.path
    file = open(DEFAULT_CONFIG_DIR, "w+")
    # Creating a dict to be written in the json file
    config_dict_file_content = {
        "default_options": []
    }
    # Writing the dict as a json string in the file
    file.write(json.dumps(config_dict_file_content))
    # Closing file for saving the changes
    file.close()
    # Calling method load of the instance config_dict of the class BaseConfigDict
    config_dict.load()
    # Testing if the instance variable self is equal to the config_dict_file_content dict
    assert config_dict

# Generated at 2022-06-25 18:16:13.470577
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path_0 = get_default_config_dir()
    assert path_0.is_dir()
    assert (path_0 / 'config.json').exists()


# Generated at 2022-06-25 18:16:17.772765
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    c = Config()
    c.load()


# Generated at 2022-06-25 18:16:29.804548
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    file_name = base_config_dict_0.FILENAME
    folder = base_config_dict_0.directory
    path_1 = folder / file_name


# Generated at 2022-06-25 18:16:36.051397
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1['key_0'] = 'value_0'
    base_config_dict_1.save()
    with open(path_1, 'rt') as f:
        dict_0 = json.load(f)
    assert dict_0['key_0'] == 'value_0'


# Generated at 2022-06-25 18:16:46.156771
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.load()
        assert False
    except IOError as e:
        assert e.errno == errno.ENOENT
    except Exception as e:
        assert False
    base_config_dict_0.ensure_directory()
    base_config_dict_0.save()
    try:
        base_config_dict_0.load()
        assert True
    except Exception as e:
        assert False


if __name__ == "__main__":
    test_BaseConfigDict_load()

# Generated at 2022-06-25 18:16:51.046221
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == Path(
            'C:\\Users\\Dony\\AppData\\Roaming\\httpie\\config.json')
    else:
        assert get_default_config_dir() == Path('/home/dony/.config/httpie/config.json')



# Generated at 2022-06-25 18:16:56.192708
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    print("Inside Unit test for method ensure_directory of class BaseConfigDict")
    try:
        path_0 = get_default_config_dir()
        base_config_dict_0 = BaseConfigDict(path_0)
        base_config_dict_0.ensure_directory()
        print("Unit test for method ensure_directory of class BaseConfigDict passed")
    except Exception as e:
        print("Unit test for method ensure_directory of class BaseConfigDict failed")
        print("Exception: ")
        print(e)


# Generated at 2022-06-25 18:16:59.982299
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.save(fail_silently=True)


# Generated at 2022-06-25 18:17:03.290306
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()


# Generated at 2022-06-25 18:17:09.597520
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import tempfile
    path_0 = tempfile.mkdtemp()
    path_1 = path_0 / 'httpie'
    with open(path_1, mode='w') as f:
        json.dump({'__meta__': {'httpie': '0.9.2'}}, f)
    base_config_dict_0 = BaseConfigDict(path_1)
    base_config_dict_0.load()


# Generated at 2022-06-25 18:17:10.938182
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-25 18:17:14.608469
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_case_0()

# Generated at 2022-06-25 18:17:17.137843
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = Path('config.json')
    base_config_dict_1 = BaseConfigDict(path_1)
    assert(not base_config_dict_1)


# Generated at 2022-06-25 18:17:22.099393
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case with default
    path_1 = get_default_config_dir()
    assert path_1 == Path.home() / '.config' / 'httpie' / 'config.json'
    # Test case for Windows
    assert get_default_config_dir() == Path(
        os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME / 'config.json'

# Generated at 2022-06-25 18:17:32.531701
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    my_path = Path.home()
    my_path = my_path.joinpath('test_ensure_directory')
    #my_path = my_path.joinpath('test_ensure_directory/test_ensure_directory2')
    #my_path = my_path.joinpath('test_ensure_directory/test_ensure_directory2/test_ensure_directory3')
    #my_path = my_path.joinpath('/test_ensure_directory/test_ensure_directory2/test_ensure_directory3')
    try:
        #os.mkdir(my_path)
        os.makedirs(my_path)
        print('Directory', my_path, 'created!')
    except FileExistsError:
        print('Directory', my_path, 'already exists!')

# Generated at 2022-06-25 18:17:40.785777
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir_home_path = os.path.join(os.path.expanduser('~'), ".config")
    config_dir_env_path = os.path.join(os.path.expanduser('~'), ".httpie")
    assert get_default_config_dir() == config_dir_home_path / "httpie"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = config_dir_env_path
    assert get_default_config_dir() == config_dir_env_path

# Generated at 2022-06-25 18:17:43.458872
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        json.load(open('config.json'))
    except:
        print('test failed')
    else:
        print('test passed')


# Generated at 2022-06-25 18:17:46.113928
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.save()


# Generated at 2022-06-25 18:17:50.756309
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    print(test_case_0.__doc__)

    import json

    # Create a file with json string
    f = open('test.json', 'w')
    f.write('{"key1": "value1"}')
    f.close()

    # Create the BaseConfigDict instance
    base_config_dict_0 = BaseConfigDict(path = Path('test.json'))
    base_config_dict_0.load()

    # Check if the load method works correctly
    assert base_config_dict_0['key1'] == 'value1'
    
    # Remove the test.json file
    os.remove('test.json')


# Generated at 2022-06-25 18:17:54.147760
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.save()
    assert path_0.exists()
    path_0.unlink()


# Generated at 2022-06-25 18:17:56.452313
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    # Testing the default case
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:18:06.343013
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path1 = Path(os.getcwd() + '/testconfig.json').resolve()
    print(path1)
    config1 = BaseConfigDict(path1)
    config1['alpha'] = [1,2,3,4]
    config1['beta'] = 'value'
    config1.save()
    config1.load()
    assert set(config1.keys()) == {'__meta__', 'alpha', 'beta'}
    config1.delete()


# Generated at 2022-06-25 18:18:12.375813
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    # load and save without fail_silently
    base_config_dict_0.load()
    base_config_dict_0.save()
    # load and save with fail_silently
    base_config_dict_0.load()
    base_config_dict_0.save(fail_silently=True)

# Generated at 2022-06-25 18:18:16.634189
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = ''
    base_config_dict = BaseConfigDict(path)
    try:
        base_config_dict.load()
    except ConfigFileError as e:
        if (e.args[0]=='invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [{}]'):
            return 1
    return -1



# Generated at 2022-06-25 18:18:24.574262
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = '/home/httpie/test'
    base_config_dict_0 = BaseConfigDict(Path(path_0))
    # Test for Path does not exist
    base_config_dict_0.ensure_directory()
    assert(base_config_dict_0.path.exists())
    # Test for Path exists
    base_config_dict_0.ensure_directory()
    assert(base_config_dict_0.path.exists())


# Generated at 2022-06-25 18:18:28.304125
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Test that ensure_directory is not raising anything
    """
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()

# Generated at 2022-06-25 18:18:31.003263
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert isinstance(path, Path)


# Generated at 2022-06-25 18:18:33.202306
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(get_default_config_dir())
    config_dict.load()
    assert type(config_dict) is BaseConfigDict


# Generated at 2022-06-25 18:18:44.711375
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Array for storing results for each test case
    results = []
    # Testing invalid JSON format of config file
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    config_type = type(base_config_dict_1).__name__.lower()
    base_config_dict_1.load()

# Generated at 2022-06-25 18:18:47.348564
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.save()
    except IOError:
        pass


# Generated at 2022-06-25 18:18:54.895323
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(Path.home()) / ".config" / "httpie"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "test"
    assert get_default_config_dir() == Path('test')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = "test"
    assert get_default_config_dir() == Path('test') / "httpie"
    del os.environ[ENV_XDG_CONFIG_HOME]



# Generated at 2022-06-25 18:19:05.639555
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    base_config_dict_0 = BaseConfigDict(Path.home())
    base_config_dict_0.save()
    base_config_dict_0.update({'key_0':'value_0'})
    base_config_dict_0.save()
    base_config_dict_0.delete()


config_0 = Config()
config_0.save()

# Generated at 2022-06-25 18:19:14.518998
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dict = {
        '__meta__': {
            'httpie': '1.0.0'
        },
        'url': 'https://github.com'
    }
    class TestConfig(BaseConfigDict):
        FILENAME = 'test.json'
        helpurl = None
        about = None

    with tempfile.TemporaryDirectory() as tmpdirname:
        path = Path(tmpdirname, TestConfig.FILENAME)
        with open(path, 'w') as f:
            json.dump(test_dict, f)
        config = TestConfig(path)
        config.load()
        assert config == test_dict


# Generated at 2022-06-25 18:19:18.514438
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict_1 = BaseConfigDict(Path(os.getcwd())/DEFAULT_CONFIG_DIRNAME/'config.json')
    base_config_dict_1.load()
    assert base_config_dict_1['default_options'] == []


# Generated at 2022-06-25 18:19:29.990209
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dummy_path_0 = Path('/Users/benjamin/.config/httpie/dummy.txt')
    base_config_dict_0 = BaseConfigDict(dummy_path_0)
    try:
        base_config_dict_0.load()
        assert False
    except ConfigFileError as e:
        assert str(e) == "cannot read BaseConfigDict file: [Errno 2] No such file or directory: '/Users/benjamin/.config/httpie/dummy.txt'"
    dummy_path_1 = Path('/Users/benjamin/.httpie/auth')
    base_config_dict_1 = BaseConfigDict(dummy_path_1)

# Generated at 2022-06-25 18:19:35.288331
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test on Windows
    path_dir_windows = Path(os.path.expanduser('~')) / DEFAULT_WINDOWS_CONFIG_DIR
    assert get_default_config_dir() == path_dir_windows

    # test on non Windows
    path_dir_non_windows = Path(os.path.expanduser('~')) / DEFAULT_CONFIG_DIR
    assert get_default_config_dir() == path_dir_non_windows

# Generated at 2022-06-25 18:19:37.884881
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()


# Generated at 2022-06-25 18:19:43.799143
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Case 0: Correct case
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)

    # Case 1: if path is not a directory
    path_1 = get_default_config_dir()/'test_path1.txt'
    base_config_dict_1 = BaseConfigDict(path=path_1)
    try:
        base_config_dict_1.ensure_directory()
    except ConfigFileError:
        pass
    else:
        assert 0, "Expected exception"

    # Case 2: if can not get the parent
    path_2 = get_default_config_dir()/'test_path2.txt'
    base_config_dict_2 = BaseConfigDict(path=path_2)

# Generated at 2022-06-25 18:19:53.844285
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def test_case_0():
        path_0 = get_default_config_dir()
        base_config_dict_0 = BaseConfigDict(path_0)

    def test_case_1():
        pass

    def test_case_2():
        pass

    def test_case_3():
        pass

    def test_case_4():
        pass

    def test_case_5():
        pass

    def test_case_6():
        pass

    def test_case_7():
        pass

    def test_case_8():
        pass

    def test_case_9():
        pass

    def test_case_10():
        pass

    def test_case_11():
        pass

    def test_case_12():
        pass

    def test_case_13():
        pass

   

# Generated at 2022-06-25 18:19:58.316610
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir() / "config.json"
    base_config_dict_0 = BaseConfigDict(path_0)
    if not base_config_dict_0.path.exists():
        base_config_dict_0.path.touch()
        base_config_dict_0.load()
    else:
        assert True


# Generated at 2022-06-25 18:20:03.180376
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        base_config_dict_0 = BaseConfigDict('config.json')
        base_config_dict_0.load()
    except ConfigFileError:
        print('ConfigFileError caught')


# Generated at 2022-06-25 18:20:19.379428
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = str(Path(".")) + "/tests/configs/" + "data.json"
    BaseConfigDict_1 = BaseConfigDict(path_1)
    BaseConfigDict_1.ensure_directory()
    assert Path.exists(Path(".") + "/tests/configs") == True


# Generated at 2022-06-25 18:20:21.601303
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict_0 = BaseConfigDict(Path('/config/json'))
    base_config_dict_0.ensure_directory()



# Generated at 2022-06-25 18:20:24.545277
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path.home() / 'test_config'
    base_config_dict = BaseConfigDict(path)
    base_config_dict.ensure_directory()
    assert path.parent.exists()
    assert path.parent.is_dir()
    rmtree(path.parent, ignore_errors=True)



# Generated at 2022-06-25 18:20:30.713599
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dict_1 = {
        '__meta__': {
            'httpie': '0.9.9',
        },
        'default_options': []
    }
    f_1 = open(str(DEFAULT_CONFIG_DIR / "config.json"), 'w+')
    f_1.write(str(dict_1))
    def test_load():
        Config().load()
    test_load()


# Generated at 2022-06-25 18:20:31.604386
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass


# Generated at 2022-06-25 18:20:35.259887
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_0)
    base_config_dict_1.save()


# Generated at 2022-06-25 18:20:38.244337
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(Path.home() / Path('.config/httpie'))


# Generated at 2022-06-25 18:20:39.087138
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_case_0()

# Generated at 2022-06-25 18:20:42.948153
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    base_config_dict_1 = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    base_config_dict_1.save();
    assert base_config_dict_1.path.exists()


# Generated at 2022-06-25 18:20:47.344454
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir() / 'config.json'
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1['default_options'] = ['def']
    base_config_dict_1.save()
    base_config_dict_1.path.read_text()


# Generated at 2022-06-25 18:21:11.727313
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert not get_default_config_dir().exists()



# Generated at 2022-06-25 18:21:14.833455
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = DEFAULT_CONFIG_DIR
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.load()



# Generated at 2022-06-25 18:21:21.081471
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = get_default_config_dir()
    # Create file for test
    path_1.touch()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.load()
    assert base_config_dict_1 == {}
    assert base_config_dict_1.path == path_1


# Generated at 2022-06-25 18:21:28.630300
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    error_flag = False

    user_name = os.getlogin()

    if is_windows:
        path = 'C:\\Users\\' + user_name + '\\AppData\\Roaming\\httpie\\'
    else:
        path = '/home/' + user_name + '/.config/httpie/'

    if path == get_default_config_dir():
        print('Function get_default_config_dir passed')
    else:
        print('Function get_default_config_dir failed')
        error_flag = True

    return error_flag



# Generated at 2022-06-25 18:21:35.100051
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case: explicitly set through env
    # set environment variable HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'data/config.json'
    assert get_default_config_dir() == Path('data/config.json')
    # unset environment variable HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

    # Case: Windows
    # set is_windows
    is_windows = 'True'
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # unset is_windows
    is_windows = ''

    # Case: legacy ~/.httpie
    # set legacy config dir
    if not os.path.exists('test_legacy_config_dir'): os.mk

# Generated at 2022-06-25 18:21:39.010438
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    case = BaseConfigDict(Path('/home/foo/.config/httpie/config.json'))
    case.ensure_directory()
    assert case.path.parent.exists()


# Generated at 2022-06-25 18:21:40.246528
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()



# Generated at 2022-06-25 18:21:43.450919
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    base_config_dict_0.ensure_directory()
    path_0.parent.rmdir()


# Generated at 2022-06-25 18:21:48.916506
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR is not None
    print("Testing of get_default_config_dir() function is completed")


if __name__ == "__main__":
    test_case_0()
    test_get_default_config_dir()

# Generated at 2022-06-25 18:21:56.950490
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    case_0 = get_default_config_dir()

    case_1 = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "test_path"
    case_2 = get_default_config_dir()
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    case_3 = os.environ.get(ENV_XDG_CONFIG_HOME)
    os.environ[ENV_XDG_CONFIG_HOME] = "/test_path"
    case_4 = get_default_config_dir()
    os.environ.pop(ENV_XDG_CONFIG_HOME)

    assert case_0 == DEFAULT_CONFIG_DIR
    assert case_

# Generated at 2022-06-25 18:22:21.343571
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-25 18:22:25.355471
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    path_2 = path_1 / 'test'
    base_config_dict_1 = BaseConfigDict(path_2)
    if not path_2.is_dir():
        base_config_dict_1.ensure_directory()
    assert path_2.is_dir()
    base_config_dict_1.delete()

# Generated at 2022-06-25 18:22:35.793299
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from contextlib import redirect_stdout
    from io import StringIO
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)

    with open("/home/buiquang/.config/httpie/config.json", "w") as f:
        f.write("{\"__meta__\": {\"help\": \"http://httpie.org/docs#config\", \"httpie\": \"1.0.3\", \"about\": \"http://httpie.org\"}, \"default_options\": []}")

    f = StringIO()

    with redirect_stdout(f):
        # Test load
        base_config_dict_0.load()
        assert f.getvalue() == ''



# Generated at 2022-06-25 18:22:45.151123
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.path.parent.mkdir(mode=0o700, parents=True)
    try:
        base_config_dict_1.path.write_text(
            json.dumps(
                obj=base_config_dict_1,
                indent=4,
                sort_keys=True,
                ensure_ascii=True,
            ) + '\n'
        )
    except IOError:
        pass
    base_config_dict_1.load()
    assert base_config_dict_1 == {}

# Generated at 2022-06-25 18:22:48.477049
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Mock XDG_CONFIG_HOME to ~/.config
    os.environ[ENV_XDG_CONFIG_HOME] = DEFAULT_RELATIVE_XDG_CONFIG_HOME.as_posix()
    assert get_default_config_dir() == Path(DEFAULT_RELATIVE_XDG_CONFIG_HOME) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-25 18:23:00.016520
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    Create a BaseConfigDict instance,
    save the instance to a json file,
    then load the json file and create a new BaseConfigDict instance.
    """
    import tempfile
    json_string = '{}'
    temp_dir = tempfile.TemporaryDirectory()
    path = pathlib.Path(temp_dir.name) / 'test_save.json'
    base_config_dict_0 = BaseConfigDict(path)
    # call save method
    base_config_dict_0.save()
    assert path.read_text() == json_string + '\n'
    with open(path) as json_file:
        data = json.load(json_file)
        base_config_dict_1 = BaseConfigDict(path)

# Generated at 2022-06-25 18:23:04.596432
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    assert os.path.exists(path_1)



# Generated at 2022-06-25 18:23:15.806281
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # If the user doesn't set any enviroment variable, the config dir should be
    # ~/.config/httpie
    if ENV_HTTPIE_CONFIG_DIR not in os.environ and \
        ENV_XDG_CONFIG_HOME not in os.environ:
        assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)
    # If the user set $HTTPIE_CONFIG_DIR, the config dir should be
    # $HTTPIE_CONFIG_DIR
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        assert str(get_default_config_dir()) == os.environ['HTTPIE_CONFIG_DIR']
    # If the user set $XDG_CONFIG_HOME, the config dir should be
    # $XD

# Generated at 2022-06-25 18:23:23.626315
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dir = 'test_httpie_resources/config_save_test'
    try:
        if not os.path.exists(dir):
            os.makedirs(dir)
        base_config_dict_0 = BaseConfigDict(Path('test_httpie_resources/config_save_test/config.json'))
        base_config_dict_0.save()
        assert(os.path.exists('test_httpie_resources/config_save_test/config.json'))
    finally:
        os.remove('test_httpie_resources/config_save_test/config.json')
        os.rmdir('test_httpie_resources/config_save_test')

# Generated at 2022-06-25 18:23:26.950739
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_0 = Config()
    config_0.load()
    config_name_0 = config_0.name
    about_0 = config_0.about
    assert config_name_0 == None
    assert about_0 == None


# Generated at 2022-06-25 18:24:35.278815
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    '''
    Test the save method of class BaseConfigDict
    '''
    # Make sure we have a clean environment.
    if 'XDG_CONFIG_HOME' in os.environ:
        del os.environ['XDG_CONFIG_HOME']
    if 'HTTPIE_CONFIG_DIR' in os.environ:
        del os.environ['HTTPIE_CONFIG_DIR']

    # Exercise the methods
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1["test_key"] = "test_value"
    base_config_dict_1.save()

    assert path_1.exists()

    # Clean up
    base_config_dict_1.delete()


# Generated at 2022-06-25 18:24:39.509232
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory()
    assert os.path.exists(path_1)

# Generated at 2022-06-25 18:24:46.310081
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test case 1: startup case assuming user is on windows
    # win_conf_dir is expected to be %APPDATA%\httpie
    win_conf_dir = os.path.expandvars('%APPDATA%') + "\\" + DEFAULT_CONFIG_DIRNAME
    assert win_conf_dir == get_default_config_dir()

    # test case 2: test case assuming user is on a unix system and has set
    # HTTPIE_CONFIG_DIR to some dir
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "test_dir"
    assert "test_dir" == get_default_config_dir()

# Generated at 2022-06-25 18:24:51.436748
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_0 = get_default_config_dir()
    config_0 = Config(path_0)
    config_0["username"] = "admin"
    config_0["password"] = "password"
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.save()
    except:
        raise RuntimeError("Unable to save BaseConfigDict")


# Generated at 2022-06-25 18:24:58.943034
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test in Windows
    if is_windows:
        base_path = os.path.expandvars('%APPDATA%') + f'/{DEFAULT_CONFIG_DIRNAME}'
    # Test in linux
    else:
        base_path = os.path.expanduser(f'~/.config/{DEFAULT_CONFIG_DIRNAME}')
    base_path = os.path.abspath(base_path)

    assert get_default_config_dir() == base_path


# Generated at 2022-06-25 18:25:07.998241
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Test 1: Windows OS
    old_os_name = os.name
    os.name = "Windows"
    assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)

    # Test 2: Non-Windows OS
    os.name = "Linux"
    assert str(get_default_config_dir()) == str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)

    # Test 3: Explicit configuration directory
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp"
    assert str(get_default_config_dir()) == "/tmp"
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Reset os.name
    os.name = old_

# Generated at 2022-06-25 18:25:10.576153
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_0 = get_default_config_dir()
    base_config_dict_0 = BaseConfigDict(path_0)
    try:
        base_config_dict_0.load()
    except Exception as e:
        assert type(e) == ConfigFileError


# Generated at 2022-06-25 18:25:14.138447
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_1 = get_default_config_dir()
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.save()
    base_config_dict_2 = BaseConfigDict(path_1)
    assert base_config_dict_2.load() == base_config_dict_1


# Generated at 2022-06-25 18:25:15.763987
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:25:19.506830
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_1 = Path('./temp/path') / 'data.json'
    base_config_dict_1 = BaseConfigDict(path_1)
    base_config_dict_1.ensure_directory();
    assert path_1.parent.exists();