

# Generated at 2022-06-17 20:02:30.019220
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:02:32.483426
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert not config.path.exists()



# Generated at 2022-06-17 20:02:34.178258
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:38.186621
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:02:43.067441
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config_file.load()
    assert config_file == {}
    config_file.save()
    config_file.load()
    assert config_file == {'__meta__': {'httpie': __version__}}
    config_file.delete()


# Generated at 2022-06-17 20:02:47.204227
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('/tmp/test_BaseConfigDict_load.json')
    config = BaseConfigDict(path)
    config.load()
    assert config == {}
    config['a'] = 1
    config['b'] = 2
    config.save()
    config.load()
    assert config == {'a': 1, 'b': 2}
    config.delete()


# Generated at 2022-06-17 20:02:48.313581
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:53.428575
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:02:59.840668
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temp directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temp file
    temp_file = temp_dir / 'temp.json'
    # create a config dict
    config_dict = BaseConfigDict(temp_file)
    # ensure the directory
    config_dict.ensure_directory()
    # check if the directory exists
    assert temp_dir.exists()
    # remove the temp directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 20:03:03.179155
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()


# Generated at 2022-06-17 20:03:08.477885
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:03:14.960653
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:20.622569
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_file.exists()
    assert config_file.is_file()
    config_dir.rmdir()

# Generated at 2022-06-17 20:03:23.196529
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:29.513285
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file in the temporary directory
    temp_file = temp_dir / 'temp_file'
    # create a BaseConfigDict object with the temporary file as its path
    test_config = BaseConfigDict(temp_file)
    # call the method ensure_directory
    test_config.ensure_directory()
    # check if the temporary directory is created
    assert temp_dir.exists()
    # check if the temporary file is created
    assert temp_file.exists()
    # remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:03:34.857000
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()


# Generated at 2022-06-17 20:03:40.985484
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": "b"}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 'b'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:47.185356
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('test_config_dir')
    config_dir.mkdir()
    config_file = config_dir / 'test_config_file'
    config_file.touch()
    config_file.chmod(0o600)
    config_file.unlink()
    config_dir.rmdir()
    config_file = config_dir / 'test_config_file'
    config_file.touch()
    config_file.chmod(0o600)
    config_file.unlink()
    config_dir.rmdir()
    config_file = config_dir / 'test_config_file'
    config_file.touch()
    config_file.chmod(0o600)
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:03:53.068544
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:59.640462
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_dir = Path('./test_config_dir')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{')
    config = Config(config_dir)
    try:
        config.load()
    except ConfigFileError:
        pass
    else:
        assert False, 'Should raise ConfigFileError'
    config_file.unlink()
    config_dir.rmdir()

    # Test for valid json file
    config_dir = Path('./test_config_dir')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write

# Generated at 2022-06-17 20:04:10.155596
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   $XDG_CONFIG_HOME is set
    #   $HTTPIE_CONFIG_DIR is not set
    #   ~/.config/httpie exists
    #   ~/.httpie does not exist
    #   Expected result: ~/.config/httpie
    with mock.patch.dict(os.environ, {ENV_XDG_CONFIG_HOME: '/home/user/.config'}):
        with mock.patch('httpie.config.Path.home', return_value='/home/user'):
            with mock.patch('httpie.config.Path.exists', return_value=True):
                assert get_default_config_dir() == Path('/home/user/.config/httpie')

    # Test 2:
    #   $XDG_CONFIG_HOME is not set

# Generated at 2022-06-17 20:04:19.067442
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:04:23.158107
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:04:25.562501
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:29.477312
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import os.path
    import errno
    import stat

    class TestConfig(BaseConfigDict):
        pass

    try:
        tmpdir = tempfile.mkdtemp()
        tmpdir_path = Path(tmpdir)
        config_path = tmpdir_path / 'config.json'
        config = TestConfig(config_path)
        config.ensure_directory()
        assert os.path.exists(tmpdir)
        assert os.path.isdir(tmpdir)
        assert stat.S_IMODE(os.stat(tmpdir).st_mode) == 0o700
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-17 20:04:34.447607
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    with TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / 'config.json'
        config = BaseConfigDict(path)
        config.save()
        assert path.exists()
        assert path.read_text() == '{"__meta__": {"httpie": "2.0.0"}}\n'


# Generated at 2022-06-17 20:04:46.921404
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.com'
        about = 'about'

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:04:51.175569
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:04:58.763713
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:08.640112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:13.540771
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('config.json'))
    config_dict.load()
    assert config_dict['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:05:14.697466
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:05:18.171141
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:20.060832
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:27.560125
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        pass

    with tempfile.TemporaryDirectory() as tempdir:
        config_path = Path(tempdir) / 'config.json'
        config = TestConfigDict(config_path)
        config['foo'] = 'bar'
        config.save()
        assert config_path.exists()
        config = TestConfigDict(config_path)
        config.load()
        assert config['foo'] == 'bar'

        # Test invalid json
        with open(config_path, 'w') as f:
            f.write('{')
        config = TestConfigDict(config_path)

# Generated at 2022-06-17 20:05:29.746549
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.load()
    assert config == {}



# Generated at 2022-06-17 20:05:37.152409
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # Test for $HTTPIE_CONFIG_DIR
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/httpie'
        assert get_default_config_dir() == Path('/test/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # Test for $XDG_CONFIG_HOME
        os.environ[ENV_XDG_CONFIG_HOME] = '/test/xdg/config'
        assert get_default_config_dir() == Path('/test/xdg/config/httpie')

# Generated at 2022-06-17 20:05:44.133080
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:05:44.917823
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


# Generated at 2022-06-17 20:05:51.420758
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()
    assert not config_dict.path.exists()


# Generated at 2022-06-17 20:05:56.790301
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:05.295981
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temp file
    fd, temp_path = tempfile.mkstemp()
    # Write some content to the file
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('{"foo": "bar"}')
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=temp_path)
    # Load the file
    config.load()
    # Check the content
    assert config['foo'] == 'bar'
    # Remove the temp file
    os.remove(temp_path)


# Generated at 2022-06-17 20:06:12.792466
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:06:14.679755
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:18.971376
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:25.391325
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:30.047205
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = Path('./test_config.json')
    config_file.write_text('{"key": "value"}')
    config = BaseConfigDict(config_file)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()


# Generated at 2022-06-17 20:06:38.705286
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg/httpie')

    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default_config_dir() == Path.home() / '.config/httpie'

# Generated at 2022-06-17 20:06:46.073075
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/httpie/config/dir'
    assert get_default_config_dir() == Path('/httpie/config/dir')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:59.073986
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    # Test for method get_default_config_dir
    # 1. explicitly set through env

# Generated at 2022-06-17 20:07:09.275556
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    with tempfile.TemporaryDirectory() as tmpdir:
        config = BaseConfigDict(path=os.path.join(tmpdir, 'config.json'))
        config.save()
        with open(os.path.join(tmpdir, 'config.json'), 'r') as f:
            data = json.load(f)
            assert data == {'__meta__': {'httpie': __version__}}


# Generated at 2022-06-17 20:07:17.053933
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import tempfile
    import shutil
    import errno
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the config file
    config_file = Path(tmpdir) / 'config.json'
    config_file.touch()
    # Create the config object
    config = BaseConfigDict(config_file)

    # Test if the config file is empty
    with pytest.raises(ConfigFileError):
        config.load()

    # Test if the config file is not a valid json file
    with open(config_file, 'w') as f:
        f.write('{')

# Generated at 2022-06-17 20:07:26.597718
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:07:31.448383
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:07:38.425644
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:41.766855
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:07:49.894741
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a temporary file
        with tempfile.NamedTemporaryFile(mode='w', dir=tmpdirname, delete=False) as f:
            # Write some data to the file
            f.write('{"a": 1, "b": 2}')
        # Create a new BaseConfigDict object
        config = BaseConfigDict(Path(f.name))
        # Load the data from the file
        config.load()
        # Check if the data was loaded correctly
        assert config['a'] == 1
        assert config['b'] == 2


# Generated at 2022-06-17 20:07:58.581892
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:06.286195
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:08:07.820949
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:21.416912
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert os.path.exists('/tmp/test_BaseConfigDict_ensure_directory')
    os.rmdir('/tmp/test_BaseConfigDict_ensure_directory')


# Generated at 2022-06-17 20:08:24.853456
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:29.212107
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:33.980495
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    config = TestConfig(Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:08:35.364497
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:08:46.026435
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 4. XDG
    # 4.1. explicit

# Generated at 2022-06-17 20:08:49.727604
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:08:58.016073
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config/')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:03.666243
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'test_config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:05.977798
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:09:35.384828
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1.
    # When HTTPIE_CONFIG_DIR is set, return the value of HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test 2.
    # When HTTPIE_CONFIG_DIR is not set, return the default config dir
    # for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-17 20:09:39.045502
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:09:40.646891
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:42.535051
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import DEFAULT_CONFIG_DIR
    assert DEFAULT_CONFIG_DIR == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:47.509580
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie/config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_path.write_text('{"a": 1}')
    config = Config(config_dir)
    assert config['a'] == 1
    config_path.unlink()
    config_path.parent.rmdir()


# Generated at 2022-06-17 20:09:58.427787
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: Environment variable set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 3: Windows
    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / 'httpie'

    # Cleanup
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:10:08.575097
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG


# Generated at 2022-06-17 20:10:17.127280
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a directory
    dir_name = "test_dir"
    os.mkdir(dir_name)

    # Create a file in the directory
    file_name = "test_file.json"
    file_path = os.path.join(dir_name, file_name)
    with open(file_path, "w") as f:
        f.write("{}")

    # Create a BaseConfigDict object
    config = BaseConfigDict(Path(file_path))

    # Test load method
    config.load()

    # Delete the directory
    os.rmdir(dir_name)

# Generated at 2022-06-17 20:10:20.993520
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'test_config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:26.911266
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for case when directory exists
    config_dir = Path('/tmp')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()

    # Test for case when directory does not exist
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()

    # Test for case when directory is not writable
    config_dir = Path('/root')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)

# Generated at 2022-06-17 20:11:04.853572
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:13.848167
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        home_dir = Path.home()
        legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir(mode=0o700, parents=True)
        assert get_default_config_dir() == legacy_config_dir
        legacy_config_dir.rmdir()


# Generated at 2022-06-17 20:11:15.179892
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:26.047410
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ConfigFileError
    from httpie.config import get_default_config_dir

    # test for method get_default_config_dir
    # 1

# Generated at 2022-06-17 20:11:27.351442
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:37.755384
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import unittest
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    class TestConfigDictTestCase(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config = TestConfigDict(self.temp_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_save(self):
            self.config['foo'] = 'bar'
            self.config.save()
            self.assertTrue(os.path.exists(self.config.path))

    unittest.main()

# Generated at 2022-06-17 20:11:39.488961
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:47.484921
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)

# Generated at 2022-06-17 20:11:59.108883
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import PluginRegistry
    from httpie.plugins import plugin_manager


# Generated at 2022-06-17 20:12:01.224913
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'