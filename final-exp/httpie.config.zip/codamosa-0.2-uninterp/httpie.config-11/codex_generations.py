

# Generated at 2022-06-17 20:02:28.961108
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:33.119984
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:02:36.042294
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:44.445615
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:56.187081
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:02:58.149300
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:03:01.331768
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:03:10.454151
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIR

    if is_windows:
        config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        config_dir = DEFAULT_CONFIG_DIR

    with tempfile.TemporaryDirectory() as tmpdirname:
        config_dir = os.path.join(tmpdirname, config_dir)
        config_file = os.path.join(config_dir, 'config.json')
        config = BaseConfigDict(config_file)
        config.save()

# Generated at 2022-06-17 20:03:13.472104
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_load'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:20.375685
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    # Test for explicit $XDG_CONFIG_HOME

# Generated at 2022-06-17 20:03:30.095833
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:32.639862
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:40.851493
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:03:44.203222
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_save.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:03:47.069568
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:52.269719
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()
    assert not config_dict.path.exists()


# Generated at 2022-06-17 20:04:00.869461
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:04:09.357293
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    import shutil
    import httpie.config

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'config.json')
    with open(file_path, 'w') as f:
        f.write(json.dumps({"default_options": ["--form"]}))

    # Test load
    config = httpie.config.Config(directory=tmpdir)
    config.load()
    assert config['default_options'] == ["--form"]

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 20:04:15.362900
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name, delete=False)
    # Write data to the temporary file
    temp_file.write(b'{"key": "value"}')
    temp_file.close()

    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(path=temp_file.name)
    # Load the data from the temporary file
    base_config_dict.load()
    # Check if the data is loaded correctly
    assert base_config_dict['key'] == 'value'

    # Remove the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:04:16.886560
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:30.836950
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'

# Generated at 2022-06-17 20:04:32.999175
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.is_new() == False
    config.delete()
    assert config.is_new() == True


# Generated at 2022-06-17 20:04:39.617008
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_load'))
    config.load()
    assert config == {}
    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}}
    config.delete()


# Generated at 2022-06-17 20:04:46.010351
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:04:57.652320
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: no env var set
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test 2: env var set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 3: env var set to empty string
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test 4: env var set to empty string, legacy config dir exists

# Generated at 2022-06-17 20:05:03.852145
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie/')
    config_dir.mkdir(mode=0o700, parents=True)
    config = BaseConfigDict(path=config_dir / 'test.json')
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:05:05.510274
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:11.701643
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:13.012758
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:05:13.998614
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:20.187542
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:27.642597
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)

# Generated at 2022-06-17 20:05:35.527312
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client'

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:05:37.215261
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:45.131576
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg-config'
    assert get_default_config_dir() == Path('/tmp/xdg-config') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie-config'
    assert get_default_config_dir() == Path('/tmp/httpie-config')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:05:57.736606
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG
    #

# Generated at 2022-06-17 20:06:03.296779
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path('/tmp/test_BaseConfigDict_load')
    config_path.write_text('{"key": "value"}')
    config = BaseConfigDict(config_path)
    config.load()
    assert config['key'] == 'value'
    config_path.unlink()


# Generated at 2022-06-17 20:06:07.495197
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:06:10.200614
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:19.763170
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:33.873861
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    import httpie.config
    import httpie.plugins

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a config file
    config_file = os.path.join(tmpdir, 'config.json')
    with open(config_file, 'w') as f:
        f.write('{"default_options": ["--form"]}')

    # Create a config object
    config = httpie.config.Config(tmpdir)

    # Load the config file
    config.load()

    # Check if the config file is loaded
    assert config['default_options'] == ['--form']

    # Remove the temporary directory
    os.rmdir(tmpdir)

# Generated at 2022-06-17 20:06:40.881417
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    import os
    import json
    import httpie.config

    class TestConfig(httpie.config.BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:06:51.733529
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:57.929349
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir
    from httpie.compat import is_windows

    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:00.002425
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:07:10.231565
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # 1. Test for explicitly set through env
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

        # 2. Test for legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir(mode=0o700, parents=True)
        assert get_default_config_dir() == legacy_config_dir
        legacy_

# Generated at 2022-06-17 20:07:11.214803
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:18.196712
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:26.701033
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxy
    from httpie.plugins.builtin import HTTPIgnoreStdin
    from httpie.plugins.builtin import HTTPFollowRedirect

# Generated at 2022-06-17 20:07:30.121762
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:07:36.012939
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path=Path('./test_config.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()


# Generated at 2022-06-17 20:07:46.458488
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/httpie/config/dir'
    assert get_default_config_dir() == Path('/httpie/config/dir')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:47.606647
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:55.652615
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # Test for XDG
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
        assert get_default_config_dir() == Path('/tmp/xdg/httpie')
        # Test for legacy
        os.environ[ENV_XDG_CONFIG_HOME] = ''
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        # Test for explicitly set
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir

# Generated at 2022-06-17 20:08:03.356521
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/httpie/config/dir'
    assert get_default_config_dir() == Path('/httpie/config/dir')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:08:10.384034
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:08:12.603124
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:20.180084
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'

# Generated at 2022-06-17 20:08:32.125254
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # 1. explicitly set through env
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2. legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir()
        assert get_default_config_dir() == legacy_config_dir
        legacy_config_dir.rmdir()

        # 3. XDG

# Generated at 2022-06-17 20:08:35.421854
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()



# Generated at 2022-06-17 20:08:47.153072
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR

    if is_windows:
        temp_dir = os.path.expandvars('%APPDATA%')
    else:
        temp_dir = tempfile.gettempdir()

    temp_dir = os.path.join(temp_dir, 'httpie')
    temp_config_file = os.path.join(temp_dir, 'config.json')
    temp_config_dict = BaseConfigDict(temp_config_file)
    temp_config_dict['default_options'] = ['--form']
    temp_config_dict.save()


# Generated at 2022-06-17 20:08:50.045962
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:00.680144
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:05.240005
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie-test')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:09:11.004388
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert get_default_config_dir() == Path(env_config_dir)

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:09:22.141924
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    xdg_config_dir = xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    # 1. Test for explicit

# Generated at 2022-06-17 20:09:24.723913
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:09:27.013009
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:09:33.248655
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    with open('test.json', 'r') as f:
        assert f.read() == '{\n    "__meta__": {\n        "httpie": "1.0.3"\n    }\n}\n'
    os.remove('test.json')


# Generated at 2022-06-17 20:09:39.508735
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:09:58.317756
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   - $XDG_CONFIG_HOME is not set
    #   - $HOME/.config exists
    #   - $HOME/.httpie does not exist
    #   - $HOME/.config/httpie does not exist
    #   - $HOME/.config/httpie is created
    #   - $HOME/.config/httpie is returned
    with tempfile.TemporaryDirectory() as tmpdir:
        home_dir = Path(tmpdir)
        config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
        config_dir.mkdir()
        assert get_default_config_dir() == config_dir / DEFAULT_CONFIG_DIRNAME

    # Test 2:
    #   - $XDG_CONFIG_HOME is not set
    #   - $

# Generated at 2022-06-17 20:10:07.207162
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:10:14.704708
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.write_text('{}')
    config = Config(config_dir)
    config.save()
    assert config_file.read_text() == '{\n    "default_options": []\n}'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:16.381543
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:24.164008
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test 2: Legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        if legacy_config_dir.exists():
            assert get_default_config_dir() == legacy_config_dir
        else:
            # Test 3: XDG
            xdg_config_home_dir = os.environ.get(
                ENV_XDG_CONFIG_HOME,  # 4.1. explicit
                Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
            )

# Generated at 2022-06-17 20:10:28.303675
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:10:35.541575
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:10:36.826264
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:38.432481
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:10:45.458114
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a config file
    config_file = os.path.join(tmpdir, 'config.json')
    config = BaseConfigDict(config_file)
    config['key'] = 'value'
    config.save()

    # Check the content of the config file
    with open(config_file, 'r') as f:
        data = json.load(f)
        assert data['key'] == 'value'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 20:11:04.397474
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:12.555114
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:14.846369
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:11:18.932290
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:25.937390
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_XDG_CONFIG_HOME]
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:11:36.751377
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 3: HTTPIE_CONFIG_DIR set to empty string
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 4: HTTPIE_CONFIG_DIR set to empty string, XDG_CONFIG_HOME set

# Generated at 2022-06-17 20:11:38.220830
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:40.906362
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:11:43.921118
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:11:52.301099
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:12:11.092652
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:12:13.405782
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()
