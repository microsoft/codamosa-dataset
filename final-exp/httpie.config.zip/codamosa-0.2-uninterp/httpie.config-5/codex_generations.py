

# Generated at 2022-06-17 20:02:31.031564
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_path = temp_dir / 'config.json'
        config = TestConfigDict(config_path)
        config.load()
        assert config == {}
        config['foo'] = 'bar'
        config.save()
        config = TestConfigDict(config_path)
        config.load()
        assert config == {'foo': 'bar'}
        with open(config_path, 'w') as f:
            f.write('{')

# Generated at 2022-06-17 20:02:34.951113
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/')
    config = BaseConfigDict(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:02:37.036940
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:44.481141
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    tmpdir = tempfile.TemporaryDirectory()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir.name)
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=Path(tmpfile.name))
    # Call method ensure_directory
    config.ensure_directory()
    # Check if the directory exists
    assert Path(tmpdir.name).exists()
    # Check if the file exists
    assert Path(tmpfile.name).exists()
    # Delete the temporary directory
    tmpdir.cleanup()


# Generated at 2022-06-17 20:02:50.448603
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:00.042730
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    import os
    import json
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    try:
        tmpdir = tempfile.mkdtemp()
        path = os.path.join(tmpdir, 'test.json')
        config = TestConfig(path)
        config['test'] = 'test'
        config.save()
        with open(path, 'r') as f:
            data = json.load(f)
        assert data['test'] == 'test'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-17 20:03:04.207368
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.delete()
    assert not config_file.exists()

# Generated at 2022-06-17 20:03:05.984933
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:09.460750
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('config.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:03:20.397801
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import errno
    import stat

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

    def check_permission(path):
        st = os.stat(path)
        return bool(st.st_mode & stat.S_IRWXU)

    def check_directory_exists(path):
        return os.path.isdir(path)

    def check_file_exists(path):
        return os.path.isfile(path)

    def check_file_content(path, content):
        with open(path, 'r') as f:
            return f.read() == content

    def check_file_permission(path):
        st = os.stat

# Generated at 2022-06-17 20:03:31.662858
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:42.227969
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variables set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    # Test 4: $HTTPIE_CONFIG_DIR set, $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'


# Generated at 2022-06-17 20:03:46.637358
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_dir = temp_dir / 'config' / 'httpie'
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(path=config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_dir.is_dir()
        rmtree(temp_dir)


# Generated at 2022-06-17 20:03:52.484307
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:56.883722
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory/config.json'))
    config.ensure_directory()
    assert os.path.exists('/tmp/test_BaseConfigDict_ensure_directory')
    os.rmdir('/tmp/test_BaseConfigDict_ensure_directory')


# Generated at 2022-06-17 20:04:04.435192
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:08.199153
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:04:10.152911
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:18.759791
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file.name)
    # Call the method ensure_directory
    config_dict.ensure_directory()
    # Check if the directory exists
    assert os.path.exists(temp_file.name)
    # Delete the temporary file
    temp_file.close()
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:04:21.817916
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:27.849209
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:29.306455
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/test_config.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()


# Generated at 2022-06-17 20:04:30.594264
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:32.199479
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:33.360162
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:40.290486
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:45.832046
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"foo": "bar"}')
    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:47.747439
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:58.269798
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

    tmpdir = tempfile.mkdtemp()
    if is_windows:
        tmpdir = tmpdir.replace('\\', '/')

    test_config = TestConfig(tmpdir + '/config.json')
    test_config.save()
    assert os.path.exists(tmpdir + '/config.json')
    with open(tmpdir + '/config.json', 'r') as f:
        data = json.load(f)
        assert data['__meta__']['httpie'] == __version__
       

# Generated at 2022-06-17 20:05:05.334493
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

# Generated at 2022-06-17 20:05:12.834657
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:05:17.425681
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg/httpie')

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config/httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:05:20.822594
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.temp_dir, 'config')
            self.config_file = os.path.join(self.config_dir, 'config.json')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_save(self):
            config = Config(self.config_dir)
            config.save()
            self.assertTrue(os.path.exists(self.config_file))

    unittest.main()

# Generated at 2022-06-17 20:05:22.032290
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:05:24.839772
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:28.016771
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:05:29.293120
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:35.657136
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file.name)
    # Save the BaseConfigDict object
    config.save()
    # Check if the file exists
    assert os.path.isfile(temp_file.name)
    # Check if the file is empty
    assert os.path.getsize(temp_file.name) == 0
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:05:44.552694
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: $HTTPIE_CONFIG_DIR is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 2: $HTTPIE_CONFIG_DIR is not set
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test 2.1: $XDG_CONFIG_HOME is set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar/httpie')

    # Test 2.2: $XDG_CONFIG_HOME is not set

# Generated at 2022-06-17 20:05:57.554755
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:06:04.277827
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = BaseConfigDict(path=Path('test_config.json'))
    config_file.load()
    assert config_file == {}


# Generated at 2022-06-17 20:06:11.687338
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:21.596699
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import get_default_config_dir

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        # test for windows
        if is_windows:
            config_dir = DEFAULT_WINDOWS_CONFIG_DIR
            config

# Generated at 2022-06-17 20:06:27.277749
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:33.069225
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:34.363823
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:06:36.275180
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:06:41.058865
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:45.744238
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()

# Generated at 2022-06-17 20:06:53.234766
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:01.413360
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    import shutil
    import pytest
    from httpie.config import BaseConfigDict

    def create_config_file(config_dir, config_dict):
        config_file = config_dir / 'config.json'
        config_file.write_text(json.dumps(config_dict))
        return config_file

    def create_config_dir():
        return tempfile.mkdtemp()

    def create_config_dict():
        return {'foo': 'bar'}

    def create_invalid_config_dict():
        return 'invalid_config_dict'

    def create_invalid_config_file(config_dir):
        config_file = config_dir / 'config.json'

# Generated at 2022-06-17 20:07:07.711162
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:15.225302
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:25.843979
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   $XDG_CONFIG_HOME is set
    #   $HTTPIE_CONFIG_DIR is not set
    #   ~/.config/httpie exists
    #   ~/.httpie does not exist
    #   $APPDATA is not set
    #   Expected: ~/.config/httpie
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/user/.config'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path('/home/user/.config/httpie')

    # Test 2:
    #   $XDG_CONFIG_HOME is not set
    #   $HTTPIE_CONFIG_DIR is set
    #   ~/.config/httpie does not exist

# Generated at 2022-06-17 20:07:31.530757
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:35.168979
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('./test_config.json'))
    config['test'] = 'test'
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:07:39.212723
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:40.718671
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.is_new() == False

# Generated at 2022-06-17 20:07:43.690666
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:07:45.712543
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:07:49.888439
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:55.875722
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:08:04.106326
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    os.environ['HTTPIE_CONFIG_DIR'] = ''
    os.environ['XDG_CONFIG_HOME'] = ''
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    os.environ['HTTPIE_CONFIG_DIR'] = ''
    os.environ['XDG_CONFIG_HOME'] = ''
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test for Linux with HTTPIE_CONFIG_DIR
    os.environ['HTTPIE_CONFIG_DIR'] = '/tmp/httpie'
    os.environ['XDG_CONFIG_HOME'] = ''

# Generated at 2022-06-17 20:08:05.797518
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:13.448425
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:08:17.524023
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:21.016353
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    temp_file = temp_dir / 'test.json'
    # Create a BaseConfigDict object
    test_obj = BaseConfigDict(temp_file)
    # Call the method ensure_directory
    test_obj.ensure_directory()
    # Check if the directory is created
    assert temp_dir.exists()
    # Remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:08:26.022890
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:08:34.018558
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from os import chmod, stat
    from stat import S_IRUSR, S_IWUSR, S_IXUSR
    from httpie.config import BaseConfigDict
    with TemporaryDirectory() as tempdir:
        path = Path(tempdir) / 'test.json'
        config = BaseConfigDict(path)
        config.ensure_directory()
        assert stat(tempdir).st_mode & S_IRUSR
        assert stat(tempdir).st_mode & S_IWUSR
        assert stat(tempdir).st_mode & S_IXUSR


# Generated at 2022-06-17 20:08:45.029373
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    import shutil
    import json

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:09:01.373215
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    import shutil
    import httpie.config

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write JSON data into temporary file
    data = {'key1': 'value1', 'key2': 'value2'}
    json.dump(data, tmpfile)
    tmpfile.close()
    # Load the temporary file
    config = httpie.config.BaseConfigDict(path=tmpfile.name)
    config.load()
    # Remove the directory after the test
    shutil.rmtree(tmpdir)
    # Assert the data
    assert config['key1'] == 'value1'
   

# Generated at 2022-06-17 20:09:05.200703
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('./test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:09:08.039371
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:09:19.631529
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import errno
    import pytest

    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    temp_dir = tempfile.mkdtemp()
    test_config_dict = TestConfigDict(Path(temp_dir) / 'test.json')
    test_config_dict.ensure_directory()
    assert os.path.exists(temp_dir)

    # Test if the exception is raised when the directory already exists
    with pytest.raises(OSError):
        test_config_dict.ensure_directory()

    # Test if the exception is raised when the directory is not writable
    os.chmod(temp_dir, 0o444)

# Generated at 2022-06-17 20:09:26.882195
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file.name)
    # Call the method ensure_directory
    config.ensure_directory()
    # Check if the directory exists
    assert os.path.exists(temp_dir.name)
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:09:37.424444
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file in the temporary directory
    temp_file = temp_dir / 'config.json'
    # Create a temporary config object
    temp_config = BaseConfigDict(temp_file)
    # Create a temporary dictionary
    temp_dict = {'default_options': []}
    # Update the temporary config object with the temporary dictionary
    temp_config.update(temp_dict)
    # Save the temporary config object
    temp_config.save()
    # Check if the temporary file exists
    assert temp_file.exists()
    # Check if the temporary file is empty
    assert temp_file.stat().st_size == 0
    # Delete the temporary directory
    temp_dir.rmdir()

# Generated at 2022-06-17 20:09:41.938995
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:44.611098
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.save()
    assert Path('/tmp/config.json').exists()


# Generated at 2022-06-17 20:09:48.532802
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:09:54.835930
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:11.446550
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:13.595032
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:10:15.343410
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:23.397953
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert DEFAULT_CONFIG_DIR == get_default_

# Generated at 2022-06-17 20:10:26.926194
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:10:29.473883
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:32.893905
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:36.680718
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:10:41.224509
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:45.649829
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path(__file__).parent / 'test_config'
    config_dir.mkdir(exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:15.873931
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:26.251788
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No env var set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    # Test 3: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')

    # Test 4: Windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

# Generated at 2022-06-17 20:11:31.854137
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(parents=True)
    config_path.write_text('{"foo": "bar"}')

    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'
    config_path.unlink()
    config_path.parent.rmdir()

# Generated at 2022-06-17 20:11:42.304599
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    import os.path
    import shutil
    import sys
    import unittest

    class BaseConfigDictTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_file = os.path.join(self.temp_dir, 'config.json')
            self.config_dict = BaseConfigDict(self.config_file)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_load_empty(self):
            self.config_dict.load()
            self.assertEqual(self.config_dict, {})


# Generated at 2022-06-17 20:11:45.713648
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:58.443588
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:12:07.206034
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:12:16.903014
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    if is_windows:
        return

    with tempfile.TemporaryDirectory() as tmpdirname:
        config_dir = os.path.join(tmpdirname, 'config')
        config_file = os.path.join(config_dir, 'config.json')
        config = BaseConfigDict(config_file)
        config.save()
        assert os.path.exists(config_file)
        with open(config_file, 'r') as f:
            data = json.load(f)
        assert '__meta__' in data
        assert 'httpie' in data['__meta__']
        assert data['__meta__']['httpie'] == __