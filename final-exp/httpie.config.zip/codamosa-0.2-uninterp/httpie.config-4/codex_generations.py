

# Generated at 2022-06-17 20:02:24.212468
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = BaseConfigDict(path=Path("test_config.json"))
    config_file.load()
    assert config_file == {}


# Generated at 2022-06-17 20:02:30.837534
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:41.732843
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:48.173433
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    import os
    import json
    import tempfile
    import errno
    import pytest

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.com'
        about = 'about'

    def create_config_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as tmp:
            tmp.write(content)
        return path

    def create_config_dir():
        return tempfile.mkdtemp()

    def create_config_dir_with_file(content):
        dir_path = create_config_dir()
        path = create_config_file(content)
        os

# Generated at 2022-06-17 20:02:49.336960
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:50.747982
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:54.058579
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('./config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:03:01.314599
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_file.touch()
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.save()
    assert config_file.read_text() == '{"default_options": ["--form"], "__meta__": {"httpie": "2.0.0"}}\n'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:03:10.422122
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for normal case
    config = BaseConfigDict(Path('/tmp/test_httpie_config/config.json'))
    config.ensure_directory()
    assert os.path.exists('/tmp/test_httpie_config')
    assert os.path.isdir('/tmp/test_httpie_config')
    os.rmdir('/tmp/test_httpie_config')

    # Test for abnormal case
    config = BaseConfigDict(Path('/tmp/test_httpie_config/config.json'))
    os.mkdir('/tmp/test_httpie_config')
    with pytest.raises(OSError):
        config.ensure_directory()
    os.rmdir('/tmp/test_httpie_config')



# Generated at 2022-06-17 20:03:12.389585
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:29.154140
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_path = os.path.join(self.temp_dir, 'config.json')
            self.config = BaseConfigDict(self.config_path)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_save_fail_silently(self):
            self.config.save(fail_silently=True)

        def test_save_fail_silently_exception(self):
            with self.assertRaises(ConfigFileError):
                self.config.save(fail_silently=False)

   

# Generated at 2022-06-17 20:03:33.304110
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:03:36.543137
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:03:42.930266
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config_dir')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:47.015354
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.config_file = os.path.join(self.tempdir, 'config.json')
            self.config = BaseConfigDict(self.config_file)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_load_empty_file(self):
            with open(self.config_file, 'w') as f:
                f.write('')
            self.config.load()
            self.assertEqual(self.config, {})


# Generated at 2022-06-17 20:03:53.488618
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:59.767567
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'


# Generated at 2022-06-17 20:04:05.044794
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:07.500172
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:13.590900
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:04:23.622281
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.com'
        about = 'about'

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:04:28.394470
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:34.009649
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie_test')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:45.322605
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:04:57.384701
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    def create_config_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as f:
            f.write(content)
        return Path(path)

    def remove_config_file(path):
        os.remove(path)

    def get_config_dict(path):
        config_dict = BaseConfigDict(path)
        config_dict.load()
        return config_dict

    def test_load_empty_file():
        path = create_config_file('')
        config_dict = get_config_dict(path)
        assert config_dict == {}
        remove_config_file(path)

# Generated at 2022-06-17 20:05:05.290161
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.write_text('{"default_options": ["--form"]}')

    config = Config(config_dir)
    config.load()
    assert config.default_options == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:05:08.457992
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:05:11.927730
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('config.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:05:16.679753
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_dict = BaseConfigDict(path=tmpdir / 'config.json')
        assert not (tmpdir / 'config.json').exists()
        config_dict.ensure_directory()
        assert (tmpdir / 'config.json').exists()

# Generated at 2022-06-17 20:05:19.180300
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:31.029190
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:05:36.728618
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:38.892851
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:05:43.433351
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:50.853123
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie import __version__

    if is_windows:
        temp_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        temp_dir = Path(tempfile.gettempdir()) / 'httpie'
    temp_dir.mkdir(parents=True, exist_ok=True)
    temp_config_file = temp_dir / 'config.json'
    if temp_config_file.exists():
        temp_config_file.unlink()
    temp_config_dict = BaseConfigDict(path=temp_config_file)
    temp_config_dict

# Generated at 2022-06-17 20:05:54.260604
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()


# Generated at 2022-06-17 20:06:06.156798
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    def get_default_config_dir():
        if is_windows:
            return DEFAULT_WINDOWS_CONFIG_DIR
        else:
            return DEFAULT_CONFIG_DIR

    # test for method save of class BaseConfigDict
    # test for save a new config file
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = Path(tmpdirname)
        config_file = BaseConfigDict(path=tmpdir / 'config.json')
        config_file.save()

# Generated at 2022-06-17 20:06:14.802662
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmd

# Generated at 2022-06-17 20:06:23.251959
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test default
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test with XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    # Test with HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test with HTTPIE_CONFIG_DIR and XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_

# Generated at 2022-06-17 20:06:26.303776
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:31.243351
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:32.050768
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:06:35.387680
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:06:39.101404
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:06:39.889730
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:06:40.993941
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:45.958197
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_save'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:06:49.290880
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:06:51.915665
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:00.511793
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / 'httpie'



# Generated at 2022-06-17 20:07:14.337351
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   $XDG_CONFIG_HOME is set
    #   $HTTPIE_CONFIG_DIR is not set
    #   ~/.config/httpie exists
    #   ~/.httpie does not exist
    #   Expected result: ~/.config/httpie
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/user/.config'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    home_dir = Path.home()
    xdg_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    xdg_config_dir.mkdir(mode=0o700, parents=True)
    xdg_config_dir = xdg_config_dir / DEFAULT_

# Generated at 2022-06-17 20:07:21.544158
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config_file.unlink(missing_ok=True)
    config_dir.rmdir()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:28.550734
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import unittest
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    class TestBaseConfigDict(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.config_dir = Path(self.temp_dir) / 'config'
            self.config_file = self.config_dir / 'config.json'
            self.config = TestConfigDict(self.config_dir)

        def tearDown(self):
            shutil.r

# Generated at 2022-06-17 20:07:31.655186
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:07:37.233605
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:43.540953
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:52.608142
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    import tempfile
    import os
    import json
    import pytest
    import shutil

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    with tempfile.TemporaryDirectory() as tmpdir:
        config_dir = Path(tmpdir)
        config_path = config_dir / 'test.json'
        config = TestConfigDict(config_path)
        config.save()
        assert config_path.exists()
        with open(config_path, 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie']

# Generated at 2022-06-17 20:07:54.443149
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:08:01.124329
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:07.354008
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:08:14.022409
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()


# Generated at 2022-06-17 20:08:18.976297
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:08:23.192638
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    import json
    import os
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.tempdir_path = Path(self.tempdir.name)
            self.config_path = self.tempdir_path / 'config.json'
            self.config = BaseConfigDict(self.config_path)

        def tearDown(self):
            self.tempdir.cleanup()

        def test_load_empty(self):
            self.config.load()
            self.assertEqual(self.config, {})


# Generated at 2022-06-17 20:08:33.246342
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPDigestAuth

# Generated at 2022-06-17 20:08:34.863320
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:37.365153
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:08:44.625475
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    with tempfile.TemporaryDirectory() as tmpdirname:
        path = os.path.join(tmpdirname, 'config.json')
        config = BaseConfigDict(path)
        config['default_options'] = []
        config.save()
        with open(path, 'r') as f:
            data = json.load(f)
        assert data['default_options'] == []

# Generated at 2022-06-17 20:08:56.757837
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path(__file__).parent / 'config'
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    assert config['__meta__']['httpie'] == '0.9.9'
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'


# Generated at 2022-06-17 20:09:02.181947
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/test_config.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()
    assert not config_dict.path.exists()

# Generated at 2022-06-17 20:09:11.400749
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1:
    #   - $XDG_CONFIG_HOME is not set
    #   - $HOME/.config exists
    #   - $HOME/.httpie does not exist
    #   - $HOME/.config/httpie does not exist
    # Expected result:
    #   - $HOME/.config/httpie
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    home_dir = Path.home()
    config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    config_dir.mkdir(mode=0o700, parents=True)
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.rmdir()
    assert get_

# Generated at 2022-06-17 20:09:24.567967
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        if is_windows:
            tmpdir = os.path.expandvars(tmpdir)
        config_path = os.path.join(tmpdir, 'config.json')
        config = TestConfigDict(path=config_path)
        config.save()
        with open(config_path, 'r') as f:
            data = json.load(f)

# Generated at 2022-06-17 20:09:27.180765
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:09:37.635791
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test default
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    # Test legacy
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / '.httpie')
    assert get_default_config_dir() == Path.home() / '.httpie'
    # Test explicit
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / 'httpie')
    assert get_default_config_dir() == Path.home() / 'httpie'
    # Test Windows
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-17 20:09:41.553658
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_httpie_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:09:42.830489
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:50.475244
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import shutil
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary directory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # Create a temporary file
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)

    # Create a BaseConfigDict object
    config = BaseConfigDict(path=tmpfile.name)
    # Ensure the directory of the temporary file
    config.ensure_directory()
    # Check if the directory exists

# Generated at 2022-06-17 20:10:00.700204
# Unit test for method ensure_directory of class BaseConfigDict

# Generated at 2022-06-17 20:10:06.830372
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    config_dir = Path(temp_dir) / 'httpie'
    config_file = config_dir / 'config.json'

    config = Config(config_dir)
    config.ensure_directory()

    assert config_dir.exists()
    assert config_file.exists()

    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 20:10:13.218397
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)

    config = Config(config_dir)
    config.save()

    assert config_file.exists()

    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:10:20.572620
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    temp_dir = tempfile.mkdtemp()
    config_file_path = os.path.join(temp_dir, 'config.json')

    class TestConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)
            self['key'] = 'value'

    config = TestConfig(config_file_path)
    config.save()

    with open(config_file_path, 'r') as f:
        data = json.load(f)
        assert data['key'] == 'value'

    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 20:10:31.349757
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:10:41.809619
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:47.356947
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie_test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_dir.is_absolute()
    assert config_dir.is_resolved()
    assert config_dir.stat().st_mode == 0o40700
    config.delete()
    config_dir.rmdir()
    assert not config_dir.exists()


# Generated at 2022-06-17 20:10:59.249492
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home

# Generated at 2022-06-17 20:11:01.091306
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('config.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:11:02.878894
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:04.274557
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:11:05.403257
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:11.267617
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"foo": "bar"}')
    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:11:14.676000
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:33.279353
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:34.747495
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:36.194912
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:44.027842
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path)
    tmp_file_path = Path(tmp_file.name)
    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(tmp_file_path)
    # Call method ensure_directory
    base_config_dict.ensure_directory()
    # Check if the directory exists
    assert tmp_file_path.parent.exists()
    # Delete the temporary directory
    tmp_dir.cleanup()


# Generated at 2022-06-17 20:11:52.735779
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import DEFAULT_CONFIG_DIR

    # test get_default_config_dir
    #

# Generated at 2022-06-17 20:12:00.466998
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path)
    temp_file_path = Path(temp_file.name)
    # Create a BaseConfigDict object with the temporary file as path
    temp_config_dict = BaseConfigDict(temp_file_path)
    # Call the method ensure_directory
    temp_config_dict.ensure_directory()
    # Check that the temporary directory exists
    assert temp_dir_path.exists()
    # Check that the temporary file exists
    assert temp_file_path.exists()
    # Delete the temporary directory
    temp_dir.cleanup

# Generated at 2022-06-17 20:12:05.257550
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path(__file__).parent / 'test_config_dir'
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:10.800547
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:20.429023
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # 1. explicitly set through env
    env_config_dir = os.environ.get('HTTPIE_CONFIG_DIR')
    if env_config_dir:
        return Path(env_config_dir)

    # 2. Windows
    if is_windows:
        return DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        return legacy_config_dir

    # 4. XDG
    xdg_config_home_dir = os.environ