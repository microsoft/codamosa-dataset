

# Generated at 2022-06-17 20:02:23.972529
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path='/tmp/test.json')
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:02:25.660647
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:31.508731
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_dict = BaseConfigDict(Path('test_config.json'))
    with open('test_config.json', 'w') as f:
        f.write('{"key": "value"')
    with pytest.raises(ConfigFileError):
        config_dict.load()

    # Test for valid json file
    with open('test_config.json', 'w') as f:
        f.write('{"key": "value"}')
    config_dict.load()
    assert config_dict['key'] == 'value'
    os.remove('test_config.json')

    # Test for non-existent file
    with pytest.raises(ConfigFileError):
        config_dict.load()


# Generated at 2022-06-17 20:02:35.027340
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:02:40.956821
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:02:42.616556
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:46.590214
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigDict(BaseConfigDict):
        name = 'test'

    test_config_dict = TestConfigDict(Path('/tmp/test.json'))
    test_config_dict.ensure_directory()
    assert test_config_dict.path.parent.exists()
    test_config_dict.path.parent.rmdir()


# Generated at 2022-06-17 20:02:56.578427
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a temp file
    fd, path = tempfile.mkstemp()
    # write some data to the file
    with open(path, 'w') as f:
        f.write('{"a": "b"}')

    # create a BaseConfigDict object with the temp file
    config = BaseConfigDict(path=path)
    # load the data from the file
    config.load()
    # check the data is loaded correctly
    assert config['a'] == 'b'

    # delete the temp file
    os.remove(path)

# Generated at 2022-06-17 20:03:07.251425
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:03:17.000381
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:03:29.567428
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:32.949712
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:42.712789
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import shutil
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    class TestConfigDict(BaseConfigDict):
        FILENAME = 'test_config.json'
        DEFAULTS = {
            'default_options': []
        }

    def test_config_dir():
        if is_windows:
            return os.path.expandvars('%APPDATA%')
        else:
            return tempfile.mkdtemp()

    def test_config_file(config_dir):
        return os.path.join(config_dir, TestConfigDict.FILENAME)

    def test_config_dict(config_dir):
        return TestConfigDict

# Generated at 2022-06-17 20:03:43.363706
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:44.244000
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:50.674855
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   - $XDG_CONFIG_HOME is not set
    #   - $HOME/.config exists
    #   - $HOME/.config/httpie does not exist
    #   - $HOME/.httpie does not exist
    #
    # Expected result:
    #   - $HOME/.config/httpie
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    home_dir = Path.home()
    home_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    home_config_dir.mkdir(mode=0o700, parents=True)
    home_httpie_config_dir = home_config_dir / DEFAULT_CONFIG_DIRNAME
    home_httpie_config_dir.r

# Generated at 2022-06-17 20:03:54.003635
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:03:59.401994
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('/tmp/test_BaseConfigDict_load')
    path.parent.mkdir(mode=0o700, parents=True)
    path.write_text('{"a": 1}')
    config = BaseConfigDict(path)
    config.load()
    assert config['a'] == 1
    path.unlink()
    path.parent.rmdir()


# Generated at 2022-06-17 20:04:05.155138
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config['test'] = 'test'
    config.save()
    with open('/tmp/test.json', 'r') as f:
        assert f.read() == '{\n    "test": "test"\n}\n'
    os.remove('/tmp/test.json')


# Generated at 2022-06-17 20:04:12.283036
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    def test_config_dir(config_dir):
        config = TestConfigDict(config_dir)
        config.save()
        assert config.path.exists()
        with config.path.open('rt') as f:
            data = json.load(f)
        assert data['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:04:17.617946
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:04:20.548021
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path(__file__).parent.parent / 'config'
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.load()
    assert config['default_options'] == ['--form']

# Generated at 2022-06-17 20:04:27.272186
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config_dict = BaseConfigDict(config_path)
    config_dict.save()
    assert config_path.exists()
    assert config_path.is_file()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:35.569703
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/baz'
    assert get_default_config_dir() == Path('/foo/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:04:47.251200
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: Default
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: Legacy
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / '.httpie')
    assert get_default_config_dir() == Path.home() / '.httpie'

    # Test 3: Windows
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path(
        os.path.expandvars('%APPDATA%')) / 'httpie'

    # Test 4: Explicit
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / 'httpie')
    assert get_default_config_

# Generated at 2022-06-17 20:04:51.590623
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:54.424062
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    assert config.is_new() == True
    config.load()
    assert config.is_new() == False


# Generated at 2022-06-17 20:04:57.328592
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:05:01.212433
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:05:09.677995
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1:
    #   - $XDG_CONFIG_HOME is set
    #   - $HTTPIE_CONFIG_DIR is not set
    #   - ~/.config/httpie exists
    #   - ~/.httpie does not exist
    #   - OS is not Windows
    # Expected result:
    #   - ~/.config/httpie
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/user/.config'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path('/home/user/.config/httpie')

    # Test case 2:
    #   - $XDG_CONFIG_HOME is not set
    #   - $HTTPIE_CONFIG_DIR is not set

# Generated at 2022-06-17 20:05:16.156753
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:05:21.483660
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG


# Generated at 2022-06-17 20:05:27.977396
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

# Generated at 2022-06-17 20:05:29.061064
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:30.550255
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:05:31.989634
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:42.506459
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie import __version__
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR

# Generated at 2022-06-17 20:05:50.086258
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:59.211977
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

   

# Generated at 2022-06-17 20:06:09.713736
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No env var set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    # Test 4: Windows

# Generated at 2022-06-17 20:06:17.944774
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()


# Generated at 2022-06-17 20:06:31.516704
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie'
    assert get_default_config_dir() == Path.home() / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie/'
    assert get_default_config_dir() == Path.home() / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie/config.json'
    assert get_default_config

# Generated at 2022-06-17 20:06:34.411238
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:06:39.944895
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:43.988439
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:06:46.283592
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_httpie_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:51.994025
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:07:00.549082
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: no env vars set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    # Test 3: $XDG_CONFIG_HOME set, but empty
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    # Test 4: $XDG_CONFIG_HOME set, but empty, but $HOME is empty

# Generated at 2022-06-17 20:07:01.865092
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


# Generated at 2022-06-17 20:07:04.396112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:22.838482
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:07:25.810028
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:07:29.301990
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:36.630990
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:45.918462
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:07:57.036911
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config = Config(config_dir)
    config['default_options'] = ['--form']
    config.save()
    with config_file.open('rt') as f:
        data = json.load(f)
    assert data['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:59.818337
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:08:07.119002
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:08:09.632243
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:08:11.078931
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:34.980329
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:45.740097
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: Test default config dir
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: Test config dir with XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    # Test 3: Test config dir with HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 4: Test config dir on Windows

# Generated at 2022-06-17 20:08:58.968913
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:03.897198
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(directory=config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:12.159490
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # 1. explicitly set through env
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2. legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir()
        assert get_default_config_dir() == legacy_config_dir
        legacy_config_dir.rmdir()

        # 3. XDG

# Generated at 2022-06-17 20:09:15.493038
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:17.946088
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('test_config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:09:24.958032
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:09:32.029848
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path=Path('/tmp/test.json'))
    config_dict['test'] = 'test'
    config_dict.save()
    assert Path('/tmp/test.json').exists()
    assert Path('/tmp/test.json').read_text() == '{\n    "test": "test"\n}\n'
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:09:38.399429
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.test.com'
        about = 'test config'

    test_config_dict = TestConfigDict(Path('test.json'))
    test_config_dict.load()
    assert test_config_dict['__meta__']['httpie'] == __version__
    assert test_config_dict['__meta__']['help'] == 'http://help.test.com'
    assert test_config_dict['__meta__']['about'] == 'test config'


# Generated at 2022-06-17 20:10:44.409434
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:10:55.246225
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    assert config.default_options == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:10:56.942589
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:11:06.454194
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test with no env variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test with XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]

    # Test with HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/httpie/config/dir'
    assert get_default_config_dir() == Path('/httpie/config/dir')

# Generated at 2022-06-17 20:11:08.197675
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:10.138517
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:14.676136
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('./test_config.json'))
    config_dict['test_key'] = 'test_value'
    config_dict.save()
    with open('./test_config.json', 'r') as f:
        assert f.read() == '{\n    "test_key": "test_value"\n}\n'
    os.remove('./test_config.json')


# Generated at 2022-06-17 20:11:19.067760
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:21.057993
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:23.715440
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config['test'] = 'test'
    config.save()
    assert Path('test.json').exists()
    os.remove('test.json')
