

# Generated at 2022-06-17 20:02:40.547756
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    with tempfile.TemporaryDirectory() as tempdir:
        config_dir = Path(tempdir)
        config_path = config_dir / 'config.json'
        config = TestConfigDict(config_path)
        config.load()
        assert config == {}
        config['foo'] = 'bar'
        config.save()
        config = TestConfigDict(config_path)
        config.load()

# Generated at 2022-06-17 20:02:45.866194
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.touch()
    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:02:49.016315
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:00.183265
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    if is_windows:
        return

    def create_config_file(content):
        fd, path = tempfile.mkstemp()
        os.close(fd)
        with open(path, 'w') as f:
            f.write(content)
        return Path(path)

    def remove_config_file(path):
        os.remove(path)

    # test for invalid json file
    path = create_config_file('{')

# Generated at 2022-06-17 20:03:02.300517
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:04.149053
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:03:08.284238
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        pass
    config = TestConfigDict(Path('/tmp/test_BaseConfigDict_load.json'))
    config.load()
    assert config == {}
    config.save()
    config.load()
    assert config == {}
    config.delete()


# Generated at 2022-06-17 20:03:15.149162
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_path.unlink()
    config_path.parent.rmdir()


# Generated at 2022-06-17 20:03:18.290566
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.is_new() == False
    config.delete()
    assert config.is_new() == True


# Generated at 2022-06-17 20:03:21.029065
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:03:32.743513
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:03:37.692356
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:44.410532
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:03:47.211782
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:55.684436
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:03:58.600729
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:04:05.805870
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_dict = BaseConfigDict(Path('test.json'))
    try:
        config_dict.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid basedict file: Expecting value: line 1 column 1 (char 0) [test.json]'

    # Test for valid json file
    config_dict = BaseConfigDict(Path('test.json'))
    config_dict.load()
    assert config_dict == {}

    # Test for IOError
    config_dict = BaseConfigDict(Path('test.json'))

# Generated at 2022-06-17 20:04:11.135249
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temporary directory
    filename = os.path.join(tmpdir, 'test.json')
    with open(filename, 'w') as f:
        json.dump({'a': 1}, f)

    # test load
    config = BaseConfigDict(path=filename)
    config.load()
    assert config['a'] == 1

    # remove the directory after the test
    shutil.rmtree(tmpdir)


# Generated at 2022-06-17 20:04:20.969776
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a temp file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # create a BaseConfigDict object
    config = BaseConfigDict(path)

    # write invalid json to the temp file
    with open(path, 'w') as f:
        f.write('{"key": "value"')

    # load the temp file
    try:
        config.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 14 (char 13) [{}]'.format(path)
    else:
        assert False

    # write valid json to the temp file
    with open(path, 'w') as f:
        f.write('{"key": "value"}')

   

# Generated at 2022-06-17 20:04:31.139198
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # Test for XDG
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
        assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME
        del os.environ[ENV_XDG_CONFIG_HOME]

        # Test for legacy ~/.httpie
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
        assert get_default_config_dir() == Path('/tmp')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # Test for default
        assert get_default_

# Generated at 2022-06-17 20:04:43.373428
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    from httpie.config import BaseConfigDict
    with tempfile.TemporaryDirectory() as tempdir:
        test_file = os.path.join(tempdir, 'test.json')
        with open(test_file, 'w') as f:
            json.dump({'a': 1}, f)
        config = BaseConfigDict(test_file)
        config.load()
        assert config['a'] == 1


# Generated at 2022-06-17 20:04:52.976226
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:58.075334
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:05.807868
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:12.430344
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tempdir:
        test_config_dict = TestConfigDict(path=Path(tempdir) / 'config.json')
        test_config_dict.save()
        with open(os.path.join(tempdir, 'config.json'), 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == httpie.__version__

# Generated at 2022-06-17 20:05:15.800996
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:05:19.705357
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_ensure_directory/config.json'))
    config.ensure_directory()
    assert os.path.exists('/tmp/test_BaseConfigDict_ensure_directory')
    os.rmdir('/tmp/test_BaseConfigDict_ensure_directory')



# Generated at 2022-06-17 20:05:28.742043
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import errno
    import pytest

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'helpurl'
        about = 'about'

    def test_load_config_file_error():
        with pytest.raises(ConfigFileError):
            config = TestConfigDict(Path('/tmp/test_config.json'))
            config.load()

    def test_load_config_file_success():
        config = TestConfigDict(Path('/tmp/test_config.json'))
        config['test'] = 'test'
        config.save()
        config.load()

# Generated at 2022-06-17 20:05:39.142320
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import shutil
    from tempfile import mkdtemp
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # create a temporary directory
    tmpdir = mkdtemp()
    # create a temporary file
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    # create a temporary config file
    tmpconfig = os.path.join(tmpdir, 'tmpconfig')
    # create a temporary config file with a parent directory
    tmpconfig_parent = os.path.join(tmpdir, 'tmpconfig_parent', 'tmpconfig')

    # test for a file

# Generated at 2022-06-17 20:05:45.909438
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:05:56.204167
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict('config.json')
    config['default_options'] = []
    config.save()
    config.load()
    assert config['default_options'] == []


# Generated at 2022-06-17 20:06:02.057618
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie/')
    config_dir.mkdir(parents=True, exist_ok=True)
    config = BaseConfigDict(path=config_dir / 'config.json')
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:06:07.532541
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"foo": "bar"}')
    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:06:13.909004
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:06:17.032651
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_load.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:21.429228
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:33.123051
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    import shutil
    import httpie.config

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the file
    filename = os.path.join(tmpdir, 'config.json')
    # Write json file
    with open(filename, 'w') as f:
        json.dump({'foo': 'bar'}, f)

    # Create a Config object
    config = httpie.config.Config(tmpdir)
    # Load the file
    config.load()
    # Check the content
    assert config['foo'] == 'bar'

    # Remove the directory
    shutil.rmtree(tmpdir)



# Generated at 2022-06-17 20:06:39.572566
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:40.871807
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:06:49.146831
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'https://httpie.org/test'
        about = 'Test config file'

    config = TestConfig(Path('/tmp/test.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'https://httpie.org/test'
    assert config['__meta__']['about'] == 'Test config file'


# Generated at 2022-06-17 20:07:05.264240
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:06.519577
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:07:15.115256
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import shutil
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 20:07:25.710238
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)
    # Write some data to the temporary file
    temp_file.write(b'{"key": "value"}')
    temp_file.close()
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file_path)
    # Load the data from the temporary file
    config_dict.load()
    # Check that the data was loaded correctly
    assert config_dict['key'] == 'value'
    # Delete the temporary directory and all of its

# Generated at 2022-06-17 20:07:27.340803
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:34.379308
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    assert config['a'] == 1
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:38.079786
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:49.365320
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4

# Generated at 2022-06-17 20:07:52.060838
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('./test.json'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:07:57.548692
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:17.129676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_dir = temp_dir / 'config'
        config_dir.mkdir()
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_file.exists()
        assert config_file.is_file()
        assert config_file.stat().st_mode & 0o777 == 0o600

# Generated at 2022-06-17 20:08:25.166999
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        if (Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).exists():
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

        # Test for XDG
        else:
            # Test for explicit
            os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
            assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME

            # Test for default

# Generated at 2022-06-17 20:08:26.153391
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:35.178985
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   - no env var set
    #   - no legacy config dir
    #   - no xdg config home
    #   - no xdg config dirs
    #   - no windows
    #   => default config dir
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Test 2:
    #   - no env var set
    #   - no legacy config dir
    #   - no xdg config home
    #   - no xdg config dirs
    #   - windows
    #   => windows config dir

# Generated at 2022-06-17 20:08:45.918973
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG
    #

# Generated at 2022-06-17 20:08:59.937799
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    # test for invalid json file
    path = Path('test.json')
    path.write_text('{')
    test_config = TestConfigDict(path)
    try:
        test_config.load()
        assert False
    except ConfigFileError:
        assert True
    path.unlink()

    # test for valid json file
    path = Path('test.json')
    path.write_text('{"a": 1}')
    test_config = TestConfigDict(path)
    test_config.load()
    assert test_config['a'] == 1
    path.unlink()

    # test for non-existing file

# Generated at 2022-06-17 20:09:09.697643
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path

    class TestConfigDict(BaseConfigDict):
        pass

    with tempfile.TemporaryDirectory() as tempdir:
        path = Path(tempdir) / 'config.json'
        config = TestConfigDict(path)
        config.load()

        assert config == {}

        config['foo'] = 'bar'
        config.save()

        config = TestConfigDict(path)
        config.load()

        assert config == {'foo': 'bar'}

        with open(path, 'w') as f:
            f.write('{')

        with pytest.raises(ConfigFileError):
            config.load()

        os.remove(path)

        config.load()

        assert config == {}



# Generated at 2022-06-17 20:09:10.775128
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:16.274602
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:24.404692
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w+t', dir=temp_dir.name, delete=False)
    # Write some data to the file
    temp_file.write('{"foo": "bar"}')
    temp_file.close()
    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(path=Path(temp_file.name))
    # Load the data from the file
    base_config_dict.load()
    # Check if the data was loaded correctly
    assert base_config_dict == {'foo': 'bar'}
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:10:01.049376
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:09.867386
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree
    from os import chmod, stat
    from stat import S_IRWXU
    from httpie.config import BaseConfigDict

    with TemporaryDirectory() as tmpdirname:
        tmpdir = Path(tmpdirname)
        tmpfile = tmpdir / 'tmpfile'
        tmpdir.mkdir(mode=0o700, parents=True)
        chmod(tmpdirname, 0o000)
        try:
            BaseConfigDict(tmpfile).ensure_directory()
        except OSError:
            pass
        else:
            assert False, 'ensure_directory() should raise OSError'
        finally:
            chmod(tmpdirname, S_IRWXU)

# Generated at 2022-06-17 20:10:14.984399
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import pytest
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)

    # Write some data to the temporary file
    data = {'foo': 'bar'}
    json_string = json.dumps(data)
    temp_file.write(json_string.encode())
    temp_file.close()

    # Create a BaseConfigDict object

# Generated at 2022-06-17 20:10:23.153066
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file = temp_dir / 'config.json'
        config_file.write_text('{"foo": "bar"}')

        config = BaseConfigDict(config_file)
        config.load()
        assert config['foo'] == 'bar'

        config_file.write_text('{"foo": "baz"}')
        config.load()
        assert config['foo'] == 'baz'

        config_file.write_text('{"foo": "baz"')
        try:
            config.load()
        except ConfigFileError:
            pass

# Generated at 2022-06-17 20:10:26.154069
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:31.078162
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:38.012994
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie/')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / 'config.json'
    config_path.touch()
    config = Config(config_dir)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:42.859108
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory.json'))
    config.ensure_directory()
    assert os.path.exists('/tmp/test_BaseConfigDict_ensure_directory.json')
    os.remove('/tmp/test_BaseConfigDict_ensure_directory.json')


# Generated at 2022-06-17 20:10:51.171153
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    invalid_json_file = Path('/tmp/invalid.json')
    invalid_json_file.write_text('{')
    config = BaseConfigDict(invalid_json_file)
    try:
        config.load()
    except ConfigFileError as e:
        assert 'invalid baseconfigdict file' in str(e)
    else:
        assert False, 'Should raise ConfigFileError'
    invalid_json_file.unlink()

    # Test for valid json file
    valid_json_file = Path('/tmp/valid.json')
    valid_json_file.write_text('{"a": 1}')
    config = BaseConfigDict(valid_json_file)
    config.load()
    assert config['a'] == 1
    valid_json_file.un

# Generated at 2022-06-17 20:11:00.089082
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:31.609331
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:34.329990
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:43.590762
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:11:52.419744
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    import os
    import tempfile
    import json
    import errno
    import shutil
    import sys
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, 'config.json')
            self.config = BaseConfigDict(self.tempfile)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_load_empty(self):
            self.config.load()
            self.assertEqual(self.config, {})


# Generated at 2022-06-17 20:11:58.782331
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:12:07.814106
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:12:10.206103
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config.path.exists()


# Generated at 2022-06-17 20:12:12.430403
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:12:21.832080
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        pass

    with tempfile.TemporaryDirectory() as tempdir:
        test_config_dict = TestConfigDict(Path(tempdir) / 'test.json')
        test_config_dict['test'] = 'test'
        test_config_dict.save()
        test_config_dict.clear()
        test_config_dict.load()
        assert test_config_dict['test'] == 'test'

        with open(os.path.join(tempdir, 'test.json'), 'w') as f:
            f.write('{')
        test_config_dict.load()

