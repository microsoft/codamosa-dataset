

# Generated at 2022-06-17 20:02:28.072676
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:02:33.099894
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    import os
    import tempfile
    import json
    import pytest

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)

    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(path=temp_file_path)

    # Write a valid JSON file
    valid_json = {'a': 1, 'b': 2}
    json.dump(valid_json, temp_file)
   

# Generated at 2022-06-17 20:02:34.833232
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:44.516205
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # Test for env HTTPIE_CONFIG_DIR
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # Test for legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        if legacy_config_dir.exists():
            assert get_default_config_dir() == legacy_config_dir

# Generated at 2022-06-17 20:02:49.159325
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    temp_file = temp_dir / 'config.json'
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file)
    # Call method ensure_directory
    config_dict.ensure_directory()
    # Check if the directory exists
    assert temp_dir.exists()
    # Remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:02:55.275328
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    assert config['a'] == 1
    assert config['b'] == 2
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:02:56.713806
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:58.694726
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:01.424378
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config = BaseConfigDict(Path('test_config.json'))
    test_config.load()
    assert test_config == {}


# Generated at 2022-06-17 20:03:07.575291
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:03:16.317464
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:25.974335
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / 'httpie'

# Generated at 2022-06-17 20:03:38.169671
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    class TestConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
    test_config = TestConfig(Path('test_config.json'))
    try:
        test_config.load()
    except ConfigFileError as e:
        assert e.args[0] == 'invalid testconfig file: Expecting value: line 1 column 1 (char 0) [test_config.json]'
    else:
        assert False
    # Test for valid json file
    test_config.path.write_text('{"a": 1, "b": 2}')
    test_config.load()
    assert test_config['a'] == 1
    assert test_config['b'] == 2
    test_config.path.unlink()

#

# Generated at 2022-06-17 20:03:44.841560
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:03:56.937691
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import get_default_config_dir
    from httpie.config import ConfigFileError

# Generated at 2022-06-17 20:04:04.118870
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:11.199364
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write json data to the temporary file
    json_data = {'key1': 'value1', 'key2': 'value2'}
    json.dump(json_data, tmpfile)
    tmpfile.close()

    # Create a BaseConfigDict instance
    config_dict = BaseConfigDict(path=tmpfile.name)
    # Load the data from the temporary file
    config_dict.load()

    # Check the data
    assert config_dict == json

# Generated at 2022-06-17 20:04:21.035377
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test default config dir
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Test config dir set by env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test config dir set by env with relative path
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foo/bar'
    assert get_default_config_dir() == Path('foo/bar')

    # Test config dir set by env with relative path
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foo/bar'
    assert get_default_config_dir() == Path('foo/bar')

    # Test config dir set by env with relative path
   

# Generated at 2022-06-17 20:04:22.660942
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:26.324532
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:33.308182
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:44.726945
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]



# Generated at 2022-06-17 20:04:55.415077
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 4: Windows

# Generated at 2022-06-17 20:04:57.841841
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:05:08.077118
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Test for legacy config dir
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG config dir
    assert get_default_config_dir() == xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:05:13.011874
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:14.969572
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config.is_new() == True
    assert config.default_options == []


# Generated at 2022-06-17 20:05:19.886765
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:24.961381
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_path.unlink()
    config_path.parent.rmdir()


# Generated at 2022-06-17 20:05:27.894828
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:05:39.677825
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:05:48.094417
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import errno

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://test.com'
        about = 'test'

    with tempfile.TemporaryDirectory() as tmp_dir:
        path = Path(tmp_dir) / 'test.json'
        config = TestConfigDict(path=path)
        config.save()
        assert path.exists()
        with path.open('rt') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:05:56.428767
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('./test_config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'
    assert config['default_options'] == []



# Generated at 2022-06-17 20:06:06.382191
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    try:
        config = BaseConfigDict(Path('test_invalid.json'))
        config.load()
    except ConfigFileError as e:
        assert e.args[0] == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [test_invalid.json]'
    # Test for valid json file
    config = BaseConfigDict(Path('test_valid.json'))
    config.load()
    assert config['test'] == 'test'
    # Test for non-existent file
    config = BaseConfigDict(Path('test_nonexistent.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:09.128110
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_path = config_dir / 'config.json'
    config = BaseConfigDict(path=config_path)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:12.489594
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('./test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:14.321617
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:16.499450
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:24.032032
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for the case that the parent directory of the path exists
    config_dict = BaseConfigDict(Path('/tmp/test.json'))
    config_dict.ensure_directory()
    assert os.path.exists('/tmp/test.json')
    # Test for the case that the parent directory of the path does not exist
    config_dict = BaseConfigDict(Path('/tmp/test/test.json'))
    config_dict.ensure_directory()
    assert os.path.exists('/tmp/test/test.json')
    # Test for the case that the parent directory of the path is not writable
    config_dict = BaseConfigDict(Path('/root/test.json'))

# Generated at 2022-06-17 20:06:31.302949
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config_path.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:50.072218
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:06:55.707529
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(path=Path('test_config.json'))
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()
    config_dict.path.parent.rmdir()


# Generated at 2022-06-17 20:07:01.938844
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary file path
    temp_file_path = Path(temp_file.name)
    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(temp_file_path)
    # Save the BaseConfigDict object
    base_config_dict.save()
    # Check if the file exists
    assert os.path.exists(temp_file_path)


# Generated at 2022-06-17 20:07:04.477173
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    with pytest.raises(ConfigFileError):
        config = BaseConfigDict(Path('/tmp/config.json'))
        config.load()

    # Test for valid json file
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.path.write_text('{"a": 1}')
    config.load()
    assert config['a'] == 1


# Generated at 2022-06-17 20:07:13.437281
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz'
    assert get_default_config_dir() == Path('/baz')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:21.588820
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    temp_file = temp_dir / 'test.json'
    # Create a BaseConfigDict object
    config = BaseConfigDict(temp_file)
    # Call the method ensure_directory
    config.ensure_directory()
    # Check that the directory has been created
    assert temp_dir.exists()
    # Remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:07:26.510357
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:30.301079
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:07:32.652216
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:07:34.583477
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:06.325837
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a file
    test_file = Path('test_file.json')
    test_file.write_text('{"a":1}')
    # test load
    test_config = BaseConfigDict(test_file)
    test_config.load()
    assert test_config['a'] == 1
    # remove the file
    test_file.unlink()


# Generated at 2022-06-17 20:08:09.778495
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_httpie_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:17.506245
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG

# Generated at 2022-06-17 20:08:23.694694
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:08:28.146947
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:38.872226
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir
    from httpie.compat import is_windows

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    #

# Generated at 2022-06-17 20:08:47.730438
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    os.environ[ENV_XDG_CONFIG_HOME] = str(xdg_config_home_dir)

# Generated at 2022-06-17 20:08:51.305195
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:54.986504
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:08:59.745402
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:41.179948
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:42.747091
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:44.279116
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:47.540887
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file_path = Path('./test_config.json')
    config_file_path.write_text('{"key": "value"}')
    config = BaseConfigDict(config_file_path)
    config.load()
    assert config['key'] == 'value'
    config_file_path.unlink()


# Generated at 2022-06-17 20:09:51.955058
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test for Linux with XDG_CONFIG_HOME
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'

# Generated at 2022-06-17 20:09:54.683182
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:58.304036
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a test directory
    test_dir = Path('./test_dir')
    test_dir.mkdir(mode=0o700, parents=True)
    # create a test file
    test_file = Path('./test_dir/test_file.json')
    test_file.touch()
    # create a test config dict
    test_config = BaseConfigDict(test_file)
    # test the method
    test_config.ensure_directory()
    # check if the test directory is created
    assert test_dir.exists()
    # remove the test directory
    test_dir.rmdir()

# Generated at 2022-06-17 20:10:06.244533
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_dir = tmpdir / 'config'
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_dir.is_dir()
        assert config_file.exists()
        assert config_file.is_file()


# Generated at 2022-06-17 20:10:17.388807
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPPrettyPrintJSON
    from httpie.plugins.builtin import HTTPPrettyPrintStream
    from httpie.plugins.builtin import HTTPPrint0
    from httpie.plugins.builtin import HTTPPrintHeaders
    from httpie.plugins.builtin import HTTPPrintHex
    from httpie.plugins.builtin import HTTPPrintResponseHeaders
    from httpie.plugins.builtin import HTTPPrintResponseBody

# Generated at 2022-06-17 20:10:22.092717
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')

# Generated at 2022-06-17 20:12:09.209304
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict

    with tempfile.TemporaryDirectory() as temp_dir:
        config_file = os.path.join(temp_dir, 'config.json')
        with open(config_file, 'w') as f:
            json.dump({'key': 'value'}, f)
        config = BaseConfigDict(config_file)
        config.load()
        assert config['key'] == 'value'



# Generated at 2022-06-17 20:12:12.430856
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:12:21.869688
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    import json
    import os
    import tempfile

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'test.json')
        with open(path, 'w') as f:
            json.dump({'a': 1}, f)
        config = TestConfigDict(path)
        config.load()
        assert config['a'] == 1

        with open(path, 'w') as f:
            f.write('{')