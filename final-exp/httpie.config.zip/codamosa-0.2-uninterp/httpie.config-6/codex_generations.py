

# Generated at 2022-06-17 20:02:29.247679
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:02:34.631369
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:02:37.816625
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/httpie/config.json'))
    config.save()
    assert Path('/tmp/httpie/config.json').exists()



# Generated at 2022-06-17 20:02:39.987515
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.save()
    assert Path('/tmp/config.json').exists()


# Generated at 2022-06-17 20:02:42.762775
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:02:49.554940
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test case 1:
    #   directory exists
    #   expected: no exception
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    config_dir.rmdir()

    # Test case 2:
    #   directory does not exist
    #   expected: no exception
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    config_dir.rmdir()

    # Test case 3:
    #   directory does not exist

# Generated at 2022-06-17 20:02:56.714575
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config['test'] = 'test'
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:06.909563
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:11.874022
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:19.353227
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:35.049127
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'helpurl'
        about = 'about'

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        config_path = tmp_dir / 'config.json'
        test_config = TestConfig(config_path)

        # Test load when file not exist
        assert test_config.is_new()
        test_config.load()
        assert test_config == {}

        # Test load when file exist
        test_config['key1'] = 'value1'
        test_config['key2'] = 'value2'
        test_config.save()

# Generated at 2022-06-17 20:03:37.260875
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:45.656290
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test case 1:
    #   Input:
    #       fail_silently = False
    #   Expected:
    #       ConfigFileError
    config = BaseConfigDict(path='/')
    try:
        config.save(fail_silently=False)
    except ConfigFileError:
        assert True
    else:
        assert False
    # Test case 2:
    #   Input:
    #       fail_silently = True
    #   Expected:
    #       No exception
    config = BaseConfigDict(path='/')
    try:
        config.save(fail_silently=True)
    except ConfigFileError:
        assert False
    else:
        assert True


# Generated at 2022-06-17 20:03:52.267367
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:53.662695
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:55.266891
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:57.675468
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:04:08.948520
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'test'
    config_dir = get_default_config_dir()
    assert config_dir == Path('test')

    # 2. Windows
    if is_windows:
        config_dir = DEFAULT_WINDOWS_CONFIG_DIR
        assert config_dir == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-17 20:04:11.689862
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:04:15.366759
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:04:23.484434
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test on Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test on Linux
        # 1. Test when $HTTPIE_CONFIG_DIR is set
        os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_WINDOWS_CONFIG_DIR)
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

        # 2. Test when $HTTPIE_CONFIG_DIR is not set
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2.1. Test when ~/.httpie exists
        os.makedirs(str(DEFAULT_RELATIVE_LEGACY_CONFIG_DIR))

# Generated at 2022-06-17 20:04:26.073705
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config.is_new() == True
    assert config.default_options == []


# Generated at 2022-06-17 20:04:27.626419
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:04:32.526967
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config = Config(config_dir)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_path.parent.rmdir()

# Generated at 2022-06-17 20:04:33.915833
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:04:44.577411
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:04:49.766640
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()

# Generated at 2022-06-17 20:04:58.857983
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import DEFAULT_CONFIG_DIR

    # 1. explicitly set through env

# Generated at 2022-06-17 20:05:05.156155
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    assert not config_dir.exists()
    config.ensure_directory()
    assert config_dir.exists()
    config_file.write_text('{}')
    config.delete()
    assert not config_dir.exists()

# Generated at 2022-06-17 20:05:15.231060
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:05:20.810802
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:05:26.715576
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_dir')
    config_dir.mkdir()
    config_path = config_dir / 'config.json'
    config_path.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:30.643850
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path('/tmp/httpie/config.json')
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text('{"a": 1}')
    config = Config(directory='/tmp/httpie')
    config.load()
    assert config['a'] == 1


# Generated at 2022-06-17 20:05:37.370380
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('test_config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'
    assert config['default_options'] == []
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'
    assert config['default_options'] == []


# Generated at 2022-06-17 20:05:38.628872
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:45.755530
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def get_default_config_dir_test(env_xdg_config_home, env_httpie_config_dir,
                                    expected_dir):
        os.environ[ENV_XDG_CONFIG_HOME] = env_xdg_config_home
        os.environ[ENV_HTTPIE_CONFIG_DIR] = env_httpie_config_dir
        assert get_default_config_dir() == expected_dir

    # 1. explicitly set through env
    get_default_config_dir_test(
        env_xdg_config_home='',
        env_httpie_config_dir='/explicit/path',
        expected_dir='/explicit/path'
    )

    # 2. Windows

# Generated at 2022-06-17 20:05:57.902161
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_dir_path = Path(self.temp_dir.name)
            self.config_file_path = self.temp_dir_path / 'config.json'
            self.config_dict = BaseConfigDict(self.config_file_path)

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_load_empty_file(self):
            self.config_dict.load()
            self.assertEqual(self.config_dict, {})


# Generated at 2022-06-17 20:06:05.483981
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict

    with tempfile.TemporaryDirectory() as tmpdirname:
        path = os.path.join(tmpdirname, 'config.json')
        config = BaseConfigDict(path)
        config.save()
        with open(path, 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:06:13.307865
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:15.861687
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:24.937574
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:35.130186
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_dict = BaseConfigDict(path=Path('config.json'))
    try:
        config_dict.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid basedict file: Expecting value: line 1 column 1 (char 0) [config.json]'
    # Test for valid json file
    config_dict = BaseConfigDict(path=Path('config.json'))
    config_dict.load()
    assert config_dict['__meta__'] == {'httpie': '2.2.0'}
    assert config_dict['default_options'] == []


# Generated at 2022-06-17 20:06:43.832178
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    from httpie.config import BaseConfigDict

    def create_config_file(content):
        fd, path = tempfile.mkstemp()
        os.write(fd, content.encode('utf-8'))
        os.close(fd)
        return path

    def test_load(content, expected):
        path = create_config_file(content)
        config = BaseConfigDict(path)
        config.load()
        assert config == expected

    test_load('{"a": 1}', {'a': 1})
    test_load('{"a": 1, "b": 2}', {'a': 1, 'b': 2})

# Generated at 2022-06-17 20:06:50.661621
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    temp_dir = tempfile.gettempdir()
    if is_windows:
        temp_dir = os.path.expandvars('%APPDATA%')
    config_dir = Path(temp_dir) / 'httpie'
    config_path = config_dir / 'config.json'
    config = BaseConfigDict(config_path)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:07:00.191789
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.config_file = os.path.join(self.tempdir.name, 'config.json')
            self.config_dict = BaseConfigDict(self.config_file)

        def tearDown(self):
            self.tempdir.cleanup()

        def test_load_new_file(self):
            self.config_dict.load()
            self.assertEqual(self.config_dict, {})


# Generated at 2022-06-17 20:07:04.576543
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        pass
    test_config_dict = TestConfigDict(path=Path('/tmp/test.json'))
    test_config_dict.load()
    assert test_config_dict == {}


# Generated at 2022-06-17 20:07:13.239821
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w', dir=temp_dir.name, delete=False)
    # Write a json string to the temporary file
    temp_file.write('{"a": "b"}')
    temp_file.close()
    # Create a BaseConfigDict object
    base_config_dict = BaseConfigDict(Path(temp_file.name))
    # Load the temporary file
    base_config_dict.load()
    # Check if the file is loaded correctly
    assert base_config_dict == {"a": "b"}
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:07:14.286429
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:17.080125
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:07:24.181480
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:46.373739
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test for invalid json file
    config_dict = BaseConfigDict(Path('test_config.json'))
    try:
        config_dict.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [test_config.json]'

    # test for valid json file
    config_dict = BaseConfigDict(Path('test_config.json'))
    config_dict.load()
    assert config_dict['test'] == 'test'


# Generated at 2022-06-17 20:07:48.985457
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:57.236133
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config_dir')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_path.unlink()
    config_path.parent.rmdir()


# Generated at 2022-06-17 20:08:08.070336
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmd

# Generated at 2022-06-17 20:08:16.280004
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir)
        config_path = config_dir / 'test.json'
        config = TestConfigDict(config_path)
        config.save()
        assert config_path.exists()
        with config_path.open('rt') as f:
            data = json.load(f)

# Generated at 2022-06-17 20:08:22.267670
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:08:28.691439
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    with pytest.raises(ConfigFileError):
        BaseConfigDict(Path('/tmp/test_config.json')).load()
    # Test for valid json file
    BaseConfigDict(Path('/tmp/test_config.json')).save()
    BaseConfigDict(Path('/tmp/test_config.json')).load()


# Generated at 2022-06-17 20:08:29.974211
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:32.385955
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:08:39.711357
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

# Generated at 2022-06-17 20:09:08.039162
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:09:09.851296
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:11.214255
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:15.356032
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:09:23.911213
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        if legacy_config_dir.exists():
            assert get_default_config_dir() == legacy_config_dir

        # Test for XDG
        else:
            xdg_config_home_dir = os.environ.get(
                ENV_XDG_CONFIG_HOME,  # 4.1. explicit
                Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
            )
            assert get_default_config_

# Generated at 2022-06-17 20:09:35.459783
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variables set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    #

# Generated at 2022-06-17 20:09:45.270027
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    xdg_config_dir = xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    # 4.1. explicit

# Generated at 2022-06-17 20:09:58.280489
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w+t', dir=temp_dir.name, delete=False)
    # Create a BaseConfigDict object
    bcd = BaseConfigDict(path=temp_file.name)
    # Save the BaseConfigDict object
    bcd.save()
    # Check if the file exists
    assert os.path.exists(temp_file.name)
    # Check if the file is empty
    assert os.stat(temp_file.name).st_size == 0
    # Close the file
    temp_file.close()
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:10:08.512619
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR

    # test for method get_default_config_dir
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'

# Generated at 2022-06-17 20:10:12.162788
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()

# Generated at 2022-06-17 20:11:26.442341
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJSONData
    from httpie.plugins.builtin import HTTPOptions
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPResponseHeaders
    from httpie.plugins.builtin import HTTPPrettyOptions
    from httpie.plugins.builtin import HTTPSignatureAuth
    from httpie.plugins.builtin import HTTPTLS
    from httpie.plugins.builtin import HTTPUnixSocket

# Generated at 2022-06-17 20:11:28.890989
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:11:35.774613
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    assert config_file.is_file()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:44.500131
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='w+t', dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)

    # Write some data to the temporary file
    data = {'a': 1, 'b': 2}
    json.dump(data, temp_file)
    temp_file.close()

    # Load the data from the temporary file
    config = BaseConfigDict(temp_file_path)
    config.load()

# Generated at 2022-06-17 20:11:57.567088
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:59.630859
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:12:01.141601
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:12:02.615928
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:12:11.391453
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file.name)
    # Save the BaseConfigDict object
    config_dict.save()
    # Check if the file exists
    assert os.path.exists(temp_file.name)
    # Check if the file is empty
    assert os.stat(temp_file.name).st_size == 0
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:12:20.932187
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 3: HTTPIE_CONFIG_DIR set, XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'