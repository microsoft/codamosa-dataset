

# Generated at 2022-06-17 20:02:30.707344
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:33.721762
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:02:37.079607
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        pass
    test_config_dict = TestConfigDict(path=Path('test.json'))
    test_config_dict.load()


# Generated at 2022-06-17 20:02:40.505710
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    path = Path('./test_BaseConfigDict_load.json')
    config = TestConfigDict(path)
    config.load()
    assert config == {}

    path.write_text('{"a": 1}')
    config.load()
    assert config == {'a': 1}

    path.write_text('{"b": 2}')
    config.load()
    assert config == {'b': 2}

    path.unlink()


# Generated at 2022-06-17 20:02:42.862790
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:02:44.020107
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:57.673012
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import shutil
    import tempfile
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import ConfigFileError

    # Test for invalid json file
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_file = temp_dir / 'config.json'
        config_file.write_text('{')
        config = BaseConfigDict(config_file)
        try:
            config.load()
        except ConfigFileError as e:
            assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 2 (char 1) [{}]'.format(config_file)

    # Test for non-existent file

# Generated at 2022-06-17 20:03:04.921114
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:03:13.749510
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file
    temp_file = temp_dir / 'temp.json'
    # create a BaseConfigDict object
    config = BaseConfigDict(temp_file)
    # ensure the directory
    config.ensure_directory()
    # check if the directory exists
    assert temp_dir.exists()
    # remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:03:16.813364
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test_BaseConfigDict_load.json'))
    config.load()
    assert config == {}
    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}}
    config.delete()


# Generated at 2022-06-17 20:03:35.002062
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    config = TestConfig(Path('/tmp/test.json'))
    config.save()
    with open('/tmp/test.json') as f:
        data = json.load(f)
    assert data['__meta__']['httpie'] == __version__
    assert data['__meta__']['help'] == 'https://github.com/jakubroztocil/httpie'
    assert data['__meta__']['about'] == 'HTTPie is a command line HTTP client.'
    os.remove('/tmp/test.json')

# Generated at 2022-06-17 20:03:36.919228
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:45.666093
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import json
    import os
    import sys

    def get_default_config_dir() -> Path:
        """
        Return the path to the httpie configuration directory.

        This directory isn't guaranteed to exist, and nor are any of its
        ancestors (only the legacy ~/.httpie, if returned, is guaranteed to exist).

        XDG Base Directory Specification support:

            <https://wiki.archlinux.org/index.php/XDG_Base_Directory>

            $XDG_CONFIG_HOME is supported; $XDG_CONFIG_DIRS is not

        """
        # 1. explicitly set through env

# Generated at 2022-06-17 20:03:50.184174
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:03:58.429867
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict

    config_dict = {
        'foo': 'bar',
        'baz': 'qux'
    }

    with tempfile.NamedTemporaryFile(mode='w+t', delete=False) as f:
        json.dump(config_dict, f)
        f.flush()
        config_path = f.name

    config = BaseConfigDict(config_path)
    config.load()
    assert config == config_dict

    os.remove(config_path)


# Generated at 2022-06-17 20:04:05.302960
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.unlink(missing_ok=True)
    config_dir.rmdir(missing_ok=True)

    config = Config(config_dir)
    config.save()
    assert config_file.exists()

    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:12.388780
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test with no environment variables set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test with XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    # Test with HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    # Test with HTTPIE_CONFIG_DIR set to empty string
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config'

# Generated at 2022-06-17 20:04:15.408945
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:21.106666
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:27.631413
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:04:37.035154
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:41.434402
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:42.839547
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:44.772578
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:55.457991
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    import httpie.config
    import httpie.plugins
    import httpie.plugins.builtin

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write data to the temporary file
    data = {'foo': 'bar'}
    json.dump(data, tmpfile)
    tmpfile.close()
    # Create a BaseConfigDict object
    config = httpie.config.BaseConfigDict(tmpfile.name)
    # Load the data from the temporary file
    config.load()
    # Check if the data is loaded correctly
    assert config == data
    # Remove the temporary file

# Generated at 2022-06-17 20:05:06.143345
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:05:16.638688
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    config_dir = Path('/tmp/httpie-test')
    config_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_file = config_dir / 'test.json'
    config_file.write_text('{"a": 1, "b": 2}')

    config = TestConfigDict(config_file)
    config.load()

    assert config['a'] == 1
    assert config['b'] == 2
    assert config['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:05:20.780361
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / 'test.json'
        with path.open('wt') as f:
            json.dump({'foo': 'bar'}, f)
        config = TestConfigDict(path)
        config.load()
        assert config['foo'] == 'bar'



# Generated at 2022-06-17 20:05:25.183349
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"test": "test"}')
    config = Config(config_dir)
    config.load()
    assert config['test'] == 'test'
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:30.676478
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

# Generated at 2022-06-17 20:05:47.803458
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    import json
    import shutil
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR

    # create a temp directory
    temp_dir = tempfile.mkdtemp()
    # create a temp file
    temp_file = tempfile.NamedTemporaryFile(mode='w+t', dir=temp_dir, delete=False)
    temp_file.write('{"key": "value"}')
    temp_file.close()

    # create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file.name)
    # load the file
    config.load()
    # check the content
    assert config['key'] == 'value'

    # remove the temp

# Generated at 2022-06-17 20:05:58.585754
# Unit test for function get_default_config_dir

# Generated at 2022-06-17 20:06:05.389517
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')

# Generated at 2022-06-17 20:06:07.575196
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:06:11.052070
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:06:15.484673
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)
            self.update(self.DEFAULTS)
        DEFAULTS = {
            'default_options': []
        }
    test_config = TestConfig(Path('test_config.json'))
    test_config.load()
    assert test_config == {'default_options': []}
    test_config.delete()


# Generated at 2022-06-17 20:06:21.111928
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_path = config_dir / 'config.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_path.unlink()
    config_path.parent.rmdir()


# Generated at 2022-06-17 20:06:29.440973
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:06:39.192081
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://httpie.org/docs'
        about = 'https://httpie.org/about'

    config_dir = Path('./test_config')
    config_path = config_dir / 'test.json'
    config_path.parent.mkdir(mode=0o700, parents=True)
    config_path.write_text(json.dumps({'test': 'test'}))
    config = TestConfigDict(config_path)
    config.load()
    assert config['test'] == 'test'
    assert config['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:06:40.423750
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:07:01.277647
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 4: Windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

# Generated at 2022-06-17 20:07:11.450429
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG
    assert get_default_config_dir() == Path.home() / DEFAULT_REL

# Generated at 2022-06-17 20:07:16.912500
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file.name)
    # create a directory
    config_dict.ensure_directory()
    # check if the directory is created
    assert os.path.exists(temp_file.name)
    # delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:07:19.499782
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:22.169842
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
    config.load()
    assert config['default_options'] == []


# Generated at 2022-06-17 20:07:35.054042
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg_config_home'
    assert get_default_config_dir() == Path('/tmp/xdg_config_home') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie_config_dir'
    assert get_default_config_dir() == Path('/tmp/httpie_config_dir')

    del os.environ[ENV_XDG_CONFIG_HOME]
    del os.environ[ENV_HTTPIE_CONFIG_DIR]


# Generated at 2022-06-17 20:07:39.118100
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"foo": "bar"}')
    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:44.109485
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path('./test_config.json')
    config = BaseConfigDict(config_path)
    config.load()
    assert config == {}
    config_path.write_text('{"a": 1}')
    config.load()
    assert config == {"a": 1}
    config_path.unlink()


# Generated at 2022-06-17 20:07:50.970379
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file in this directory
    temp_file = temp_dir / 'temp_file'
    # create a BaseConfigDict object with this file as path
    config = BaseConfigDict(temp_file)
    # ensure the directory of this file exists
    config.ensure_directory()
    # check if the directory exists
    assert temp_dir.exists()
    # delete the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:07:53.706733
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:08:38.414598
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test default config dir
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test config dir set by env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test config dir set by env with relative path
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foo/bar'
    assert get_default_config_dir() == Path('foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test config dir set by env with relative path and ~

# Generated at 2022-06-17 20:08:39.979150
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:41.625275
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:43.607793
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:51.921050
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ConfigFileError
    from httpie.config import get_default_config_dir

    # Test for method load of class BaseConfigDict
    # Case

# Generated at 2022-06-17 20:08:54.151876
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:55.464003
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:02.030284
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file.name)
    # Call ensure_directory method
    config_dict.ensure_directory()
    # Check if the directory exists
    assert os.path.exists(temp_dir.name)
    # Check if the file exists
    assert os.path.exists(temp_file.name)
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:09:10.487552
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:21.622262
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'https://example.com/help'
        about = 'https://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = os.path.join(tmpdir, 'config.json')
        config = TestConfig(config_path)
        config.save()
        with open(config_path, 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__
            assert data['__meta__']['help'] == 'https://example.com/help'
            assert data['__meta__']['about']

# Generated at 2022-06-17 20:10:24.632246
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:33.513409
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file in the temporary directory
    temp_file = temp_dir / 'temp_file'
    # Create an instance of BaseConfigDict
    base_config_dict = BaseConfigDict(temp_file)
    # Call method ensure_directory
    base_config_dict.ensure_directory()
    # Check if the temporary directory exists
    assert temp_dir.exists()
    # Check if the temporary file exists
    assert temp_file.exists()
    # Remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:10:40.911983
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:48.150507
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path)
    tmp_file_path = Path(tmp_file.name)
    # Create a temporary directory
    tmp_sub_dir = tempfile.TemporaryDirectory(dir=tmp_dir_path)
    tmp_sub_dir_path = Path(tmp_sub_dir.name)
    # Create a temporary file
    tmp_sub_file = tempfile.NamedTemporaryFile(dir=tmp_sub_dir_path)
    tmp_sub_file_path = Path(tmp_sub_file.name)

    # Test for a file
    test_config = Base

# Generated at 2022-06-17 20:10:50.537110
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:55.389511
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:10:58.005982
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:11:00.298574
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    config.delete()


# Generated at 2022-06-17 20:11:03.925804
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()

    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:05.443727
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:12:04.462716
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:08.565678
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1}')

    config = BaseConfigDict(config_file)
    config.load()

    assert config['a'] == 1

    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:17.679336
# Unit test for method ensure_directory of class BaseConfigDict