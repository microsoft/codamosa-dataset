

# Generated at 2022-06-17 20:02:38.847429
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    temp_dir = tempfile.mkdtemp()
    config_path = os.path.join(temp_dir, 'config.json')
    config = BaseConfigDict(config_path)
    config['key'] = 'value'
    config.save()

    with open(config_path, 'r') as f:
        data = json.load(f)
        assert data['key'] == 'value'

    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 20:02:44.550585
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from httpie.config import BaseConfigDict

    temp_dir = Path(mkdtemp())
    config_file = temp_dir / 'config.json'
    config_dict = BaseConfigDict(config_file)
    config_dict.ensure_directory()
    assert config_file.parent.exists()
    rmtree(temp_dir)

# Generated at 2022-06-17 20:02:47.305238
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:59.453878
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for method ensure_directory of class BaseConfigDict
    # Case 1: The directory does not exist
    # Expected: The directory is created
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config.delete()
    config_dir.rmdir()

    # Case 2: The directory exists
    # Expected: The directory is not created
    config_dir = Path('/tmp/test_httpie_config')
    config_dir.mkdir()
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_

# Generated at 2022-06-17 20:03:09.231147
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.unlink(missing_ok=True)
    config_dir.rmdir(missing_ok=True)

    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    assert config_file.read_text() == '{\n    "__meta__": {\n        "httpie": "1.0.3"\n    },\n    "default_options": []\n}\n'

    config.save(fail_silently=True)
    assert config_file.exists()

# Generated at 2022-06-17 20:03:11.737113
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:20.087069
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'config.json')
    config_dict = BaseConfigDict(temp_file)
    config_dict['test'] = 'test'
    config_dict.save()
    with open(temp_file, 'r') as f:
        data = json.load(f)
        assert data['test'] == 'test'
    os.remove(temp_file)
    os.rmdir(temp_dir)

# Generated at 2022-06-17 20:03:28.056654
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:39.246921
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    import shutil
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    def get_default_config_dir():
        """
        Return the path to the httpie configuration directory.

        This directory isn't guaranteed to exist, and nor are any of its
        ancestors (only the legacy ~/.httpie, if returned, is guaranteed to exist).

        XDG Base Directory Specification support:

            <https://wiki.archlinux.org/index.php/XDG_Base_Directory>

            $XDG_CONFIG_HOME is supported; $XDG_CONFIG_DIRS is not

        """
        # 1. explicitly set through env
        env_config_dir = os.environ.get

# Generated at 2022-06-17 20:03:47.443964
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    if is_windows:
        return
    if is_py26:
        return

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.json')
    test_dict = BaseConfigDict(tmp_file)
    test_dict['test'] = 'test'
    test_dict.save()
    with open(tmp_file, 'r') as f:
        data = json.load(f)
    assert data['test'] == 'test'
    os.remove(tmp_file)
    os.rmdir(tmp_dir)

# Generated at 2022-06-17 20:03:53.406109
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:55.019966
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:59.269829
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26

    if is_windows:
        return

    if is_py26:
        return

    with tempfile.TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir)
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(config_file)
        config.save()
        assert config_file.exists()
        with config_file.open('rt') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:04:07.703729
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:04:13.711863
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    temp_file = temp_dir / 'temp_file'
    # Create a temporary config file
    temp_config_file = temp_dir / 'config.json'
    # Create a config object
    temp_config = Config(temp_dir)
    # Create a directory
    temp_config.ensure_directory()
    # Check if the directory is created
    assert temp_dir.exists()
    # Create a file
    temp_file.touch()
    # Check if the file is created
    assert temp_file.exists()
    # Check if the config file is not created
    assert not temp_config_file.exists()
    # Delete the temporary directory

# Generated at 2022-06-17 20:04:15.793169
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:18.213188
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:19.399688
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:30.835333
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as temp_dir:
        if is_windows:
            temp_dir = os.path.expandvars(temp_dir)
        config_dict = TestConfigDict(path=Path(temp_dir) / 'config.json')
        config_dict.save()
        with open(os.path.join(temp_dir, 'config.json'), 'r') as f:
            data = json.load(f)

# Generated at 2022-06-17 20:04:41.946039
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:57.137170
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:04:58.178219
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:02.310769
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:05:06.775751
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:17.001612
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG
   

# Generated at 2022-06-17 20:05:26.624773
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # 4. XDG
    # 4.1

# Generated at 2022-06-17 20:05:28.457439
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:32.564058
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:41.988825
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree
    from os import chmod
    from os.path import join
    from stat import S_IWUSR

    with TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir) / 'config'
        config_file = config_dir / 'config.json'
        chmod(temp_dir, S_IWUSR)
        config = BaseConfigDict(config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_dir.is_dir()
        assert config_file.exists()
        assert config_file.is_file()
        rmtree(temp_dir)

# Generated at 2022-06-17 20:05:44.968467
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.save()
    assert Path('/tmp/config.json').exists()
    Path('/tmp/config.json').unlink()


# Generated at 2022-06-17 20:06:06.291528
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config['key'] = 'value'
    config.save()
    assert Path('/tmp/test.json').exists()
    with Path('/tmp/test.json').open() as f:
        assert f.read() == '{"key": "value"}\n'
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:06:13.874587
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg/config'
    assert get_default_config_dir() == Path('/tmp/xdg/config') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:22.845758
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1.
    # Test if the function returns the default config dir
    # when the HTTPIE_CONFIG_DIR environment variable is not set
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Test 2.
    # Test if the function returns the config dir set by the
    # HTTPIE_CONFIG_DIR environment variable
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 3.
    # Test if the function returns the default config dir
    # when the HTTPIE_CONFIG_DIR environment variable is set to an
    # empty string
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config

# Generated at 2022-06-17 20:06:35.129546
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # Test 4. XDG

# Generated at 2022-06-17 20:06:38.787191
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        pass
    config_dict = TestConfigDict(Path('/tmp/test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:06:40.623205
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    config_dict.save()
    assert Path('/tmp/config.json').exists()
    Path('/tmp/config.json').unlink()


# Generated at 2022-06-17 20:06:44.526042
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:06:56.669442
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:06:59.835917
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:07:01.073821
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:23.954225
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:25.663607
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:30.343920
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:07:34.740064
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:36.782614
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:48.767808
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import errno
    import stat
    import pytest
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    def get_permissions(path):
        return oct(stat.S_IMODE(os.lstat(path).st_mode))

    def test_ensure_directory_exists(tmpdir):
        config_dir = tmpdir.mkdir('config')
        config_file = config_dir.join('config.json')
        config = TestConfigDict(path=config_file)
        config.ensure_

# Generated at 2022-06-17 20:07:52.063426
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:54.973801
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:00.662469
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_file.exists()
    assert config_file.is_file()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:10.205255
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:08:46.770141
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from os import environ
    from os import path
    from os import chmod
    from os import mkdir
    from os import rmdir
    from os import remove
    from shutil import rmtree
    from stat import S_IRUSR
    from stat import S_IWUSR
    from stat import S_IXUSR
    from stat import S_IRGRP
    from stat import S_IWGRP
    from stat import S_IXGRP
    from stat import S_IROTH
    from stat import S_IWOTH
    from stat import S_IXOTH
    from stat import S_ISVTX
    from stat import S_ISGID
    from stat import S_ISUID
    from stat import S_IFMT
    from stat import S_

# Generated at 2022-06-17 20:08:55.392300
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:01.105684
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:09:02.831027
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:11.730875
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/baz'
    assert get_default_config_dir() == Path.home() / 'baz'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/baz/'
    assert get_default_config_dir() == Path.home

# Generated at 2022-06-17 20:09:20.757056
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    temp_dir = tempfile.TemporaryDirectory()
    temp_file = os.path.join(temp_dir.name, 'test.json')
    config = BaseConfigDict(temp_file)
    config['test'] = 'test'
    config.save()
    with open(temp_file, 'r') as f:
        data = json.load(f)
    assert data['test'] == 'test'
    temp_dir.cleanup()


# Generated at 2022-06-17 20:09:21.917598
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:31.994659
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    import tempfile
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    # Create a temporary file
    tmp_file = tmp_dir_path / 'config.json'
    # Create a config object
    config = BaseConfigDict(path=tmp_file)
    # Save the config object
    config.save()
    # Check if the file exists
    assert tmp_file.exists()
    # Check if the file is empty
    assert tmp_file.stat().st_size == 0
    # Delete the temporary directory
    tmp_dir.cleanup()


# Generated at 2022-06-17 20:09:39.711383
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'http://helpurl.com'
        about = 'about'

    with tempfile.TemporaryDirectory() as tempdir:
        config_path = os.path.join(tempdir, 'config.json')
        config = TestConfig(config_path)
        config.save()
        with open(config_path, 'r') as f:
            config_data = json.load(f)
            assert config_data['__meta__']['httpie'] == httpie.__version__
            assert config_data['__meta__']['help'] == 'http://helpurl.com'

# Generated at 2022-06-17 20:09:43.898278
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:58.925275
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:02.911473
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config['test'] = 'test'
    config.save()
    with open('test.json', 'r') as f:
        data = json.load(f)
    assert data['test'] == 'test'
    os.remove('test.json')


# Generated at 2022-06-17 20:11:10.425955
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:11:12.434021
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:11:17.656114
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    import json

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path)
    temp_file_path = Path(temp_file.name)

    # Create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file_path)

    # Save the config
    config.save()

    # Check if the file exists
    assert os.path.exists(temp_file_path)

    # Check if the file is a valid json file
    with open(temp_file_path) as f:
        json.load(f)

    # Delete the temporary directory


# Generated at 2022-06-17 20:11:21.818924
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:28.117525
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:32.613154
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:35.111124
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:11:39.360245
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()
