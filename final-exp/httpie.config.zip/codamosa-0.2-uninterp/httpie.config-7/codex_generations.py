

# Generated at 2022-06-17 20:02:24.521941
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:31.058062
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test case 1:
    #   - $XDG_CONFIG_HOME is set
    #   - $HTTPIE_CONFIG_DIR is not set
    #   - ~/.config/httpie exists
    #   - ~/.httpie does not exist
    #   - OS is not Windows
    # Expected: ~/.config/httpie
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/user/.config'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path('/home/user/.config/httpie')

    # Test case 2:
    #   - $XDG_CONFIG_HOME is not set
    #   - $HTTPIE_CONFIG_DIR is not set
    #   - ~/.

# Generated at 2022-06-17 20:02:41.732853
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_

# Generated at 2022-06-17 20:02:43.111704
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:02:49.720568
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree
    from os import chmod
    from stat import S_IWUSR
    from httpie.config import BaseConfigDict
    from httpie.config import ConfigFileError
    from httpie.compat import is_windows

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_path = temp_dir / 'config.json'
        config = BaseConfigDict(config_path)

        # Test if directory is created
        config.ensure_directory()
        assert config.path.parent.exists()

        # Test if exception is raised when directory is not writable
        if not is_windows:
            chmod(str(config.path.parent), S_IWUSR)


# Generated at 2022-06-17 20:02:52.446354
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:00.261519
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:03:02.354634
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:03:06.868400
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:11.109210
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'test_config.json'
    config_file.touch()
    config = BaseConfigDict(config_file)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:20.310170
# Unit test for method ensure_directory of class BaseConfigDict

# Generated at 2022-06-17 20:03:28.950776
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/bar'

# Generated at 2022-06-17 20:03:40.414648
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG

# Generated at 2022-06-17 20:03:44.455968
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:47.958508
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for the case when the directory already exists
    config_dir = Path('./test_config_dir')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = BaseConfigDict(config_dir / 'config.json')
    config_file.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()

    # Test for the case when the directory doesn't exist
    config_dir = Path('./test_config_dir')
    config_file = BaseConfigDict(config_dir / 'config.json')
    config_file.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()



# Generated at 2022-06-17 20:03:58.534117
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test default
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test with XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/path'
    assert get_default_config_dir() == Path('/some/path') / 'httpie'

    # Test with HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/other/path'
    assert get_default_config_dir() == Path('/some/other/path')

    # Test with HTTPIE_CONFIG_DIR set to empty string
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-17 20:04:00.569151
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/test_config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:04:03.871476
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:05.277354
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:09.013461
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie_test')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:16.406429
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:21.384853
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = Path('/tmp/httpie/config.json')
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(directory='/tmp/httpie')
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()



# Generated at 2022-06-17 20:04:31.569186
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie import __version__

    if is_windows:
        temp_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        temp_dir = Path(tempfile.gettempdir()) / 'httpie'

    temp_dir.mkdir(parents=True, exist_ok=True)

    config_dict = BaseConfigDict(temp_dir / 'config.json')
    config_dict['default_options'] = ['--json']
    config_dict.save()

    with open(temp_dir / 'config.json', 'r') as f:
        data = json

# Generated at 2022-06-17 20:04:33.657856
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:04:46.667502
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py38
    from pathlib import Path
    from httpie import __version__
    from os import path
    from os import remove
    from os import mkdir
    from os import rmdir
    from os import chmod
    from os import stat
    from os import access
    from os import W_OK
    from os import R_OK

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary file
    temp_file_2 = tempfile.Named

# Generated at 2022-06-17 20:04:52.089972
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory/config.json'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:04:57.573382
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_file.exists()
    assert config_file.is_file()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:05.554542
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1, "b": 2}')
    config = Config(directory=config_dir)
    config.load()
    assert config['a'] == 1
    assert config['b'] == 2
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:05:07.086483
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:17.239963
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy

# Generated at 2022-06-17 20:05:27.117107
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    tmp_dir = Path(tempfile.mkdtemp())
    # create a temporary file
    tmp_file = Path(tempfile.mkstemp()[1])
    # create a temporary directory
    tmp_dir_2 = Path(tempfile.mkdtemp())
    # create a temporary file
    tmp_file_2 = Path(tempfile.mkstemp()[1])
    # create a temporary directory
    tmp_dir_3 = Path(tempfile.mkdtemp())
    # create a temporary file
    tmp_file_3 = Path(tempfile.mkstemp()[1])
    # create a temporary directory
    tmp_dir_4 = Path(tempfile.mkdtemp())
    # create a temporary file
    tmp_file_4 = Path(tempfile.mkstemp()[1])

# Generated at 2022-06-17 20:05:35.097857
# Unit test for function get_default_config_dir

# Generated at 2022-06-17 20:05:40.086711
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.write_text('{}')
    config.delete()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:43.514848
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/tmp/test_httpie_config_dir/config.json'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:05:49.463139
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:05:52.865069
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:05:57.445342
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:08.797084
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path)
    temp_file_path = Path(temp_file.name)
    # Create a temporary config file
    temp_config_file = tempfile.NamedTemporaryFile(dir=temp_dir_path)
    temp_config_file_path = Path(temp_config_file.name)
    # Create a temporary config dict
    temp_config_dict = BaseConfigDict(path=temp_config_file_path)
    # Check if the temporary file exists
    assert temp_file_path.exists()
    # Check if the temporary config file exists

# Generated at 2022-06-17 20:06:19.950056
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG


# Generated at 2022-06-17 20:06:30.463378
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:36.991058
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1

# Generated at 2022-06-17 20:06:45.727351
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:57.416287
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:07:06.728399
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'config.json')
        config = BaseConfigDict(path)
        config.save()
        with open(path, 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__
            assert data['__meta__']['help'] == 'https://httpie.org/docs'
            assert data['__meta__']['about'] == 'https://httpie.org'


# Generated at 2022-06-17 20:07:10.882365
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:17.399381
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:22.343148
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:28.725159
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:33.829555
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_load.json'))
    config.load()
    assert config == {}
    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}}
    config.delete()


# Generated at 2022-06-17 20:07:35.015309
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:40.901792
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:43.007825
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:44.748556
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:57.639193
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:08.529256
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    with tempfile.TemporaryDirectory() as tmpdirname:
        if is_windows:
            tmpdirname = os.path.expandvars(tmpdirname)
        config_dir = Path(tmpdirname)
        config = TestConfigDict(config_dir / 'test.json')
        config.save()

# Generated at 2022-06-17 20:08:09.889060
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:12.087472
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:19.842407
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie/'
    assert get_default_config_dir() == Path('/tmp/httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie'
    assert get_default_config_dir() == Path.home() / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie/'

# Generated at 2022-06-17 20:08:20.829193
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:27.826377
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    assert config['a'] == 1
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:32.386059
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
    config.load()
    assert config['default_options'] == []


# Generated at 2022-06-17 20:08:44.321603
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_CONFIG_DIRNAME

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        # 1. explicitly set through env

# Generated at 2022-06-17 20:08:58.643423
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file.name)
    # Save the BaseConfigDict object
    config_dict.save()
    # Check if the file exists
    assert os.path.isfile(temp_file.name)
    # Check if the file is empty
    assert os.stat(temp_file.name).st_size == 0
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:09:00.291884
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:01.614341
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:11.014838
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/config/dir'
    assert get_default_config_dir() == Path('/test/config/dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Test 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if not legacy_config_dir.exists():
        legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
   

# Generated at 2022-06-17 20:09:22.142499
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie import __version__

    if is_windows:
        temp_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        temp_dir = Path(tempfile.gettempdir()) / 'httpie'

    config_dict = BaseConfigDict(temp_dir / 'config.json')
    config_dict.save()
    with open(temp_dir / 'config.json', 'r') as f:
        data = json.load(f)
        assert data['__meta__']['httpie'] == __version__


# Generated at 2022-06-17 20:09:31.913970
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]



# Generated at 2022-06-17 20:09:34.946053
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('config.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:09:36.918141
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:09:41.316497
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:49.480635
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    if is_windows:
        config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        config_dir = tempfile.mkdtemp()
    config_path = os.path.join(config_dir, 'config.json')
    config = BaseConfigDict(config_path)
    config.save()
    with open(config_path, 'r') as f:
        data = json.load(f)
    assert data['__meta__']['httpie'] == __version__
    assert data['__meta__']['help'] == 'https://httpie.org/docs'

# Generated at 2022-06-17 20:09:51.509912
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:53.539983
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:56.201411
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:02.624203
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/test'
        about = 'test config'

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'test.json')
        with open(path, 'w') as f:
            json.dump({'foo': 'bar'}, f)
        config = TestConfigDict(path)
        config.load()
        assert config['foo'] == 'bar'
        assert config['__meta__']['httpie'] == __version__
        assert config['__meta__']['help'] == 'http://example.com/test'
        assert config

# Generated at 2022-06-17 20:10:05.199739
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:10:15.257833
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:23.338575
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import ConfigFileError
    from httpie.config import BaseConfig

# Generated at 2022-06-17 20:10:31.498126
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": "b"}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 'b'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:43.169772
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from shutil import rmtree

    if is_windows:
        tempfile.tempdir = 'C:\\Users\\Administrator\\AppData\\Local\\Temp'
    else:
        tempfile.tempdir = '/tmp'

    temp_dir = tempfile.mkdtemp()
    config_path = Path(temp_dir) / 'config.json'
    config = BaseConfigDict(config_path)
    config.save()
    assert config_path.exists()
    rmtree(temp_dir)

# Generated at 2022-06-17 20:10:46.627830
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com'
        about = 'test config'

    config = TestConfig(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()



# Generated at 2022-06-17 20:10:51.446067
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:10:53.680320
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config['default_options'] == []

# Generated at 2022-06-17 20:11:00.792920
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    if is_windows:
        temp_dir = temp_dir.replace('\\', '/')
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file.name)
    # Save the config_dict to the temporary file
    config_dict.save()
    # Check if the file exists
    assert os.path.exists(temp_file.name)
    # Check if the file is empty
    assert os.path.gets

# Generated at 2022-06-17 20:11:04.994830
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        if Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR:
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

        # Test for XDG
        else:
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:11:07.970669
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save'))
    config_dict.save()
    assert config_dict.path.exists()


# Generated at 2022-06-17 20:11:09.842167
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:11:16.649204
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import get_default_config_dir
    from httpie.config import DEFAULT

# Generated at 2022-06-17 20:11:19.598605
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:11:26.384647
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:37.190241
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test for Linux with $XDG_CONFIG_HOME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-17 20:11:39.010886
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:41.368693
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:46.114931
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:58.619208
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # 1. explicitly set through env
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2. legacy ~/.httpie
        legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        legacy_config_dir.mkdir()
        assert get_default_config_dir() == legacy_config_dir
        legacy_config_dir.rmdir()

        # 3. XDG

# Generated at 2022-06-17 20:12:09.169289
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG
    x

# Generated at 2022-06-17 20:12:17.255381
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'