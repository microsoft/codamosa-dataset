

# Generated at 2022-06-17 20:02:28.821048
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:39.478708
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import errno
    import stat
    import pytest

    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_path = tmpdir / 'config.json'
        config = TestConfigDict(config_path)
        config.ensure_directory()
        assert os.path.exists(tmpdir)
        assert stat.S_IMODE(os.stat(tmpdir).st_mode) == 0o700
        assert os.path.exists(config_path)
        assert stat.S_IMODE(os.stat(config_path).st_mode) == 0

# Generated at 2022-06-17 20:02:43.979429
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.delete()
    assert not config_file.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:02:49.637361
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:03:00.421760
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin

# Generated at 2022-06-17 20:03:04.320669
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        if (Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).exists():
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

        # Test for XDG
        else:
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:03:09.581025
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    assert config['key'] == 'value'
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:03:12.389863
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path='/tmp/test.json')
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:20.197699
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import os
    import shutil
    import sys
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.config_file = os.path.join(self.tempdir, 'config.json')
            self.config_dict = BaseConfigDict(self.config_file)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_load_file_not_exist(self):
            self.config_dict.load()
            self.assertEqual(self.config_dict, {})


# Generated at 2022-06-17 20:03:22.749159
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:34.956975
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:03:43.283159
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a temporary file
        f = tempfile.NamedTemporaryFile(dir=tmpdirname, delete=False)
        # Write some data to the file
        f.write(b'{"key1": "value1", "key2": "value2"}')
        f.close()

        # Create a BaseConfigDict object
        config = BaseConfigDict(path=Path(f.name))
        # Load the data from the file
        config.load()

        # Check the data
        assert config['key1'] == 'value1'
        assert config['key2'] == 'value2'


# Generated at 2022-06-17 20:03:45.096605
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}
    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}}
    config.delete()


# Generated at 2022-06-17 20:03:52.710476
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir()
    config_file = config_dir / 'config.json'
    config_file.write_text('{"a": 1}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 1
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:54.366832
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:03:57.236885
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:04:00.755618
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:02.564506
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:04.955710
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:09.571514
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('./test_config.json'))
    config_dict.load()
    assert config_dict['__meta__']['httpie'] == __version__
    assert config_dict['__meta__']['help'] == 'https://httpie.org/docs'
    assert config_dict['__meta__']['about'] == 'https://httpie.org'
    assert config_dict['default_options'] == []


# Generated at 2022-06-17 20:04:24.251390
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name, delete=False)
    # Write some data to the temporary file
    temp_file.write(b'{"key1": "value1", "key2": "value2"}')
    temp_file.close()
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file.name)
    # Load the temporary file
    config.load()
    # Check the loaded data
    assert config['key1'] == 'value1'
    assert config['key2'] == 'value2'
    # Remove the temporary file
    os.unlink(temp_file.name)
    #

# Generated at 2022-06-17 20:04:33.657654
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.unlink()
    config_dir.rmdir()
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.unlink()
    config_dir.rmdir()
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:37.339578
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:04:40.445688
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:48.663210
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    with pytest.raises(ConfigFileError):
        BaseConfigDict(Path('/tmp/invalid.json')).load()

    # Test for valid json file
    config = BaseConfigDict(Path('/tmp/valid.json'))
    config.update({'test': 'test'})
    config.save()
    config.load()
    assert config == {'test': 'test'}

    # Test for non-existing file
    config = BaseConfigDict(Path('/tmp/non-existing.json'))
    config.load()
    assert config == {}



# Generated at 2022-06-17 20:04:58.646903
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    def create_config_file(content):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write(content)
        return Path(f.name)

    def remove_config_file(path):
        os.remove(path)

    def test_load_valid_json(path):
        config = BaseConfigDict(path)
        config.load()
        assert config['foo'] == 'bar'

    def test_load_invalid_json(path):
        config = BaseConfigDict(path)
        try:
            config.load()
        except ConfigFileError:
            pass
        else:
            assert False


# Generated at 2022-06-17 20:05:02.224492
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:05:03.517614
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:14.218188
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:18.096179
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(path=config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:31.144690
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = BaseConfigDict(path=Path('config.json'))
    config_file.load()
    assert config_file.path == Path('config.json')


# Generated at 2022-06-17 20:05:38.094896
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config_path.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:46.820122
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # Test 2: HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 3: Windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_WINDOWS_

# Generated at 2022-06-17 20:05:55.191340
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config['key'] = 'value'
    config.save()
    assert Path('/tmp/config.json').exists()
    assert Path('/tmp/config.json').read_text() == '{\n    "key": "value"\n}'
    Path('/tmp/config.json').unlink()


# Generated at 2022-06-17 20:06:06.246297
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        if is_windows:
            tmpdir = Path(tmpdir).as_posix()
        config_dir = Path(tmpdir) / 'httpie'
        config = TestConfigDict(config_dir / 'config.json')
        config.save()
        with open(config_dir / 'config.json', 'r') as f:
            data = json.load(f)

# Generated at 2022-06-17 20:06:12.347343
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:06:21.685777
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import pytest
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ConfigFileError
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import get_default_config_dir
    from pathlib import Path

# Generated at 2022-06-17 20:06:24.841012
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:06:33.963407
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_dir = tmpdir / 'config'
        config_dir.mkdir()
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_file.exists()
        rmtree(tmpdir)


# Generated at 2022-06-17 20:06:36.237863
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:07:10.795145
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:17.134827
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:22.300464
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:25.015137
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:36.455884
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json
    from httpie.config import BaseConfigDict
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a config file
    config_file = os.path.join(tmpdir, 'config.json')
    # create a config dict
    config_dict = BaseConfigDict(config_file)
    config_dict['test'] = 'test'
    config_dict.save()
    # check if the config file is created
    assert os.path.exists(config_file)
    # check if the config file is valid json
    with open(config_file, 'r') as f:
        json.load(f)
    # remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 20:07:39.557987
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:49.818731
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = Path(tmpdir) / 'config.json'
    # create a temporary config
    tmpconfig = BaseConfigDict(tmpfile)
    # create a temporary config content
    tmpconfig_content = {
        'default_options': [
            '--form',
            '--json',
            '--pretty=all',
            '--style=solarized'
        ]
    }
    # write the temporary config content to the temporary file
    with tmpfile.open('w') as f:
        json.dump(tmpconfig_content, f)
    # load the temporary config


# Generated at 2022-06-17 20:07:56.038537
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name, delete=False)
    # Write data to the temporary file
    temp_file.write(b'{"key": "value"}')
    temp_file.close()
    # Create a BaseConfigDict object
    config = BaseConfigDict(path=Path(temp_file.name))
    # Load the data from the temporary file
    config.load()
    # Check the data
    assert config == {"key": "value"}
    # Delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:08:04.227389
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    import httpie
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://httpie.org/docs'
        about = 'https://httpie.org/about'


# Generated at 2022-06-17 20:08:12.954431
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG
    x

# Generated at 2022-06-17 20:08:56.941095
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:09:08.791272
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_file = BaseConfigDict(Path('/tmp/config.json'))
    with open('/tmp/config.json', 'w') as f:
        f.write('{')
    try:
        config_file.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 2 (char 1) [Path(\'/tmp/config.json\')]'
    os.remove('/tmp/config.json')

    # Test for valid json file
    config_file = BaseConfigDict(Path('/tmp/config.json'))
    with open('/tmp/config.json', 'w') as f:
        f.write('{}')
    config_file.load()

# Generated at 2022-06-17 20:09:19.984733
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_path = tmpdir / 'test.json'
        config = TestConfigDict(config_path)
        assert config.is_new()
        config.save()
        assert not config.is_new()
        assert config['__meta__']['httpie'] == __version__
        assert config['__meta__']['help'] == 'http://example.com/help'

# Generated at 2022-06-17 20:09:31.481397
# Unit test for function get_default_config_dir

# Generated at 2022-06-17 20:09:39.375517
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test case 1: invalid json file
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    try:
        config_dict.load()
    except ConfigFileError as e:
        assert e.args[0] == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [/tmp/config.json]'

    # Test case 2: valid json file
    config_dict = BaseConfigDict(Path('/tmp/config.json'))
    config_dict.path.write_text('{"key": "value"}')
    config_dict.load()
    assert config_dict['key'] == 'value'

    # Test case 3: IOError
    config_dict = BaseConfigDict(Path('/tmp/config.json'))

# Generated at 2022-06-17 20:09:47.623013
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:09:49.061478
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:09:54.703932
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:10:01.921803
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        if (Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).exists():
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        # Test for XDG
        else:
            assert get_default_config_dir() == Path(os.environ.get(ENV_XDG_CONFIG_HOME, Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME)) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:10:08.511818
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for the case that the parent directory of the config file exists
    config_file = BaseConfigDict(Path('/tmp/config.json'))
    config_file.ensure_directory()
    assert Path('/tmp/config.json').exists()

    # Test for the case that the parent directory of the config file does not exist
    config_file = BaseConfigDict(Path('/tmp/test/config.json'))
    config_file.ensure_directory()
    assert Path('/tmp/test/config.json').exists()



# Generated at 2022-06-17 20:11:51.221573
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-17 20:11:56.943781
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:07.015334
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path
    from os import chmod, stat
    from stat import S_IRWXU, S_IRWXG, S_IRWXO

    with TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        config_file = BaseConfigDict(tmpdir_path / 'config.json')
        config_file.ensure_directory()
        assert tmpdir_path.exists()
        assert stat(tmpdir).st_mode & S_IRWXU == S_IRWXU
        assert stat(tmpdir).st_mode & S_IRWXG == 0
        assert stat(tmpdir).st_mode & S_IRWXO == 0
        rmtree(tmpdir)

        #

# Generated at 2022-06-17 20:12:16.680554
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file
    temp_file = Path(tempfile.mkstemp()[1])
    # create a temporary file in the temporary directory
    temp_file_in_dir = Path(tempfile.mkstemp(dir=temp_dir)[1])
    # create a temporary file in the temporary directory
    temp_file_in_dir_2 = Path(tempfile.mkstemp(dir=temp_dir)[1])
    # create a temporary file in the temporary directory
    temp_file_in_dir_3 = Path(tempfile.mkstemp(dir=temp_dir)[1])
    # create a temporary file in the temporary directory