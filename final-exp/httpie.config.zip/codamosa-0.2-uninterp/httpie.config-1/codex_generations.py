

# Generated at 2022-06-17 20:02:33.942509
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:02:36.278079
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:44.652467
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:47.073866
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:02:59.332930
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import ConfigFileError

    # Unit test for method get_default_config_dir

# Generated at 2022-06-17 20:03:01.232062
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:03:06.031815
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:17.295600
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for the case when the directory is not exist
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()
    # Test for the case when the directory is exist
    config_dir = Path('./test_config')
    config_dir.mkdir()
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:20.085933
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:03:28.313151
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.config_dir = os.path.join(self.tempdir, 'config')
            self.config_file = os.path.join(self.config_dir, 'config.json')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_save(self):
            config = Config(self.config_dir)
            config.save()
            self.assertTrue(os.path.exists(self.config_file))

    unittest.main()

# Generated at 2022-06-17 20:03:32.790811
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:42.595686
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for directory creation
    config_dir = Path('/tmp/httpie/test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()

    # Test for directory creation with parents
    config_dir = Path('/tmp/httpie/test_config/sub_dir')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()
    config_dir.parent.rmdir()

    # Test for directory creation with parents and mode
    config_dir = Path

# Generated at 2022-06-17 20:03:44.543612
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie_test')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.unlink()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()

# Generated at 2022-06-17 20:03:49.764245
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    config_dir = Path(temp_dir) / 'config'
    config_file = config_dir / 'config.json'

    config = BaseConfigDict(config_file)
    config.ensure_directory()

    assert config_dir.exists()
    assert config_dir.is_dir()

    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 20:03:51.717447
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:58.912729
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # create a BaseConfigDict object
    config = BaseConfigDict(path=temp_file.name)
    # save the config
    config.save()
    # check if the file exists
    assert os.path.exists(temp_file.name)
    # check if the file is empty
    assert os.stat(temp_file.name).st_size == 0
    # delete the temporary directory
    temp_dir.cleanup()

# Generated at 2022-06-17 20:04:05.266613
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    if config_file.exists():
        config_file.unlink()
    config = Config(directory=config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:11.425213
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:21.195380
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / 'config.json'
        config = TestConfigDict(path)
        config.save()
        assert config.path.exists()
        with config.path.open('rt') as f:
            data = json.load(f)
        assert data['__meta__']['httpie'] == __version__
        assert data['__meta__']['help'] == 'http://example.com/help'

# Generated at 2022-06-17 20:04:22.822260
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:30.808533
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:32.331213
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:04:40.547792
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_file.exists()
    assert config_file.is_file()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:51.564093
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmd

# Generated at 2022-06-17 20:04:55.213510
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:05:02.218857
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import errno
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    def test_ensure_directory(path):
        config_dict = TestConfigDict(path)
        config_dict.ensure_directory()
        assert os.path.exists(path)
        assert os.path.exists(os.path.dirname(path))
        assert os.path.isdir(os.path.dirname(path))

# Generated at 2022-06-17 20:05:06.054615
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:14.219837
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # create a BaseConfigDict object
    config_dict = BaseConfigDict(path=Path(temp_file.name))
    # create a directory
    config_dict.ensure_directory()
    # check if the directory exists
    assert os.path.exists(temp_dir.name)
    # delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:05:16.600724
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:05:26.592971
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    if is_windows:
        temp_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        temp_dir = Path(tempfile.gettempdir()) / 'httpie'

    test_config_dict = TestConfigDict(temp_dir / 'config.json')
    test_config_dict.save()


# Generated at 2022-06-17 20:05:38.893620
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:05:41.653096
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path='/tmp/config.json')
    config.load()
    assert config.is_new() == True
    assert config.load() == None


# Generated at 2022-06-17 20:05:49.694230
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    from httpie.config import BaseConfigDict
    from pathlib import Path
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    # Test for Windows
    if is_windows:
        # Create a temporary directory
        temp_dir = tempfile.mkdtemp()
        # Create a temporary file
        temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
        # Create a temporary config file
        temp_config_file = Path(temp_file.name)
        # Create a temporary config directory
        temp_config_dir = temp_config_file.parent
        # Create a temporary config directory path
        temp_config_dir_path = temp_config_dir.parent

# Generated at 2022-06-17 20:05:51.916027
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:05:55.263905
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path='/tmp/config.json')
    config_dict.load()


# Generated at 2022-06-17 20:06:02.709797
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-17 20:06:05.757264
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:06:14.521770
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'




# Generated at 2022-06-17 20:06:23.174583
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import errno
    import tempfile
    import shutil

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://test.com'
        about = 'test'

    def test_load(path):
        config = TestConfigDict(path)
        config.load()
        assert config['__meta__']['httpie'] == __version__
        assert config['__meta__']['help'] == 'http://test.com'
        assert config['__meta__']['about'] == 'test'


# Generated at 2022-06-17 20:06:26.392932
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:06:38.984058
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:06:40.752921
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:06:46.405268
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    tmp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    tmp_file = tmp_dir / 'test.json'
    # Create a BaseConfigDict object
    test_config = BaseConfigDict(tmp_file)
    # Call the method ensure_directory
    test_config.ensure_directory()
    # Check if the directory is created
    assert tmp_dir.exists()
    # Remove the temporary directory
    shutil.rmtree(tmp_dir)


# Generated at 2022-06-17 20:06:54.954861
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config.delete()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:00.255862
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:07:01.909732
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:07.449970
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:15.845994
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary file in the temporary directory
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)
    # Create a BaseConfigDict object with the temporary file
    config = BaseConfigDict(temp_file_path)
    # Call the method ensure_directory
    config.ensure_directory()
    # Check if the temporary directory exists
    assert temp_dir_path.exists()
    # Check if the temporary file exists
    assert temp_file_path.exists()
    # Delete the temporary directory
    temp_dir.cleanup()

# Generated at 2022-06-17 20:07:19.040693
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:07:25.091231
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:57.729684
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:04.752677
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config = BaseConfigDict(config_path)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:09.060935
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_dict = BaseConfigDict(temp_dir / 'config.json')
        config_dict.ensure_directory()
        assert (temp_dir / 'config.json').parent.exists()


# Generated at 2022-06-17 20:08:14.553730
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie_test')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()
    config_file.unlink()


# Generated at 2022-06-17 20:08:18.552754
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:23.893702
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:26.885669
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:08:33.481018
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test for invalid json file
    try:
        config = BaseConfigDict(Path('test_config.json'))
        config.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [test_config.json]'
    # test for valid json file
    config = BaseConfigDict(Path('test_config_valid.json'))
    config.load()
    assert config['test'] == 'test'


# Generated at 2022-06-17 20:08:39.714113
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
    config = TestConfig(Path('/tmp/test_BaseConfigDict_ensure_directory'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-17 20:08:47.929792
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/baz/qux'
    assert get_default_config_dir() == Path('/baz/qux')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:35.025156
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:43.302392
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:09:44.588751
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:09:47.197243
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:59.400939
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        config_path = tmpdir / 'test.json'
        config = TestConfigDict(config_path)
        assert config.is_new()

        config['foo'] = 'bar'
        config.save()
        assert config_path.exists()

        config.clear()
        assert config.is_new()

        config.load()
        assert config['foo'] == 'bar'

        # Test invalid JSON
        with open(config_path, 'w') as f:
            f.write('{')

# Generated at 2022-06-17 20:10:08.889534
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1:
    #   - $XDG_CONFIG_HOME is set
    #   - $HTTPIE_CONFIG_DIR is not set
    #   - ~/.config/httpie exists
    #   - ~/.httpie does not exist
    #   - platform is not Windows
    #
    # Expected result:
    #   - ~/.config/httpie
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    (Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME).mkdir(parents=True)
    assert get_default_config

# Generated at 2022-06-17 20:10:13.006397
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"default_options": []}')
    config = Config(directory=config_dir)
    config.save()
    assert config_file.read_text() == '{"default_options": [], "__meta__": {"httpie": "2.0.0"}}'
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:10:14.555510
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:22.931760
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import tempfile

    if is_windows:
        config_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        config_dir = Path.home() / '.config' / 'httpie'

    config_file = config_dir / 'config.json'

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Change the working directory to the temporary directory
    os.chdir(temp_dir.name)

    # Create a config file
    config_file.parent.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-17 20:10:24.377882
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:11:17.185448
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    import json
    import os
    import shutil
    import tempfile

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://httpie.org/docs'
        about = 'httpie test config'

    tmp_dir = Path(tempfile.mkdtemp())
    config_path = tmp_dir / 'config.json'
    config = TestConfigDict(config_path)
    config.save()
    assert config_path.exists()
    with config_path.open('rt') as f:
        data = json.load(f)
    assert data['__meta__']['httpie'] == __version__
    assert data['__meta__']['help'] == 'http://httpie.org/docs'

# Generated at 2022-06-17 20:11:25.748220
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/config'
    assert get_default_config_dir() == Path('/tmp/config') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/config'
    assert get_default_config_dir() == Path('/tmp/config')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:33.279799
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    if is_windows:
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = os.path.join(tmpdir, 'config.json')
        config = BaseConfigDict(config_path)
        config.save()
        with open(config_path, 'r') as f:
            data = json.load(f)
            assert data == {'__meta__': {'httpie': __version__}}



# Generated at 2022-06-17 20:11:37.141331
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:11:38.967355
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:11:40.960526
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:48.263415
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import json
    import errno
    import sys
    import tempfile

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.test.com'
        about = 'test config'

    if is_windows:
        config_dir = Path(os.path.expandvars('%APPDATA%')) / 'httpie'
    else:
        config_dir = Path.home() / '.config' / 'httpie'

    # test save
    with tempfile.TemporaryDirectory() as tmpdir:
        config_dir = Path(tmpdir) / 'httpie'

# Generated at 2022-06-17 20:11:59.342204
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: default
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 4: Windows

# Generated at 2022-06-17 20:12:01.613190
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:12:11.699562
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    assert get_default_config_dir() == xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME

    # Test for explicitly set through env