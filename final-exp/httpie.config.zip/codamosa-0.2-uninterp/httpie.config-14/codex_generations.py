

# Generated at 2022-06-17 20:02:31.117787
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    # 1. Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    temp_dir_path.mkdir(mode=0o700, parents=True)

    # 2. Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)
    temp_file.close()

    # 3. Create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file_path)

    # 4. Save the BaseConfigDict object
    config

# Generated at 2022-06-17 20:02:36.913084
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config.delete()
    config_dir.rmdir()


# Generated at 2022-06-17 20:02:46.046133
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
            self.path = path

    path = Path('./test.json')
    test_config = TestConfig(path)
    test_config.load()
    assert test_config == {}
    path.write_text('{"a": 1}')
    test_config.load()
    assert test_config == {"a": 1}
    path.write_text('{"a": 1, "b": 2}')
    test_config.load()
    assert test_config == {"a": 1, "b": 2}
    path.write_text('{"a": 1, "b": 2, "c": 3}')
    test_config.load()

# Generated at 2022-06-17 20:02:48.591728
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config.default_options == []


# Generated at 2022-06-17 20:02:57.787749
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config_file.write_text('{}')
    config = Config(config_dir)
    config.save()
    assert config_file.read_text() == '{\n    "default_options": []\n}\n'
    config_file.unlink()
    config_file.parent.rmdir()



# Generated at 2022-06-17 20:03:08.167412
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    config_file = BaseConfigDict(path=Path('/tmp/config.json'))
    with open('/tmp/config.json', 'w') as f:
        f.write('{')
    try:
        config_file.load()
    except ConfigFileError:
        pass
    else:
        assert False
    os.remove('/tmp/config.json')

    # Test for valid json file
    config_file = BaseConfigDict(path=Path('/tmp/config.json'))
    with open('/tmp/config.json', 'w') as f:
        f.write('{"a": "b"}')
    config_file.load()
    assert config_file['a'] == 'b'
    os.remove('/tmp/config.json')

    # Test

# Generated at 2022-06-17 20:03:10.698304
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:03:19.989735
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:03:28.743275
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie_config_dir'
    assert get_default_config_dir() == Path('/tmp/httpie_config_dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG
    xd

# Generated at 2022-06-17 20:03:33.678353
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:39.459911
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()


# Generated at 2022-06-17 20:03:46.011592
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file
    temp_file = temp_dir / 'config.json'
    # create a BaseConfigDict object
    config = BaseConfigDict(temp_file)
    # save the file
    config.save()
    # check if the file exists
    assert temp_file.exists()
    # check if the file is not empty
    assert temp_file.stat().st_size > 0
    # remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:03:48.726177
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:59.164045
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    import os
    import json
    import shutil
    import tempfile
    import errno

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://httpie.org/docs'
        about = 'https://httpie.org'

    def test_save():
        temp_dir = Path(tempfile.mkdtemp())
        config_path = temp_dir / 'config.json'
        config = TestConfigDict(config_path)
        config.save()
        assert config_path.exists()
        with config_path.open('rt') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__

# Generated at 2022-06-17 20:04:02.737852
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        pass
    config = TestConfig(Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:04:03.789546
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()

# Generated at 2022-06-17 20:04:09.639984
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.write_text('{"default_options": ["--json"]}')
    config = Config(config_dir)
    config.save()
    assert config_file.read_text() == '{"default_options": ["--json"], "__meta__": {"httpie": "2.0.0"}}'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:12.370171
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:17.631921
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'test.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:24.624651
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:04:33.269561
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie/')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / 'config.json'
    config_path.touch()
    config = Config(config_dir)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:04:34.246695
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:37.594957
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:04:41.899230
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path='test.json')
    config.save()
    assert os.path.exists('test.json')
    os.remove('test.json')


# Generated at 2022-06-17 20:04:49.658676
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config_file.write_text('{"default_options": []}')
    config = Config(config_dir)
    config.save()
    assert config_file.read_text() == '{"default_options": [], "__meta__": {"httpie": "2.0.0"}}'


# Generated at 2022-06-17 20:04:53.402750
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('/tmp/test_config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:04:59.159707
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/baz'
    assert get_default_config_dir() == Path('/foo/bar/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:05:05.644469
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid json file
    with pytest.raises(ConfigFileError):
        config = BaseConfigDict(Path('/tmp/config.json'))
        config.load()
    # Test for valid json file
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.path.write_text('{"a":1}')
    config.load()
    assert config['a'] == 1


# Generated at 2022-06-17 20:05:09.737446
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a file
    path = Path('test_config.json')
    path.write_text('{"a": 1}')
    # create a BaseConfigDict
    config = BaseConfigDict(path)
    # load the file
    config.load()
    # check the content
    assert config['a'] == 1
    # delete the file
    path.unlink()


# Generated at 2022-06-17 20:05:13.576441
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:05:26.597180
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/some/path'
    assert get_default_config_dir() == Path('/some/path') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/other/path'
    assert get_default_config_dir() == Path('/some/other/path')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path('/some/path') / 'httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home()

# Generated at 2022-06-17 20:05:28.780636
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:05:36.808518
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test for method ensure_directory of class BaseConfigDict
    # Create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file
    temp_file = temp_dir / 'config.json'
    # Create a temporary config object
    temp_config = BaseConfigDict(temp_file)
    # Call method ensure_directory
    temp_config.ensure_directory()
    # Check if the directory is created
    assert temp_dir.exists()
    # Remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:05:45.827990
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test for invalid json file
    config_file = BaseConfigDict(path=Path('test_config.json'))
    config_file.path.write_text('{"key": "value"')
    try:
        config_file.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 12 (char 11) [test_config.json]'
    config_file.path.unlink()

    # test for valid json file
    config_file = BaseConfigDict(path=Path('test_config.json'))
    config_file.path.write_text('{"key": "value"}')
    config_file.load()
    assert config_file['key'] == 'value'
    config_file.path.unlink()

    #

# Generated at 2022-06-17 20:05:54.187793
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    config.delete()
    assert not config_dir.exists()
    assert not config_file.exists()

# Generated at 2022-06-17 20:06:06.155685
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / 'httpie'

# Generated at 2022-06-17 20:06:11.198709
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/baz'
    assert get_default_config_dir() == Path('/foo/baz')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert get_default_config_dir() == DEFAULT_CONFIG

# Generated at 2022-06-17 20:06:15.600291
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config_path.write_text('{"a": "b"}')
    config = Config(config_dir)
    config.load()
    assert config['a'] == 'b'
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:17.518508
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:24.433832
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:06:35.477848
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.write_text('{"default_options": ["--form"]}')
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:06:40.503440
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]



# Generated at 2022-06-17 20:06:48.756310
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path(__file__).parent / 'config'
    config_path = config_dir / 'config.json'
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'


# Generated at 2022-06-17 20:06:57.680405
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict

    with tempfile.TemporaryDirectory() as tempdir:
        config_path = os.path.join(tempdir, 'config.json')
        config = BaseConfigDict(config_path)
        config.save()

        with open(config_path, 'r') as f:
            data = json.load(f)
            assert data == {'__meta__': {'httpie': __version__}}



# Generated at 2022-06-17 20:06:59.594719
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:05.862981
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_file.exists()
    assert config_file.is_file()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:07.537080
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:07:12.915927
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')

# Generated at 2022-06-17 20:07:20.948369
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    assert config_file.stat().st_mode & 0o777 == 0o600
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:25.844626
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo')

# Generated at 2022-06-17 20:07:36.490813
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir()
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:41.396905
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('./test_config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:07:47.260859
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_dir')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:07:51.655130
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        pass
    config = TestConfig(Path('/tmp/test_config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:07:54.588354
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:03.948038
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test for invalid json file
    path = Path('./test.json')
    path.write_text('{')
    config = BaseConfigDict(path)
    try:
        config.load()
    except ConfigFileError as e:
        assert e.args[0] == 'invalid baseconfigdict file: Expecting value: line 1 column 2 (char 1) [./test.json]'
    path.unlink()

    # test for valid json file
    path.write_text('{"a": 1}')
    config = BaseConfigDict(path)
    config.load()
    assert config['a'] == 1
    path.unlink()

    # test for non-existent file
    config = BaseConfigDict(path)

# Generated at 2022-06-17 20:08:05.293685
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:08:13.761301
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import shutil
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py2

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie is a command line HTTP client.'

    test_config_dict = TestConfigDict(path=Path('test.json'))
    test_config_dict['default_options'] = ['--json']
    test_config_dict['__meta__'] = {
        'httpie': '1.0.0'
    }

# Generated at 2022-06-17 20:08:24.502082
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import ConfigFileError

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)


# Generated at 2022-06-17 20:08:26.326146
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:31.086269
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:33.363438
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('test.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:08:44.624958
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'This is a test'

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'test.json')
        config = TestConfigDict(path)
        config.save()
        with open(path, 'r') as f:
            data = json.load(f)
        assert data['__meta__']['httpie'] == __version__
        assert data['__meta__']['help'] == 'http://example.com/help'

# Generated at 2022-06-17 20:08:48.214400
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.is_new() == False


# Generated at 2022-06-17 20:08:52.372760
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
    config.load()
    assert config['default_options'] == []


# Generated at 2022-06-17 20:08:59.813997
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:06.261209
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPJSONData
    from httpie.plugins.builtin import HTTPJSONPath
    from httpie.plugins.builtin import HTTPMultipartFormData
    from httpie.plugins.builtin import HTTPPrettyOptions
    from httpie.plugins.builtin import HTTPPrintHooks
    from httpie.plugins.builtin import HTTPPrintHeaders
    from httpie.plugins.builtin import HTTPPrintBody
    from httpie.plugins.builtin import HTTPPrintBinary
   

# Generated at 2022-06-17 20:09:09.122473
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:09:10.515635
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:17.085401
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"key": "value"}')
    config = Config(config_dir)
    config.load()
    assert config['key'] == 'value'
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:31.795794
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:09:34.500876
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:09:40.649345
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import get_default_config_dir
    from httpie.config import ConfigFileError

    # test for method get_default_config_dir
    # 1. explicitly set through env
    os

# Generated at 2022-06-17 20:09:48.899882
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = os.path.join(tmpdir, 'config.json')
        config = TestConfig(config_path)
        config['test'] = 'test'
        config.save()
        with open(config_path, 'r') as f:
            data = json.load(f)
            assert data['__meta__']['httpie'] == __version__
            assert data['__meta__']['help'] == 'http://example.com/help'

# Generated at 2022-06-17 20:09:55.171846
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:01.678631
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name, delete=False)
    # create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file.name)
    # save the BaseConfigDict object
    config_dict.save()
    # check if the file exists
    assert os.path.exists(temp_file.name)
    # check if the file is empty
    assert os.path.getsize(temp_file.name) == 0
    # delete the temporary directory
    temp_dir.cleanup()


# Generated at 2022-06-17 20:10:02.645727
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:03.755353
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/config.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:10:04.658497
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:10:05.975780
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:19.337719
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()

    config = Config(config_dir)
    config.save()
    config.load()
    assert config.is_new() == False
    assert config.default_options == []
    config.delete()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:10:20.492542
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:22.246666
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:10:23.283537
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:10:32.894865
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:10:43.356748
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://help.test.com'
        about = 'test config'

    def get_default_config_dir():
        if is_windows:
            return Path(os.path.expandvars('%APPDATA%')) / 'httpie'
        else:
            return Path.home() / '.config' / 'httpie'

    DEFAULT_CONFIG_DIR = get_default_config_dir()


# Generated at 2022-06-17 20:10:46.778150
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config['test'] = 'test'
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:10:49.938942
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:10:55.389175
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:10:58.044849
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:11:26.187131
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No env variable set
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $XDG_CONFIG_HOME set
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg_config_home'
    assert get_default_config_dir() == Path('/tmp/xdg_config_home') / 'httpie'

    # Test 3: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie_config_dir'
    assert get_default_config_dir() == Path('/tmp/httpie_config_dir')

    # Test 4: Windows
    if is_windows:
        assert get_default_config

# Generated at 2022-06-17 20:11:27.696254
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:38.567560
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:11:40.156448
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:11:45.276826
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a new file
    filename = 'test_BaseConfigDict_load.json'
    filepath = Path(filename)
    filepath.touch()

    # Write data to the file
    data = {'key1': 'value1', 'key2': 'value2'}
    with filepath.open('wt') as f:
        json.dump(data, f)

    # Load the file
    config = BaseConfigDict(filepath)
    config.load()

    # Check the loaded data
    assert config['key1'] == 'value1'
    assert config['key2'] == 'value2'

    # Clean up
    filepath.unlink()


# Generated at 2022-06-17 20:11:49.333455
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert Path('test.json').exists()
    Path('test.json').unlink()

# Generated at 2022-06-17 20:11:54.492763
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPMultipartFormData
    from httpie.plugins.builtin import HTTPiePath
    from httpie.plugins.builtin import HTTPiePretty
    from httpie.plugins.builtin import HTTPieSession
    from httpie.plugins.builtin import HTTPieStream
    from httpie.plugins.builtin import HTTPieVerbose


# Generated at 2022-06-17 20:12:04.683423
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: No environment variable set
    # Expected result: ~/.config/httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test 2: $HTTPIE_CONFIG_DIR set
    # Expected result: $HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # Test 3: $HTTPIE_CONFIG_DIR set, $XDG

# Generated at 2022-06-17 20:12:06.840943
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:12:14.476640
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]