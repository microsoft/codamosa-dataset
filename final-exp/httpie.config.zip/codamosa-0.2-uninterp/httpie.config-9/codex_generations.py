

# Generated at 2022-06-17 20:02:28.505981
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:02:33.405976
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py2

    if is_py2:
        import io
        StringIO = io.StringIO
    else:
        from io import StringIO

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = Path(tmpdirname)
        if is_windows:
            tmpdir = Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        config_file = BaseConfigDict(path=tmpdir / 'config.json')
        config_file.save()
        with open(str(tmpdir / 'config.json'), 'r') as f:
            data

# Generated at 2022-06-17 20:02:35.339298
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:42.329804
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    temp_dir = Path(tempfile.mkdtemp())
    # create a temporary file
    temp_file = temp_dir / 'config.json'
    # create a BaseConfigDict object
    config = BaseConfigDict(temp_file)
    # call method ensure_directory
    config.ensure_directory()
    # check if the directory is created
    assert temp_dir.exists()
    # remove the temporary directory
    shutil.rmtree(temp_dir)


# Generated at 2022-06-17 20:02:48.720991
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:02:57.488894
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'about'

    config = TestConfigDict(Path('/tmp/test_config.json'))
    config.save()
    with open('/tmp/test_config.json') as f:
        data = json.load(f)
    assert data['__meta__']['httpie'] == __version__
    assert data['__meta__']['help'] == 'http://example.com/help'
    assert data['__meta__']['about'] == 'about'
    os.remove('/tmp/test_config.json')

# Generated at 2022-06-17 20:03:02.246046
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:04.089192
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:06.256107
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:03:12.894008
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / 'config.json'
    config = BaseConfigDict(config_path)
    config.save()
    assert config_path.exists()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:25.671104
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'http://example.com/help'
        about = 'http://example.com/about'

    config_dir = Path('/tmp/httpie/config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / 'test.json'
    config_path.write_text('{"foo": "bar"}')
    config = TestConfig(config_path)
    config.load()
    assert config['foo'] == 'bar'
    assert config['__meta__']['httpie'] == __version__
    assert config['__meta__']['help'] == 'http://example.com/help'

# Generated at 2022-06-17 20:03:27.776980
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:03:29.822812
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:03:31.815207
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.path.exists()


# Generated at 2022-06-17 20:03:42.261545
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config_file.unlink(missing_ok=True)
    config_dir.rmdir(missing_ok=True)

    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    assert config_file.read_text() == '{\n    "default_options": []\n}\n'

    config['default_options'] = ['--form']
    config.save()
    assert config_file.read_text() == '{\n    "default_options": [\n        "--form"\n    ]\n}\n'

    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:03:46.016479
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a temporary file
        with tempfile.NamedTemporaryFile(dir=tmpdirname, delete=False) as f:
            # Create a BaseConfigDict object
            config = BaseConfigDict(f.name)
            # Save the file
            config.save()
            # Check if the file exists
            assert os.path.exists(f.name)


# Generated at 2022-06-17 20:03:57.292248
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Create a temporary file
        with tempfile.NamedTemporaryFile(dir=tmpdirname, delete=False) as f:
            # Create a BaseConfigDict object
            config = BaseConfigDict(path=Path(f.name))
            # Save the BaseConfigDict object
            config.save()
            # Check if the file exists
            assert os.path.exists(f.name)
            # Check if the file is empty
            assert os.stat(f.name).st_size == 0
            # Check if the file is readable
            assert os.access(f.name, os.R_OK)
            # Check if the file is writable
            assert os.access(f.name, os.W_OK)
            #

# Generated at 2022-06-17 20:04:08.913840
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    temp_file_path = Path(temp_file.name)
    # Create a BaseConfigDict object with the temporary file as path
    config_dict = BaseConfigDict(temp_file_path)
    # Call the method ensure_directory
    config_dict.ensure_directory()
    # Check that the directory exists
    assert temp_file_path.parent.exists()
    # Check that the directory is empty
    assert len(os.listdir(temp_file_path.parent)) == 0
    # Check that the directory is not a symlink


# Generated at 2022-06-17 20:04:11.688735
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:04:15.022334
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-17 20:04:24.190672
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py38
    from httpie.compat import is_py39

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir_path, delete=False)
    temp_file_path = Path(temp_file.name)

    # Create a config dict
    config_dict = BaseConfigDict(temp_file_path)

    # Save the config dict
    config_dict.save()

    # Check if the file exists
    assert temp_

# Generated at 2022-06-17 20:04:33.621936
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class TestConfigDict(BaseConfigDict):
        name = 'test'

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test.json'
        config = TestConfigDict(path)
        assert config.is_new()
        config.save()
        assert not config.is_new()
        assert path.exists()

        with path.open('rt') as f:
            data = json.load(f)
        assert data['__meta__']['httpie'] == __version__
        assert data['__meta__']['help'] == config.helpurl

# Generated at 2022-06-17 20:04:36.394758
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-17 20:04:41.233650
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert os.path.exists(DEFAULT_CONFIG_DIR) == False
    config = Config()
    config.ensure_directory()
    assert os.path.exists(DEFAULT_CONFIG_DIR) == True


# Generated at 2022-06-17 20:04:44.321440
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('/tmp/test_config.json'))
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-17 20:04:49.693934
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test_BaseConfigDict_save'))
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-17 20:04:58.758577
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'

# Generated at 2022-06-17 20:05:01.840842
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:06.381019
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:05:08.154228
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:13.682256
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_config_dir')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config = Config(config_dir)
    config.ensure_directory()
    assert config_file.parent.exists()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:05:19.680209
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # 1. Test for explicitly set through env
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

        # 2. Test for legacy ~/.httpie
        os.environ['HOME'] = '/tmp'
        assert get_default_config_dir() == Path('/tmp/.httpie')
        del os.environ['HOME']

        # 3. Test for XDG
        # 3.1. Test for explicit

# Generated at 2022-06-17 20:05:21.174001
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path('/tmp/test.json'))
    config.load()
    assert config == {}


# Generated at 2022-06-17 20:05:22.528604
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:05:32.699022
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie.config import ENV_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_XDG_CONFIG_HOME
    from httpie.config import DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    from httpie.config import DEFAULT_CONFIG_DIRNAME
    from httpie.config import get_default_config_dir
    from httpie.config import ConfigFileError

# Generated at 2022-06-17 20:05:42.702833
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        # Test for Linux
        # Test for XDG
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
        assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME

        # Test for legacy
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
        assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME

        # Test for explicitly set
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'

# Generated at 2022-06-17 20:05:49.495112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # Test for Linux
    else:
        # Test for legacy ~/.httpie
        if (Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).exists():
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        # Test for XDG
        else:
            assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:05:53.746182
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=Path('test_config.json'))
    config_dict.load()
    assert config_dict == {}


# Generated at 2022-06-17 20:05:56.114976
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:00.280232
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/tmp/test.json'))
    config.save()
    assert Path('/tmp/test.json').exists()
    Path('/tmp/test.json').unlink()


# Generated at 2022-06-17 20:06:10.280116
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    tmp_dir = Path(tempfile.mkdtemp())
    # Create a temporary file in the temporary directory
    tmp_file = tmp_dir / 'tmp_file'
    # Create a BaseConfigDict object with the temporary file as its path
    tmp_config_dict = BaseConfigDict(tmp_file)
    # Ensure that the directory of the temporary file exists
    tmp_config_dict.ensure_directory()
    # Check that the directory of the temporary file exists
    assert tmp_file.parent.exists()
    # Remove the temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-17 20:06:18.931630
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(path=temp_file.name)
    # Call the method ensure_directory
    config_dict.ensure_directory()
    # Check if the directory is created
    assert os.path.exists(temp_file.name)
    # Clean up
    temp_file.close()
    temp_dir.cleanup()


# Generated at 2022-06-17 20:06:21.612113
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:06:31.360907
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.touch()

    config = Config(config_dir)
    config.ensure_directory()

    assert config_file.parent.exists()
    assert config_file.parent.is_dir()
    assert config_file.exists()
    assert config_file.is_file()

    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:06:36.007583
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:40.140413
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:06:43.570171
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_file.exists()
    config_dir.rmdir()

# Generated at 2022-06-17 20:06:50.304400
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/bar'
    assert get_default_config_dir() == Path('/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:06:59.502843
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    """
    Test the load method of BaseConfigDict
    """
    # Test for invalid json file
    with pytest.raises(ConfigFileError):
        config = BaseConfigDict(Path('/tmp/config.json'))
        config.load()

    # Test for valid json file
    config = BaseConfigDict(Path('/tmp/config.json'))
    config.path.write_text('{"key": "value"}')
    config.load()
    assert config['key'] == 'value'

    # Test for IOError
    with pytest.raises(ConfigFileError):
        config = BaseConfigDict(Path('/tmp/config.json'))
        config.load()


# Generated at 2022-06-17 20:07:03.836230
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(Path('/tmp/test_httpie_config'))
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()
    config_dict.path.parent.rmdir()


# Generated at 2022-06-17 20:07:16.472036
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-17 20:07:20.277912
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir.name)
    # Create a BaseConfigDict object
    config_dict = BaseConfigDict(temp_file.name)
    # Save the BaseConfigDict object
    config_dict.save()
    # Read the saved file
    with open(temp_file.name, 'r') as f:
        data = json.load(f)
    # Check the saved file
    assert data['__meta__']['httpie'] == __version__
    # Delete the temporary directory
    temp_dir.cleanup()

# Generated at 2022-06-17 20:07:27.893215
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir
    legacy_config_dir.rmdir()

    # 4. XDG

# Generated at 2022-06-17 20:07:37.498071
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # Test for Linux
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    # Test for legacy ~/.httpie
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
        return

    # Test for XDG
    assert get_default_config_dir() == xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-17 20:07:40.623580
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config.default_options == []

# Generated at 2022-06-17 20:07:46.457345
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_file.parent.rmdir()


# Generated at 2022-06-17 20:07:49.059883
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:07:56.166237
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ['APPDATA'] = '/tmp'

# Generated at 2022-06-17 20:07:59.448920
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('config.json'))
    config['default_options'] = []
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-17 20:08:05.457395
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:18.551958
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:22.436669
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_httpie_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(path=config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:27.670748
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = Path(temp_dir.name)
    # Create a temporary config file
    temp_config_file = tempfile.NamedTemporaryFile(
        mode='w+t',
        dir=temp_dir_path,
        suffix='.json',
        delete=False
    )
    temp_config_file_path = Path(temp_config_file.name)
    # Create a temporary config dict
    temp_config_dict = BaseConfigDict(path=temp_config_file_path)
    # Test ensure_directory
    temp_config_dict.ensure_directory()
    # Check if the directory exists
    assert temp_config_file_path.parent.exists()
    # Clean up
    temp_config_

# Generated at 2022-06-17 20:08:34.094736
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config_file.unlink(missing_ok=True)
    config_dir.rmdir()
    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.is_dir()
    assert config_dir.stat().st_mode == 0o40700
    config_file.unlink()
    config_dir.rmdir()

# Generated at 2022-06-17 20:08:40.202929
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./test_config_dir')
    config_file = config_dir / 'config.json'
    config_file.parent.mkdir(mode=0o700, parents=True)
    config = Config(directory=config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:08:48.372702
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'

# Generated at 2022-06-17 20:08:51.238497
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:08:54.077318
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:02.359562
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py26
    from httpie.compat import is_py27
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37
    from httpie.compat import is_py38
    from httpie.compat import is_py39

    if is_py26:
        return
    if is_py27:
        return
    if is_py34:
        return
    if is_py35:
        return
    if is_py36:
        return

# Generated at 2022-06-17 20:09:04.660476
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-17 20:09:31.441609
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(mode=0o700, parents=True)
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:39.345560
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.plugins import plugin_manager

    class TestConfig(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

    with TemporaryDirectory() as tempdir:
        tempdir = Path(tempdir)
        config_dir = tempdir / 'config'
        config_file = config_dir / 'test.json'
        config = TestConfig(path=config_file)
        config.ensure_directory()
        assert config_dir.exists()
        assert config_dir.is_dir()
        if not is_windows:
            assert config_dir.stat().st_mode == 0o700


#

# Generated at 2022-06-17 20:09:43.856493
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/test_BaseConfigDict_ensure_directory')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:45.866248
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.ensure_directory()
    assert config_dir.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:09:58.848665
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1: no env var set
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test 2: $HTTPIE_CONFIG_DIR set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # Test 3: $XDG_CONFIG_HOME set
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

# Generated at 2022-06-17 20:10:01.535337
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path=Path('test.json'))
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-17 20:10:08.939786
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg/httpie')
    del os.environ[ENV_XDG_CONFIG_HOME]

    assert get_default_config_dir() == Path.home() / '.config/httpie'

# Generated at 2022-06-17 20:10:14.330796
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import os
    import json
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import is_py2

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary file path
    temp_file_path = Path(temp_file.name)
    # Create a BaseConfigDict instance
    base_config_dict = BaseConfigDict(path=temp_file_path)
    # Create a dictionary
    dict = {
        '__meta__': {
            'httpie': __version__
        }
    }
    # Update the dictionary
    base

# Generated at 2022-06-17 20:10:22.801766
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()

# Generated at 2022-06-17 20:10:25.668549
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path(__file__).parent / 'test_config_dir'
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:16.295506
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar') / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-17 20:11:22.563254
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigDict(BaseConfigDict):
        pass

    config_dir = Path('/tmp/test_httpie_config_dir')
    config_file = config_dir / 'config.json'
    config = TestConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:28.212565
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:11:37.517417
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'
    assert get_default_config_dir() == Path('/tmp/xdg') / 'httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-17 20:11:45.374377
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    import stat
    import errno
    import pytest

    class TestConfigDict(BaseConfigDict):
        pass

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # make the temporary file unreadable
    os.chmod(tmpfile.name, stat.S_IREAD)

    # create a config dict with the temporary file as its path
    config_dict = TestConfigDict(path=Path(tmpfile.name))

    # ensure_directory should fail
    with pytest.raises(OSError) as excinfo:
        config_dict.ensure_directory()
    assert excinfo.value.errno

# Generated at 2022-06-17 20:11:54.499523
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_config')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'
    config_file.touch()
    config = Config(config_dir)
    config.save()
    assert config_file.exists()
    config_file.unlink()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:01.183001
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path(__file__).parent / 'config'
    config_file = config_dir / 'config.json'
    config = Config(config_dir)
    config.load()
    assert config['default_options'] == ['--form']
    assert config['__meta__']['httpie'] == '0.9.9'
    assert config['__meta__']['help'] == 'https://httpie.org/docs'
    assert config['__meta__']['about'] == 'https://httpie.org'


# Generated at 2022-06-17 20:12:03.439244
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie/')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()


# Generated at 2022-06-17 20:12:12.487921
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree
    from os import chmod, stat
    from stat import S_IRUSR, S_IWUSR, S_IXUSR
    from httpie.config import BaseConfigDict

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        config_dict = BaseConfigDict(temp_dir / 'config.json')
        config_dict.ensure_directory()
        assert stat(temp_dir).st_mode & (S_IRUSR | S_IWUSR | S_IXUSR) == (S_IRUSR | S_IWUSR | S_IXUSR)