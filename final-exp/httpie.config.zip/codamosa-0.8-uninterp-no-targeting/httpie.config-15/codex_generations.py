

# Generated at 2022-06-21 13:39:55.781408
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(Exception):
        raise ConfigFileError
    raise ConfigFileError('config file error!')


# Generated at 2022-06-21 13:40:03.563846
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
   
    # Setup
    config_name = 'config.json'
    test_directory = Path('./')
    new_config = BaseConfigDict(path = Path(test_directory / config_name))
    
    assert new_config.is_new() == True

    # Execute
    new_config.save()

    # Verify
    assert new_config.is_new() == False
    assert Path(test_directory / config_name).exists()
    
    # Teardown
    os.remove(Path(test_directory / config_name))


# Generated at 2022-06-21 13:40:09.499751
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    t_config_dir_name = 'test_dir'
    b_config_path = get_default_config_dir() / t_config_dir_name
    b_config_path.mkdir()
    config_dir = BaseConfigDict(b_config_path)
    config_dir.ensure_directory()
    assert os.path.exists(b_config_path)
    b_config_path.rmdir()



# Generated at 2022-06-21 13:40:19.964664
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    # is_new() return False when the directory exists
    # Arrange
    d = TemporaryDirectory()
    p = Path(d.name)/'config'
    config = BaseConfigDict(path=p)

    # Act & Assert
    assert not config.is_new()
    d.cleanup()

    # is_new() return True when the directory doesn't exist
    # Arrange
    d = TemporaryDirectory()
    p = Path(d.name)/'config'
    config = BaseConfigDict(path=p)

    # Act & Assert
    assert config.is_new()
    d.cleanup()

# Generated at 2022-06-21 13:40:23.921937
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file_path = Path('file.txt')
    config_dict = BaseConfigDict(path=file_path)

    assert config_dict.path == file_path
    assert not config_dict.is_new()


# Generated at 2022-06-21 13:40:28.126432
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict("/home/user")
    config.ensure_directory()
    config.is_new()
    config.load()
    config.save()
    config.delete()


# Generated at 2022-06-21 13:40:38.881493
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Create a dummy config file in user's home directory -
    # tests.output.DIR_TEST_CONFIG_DELETE/DEFAULT_CONFIG_DIR/DEFAULT_CONFIG_FILENAME
    test_config_dir = Path(__file__).parent / 'test_config'
    test_config_filename = Config.FILENAME

    config = Config(directory=test_config_dir)
    config.ensure_directory()
    config.save()

    # Check if the config file exists before deletion
    assert os.path.isfile(str(config.path)) is True

    # Delete the config file
    config.delete()

    # Check if the config file is deleted
    assert os.path.isfile(str(config.path)) is False

# Generated at 2022-06-21 13:40:50.017868
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass
    else:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

    try:
        os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        pass
    else:
        del os.environ[ENV_XDG_CONFIG_HOME]

    home_dir = Path.home()
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/thing'
    assert get_default_config_dir() == Path(os.environ[ENV_HTTPIE_CONFIG_DIR])


# Generated at 2022-06-21 13:40:57.349931
# Unit test for constructor of class Config
def test_Config():
    cwd = Path.cwd()

# Generated at 2022-06-21 13:41:08.832151
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    def ini():
        config_dict_instance = BaseConfigDict(Path("./test.txt"))
        config_dict_instance.path.write_text("[]")
        config_dict_instance.load()
        return config_dict_instance

    def inv():
        config_dict_instance = BaseConfigDict(Path("./test.txt"))
        config_dict_instance.path.write_text("{}{}".format("1", "2"))
        try:
            config_dict_instance.load()
        except ConfigFileError as e:
            print(e)
            return config_dict_instance

    def nex():
        config_dict_instance = BaseConfigDict(Path("./test.txt"))

# Generated at 2022-06-21 13:41:14.221472
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    a = BaseConfigDict(Path('dir1/dir2/dir3/dir4'))
    assert a.load() == None


# Generated at 2022-06-21 13:41:22.769310
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import shutil
    dirpath = Path('./apps/' + DEFAULT_CONFIG_DIRNAME)
    dirpath.mkdir(mode=0o700, parents=True)
    filepath = dirpath / 'config.json'
    filepath.write_text('{ "hello": "world", "__meta__": { "httpie": "1.0.0" } }')
    c = Config(directory=dirpath)
    c.delete()
    assert os.path.exists(filepath) == False
    shutil.rmtree(dirpath, ignore_errors=True)


# Generated at 2022-06-21 13:41:24.997907
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict('test_BaseConfigDict_is_new')
    assert config.is_new()



# Generated at 2022-06-21 13:41:27.012298
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR)



# Generated at 2022-06-21 13:41:31.196450
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test if a config dir is returned
    assert get_default_config_dir()

    # Test if calling the function twice returns the same result
    first = get_default_config_dir()
    second = get_default_config_dir()
    assert first == second

# Generated at 2022-06-21 13:41:32.816325
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    configFileError = ConfigFileError('error message')
    assert str(configFileError) == 'error message'

# Generated at 2022-06-21 13:41:34.577150
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    config2 = Config()
    config2.load()
    assert config2 == config


# Generated at 2022-06-21 13:41:43.763359
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test config dir without env var, without legacy config and without XDG
    import os
    cwd = os.getcwd()
    os.chdir('/tmp')
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # Test env var
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test'
    config_dir = get_default_config_dir()
    assert config_dir == '/test'

    # Test Windows
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ['APPDATA'] = '/test'
    assert get_default_config_dir() == Path('/test') / 'httpie'

    # Test legacy config dir

# Generated at 2022-06-21 13:41:55.074187
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import pytest
    from httpie.config import BaseConfigDict

    with pytest.raises(ConfigFileError):
        def test_1():
            b = BaseConfigDict(Path("xz"))
            b["name"] = "b"
            b.save()

    with pytest.raises(ConfigFileError):
        def test_2():
            b = BaseConfigDict(Path(".."))
            b["name"] = "b"
            b.save()

    with pytest.raises(ConfigFileError):
        def test_3():
            b = BaseConfigDict(Path("///"))
            b["name"] = "b"
            b.save()

    with pytest.raises(ConfigFileError):
        def test_4():
            b = BaseConfigDict(Path("///"))
           

# Generated at 2022-06-21 13:42:07.400181
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    # def get_default_config_dir() -> Path:
    assert(c.directory == Path("/home/ubuntu/.config/httpie"))
    # def __init__(self, directory: Union[str, Path] = DEFAULT_CONFIG_DIR):
    c = Config("/tmp/test_dir")
    assert(c.directory == Path("/tmp/test_dir"))

    # def delete(self):
    assert(c.delete() == None)

    # def is_new(self) -> bool:
    assert(c.is_new() == True)

    # def load(self):
    assert(c.load() == None)

    # def ensure_directory(self):
    assert(c.ensure_directory() == None)

    # def save(self, fail_silently=False

# Generated at 2022-06-21 13:42:10.951516
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    assert BaseConfigDict.is_new


# Generated at 2022-06-21 13:42:13.329533
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("test")
    except Exception as err:
        assert type(err) == ConfigFileError


# Generated at 2022-06-21 13:42:20.268484
# Unit test for constructor of class Config
def test_Config():
    # Case1: the default constructor
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR

    # Case2: the explicit constructor
    config2 = Config('/tmp')
    assert config2.directory == Path('/tmp')

    # Case3: the explicit constructor but the directory is not an absolute path
    config3 = Config('~')
    assert config3.directory == Path.home()
test_Config()


# Generated at 2022-06-21 13:42:22.615275
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_dir = os.path.dirname(__file__)
    assert get_default_config_dir() == Path(
        f'{test_dir}/{DEFAULT_CONFIG_DIRNAME}')



# Generated at 2022-06-21 13:42:29.893811
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    path = Path("test.json")
    if path.exists():
        path.unlink()
    assert not path.exists()
    d = BaseConfigDict(path)
    assert d.is_new()

    with path.open('wt') as f:
        f.write("test")
    assert path.exists()
    d = BaseConfigDict(path)
    assert not d.is_new()

    path.unlink()

# Generated at 2022-06-21 13:42:41.146104
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        return Path(env_config_dir)

    # 2. Windows
    if is_windows:
        return DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        return legacy_config_dir

    # 4. XDG

# Generated at 2022-06-21 13:42:43.837652
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    configDir = get_default_config_dir()
    conf = Config(configDir)
    assert conf.is_new()



# Generated at 2022-06-21 13:42:55.081235
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = DEFAULT_CONFIG_DIR / 'test' / 'save.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()


# Generated at 2022-06-21 13:42:56.689646
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:42:59.926862
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    d = Path('test.json')
    d.touch()
    b = BaseConfigDict(d)
    b.delete()
    assert not d.exists()



# Generated at 2022-06-21 13:43:09.031815
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    configuration_file = BaseConfigDict(__name__)
    configuration_file['foo'] = 'bar'
    configuration_file.save()
    assert configuration_file['foo'] == 'bar'

if __name__ == '__main__':
    test_BaseConfigDict()
    print('All Tests Passed!')

# Generated at 2022-06-21 13:43:11.645210
# Unit test for constructor of class Config
def test_Config():
    input = DEFAULT_CONFIG_DIR
    expected_result = True
    actual_result = isinstance(Config(input), Config)
    assert actual_result == expected_result


# Generated at 2022-06-21 13:43:14.474696
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path('./test'))
    assert config.is_new() == False


# Generated at 2022-06-21 13:43:21.396602
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path("./test")
    path = config_dir / 'test.json'
    config = BaseConfigDict(path)

    # when config dir doesn't exist
    config.ensure_directory()
    assert config_dir.exists()

    # when config dir already exists
    assert config_dir.exists()
    config.ensure_directory()
    assert config_dir.exists()


# Generated at 2022-06-21 13:43:25.499397
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    FILE = 'testconfig.json'
    f = open(FILE,'w')
    f.write('some data')
    f.close()
    temp_instance = BaseConfigDict(FILE)
    temp_instance.delete()

# Generated at 2022-06-21 13:43:27.313703
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert issubclass(ConfigFileError, Exception)


# Generated at 2022-06-21 13:43:31.757203
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path('config.json'))
    config_dict['proxy'] = None
    test_config_dict = config_dict.load()
    if not test_config_dict == config_dict:
        raise ValueError('test faild')


# Generated at 2022-06-21 13:43:42.172841
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """ test the ensure_directory method of BaseConfigDict """
    import os
    import tempfile

    # creating a temporary directory and change to the temp dir
    temp_dir = tempfile.TemporaryDirectory(suffix='.test_httpie')
    current_dir = os.getcwd()
    os.chdir(temp_dir.name)

    # creating a fake class to test the method
    class FakeConfigDict(BaseConfigDict):
        def __init__(self):
            super().__init__('fake_config.json')

    fake_dict = FakeConfigDict()
    # the parent of the path doesn't exist

# Generated at 2022-06-21 13:43:54.552123
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class MockConfigDict(BaseConfigDict):
        def __init__(self, path):
            super(MockConfigDict, self).__init__(path=path)

    valid_json_string = '{"one": 1}'

    valid_json_file = StringIO(valid_json_string)
    path_valid_json = Path(valid_json_file.name)

    mock_config_dict = MockConfigDict(path_valid_json)
    mock_config_dict.load()

    assert mock_config_dict.pop('one') == 1

    invalid_json_string = '{"invalid json"}'
    invalid_json_file = StringIO(invalid_json_string)
    path_invalid_json = Path(invalid_json_file.name)

    mock_config_dict = Mock

# Generated at 2022-06-21 13:43:58.969675
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    temp_file = Path('./temp.json')
    config_dict = BaseConfigDict(path=temp_file)
    config_dict["hello"] = "world"
    config_dict.save()
    
    assert temp_file.exists()
    config_dict.delete()
    assert not temp_file.exists()

if __name__ == "__main__":
    test_BaseConfigDict_delete()

# Generated at 2022-06-21 13:44:14.424979
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    config_dic = BaseConfigDict(path=os.path.join(tempfile.gettempdir(), "test_config.json"))
    config_dic.load()
    config_dic.save()

# Generated at 2022-06-21 13:44:15.133331
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    assert config.is_new()



# Generated at 2022-06-21 13:44:21.937038
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class FakeConfig(BaseConfigDict):
        def __init__(self, path: Path, directory: str):
            self.directory = Path(directory)
            super().__init__(path=path)

    config_file_path = Path('test/test_config_file.json')
    config = FakeConfig(config_file_path, directory='test/.config')
    config.ensure_directory()
    assert config.path.parent.exists()

    config.path.parent.rmdir()
    assert not config.path.parent.exists()



# Generated at 2022-06-21 13:44:24.061590
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert c.default_options == []



# Generated at 2022-06-21 13:44:35.545406
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    x = {"a": "b"}
    
    # Test a valid json string
    with open('test_file.json', 'w') as file:
        json.dump(x, file)
    def convert(path):
        with open(path) as file:
            print(json.load(file))
    convert('test_file.json')

    # Test an invalid json string
    with open('test_file.json', 'w') as file:
        json.dump(x, file)
    try:
        file.close()
        f = open('test_file.json', 'r')
        f.write('invalid string')
        f.close()
        convert('test_file.json')
    except IOError:
        print("An error has occurred.")
    else:
        print("Successfully loaded.")

# Generated at 2022-06-21 13:44:38.235449
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path_to_config = BaseConfigDict('test_BaseConfigDict.json')
    path_to_config.save()


# Generated at 2022-06-21 13:44:44.153974
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('/tmp/httpie')
    config['foo'] = 'bar'
    assert config['foo'] == 'bar'
    config.save()
    file = open('/tmp/httpie', 'r')
    assert file.read() == '{"foo": "bar", "__meta__": {"httpie": "0.9.9"}}'

# Generated at 2022-06-21 13:44:45.988294
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    a = BaseConfigDict(Path("abc"))
    assert a.is_new()
    return

# Generated at 2022-06-21 13:44:47.715692
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert path.name == DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:44:54.606158
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import httpie
    tmp_dir = httpie.__UT__obj_dir(__file__)

    class BaseConfigDict_test(BaseConfigDict):
        FILENAME = 'config.json'

    # Case 1: config file exists
    with tmp_dir.as_cwd():
        BaseConfigDict_test(
            path=Path('.') / BaseConfigDict_test.FILENAME
        ).delete()
        assert not Path('.') / BaseConfigDict_test.FILENAME

    # Case 2: config file does not exists
    with tmp_dir.as_cwd():
        BaseConfigDict_test(
            path=Path('.') / BaseConfigDict_test.FILENAME
        ).delete()

    # Case 3: parent dir does not exists

# Generated at 2022-06-21 13:45:06.293554
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError("error message")
    assert str(error) == "error message"



# Generated at 2022-06-21 13:45:15.310441
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Environment variables
    env_vars = os.environ.copy()
    env_vars.update({"XDG_CONFIG_HOME" : "/tmp/home" , "HTTPIE_CONFIG_DIR" : "/tmp/home/config" })
    with mock.patch("httpie.config.os.environ", env_vars):
        with mock.patch("httpie.config.DEFAULT_RELATIVE_XDG_CONFIG_HOME", Path("/tmp/home")) as mock_xdg_home:
            with mock.patch("httpie.config.DEFAULT_RELATIVE_LEGACY_CONFIG_DIR", Path("/tmp/home/legacy")) as mock_legacy_home:
                config = baseConfigDict("/tmp/home/.config/httpie/config.json")

# Generated at 2022-06-21 13:45:27.013162
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    测试BaseConfigDict类中ensure_directory方法
    :return:
    """
    home_dir = Path.home()
    test_dir = home_dir / 'httpie_test'
    if test_dir.exists():
        shutil.rmtree(test_dir)
    # 存在，报错
    b = BaseConfigDict(home_dir)
    try:
        b.ensure_directory()
        assert True
    except Exception:
        assert False

    # 不存在，创建成功
    c = BaseConfigDict(test_dir)
    try:
        c.ensure_directory()
        assert True
    except Exception:
        assert False




# Generated at 2022-06-21 13:45:36.969495
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import shutil

    # Create a temporary test directory
    tmp_dir = Path.cwd() / 'tmp'
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)
    tmp_dir.mkdir(mode=0o755, parents=True)

    # Create a temporary config json file
    tmp_config = tmp_dir / 'config.json'

    # Read the json file
    with tmp_config.open('r') as f:
        data = json.load(f)

    # Modify the json content
    data['__meta__'] = {'httpie': '0.9.2'}
    data['default_options'] = ['--weird']

    # Save the modified json content

# Generated at 2022-06-21 13:45:41.943608
# Unit test for constructor of class Config
def test_Config():
    # test for path attribute of Config
    def test_Config_path():
        pass

    # test for directory attribute of Config
    def test_Config_directory():
        pass

    # test for default_options attribute of Config
    def test_Config_default_options():
        pass

    # test for helpurl attribute of Config
    def test_Config_helpurl():
        pass



# Generated at 2022-06-21 13:45:48.169102
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TempConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(path="/tmp/temp_config.json")

    t = TempConfig()
    t.save()
    assert t.is_new() == False
    t.delete()
    assert t.is_new() == True
    return


if __name__ == "__main__":
    test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:45:50.642007
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-21 13:45:59.732492
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_path = Path('test.json')
    test_config = {
        '__meta__': {
            'httpie': __version__
        }
    }

# Generated at 2022-06-21 13:46:04.219462
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    tmp_dir = Path(tempfile.mkdtemp())
    class MyConfigDict(BaseConfigDict):
        pass
    my_config = MyConfigDict(path=tmp_dir/'foo.json')
    assert my_config.is_new()


# Generated at 2022-06-21 13:46:06.489618
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    assert BaseConfigDict(Path('/tmp/')).is_new() is True


# Generated at 2022-06-21 13:46:33.518458
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class testConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
    #test file not exist
    path = "dummy"
    cfg = testConfig(path)
    cfg.delete()
    #test file exist
    fd = open(path, "w")
    fd.close()
    cfg = testConfig(path)
    cfg.delete()



# Generated at 2022-06-21 13:46:36.167308
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    config.ensure_directory()
    assert 'default_options' in config
    assert config['default_options'] == []


# Generated at 2022-06-21 13:46:44.426581
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    #invalid config file
    path = './tests/data/config1'
    config = BaseConfigDict(Path(path))
    try:
        config.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [./tests/data/config1]'
    #valid config file
    path = './tests/data/config2'
    config = BaseConfigDict(Path(path))
    try:
        config.load()
    except ConfigFileError as e:
        assert str(e) == 'invalid baseconfigdict file: Expecting value: line 1 column 1 (char 0) [./tests/data/config2]'

# Generated at 2022-06-21 13:46:51.508910
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_file = Path('test_config.json')
    try:
        assert isinstance(test_file.exists(),bool)
        test_config = BaseConfigDict(test_file)
        assert test_config.is_new() == True
        test_config.save()
        assert test_config.is_new() == False
    finally:
        if test_file.exists():
            test_file.unlink()


# Generated at 2022-06-21 13:46:56.775497
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # A config file doesn't exist, so is_new() should return true
    config = BaseConfigDict(Path('/some/file/path/config'))
    assert config.is_new() == True
    
    # A config file exists, so is_new() should return false
    config = BaseConfigDict(Path('/usr/share/httpie/config.json'))
    assert config.is_new() == False

# Generated at 2022-06-21 13:47:01.806388
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()

    assert get_default_config_dir() == legacy_config_dir

    legacy_config_dir.rmdir()

    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR



# Generated at 2022-06-21 13:47:04.731139
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(path="/tmp/test.json")
    config['a'] = "a"
    config['b'] = {'b': 1}
    config.save()


# Generated at 2022-06-21 13:47:08.625062
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    # Act
    try:
        raise ConfigFileError('test')
    except ConfigFileError as e:
        # Assert
        assert isinstance(e, Exception)
        assert e.args[0] == 'test'


# Generated at 2022-06-21 13:47:12.076122
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = "/tmp/"
    test = BaseConfigDict(path)
    test.ensure_directory()
    assert os.path.exists("/tmp/") == True
    os.rmdir("/tmp/")


# Generated at 2022-06-21 13:47:21.365326
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if is_windows:
        legacy_config_dir = DEFAULT_WINDOWS_CONFIG_DIR / DEFAULT_

# Generated at 2022-06-21 13:47:46.091162
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    data = {
        'key': 'value'
    }
    with tempfile.NamedTemporaryFile('wt') as f:
        json.dump(data, f)
        f.flush()
        config = BaseConfigDict(Path(f.name))
        config.load()
        assert config == data


# Generated at 2022-06-21 13:47:47.721079
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
  configFileError = ConfigFileError()
  assert configFileError is not None, "constructor of ConfigFileError failed"

# Generated at 2022-06-21 13:48:01.063510
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config_file = 'this_is_a_test.json'
    test_config_path = str(DEFAULT_CONFIG_DIR / test_config_file)
    test_config_content = '{"color": "on"}'
    test_config_dict = BaseConfigDict(Path(test_config_path))

    def test_happy_path():
        test_config_dict.load()
        if test_config_dict['color'] == 'on':
            pass
        else:
            assert False

    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-21 13:48:03.612672
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    config = Config(config_dir)
    assert config.path == config_dir / Config.FILENAME

# Generated at 2022-06-21 13:48:04.571843
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.default_options == []

# Generated at 2022-06-21 13:48:08.143438
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        print('test ConfigFileError, pass')
    else:
        print('test ConfigFileError, fail')


# Generated at 2022-06-21 13:48:16.890689
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    '''
    Unit test for method delete of class BaseConfigDict
    '''
    class MockConfig(BaseConfigDict):
        '''
        Mock class of BaseConfigDict
        '''
        def __init__(self, path: Path):
            super().__init__(path=path)

    fpath = Path('./config_delete_test.json')
    fpath.touch()
    mock = MockConfig(fpath)
    mock['default_options'] = ['-h']
    mock.save()
    mock.delete()
    assert not fpath.exists()



# Generated at 2022-06-21 13:48:21.517706
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os, shutil

    directory = Path('/tmp/httpie')
    config = BaseConfigDict(directory / '/config.json')

    config.path.parent.mkdir(parents=True)
    config.update({"some_key": "some_value"})
    config.save()

    with config.path.open(mode="r") as f:
        lines = f.readlines()
        assert '"some_key": "some_value"' in lines
        assert '"__meta__": {\n    "httpie": ' in lines

    config.delete()
    assert not config.is_new()

    shutil.rmtree(directory, ignore_errors=True)

# Generated at 2022-06-21 13:48:31.741676
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    import json
    import os
    import tempfile

    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict): pass

    if is_windows:
        test_path = os.path.expandvars('%APPDATA%/')
    else:
        test_path = '/tmp/'
    test_config_file = tempfile.TemporaryFile(mode='w+b', dir=test_path, suffix='.json')
    test_config_file.close()
    test_config_file = Path(test_config_file.name)

    test_json_data = {"test": "example_data"}


# Generated at 2022-06-21 13:48:33.076759
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config is not None
