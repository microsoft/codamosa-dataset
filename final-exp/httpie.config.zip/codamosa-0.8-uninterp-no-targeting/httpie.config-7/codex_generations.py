

# Generated at 2022-06-21 13:39:56.521333
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('This is an argument')
    except ConfigFileError as e:
        print(e.message)

# Generated at 2022-06-21 13:39:58.659578
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    cd = BaseConfigDict(DEFAULT_CONFIG_DIR)
    assert cd.is_new() 


# Generated at 2022-06-21 13:40:03.774259
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import DEFAULT_CONFIG_DIR
    config_file = BaseConfigDict(DEFAULT_CONFIG_DIR)
    config_file.ensure_directory()
    assert os.path.exists(str(DEFAULT_CONFIG_DIR))
    assert os.path.isdir(str(DEFAULT_CONFIG_DIR))

# Generated at 2022-06-21 13:40:06.914534
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    s = BaseConfigDict(Path('~/config.json'))
    s.load()
    s.is_new()
    s.save()
    s.delete()

# Generated at 2022-06-21 13:40:14.297518
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_test = Path('./test.json')
    inst = BaseConfigDict(path_test)
    with open('./test.json', 'w') as f:
        f.write('{"color": true, "config": { "debug": true , "log_level": "ERROR"}}')
    inst.load()
    assert inst['color'] == True
    assert inst['config'] == {'debug': True, 'log_level': 'ERROR'}


# Generated at 2022-06-21 13:40:20.605924
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Given a valid config file
    file_path = Path('./test_files/valid_config_json')
    dict_ = BaseConfigDict(file_path)

    # When we try to load the file
    dict_.load()

    # Then we should get the config data
    assert(dict_['default_options'] == ["--debug"])



# Generated at 2022-06-21 13:40:31.533127
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_env_xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    old_env_httpie_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)

# Generated at 2022-06-21 13:40:37.960603
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigDict(BaseConfigDict):
        name = "Test"

    temp_dir = tempfile.gettempdir()
    config = TestConfigDict(path=Path(temp_dir) / "TestConfig.json")
    config.ensure_directory()
    assert Path(temp_dir).is_dir()


# Generated at 2022-06-21 13:40:44.717736
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = 'test.json'
    if os.path.exists(path):
        os.remove(path)
    f = open(path, 'w+')
    f.write('{"name": "testfile"}')
    f.close()
    f = open(path, 'r')
    assert json.load(f) == {'name': 'testfile'}
    f.close()
    if os.path.exists(path):
        os.remove(path)

# Generated at 2022-06-21 13:40:51.467543
# Unit test for constructor of class Config
def test_Config():
    config = Config('/home/bohao/httpie/httpie/config')
    assert config.directory == Path('/home/bohao/httpie/httpie/config')
    assert config.DEFAULTS['default_options'] == []
    assert config['default_options'] == []
    assert config.default_options == []
    assert config.path == Path('/home/bohao/httpie/httpie/config') / 'config.json'



# Generated at 2022-06-21 13:40:55.823625
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    BaseConfigDict(Path(''))

# Generated at 2022-06-21 13:41:00.454169
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    filename = 'examples/config.json'
    with open(filename) as f:
        data = f.read()
    try:
        json.loads(data)
    except Exception as e:
        raise ConfigFileError(f'Invalid config file. {e}')
test_ConfigFileError()


# Generated at 2022-06-21 13:41:07.204394
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(path=DEFAULT_CONFIG_DIR / "config.json")
    config_dict.load()
    assert config_dict.is_new() == True
    path = DEFAULT_CONFIG_DIR/'test_file'
    config_dict.path = path
    path.touch()
    config_dict.load()
    assert config_dict.is_new() == False


# Generated at 2022-06-21 13:41:16.887041
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def _mock_environ(vars):
        orig_environ = dict(os.environ)
        os.environ.clear()
        os.environ.update(vars)
        yield
        os.environ.clear()
        os.environ.update(orig_environ)


# Generated at 2022-06-21 13:41:20.375531
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("Test message")
    except ConfigFileError as e:
        assert str(e) == "Test message"


if __name__ == '__main__':
    test_ConfigFileError()

# Generated at 2022-06-21 13:41:21.834789
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert type(c) == Config


# Generated at 2022-06-21 13:41:22.209693
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
   assert True

# Generated at 2022-06-21 13:41:24.848397
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict(Path("/a/b/c"))
    assert config_dict.path == Path("/a/b/c")


# Generated at 2022-06-21 13:41:28.603837
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    print(os.getcwd())
    config = Config()
    print(config.path)
    config.load()
    print(config)

if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-21 13:41:32.121108
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    assert conf.directory == Path(DEFAULT_CONFIG_DIR)
    assert conf.directory / Config.FILENAME == conf.path
    assert conf.default_options == conf.DEFAULTS['default_options']



# Generated at 2022-06-21 13:41:35.785854
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict('/some/path')


# Generated at 2022-06-21 13:41:37.181718
# Unit test for constructor of class Config
def test_Config():
    isinstance(Config, dict)

# Generated at 2022-06-21 13:41:40.704064
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import tempfile
    fd, path = tempfile.mkstemp(suffix='.json')
    bcd = BaseConfigDict(Path(path))
    assert bcd.is_new()
    bcd.save()
    assert not bcd.is_new()



# Generated at 2022-06-21 13:41:41.585169
# Unit test for constructor of class Config
def test_Config():
    assert isinstance(Config(), Config)



# Generated at 2022-06-21 13:41:46.355452
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    if config.is_new():
        assert config.path.exists()
        config.save(fail_silently=True)
        assert config.path.exists()
        config.delete()
        assert not config.path.exists()

# Generated at 2022-06-21 13:41:54.086663
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    d = BaseConfigDict(Path('/home/path'))
    d['__meta__'] = {
        'httpie': __version__
    }
    d['key1'] = 'value1'
    # PASS: BaseConfigDict is new
    assert d.is_new() == True
    d.save(fail_silently=False)
    # PASS: BaseConfigDict is NOT new
    assert d.is_new() == False
    d.delete()


# Generated at 2022-06-21 13:41:57.030421
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class D(BaseConfigDict):
        FILENAME = 'config.json'
        DEFAULTS = {}
    d = D('config.json')
    assert(d)


# Generated at 2022-06-21 13:42:08.906863
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from tempfile import TemporaryDirectory
    from httpie.config import ConfigFileError

    with TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir)
        config_path = config_dir / BaseConfigDict.FILENAME

        # 1. no file
        config_dict = BaseConfigDict(config_path)
        config_dict.load()

        # 2. invalid content
        config_path.write_text('')
        config_dict.load()
        config_path.write_text('{')
        try:
            config_dict.load()
            assert False
        except ConfigFileError:
            pass

        # 3. valid content
        config_path.write_text('{}')
        config_dict.load()

        # 4. not accessible

# Generated at 2022-06-21 13:42:14.208452
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict('~/.config/httpie/config.json')
    config.update({'hello': 'world'})
    config.save()
    config1 = BaseConfigDict('~/.config/httpie/config.json')
    config1.load()
    assert config1['hello'] == 'world'
    return 0


# Generated at 2022-06-21 13:42:20.652229
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TestConfigDict(BaseConfigDict):
        name = 'test'
    tc = TestConfigDict(path='/tmp/test.json')
    assert tc.is_new() == True
    tc['__meta__'] = {'httpie': __version__}
    tc.save()
    assert tc.is_new() == False
    tc.delete()


config = Config()
config.load()

# Generated at 2022-06-21 13:42:26.195236
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.environ.get(ENV_HTTPIE_CONFIG_DIR))

# Generated at 2022-06-21 13:42:37.776477
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dir = 'tests/test_dir'
    # Remove the test_dir to make sure that
    # the test_dir is not there
    try:
        shutil.rmtree(test_dir)
    except:
        pass

    assert not os.path.exists(test_dir)
    # Create an empty test_dir
    os.mkdir(test_dir)

    test_path = Path(test_dir) / 'test.json'
    json_string = '{"foo":"bar"}'


    with test_path.open('wt') as f:
        f.write(json_string)

    conf = BaseConfigDict(test_path)


    conf.load()

    assert conf['foo'] == 'bar'


# Cleanup the test_dir after test
    shutil.rmtree

# Generated at 2022-06-21 13:42:49.398155
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def mock_mkdir(mode, parents):
        if parents:
            assert mock_os.geteuid() == 0
        assert mode == 0o700
        nonlocal called
        called = True
        raise OSError(errno.EEXIST, os.strerror(errno.EEXIST))

    called = False
    mock_os = mock.MagicMock()
    mock_os.geteuid = mock.MagicMock(return_value=0)


# Generated at 2022-06-21 13:42:56.285150
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    def test():
        file_path = "./test_file"
        with open(file_path, "w", encoding="utf-8") as f:
             f.write('Hello World!')
        os.chmod(file_path, 0o777)
        bcd = BaseConfigDict(file_path)
        assert os.path.exists(file_path) == True
        bcd.delete()
        assert os.path.exists(file_path) == False

    test()


# Generated at 2022-06-21 13:43:02.188006
# Unit test for constructor of class Config
def test_Config():
    config_dir = '/tmp/httpie'
    config_path = Path(config_dir) / 'config.json'
    config_path.unlink(missing_ok=True)

    try:
        c = Config(directory=config_dir)
        assert c.default_options == []

        c.default_options.append('--auth')
        c.save()
        c2 = Config(directory=config_dir)
        assert c2.default_options == ['--auth']

        c.default_options = []
        c.save()
        c3 = Config(directory=config_dir)
        assert c3.default_options == []
    finally:
        config_path.unlink()



# Generated at 2022-06-21 13:43:12.036552
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(os.environ):
        # Case 1: the environment variable HTTPIE_CONFIG_DIR is set.
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/fake/path'
        assert get_default_config_dir() == '/fake/path'

        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        # Case 2: it is windows
        with mock.patch('httpie.config.is_windows', return_value=True):
            assert get_default_config_dir() == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

        # Case 3: the legacy ~/.httpie exists

# Generated at 2022-06-21 13:43:13.915268
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert(config['default_options'] == [])
    return 0



# Generated at 2022-06-21 13:43:16.509070
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    configdir = 'dir'
    path = 'dir/config.json'
    d = BaseConfigDict(path)
    assert(d.path==Path(path))
    assert(d.get('a') == None)

if __name__ == "__main__":
    test_BaseConfigDict()

# Generated at 2022-06-21 13:43:19.977782
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = '~/.httpie/config.json'
    bcd = BaseConfigDict(path)
    assert bcd.path == os.path.expanduser(path)


# Generated at 2022-06-21 13:43:23.597157
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    filepath = '/tmp/test_unit_test_config.json'
    bcf = BaseConfigDict(filepath)
    if bcf.is_new():
        assert True
    else:
        assert False

# Generated at 2022-06-21 13:43:37.173694
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_path = Path('.') / 'config.json'
    test_dict = BaseConfigDict(test_path)
    data = '{"__meta__": {"httpie": "1.0.4"}, "a": {"b": {"c": [1, 2, 3]}}}'
    test_dict.load()

    assert(len(test_dict) == 0)

    with test_path.open('wt') as f:
        f.write(data)

    test_dict.load()
    assert(test_dict['a'] == {"b": {"c": [1, 2, 3]}})

# Generated at 2022-06-21 13:43:42.959658
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('.') / "tests" / "configs" / "test_config.json"
    c = BaseConfigDict(path)
    c["x"] = 7
    c["y"] = 8
    c.save()
    with open(str(path)) as json_file:
        data = json.load(json_file)
    assert data["x"] == 7
    assert data["y"] == 8
    c.delete()


# Generated at 2022-06-21 13:43:45.753817
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    try:
        config.ensure_directory()
    except OSError:
        assert False

# Generated at 2022-06-21 13:43:47.465794
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config.is_new() == False

# Generated at 2022-06-21 13:43:58.484020
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    print("load method test");
    print("test:load:empty file");
    config = {"test_key":"test_value"}
    path = Path("./empty_file.json")
    try:
        with path.open('wt') as f:
            try:
                json.dump(config, f)
            except:
                pass
        path.unlink()
    except:
        print("open file failed");
    bcd = BaseConfigDict(path)
    bcd.load()
    print(bcd)
    print("test:load:wrong format file");
    try:
        with path.open('wt') as f:
            try:
                f.wrinte("hello world")
            except:
                pass
        path.unlink()
    except:
        print("open file failed");
    b

# Generated at 2022-06-21 13:44:00.463899
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        assert True

# Generated at 2022-06-21 13:44:05.285767
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Delete a file
    tmp_path = Path('/tmp/xxx.txt')
    tmp_path.write_text('The quick brown fox jumps over the lazy dog.')
    bcd = BaseConfigDict(path=tmp_path)
    bcd.delete()
    assert (not tmp_path.exists())
    # Use it on a non-existent file
    bcd.delete()


# Generated at 2022-06-21 13:44:17.801276
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    import tempfile
    from httpie.config import BaseConfigDict
    test_config = {"password": "123456"}
    fd, test_path = tempfile.mkstemp()
    os.close(fd)
    config_dict = BaseConfigDict(path=Path(test_path))
    config_dict.update(test_config)
    config_dict.save()
    assert os.path.exists(test_path), "test_path should exist."
    with open(test_path, 'r') as f:
        config_str = f.read()
    assert "__meta__" in config_str, "meta should exist in json file."
    # assert "httpie" in config_str, "httpie version should exist in json file."


# Generated at 2022-06-21 13:44:22.524718
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class Test(BaseConfigDict):
        name = 'test'
        helpurl = 'http://BYVoid.github.io/httpie'
        about = 'httpie test'

    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'config.json'
        config_dict = Test(path)
        config_dict.save()
        assert path.exists()


# Generated at 2022-06-21 13:44:26.324158
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = "./~/__httpie__/config.json"
    bcd = BaseConfigDict(path)
    print(bcd)


# Generated at 2022-06-21 13:44:32.715542
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:44:44.605543
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    temp_json = '.temp.json'
    # json file with correct content
    json_str = '{"a": 1, "b": 2}'
    with open(temp_json, 'w') as f:
        f.write(json_str)
    config = Config()
    config.load()
    assert config['a'] == 1 and config['b'] == 2
    config['c'] = 3
    # json file with wrong content
    with open(temp_json, 'w') as f:
        f.write('"a": 1, "b": 2}')
    config = Config()
    try:
        config.load()
    except ConfigFileError:
        pass
    else:
        os.remove(temp_json)
        assert False
    # file not exists
    os.remove(temp_json)
   

# Generated at 2022-06-21 13:44:46.929134
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from pathlib import Path
    configDict = BaseConfigDict(Path("/tmp/"))
    assert configDict.path == "/tmp/", "Path of config file incorrect"


# Generated at 2022-06-21 13:44:49.407606
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    d = BaseConfigDict("/httpie/config.json")
    d.update({"default_options": []})
    assert d["default_options"] == []



# Generated at 2022-06-21 13:44:54.237670
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    config = BaseConfigDict(Path.home() / '.httpie/config.json')
    config.save()
    assert json.loads(config.path.read_text()) == {}
    config.save()
    assert json.loads(config.path.read_text()) == {}


# Generated at 2022-06-21 13:45:01.270923
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class TestConfigDict(BaseConfigDict):
        pass

    test_config_dir = Path('/tmp')
    test_config_file = test_config_dir / 'test_config.json'
    test_config_file.open('w')
    test_config = TestConfigDict(test_config_file)
    test_config.delete()
    assert not test_config_file.exists(), "The test config file should be removed"

# Generated at 2022-06-21 13:45:05.523975
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('test')
    config_dict = BaseConfigDict(path=test_dir / 'test_config.json')
    # test_dir not exist
    assert not test_dir.exists()
    config_dict.ensure_directory()
    assert test_dir.exists()
    # test_dir exists
    config_dict.ensure_directory()
    assert test_dir.exists()
    # remove test_dir
    test_dir.rmdir()
    assert not test_dir.exists()


# Generated at 2022-06-21 13:45:14.780989
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import pytest
    from httpie.plugins.builtin import HTTPBasicAuth
    # test for deleting a exist file
    class AuthConfig(BaseConfigDict):
        FILENAME = 'auth.json'

    auth_config = AuthConfig(path=DEFAULT_CONFIG_DIR / 'auth.json')
    # create a file
    auth_config.save()
    assert DEFAULT_CONFIG_DIR / 'auth.json'
    auth_config.delete()
    with pytest.raises(FileNotFoundError):
        auth_config.path.unlink()

    # test for deleting a non-exist file
    auth_config = AuthConfig(path=DEFAULT_CONFIG_DIR / 'auth.json')
    with pytest.raises(FileNotFoundError):
        auth_config.delete()



# Generated at 2022-06-21 13:45:25.111988
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_filename = ".temp_save_test"
    current_dir = Path.cwd()
    if(current_dir.parent.name == "httpie"):
        path = current_dir / "tests" / temp_filename
    else:
        path = current_dir.parent / "httpie" / "tests" / temp_filename
    config = BaseConfigDict(path)
    config["__meta__"] = {'httpie': __version__}
    assert config.is_new(), "Config file is new"
    config.save()
    assert not config.is_new(), "Config file wasn't saved"
    config.delete()
    assert config.is_new(), "Config file isn't deleted"


# Generated at 2022-06-21 13:45:30.605358
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_file = BaseConfigDict(path=Path("./new_file.json"))
    assert test_file.is_new() == True

    test_file_1 = BaseConfigDict(path=Path("./new_file_1.json"))
    test_file_1.load()
    assert test_file_1.is_new() == False



# Generated at 2022-06-21 13:45:44.894299
# Unit test for constructor of class Config
def test_Config():
    """
     This is unit test for the constructor of class Config
     From the test result, we can know that class Config can be constructed
     successfully.
    """
    configInstance = Config()
    assert isinstance(configInstance, Config)


# Generated at 2022-06-21 13:45:48.169376
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'test.json')
    assert config.is_new() == True
    config.save()
    assert config.is_new() == False


# Generated at 2022-06-21 13:45:53.737295
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file_name = 'my_config.json'
    base_config = BaseConfigDict(Path(file_name))
    assert base_config.path == Path(file_name)
    assert base_config['__meta__'] == {}
    assert base_config['key1'] == {}
    assert base_config['key2'] == {}


# Generated at 2022-06-21 13:45:57.754382
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
# Case 1: file exist
    test_path = Path('.') / 'httpie-test-1'
    test_path.touch()
    test_dict = BaseConfigDict(test_path)
    test_dict.delete()
    assert test_path.exists() == False

# Case 2: file doesn't exist
    test_path_2 = Path('.') / 'httpie-test-2'
    test_dict_2 = BaseConfigDict(test_path_2)
    assert test_path_2.exists() == False
    assert test_dict_2.delete() == None

# Generated at 2022-06-21 13:45:59.453535
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    path = Path(__file__)
    d = BaseConfigDict(path)
    assert d.is_new() == False


# Generated at 2022-06-21 13:46:03.885428
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import json
    import tempfile
    import os
    import os.path
    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'config.json')
    bd = BaseConfigDict(path)
    assert bd.path == path
    assert bd.filename == 'config.json'
    assert bd.is_new() == True
    file = open(path, 'rw')
    file.close()
    assert bd.is_new() == False
    bd = BaseConfigDict(path)
    with open(path, 'r') as f:
        data = json.load(f)
    assert data == {}
    assert bd.load() == True
    data['a'] = 'b'

# Generated at 2022-06-21 13:46:06.659856
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    return_value = BaseConfigDict(path=Path('path')).is_new()
    assert return_value == True


# Generated at 2022-06-21 13:46:10.072770
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = "../compat/tests/data/config.json"
    config = BaseConfigDict(path)
    config.load()
    assert config == {"a":1,"b":2}


# Generated at 2022-06-21 13:46:15.462485
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    test_filename = 'test-delete.json'
    config_file = Path(test_filename)
    # Check that file exists before calling delete
    # method.
    assert config_file.exists() == True
    base_config_dict = BaseConfigDict(config_file)
    base_config_dict.delete()
    assert config_file.exists() == False

config = Config()



# Generated at 2022-06-21 13:46:20.157888
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with patch.object(Path, 'write_text') as mockWrite:
        cDict = BaseConfigDict(Path('/test'))
        cDict.save()
        expected = '''\
{
    "__meta__": {
        "httpie": "1.0.3"
    }
}
'''
        mockWrite.assert_called_once_with(expected)

# Generated at 2022-06-21 13:46:34.297921
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = os.getcwd()+"\\test\\test_config.json"
    config = BaseConfigDict(path)
    config.load()
    assert config['test'] == 1
    assert config['test1'] == 2


# Generated at 2022-06-21 13:46:39.445865
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from io import StringIO

    with open("test_data/api.json",'r') as f:
        with StringIO("") as test_file:
            test_file.write(json.dumps(f.read()))
            expected_str = test_file.getvalue()
            print(expected_str)

# Generated at 2022-06-21 13:46:50.640802
# Unit test for function get_default_config_dir

# Generated at 2022-06-21 13:46:52.734372
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict('foo/bar')
    assert config.is_new()


# Generated at 2022-06-21 13:47:03.855854
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from io import StringIO
    import sys
    import json
    import os

    # Save the reference to the previous stdout
    old_stdout = sys.stdout

    # Create StringIO object
    string_io = StringIO()

    # Assign the StringIO object to the stdout
    sys.stdout = string_io

    # Create a config file
    config = Config(directory=os.path.dirname(os.path.abspath(__file__)))
    config.save()

    # Get the stdout from the beginning
    string_io.seek(0)

    # Read the stdout
    json_str = string_io.read()

    # Use JSON library to decode the JSON string
    json_str = json.loads(json_str)

    # Assert that the default options of JSON string is a list


# Generated at 2022-06-21 13:47:06.334279
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('Custom error!')
    except ConfigFileError as e:
        assert str(e) == 'Custom error!'


# Generated at 2022-06-21 13:47:08.187285
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert isinstance(config, dict)



# Generated at 2022-06-21 13:47:11.188636
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_dict = BaseConfigDict("test")
    test_config_dict['key'] = 'value'
    assert test_config_dict.save(True) is None


# Generated at 2022-06-21 13:47:20.678629
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # GIVEN
    config_dir = Path(os.getcwd()) / 'config_dir'
    config_dir.mkdir()
    config_dir_yaml = config_dir / 'config.yaml'
    config_dir_yaml.touch()
    config_dir_yaml.write_text(
        '{"default_options": ["--verbose", "--ignore-stdin"], "__meta__": {"httpie": "1.0.3"}}'
    )
    # WHEN
    config_dict = BaseConfigDict(config_dir_yaml)
    config_dict.load()
    # THEN
    print(config_dict.get('__meta__').get('httpie'))
    assert config_dict.get('default_options') == ["--verbose", "--ignore-stdin"]



# Generated at 2022-06-21 13:47:22.220340
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    assert Path(config.directory).exists()


# Generated at 2022-06-21 13:47:46.735391
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory  = '~/.httpie'
    config_dict = BaseConfigDict(directory)
    if os.path.isdir(directory):
        os.rmdir(directory)
    else:
        os.remove(directory)
    config_dict.ensure_directory()
    assert os.path.isdir(directory)



# Generated at 2022-06-21 13:47:50.292489
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Check load with no errors
    config_dict=BaseConfigDict('config.json')
    config_dict['key']='value'
    config_dict.save()
    config_dict['key'] = 'value1'
    config_dict.load()
    assert(config_dict['key']=='value')


# Generated at 2022-06-21 13:47:54.180526
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test message')
    except ConfigFileError as e:
        assert str(e) == 'test message'


# Generated at 2022-06-21 13:47:56.679789
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    #comparing the error to the exception
    exc = ConfigFileError("error")
    assert exc.args[0] == "error"


# Generated at 2022-06-21 13:48:02.505932
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = '/home/tddk/PycharmProjects/httpie/httpie/config_dir/config.json'
    f = open(path, 'w')
    f.write('{"a":1}')
    f.close()
    c = Config(path)
    c.load()
    print(c)
    assert c['a'] == 1


# Generated at 2022-06-21 13:48:07.040009
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config/httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = Path('~/myConfig').expanduser().as_posix()
    assert get_default_config_dir() == Path('~/myConfig').expanduser() / 'httpie'

    os.environ.pop(ENV_XDG_CONFIG_HOME)



# Generated at 2022-06-21 13:48:11.759947
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict()
    with open('test_data.txt', 'r') as json_file:
        config['test'] = json.load(json_file)
    config.load()
    assert config.keys() >= {'__meta__', 'test'}



# Generated at 2022-06-21 13:48:13.799799
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    assert config.is_new() == True

# Generated at 2022-06-21 13:48:24.941763
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree

    config_dirname = 'httpie'
    config_filename = 'config.json'
    with TemporaryDirectory() as tmpdir_path:
        tmpdir_path = Path(tmpdir_path)
        assert not (tmpdir_path / config_dirname).exists()
        assert not (tmpdir_path / config_dirname / config_filename).exists()

        conf = Config(tmpdir_path / config_dirname)
        conf.ensure_directory()
        assert (tmpdir_path / config_dirname).exists()
        assert not (tmpdir_path / config_dirname / config_filename).exists()

        conf.save()

# Generated at 2022-06-21 13:48:28.000479
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ['XDG_CONFIG_HOME'] = '.'
    assert get_default_config_dir() == Path('./httpie')



# Generated at 2022-06-21 13:49:38.730550
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()
    config.ensure_directory()
    assert config.directory.exists()


# Generated at 2022-06-21 13:49:39.545681
# Unit test for constructor of class Config
def test_Config():
    assert Config().default_options == []



# Generated at 2022-06-21 13:49:51.029730
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    import json

    # get test directory
    cfg_dir = tempfile.mkdtemp()
    cfg = os.path.join(cfg_dir,"config.json")
    mypath = Path(cfg)
    testDict = BaseConfigDict(mypath)
    testDict['test'] = '1234'
    testDict['test2'] = '4567'
    testDict.save()

    # open saved file and make a dict
    with open(cfg, "r") as f:
        fileDict = json.load(f)

    # compare testDict with fileDict
    assert fileDict == testDict
    f.close()
    os.remove(cfg)
    os.rmdir(cfg_dir)
