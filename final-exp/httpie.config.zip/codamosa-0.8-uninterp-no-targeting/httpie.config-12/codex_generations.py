

# Generated at 2022-06-21 13:39:57.382634
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    my_file = BaseConfigDict(Path('/Users/ztang/httpie/httpie'))
    try:
        my_file.ensure_directory()
    except OSError as e:
        print(e)
        raise
    else:
        print('directory created!')

# Generated at 2022-06-21 13:40:00.799360
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    exception = ConfigFileError(
        'cannot read {config_type} file: {e}'
    )
    assert exception.args[0] == 'cannot read {config_type} file: {e}'


# Generated at 2022-06-21 13:40:04.350544
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('test.json')
    dic = BaseConfigDict(path)
    dic['name'] = 'httpie'

    dic.save()

    assert path.is_file()

# Generated at 2022-06-21 13:40:10.073126
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    class SimpleConfig(BaseConfigDict):
        def __init__(self, temp_dir):
            super().__init__(
                path = Path(temp_dir.name) / 'config.json'
            )
    config = SimpleConfig(temp_dir)
    assert config.is_new()
    temp_dir.cleanup()


# Generated at 2022-06-21 13:40:22.701502
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import Config
    from httpie.compat import is_windows

    test_dict = {
        '__meta__': {
            'httpie': __version__
        },
        'Content-Type': 'application/json'
    }

    temp_file_name = 'temp.json'
    config_path = Path('temp')



# Generated at 2022-06-21 13:40:24.473698
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict(path='temp')
    assert config_dict.path == Path('temp')
    assert config_dict.name is None
    assert config_dict.helpurl is None
    assert config_dict.about is None


# Generated at 2022-06-21 13:40:25.788643
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base_config_dict = BaseConfigDict('./')
    assert base_config_dict.load() == None


# Generated at 2022-06-21 13:40:31.072394
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path("/tmp/httpie")
    config_path = config_dir / "test.json"
    dic = BaseConfigDict(path=config_path)
    dic.ensure_directory()
    assert Path(config_dir).exists()
    config_path.unlink()
    config_dir.rmdir()

# Generated at 2022-06-21 13:40:40.497116
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    tmp_dir = tempfile.TemporaryDirectory()
    path_to_file = os.path.join(tmp_dir.name, 'test.json')
    with open(path_to_file, 'w') as f:
        f.write('') # Create empty file

    test_dict = BaseConfigDict(path_to_file)
    test_dict.delete()

    # Assert that the file is deleted
    assert not os.path.exists(path_to_file)
    tmp_dir.cleanup()

# Generated at 2022-06-21 13:40:47.548822
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/tmp/httpie')
    config_dir.mkdir(mode=0o700,parents=True)
    config_path = Path(config_dir / Config.FILENAME)
    config = Config(directory=config_dir)
    config.save()
    assert config_path.stat().st_mode & 0o700 == 0o700
    try:
        config_dir.rmdir()
    except:
        print("Cannot remove /tmp/httpie")


# Generated at 2022-06-21 13:40:54.776467
# Unit test for constructor of class Config
def test_Config():
    # Test whether the constructor raises errors,
    # not whether the returned object is correct.
    configdir = 'configdir'
    try:
        config = Config(configdir)
    except ConfigFileError as e:
        config = None
    assert config, f'Failed to create config object: {e}'
    # check whether the default config dir is set correctly
    assert config.directory == configdir



# Generated at 2022-06-21 13:41:04.699279
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(os.environ, {}, clear=True):
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    with mock.patch.dict(os.environ, {ENV_XDG_CONFIG_HOME: '/my/config'}, clear=True):
        assert get_default_config_dir() == Path('/my/config') / 'httpie'

    with mock.patch.dict(os.environ, {ENV_HTTPIE_CONFIG_DIR: '/my/config'}, clear=True):
        assert get_default_config_dir() == Path('/my/config')

# Generated at 2022-06-21 13:41:07.133785
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    p = get_default_config_dir()
    # on *nix, default is ~/.config/httpie
    if not is_windows:
        assert p == Path.home() / Path('.config') / 'httpie'

# Generated at 2022-06-21 13:41:08.163984
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    assert False


# Generated at 2022-06-21 13:41:10.442268
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    try:
        config = BaseConfigDict(path='config.json')
        config.delete()
    except:
        pass

# Generated at 2022-06-21 13:41:15.870215
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('./test_config.json')
    config = BaseConfigDict(path)
    config.save()
    config.load()
    assert config.is_new() == False
    assert 'httpie' in config['__meta__']
    assert config['__meta__']['httpie'] == __version__
    config.delete()
    assert os.path.exists('./test_config.json') == False

# Generated at 2022-06-21 13:41:18.712377
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    baseconfig = BaseConfigDict('test/test_config_dir/test_config.json')
    baseconfig['default_options'] = []
    baseconfig.save()



# Generated at 2022-06-21 13:41:29.818043
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        env_config_dir = os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        env_config_dir = None
    try:
        env_xdg_config_home = os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        env_xdg_config_home = None

    # 1. explicitly set through env
    expected = Path('/root/config')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(expected)
    assert get_default_config_dir() == expected

    # 2. Windows
    expected = Path('C:\\Users\\admin\\AppData\\Roaming\\httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = None
    assert get_

# Generated at 2022-06-21 13:41:32.076242
# Unit test for constructor of class Config
def test_Config():
    config_dir = os.getcwd()
    c = Config(config_dir)
    assert(c['default_options'] == [])



# Generated at 2022-06-21 13:41:33.027617
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass



# Generated at 2022-06-21 13:41:37.980832
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    bcd = BaseConfigDict('/tmp/config.json')
    assert bcd.path == '/tmp/config.json'


# Generated at 2022-06-21 13:41:40.763824
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    tfile = "test.json"
    cj = BaseConfigDict()
    cj.path = Path(tfile)

    with cj.path.open('w') as f:
        f.write("")

    # file exists
    assert cj.path.exists()

    cj.delete()

    # file does not exist
    assert not cj.path.exists()


# Generated at 2022-06-21 13:41:47.343337
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class Test(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

    path = Path(Path.cwd(), 'test.json')
    bcd = Test(path=path)
    bcd.save()
    assert bcd.is_new() is False


# Generated at 2022-06-21 13:41:50.296682
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    with open("test.json", "w") as f:
        json.dump({"key": "value"}, f)

    d = BaseConfigDict("test.json")
    d.load()
    assert d == {"key": "value"}


# Generated at 2022-06-21 13:41:51.423358
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        print("ConfigFileError has been thrown successfully")

# Generated at 2022-06-21 13:42:00.094143
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test the executable code
    conf = Config()
    conf['default_options'] = ['--form']
    conf.save()
    assert conf.path.exists()
    # Test the executable code
    conf = Config()
    conf['default_options'] = ['--form', '--verbose']
    conf.save()

# Generated at 2022-06-21 13:42:05.030683
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dirname = str(DEFAULT_CONFIG_DIR)
    config_filename = 'test.json'
    config_path = Path(dirname) / config_filename
    config = BaseConfigDict(path=config_path)
    assert config.load() == {}



# Generated at 2022-06-21 13:42:07.445895
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('test')
    new_config = BaseConfigDict(path)
    assert new_config.path == Path('test')


# Generated at 2022-06-21 13:42:10.221870
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert ( c.FILENAME == 'config.json')
    assert (c.DEFAULTS == {'default_options': []})
    assert (c.directory == DEFAULT_CONFIG_DIR)
    assert (c.path == DEFAULT_CONFIG_DIR / 'config.json')


# Generated at 2022-06-21 13:42:12.358618
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class Temp(BaseConfigDict):
        pass

    a = Temp(path=Path(Temp.__module__+'.json'))


# Generated at 2022-06-21 13:42:27.199456
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir_path = Path('tests/config/config_dir')
    temp_config_file_path = config_dir_path / 'config.json'

    dict_instance = BaseConfigDict(path=temp_config_file_path)

    try:
        dict_instance.load()
    except ConfigFileError:
        pass
    else:
        assert False, 'The temporary config file should be invalid.'

    dict_instance.path.parent.mkdir(parents=True)

    dict_instance['option1'] = 1
    dict_instance['option2'] = 2
    dict_instance['list_option'] = [1, 2, 3]
    dict_instance.save()

    dict_instance.load()

    assert dict_instance['option1'] == 1
    assert dict_instance['option2'] == 2

# Generated at 2022-06-21 13:42:38.657308
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # the unit test check if the function get_default_config_dir() return the correct path
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/user'
    assert str(get_default_config_dir()) == '/home/user/httpie'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert str(get_default_config_dir()) == '/home/user/.config/httpie'

    with patch('httpie.config.Path') as mock_Path:
        mock_Path.home.return_value = '/Users/user'
        mock_Path.user_config_dir.return_value = '/Users/user/Library/Preferences'
        assert str(get_default_config_dir()) == '/Users/user/Library/Preferences/httpie'

# Generated at 2022-06-21 13:42:45.257508
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'foo' / 'bar.txt'

        # Directory does not exist
        with path.open('wt') as f:
            f.write('foo')
        assert path.exists()

        # Directory already exists
        with path.open('wt') as f:
            f.write('foo')



# Generated at 2022-06-21 13:42:56.332901
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import os.path
    import shutil

    # Test with config dir explicitly set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/base/config/dir/explicit/'
    config_dir1 = get_default_config_dir()
    assert config_dir1 == '/base/config/dir/explicit/httpie'

    # Test with XDG env set to something
    os.environ[ENV_XDG_CONFIG_HOME] = '/base/config/dir/xdg/explicit/'
    config_dir2 = get_default_config_dir()
    assert config_dir2 == '/base/config/dir/xdg/explicit/httpie'

    # Test without XDG env set and w/o legacy dir
    # Check that the function returns the expected XD

# Generated at 2022-06-21 13:43:01.645812
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with tempfile.TemporaryDirectory() as temp_dir_name:
        temp_dir = Path(temp_dir_name)
        config = BaseConfigDict(temp_dir)
        config['default_options'] = []

        config.save()
        assert (temp_dir / 'httpie.json').exists()

        with (temp_dir / 'httpie.json').open() as f:
            data = json.load(f)
            assert 'default_options' in data
            assert isinstance(data['default_options'], list)
            assert len(data['default_options']) == 0

# Generated at 2022-06-21 13:43:05.502629
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    path = Path('tmp.json')
    c = BaseConfigDict(path)
    assert c.is_new()
    c.save()
    assert not c.is_new()
    c.delete()


# Generated at 2022-06-21 13:43:13.604120
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    mypath = Path("./a/b/c/d")
    assert BaseConfigDict.ensure_directory(mypath) == OSError
    mypath = Path("./a/b/c/d")
    assert BaseConfigDict.is_new(mypath) == True
    mypath = Path("./a/b/c/d")
    assert BaseConfigDict.load(mypath) == IOError
    mypath = Path("./a/b/c/d")
    assert BaseConfigDict.save(mypath) == IOError
    mypath = Path("./a/b/c/d")
    assert BaseConfigDict.delete(mypath) == OSError


# Generated at 2022-06-21 13:43:20.342819
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    x = ConfigFileError()
    assert str(x) == ''
    y = ConfigFileError('msg')
    assert str(y) == 'msg'
    assert repr(y) == "ConfigFileError('msg',)"
    z = ConfigFileError(oo='oo')
    assert str(z) == ''
    assert repr(z) == "ConfigFileError({'oo': 'oo'},)"

# Generated at 2022-06-21 13:43:27.367246
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_directory = Path("/tmp/configdir")
    if config_directory.exists():
        shutil.rmtree(config_directory)
    config_file = config_directory / Config.FILENAME
    config = Config(directory=config_directory)
    assert(not config_directory.exists())
    config.ensure_directory()
    assert(config_directory.exists())
    shutil.rmtree(config_directory)

# Generated at 2022-06-21 13:43:38.228819
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    """
    Test creation of new files.
    """
    import tempfile
    # Create temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    test_path = Path(temp_dir.name) / 'test'
    assert not test_path.exists()
    # Create config file based on class BaseConfigDict
    test_config = BaseConfigDict(test_path)
    # Call method is_new, should return true
    assert test_config.is_new() == True
    # Create file test_path
    test_path.write_text('')
    # Call method is_new again, should return false
    assert test_config.is_new() == False
    # Cleanup
    temp_dir.cleanup()


# Generated at 2022-06-21 13:43:55.006629
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a directory with 700 permission
    dir_name = 'new_directory'
    directory = Path.home()
    config_dict = BaseConfigDict(directory)
    config_dict.ensure_directory()
    assert os.access(config_dict.path, os.W_OK)

    # Create a directory with 600 permission
    os.umask(0o077)
    config_dict.ensure_directory()
    assert not os.access(config_dict.path, os.W_OK)



# Generated at 2022-06-21 13:44:00.217838
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # The BaseConfigDict.ensure_directory method should create a new
    # configuration directory for the httpie.
    try:
        os.rmdir(DEFAULT_CONFIG_DIR)
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise

    BaseConfigDict.ensure_directory(DEFAULT_CONFIG_DIR)
    assert DEFAULT_CONFIG_DIR.exists()
    assert os.listdir(DEFAULT_CONFIG_DIR) == []



# Generated at 2022-06-21 13:44:07.832172
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    class TestConfigDict(BaseConfigDict):
        name = None
        helpurl = None
        about = None
    
    path = Path('/tmp/httpie/test_1.json')
    test_conf = TestConfigDict(path)
    test_conf.ensure_directory()

    path = Path('test_2.json')
    test_conf = TestConfigDict(path)
    test_conf.ensure_directory()

    path = Path('/tmp/httpie/test_3.json')
    test_conf = TestConfigDict(path)
    test_conf.ensure_directory()

    path = Path('/tmp/httpie/test_4.json')
    test_conf = TestConfigDict(path)
    test_conf.ensure_directory()

# Generated at 2022-06-21 13:44:19.408050
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    Test if BaseConfigDict.save() works and can save a file
    """
    path = Path("./config.json")
    path.parent.mkdir(mode=0o700, parents=True)
    test_dict = BaseConfigDict(path)
    test_dict['test_entry'] = "test_entry"
    test_dict['__meta__'] = {
        'about': 'abc',
        'help': 'abc',
        'httpie': 'abc',
    }
    try:
        test_dict.save()
        assert(Path("./config.json").exists())
    finally:
        os.remove("./config.json")
        os.rmdir("./.httpie")


# Generated at 2022-06-21 13:44:23.587965
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from httpie.config import BaseConfigDict
    d = BaseConfigDict('/tmp/3')
    assert d.path == '/tmp/3'
    d.ensure_directory()
    assert d.helpurl == None
    


# Generated at 2022-06-21 13:44:33.381991
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_dict = {
        'key1': 'value',
        'key2': True,
        'key3': 1,
    }

    config_dir = Path('test')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / 'config.json'

    base_config_dict = BaseConfigDict(path=config_file)
    base_config_dict.update(test_dict)
    base_config_dict.save()

    with config_file.open('rt') as f:
        json_dict = json.load(f)

    assert json_dict == test_dict



# Generated at 2022-06-21 13:44:45.176821
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Setup environment
    env = os.environ.copy()
    if ENV_HTTPIE_CONFIG_DIR in env:
        del env[ENV_HTTPIE_CONFIG_DIR]
    if ENV_XDG_CONFIG_HOME in env:
        del env[ENV_XDG_CONFIG_HOME]

    # Test default
    default_dir = get_default_config_dir()
    if is_windows:
        default_expected = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        default_expected = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert default_dir == default_expected

    # Test HTTPIE_CONFIG_DIR

# Generated at 2022-06-21 13:44:48.375084
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Success case of the method
    base_config_dict = BaseConfigDict(Path('/tmp/subdir/subsubdir/config.json'))
    try:
        base_config_dict.ensure_directory()
    except OSError:
        assert False
    finally:
        shutil.rmtree('/tmp/subdir')


# Generated at 2022-06-21 13:44:49.127018
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    configFileError = ConfigFileError()
    assert configFileError.args == tuple()

# Generated at 2022-06-21 13:44:53.850810
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class FooConfig(BaseConfigDict):
        DIRNAME = 'fooconfigdir'
        FILENAME = 'fooconfig.json'

    foo = FooConfig(path=DEFAULT_CONFIG_DIR / FooConfig.DIRNAME / FooConfig.FILENAME)
    foo.save()

# Generated at 2022-06-21 13:45:24.143608
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_dir = os.environ.get(
        ENV_XDG_CONFIG_HOME,  # 4.1. explicit
        home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
    )
    # The class is initialized with the path of httpie config file.
    # The path of httpie config file is a directory.
    assert type(BaseConfigDict(Path('/tmp'))) is BaseConfigDict
    # The class is initialized with the path of httpie config file.
    # The path of httpie config file is a file.

# Generated at 2022-06-21 13:45:28.751012
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('config_dir')
    config_file = config_dir / 'config.json'
    config_file.write_text('{"foo":"bar"}')
    config = Config(config_dir)
    config.load()
    assert config['foo'] == 'bar'


# Generated at 2022-06-21 13:45:31.594835
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError as e:
        assert str(e) == 'cannot read config file: error'


# Generated at 2022-06-21 13:45:33.275466
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import tempfile
    path = tempfile.mktemp()
    BaseConfigDict(path)

# Generated at 2022-06-21 13:45:35.038695
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    ex1 = ConfigFileError('Message')
    assert ex1.args[0] == 'Message'


# Generated at 2022-06-21 13:45:42.233063
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test_BaseConfigDict_load test the method load of class BaseConfigDict
    basedir = Path(__file__).parent
    test_BaseConfigDict_load_config_path = basedir / 'test_BaseConfigDict_load_config.json'
    with open(basedir / 'test_BaseConfigDict_load_config.json') as f:
        test_BaseConfigDict_load_config_dict = json.load(f)

    test_BaseConfigDict_load_dict = BaseConfigDict(test_BaseConfigDict_load_config_path)
    test_BaseConfigDict_load_dict.load()
    assert test_BaseConfigDict_load_config_dict == test_BaseConfigDict_load_dict

    # test_BaseConfigDict_load_config_path.un

# Generated at 2022-06-21 13:45:50.680754
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class SubBaseConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path=path)

    with tempfile.TemporaryDirectory() as directory:
        config = SubBaseConfigDict(path=Path(directory).joinpath('config.json'))
        assert config.path.as_posix() == os.path.join(directory,"config.json")
        assert config.is_new() == True
        config['default_options'] = []
        config.save()
        config.clear()
        assert config == {}
        config.load()
        assert config.default_options == []

test_BaseConfigDict_load()

# Generated at 2022-06-21 13:45:53.586817
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfe1 = ConfigFileError("Error when openning config file")
    assert cfe1.args[0] == "Error when openning config file"


# Generated at 2022-06-21 13:45:57.243371
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict()
    config = BaseConfigDict(Path.cwd())
    config = BaseConfigDict(Path(__file__).parent)
    config = BaseConfigDict(Path(__file__).parent / 'not_exist')
    assert config.ensure_directory() == None

# Generated at 2022-06-21 13:46:02.542658
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    tmpdir = Path(tempfile.gettempdir())
    file1 = tmpdir / 'testload.json'
    file2 = tmpdir / 'test_load_error.json'

    with file1.open('wt') as f:
        json.dump({'test': "load"}, f)

    with file2.open('wt') as f:
        f.write("{")

    with pytest.raises(ConfigFileError):
        BaseConfigDict(file2).load()

    config = BaseConfigDict(file1)
    config.load()

    assert config == {'test': "load"}

    file1.unlink()
    file2.unlink()



# Generated at 2022-06-21 13:46:52.478658
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:47:03.426377
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    old_httpie_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)

    def get_default_config_dir_base(environ=None):
        if environ is None:
            environ = os.environ.copy()
        os.environ = environ
        return get_default_config_dir()

    # Explicitly set through env.
    assert get_default_config_dir_base({
        ENV_HTTPIE_CONFIG_DIR: '/dir/dir'
    }) == Path('/dir/dir')

    # Windows
    assert get_default_config_dir_base() == DEFAULT_WINDOWS_CONFIG_DIR

    # Legacy.
    #

# Generated at 2022-06-21 13:47:05.218948
# Unit test for constructor of class Config
def test_Config():
    config = Config('~/.httpie')
    assert config.directory == '~/.httpie'


# Generated at 2022-06-21 13:47:15.884283
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_file_path = Path('./config_file_for_testing.json')
    if config_file_path.exists():
        config_file_path.unlink()
    # Case 1: new config file, not exist
    test_dict = BaseConfigDict(config_file_path)
    assert test_dict.is_new()
    # Case 2: not new, already exist
    test_dict.save()
    test_dict = BaseConfigDict(config_file_path)
    assert not test_dict.is_new()
    # Case 3: not new, already exist, but modified file
    test_dict.save()
    assert not test_dict.is_new()
    config_file_path.unlink()
    if DEFAULT_CONFIG_DIR.exists():
        DEFAULT_CONFIG

# Generated at 2022-06-21 13:47:18.617800
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict(path = Path('./confx/config.json'))
    ans = config_dict.path
    assert ans == Path('./confx/config.json')



# Generated at 2022-06-21 13:47:30.229934
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    base_dir = Path(__file__).parent.absolute() / 'dir_for_test'

# Generated at 2022-06-21 13:47:33.812884
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = "/foo/bar/baz/"
    assert not os.path.exists(path)
    config = BaseConfigDict(path)
    config.ensure_directory()
    assert os.path.exists(path)


# Generated at 2022-06-21 13:47:37.394997
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file_path = os.path.join(DEFAULT_CONFIG_DIR, "config.json")
    bcd = BaseConfigDict(Path(file_path))
    bcd.ensure_directory()



# Generated at 2022-06-21 13:47:39.512832
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:47:48.876393
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    tmpdir =  tempfile.TemporaryDirectory()
    dir_name = tmpdir.name
    print(dir_name)
    config_filename = "config.json"
    path = Path(dir_name) / config_filename
    print(path)
    config = {
        '__meta__': {
            'httpie': '2.2.1',
            'help': 'https://httpie.org/docs',
            'about': 'https://github.com/jakubroztocil/httpie'
        }
    }
    config_dict = BaseConfigDict(path)
    config_dict.update(config)
    config_dict.save()
    config_dict.load()
    assert config_dict == config



# Generated at 2022-06-21 13:49:15.184521
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from . import config as config_module

    # No XDG: ~/.httpie
    os.environ.pop(config_module.ENV_XDG_CONFIG_HOME, None)
    d = config_module.get_default_config_dir()
    assert d == Path.home() / config_module.DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    # XDG: $XDG_CONFIG_HOME/httpie
    os.environ[config_module.ENV_XDG_CONFIG_HOME] = '/home/user/config'
    d = config_module.get_default_config_dir()
    assert d == Path('/home/user/config') / config_module.DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:49:16.729392
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    filename = "/tmp/example.json"
    a = BaseConfigDict(filename)
    a.save()

# Generated at 2022-06-21 13:49:22.288943
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Path to config file
    path = Path('./config.json')

    # Content for config file
    content = {
        "content": "example"
    }

    # Instance of BaseConfigDict
    bcd = BaseConfigDict(path=path)
    # Save the data to config file
    bcd.save()

    with open("./config.json", "r") as f:
        data = json.load(f)
        assert bcd.path == path
        assert data["__meta__"]["httpie"] == __version__

if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-21 13:49:31.762041
# Unit test for constructor of class Config
def test_Config():
    print('Result of unit test for constructor of class Config:')
    # Test case 1
    c1 = Config()
    print(c1['__meta__']['httpie'] == __version__)
    for key in c1.DEFAULTS.keys():
        print(key in c1.keys())

    # Test case 2
    c2 = Config(directory='./tests')
    print(c2['__meta__']['httpie'] == __version__)
    path = Path('./tests') / Config.FILENAME
    print(c2.path == path)
    for key in c2.DEFAULTS.keys():
        print(key in c2.keys())



# Generated at 2022-06-21 13:49:39.969477
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temporary_directory = tempfile.TemporaryDirectory()
    temp_config_dict = BaseConfigDict(Path(temporary_directory.name) / 'config.json')
    try:
        # verify that the directory has been successfully created when it did not exist
        base_dict_path = temp_config_dict.path
        assert not os.path.exists(base_dict_path)
        temp_config_dict.ensure_directory()
        assert os.path.exists(base_dict_path)
    finally:
        temporary_directory.cleanup()


# Generated at 2022-06-21 13:49:41.530970
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    myobj = BaseConfigDict('abcd')
    assert myobj.path == 'abcd'

# Generated at 2022-06-21 13:49:42.859777
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = Config()
    config._assert_options_type()


# Generated at 2022-06-21 13:49:45.340926
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert c['__meta__'] == {'httpie': __version__}
    assert c['default_options'] == []


# Generated at 2022-06-21 13:49:46.958069
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError("Test")
    assert str(error) == "Test"