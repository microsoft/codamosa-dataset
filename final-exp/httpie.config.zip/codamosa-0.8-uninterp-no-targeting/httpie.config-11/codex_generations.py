

# Generated at 2022-06-21 13:40:06.243319
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    else:
        home_dir = Path.home()
        legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
        try:
            os.makedirs(legacy_config_dir)
            assert get_default_config_dir() == legacy_config_dir
            os.rmdir(legacy_config_dir)
        except OSError:
            pass

        default_config_dir = Path(home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME)
        assert get_default_config_dir() == default_config_dir

# Generated at 2022-06-21 13:40:12.985484
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_path = Path(".") / "test_BaseConfigDict.json"
    configDict = BaseConfigDict(test_path)
    assert configDict.load() == None
    assert configDict.update("{'x': {'y': 'z'}}") == None
    assert configDict.load() != None
    # test for invalid config file
    configDict.path = Path(".") / "test_BaseConfigDict_invalid.json"
    assert configDict.load() != None
    assert configDict.save(fail_silently = True) == None
    assert configDict.path.unlink() == None
    assert configDict.delete() == None

# Generated at 2022-06-21 13:40:24.061493
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os
    tmpdir = tempfile.mkdtemp(prefix='httpie-test-')
    try:
        os.chmod(tmpdir, 0o100)
        config_dir = os.path.join(tmpdir, 'httpie')
        config_file = os.path.join(config_dir, 'config.json')
        c = Config(config_dir)
        with open(config_file, 'w') as f:
            f.write("{}")
        os.chmod(config_dir, 0o100)
        c.ensure_directory()
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-21 13:40:25.154329
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print(DEFAULT_CONFIG_DIR)
    assert DEFAULT_CONFIG_DIR is not None

# Generated at 2022-06-21 13:40:32.535402
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a Config file
    import io
    test_dir = Path('testdir')
    test_dir.mkdir()
    test_config_file = test_dir / 'config.json'
    test_json_string = io.StringIO('{\n'
                                   '  "__meta__": {\n'
                                   '    "about": "config.json",\n'
                                   '    "httpie": "' + __version__ + '",\n'
                                   '    "help": "https://httpie.org/doc#config"\n'
                                   '  },\n'
                                   '  "default_options": ["--form"]\n'
                                   '}\n')
    test_config_file.write_text(test_json_string.read())
    test_config_object = BaseConfigD

# Generated at 2022-06-21 13:40:33.635787
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    assert Config().is_new()

# Generated at 2022-06-21 13:40:37.264240
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    c = ConfigFileError('This is a ConfigFileError')
    assert c.args[0] == 'This is a ConfigFileError', 'Accepts a string as an argument'

# Generated at 2022-06-21 13:40:38.402877
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    pass


# Generated at 2022-06-21 13:40:49.565596
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    try:
        config_dir = DEFAULT_CONFIG_DIR
        config_dir.mkdir(mode=0o700, parents=True)
    except FileExistsError:
        pass
    
    test_file = config_dir / 'test.json'  # store the test file in default config directory
    test_dir = config_dir / 'test_dir'
    config_dict = BaseConfigDict(path=test_file)
    
    with pytest.raises(OSError):
        config_dict.delete()  # impossible to delete a file that does not exist
    test_file.write_text("{'test': 'This is a test.'}")
    config_dict.delete()  # now we can delete test file
    assert not test_file.exists()
    

# Generated at 2022-06-21 13:40:50.178034
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	pass

# Generated at 2022-06-21 13:40:56.506323
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    temp = Config()
    temp.save
    assert temp.is_new() == False



# Generated at 2022-06-21 13:41:07.986807
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import shutil
    file = "temp_BaseConfigDict.json"
    temp_dir = os.path.dirname(os.path.abspath(file))
    temp_dir_backup = temp_dir + "_backup"
    shutil.copytree(temp_dir, temp_dir_backup)
    
    bcdf = BaseConfigDict(file)
    is_new = bcdf.is_new()
    bcdf.save()
    bcdf.load()
    bcdf.save()
    
    shutil.rmtree(temp_dir)
    shutil.copytree(temp_dir_backup, temp_dir)
    shutil.rmtree(temp_dir_backup)
    
    return is_new


# Generated at 2022-06-21 13:41:17.389569
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def _test(env_config_dir: str, expected_dir: str):
        env = os.environ.copy()
        if env_config_dir:
            env[ENV_HTTPIE_CONFIG_DIR] = env_config_dir

        with mock.patch.dict('os.environ', env, clear=True):
            assert get_default_config_dir() == Path(expected_dir)

    # 1. $HTTPIE_CONFIG_DIR is explicitly set
    _test(
        env_config_dir='a',
        expected_dir='a'
    )

    # 2. Windows
    if is_windows:
        _test(
            env_config_dir=None,
            expected_dir=str(DEFAULT_WINDOWS_CONFIG_DIR)
        )

    # 3. legacy ~/.httpie exists

# Generated at 2022-06-21 13:41:27.730013
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Create a temp directory
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict

    with TemporaryDirectory() as tempdirname:
        # Create an instance of BaseConfigDict
        config_dir = Path(tempdirname)
        config_file = config_dir / 'config.json'
        config = BaseConfigDict(config_file)

        # Create a config file
        config['httpie'] = 'httpie'
        config.save(fail_silently=True)

        # Delete the config file
        config.delete()

        # The config file should not exist
        assert Path(config.path).is_file() == False

        # Delete a file that does not exist
        config.delete()

# Generated at 2022-06-21 13:41:36.594315
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Mock env
    env = {
        ENV_XDG_CONFIG_HOME: Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    }
    os.environ = env

    # 2. XDG
    xdg_config_home_dir = os.environ.get(
        ENV_XDG_CONFIG_HOME,  # 4.1. explicit
        Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME  # 4.2. default
    )
    assert get_default_config_dir() == Path(xdg_config_home_dir) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:41:37.935257
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    exception = ConfigFileError()
    assert exception
    assert str(exception) == ''

# Generated at 2022-06-21 13:41:39.647775
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.load()
    assert config['__meta__'] == {"httpie": __version__}

# Generated at 2022-06-21 13:41:44.752543
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Create a test file
    path = Path('.config') / DEFAULT_CONFIG_DIRNAME / 'config.json'
    fp = open(str(path), 'w+')
    fp.write('{"a": "b"}')
    fp.close()

    # Create a BaseConfigDict object and call its delete method
    config_dic = BaseConfigDict(path)
    config_dic.delete()

    # Check the test file was deleted
    assert not path.exists()

# Generated at 2022-06-21 13:41:56.003879
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().name == 'httpie'

    old_xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    old_httpie_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)


# Generated at 2022-06-21 13:41:59.079305
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('exception message')
    except ConfigFileError as e:
        assert str(e) == 'exception message'
    else:
        assert False, 'No exception was raised'

# Generated at 2022-06-21 13:42:08.318772
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    configs = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    configs.load()
    assert configs

# Generated at 2022-06-21 13:42:14.352237
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '$HOME/my_config_dir'
    assert get_default_config_dir() == Path.home() / 'my_config_dir'

# Generated at 2022-06-21 13:42:19.892824
# Unit test for constructor of class Config
def test_Config():
    print("Main config path of json file is : ", Config().path)
    print("Main config folder path of json file is : ", Config().directory)
    print("Main config default option is : ", Config().default_options)
    assert Config().path == Path(DEFAULT_CONFIG_DIR, 'config.json')



# Generated at 2022-06-21 13:42:22.556898
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    for i in range(5):
        try:
            raise ConfigFileError(i)
            assert False
        except ConfigFileError as e:
            assert e.args[0] == str(i)
            assert isinstance(e.args, tuple)


# Generated at 2022-06-21 13:42:30.173067
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import os
    config_dir = os.getcwd() + "\\httpie"
    if not os.path.isdir(config_dir):
        os.mkdir(config_dir)
    config_file = config_dir + "\\config.json"
    config = Config(config_file)
    config.save()
    config.load()
    assert config.is_new() == False
    config.delete()
    assert config.is_new() == True


# Generated at 2022-06-21 13:42:33.256884
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dict = BaseConfigDict()
    try:
        config_dict.path.unlink()
    except:
        pass
    config_dict.delete()
    assert not config_dict.path.exists()

# Generated at 2022-06-21 13:42:38.128152
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(path='test')
    
    assert config.get('name') == None
    assert config.get('helpurl') == None
    assert config.get('about') == None
    assert config.get('path') == 'test'
    assert isinstance(config, dict)
    

# Generated at 2022-06-21 13:42:43.947150
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_path = "/tmp/" + "httpie/config.json"
    config_dict = BaseConfigDict(config_path)
    if os.path.exists(config_path):
        os.remove(config_path)
    assert config_dict.is_new()
    config_dict.load()
    assert not config_dict.is_new()



# Generated at 2022-06-21 13:42:47.749204
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    a = BaseConfigDict("test.json")
    assert a.name is None
    assert a.helpurl is None
    assert a.about is None
    assert a.path == Path("test.json")


# Generated at 2022-06-21 13:42:49.762051
# Unit test for constructor of class Config
def test_Config():
    cfg = Config()
    print(cfg.directory)
    print(cfg.path)


# Generated at 2022-06-21 13:43:03.543066
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class MockBaseConfigDict(BaseConfigDict):
        is_new = lambda: False
        helpurl = "test"
        about = "test"
    class_instance = MockBaseConfigDict(Path())
    class_instance.save()
    assert class_instance['__meta__'] == {
        'httpie': __version__,
        'help': "test",
        'about': "test"
    }

# Generated at 2022-06-21 13:43:08.263998
# Unit test for constructor of class Config
def test_Config():
    directory = '/Users/zhangquanwei/.config/httpie'
    path = directory + '/' + 'config.json'
    assert get_default_config_dir() == directory
    assert Config.DEFAULTS['default_options'] == []
    assert Config().directory == directory
    assert Config().path == path


# Generated at 2022-06-21 13:43:13.257941
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pytest import raises

    from httpie.config import BaseConfigDict

    config = BaseConfigDict(path='/path/to/file.json')
    config['a'] = {'b': 1, 'c': 2}
    config['__meta__'] = {'httpie': __version__}
    config.helpurl = 'https://httpie.org'

    config.save()
    assert config.path.read_text() == """{
    "a": {
        "b": 1,
        "c": 2
    },
    "__meta__": {
        "about": "https://httpie.org",
        "httpie": "0.9.9"
    }
}
"""


# Generated at 2022-06-21 13:43:15.009301
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == str(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-21 13:43:17.584890
# Unit test for constructor of class Config
def test_Config():
    c = Config(directory=DEFAULT_CONFIG_DIR)
    assert c['default_options'] == []


# Generated at 2022-06-21 13:43:19.977642
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    baseConfigDict = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    return baseConfigDict


# Generated at 2022-06-21 13:43:25.770419
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dict_type = 'Test'
    d = BaseConfigDict(Path('./test_'+dict_type+'.json'))
    d['name'] = 'This is a test'
    d.save()
    assert(d.path.exists())
    d.delete()

if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-21 13:43:29.259155
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(Path('/a/b/c/config.json'))
    assert config.path == Path('/a/b/c/config.json')
# Unit tests for class Config

# Generated at 2022-06-21 13:43:40.310035
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ['HTTPIE_CONFIG_DIR'] = "/tata"
    assert get_default_config_dir() == "/tata"
    
    del os.environ['HTTPIE_CONFIG_DIR']
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    del os.environ['APPDATA']
    assert get_default_config_dir() == Path("/home/toto/.config/httpie")

    os.environ[ENV_XDG_CONFIG_HOME] = "/home/toto/home"
    assert get_default_config_dir() == Path("/home/toto/home/httpie")

    home = Path("/home/httpie")
    home.mkdir(parents=True, exist_ok=True)
    os.environ

# Generated at 2022-06-21 13:43:42.859507
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # Creating config file with the path
    created_path = Path('/home/tests/.config')
    base_config_dict = BaseConfigDict(created_path)

    # Asserting the path is set to the constructor path
    assert base_config_dict.path == created_path


# Generated at 2022-06-21 13:43:57.151831
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError

# Generated at 2022-06-21 13:44:00.333052
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    temp_config = BaseConfigDict(path=Path("temp_config.json"))
    try:
        assert temp_config.is_new()
    finally:
        temp_config.delete()

# Generated at 2022-06-21 13:44:06.675874
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import unittest

    class TestBaseConfigDict(unittest.TestCase):
        def test_load(self):
            import os
            import io
            import tempfile

            contents = """{"key": "value"}"""

            fp = tempfile.NamedTemporaryFile(delete=False)
            fp.write(contents)
            fp.close()

            d = BaseConfigDict(path=fp.name)
            d.load()

            self.assertTrue("key" in d)

            os.unlink(fp.name)

    unittest.main()



# Generated at 2022-06-21 13:44:18.649651
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict

    class UserConfigDict(BaseConfigDict):
        name = None
        helpurl = None
        about = None

    data = {
        'a': 1,
        'b': [2, 3, {
            'd': 0
        }],
        'c': {
            'd': 0
        }
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        filename = tmpdir / 'test.json'
        with filename.open('wt') as f:
            json.dump(data, f)
        user_config = UserConfigDict(filename)
        user_config.load()
        assert user_config == data



# Generated at 2022-06-21 13:44:20.997346
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('This is a ConfigFileError')
    except ConfigFileError as e:
        assert str(e) == 'This is a ConfigFileError'

# Generated at 2022-06-21 13:44:27.598720
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(path='/')
    assert config['__meta__'] == {'httpie': __version__}
    assert config['help'] == 'https://github.com/jkbrzt/httpie'
    assert config['about'] == 'HTTPie %s, a CLI, cURL-like tool for humans' % __version__

# Generated at 2022-06-21 13:44:31.810114
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config(directory='/tmp')
    config.update({'default_options': ['--debug']})

    # save a first time
    config.save()
    # save a second time
    config.save()
    # delete the config file
    config.delete()



# Generated at 2022-06-21 13:44:43.648503
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from os.path import join
    from tempfile import TemporaryDirectory
    from json import JSONDecodeError

    def check_load(expected, content):
        with open(join(tempdir, 'config.json'), 'w') as f:
            f.write(content)
        actual = BaseConfigDict(path=join(tempdir, 'config.json'))
        actual.load()
        assert actual == expected

    # Initialization
    tempdir = TemporaryDirectory()
    invalid_json = '{"this_is_invalid_json": "this will raise JSONDecodeError'

    # Case 1: load no file
    check_load({}, '')
    # Case 2: load file with valid json
    check_load({"a": 1}, '{"a": 1}')
    # Case 3: raise ConfigFileError if read error occur


# Generated at 2022-06-21 13:44:45.126098
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-21 13:44:49.889444
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    #test for class Config
    assert Config(Config.DEFAULT_CONFIG_DIR).load
    #test for class colorscheme
    assert colorscheme.load
    #test for class Shortcut
    assert Shortcut(Shortcut.DEFAULT_CONFIG_DIR).load


if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-21 13:45:33.446006
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():

    class TestConfig(BaseConfigDict):
        pass

    # Test for init
    config_dict = TestConfig(Path('test'))
    assert config_dict.path == Path('test')

    # Test for ensure_directory
    try:
        config_dict.ensure_directory()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    # Test for is_new
    assert config_dict.is_new() == True

    # Test for load
    config_type = type(config_dict).__name__.lower()

# Generated at 2022-06-21 13:45:36.886662
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path_base = os.path.dirname(__file__)
    test_config = BaseConfigDict(Path(path_base) / 'httpie_test')
    test = test_config.load()
    assert(test == {})


# Generated at 2022-06-21 13:45:47.525778
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    # test directory name
    assert config.directory == DEFAULT_CONFIG_DIR
    # test if file name is read only
    with pytest.raises(AttributeError, match=r'.*readonly.*'):
        config.FILENAME = 'test'
    # test if new file was created
    assert config.is_new() == True
    # test if file is json format
    with pytest.raises(ConfigFileError, match=r'.*invalid.*config.*file.*'):
        config.load()
    # save a file and test
    config.save()
    assert config.is_new() == False
    # test filename
    assert config.path.name == config.FILENAME
    # test for a valid json file
    config.load()
    # test for default values

# Generated at 2022-06-21 13:45:54.487985
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    with mock.patch('os.path.exists') as mock_exist:
        mock_exist.return_value = False
        with mock.patch('os.path.dirname') as mock_dirname:
            mock_dirname.return_value = 'test'
            base_config_dict = BaseConfigDict(Path('test'))
            base_config_dict['test'] = 'abc'
            base_config_dict.save()


# Generated at 2022-06-21 13:46:00.890462
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    import json
    import os

    config_dir = os.path.dirname(__file__)
    test_path = Path(config_dir).parent / 'test_dir'
    test_config = BaseConfigDict(test_path)
    test_config['test'] = 'test'
    test_config.save()

    assert test_path.exists()
    with open(str(test_path), 'rt') as f:
        data = json.load(f)
        assert data['test'] == 'test'

    if test_path.exists():
        os.remove(str(test_path))


# Generated at 2022-06-21 13:46:11.876302
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_path = Path(__file__).absolute().parent / './test_config_file'
    config_content = {
        "hello": "world"
    }
    config = BaseConfigDict(path=file_path)
    # In this case, the Config file does not exist
    config.load()
    print(config)
    # Add the valid config content to the config file
    with file_path.open('wt') as f:
        json.dump(config_content, f, sort_keys=True, indent=4, ensure_ascii=True)
    # Now load the config file
    config.load()
    print(config)

if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-21 13:46:18.884225
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    try:
        # Create a folder with an incorrect permission to check that the folder
        # is created with correct permission (0o700)
        os.makedirs('/tmp/BaseConfigDict_save', mode=0o400)
        config = BaseConfigDict(path='/tmp/BaseConfigDict_save/config.json')
        config.save()
        assert os.access('/tmp/BaseConfigDict_save', os.R_OK | os.W_OK)
    finally:
        shutil.rmtree('/tmp/BaseConfigDict_save')



# Generated at 2022-06-21 13:46:30.934676
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class ConfigDict(BaseConfigDict):
        name = 'Config'
        helpurl = 'https://github.com/jakubroztocil/httpie'
        about = 'HTTPie - a CLI, cURL-like tool for humans'
    config = ConfigDict(Path('test.json'))
    config['key'] = 'value'
    config.save()
    with open('test.json', 'r') as f:
        contents = f.read()

# Generated at 2022-06-21 13:46:37.343237
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    config_dir.mkdir(mode=0o700, parents=True)
    config_path = config_dir / Config.FILENAME
    config_path.write_text('{}')
    config = Config()
    assert not config.is_new()
    config_path.unlink()
    config_dir.rmdir()


# Generated at 2022-06-21 13:46:45.295631
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from pathlib import Path
    from httpie.config import ENV_XDG_CONFIG_HOME, ENV_HTTPIE_CONFIG_DIR, DEFAULT_CONFIG_DIRNAME, DEFAULT_RELATIVE_XDG_CONFIG_HOME, get_default_config_dir
    # windows
    assert get_default_config_dir() == Path('E:\\Users\\test\\AppData\\Roaming\\httpie')
    # linux
    assert get_default_config_dir() == Path('/home/test/.config/httpie')
    # test ENV_HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-21 13:47:34.828626
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cf = ConfigFileError()
    assert cf is not None


# Generated at 2022-06-21 13:47:40.768161
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = "tests/config_dir/"
    if not os.path.isdir(config_dir):
        os.makedirs(config_dir)

    filename = os.path.join(config_dir, "config.json")
    BaseConfigDict(path=filename).save(fail_silently=True)
    assert os.path.isfile(filename)


# Generated at 2022-06-21 13:47:42.371207
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert isinstance(ConfigFileError(''), BaseException)


# Generated at 2022-06-21 13:47:44.540595
# Unit test for constructor of class Config
def test_Config():
    print(type(Config()["default_options"]))
    assert type(Config()["default_options"]) == list



# Generated at 2022-06-21 13:47:45.457491
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError is ConfigFileError

# Generated at 2022-06-21 13:47:47.841952
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from httpie.config import BaseConfigDict
    # Just calling the constructor.
    # No error or exception thrown.
    BaseConfigDict('test')



# Generated at 2022-06-21 13:47:51.837233
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('./httpie_test')
    BASE_CD = BaseConfigDict(path)

    # Test for __init__
    assert BASE_CD.path == path



# Generated at 2022-06-21 13:47:56.525879
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    temp_dir = Path(tempfile.mkdtemp())
    config = Config(temp_dir)
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()



# Generated at 2022-06-21 13:48:04.116715
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from httpie.config import DEFAULT_CONFIG_DIR
    from tempfile import TemporaryDirectory
    with TemporaryDirectory(dir=str(DEFAULT_CONFIG_DIR)) as tmpdirname:
        path_to_file = os.path.join(tmpdirname, 'tmpfile')
        with open(path_to_file, 'w'):
            pass
        myfile = BaseConfigDict(Path(path_to_file))
        myfile.delete()
        assert not os.path.isfile(path_to_file)


# Generated at 2022-06-21 13:48:06.171977
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TestConfigDict(BaseConfigDict):
        pass

    config = TestConfigDict(os.devnull)
    assert config.is_new() is True



# Generated at 2022-06-21 13:48:57.296248
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # This function is to ensure the directory exists
    path = DEFAULT_CONFIG_DIR
    if path.exists():
        print('test_BaseConfigDict_ensure_directory method is passed')
        return True
    else:
        print('test_BaseConfigDict_ensure_directory is failed')
        return False



# Generated at 2022-06-21 13:49:07.933552
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import pytest

    class TestConfigDict(BaseConfigDict):
        name = 'test'

        def __init__(self, json_dict):
            self.path = Path('{}.json'.format(self.name))
            self.json_dict = json_dict
            super().__init__(path=self.path)

        def load(self):
            super().load()
            with self.path.open('wt') as f:
                f.write(json.dumps(self.json_dict))


    path = os.path.join(DEFAULT_CONFIG_DIR, 'test.json')
    os.chdir(DEFAULT_CONFIG_DIR)

    with pytest.raises(ConfigFileError):
        config_dict = TestConfigDict({'name': 'httpie'})
        config_

# Generated at 2022-06-21 13:49:17.799401
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # No such file exists
    path = Path("config.json")
    # path = Path("/Users/feimeng/Desktop/httpie_config/config.json")
    print("Creat file {}".format(path))
    # path.write_text("", encoding="utf-8")
    base_config_dict = BaseConfigDict(path)
    print("BaseConfigDict is {}".format(base_config_dict))
    print("BaseConfigDict path is {}".format(base_config_dict.path))
    print("BaseConfigDict __class__ is {}".format(base_config_dict.__class__))
    print("BaseConfigDict parent is {}".format(base_config_dict.__class__.__base__))

# Generated at 2022-06-21 13:49:22.175752
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    tmp_dir = Path('/tmp/httpie_testing')
    tmp_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    config_json = tmp_dir / 'config.json'
    try:
        config_json.write_text('{"a": 1}')
        config = Config(directory=tmp_dir)
    except ConfigFileError as e:
        print(e)
        print('test_BaseConfigDict_load: Load config fail!')
        exit(1)
    config.load()

    if config['a'] != 1:
        print('test_BaseConfigDict_load: Load config fail!')
        exit(1)

    os.remove(config_json)
    os.rmdir(tmp_dir)

# Generated at 2022-06-21 13:49:24.433249
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_file = BaseConfigDict(path='./config.json')
    # todo: add test for valid case



# Generated at 2022-06-21 13:49:30.357190
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class Config(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    config = Config('/tmp/httpie-test')
    config['key'] = 'value'
    assert config['key'] == 'value'
    config.save()
    assert config.path.exists()
    config.delete()
    assert not config.path.exists()

# Generated at 2022-06-21 13:49:31.923494
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_file = BaseConfigDict('/tmp/config.json')
    config_file.delete()



# Generated at 2022-06-21 13:49:39.183349
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    dir_name = "httpie"
    current_path = os.path.abspath(os.path.dirname(__file__))
    test_path = os.path.join(current_path, dir_name)
    config_dict_file = os.path.join(test_path, 'config.json')
    config_dict = BaseConfigDict(config_dict_file)
    assert config_dict.path.exists()


# Generated at 2022-06-21 13:49:50.629676
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from .utils import MockEnvironment
    import io


    with MockEnvironment() as environ:
        # test io error
        environ.fs.CreateFile(
            '/some/config.json',
            contents=io.BytesIO(b'{"a": 1}')
        )
        d = BaseConfigDict(path='/some/config.json')
        d.load()
        assert d == {"a": 1}

        # test json load error
        environ.fs.CreateFile(
            '/some/config.json',
            contents=io.BytesIO(b'invalid json')
        )
        d = BaseConfigDict(path='/some/config.json')
        with pytest.raises(ConfigFileError):
            d.load()

        # test filenotfound error
        d = BaseConfigDict