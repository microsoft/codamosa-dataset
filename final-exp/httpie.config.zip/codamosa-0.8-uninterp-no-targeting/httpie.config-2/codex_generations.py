

# Generated at 2022-06-21 13:39:58.011514
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == DEFAULT_WINDOWS_CONFIG_DIR


# Generated at 2022-06-21 13:40:08.986876
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a config dict at a path that does not exist
    config_dict = BaseConfigDict("/some/nonexistent/path/test_config.json")

    # try to save the config_dict
    failed = False
    try:
        config_dict.save()
    except ConfigFileError as e:
        # assert that the error raised was ENOENT
        assert e.errno == errno.ENOENT
        failed = True
    # assert that the save does indeed fail
    assert failed == True

    # now ensure the directory
    config_dict.ensure_directory()

    # try to save again
    failed = False
    try:
        config_dict.save()
    except ConfigFileError as e:
        failed = True
    # assert that the save does not fail
    assert failed == False

# Generated at 2022-06-21 13:40:13.098380
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    directory = '.test_BaseConfigDict'
    user_config = BaseConfigDict(directory)
    assert user_config.path == Path('.test_BaseConfigDict')
    assert not user_config.is_new()
    assert user_config == {}


# Generated at 2022-06-21 13:40:18.743683
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class ConfigDict(BaseConfigDict):
        name = 'config'
        helpurl = None
        about = None
    config = ConfigDict('/tmp/config')
    config.save()
    assert config.path.exists()
    config.path.unlink()


# Generated at 2022-06-21 13:40:30.373394
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test that get_default_config_dir works correctly.

    - Test that it returns the correct value when HTTPIE_CONFIG is set.
    - Test that it returns something different for Windows, for ease of
      testing (to get ~/.config).
    - Test that it returns the correct path if ~/.httpie exists.
    - Test that it respects XDG_CONFIG_HOME.
    - Test that it returns a reasonable default value if XDG_CONFIG_HOME
      isn't set.
    """
    env = os.environ.copy()
    path = "/some/path"

    # Test that it returns the correct value when HTTPIE_CONFIG is set.
    env['HTTPIE_CONFIG_DIR'] = path
    assert get_default_config_dir() == Path(path)

    # Test that it returns something different for Windows,

# Generated at 2022-06-21 13:40:33.050705
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError('test message')
    assert error.args[0] == 'test message'

# Generated at 2022-06-21 13:40:34.212314
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError


# Generated at 2022-06-21 13:40:46.168818
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    #create a test directory named test_delete
    test_delete_dir = Path('test_delete')
    test_delete_dir.mkdir()

    #create a file in test directory named test_delete.json
    test_file_path = Path('test_delete/test_delete.json')
    test_file_path.touch()

    #create a BaseConfigDict object with path = test_file_path
    obj = BaseConfigDict(test_file_path)

    #check if test_file_path is existing before delete
    assert test_file_path.exists()

    #call method delete of BaseConfigDict
    obj.delete()

    #check if test_file_path is not existing after delete
    assert not test_file_path.exists()

    #remove test directory named test_delete
    test_delete

# Generated at 2022-06-21 13:40:52.595598
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dirpath = Path('/tmp/test_dir')
    if config_dirpath.exists():
        config_dirpath.rmdir()
    config_path = Path('/tmp/test_dir/config.json')
    config_file = BaseConfigDict(config_path)
    config_file.ensure_directory()
    assert config_path.parent.exists()
    config_path.parent.rmdir()



# Generated at 2022-06-21 13:41:04.748895
# Unit test for constructor of class Config
def test_Config():
    # test for default constructor
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == DEFAULT_CONFIG_DIR / 'config.json'

    # test for user-defined directory
    config = Config(directory=DEFAULT_WINDOWS_CONFIG_DIR)
    assert config.directory == DEFAULT_WINDOWS_CONFIG_DIR
    assert config.path == DEFAULT_WINDOWS_CONFIG_DIR / 'config.json'

    # test for user-defined directory which is a string instead of path
    config = Config(directory=str(DEFAULT_WINDOWS_CONFIG_DIR))
    assert config.directory == DEFAULT_WINDOWS_CONFIG_DIR
    assert config.path == DEFAULT_WINDOWS_CONFIG_DIR / 'config.json'

    # test for empty directory

# Generated at 2022-06-21 13:41:09.949570
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path('/etc/httpie/config.json'))
    assert config.is_new()

# Generated at 2022-06-21 13:41:11.397887
# Unit test for constructor of class Config
def test_Config():
    assert Config(directory='data/').default_options == []



# Generated at 2022-06-21 13:41:18.575489
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    directory = DEFAULT_CONFIG_DIR
    if not directory.exists():
        directory.mkdir()
    else:
        # Delete all the files in the directory
        for file in directory.iterdir():
            file.unlink()

    # Test the case when the directory is empty
    config_file = Config(directory)
    assert config_file.is_new() is True

    # Test the case when the directory is not empty
    fake_file = directory / "fake_file"
    fake_file.touch()

    config_file = Config(directory)
    assert config_file.is_new() is False

    # Clean up
    fake_file.unlink()
    directory.rmdir()



# Generated at 2022-06-21 13:41:26.237519
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('/home')
    bcd = BaseConfigDict(path)
    print(bcd['name'])
    print(bcd['helpurl'])
    print(bcd['about'])
    bcd['name'] = 'Hello'
    bcd['helpurl'] = 'http://www.baidu.com'
    bcd['about'] = 'new about'
    print(bcd['name'])
    print(bcd['helpurl'])
    print(bcd['about'])


# Generated at 2022-06-21 13:41:28.671581
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    c = Config(directory='/tmp')
    print(c.is_new())
    c.save()
    print(c.is_new())
    c.delete()

# Generated at 2022-06-21 13:41:29.769461
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass



# Generated at 2022-06-21 13:41:37.723125
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import sys

    # Windows should return DEFAULT_WINDOWS_CONFIG_DIR if not explicitly set
    if is_windows:
        assert get_default_config_dir(
        ) == DEFAULT_WINDOWS_CONFIG_DIR, \
            'Windows return path should equal DEFAULT_WINDOWS_CONFIG_DIR'

    # If set explicitly, HTTPIE_CONFIG_DIR should be returned
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home() / '.foo')
    assert get_default_config_dir() == Path.home() / '.foo', \
        'HTTPIE_CONFIG_DIR should be returned if set in environment'

    # If XDG_CONFIG_HOME is set, and ~/.httpie does not exist, XDG should be returned

# Generated at 2022-06-21 13:41:43.657885
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from pathlib import Path
    from httpie import config
    test_config = config.BaseConfigDict(Path('~/.httpie/test_config.json'))
    assert isinstance(test_config, config.BaseConfigDict)
    assert test_config.name is None
    assert test_config.helpurl is None
    assert test_config.about is None
    assert isinstance(test_config.path, Path)
    assert test_config.path == Path('~/.httpie/test_config.json')


# Generated at 2022-06-21 13:41:48.744446
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    test_config_file = Path("/tmp/test_config.json")
    test_config = BaseConfigDict(test_config_file)
    test_config.save()
    test_config.delete()
    assert not test_config_file.exists()

# Generated at 2022-06-21 13:41:53.659093
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with patch.dict(os.environ, clear=True):
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
        assert get_default_config_dir() == Path('/tmp/httpie')

# Generated at 2022-06-21 13:41:58.086525
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict(Path.cwd()).path == Path.cwd()

# Generated at 2022-06-21 13:42:08.065669
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile

    test_file = tempfile.NamedTemporaryFile(prefix="test_BaseConfigDict_save_", suffix=".json", delete=False)
    test_file.close()

    class Config(BaseConfigDict):
        name = 'test'

    config = Config(test_file.name)
    config.save()

    with open(test_file.name, 'rt') as f:
        content = f.read()

    assert content == '{\n    "__meta__": {\n        "httpie": "0.9.9"\n    }\n}\n'

    os.unlink(test_file.name)

# Generated at 2022-06-21 13:42:12.535877
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    # 2. Windows
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ['OS'] = 'Windows_NT'
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # 3. legacy ~/.httpie
    del os.environ['OS']
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    path = Path.home() / DEFAULT_RELATIVE_

# Generated at 2022-06-21 13:42:19.065150
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    temp_dir = Path(tempfile.mkdtemp())
    assert not (temp_dir / 'test').parent.exists()
    BaseConfigDict(temp_dir / 'test').ensure_directory()
    assert (temp_dir / 'test').parent.exists()
    import shutil
    shutil.rmtree(temp_dir)


# Generated at 2022-06-21 13:42:22.441475
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    print ("#### Running unit test for BaseConfigDict.is_new() ####")
    config_path = BaseConfigDict.DEFAULT_CONFIG_DIR / BaseConfigDict.FILENAME
    if config_path.exists():
        print ("Configuration file available")
    else:
        print ("Configuration file does not exist.")


# Generated at 2022-06-21 13:42:34.357026
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class MockBaseConfigDict(BaseConfigDict):
        pass
    
    #Test on Linux
    if os.path.isdir('/tmp'):
        mock_config_dir = Path('/tmp/mock_dir')
        mock_config_dir.mkdir(mode=0o700, parents=True)
        mock_config = MockBaseConfigDict(mock_config_dir)
        mock_config.ensure_directory()
        mock_config_dir.rmdir()
    
    #Test on Windows
    if os.path.isdir('C:\\'):
        mock_config_dir = Path('C:\\mock_dir')
        mock_config_dir.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-21 13:42:37.348133
# Unit test for constructor of class Config
def test_Config():
    c = Config(DEFAULT_CONFIG_DIR)
    assert isinstance(c, BaseConfigDict)
    assert c.directory == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:42:46.112621
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestDict(BaseConfigDict):
        name = 'test'
        helpurl = 'www.opentech.com'
        about = 'OpenTech'

    value = TestDict(Path('./test.json'))
    value.save()

    assert value.get('__meta__') == {'httpie': __version__, 'help': 'www.opentech.com', 'about': 'OpenTech'}
    assert value.get('default_options', value.DEFAULTS['default_options']) == value.DEFAULTS['default_options']
    value.delete()

# Generated at 2022-06-21 13:42:49.293374
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory =  Path("./test_dir/test2/")
    d = directory.parent.mkdir(mode=0o700, parents=True)
    assert d == True

# Generated at 2022-06-21 13:42:55.841148
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path(__file__))
    # test if the ensure_directory function works with error
    try:
        config.ensure_directory()
        assert False
    except OSError:
        assert True
    # test if the ensure_directory function works normally
    # which means if no error occurs
    try:
        config.ensure_directory()
        assert True
    except OSError:
        assert False


# Generated at 2022-06-21 13:43:10.591999
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # test default parameters
    config_dict = BaseConfigDict(DEFAULT_CONFIG_DIR)
    assert config_dict.path == DEFAULT_CONFIG_DIR
    assert config_dict.name == None
    assert config_dict.helpurl == None
    assert config_dict.about == None
    # test non-default parameters
    test_path = Path("/tmp/non-default-path")
    config_dict = BaseConfigDict(test_path)
    assert config_dict.path == test_path
    assert config_dict.name == None
    assert config_dict.helpurl == None
    assert config_dict.about == None


# Generated at 2022-06-21 13:43:18.074141
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = '/home/mars/.test/test.config'
    os.system(f"rm -rf /home/mars/.test && mkdir -p /home/mars/.test")
    with open(config_path, 'w') as f:
        f.write('invalid value')
    config_dict = BaseConfigDict(path=config_path)
    with pytest.raises(ConfigFileError):
        config_dict.load()



# Generated at 2022-06-21 13:43:22.234368
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    sub_dir = str(DEFAULT_CONFIG_DIR)
    delete_path = sub_dir + '/delete_test.json'
    BaseConfigDict(delete_path).delete()
    assert not Path(delete_path).exists() 


# Generated at 2022-06-21 13:43:23.817391
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert c.default_options == []
    c = Config(directory='/tmp')
    assert c.default_options == []



# Generated at 2022-06-21 13:43:26.192759
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test')
    except ConfigFileError as e:
        assert str(e) == 'test'



# Generated at 2022-06-21 13:43:31.405803
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    conf = BaseConfigDict()
    conf['test'] = "test"
    assert conf['test'] == "test"
    conf.delete()
    try:
        conf["test"]
        # Should not get here
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-21 13:43:33.627951
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dict = BaseConfigDict(path=Path("/tmp/some_file"))
    assert config_dict.delete() is not None


# Generated at 2022-06-21 13:43:43.549593
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():

    data = {
        'key1': 'value1',
        'key2': 'value2'
    }
    my_config_dir = Path('my_config_dir')
    my_config_dir.mkdir(parents=True, exist_ok=True)
    my_config_file = my_config_dir / 'my_config_file.json'
    with my_config_file.open('wt') as f:
        f.write(json.dumps(obj=data,
                           indent=4,
                           sort_keys=True,
                           ensure_ascii=True
                           ))

    base_conf =  BaseConfigDict(path=my_config_file)
    if not base_conf.is_new():
        base_conf.delete()


# Generated at 2022-06-21 13:43:55.880927
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # XDG_CONFIG_HOME is explicitly set
    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / 'xdg_config')
    assert get_default_config_dir() == os.environ[ENV_XDG_CONFIG_HOME] / DEFAULT_CONFIG_DIRNAME

    # $HOME/.config/httpie exists and XDG_CONFIG_HOME is not set
    path_xdg_config = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    path_xdg_config.mkdir()
    assert get_default_config_dir() == path_xdg_config / DEFAULT_CONFIG_DIRNAME

    path_xdg_config.rmdir()

    # $HOME/.httpie exists and XDG_CON

# Generated at 2022-06-21 13:44:02.180467
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('/home/zero/test_base_config.txt')
    baseConfig = BaseConfigDict(path)
    baseConfig.save()
    baseConfig['name'] = 'zero'
    baseConfig.save()
    baseConfig.load()
    print(baseConfig['name'])
    baseConfig.load()
    assert baseConfig['name'] == 'zero'
    print('Test Passed!')


# Generated at 2022-06-21 13:44:20.446915
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('/home/yuan/.httpie')
    config_path = config_dir / 'config.json'
    assert config_path.exists()
    config_dict = BaseConfigDict(config_path)
    config_dict.load()
    print(config_dict.path)
    assert config_dict.get('__meta__')
    assert config_dict.get('default_options')


# Generated at 2022-06-21 13:44:32.558500
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    directory = '/Users/zhuangjingqi/doraemon/httpie/httpie/config'
    filename = 'config.json'
    path = directory + '/' + filename
    file = open("/Users/zhuangjingqi/doraemon/httpie/httpie/config/config.json", "w")
    file.write('''{
        "default_options": []
        }''')
    file.close()

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        return Path(env_config_dir)

    # 2. Windows
    if is_windows:
        return DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3

# Generated at 2022-06-21 13:44:44.400057
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    try:
        import os
        test_dir = os.path.realpath(test_dir)
        test_config_file_path = os.path.join(test_dir, 'config.json')

        with open(test_config_file_path, 'w') as f:
            f.write('{"x":"y"}')

        class TestConfigDict(BaseConfigDict):
            pass

        test_dict = TestConfigDict(test_config_file_path)
        test_dict.load()
        assert 'x' in test_dict
        assert test_dict['x'] == 'y'
    finally:
        shutil.rmtree(test_dir)


# Generated at 2022-06-21 13:44:47.380207
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path(
        "/Users/avadhut/Documents/GitHub/httpie/httpie/config.py"))
    assert not config.is_new()


# Generated at 2022-06-21 13:44:52.600443
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    option_dir = Path(pathlib.Path(__file__).parent, 'option')
    try:
        option_dir.mkdir()
    except FileExistsError:
        pass
    try:
        config_path = option_dir / 'config.json'
        config = Config(option_dir)
        config.ensure_directory()
        assert config_path.exists()
    except FileExistsError:
        pass
    finally:
        shutil.rmtree(option_dir)


# Generated at 2022-06-21 13:44:57.193989
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file_tmp = Path("tmp.json")
    c = BaseConfigDict(path=file_tmp)
    assert c.path == file_tmp
    c.save()
    assert file_tmp.exists()


# Generated at 2022-06-21 13:44:59.814853
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_instance = BaseConfigDict(path="/tmp/test_httpie_config")
    config_instance.save()
    assert config_instance.path.exists()

# Generated at 2022-06-21 13:45:06.164007
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    #Test failed case of json unreadable
    #create empty file
    f = open('empty.json', 'w')
    f.close()
    #try to load the json file
    b = BaseConfigDict('empty.json')
    try:
        b.load()
    except ConfigFileError:
        os.remove('empty.json' )
        print('Test BaseConfigDict_load passed')
        return
    print('Test BaseConfigDict_load failed')


# Generated at 2022-06-21 13:45:13.872566
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = os.path.join(os.getcwd(), ".test_httpie")
    os.makedirs(config_dir,exist_ok=True)
    path = os.path.join(config_dir, "test_config")
    bcd = BaseConfigDict(path)
    bcd["username"] = "test_username"
    bcd.save()
    with open(path,"r") as f:
        data = json.load(f)
    assert data["username"] == "test_username"
    os.remove(path)
    os.rmdir(config_dir)


# Generated at 2022-06-21 13:45:16.134771
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    BAD_PATH = '~/blah_blah_blah'
    assert BaseConfigDict(BAD_PATH)

# Generated at 2022-06-21 13:45:30.236950
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from httpie import cli

    c = cli.BaseConfigDict("/home/sean/.config/httpie/config.json")
    c.save(fail_silently=True)
    c.delete()



# Generated at 2022-06-21 13:45:34.706118
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    temp_dir = Path("ut_temp")
    temp_dir.mkdir()
    test_path = temp_dir / "test_file.json"
    test_dict = BaseConfigDict(test_path)
    test_dict.save()
    test_dict.delete()
    assert not temp_dir.exists()

# Generated at 2022-06-21 13:45:37.021255
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    d = BaseConfigDict(Path('./123'))
    d.ensure_directory()
    assert Path('./123').exists()


# Generated at 2022-06-21 13:45:38.804594
# Unit test for constructor of class Config
def test_Config():
    config = Config('/home/user/.config/httpie')
    assert config.default_options == []


# Generated at 2022-06-21 13:45:41.773846
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir() == Path.home() / Path(
            '.config') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:45:45.303330
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config()

    # Ensure directory exists, as it does on a fresh install
    config.ensure_directory()

    # Ensure directory does exist, as it does on a fresh install
    assert config.directory.exists()

# Generated at 2022-06-21 13:45:46.016255
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass

# Generated at 2022-06-21 13:45:49.211182
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Ensure that directory of the config file is created on init.
    """
    config = BaseConfigDict(Path('.config/httpie/config.json'))
    assert config.path.parent.exists()


# Generated at 2022-06-21 13:45:54.617494
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import tempfile
    import os
    tmp_path = tempfile.mkdtemp()
    x = BaseConfigDict(tmp_path + "/config.json")
    assert(x.path == Path(tmp_path + "/config.json"))
    os.remove(tmp_path + "/config.json")
    os.rmdir(tmp_path)


# Generated at 2022-06-21 13:45:58.398163
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('./test_save.json'))
    config.save()
    with open('./test_save.json') as f:
        json.load(f)
    os.remove('./test_save.json')


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-21 13:46:12.017796
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    bc = BaseConfigDict(Path('/tmp/config.json'))
    bc['a'] = 1
    bc.save(fail_silently=True)
    assert Path('/tmp/config.json').exists()


# Generated at 2022-06-21 13:46:16.573074
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_file = BaseConfigDict(Path('/tmp/httpie/config.json'))
    assert not Path('/tmp/httpie').exists()
    config_file.ensure_directory()
    assert Path('/tmp/httpie').exists()
    os.system('rm -rf /tmp/httpie')


# Generated at 2022-06-21 13:46:23.161575
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie import __version__
    # create a temporary configuration file and set a default option and then save
    temp_path = 'temp.json'
    c = BaseConfigDict(temp_path)
    c.update({'default_options': ['--form'],
              '__meta__': {'httpie': __version__}})
    c.save()
    # check if the contents are correct
    with open(temp_path) as js:
        assert json.load(js) == {'default_options': ['--form'],
                                 '__meta__': {'httpie': __version__}}
    # remove the temporary configuration file
    os.remove(temp_path)


# Generated at 2022-06-21 13:46:32.348365
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    new_config_file = Path("httpie_test") / "httpie" / "config_test.json"
    try:
        new_config_file.parent.mkdir(mode=0o700, parents=True)
    except:
        pass
    new_config = BaseConfigDict(path=new_config_file)
    new_config.ensure_directory()
    assert new_config_file.parent.exists()
    assert new_config_file.parent.is_dir()
    new_config_file.parent.rmdir()


# Generated at 2022-06-21 13:46:42.710575
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    def test_BaseConfigDict_delete_empty_file(tmp_path):
        config_path = tmp_path / "config.json"
        open(config_path, 'a').close()

        c = BaseConfigDict(config_path)
        c.delete()
        assert not config_path.exists()

    def test_BaseConfigDict_delete_file_with_content(tmp_path):
        config_path = tmp_path / "config.json"
        config_path.write_text('{"test": "test"}')

        c = BaseConfigDict(config_path)
        c.delete()
        assert not config_path.exists()

    test_BaseConfigDict_delete_empty_file(Path("/tmp/"))

# Generated at 2022-06-21 13:46:44.700913
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dir = Path('.')
    b = BaseConfigDict(dir)
    b.load()


# Generated at 2022-06-21 13:46:56.181359
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # create a temporary directory
    tmp_dir = os.path.join(os.path.expanduser('~'), 'test-httpie')
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    # create a temporary file, then delete it
    tmp_file = os.path.join(tmp_dir, 'test.json')
    f = open(tmp_file, 'w')
    f.close()
    os.remove(tmp_file)

    # create a temporary configdict
    tmp_configdict = BaseConfigDict(path=tmp_file)

    # check is_new() for temporary configdict
    assert tmp_configdict.is_new() is True

    # clean up
    if os.path.exists(tmp_dir):
        os.removed

# Generated at 2022-06-21 13:47:06.049899
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch('httpie.config.os.environ', {}):
        assert get_default_config_dir() == Path.home() / '.config/httpie'
    os.environ['XDG_CONFIG_HOME'] = 'test'
    with mock.patch('httpie.config.os.environ', {}):
        assert get_default_config_dir() == Path('test') / 'httpie'
    os.environ['HTTPIE_CONFIG_DIR'] = 'test'
    with mock.patch('httpie.config.os.environ', {}):
        assert get_default_config_dir() == Path('test')
    assert DEFAULT_WINDOWS_CONFIG_DIR == Path(
        os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
   

# Generated at 2022-06-21 13:47:08.434701
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("test")
    except ConfigFileError:
        return True
    return False


# Generated at 2022-06-21 13:47:11.438563
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    test_config = BaseConfigDict('config_mock.json')
    assert test_config['default_options'] == None
    print ("test_BaseConfigDict() passed")


# Generated at 2022-06-21 13:47:41.025445
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    dir_path, file_path = mkstemp(suffix='.json')
    try:
        with open(file_path, 'w+') as f:
            f.write("{}")
        config = BaseConfigDict(path=Path(file_path))
        config.delete()
        assert not os.path.exists(file_path)
    finally:
        os.close(dir_path)
        os.remove(file_path)

# Generated at 2022-06-21 13:47:44.270301
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    bcd = BaseConfigDict(path=Path('xx'))
    assert bcd.is_new() == False

if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:47:50.826454
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    f = open('config.json', 'w')
    f.write('{"path": "/"}')
    f.close()
    a = BaseConfigDict(path=Path('config.json'))
    a.load()
    assert(a.get('path') == '/')

    f = open('config.json', 'w')
    f.write('{"path": "/home"}')
    f.close()
    b = BaseConfigDict(path=Path('config.json'))
    b.load()
    assert(b.get('path') == '/home')


# Generated at 2022-06-21 13:47:52.516248
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    test_dir = Path("./test/")
    test_dir.mkdir(parents=True)
    config_dict = BaseConfigDict(test_dir / "config.json")
    return config_dict


# Generated at 2022-06-21 13:47:57.865979
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    config.ensure_directory()
    assert config.is_new() == True, "config.is_new() should be True"
    config.load()
    assert config.is_new() == False, "config.is_new() should be False"
    config.delete()

# Generated at 2022-06-21 13:48:00.700771
# Unit test for constructor of class Config
def test_Config():
    config_path = Config().path
    assert config_path == Path('/home/wu/.config/httpie/config.json')

# Generated at 2022-06-21 13:48:03.320002
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert isinstance(c, dict)
    assert c['default_options'] == c.DEFAULTS['default_options']


# Generated at 2022-06-21 13:48:04.885032
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert type(BaseConfigDict).__name__ == 'BaseConfigDict'


# Generated at 2022-06-21 13:48:16.389317
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Check if it creates the directory if it doesn't exist
    config = BaseConfigDict(path="_test/test_directory/test_file.txt")
    assert not os.path.exists("_test/test_directory/")
    config.ensure_directory()
    assert os.path.exists("_test/test_directory/")
    os.rmdir("_test/test_directory/")

    # Check if it creates the directory and its parents if they don't exist
    config = BaseConfigDict(path="_test/test_directory1/test_directory2/test_file.txt")
    assert not os.path.exists("_test/test_directory1/test_directory2/")
    assert not os.path.exists("_test/test_directory1/")
    config.ensure_directory

# Generated at 2022-06-21 13:48:23.200555
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_directory = 'test_method_ensure_directory'
    test_path = Path.cwd() / test_directory
    if test_path.exists():
        shutil.rmtree(test_path)
    test_obj = BaseConfigDict(test_path)
    test_obj.ensure_directory()
    assert test_path.exists()
    assert test_path.is_dir()
    shutil.rmtree(test_path)


# Generated at 2022-06-21 13:49:13.377087
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    temp_config_dir = tempfile.mkdtemp()
    config = BaseConfigDict(temp_config_dir + '/test.json')
    config.ensure_directory()
    os.rmdir(temp_config_dir)



# Generated at 2022-06-21 13:49:16.654144
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    #Get the temp path.
    path = Path(tempfile.mkdtemp())
    #Write test data to the temp path.
    BaseConfigDict(path).save()

    if not path.exists():
        assert False
    else:
        assert True



# Generated at 2022-06-21 13:49:21.215862
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = None
        about = None
        def __init__(self):
            super().__init__(path=Path("config.json"))
    if not os.path.exists("config.json"):
        test = TestConfigDict()
        test.save()
    test = TestConfigDict()
    test.delete()
    assert test.path.exists() == False

# Generated at 2022-06-21 13:49:23.256965
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    f = BaseConfigDict('/test/test.json')
    print(f.path)



# Generated at 2022-06-21 13:49:33.333699
# Unit test for constructor of class Config
def test_Config():
    # test constructor of class Config
    config = Config('~/.httpie')
    assert config.directory == os.path.expanduser('~/.httpie')
    assert config['default_options'] == []
    assert config.path == os.path.expanduser('~/.httpie/config.json')
    assert config['__meta__']['httpie'] == __version__
    config2 = Config()
    assert config2.directory == Path.home() / '.httpie'
    assert config2.path == Path.home() / '.httpie' / 'config.json'
    assert config2['default_options'] == []
    assert config2['__meta__']['httpie'] == __version__


# Generated at 2022-06-21 13:49:42.502261
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import time

    tmpdir = Path('/tmp/httpie-test_{}'.format(time.strftime("%Y%m%d%H%M%S")))

    d1 = BaseConfigDict(path=tmpdir/'t1')
    d1.ensure_directory()
    print('ensure_directory {}'.format(tmpdir/'t1'))
    assert Path(tmpdir).exists()
    assert Path(tmpdir/'t1').exists()

    d2 = BaseConfigDict(path=tmpdir/'t2/t3/t4')
    d2.ensure_directory()
    print('ensure_directory {}'.format(tmpdir/'t2/t3/t4'))
    assert Path(tmpdir).exists()

# Generated at 2022-06-21 13:49:51.667877
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_file_name = Path('/tmp/config.json')
    with test_file_name.open('wt') as f:
        f.write('{"aaa": "bbb"}')
    test_config_dict = BaseConfigDict(path=test_file_name)
    test_config_dict.load()
    print(f'ConfigDict is {test_config_dict}')
    assert test_config_dict == {'aaa': 'bbb'}
    test_file_name.unlink()


if __name__ == '__main__':
    test_BaseConfigDict_load()