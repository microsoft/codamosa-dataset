

# Generated at 2022-06-21 13:39:55.981469
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path('/test/test.json')
    base_config_dict = BaseConfigDict(path)
    assert base_config_dict.ensure_directory() == None

# Generated at 2022-06-21 13:40:00.558556
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import tempfile
    path = Path(tempfile.gettempdir()) / 'test_BaseConfigDict_is_new'
    base = BaseConfigDict(path=path)
    assert base.is_new() == True
    base.save()
    assert base.is_new() == False
    base.delete()


# Generated at 2022-06-21 13:40:10.038172
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.utils import json_response

    class TestConfigDict(BaseConfigDict):
        pass

    with TemporaryDirectory() as td:
        d = Path(td)
        dp = d / 'config.json'
        dd = TestConfigDict(dp)
        dd['key1'] = 'value1'
        dd.save()
        dd.delete()
        try:
            dp.open()
        except FileNotFoundError:
            pass
        else:
            raise AssertionError('File should be deleted')


if __name__ == '__main__':
    test_BaseConfigDict_delete()

# Generated at 2022-06-21 13:40:13.895417
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('a test error')
    except ConfigFileError as e:
        assert e
        assert str(e) == 'a test error'
    else:
        assert False, 'unreachable'


# Generated at 2022-06-21 13:40:25.717072
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass
    try:
        del os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        pass
    dirname = get_default_config_dir()

    if is_windows:
        assert dirname == Path('C:/Users/user/AppData/Roaming/httpie')

    else:
        assert dirname == Path('/home/user/.config/httpie')


    # set ENV_HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('/home/user/.httpie'))
    dirname = get_default_config_dir()

# Generated at 2022-06-21 13:40:28.084450
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert(ConfigFileError)



# Generated at 2022-06-21 13:40:28.708844
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert True


# Generated at 2022-06-21 13:40:32.031919
# Unit test for constructor of class Config
def test_Config():
    config_dir = Path.cwd()
    config = Config(config_dir)
    assert config.directory == config_dir / "httpie"
    assert config.directory.resolve() == config.path.parent.resolve()
    assert config.path.name == "config.json"
    assert config.default_options == []


# Generated at 2022-06-21 13:40:44.100623
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():

    # Testing creating directory using ensure_directory
    a = BaseConfigDict(Path('/tmp/c/d'))
    a.ensure_directory()

    assert os.path.isdir(Path('/tmp/c/d').parent)

    # Testing that creating a subdirectory works as expected
    b = BaseConfigDict(Path('/tmp/c/d/e'))
    b.ensure_directory()

    assert os.path.isdir(Path('/tmp/c').parent)
    assert os.path.isdir(Path('/tmp/c/d').parent)
    assert os.path.isdir(Path('/tmp/c/d/e').parent)

    # Testing that the function does not raise an exception if directory already exists
    c = BaseConfigDict(Path('/tmp/c/d'))


# Generated at 2022-06-21 13:40:46.123055
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert config.path.exists() == False


# Generated at 2022-06-21 13:40:56.962676
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = config.Config().directory
    config_dir.mkdir()

    config_file = config_dir / 'config.json'
    config_file.write_text('string')
    assert config.Config().is_new() == False

    try:
        config.Config().load()
    except Exception as e:
        assert e.__class__.__name__ == 'ConfigFileError'
        message = 'invalid config file: Expecting property name: line 1 column 1 (char 0) [{}]'.format(config_file)
        assert e.__str__() == message

    config_file.write_text(json.dumps({}))
    config.Config().load()
    assert config.Config().get('default_options') == []
    assert config.Config().get('__meta__') == None


#

# Generated at 2022-06-21 13:41:03.775901
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = os.path.join(DEFAULT_CONFIG_DIR, Config.FILENAME)
    with open(config_path, 'w') as f:
        json.dump({'default_options': ['--debug']}, f)

    baseconfigdict = BaseConfigDict(config_path)
    baseconfigdict.load()
    assert baseconfigdict['default_options'] == ['--debug']

    os.remove(config_path)

# Generated at 2022-06-21 13:41:08.225381
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError()
    except ConfigFileError as e:
        assert str(e) == 'cannot read config file: '
        assert ConfigFileError().__str__() == str(e)
        assert ConfigFileError().__str__() == 'cannot read config file: '



# Generated at 2022-06-21 13:41:15.090416
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfig(BaseConfigDict):
        def __init__(self, directory: str):
            self.directory = Path(directory)
            super().__init__(path=self.directory / 'config.json')

    path = TempPath(change_cwd=True)
    config = TestConfig(directory=path.name)
    config.ensure_directory()
    assert path.joinpath('config.json').resolve().parent.name == '.httpie'
    rmtree(path.joinpath('.httpie'))

# Generated at 2022-06-21 13:41:18.310329
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    conf.load()
    assert isinstance(conf, dict)
    assert isinstance(conf, BaseConfigDict)
    assert conf.default_options == []


# Generated at 2022-06-21 13:41:20.475490
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    r = BaseConfigDict("abc")
    assert r.path == "abc"


# Generated at 2022-06-21 13:41:28.498660
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import io
    import json
    from tempfile import TemporaryDirectory
    from unittest.mock import patch

    class DummyConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(path=None)

    # ensure_directory must create the directory if needed
    with TemporaryDirectory() as tmpdir:
        config = DummyConfig()
        config.path = Path(tmpdir) / 'config.json'
        assert not config.path.parent.exists()
        config.ensure_directory()
        assert config.path.parent.exists()

    # is_new must return True if the file does not exist
    with TemporaryDirectory() as tmpdir:
        config = DummyConfig()
        config.path = Path(tmpdir) / 'config.json'
        assert config.is_new()

# Generated at 2022-06-21 13:41:37.478534
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    from pathlib import Path
    import os
    import shutil
    cur_path = os.path.dirname(os.path.realpath(__file__))
    c_dir = os.path.join(cur_path, "test_dir")
    c_file = os.path.join(cur_path, "test_dir", "config.json")
    if not os.path.exists(c_dir):
        os.makedirs(c_dir)
    else:
        if os.path.exists(c_file):
            os.remove(c_file)
    test_dict = BaseConfigDict(Path(c_file))
    assert test_dict.is_new()
    # create a file to test false case
    with open(c_file, 'w') as f:
        f.write

# Generated at 2022-06-21 13:41:40.963250
# Unit test for constructor of class Config
def test_Config():
    path = "~/http"
    config = Config(path)
    assert config.directory == Path.home() / "http"
    assert config.path == Path.home() / "http" / "config.json"

if __name__ == "__main__":
    test_Config()

# Generated at 2022-06-21 13:41:52.672241
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class MockedBaseConfigDict(BaseConfigDict):
        def ensure_directory(self):
            pass
    
    config = MockedBaseConfigDict(path=Path((os.getcwd() + "/test/test.json")))
    config["hello"] = "world"
    config.save()

    f = open("test/test.json","r")
    if f.mode == 'r':
        contents = f.read()
    assert contents == '{\n    "hello": "world", \n    "__meta__": {\n        "httpie": "2.0.0"\n    }\n}'

    f.close()
    os.remove("test/test.json")

# Generated at 2022-06-21 13:41:57.362710
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    error = ConfigFileError('file not found')
    assert str(error) == 'file not found'

# Generated at 2022-06-21 13:42:06.573838
# Unit test for constructor of class Config
def test_Config():
    d = Config()
    assert d.FILENAME == 'config.json'
    assert d.DEFAULTS == {
        'default_options': []
    }
    assert d.directory == Path(DEFAULT_CONFIG_DIR)
    assert d.path == Path(DEFAULT_CONFIG_DIR) / 'config.json'
    assert isinstance(d, dict)
    assert isinstance(d.default_options, list)
    assert d['__meta__'] == {'httpie': __version__}
    assert d['default_options'] == []


# Generated at 2022-06-21 13:42:09.120443
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    my_config = BaseConfigDict("test.json")
    assert my_config.is_new() == True
    assert my_config.is_new() != False


# Generated at 2022-06-21 13:42:10.388867
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    ConfigFileError("test")


# Generated at 2022-06-21 13:42:21.381876
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # test on case when directory doesn't exist
    bad_test_path = Path('./test/test_directory')

    if bad_test_path.exists():
        shutil.rmtree(bad_test_path)

    config = BaseConfigDict(path=bad_test_path)
    config.ensure_directory()

    assert bad_test_path.exists()
    assert bad_test_path.is_dir()

    # test on case when file with same name as directory exists
    if bad_test_path.exists():
        shutil.rmtree(bad_test_path)

    # create file with same name as directory to test the case
    open(bad_test_path, 'w').close()


# Generated at 2022-06-21 13:42:24.020321
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    x = BaseConfigDict('/path')
    assert x.__dict__ == {'path': Path('/path')}


# Generated at 2022-06-21 13:42:28.459956
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from pathlib import Path
    c = BaseConfigDict(Path('/home/username/httpie/config.json'))
    assert c.path.absolute() == Path('/home/username/httpie/config.json').absolute()


# Generated at 2022-06-21 13:42:38.447695
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    dir_ = get_default_config_dir()
    t = BaseConfigDict(dir_)
    assert type(t) == BaseConfigDict
    print(t)
    try:
        assert not t.is_new()
        t1 = BaseConfigDict('~/.httpie_config/config.json')
        assert t1.is_new()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    t2 = BaseConfigDict('/tmp/ttt')
    print(t2)
    print(type(t2))

if __name__ == '__main__':
    test_BaseConfigDict()

# Generated at 2022-06-21 13:42:42.816879
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    base_config = BaseConfigDict(Path('/tmp/config_test'))
    assert base_config.path.absolute() == Path('/tmp/config_test').absolute()
    assert base_config.is_new(), 'The file should be new'


# Generated at 2022-06-21 13:42:54.249835
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie import env
    import tempfile
    test_env = env.Environment()
    with tempfile.TemporaryDirectory() as d:
        home_dir = Path(d)
        test_env.config_dir = None
        test_env.xdg_config_home = None
        assert get_default_config_dir() == (home_dir / Path('.config') / Path(DEFAULT_CONFIG_DIRNAME))
        test_env.config_dir = 'test'
        assert get_default_config_dir() == Path('test')
        test_env.config_dir = None
        test_env.xdg_config_home = 'test'
        assert get_default_config_dir() == Path('test') / Path(DEFAULT_CONFIG_DIRNAME)

# Generated at 2022-06-21 13:43:04.508583
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path("testconfig.json")
    configdict = BaseConfigDict(path)
    path.unlink(missing_ok=True)  # delete file if it exists
    configdict.ensure_directory()
    assert path.parent.exists()    # test if directory is created
    assert path.parent.is_dir()    # test if directory is created
    path.parent.rmdir()            # delete directory so that it won't cause trouble when unit testing


# Generated at 2022-06-21 13:43:08.753872
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_content = '{"default_options": ["--verbose"]}'
    path = pathlib.Path("./test/config.json")
    path.write_text(config_content)
    config = Config('./test')
    config.load()
    assert config['default_options'] == ['--verbose']

# Generated at 2022-06-21 13:43:12.318048
# Unit test for constructor of class Config
def test_Config():
    config_dir = Path.home()
    config = Config(directory=config_dir)
    print(config)
    print(config_dir)
    print(config['default_options'])
    assert config == {}
    assert config_dir == Path.home()
    assert config['default_options'] == []



# Generated at 2022-06-21 13:43:21.154240
# Unit test for constructor of class Config
def test_Config():
    import httpie.config
    default_config_dir = httpie.config.DEFAULT_CONFIG_DIR
    config_dir        = default_config_dir / 'httpie'

    config = httpie.config.Config('fake_config_dir')
    assert config.directory == Path('fake_config_dir')
    assert config.path == Path('fake_config_dir/config.json')

    config = httpie.config.Config()
    assert config.directory == config_dir
    assert config.path == config_dir / 'config.json'
# End of test



# Generated at 2022-06-21 13:43:33.153976
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows.
    if is_windows:
        assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)
        return

    # Legacy ~.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert str(get_default_config_dir()) == str(legacy_config_dir)
    legacy_config_dir.rmdir()

    # XDG
    os.environ[ENV_XDG_CONFIG_HOME] = str(DEFAULT_RELATIVE_XDG_CONFIG_HOME)

# Generated at 2022-06-21 13:43:37.831179
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    t = BaseConfigDict
    t.name = "BaseConfigDict"
    d = DEFAULT_CONFIG_DIR
    t.__init__(d)
    assert t.is_new()

if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:43:39.939256
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    assert conf['default_options'] == []
    print('[PASS] test of class Config')


# Generated at 2022-06-21 13:43:46.814151
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load(): 
    # Test for a valid config file
    config = BaseConfigDict(Path("./test/fixtures/httpie/config.json"))
    config.load()
    assert config == {'__meta__': {'httpie': '0.9.4'}, 'default_options': []}

    # Test for an empty config file
    config = BaseConfigDict(Path("./test/fixtures/httpie/empty.json"))
    config.load()
    assert config == {}

    # Test for an invalid config file

# Generated at 2022-06-21 13:43:50.117999
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    test_config = Config()
    test_config.load()
    test_config.delete()
    assert test_config.is_new() == True



# Generated at 2022-06-21 13:44:01.249691
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    if ENV_XDG_CONFIG_HOME in os.environ:
        del os.environ[ENV_XDG_CONFIG_HOME]
    home_dir = Path.home()

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/my/config/dir'
    assert get_default_config_dir() == '/my/config/dir'

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()
    assert get_default_config_dir() == legacy_config_dir



# Generated at 2022-06-21 13:44:06.089518
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dir = '~/.httpie'
    path = Path(config_dir)
    BaseConfigDict(path)


# Generated at 2022-06-21 13:44:08.276952
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    BaseConfigDict.delete('test_file.json')
    assert not os.path.exists('test_file.json')

# Generated at 2022-06-21 13:44:20.484372
# Unit test for constructor of class Config
def test_Config():
    # Testing all parameters are correct
    config = Config('/home/user/dir')
    assert config.directory == Path('/home/user/dir')
    assert config.path == Path('/home/user/dir/config.json')
    assert config.DEFAULTS['default_options'] == []

    # Test with a path object
    config = Config(Path('/home/user/dir'))
    assert config.directory == Path('/home/user/dir')
    assert config.path == Path('/home/user/dir/config.json')
    assert config.DEFAULTS['default_options'] == []

    # Test with no input
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == Path(DEFAULT_CONFIG_DIR / Config.FILENAME)

# Generated at 2022-06-21 13:44:23.832973
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    bcd = BaseConfigDict(Path("ssss"))
    try:
        bcd.delete()
    except OSError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 13:44:27.604786
# Unit test for constructor of class Config
def test_Config():
    assert Config().directory == DEFAULT_CONFIG_DIR
    assert Config().path == DEFAULT_CONFIG_DIR/'config.json'
    assert Config().default_options == []


# Generated at 2022-06-21 13:44:32.224526
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    dc = BaseConfigDict()
    dc.path = './test_BaseConfigDict_is_new_path.txt'
    dc.ensure_directory()
    dc.save()
    assert not dc.is_new()
    dc.delete()
    assert dc.is_new()


# Generated at 2022-06-21 13:44:37.150320
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        tmp_dir = os.path.join(tempfile.gettempdir(), "test_httpie")
        config = BaseConfigDict(Path(tmp_dir))
        config.ensure_directory()
    except Exception as e:
        return False
    else:
        return os.path.isdir(tmp_dir)


# Generated at 2022-06-21 13:44:48.586730
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Default: on Linux
    if not is_windows:
        assert DEFAULT_CONFIG_DIR == Path.home() / \
            DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Legacy: ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    httpie_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    httpie_config_dir.mkdir()
    assert get_default_config_dir() == httpie_config_dir
    httpie_config_dir.rmdir()

    # Explicit HTTPIE_CONFIG_DIR env

# Generated at 2022-06-21 13:44:52.472542
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test for Windows
    if os.name == 'nt':
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # Test for non-Windows
    else:
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:44:57.045804
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = "dummy_config.json"
    config = BaseConfigDict(path)
    config.save()
    assert os.path.exists(path)
    config.delete()
    assert not os.path.exists(path)

# Generated at 2022-06-21 13:45:03.643794
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    tmp_file = Path('/tmp/test_BaseConfigDict_load')
    tmp_file.write_text('{"test": true}')
    BaseConfigDict(tmp_file).load()
    tmp_file.unlink()

# Generated at 2022-06-21 13:45:06.423700
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Case: invalid JSON file
    config = BaseConfigDict(path=Path('/tmp/none_existing_file'))
    with pytest.raises(ConfigFileError):
        config.load()


# Generated at 2022-06-21 13:45:13.178660
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def assert_default_config_dir(expected):
        assert get_default_config_dir() == expected

    config_dir = get_default_config_dir()
    assert_default_config_dir(DEFAULT_CONFIG_DIR)

    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'explicit'
    assert_default_config_dir('explicit')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    assert_default_config_dir(DEFAULT_CONFIG_DIR)



# Generated at 2022-06-21 13:45:24.785017
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    print("Test save method of BaseConfigDict")
    # Test with bad file path
    try:
        s = BaseConfigDict("bad/file/path")
        s.save()
    except:
        print("Error: Test with bad file path failed")
    # Test with good file path
    directory = "temp"
    path = directory + "/config.json"
    if not os.path.exists(directory):
        os.makedirs(directory)
    s = BaseConfigDict(path)
    s.save()
    if os.path.exists(path):
        os.remove(path)
        os.rmdir(directory)
    else:
        print("Error: Test with good file path failed")
    print("Test save method of BaseConfigDict finished")


# Generated at 2022-06-21 13:45:26.365789
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        assert True

# Generated at 2022-06-21 13:45:31.328102
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict(path = Path('test.json'))
    assert os.path.exists('test.json') == False
    config.save()
    assert os.path.exists('test.json') == True
    config.delete()
    assert os.path.exists('test.json') == False


# Generated at 2022-06-21 13:45:33.816934
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    BaseConfigDict(Path('./config.json')).ensure_directory()
    assert os.path.exists('./config.json')



# Generated at 2022-06-21 13:45:39.010179
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    x=BaseConfigDict(path="/tmp/base_config_dict")
    assert x.path=="/tmp/base_config_dict"
    x=BaseConfigDict(path="//tmp/base_config_dict")
    assert x.path=='/tmp/base_config_dict'
    x=BaseConfigDict(path="//tmp///base_config_dict")
    assert x.path=='/tmp/base_config_dict'


# Generated at 2022-06-21 13:45:43.992263
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a file at path 'a.json'
    # It will be deleted after the test case executed
    with tempfile.NamedTemporaryFile(mode='w',
                                     suffix='.json',
                                     delete=False) as f:
        f.write(json.dumps(obj={"key_1":"value_1",
                                "key_2":"value_2"}))
        f.close()

    config_instance = BaseConfigDict(f.name)
    config_instance.load()

    # check the config content
    assert config_instance["key_1"] == "value_1"
    assert config_instance["key_2"] == "value_2"

    # delete the temp file
    os.remove(f.name)



# Generated at 2022-06-21 13:45:46.232470
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError("a test config error")
    assert e.args[0] == "a test config error"


# Generated at 2022-06-21 13:46:00.142182
# Unit test for method ensure_directory of class BaseConfigDict

# Generated at 2022-06-21 13:46:03.165529
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_BaseConfigDict = BaseConfigDict(Path('./test_directory/test_file'))
    assert test_BaseConfigDict.is_new()


# Generated at 2022-06-21 13:46:06.387626
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dict = BaseConfigDict(Path('/home/.httpie/config.json'))
    assert config_dict.is_new() == True



# Generated at 2022-06-21 13:46:09.815881
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    this_directory = Path(__file__).parent
    config_path = this_directory / 'config.json'
    config = BaseConfigDict(path=config_path)
    return config


# Generated at 2022-06-21 13:46:18.143629
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    mypath = Path('/path/to/myfile.json')
    config = BaseConfigDict(mypath)
    assert isinstance(config, dict)
    assert config.path == mypath

    # Ensure that the parent directory of the configuration file gets created
    # when you create a new class.
    expected_config_dir = '/path/to'
    actual_config_dir = config.path.parent
    assert expected_config_dir == str(actual_config_dir)
    assert not os.path.exists(expected_config_dir)
    config.ensure_directory()
    assert os.path.exists(expected_config_dir)


# Generated at 2022-06-21 13:46:20.624218
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == (DEFAULT_CONFIG_DIR / Config.FILENAME)
    assert config == Config.DEFAULTS



# Generated at 2022-06-21 13:46:23.025038
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:46:24.668214
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.default_options == []

# Generated at 2022-06-21 13:46:29.135265
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError("test", 3)
    assert repr(e) == "ConfigFileError('test', 3)"
    assert str(e) == "test"
    assert e.args == ("test", 3)


# Generated at 2022-06-21 13:46:33.841050
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_BaseConfigDict_path = Path('./test_BaseConfigDict.json')
    test_BaseConfigDict = BaseConfigDict(test_BaseConfigDict_path)
    assert test_BaseConfigDict.is_new() == True


# Generated at 2022-06-21 13:46:50.041717
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    if __name__ == '__main__':
        bcd = BaseConfigDict(Path.home() / '.httpie' / 'config.json')
        assert bcd.is_new() == False


if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:46:59.349987
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(os.environ, {}):
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    with mock.patch.dict(os.environ, {'XDG_CONFIG_HOME': '/a/b/c'}):
        assert get_default_config_dir() == '/a/b/c' / 'httpie'

    with mock.patch.dict(os.environ, {'HTTPIE_CONFIG_DIR': '/a/b/c'}):
        assert get_default_config_dir() == '/a/b/c'

    if sys.platform != 'win32':
        with mock.patch.dict(os.environ, {}):
            os.path.exists = lambda p: True
            assert get_default_config_

# Generated at 2022-06-21 13:47:02.851191
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    print("BaseConfigDict.delete :")

    try:
        temp_Config = Config()
        temp_Config.delete()
        result = "Success"
    except Exception as e:
        result = "Failed" + str(e)
    print(result)


# Generated at 2022-06-21 13:47:11.040333
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dict = BaseConfigDict("/tmp/config.json")
    dict['a'] = 1
    dict['b'] = 2
    dict.save()
    # json.dumps() ensures that the output is sorted by key, so we can just
    # ensure that the file exists and has the right content to trigger the
    # golden-file check
    assert Path("/tmp/config.json").read_text() == """{
    "__meta__": {
        "httpie": "1.0.3"
    }, 
    "a": 1, 
    "b": 2
}
"""

# Generated at 2022-06-21 13:47:13.412738
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict('/tmp/test_BaseConfigDict_delete')
    config.delete()



# Generated at 2022-06-21 13:47:17.485143
# Unit test for constructor of class Config
def test_Config():
    path = '~/.httpie/config.json'
    #config = Config()

    assert Config().directory == DEFAULT_CONFIG_DIR
    assert Config().FILENAME == 'config.json'
    assert Config(directory='~/.httpie/config.json').directory == path
    assert Config(directory='~/.httpie/config.json').FILENAME == 'config.json'

    assert Config().default_options == []



# Generated at 2022-06-21 13:47:22.816389
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        pass
    test_config = TestConfig('test_config.json')
    test_config["test"] = "test"
    test_config.save()
    s = TestConfig('test_config.json')
    s.load()
    assert s["test"] == "test"


# Generated at 2022-06-21 13:47:24.375636
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert type(config) == Config


# Generated at 2022-06-21 13:47:29.094647
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    configFile = DEFAULT_CONFIG_DIR / 'config.json'
    if configFile.exists():
        config = Config(DEFAULT_CONFIG_DIR)
        config['default_options'] = []
        config.save()
        config.delete()
        assert not configFile.exists()



# Generated at 2022-06-21 13:47:39.624037
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_data = {
        'foo': 1,
        'bar': {
            'baz': 2
        }
    }
    test_json_string = json.dumps(
        obj=test_data,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    test_config = BaseConfigDict(path='test')
    with open('test', 'w') as f:
        f.write(test_json_string + '\n')
    test_config.load()
    assert test_config['foo'] == 1
    assert test_config['bar']['baz'] == 2
    os.remove('test')

# Generated at 2022-06-21 13:48:03.915133
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    assert str(get_default_config_dir()) == 'C:\\Users\\something\\AppData\\Roaming\\httpie'

    # OSX/Linux
    os.environ[ENV_XDG_CONFIG_HOME] = '~/.config/'
    assert str(get_default_config_dir()) == '~/.config/httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '~/.other/'
    assert str(get_default_config_dir()) == '~/.other/httpie'

    assert str(get_default_config_dir()) == '~/.other/httpie'



# Generated at 2022-06-21 13:48:06.307020
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    try:
        login_config_dict = BaseConfigDict(Path('./test'))
        login_config_dict.save()
        assert True
    except:
        assert False



# Generated at 2022-06-21 13:48:18.011072
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dir = '../'
    test_path = 'httpie/tests/test_config.txt'
    config = BaseConfigDict(path=Path(test_path))
    assert type(config) == BaseConfigDict

    # Test is_new()
    assert config.is_new() is True
    config.save()
    assert config.is_new() is False

    # Test load() and save()
    config.load()
    assert config.is_new() is False

    # Test ensure_directory()
    config.ensure_directory()
    assert config.is_new() is False
    config.delete()
    assert config.is_new() is True

    # Test delete()
    config.save()
    assert config.is_new() is False
    config.delete()
    assert config.is_new

# Generated at 2022-06-21 13:48:20.253367
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    test_exception = ConfigFileError('test')
    assert('test' == test_exception.args[0])



# Generated at 2022-06-21 13:48:28.756304
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Config object
    config_file_path = Path("/tmp")
    config_dict = BaseConfigDict(path=config_file_path)    
    config_dict.ensure_directory() # The function ensure_directory should not throw an exception
    config_dict.path = config_file_path / "abc" / "def" # Create a config path that doesn't exist
    # The function ensure_directory should not throw an exception
    config_dict.ensure_directory()
    assert(os.path.exists(config_file_path / "abc" / "def"))

# Generated at 2022-06-21 13:48:34.936010
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import BaseConfigDict, ConfigFileError

    json_file = '''
        {
            "foo": "bar",
            "bar": {
                "foo": "bar"
            }
        }
    '''

    # 1. Path is not a directory
    def test_1():
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / 'config.json'
            with open(config_file, 'wt') as f:
                f.write(json_file)
            config_dict = BaseConfigDict(config_file)
            config_dict.load()
            assert isinstance(config_dict, BaseConfigDict)

# Generated at 2022-06-21 13:48:42.578882
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class TestConfigDict(BaseConfigDict):
        name = "test"
        helpurl = "test.com"
        about = "test test test"

    if not Path.home()/'test/test':
        os.makedirs(Path.home()/'test/test')
    testdict = TestConfigDict(Path.home()/'test/test/test.json')
    testdict.save()
    testdict.load()
    assert testdict['__meta__']['about'] == 'test test test'

# Generated at 2022-06-21 13:48:53.286046
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def disable_mkdir():
        original_mkdir_func = os.mkdir
        def wrapped(*args, **kwargs):
            raise OSError(errno.EEXIST, 'foo')

        os.mkdir = wrapped
        yield
        os.mkdir = original_mkdir_func

    with tempfile.TemporaryDirectory() as tmp:
        os.mkdir(tmp + '/foo')
        path = Path(tmp + '/foo/bar')

        # normal case
        config = BaseConfigDict(path)
        config.ensure_directory()
        assert os.path.exists(str(config.path.parent))
        Path(str(config.path.parent)).rmdir()

        # parent path already exists

# Generated at 2022-06-21 13:48:56.907473
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    testFile = Path('test.json')
    with testFile.open('w', encoding='utf-8') as f:
        json.dump({"test": 1}, f)
    dict = BaseConfigDict(testFile)
    dict.load()
    assert dict.get("test") == 1

# Generated at 2022-06-21 13:48:59.598241
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('./test_dir')
    assert not test_dir.exists()

    config = BaseConfigDict(test_dir)
    config.ensure_directory()

    assert test_dir.parent.exists()
    assert test_dir.parent.is_dir()


# Generated at 2022-06-21 13:49:20.357583
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # 1. A valid config file should be parsed to dict
    path = Path('tests/data/config/config.json').resolve()  # pointing to a valid config file
    target = BaseConfigDict(path)
    target.load()
    expected = {'__meta__': {'httpie': '2.0.0'},
                'default_options': ['--json']
                }
    assert target == expected
    # 2. A non-existent file shouldn't be loaded successfully and raise error
    path = Path('non-existent.json').resolve()  # pointing to a valid config file
    target = BaseConfigDict(path)
    with pytest.raises(ConfigFileError):
        target.load()
    # 3. An invaild json content shouldn't be loaded successfully and raise error

# Generated at 2022-06-21 13:49:22.733725
# Unit test for constructor of class Config
def test_Config():
    dir = "/tmp/httpie"
    assert 'default_options' in  Config(dir).default_options



# Generated at 2022-06-21 13:49:34.268228
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_path = DEFAULT_CONFIG_DIR
    config_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    config_path_copy = DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    config_path_copy.mkdir(mode=0o700, parents=True, exist_ok=True)
    if not (config_path.exists() and config_path_copy.exists()):
        assert False

    config = Config(directory=config_path_copy)
    # Try delete existing file
    config.save()
    if config.is_new():
        assert False

    config.load()
    if config.is_new():
        assert False

    config.delete()
    if not config.is_new():
        assert False

    # Try delete file which

# Generated at 2022-06-21 13:49:41.369427
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    import json
    import tempfile

    # Create an empty file
    fd = tempfile.NamedTemporaryFile(delete=False)
    fname = fd.name
    fd.close()
    d = BaseConfigDict(
        path=Path(fname))
    d['a'] = '1'

    with Path(fname).open('rt') as f:
        data = json.load(f)

    assert data == {'a': '1'}
    d.delete()
    assert not Path(fname).exists()



# Generated at 2022-06-21 13:49:52.590492
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    from tempfile import TemporaryDirectory
    from os import environ

    home_dir = Path.home()

    # 1. explicitly set through env
    with TemporaryDirectory(prefix='httpie') as tmpdir:
        environ[ENV_HTTPIE_CONFIG_DIR] = tmpdir
        assert get_default_config_dir() == Path(tmpdir)

    # 2. Windows

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    with TemporaryDirectory(prefix='httpie') as tmpdir:
        if legacy_config_dir.exists():
            old_config_dir = legacy_config_dir.rename