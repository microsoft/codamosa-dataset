

# Generated at 2022-06-21 13:40:08.385744
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(
        os.path.expanduser('~/.config/httpie'))

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == Path(
        os.path.expanduser('~/.config/httpie'))

    os.environ.update({ENV_XDG_CONFIG_HOME: '/tmp/config'})
    assert get_default_config_dir() == Path('/tmp/config/httpie')

    os.environ.update({ENV_XDG_CONFIG_HOME: '/tmp/config/'})

# Generated at 2022-06-21 13:40:13.535676
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dir = Path(tempfile.mkdtemp())
    assert not (dir / 't1').exists()
    t1 = BaseConfigDict(dir / 't1')
    t1.ensure_directory()
    assert (dir / 't1').exists()
    assert (dir / 't1').is_dir()

# Generated at 2022-06-21 13:40:15.851040
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('invalid config file')
    except ConfigFileError as e:
        print(e)

# Generated at 2022-06-21 13:40:23.972553
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfig(BaseConfigDict):
        def __init__(self, path=Path.cwd() / 'tmp.json'):
            super().__init__(path)

    config = TestConfig()
    config['a'] = 'b'
    config.save()
    assert config.path.is_file() is True
    with config.path.open('r') as f:
        content = json.load(f)
    assert content['a'] == 'b'
    config.delete()

# Generated at 2022-06-21 13:40:27.550889
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Unit test that tests whether method delete from class BaseConfigDict deletes the file.

    Returns:
       None
    """
    class Config(BaseConfigDict):
        name = None
        helpurl = None
        about = None

        def __init__(self):
            super().__init__(Path('test.json'))
            self.path.touch()

    config = Config()
    config.delete()
    assert not Path('test.json').exists()



# Generated at 2022-06-21 13:40:29.290650
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config['default_options'] == []
    assert config.default_options == []



# Generated at 2022-06-21 13:40:32.793846
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == DEFAULT_CONFIG_DIR / 'config.json'



# Generated at 2022-06-21 13:40:37.840675
# Unit test for constructor of class Config
def test_Config():
    assert Config().directory == Path.cwd() / DEFAULT_CONFIG_DIR
    assert Config('/tmp').directory == '/tmp'
    assert Config(Path('/tmp')).directory == '/tmp'
    assert Config(directory=Path('/tmp')).directory == '/tmp'



# Generated at 2022-06-21 13:40:43.385724
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from contextlib import contextmanager
    @contextmanager
    def make_env(**kwargs):
        _environ = os.environ.copy()
        os.environ.update(kwargs)
        try:
            yield
        finally:
            os.environ.clear()
            os.environ.update(_environ)

    def path_exists(*args):
        return Path.home() / Path(*args).expanduser().relative_to(Path.home())

    with make_env():
        default_xdg = DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
        assert get_default_config_dir() == path_exists(default_xdg)

    with make_env(XDG_CONFIG_HOME='/foo/bar'):
        default_

# Generated at 2022-06-21 13:40:47.716004
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    This test creates a temporary file, then calls the delete method on that file.
    It then checks that the file has been deleted successfully.
    """
    # Make a temporary file to test delete on
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    test_config_dict = BaseConfigDict(path=temp_file.name)
    # Delete the temporary file
    test_config_dict.delete()
    # Check that the file is deleted
    assert(not Path(temp_file.name).exists())


# Generated at 2022-06-21 13:40:59.559627
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    default_config_dir = get_default_config_dir()
    default_config_path = default_config_dir / Config.FILENAME

    # Change permissions, so that we can test the fail_silently argument
    os.chmod(default_config_dir, mode=0o000)
    config = Config(directory=default_config_dir)
    config['default_options'] = ['--form']
    config.save(fail_silently=True)
    # Restore permissions
    os.chmod(default_config_dir, mode=0o700)



# Generated at 2022-06-21 13:41:04.093595
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.name == 'nt':
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path(os.environ['HOME']) / '.config' / 'httpie'


# Generated at 2022-06-21 13:41:07.295563
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    test_path = Path("./httpie/test")
    test_baseconfigdict = BaseConfigDict(test_path)
    assert test_baseconfigdict.path == test_path


# Generated at 2022-06-21 13:41:09.246438
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict('home')
    assert config_dict['name'] == None


# Generated at 2022-06-21 13:41:10.242637
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-21 13:41:16.654138
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import io
    import json
    f = io.StringIO()
    config_dict = {
        'hello': 'world',
        '__meta__': {
            'httpie': __version__
        }
    }
    config = BaseConfigDict(f)
    config.update(config_dict)
    config.save()
    f.seek(0)
    assert f.read() == json.dumps(config_dict, indent=4, sort_keys=True, ensure_ascii=True) + '\n'

# Generated at 2022-06-21 13:41:18.613266
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    x = BaseConfigDict('/tmp/config.json')
    assert x.delete() is None



# Generated at 2022-06-21 13:41:22.466955
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    test_config = BaseConfigDict(Path('test.json'))
    Path('test.json').touch()
    assert test_config.is_new() == False
    Path('test.json').unlink()


# Generated at 2022-06-21 13:41:26.506672
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    actual = '{"__meta__": {"httpie": "1.0.2"}}\n'
    d = BaseConfigDict('test.txt')
    d.ensure_directory()
    d.save()
    assert d.path.read_text() == actual


# Generated at 2022-06-21 13:41:27.624879
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()

# Generated at 2022-06-21 13:41:33.027662
# Unit test for constructor of class Config
def test_Config():
    assert isinstance(Config(), Config)
    assert isinstance(Config('.'), Config)
    assert not isinstance(Config(1), Config)


# Generated at 2022-06-21 13:41:37.808295
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().is_absolute()
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir().is_absolute()
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir().is_absolute()
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-21 13:41:40.965151
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().name == DEFAULT_CONFIG_DIRNAME
    assert not get_default_config_dir().exists()
    assert not get_default_config_dir().parent.exists()

    assert get_default_config_dir().parent.name == '.config'
    assert not get_default_config_dir().parent.parent.exists()
    assert get_default_config_dir().parent.parent.name == 'home'



# Generated at 2022-06-21 13:41:47.343274
# Unit test for constructor of class Config
def test_Config():
    # Config() should not raise an exception
    Config()
    # Config() should create a default config directory
    assert os.path.isdir(DEFAULT_CONFIG_DIR)
    # No exception should be raised if the config directory is specified explicitly
    Config(directory='/tmp')


# Generated at 2022-06-21 13:41:49.359920
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    c = BaseConfigDict(Path("/tmp/delete.json"))
    c.delete()

# Generated at 2022-06-21 13:41:51.331355
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-21 13:41:52.543226
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    c = BaseConfigDict('path')
    assert c.is_new() == True


# Generated at 2022-06-21 13:41:55.065544
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:42:05.630966
# Unit test for constructor of class Config
def test_Config():
    # test for constructor with positional arguments,
    # checking for the actual type of Config.directory
    # and Config.path
    config = Config('./test')
    if not (isinstance(config.directory, Path)):
        raise AssertionError('directory must be Path')
    if not (isinstance(config.path, Path)):
        raise AssertionError('config.path must be Path')
    if config.directory.name != 'test':
        raise AssertionError('directory name must be "test"')
    if config.path.name != 'config.json':
        raise AssertionError('path name must be "config.json"')



# Generated at 2022-06-21 13:42:07.588409
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError()
    assert(str(e) == '')


# Generated at 2022-06-21 13:42:18.490674
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_path = "/tmp/test/config.json"
    try:
        os.remove(config_path)
    except:
        pass
    config = BaseConfigDict(config_path)
    config.ensure_directory()
    config.path.parent.rmdir()


# Generated at 2022-06-21 13:42:21.416090
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfgFileName = "config.json"
    path = Path("~/httpie/" + cfgFileName)
    cfgFileError = ConfigFileError("config.json")
    # assert cfgFileError.path == path


# Generated at 2022-06-21 13:42:29.689732
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_path = '~/con.json'
    try:
        os.remove(config_path)
    except:
        pass
    
    a = BaseConfigDict(Path(config_path))
    is_new = a.is_new()
    assert type(is_new) == bool
    assert is_new == True
    a.save(fail_silently=True)
    is_new = a.is_new()
    assert is_new == False
    a.delete()

# Generated at 2022-06-21 13:42:40.871010
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class DerivedConfigDict(BaseConfigDict):
        def __init__(self):
            super().__init__(
                path=DEFAULT_CONFIG_DIR / 'test' / 'test.json'
            )

    dcd = DerivedConfigDict()
    dcd.ensure_directory()
    assert (DEFAULT_CONFIG_DIR / 'test').is_dir()
    assert (DEFAULT_CONFIG_DIR / 'test').is_dir()
    assert not (DEFAULT_CONFIG_DIR / 'test').is_file()
    assert not (DEFAULT_CONFIG_DIR / 'test' / 'test.json').is_dir()
    assert not (DEFAULT_CONFIG_DIR / 'test' / 'test.json').is_file()

# Generated at 2022-06-21 13:42:48.965756
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert Path.home() / '.config/httpie' == get_default_config_dir()

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
    assert '/foo/bar/httpie' == str(get_default_config_dir())

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/baz'
    assert '/foo/baz' == str(get_default_config_dir())

# Generated at 2022-06-21 13:42:52.658280
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cf1 = ConfigFileError()
    cf2 = ConfigFileError('Some message')
    assert(cf1.args == tuple())
    assert(cf2.args == ('Some message',))



# Generated at 2022-06-21 13:43:00.169107
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create temp directory
    dir_path = Path(__file__).parent / "temp_dir"
    dir_path.mkdir()

    # Create class an instance of BaseConfigDict
    config = BaseConfigDict(dir_path / "test_BaseConfigDict_ensure_directory")

    # Ensure directory doesn't exist
    assert not (dir_path / "test_BaseConfigDict_ensure_directory").exists()

    # Call method ensure_directory
    config.ensure_directory()

    # Ensure directory was created
    assert (dir_path / "test_BaseConfigDict_ensure_directory").exists()

    # Remove directory
    dir_path.rmdir()



# Generated at 2022-06-21 13:43:05.554866
# Unit test for constructor of class Config
def test_Config():
    config_dir = Path('/tmp/config')
    config = Config(directory=config_dir)
    assert config.directory == Path('/tmp/config')
    # Default options in Config
    assert config.default_options == []
    assert config.get('default_options') is not None
    assert config.get('default_options') == []



# Generated at 2022-06-21 13:43:07.406759
# Unit test for constructor of class Config
def test_Config():
    cfg = Config()
    assert cfg['default_options'] == []

test_Config()


# Generated at 2022-06-21 13:43:11.567762
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    test_path = 'test.txt'
    with open(test_path, 'a', encoding='utf8') as f:
        f.write('test')
    test_obj = BaseConfigDict(path=Path(test_path))
    test_obj.delete()
    assert not Path(test_path).exists()


# Generated at 2022-06-21 13:43:23.840551
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = BaseConfigDict('~/.httpie/config.json')
    assert(config.delete()) == 0

# Generated at 2022-06-21 13:43:34.447570
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class TestConfigDict(BaseConfigDict):
        name = 'test_config.json'

    class TestBaseConfigDict(TestCase):

        def test_delete(self):
            with TemporaryDirectory() as directory:
                config_dir = Path(directory)
                config_path = config_dir / TestConfigDict.name
                config = TestConfigDict(config_path)
                config.save()
                self.assertTrue(config_path.exists())
                config.delete()
                self.assertFalse(config_path.exists())

    tbcd = TestBaseConfigDict()
    tbcd.test_delete()


# Generated at 2022-06-21 13:43:37.023881
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    mock_path = Path("/tmp")
    obj = BaseConfigDict(mock_path)

    assert obj.is_new() == True

# Generated at 2022-06-21 13:43:39.985909
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError()
    except ConfigFileError as e:
        assert str(e) == 'ConfigFileError'
        # Note: no error raised due to assert statement


# Generated at 2022-06-21 13:43:42.456466
# Unit test for constructor of class Config

# Generated at 2022-06-21 13:43:48.746180
# Unit test for constructor of class Config
def test_Config():
    config = Config('/some/directory')
    assert config.directory == Path('/some/directory')
    assert config.path == Path('/some/directory/config.json')
    assert config.DEFAULTS == {
        'default_options': []
    }
    assert config.FILENAME == 'config.json'



# Generated at 2022-06-21 13:43:53.384568
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    s = '{"a": 1}'
    class C(BaseConfigDict):
        pass
    c = C(path=Path("/tmp"))
    c.path.write_text(s)
    c.load()
    assert c.path.read_text() == s



# Generated at 2022-06-21 13:43:57.108557
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    expected_config_dir = Path.home() / '.config/httpie'
    config = Config()
    assert config.path == expected_config_dir / 'config.json'
    assert config.directory == expected_config_dir
    assert config.is_new() == True


# Generated at 2022-06-21 13:43:58.921457
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    d = BaseConfigDict(path='.tst')
    assert d.is_new() == True


# Generated at 2022-06-21 13:44:07.277024
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = 'test/testfile'
    # To avoid the situation of test file exist 
    if os.path.exists(path) == True:
        os.remove(path)
    with open(path,"w") as f:
        f.write('{}')
    baseConfigDict = BaseConfigDict(path)
    baseConfigDict.load()
    assert baseConfigDict == {}, 'The output should be {}'
    # To avoid the situation of test file exist 
    if os.path.exists(path) == True:
        os.remove(path)
    with open(path,"w") as f:
        f.write('{"__meta__":{"httpie":"2.0.1"}}')
    baseConfigDict = BaseConfigDict(path)
    baseConfigDict.load()
   

# Generated at 2022-06-21 13:44:28.976244
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:44:39.081145
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class OptConfigDict(BaseConfigDict):
        pass
    # Call constructor
    # 1. path is a str
    opt_config_dict = OptConfigDict(path="/httpie/config.json")
    assert(str, type(opt_config_dict.path))
    # 2. path is a Path
    opt_config_dict = OptConfigDict(path=Path("/httpie/config.json"))
    assert(Path, type(opt_config_dict.path))
    # 3. path is a Path
    opt_config_dict = OptConfigDict(path=Path("/httpie/config.json"))
    assert(Path, type(opt_config_dict.path))



# Generated at 2022-06-21 13:44:41.622253
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    basedict = BaseConfigDict(Path(__file__))
    assert basedict.path.name == 'test_config.py'


# Generated at 2022-06-21 13:44:50.817587
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from . import env
    env.set('HTTPIE_CONFIG_DIR', '')
    env.unset('XDG_CONFIG_HOME')
    assert DEFAULT_CONFIG_DIR == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    env.set('HTTPIE_CONFIG_DIR', '/tmp/config')
    assert DEFAULT_CONFIG_DIR == Path('/tmp/config')

    env.unset('HTTPIE_CONFIG_DIR')
    env.set('XDG_CONFIG_HOME', '/xdg/config')
    assert DEFAULT_CONFIG_DIR == Path('/xdg/config') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:44:52.052800
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    print(c.default_options)



# Generated at 2022-06-21 13:45:03.939388
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert(get_default_config_dir() == DEFAULT_CONFIG_DIR)

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/.httpie'
    assert(get_default_config_dir() == Path('/test/.httpie'))

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg_config_home'
    expected = Path('/xdg_config_home') / DEFAULT_CONFIG_DIRNAME
    assert(get_default_config_dir() == expected)


# Generated at 2022-06-21 13:45:08.732363
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert isinstance(config, Config)
    assert config.path == Path.home() / '.config' / 'httpie' / 'config.json'
    assert config == {'default_options': []}
    assert config.directory == Path.home() / '.config' / 'httpie'
    assert config.default_options == []


# Generated at 2022-06-21 13:45:13.649169
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    Home = Path.home()
    configdir = Path(
        Home,
        '.config',
        'httpie'
    )
    default_cookie_file = Path(
        configdir,
        'cookies.json'
    )
    cookie_file = BaseConfigDict(default_cookie_file)
    cookie_file.delete()
    assert not default_cookie_file.exists()

# Generated at 2022-06-21 13:45:20.074862
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path('/test')
    Path(config_dir).mkdir(mode=0o700, parents=True)
    path = config_dir / 'test.json'
    Path(path).touch()
    testDict = BaseConfigDict(path)
    assert testDict.path.exists() == True
    testDict.delete()
    assert testDict.path.exists() == False


# Generated at 2022-06-21 13:45:28.751410
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmp_dir = Path('/tmp/httpie')
    tmp_dir.mkdir(exist_ok=True)
    path = tmp_dir / 'config.json'
    baseConfigDict = BaseConfigDict(path)
    baseConfigDict.save()

    assert path.exists(), '配置文件未创建'
    assert path.read_text().endswith('\n'), '配置文件未添加换行'



# Generated at 2022-06-21 13:45:54.735995
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class ConfigDict(BaseConfigDict):
        name = 'config_dict'
    config_dict = ConfigDict(path=DEFAULT_CONFIG_DIR / 'test_config.json')
    config_dict.ensure_directory()
    assert DEFAULT_CONFIG_DIR / ConfigDict.name == DEFAULT_CONFIG_DIR / 'httpie'


# Generated at 2022-06-21 13:45:56.642764
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # BaseConfigDict constructor with argument
    BaseConfigDict(path=Path('D:\Program Files\Python3\httpie'))


# Generated at 2022-06-21 13:46:02.712974
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_name = "test_config.json"
    data = [
        {"a": 100, "b": 200},
        {"a": "abcd", "b": "efg"},
        {"a": [1, 2, 3], "b": [2, 3, 4]},
    ]
    for i in data:
        json_string = json.dumps(obj=i, indent=4, sort_keys=True, ensure_ascii=True)
        with open(file_name, 'w') as f:
            f.write(json_string)
            f.close()

        test_base_config_dict = BaseConfigDict(Path(file_name))
        test_base_config_dict.load()
        if i == test_base_config_dict:
            print("Pass")

# Generated at 2022-06-21 13:46:07.296863
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError as e:
        assert str(e) == ''
    try:
        raise ConfigFileError('error message')
    except ConfigFileError as e:
        assert str(e) == 'error message'


# Generated at 2022-06-21 13:46:10.685945
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class test_base(BaseConfigDict):
        pass
    try:
        test_base('test').load()
    except ConfigFileError as e:
        print(e)


# Generated at 2022-06-21 13:46:18.575420
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    settings = BaseConfigDict(Path("test.json"))
    try:
        settings.load()
    except ConfigFileError:
        assert True
    else:
        assert False

    with open("test.json", "w") as f:
        f.write("")
    try:
        settings.load()
    except ConfigFileError:
        assert True
    else:
        assert False

    with open("test.json", "w") as f:
        f.write("{}")
    try:
        settings.load()
    except ConfigFileError:
        assert False
    else:
        assert True


# Generated at 2022-06-21 13:46:20.896948
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    configFileErrorObject = ConfigFileError('something is wrong')
    if configFileErrorObject.__str__() != 'something is wrong':
        raise AssertionError

# Generated at 2022-06-21 13:46:24.213822
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    err = ConfigFileError()
    assert err, err
    assert 'invalid' in err, err
    assert 'cannot read' in err, err


# Generated at 2022-06-21 13:46:30.003674
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(Path('/test_save/test.json'))
    config_dict['test'] = 0
    config_dict.save()
    config_dict = BaseConfigDict(Path('/test_save/test.json'))
    assert config_dict['test'] == 0



# Generated at 2022-06-21 13:46:39.977770
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    #initialization
    new_config_dir=Path('test/test_config')
    new_config_file=new_config_dir/'config.json'
    new_config=Config(directory=new_config_dir)

    #test if the directory exists or not
    if new_config_dir.exists():
        new_config_dir.rmdir()
    if new_config_file.exists():
        new_config_file.unlink()

    new_config.ensure_directory()

    #call ensure_directory method
    assert new_config_dir.exists()

    #remove created directories
    new_config_dir.rmdir()



# Generated at 2022-06-21 13:47:34.768599
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from .utils import strip_ansi

    _path = tempfile.mktemp(suffix='.json')
    _path = Path(_path)
    _data = {
        'hello': 'world'
    }

    class MyConfigDict(BaseConfigDict):
        name = ''
        helpurl = None
        about = None

    myconfig = MyConfigDict(path=_path)
    myconfig.load()
    myconfig.update(_data)
    myconfig.save()

    # import json
    # with _path.open('rt') as f:
    #     obj = json.load(f)
    #     print(obj)

    with _path.open('rt') as f:
        content = strip_ansi(f.read())

# Generated at 2022-06-21 13:47:38.882388
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert BaseConfigDict
    assert BaseConfigDict.__name__ == 'BaseConfigDict'
    assert BaseConfigDict.__init__
    assert BaseConfigDict.__init__.__name__ == '__init__'


# Generated at 2022-06-21 13:47:48.798955
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    default_config_dir = get_default_config_dir()

    try:
        # <http://legacy.python.org/dev/peps/pep-0373/>
        os.mkdir(str(default_config_dir), mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    assert default_config_dir.exists()
    assert default_config_dir.is_dir()
    assert default_config_dir.stat().st_mode == 33152

    default_config_dir.rmdir()

# Generated at 2022-06-21 13:47:50.459304
# Unit test for constructor of class Config
def test_Config():
    local_cfg = Config()
    assert local_cfg is not None



# Generated at 2022-06-21 13:47:58.674039
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TempConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    tmp_path = Path("./test.test.test")
    assert not tmp_path.exists()
    tmp_config = TempConfig(tmp_path)
    assert not tmp_path.exists()
    tmp_config.ensure_directory()
    assert tmp_path.exists()
    tmp_path.unlink()



# Generated at 2022-06-21 13:48:07.548322
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    b1 = BaseConfigDict('test_BaseConfigDict')
    b1['test_a'] = 'test'
    b1['test_b'] = 'test'
    print(b1.path)
    assert b1.path == 'test_BaseConfigDict'
    assert b1.is_new() == True
    assert b1['test_a'] == 'test'
    assert b1['test_b'] == 'test'
    b1['test_c'] = 'test'
    assert b1['test_c'] == 'test'

    b1.load()
    assert b1.path == 'test_BaseConfigDict'
    assert b1.is_new() == True
    assert b1['test_a'] == 'test'
    assert b1['test_b'] == 'test'
   

# Generated at 2022-06-21 13:48:08.914091
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = BaseConfigDict(Path(''))
    assert config.is_new()

# Generated at 2022-06-21 13:48:16.197131
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    myDir = Path('/home/qawebuser/Documents/Pycharm/httpie-1.0.3/tests/test_examples')
    if myDir.exists():
        print(myDir.exists())
        base = BaseConfigDict(myDir)
        #print(base)
        base.load()
        #print(base)
        base['http'] = 'https'
        base.save()
        base.delete()


# Generated at 2022-06-21 13:48:19.179212
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert str(ConfigFileError()) == 'ConfigFileError'
    assert str(ConfigFileError(1)) == 'ConfigFileError'
    assert str(ConfigFileError('2')) == 'ConfigFileError'

# Generated at 2022-06-21 13:48:21.961233
# Unit test for constructor of class Config
def test_Config():
    a = Config().directory
    if a == DEFAULT_CONFIG_DIR:
        print('Success')
    else:
        print('Fail')
