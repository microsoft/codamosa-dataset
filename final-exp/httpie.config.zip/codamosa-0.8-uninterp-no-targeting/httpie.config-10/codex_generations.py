

# Generated at 2022-06-21 13:39:59.708761
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from os.path import dirname, abspath
    from time import time

    class TestDict(BaseConfigDict):
        about = 'test'
        helpurl = 'test_help'

    test_path = Path(dirname(abspath(__file__))) / Path('test_file')
    test_dict = TestDict(test_path)

    test_dict.save()
    test_dict['test'] = str(time())
    test_dict.save()


# Generated at 2022-06-21 13:40:03.723604
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    err1 = ConfigFileError('error1')
    err2 = ConfigFileError('error2')
    assert err1.__str__() == 'error1'
    assert err2.__str__() == 'error2'



# Generated at 2022-06-21 13:40:12.551487
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    if is_windows:
        assert get_default_config_dir().__str__() == Config(get_default_config_dir()).__str__()

    # Linux / Mac
    else:
        home_dir = Path.home().__str__()
        # Check if default config path exists and is not empty
        if get_default_config_dir().__str__():
            assert get_default_config_dir().__str__() == Config(get_default_config_dir()).__str__()
        # Check if environment variable HTTPIE_CONFIG_DIR is set and not empty
        if os.environ.get(ENV_HTTPIE_CONFIG_DIR):
            assert os.environ.get(ENV_HTTPIE_CONFIG_DIR) == get_default_config_dir()
        # Check if

# Generated at 2022-06-21 13:40:22.143724
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    class ConfigDict(BaseConfigDict):
        FILENAME = 'config.json'
        DEFAULTS = {
            'default_options': []
        }

        def __init__(self, directory: Union[str, Path] = DEFAULT_CONFIG_DIR):
            self.directory = Path(directory)
            super().__init__(path=self.directory / self.FILENAME)
            self.update(self.DEFAULTS)

    config = ConfigDict()
    print(config.path)
    config.delete()


# Generated at 2022-06-21 13:40:30.641484
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('/test/config.json'))
    config.ensure_directory = lambda: True
    with patch('builtins.open', mock_open(read_data='{"a": "b"}')) as mock_file:
        config.save()
        mock_file.assert_called_once_with('/test/config.json', 'wt')
        handle = mock_file()
        handle.write.assert_called_once_with('{\n    "__meta__": {\n        "httpie": "0.3.0"\n    }\n}\n')

# Generated at 2022-06-21 13:40:41.632842
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Define a temp file and create it
    file = tempfile.TemporaryDirectory()
    data = {"username": "user", "password": "pass"}
    # Create the object and save it
    c = BaseConfigDict(Path(file.name))
    c.update(data)
    c.save()
    # Read the file and parse it
    with Path(file.name + "/" + "config.json").open('rt') as f:
        try:
            json_data = json.load(f)
        except ValueError as e:
            print(e)
    # Test if the data is the same
    assert data == json_data

# Generated at 2022-06-21 13:40:45.895999
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Delete a real file
    config = Config(directory='../config')
    config.save()
    config.delete()
    assert not config.path.exists()
    # Delete a non existing file
    config = Config(directory='../config_error')
    config.delete()

# Generated at 2022-06-21 13:40:52.348851
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test that the save method of the inherited class Config write to config.json file
    import pytest
    c = Config('.')
    c.save()
    f = open('./config.json', 'r+')
    l = f.readline()
    assert l == '{"__meta__": {"httpie": "0.9.9.1"}, "default_options": []}'
    f.close()
    os.remove('./config.json')


# Generated at 2022-06-21 13:40:59.873432
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR, \
        'this test case should use a non-existing config directory'
    assert config.FILENAME == 'config.json', 'fatal error in test code'
    assert config.DEFAULTS == {'default_options': []}, \
        'fatal error in test code'
    assert config.default_options == [], 'fatal error in test code'
    assert not config.is_new(), 'fatal error in test code'



# Generated at 2022-06-21 13:41:04.041423
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = Path('.') / 'test_config.json'
    config = BaseConfigDict(path)
    config['foo'] = 'bar'
    config.save()
    config.delete()
    assert not path.exists()

# Generated at 2022-06-21 13:41:08.386741
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    pass

# Generated at 2022-06-21 13:41:11.850944
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test = BaseConfigDict(Path('./test_files/mock_config.json'))
    test.save()
    assert(Path.exists(Path('./test_files/mock_config.json')))

# Generated at 2022-06-21 13:41:23.530154
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    """
    Since there is no way to create a directory, then it is not possible to
    create a file. Then you can only test the exception.
    """
    import socket
    from errno import ENOENT
    from io import StringIO
    from unittest.mock import patch
    from httpie.config import BaseConfigDict

    class MockBaseConfigDict(BaseConfigDict):
        def __init__(self):
            self.path = StringIO()

    with patch('httpie.config.os') as m_os, patch('httpie.config.os.unlink'):
        m_os.unlink.side_effect = OSError(errno.ENOENT, os.strerror(ENOENT))
        MockBaseConfigDict().delete()

# Generated at 2022-06-21 13:41:33.956483
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil

    try:
        tempdir = tempfile.mkdtemp()
        path = Path(tempdir, 'non-existing/dir/config.json')

        config = BaseConfigDict(path)

        # Created mode is masked by umask
        config.ensure_directory()

        assert path.parent.exists() == True
        assert path.parent.is_dir() == True
        assert path.parent.is_file() == False

        path.parent.chmod(0o000)
        config.ensure_directory()

        assert path.parent.exists() == True
        assert path.parent.is_dir() == True
        assert path.parent.is_file() == False
    finally:
        shutil.rmtree(tempdir)


# Generated at 2022-06-21 13:41:41.302392
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_name= 'httpie'
    home_dir = Path.home()
    test_path =  home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / config_name
    config = BaseConfigDict(test_path)
    assert config.path == test_path, 'Wrong path'
    assert config.helpurl is None, 'Wrong helpurl value'
    assert config.about is None, 'Wrong about value'
    assert config.name == 'httpie', 'Wrong name'
    assert config.is_new() == False, 'Wrong return value'
    

# Generated at 2022-06-21 13:41:50.958754
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_file='test_config.json'
    config_data=r'{"__meta__": {"httpie": "0.9.6"}}'
    test_config_file_path=Path(config_file)
    test_config_file_path.write_text(config_data)
    temp_cls=type('temp_cls',(BaseConfigDict,),{'path': Path(config_file)})
    temp_cls.delete(temp_cls)
    assert not test_config_file_path.exists()


# Generated at 2022-06-21 13:41:57.952055
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # saving the test file
    config = Config()
    config.save()
    
    # initialize the class
    class TestClass(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)
        
    testClass = TestClass(config.path)
    if testClass.is_new() == False:
        # loading the test file
        testClass.load()
        assert testClass.path == config.path
        assert testClass['__meta__'] == config['__meta__']
    else:
        raise Exception("The test file is not saved!")

# Generated at 2022-06-21 13:41:58.976241
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-21 13:42:11.046761
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test case 1 - make it testable
    my_env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    home_dir = os.path.expanduser("~")
    tmp_dir = os.path.join(home_dir, "httpie_test_tmp.httpie")
    test_file = tmp_dir + '/test_config.json'
    temp_path = Path(test_file)
    if temp_path.parent.exists():
        shutil.rmtree(temp_path.parent, ignore_errors = True)
    temp_path.parent.mkdir(mode=0o700, parents=True)

    # Test case 1

# Generated at 2022-06-21 13:42:12.871796
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-21 13:42:16.202829
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    assert BaseConfigDict("").is_new() == False


# Generated at 2022-06-21 13:42:24.737136
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import tempfile
    tmpdir = Path(tempfile.mkdtemp())
    home_dir = tmpdir / 'home'
    home_dir.mkdir()

    xdg_config_dir = tmpdir / 'xdg-config'
    xdg_config_dir.mkdir()

    httpie_dir = tmpdir / DEFAULT_CONFIG_DIRNAME
    httpie_dir.mkdir()
    httpie_dir = httpie_dir.resolve()

    httpie_dir2 = tmpdir / DEFAULT_CONFIG_DIRNAME
    httpie_dir2.mkdir()
    httpie_dir2 = httpie_dir2.resolve()

    os.environ['HOME'] = str(home_dir)

    # 1. explicitly set through env

# Generated at 2022-06-21 13:42:26.635998
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    assert BaseConfigDict.delete(self) == None


# Generated at 2022-06-21 13:42:31.995212
# Unit test for constructor of class Config
def test_Config():
    cwd = os.getcwd()
    configdir = os.path.join(cwd, 'httpie')
    config = Config(directory = Path(configdir))
    assert config.directory == Path(configdir)
    assert config.path == Path(os.path.join(configdir, 'config.json'))


# Generated at 2022-06-21 13:42:37.140964
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    d = BaseConfigDict('/tmp')
    d.ensure_directory()
    d.path.parent.rmdir()
    d.path.parent.rmdir()
    # /tmp doesn't exist, so it's bound to fail
    try:
        d.ensure_directory()
    except OSError:
        pass



# Generated at 2022-06-21 13:42:45.858405
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = Config()
    config.load()
    print(config.items())
    
test_BaseConfigDict()

# The following to be implemented in the future.
#
# class Authorization(BaseConfigDict):
#     FILENAME = 'auth.json'
# 
# 
# class Netrc(BaseConfigDict):
#     FILENAME = '.netrc'
# 
# 
# class Environment(BaseConfigDict):
#     FILENAME = '.env'
# 
# 
# class Form(BaseConfigDict):
#     FILENAME = 'form.json'

# Generated at 2022-06-21 13:42:50.224899
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path("/home/test")
    obj = BaseConfigDict(path)
    assert obj.path.as_posix() == path.as_posix()
    assert 'path' in obj
    assert obj['path'] == path


# Generated at 2022-06-21 13:42:54.818179
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_path = Path('/tmp/test_httpie_config_file')
    if config_path.exists():
        config_path.unlink()
    config = Config()
    assert config.is_new()
    config.save()
    assert not config.is_new()
    config_path.unlink()

# Generated at 2022-06-21 13:42:57.156475
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class Foo(BaseConfigDict):
        pass
    config = Foo(Path('/config.json'))
    assert config['/config.json'].is_new()


# Generated at 2022-06-21 13:43:07.010408
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import json
    import os
    import shutil
    import tempfile

    assert not BaseConfigDict(
        path=Path(os.environ.get('HOME'), '.httpie')).is_new()

    temp_dir = tempfile.mkdtemp()
    path = Path(temp_dir, 'test_BaseConfigDict_is_new.json')
    assert BaseConfigDict(path=path).is_new()
    with path.open('w') as f:
        json.dump({}, f)
    assert not BaseConfigDict(path=path).is_new()
    shutil.rmtree(temp_dir)



# Generated at 2022-06-21 13:43:17.920533
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''

    if is_windows:
        assert get_default_config_dir() == Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        return

    home_dir = Path.home()
    assert get_default_config_dir() == home_dir / '.config' / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-21 13:43:24.226784
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    dir = Path(os.path.abspath('testdata'))
    config = Config(directory=dir)
    assert(config.is_new())
    config.save()
    assert(not config.is_new())

    log = Log(directory=dir)
    assert(not log.is_new())

    hist = History(directory=dir)
    assert(hist.is_new())


c = Config()

# Generated at 2022-06-21 13:43:30.287449
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    configdir = Path('/tmp')
    config = BaseConfigDict(configdir)
    print(type(config))
    print(config)
    config['test'] = ''
    print(config)

    assert config.path.exists() is False
    config.save()
    assert config.path.exists() is True

    config.delete()
    assert config.path.exists() is False


# Generated at 2022-06-21 13:43:41.329546
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config_dict = BaseConfigDict(Path('test.json'))
    assert test_config_dict['__meta__'] is None
    test_config_dict['__meta__'] = 'test'
    test_config_dict['default_options'] = 'test'
    test_config_dict.save()
    test_config_dict.update({})
    assert test_config_dict['default_options'] is None
    test_config_dict.load()
    assert test_config_dict['__meta__'] == 'test'
    assert test_config_dict['default_options'] == 'test'
    test_config_dict.update({})
    assert test_config_dict['__meta__'] is None
    assert test_config_dict['default_options'] is None
    test_config_dict.load()
   

# Generated at 2022-06-21 13:43:50.638088
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path_test= 'test/test_config_deletion'
    if os.path.isdir(path_test):
        shutil.rmtree(path_test)
    os.mkdir(path_test)
    test_file = os.path.join(path_test,'config.json')
    myconf = BaseConfigDict(path_test)
    myconf.ensure_directory()
    myconf.delete()
    if os.path.isfile(test_file):
        raise Exception("File not deleted")
    shutil.rmtree(path_test)


# Generated at 2022-06-21 13:43:53.584975
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    dict = BaseConfigDict(Path('./test'))
    assert dict.is_new() is True

test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:43:55.453770
# Unit test for constructor of class Config
def test_Config():
    assert type(Config('./sftp://httpbin.org/')) == Config



# Generated at 2022-06-21 13:43:56.806271
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config['default_options'] == []

# Generated at 2022-06-21 13:44:05.619353
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    json_dict = BaseConfigDict(Path('./test.json'))
    json_dict['test_string'] = 'test'
    json_dict['test_int'] = 1
    json_dict['test_dict'] = {'a':1, 'b':2}
    json_dict.save()
    with open('./test.json', 'r') as file:
        json_data = json.load(file)
    assert json_data['test_string'] == 'test'
    assert json_data['test_int'] == 1
    assert json_data['test_dict']['a'] == 1

if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-21 13:44:13.715522
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    import tempfile
    import os
    tmp = tempfile.mkdtemp()
    try:
        fpath = os.path.join(tmp, 'test_BaseConfigDict_save.json')
        data = {'foo': 'bar'}
        d = BaseConfigDict(fpath)
        d.update(data)
        d.save()
    finally:
        os.unlink(fpath)
        os.rmdir(tmp)

# Generated at 2022-06-21 13:44:32.278968
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '../'
    assert get_default_config_dir() == '../'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/'
    assert get_default_config_dir() == '/tmp/'

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    assert get_default_config_dir() != '/tmp/'

    #

# Generated at 2022-06-21 13:44:42.791626
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config/httpie'
    
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/home/path'
    assert get_default_config_dir() == Path('/some/home/path')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/xdg/config/home'
    assert get_default_config_dir() == Path('/some/xdg/config/home/httpie')
    del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-21 13:44:47.141564
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert DEFAULT_CONFIG_DIR.is_dir()
    config = Config()
    config.ensure_directory()
    assert config.path.parent.is_dir()
    config.path.parent.rmdir()
    assert not config.path.parent.exists()


# Generated at 2022-06-21 13:44:51.459564
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_config')
    config_dir.mkdir()
    config_dir /= 'config.json'
    config = BaseConfigDict(path=config_dir)
    config.ensure_directory()
    assert Path.exists(config_dir.parent)
    config_dir.parent.rmdir()


# Generated at 2022-06-21 13:44:52.619904
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert base_config_dict.ConfigFileError("test")

# Generated at 2022-06-21 13:44:57.185145
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import tempfile
    t = tempfile.TemporaryDirectory()
    a = BaseConfigDict(Path(t.name) / 'config.json')
    a.save()
    a.delete()
    assert not a.path.exists()

# Generated at 2022-06-21 13:44:59.277933
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    my_dict = BaseConfigDict(Path('/tmp/config.json'))
    assert my_dict.is_new() == True

# Generated at 2022-06-21 13:45:01.624283
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    d = Path('E:/param.json')
    k = BaseConfigDict(d)
    print(k.path)

# Generated at 2022-06-21 13:45:11.587356
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    save_env_xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    save_env_httpie_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)

# Generated at 2022-06-21 13:45:13.760457
# Unit test for constructor of class Config
def test_Config():
    DEFAULT_CONFIG = Config()
    assert DEFAULT_CONFIG.directory == get_default_config_dir()
    assert DEFAULT_CONFIG['default_options'] == []



# Generated at 2022-06-21 13:45:23.157311
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    os.remove(str(Config().directory / Config.FILENAME))
    Config().delete() # not raise



# Generated at 2022-06-21 13:45:31.278771
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dir = os.path.dirname(__file__)

    assert ConfigFileError
    assert BaseConfigDict.name is None
    assert BaseConfigDict.helpurl is None
    assert BaseConfigDict.about is None

    assert BaseConfigDict(config_dir)
    assert BaseConfigDict(config_dir)['__meta__'] is None
    assert BaseConfigDict(config_dir).load()
    assert BaseConfigDict(config_dir).save()
    assert BaseConfigDict(config_dir).delete()




# Generated at 2022-06-21 13:45:40.033913
# Unit test for function get_default_config_dir

# Generated at 2022-06-21 13:45:43.697948
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    test_path = Path("test_path")
    x = BaseConfigDict(test_path)
    assert(x.path == test_path)


# Generated at 2022-06-21 13:45:45.479198
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError
    except ConfigFileError:
        return True
    assert False


# Generated at 2022-06-21 13:45:53.722520
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    if os.path.exists('test_BaseConfigDict_is_new'):
        os.remove('test_BaseConfigDict_is_new')
    config = BaseConfigDict("test_BaseConfigDict_is_new")
    assert config.is_new() == True

    with open("test_BaseConfigDict_is_new", "w") as f:
        f.write("")

    assert config.is_new() == False

    os.remove("test_BaseConfigDict_is_new")


# Generated at 2022-06-21 13:45:59.454291
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a json file to simulate the configuration
    path = "./test"
    # test whether the file exist, but it won't exist
    assert not isfile(path)
    # create a BaseConfigDict instance
    cfg = BaseConfigDict(Path(path))
    # create the json file
    cfg.save()
    # test whether the file exist, but it will exist
    assert isfile(path)
    # test the method load
    cfg.load()
    # remove the file
    remove(path)


# Generated at 2022-06-21 13:46:11.502695
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    xdg_config_dir = '/tmp/html'
    os.environ[ENV_XDG_CONFIG_HOME] = xdg_config_dir
    assert get_default_config_dir() == Path(xdg_config_dir) / DEFAULT_CONFIG_DIRNAME

    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    config_dir = '/tmp/httpie-config'
    os.environ

# Generated at 2022-06-21 13:46:15.310747
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dict = BaseConfigDict('test.txt')
    assert config_dict.is_new() == True

    config_dict1 = BaseConfigDict('../httpie/config.json')
    assert config_dict1.is_new() == False



# Generated at 2022-06-21 13:46:23.087968
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def setup():
        tmp_dir = 'test_httpie_config'
        os.mkdir(tmp_dir)
        os.chdir(tmp_dir)
        return tmp_dir

    def cleanup(tmp_dir):
        os.chdir('..')
        shutil.rmtree(tmp_dir)

    tmp_dir = setup()

# Generated at 2022-06-21 13:46:41.570628
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    b = BaseConfigDict(Path('config.json'))
    b.delete()
    assert not b.path.exists()
    with open('config.json', 'w+') as f:
        f.write('asd')
    b = BaseConfigDict(Path('config.json'))
    b.delete()
    assert not b.path.exists()
    os.remove('config.json')


# Generated at 2022-06-21 13:46:50.642425
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path=path)
    size = 1024
    data = {}
    for i in range(1, size + 1):
        data[str(i)] = str(i)
    path = Path('./test.txt')
    if path.exists():
        path.unlink()
    with path.open('wt') as f:
        json.dump(data, f)
    config = TestConfigDict(path)
    config.load()
    assert config == data


# Generated at 2022-06-21 13:46:58.162772
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    assert get_default_config_dir() == get_default_config_dir()

    import os
    os.environ[ENV_XDG_CONFIG_HOME] = '/opt/config'
    assert get_default_config_dir() == Path('/opt/config/httpie')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/opt/config/httpie'
    assert get_default_config_dir() == Path('/opt/config/httpie')


# Generated at 2022-06-21 13:47:02.806742
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory = 'test_config_dir'
    path = directory + '/test.json'
    if not os.path.exists(directory):
        os.mkdir(directory)
    config = BaseConfigDict(path)
    config.ensure_directory()
    assert os.path.exists(directory)
    assert os.path.isdir(directory)

# Generated at 2022-06-21 13:47:13.508219
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import pytest
    # Create a temporary folder
    testdir = Path('./testdir')
    try:
        testdir.mkdir()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    # Create a temporary file
    testfile = testdir / 'testfile.txt'

    class TestConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(path=testfile)
        def load(self):
            super().load()

    # Try to load from a non-exist file
    test_file = TestConfig()
    with pytest.raises(ConfigFileError):
        test_file.load()

    # Create a new file and test if it is a valid json file

# Generated at 2022-06-21 13:47:22.859304
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class MyConfig(BaseConfigDict):
        pass

    # Create a sample directory
    import tempfile
    sample_dir = tempfile.TemporaryDirectory()

    # Initialise a config dict
    config_dict = MyConfig(Path(sample_dir.name) / 'my_config.json')

    # Check that the file does not exist
    assert config_dict.is_new() == True

    # Ensure the directory exists
    config_dict.ensure_directory()

    # Check that the file does not exist
    assert config_dict.is_new() == True

    # Write default data and check that the file does exist
    config_dict.save(True)
    assert config_dict.is_new() == False

    # Remove the sample directory safely
    sample_dir.cleanup()



# Generated at 2022-06-21 13:47:27.341737
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    type_of_BaseConfigDict = type(BaseConfigDict)
    print(type_of_BaseConfigDict)
    print(type_of_BaseConfigDict.__name__)
    print(type_of_BaseConfigDict.__doc__)


# Generated at 2022-06-21 13:47:29.961846
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
	config = BaseConfigDict('/home/ubuntu/Desktop/CONFIG.json')
	assert config.path == '/home/ubuntu/Desktop/CONFIG.json'
	

# Generated at 2022-06-21 13:47:38.314916
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Given
    directory = './path/to/config/dir'
    config_file_name = 'config.json'
    path = f'{directory}/{config_file_name}'
    config_json = BaseConfigDict(Path(path))

    # When
    mk_dir_result = config_json.ensure_directory()
    is_new_result = config_json.is_new()
    config_json.delete()

    # Then
    assert mk_dir_result == None
    assert is_new_result == True
    # clean up

# Generated at 2022-06-21 13:47:41.534536
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('this is a test')
    except ConfigFileError as e:
        assert str(e) == 'this is a test'



# Generated at 2022-06-21 13:48:28.249515
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
	assert type(ConfigFileError()) is ConfigFileError

# Generated at 2022-06-21 13:48:34.710821
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_xdg_config_home = os.getenv(ENV_XDG_CONFIG_HOME)
    old_httpie_config_dir = os.getenv(ENV_HTTPIE_CONFIG_DIR)


# Generated at 2022-06-21 13:48:36.901351
# Unit test for constructor of class Config
def test_Config():
    try:
        test_config = Config()
    except:
        raise

# Generated at 2022-06-21 13:48:39.464577
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(DEFAULT_CONFIG_DIR)
    assert config.path == DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:48:41.109348
# Unit test for constructor of class Config
def test_Config():
    cd = Config(directory='/')
    assert 'default_options' in list(cd.keys())


# Generated at 2022-06-21 13:48:44.570160
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    c = BaseConfigDict(path='/testpath')
    with open('/testpath', 'w') as f:
        f.close()
    c.delete()
    assert not os.path.exists('/testpath')

# Generated at 2022-06-21 13:48:50.827873
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import random
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from httpie.config import ConfigDict

    with TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / f'{random.choice(range(100))}.json'
        config = ConfigDict(path)
        config['a'] = 1
        config['b'] = 2
        config.save()

        assert path.is_file()



# Generated at 2022-06-21 13:48:53.469209
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dic = BaseConfigDict()
    config_dic['test_key'] = "test_value"
    config_dic.save()

# Generated at 2022-06-21 13:48:54.715194
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    BaseConfigDict(Path('~/.httpie/test.test'))

# Generated at 2022-06-21 13:48:59.697728
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    temp_dir = Path("test_dir")
    temp_dir.mkdir()
    temp_file = temp_dir / "test_file"
    content = "\n".join(("{",
                         "\"test\" : \"test\",",
                         "\"test1\" : \"test1\"",
                         "}"))
    temp_file.write_text(content)
    temp_file.delete()
    assert not temp_file.exists()
    temp_dir.rmdir()
    assert not temp_dir.exists()