

# Generated at 2022-06-21 13:39:55.776447
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    BaseConfigDict('../data/config.json')



# Generated at 2022-06-21 13:40:04.844363
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    sample_dir = './samples'
    if not os.path.exists(sample_dir):
        os.makedirs(sample_dir)
    os.chdir(sample_dir)
    instance = BaseConfigDict(path = './test.json')
    data = {
        '__meta__': {
            'httpie': '1'
        },
        'default_options': []
    }
    with open('./test.json', 'w') as f:
        json.dump(data, f, indent=4, sort_keys=True, ensure_ascii=True)
    instance.load()
    assert instance == data


# Generated at 2022-06-21 13:40:07.493194
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    assert isinstance(BaseConfigDict.FILENAME, str)
    assert isinstance(BaseConfigDict.DEFAULTS, dict)


# Generated at 2022-06-21 13:40:19.759997
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import sys
    import subprocess
    import tempfile
    # Create a temporary folder
    cwd = os.getcwd()
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        print(tmpdirname)
        # Create file config.json
        p = BaseConfigDict(path=tmpdirname+'/config.json')
        p.update({'r':12})
        # Save the content
        p.save()
        # A config.json file should be created in the temporary folder
        assert subprocess.check_call(['test -f config.json'], shell=True) == 0
        # The content of config.json should be: {"r": 12}

# Generated at 2022-06-21 13:40:23.329306
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    cf = BaseConfigDict(path=DEFAULT_CONFIG_DIR/'config.json')
    cf.update({'default_options': []})
    assert cf.get('default_options') == []


# Generated at 2022-06-21 13:40:29.028127
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Create a file in /tmp
    f = open('/tmp/my_file', 'w')
    f.write('hello')
    f.close()

    # Delete a non existing file
    try:
        os.remove('/tmp/my_file_not_exist')
    except OSError as e:
        pass



# Generated at 2022-06-21 13:40:30.773094
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dict = BaseConfigDict(path='')
    print(config_dict.delete())


# Generated at 2022-06-21 13:40:39.597802
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import tempfile # Unit test imports
    from pathlib import Path

    temp_dir = Path(tempfile.gettempdir())
    temp_file = temp_dir / "config.json"
    temp_cfg = BaseConfigDict(temp_file)
    assert temp_cfg._path == temp_file

    temp_dir = temp_dir.absolute()
    temp_file = temp_dir / "config.json"
    temp_cfg = BaseConfigDict(temp_file)
    assert temp_cfg._path == temp_file

# Generated at 2022-06-21 13:40:42.647305
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.load()
    print(config)
    config.save()


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-21 13:40:45.336340
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config = BaseConfigDict(Path('~/.httpie/config.json'))
    try:
        test_config.load()
    except ConfigFileError as e:
        pass

# Generated at 2022-06-21 13:40:50.900019
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    import pytest
    with pytest.raises(ConfigFileError):
        raise ConfigFileError

# Generated at 2022-06-21 13:40:57.205263
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        return
    else:

        # Test for system where XDG_CONFIG_HOME is set:
        os.environ['XDG_CONFIG_HOME'] = '/some/path/to/.config/'
        default_config_path = get_default_config_dir()
        assert default_config_path == Path('/some/path/to/.config/httpie')

        # Test for system where XDG_CONFIG_HOME is NOT set:
        del os.environ['XDG_CONFIG_HOME']
        default_config_path = get_default_config_dir()
        assert default_config_path == Path('/home/user/.config/httpie')



# Generated at 2022-06-21 13:41:00.139723
# Unit test for constructor of class Config
def test_Config():
    config = Config(directory='/tmp')
    assert config.directory == Path('/tmp')

    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR



# Generated at 2022-06-21 13:41:11.399170
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def check_safe_mkdir(Safe_path):
        # we expect no exception
        Safe_path.parent.mkdir(mode=0o700, parents=True)

    def check_exception_mkdir(Exception_path):
        try:
            Exception_path.parent.mkdir(mode=0o700, parents=True)
        except OSError as e:
            if e.errno == errno.EEXIST:
                raise

    # create temporary directory
    path = Path(tempfile.mkdtemp())
    test_path = path / "test_config_dir"
    test_dir = BaseConfigDict(test_path)

    # when the path is not exists
    check_safe_mkdir(test_path)

    # when the parent path is exists

# Generated at 2022-06-21 13:41:14.356892
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    There is no built-in unittest function for testing function.
    Use this custom function to print the returned value for manual testing.
    """
    print(get_default_config_dir())

# Generated at 2022-06-21 13:41:16.217948
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        configFileError = ConfigFileError()
    except TypeError:
        assert False


# Generated at 2022-06-21 13:41:21.117945
# Unit test for constructor of class Config
def test_Config():
    import os
    os.environ[ENV_HTTPIE_CONFIG_DIR]="."
    assert Config().directory == Path('.')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert Config() == Config(DEFAULT_CONFIG_DIR)



# Generated at 2022-06-21 13:41:30.834062
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_path=Path('/tmp/config.json')
    config=BaseConfigDict(path=test_path)
    config['key1']='value1'
    config['key2']='value2'
    config['key3']='value3'
    config.save()
    assert test_path.exists()
    assert test_path.read_text()==(
        '{\n'
        '    "key1": "value1",\n'
        '    "key2": "value2",\n'
        '    "key3": "value3"\n'
        '}\n'
    )
    test_path.unlink()
    assert not test_path.exists()

# Generated at 2022-06-21 13:41:38.211927
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    if is_windows:
        TEST_CONFIG_DIR = Path('C:\\Users\\hp\\AppData\Roaming\\httpie') / 'test'
        TEST_CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
        TEST_CONFIG_FILE = TEST_CONFIG_DIR / "config.json"
    else:
        TEST_CONFIG_DIR = Path.home() / '.config' / 'httpie' / 'test_delete'
        TEST_CONFIG_FILE = TEST_CONFIG_DIR / "config.json"

    TEST_CONFIG_FILE.write_text('{}\n')
    assert TEST_CONFIG_FILE.exists()
    BaseConfigDict(TEST_CONFIG_FILE).delete()
    assert not TEST_CONFIG_FILE.exists()

# Generated at 2022-06-21 13:41:40.836102
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    # Assert that directory is the default directory
    assert config.directory == DEFAULT_CONFIG_DIR
    # Assert that the path exists, i.e., /Users/josh/Libraries/Python/httpie/httpie/config/config.json
    assert config.path.exists
    # Assert that the config.json file has a key, value pair
    assert config.default_options

# Generated at 2022-06-21 13:41:47.448385
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # test for invalid path
    b = BaseConfigDict(Path("invalid_path"))
    b.delete()



# Generated at 2022-06-21 13:41:49.904760
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict(path = Path('httpie/config.json'))
    assert config.path == Path('httpie/config.json')

# Generated at 2022-06-21 13:41:57.301536
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == Path(os.getenv(DEFAULT_CONFIG_DIRNAME, Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME))

    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-21 13:42:09.210050
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    import tempfile, shutil
    class DummyBaseConfigDict(BaseConfigDict):
        pass

    ROOT_DIR = Path(tempfile.gettempdir())
    SUB_DIR = 'sub_dir'
    FILENAME = 'config.json'
    NEW_FILE_PATH = ROOT_DIR / SUB_DIR / FILENAME

    # Create new file(s)
    #   1. Create sub directory
    NEW_FILE_PATH.parent.mkdir(mode=0o700, parents=True)

    #   2. Create JSON config file
    with NEW_FILE_PATH.open('wt') as f:
        json.dump(obj={'key1': 'value1'}, fp=f, indent=4)

    # Test
    obj = DummyBaseConfigDict(path=NEW_FILE_PATH)

# Generated at 2022-06-21 13:42:12.678861
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = {
        ENV_HTTPIE_CONFIG_DIR: '/foo/bar'
    }
    assert get_default_config_dir(env) == '/foo/bar'
    env = {}
    if is_windows:
        expected_config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        expected_config_dir = Path.home() / Path('.config') / Path('httpie')
    assert get_default_config_dir(env) == expected_config_dir



# Generated at 2022-06-21 13:42:14.578344
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.default_options == []
    config.save()
    config.delete()



# Generated at 2022-06-21 13:42:20.340812
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_path = './test_config.json'
    test_obj = BaseConfigDict(file_path)
    test_obj.load()
    assert test_obj.config_file == './test_config.json'
    test_obj = BaseConfigDict('./test_config.json')
    test_obj.load()


# Generated at 2022-06-21 13:42:32.841830
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():

    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    assert ConfigFileError.__name__ == 'ConfigFileError'

    assert BaseConfigDict.__name__ == 'BaseConfigDict'
    assert BaseConfigDict.__bases__ == (dict,)

    assert BaseConfigDict.__init__.__name__ == '__init__'
    assert BaseConfigDict.__init__.__qualname__ == 'BaseConfigDict.__init__'

    assert BaseConfigDict.is_new.__name__ == 'is_new'
    assert BaseConfigDict.is_new.__qualname__ == 'BaseConfigDict.is_new'

    # test for property
    assert BaseConfigDict.ensure_directory.__get__.__name__ == 'get'
    assert BaseConfig

# Generated at 2022-06-21 13:42:39.840859
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    data = {'a': 1, 'b': 2, 'c': 3}
    config = BaseConfigDict(path=Path("example.json"))
    config['a'] = data['a']
    config['b'] = data['b']
    config['c'] = data['c']
    config.save()
    result = config.delete()
    assert result == None
    config.load()
    assert config.path == Path("example.json")
    assert config == {}

# Generated at 2022-06-21 13:42:44.307262
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.is_new() == True
    assert config['default_options'] == []
    assert config['__meta__'] == {}
    assert config.default_options == []



# Generated at 2022-06-21 13:42:58.046164
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict('test')
    assert str(config_dict) == '{}'
    assert config_dict.path == Path('test')



# Generated at 2022-06-21 13:43:09.344129
# Unit test for constructor of class Config
def test_Config():
    default_path = str(DEFAULT_CONFIG_DIR)
    # Cases that constructing path using argument 'directory' is not equal to DEFAULT_CONFIG_DIR
    assert Config(Path.home()).directory != default_path
    assert Config('/etc').directory != default_path
    # Cases that constructing path using argument 'directory' is equal to DEFAULT_CONFIG_DIR
    assert Config(default_path).directory == default_path
    assert Config().directory == default_path
    assert Config(str(DEFAULT_CONFIG_DIR)).directory == default_path
    # Cases that constructing path using argument 'directory' is not a path
    assert Config(1).directory == default_path
    assert Config([1]).directory == default_path
    assert Config({1}).directory == default_path
    assert Config(None).directory == default_path
   

# Generated at 2022-06-21 13:43:12.004950
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('Error message')
    except ConfigFileError as e:
        assert str(e) == 'Error message'
    else:
        assert False


# Generated at 2022-06-21 13:43:15.491189
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.directory == DEFAULT_CONFIG_DIR
    assert config.path == DEFAULT_CONFIG_DIR / 'config.json'
    assert config['default_options'] == []



# Generated at 2022-06-21 13:43:21.497928
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    with tempfile.NamedTemporaryFile('wt') as f:
        content = {'test': True}
        json.dump(content, f)
        f.flush()
        f.seek(0)
        config = BaseConfigDict(Path(f.name))
        config.delete()
        assert f.name not in os.listdir(tempfile.gettempdir())

# Generated at 2022-06-21 13:43:25.122654
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    path = Path('test')
    config = BaseConfigDict(path=path)
    assert config.path.name == path.name
    assert config.path.parent.name == path.parent.name


# Generated at 2022-06-21 13:43:29.033419
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    test_dict = BaseConfigDict('test/test.json')
    assert (test_dict.__init__ == BaseConfigDict.__init__)
    assert (test_dict.path == 'test/test.json')


# Generated at 2022-06-21 13:43:34.751939
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    c = Config()
    print(c.is_new())
    print(c.default_options)

if __name__ == '__main__':
    test_BaseConfigDict()

# Generated at 2022-06-21 13:43:36.820945
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path.home()
    config = BaseConfigDict(path)
    config.save()


# Generated at 2022-06-21 13:43:38.228888
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    #errno.ENOENT
    pass


# Generated at 2022-06-21 13:43:52.930638
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    class SomeConfigDict(BaseConfigDict):
        name = 'myname'
        helpurl = 'myhelpurl'
        about = 'myabout'

    config_dir = Path('~/.httpie').expanduser()
    config_file = config_dir / 'config.json'
    config = SomeConfigDict(config_file)
    assert config.name == 'myname'
    assert config.helpurl == 'myhelpurl'
    assert config.about == 'myabout'



# Generated at 2022-06-21 13:43:55.968912
# Unit test for constructor of class Config
def test_Config():
    assert repr(Config) == "<class 'httpie.config.Config'>"
    assert len(Config().default_options) == 0
    assert len(Config(directory='.').default_options) == 0



# Generated at 2022-06-21 13:44:05.556557
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import io
    import json
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory

    import pytest
    from httpie import __version__
    from httpie.config import BaseConfigDict

    @pytest.fixture(scope='class')
    def config_dict():

        class Dict(BaseConfigDict):
            pass

        return Dict

    def test_save_fail_silently(config_dict):
        with TemporaryDirectory() as dir_name:
            path = Path(dir_name) / 'config.json'
            d = config_dict(path)
            d['foo'] = 'bar'
            d.save(fail_silently=True)
            assert not path.exists()


# Generated at 2022-06-21 13:44:08.278863
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    path = '/home/admin/httpie/config'
    config = BaseConfigDict(path)
    assert config.is_new() == True



# Generated at 2022-06-21 13:44:14.220748
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from .paths import CONFIG_DIR
    from httpie.config import BaseConfigDict
    source = CONFIG_DIR / 'config.json'
    target = CONFIG_DIR / 'configtmp.json'
    target.write_text(source.read_text())
    b = BaseConfigDict(target)
    b.load()


# Generated at 2022-06-21 13:44:23.519471
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    #config = BaseConfigDict(Path("/home/havah/httpie/rmb/rmb-0.0.6/rmb.json"))
    config = BaseConfigDict(Path("/home/havah/httpie/rmb/rmb-0.0.6/rmb.json"))
    print("config={}".format(config))
    #config.load()
    print("config={}".format(config))
    #config.save()
    print("config={}".format(config))
    #config.delete()
    print("config={}".format(config))
    print("dict(config)={}".format(dict(config)))
    print("config.path={}".format(config.path))

if __name__ == '__main__':
    test_BaseConfigDict()

# Generated at 2022-06-21 13:44:27.019509
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    inst = BaseConfigDict(Path('./config'))
    assert not inst.is_new()
    inst.delete()
    assert inst.is_new()

# Generated at 2022-06-21 13:44:38.320655
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. Test explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/test/config'
    assert get_default_config_dir() == '/tmp/test/config'

    # 2. Test non-Windows
    if not is_windows:
        assert get_default_config_dir() == '/tmp/test/config'

    # 3. Test legacy ~/.httpie
    Path('/tmp/test/.httpie').mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == '/tmp/test/.httpie'

    # 4. Test XDG
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg'

# Generated at 2022-06-21 13:44:41.073996
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_config = BaseConfigDict(path="/home/temp")
    test_config.ensure_directory()


# Generated at 2022-06-21 13:44:49.046328
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Set-up
    test_dir = Path('testdir')
    test_dir.mkdir()

    test_file_path = Path(test_dir / 'test.file')
    # Create test file
    test_file_path.write_text('hello world')

    class TestDict(BaseConfigDict):
        pass

    test_dict = TestDict(test_file_path)

    # Testing
    test_dict.delete()

    # Assertions
    assert not test_file_path.exists()

    # Set-Down
    test_dir.rmdir()

# Generated at 2022-06-21 13:45:11.282711
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import platform
    import shutil
    import tempfile
    tmp_dir = tempfile.mkdtemp()

    os.chdir(tmp_dir)
    config = Config(directory=tmp_dir)
    config.save()
    assert os.path.isfile(os.path.join(tmp_dir, 'config.json'))

    os.chdir(tmp_dir)
    config = Config(directory=tmp_dir)
    config.save()
    assert os.path.isfile(os.path.join(tmp_dir, 'config.json'))

    os.chdir(tmp_dir)
    config = Config(directory=tmp_dir)
    config.save()
    assert os.path.isfile(os.path.join(tmp_dir, 'config.json'))

    shutil

# Generated at 2022-06-21 13:45:11.810287
# Unit test for constructor of class Config
def test_Config():
    print(DEFAULT_CONFIG_DIR)



# Generated at 2022-06-21 13:45:23.261352
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    assert BaseConfigDict(Path(DEFAULT_CONFIG_DIR)).is_new() == True
    json_dict = {
        '__meta__': {
            'httpie': '0.9.9'
        }
    }
    path = Path(DEFAULT_CONFIG_DIR)/'config.json'
    json_string = json.dumps(
        obj=json_dict,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    path.write_text(json_string + '\n')
    d = Config()
    assert d.is_new() == False
    d.load()
    assert d['__meta__']['httpie'] == '0.9.9'


# Generated at 2022-06-21 13:45:31.790140
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    my_config = BaseConfigDict(path=Path('./base.json'))
    my_config['test'] = 'test'
    my_config.save()
    if my_config.is_new():
        print('new')
    else:
        print('not new')
    print(my_config)
    print(my_config.path)
    print(my_config.is_new())
    my_config['test'] = 'test2'
    my_config.save()
    my_config.load()
    print(my_config)
    my_config.delete()



# Generated at 2022-06-21 13:45:34.996206
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config = BaseConfigDict("config.json")
    assert config.path == "config.json"

    config2 = BaseConfigDict("config2.json")
    assert config2.path == "config2.json"


# Generated at 2022-06-21 13:45:45.168912
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_path = Path('test_load.json')
    config_dict = BaseConfigDict(path=test_path)
    config_dict.load()
    assert config_dict == {}

    valid_json = ['{\n', ' "json_key": "json_value"', '}\n' ]
    with test_path.open('wt') as f:
        for line in valid_json:
            f.write(line)
    config_dict = BaseConfigDict(path=test_path)
    config_dict.load()
    assert config_dict["json_key"] == "json_value"

    invalid_json = '{ "json_key": "json_value" }'
    with test_path.open('wt') as f:
        f.write(invalid_json)
    config_dict = BaseConfig

# Generated at 2022-06-21 13:45:48.084307
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    fake_path = Path('fakepath/test.json')
    newConfigDict = BaseConfigDict(fake_path)
    assert newConfigDict.path == fake_path


# Generated at 2022-06-21 13:45:50.170047
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    # make sure ConfigFileError can be created
    error = ConfigFileError()
    assert error

# Generated at 2022-06-21 13:45:52.964043
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test 1 2 3')
    except ConfigFileError as e:
        assert str(e) == 'test 1 2 3'


# Generated at 2022-06-21 13:45:54.204763
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    my_config = BaseConfigDict(Path('testfile'))
    assert my_config.is_new() == True


# Generated at 2022-06-21 13:46:21.528093
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('test.txt'))
    config.ensure_directory()
    assert config.path.parent.exists()
    config.path.parent.rmdir()


# Generated at 2022-06-21 13:46:26.088933
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == 'C:\\Users\\username\\AppData\\Roaming\\httpie'
    else:
        assert get_default_config_dir() == '~/.config/httpie'

# Generated at 2022-06-21 13:46:32.832746
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    home_dir = Path.home()
    test_config_path = home_dir / 'test/test_config.json'
    if os.path.exists(test_config_path):
        os.remove(test_config_path)
    test_config = BaseConfigDict(test_config_path)
    assert test_config.path == test_config_path

test_BaseConfigDict()

# Generated at 2022-06-21 13:46:43.007342
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    name1 = 'sample'
    helpurl1 = 'sample url'
    about1 = 'about sample'
    path = '~/.config/httpie/sample.json'
    temp = BaseConfigDict(path)
    temp.name = name1
    temp.helpurl = helpurl1
    temp.about = about1
    if temp.name != name1:
        raise ValueError('test_BaseConfigDict failed')
    if temp.helpurl != helpurl1:
        raise ValueError('test_BaseConfigDict failed')
    if temp.about != about1:
        raise ValueError('test_BaseConfigDict failed')
    if not isinstance(temp.path, Path):
        raise ValueError('test_BaseConfigDict failed')
    if temp.path.as_posix() != path:
        raise Value

# Generated at 2022-06-21 13:46:54.103937
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    TMP_DIR = os.path.join(BASE_DIR, "tmp")
    os.mkdir(TMP_DIR)
    os.chdir(TMP_DIR)
    f = open("__init__.py", "w+")
    f.close()
    from httpie.configurator.config_dir import BaseConfigDict
    dict = BaseConfigDict()
    dict.save()
    files = os.listdir(".")
    assert files == ["__init__.py"]
    os.remove("__init__.py")
    os.chdir("..")
    os.rmdir("tmp")


# Generated at 2022-06-21 13:46:55.228594
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    assert ConfigFileError

# Generated at 2022-06-21 13:47:01.671913
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile()
    # load the file
    bcd = BaseConfigDict(path=Path(temp_file.name))
    assert bcd.is_new() == False
    # delete the file
    os.remove(temp_file.name)
    # load the deleted file
    bcd = BaseConfigDict(path=Path(temp_file.name))
    assert bcd.is_new() == True


# Generated at 2022-06-21 13:47:06.868053
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # 1. Create a new file
    config_dict = BaseConfigDict(path=Path('/tmp/config.json'))
    # 2. Save the content
    config_dict.save()
    # 3. Check if the file exists
    assert config_dict.path.exists()
    # 4. Delete the file
    config_dict.path.unlink()


# Generated at 2022-06-21 13:47:08.389505
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    print(config.path)
    print(config.directory)

# Generated at 2022-06-21 13:47:12.227417
# Unit test for constructor of class Config
def test_Config():
    config_dir = Path('../httpie')
    config = Config(config_dir)
    assert config.directory == config_dir
    assert config.path == Path('../httpie/config.json')
    assert config.default_options == []


# Generated at 2022-06-21 13:48:08.893465
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def env(**envvars):
        old_env = os.environ
        old_keys = set(os.environ)
        os.environ = old_env.copy()
        os.environ.update(envvars)
        try:
            yield
        finally:
            new_keys = set(os.environ) - old_keys
            for key in new_keys:
                del os.environ[key]
            os.environ = old_env

    def mkdir(*path):
        path = os.path.join(*path)
        os.mkdir(path)
        return path


# Generated at 2022-06-21 13:48:15.300906
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('~/.httpie') / 'test'
    config_dir.mkdir(mode=0o600, parents=True)
    config = BaseConfigDict(path=config_dir / 'test.json')
    config.save()
    assert config_dir.exists()
    assert config_dir.is_dir()
    config_dir.unlink()


# Generated at 2022-06-21 13:48:17.074828
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cf = ConfigFileError("error")
    assert str(cf) == "error"



# Generated at 2022-06-21 13:48:19.667322
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    import pytest
    base_test = BaseConfigDict(Path(__file__))
    assert isinstance(base_test, BaseConfigDict)


# Generated at 2022-06-21 13:48:30.439193
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dirs = []
    # Test case:
    # Test when:
    #     - the directory is newly created
    #     - the directory is existed (has been created by previous test case)
    # Expected:
    #     - the directory is created
    for new_dir in ['new_config_dir', 'existed_config_dir']:
        config_dirs.append(Path('/tmp') / new_dir)
        config = BaseConfigDict(config_dirs[-1])

        # Test before: directory is not created
        assert not config_dirs[-1].exists()

        # Test after: directory is created
        config.ensure_directory()
        assert config_dirs[-1].exists()

    # Test case:
    # Test when:
    #     - the directory is not

# Generated at 2022-06-21 13:48:36.016018
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # init a BaseConfigDict
    dummy_path = '/not/exist'
    bcd = BaseConfigDict(path=Path(dummy_path))
    bcd['a'] = 'b'

    # test saving
    bcd.save()
    assert False # it should never go to this line



# Generated at 2022-06-21 13:48:37.412754
# Unit test for constructor of class Config
def test_Config():
    Config()
    Config(directory=Path.home() / '.config')


# Generated at 2022-06-21 13:48:47.508388
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # 建立临时目录
    dirpath = tempfile.mkdtemp()
    # 生成测试文件
    filepath = os.path.join(dirpath, BaseConfigDict.FILENAME)
    with open(filepath, 'w') as f:
        f.write(
            json.dumps(
                {
                    '__meta__': {
                        'httpie': '0.9.9',
                        'help': 'https://httpie.org/docs',
                        'about': 'https://httpie.org'
                    },
                    'default_options': []
                }
            )
        )
    config = Config(dirpath)
    assert config.is_new() == False
    assert config.path.exists() == True
   

# Generated at 2022-06-21 13:48:49.853364
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('Invalid config file')
    except ConfigFileError as e:
        print(e)


# Generated at 2022-06-21 13:48:57.648682
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    TEST_FILE_PATH = "test_file.json"
    TEST_KEY = "test_key"
    TEST_VAL = "test_val"
    TEST_DICT = {TEST_KEY: TEST_VAL}

    test_obj = BaseConfigDict(TEST_FILE_PATH)
    test_obj.save()

    with open(TEST_FILE_PATH, 'r') as file:
        try:
            test_dict = json.load(file)
            assert test_dict == test_obj
        except Exception as e:
            print(str(e))

    os.remove(TEST_FILE_PATH)

