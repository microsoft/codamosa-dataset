

# Generated at 2022-06-21 13:39:59.707525
# Unit test for constructor of class Config
def test_Config():
    conf = Config()
    conf.load()
    assert isinstance(conf, dict)
    assert conf.get('default_options', np.nan) == []
    try:
        conf.save()
    except ConfigFileError:
        pass
    
    
    

# Generated at 2022-06-21 13:40:06.660581
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    DUMMY_PATH = 'DUMMY_PATH'
    class DummyBaseConfigDict(BaseConfigDict):
        def __init__(self):
            super().__init__(DUMMY_PATH)

    dummy = DummyBaseConfigDict()
    assert dummy.path == 'DUMMY_PATH'
    assert dummy.about == None
    assert dummy.helpurl == None
    assert dummy.name == None


# Generated at 2022-06-21 13:40:08.336504
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    bd = BaseConfigDict(Path.cwd() / 'config.json')
    bd.delete()

# Generated at 2022-06-21 13:40:12.646319
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    # Prepare test parameters
    c = BaseConfigDict(Path("test.json"))
    c['test'] = 'test'
    c.save()

    # Unit test starts
    c.delete()

    # Verify outcome
    assert c.path.is_file() == False

# Generated at 2022-06-21 13:40:24.833466
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmpf_name = 'test_config_%s.json' % os.getpid()
    tmpf = Path('/tmp') / tmpf_name
    tmpd = tmpf.parent
    try:
        def get_tmpf_stat():
            return tmpf.stat()
        tmpd.mkdir()
        assert(get_tmpf_stat().st_mode == 16877)
        tmpd.rmdir()
        assert (not tmpd.exists())
        init_config = BaseConfigDict(path=tmpf)
        init_config.ensure_directory()
        assert(get_tmpf_stat().st_mode == 16877)
        tmpd.chmod(0o755)
    finally:
        if tmpf.exists():
            tmpf.unlink()

# Generated at 2022-06-21 13:40:26.937873
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    assert config.is_new() == True
    config.load()
    config.save()
    assert config.is_new() == False

if __name__ == '__main__':
    test_BaseConfigDict_is_new()

# Generated at 2022-06-21 13:40:29.074751
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(str(DEFAULT_CONFIG_DIR) == os.path.expanduser('~/.config/httpie'))

# Generated at 2022-06-21 13:40:30.116602
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # TODO
    pass


# Generated at 2022-06-21 13:40:32.332096
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert DEFAULT_CONFIG_DIR.parent.exists()

# Generated at 2022-06-21 13:40:44.377963
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    #Test directory creation
    test_config_dir = Path.home() / 'test_directory'
    if test_config_dir.exists():
        test_config_dir.unlink()
    test_config_file = Path.home() / 'test_directory' / 'test_config.json'
    if test_config_file.exists():
        test_config_file.unlink()
    test_config = BaseConfigDict(path = test_config_file)
    assert not test_config_dir.exists()
    assert not test_config_file.exists()
    test_config.save()
    assert test_config_dir.exists()
    assert test_config_file.exists()
    #Test load and save
    test_config['test_key'] = 'test_value'
    test_

# Generated at 2022-06-21 13:40:55.995809
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import json
    import httpie.config
    import shutil
    import tempfile

    # Create a test config file
    test_config = tempfile.mkstemp()
    test_config_path = test_config[1]
    with open(test_config_path, 'w') as test_config_handle:
        test_config_handle.write(json.dumps({
            'foo': 'bar',
            'baz': [1, 2, 3],
            'qux': {
                'quux': 'quuz'
            }
        }))

    # Load it
    config = httpie.config.BaseConfigDict(path = test_config_path)
    config.load()

    # Assert that the file was loaded
    assert (config['foo'] == 'bar')

# Generated at 2022-06-21 13:40:57.923765
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    c = BaseConfigDict('config.json')
    c.delete()



# Generated at 2022-06-21 13:41:03.888741
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('test_config.json')
    test_config = BaseConfigDict(path)
    test_config.save()
    with path.open('rt') as f:
        try:
            data = json.load(f)
        except ValueError as e:
            raise ConfigFileError(e)
    os.remove('test_config.json')


# Generated at 2022-06-21 13:41:05.954360
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict('path_to_file')
    config_dict.load()
    return True

# Generated at 2022-06-21 13:41:14.879326
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # If true the file is created, if false the existing file is deleted.
    test = True
    test_file = DEFAULT_CONFIG_DIR / 'test_BaseConfigDict_is_new.json'

    if test_file.exists():
        test_file.unlink()

    # Create new config file
    config_file = BaseConfigDict(test_file)
    assert config_file.is_new() == test

    if test:
        config_file.save(fail_silently=False)

# Generated at 2022-06-21 13:41:21.272897
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import DEFAULT_CONFIG_DIR

    config_dir = DEFAULT_CONFIG_DIR
    # test for method ensure_directory of class BaseConfigDict
    base_config_test1 = BaseConfigDict(config_dir)
    # reload method ensure_directory of class BaseConfigDict
    base_config_test1.ensure_directory()
    assert (config_dir).exists()


# Generated at 2022-06-21 13:41:24.659803
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    a = BaseConfigDict(Path('~/.httpie/config.json'))
    a.ensure_directory()
    if os.path.exists(a.path.parent):
        pass
    else:
        assert False


# Generated at 2022-06-21 13:41:30.514510
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    class TempConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(path=Path('temp_config.json'))

    tmp_config = TempConfig()
    if tmp_config.is_new():
        tmp_config.save()

    assert not tmp_config.is_new()
    tmp_config.delete()
    assert tmp_config.is_new()



# Generated at 2022-06-21 13:41:35.621864
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    try:
        BaseConfigDict(Path('./test_config_file.json')).delete()
    except OSError:
        pass
    test_file = Path('./test_config_file2.json')
    test_file.touch()
    try:
        assert BaseConfigDict(test_file).delete() is None
        test_file.unlink()
    except:
        test_file.unlink()



# Generated at 2022-06-21 13:41:38.522823
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('error')
    except ConfigFileError as e:
        assert e.args[0] == 'error'


# Generated at 2022-06-21 13:41:54.140286
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        config = BaseConfigDict(Path("config_test.json"))
        config.load()
    except ConfigFileError as e:
        success = 'invalid config file: unexpected data [test.json]'
        if e.args[0] != success:
            raise AssertionError()
    else:
        raise AssertionError()
    try:
        config = BaseConfigDict(Path("package.json"))
        config.load()
    except ConfigFileError as e:
        success = 'invalid config file: No JSON object could be decoded [package.json]'
        if e.args[0] != success:
            raise AssertionError()
    else:
        raise AssertionError()



# Generated at 2022-06-21 13:41:58.256595
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    path = "httpie/test/test_config_delete"
    config_dict = BaseConfigDict(path=path)
    config_dict['test'] = "test"
    config_dict.save()

    config_dict.delete()
    assert os.path.isfile(path) == False



# Generated at 2022-06-21 13:42:00.644736
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-21 13:42:11.792750
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    def test():
        test_config = BaseConfigDict(path='/home/xinzhao/project/httpie/httpie/config/config.json')
        test_config.load()
        test_config['__meta__'] = {'httpie': __version__}
        with open('/home/xinzhao/project/httpie/httpie/config/load_test_output.txt', 'rt') as f:
            try:
                data = json.load(f)
            except ValueError as e:
                raise ConfigFileError('invalid load_test_output.txt file: {e} [{test_config.path}]')
            if data != test_config:
                raise Exception('method load test failed')

    test()


# Generated at 2022-06-21 13:42:17.750674
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    '''
    Instantiate class BaseConfigDict to initialize its variables
    :return: class instance
    '''
    path = Path('test/test_data/test_config.json')
    test_BaseConfigDict = BaseConfigDict(path)
    return test_BaseConfigDict


# Generated at 2022-06-21 13:42:24.156960
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_conf_dir_1 = Path('/tmp/httpie_test')
    try:
        test_conf_dir_1.mkdir()
    except:
        pass
    test_config = BaseConfigDict(path=test_conf_dir_1 / Config.FILENAME)
    try:
        test_config.load()
    except ConfigFileError as e:
        assert True
    else:
        assert False

    test_conf_dir_2 = Path('/tmp/httpie_test')
    test_config = BaseConfigDict(path=test_conf_dir_2 / Config.FILENAME)
    test_config.save()
    test_config.load()
    assert test_config.is_new() == False

# Generated at 2022-06-21 13:42:36.159544
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    from pathlib import Path
    from .config import BaseConfigDict
    from .constants import (
        DEFAULT_CONFIG_DIR,
        DEFAULT_COOKIES_FILENAME,
        DEFAULT_FORM_FILENAME,
        DEFAULT_HISTORY_FILENAME,
        DEFAULT_RC_FILENAME,
    )

    def get_test_config_file_path(test_file_name: str) -> str:
        """
        Return the path to the test config file.
        The current working directory must be that of the httpie git repository.
        """

        # test file directory
        test_file_dir = Path('tests', 'config')
        return str(Path.cwd() / test_file_dir / test_file_name)

    # create a test file
    test_file_name

# Generated at 2022-06-21 13:42:42.268880
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    file = open('test.txt', 'w')
    b = BaseConfigDict(path = Path('test.txt'))
    assert b.path == Path('test.txt')

    file.close()
    b.__init__(Path('test.txt'))
    assert b.path == Path('test.txt')
    os.remove('test.txt')

test_BaseConfigDict()

# Generated at 2022-06-21 13:42:53.943428
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from mock import patch, call
    from httpie.config import BaseConfigDict
    from pathlib import Path
    from httpie import __version__

    # Unit tests for method ensure_directory of class BaseConfigDict
    class FakeBaseConfigDict(BaseConfigDict):
        name = 'fake'
        helpurl = 'url'
        about = 'about'

        def __init__(self, path):
            super().__init__(path=path)

    def mock_mkdir(directory, mode, parents):
        directory.mkdir_called = True

    # Test that the ensure_directory calls the mkdir method of the path object
    # if all is correct
    path = Path('/path/to/fake/config/file.json')
    path.mkdir = mock_mkdir

    fake_config = FakeBaseConfigD

# Generated at 2022-06-21 13:42:59.525629
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path = 'test/test_save.json')
    config_dict.save()
    json_file = open('test/test_save.json', 'r')
    try:
        data = json.load(json_file)
    except ValueError as e:
        raise ConfigFileError(f'invalid config file: {e} [{self.path}]')
    assert data['__meta__']['httpie'] == __version__


# Generated at 2022-06-21 13:43:11.449076
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('The wrong file name')
    except ConfigFileError as e:
        assert str(e) == 'The wrong file name'


# Generated at 2022-06-21 13:43:13.675410
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    config_dict = BaseConfigDict("test")
    assert config_dict.path == Path("test")

# Generated at 2022-06-21 13:43:18.643481
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    new_file = BaseConfigDict(Path('/Users/xiao/httpie/httpie/src/httpie/json'))
    assert (new_file.path == Path('/Users/xiao/httpie/httpie/src/httpie/json'))


# Generated at 2022-06-21 13:43:22.884455
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    temp_dir = Path(tempfile.gettempdir())
    file_path = temp_dir / 'test_config.json'
    config = BaseConfigDict(file_path)
    config.save()
    assert config.is_new() == True

# Generated at 2022-06-21 13:43:25.128622
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    cfg = Config(directory='/tmp')
    cfg._BaseConfigDict__ensure_directory()

# Generated at 2022-06-21 13:43:27.365806
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config = Config()
    config.delete()
    assert not config.path.exists()


# Generated at 2022-06-21 13:43:31.808223
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    try:
        config_dict = BaseConfigDict(Path('test_config.json'))  # path doesn't exist
        if config_dict.is_new() == False:
            return False
    except:
        return False
    return True



# Generated at 2022-06-21 13:43:42.255265
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.clear()
    if is_windows:
        assert str(get_default_config_dir()) == 'C:\\Users\\user\\AppData\\Roaming\\httpie'
    else:
        assert str(get_default_config_dir()) == '/home/user/httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert str(get_default_config_dir()) == '/home/user/httpie'

    # Simulate XDG setup, with XDG_CONFIG_HOME set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/xdg/config/home'

# Generated at 2022-06-21 13:43:54.252896
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    # valid directory
    p = Path.home()
    try:
        cfg = BaseConfigDict(p / 'tmp')
    except Exception:
        assert False
    else:
        assert True

    # invalid directory
    tmp_dir = p / 'tmp'
    if not tmp_dir.exists():
        tmp_dir.mkdir()
    tmp_dir.chmod(0o400)  # make it not readable and writable

    try:
        cfg = BaseConfigDict(tmp_dir / 'tmp')
    except (PermissionError, ConfigFileError):
        assert True
    else:
        assert False
    tmp_dir.chmod(0o700)
    tmp_dir.rmdir()


test_BaseConfigDict()

# Generated at 2022-06-21 13:43:56.062295
# Unit test for constructor of class Config
def test_Config():
    a = Config()
    assert a.path == DEFAULT_CONFIG_DIR / 'config.json'



# Generated at 2022-06-21 13:44:24.236510
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    CONFIG_DIR = Path('~/.config/httpie').expanduser()
    CONFIG_FILE = Path('~/.config/httpie/config.json').expanduser()

    config_dict = BaseConfigDict(path=CONFIG_FILE)
    assert config_dict.__class__.__name__ == 'BaseConfigDict'
    assert config_dict.path == CONFIG_FILE

    # test config_dict.ensure_directory()
    config_dict.ensure_directory()
    assert (CONFIG_DIR).exists()

    # test config_dict.is_new()
    assert config_dict.is_new() == True

    # test config_dict.load()
    config_dict.load()

    # test config_dict.save()
    config_dict.save()
    assert (CONFIG_FILE).ex

# Generated at 2022-06-21 13:44:25.674283
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    pass


# Generated at 2022-06-21 13:44:27.831540
# Unit test for constructor of class Config
def test_Config():
    """
    Test config module constructor function.
    """
    config = Config()
    assert isinstance(config, Config)


# Generated at 2022-06-21 13:44:34.281736
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    # Case 1: default config file on windows
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR.is_dir()
        assert Config().is_new()
    # Case 2: default config file on linux
    else:
        assert Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME / Config.FILENAME
        assert Config().is_new()


# Generated at 2022-06-21 13:44:35.812121
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cf_error=ConfigFileError("test message")    
    assert cf_error is not None

# Generated at 2022-06-21 13:44:41.945732
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_path = Path('tests/resources/config1.json')
    config = BaseConfigDict(config_path)
    assert config.is_new() == False
    config_path = Path('tests/resources/non-existing-config.json')
    config = BaseConfigDict(config_path)
    assert config.is_new() == True


# Generated at 2022-06-21 13:44:43.953969
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(ConfigFileError):
        raise ConfigFileError("test")


# Generated at 2022-06-21 13:44:46.998386
# Unit test for constructor of class Config
def test_Config():
    path = '~/.httpie/test'
    c = Config(path)
    c.save()
    if c.save() == 0:
        assert 1
    else:
        assert 0


# Generated at 2022-06-21 13:44:49.182441
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    cfe = ConfigFileError('cannot read file')
    assert str(cfe) == 'cannot read file'


# Generated at 2022-06-21 13:44:50.877616
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    with pytest.raises(Exception):
        raise ConfigFileError()

# Generated at 2022-06-21 13:45:17.779133
# Unit test for constructor of class BaseConfigDict
def test_BaseConfigDict():
    from pathlib import Path
    from .compat import is_windows
    from .config import BaseConfigDict, get_default_config_dir, DEFAULT_CONFIG_DIR
    # Test for non-windows platform
    if is_windows:
        c = BaseConfigDict(Path('./example_config.json'))
        c.ensure_directory()
        assert c.path.parent == (Path.home() / 'httpie')
    # Test for windows platform
    else:
        c = BaseConfigDict(Path('~/example_config.json'))
        c.ensure_directory()
        assert c.path.parent == (Path.home() / '.config' / 'httpie')
    assert c.path.name == 'example_config.json'
    assert get_default_config_dir() == DEFAULT

# Generated at 2022-06-21 13:45:28.988799
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from tempfile import mkdtemp
    from os import path
    from shutil import rmtree
    from pathlib import Path

    file_content = '{"a": "b"}'
    tmp_file_1 = Path("{}/{}".format(mkdtemp(), "config.json"))
    tmp_file_2 = Path("{}/{}".format(mkdtemp(), "config.json"))

    with open(tmp_file_1, 'w') as file:
        file.write(file_content)


# Generated at 2022-06-21 13:45:35.220272
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil
    # Create a temporary directory
    tmp_dir = Path('tmp') / 'httpie'
    tmp_dir.mkdir(parents=True, exist_ok=True)
    # Test case 1
    tmp_config = BaseConfigDict(path = tmp_dir / 'config.json')
    tmp_config.ensure_directory()
    assert tmp_dir.exists()
    shutil.rmtree(tmp_dir)


# Generated at 2022-06-21 13:45:40.669608
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import tempfile

    class ConfigDict(BaseConfigDict):
        def __init__(self, directory: Union[str, Path] = DEFAULT_CONFIG_DIR):
            directory = Path(directory)
            super().__init__(path=directory / 'config.json')

    dirpath = tempfile.mkdtemp()
    config_test = ConfigDict(directory=dirpath)

    config_test.ensure_directory()
    assert os.path.isdir(config_test.path.parent)

# Generated at 2022-06-21 13:45:50.613325
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dir = Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    config_path = config_dir / 'config.json'
    class TestConfig(BaseConfigDict):
        def __init__(self):
            super().__init__(config_path)
    test_config = TestConfig()
    test_config['test'] = 'test'
    test_config.save()
    assert test_config['test'] == 'test'

    test_config.delete()
    assert not config_path.exists()

    # raise OSError when try to unlink a file which has been deleted
    with pytest.raises(OSError):
        test_config.delete()



# Generated at 2022-06-21 13:45:52.247404
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    e = ConfigFileError("test")
    assert str(e) == "test"

# Generated at 2022-06-21 13:46:00.523280
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Test for method `ensure_directory` of class `BaseConfigDict`.
    """
    config_dir = DEFAULT_CONFIG_DIR
    config_dir.mkdir(parents=True)

    class TestConfig(BaseConfigDict):
        def __init__(self):
            path = config_dir / 'test_config.json'
            super().__init__(path)

    config = TestConfig()
    assert config_dir.is_dir()
    assert not (config_dir / 'test_config.json').exists()

    config.ensure_directory()
    assert config_dir.is_dir()
    assert not (config_dir / 'test_config.json').exists()

    config.save()
    assert config_dir.is_dir()

# Generated at 2022-06-21 13:46:01.132178
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass

# Generated at 2022-06-21 13:46:12.811055
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def get_xdg_config_home():
        if ENV_XDG_CONFIG_HOME in os.environ:
            return os.environ[ENV_XDG_CONFIG_HOME]
        if is_windows:
            return None
        return os.path.join(str(Path.home()), DEFAULT_RELATIVE_XDG_CONFIG_HOME)

    def check_config_dir(os_name, expected_default_config_dir):
        if os_name == 'nt':
            os.name = 'nt'
            os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
            os.environ.pop(ENV_XDG_CONFIG_HOME, None)
            assert get_default_config_dir() == expected_default_config_dir
           

# Generated at 2022-06-21 13:46:15.494807
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config = Config()
    config.delete()
    assert config.is_new() == True

    config.save()
    assert config.is_new() == False

# Generated at 2022-06-21 13:47:07.401138
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    import os
    from pathlib import Path
    from httpie.config import BaseConfigDict
    import json

    config_dic = {
        "__meta__": {
            "httpie": "1.0.3",
            "help": "http://httpie.org",
            "about": "HTTPie - a CLI, cURL-like tool for humans"
        },
        "default_options": []
    }

    config_path = Path(os.getcwd()) / "test.json"
    BaseConfigDict.__init__(self=BaseConfigDict, path=config_path)
    BaseConfigDict.ensure_directory(self=BaseConfigDict)

# Generated at 2022-06-21 13:47:08.785651
# Unit test for constructor of class Config
def test_Config():
    c = Config()
    assert c.default_options == []

# Generated at 2022-06-21 13:47:13.554009
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class test(BaseConfigDict):
        def __init__(self, path: Path):
            self.path = path

    test_dict = {}
    p = 'mock_path'
    test_instance = test(p)
    test_instance.load()
    assert(test_instance == test_dict)



# Generated at 2022-06-21 13:47:18.475741
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError("ConfigFileError")
    except ConfigFileError as e:
        assert str(e) == 'ConfigFileError'

    try:
        raise ConfigFileError("ConfigFileError") from None
    except ConfigFileError as e:
        assert str(e) == 'ConfigFileError'

    try:
        raise ConfigFileError("ConfigFileError", "ConfigFileError")
    except ConfigFileError as e:
        assert str(e) == 'ConfigFileError'



# Generated at 2022-06-21 13:47:29.315236
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        name = 'test_config_dict'

    test_config = TestConfigDict(Path('~/.httpie/test_config_dict.json'))
    test_config['default_options'] = ['--ignore-stdin', '--pretty=all']
    test_config.save()

    test_config.load()
    assert test_config['default_options'] == ['--ignore-stdin', '--pretty=all']
    assert test_config['__meta__']['httpie'] == __version__

    # test for excpetion
    try:
        test_config.load()
        assert 1 == 0
    except ConfigFileError:
        pass



# Generated at 2022-06-21 13:47:34.558114
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = '/home/libo/Desktop/httpie-0.9.9/tests/fixtures/config'
    test_path = Path(config_dir)
    test_dict = BaseConfigDict(test_path)
    test_dict.ensure_directory()
    assert test_path.parent.exists()

# Generated at 2022-06-21 13:47:37.282043
# Unit test for constructor of class Config
def test_Config():
    config = Config()
    assert config.FILENAME == "config.json"
    assert config.DEFAULTS == {
        'default_options': []
    }



# Generated at 2022-06-21 13:47:42.964585
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('@')
    dict = BaseConfigDict(path)
    dict.save()

    # Check if path exists
    assert path.exists()
    # Check if file is not empty
    assert path.stat().st_size > 0
    # Check if file is in JSON format
    open(path, 'r')


# Generated at 2022-06-21 13:47:51.037728
# Unit test for function get_default_config_dir

# Generated at 2022-06-21 13:47:54.357070
# Unit test for constructor of class ConfigFileError
def test_ConfigFileError():
    try:
        raise ConfigFileError('test')
    except ConfigFileError as e:
        assert str(e) == 'test'

# Generated at 2022-06-21 13:49:33.711440
# Unit test for method is_new of class BaseConfigDict
def test_BaseConfigDict_is_new():
    config_dir = Path('/tmp/httpietest')
    config_file = config_dir / 'config.json'
    test_config = BaseConfigDict(path=config_file)
    assert test_config.is_new() == True

    config_dir.mkdir()
    test_config.ensure_directory()
    assert test_config.path.exists() == True
    assert test_config.is_new() == True

    test_config.save()
    assert test_config.is_new() == False
    test_config.delete()

# Generated at 2022-06-21 13:49:42.642610
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def _test(expected):
        assert get_default_config_dir() == expected

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    _test(expected='/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        _test(expected=DEFAULT_WINDOWS_CONFIG_DIR)
        return

    # 3. legacy ~/.httpie
    home_dir = Path.home()
    Path(home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR).mkdir()
    Path(home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME) \
        .mk

# Generated at 2022-06-21 13:49:45.478059
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
