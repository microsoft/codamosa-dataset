

# Generated at 2022-06-11 23:12:20.766831
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # First check if environment variable is present
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert get_default_config_dir() == Path(env_config_dir)

    home_dir = Path.home()
    assert get_default_config_dir() == home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    # Set explicitly set XDG_CONFIG_HOME variable
    os.environ[ENV_XDG_CONFIG_HOME] = str(
        home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME)

    assert get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:22.255062
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:25.514559
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    if is_windows:
        assert config_dir.name == DEFAULT_CONFIG_DIRNAME
    else:
        assert config_dir.name == 'httpie'

# Generated at 2022-06-11 23:12:33.446127
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_path = Path(__file__).parent / 'test.config.json'
    if config_path.exists():
        config_path.unlink()
    assert not config_path.exists()
    config_dict = BaseConfigDict(config_path)
    config_dict['foo'] = 'bar'
    config_dict.save()

    assert 'foo' in config_path.read_text()

    if config_path.exists():
        config_path.unlink()


# Generated at 2022-06-11 23:12:41.749529
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        os.system("rm -rf ~/.httpie")
    except:
        print("rm error")
    # test path not exist
    config = Config()
    config.ensure_directory()
    assert Path(config.directory).exists()
    assert config.directory.is_dir()
    Path(config.directory).rmdir()
    # test path is a dir
    Path(config.directory).mkdir(mode=0o700, parents=True)
    config.ensure_directory()
    Path(config.directory).rmdir()
    # test not mkdir when path is a file
    Path(config.directory).touch()
    try:
        config.ensure_directory()
        assert False
    except OSError:
        assert True
    except:
        assert False

# Generated at 2022-06-11 23:12:45.204279
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir

    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:53.467936
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_dir = 'tests/config/'
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)
    file_path = test_dir + 'test_BaseConfigDict_save.json'
    if os.path.exists(file_path):
        os.remove(file_path)
    test_obj = BaseConfigDict(file_path)
    test_obj.save()
    assert os.path.exists(file_path)

    with open(file_path, 'r') as FILE:
        data = FILE.read()
        assert data == '{"__meta__": {"httpie": "0.8.1"}}\n'

        os.remove(file_path)
        if not os.listdir(test_dir):
            os.rmdir

# Generated at 2022-06-11 23:12:58.116443
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = Path('./config.json')
    config = BaseConfigDict(config_path)
    config['key'] = 20
    config['key2'] = 40
    config.save()
    config.load()
    print(config)
    config.delete()


# Generated at 2022-06-11 23:13:04.088181
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    os.chdir('.')
    test_path = './.test'
    f = open(test_path, 'w')
    f.write("""{
                "default_options": [
                    "--form"
                ]
            }""")
    f.close()
    test_config = BaseConfigDict(test_path)
    test_config.load()
    assert test_config['default_options'] == ['--form']
    # remove test file
    os.remove(test_path)


# Generated at 2022-06-11 23:13:06.845957
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config("tests/fixtures")
    config.load()
    assert config["default_options"] == ["p1=v1", "p2=v2"]

# Generated at 2022-06-11 23:13:20.128377
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test case where the file path doesn't exist
    config_dict = BaseConfigDict(Path("~/non_existent_file"))
    with pytest.raises(ConfigFileError):
        config_dict.load()

    # Test case for invalid JSON file
    config_dict = BaseConfigDict(Path("test/data/config_invalid_json.json"))
    with pytest.raises(ConfigFileError):
        config_dict.load()

    # Test case for valid JSON file
    config_dict = BaseConfigDict(Path("test/data/config_valid_json.json"))
    config_dict.load()
    assert config_dict == {"item1": "value1", "item2": "value2", "item3": "value3"}



# Generated at 2022-06-11 23:13:31.193610
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(DEFAULT_CONFIG_DIR)
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]
    assert get_default_config_dir() == Path(DEFAULT_WINDOWS_CONFIG_DIR)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/test"
    assert get_default_config_dir() == Path("/test")
    os.environ[ENV_XDG_CONFIG_HOME] = "/test"
    if is_windows:
        assert get_default_config_dir() == Path("/test")
    else:
        assert get_default_config_dir() == Path("/test/httpie")

# Generated at 2022-06-11 23:13:35.140005
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    base = BaseConfigDict(Path('something'))
    try:
        base.load()
    except ConfigFileError:
        pass
    else:
        raise AssertionError('Should raise an exception.')

# Generated at 2022-06-11 23:13:47.967621
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Mock Path.home()
    original_home = Path.home
    home_dir = Path('/home/foo')
    Path.home = lambda cls: home_dir

# Generated at 2022-06-11 23:13:52.033922
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    c = BaseConfigDict(path='test.json')
    c['test1'] = 'test2'
    c.save()
    with open('test.json', 'r') as f:
        assert f.read() == '{"test1": "test2"}\n'
    os.remove('test.json')

# Generated at 2022-06-11 23:13:55.886322
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    # check that the new directory exist
    x = BaseConfigDict('/home/httpie/config.json')
    x.ensure_directory()
    assert True == os.path.exists('/home/httpie')

    # check that the file saved
    x.save()
    assert True == os.path.exists('/home/httpie/config.json')


# Generated at 2022-06-11 23:14:03.807596
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    httpie_config_dir = get_default_config_dir()
    if 'XDG_CONFIG_HOME' in os.environ:
        assert str(httpie_config_dir).startswith(os.environ['XDG_CONFIG_HOME'])
    else:
        assert str(httpie_config_dir).startswith(Path.home())

    # Test that it doesn't create directories
    try:
        os.rmdir(httpie_config_dir)
    except OSError as e:
        if e.errno != errno.ENOTEMPTY:
            raise

# Generated at 2022-06-11 23:14:12.340599
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.output.utils import TestEnvironment
    from httpie.compat import is_windows
    from httpie.config import BaseConfigDict

    class TestDict(BaseConfigDict):
        FILENAME = 'config.json'
        DEFAULTS = {'default_options': [], 'new_options': []}

    # For testing reason, the directory has a special value
    if is_windows:
        directory = Path(os.path.expandvars('%APPDATA%')) / 'httpieTest'
    else:
        directory = Path.home() / '.httpieTest'

    with TestEnvironment() as env:
        new_dict = TestDict(directory=directory)
        new_dict.save()

        new_dict.load()
        assert new_dict

# Generated at 2022-06-11 23:14:14.001421
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    baseconfigdict = BaseConfigDict(path=DEFAULT_CONFIG_DIR / "config.json")
    assert baseconfigdict.load() == None

# Generated at 2022-06-11 23:14:16.897642
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    filename = "abc.json"
    config_path = Path(filename)
    config = BaseConfigDict(config_path)
    config.ensure_directory()
    assert os.path.exists(filename)
    # check the path is created


# Generated at 2022-06-11 23:14:30.904929
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from unittest import mock
    from pathlib import Path
    from os.path import isfile
    from httpie.config import BaseConfigDict
    import os

    def create_config_file(fname, contents):
        # Create a config file temporarily
        filepath = Path(fname)
        filepath.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        f = open(fname, "w")
        f.write(contents)
        f.close()

        # Remove config file after test is complete
        os.remove(fname)

    fname = '.httpie/config.json'
    contents = ""
    create_config_file(fname, contents)
    config = BaseConfigDict(fname)
    config.load()


# Generated at 2022-06-11 23:14:35.943390
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestingDict(BaseConfigDict):
        pass
    config_dict = TestingDict(Path('test.json'))
    config_dict.save()
    assert config_dict.path.exists()
    config_dict['a'] = 'b'
    config_dict.save()
    with config_dict.path.open() as f:
        assert json.load(f) == config_dict
    config_dict.delete()
    assert not config_dict.path.exists()



# Generated at 2022-06-11 23:14:45.021504
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import Config
    from httpie.compat import is_osx, is_windows
    try:
        path = Config().path
        os.rename(os.path.abspath(path.parent),os.path.abspath(path.parent) + '.backup')
        assert not os.path.exists(path.parent)
        Config().ensure_directory()
        assert os.path.exists(path.parent)
        os.rename(os.path.abspath(path.parent) + '.backup',os.path.abspath(path.parent))
    finally:
        assert os.path.exists(path.parent)
        src = os.path.abspath(path.parent)

# Generated at 2022-06-11 23:14:58.247672
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    import os.path
    import tempfile
    import unittest
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows

    class TestConfigDict(BaseConfigDict):
        name = 'foo'

    def get_default_config_dir():
        return Path(tempfile.gettempdir()) / DEFAULT_CONFIG_DIRNAME

    class TestConfigDict2(TestConfigDict):
        pass

    class Security:
        """A class that defines the necessary attributes for security to work
        because we muck with __builtins__"""
        class Skip: pass
        class TestCase(unittest.TestCase): pass
        class defaultTestLoader(unittest.defaultTestLoader): pass

# Generated at 2022-06-11 23:15:09.752605
# Unit test for function get_default_config_dir

# Generated at 2022-06-11 23:15:16.389895
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    import tempfile

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_config_file = Path(tmp_dir.name) / Config.FILENAME

    test_config = Config(directory=tmp_dir.name)

    test_config.save()
    assert tmp_config_file.exists()

    with open(tmp_config_file) as fh:
        output = json.load(fh)
        assert output == {'default_options': [], '__meta__': {'httpie': __version__}}

    assert test_config == {'default_options': [], '__meta__': {'httpie': __version__}}

    test_config['default_options'] = ['--form']
    test_config.save()

    assert tmp_config_file.exists()


# Generated at 2022-06-11 23:15:24.132479
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class ConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            self.directory = path
            self.path = path / 'config.json'
            super().__init__(self.path)
            self.update({
                '__meta__': {
                    'httpie': __version__
                },
                'default_options': [],
            })

    config_dir = Path(__file__).parent
    config = ConfigDict(config_dir)
    config.save(fail_silently=True)


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:15:34.276020
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Create a folder where we will save the config
    # and verify that the folder does not exist
    test_config_dir = Path('.test-config')
    assert not test_config_dir.exists()

    # Create an instance of BaseConfigDict, overwriting the
    # folder where the config is usually stored with the
    # temporary one
    test_config_dict = BaseConfigDict(test_config_dir)

    # Invoke method ensure_directory via the wrapper method save
    test_config_dict.save()

    # Verify that the folder is created
    assert test_config_dir.exists()

    # Remove the created folder
    test_config_dir.rmdir()
    assert not test_config_dir.exists()

# Generated at 2022-06-11 23:15:42.020568
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # windows
    if is_windows:
        assert get_default_config_dir() == Path(os.environ['APPDATA']) / 'httpie'

    # linux
    # 1. env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '$HOME/envconfig'
    assert get_default_config_dir() == Path('$HOME/envconfig')

    # 2. legacy
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    with tempfile.TemporaryDirectory() as tmpdir:
        os.mkdir(os.path.join(tmpdir, '.httpie'))
        os.environ['HOME'] = tmpdir
        assert get_default_config_dir() == Path(tmpdir) / '.httpie'

    # 3. xdg


# Generated at 2022-06-11 23:15:51.862452
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.utils import getenv
    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert Path(env_config_dir) == get_default_config_dir()

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG
    xdg_config_home = os

# Generated at 2022-06-11 23:16:02.658813
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = 'env_config_dir'
        assert get_default_config_dir() == 'env_config_dir'
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass

    try:
        os.environ[ENV_XDG_CONFIG_HOME] = 'xdg_config_home'
        assert get_default_config_dir() == 'xdg_config_home/httpie'
    except KeyError:
        pass
    finally:
        try:
            del os.environ[ENV_XDG_CONFIG_HOME]
        except KeyError:
            pass

    assert get_default_config_dir() == '~/.config/httpie'




# Generated at 2022-06-11 23:16:04.098422
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    results = get_default_config_dir()
    assert isinstance(results, Path)

# Generated at 2022-06-11 23:16:15.333273
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    except KeyError:
        pass
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    Path(str(DEFAULT_CONFIG_DIR)).parent.mkdir(exist_ok=True)
    config = Config(directory=DEFAULT_CONFIG_DIR)
    config.save()
    config.load()
    config.delete()

    Path(str(DEFAULT_CONFIG_DIR)).parent.rmdir()
    assert Path(os.path.expanduser("~/.httpie/config.json")) != DEFAULT_CONFIG_DIR, "Get default config directory failed!"



# Generated at 2022-06-11 23:16:19.278178
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir = Path('/tmp/test_dir')
    config = BaseConfigDict(path=test_dir)
    config.ensure_directory()
    assert os.access(config.path, os.W_OK)
    os.rmdir(config.path)



# Generated at 2022-06-11 23:16:24.290483
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('test.json')
    test = BaseConfigDict(path)
    test.update({'test1': 'test1'})
    test.update({'test2': 'test2'})
    test.save()
    assert path.exists()
    path.unlink()

# Generated at 2022-06-11 23:16:29.570249
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg_config_home'
    assert get_default_config_dir() == '/xdg_config_home' / 'httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/httpie_config_dir'
    assert get_default_config_dir() == '/httpie_config_dir'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-11 23:16:31.847826
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    a = BaseConfigDict("./config.json")
    a.save()
    assert Path("./config.json").exists()


# Generated at 2022-06-11 23:16:36.767222
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    DEFAULT_DIRECTORY = DEFAULT_CONFIG_DIR
    test_config = Config(directory=DEFAULT_DIRECTORY)
    assert not test_config.is_new()
    test_config.delete()
    assert test_config.is_new()
    test_config.save()
    assert not test_config.is_new()

# Generated at 2022-06-11 23:16:45.615463
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    for env_value in [
        # [expected_config_dir, env_xdg_config_home, env_httpie_config_dir]
        [DEFAULT_CONFIG_DIR, None, None],  # default
        [
            Path('/foo/bar'),
            '/foo/bar', None,
        ],  # XDG default
        [
            Path('/foo/bar/baz'),
            '/foo/bar', 'baz',
        ],  # XDG default with env override
        [Path('/foo/bar'), None, '/foo/bar'],  # env override
        [
            Path('C:/Users/user/AppData/Roaming/httpie'),
            None, None,
        ],  # Windows default
    ]:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = ''


# Generated at 2022-06-11 23:16:52.206784
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test get_default_config_dir
    """
    if is_windows:
        default_config_dir = get_default_config_dir()
        assert str(default_config_dir) == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        default_config_dir = get_default_config_dir()
        assert str(default_config_dir) == str(DEFAULT_RELATIVE_XDG_CONFIG_HOME)

# Generated at 2022-06-11 23:17:04.758843
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_file = 'config.json'

    # Test user configuration directory
    path = DEFAULT_CONFIG_DIR / config_file
    temp = BaseConfigDict(path)
    temp.ensure_directory()
    assert path.parent.exists() == True

    # Test legacy configuration directory
    legacy = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    path = legacy / config_file
    temp = BaseConfigDict(path)
    temp.ensure_directory()
    assert path.parent.exists() == True

    # Test new .config directory
    home = Path.home()
    path = home / '.config' / DEFAULT_CONFIG_DIRNAME / config_file
    temp = BaseConfigDict(path)
    temp.ensure_directory()
    assert path.parent

# Generated at 2022-06-11 23:17:06.013756
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-11 23:17:08.532947
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert type(config_dir) is Path
    assert config_dir.exists() is False



# Generated at 2022-06-11 23:17:19.058492
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    if not is_windows:
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
        assert get_default_config_dir() == Path(os.environ[ENV_XDG_CONFIG_HOME]) / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/foo'
    assert get_default_config_dir() == Path(os.environ[ENV_HTTPIE_CONFIG_DIR])

# Generated at 2022-06-11 23:17:24.356631
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('test.json')
    assert path.is_file() == False
    testDict = BaseConfigDict(path)
    testDict.load()
    assert len(testDict) == 0

    path.write_text("""{"prefs": {"foo": "bar"}, "default_options": []}""")
    testDict.load()
    assert testDict['foo'] == 'bar'


# Generated at 2022-06-11 23:17:25.980141
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config/httpie'



# Generated at 2022-06-11 23:17:27.728114
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    d = BaseConfigDict(path="../test")
    d.save()


# Generated at 2022-06-11 23:17:36.185667
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    def pop(env_var, default=None):
        try:
            return os.environ.pop(env_var)
        except KeyError:
            return default

    def is_default_xdg() -> bool:
        return get_default_config_dir() == (Path.home() / Path('.config') / DEFAULT_CONFIG_DIRNAME)

    def is_legacy() -> bool:
        return get_default_config_dir() == Path.home() / Path('.httpie')

    def is_xdg() -> bool:
        return get_default_config_dir() == Path('.xdg') / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-11 23:17:41.773060
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop('XDG_CONFIG_HOME', None)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:17:47.890499
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        name = 'Test'
        helpurl = 'helpurl'
        about = 'about'

    import tempfile
    TEMP_DIRECTORY = Path(tempfile.gettempdir())
    config = TestConfigDict(TEMP_DIRECTORY / 'TestConfig.json')
    config.save()

    assert not config.is_new()
    assert config.directory == TEMP_DIRECTORY
    assert config.name == 'Test'
    assert config.helpurl == 'helpurl'
    assert config.about == 'about'

    config['a'] = 'b'
    config.save()

    assert config['__meta__'] != None
    assert config['__meta__']['httpie'] != None
    assert config['__meta__']['help'] != None

# Generated at 2022-06-11 23:17:59.041499
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from pathlib import Path
    from httpie import __version__

    def get_config_dir():
        file_dir = Path(__file__).resolve().parent
        return file_dir / 'config_dir_test'

    config_dir = get_config_dir()
    config_path = config_dir / 'config.json'

    # Test config file not exist
    config_file_not_exist = BaseConfigDict(config_path)
    try:
        config_file_not_exist.load()
    except ConfigFileError as e:
        assert True

    # Test config file is invalid
    config_file_invalid = BaseConfigDict(config_path)
    if not config_dir.exists():
        config_dir.mkdir()

# Generated at 2022-06-11 23:18:10.715294
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    class Env(dict):
        """Mock os.environ"""
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.update(os.environ)

        def reset(self):
            self.update(os.environ)

    env = Env()
    config_dir = get_default_config_dir()
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    xdg_config_dir = xdg_config_home / DEFAULT_CONFIG_DIRNAME

    # Legacy config dir exists

# Generated at 2022-06-11 23:18:20.651554
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import os
    import os.path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from httpie.config import BaseConfigDict

    def test_load_normal(tmp_path):
        config_path = tmp_path / 'test.json'
        config_path.write_text('{"a": "b"}')
        config = BaseConfigDict(config_path)
        config.load()
        assert config['a'] == 'b'

    def test_load_json_error(tmp_path):
        config_path = tmp_path / 'test.json'
        config_path.write_text('{')  # invalid json
        config = BaseConfigDict(config_path)
        with pytest.raises(ConfigFileError) as exc_info:
            config.load()


# Generated at 2022-06-11 23:18:27.991263
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    Test the save method of BaseConfigDict in a mocked env.
    """
    import tempfile

    def mock_mkdir(path, *args, **kwargs):
        return

    def mock_unlink(path):
        return

    def mock_write_text(path, json_string):
        return

    class MockJsonDumpsObj(object):
        def __init__(self, response):
            self.response = response

        def dumps(self, obj, indent=4, sort_keys=True, ensure_ascii=True):
            return self.response

    def mock_dumps(self, indent=4, sort_keys=True, ensure_ascii=True):
        return '{"test": "unit"}\n'

    tmp_dir = Path(tempfile.gettempdir())
    temp

# Generated at 2022-06-11 23:18:31.476555
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir

    assert get_default_config_dir() == Path('.config') / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() != Path('.httpie')

# Generated at 2022-06-11 23:18:41.894615
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from shutil import rmtree
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    config_path = config_dir / Config.FILENAME
    def cleanup():
        rmtree(config_dir)
    # Make it easy to remove the config directory

# Generated at 2022-06-11 23:18:52.269171
# Unit test for function get_default_config_dir

# Generated at 2022-06-11 23:19:03.229278
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test the return value of function get_default_config_dir under different
    circumstances.

    """
    # 1.1. No explicit config directory and no previous ~/.httpie
    if is_windows:
        directory = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        directory = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == directory

    # 1.2. No explicit config directory (but previous ~/.httpie)
    default_config_dir = get_default_config_dir()
    default_config_dir.unlink()
    default_legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    default_legacy_config_dir.mk

# Generated at 2022-06-11 23:19:09.390599
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    import json
    import os
    import tempfile
    # create temp file to store the config
    temp = tempfile.TemporaryDirectory()
    test_file = Path(temp.name + '/config.json')
    # initialize a new BaseConfigDict
    test = BaseConfigDict(test_file)
    test.save()
    assert test_file.exists()
    with test_file.open() as f:
        data = json.load(f)
    assert data['__meta__']['httpie'] == __version__
    temp.cleanup()


# Generated at 2022-06-11 23:19:11.101009
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / ".config" / "httpie"

# Generated at 2022-06-11 23:19:24.555296
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import tempfile
    import shutil
    import errno

    def get_temp_dirname() -> str:
        return tempfile.mkdtemp(prefix='httpie-test-')

    # 1. explicitly set through env
    with tempfile.TemporaryDirectory() as temp_dirname:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = temp_dirname
        config_dir = get_default_config_dir()
        assert config_dir == Path(temp_dirname)

    # 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    with tempfile.TemporaryDirectory() as temp_dirname:
        legacy_dir = Path(temp_dirname) / DEFAULT_RELATIVE_LEG

# Generated at 2022-06-11 23:19:32.049499
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    context = {}
    config_dir = get_default_config_dir()
    context["config_dir"] = config_dir
    config_dir_win = Path('C:\\Users\\test_user\\AppData\\Roaming\\httpie')
    config_dir_xdg_explicit = Path('/home/test_user/.config/httpie')
    config_dir_xdg_default = Path('/home/test_user/.config/httpie')
    config_dir_legacy = Path('/home/test_user/.httpie')
    assert isinstance(config_dir, Path)


# Generated at 2022-06-11 23:19:33.932822
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR



# Generated at 2022-06-11 23:19:42.027611
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    Path('/tmp/test').mkdir(mode=0o700, parents=True)
    os.environ['HOME'] = '/tmp/test'
    config_dir = get_default_config_dir()
    assert config_dir == Path('/tmp/test/.config/httpie')

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/test/httpie'
    config_dir = get_default_config_dir()
    assert config_dir == Path('/tmp/test/httpie')

    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/test/config'
    config_dir = get_default_config_dir()
    assert config_dir == Path('/tmp/test/config/httpie')


# Generated at 2022-06-11 23:19:49.891197
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create empty directory for temporary config file
    config_path = Path.home() / 'empty_with_no_permission'
    config_path.mkdir()
    config_path.chmod(mode=0o000)
    # initialize empty config file
    config_file = BaseConfigDict(config_path / 'test_config.json')
    config_file['test'] = "test_config"
    config_file.save()
    assert not Path(config_file.path).exists()
    # remove temporary files
    config_path.chmod(mode=0o700)
    config_path.rmdir()

# Generated at 2022-06-11 23:19:57.222203
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    try:
        config_dict = BaseConfigDict('./test.json')
        # a new file cannot be saved
        assert config_dict.save() == None
        # write a dictionary to the new file
        config_dict['name'] = 'test'
        config_dict.save()
        with open('./test.json', 'r') as json_file:
            data = json.load(json_file)
        assert data == config_dict
    except:
        print('Fail')
    finally:
        os.remove('./test.json')

# Generated at 2022-06-11 23:20:03.481745
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create new config file
    config_file_path = Path('config.json')
    f = open('config.json', 'w')
    f.write('{"test":"test"}')
    f.close()
    # create new BaseConfigDict
    config = BaseConfigDict(config_file_path)
    config.load()
    # assert data
    assert 'test' in config.keys()
    assert config['test'] == 'test'
    # delete file
    config_file_path.unlink()


# Generated at 2022-06-11 23:20:10.829160
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_environ = dict(os.environ)

# Generated at 2022-06-11 23:20:15.118595
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / ".config" / "httpie"
    assert get_default_config_dir() == Path(DEFAULT_CONFIG_DIR)
    assert get_default_config_dir() == Path(get_default_config_dir())



# Generated at 2022-06-11 23:20:20.845867
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Config().directory
    test_file = config_dir / "test.json"

    dict = BaseConfigDict(test_file)
    dict['key'] = 'value'
    dict.save()

    with open(test_file) as f:
        json_data = f.read()

    assert '"key": "value"' in json_data
    assert '"httpie": "' + __version__ + '"' in json_data

    test_file.unlink()


# Generated at 2022-06-11 23:20:25.545607
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	config = BaseConfigDict(path = Path("test.json"))
	config.load()
	print(config)


# Generated at 2022-06-11 23:20:34.759469
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    expected = Path('/foo/bar')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(expected)
    assert get_default_config_dir() == expected
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
        return

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(parents=True)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(legacy_config_dir)

# Generated at 2022-06-11 23:20:36.542260
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert os.getcwd() in str(get_default_config_dir())

# Generated at 2022-06-11 23:20:45.389278
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create an instance of BaseConfigDict
    config = BaseConfigDict(Path('test.json'))

    # Create an empty dictionary, and set proper value to the dictionary
    data = {}
    data.update({"key": "value"})
    data.update({"__meta__": {"httpie": "1.0.3"}})

    # Set the dictionary to self, and call save method
    config.update(data)
    config.save()

    # Load the file and compare with data, then remove the file
    assert data == json.load(open('test.json', 'r'))
    os.remove('test.json')


# Generated at 2022-06-11 23:20:55.881041
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        import pytest
        pytest.skip("skipping unit test because pytest exists")
    except ImportError:
        pass
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / '.config')
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = str(Path.home() / '.config' / 'xdg')
    assert get_default_config_dir() == Path.home() / '.config' / 'xdg' / 'httpie'


# Generated at 2022-06-11 23:21:05.228927
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_path = Path.cwd() / 'test.json'

    # 1. Assert empty
    default_config_dict = BaseConfigDict(path=test_path)
    if test_path.exists():
        raise Exception("test.json file should not exist")
    assert default_config_dict.is_new()

    # 2. Create file, write sample data and assert not empty
    sample_data = '{"test":"test"}'
    test_path.write_text(sample_data + '\n')
    default_config_dict.load()
    default_config_dict.update(json.loads(sample_data))
    assert "test" in default_config_dict 
    assert default_config_dict["test"] == "test"

    # 3. Test is not new anymore
    assert not default_config_

# Generated at 2022-06-11 23:21:15.779362
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    PLATFORM_DEFAULT = None
    if os.name == 'posix':
        PLATFORM_DEFAULT = os.path.expanduser('~/.config/httpie')
    if os.name == 'nt' or sys.platform == 'cygwin':
        PLATFORM_DEFAULT = os.path.expandvars('%APPDATA%/httpie')

    assert get_default_config_dir() == Path(PLATFORM_DEFAULT)
    
    prev_env = os.getenv('HTTPIE_CONFIG_DIR')
    os.environ["HTTPIE_CONFIG_DIR"] = "/some/other/path"
    assert get_default_config_dir() == Path("/some/other/path")
    os.environ["HTTPIE_CONFIG_DIR"] = prev_env

# Generated at 2022-06-11 23:21:17.595053
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert Config().directory == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:21:26.268702
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    a_dir = Path(DEFAULT_CONFIG_DIR) / 'a_dir'
    a_config = Path(a_dir) / 'a_config'
    if a_dir.exists():
        a_dir.rmdir()
    if a_config.exists():
        a_config.unlink()
    bcd = BaseConfigDict(a_config)
    bcd['cid'] = 'abc'
    bcd.save()
    bcd['cid'] = 'xyz'
    bcd.load()
    assert 'abc' == bcd['cid']  # load() should restore the configuration
    a_config.unlink()
    a_dir.rmdir()


# Generated at 2022-06-11 23:21:27.100145
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Config().directory

# Generated at 2022-06-11 23:21:42.731972
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/Users/Web_Dev/config"
    assert get_default_config_dir() == Path("/Users/Web_Dev/config")

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ["HOME"] = "/Users/Web_Dev"
    assert get_default_config_dir() == Path("/Users/Web_Dev/.config/httpie")

    del os.environ["HOME"]
    assert not os.path.exists("/Users/Web_Dev")
    assert get_default_config_dir() == Path("/.config/httpie")



# Generated at 2022-06-11 23:21:46.180622
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class DummyConfigDict(BaseConfigDict):
        pass

    config = DummyConfigDict(Path(__file__))
    config.load()
    assert config['__meta__']['httpie'] == __version__

# Generated at 2022-06-11 23:21:53.348190
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_dict_data = {'1': 1, '2': 2}
    test_config_dict = BaseConfigDict('fixtures/test_config.txt')
    test_config_dict.update(test_dict_data)
    test_config_dict.save()
    with open('fixtures/test_config.txt', mode='rt') as f:
        assert f.read() == '{\n    "1": 1,\n    "2": 2\n}', (
            'Error: the dict data is not saved to file properly')
    os.remove('fixtures/test_config.txt')



# Generated at 2022-06-11 23:21:58.092945
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test wrong json file
    try:
        config_dic = BaseConfigDict(path=Path('wrong.json'))
        config_dic.load()
    except ConfigFileError:
        pass
    except:
        raise AssertionError('Expected exception=ConfigFileError')



# Generated at 2022-06-11 23:22:05.989213
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Default config dir
    assert (
        get_default_config_dir() ==
        Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    )
    # Explicit config dir
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foo'
    assert (
        get_default_config_dir() ==
        Path('foo')
    )
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    # On Windows
    if is_windows:
        assert (
            get_default_config_dir() ==
            Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        )
    else:
        # XDG config dir
        os.en