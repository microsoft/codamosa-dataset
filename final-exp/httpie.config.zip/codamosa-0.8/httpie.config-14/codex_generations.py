

# Generated at 2022-06-11 23:12:14.096557
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from mock import patch

    with patch.dict(os.environ, {}, clear=True):
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    with patch.dict(os.environ, {ENV_XDG_CONFIG_HOME: 'test'}, clear=True):
        assert get_default_config_dir() == Path('test') / DEFAULT_CONFIG_DIRNAME

    with patch.dict(os.environ, {ENV_HTTPIE_CONFIG_DIR: 'test'}, clear=True):
        assert get_default_config_dir() == Path('test')



# Generated at 2022-06-11 23:12:16.391664
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert '/home/test/.config/httpie' == str(get_default_config_dir())

# Generated at 2022-06-11 23:12:26.357317
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie import environment
    from httpie.context import Environment
    from httpie.config import ConfigDict

    env = Environment(
        directory=environment.get_config_dir(),
        config_path=environment.get_config_path(),
        config_dir=environment.get_config_dir(),
        auth_file=environment.get_auth_file_path(),
        netrc_file=environment.get_netrc_file_path(),
        defaults_file=environment.get_defaults_file_path(),
        defaults=ConfigDict(),
        config_dir_exists=False,
        is_windows=False
    )

    config_filename = 'c.json'
    config = ConfigDict(path=env.directory / config_filename)
    config['a'] = 'b'


# Generated at 2022-06-11 23:12:37.028817
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
    else:
        assert get_default_config_dir() == Path(
            os.environ.get(  # 1. explicit
                ENV_XDG_CONFIG_HOME,
                # 2. default
                home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME,
            )
        ) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:12:40.897806
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    home_user = os.environ.get('HOME')
    config_dir = home_user + "/.config/httpie"
    config_path = config_dir + '/config.json'
    tcd = BaseConfigDict(path=config_path)
    tcd.save()

if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:12:51.946039
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict(os.environ):
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
        with mock.patch('httpie.config.is_windows', False):

            def mock_path_home():
                return '/home/foo'
            mock_home = mock.patch('pathlib.Path.home', mock_path_home)
            with mock_home:
                assert (get_default_config_dir() ==
                        Path('/home/foo/.config/httpie'))

            def mock_path_exists(path):
                if (path == Path('/home/foo/.config/httpie') or
                        path == Path('/etc/xdg')):
                    return False
                else:
                    raise NotImplementedError()
            mock_exists = mock.patch

# Generated at 2022-06-11 23:12:53.371958
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:13:03.383470
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory(prefix='httpie-config-') as temp_dir:
        # is_new and save at one time
        path = Path(temp_dir) / 'test.json'
        test_config = BaseConfigDict(path=path)
        assert test_config.is_new()
        test_config.save()
        assert not test_config.is_new()

        # save again
        test_config['key1'] = 'value1'
        test_config.save()

        # check the file
        test_config_file = path.open('r')
        lines = test_config_file.readlines()
        assert lines[0] == '{\n'
        assert lines[-2] == '    "__meta__": {\n'
       

# Generated at 2022-06-11 23:13:05.002581
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:13:08.628330
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() != Path.home() / '.httpie'
    assert get_default_config_dir() != Path.home() / '.config' / 'httpie'



# Generated at 2022-06-11 23:13:23.033882
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    old_appdata = os.environ.get('APPDATA')
    old_xdg_config_home = os.environ.get('XDG_CONFIG_HOME')
    

# Generated at 2022-06-11 23:13:34.264128
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_XDG_CONFIG_HOME] = 'xdg-path'
    assert str(get_default_config_dir()) == 'xdg-path/httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'httpie-path'
    assert str(get_default_config_dir()) == 'httpie-path'

    del os.environ[ENV_XDG_CONFIG_HOME]
    assert str(get_default_config_dir()) == 'httpie-path'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert str(get_default_config_dir()) == str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)

# Generated at 2022-06-11 23:13:47.115873
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import mkdtemp
    from shutil import rmtree
    from functools import partial

    # All the tests here are based on the Config class.
    # Let's create a Config class with a temporary directory
    # The directory will free when the program exit.
    TempDir = partial(Config, mkdtemp())
    # Delete the temporary directory after the test
    def cleanup(dir): 
        rmtree(dir)

    # Test saving empty file
    # Test file to save
    empty_file = TempDir()
    # Test if directory is created
    assert empty_file.directory.exists()
    # Test if the file to save exists
    assert not empty_file.path.exists()
    # Save the file
    empty_file.save()
    # Test if the file is saved

# Generated at 2022-06-11 23:13:50.843113
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict = BaseConfigDict(path=DEFAULT_CONFIG_DIR / Config.FILENAME)
    base_config_dict.ensure_directory()
    assert DEFAULT_CONFIG_DIR.exists()
    DEFAULT_CONFIG_DIR.rmdir()

# Generated at 2022-06-11 23:13:54.309128
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a directory for this test
    config = BaseConfigDict('/tmp/test_httpie_config')
    config['test1'] = 'test1'
    config['test3'] = 'test3'
    config['test2'] = 'test2'
    # save config
    config.save()

# Generated at 2022-06-11 23:13:59.831122
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def get_dir(env):
        os.environ[ENV_XDG_CONFIG_HOME] = env
        dir = get_default_config_dir()
        os.environ.pop(ENV_XDG_CONFIG_HOME)
        return dir

    assert get_dir('/foo') == Path('/foo') / DEFAULT_CONFIG_DIRNAME
    assert get_dir('/bar/') == Path('/bar') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:14:06.734479
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    # setup
    file = tempfile.mktemp()
    config = BaseConfigDict(Path(file))
    config[1] = 2
    # test
    config.save()

    # verify
    with open(file, 'r') as f:
        read_data = f.read()

    assert read_data == '{\n    "1": 2, \n    "__meta__": {\n        "httpie": "0.9.9"\n    }\n}\n'

# Generated at 2022-06-11 23:14:14.423150
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def sha1_hash(s):
        import hashlib
        return hashlib.sha1(s).hexdigest()

    import tempfile
    d = tempfile.mkdtemp()
    config_dir = Path(d) / 'test_httpie' / 'config.json'
    config_dir_sha1 = sha1_hash(str(config_dir))

    import os
    os.environ['HTTPIE_CONFIG_DIR'] = d

    mconfig = BaseConfigDict(path=config_dir)
    mconfig.ensure_directory()

    assert (Path(d) / 'test_httpie').is_dir()

    config_dir_new = Path(d) / 'test_httpie' / 'config.json'

# Generated at 2022-06-11 23:14:16.171994
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:14:21.687855
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmp_file = Path('/tmp/httpie/test.json')
    tmp_file.parent.mkdir(mode=0o700, parents=True)
    tmp_file.parent.rmdir()
    config = BaseConfigDict(path=Path('/tmp/httpie/test.json'))
    config.ensure_directory()
    assert tmp_file.parent.exists() is True
    tmp_file.parent.rmdir()


# Generated at 2022-06-11 23:14:31.326984
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_file = Path("./test_file")
    test_file.unlink(missing_ok=True)
    assert test_file.exists() == False

    class TmpConfig(BaseConfigDict):
        name = "test_config"
        helpurl = "test_helpurl"
        about = "test_about"

    config = TmpConfig(test_file)
    config.save()

    assert test_file.exists()
    with test_file.open('r') as f:
        json_config = json.load(f)
        assert json_config['__meta__']['httpie'] == __version__
        assert json_config['__meta__']['help'] == "test_helpurl"
        assert json_config['__meta__']['about'] == "test_about"



# Generated at 2022-06-11 23:14:33.833098
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(Path('Test1').parent)
    config_dict.ensure_directory()



# Generated at 2022-06-11 23:14:43.256403
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import get_default_config_dir
    config_dir = get_default_config_dir()
    assert config_dir.exists()
    # create config file for test
    class ConfigDictForTest(BaseConfigDict):
        def save(self):
            self.path = config_dir / 'config.json'
            super().save()
            assert self.path.exists()
    BaseConfigDictForTest = ConfigDictForTest()
    # test method save
    BaseConfigDictForTest.save()
    # del config file for test
    BaseConfigDictForTest.path.unlink()
    assert not BaseConfigDictForTest.path.exists()


# Generated at 2022-06-11 23:14:54.366372
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def assert_dir(dir_name):
        if dir_name.exists():
            dir_name.rmdir()
        subdir_name = dir_name / 'sub_dir'
        subdir_name.mkdir()
        subdir_name.rmdir()
        d = BaseConfigDict(dir_name)
        d.ensure_directory()
        assert dir_name.exists()
        assert subdir_name.exists()
    temp_dir = Path('temp_dir')
    assert_dir(temp_dir)
    temp_dir.rmdir()
    temp_dir_parent = temp_dir / 'parent'
    assert_dir(temp_dir_parent)
    rmdir_recursive(temp_dir)



# Generated at 2022-06-11 23:15:07.684653
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test 1
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test 2
    httpie_config_dir = '/foo/bar'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = httpie_config_dir
    assert get_default_config_dir() == httpie_config_dir

    # Test 3
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # Test 4
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700)
    assert get_default_config_dir() == legacy_config_dir



# Generated at 2022-06-11 23:15:15.317444
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import pytest
    import httpie

    # Test environment: Windows
    os.environ[httpie.core.config.ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[httpie.core.config.ENV_XDG_CONFIG_HOME] = ''
    httpie.core.config.DEFAULT_CONFIG_DIR = httpie.core.config.get_default_config_dir()
    assert httpie.core.config.DEFAULT_CONFIG_DIR == httpie.core.config.DEFAULT_WINDOWS_CONFIG_DIR

    # Test environment: MacOS
    os.environ[httpie.core.config.ENV_HTTPIE_CONFIG_DIR] = ''

# Generated at 2022-06-11 23:15:23.727378
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    configdir = Path('/tmp/httpie_test/testdir')
    if configdir.exists():
        try:
            configdir.unlink()
        except OSError as e:
            if e.errno != errno.ENOENT:
                raise

    class TestConfig(BaseConfigDict):
        name = 'test_config'
    test_config = TestConfig(configdir)
    test_config.ensure_directory()

    assert configdir.exists()
    assert configdir.is_dir()

    testdir_parent = Path('/tmp/httpie_test')
    configdir.unlink()
    testdir_parent.rmdir()

# Generated at 2022-06-11 23:15:29.332215
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    try:
        with tempfile.TemporaryDirectory() as tempdir:
            tmp_path = Path(tempdir)
            config_dict = BaseConfigDict(tmp_path)
            config_dict.ensure_directory()
            if not os.listdir(tempdir):
                assert(True)
            else:
                assert(False)
    except OSError:
        assert(False)



# Generated at 2022-06-11 23:15:30.919854
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:15:36.991496
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TmpConfigDict(BaseConfigDict):
        def __init__(self):
            super().__init__(Path('/tmp/tmp'))

    d = TmpConfigDict()
    d['k'] = 1
    d.save()
    with open('/tmp/tmp', 'r') as f:
        assert f.read() == '{"k": 1}'

# Generated at 2022-06-11 23:15:50.683219
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ = {}
    assert get_default_config_dir() == DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicitly/set'
    assert get_default_config_dir() == Path('/explicitly/set')
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicitly/set'

# Generated at 2022-06-11 23:15:55.628680
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    :return: True if _get_default_config_dir works as expected.
    """
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-11 23:15:57.619375
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(Path.home(), ".config", "httpie")



# Generated at 2022-06-11 23:16:08.101037
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ['HOME'] = '/home/username'
    assert get_default_config_dir() == Path('/home/username/.config/httpie')

    os.environ['XDG_CONFIG_HOME'] = '/path/to/config'
    assert get_default_config_dir() == Path('/path/to/config/httpie')

    os.environ['XDG_CONFIG_HOME'] = ''
    assert get_default_config_dir() == Path('/home/username/.config/httpie')

    del os.environ['XDG_CONFIG_HOME']
    assert get_default_config_dir() == Path('/home/username/.config/httpie')

    del os.environ['HOME']
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_

# Generated at 2022-06-11 23:16:10.285730
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:16:14.172438
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    assert (Path.home() / '.config' / 'httpie').is_dir() is True

# Generated at 2022-06-11 23:16:15.430970
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('/test/.httpie')
    config_path = config_dir / 'test_config.json'
    config = BaseConfigDict(config_path)
    config.save()
    assert config_path.exists()

# Generated at 2022-06-11 23:16:18.339564
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_dir = Path('.config') / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == expected_dir, \
        'Default config directory doesn\'t match'



# Generated at 2022-06-11 23:16:29.989072
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict, ConfigFileError
    from httpie.plugins import builtin

    from tempfile import TemporaryDirectory
    from httpie.compat import is_windows

    import os

    config_dir_path = TemporaryDirectory().name
    config_file_path = os.path.join(config_dir_path, 'config.json')

    config = BaseConfigDict(config_file_path)
    assert isinstance(config, BaseConfigDict)

    config.ensure_directory()
    config.save()

    config2 = BaseConfigDict(config_file_path)
    config2.ensure_directory()
    assert config2.is_new()
    config2.save()
    assert not config2.is_new()

    config3 = BaseConfigDict(config_file_path)

# Generated at 2022-06-11 23:16:30.579382
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    assert True

# Generated at 2022-06-11 23:16:40.298805
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    e_path = os.path.join(os.getcwd(), ".config")
    if os.getenv(ENV_XDG_CONFIG_HOME):
        e_path = os.getenv(ENV_XDG_CONFIG_HOME)
    e_path = os.path.join(e_path, DEFAULT_CONFIG_DIRNAME)

    assert str(DEFAULT_CONFIG_DIR) == str(Path(e_path))



# Generated at 2022-06-11 23:16:47.069557
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def reset_env():
        to_reset = {'XDG_CONFIG_HOME'}
        for key in to_reset:
            if key in os.environ:
                del os.environ[key]

    home_dir = os.path.expanduser('~')
    reset_env()
    assert get_default_config_dir() == os.path.normpath(
        f'{home_dir}/.config/httpie')
    os.environ['XDG_CONFIG_HOME'] = '/tmp/does-not-exist'
    assert get_default_config_dir() == os.path.normpath(
        '/tmp/does-not-exist/httpie')
    os.environ['XDG_CONFIG_HOME'] = '/tmp/exists'
    assert get_default_config

# Generated at 2022-06-11 23:16:57.771202
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def stub_os_environ_get(name):
        if name == ENV_HTTPIE_CONFIG_DIR:
            return None
        elif name == ENV_XDG_CONFIG_HOME:
            return '/my/xdg_config_home'
        else:
            return NotImplementedError(name)

    # case: Windows
    def stub_is_windows():
        return True

    # case: no env vars are set
    def stub_is_windows():
        return False

    def stub_os_path_expandvars(v):
        if v == '%APPDATA%':
            return '/my/appdata_dir'
        else:
            return NotImplementedError(v)

    # case: ENV_HTTPIE_CONFIG_DIR is set

# Generated at 2022-06-11 23:17:06.462866
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    This test is to check if the save method would raise an expected error
    when the parent directory of the config file cannot be created.
    """
    import pytest
    class DummyConfigDict(BaseConfigDict):
        name = 'dummy'
        helpurl = 'http://example.com/help'
        about = 'Dummy Config'
    dummy_config = DummyConfigDict(path=Path('/a/b/c/dummy.json'))
    dummy_config['key'] = 'value'
    with pytest.raises(ConfigFileError) as excinfo:
        dummy_config.save()
    assert 'cannot create' in str(excinfo.value)

# Generated at 2022-06-11 23:17:17.423961
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    import shutil
    import tempfile
    from pathlib import Path

    class TestConfig(BaseConfigDict):
        '''
        A simple class to test saving data
        '''
        def __init__(self, dir_test):
            super().__init__(path=dir_test)
            self.update({
                'foo': 'bar',
                'baz': True,
                'blah': [1, 2, 3],
                '__meta__': {
                    'help': 'http://www.example.com/help/',
                    'about': 'http://www.example.com/about/'
                }
            })

    # Create a temporary directory

# Generated at 2022-06-11 23:17:26.663185
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    test_dict = {
        'windows': DEFAULT_WINDOWS_CONFIG_DIR,
        'posix, new': DEFAULT_CONFIG_DIR,
        'posix, old': Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR,
    }
    result_dict = {}
    for os_type in ['posix', 'windows']:
        for config_style in ['new', 'old']:
            os.environ = {}
            is_windows.cache_clear()
            if os_type == 'posix':
                is_windows.return_value = False
                if config_style == 'old':
                    with mock.patch('httpie.config.Path.home') as mock_home:
                        mock_home.return_value = Path('test_home')

# Generated at 2022-06-11 23:17:35.462350
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    expected_config_dir = Path(os.environ.get('XDG_CONFIG_HOME', '~/.config')) / 'httpie'
    result = get_default_config_dir()
    assert result == expected_config_dir


    def setUp(self):
        super().setUp()
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    def tearDown(self):
        super().tearDown()
        os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    def test_default_if_nothing_set(self):
        expected_config_dir = Path(os.environ.get(ENV_XDG_CONFIG_HOME, '~/.config')) / DEFAULT_CONFIG_DIRNAME
        assert get_default

# Generated at 2022-06-11 23:17:43.768157
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    directory = 'httpie_test'
    filename = 'config_test.json'
    config_file = Path(directory) / filename
    if config_file.exists():
        os.remove(config_file)

    config = Config(directory)
    assert not config_file.exists()
    config.save()
    assert config_file.exists()
    config.load()
    config['default_options'] = ['--form']
    config['__meta__'] = 'httpie'
    config.save()
    config['__meta__'] = 'h'
    config.save()
    os.remove(config_file)



# Generated at 2022-06-11 23:17:51.184126
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	config_dict = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
	config_dict['name'] = 'config.json'
	config_dict['helpurl'] = 'http://test.test'
	config_dict['about'] = 'test'
	config_dict.ensure_directory()
	config_dict.save()
	config_dict_new = BaseConfigDict(path=DEFAULT_CONFIG_DIR / 'config.json')
	config_dict_new.load()
	assert config_dict_new['name'] == 'config.json'
	config_dict.delete()
	

# Generated at 2022-06-11 23:17:58.686260
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        config = BaseConfigDict(path=tmpdirname / 'testfile.json')
        config.save()
        assert (tmpdirname / 'testfile.json').exists()
        assert (tmpdirname / 'testfile.json').is_file()
        with (tmpdirname / 'testfile.json').open('rt') as f:
            data = json.load(f)
            assert data == {}
        config['foo'] = 'bar'
        config.save()
        with (tmpdirname / 'testfile.json').open('rt') as f:
            data = json.load(f)
            assert data['foo'] == 'bar'


# Generated at 2022-06-11 23:18:07.211617
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:18:17.489502
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import sys
    import os
    import tempfile

    def assert_config_dir(expected: Path, env: dict = None):
        old_environ = os.environ.copy()
        old_platform = sys.platform
        old_config_dir = DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:18:19.273144
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config/httpie'



# Generated at 2022-06-11 23:18:27.167052
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass

    try:
        del os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        pass

    home_dir = Path.home()

    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir()

    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    xdg_config_home_dir.mkdir(parents=True)

    # Given: HTTPIE_CONFIG_DIR exists

# Generated at 2022-06-11 23:18:37.214615
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test on Linux
    os.environ[ENV_HTTPIE_CONFIG_DIR] = None
    os.environ[ENV_XDG_CONFIG_HOME] = None
    httpie_config_dir = Path(
        get_default_config_dir()
    )
    assert httpie_config_dir == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # Test on Linux with $XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/config_home'
    httpie_config_dir = Path(
        get_default_config_dir()
    )
    assert httpie_config_dir == Path('/tmp/config_home') / DEFAULT_CON

# Generated at 2022-06-11 23:18:44.894719
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    x = BaseConfigDict(path = 'config.json')
    x.__setitem__('key1','value1')
    x.__setitem__('key2','value2')

    x.save()

    # Now, let's read the file
    y = BaseConfigDict(path = 'config.json')
    y.load()

    assert(y.__len__() == 2)
    assert(y.__getitem__('key1') == 'value1')
    assert(y.__getitem__('key2') == 'value2')



# Generated at 2022-06-11 23:18:53.773325
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    n = "unit test result"
    config_dir = Path.cwd() / "test"
    config = BaseConfigDict(path=config_dir / "test_BaseConfigDict_save.json")
    try:
        config.save()
        with config.path.open('rt') as f:
            data = json.load(f)
        assert data["__meta__"]["httpie"] == __version__
    except AssertionError:
        n = "AssertionError: unit test result"
    except Exception:
        n = "Exception: unit test result"
    finally:
        os.remove(config.path)
        return n



# Generated at 2022-06-11 23:19:04.662145
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestBaseConfigDict(BaseConfigDict):
        FILENAME = 'test_BaseConfigDict.json'

    fail_path = Path('fail_path_for_test')
    failed_file = TestBaseConfigDict(fail_path)
    assert False == failed_file.is_new()

    with open('test_data/config.json', 'wb') as f:
        f.write(2)
    failed_file = TestBaseConfigDict(fail_path)
    assert False == failed_file.load()

    with open('test_data/config.json', 'w') as f:
        f.write('')
    failed_file = TestBaseConfigDict(fail_path)
    assert False == failed_file.load()


# Generated at 2022-06-11 23:19:13.723881
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_file = Path('test_file')
    if test_file.exists():
        test_file.unlink()
    config = BaseConfigDict(test_file)
    assert config.load() == None
    assert config.keys() == dict_keys(['__meta__'])
    test_file.write_text('{"test":"test"}')
    assert config.load() == None
    assert config.keys() == dict_keys(['__meta__', 'test'])
    assert config['test'] == 'test'
    test_file.write_text('{"test":[1,2,3]}')
    assert config.load() == None
    assert config['test'] == [1, 2, 3]
    test_file.write_text('{1:2}')
    assert config.load() != None
    test

# Generated at 2022-06-11 23:19:24.513986
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    env_config_dir = "test"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = env_config_dir
    assert get_default_config_dir() == Path(env_config_dir)
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-11 23:19:37.652856
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    bcd = BaseConfigDict(Path('.'))
    bcd.ensure_directory()
    bcd.save()



# Generated at 2022-06-11 23:19:44.394123
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from pathlib import Path
    from httpie.config import BaseConfigDict

    class MyBaseConfigDict(BaseConfigDict):
        pass

    data = {"default_options": []}
    path = Path('./tmp/MyBaseConfigDict.json')
    if path.exists():
        path.unlink()

    myBaseConfigDict = MyBaseConfigDict(path)
    myBaseConfigDict.update(data)
    myBaseConfigDict.save()

    assert path.exists()

    shutil.rmtree("./tmp")

# Generated at 2022-06-11 23:19:54.436418
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # This method save the configuration in a json file
    import random
    random.seed(__file__)
    # Create a new class that inherit from BaseConfigDict
    class ConfigDict(BaseConfigDict):
        pass
    # Create an object of the new class
    config = ConfigDict({})
    # Create a temporary directory
    import tempfile
    tmp_dir = Path(tempfile.mkdtemp())
    # Create a configuration file
    # The name of the file is the name of the class: ConfigDict.FILENAME
    file_name = tmp_dir / ConfigDict.FILENAME
    # Set the path to the configuration file
    config.path = file_name
    # Save the configuration file
    config.save()
    # Check if the configuration file has been created
    assert file_name.exists()

# Generated at 2022-06-11 23:19:56.590266
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = BaseConfigDict(Path("./config.json"))
    config_dict.load()
    assert True


# Generated at 2022-06-11 23:20:06.801135
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    '''
    Test saving a config file.
    '''

    # setting up a temporary directory
    path_to_config_dir = Path(DEFAULT_CONFIG_DIR)
    path_to_config_dir.mkdir(parents=True)

    # create a config
    config_dict = BaseConfigDict()
    config_dict['a'] = 5

    # save it
    config_dict.save(path_to_config_dir / 'temp.json', fail_silently=True)

    # check if the file was created and if the content is correct
    assert (path_to_config_dir / 'temp.json').exists()

# Generated at 2022-06-11 23:20:10.913937
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class MyConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    config = MyConfig(path=Path('tests/fixtures/config_no_exist.json'))
    assert config["__meta__"] == {}


# Generated at 2022-06-11 23:20:20.451284
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    assert get_default_config_dir() == str(DEFAULT_WINDOWS_CONFIG_DIR)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '.'
    assert get_default_config_dir() == '.'
    assert get_default_config_dir() == Path.cwd()
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    if not is_windows:
        # NOTE:    This test is flaky, since who knows what other tests have done
        #          to ~/.httpie/.
        legacy_config_dir = home_dir / DEFAULT_REL

# Generated at 2022-06-11 23:20:25.766622
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(
        os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/foo'
    assert get_default_config_dir() == Path('/tmp/foo/httpie')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/bar'
    assert get_default_config_dir() == Path('/tmp/bar')

# Generated at 2022-06-11 23:20:34.939417
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from os import environ

    # 1. explicitly set through env
    parent_dir = '/some/parent/dir'
    environ[ENV_HTTPIE_CONFIG_DIR] = parent_dir
    assert get_default_config_dir() == Path(parent_dir)
    del environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if not legacy_config_dir.exists():
        legacy_config_dir.mkdir()
    assert get_default_config_dir

# Generated at 2022-06-11 23:20:45.673081
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import sys
    import unittest
    if sys.platform == "win32":
        import tempfile

        class Win32TestCase(unittest.TestCase):
            def test_default(self):
                def _check(exp_str=None):
                    res = get_default_config_dir()
                    self.assertEqual(str(res), exp_str)

                _check(DEFAULT_WINDOWS_CONFIG_DIR)

                os.environ[ENV_HTTPIE_CONFIG_DIR] = "test"

# Generated at 2022-06-11 23:21:11.330935
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path("./tmp")
    dict = BaseConfigDict(path = path)
    dict['__meta__'] = {
        'httpie': __version__
    }
    dict.save()
    assert path.exists()
    assert path.is_file()
    path.unlink()

# Generated at 2022-06-11 23:21:17.427301
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    _file = Path('./test_httpie_config.json')

    config = BaseConfigDict(_file)
    config['key1'] = 'value1'
    config['key2'] = [1, 2, 3]
    config['key3'] = True

    config.save()

    config.clear()
    config.load()

    assert config['key1'] == 'value1'
    assert config['key2'] == [1, 2, 3]
    assert config['key3'] == True

# Generated at 2022-06-11 23:21:18.694366
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert os.path.exists(get_default_config_dir())

# Generated at 2022-06-11 23:21:28.030606
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('~/.config/httpie')

    os.environ.update({'HTTPIE_CONFIG_DIR': '/my/dir'})
    assert get_default_config_dir() == Path('/my/dir')

    os.environ.update({'HTTPIE_CONFIG_DIR': 'relative/path'})
    assert get_default_config_dir() == Path('relative/path')

    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    else:
        os.environ.pop('HTTPIE_CONFIG_DIR')

# Generated at 2022-06-11 23:21:30.683619
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_XDG_CONFIG_HOME] = '/some/dir'
    assert get_default_config_dir() == Path('/some/dir') / 'httpie'
    os.environ.pop(ENV_XDG_CONFIG_HOME)

# Generated at 2022-06-11 23:21:34.515137
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_path = Path('test_httpie_config.json')
    config_path.touch()
    c= BaseConfigDict(config_path)
    c['test_key'] = 'test_value'
    c.save(fail_silently=True)
    config_path.unlink()

# Generated at 2022-06-11 23:21:44.197050
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        pass

    # Create a dict
    cfg = TestConfigDict(Path('./test.json'))
    cfg['string'] = 'abc'
    cfg['dict'] = {'k': 'v'}
    # Raise an exception if path doesn't exist
    with pytest.raises(ConfigFileError):
        cfg.load()

    # Save the dict to config file and load it
    cfg.save()
    cfg.clear()
    cfg.load()

    # Check if we load the dict correctly
    assert cfg['string'] == 'abc'
    assert cfg['dict']['k'] == 'v'


# Generated at 2022-06-11 23:21:48.961341
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    
    print("\n\n{0}\n{1}\n{2}\n\n".format("*"*10, "Unit test for method load of class BaseConfigDict", "*"*10))
    config = BaseConfigDict("../test/config.json")
    config.load()
    print("config: ", config)
    assert len(config) > 0


# Generated at 2022-06-11 23:21:53.258264
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """

    Test method save of class BaseConfigDict

    Returns
    _______

        None
    """
    file = BaseConfigDict(Path(DEFAULT_CONFIG_DIR))
    config = Config()
    assert isinstance(file.save(), None)
    assert isinstance(config.save(), None)

# Generated at 2022-06-11 23:22:03.563937
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import copy
    import os

    original_environ = copy.deepcopy(os.environ)
    original_home_dir = os.environ.get('HOME')
    original_xdg_config_home_dir = os.environ.get(ENV_XDG_CONFIG_HOME)

    os.environ['HOME'] = '/home/user'

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/my/httpie'
    assert get_default_config_dir() == Path('/home/my/httpie')

    # 2. Windows
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/user/.config/httpie'
    if is_windows:
        assert get_default_config_dir()