

# Generated at 2022-06-11 23:12:08.073644
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:08.924167
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()

# Generated at 2022-06-11 23:12:09.749547
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:12.801330
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('./test_BaseConfigDict_save')
    dic = BaseConfigDict(path)
    dic.save()
    assert path.is_file()

# Generated at 2022-06-11 23:12:16.903452
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() \
               == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:12:26.904098
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from click.testing import CliRunner
    from httpie.output.streams import get_err

    from httpie.cli.config import CONFIG_DIR_TYPE, handle_config_dir
    from httpie.cli.context import Context
    from httpie.cli.exceptions import BadOptionUsage

    runner = CliRunner()

    ctx = Context()

    # No HTTPIE_CONFIG_DIR in env
    # No XDG_CONFIG_HOME in env
    # No ~/.httpie
    # Expects default path: ~/.config/httpie
    runner.invoke(handle_config_dir, [], obj=ctx)
    assert ctx.config_dir == Path.home() / Path('.config/httpie')

    # Set XDG_CONFIG_HOME

# Generated at 2022-06-11 23:12:29.476448
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == Path.home() / '.config/httpie'

# Generated at 2022-06-11 23:12:35.977753
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from httpie.config import get_default_config_dir

    backup = os.environ.copy()
    try:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        path = get_default_config_dir()
        assert isinstance(path, Path)
    finally:
        os.environ.clear()
        os.environ.update(backup)

    assert path == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:12:43.192606
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'explicit'
    assert get_default_config_dir() == 'explicit'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        with patch.object(Path, 'home', return_value='HOME'):
            with patch.object(Path, 'exists', return_value=True):
                assert get_default_config_dir() == 'HOME/.httpie'

# Generated at 2022-06-11 23:12:52.859331
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_XDG_CONFIG_HOME] = '/test/config'
    assert get_default_config_dir() == Path('/test/config') / DEFAULT_CONFIG_DIRNAME
    del os.environ[ENV_XDG_CONFIG_HOME]

    home_dir = Path.home()
    default_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == default_config_dir
    default_config_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_

# Generated at 2022-06-11 23:12:57.810916
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict("/tmp/testfile.json")
    assert (config_dict.ensure_directory())


# Generated at 2022-06-11 23:13:00.020415
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:13:06.859495
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ.copy()

    def set_env(**kwargs):
        env.update(kwargs)
        os.environ.update(env)

    def reset_env():
        env.clear()
        env.update(os.environ)

    def get_config_dir():
        return get_default_config_dir()

    reset_env()
    assert get_config_dir() != get_config_dir()
    Path.home.cache_clear()
    assert get_config_dir() == get_config_dir()

    reset_env()
    assert get_config_dir() != get_config_dir()
    Path.exists.cache_clear()
    assert get_config_dir() == get_config_dir()

    reset_env()
    assert get_config_dir() == DE

# Generated at 2022-06-11 23:13:10.911634
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class Conf(BaseConfigDict):
        pass
    conf = Conf(Path('~/.httpie_not_exist'))
    conf.ensure_directory()
    assert conf.path.parent.exists()


# Generated at 2022-06-11 23:13:12.720542
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config(directory="/tmp/httpie/test")
    config.save()

# Generated at 2022-06-11 23:13:23.976995
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print('\n')
    if is_windows:
        print("On Windows")
    else:
        print("Not on Windows")
    print("HOME: ", os.environ.get('HOME'))
    print("XDG_CONFIG_HOME: ", os.environ.get('XDG_CONFIG_HOME'))
    print("HTTPIE_CONFIG_DIR: ", os.environ.get('HTTPIE_CONFIG_DIR'))
    print("DEFAULT_CONFIG_DIR: ", DEFAULT_CONFIG_DIR)

test_get_default_config_dir()

# Generated at 2022-06-11 23:13:35.337074
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Check default case
    assert get_default_config_dir() == os.path.expanduser('~/.config/httpie')

    # Check default case with XDG env variable
    os.environ[ENV_XDG_CONFIG_HOME] = '~/.xedgconfig'
    assert get_default_config_dir() == os.path.expanduser('~/.xedgconfig/httpie')

    # Check case with HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/httpie_test_case'
    assert get_default_config_dir() == os.path.expanduser('~/httpie_test_case')

    # Check on Windows
    with patches('httpie.config.is_windows'):
        assert get_default

# Generated at 2022-06-11 23:13:40.763443
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_path = Path('/tmp/test.json')
    bd = BaseConfigDict(config_path)
    bd.ensure_directory()
    result = Path('/tmp').exists()
    assert (result == True)
    config_path.unlink()

# Generated at 2022-06-11 23:13:51.912436
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass

    try:
        del os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        pass

    home_dir = Path.home()
    xdg_config_home_dir = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME

    xdg_config_dir = xdg_config_home_dir / DEFAULT_CONFIG_DIRNAME
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

    #
    # 1. explicitly set through env
    #


# Generated at 2022-06-11 23:13:57.553508
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        pass

    import tempfile
    test_config_dict_path = Path(tempfile.gettempdir()) / 'httpie.config.json'

    foo_config_dict = TestConfigDict(path=test_config_dict_path)
    foo_config_dict['foo'] = 'bar'
    foo_config_dict.save()

    assert test_config_dict_path.read_text() \
        == '{"__meta__": {"httpie": "0.9.9"}, "foo": "bar"}\n'



# Generated at 2022-06-11 23:14:03.763855
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict('config.json')
    config_dict['this is'] = 'atest'
    config_dict.save(True)
    assert type(config_dict) is BaseConfigDict
    assert config_dict['this is'] == 'atest'

# Generated at 2022-06-11 23:14:12.311563
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    dir = Path("test")
    c = BaseConfigDict(path=dir)
    # If directory doest not exist, should create the directory
    if dir.exists():
        dir.rmdir()
    c.ensure_directory()
    assert dir.exists()
    # If directory exists, should not raise exception
    c.ensure_directory()
    assert dir.exists()
    # Should not raise exception if can't create parent
    if not dir.parents[0].exists():
        dir.parents[0].mkdir()
    with mock.patch('os.chmod', side_effect=OSError):
        c.ensure_directory()
    assert dir.exists()
    # Should raise exception if can't create the directory
    if dir.exists():
        dir.rmdir()

# Generated at 2022-06-11 23:14:20.020004
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import sys, json
    from os import path

    from httpie.config import BaseConfigDict

    # Create temporary file for testing
    config_file_path = '/tmp/httpie-config-dict-write-test.json'

    # Create the instance object.
    bc = BaseConfigDict(path=config_file_path)

    # Save the object.
    bc.save()

    # Try to read the created file.
    with open(config_file_path, 'r') as f:
        json_data = json.load(f)

    # Check if the loaded data is an instance of dict
    assert isinstance(json_data, dict)
    assert json_data.get('__meta__') is not None

    # Remove the temporary file.

# Generated at 2022-06-11 23:14:31.381894
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class DummyConfig(BaseConfigDict):
        def __init__(self, path):
            self.path = path
            self['x'] = 1
            self['y'] = 'abc'
            self['z'] = {'a': 10, 'b': 'foo'}
            self['helpurl'] = 'http://example.com/help'
            self['about'] = 'This is an example config.'

    dirpath = Path('dummy') / 'config'
    path = dirpath / 'config.json'
    config = DummyConfig(path)


# Generated at 2022-06-11 23:14:35.049549
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = '/home/user/.httpie'
    result = BaseConfigDict(config_dir)
    result.ensure_directory()
    exp_result = True
    assert exp_result == os.path.exists(config_dir)


# Generated at 2022-06-11 23:14:38.423112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert path.name == 'httpie'


# Generated at 2022-06-11 23:14:42.010429
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = TempDir()
    config_file_path = config_dir.path / 'config.json'
    config = BaseConfigDict(path=config_file_path)
    config.ensure_directory()
    assert config_dir.path.is_dir()



# Generated at 2022-06-11 23:14:49.493237
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    from pathlib import Path
    config_path = Path('/tmp/test_BaseConfigDict_save.json')

    config = BaseConfigDict(config_path)
    assert not config_path.exists()
    assert config.is_new()
    config['key'] = 'value'
    config['key2'] = 'value2'

    config.save()
    with config_path.open('rt') as f:
        assert json.load(f) == {'key': 'value', 'key2': 'value2'}

# Generated at 2022-06-11 23:15:02.306425
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import unittest

    class GetDefaultConfigDirTestCase(unittest.TestCase):
        # TODO: Test on Windows

        def test_no_dirs(self):
            # Test without xdg and legacy config dirs
            env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
            if env_config_dir:
                del os.environ[ENV_HTTPIE_CONFIG_DIR]
            env_xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
            if env_xdg_config_home:
                del os.environ[ENV_XDG_CONFIG_HOME]

            default_config_dir = get_default_config_dir()
            expected_config_dir = Path.home

# Generated at 2022-06-11 23:15:11.706533
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1: $HTTPIE_CONFIG_DIR is set
    os.environ['HTTPIE_CONFIG_DIR'] = 'foo'
    assert get_default_config_dir() == 'foo'
    del os.environ['HTTPIE_CONFIG_DIR']

    # Case 2: $XDG_CONFIG_HOME is set
    os.environ['XDG_CONFIG_HOME'] = 'bar'
    assert get_default_config_dir() == 'bar/httpie'
    del os.environ['XDG_CONFIG_HOME']

    # Case 3: On Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-11 23:15:17.173171
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    c=BaseConfigDict('./test/config.json')
    c['a']='aaa'
    assert not c.is_new()
    c.save()

# Generated at 2022-06-11 23:15:25.595074
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def _test(env=None, windows=False, expected_config_dir=None):
        with patch.object(os.path, 'expandvars') as mock_expandvars:
            mock_expandvars.return_value = '%APPDATA%'

            with patch.object(os, 'environ') as mock_env:
                mock_env.copy.return_value = env or {}

                with patch('httpie.config.is_windows') as mock_is_windows:
                    mock_is_windows.return_value = windows

                    config_dir = get_default_config_dir()

                    if windows:
                        mock_expandvars.assert_called_once_with('%APPDATA%')
                    assert config_dir == expected_config_dir


# Generated at 2022-06-11 23:15:29.528121
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test the function of load()
    x = BaseConfigDict(Path('tests/conf/config.json'))
    x.load()
    # load() should return nothing
    assert x == {"default_options": ["--ignore-stdin"]}, "Test load() failed"

# Generated at 2022-06-11 23:15:34.107773
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import builtins

    backup_env_xdg_config_home = os.environ.get(ENV_XDG_CONFIG_HOME)
    backup_env_httpie_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    parent_path = Path.joinpath(*Path.home().parts[:2])


# Generated at 2022-06-11 23:15:36.099529
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()


# Generated at 2022-06-11 23:15:42.511252
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def reset_config_dir_env_vars():
        if ENV_HTTPIE_CONFIG_DIR in os.environ:
            os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
        if ENV_XDG_CONFIG_HOME in os.environ:
            os.environ.pop(ENV_XDG_CONFIG_HOME)

    reset_config_dir_env_vars()
    default_config_dir = get_default_config_dir()
    assert default_config_dir == DEFAULT_WINDOWS_CONFIG_DIR, \
        'should use %APPDATA% on Windows'
    assert not default_config_dir.exists(), 'should not exist'

    reset_config_dir_env_vars()

# Generated at 2022-06-11 23:15:52.503001
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    
    class TestConfigDict(BaseConfigDict):
        name = "test"
        helpurl = "https://example.com"
        about = "about"

    testConfigDir = Path("/tmp/testConfig")
    testConfigFile = testConfigDir / "testConfig.json"

    if testConfigFile.exists():
        testConfigFile.unlink()
    
    test_config = TestConfigDict(testConfigFile)
    test_config["hello"] = "world"
    test_config.save()

    assert testConfigFile.exists()

    test_config = TestConfigDict(testConfigFile)
    test_config.load()
    assert test_config["hello"] == "world"

    test_config.delete()
    assert not test_config.__getitem__("hello")

# Generated at 2022-06-11 23:15:57.071511
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    file_name = 'config.json'
    file_path = Path(file_name)
    if file_path.exists():
        file_path.unlink()
    file_path.write_text('{}\n')
    config = Config()
    config.load()
    assert config['default_options'] == []

# Generated at 2022-06-11 23:16:07.132524
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # New path format
    assert get_default_config_dir().as_posix() == '~/.config/httpie'

    if is_windows:
        assert get_default_config_dir().as_posix() == '%APPDATA%/httpie'
    else:
        os.environ[ENV_XDG_CONFIG_HOME] = '~/.myconf'
        assert get_default_config_dir().as_posix() == '~/.myconf/httpie'

        os.environ[ENV_XDG_CONFIG_HOME] = '~/'
        assert get_default_config_dir().as_posix() == '~/httpie'

        os.environ[ENV_XDG_CONFIG_HOME] = '~'
        assert get_default_config_

# Generated at 2022-06-11 23:16:18.560080
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        tmp_dir = '/tmp/httpie_test/'
        if not os.path.exists(tmp_dir):
            os.makedirs(tmp_dir)
        self = BaseConfigDict(path=tmp_dir + 'test_file.json')
        self.ensure_directory()
        assert os.access(tmp_dir, os.R_OK) and os.access(tmp_dir, os.W_OK)
        assert os.path.exists(tmp_dir) and os.path.isdir(tmp_dir)
        os.removedirs(tmp_dir)
    except AssertionError:
        print("BaseConfigDict_ensure_directory() is not tested.")
    else:
        print("BaseConfigDict_ensure_directory() is tested.")


# Generated at 2022-06-11 23:16:25.665327
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_dir_name = 'test_dir'
    config_test_dir = Config(directory=test_dir_name)
    config_test_dir.ensure_directory()

    assert os.path.isdir(test_dir_name)
    os.rmdir(test_dir_name)

CONFIG = Config()

# Generated at 2022-06-11 23:16:33.078380
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie import config
    from tempfile import mkdtemp
    from pathlib import Path
    from os import chmod, stat

    tmp_path = Path(mkdtemp())

    chmod(tmp_path, 0o000)

    try:
        config_dir = tmp_path / 'httpie'
        config_file = config_dir / config.Config.FILENAME
        config_obj = config.Config(config_dir)
        config_obj.ensure_directory()
        assert stat(config_dir).st_mode & 0o700 == 0o700
        assert config_dir.exists()
        assert config_file.exists()
    finally:
        chmod(tmp_path, 0o700)

# Generated at 2022-06-11 23:16:42.241295
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    from pathlib import Path
    import json
    import shutil

    path = Path('/tmp/test_httpie_config_dict.json')
    if path.exists():
        os.remove(path)

    class TestConfigDict(BaseConfigDict):
        pass

    config_dict = TestConfigDict(path)
    config_dict['test_key'] = 'test_value'
    config_dict.save()

    with path.open('r') as f:
        data = json.load(f)

    assert data == config_dict

    os.remove(path)



# Generated at 2022-06-11 23:16:51.436415
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # path doesn't exist
    path = 'base_config_dict_test_dir/base_config_dict_test_file'
    base_config = BaseConfigDict(path=path)
    base_config.ensure_directory()
    directory = Path('base_config_dict_test_dir')
    assert directory.is_dir()
    file = Path(path)
    assert file.is_file()

    # path exists
    base_config.ensure_directory()
    assert directory.is_dir()
    assert file.is_file()

    # remove testing files and folders
    file.unlink()
    directory.rmdir()


# Generated at 2022-06-11 23:17:01.884871
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch('httpie.config.DEFAULT_RELATIVE_LEGACY_CONFIG_DIR'):
        DEFAULT_RELATIVE_LEGACY_CONFIG_DIR.exists.return_value = False
        with mock.patch.object(os.path, 'expandvars'):
            os.path.expandvars.return_value = 'blabla'
            assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()

    with mock.patch.dict(os.environ,
                         {ENV_HTTPIE_CONFIG_DIR: '/path/to/config'},
                         clear=True):
        assert Path('/path/to/config') == get_default_config_dir()



# Generated at 2022-06-11 23:17:11.813167
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    print("\n**** Testing method ensure_directory of class BaseConfigDict ****")

    # Test1: test if the directory is created successfully
    config = BaseConfigDict(Path(DEFAULT_CONFIG_DIR) / 'test.json')
    config.ensure_directory()
    assert DEFAULT_CONFIG_DIR.exists()

    # Test2: test if error occurs when creating directory
    import shutil
    shutil.rmtree(DEFAULT_CONFIG_DIR)
    config = BaseConfigDict(Path(DEFAULT_CONFIG_DIR) / 'test.json')
    try:
        config.ensure_directory()
    except Exception as e:
        assert str(e).startswith("[Errno")
    else:
        raise Exception("Error not raised")

# Generated at 2022-06-11 23:17:22.104139
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = Config('test_BaseConfigDict/config0')
    config.ensure_directory()
    path0 = Path('test_BaseConfigDict/config0')
    assert path0.exists()
    assert config.path == path0 / 'config.json'
    path0.rmdir()
    assert not path0.exists()

    config = Config('test_BaseConfigDict/config1/config2')
    config.ensure_directory()
    path1 = Path('test_BaseConfigDict/config1')
    path2 = path1 / 'config2'
    assert path1.exists()
    assert path2.exists()
    assert config.path == path2 / 'config.json'
    path2.rmdir()
    path1.rmdir()

# Generated at 2022-06-11 23:17:29.287017
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class test_BaseConfigDict(BaseConfigDict):
        name = 'config'
        helpurl = 'http://docs.httpie.org/en/latest/config.html'
        about = 'httpie Config file'

    config_dir = Path('.httpie')
    if config_dir.exists() is False:
        os.mkdir(config_dir)
    test_config = test_BaseConfigDict('.httpie/config.json')
    test_config.update({'test': 'test contant'})

    # test return value
    assert test_config.save() == None


# Generated at 2022-06-11 23:17:32.270442
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class Test(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'

    test = Test(Path('.TestFile'))
    test.save(fail_silently=True)

# Generated at 2022-06-11 23:17:41.870483
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmpdir = Path(tempfile.mkdtemp())
    config_dir = tmpdir / DEFAULT_CONFIG_DIRNAME
    config = Config(directory=config_dir)
    config['default_options'] = ['--form']
    config.save()
    test_file = config_dir / Config.FILENAME
    assert test_file.is_file()
    with test_file.open('rt') as f:
        try:
            data = json.load(f)
        except ValueError as e:
            raise ConfigFileError(
                f'invalid config file: {e} [{config.path}]')
    assert data == {
        'default_options': ['--form'],
        '__meta__': {
            'httpie': __version__
        }
    }
    config.delete()

# Generated at 2022-06-11 23:17:55.803151
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from os import path
    from pathlib import Path
    import json
    import inspect

    # Test functionality
    with NamedTemporaryFile(mode='w+t', delete=False) as tf:
        tf.close()
        tmp_file = Path(tf.name)
        assert not tmp_file.exists()
        # Create some config data to dump

# Generated at 2022-06-11 23:18:01.458852
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    class TempFile(BaseConfigDict):
        def __init__(self):
            path = Path('/tmp/file')
            super().__init__(path=path)

    with pytest.raises(ConfigFileError):
        f = TempFile()
        f['name'] = 'hello'
        f.save()
        with f.path.open('wt') as outfile:
            outfile.write('this is not json object')
        f.load()



# Generated at 2022-06-11 23:18:10.467585
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    from pathlib import Path
    from tempfile import NamedTemporaryFile
    from httpie.config import BaseConfigDict
    
    json_string = '{"test_key":"test_value"}'
    
    with NamedTemporaryFile() as f:
        f.write(json_string.encode())
        f.seek(0)
        
        test_config = BaseConfigDict(Path(f.name))
        test_config.load()
    
    assert test_config['test_key'] == 'test_value'
        

# Generated at 2022-06-11 23:18:15.652743
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Config(BaseConfigDict):
        def __init__(self):
            super().__init__(path=Path("config.json"))
            
    config = Config()
    config.load()
    assert config.get("__meta__") == {'httpie': __version__}
    assert config.get("default_options") == []
    

# Generated at 2022-06-11 23:18:21.321682
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    user_config_dir = os.path.join(temp_dir, 'config')
    os.mkdir(user_config_dir)
    settings = Config(directory=user_config_dir)
    settings.ensure_directory()
    assert os.path.exists(settings.path.parent)
    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 23:18:28.421018
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Unset the config dir variable
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        tmp_value = os.environ[ENV_HTTPIE_CONFIG_DIR]
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    else:
        tmp_value = None

    # Unset the XDG config home variable
    if ENV_XDG_CONFIG_HOME in os.environ:
        tmp_value_xdg = os.environ[ENV_XDG_CONFIG_HOME]
        del os.environ[ENV_XDG_CONFIG_HOME]
    else:
        tmp_value_xdg = None

    # When both are unset, the default dir is $HOME/.config/httpie
    assert Path.home() / DE

# Generated at 2022-06-11 23:18:31.129530
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path = Path("/data/test")
    baseConfigDict = BaseConfigDict(path)
    baseConfigDict.ensure_directory()


# Generated at 2022-06-11 23:18:41.544335
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def assert_dir_eq(dir_path, expected_dir_path):
        assert dir_path == expected_dir_path, (dir_path, expected_dir_path)

    # 1. explicitly set through env
    with mock.patch.dict(os.environ, {ENV_HTTPIE_CONFIG_DIR: "foo"}):
        assert_dir_eq(get_default_config_dir(), Path("foo"))

    # 2. Windows
    with mock.patch('httpie.config.is_windows', return_value=True):
        assert_dir_eq(
            get_default_config_dir(),
            Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        )

    # 3. legacy ~/.httpie

# Generated at 2022-06-11 23:18:45.728048
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    os.environ[ENV_XDG_CONFIG_HOME] = '/custom/path'
    assert get_default_config_dir() == Path('/custom/path') / 'httpie'

# Generated at 2022-06-11 23:18:56.548704
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicit/config/dir'
    assert get_default_config_dir() == Path('/explicit/config/dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        # not testing, just making sure nothing is broken
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # 3. legacy ~/.httpie
    Path.home().mkdir(mode=0o700, parents=True)
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700)
   

# Generated at 2022-06-11 23:19:08.569089
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('test.json'))
    config.ensure_directory()
    try:
        assert (Path('./') / 'config').exists()
        assert (Path('./') / 'config').is_dir()
    finally:
        shutil.rmtree('./config')



# Generated at 2022-06-11 23:19:13.930575
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_dir = Path.cwd() / 'temp_json'
    temp_dir.mkdir()
    config = BaseConfigDict(path=temp_dir / 'config.json')
    config.save()
    file_exist = temp_dir / 'config.json'
    assert file_exist.exists()
    file_exist.unlink()
    temp_dir.rmdir()

# Generated at 2022-06-11 23:19:19.652458
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir
    else:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR


# Generated at 2022-06-11 23:19:22.688700
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    a = BaseConfigDict(Path('c:\\temp\\test.json'))
    a.ensure_directory()
    assert os.path.exists('c:\\temp')


# Generated at 2022-06-11 23:19:30.712852
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # mock os.path.expandvars, otherwise our tests won't work in
    # TravisCI (and any other system where %APPDATA% is not set)
    os.path.expandvars = lambda x: x

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('/some/dir'))
    assert get_default_config_dir() == Path('/some/dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    # 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-11 23:19:40.502581
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)
        return

    # Test case 1: `XDG_CONFIG_HOME` not set
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert str(get_default_config_dir()) == '{}/{}'.format(
        str(Path('~/').expanduser()),
        str(DEFAULT_RELATIVE_LEGACY_CONFIG_DIR),
    )

    # Test case 2: `XDG_CONFIG_HOME` set

# Generated at 2022-06-11 23:19:42.915681
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.environ.get('HOME')) / '.config' / 'httpie'



# Generated at 2022-06-11 23:19:45.279699
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    t = BaseConfigDict(Path('/tmp/test.json'))
    t.ensure_directory()
    assert Path('/tmp').is_dir()

# Generated at 2022-06-11 23:19:47.111974
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    baseConfigDict = BaseConfigDict(dir)
    baseConfigDict.save()


# Generated at 2022-06-11 23:19:57.175924
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # default case
    assert get_default_config_dir() == Path.home() / Path(".config") / 'httpie'

    # env variable HTTPIE_CONFIG_DIR is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/.httpie'
    assert get_default_config_dir() == Path('/test/.httpie')

    # platform is windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == Path.home() / Path(".config") / 'httpie'

    # legacy config
    assert get_default_config_dir() == Path.home() / Path(".config") / 'httpie'

# Generated at 2022-06-11 23:20:23.185484
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    my_dir = Path('./my_dir')
    my_file = Path('./my_dir/my_file')
    my_config = BaseConfigDict(my_file)
    if (my_dir.exists()):
        shutil.rmtree(my_dir)
    my_config.ensure_directory()
    assert my_dir.exists()


# Generated at 2022-06-11 23:20:27.997801
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Current directory is not write
    tmp_config_dict = BaseConfigDict(path=Path(os.getcwd()) / 'config.json')
    try:
        tmp_config_dict.ensure_directory()
        assert False, 'PermissionError should be raised'
    except PermissionError:
        assert True, 'PermissionError should be raised'

    # Current directory is write
    tmp_config_dict = BaseConfigDict(path=Path(os.getcwd()) / 'config.json')
    tmp_config_dict.ensure_directory()
    assert True



# Generated at 2022-06-11 23:20:35.804884
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie import config
    from httpie.compat import is_windows

    testConfig = {
        'a': 34,
        'b': 'hey'
    }

    temp = config.ConfigFile()
    temp.update(testConfig)

# Generated at 2022-06-11 23:20:38.252909
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = ConfigFileError()
    with pytest.raises(ConfigFileError):
        config.save()


# Generated at 2022-06-11 23:20:45.801592
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dir = Path(__file__).parent / 'test_dir'
    test_dir.mkdir(exist_ok=True)
    path = test_dir / 'test_BaseConfigDict_load.json'
    path.touch()
    with open(str(path), 'w') as f:
        f.write('[')

    try:
        baseConfigDict = BaseConfigDict(path=path)
        baseConfigDict.load()
    finally:
        path.unlink()
        test_dir.rmdir()



# Generated at 2022-06-11 23:20:56.275693
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import pytest
    from httpie.config import BaseConfigDict
    from httpie.compat import is_windows
    import os
    '''created a temp dictionary which is read by the config.load()'''
    newd = {'a':1, 'b':2}
    if is_windows:
        tempdir = str(os.path.expandvars('%APPDATA%')) + '\\httpie'
    else:
        tempdir = Path.home() / '.httpie'
    with open(tempdir + '\\config.json', 'w') as f:
        json.dump(newd, f)
    '''now test on it with Config class'''
    tempConfig = Config(tempdir)

# Generated at 2022-06-11 23:21:05.629191
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir(
    ) == DEFAULT_WINDOWS_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'xyz_ENV_HTTPIE_CONFIG_DIR_xyz'
    assert get_default_config_dir(
    ) == 'xyz_ENV_HTTPIE_CONFIG_DIR_xyz'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = 'xyz_ENV_XDG_CONFIG_HOME_xyz'
    assert get_default_config_dir(
    ) == Path('xyz_ENV_XDG_CONFIG_HOME_xyz'
              ) / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-11 23:21:11.904477
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    if not os.path.exists('unittest'):
        os.mkdir('unittest')
    path = './unittest/unit_test.json'
    config_dict = BaseConfigDict(Path(path))
    config_dict.save()
    assert os.path.exists(path) is True
    os.remove(path)
    os.rmdir('unittest')



# Generated at 2022-06-11 23:21:13.345911
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    config.delete()

# Generated at 2022-06-11 23:21:22.919338
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def test_cases(cases):
        for case in cases:
            name, env, exp = case
            os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
            if env is not None:
                if isinstance(env, tuple):
                    os.environ[ENV_XDG_CONFIG_HOME] = env[0]
                    os.environ[ENV_HTTPIE_CONFIG_DIR] = env[1]
                else:
                    os.environ[ENV_HTTPIE_CONFIG_DIR] = env
            if is_windows:
                exp = DEFAULT_WINDOWS_CONFIG_DIR
            res = get_default_config_dir()
            if res != exp:
                yield (name, env, exp, res)