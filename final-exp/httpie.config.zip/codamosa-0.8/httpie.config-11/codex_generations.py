

# Generated at 2022-06-11 23:12:08.998191
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert BaseConfigDict is not None

# Generated at 2022-06-11 23:12:13.706844
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class DummyConfig(BaseConfigDict):
        pass
    path = Path('/tmp/config_file')
    # First, make sure the file does not exist.
    path.parent.rmdir()
    dummy = DummyConfig(path)
    dummy.ensure_directory()
    assert path.parent.is_dir()
    path.parent.rmdir()

# Generated at 2022-06-11 23:12:24.287082
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    temp_path = Path(temp_file.name)
    temp_file.close()


# Generated at 2022-06-11 23:12:26.903617
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(Path('./config.json'))
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()



# Generated at 2022-06-11 23:12:34.255515
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = DEFAULT_CONFIG_DIR
    class config(BaseConfigDict):
        name = "config"
        config_dir = config_dir
        path = config_dir / "config.json"
        helpurl = "https://httpie.org/"
        about = "HTTPie is a command line HTTP client."
    config = config(config_dir)
    config.ensure_directory()
    config.load()

# Generated at 2022-06-11 23:12:42.238010
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
  """Test function get_default_config_dir
  """
  import os
  import tempfile
  from httpie.context import Environment
  from httpie.config import get_default_config_dir

  def do_test(data, expected):
    for name, value in data.items():
      os.environ[name] = value
    try:
      actual = get_default_config_dir()
      assert expected == actual
    finally:
      for name in data:
        del os.environ[name]

  do_test({}, Environment.default_config_dir)
  do_test({'XDG_CONFIG_HOME': ''},
          Environment.default_config_dir)

# Generated at 2022-06-11 23:12:48.669169
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.path.expanduser('~/.config/httpie'))
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/a/b/c'
    assert get_default_config_dir() == Path('/a/b/c')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-11 23:12:56.709075
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    tmp_dir = Path(tempfile.mkdtemp())

    # Test for a new directory
    config = BaseConfigDict(tmp_dir / 'config.json')
    config.ensure_directory()
    assert (tmp_dir / 'config.json').exists()

    # Test for an existing directory
    config.ensure_directory()
    assert (tmp_dir / 'config.json').exists()

    shutil.rmtree(tmp_dir)


config = Config()

# Generated at 2022-06-11 23:12:59.395944
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    cfg = BaseConfigDict('/tmp/httpie/config.json')
    cfg.ensure_directory()



# Generated at 2022-06-11 23:13:06.596751
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    conf_dir = get_default_config_dir()
    assert conf_dir == DEFAULT_CONFIG_DIR
    assert conf_dir == Path('.config') / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/config/dir'
    conf_dir = get_default_config_dir()
    assert conf_dir == Path('/config/dir')
    assert conf_dir == Path('.config') / 'httpie'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    with mock.patch('httpie.config.is_windows', return_value=True):
        conf_dir = get_default_config_dir()
        assert conf_dir == DEFAULT_WINDOWS_

# Generated at 2022-06-11 23:13:15.185385
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    try:
        tmpdir = os.environ["TMPDIR"]
    except:
        tmpdir = "/tmp"
    tmpfile = os.path.join(tmpdir, "test_config.json")
    dict = BaseConfigDict(tmpfile)
    dict.save()


# Generated at 2022-06-11 23:13:18.154055
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert DEFAULT_CONFIG_DIR == Path.home() / Path('.config/httpie')

# Generated at 2022-06-11 23:13:22.949342
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('/tmp/abc')
    base_config = BaseConfigDict(path)
    # First round
    base_config.save()
    assert base_config['__meta__']['httpie'] == __version__
    # Second round
    base_config.save()


# Generated at 2022-06-11 23:13:31.329968
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temp directory
    tmp_dir = Path(tempfile.mkdtemp())
    # create a config file in temp directory
    test_config_path = tmp_dir / 'test_config.json'
    config = BaseConfigDict(path=test_config_path)
    try:
        config.ensure_directory()
        # check if a parent directory exists
        parent_dir = test_config_path.parent
        assert parent_dir.exists()
        # check if file does not exist
        assert not test_config_path.exists()
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 23:13:44.388821
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import tempfile
    import pathlib
    # test directory already exists
    tmpdirname = tempfile.mkdtemp()
    assert os.path.isdir(tmpdirname)

    base = BaseConfigDict(pathlib.Path("%s/test.json" % tmpdirname))
    base.ensure_directory()
    assert os.path.exists(tmpdirname)
    assert os.path.isdir(tmpdirname)
    # remove the parent dir of file test.json
    os.rmdir(tmpdirname)

    # test directory does not exist
    tmpdirname = tempfile.tempdir
    tmpdirname = "%s/%s" % (tmpdirname, "test")
    assert not os.path.exists(tmpdirname)

# Generated at 2022-06-11 23:13:53.883233
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    default_config_dir = get_default_config_dir()
    test_file = default_config_dir / "test_file"

    try:
        test_file.parent.mkdir(mode=0o700, parents=True)
        BaseConfigDict(test_file).ensure_directory()
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
        print("The file directory does exist")

    try:
        test_file.parent.mkdir(mode=0o700, parents=True)
        BaseConfigDict("wrong_path").ensure_directory()
    except OSError as e:
        print("The file directory does not exist")



# Generated at 2022-06-11 23:13:55.267455
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config/httpie'



# Generated at 2022-06-11 23:14:05.228081
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    XDG_CONFIG_HOME = '/home/user/.config'
    # run os.unsetenv under Windows will cause ValueError,
    # so we just ignore removing env var in Windows
    if not is_windows:
        os.unsetenv(ENV_XDG_CONFIG_HOME)  # None
    assert get_default_config_dir() == Path('/home/user/.config') / DEFAULT_CONFIG_DIRNAME

    if not is_windows:
        os.environ[ENV_XDG_CONFIG_HOME] = XDG_CONFIG_HOME  # explicit
    assert get_default_config_dir() == Path(XDG_CONFIG_HOME) / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-11 23:14:07.880470
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/path'
    assert get_default_config_dir() == Path('/some/path')

# Generated at 2022-06-11 23:14:19.571478
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    $HTTPIE_CONFIG_DIR
    """
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == '/foo/bar'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    """
    Windows
    """
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    """
    Legacy
    """
    Path.home = lambda: '/home/a'
    assert get_default_config_dir() == '/home/a/.httpie'
    Path.home = lambda: None

    """
    XDG
    """
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/a/.config'
    assert get_default

# Generated at 2022-06-11 23:14:26.903043
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_path = Path('test_file.json')
    test_config = BaseConfigDict(test_path)
    test_config.ensure_directory()
    assert os.path.exists(test_path.parent)
    os.rmdir(test_path.parent)



# Generated at 2022-06-11 23:14:35.699590
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    from httpie.core import JSON_DEV


    class config(BaseConfigDict):
        def __init__(self, directory: Path):
            super().__init__(path=directory / self.FILENAME)


    with TemporaryDirectory() as directory:
        # Unit test: make sure values are saved correctly
        conf = config(directory=Path(directory))
        conf['default_options'] = ['--json']
        conf['__meta__'] = {}
        conf.save()

        conf2 = config(directory=Path(directory))
        conf2.load()
        assert conf == conf2

        # Unit test: make sure `json.dumps` is called
        # with the

# Generated at 2022-06-11 23:14:38.180049
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert 1 == 1



# Generated at 2022-06-11 23:14:39.531769
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    pass



# Generated at 2022-06-11 23:14:44.447568
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Case1: If config file is new, then save
    config = BaseConfigDict('config.json')
    config.save(True)
    assert config['__meta__']['httpie'] == __version__

    # Case2: If config file is not new and there is no IOerror, then save
    config.save(True)
    assert config['__meta__']['httpie'] == __version__

# Generated at 2022-06-11 23:14:57.222453
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    if os.name == 'nt':
        # Windows
        assert get_default_config_dir().as_posix() == \
            DEFAULT_WINDOWS_CONFIG_DIR.as_posix()

    else:
        # Linux or MacOS
        config_dir_name = 'config_dir'

# Generated at 2022-06-11 23:15:09.210580
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    BASE_CONFIG_DICT_FILENAME = "config.json"
    BASE_CONFIG_DICT_DEFAULTS = {
        'default_options': []
    }
    BASE_CONFIG_DICT_PATH = "./config.json"
    # Create a BaseConfigDict object:
    base_config_dict = BaseConfigDict(path=BASE_CONFIG_DICT_PATH)
    # Set a DEFAULTS
    base_config_dict.DEFAULTS = BASE_CONFIG_DICT_DEFAULTS
    # Set a FILENAME
    base_config_dict.FILENAME = BASE_CONFIG_DICT_FILENAME
    # Set a helpurl
    base_config_dict.helpurl = None
    # Set a about
    base_config_dict.about = None
   

# Generated at 2022-06-11 23:15:20.116957
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # On most platforms, the default config directory should be ~/.config/httpie
    default_config_dir = get_default_config_dir()
    assert default_config_dir.parts[-1] == DEFAULT_CONFIG_DIRNAME
    if is_windows:
        assert default_config_dir.parts[0] == '%APPDATA%'
    else:
        if 'XDG_CONFIG_HOME' in os.environ:
            assert default_config_dir.parts[0] == Path(os.environ['XDG_CONFIG_HOME'])
        else:
            assert default_config_dir.parts[0] == '~/.config'

    # On Linux, with XDG_CONFIG_HOME set, use that instead of ~/.config
    os.environ['XDG_CONFIG_HOME']

# Generated at 2022-06-11 23:15:30.307918
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import pytest
    from httpie.config import DEFAULT_CONFIG_DIR, BaseConfigDict

    '''
    This test case is used for test the method load of class BaseConfigDict.
    First step: use default config
    '''
    with pytest.raises(ConfigFileError):
        a = BaseConfigDict(DEFAULT_CONFIG_DIR)
        a.load()
    '''
    Second step: use new config
    '''
    b = BaseConfigDict(DEFAULT_CONFIG_DIR / 'test.json')
    b.load()
    assert b == {}
    '''
    Third step: use normal config
    '''
    c = BaseConfigDict(DEFAULT_CONFIG_DIR / 'test.json')
    c['key'] = 'value'
   

# Generated at 2022-06-11 23:15:40.490203
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import subprocess
    import sys

    class TempConfig(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

        def load(self):
            pass

        def save(self, fail_silently=False):
            pass

    with tempfile.TemporaryDirectory() as directory:
        # noinspection SpellCheckingInspection

        config = TempConfig(Path(directory, 'httpie', 'config.json'))
        config.ensure_directory()
        assert os.listdir(directory) == ['httpie']
        subprocess.check_call([sys.executable, '-m', 'httpie',
                               '--config-dir', directory, '--debug'])


# Generated at 2022-06-11 23:15:56.380016
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
	my_config_dir = ".my_config_dir"
	my_config_file = "config.json"
	my_config_path = os.path.join(my_config_dir, my_config_file)

	my_config_dict = BaseConfigDict(path=my_config_path)

	if os.path.isfile(my_config_path):
		os.remove(my_config_path)

	assert not os.path.isfile(my_config_path)

	my_config_dict.save()

	assert os.path.isfile(my_config_path)

	my_config_dict.delete()

	assert not os.path.isfile(my_config_path)



# Generated at 2022-06-11 23:16:03.351778
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory
    import shutil
    from httpie.config import BaseConfigDict

    with TemporaryDirectory() as tmpdir:
        base_dir = Path(tmpdir)
        base_dir.mkdir()
        with open(str(base_dir / 'file.json'), 'r') as file:
            content = file.read()
            assert content == '{}'
        data = BaseConfigDict(base_dir / 'file.json')
        data['key'] = 'value'
        data.save()
        with open(str(base_dir / 'file.json'), 'r') as file:
            content = file.read()
            assert content == '{\n    "key": "value"\n}'
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 23:16:05.102774
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    dir = get_default_config_dir()
    assert isinstance(dir, Path)

# Generated at 2022-06-11 23:16:08.755896
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('randomfile'))
    try:
        config.ensure_directory()
        raise ValueError
    except OSError:
        pass

test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-11 23:16:19.851479
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from unittest.mock import patch
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR

    # 1. explicitly set through env
    with patch.dict('os.environ', {ENV_HTTPIE_CONFIG_DIR: '/path/foo'}):
        assert get_default_config_dir() == Path('/path/foo')

    # 2. Windows
    with patch('httpie.config.is_windows', return_value=True):
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    with patch('httpie.config.is_windows', return_value=False):
        patcher = patch('httpie.config.Path.home', return_value=Path('/home/foo'))
        # run the whole function
       

# Generated at 2022-06-11 23:16:25.561859
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Use parent directory of script as temp dir
    temp_dir = Path(os.path.dirname(os.path.realpath(__file__)))
    temp_dir = temp_dir.joinpath('test_dir')
    config = BaseConfigDict(temp_dir)
    config.ensure_directory()
    assert temp_dir.exists()


# Generated at 2022-06-11 23:16:29.642106
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # ConfigFileError
    dir_path = Path('/nonexisting-dir') / Path('httpie')
    config = BaseConfigDict(path=dir_path / 'config.json')
    config['default_options'] = []
    try:
        config.save()
    except ConfigFileError:
        pass

    # test successful config save
    dir_path = Path()
    config = BaseConfigDict(path=dir_path / 'config.json')
    config.save(fail_silently=True)

# Generated at 2022-06-11 23:16:40.453238
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create a temporary directory
    try:
        os.mkdir('temp')
    except FileExistsError:
        pass
    except:
        raise
    # create a temporary config file under the temporary directory
    try:
        with open('temp/test.json', 'w') as f:
            f.write('test')
    except FileExistsError:
        pass
    except:
        raise
    # create a ConfigDict object
    config = BaseConfigDict(path=Path('temp/test.json'))
    # test the ensure_directory method
    try:
        assert os.listdir('temp') == ['test.json']
        config.ensure_directory()
        assert os.listdir('temp') == ['test.json']
    except AssertionError:
        raise

# Generated at 2022-06-11 23:16:50.885412
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'foo'
    assert get_default_config_dir() == Path('foo')

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ[ENV_XDG_CONFIG_HOME] = 'bar'
    assert get_default_config_dir() == Path('bar') / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = ''
    assert get_

# Generated at 2022-06-11 23:16:55.602262
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Get default config directory
    default_config_directory = get_default_config_dir()

    # Ensure the directory is on the system
    assert default_config_directory.exists()

    # Check to see if it is the proper name
    assert default_config_directory.name == DEFAULT_CONFIG_DIRNAME





# Generated at 2022-06-11 23:17:21.206358
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # windows
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    # xdg
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    # xdg
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    # default
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config'
    assert get_default_config_dir() == Path('/xdg/config/httpie')

# Generated at 2022-06-11 23:17:30.540231
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import BaseConfigDict
    from httpie.core import main
    from httpie.plugins import builtin

    directory = Path(".temp_httpie_config")
    directory.mkdir(mode=0o700, parents=True)
    config_dict = BaseConfigDict(directory / "test")
    config_dict.save()
    with open(directory / "test", "r") as f:
        data = json.load(f)

    assert data["__meta__"]["httpie"] == __version__
    assert data["__meta__"]["help"] == "https://httpie.org/"
    assert data["__meta__"]["about"] == f"HTTPie {main.__version__}\n{builtin.ABOUT}"

    config_dict.save()

# Generated at 2022-06-11 23:17:34.927372
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    l = BaseConfigDict(Path("test.json"))
    l["request"] = "none"
    l["description"] = "some none"
    l.save()
    l["request"] = "none"
    l["description"] = "some none"
    l.save()
    assert Path("test.json").exists() == True
    os.remove("test.json")


# Generated at 2022-06-11 23:17:38.113873
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_dir = 'test_dir'
    config = BaseConfigDict(Path(test_dir))
    path = config.path
    if os.path.exists(path):
        raise ConfigFileError(f'cannot read config file: {e}')

# Generated at 2022-06-11 23:17:46.873659
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        old_env_xdg_config_home = os.environ[ENV_XDG_CONFIG_HOME]
        old_env_httpie_config_dir = os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass
    else:
        del os.environ[ENV_XDG_CONFIG_HOME]
        del os.environ[ENV_HTTPIE_CONFIG_DIR]


# Generated at 2022-06-11 23:17:56.087566
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import Config
    from httpie import __version__
    import json

    class TestBaseConfigDict(BaseConfigDict):
        name = 'test'
        about = 'this is a test'
        helpurl = 'https://httpie.org'

        def __init__(self, path: Path):
            super().__init__(path)
            self['test'] = 'test'

    config = TestBaseConfigDict(
        Path('~/.httpie/test.json').expanduser())

    config.save(fail_silently=True)

    path = config.path.expanduser()
    assert path.read_text() == json.dumps(config, indent=4, sort_keys=True, ensure_ascii=True)

# Generated at 2022-06-11 23:17:58.600238
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()



# Generated at 2022-06-11 23:17:59.174612
# Unit test for function get_default_config_dir

# Generated at 2022-06-11 23:18:01.192059
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    assert isinstance(get_default_config_dir(), Path)

# Generated at 2022-06-11 23:18:09.466646
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path = "/tmp/httpie/save.json")
    config_dict['foo'] = 'bar'
    config_dict.save()
    assert os.path.exists("/tmp/httpie/save.json")
    with open("/tmp/httpie/save.json", "r") as f:
        assert f.read() == "{\"foo\": \"bar\", \"__meta__\": {\"httpie\": \"" + __version__ + "\"}}\n"


# Generated at 2022-06-11 23:18:24.457375
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict("config.json")
    config.save(True)

# Generated at 2022-06-11 23:18:30.618350
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    from pathlib import Path
    with TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        test_config_dict = BaseConfigDict(tmpdir_path / "config_dict.json")
        test_config_dict.ensure_directory()
        assert tmpdir_path.is_dir()

# Generated at 2022-06-11 23:18:37.349188
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_config_dir = DEFAULT_CONFIG_DIR / "test"
    if test_config_dir.exists():
        test_config_dir.rmdir()
    assert not test_config_dir.exists()
    test_BaseConfigDict = BaseConfigDict(path=test_config_dir.parent / "config.json")
    test_BaseConfigDict.ensure_directory()
    assert test_config_dir.exists()
    test_config_dir.rmdir()


# Generated at 2022-06-11 23:18:47.974294
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import tempfile
    import json

    # Test case 1: Writing to a new file
    print("Test case 1")
    tmp_path = Path(tempfile.gettempdir())/"tmp_config.json"
    print("Expected: tmp_config.json file is created")
    print("Actual: ", end="")
    if tmp_path.exists():
        tmp_path.unlink()
    test_dict = BaseConfigDict(tmp_path)
    test_dict['a'] = 1
    test_dict.save()
    assert tmp_path.exists()
    if tmp_path.exists():
        tmp_path.unlink()
    print("tmp_config.json file is created")

    # Test case 2: Writing to a existing file

# Generated at 2022-06-11 23:18:54.756197
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    saved_file = 'test_data.json'
    config_data = {
            'default_options': ['--repeat', '20', '--timeout', '10']
        }

    config_ob = BaseConfigDict(Path(saved_file))
    config_ob.update(config_data)
    config_ob.save()

    # read back the saved file
    with open(saved_file, 'rt') as f:
        assert f.readline() == '{\n'


# Generated at 2022-06-11 23:18:58.532452
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict("/tmp/test")
    config.ensure_directory()
    assert os.path.exists("/tmp/test")
    os.rmdir("/tmp/test")

# Generated at 2022-06-11 23:19:07.772699
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIRNAME in str(get_default_config_dir())
    assert type(get_default_config_dir()) == Path

    # explicitly set through env
    env_config_dir = Path('/explicit/path')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(env_config_dir)
    assert get_default_config_dir() == env_config_dir

    # Windows
    if is_windows:
        assert (
            get_default_config_dir() ==
            Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
        )

    # legacy ~/.httpie
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY

# Generated at 2022-06-11 23:19:18.415124
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if is_windows:
        legacy_config_dir = DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-11 23:19:28.626006
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    import json
    import pytest

    @pytest.fixture(scope='function')
    def temp_file_path(request):
        f = tempfile.NamedTemporaryFile(mode='wt', delete=False)
        f.write('{}')
        f.close()
        def fin():
            os.unlink(f.name)
        request.addfinalizer(fin)
        return f.name

    # success
    d = BaseConfigDict(temp_file_path)
    d.load()
    assert d == {}

    # failure: invalid json
    with pytest.raises(ConfigFileError):
        d = BaseConfigDict(temp_file_path)
        with open(temp_file_path, "w") as f:
            f.write("{")
        d

# Generated at 2022-06-11 23:19:39.036680
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmp_path = Path('./test/test-save')

# Generated at 2022-06-11 23:20:10.656653
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path('.config/httpie')

# Generated at 2022-06-11 23:20:13.807488
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_path = '/home/test_user/test.json'
    dict = BaseConfigDict(Path(test_path))
    dict.save()
    assert dict.path.exists()


# Generated at 2022-06-11 23:20:19.273840
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    from shutil import rmtree
    import json
    import httpie.config

    dir = Path('./test_BaseConfigDict_save')
    dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    config = httpie.config.BaseConfigDict(path=dir / 'config.json')
    config.save()
    with open('./test_BaseConfigDict_save/config.json','r') as f:
        config_file = json.loads(f.read())
    assert config_file == {'__meta__': {'httpie': __version__}}
    rmtree('./test_BaseConfigDict_save')


# Generated at 2022-06-11 23:20:25.335679
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a instance of class BaseConfigDict
    config = BaseConfigDict('config.json')
    # Modify the path
    config.path = Path.cwd()
    # Create the config file
    config.save()
    # Check the config file
    assert Path('config.json').exists()
    # Check the file contents
    assert Path('config.json').read_text() == '{\n    "__meta__": {\n        "httpie": "' + __version__ + '"\n    }\n}\n'
    # Delete the config file
    Path('config.json').unlink()

# Generated at 2022-06-11 23:20:26.725233
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:20:35.584374
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from subprocess import CalledProcessError
    from subprocess import check_output
    os.environ['XDG_CONFIG_HOME'] = str(Path.home()/'.config')
    os.environ['HOME'] = str(Path.home()/'.testhome')
    os.environ['XDG_CONFIG_DIRS'] = str(Path.home()/'.config')

    try:
        check_output(['rm', '-rf', str(Path.home()/'.testhome'+'/config')])
    except CalledProcessError as e:
        pass

    try:
        check_output(['rm', '-rf', str(Path.home()/'.testhome'+'/.config')])
    except CalledProcessError as e:
        pass


# Generated at 2022-06-11 23:20:43.515993
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = Path('./test_BaseConfigDict.json')
    try:
        path.unlink()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    config = BaseConfigDict(path)
    config['a'] = 'A'
    config.save()
    assert path.exists()
    assert path.read_text() == '{\n    "a": "A"\n}\n'

if __name__ == "__main__":
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:20:52.207565
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test without XDG related environment variable
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    # test with XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '~/.config'
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
    # test with HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/.httpie'
    assert get_default_config_dir() == Path.home() / '.httpie'



# Generated at 2022-06-11 23:20:58.088118
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / ".config" / "httpie"
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(
        Path.home() / "some" / "custom" / "dir"
    )
    assert get_default_config_dir() == Path.home() / "some" / "custom" / "dir"


if __name__ == "__main__":
    test_get_default_config_dir()

# Generated at 2022-06-11 23:21:03.889638
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """Test get_default_config_dir() function
    """
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/config/dir'
    assert get_default_config_dir() == Path('/test/config/dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_

# Generated at 2022-06-11 23:21:46.662204
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        name = 'this is the name'
        helpurl = 'a help url'
        about = 'about this config file'
        FILENAME = 'config_test.json'

    test_config_path = 'test_files/test_data/' + TestConfigDict.FILENAME
    test_config = TestConfigDict(path=test_config_path)
    test_config['key'] = 'value'
    test_config.save()
    assert test_config_path == 'test_files/test_data/config_test.json'  
    with open(test_config_path) as json_file:
        data = json.load(json_file)
        assert data['key'] == 'value'
    os.remove(test_config_path)

# Generated at 2022-06-11 23:21:52.175720
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class MockBaseConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

        def is_new(self) -> bool:
            return True

    tmp_dir = Path(tempfile.mkdtemp())
    mock_config = MockBaseConfigDict(path=tmp_dir / 'foo.bar')
    mock_config.ensure_directory()
    assert tmp_dir.exists()



# Generated at 2022-06-11 23:21:55.952771
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    file_tmp = open("tmp.json", "w+")
    bcd = BaseConfigDict("tmp.json")
    bcd.save()
    file_tmp.close()
    os.remove("tmp.json")


# Generated at 2022-06-11 23:22:01.897420
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    home_dir = Path.home()
    test_config_dir = home_dir / 'test'
    try:
        test_config_dir.mkdir()
        try:
            config = BaseConfigDict(test_config_dir / 'config')
            config.ensure_directory()
        finally:
            test_config_dir.rmdir()
    except:
        pass

    assert not test_config_dir.exists()

# Generated at 2022-06-11 23:22:03.486885
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config'
