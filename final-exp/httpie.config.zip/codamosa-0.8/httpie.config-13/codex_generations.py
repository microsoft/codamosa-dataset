

# Generated at 2022-06-11 23:12:15.742627
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import HTTPieConfig
    from httpie.config import ItemConfig
    from httpie.config import AuthConfig
    
    # create directory for test
    os.makedirs('./config-test/')
    open('./config-test/config.json', 'x')
    open('./config-test/httpie.json', 'x')
    open('./config-test/auth.json', 'x')

    # test load config.json
    config = Config(directory='./config-test')
    config.load()
    assert config['__meta__'] == {'httpie': __version__}

    # test load httpie.json
    httpieconfig = HTTPieConfig(directory='./config-test')
    httpieconfig.load()
    assert httpieconfig['__meta__']

# Generated at 2022-06-11 23:12:17.541137
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	print('TESTING METHOD load for class BaseConfigDict')
	BaseConfigDict.load(self)


# Generated at 2022-06-11 23:12:23.859561
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./test_httpie_config_dir')
    config_path = config_dir / Config.FILENAME
    if config_path.exists():
        config_path.unlink()
    config = Config(config_dir)
    config['default_options'] = ['--form']
    config.save()
    if config_path.exists():
        assert True
    else:
        assert False


# Generated at 2022-06-11 23:12:35.071086
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Empty environment
    os.environ.clear()
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_XDG_CONFIG_HOME] = '/foo'
    assert get_default_config_dir() == Path('/foo') / DEFAULT_CONFIG_DIRNAME

    # For Windows, check that the expansion in get_default_config_dir() is used
    # rather than expanded in the variable
    os.environ['APPDATA'] = '/bar'
    assert get_default_config_dir() == Path('/bar') / DEFAULT_CONFIG_DIRNAME

    # Check that the environment variable takes precedence

# Generated at 2022-06-11 23:12:35.970502
# Unit test for method delete of class BaseConfigDict
def test_BaseConfigDict_delete():
    config_dict = BaseConfigDict('test.json')
    config_dict.delete()


# Generated at 2022-06-11 23:12:40.989097
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class A(BaseConfigDict):
        pass

    a = A('/tmp/config')
    a.save()
    assert a.is_new() == True

    a['a'] = 'a'
    a['b'] = 'b'
    a.save()
    assert a.is_new() == False


# Generated at 2022-06-11 23:12:50.559050
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # test directory do not exist
    test_path = Path.home() / Path('test_dir') / Path('config.json')
    config = BaseConfigDict(test_path)
    with pytest.raises(ConfigFileError):
        config.ensure_directory()
    test_path.parent.rmdir()
    # test file exist as a directory
    test_path = Path.home() / Path('test_file.txt')
    test_path.touch()
    config = BaseConfigDict(test_path)
    with pytest.raises(ConfigFileError):
        config.ensure_directory()
    test_path.unlink()

# Generated at 2022-06-11 23:13:01.245608
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_path = DEFAULT_CONFIG_DIR / BaseConfigDict.FILENAME
    test_obj = BaseConfigDict(path=config_path)
    # Test for non-existing config file
    test_obj['__meta__'] = {}
    test_obj.save(fail_silently=False)
    test_obj = BaseConfigDict(path=config_path)
    test_obj.load()
    assert test_obj['__meta__'] == {'httpie': __version__}
    test_obj.delete()
    # Test for existing config file
    test_obj['__meta__'] = {}
    test_obj.save(fail_silently=False)
    test_obj = BaseConfigDict(path=config_path)

# Generated at 2022-06-11 23:13:12.484131
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import io
    import io
    import os
    import json
    from httpie import __version__
    from httpie.config import BaseConfigDict
    from httpie.compat import str

    config_dir = os.path.join(os.getcwd(), 'test_save')
    path = os.path.join(config_dir, 'test.json')

    d = BaseConfigDict(path)
    d['foo'] = 'bar'
    d.save()

    assert os.path.exists(config_dir)
    assert os.path.exists(path)

    with open(path) as f:
        actual_contents = f.read()

# Generated at 2022-06-11 23:13:19.326778
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file_path = Path(__file__).parent / 'config_file_data.json'
    b = BaseConfigDict(config_file_path)
    data = {"aaa": "bbb", "ccc": "ddd", "eee": "fff"}
    b.update(data)
    b.save()
    with config_file_path.open('rt') as f:
        assert 'aaa' in f.read()
    config_file_path.unlink()

# Generated at 2022-06-11 23:13:32.463358
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    base_dir_1 = os.path.join(os.path.expanduser('~'), '.config')
    base_dir_2 = os.path.join(os.path.expanduser('~'), '.httpie')

    def mock_getenv(k, d=None):
        if k == ENV_XDG_CONFIG_HOME:
            return os.path.join(base_dir_1, DEFAULT_CONFIG_DIRNAME)
        if k == ENV_HTTPIE_CONFIG_DIR:
            return os.path.join(base_dir_2, DEFAULT_CONFIG_DIRNAME)

    def mock_isdir(path):
        if path == base_dir_1:
            raise
        if path == base_dir_2:
            return True


# Generated at 2022-06-11 23:13:45.299058
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicit_vs_xdg_config_dir'
    assert get_default_config_dir() == Path('/explicit_vs_xdg_config_dir')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg_dir'
    assert get_default_config_dir() == Path('/xdg_dir') / DEFAULT_CONFIG_DIRNAME
    del os.environ[ENV_XDG_CONFIG_HOME]

    # TODO: how to mock HOME dir?
    # assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT

# Generated at 2022-06-11 23:13:55.085532
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    _environ = os.environ.copy()

# Generated at 2022-06-11 23:14:04.977380
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import DEFAULT_CONFIG_DIR, Config, BaseConfigDict
    from httpie.compat import is_windows
    from httpie.compat import Path
    from httpie import __version__
    import os
    import os.path
    import sys
    import json

    config_default_dir = Path(DEFAULT_CONFIG_DIR)
    if not is_windows:
        config_default_dir = Path.home() / '.config/httpie'
    config_default_path = config_default_dir / 'config.json'

    data = {
        "default_options": ["--form"]
    }
    json_string = json.dumps(data)


# Generated at 2022-06-11 23:14:09.967860
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Run:

        PYTHONPATH=. python httpie/config.py

    """
    path = DEFAULT_CONFIG_DIR
    config_dict = BaseConfigDict(path)
    config_dict.ensure_directory()
    assert Path(path).parent.exists()

if __name__ == '__main__':
    test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-11 23:14:20.873763
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class xxxConfig(BaseConfigDict):
        FILENAME = 'config.json'
        DEFAILS = {
            'xxx': 'yyy'
        }
    
        def __init__(self, directory: Union[str, Path] = DEFAULT_CONFIG_DIR):
            xxx = self.DEFAILS['xxx']
            self.directory = Path(directory)
            super().__init__(path=self.directory / self.FILENAME)
            self.update(self.DEFAILS)
        
        @property
        def xxx(self):
            return "xxx"

    xxxCfg = xxxConfig()
    xxxCfg.save()
    xxxCfg.load()
    assert xxxCfg.xxx == "xxx"


test_BaseConfigDict_save()

# Generated at 2022-06-11 23:14:22.152799
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert BaseConfigDict.ensure_directory() == Path.home()

# Generated at 2022-06-11 23:14:25.319529
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_file = BaseConfigDict(Path('/home/test/test.json'))
    config_file.ensure_directory()
    assert os.path.exists('/home/test')



# Generated at 2022-06-11 23:14:28.869887
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file_name = 'BaseConfigDict.json'
    config_file_path = (Path(__file__).with_suffix('') / Path(config_file_name))
    configdic = BaseConfigDict(config_file_path)
    configdic.load()
    #print(configdic)
    return configdic

if __name__ == "__main__":
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:14:37.432272
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    home_dir = Path.home()
    # Default, XDG_CONFIG_HOME is set to ~/.config
    # and no HTTPIE_CONFIG_DIR is set
    assert(get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)
    os.environ[ENV_XDG_CONFIG_HOME] = os.path.join(str(Path.home()), '.config')
    # XDG_CONFIG_HOME is explicitly set to ~/.config
    assert(get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)
    os.environ[ENV_XDG_CONFIG_HOME] = os.path.join

# Generated at 2022-06-11 23:14:50.304087
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    def get_temp_path():
        fd, temp_path = tempfile.mkstemp(prefix='httpie-', suffix=".json")
        os.close(fd)
        return temp_path

    good_data_string="""{
    "default_options": "--debug"
}"""

    bad_data_string="""{
    "default_options": --debug
}"""

    # Test for valid data
    temp_path=get_temp_path()
    with open(temp_path, 'w') as f:
        f.write(good_data_string)
    c=Config(temp_path)
    c.load()

    # Test for invalid data
    temp_path=get_temp_path()

# Generated at 2022-06-11 23:14:56.938192
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestBaseConfigDict(BaseConfigDict):
        pass
    
    path = Path('~') / 'test'
    test_base_config_dict = TestBaseConfigDict(path)
    test_base_config_dict.ensure_directory()
    assert test_base_config_dict.path.parent.exists()

# Generated at 2022-06-11 23:15:08.942233
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Create a new class which is inherited from BaseConfigDict
    class ConfigTmp(BaseConfigDict):
        ABSPATH = 'abspath'
        def __init__(self, path: Path):
            super().__init__(path)
        
    # Initialize the class
    config_tmp = ConfigTmp(Path(os.path.curdir) / ConfigTmp.ABSPATH)
    
    # Get the current time
    from time import time
    import datetime
    ts = time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    
    # Update the meta attribute

# Generated at 2022-06-11 23:15:20.116884
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        name = 'test_config'
        helpurl = 'http://example.com/help'
        about = 'About this test config.'
    
    path = Path('test') / TestConfigDict.name
    config = TestConfigDict(path)
    config_type = TestConfigDict.name
    test_data = {
        '__meta__': {
            'httpie': __version__,
            'help': 'http://example.com/help',
            'about': 'About this test config.'
        },
        'test': 'test'
    }
    
    # load with no exception

# Generated at 2022-06-11 23:15:30.307768
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import mktemp
    from random import choice, sample
    from string import ascii_letters, digits

    tmp_dir = Path(mktemp())
    if tmp_dir.exists():
        tmp_dir.unlink()
    tmp_dir = tmp_dir.parent
    if not tmp_dir.exists():
        tmp_dir.mkdir()

    for i in range(1000):
        for _ in range(10):
            ran_dir = tmp_dir
            for _ in range(i):
                dir_name = ''.join(sample(ascii_letters + digits, 8))
                ran_dir = ran_dir.joinpath(dir_name)
            if ran_dir.exists():
                continue
            ran_dir.mkdir()


# Generated at 2022-06-11 23:15:38.030403
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from httpie import AuthPlugin as auth_plugin
    with tempfile.TemporaryDirectory() as temp_dir, tempfile.NamedTemporaryFile(
            mode='w', delete=False) as temp_file_auth:
        temp_plugin = auth_plugin.AuthPlugin()
        temp_plugin.save(temp_file_auth.name)
        temp_file_auth.close()
        temp_plugin.path = Path(temp_file_auth.name)
        temp_plugin.save(temp_dir)

# Generated at 2022-06-11 23:15:47.081608
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = 'test_load.json'
    print('test_load.json will be created under current folder')
    json_string = '''
    {
    "id": "101",
    "username": "Tom"
    }
    '''
    with open(path, 'w') as f:
        f.write(json_string)
    config = BaseConfigDict(path=path)
    config.load()
    assert isinstance(config, dict)
    assert config['id'] == '101'
    if os.path.exists(path):
        os.remove(path)
        print('test_load.json has been deleted')
    else:
        print('test_load.json was not found')

# Generated at 2022-06-11 23:15:56.923550
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    filename = "test_file.json"
    # Test 1: Invalid json
    f = open(filename, "w")
    f.write("{]")
    f.close()
    with pytest.raises(ConfigFileError):
        source = BaseConfigDict(filename)
        source.load()

    # Test 2: Valid json
    f = open(filename, "w")
    f.write("{}")
    f.close()
    source = BaseConfigDict(filename)
    source.load()

    # Test 3: Exception when reading file
    with pytest.raises(ConfigFileError):
        source = BaseConfigDict("non-existing-file.json")
        source.load()

    os.remove(filename)

# Generated at 2022-06-11 23:16:03.574049
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if os.environ.get(ENV_XDG_CONFIG_HOME):
        del os.environ[ENV_XDG_CONFIG_HOME]

    if os.environ.get(ENV_HTTPIE_CONFIG_DIR):
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # XDG
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/config/home'
    assert get_default_config_dir() == Path('/xdg/config/home') / DEFAULT_CONFIG_DIRNAME

    # Legacy
    assert get_default_config_dir

# Generated at 2022-06-11 23:16:14.826677
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # setup
    path = Path('~/.config/httpie/test.json').expanduser()
    config = BaseConfigDict(path=path)
    config['foo'] = 'bar'
    config.save()

    # verify
    with path.open('rt') as f:
        try:
            data = json.load(f)
        except ValueError as e:
            raise ConfigFileError(
                f'invalid {config.name} file: {e} [{config.path}]'
            )
        assert data == {'__meta__': {'httpie': __version__}, 'foo': 'bar'}
    config.delete()


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:16:29.285318
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Test(BaseConfigDict):
        name = None
        helpurl = None
        about = None

        def __init__(self, path: Path):
            super().__init__(path)
            self.path = path
            self['test'] = {
                "default": ["test1", "test2"],
                "test3": "test3"
            }

    test = Test(Path('./test.json'))
    test.save()

    assert test['test'] == {
        "default": ["test1", "test2"],
        "test3": "test3"
    }

    test_new = Test(Path('./test.json'))
    assert test_new['test'] == {
        "default": ["test1", "test2"],
        "test3": "test3"
    }

# Generated at 2022-06-11 23:16:39.935093
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        pass
    config = TestConfig(path=Path('/tmp/test_config.json'))
    # If the file specified by the path is not exist,
    # ConfigFileError will be raised
    with pytest.raises(ConfigFileError):
        config.load()
    # If file exists, load the file
    test_data = {
        'key': 'value'
    }
    with config.path.open('wt') as f:
        json.dump(f, test_data)
    config.load()
    assert config['key'] == test_data['key']
    # If file exists but there are invalid data,
    # ConfigFileError will be raised
    with config.path.open('wt') as f:
        f.write('invalid_data')

# Generated at 2022-06-11 23:16:42.066576
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    path = Path("test.json")
    config = BaseConfigDict(path)
    config.save()


# Generated at 2022-06-11 23:16:49.948285
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('./.httpie')
    try:
        config_dir.mkdir(mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    config = BaseConfigDict(config_dir / 'config.json')
    assert config_dir.exists()
    assert config_dir.parent.exists()

    config.ensure_directory()
    assert config_dir.exists()
    assert config_dir.parent.exists()



# Generated at 2022-06-11 23:16:54.655249
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = 'config/test_config_file'
    BaseConfig = BaseConfigDict(path)

    # test load with no such file
    assert not BaseConfig.load()

    # test load with file exists
    f = open('test.txt', 'w')
    f.close()
    assert BaseConfig.load()



# Generated at 2022-06-11 23:17:01.838705
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR, '') == ''
    assert os.environ.get(ENV_XDG_CONFIG_HOME, '') == ''
    try:
        home = Path.home()
        assert get_default_config_dir() == home / '.config' / 'httpie'
    finally:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        del os.environ[ENV_XDG_CONFIG_HOME]



# Generated at 2022-06-11 23:17:11.770196
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile

    def build_mock_deployment_config():
        '''This function builds a mock deployment config used in tests.'''
        config = BaseConfigDict(path = tempfile.mkdtemp() + 'deployment.json')
        del config['__meta__']
        del config['applications']
        config['content_type'] = 'json'
        return config

    def test_load(mock_config):
        def test_valid_load(mock_config):
            try:
                mock_config.load()
            except ConfigFileError:
                assert False


# Generated at 2022-06-11 23:17:15.715187
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = get_default_config_dir()
    default_config = Config(config_dir)
    default_config.load()
    print (default_config)

if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:17:17.885121
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert len(config) != 0


# Generated at 2022-06-11 23:17:27.180065
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        import httpie.plugins.builtin
    except ImportError:
        pytest.skip()

    # tests for function get_default_config_dir
    def test_get_default_config_dir():
        # 1. explicitly set through env
        expected_dir = '/a/b/c/'
        os.environ[ENV_HTTPIE_CONFIG_DIR] = expected_dir
        assert get_default_config_dir() == Path(expected_dir)

        # 2. Windows
        if is_windows:
            assert DEFAULT_WINDOWS_CONFIG_DIR == Path(
                os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME

        home_dir = Path.home()

        # 3. legacy ~/.httpie
        legacy_config_dir = home_

# Generated at 2022-06-11 23:17:33.084096
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    print('--- Start test_BaseConfigDict_ensure_directory')
    config_dir = DEFAULT_CONFIG_DIR
    config_file_path = config_dir / Config.FILENAME
    # Clean the directory if exists
    if config_dir.exists():
        config_file_path.unlink()
        config_dir.rmdir()
    # Call function ensure_directory of class Config
    config = Config()
    config.ensure_directory()
    # Check the result
    assert config_dir.exists()
    assert config_file_path.exists()
    print('Test passed.')
    print('Finish test_BaseConfigDict_ensure_directory')


# Generated at 2022-06-11 23:17:36.228918
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    conf = Config()
    #  conf.load()
    conf.delete()

if __name__ == "__main__":
    #  conf = Config()
    #  conf.delete()
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:17:45.759536
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path.home() / '.config' / 'httpie'
        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
        assert get_default_config_dir() == '/tmp'
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
        assert get_default_

# Generated at 2022-06-11 23:17:55.504561
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home_dir = '~/.config'
    old_xdg_config_home_dir = os.environ.get(ENV_XDG_CONFIG_HOME)
    if old_xdg_config_home_dir is None:
        os.environ[ENV_XDG_CONFIG_HOME] = xdg_config_home_dir

    assert str(get_default_config_dir().resolve()) == \
        str(Path(xdg_config_home_dir).resolve() / DEFAULT_CONFIG_DIRNAME)

    if old_xdg_config_home_dir is None:
        # Remove env var
        del os.environ[ENV_XDG_CONFIG_HOME]

# Generated at 2022-06-11 23:18:06.632924
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Variables for testing
    my_path = "file1.json"
    help_url = "https://httpie.org/help"
    version = "2.2.2"
    with open(my_path, 'wt') as f:
        f.write("{}")
        f.close()

    class MyConfig(BaseConfigDict):
        helpurl = help_url
        about = False

    my_config = MyConfig(path = Path(my_path))
    my_config.save()

    assert my_config['__meta__']['httpie'] == version
    assert my_config['__meta__']['help'] == help_url
    assert my_config['__meta__']['about'] == False


# Generated at 2022-06-11 23:18:08.970480
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    assert Path('/tmp/httpie/config.json').parent.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-11 23:18:19.150388
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        os.mkdir('test_BaseConfigDict_load')
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    os.chdir('test_BaseConfigDict_load')

# Generated at 2022-06-11 23:18:25.049518
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
	"""
	Test if method load properly loads a json file.
	"""
	filename = "temp"
	to_write = "{" + os.linesep + "    \"key\": \"value\"" + os.linesep + "}"
	
	with open(filename, "w") as file:
		file.write(to_write)
	
	temp = BaseConfigDict(filename)
	temp.load()
	
	assert temp["key"] == "value"
	
	os.remove(filename)


# Generated at 2022-06-11 23:18:34.760566
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():

    def mock_mkdir(mode):
        assert mode == 0o700

    def mock_makedirs(mode, parents):
        assert mode == 0o700
        assert parents == True

    try:
        path = Path(DEFAULT_CONFIG_DIR)
        configDict = BaseConfigDict(path)
    except:
        assert False

    configDict.path.parent.mkdir = mock_mkdir
    configDict.path.parent.makedirs = mock_makedirs

    configDict.ensure_directory()

    config = Config()
    configDict.directory = config.directory
    configDict.path = configDict.directory / Config.FILENAME

    configDict.ensure_directory()


# Generated at 2022-06-11 23:18:45.275277
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a file to save
    tmp_dir = tempfile.mkdtemp()
    config = BaseConfigDict(path=Path(tmp_dir) / 'config.json')
    config.save()
    
    # Even if the directory we want to save the file is not exist, we can
    # save the file.
    config = BaseConfigDict(path=Path(tmp_dir) / 'y/b/c/config.json')
    config.save()
    
    # Even if the path is a file, we can still save the file.
    config = BaseConfigDict(path=Path(tmp_dir) / 'config.json')
    config.save(fail_silently=True)
    
    # I can't add other objects in the config to save, because it will ruin
    # the json format.
    #

# Generated at 2022-06-11 23:18:58.293434
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    env_xdg_config_home = Path('/example/xdg/config/home')

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    elif env_xdg_config_home:
        assert get_default_config_dir() == env_xdg_config_home / DEFAULT_CONFIG_DIRNAME

    else:
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:19:05.096682
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        config_type = BaseConfigDict.__name__.lower()
        value = {
            'hello': 'world'
        }
        with (DEFAULT_CONFIG_DIR / Config.FILENAME).open('wt') as f:
            json.dump(value, f)
        config = Config()
        config.load()
        assert config == value
        config.delete()
    except ConfigFileError as e:
        print(f'cannot read {config_type} file: {e}')


# Generated at 2022-06-11 23:19:14.270277
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class ConfigDict(BaseConfigDict):
        pass

    config_dict = ConfigDict(path=Path('/no/such/file.json'))
    assert config_dict.is_new()

    with pytest.raises(ConfigFileError):
        config_dict.load()

    with open(str(config_dict.path), 'w') as f:
        json.dump({'foo': 'bar'}, f)
    config_dict.load()
    assert config_dict.is_new()

    with open(str(config_dict.path), 'w') as f:
        json.dump({'foo': 'bar'}, f)
    config_dict.load()
    assert not config_dict.is_new()
    assert config_dict == {'foo': 'bar'}


# Generated at 2022-06-11 23:19:22.789880
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile

    class TestConfigDict(BaseConfigDict):
        pass

    test_file = tempfile.mkstemp(prefix='httpie_test_config')[1]
    config = TestConfigDict(test_file)
    assert not os.path.exists(os.path.dirname(test_file))
    config.ensure_directory()
    assert os.path.exists(os.path.dirname(test_file))
    os.remove(test_file)
    os.rmdir(os.path.dirname(test_file))
    return 0

# Generated at 2022-06-11 23:19:29.739198
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    dir_path = Path().cwd()
    file_suffix = "test"
    file_path = dir_path / (file_suffix + ".json")
    cd = BaseConfigDict(file_path)

    # if no directory, then create it.
    cd.save()
    assert dir_path.exists()
    assert file_path.exists()

    # if the directory already created, just write file.
    cd.save()
    assert dir_path.exists()
    assert file_path.exists()


# Generated at 2022-06-11 23:19:38.042336
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import BaseConfigDict
    from httpie.config import ConfigFileError

    config_dict_ = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    config_dict_.load()
    assert config_dict_.get('__meta__') != None

    if os.path.exists(DEFAULT_CONFIG_DIR):
        os.remove(DEFAULT_CONFIG_DIR)
    try:
        config_dict_.load()
    except ConfigFileError:
        print('Test excpeted data')

# Generated at 2022-06-11 23:19:47.200422
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import pytest
    from pathlib import Path
    from httpie.config import BaseConfigDict

    bcd = BaseConfigDict(Path('test.json'))
    # Can load a valid json file
    with open('test.json', 'wt') as f:
        f.write('{"test": "ok"}')
    bcd.load()
    assert bcd == {'test': 'ok'}
    # Fail if the given file is not a valid json
    with open('test.json', 'wt') as f:
        f.write('{"test": "ok"')
    with pytest.raises(json.decoder.JSONDecodeError):
        bcd.load()
    # Raise an IOError if the given file doesn't exist

# Generated at 2022-06-11 23:19:57.266908
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    '''
    Test the load method of class BaseConfigDict. A file config.json is created,
    the first line has a valid json format, the second line has an invalid
    format. As a result, the method load raises an exception.
    '''
    config_file_path = 'config.json'
    with open(config_file_path, 'w') as f:
        f.write('{"foo": "bar"}')
        f.write('This line is not a valid json format.')

    config_dict = BaseConfigDict(path=config_file_path)

    try:
        config_dict.load()
    except ConfigFileError:
        return True
    except Exception:
        raise Exception
    finally:
        os.remove(config_file_path)


# Generated at 2022-06-11 23:20:07.144133
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ
    assert get_default_config_dir().name == 'httpie'
    assert get_default_config_dir().parents[0].name == 'config'

    os.environ[ENV_XDG_CONFIG_HOME] = str(Path('test/test_dir'))
    assert get_default_config_dir().parents[0].name == 'test_dir'
    del os.environ[ENV_XDG_CONFIG_HOME]

    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path('test/test_dir'))
    assert get_default_config_dir().name == 'test_dir'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-11 23:20:13.489674
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "config.json"
        config = BaseConfigDict(path)
        config['test'] = True
        config.save(fail_silently=True)
        with open(path, 'r') as f:
            data = json.load(f)
            assert data['test'] == True
            assert data['__meta__']['httpie'] == __version__



# Generated at 2022-06-11 23:20:28.050061
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from tempfile import TemporaryDirectory
    from httpie import ExitStatus

    with TemporaryDirectory() as tmpdir:
        config_file = Path(tmpdir) / 'config.json'
        config = BaseConfigDict(config_file)
        config.update({'default_options': []})
        config.save()
        with config_file.open() as f:
            json_string = f.read()
        from json import JSONDecodeError
        try:
            config = json.loads(json_string)
        except JSONDecodeError:
            assert False, 'Json decode error.'

        assert config['default_options'] == [], 'Attribute default_options error.'



# Generated at 2022-06-11 23:20:30.958770
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    output_dir = get_default_config_dir()
    print("Output Directory is "+str(output_dir))
    print("The type of output directory is "+str(type(output_dir)))



# Generated at 2022-06-11 23:20:43.054050
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import json
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import BaseConfigDict

    class TestConfig(BaseConfigDict):
        FILENAME = 'Test_config.json'
        DEFAULTS = {
            'default_options': []
        }

    test_config_path = DEFAULT_CONFIG_DIR
    test_config_file = test_config_path / 'Test_config.json'

    config = TestConfig()
    config.save()

    if not os.path.exists(test_config_path):
        print('Directory', test_config_path, 'is not created.')
        return False
    if not test_config_file.exists():
        print('Configuration file', test_config_file, 'is not created.')
        return

# Generated at 2022-06-11 23:20:46.866332
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class C(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    p = Path('./test_config')
    d = C(p)
    d.ensure_directory()
    assert (p.parent).exists()

# Generated at 2022-06-11 23:20:57.352336
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import tempfile
    import shutil

    class OSEnvironment:
        """ Mock the os.environ dict """

        def __init__(self):
            self.env = {}

        def __getitem__(self, key):
            return self.env[key]

        def __setitem__(self, key, value):
            self.env[key] = value

        def __delitem__(self, key):
            del self.env[key]

        def __iter__(self):
            return iter(self.env)

        def __len__(self):
            return len(self.env)

    def mocked_home_path(*args, **kwargs):
        """ Helper function for temporary directory creation. """
        tmp_path = tempfile.mkdtemp(suffix='httpie')
        return Path(tmp_path)

# Generated at 2022-06-11 23:21:01.117408
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(path=Path('/home/linjing/config.json'))
    config.ensure_directory()

# config = BaseConfigDict(path=Path('/home/linjing/config.json'))
# print(config.is_new())

config = Config(directory='/home/linjing')
print(config.default_options)

# config = Config()
# print(config.default_options)

# Generated at 2022-06-11 23:21:08.133182
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path

    class MyDict(BaseConfigDict):
        name = 'test_file'

    # Create temporary file
    import tempfile
    fd, path = tempfile.mkstemp(prefix='httpie-',suffix='.json')
    f = os.fdopen(fd, 'w')
    f.close()

    test_dict = MyDict(Path(path))
    test_dict.save()
    assert os.path.isfile(path)

    # Cleanup
    os.remove(path)

# Generated at 2022-06-11 23:21:16.616172
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tempdir_path = Path('c:/temp/tempdir2')
    config_path = tempdir_path / 'config.json'
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.touch()

    cfd = BaseConfigDict(config_path)
    cfd.save()

    with open(config_path, 'r') as f:
        config_file_contents = json.load(f)
    assert config_file_contents == {'__meta__': {'httpie': __version__},
                                    'help': None,
                                    'about': None}



# Generated at 2022-06-11 23:21:25.902710
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    get_default_config_dir
    ~~~~~~~~~~~~~~~~~~~~~~~~

    Should return:
    - the value set on env HTTPIE_CONFIG_DIR, if set
    - the default XDG Base Directory, if set
    - the legacy location ~/.httpie, if set
    - the default ~/.config/httpie, if no env and no previous config found
    - the default windows location %APPDATA%\httpie, if on windows
    """

    with mock.patch.dict(os.environ):
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        assert get_default_config_dir() == (
            Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME /
            DEFAULT_CONFIG_DIRNAME
        )


# Generated at 2022-06-11 23:21:30.083622
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir =  "/tmp/test_httpie_config"
    config_dir_path = Path(config_dir)
    config_dir_path.mkdir(mode=0o700)

    c = BaseConfigDict(config_dir_path)
    c.ensure_directory()

    assert os.path.isdir(config_dir) == True
    config_dir_path.rmdir()

# Generated at 2022-06-11 23:21:39.225369
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dict = BaseConfigDict(path=Path("httpie/test/config_test.json"))
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()


# Generated at 2022-06-11 23:21:41.277817
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        config = Config()
        config.load()
    except ConfigFileError as e:
        e
    else:
        assert True

# Generated at 2022-06-11 23:21:47.986702
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_dir = Path('~') / 'temp_dir'
    if temp_dir.exists():
        temp_dir.rmdir()
    temp_file = temp_dir / 'file'
    c = BaseConfigDict(path=temp_file)
    assert c.ensure_directory() == None
    assert temp_dir.exists() == True
    assert temp_dir.is_dir() == True
    temp_dir.rmdir()


# Generated at 2022-06-11 23:21:58.327166
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import py.path
    import json
    tmp_dir = py.path.local.mkdtemp()
    filename = tmp_dir.join('ut_config.json')

    class TestConfig(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path=path)

        @property
        def default_options(self):
            return self['default_options']

    test_conf = TestConfig(filename)

    test_conf.save()
    assert not test_conf.is_new()
    with open(filename, 'r') as f:
        assert json.load(f) == {'__meta__': {'httpie': __version__}}

    test_conf['default_options'] = ['--verbose']
    test_conf.save()

# Generated at 2022-06-11 23:22:03.416106
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)
            self.ensure_directory()
    directory = Path('/tmp/httpie-test')
    tmp = TestConfigDict(path=directory / 'sub-directory')
    assert tmp.path.parent.resolve() == directory.resolve()

