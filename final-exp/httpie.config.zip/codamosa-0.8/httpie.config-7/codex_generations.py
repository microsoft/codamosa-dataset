

# Generated at 2022-06-11 23:12:17.660330
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_file = tempfile.NamedTemporaryFile(delete=False)
    config_file.write(b'{"__meta__": {"httpie": "1.0.2"}, "default_options": ["--traceback"]}')
    config_file.flush()
    config_file.close()
    config = Config(directory=Path(config_file.name).parent)
    config.load()
    assert config.default_options == ['--traceback']
    assert config['__meta__'] == {'httpie': '1.0.2'}
    os.unlink(config_file.name)


# Generated at 2022-06-11 23:12:28.664112
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import httpie
    import os
    from tempfile import TemporaryDirectory
    from pathlib import Path

    from httpie.config import get_default_config_dir

    # 1. explicitly set through env
    def test_1():
        os.environ[httpie.ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
        assert get_default_config_dir() == Path('/foo/bar')
    test_1()

    # 2. Windows
    def test_2():
        from httpie.compat import is_windows
        if is_windows:
            assert get_default_config_dir().startswith(Path(os.environ['APPDATA']))

    test_2()

    # 3. legacy ~/.httpie

# Generated at 2022-06-11 23:12:36.378454
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)

    config_file = Path('./test_config.json')
    config_file.parent.mkdir(mode=0o700, parents=True)

    config_file.write_text('{"foo": "bar"}\n')
    my_config = TestConfigDict(config_file)
    assert my_config.load() == {'foo': 'bar'}



# Generated at 2022-06-11 23:12:37.630590
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()

    config.save()

# Generated at 2022-06-11 23:12:42.709311
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    config_dir = get_default_config_dir()
    if is_windows:
        assert str(config_dir) == str(DEFAULT_WINDOWS_CONFIG_DIR)
    else:
        assert str(config_dir) == str(Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)


# Generated at 2022-06-11 23:12:50.764511
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    class test_BaseConfigDict(BaseConfigDict):
        name = None   
        helpurl = None
        about = None
    
    temp = tempfile.TemporaryFile()
    path = Path(temp.name)
    path.write_text("test")
    
    try:
        config = test_BaseConfigDict(path)
        assert path.exists()
        config.save()
        config.save()
    except Exception as e:
        raise
    finally:
        path.unlink()
        


# Generated at 2022-06-11 23:12:57.600485
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    base = BaseConfigDict(path=path)
    # load if path exists
    path.mkdir()
    assert not base.is_new()
    base.load()
    # raise error if path not exists
    path.rmdir()
    assert base.is_new()
    try:
        base.load()
    except ConfigFileError:
        assert True


# Generated at 2022-06-11 23:13:05.694845
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    # no test file
    with pytest.raises(ConfigFileError) as e:
        path = Path('no-file')
        config = BaseConfigDict(path)
        config.load()
    assert e.value.args[0] == 'cannot read baseconfigdict file: [Errno 2] No such file or directory: \'no-file\''

    # invalid json
    with pytest.raises(ConfigFileError) as e:
        path = Path('./test.json')
        config = BaseConfigDict(path)

        # no test file
        with pytest.raises(ConfigFileError) as e:
            path = Path('no-file')
            config = BaseConfigDict(path)
            config.load()

# Generated at 2022-06-11 23:13:17.735329
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    xdg_env = 'XDG_CONFIG_HOME'
    if xdg_env in os.environ:
        del os.environ[xdg_env]

    path = get_default_config_dir()
    assert path.parts[-1] == DEFAULT_CONFIG_DIRNAME
    assert os.environ[xdg_env] == str(Path.home() / '.config')
    assert os.environ[xdg_env] == str(path.parent)

    os.environ[xdg_env] = 'test'

# Generated at 2022-06-11 23:13:19.396091
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:13:27.461353
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Test(BaseConfigDict):
        def __init__(self, path):
            self.path = path
            self.deleted = False
            self.file_exists = False

        def delete(self):
            self.deleted = True

    path = Path('test_file')
    fake_test = Test(path)
    fake_test.file_exists = True
    fake_test.load()
    assert fake_test.deleted
    fake_test.deleted = False
    fake_test.file_exists = False
    fake_test.load()
    assert not fake_test.deleted


# Generated at 2022-06-11 23:13:28.051030
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass

# Generated at 2022-06-11 23:13:37.590393
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class BaseConfigDict_Subclass(BaseConfigDict):
        name = None
        helpurl = None
        about = None
        def __init__(self, path: Path):
            super().__init__(path)
            self.path = path

    path = Path(os.getcwd() + '/httpie/config/test_config.json') 
    b = BaseConfigDict_Subclass(path)
    assert b == {}, 'load() function didn\'t work'
    b.load()
    assert b == {'test': 'test'}, 'load() function didn\'t work'

# Generated at 2022-06-11 23:13:44.587934
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from io import StringIO
    from unittest.mock import patch

    with patch('httpie.config.Path') as PathMock:
        PathMock.open.return_value = StringIO('{"test_key":"test_value"}')
        path = PathMock()
        config = BaseConfigDict(path=path)
        config.load()
        assert config['test_key'] == 'test_value'



# Generated at 2022-06-11 23:13:52.796755
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import DEFAULT_CONFIG_DIR, BaseConfigDict
    path = DEFAULT_CONFIG_DIR / "test"
    bc = BaseConfigDict(path)
    assert path.parent.exists() == False
    bc.ensure_directory()
    path.parent.mkdir(mode=0o700, parents=False)
    assert path.parent.exists() == True
    bc.ensure_directory()
    assert path.parent.exists() == True
    path.parent.rmdir()
    assert path.parent.exists() == False


# Generated at 2022-06-11 23:14:02.031409
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # The following is assumed to be the per-user config directory
    # (XDG_CONFIG_HOME), or the default one if the environment variable is
    # unset.
    per_user_config_dir = Path.home() / '.config'
    expected_config_dir = per_user_config_dir / 'httpie'

    # By default, the config directory is returned
    assert (
        get_default_config_dir() == expected_config_dir
    )

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ[ENV_XDG_CONFIG_HOME] = ''

    # When XDG_CONFIG_HOME is empty, the per-user config directory should be
    # returned.

# Generated at 2022-06-11 23:14:09.693715
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        name = None
        helpurl = None
        about = None

    assert TestConfig(path = Path('./test_config')).load() == {}
    assert TestConfig(path = Path('./test_config')).load() == {'__meta__': {'httpie': __version__}}
    # assert TestConfig(path = Path('./test_config')).load() == {'__meta__': {'httpie': __version__}}


if __name__ == '__main__':
    print('Test for method load of class BaseConfigDict')
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:14:20.658194
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    if is_windows:
        assert get_default_config_dir() == Path(
            os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    else:
        assert get_default_config_dir() == Path.home() / '.config' / DEFAULT_CONFIG_DIRNAME

    # $XDG_CONFIG_HOME set
    xdg_config_home = Path('~/.config_home').expanduser()
    os.environ[ENV_XDG_CONFIG_HOME] = str(xdg_config_home)
    assert get_default_config_dir

# Generated at 2022-06-11 23:14:24.610567
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from unittest.mock import mock_open

    with mock_open():
        cfg = BaseConfigDict("./config.json")
        assert cfg.ensure_directory() is None



# Generated at 2022-06-11 23:14:30.728927
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from moto import mock_s3
    from moto import mock_s3
    from boto3.session import Session


    from httpie.plugins import plugin_manager

    @mock_s3
    def test_s3_session(path='test/config.json'):
        user_config = Config(path)
        user_config.ensure_directory()


test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-11 23:14:39.084422
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(None)
    config_dict.update({"__meta__": {"httpie": "0.9.8", "help": None, "about": None}})
    config_dict.save()

# Generated at 2022-06-11 23:14:48.645340
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path("test_BaseConfigDict_load.json")
    ccd = BaseConfigDict(path)

    # test empty file
    with path.open('w') as f:
        f.write("")

    ccd.load()
    path.unlink()

    # test invalid value
    with path.open('w') as f:
        f.write("invalid")

    try:
        ccd.load()
        assert False
    except ConfigFileError:
        pass

    path.unlink()

    # test valid value
    with path.open('w') as f:
        json.dump({'abc':123}, f)

    ccd.load()

    assert ccd == {'abc':123}

    path.unlink()

# Generated at 2022-06-11 23:14:49.752637
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    pass


# Generated at 2022-06-11 23:15:01.763618
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path("/home/user/.httpie")
    config_path = config_dir / 'config.json'

    try:
        config_dir.rmdir()
    except:
        pass

    config = Config(config_dir)
    assert config.is_new() == True
    config.default_options = ["--body", "--verbose"]

    config.save()
    assert config.is_new() == False

    new_config = Config(config_dir)
    assert new_config.is_new() == False
    assert new_config.default_options == ["--body", "--verbose"]
    
    try:
        config_dir.rmdir()
    except:
        pass

# Generated at 2022-06-11 23:15:12.545665
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # 1. work on windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        # should not check the value of environment variables on windows
        return

    # 2. check environment variables
    env_config_dir = get_default_config_dir()
    env_dir = Path(os.environ[ENV_HTTPIE_CONFIG_DIR])
    assert env_config_dir == env_dir

    # 3. check legacy directory
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    assert get_default_config_dir() == legacy_config_dir

    # 4. check xd

# Generated at 2022-06-11 23:15:18.575358
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        os.mkdir("~/test_base")
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    os.chdir("~/test_base")
    config = BaseConfigDict("/test")
    config.ensure_directory()
    os.remove("~/test_base")



# Generated at 2022-06-11 23:15:25.859369
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    # python -m httpie.config
    #
    # python -m httpie.config.__main__
    #
    # python -m httpie.config.test_BaseConfigDict_load
    if __package__ is None or __package__ == '':
        from .. import __main__
    else:
        from . import __main__
    __main__.main()


if __name__ == '__main__':
    import unittest


    class UnitTest(unittest.TestCase):

        @unittest.skip('test_BaseConfigDict_load')
        def test_BaseConfigDict_load(self):
            test_BaseConfigDict_load()


    unittest.main()

# Generated at 2022-06-11 23:15:27.774865
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict_obj = BaseConfigDict(Path("Config.json"))
    config_dict_obj.save()

# Generated at 2022-06-11 23:15:38.953455
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    env = os.environ.copy()
    test_dir = Path.home() / Path('test/config/dir')
    test_dir.mkdir(parents=True, exist_ok=True)

    # no env var
    os.environ.clear()
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # non-existent env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(test_dir)
    assert get_default_config_dir() == test_dir

    # windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_CONFIG_DIR

    # non-existent env & XDG
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(test_dir)
    os.en

# Generated at 2022-06-11 23:15:48.148215
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    old_create_config_dir = create_config_dir
    config_dir = Path('/tmp/httpie_config_dir/new_dir')
    try:
        def create(dir):
            global config_dir
            config_dir = dir

        create_config_dir = create
        cfg = Config()
        cfg.ensure_directory()
        assert os.path.isdir(config_dir)
    finally:
        create_config_dir = old_create_config_dir
        parent_dir = config_dir.parent
        while parent_dir != Path('/tmp'):
            os.rmdir(parent_dir)
            parent_dir = parent_dir.parent
        os.rmdir(Path('/tmp/httpie_config_dir'))

# Generated at 2022-06-11 23:15:59.794867
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test on Unix-like system
    if hasattr(os, 'getuid'):
        assert get_default_config_dir() == Path.home() / '.config/httpie'
    # Test on Windows system
    else:
        assert get_default_config_dir() == Path(os.environ['APPDATA']) / 'httpie'


# Generated at 2022-06-11 23:16:07.889931
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    directory = Path('./testdir/')
    config_path = directory/'config.json'
    config = BaseConfigDict(config_path)
    # First save may fail because the directory does not exist.
    # In this case we create the directory and try again
    try:
        config.save(fail_silently=True)
        config.save(fail_silently=False)
    except ConfigFileError:
        directory.mkdir(mode=0o700, parents=True)
        config.save(fail_silently=False)


# Generated at 2022-06-11 23:16:12.308404
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    filename = "test_file.json"
    filepath = "/tmp"

    bc = BaseConfigDict(path=Path(filepath)/filename)
    bc.ensure_directory()
    assert os.path.isdir(filepath), "Directory not created"



# Generated at 2022-06-11 23:16:18.645699
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    config_json = os.path.join(tmp_dir, "test.json")

    test_config_dict = BaseConfigDict(Path(config_json))
    test_config_dict.ensure_directory()

    assert os.path.exists(config_json)

    shutil.rmtree(tmp_dir)



# Generated at 2022-06-11 23:16:27.028562
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie import ExitStatus
    from httpie.client import Environment
    import pytest

    config = Config()
    config.ensure_directory()
    with config.path.open('wt') as f:
        f.write('a:1')
    with pytest.raises(Exception) as excinfo:
        config.load()
    assert 'invalid config file' in str(excinfo.value)
    config.path.unlink()


if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:16:33.356818
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    '''
    Create custom instance of BaseConfigDict and ensure that directory is created
    '''
    class TestConfig(BaseConfigDict):
        name = 'test_config'
        helpurl = 'https://httpie.org/docs'
        about = 'test_about'
    config_file = Path('test.json')
    test_config = TestConfig(path = config_file)
    os.rmdir(os.path.split(config_file)[0])
    test_config.ensure_directory()
    assert os.path.exists(os.path.split(config_file)[0])


# Generated at 2022-06-11 23:16:37.681819
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    myConfigDict = {'color':'red'}
    configDict = BaseConfigDict(path = "config.json")
    configDict['color'] = myConfigDict['color']
    configDict.save(fail_silently = True)

# Generated at 2022-06-11 23:16:44.725334
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('.'))
    config['a'] = 'b'
    config['b'] = 1
    config['c'] = 2.0
    config.save()

    with config.path.open('rt') as f:
        json_string = f.read()

    expected_json_string = ("""{
    "a": "b",
    "b": 1,
    "c": 2.0
}
""")
    assert json_string == expected_json_string


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:16:55.870827
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class MyConfig(BaseConfigDict):
        name = 'MyConfig'
        helpurl = 'http://myconfig.com'
        about = 'about my config'

        def __init__(self, path: Path):
            super().__init__(path)
            self.update({
                'header1': 'foo',
                'header2': 'bar',
                '__meta__': {
                    'httpie': '1.0.0',
                    'help': 'http://myconfig.com',
                    'about': 'about my config'
                }
            })

    # Create a temporary directory
    temp_dir = tempfile.TemporaryDirectory()
    temp_path = Path(temp_dir.name)
    temp_file = temp_path / 'config_test'

    # Create the config.json file

# Generated at 2022-06-11 23:16:59.296755
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_file = Config()
    if config_file.is_new():
        config_file.ensure_directory()
        config_file.save()
    assert config_file.directory.exists()

# Generated at 2022-06-11 23:17:17.564314
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import tempfile
    from pathlib import Path
    from httpie.config import get_default_config_dir

    home_dir = Path.home()

    # Existing legacy config dir
    legacy_config_dir = home_dir / Path('.httpie')
    legacy_config_dir.mkdir(mode=0o700, parents=True)
    assert get_default_config_dir() == legacy_config_dir

    # No legacy config dir - no XDG env - default XDG config dir in home
    legacy_config_dir.rmdir()
    default_xdg_config_dir = home_dir / Path('.config') / Path('httpie')
    assert get_default_config_dir() == default_xdg_config_dir

    # No legacy config dir - has XDG env - custom XDG config

# Generated at 2022-06-11 23:17:26.800971
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    file_to_test = './test_BaseConfigDict_save.txt'
    file = open(file_to_test, 'w+')
    file.close()
    class BaseConfigDictTest(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)


    BaseConfigDictTest(Path(file_to_test)).save()
    with open(file_to_test, 'r') as p:
        config_data = json.load(p)
        parsed_data = config_data.get('__meta__')
        assert parsed_data is not None
        assert parsed_data['httpie'] is not None
        assert parsed_data['about'] is None
        assert parsed_data['help'] is None


# Generated at 2022-06-11 23:17:35.531540
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    
    def test_load_config_file_fail_silently_ENOENT(self):
        """
        An IOError with an errno of ENOENT is silently swallowed.
        """
        config_file = Path('./some_file')
        config_file.touch()
        
        def __init__(self, path):
            self.path = config_file
        
        with mock.patch.object(BaseConfigDict, '__init__', side_effect=__init__):
            c = BaseConfigDict()
            c.load()        
        
        try:
            os.remove(config_file)
        except OSError as e:
            if e.errno != errno.ENOENT:
                raise
    

# Generated at 2022-06-11 23:17:41.820351
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    home_dir = Path.home()
    file_path = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR / 'test_config.json'
    if file_path.exists():
        file_path.unlink()
    base = BaseConfigDict(path=file_path)
    base.save()
    assert True == file_path.exists()
    file_path.unlink()



# Generated at 2022-06-11 23:17:45.907657
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    my_config = BaseConfigDict(path="./config.json")
    my_config.update({'default_options': []})
    my_config.save()
    my_config.load()
    my_config.update({'default_options': ['--pretty','all']})
    my_config.save(fail_silently=True)
    os.remove("./config.json")


# Generated at 2022-06-11 23:17:48.480263
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    with open('test.txt', 'w') as file:
        file.write('{}')


if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:17:54.247415
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if 'XDG_CONFIG_HOME' in os.environ:
        del os.environ['XDG_CONFIG_HOME']
    p = get_default_config_dir()
    if os.name == 'nt':
        assert str(p) == 'C:\\Users\\travis\\AppData\\Roaming\\httpie'
    else:
        assert str(p) == '/home/travis/.config/httpie'

# Generated at 2022-06-11 23:17:57.023305
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import appdirs
    config = BaseConfigDict(appdirs.user_config_dir(appname=__file__, appauthor=__file__)+'config.json')
    config.load()
    config.clear()
    config.save()
    config.load()

# Generated at 2022-06-11 23:18:08.714956
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Use this test on FDroid but not Travis CI due to 
    # https://github.com/httpie/httpie/issues/2439
    if os.getenv('TRAVIS') or os.getenv('SETUPPY_BUILD_EXTENSION'):
        return
    default_config_dir = get_default_config_dir()
    # legacy ~/.httpie
    legacy_config_dir = Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    # XDG
    xdg_config_home_dir = os.environ.get(
        ENV_XDG_CONFIG_HOME,
        Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    )
    config_dir = Path(xdg_config_home_dir) / DE

# Generated at 2022-06-11 23:18:18.975786
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def mocked_home_path(path):
        return '{:s}/{:s}'.format('/home/user', path)
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'env_config_dir'
    # 2. Windows
    if is_windows:
        default_config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    # 3. legacy ~/.httpie
    legacy_config_dir = mocked_home_path(DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)
    if Path(legacy_config_dir).exists():
        default_config_dir = legacy_config_dir
    # 4. XDG

# Generated at 2022-06-11 23:18:41.806825
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    import json
    import os
    import tempfile
    import unittest
    class BaseConfigDictTest(unittest.TestCase):
        def setUp(self):
            self.valid_json_file1 = tempfile.NamedTemporaryFile(mode='w+')
            self.valid_json_file2 = tempfile.NamedTemporaryFile(mode='w+')
            self.valid_json_file1.write(json.dumps({"key": "value"}))
            self.valid_json_file2.write(json.dumps({"key1": "value1", "key2": "value2"}))
            self.invalid_json_file = tempfile.NamedTemporaryFile(mode='w+')
            self.invalid_json_file

# Generated at 2022-06-11 23:18:46.011458
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    str_test_dir = "tmp/test_dir"
    path_test_dir = Path(str_test_dir)
    obj = BaseConfigDict(path_test_dir)
    obj.ensure_directory()
    assert path_test_dir.is_dir()


# Generated at 2022-06-11 23:18:48.648985
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path=Path('./json_config/config.json'))
    config_dict.save(fail_silently=False)

# Generated at 2022-06-11 23:18:51.732261
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict = BaseConfigDict(Path(''))
    base_config_dict.ensure_directory()
    assert os.path.exists(base_config_dict.path.parent)

# Generated at 2022-06-11 23:19:02.867167
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import DEFAULT_WINDOWS_CONFIG_DIR, get_default_config_dir
    from httpie.compat import is_windows
    import shutil

    if is_windows:
        DEFAULT_CONFIG_DIR = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        DEFAULT_CONFIG_DIR = get_default_config_dir()

    temp_config_dir = DEFAULT_CONFIG_DIR / 'unittest'
    if not temp_config_dir.exists():
        temp_config_dir.mkdir()
    test_config_file = temp_config_dir / 'test_ensure_directory'

    # temp_config_file exist
    test_config_file.touch()
    test_BaseConfigDict = BaseConfigDict(test_config_file)

# Generated at 2022-06-11 23:19:06.248642
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_path = Path('testdir')
    config = BaseConfigDict(path=config_path)
    config.save()
    assert config_path.exists() is True
    config.delete()
    assert config_path.exists() is False


# Generated at 2022-06-11 23:19:07.760689
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config=Config(directory='/tmp/httpie_config/config.json')
    config.save()


# Generated at 2022-06-11 23:19:18.369248
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/foo'
    assert get_default_config_dir() == Path('~/foo')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        assert (get_default_config_dir() ==
                Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME)

    os.environ[ENV_XDG_CONFIG_HOME] = '~/foo'
    assert get_default_config_dir() == '~/foo/httpie'
    del os.environ[ENV_XDG_CONFIG_HOME]

    # should use the default value of $XDG_CONFIG_HOME
   

# Generated at 2022-06-11 23:19:22.981173
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    test_path = Path('/root/base_config.json')
    bcd = BaseConfigDict(test_path)
    assert bcd.load() is None
    try:
        assert bcd.load() is not None
    except Exception as e:
        assert e


# Generated at 2022-06-11 23:19:25.155672
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert DEFAULT_CONFIG_DIR == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-11 23:19:57.982771
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # If a directory exists, nothing should happen.
    path = Path('/tmp/test/test')
    path.mkdir(parents=True, exist_ok=True)
    test_dict = BaseConfigDict(path)
    try:
        test_dict.ensure_directory()
    except OSError:
        raise AssertionError("An OSError was raised.")

    # If a directory does not exist, it should be created.
    path = Path('/tmp/test/test2')
    test_dict = BaseConfigDict(path)
    try:
        test_dict.ensure_directory()
    except OSError:
        raise AssertionError("An OSError was raised.")

# Generated at 2022-06-11 23:20:02.198816
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    mock_path = Path('/test/path')
    class MockConfigDict(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path=path)

    config = MockConfigDict(mock_path)
    config.save(fail_silently=True)


# Generated at 2022-06-11 23:20:08.573093
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_BaseConfigDict_ensure_directory/')
    config_path = config_dir / 'config_file'
    try:
        config = BaseConfigDict(config_path)
        config.ensure_directory()
        assert Path('/tmp/test_BaseConfigDict_ensure_directory/').exists()
    finally:
        shutil.rmtree(config_dir)



# Generated at 2022-06-11 23:20:10.051401
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert Path.home().name in str(DEFAULT_CONFIG_DIR)

# Generated at 2022-06-11 23:20:16.498276
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    config_path = config_dir / 'config.json'
    config = Config(config_dir)

    def clean_up():
        try:
            os.remove('config.json')
        except:
            pass
        os.rmdir(config_dir)

    clean_up()
    config.save()
    assert config_path.exists() == True
    clean_up()



# Generated at 2022-06-11 23:20:24.872485
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    # create a temporary directory
    with tempfile.TemporaryDirectory() as directory:
        # httpie configuration directory
        httpie_config_dir = Path(directory) / DEFAULT_CONFIG_DIRNAME
        # httpie config file name
        config_file_name = 'test_config.json'
        # httpie config file path
        config_file_path = httpie_config_dir / config_file_name

        # create an instance of the class TestConfigDict
        test_config_dict = TestConfigDict(config_file_path)
        # create a new configuration file
        test_config_dict.save()
        # assert that the configuration file has been created

# Generated at 2022-06-11 23:20:34.204024
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    # Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(
        Path('/a/b/c').expanduser())
    assert get_default_config_dir() == Path('/a/b/c')

    # 2. Windows
    assert not is_windows

    # 3. legacy ~/.httpie
    home = Path.home()
    legacy = home / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    legacy.touch()

    assert get_default_config_dir() == legacy

    legacy.unlink()

    # 4. XDG default config dir
    xdg_default = home / DEFAULT_

# Generated at 2022-06-11 23:20:37.155166
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Config(BaseConfigDict):
        pass

    config = Config('config.json')
    config.load()
    assert '__meta__' in config

# Generated at 2022-06-11 23:20:47.197748
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create directory for the test
    test_dir = DEFAULT_CONFIG_DIR / "test"
    test_dir.mkdir(mode=0o700, parents=True)
    test_file = DEFAULT_CONFIG_DIR / "test" / "config.json"
    assert os.path.exists(DEFAULT_CONFIG_DIR / "test")
    assert not test_file.exists()

    # test base config dict
    test_base_conf = BaseConfigDict(test_file)
    assert test_file.parent == test_dir
    assert test_base_conf.path == test_file
    assert not test_file.exists()

    # write to the test file
    test_base_conf.load()
    test_base_conf['test'] = {'test': "test"}
    test_

# Generated at 2022-06-11 23:20:54.516691
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    temp_dir_path = Path(tempfile.mkdtemp())
    test_config_file_path = temp_dir_path / 'config.json'
    test_config_dict = BaseConfigDict(test_config_file_path)
    assert test_config_dict.is_new()
    test_config_dict.save()
    assert test_config_file_path.exists()
    assert not test_config_dict.is_new()    
    test_config_file_path.unlink()


# Generated at 2022-06-11 23:21:57.502855
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import shutil
    config_file_folder = 'config_file_folder'
    config_file_path = './config_file_folder/config_file.json'
    if not os.path.exists(config_file_path):
        os.makedirs(config_file_folder)
    config_dict = BaseConfigDict(Path(config_file_path))
    config_dict.ensure_directory()
    assert os.path.exists(config_file_folder)
    shutil.rmtree(config_file_folder)

# Generated at 2022-06-11 23:22:04.699759
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # INPUT: directory_path = tmp/test_directory
    # EXPECTED OUTPUT: directory_path exists

    directory_path = os.getcwd() + "/tmp/test_directory"
    if os.path.exists(directory_path):
        shutil.rmtree(directory_path)
    config_dict = BaseConfigDict(directory_path)
    config_dict.ensure_directory()
    assert os.path.exists(directory_path)

    # Clean up
    if os.path.exists(directory_path):
        shutil.rmtree(directory_path)
