

# Generated at 2022-06-11 23:12:15.742795
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert isinstance(DEFAULT_CONFIG_DIR, Path)
    assert DEFAULT_CONFIG_DIR.exists()
    assert DEFAULT_CONFIG_DIR.is_dir()
    assert DEFAULT_CONFIG_DIR / Config.FILENAME

# Unit tests for class Config

# Generated at 2022-06-11 23:12:25.660477
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test with no env. variable.
    # On Unix systems it would return /home/user/.config/httpie/config.json
    # On Windows systems it would return %APPDATA%\httpie\config.json
    home_dir = Path.home()
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()

    # Test the legacy directory for Linux systems.
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    try:
        legacy_config_dir.mkdir(mode=0o700)
        assert legacy_config_dir == get_default_config_dir()
    finally:
        legacy_config_dir.rmdir()

    # Test with explicit configuration directory.

# Generated at 2022-06-11 23:12:30.015948
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    temp_path = Path(tempfile.gettempdir()) / 'test_httpie'
    file = BaseConfigDict(temp_path)
    file.ensure_directory()
    assert temp_path.parent.exists()

# Generated at 2022-06-11 23:12:32.425437
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    a = BaseConfigDict(path='temp.json')
    a.load()
    

# Generated at 2022-06-11 23:12:41.274171
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmp_path = Path('/tmp')
    tmp_file = tmp_path / 'test001.txt'
    tmp_content = 'test001'

    # create file and make sure its exist
    tmp_file.touch()
    assert tmp_file.exists(), 'Test file exists.'

    # create BaseConfigDict class and set file path
    tmp_BaseConfigDict = BaseConfigDict(tmp_file)

    # make sure file has no content
    assert tmp_file.read_text() == '', 'Test file has no content.'

    # make sure tmp_file is a file not directory
    assert tmp_file.is_file(), 'Test file is a file.'

    # change tmp_file's parent directory's access code
    tmp_file.parent.chmod(0o100)

    # make sure tmp_file's parent

# Generated at 2022-06-11 23:12:46.724381
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('test.js')
    config2 = BaseConfigDict('test.js')
    config['a'] = 'aaa'
    config['b'] = 'bbb'
    config.save()
    config2.load()
    assert config == config2

# Generated at 2022-06-11 23:12:54.029394
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Case 1. When the parent directory of the config_file doesn't exist,
    #          it can be created and all the intermediate-level directories
    #          are created if they don't exist.
    try:
        test_dir = Path('test_ensure_directory')
        test_dir.mkdir()
        config_file = Path('test_ensure_directory/temp/config.json')
        config_file.parent.mkdir()
        config_file.parent.rmdir()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    finally:
        test_dir.rmdir()

    # Case 2. The parent directory of the config_file does exist
    #          but the access mode is not 0o700, this will raise
    #          a Permission

# Generated at 2022-06-11 23:12:56.644297
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        test_dict = BaseConfigDict("test.txt")
        test_dict.load()
    except ConfigFileError:
        print("Invalid format")


# Generated at 2022-06-11 23:13:03.418955
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import unittest
    class TestBaseConfigDict(unittest.TestCase):
        def test_BaseConfigDict_ensure_directory(self):
            with TemporaryDirectory() as temporary_directory:
                p = Path(temporary_directory)
                c = BaseConfigDict(path=p / 'config.json')
                c.ensure_directory()
                self.assertTrue(c.path.parent.exists())
    unittest.main(verbosity=2)


# Generated at 2022-06-11 23:13:11.538353
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.context import Environment
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    Environment.config_dir = config_dir
    Environment.config = Config()

    config_path = Environment.config.path
    config_path.parent.mkdir(mode=0o700, parents=True)
    assert config_path.parent.is_dir()
    try:
        config_path.parent.rmdir()
    except OSError as e:
        assert e.errno == errno.ENOTEMPTY

# Generated at 2022-06-11 23:13:23.274336
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # input_env = {}
    # output = get_default_config_dir(env=input_env)
    #
    # assert output == Path('~/.config/httpie')

    input_env = {ENV_XDG_CONFIG_HOME: '/tmp/config'}
    output = get_default_config_dir(env=input_env)

    assert output == Path('/tmp/config/httpie')

    input_env = {ENV_HTTPIE_CONFIG_DIR: '/tmp'}
    output = get_default_config_dir(env=input_env)

    assert output == Path('/tmp')
    return



# Generated at 2022-06-11 23:13:34.579218
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def get_expect(path_A, path_B):
        return set([p.expanduser().resolve() for p in [path_A, path_B]])

    def get_result():
        return set([
            p.expanduser().resolve()
            for p in [DEFAULT_CONFIG_DIR, get_default_config_dir()]
        ])

    assert get_result() == get_expect(DEFAULT_CONFIG_DIR, DEFAULT_WINDOWS_CONFIG_DIR)

    assert get_result() == get_expect(DEFAULT_CONFIG_DIR, Path.home() / '.config' / DEFAULT_CONFIG_DIRNAME)

    assert get_result() == get_expect(DEFAULT_CONFIG_DIR, Path.home() / '.httpie')

# Generated at 2022-06-11 23:13:44.278367
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()
    config_file = BaseConfigDict(path=Path(temp_dir) / "test_save.json")
    config_file['key'] = "value"
    config_file.save()
    assert config_file['key'] == "value"

    config_file = BaseConfigDict(path=Path(temp_dir) / "test_save.json")
    config_file.load()
    assert config_file['key'] == "value"
    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 23:13:47.218126
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    instance=BaseConfigDict(Path("/root/httpie/httpie/config.json"))
    instance.save()


# Generated at 2022-06-11 23:13:55.768560
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    _ConfigFileError = ConfigFileError

# Generated at 2022-06-11 23:14:04.324237
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_config_dir = Path(os.path.dirname(__file__)) / 'test_config'
    class TestConfig(BaseConfigDict):
        name = None
        helpurl = None
        about = 'Test config file'

    test_config = TestConfig(path=test_config_dir / 'test.json')
    test_config['foo'] = 'bar'
    test_config.save()
    test_config = TestConfig(path=test_config_dir / 'test.json')
    test_config.load()
    assert test_config['foo'] == 'bar'

    test_config.delete()
    assert not test_config.path.exists()

# Generated at 2022-06-11 23:14:10.417311
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():

    class MyBaseConfigDict(BaseConfigDict):
        name = 'my'

    my_config_file_path = Path('~/.httpie/my.json')
    my_config = MyBaseConfigDict(path=my_config_file_path)
    my_config.load()
    assert my_config['__meta__']['httpie'] == __version__
    assert my_config['__meta__']['help'] == 'https://httpie.org/doc#my'

# Generated at 2022-06-11 23:14:18.384614
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    dir = Path.cwd() / 'httpie'
    config_path = dir / 'config.json'
    try:
        if config_path.exists():
            config_path.unlink()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise
    config.save()
    assert config_path.exists() and config_path.is_file()
    config_path.unlink()



# Generated at 2022-06-11 23:14:20.413697
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    config = Config()
    config.save(fail_silently=True)


# Generated at 2022-06-11 23:14:24.403460
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path('config.json'))
    config['default_options'] = []
    if not config.is_new():
        config.load()
    assert(config['default_options'] == [])

# Generated at 2022-06-11 23:14:35.864913
# Unit test for function get_default_config_dir
def test_get_default_config_dir():

    os.unsetenv(ENV_XDG_CONFIG_HOME)
    os.unsetenv(ENV_HTTPIE_CONFIG_DIR)
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # override with explicitly set env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/my_path'
    assert get_default_config_dir() == '/my_path'
    os.unsetenv(ENV_HTTPIE_CONFIG_DIR)

    # override with XDG
    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg'
    assert get_default_config_dir() == '/xdg' / DEFAULT_CONFIG

# Generated at 2022-06-11 23:14:45.021726
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # setup
    env = os.environ
    orig_config_dir = env.get(ENV_HTTPIE_CONFIG_DIR)
    orig_xdg_config_home = env.get(ENV_XDG_CONFIG_HOME)
    orig_is_windows = is_windows

    # default
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    is_windows = False
    actual_default_config_dir = get_default_config_dir()
    expected_default_config_dir = Path.home() / Path('.config') / 'httpie'
    assert actual_default_config_dir == expected_default_config_dir

    # $HTTPIE_CONFIG_DIR
    os

# Generated at 2022-06-11 23:14:58.248549
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def set_environ_clear_cache(**kwargs):
        old_environ = os.environ
        try:
            os.environ = os.environ.copy()
            os.environ.update(**kwargs)
            from httpie import config as _config
            # Clear the cached property
            reload(_config)
        finally:
            os.environ = old_environ

    def assert_xdg_env(xdg_config_home, expected_dir):
        set_environ_clear_cache({ENV_XDG_CONFIG_HOME: xdg_config_home})
        assert get_default_config_dir() == expected_dir
        assert DEFAULT_CONFIG_DIR == expected_dir

    # The default current user directory is the current user's home
    # with a `.config`

# Generated at 2022-06-11 23:15:08.624918
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create parent of config file
    config_file = DEFAULT_CONFIG_DIR / '__temp__'
    try:
        config_file.parent.mkdir(mode=0o700, parents=True)
    except OSError as e:
        if e.errno != errno.EEXIST:
            assert e.errno != errno.EEXIST
    # create config file
    try:
        config_file.touch()
    except IOError as e:
        if e.errno != errno.ENOENT:
            assert e.errno != errno.ENOENT
    finally:
        config_file.unlink()

test_BaseConfigDict_ensure_directory()

# Generated at 2022-06-11 23:15:11.100261
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config['test'] = "test"
    config.save()
    assert config.path.exists()
    config.delete()


# Generated at 2022-06-11 23:15:16.884043
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    """
    ensure_directory()
    save()
    """
    test_config_dict = BaseConfigDict(Path('./test.json'))
    assert (
        test_config_dict.is_new() == True
    ), "BaseConfigDict.is_new() works incorrectly"
    test_config_dict.save()
    test_config_dict_pickle_path = Path('./test.pkl')
    assert (
        test_config_dict.is_new() == False
    ), "BaseConfigDict.is_new() works incorrectly"
    with test_config_dict_pickle_path.open('wb') as f:
        pickle.dump(test_config_dict, f, pickle.HIGHEST_PROTOCOL)

# Generated at 2022-06-11 23:15:21.580788
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file_path = Path.home() / "temp_test_save.json"
    config_file = BaseConfigDict(config_file_path)
    config_file['user1'] = 'blue'
    config_file['user2'] = 'red'
    config_file.save()


# Generated at 2022-06-11 23:15:32.761256
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Check if load() method works
    class config(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    file_path = Path('test.json')

    config_file_content = {
        "helpurl": "https://github.com/jakubroztocil/httpie",
        "about": "HTTPie: a CLI, cURL-like tool for humans.",
        "__meta__": {"httpie": "1.0.3", "help": "https://github.com/jakubroztocil/httpie"},
        "default_options": ["--form"]
    }

# Generated at 2022-06-11 23:15:41.359351
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():

    # For tests, the path of the directory where the config json file is saved is hardcoded with a test dir
    # The code will create 2 config json files:
    #       1. one with a valid content
    #       2. one with an invalid content
    config_dir = Path(os.path.dirname(os.path.realpath(__file__))) / "test_dir"

    # The content of the valid config json file
    valid_config_content = {
        "default_options": [],
        "__meta__": {
            "about": "HTTPie is a command line HTTP client.\nLengthy documentation at: https://httpie.org",
            "help": "https://httpie.org/docs",
            "httpie": "2.2.0"
        }
    }

    # test with a valid content


# Generated at 2022-06-11 23:15:50.278905
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # create directory does not exist
    config_dict = BaseConfigDict(Path('/test/test.json'))
    config_dict.ensure_directory()
    assert Path('/test').is_dir()
    assert not Path('/test/test.json').exists()

    # create directory exists
    Path('/test').rmdir()
    os.mkdir('/test')
    config_dict = BaseConfigDict(Path('/test/test.json'))
    config_dict.ensure_directory()
    assert Path('/test').is_dir()
    assert not Path('/test/test.json').exists()

    # remove directory
    Path('/test').rmdir()


# Generated at 2022-06-11 23:15:57.710917
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmp_file = Path('./temp.json')
    try:
        conf = BaseConfigDict(tmp_file)
        conf.save()
        assert tmp_file.exists()
    except Exception as e:
        print(e)
        assert False
    finally:
        tmp_file.unlink()



# Generated at 2022-06-11 23:16:01.728034
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = get_default_config_dir()
    path = config_dir / 'test.json'
    config = BaseConfigDict(path)
    config.ensure_directory()
    assert path.exists()
    path.unlink()
    assert path.parent.exists()



# Generated at 2022-06-11 23:16:11.412562
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import re
    from httpie.config import ENV_HTTPIE_CONFIG_DIR
    from httpie import __version__
    path = 'C:\\Users\\nk2o4\\OneDrive\\Documents\\GitHub\\httpie\\test_config.json'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = path
    config = Config()
    config.save(fail_silently=True)
    with open(config._BaseConfigDict__path,'r') as f:
        result = re.findall('.*httpie.*',str(f.read()))
        assert __version__ in result[0]

# Generated at 2022-06-11 23:16:21.409536
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == Path('/foo/bar')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        os.environ[ENV_XDG_CONFIG_HOME] = '/foo/bar'
        assert get_default_config_dir() == Path('/foo/bar')
        del os.environ[ENV_XDG_CONFIG_HOME]
        assert get_default_config_dir() == DEFAULT_RELATIVE_XDG_CON

# Generated at 2022-06-11 23:16:24.089092
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path = ".")
    config_dict.save(fail_silently=False)
    os.remove("./__meta__")

# Generated at 2022-06-11 23:16:30.097521
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    testDir = "testdir_BaseConfigDict"
    testFile = f"{testDir}/config.json"
    with open(testFile, "w") as f:
        f.write('{"default_options": []}')

    test = BaseConfigDict(testFile)
    test.ensure_directory()
    test.save()
    assert os.path.exists(testFile)
    with open(testFile) as f:
        assert f.read() == '{"__meta__": {"httpie": "0.9.9"}, "default_options": []}'

    test['default_options'] = ['Accept:application/json']
    test.save()

# Generated at 2022-06-11 23:16:40.968139
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import os
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from httpie.config import BaseConfigDict

    with TemporaryDirectory() as temp_dir:
        path = Path(temp_dir)

        config = BaseConfigDict(path)
        config.save()

        assert os.path.isfile(path)

        with path.open('r') as f:
            content = json.load(f)

        assert len(content) == 0

        config['foo'] = 'bar'
        config['bar'] = 'baz'
        config.save()

        with path.open('r') as f:
            content = json.load(f)

        assert len(content) == 2

        config.delete()
        assert not os.path.isfile(path)



# Generated at 2022-06-11 23:16:42.376588
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert is_windows == (get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR)

# Generated at 2022-06-11 23:16:49.021939
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Saving to a file that does not exist in a directory that does not exist
    my_path = Path('/my/nonexisting/path.json')
    my_config = BaseConfigDict(path=my_path)
    # Verify that an error has been raised
    try:
        my_config.save()
        assert False
    except:
        assert True
    # Verify that the directory has not been created
    assert not my_path.parent.exists()


# Generated at 2022-06-11 23:16:58.138454
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/xyz'
    assert get_default_config_dir() == Path('/xyz')

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    os.environ[ENV_XDG_CONFIG_HOME] = '/xyz'
    assert get_default_config_dir() == Path('/xyz/httpie')

    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == Path('/x/y/z/httpie')

# Generated at 2022-06-11 23:17:09.631996
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    home_dir = Path.home()
    file_dir = Path('/tmp') / DEFAULT_CONFIG_DIRNAME
    class TestConfigDict(BaseConfigDict):
        pass
    test_config_dict_path = home_dir / TestConfigDict.__name__
    test_config_dict_file_path = home_dir / TestConfigDict.__name__ / TestConfigDict.FILENAME
    test_config_dict_file = TestConfigDict(test_config_dict_file_path)
    test_config_dict_file.ensure_directory()
    assert test_config_dict_path.exists()
    assert test_config_dict_file_path.exists()
    test_config_dict_file_path.unlink()
    test_config_dict_path.rmdir()

# Generated at 2022-06-11 23:17:20.348809
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR, None) is None
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar/httpie'
    assert os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None) is not None
    assert get_default_config_dir() == Path('/foo/bar/httpie')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR, None) is None
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_LEG

# Generated at 2022-06-11 23:17:27.086157
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_config_directory = Path("test_directory")
    BaseConfigDict(test_config_directory/'config.json').ensure_directory()
    # test if directory exists
    assert(os.path.isdir(test_config_directory))
    # test if directory has correct permission
    mode = os.stat(test_config_directory).st_mode
    assert(stat.S_IMODE(mode) == 0o700)
    # remove the test directory
    if os.path.isdir(test_config_directory):
        os.rmdir(test_config_directory)

# Generated at 2022-06-11 23:17:35.738286
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Test httpie installed with pip
    assert get_default_config_dir() == Path(str(Path.home()) + '/.config/httpie')

    # Test httpie installed by setup.py
    path = get_default_config_dir()
    os.environ['XDG_CONFIG_HOME'] = str(path.parent)
    assert get_default_config_dir() == Path(str(Path.home()) + '/.config/httpie')

    # Test httpie installed with pip and user defines XDG_CONFIG_HOME
    os.environ['XDG_CONFIG_HOME'] = str(Path.home() + '/dot-config')
    assert get_default_config_dir() == Path(str(Path.home()) + '/dot-config/httpie')

    # Test httpie installed by setup.py and

# Generated at 2022-06-11 23:17:43.411334
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # pylint: disable=protected-access
    old_env = os.environ.copy()
    os.environ.clear()
    try:
        path = DEFAULT_CONFIG_DIR / 'test' / 'config-test'
        BaseConfigDict._ensure_directory(path)
        path.mkdir(parents=True, exist_ok=True)
        for p in path.parents:
            assert p.is_dir()
    finally:
        os.environ.clear()
        os.environ.update(old_env)

# Generated at 2022-06-11 23:17:47.547024
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    test_path = Path.home() / 'httpie_test_BaseConfigDict_ensure_directory'
    test_path.mkdir(mode=0o700, parents=True)
    try:
        config = BaseConfigDict(test_path)
        assert config.ensure_directory() is None
    finally:
        test_path.rmdir()


# Generated at 2022-06-11 23:17:55.804638
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import unittest
    from tempfile import TemporaryDirectory
    from httpie.config import Config
    from httpie.compat import is_windows
    config_dir = Config()
    if is_windows:
        class Api(BaseConfigDict):
            name = 'api'
            helpurl = None
            about = None
        api_dir = Api(path=Path(config_dir.directory) / 'api.json')
        with TemporaryDirectory() as dir:
            api_dir.path = Path(dir) / 'api.json'
            api_dir.ensure_directory()
            assert api_dir.path.parent.exists()



# Generated at 2022-06-11 23:17:58.949317
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    BaseConfigDict.ensure_directory('/tmp')
    from httpie.config import BaseConfigDict
    if os.path.exists('/tmp/httpie'):
        assert True
    else:
        assert False


# Generated at 2022-06-11 23:18:10.611001
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert str(get_default_config_dir()) == str(DEFAULT_CONFIG_DIR)
    os.environ[ENV_XDG_CONFIG_HOME] = '/something/xdg'
    assert str(get_default_config_dir()) == '/something/xdg/httpie'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/something/else'
    assert str(get_default_config_dir()) == '/something/else'

# Generated at 2022-06-11 23:18:17.216878
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert str(get_default_config_dir()) == str(DEFAULT_WINDOWS_CONFIG_DIR)

# Generated at 2022-06-11 23:18:28.726013
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # create a file at /tmp/config.json
    # /tmp must be exist before running this test
    data = {"default_options": []}
    path = Path('/tmp/config.json')
    json_string = json.dumps(
        obj=data,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    try:
        path.write_text(json_string + '\n')
    except IOError:
        raise

    # read file and test
    # delete the file created during test
    try:
        bcd = BaseConfigDict(path)
        assert bcd == data
        path.unlink()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise

# Generated at 2022-06-11 23:18:35.163137
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class dummy_BaseConfigDict(BaseConfigDict):
        name = None
        helpurl = None
        about = None
    a = dummy_BaseConfigDict(Path("test_BaseConfigDict_save.json"))
    a['a'] = 1
    a['b'] = 2
    a['c'] = 3
    a.save()
    b = dummy_BaseConfigDict(Path("test_BaseConfigDict_save.json"))
    b.load()
    assert a == b

# Generated at 2022-06-11 23:18:39.060500
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == \
        Path(os.environ['XDG_CONFIG_HOME']) / DEFAULT_CONFIG_DIRNAME

if __name__ == '__main__':
    test_get_default_config_dir()

# Generated at 2022-06-11 23:18:49.264377
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    from pathlib import Path
    from httpie.config import BaseConfigDict

    # create temporary directory to save config file
    tmp_dir = 'test_BaseConfigDict_save'
    os.makedirs(tmp_dir)

    config = BaseConfigDict(path=Path(tmp_dir) / '_config')

    assert config.is_new()

    # setters
    config['key1'] = 'value1'
    config['key2'] = 'value2'

    # save config dict
    config.save()

    config = BaseConfigDict(path=Path(tmp_dir) / '_config')
    config.load()

    # getters
    assert config['key1'] == 'value1'
    assert config['key2'] == 'value2'

    shut

# Generated at 2022-06-11 23:18:52.983583
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file = Path("httptest")
    test_dict = BaseConfigDict(config_file)
    test_dict.save()
    assert config_file.exists()
    config_file.unlink()


# Generated at 2022-06-11 23:19:02.819948
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    print('Testing test_BaseConfigDict_save')

    sample_config_dict = {
        '__meta__': {
            'httpie': __version__,
            'help': 'help url',
            'about': 'some about'
        },
        'default_options': []
    }

    testing_object = BaseConfigDict(Path('./test_BaseConfigDict_save'))
    testing_object.path.unlink()

    testing_object.save(fail_silently=False)
    assert testing_object.path.exists() == True

    json_string = testing_object.path.read_text()
    assert sample_config_dict == json.loads(json_string)



# Generated at 2022-06-11 23:19:07.135503
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigFile(BaseConfigDict):
        pass

    config_path = Path('/does-not-exist/toto')
    test_config = TestConfigFile(config_path)
    test_config.ensure_directory()
    assert config_path.parent.is_dir()
    config_path.parent.rmdir()


# Generated at 2022-06-11 23:19:13.255084
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil, tempfile
    temp_dir_path = Path(tempfile.mkdtemp())
    temp_config_file_path = temp_dir_path / 'test.conf'
    config = BaseConfigDict(temp_config_file_path)
    assert not config.path.exists()
    assert not config.path.parent.exists()
    config.ensure_directory()
    assert config.path.parent.exists()
    shutil.rmtree(temp_dir_path)

# Generated at 2022-06-11 23:19:20.467045
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import tempfile
    config_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    try:
        config_file.write("""{"foo": "bar"}""")
        config_file.close()
        config = BaseConfigDict(path=Path(config_file.name))
        config.load()
        assert config['foo'] == 'bar'
    finally:
        os.remove(config_file.name)

test_BaseConfigDict_load()

# Generated at 2022-06-11 23:19:26.398407
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = Path('./.httpie')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(path=config_file)
    config['default_options'] = ['--timeout=10',"--auth-type=basic"]
    config.save()
    config.load()
    assert config.default_options == ['--timeout=10', '--auth-type=basic']
    config.delete()



# Generated at 2022-06-11 23:19:40.129109
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config = BaseConfigDict(Path('test_dir_test/test.json'))
    # create a test dir
    config.ensure_directory()
    assert Path('test_dir_test').exists()

    # remove test dir
    Path('test_dir_test').rmdir()
    assert not Path('test_dir_test').exists()



# Generated at 2022-06-11 23:19:42.491735
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config['aaa'] = 'bbb'
    config.save()
    assert 'aaa' in config
    config.delete()

# Generated at 2022-06-11 23:19:43.077495
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    s = BaseConfigDict()
    s.load()

# Generated at 2022-06-11 23:19:47.378390
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    metadata = {'httpie': __version__}
    if Config.helpurl:
        metadata['help'] = Config.helpurl
    if Config.about:
        metadata['about'] = Config.about
    # it should save an empty JSON file with metadata
    assert BaseConfigDict(Path('./empty')).save() == None

# Generated at 2022-06-11 23:19:57.445556
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # test case 1
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # test case 2
    assert get_default_config_dir('/home') == Path('/home') / '.config' / 'httpie'

    # test case 3
    os.environ[ENV_XDG_CONFIG_HOME] = '/foo/.config'
    assert get_default_config_dir() == Path('/foo/.config') / 'httpie'
    os.environ.pop(ENV_XDG_CONFIG_HOME)

    # test case 4
    assert get_default_config_dir(Path.home()) == Path.home() / '.config' / 'httpie'

    # test case 5
    assert get_default_config_dir(Path('/home'))

# Generated at 2022-06-11 23:20:05.531147
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    c = BaseConfigDict(Path("/tmp/non_existent/path"))
    c.load() # File not found
    try:
        c.load() # File not found
    except ConfigFileError as e:
        pass
    c = BaseConfigDict(Path("/tmp/path_with_dot"))
    c['a'] = 0
    c['b'] = 1
    c.save()
    assert(c['a'] == 0 and c['b'] == 1)
    c2 = BaseConfigDict(Path("/tmp/path_with_dot"))
    c2.load()
    assert(c2['a'] == 0 and c2['b'] == 1)

# Generated at 2022-06-11 23:20:16.141106
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import shutil
    import unittest

    random_dir_name = str(int(random.uniform(1, 1000000)))
    config_dir = Path("./tmp_dir_" + random_dir_name)
    config_dir.mkdir()
    config_file = config_dir / "config.json"
    config_obj = BaseConfigDict(config_file)
    config_obj['test'] = {'a':1, 'b':2}
    config_obj.save()
    
    assert os.path.isfile(str(config_file))
    f = open(str(config_file), "r")
    assert 'a' in f.read() and 'b' in f.read()
    
    f.close()

# Generated at 2022-06-11 23:20:20.847465
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    class TestConfigDict(BaseConfigDict):
        pass

    with TemporaryDirectory() as tmp:
        config_dir = Path(tmp) / "test"
        assert not config_dir.exists()
        config = TestConfigDict(config_dir / "test.json")
        config.ensure_directory()
        assert config_dir.exists()

# Generated at 2022-06-11 23:20:24.491486
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert (os.path.isdir(str(DEFAULT_CONFIG_DIR)))
    assert (os.path.isdir(str(DEFAULT_CONFIG_DIR.parent)))
    assert (DEFAULT_CONFIG_DIR.parent != DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)
    assert (DEFAULT_CONFIG_DIR.parent.parent != DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)

# Generated at 2022-06-11 23:20:29.887780
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp/httpie')

    del os.environ[ENV_XDG_CONFIG_HOME]
    os.environ['HOME'] = '/tmp'
    assert get_default_config_dir() == Path('/tmp/.config/httpie')

    del os.environ['HOME']
    assert get_default_config_dir() == Path('/etc/xdg/httpie')

# Generated at 2022-06-11 23:20:57.099786
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from pathlib import Path
    import os
    import shutil
    import json

    config_dir = Path(os.path.expanduser('~')) / '.httpie'
    conf = Config(config_dir)
    conf.save()
    conf_data = None
    with open(config_dir / 'config.json', 'r') as f:
        conf_data = json.loads(f.read())
    assert conf_data is not None
    assert 'default_options' in conf_data
    assert type(conf_data) is dict
    shutil.rmtree(config_dir)



# Generated at 2022-06-11 23:20:58.513850
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from cprofilehook import cprofile
    cprofile.runctx('BaseConfigDict', globals(), locals())

# Generated at 2022-06-11 23:21:02.125754
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    from .test_config import test_directory
    test_dir = Path(test_directory)
    config_dir = test_dir / "local"
    assert config_dir.exists()

    temp_dir = config_dir / "temp"
    assert not temp_dir.exists()
    config_class = BaseConfigDict(temp_dir)
    config_class.ensure_directory()
    assert temp_dir.exists()

# Generated at 2022-06-11 23:21:06.174858
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class DummyConfig(BaseConfigDict):
        pass

    filename = 'foo.json'
    directory = 'httpie'
    path = directory + "/" + filename
    config = DummyConfig(path)
    config.load()
    assert config.path == path

# Generated at 2022-06-11 23:21:16.652613
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def test_dir(dir_name):
        return os.path.relpath(dir_name, get_default_config_dir())

    assert test_dir(os.path.expanduser('~/.config/httpie')) == '.'
    assert os.environ.get('XDG_CONFIG_HOME') is None
    os.environ['XDG_CONFIG_HOME'] = '/xdg/config/home'
    assert test_dir('/xdg/config/home/httpie') == '.'
    assert os.environ.get(ENV_HTTPIE_CONFIG_DIR) is None
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicit/config/dir'
    assert test_dir('/explicit/config/dir') == '.'
    assert is_windows

# Generated at 2022-06-11 23:21:25.956792
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """Test for httpie.config.get_default_config_dir()."""
    reset_environ()

    assert get_default_config_dir() == Path.home() / '.config/httpie'

    # Windows
    if is_windows:
        os.environ['APPDATA'] = r'C:\User\Username\AppData\Roaming'
        assert get_default_config_dir() == Path(r'C:\User\Username\AppData\Roaming\httpie')

    # Legacy directory
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    os.environ[ENV_XDG_CONFIG_HOME] = ''
    home_dir = Path.home()
    legacy_config_dir = home_dir / '.httpie'


# Generated at 2022-06-11 23:21:34.227011
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def assert_expected_default_config_dir(expected_config_dir):
        # Make sure we get what we expect
        assert DEFAULT_CONFIG_DIR == expected_config_dir
        # Make sure we can create that directory
        assert not expected_config_dir.exists()
        assert not expected_config_dir.parent.exists()
        DEFAULT_CONFIG_DIR.mkdir(mode=0o700, parents=True)
        assert expected_config_dir.exists()
        assert expected_config_dir.is_dir()
        # Cleanup
        DEFAULT_CONFIG_DIR.rmdir()
        assert DEFAULT_CONFIG_DIR.parent.exists()

    # Remove env, so we can be sure we are using the defaults

# Generated at 2022-06-11 23:21:41.777261
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # save method of class BaseConfigDict
    config = BaseConfigDict(Path('__temp_config__'))
    del config['__meta__']
    config['a'] = 1
    config['b'] = 2
    config['c'] = 3

    try:
        config.save()
        saved_config = BaseConfigDict(Path('__temp_config__'))
        saved_config.load()

        assert saved_config == config

    finally:
        try:
            os.unlink('__temp_config__')
        except OSError:
            pass

# Generated at 2022-06-11 23:21:50.692988
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    try:
        # create a file
        os.mknod("/tmp/test_BaseConfigDict_ensure_directory")
    except OSError:
        pass
    try:
        # create a directory
        os.makedirs("/tmp/test_BaseConfigDict_ensure_directory/a")
    except OSError:
        pass

    # set up BaseConfigDict_ensure_directory for testing
    # NOTE: As the class definition is not modified, the below 
    #       class definition will not be used for real 
    #       execution, but only for testing.
    class BaseConfigDict_ensure_directory(dict):
        name = None
        helpurl = None
        about = None

        def __init__(self, path: Path):
            super().__init__()
           

# Generated at 2022-06-11 23:21:58.280327
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    def get_config_dir():
        return Path('config')
    def set_config_dir(dir):
        return Path(dir)
    BaseConfigDict.get_default_config_dir = get_config_dir
    DEFAULT_CONFIG_DIR = set_config_dir('config')
    # Case: Path exists
    config = Config()
    original_path = config.path
    config.delete()
    config.ensure_directory()
    new_path = config.path
    assert new_path == original_path
    config.delete()