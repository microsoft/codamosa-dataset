

# Generated at 2022-06-11 23:12:11.741407
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class test_class(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)
    temp = tempfile.NamedTemporaryFile()
    test_class(Path(temp.name)).load()
    temp.close()



# Generated at 2022-06-11 23:12:14.096519
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

if __name__ == '__main__':
    test_get_default_config_dir()

# Generated at 2022-06-11 23:12:24.744970
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import inspect
    import os
    import sys

    src = inspect.getsource(BaseConfigDict)
    if not (sys.platform.startswith("win")):
        if not os.path.exists("/tmp"):
            os.mkdir("/tmp")

        config_file_path = "/tmp/config.json"
        if os.path.exists(config_file_path):
            os.remove(config_file_path)

        with open(config_file_path, 'w') as fout:
            fout.write("{1, 2, 3}")

        class Config(BaseConfigDict):
            def __init__(self):
                super().__init__(path=config_file_path)

        with open(config_file_path, 'w') as fout:
            fout

# Generated at 2022-06-11 23:12:29.829466
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file_name = 'test_save.json'
    config = BaseConfigDict(path=Path(config_file_name))
    config['key'] = 'value'
    config.save()
    print("Content of config file:", config_file_name, config)

    # Remove config file
    config.delete()

# Generated at 2022-06-11 23:12:33.646313
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    assert isinstance(config_dir, Path)
    assert config_dir.exists()
    assert config_dir.is_dir()



# Generated at 2022-06-11 23:12:37.592856
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    x = BaseConfigDict(os.path.abspath(__file__))
    assert x.path.name == 'config.py'
    x.ensure_directory()
    assert x.path.parent.name == 'httpie'
    x.path.parent.rmdir()



# Generated at 2022-06-11 23:12:44.113110
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    original_env = dict(os.environ)

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo'
    assert get_default_config_dir() == '/foo'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    os.environ[ENV_XDG_CONFIG_HOME] = '/xdg/conf'
    assert get_default_config_dir() == Path('/xdg/conf') / DEFAULT_CONFIG_DIRNAME
    os.environ.pop(ENV_XDG_CONFIG_HOME)

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE

# Generated at 2022-06-11 23:12:53.124807
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Legacy
    assert (get_default_config_dir() ==
            Path.home() / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)
    # Explicit
    if ENV_HTTPIE_CONFIG_DIR in os.environ:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert ENV_HTTPIE_CONFIG_DIR not in os.environ
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/abc'
    assert (get_default_config_dir() ==
            Path('/tmp/abc'))
    # XDG
    # (1) Windows
    if is_windows:
        assert (get_default_config_dir() ==
                DEFAULT_WINDOWS_CONFIG_DIR)
    # (2) Linux
   

# Generated at 2022-06-11 23:13:03.240398
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/test-path'

    assert get_default_config_dir() == Path.home() / 'test-path'

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    del os.environ[ENV_XDG_CONFIG_HOME]

    default_config_dir = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    assert get_default_config_dir() == default_config_dir

    os.environ[ENV_XDG_CONFIG_HOME] = '~/test-path2'
    default_config_dir = Path.home() / 'test-path2' / DEFAULT_CONFIG_DIRNAME

    assert get

# Generated at 2022-06-11 23:13:15.239032
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import shutil
    
    # setup
    temp_dir = Path("/tmp/test_httpie_httpie")
    temp_dir.mkdir()
    c = Config(temp_dir)

    # normal behaviour
    try:
        c.ensure_directory()
    except Exception as e:
        pytest.fail(e)
    
    # reset
    shutil.rmtree(str(temp_dir))
    temp_dir.mkdir()
    c = Config(temp_dir)
    c.ensure_directory()
    
    # exception handling
    c.path.chmod(stat.S_IWRITE)
    c.path.unlink()

# Generated at 2022-06-11 23:13:27.080297
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    print("===test_get_default_config_dir()===")
    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "/tmp"
    assert str(get_default_config_dir()) == "/tmp"
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    # 2. Windows
    assert str(get_default_config_dir()) == os.path.expandvars('%APPDATA%') + "\\httpie"

    # 3. legacy ~/.httpie
    legacy_config_dir = Path() / "tmp" / "home" / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    assert str(get_default_config_dir()) == "/tmp/home/.config/httpie"

    # 4. XDG

# Generated at 2022-06-11 23:13:37.335056
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    with pytest.raises(ConfigFileError) as error:
        # we can not simply create a BaseConfigDict instance here
        # because BaseConfigDict is not a concrete class yet
        # MockPath = mock.Mock(spec=Path)
        # config = BaseConfigDict(MockPath)
        # so we create a subclass of BaseConfigDict
        class MockConfigDict(BaseConfigDict):
            pass
        config = MockConfigDict(MockPath)
        # raise ConfigFileError since path is not a real file
        config.load()
        assert str(error.value).startswith("cannot read configdict file:")


# Generated at 2022-06-11 23:13:42.428516
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict2 = BaseConfigDict(Path('C:/folder1/folder2/folder3/config.json'))
    base_config_dict2.ensure_directory()
    assert base_config_dict2 == {}, 'ensure_directory() return an empty dict'


# Generated at 2022-06-11 23:13:52.596474
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    config_file = os.path.join(tmpdir, 'config.json')
    try:
        with open(config_file, 'w') as output:
            output.write('{"__meta__": {"httpie": "unknown", "help": "unknown", "about": "unknown"}, "default_options": []}')

        config = Config(tmpdir)
        config.load()
        assert(config["__meta__"] == {"httpie": "unknown", "help": "unknown", "about": "unknown"})
        assert(config["default_options"] == [])
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-11 23:14:00.085872
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/a/b'
    assert get_default_config_dir() == Path('/a/b')

    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/c/d'
    assert get_default_config_dir() == Path('/c/d/httpie')

# Generated at 2022-06-11 23:14:10.047328
# Unit test for method load of class BaseConfigDict

# Generated at 2022-06-11 23:14:16.884679
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # On Windows, the return value is hardcoded
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # On POSIX, on the first run, it should point to '~/.config/httpie'
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:14:22.678526
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = os.path.join(os.getcwd(),'resources', 'config.json')
    class TestConfigDict(BaseConfigDict):
        name = 'test'
        helpurl = 'test'
        about = 'test'
    result = TestConfigDict(path=path)
    result.load() 
    assert result.keys() == {
                            '__meta__',
                            'default_options',
                            'theme',
                            'output_options',
                            'style'
                            }


# Generated at 2022-06-11 23:14:27.701526
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import json
    import tempfile
    content = json.dumps({'foo':'bar'})
    with tempfile.NamedTemporaryFile() as f:
        f.write(content)
        f.flush()
        config = BaseConfigDict(path=f.name)
        config.load()
        assert config['foo'] == 'bar'

# Generated at 2022-06-11 23:14:36.124920
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Case 1: No Environment variables are set
    assert get_default_config_dir() == os.path.join(str(Path.home()), '.config', 'httpie')

    # Case 2: HTTPIE_CONFIG_DIR is set
    os.environ[ENV_HTTPIE_CONFIG_DIR] = os.path.join(str(Path.home()), '.foo')
    assert get_default_config_dir() == os.path.join(str(Path.home()), '.foo')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # Case 3: HTTPIE_CONFIG_DIR is set to an invalid directory
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/abc/some/invalid/directory'

# Generated at 2022-06-11 23:14:46.156073
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    x = BaseConfigDict(Path('test_configuration.json'))
    x.load()
    assert '__meta__' in x
    assert 'httpie' in x['__meta__']
    assert x['__meta__']['httpie'] == str(__version__)
    assert 'help' in x['__meta__']
    assert 'about' in x['__meta__']
    assert 'default_options' in x
    assert isinstance(x['default_options'], list)


# Generated at 2022-06-11 23:14:51.023259
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    with open('config.json', 'w') as file:
        json.dump({"test":"test"}, file)
    config = Config()
    config.load()
    assert config.config_file == 'config.json'
    assert config.get('test') == 'test'



# Generated at 2022-06-11 23:14:55.339897
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict('test_ConfigFile_config.json')
    with open('test_ConfigFile_config.json','w') as f:
        json.dump(config, f)


# Generated at 2022-06-11 23:14:58.866776
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    Path.home = lambda: Path('/home/test')
    assert BaseConfigDict('/home/test/xx').load() == ConfigFileError



# Generated at 2022-06-11 23:15:03.961596
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfigDict(BaseConfigDict):
        def __init__(self, path):
            super().__init__(path)
        def save(self):
            pass
    config = TestConfigDict(path=Path('nonexistent_file'))
    assert config.load() == None


# Generated at 2022-06-11 23:15:13.450714
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Get `root` path for this test
    root = Path(__file__).parent

    # Case 1: $HTTPIE_CONFIG_DIR or $XDG_CONFIG_HOME are explicitly set
    with mock.patch.dict(os.environ, {
        ENV_HTTPIE_CONFIG_DIR: '~/my-config-dir',
        ENV_XDG_CONFIG_HOME: '~/xdg-config-home'
    }):
        get_default_config_dir() == Path(os.path.expanduser('~/my-config-dir'))

    # Case 2: Windows
    with mock.patch.dict(os.environ, {}), mock.patch('httpie.config.is_windows'):
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG

# Generated at 2022-06-11 23:15:19.913837
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class ConfigDict(BaseConfigDict):
        def __init__(self, path: Path):
            super().__init__(path)

    d = ConfigDict(Path(os.path.dirname(__file__)) / 'config.json')
    d.load()
    assert d['__meta__']['__config__'] == 'Develop Commit'

# Generated at 2022-06-11 23:15:25.020179
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import Config
    f = open('config.json', 'w+')
    f.write('{"a": 1, "b": 2}')
    f.close()
    config = Config()
    assert(config.path == 'config.json')
    config.load()
    assert(config == {'a':1, 'b':2})


# Generated at 2022-06-11 23:15:36.560288
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import subprocess
    from httpie import __version__

    def get_httpie_version():
        return subprocess.check_output(['http', '--version']).decode().strip()

    def get_httpie_config_dir():
        return subprocess.check_output(
            [
                'http',
                '--debug',
            ],
        ).decode().strip().split(' ')[1]

    print('version', __version__)
    print('config_dir', get_default_config_dir())
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'explicit'
    print('config_dir', get_default_config_dir())


# Generated at 2022-06-11 23:15:38.194374
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/joe/.config/httpie')

# Generated at 2022-06-11 23:15:54.471341
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfigDict(BaseConfigDict):
        name = 'Test'
        helpurl = None
        about = None
    tmp_dir = tempfile.mkdtemp()
    try:
        config = TestConfigDict(path=Path(tmp_dir) / 'config.json')
        assert not (Path(tmp_dir) / 'config.json').is_file()
        config.ensure_directory()
        assert Path(tmp_dir) / 'config.json'
        assert (Path(tmp_dir) / 'config.json').is_file()
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-11 23:16:01.061655
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # sanity
    path = Path('./config.json')
    if path.exists():
        path.unlink()

    emptyConfig = Config()
    emptyConfig.load()

    assert emptyConfig.is_new() == True

    emptyConfig.save()

    assert emptyConfig.is_new() == False

    emptyConfig.delete()

    assert emptyConfig.is_new() == True

    path = Path('./config.json')
    if path.exists():
        path.unlink()
test_BaseConfigDict_load()


# Generated at 2022-06-11 23:16:04.406989
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    with TemporaryDirectory() as temp_dir:
        dir_path = Path(temp_dir)
        base_config = BaseConfigDict(path=dir_path / 'config.json')
        base_config.save()


# Generated at 2022-06-11 23:16:16.483095
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    tmp_dir_path = Path(tempfile.mkdtemp(prefix="httpietest"))
    # create tmp file
    file_path = tmp_dir_path / "test_config.json"
    with file_path.open("w") as f:
        f.write('{"a":"a"}')

    # test load
    config = BaseConfigDict(file_path)
    config.load()
    assert config['a'] == "a"
    # test load fail
    invalid_file_path = tmp_dir_path / "test_config_invalide.json"
    with invalid_file_path.open("w") as f:
        f.write('{')
    config = BaseConfigDict(invalid_file_path)

# Generated at 2022-06-11 23:16:23.754480
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)

    home_dir = Path.home()

    # default
    assert get_default_config_dir() == home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    # explicitly set through env
    env_config_dir = home_dir / Path('env_config_dir')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(env_config_dir)
    assert get_default_config_dir() == env_config_dir

    # Windows

# Generated at 2022-06-11 23:16:30.879653
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    def get_list(list):
        file = open(list, 'r')
        return [item.strip('\n') for item in file.readlines()]

    def test(expected, actual):
        if not expected == actual:
            raise Exception("expected" + str(expected)
                            + "actual" + str(actual))
    expected = get_list("../data/json_list.txt")
    c = BaseConfigDict("../data/config.json")
    c.load()
    actual = c.keys()
    test(expected, actual)



# Generated at 2022-06-11 23:16:35.079793
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = os.path.join(os.path.dirname(__file__), 'config.json')
    c = Config(path)
    c.load()
    return c

if __name__ == '__main__':
    c = test_BaseConfigDict_load()
    print(c)

# Generated at 2022-06-11 23:16:37.039918
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path('/home/user/.config/httpie')


# Generated at 2022-06-11 23:16:42.828206
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from pytest import raises

    class BaseConfigDictForTest(BaseConfigDict):
        name = None
        helpurl = None
        about = None

    path = Path('/home/test')

    with raises(ConfigFileError):
        f = BaseConfigDictForTest(path)
        f.load()


if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:16:51.579681
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from httpie.config import BaseConfigDict
    import os
    import shutil
    try:
        tempdir = './tempdir'
        os.mkdir(tempdir)
        os.chdir(tempdir)
        path = './foo/bar/config'
        print(f'directory is {tempdir}')
        print(f'config json file is {path}')
        bcd = BaseConfigDict(path=path)
        bcd.ensure_directory()
        assert os.path.exists('foo/bar')
    finally:
        os.chdir('..')
        shutil.rmtree(tempdir)

# Generated at 2022-06-11 23:17:03.579812
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    Test that the method ensure_directory creates it's parent directorys
    if they dont exist.
    """

    class BaseConfigDictT(BaseConfigDict):
        pass

    # delete old test_config_dir
    config_dir = Path("test_config_dir")
    if config_dir.exists():
        shutil.rmtree(config_dir)
    # create BaseConfigDict with path to test_config_dir/test_file
    conf = BaseConfigDictT(path=config_dir / "test_file")
    assert not config_dir.exists(), "test_config_dir should not exist"
    conf.ensure_directory()
    assert config_dir.exists(), "test_config_dir should exist"

# Generated at 2022-06-11 23:17:13.652548
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import configparser
    import json
    import os.path
    import pathlib
    import tempfile
    import unittest

    class TestConfigDict(BaseConfigDict):
        FILENAME = 'settings.json'

    class TestBaseConfigDictSave(unittest.TestCase):
        def test_save(self):
            # Prepare a temporary directory and files.
            config_dir = pathlib.Path(tempfile.mkdtemp())
            config_file = config_dir / TestConfigDict.FILENAME

            # Ensure the temporary directory is created.
            config = TestConfigDict(config_file)
            self.assertEqual(config.directory, config_dir)
            self.assertEqual(config.path, config_file)

            # Set a property for the config file.
            config['key1']

# Generated at 2022-06-11 23:17:18.516661
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_file = Config('./httpie')
    try:
        config_file.save()
        assert config_file.path.exists(), 'no config file after save'
    finally:
        os.unlink('./httpie/config.json')
        os.rmdir('./httpie')


# Generated at 2022-06-11 23:17:23.871037
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    d = {'A': '1'}
    p = Path('/tmp/') / 'test_base_config_dict_load.json' # type: Path
    with p.open('wt') as f:
        print(json.dumps(d), file=f)
    c = BaseConfigDict(p)
    c.load()
    assert(c['A'] == '1')
    os.unlink(p)


# Generated at 2022-06-11 23:17:33.032780
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import os
    import shutil

    random_file_path = "/tmp/test_BaseConfigDict_ensure_directory/test_dir/test_file"

    # Test for directory does not exist
    try:
        os.mkdir("/tmp/test_BaseConfigDict_ensure_directory")
    except OSError:
        pass
    try:
        os.rmdir("/tmp/test_BaseConfigDict_ensure_directory/test_dir")
    except OSError:
        pass

    try:
        section = BaseConfigDict(Path(random_file_path))
        section.ensure_directory()
    except OSError:
        assert False

    shutil.rmtree("/tmp/test_BaseConfigDict_ensure_directory")



# Generated at 2022-06-11 23:17:41.616272
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = "./test/"
    assert get_default_config_dir() == Path("test")
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        if ENV_XDG_CONFIG_HOME in os.environ:
            del os.environ[ENV_XDG_CONFIG_HOME]
        assert get_default_config_dir() == Path.home() / Path('.config/httpie')

# Generated at 2022-06-11 23:17:45.992757
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import tempfile
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    with tempfile.NamedTemporaryFile(mode='w') as test_file:
        json.dump(test_dict, test_file)
        test_file.flush()
        bc = BaseConfigDict(test_file.name)
        bc.load()
    assert bc == test_dict


# Generated at 2022-06-11 23:17:55.655325
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import BaseConfigDict
    from httpie.plugins.builtin import HTTPBasicAuth
    f = open('config.json', 'w')
    f.write('{"plugins": {"httpie.plugins.builtin.HTTPBasicAuth": {"username": "user", "password": "pass"}}}')
    f.close()
    p = Path('config.json')
    b = BaseConfigDict(p)
    b.load()
    assert "HTTPBasicAuth" in b["plugins"]
    f = open('config.json', 'w')
    f.write('{"plugins": {"httpie.plugins.builtin.HTTPBasicAuth": ""}}')
    f.close()
    b.load()
    assert "HTTPBasicAuth" not in b["plugins"]
    f = open('config.json', 'w')
   

# Generated at 2022-06-11 23:18:06.847858
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from pathlib import Path
    import tempfile
    tdir = Path(tempfile.gettempdir())
    path1 = tdir / 'temp1'
    path2 = tdir / 'temp2/temp3'
    path3 = Path('foo/bar/baz')
    c1 = BaseConfigDict(path1)
    c2 = BaseConfigDict(path2)
    c3 = BaseConfigDict(path3)
    c1.ensure_directory()
    c2.ensure_directory()
    assert tdir.exists()
    assert tdir.is_dir()
    assert path1.parent.exists()
    assert path1.parent.is_dir()
    assert path2.parent.exists()
    assert path2.parent.is_dir()

# Generated at 2022-06-11 23:18:17.171555
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    except KeyError:
        pass

    try:
        del os.environ[ENV_XDG_CONFIG_HOME]
    except KeyError:
        pass

    def assert_default_config_dir(home_dir, expected_config_dir,
                                  expected_xdg_config_home=None):
        with patch.object(os.path, 'expanduser', return_value=home_dir):
            assert get_default_config_dir() == expected_config_dir

            if expected_xdg_config_home:
                assert os.environ[ENV_XDG_CONFIG_HOME] == expected_xdg_config_home

    # Windows

# Generated at 2022-06-11 23:18:34.569357
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    class MockDict(BaseConfigDict):
        pass

    with TemporaryDirectory() as tempdir, \
            patch('builtins.open') as patched_open, \
            patch('shutil.rmtree') as patched_rmtree:
        tmpdir = Path(tempdir, 'test')
        tmpdir.mkdir()
        tmpfile = tmpdir / 'tmpfile.test'
        # test existing dir
        MockDict(tmpfile).ensure_directory()
        patched_open.assert_not_called()
        # test existing dir and writeable
        MockDict(tmpfile).ensure_directory()
        patched_open.assert_not_called()
        
        # test existing file
        tmpfile.write_text('')


# Generated at 2022-06-11 23:18:45.018838
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    config_dir = get_default_config_dir()
    assert config_dir == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_XDG_CONFIG_HOME] = '/some/other/path'
    config_dir = get_default_config_dir()
    assert config_dir == '/some/other/path' / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_XDG_CONFIG_HOME] = ''
    config_dir = get_default_config_dir()

# Generated at 2022-06-11 23:18:55.479075
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Check that get_default_config_dir() returns the following paths on each OS
    for the following XDG_CONFIG_HOME values:

        XDG_CONFIG_HOME=/some/dir
        XDG_CONFIG_HOME=/some/dir/

    """
    xdg_config_home_dirs = [
        '/some/dir',
        '/some/dir/',
    ]

    expected_xdg_config_dirs = {
        '/some/dir': '/some/dir/httpie',
        '/some/dir/': '/some/dir/httpie',
    }

    home_dir = Path.home()


# Generated at 2022-06-11 23:19:06.012375
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os

    # 1. explicitly set through env
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    if env_config_dir:
        assert get_default_config_dir() == Path(env_config_dir)

    # 2. Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    home_dir = Path.home()

    # 3. legacy ~/.httpie
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    if legacy_config_dir.exists():
        assert get_default_config_dir() == legacy_config_dir

    # 4. XDG

# Generated at 2022-06-11 23:19:15.516722
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import shutil

    # Create a temporary config file
    config_dir = tempfile.TemporaryDirectory().name
    config_dir = Path(config_dir)
    base_config_dir = config_dir / "config"
    base_config_dir.mkdir()

    base_config_file = base_config_dir / "config.json"
    default_options = {'default_options': []}

    json_string = json.dumps(default_options)
    file_handle = base_config_file.open(mode="w")
    file_handle.write(json_string)
    file_handle.close()

    expected = {'default_options': []}
    config = Config(config_dir)
    config.load()
    assert config == expected

    # Remove the config file
    shutil.rmtree

# Generated at 2022-06-11 23:19:19.607332
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    path = DEFAULT_CONFIG_DIR / 'test.json'
    config = BaseConfigDict(path)
    config['key'] = 'value'
    config.save()
    assert path.exists() == True
    path.unlink()

# Generated at 2022-06-11 23:19:28.998850
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = Path('./tests')
    config_dir.mkdir(parents=True, exist_ok=True)
    config_dict = BaseConfigDict(config_dir/'test_BaseConfigDict_save.txt')
    config_dict.ensure_directory()
    data = {'__meta__': {'httpie': '1.0.0'}}
    config_dict.update(data)
    config_dict.save()
    assert Path(config_dir/'test_BaseConfigDict_save.txt').exists()
    with open(config_dir/'test_BaseConfigDict_save.txt', 'rt') as f:
        test_data = json.load(f)
    assert data == test_data

# Generated at 2022-06-11 23:19:39.332690
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # preparation
    test_file_path = Path('./config.json')
    test_file_path.touch()
    test_file_path.write_text('{"name": "test_conf"}')
    config = BaseConfigDict(test_file_path)

    # test for success
    config.load()
    assert config['name'] == 'test_conf'

    # test for error: read file fails
    test_file_path.chmod(0o000)
    try:
        config.load()
        assert False
    except ConfigFileError as e:
        assert True
    test_file_path.unlink()
    test_file_path.touch()

    # test for error: json load fails
    test_file_path.write_text('{"name": "test_conf"')

# Generated at 2022-06-11 23:19:49.216063
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() / 'config.json' == Path.home() / '.config' / 'httpie' / 'config.json'
    os.environ['XDG_CONFIG_HOME'] = 'C:\\Users\\w\\AppData\\Roaming'
    assert get_default_config_dir() / 'config.json' == Path("C:\\Users\\w\\AppData\\Roaming\\httpie\\config.json")
    if is_windows:
        os.environ[ENV_HTTPIE_CONFIG_DIR] = 'C:\\Users\\w\\AppData\\Roaming'
        assert get_default_config_dir() / 'config.json' == Path("C:\\Users\\w\\AppData\\Roaming\\httpie\\config.json")

# Generated at 2022-06-11 23:19:55.085556
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/mock/dir'
    assert get_default_config_dir() == Path('/mock/dir')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = None
    assert get_default_config_dir() == Path('/mock/dir')

# Generated at 2022-06-11 23:20:13.925657
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    file_name = 'test/tmp/test_file'
    example_dict = {"name": "Jussi", "age": 42, "address": "Lapilli"}
    example_dict_string = json.dumps(obj=example_dict, indent=4,
                                     sort_keys=True, ensure_ascii=True)

    # Test the default values and json dump function
    if os.path.exists(file_name):
        os.remove(file_name)
    config_dict = BaseConfigDict(Path(file_name))
    config_dict.save()

    with open(file_name, 'r') as f:
        json_string = f.read()
        assert json_string == '{}\n'

    # Test the contents of the dictionary

# Generated at 2022-06-11 23:20:22.134837
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    import json
    from httpie.config import BaseConfigDict

    d = {'a':1, 'b':2, 'c':3}
    r = json.dumps(obj=d, indent=4, sort_keys=True, ensure_ascii=True)+'\n'

    fd, file_path = tempfile.mkstemp()
    base_config_dict = BaseConfigDict(path=file_path)

    base_config_dict.update(d)
    base_config_dict.save()
    with open(file_path, 'r') as file:
        assert file.read() == r

    os.close(fd)
    os.remove(file)


# Generated at 2022-06-11 23:20:28.724185
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_cases = [
        ('test_case_1', '__meta__', __version__),
        ('test_case_1', 'cache', True),
        ('test_case_1', 'colors', 256),
        ('test_case_1', 'trust_env', True),
        ('test_case_1', 'verify', True),
        ('test_case_1', 'verbose', False),
        ('test_case_1', 'style', 'solarized')
    ]
    dir = os.getcwd() + '/tests/sessions'
    for case_path, key, value in test_cases:
        case = BaseConfigDict(dir + '/' + case_path + '/' + 'config')
        case.load()
        assert case[key] == value


# Generated at 2022-06-11 23:20:31.742184
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict('config.json')
    config['blah'] = 'blah'
    config.save()
    assert config.load() == {'blah': 'blah'}
    config.delete()


# Generated at 2022-06-11 23:20:35.826182
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory_base_config_dict = BaseConfigDict(path=DEFAULT_CONFIG_DIR)
    assert(directory_base_config_dict.ensure_directory())


# Generated at 2022-06-11 23:20:46.270371
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from pathlib import Path
    from httpie.config import ConfigFileError

    class ConfigDict(BaseConfigDict):
        pass

    TEST_CONFIG_FILENAME = "test_config.json"
    TEST_CONFIG_DIR = Path("./")
    TEST_CONFIG_FILE = TEST_CONFIG_DIR / TEST_CONFIG_FILENAME
    TEST_CONFIG_INVALID = Path("./invalid.json")

    config_dict = ConfigDict(TEST_CONFIG_FILE)

    # test load: test a exist file with valid json format
    config_dict.load()

    # test load: test a exist file but invalid json format
    config_dict.path = TEST_CONFIG_INVALID
    with pytest.raises(ConfigFileError):
        config_dict.load()

# Generated at 2022-06-11 23:20:53.923451
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    temp_dir = Path('.') / 'tmp'
    try:
        temp_dir.mkdir()
        config_path = temp_dir / 'config.json'
        config_dict = BaseConfigDict(config_path)
        config_dict['key'] = 'value'
        config_dict.save()
        with config_path.open('rt') as f:
            data = json.load(f)
        assert data['key'] == 'value'
        config_dict.delete()
    finally:
        temp_dir.rmdir()


# Generated at 2022-06-11 23:20:58.603955
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        xdg_config_dir = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
        assert get_default_config_dir() == xdg_config_dir


# Generated at 2022-06-11 23:21:04.067460
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from unittest.mock import Mock, patch
    from httpie.config import ConfigFileError
    config = BaseConfigDict(path=Path('./test'))

    patch(
        'httpie.config.BaseConfigDict.path',
        new_callable=Mock(return_value=Path('test'))
    ).start()

    patch(
        'httpie.config.BaseConfigDict.path.parent.mkdir',
        new_callable=Mock(side_effect=OSError(
            errno.EEXIST,
            os.strerror(errno.EEXIST),
            config.path.parent
        ))
    ).start()


# Generated at 2022-06-11 23:21:06.008776
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() is DEFAULT_CONFIG_DIR



# Generated at 2022-06-11 23:21:30.409794
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from io import StringIO
    from unittest.mock import patch
    import sys

    # With env variable HTTPIE_CONFIG_DIR
    sys.argv = ['pytest']
    with patch.object(sys, 'argv', ['httpie']):
        with patch.dict(os.environ, {ENV_HTTPIE_CONFIG_DIR: '/some/dir'}):
            assert get_default_config_dir() == Path('/some/dir')

    # On unix, without env variable HTTPIE_CONFIG_DIR
    sys.argv = ['pytest']
    if not is_windows:
        with patch.object(sys, 'argv', ['httpie']):
            with patch.dict(os.environ, clear=True):
                assert get_default_config_dir() == Path.home()

# Generated at 2022-06-11 23:21:35.757677
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    _path = "/tmp/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/ZZZ"
    _config = BaseConfigDict(Path(_path))
    _config.ensure_directory()
    assert os.path.isdir( _path )


# Generated at 2022-06-11 23:21:38.033599
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert(get_default_config_dir() == Path.home() / '.config' / 'httpie')

# Unit tests for class Config

# Generated at 2022-06-11 23:21:48.385368
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class MyConfig(BaseConfigDict):
        name = 'myconfig'
        helpurl = 'https://myconfig.myhelpurl.com'
        about = 'This is myconfig'

    local_path = Path('./myconfig.json')
    # create a config file from DEFAULTS
    local_path.write_text(json.dumps(
        obj=MyConfig.DEFAULTS,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    ))
    # load the config file
    myconfig = MyConfig(local_path)
    # check if load succeeds
    assert myconfig.name == 'myconfig'
    assert myconfig.helpurl == 'https://myconfig.myhelpurl.com'
    assert myconfig.about == 'This is myconfig'




# Generated at 2022-06-11 23:21:52.006000
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class TestConfig(BaseConfigDict):
        name = 'test'
    c = TestConfig(path='/tmp/httpie_test/test.json')
    c.ensure_directory()
    assert os.path.exists('/tmp/httpie_test')


# Generated at 2022-06-11 23:22:02.524936
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
        return

    home_dir = Path.home()
    legacy_config_dir_path = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR
    xdg_config_home_path = home_dir / DEFAULT_RELATIVE_XDG_CONFIG_HOME
    xdg_config_path = xdg_config_home_path / DEFAULT_CONFIG_DIRNAME

    # case 1:
    # $HOME/.config exists and $XDG_CONFIG_HOME isn't set
    xdg_config_home_path.mkdir()
    assert get_default_config_dir() == xdg_config_path

    # case 2:
    # $HOME/.