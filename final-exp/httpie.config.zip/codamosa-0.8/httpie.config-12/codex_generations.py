

# Generated at 2022-06-11 23:12:14.261496
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    string_json = json.dumps({'foo': 'bar'})
    path = Path('config.json')
    try:
        path.write_text(string_json)
        config = BaseConfigDict(path)
        config.load()
        assert config.is_new() == False
    except:
        raise
    finally:
        path.unlink()



# Generated at 2022-06-11 23:12:24.883165
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Test 1: Ensure ensure_directory() does not throw an exception if directory exists
    # Test 1.1: Ensure that a directory exists
    tst_dir_path = "/tmp/httpie"
    if not os.path.exists(tst_dir_path):
        os.makedirs(tst_dir_path)
    assert os.path.exists(tst_dir_path)
    # Test 1.2: Call ensure_directory() and check for exception
    # Create sample instance of BaseConfigDict class
    tst_bd = BaseConfigDict(Path(tst_dir_path))
    # Call ensure_directory()
    tst_bd.ensure_directory()
    # Check that no exception was thrown
    assert True
    # Cleanup
    os.rmdir(tst_dir_path)

# Generated at 2022-06-11 23:12:32.474899
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import uuid
    with TemporaryDirectory() as td:
        bcd = BaseConfigDict(Path(td) / str(uuid.uuid4()))
        bcd.ensure_directory()
        assert bcd.path.parent.exists()
        assert bcd.path.parent.is_dir()
        assert bcd.path.parent.stat().st_mode == 0o40700 # drwx------


# Generated at 2022-06-11 23:12:38.762759
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    f = open('DEFAULT_CONFIG/config.json','w+')
    f.write('{"default_options": [{"key": "value"}]}')
    f.close()
    config = Config()
    config.ensure_directory()
    new_config = Config(directory = 'DEFAULT_CONFIG')
    new_config.ensure_directory()
    assert os.path.exists('DEFAULT_CONFIG') == True
    shutil.rmtree('DEFAULT_CONFIG')



# Generated at 2022-06-11 23:12:45.089318
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    directory = Path('test')
    if directory.exists():
        directory.rmdir()
    assert not directory.exists()

    test_config_dict = BaseConfigDict(Path('test/config.json'))
    test_config_dict.ensure_directory()
    assert directory.exists()
    directory.rmdir()


# Generated at 2022-06-11 23:12:48.617796
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path='tests/data/config.json')
    assert config == {}
    config.load()
    assert config.get('a') == 2
    assert config['__meta__']['httpie'] == __version__


# Generated at 2022-06-11 23:12:50.446484
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    pass


# Generated at 2022-06-11 23:13:01.118753
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir().as_posix() == Path(DEFAULT_CONFIG_DIR.as_posix()).as_posix()
    os.environ['HOME'] = '/home/user1'
    assert get_default_config_dir().as_posix() == Path('/home/user1/'+DEFAULT_RELATIVE_XDG_CONFIG_HOME.as_posix()+"/"+DEFAULT_CONFIG_DIRNAME).as_posix()
    os.environ['XDG_CONFIG_HOME'] = '/config'
    assert get_default_config_dir().as_posix() == Path('/config/'+DEFAULT_CONFIG_DIRNAME).as_posix()
    os.environ['HTTPIE_CONFIG_DIR'] = '/config1'

# Generated at 2022-06-11 23:13:12.329987
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie.config import (
        DEFAULT_CONFIG_DIR,
        DEFAULT_CONFIG_DIRNAME,
        DEFAULT_RELATIVE_XDG_CONFIG_HOME,
        ENV_HTTPIE_CONFIG_DIR,
        ENV_XDG_CONFIG_HOME,
        BaseConfigDict,
        ConfigFileError,
        get_default_config_dir,
    )
    import json

    class TestConfig(BaseConfigDict):
        FILENAME = 'test.json'
        DEFAULTS = {'a': 'b', 'c': 'd'}

    def test_new():
        config_dir = Path(DEFAULT_CONFIG_DIR) \
            / DEFAULT_CONFIG_DIRNAME
        config_file = config_dir / 'test.json'

# Generated at 2022-06-11 23:13:16.335699
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/dev/null'
    assert get_default_config_dir() == Path('/dev/null')

# Generated at 2022-06-11 23:13:22.608131
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path(os.environ.get('HOME')) / \
        DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME



# Generated at 2022-06-11 23:13:25.904035
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    """
    A unit test for the method ensure_directory of class BaseConfigDict
    :return:
    """
    user_config = Config()
    user_config.ensure_directory()


# Generated at 2022-06-11 23:13:35.388588
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import shutil
    import tempfile

    temp_dir_name = tempfile.mkdtemp()
    test_dir_path = Path(temp_dir_name)

    test_file_path = test_dir_path / "test_file.json"

    config = BaseConfigDict(test_file_path)
    config.load()

    test_data = {
        "test": "test"
    }
    config.update(test_data)
    config.save()

    with open(test_file_path, 'r') as f:
        data = json.load(f)

    shutil.rmtree(temp_dir_name)

    assert data == test_data

# Generated at 2022-06-11 23:13:37.951046
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    bcd = BaseConfigDict("config.json")
    bcd.ensure_directory()

# Generated at 2022-06-11 23:13:39.545903
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:13:51.437982
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # This function is not applicable to windows
    if is_windows:
        return

    # 1. explicitly set through env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/httpie'
    assert get_default_config_dir() == Path('/tmp/httpie')

    # 2. Windows
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

    # 3. legacy ~/.httpie
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    os.environ.pop(ENV_XDG_CONFIG_HOME)
    home_dir = Path.home()
    legacy_config_dir = home_dir / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR

# Generated at 2022-06-11 23:13:57.799855
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a new BaseConfigDict instance
    baseConfigDict = BaseConfigDict('/tmp/config.json')
    # if the file doesn't exists, then no exception is raised
    baseConfigDict.load()
    # now we create a file with invalid contents
    with open('/tmp/config.json', 'w') as the_file:
        the_file.write('INVALID CONTENTS')
    # the file exists, but has invalid contents -> ConfigFileError is raised
    try:
        baseConfigDict.load()
        assert False
    except ConfigFileError:
        assert True
    # finally we create a valid empty file
    with open('/tmp/config.json', 'w') as the_file:
        the_file.write('{}')
    # the file exists and has valid contents -> no exception is raised

# Generated at 2022-06-11 23:14:02.284056
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie import config
    from httpie.config import ConfigFileError

    class TestConfig(BaseConfigDict):
        name = 'test'

    with pytest.raises(ConfigFileError):
        c = TestConfig(config.Config().directory / 'test.json')
        c.load()

# Generated at 2022-06-11 23:14:08.668570
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    base_config_dict = BaseConfigDict(Path('~/.httpie/config.json'))
    print(base_config_dict.path.parent)
    try:
        base_config_dict.ensure_directory()
    except OSError as e:
        print('catch exception: ', e)


if __name__ == '__main__':
    # test_BaseConfigDict_ensure_directory()
    print(DEFAULT_CONFIG_DIR)
    config = Config()
    config.load()

# Generated at 2022-06-11 23:14:17.193849
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import tempfile
    from json import loads

    class MyTempFile(BaseConfigDict):
        DEFAULTS = {
            'default_options': 'hi'
        }

        def __init__(self, path: Path):
            self.directory = Path(tempfile.gettempdir())
            super().__init__(path=self.directory / 'my.conf')

    p = MyTempFile(tempfile.gettempdir())

    p.save()
    assert p.is_new() is True



# Generated at 2022-06-11 23:14:23.067207
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:14:32.861201
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir() 
        os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_WINDOWS_CONFIG_DIR)
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
    else:
        assert DEFAULT_CONFIG_DIR == get_default_config_dir() 
        os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_CONFIG_DIR)
        assert DEFAULT_CONFIG_DIR == get_default_config_dir()
        del os.environ[ENV_HTTPIE_CONFIG_DIR]

# Generated at 2022-06-11 23:14:43.103290
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    httpie_config_session_file = os.getenv("HTTPIE_CONFIG_SESSION_FILE")
    if not httpie_config_session_file:
        # Skip this test if HTTPIE_CONFIG_SESSION_FILE is not defined
        return 

    session = os.path.basename(httpie_config_session_file)

    with open(httpie_config_session_file, 'r+') as f:
        try:
            config = json.load(f)
        except ValueError as e:
            print(f'invalid session file: {e} [{httpie_config_session_file}]')
            return

# Generated at 2022-06-11 23:14:47.393708
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('test_config')
    config_file = config_dir / 'config.json'
    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert config_dir.exists()
    config_dir.rmdir()

# Generated at 2022-06-11 23:14:53.610297
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    testdict = BaseConfigDict('config.json')
    #dict = {'default_options':[ ]}
    with open('config.json') as f:
        data = json.load(f)
    testdict.update(data)
    print('unittest result:')
    print(testdict)
    assert testdict['default_options'] == []



# Generated at 2022-06-11 23:15:06.773425
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    # Test method save, which saves the content of a config file.
    # It generates a config file in the directory, "./common"
    # Test method save, which saves the content of a config file.
    import json
    from common.config import Config, BaseConfigDict
    from pathlib import Path

    # Create a directory, "./common"
    if (Path("./common")).exists():
        # If directory exists, remove it
        import shutil, os
        shutil.rmtree("./common")

    # Create a new directory, "./common"
    os.mkdir("./common")

    # Create a Config object
    config = Config("./common")


# Generated at 2022-06-11 23:15:13.455155
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    sub_dir = "/tmp/sub_dir/"    
    def create_new_existing_sub_dir():
        os.mkdir(sub_dir)
    create_new_existing_sub_dir()

    test_dir = '/tmp/sub_dir/test_dir/'
    os.makedirs(test_dir)
    path = Path(test_dir)
    config_dict = BaseConfigDict(path)
    config_dict.ensure_directory()

    # Clean up
    os.rmdir('/tmp/sub_dir/test_dir/')
    os.rmdir('/tmp/sub_dir/')


# Generated at 2022-06-11 23:15:24.010518
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # No environment variables
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)

    # 1. Unsupported platform
    if is_windows:
        raise AssertionError("Please test on UNIX-like OS")

    # 2. Legacy ~/.httpie, exists
    os.environ[HOME] = Path.home() / 'fake_home'
    assert os.environ[HOME] == get_default_config_dir()
    Path(os.environ[HOME]) / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR.mkdir()
    assert Path(os.environ[HOME]) / DEFAULT_RELATIVE_LEGACY_CONFIG_DIR == get_default_config_dir()


# Generated at 2022-06-11 23:15:28.866105
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    cfg = BaseConfigDict(path=Config().directory / 'test.json')
    cfg.save()
    assert (Config().directory / 'test.json').exists()
    try:
        (Config().directory / 'test.json').unlink()
    except OSError as e:
        if e.errno != errno.ENOENT:
            raise

# Generated at 2022-06-11 23:15:32.151918
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # create a directory
    obj = BaseConfigDict(path=Path('test_directory/dict_file.json'))
    obj.ensure_directory()

    # create a file
    data = {
        "default_options": []
    }
    with open('test_directory/dict_file.json', 'w') as f:
        json.dump(data, f)

    # load
    obj.load()


# Generated at 2022-06-11 23:15:50.588227
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Test the function get_default_config_dir shall return the path to the httpie
    configuration directory.

    This directory isn't guaranteed to exist, and nor are any of its
    ancestors (only the legacy ~/.httpie, if returned, is guaranteed to exist).

    XDG Base Directory Specification support:

        <https://wiki.archlinux.org/index.php/XDG_Base_Directory>

        $XDG_CONFIG_HOME is supported; $XDG_CONFIG_DIRS is not

    """
    # 1. explicitly set through env
    # 1.1. env is set
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR)
    assert env_config_dir is None
    # 1.2. env isn't set

# Generated at 2022-06-11 23:15:57.710870
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dict = {"foo": {
                        "bar": {
                            "baz": "qux"
                        }
                    }
                 }
    with tempfile.NamedTemporaryFile(mode='w+') as f:
        json.dump(config_dict, f)
        f.seek(0)
        config = BaseConfigDict(path=f.name)
        config.load()
        assert config['foo']['bar']['baz'] == 'qux'


# Generated at 2022-06-11 23:16:08.193606
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    tmp_dir = Path('tmp_dir')
    fake_file = Path(tmp_dir / 'fake_file')  # fake file to make it work


# Generated at 2022-06-11 23:16:10.357520
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'



# Generated at 2022-06-11 23:16:20.808711
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from httpie import config
    import os
    import tempfile
    import sys
    import json
    config_dir = tempfile.mkdtemp()
    print(config_dir, file=sys.stderr)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = config_dir
    if os.path.exists(config_dir):
        Config(config_dir).save()

    # test 'fail_silently=True'
    file = config_dir + '/config.json'
    os.chmod(file, 0o000)
    Config(config_dir).save(fail_silently=True)
    os.chmod(file, 0o666)
    with open(file) as f:
        res = json.load(f, encoding='utf-8')

# Generated at 2022-06-11 23:16:30.943360
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import shutil
    os.chdir(os.path.dirname(__file__))
    try:
        shutil.rmtree("../../../test_env/mock_config/httpie")
    except:
        pass
    config = Config("../../../test_env/mock_config")
    config.save()
    assert config.directory / Config.FILENAME == Path("../../../test_env/mock_config/httpie/config.json")
    assert os.path.exists("../../../test_env/mock_config/httpie")
    assert config.is_new()
    config.delete()
    assert not config.is_new()
    assert not os.path.exists("../../../test_env/mock_config/httpie")



# Generated at 2022-06-11 23:16:36.938282
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # Configure the environment
    os.environ['XDG_CONFIG_HOME'] = 'config'
    os.environ['HTTPIE_CONFIG_DIR'] = ''

    # A new instance of class Config
    config = Config()

    # Ensure that the directory exists
    config.ensure_directory()

    # The directory must be created
    assert os.path.exists('config/httpie'), "The directory must be created"

# Generated at 2022-06-11 23:16:42.404024
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/httpie-test-config/subdir')
    config = BaseConfigDict(config_dir / 'config.json')
    try:
        config.ensure_directory()
        assert config_dir.exists()
    finally:
        shutil.rmtree(config_dir.parent, ignore_errors=True)



# Generated at 2022-06-11 23:16:49.077049
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import shutil
    assert shutil.which("python3", mode=os.X_OK) is not None
    assert shutil.which("curl", mode=os.X_OK) is not None
    conf = Config()
    conf.save()
    conf1 = Config()
    conf1.load()
    conf2 = Config()
    conf2.save()
    conf2.load()
    assert bool(conf1 == conf2)


# Generated at 2022-06-11 23:16:51.030822
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:17:20.397569
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from httpie.config import BaseConfigDict
    from httpie.config import ConfigFileError

    with TemporaryDirectory() as temp_dir:
        base_config = BaseConfigDict(path=Path(temp_dir) / 'config.json')
        assert base_config.is_new()
        with open(str(base_config.path), 'w') as f:
            # f.write('{"abc": "value"}')
            f.write('abc')
        assert not base_config.is_new()
        assert base_config.load() == ConfigFileError
        with open(str(base_config.path), 'w') as f:
            f.write('{"abc": "value"}')
        assert base_config.load() == None
        assert base_config

# Generated at 2022-06-11 23:17:24.518538
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    path_to_be_made = Path(os.getcwd()) / 'test-ensure-directory/test-ensure/test-ensure-directory/test/'
    BaseConfigDict(path_to_be_made).ensure_directory()
    assert path_to_be_made.parent.exists()


# Generated at 2022-06-11 23:17:29.280424
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('/tmp/test_config_dir')
    config_file = config_dir / 'config.json'
    config_file.parent.rmdir()

    config = BaseConfigDict(config_file)
    config.ensure_directory()
    assert os.path.isdir(config_file.parent)
    

# Generated at 2022-06-11 23:17:37.101292
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Windows
    assert 'httpie' in str(get_default_config_dir())

    # Legacy
    env_config_dir = os.path.join(os.path.expanduser('~'), '.httpie')
    with os.environ.copy():  # type: ignore
        del os.environ[ENV_HTTPIE_CONFIG_DIR]
        os.makedirs(env_config_dir, 0o700)
        assert str(get_default_config_dir()) == env_config_dir
        os.rmdir(env_config_dir)

    # Explicit
    with os.environ.copy():  # type: ignore
        os.environ[ENV_HTTPIE_CONFIG_DIR] = env_config_dir
        assert str(get_default_config_dir()) == env_config_

# Generated at 2022-06-11 23:17:46.343567
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home = '~/.config'
    httpie_config_dir = '~/.config/httpie'
    home = os.environ['HOME']

    # 1. test without setting environment variable
    assert get_default_config_dir() == Path(httpie_config_dir)

    # 2. test with setting environment variable
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '~/temp'
    assert get_default_config_dir() == Path('~/temp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 3. test with windows
    os.environ['APPDATA'] = '~/.config/httpie'
    assert get_default_config_dir() == Path(httpie_config_dir)
    del os.en

# Generated at 2022-06-11 23:17:53.457638
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    temp_dir = '.'
    class DummyClass(BaseConfigDict):
        name = 'Dummy name'
        helpurl = 'Dummy helpurl'
        about = 'Dummy about'
    config_dir = Path(temp_dir) / "tmp"
    config_file = config_dir / 'config.json'
    dummy = DummyClass(config_file)
    dummy.ensure_directory()
    assert config_dir.exists()
    os.rmdir(str(config_dir))



# Generated at 2022-06-11 23:17:55.882930
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os, httpie
    xdg_config_dir = os.environ.get('XDG_CONFIG_HOME')
    assert get_default_config_dir() == Path(xdg_config_dir) / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:18:00.919275
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    TEST_DIR = Path('tests/dir_for_ensure_directory')
    TEST_DIR.mkdir(mode=0o777, parents=True)
    test_obj = BaseConfigDict(path=TEST_DIR/'test')
    test_obj.ensure_directory()
    assert(test_obj.path.parent.exists())
    TEST_DIR.rmdir()



# Generated at 2022-06-11 23:18:05.085252
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() == Path('~/.config/httpie').expanduser()



# Generated at 2022-06-11 23:18:14.795868
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # DEFAULT
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    # ENV_HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/env-test'
    assert get_default_config_dir() == Path('/tmp/env-test')

    # ENV_XDG_CONFIG_HOME
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/env-test'
    assert get_default_config_dir() == Path('/tmp/env-test') / 'httpie'


# Generated at 2022-06-11 23:19:00.680285
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from shutil import copy2
    import os
    import httpie.config
    tmp_dir = httpie.config.DEFAULT_CONFIG_DIR / "test"
    tmp_dir.mkdir(exist_ok=True, parents=True)
    tmp_file = tmp_dir / "config.json"
    copy2("httpie/config.json", tmp_file)
    tmp_BaseConfigDict = BaseConfigDict(tmp_file)
    tmp_BaseConfigDict.save()
    assert os.stat("httpie/config.json").st_mtime != os.stat("httpie/config.json~").st_mtime
    os.unlink("httpie/config.json~")
    os.unlink("httpie/config.json")
    os.rmdir("httpie/httpie")



# Generated at 2022-06-11 23:19:02.913516
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
  config_dir = get_default_config_dir()
  print(config_dir)
  assert Path.exists(config_dir)


# Generated at 2022-06-11 23:19:10.550312
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'C:\\Temp'
    assert get_default_config_dir() == Path('C:\\Temp')
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-11 23:19:19.879729
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from mock import patch

    with patch.dict(os.environ, {}):
        assert get_default_config_dir() == Path.home() / '.config/httpie'

    with patch.dict(os.environ, {
        ENV_XDG_CONFIG_HOME: '/custom/dir'
    }):
        assert get_default_config_dir() == Path('/custom/dir/httpie')

    with patch.dict(os.environ, {
        ENV_HTTPIE_CONFIG_DIR: '/custom/dir'
    }):
        assert get_default_config_dir() == Path('/custom/dir')


# Generated at 2022-06-11 23:19:23.692145
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    ConfigFileError = 'httpie.config.ConfigFileError'
    try:
        config = BaseConfigDict(Path(""))
        config.load()
        assert False
    except SystemExit:
        assert True
    except ConfigFileError:
        assert False


# Generated at 2022-06-11 23:19:33.975904
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """
    Unit test for function get_default_config_dir
    """
    home_dir = Path(os.environ['HOME'])

    # 1. explicitly set through env HTTPIE_CONFIG_DIR
    env_config_dir = os.environ.get(ENV_HTTPIE_CONFIG_DIR, None)
    if env_config_dir:
        default_config_dir = get_default_config_dir()
        assert (default_config_dir == Path(env_config_dir))

    # 2. Windows
    if is_windows:
        default_config_dir = get_default_config_dir()
        assert (default_config_dir == DEFAULT_WINDOWS_CONFIG_DIR)

    # 3. legacy ~/.httpie

# Generated at 2022-06-11 23:19:42.019945
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    file= open("test_BaseConfigDict_save.txt","w+")
    file.write("# Unit test for method save of class BaseConfigDict\n")
    # Testing for fail silently
    directory = "./test_config"
    path = "./test_config/config.json"

# Generated at 2022-06-11 23:19:50.281036
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    """Copy of system test test_config_file_is_stored_in_the_right_place
    """
    if is_windows:
        expected_path = DEFAULT_WINDOWS_CONFIG_DIR
    else:
        expected_path = Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME

    assert os.getenv(ENV_HTTPIE_CONFIG_DIR) is None
    assert get_default_config_dir() == expected_path
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR


if __name__ == '__main__':
    test_get_default_config_dir()

# Generated at 2022-06-11 23:19:55.365708
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    config_dir = get_default_config_dir()
    path = Path(config_dir)
    if is_windows:
        assert config_dir == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert path.home().joinpath(DEFAULT_RELATIVE_XDG_CONFIG_HOME).joinpath(DEFAULT_CONFIG_DIRNAME) == config_dir

# Generated at 2022-06-11 23:20:03.801336
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    config_file = config_dir / 'config.json'
    contents = json.dumps(
        obj={
            'default_options': [],
        },
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    ) + '\n'
    class TestConfigDict(BaseConfigDict):
        pass
    test = TestConfigDict(config_file)
    test.ensure_directory()
    assert config_file.parent.exists()
    test.save()
    assert config_file.exists()
    assert config_file.read_text(encoding='utf-8') == contents

# Generated at 2022-06-11 23:20:51.167630
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class MyConfigDict(BaseConfigDict):
        pass

    my_config_dict = MyConfigDict(Path('/tmp/test.json'))
    # /tmp/test -> /tmp
    # /tmp/test/test.json -> /tmp/test
    my_config_dict.ensure_directory()
    assert my_config_dict.path.parent.is_dir()

    my_config_dict.path.parent.rmdir()
    assert not my_config_dict.path.parent.exists()


# Generated at 2022-06-11 23:20:52.614442
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    assert get_default_config_dir() == get_default_config_dir()

# Generated at 2022-06-11 23:20:55.352873
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config(directory=DEFAULT_CONFIG_DIR)
    config.save()
    assert config.is_new()
    config.delete()



# Generated at 2022-06-11 23:20:59.532275
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(path=Path('./test.json'))
    config_dict.save()
    with open('./test.json','r') as test_file:
        config_dict = json.loads(test_file.read())
        assert config_dict['__meta__']['httpie'] == __version__


# Generated at 2022-06-11 23:21:01.150258
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = Config()
    config.save()
    assert config["__meta__"]["httpie"] == __version__

# Generated at 2022-06-11 23:21:11.904550
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from types import SimpleNamespace
    from httpie.compat import os

    class DummyOs:
        environ = {'XDG_CONFIG_HOME': '/foo'}

    os = SimpleNamespace(pathsep=';', environ=os.environ)

    assert get_default_config_dir() == Path('/foo') / DEFAULT_CONFIG_DIRNAME

    os.environ[ENV_XDG_CONFIG_HOME] = '~/.config_dir'
    assert get_default_config_dir() == Path('~/.config_dir') / DEFAULT_CONFIG_DIRNAME

    os = DummyOs()
    assert get_default_config_dir() == Path('/foo') / DEFAULT_CONFIG_DIRNAME


# Generated at 2022-06-11 23:21:15.284419
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    config_dir = Path('my_folder')
    BaseConfigDict(path = config_dir / 'important.json').ensure_directory()
    assert config_dir.is_dir()
    config_dir.rmdir()

# Generated at 2022-06-11 23:21:24.661042
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_BaseConfigDict_save.temp_config_dir = tempfile.TemporaryDirectory()
    test_BaseConfigDict_save.temp_config_dir.cleanup()
    test_BaseConfigDict_save.temp_config_dir = Path(test_BaseConfigDict_save.temp_config_dir.name)
    assert not test_BaseConfigDict_save.temp_config_dir.exists()

    dict_ = BaseConfigDict(test_BaseConfigDict_save.temp_config_dir)
    dict_['test'] = 'test'
    dict_.save()

    assert test_BaseConfigDict_save.temp_config_dir.exists()

# Generated at 2022-06-11 23:21:26.532973
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    cfg = BaseConfigDict(Path('../httpie/__about__.py'))
    cfg.save()


# Generated at 2022-06-11 23:21:33.189012
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import os
    import json
    import shutil
    from httpie.config import BaseConfigDict

    config_name = 'test'
    config_path = Path(f'/tmp/{config_name}')
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config = BaseConfigDict(path=config_path)
    config.save()
    with config_path.open('rt') as f:
        data = json.load(f)
        assert data['__meta__']['httpie'] == __version__, "can't save config's meta"
    shutil.rmtree(config_path.parent)

    # Test if the directory is a file
    bad_path = config_path.parent / '.'
    config = BaseConfigDict(path=bad_path)
