

# Generated at 2022-06-11 23:12:18.366330
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    d = BaseConfigDict(Path('test.json'))
    d['key'] = 'value'
    d.save()
    path = Path('test.json')
    path.unlink()
    assert path.exists() is False

test_BaseConfigDict_save()


# Generated at 2022-06-11 23:12:29.476141
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    # test original model
    config_dir = get_default_config_dir()
    if config_dir.exists():
        config_dir.rmdir()

    config = Config()
    assert config.is_new() == True
    config.ensure_directory()
    assert config_dir.exists() == True

    # test new model
    httpie_config_dir = Path(__file__).parent / "testdata" / "httpie"
    config_dir = httpie_config_dir / DEFAULT_CONFIG_DIRNAME
    if config_dir.exists():
        config_dir.rmdir()

    config = Config(httpie_config_dir)
    assert config.is_new() == True
    config.ensure_directory()
    assert config_dir.exists() == True


# Unit

# Generated at 2022-06-11 23:12:31.909769
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:12:40.350212
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import os
    import sys
    import pytest
    # On Windows
    if sys.platform == 'win32':
        assert get_default_config_dir() == Path(
            os.environ.get('APPDATA') + '\httpie\config.json')
    # On Mac
    if sys.platform == 'darwin':
        home = os.environ.get('HOME')
        assert get_default_config_dir() == Path(
            home + '/.config\httpie\config.json')
    # On Linux
    if sys.platform == 'linux':
        home = os.environ.get('HOME')
        assert get_default_config_dir() == Path(
            home + '/.config\httpie\config.json')

# Generated at 2022-06-11 23:12:49.313322
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    try:
        ConfigFileError
    except NameError:
        print("NameError: name 'ConfigFileError' is not defined")
    try:
        BaseConfigDict
    except NameError:
        print("NameError: name 'BaseConfigDict' is not defined")
    try:
        os
    except NameError:
        print("NameError: name 'os' is not defined")
    try:
        BaseConfigDict.load
    except AttributeError:
        print("AttributeError: type object 'BaseConfigDict' has no attribute 'load'")


# Generated at 2022-06-11 23:13:00.622067
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    import shutil
    import os

    dir_name = 'httpie'
    fd, file_path = tempfile.mkstemp()
    os.close(fd)
    file_name = os.path.basename(file_path)
    config_dir = os.path.join(os.path.split(file_path)[0], dir_name)
    config_file = os.path.join(config_dir, BaseConfigDict.FILENAME)

    if os.path.exists(os.path.dirname(config_dir)):
        shutil.rmtree(os.path.dirname(config_dir))

    assert not os.path.exists(config_file)
    config = Config(config_dir)
    config.ensure_directory()
    assert os.path

# Generated at 2022-06-11 23:13:01.424679
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    a = BaseConfigDict('/xxx')

# Generated at 2022-06-11 23:13:12.721318
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    default_config_dir = get_default_config_dir()
    # Clear all env variables
    for (env_name, _) in os.environ.items():
        del os.environ[env_name]

    # If the $HOME is ~/.config, the config directory should be ~/.config/httpie
    home_dir = Path.home()
    if home_dir.equal(Path('.config')):
        if not default_config_dir.equal(Path('.config/httpie')):
            print('The default config directory should be .config/httpie')
            print('However, it is:', default_config_dir)
            return False
        else:
            print(
                'Test succeed (if the current home directory is ~/.config)')
            return True

    # If the $HOME is not ~/.config, the config directory should

# Generated at 2022-06-11 23:13:23.976922
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    data_path = os.path.join("test_path")
    path = Path(data_path) / Config.FILENAME
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    for t in [True, False]:
        for d in [{}, {"a": 1}]:
            with open(path, 'wt') as f:
                json.dump(d, f)
                f.close()
            conf = Config(directory=path.parent)
            if t:
                conf.load()
                assert(conf == d)
            else:
                try:
                    conf.load()
                except ConfigFileError:
                    pass
            path.unlink()


if __name__ == '__main__':
    test_BaseConfigDict_load()

# Generated at 2022-06-11 23:13:32.990454
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    import tempfile
    from pathlib import Path
    temp_dir = Path(tempfile.gettempdir())
    temp_dir.mkdir(exist_ok=True, parents=True)
    path = temp_dir / 'test_dir/test_config.json'
    config_dict = BaseConfigDict(path)
    assert not config_dict.path.exists()
    assert not (config_dict.path.parent / 'test_dir').exists()
    config_dict.ensure_directory()
    assert config_dict.path.parent.exists()
    config_dict.delete()
    assert not config_dict.path.parent.exists()



# Generated at 2022-06-11 23:13:42.898913
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    test_config_dict = BaseConfigDict('./test.json')
    test_config_dict.load()
    assert test_config_dict['__meta__']['about'] == "https://github.com/jakubroztocil/httpie"
    assert test_config_dict['__meta__']['httpie'] == "1.0.2"

# Generated at 2022-06-11 23:13:53.596512
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from tempfile import TemporaryDirectory
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import Config
    import os
    import json

    example = """{
    "__meta__": {
        "httpie": "0.9.9"
    },
    "default_options": [
        "--form"
    ],
    "example": "1"
}
"""
    with TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname,'config.json')
        with open(filename, "w") as tmp:
            tmp.write(example)
        # print(tmpdirname)
        # assert tmpdirname.startswith('/tmp/pytest-of-zp/pytest-0/htt')
        config = Config(tmpdirname)
       

# Generated at 2022-06-11 23:14:02.032435
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_XDG_CONFIG_HOME] = '/home/httpie/config'
    assert get_default_config_dir() == Path('/home/httpie/config/httpie')
    del os.environ[ENV_XDG_CONFIG_HOME]

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/home/httpie/config'
    assert get_default_config_dir() == Path('/home/httpie/config')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    assert get_default_config_dir() == Path(Path.home() / '.config/httpie')



# Generated at 2022-06-11 23:14:04.061855
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path = '/home/httpie/config.json')
    config.load()


# Generated at 2022-06-11 23:14:12.278995
# Unit test for method ensure_directory of class BaseConfigDict
def test_BaseConfigDict_ensure_directory():
    class SuperBaseConfigDict(BaseConfigDict):
        def __init__(self, directory: Union[str, Path]):
            self.directory = Path(directory)
            self.path = self.directory
    path = SuperBaseConfigDict('/xxx/xxx')
    path.ensure_directory()
    assert path.directory.exists()
    path.directory.rmdir()
    path = SuperBaseConfigDict('/xxx/xxx')
    path.directory.mkdir(mode=0o700, parents=True)
    path.ensure_directory()
    path.directory.rmdir()
    path.directory.rmdir()
    path.directory.rmdir()
    Path('/xxx').rmdir()


# Generated at 2022-06-11 23:14:22.381189
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    DIR_PATH = os.path.dirname(os.path.abspath(__file__))
    valid_json_path = DIR_PATH + '/test_data/valid_config.json'
    invalid_json_path = DIR_PATH + '/test_data/invalid_config.json'

    empty_path = DIR_PATH + '/test_data/empty'
    os.makedirs(empty_path, mode=0o700, exist_ok=True)
    empty_json_path = empty_path + '/empty.json'

    with open(empty_json_path, 'w') as f:
        f.write('')

    with open(invalid_json_path, 'w') as f:
        f.write('test')


# Generated at 2022-06-11 23:14:32.738806
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Check the default value
    assert DEFAULT_CONFIG_DIR == get_default_config_dir()

    # Check the config dir specified in environment
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp/config'
    assert Path('/tmp/config') == get_default_config_dir()

    # Check the xdg dir
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert Path.home() / DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME == get_default_config_dir()

    # Check the xdg dir specified in environment
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp/xdg_config'

# Generated at 2022-06-11 23:14:34.286580
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    path = Path('./config/test.json')
    config_dict = BaseConfigDict(path)
    config_dict.load()

# Generated at 2022-06-11 23:14:44.286697
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import pathlib
    import shutil
    from httpie.config import BaseConfigDict
    from httpie import __version__

    httpie_path = pathlib.Path(__file__).parent
    httpie_config_path = pathlib.Path(httpie_path).parent / '.httpie'
    httpie_tempconfig_path = pathlib.Path(httpie_path).parent / '.tempconfig'

    # Set up, create temporary config directory
    shutil.rmtree(httpie_tempconfig_path, ignore_errors=True)
    # Create tempconfig directory
    httpie_tempconfig_path.mkdir()
    
    # Save to tempconfig directory
    test_config_dict = BaseConfigDict(httpie_tempconfig_path / "config.json")
    test_config_dict['__meta__']

# Generated at 2022-06-11 23:14:57.048319
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path=Path("./config.json"))
    def ensure_directory():
        try:
            config.path.parent.mkdir(mode=0o700, parents=True)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise
    def save():
        config['__meta__'] = {
            'httpie': __version__
        }
        config['__meta__']['help'] = "I am the help"

        config['__meta__']['about'] = "I am a test"

        ensure_directory()

        json_string = json.dumps(
            obj=config,
            indent=4,
            sort_keys=True,
            ensure_ascii=True,
        )

# Generated at 2022-06-11 23:15:11.788116
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    filename = 'test_curl_config.json'
    dirname = 'test_curl_config_dir'
    dirpath = Path(dirname)
    filepath = dirpath / filename

# Generated at 2022-06-11 23:15:13.754446
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(DEFAULT_CONFIG_DIR)
    config['hi'] = 'hello'
    config.save()

# Generated at 2022-06-11 23:15:23.726712
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/explicit'
    assert get_default_config_dir() == Path('/explicit')

    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_XDG_CONFIG_HOME] = '/explicit'
    assert get_default_config_dir() == Path('/explicit') / 'httpie'

    os.environ.pop(ENV_XDG_CONFIG_HOME)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

# Generated at 2022-06-11 23:15:34.554102
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # test_data JSON value was taken from file config.json under the directory
    # DEFAULT_CONFIG_DIR
    test_data = {
            "__meta__": {
                "about": "http://httpie.org/\n",
                "httpie": "1.0.3",
                "help": "http://httpie.org/docs#config"
            },
            "default_options": [
            ]
        }
    # test case 1:
    #     File contains 'default_options' key
    testObj1 = BaseConfigDict(Path("/tmp/kanglin/config.json"))
    testObj1.load()
    assert testObj1 == test_data
    # test case 2:
    #     File doesn't contains 'default_options' key

# Generated at 2022-06-11 23:15:36.518193
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR

# Generated at 2022-06-11 23:15:41.027756
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert DEFAULT_WINDOWS_CONFIG_DIR == get_default_config_dir()
    else:
        if ENV_XDG_CONFIG_HOME in os.environ:
            assert os.environ[ENV_XDG_CONFIG_HOME] + '/httpie' == get_default_config_dir()
        else:
            assert str(DEFAULT_CONFIG_DIR) == get_default_config_dir()

# Generated at 2022-06-11 23:15:50.727217
# Unit test for function get_default_config_dir

# Generated at 2022-06-11 23:15:52.363113
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    BaseConfigDict('/home/user/.config/httpie/config.json').load()

# Generated at 2022-06-11 23:16:01.521201
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config_dir = DEFAULT_CONFIG_DIR.joinpath('test_BaseConfigDict_load')
    config_file = config_dir.joinpath('config.json')
    class ConfigDict(BaseConfigDict):
        pass

    config_dict = ConfigDict(config_dir.joinpath('config.json'))
    config_dict.save(fail_silently=True)
    # test normal json file
    config_dict.load()
    # test invalid json file
    with open(config_file, 'w') as f:
        f.write('"invalid json string" {')
    try:
        config_dict.load()
    except ConfigFileError:
        pass
    else:
        raise RuntimeError("method load of class BaseConfigDict is invalid.")



# Generated at 2022-06-11 23:16:06.971862
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    from httpie.config import HTTPRESPONSES

    source = os.path.dirname(HTTPRESPONSES) + '/../../httpie/tests/configs/'
    test_config_file = source + 'broken_json_config.json'

    config = BaseConfigDict(test_config_file)
    config.load()


# Generated at 2022-06-11 23:16:15.981961
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        default_config_dir = Path(os.path.expandvars('%APPDATA%')) / DEFAULT_CONFIG_DIRNAME
    else:
        default_config_dir = Path.home() / '.config' / 'httpie'

    assert get_default_config_dir() == default_config_dir

# Generated at 2022-06-11 23:16:16.591159
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    assert True

# Generated at 2022-06-11 23:16:23.822657
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # Functionality tested in tests/test_config.py

    import os
    import httpie.config

    old_config_dir = os.environ.get('HTTPIE_CONFIG_DIR')
    os.environ['HTTPIE_CONFIG_DIR'] = '/test/test'
    assert httpie.config.get_default_config_dir() == Path('/test/test')

    old_xdg_home = os.environ.get('XDG_CONFIG_HOME')
    os.environ['XDG_CONFIG_HOME'] = '/test/home'
    assert httpie.config.get_default_config_dir() == Path('/test/home/httpie')

    os.environ.pop('XDG_CONFIG_HOME')
    home = os.environ['HOME']
    assert http

# Generated at 2022-06-11 23:16:28.745229
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR, None)
    os.environ.pop(ENV_XDG_CONFIG_HOME, None)
    assert get_default_config_dir() == Path.home() / '.config' / 'httpie'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = 'Httpie'
    assert get_default_config_dir() == 'Httpie'

    if is_windows:
        assert get_default_config_dir() == Path(os.environ['APPDATA']) / 'httpie'

# Generated at 2022-06-11 23:16:38.980185
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from tempfile import mkdtemp
    from shutil import rmtree
    from httpie import compat

    tmp_dir = mkdtemp()


# Generated at 2022-06-11 23:16:45.056011
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # given
    json_str = '''{
        "key1": "value1",
        "key2": "value2"
    }'''
    tmp_dir = Path(tempfile.mkdtemp(prefix='httpie_config_'))
    file = tmp_dir / 'config.json'
    file.write_text(json_str)

    # when
    config = BaseConfigDict(path=file)
    config.load()

    # then
    assert config['key1'] == 'value1'
    assert config['key2'] == 'value2'

# Generated at 2022-06-11 23:16:47.668400
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR


# Generated at 2022-06-11 23:16:58.540449
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test for invalid config file
    #invalid_config_dir = Path(__file__).parent
    #assert invalid_config_dir.exists()
    #invalid_config_path = invalid_config_dir / 'config_invalid.json'
    #assert not invalid_config_path.exists()
    
    #try:
    #    class InvalidConfigDict(BaseConfigDict):
    #        pass
    #    invalid_config = InvalidConfigDict(invalid_config_path)
    #    invalid_config.load()
    #except ConfigFileError:
    #    assert True
    #else:
    #    assert False
    
    # Test for valid config file
    valid_config_dir = Path(__file__).parent
    assert valid_config_dir.exists()
    valid_config

# Generated at 2022-06-11 23:16:59.778797
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir()
    assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR

# Generated at 2022-06-11 23:17:02.283123
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict('tests/fixtures/config/config.json')
    config.load()
    assert config['default_options'] == []


# Generated at 2022-06-11 23:17:18.290168
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # We fake $HOME as /home/test
    if not is_windows:
        os.environ['HOME'] = '/home/test'

    # Case 1: explicitly set HTTPIE_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == '/foo/bar'
    os.environ.pop(ENV_HTTPIE_CONFIG_DIR)

    # Case 2: Windows
    if is_windows:
        assert get_default_config_dir() == DEFAULT_WINDOWS_CONFIG_DIR
    else:
        assert get_default_config_dir() != DEFAULT_WINDOWS_CONFIG_DIR

    # Case 3: legacy ~/.httpie

# Generated at 2022-06-11 23:17:19.976319
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(Path(Config.FILENAME))
    config.load()


# Generated at 2022-06-11 23:17:29.438224
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    temp_path = Path('/tmp/test_load')
    test_file = BaseConfigDict(temp_path)
    if temp_path.exists():
        temp_path.unlink()

    # test for file 'test_load' not exist
    if test_file.is_new():
        assert test_file.load() == None

    # test of path parent dir not exist
    with open(temp_path, 'w') as f:
        f.write("""{"test_key":"test_value"}""")
    with pytest.raises(ConfigFileError) as excinfo:
        test_file.load()
    assert excinfo.value.args[0] == 'cannot read baseconfigdict file: [Errno 2] No such file or directory: \'/tmp/test_load\''

    # test of

# Generated at 2022-06-11 23:17:37.219812
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    with mock.patch.dict('os.environ', {ENV_HTTPIE_CONFIG_DIR: '/test/dir'}, clear=True):
        assert get_default_config_dir() == Path('/test/dir')

    with mock.patch('os.path.expandvars', return_value='C:\\User\\AppData\\Roaming\\Httpie'):
        assert get_default_config_dir() == Path('C:\\User\\AppData\\Roaming\\Httpie')

    with mock.patch.dict('os.environ', {ENV_XDG_CONFIG_HOME: '/test/config'}, clear=True):
        assert get_default_config_dir() == Path('/test/config/httpie')


# Generated at 2022-06-11 23:17:38.155399
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    pass


# Generated at 2022-06-11 23:17:46.893977
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    import unittest
    from unittest.mock import patch

    class UnitTestBaseConfigDict(unittest.TestCase):
        """Unit test for `BaseConfigDict`

        This will test load method of class BaseConfigDict
        """
        @patch('httpie.config.BaseConfigDict.path.open')
        @patch('httpie.config.BaseConfigDict.path.exists')
        def test_success_load(self, path_exists_mock, path_open_mock):
            """ When file exist, should load it.
            """
            test_path = Path('/test')
            path_exists_mock.return_value = True
            path_open_mock.return_value = mock_file = mock_open(read_data='{"a":1}').return_

# Generated at 2022-06-11 23:17:56.388110
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TempConfigDict(BaseConfigDict):
        def __init__(self):
            super().__init__('httpie/tests/temp_config.json')

        def load(self):
            raise NotImplementedError

    config_dict = TempConfigDict()
    config_dict['key1'] = 'value1'
    config_dict['key2'] = 'value2'
    config_dict.save()

    with open('httpie/tests/temp_config.json') as f:
        line = f.readline()
        assert line == '{\n'
        line = f.readline()
        assert line == '    "key1": "value1",\n'
        line = f.readline()
        assert line == '    "key2": "value2",\n'

# Generated at 2022-06-11 23:18:02.826277
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/.my_httpie/'
    assert get_default_config_dir() == '/.my_httpie/'

    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/.my_httpie/'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    assert get_default_config_dir() == '/.config/httpie/'

# Generated at 2022-06-11 23:18:10.215320
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    if os.path.isdir('unit_test') == False:
        os.mkdir('unit_test')
    os.chdir('unit_test')
    try:
        os.mkdir('httpie')
    except FileExistsError:
        pass
    os.chdir('httpie')
    with open("config.json", "w") as f:
        f.write("hello, world!")
    c = Config()
    assert c.is_new() == False

# Generated at 2022-06-11 23:18:18.805675
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    print("\n-------------------test_BaseConfigDict_save-------------------\n")

    class TestBaseConfigDict(BaseConfigDict):
        FILENAME = "test_utils.json"

    path = Path("./test_utils.json")
    t_bcd = TestBaseConfigDict(path=path)
    t_bcd.ensure_directory()
    json_string = json.dumps(
        obj=t_bcd,
        indent=4,
        sort_keys=True,
        ensure_ascii=True,
    )
    t_bcd.path.write_text(json_string + '\n')


# Generated at 2022-06-11 23:18:39.445875
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class Sub(BaseConfigDict):
        pass

    # Create an empty config file
    data = ''
    path = Path('./config.json')
    with path.open('wt') as f:
        f.write(data)

    def test():
        sub = Sub(path=path)
        sub.load()
        assert isinstance(sub, BaseConfigDict)

    # The file is an empty file
    test()

    # The file is not an empty file but not a valid json file
    data = '{'
    with path.open('wt') as f:
        f.write(data)
    from httpie.config import ConfigFileError
    try:
        test()
        assert False, 'ConfigFileError should be thrown'
    except ConfigFileError as e:
        assert True

# Generated at 2022-06-11 23:18:41.029161
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    path = get_default_config_dir()
    assert isinstance(path, Path)

# Generated at 2022-06-11 23:18:51.179459
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    try:
        del(os.environ[ENV_HTTPIE_CONFIG_DIR])
    except KeyError:
        pass
    try:
        del(os.environ[ENV_XDG_CONFIG_HOME])
    except KeyError:
        pass

    assert get_default_config_dir() == home_path(
        DEFAULT_RELATIVE_XDG_CONFIG_HOME / DEFAULT_CONFIG_DIRNAME)
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/foo/bar'
    assert get_default_config_dir() == '/foo/bar'
    os.environ[ENV_HTTPIE_CONFIG_DIR] = ''
    assert get_default_config_dir() == home_path('.config/httpie')

# Generated at 2022-06-11 23:18:57.079232
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    import json
    import tempfile
    path = tempfile.gettempdir()
    config_dict = BaseConfigDict(Path(path) / 'test.conf')
    config_dict['a'] = 'a'
    config_dict.save()
    assert json.loads(Path(path) / 'test.conf'.read_text()) == {'a':'a'}

# Generated at 2022-06-11 23:18:59.652392
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == DEFAULT_CONFIG_DIR
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/tmp'
    assert get_default_config_dir() == Path('/tmp')
    del os.environ[ENV_HTTPIE_CONFIG_DIR]
    os.environ[ENV_XDG_CONFIG_HOME] = '/tmp'
    assert get_default_config_dir() == Path('/tmp') / DEFAULT_CONFIG_DIRNAME

# Generated at 2022-06-11 23:19:01.585973
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    assert get_default_config_dir() == Path.home() / Path('.config') / Path('httpie')

# Generated at 2022-06-11 23:19:09.755367
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from unittest import TestCase
    from unittest.mock import patch

    class Dummy(BaseConfigDict):
        name = 'dummy'
        helpurl = 'https://example.com/help'
        about = 'about'

    class DummyTests(TestCase):

        @patch('httpie.config.BaseConfigDict.is_new')
        @patch('httpie.config.BaseConfigDict.ensure_directory')
        def test_save_non_empty(self, ensure_directory, is_new):
            ensure_directory.return_value = None
            is_new.return_value = True
            d = Dummy('dummy')
            d['a'] = 'b'
            d.save()
            ensure_directory.assert_called_with()
            is_new.assert_called

# Generated at 2022-06-11 23:19:20.557502
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    # Test to check if ConfigFileError exception is raised when there is an error while reading the file
    import json
    with open('test-file.json', 'w') as f:
        json.dump({"test": "value"}, f)
    from httpie.config import BaseConfigDict
    class testBase(BaseConfigDict):
        def __init__(self):
            super().__init__(path='test-file.json')
    testClass = testBase()
    try:
        import os
        os.remove('test-file.json')
        testClass.load()
        assert False
    except ConfigFileError:
        assert True
    # Test to check if ConfigFileError exception is raised when the file is not in json format

# Generated at 2022-06-11 23:19:23.225206
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    bd = BaseConfigDict(path=Path(os.getcwd())/"test1.json")
    bd.load()
    print(bd)


# Generated at 2022-06-11 23:19:31.192488
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_obj = BaseConfigDict(path='test_config.json')
    config_obj['test_key'] = 'test_value'
    config_obj['test_key'] = 'test_value'
    config_obj.save()
    assert config_obj.path.exists() is True
    assert 'https://github.com/jkbrzt/httpie#config' in config_obj['__meta__']['help']
    assert 'Open source HTTPie client, a user-friendly cURL replacement.' in config_obj['__meta__']['about']
    os.remove('test_config.json')


# Generated at 2022-06-11 23:19:45.502066
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    class TestConfig(BaseConfigDict):
        name = 'test_config'
        helpurl = 'https://www.example.com/'
        about = 'This is a test config file.'
    test_config = TestConfig(Path('test_config.json'))
    assert test_config.is_new()
    test_config.save()
    test_config.load()
    assert '__meta__' in test_config
    assert test_config['__meta__']['httpie'] == __version__
    assert test_config['__meta__']['help'] == test_config.helpurl
    assert test_config['__meta__']['about'] == test_config.about
    test_config.delete()

# Generated at 2022-06-11 23:19:54.038990
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dir = 'tests/temp/configs'
    if os.path.exists(config_dir):
        shutil.rmtree(config_dir)

    config = BaseConfigDict(config_dir + '/.httpie/config.json')
    config.ensure_directory()
    assert True == os.path.exists(config_dir)

    config.save()
    with open(config_dir + '/.httpie/config.json', "r") as f:
        assert json.load(f) == config

    if os.path.exists(config_dir):
        shutil.rmtree(config_dir)



# Generated at 2022-06-11 23:20:03.402961
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    from unittest.mock import patch
    with patch.dict(os.environ, {}):
        config = Config()
        default_config_dir = config.directory
        assert default_config_dir.name == 'httpie'
        assert default_config_dir.parent.name == '.config'
        assert default_config_dir.parent.parent.name == str(Path.home().name)

    # $XDG_CONFIG_DIRS base path
    os.environ[ENV_HTTPIE_CONFIG_DIR] = str(Path.home().joinpath('workspace'))
    config = Config()
    default_config_dir = config.directory
    assert default_config_dir.name == 'httpie'
    assert default_config_dir.parent.name == 'workspace'
    assert default_config_dir

# Generated at 2022-06-11 23:20:09.348216
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config_dict = BaseConfigDict(
        path=str(Path.cwd()) + '/' + 'config.json'
    )
    try:
        config_dict['a'] = 1
        config_dict['b'] = 2
        config_dict['c'] = 3
        config_dict.save()
    except:
        assert 0
    else:
        assert 1



# Generated at 2022-06-11 23:20:11.004514
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = Config()
    config.load()
    assert config['default_options'] == []



# Generated at 2022-06-11 23:20:13.449870
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    a = BaseConfigDict(Path(__file__))
    a.load()
    print(a)


# Generated at 2022-06-11 23:20:19.428051
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import tempfile
    if not is_windows:
        if os.environ.get(ENV_HTTPIE_CONFIG_DIR, None) is None:
            os.environ[ENV_HTTPIE_CONFIG_DIR] = str(DEFAULT_CONFIG_DIR)
            assert get_default_config_dir() == DEFAULT_CONFIG_DIR
        else:
            assert get_default_config_dir() == Path(os.environ[ENV_HTTPIE_CONFIG_DIR])

        if os.environ.get(ENV_XDG_CONFIG_HOME, None) is None and \
                os.environ.get(ENV_HTTPIE_CONFIG_DIR, None) is None:
            dir = Path(tempfile.gettempdir())

# Generated at 2022-06-11 23:20:21.557200
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    config = BaseConfigDict(path='/path_to/config1.json')
    config.load()
    assert config == {}, "Test failed"


# Generated at 2022-06-11 23:20:28.173156
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    from unittest.mock import patch
    from unittest.mock import Mock

    mock_path = Mock()
    mock_path.parent.mkdir.return_value = 1
    mock_path.exists.return_value = False
    mock_path.write_text.return_value = True
    config_dict = BaseConfigDict(mock_path)
    config_dict.save()
    
    mock_path.parent.mkdir.assert_called_once_with(mode=0o700, parents=True)
    mock_path.exists.assert_called_once()
    assert config_dict['__meta__'] == {"httpie":__version__}
    mock_path.write_text.assert_called_once()



# Generated at 2022-06-11 23:20:35.827826
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    def get_dir():
        env = os.environ.copy()
        if ENV_HTTPIE_CONFIG_DIR in env:
            del env[ENV_HTTPIE_CONFIG_DIR]
        if ENV_XDG_CONFIG_HOME in env:
            del env[ENV_XDG_CONFIG_HOME]

        return get_default_config_dir()


# Generated at 2022-06-11 23:20:55.308331
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    tmp_dir = Path('.tmp_dir')
    assert os.path.isdir(str(tmp_dir))
    tmp_dir.mkdir(parents=True, exist_ok=True)
    config_dict = BaseConfigDict(path=tmp_dir / Config.FILENAME)
    config_dict.save()
    assert config_dict.path.exists()
    config_dict.delete()

# Generated at 2022-06-11 23:21:04.002105
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    xdg_config_home = Path('/path/to/xdg_config_home')
    home = Path('/path/to/home')
    def get_home():
        return home
    def get_xdg_config_home():
        return xdg_config_home
    old_get_xdg_config_home = get_default_config_dir.get_xdg_config_home
    old_get_home = get_default_config_dir.get_home
    get_default_config_dir.get_xdg_config_home = get_xdg_config_home
    get_default_config_dir.get_home = get_home

    # No env var HTTPIE_CONFIG_DIR

# Generated at 2022-06-11 23:21:15.204569
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    import pytest
    from httpie import compat
    from httpie.compat import is_windows
    from pathlib import Path

    if not is_windows:
        with pytest.raises(KeyError):
            config_dir = get_default_config_dir()

        os.environ[ENV_HTTPIE_CONFIG_DIR] = '/some/path/httpie'
        config_dir = get_default_config_dir()
        assert str(config_dir) == '/some/path/httpie'

    expected_default_config_dir = DEFAULT_WINDOWS_CONFIG_DIR
    config_dir = get_default_config_dir()
    assert str(config_dir) == str(expected_default_config_dir)

if __name__ == '__main__':
    test_get_default_config_dir

# Generated at 2022-06-11 23:21:22.526456
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    class TestConfig(BaseConfigDict):
        path = Path('/tmp/httpie/test_BaseConfigDict_load.json')

    config = TestConfig(TestConfig.path)
    with pytest.raises(ConfigFileError):
        config.load()

    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}}

    config['foo'] = 'bar'
    config.save()
    config.load()
    assert config == {'__meta__': {'httpie': __version__}, 'foo': 'bar'}


# Generated at 2022-06-11 23:21:30.653908
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    here = os.path.dirname(os.path.realpath(__file__))
    home = os.path.join(here, 'test-home')
    expected_XDG_CONFIG_DIR = os.path.join(home,
                                           DEFAULT_RELATIVE_XDG_CONFIG_HOME,
                                           DEFAULT_CONFIG_DIRNAME)
    expected_legacy_config_dir = os.path.join(home,
                                              DEFAULT_RELATIVE_LEGACY_CONFIG_DIR)
    xdg_config_home_dir = os.path.join(home, 'config')
    expected_xdg_config_dir = os.path.join(xdg_config_home_dir,
                                           DEFAULT_CONFIG_DIRNAME)

    # 1. explicitly set through

# Generated at 2022-06-11 23:21:33.051100
# Unit test for method load of class BaseConfigDict
def test_BaseConfigDict_load():
    dir_path = os.getcwd()
    base_config_dict = BaseConfigDict(path=dir_path)
    base_config_dict.load()



# Generated at 2022-06-11 23:21:33.649281
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    Config().save()

# Generated at 2022-06-11 23:21:44.362723
# Unit test for function get_default_config_dir
def test_get_default_config_dir():
    # 'XDG_CONFIG_HOME' env
    os.environ[ENV_XDG_CONFIG_HOME] = '/test/xdg/config/home'
    assert get_default_config_dir() == os.path.join('/', 'test', 'xdg', 'config', 'home', DEFAULT_CONFIG_DIRNAME)
    del os.environ[ENV_XDG_CONFIG_HOME]

    # 'HTTPIE_CONFIG_DIR' env
    os.environ[ENV_HTTPIE_CONFIG_DIR] = '/test/httpie/config/dir'
    assert get_default_config_dir() == '/test/httpie/config/dir'
    del os.environ[ENV_HTTPIE_CONFIG_DIR]

    # 'HTTPIE_CONFIG_DIR

# Generated at 2022-06-11 23:21:47.864380
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    config = BaseConfigDict(Path('./config.json'))
    config.load()
    config['default_options'] = [1,2]
    config.save()


if __name__ == '__main__':
    test_BaseConfigDict_save()

# Generated at 2022-06-11 23:21:51.352169
# Unit test for method save of class BaseConfigDict
def test_BaseConfigDict_save():
    test_path = Path("test.json")
    if test_path.exists():
        test_path.unlink()
    test_config = BaseConfigDict(test_path)
    test_config.save()
    assert test_path.exists()

