

# Generated at 2022-06-26 11:36:57.870359
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    str_0 = ':tx0V^X'
    var_0 = extract_box_data(str_0, str_0)
    real_download = IsmFD.real_download
    var_1 = real_download(filename='http://a.b/video.mp4', info_dict=var_0)
    assert var_1 == False

if __name__ == '__main__':
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:37:09.585968
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = ParameterDict()
    info_dict['_download_params']['track_id'] = 1
    info_dict['_download_params']['fourcc'] = 'H264'
    info_dict['_download_params']['duration'] = 2
    info_dict['_download_params']['timescale'] = 3
    info_dict['_download_params']['language'] = 'und'
    info_dict['_download_params']['height'] = 0
    info_dict['_download_params']['width'] = 0
    info_dict['_download_params']['channels'] = 2
    info_dict['_download_params']['bits_per_sample'] = 16
    info_dict['_download_params']['sampling_rate'] = 4
   

# Generated at 2022-06-26 11:37:18.665629
# Unit test for function write_piff_header
def test_write_piff_header():
    print('Testing write_piff_header')

    stream = io.BytesIO()
    params = {'track_id': 0x1, 'fourcc': 'H264', 'duration': 1000, 'height': 720, 'width': 1280,
              'codec_private_data': '01640028ffe10008867640028ac32c00b0'}
    write_piff_header(stream, params)
    test_hex = binascii.hexlify(stream.getvalue())
    # test_hex is expected to be a hex encoded string
    print('test_hex: ' + str(test_hex))

# Generated at 2022-06-26 11:37:30.796437
# Unit test for constructor of class IsmFD

# Generated at 2022-06-26 11:37:41.585238
# Unit test for function write_piff_header
def test_write_piff_header():
    fourcc = 'AVC1'
    track_id = 3
    
    # "h264.avc"
    codec_private_data = '000000016742C00D9AC800000166F48BD000300010000300000300000300000300FF00'
    params = {
        'track_id': track_id,
        'fourcc': fourcc,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'codec_private_data': codec_private_data,
        'height': 720,
        'width': 1280,
        'duration': 4000,
        'timescale': 10000000,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

    # print(bin

# Generated at 2022-06-26 11:37:45.391050
# Unit test for function extract_box_data
def test_extract_box_data():
    str_0 = ':tx0V^X'
    assert extract_box_data(str_0, str_0) == str_0

compat_urllib_error.URLError = URLError
compat_urllib_error.HTTPError = HTTPError
compat_urllib_error.ContentTooShortError = ContentTooShortError

# Generated at 2022-06-26 11:37:48.505634
# Unit test for constructor of class IsmFD
def test_IsmFD():
    testfd = IsmFD()
    assert isinstance(testfd, IsmFD)


# Generated at 2022-06-26 11:37:57.232605
# Unit test for function write_piff_header
def test_write_piff_header():
    stream_0 = io.BytesIO()
    write_piff_header(stream_0, { 'track_id': 0, 'fourcc': 'H264', 'duration': 0, 'width': 0, 'height': 0, 'codec_private_data': '000000016742802980014D401F94100000030080000010560000000168CE38800'})
    print(stream_0.getvalue())
    # test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()
    test_case_4()


# Generated at 2022-06-26 11:38:03.478918
# Unit test for function write_piff_header
def test_write_piff_header():
    # 1. Initialization
    str_0 = ':tx0V^X'
    var_0 = extract_box_data(str_0, str_0)
    stream = io.BytesIO()

    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 1000
    params['timescale'] = 1
    params['width'] = 1280
    params['height'] = 720
    params['codec_private_data'] = '0142c01fffe1001767640034acd400b2a30201000468ee3c80'
    params['nal_unit_length_field'] = 4

    # 2. Execution
    write_piff_header(stream, params)

    # 3. Verification
    # TODO:
    #

# Generated at 2022-06-26 11:38:09.756791
# Unit test for function write_piff_header
def test_write_piff_header():
    str_0 = io.BytesIO()
    params = {'bits_per_sample': 16, 'duration': 0, 'track_id': 3, 'fourcc': 'AACL', 'sampling_rate': 44100, 'channels': 2}
    write_piff_header(str_0, params)
    params = {'codec_private_data': '67640028ffec1f2cb59deffb1f2cb59d0028ee3f0c000b0', 'track_id': 1, 'fourcc': 'AVC1', 'duration': 0}
    write_piff_header(str_0, params)

# Generated at 2022-06-26 11:38:23.120716
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()

# Generated at 2022-06-26 11:38:27.719473
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()
    print(ism_f_d_0)
    assert ism_f_d_0.FD_NAME == 'ism'


# Generated at 2022-06-26 11:38:28.384751
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD()

# Generated at 2022-06-26 11:38:39.054016
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'duration': 360,
        'timescale': 10000000,
        'nal_unit_length_field': 4,
        'codec_private_data': "0164001fffe100178dac1f902381010000012742f2c1f9003013328c0121f844001bfffffffe0001000468ee3c80",
        'height': 360,
        'width': 640,
    }
    with io.open('out.piff', 'wb') as f:
        write_piff_header(f, params)



import sys

# Generated at 2022-06-26 11:38:47.845633
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:38:51.825288
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:39:03.678031
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD("http://nimbus-video.us-west-2.amazonaws.com/hls/live/204477/cbs2/master.m3u8")
    assert ism_f_d.url == "http://nimbus-video.us-west-2.amazonaws.com/hls/live/204477/cbs2/master.m3u8"
    assert ism_f_d.video_id == "http://nimbus-video.us-west-2.amazonaws.com/hls/live/204477/cbs2/master.m3u8"
    assert ism_f_d.preference == -1
    assert ism_f_d.ie_key == 'Ism'
    assert ism_f_d

# Generated at 2022-06-26 11:39:13.347254
# Unit test for function write_piff_header
def test_write_piff_header():
    # TODO: test for audio
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 997664730,
        'timescale': 600000,
        #'language': 'und',
        'height': 1080,
        'width': 1920,
        'sampling_rate': 24000,
        'nal_unit_length_field': 4,
        'codec_private_data': '01640032AC02C0',
    }
    #output = io.BytesIO()
    output = open(r'C:\Users\Daniel\Desktop\test.ismv', 'wb')
    write_piff_header(output, params)
    output.seek(0)

# Generated at 2022-06-26 11:39:14.482568
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    test_case_0()

if __name__ == '__main__':

    test_IsmFD_real_download()

# Generated at 2022-06-26 11:39:15.937302
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()
    ism_f_d_1.real_download('baz', info_dict_0)


# Generated at 2022-06-26 11:39:34.331183
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00moov'
    box_sequence = ['moov']
    assert extract_box_data(data, box_sequence) == b''
    
    data = b'\x00\x00\x00\x00moov\x00\x00\x00\x00mvhd'
    box_sequence = ['moov', 'mvhd']
    assert extract_box_data(data, box_sequence) == b''
    
    data = b'\x00\x00\x00\x00moov\x00\x00\x00\x00mdhd\x00\x00\x00\x00hdlr'
    box_sequence = ['moov', 'mdhd', 'hdlr']

# Generated at 2022-06-26 11:39:40.205834
# Unit test for function extract_box_data
def test_extract_box_data():
    ism_f_d = IsmFD()
    test_data = ism_f_d._downloader.urlopen("https://download.microsoft.com/download/7/5/5/7556C785-F2E2-4CFA-9C9D-4E1D0B3BFAF0/200/200_10_v.ism/Manifest")
    box_data = extract_box_data(test_data, (b'pssh', b'box'))

    # Test PSSH box
    if u8.unpack(box_data[0:1])[0] != 1:
        print("Parsing pssh box error: wrong version")
    else:
        print("Parsing pssh box sucessfully: version is 1")


# Generated at 2022-06-26 11:39:41.760618
# Unit test for function write_piff_header
def test_write_piff_header():
    test_write_piff_header_0()
   

# Generated at 2022-06-26 11:39:52.679192
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('sample.ism', 'rb') as f:
        data = f.read()

    two_two_one = extract_box_data(data, [b'moov', b'mvhd'])

# Generated at 2022-06-26 11:40:01.050012
# Unit test for function extract_box_data
def test_extract_box_data():
    test_file = './unit_test_data/test_header.bin'
    with io.open(test_file, 'rb') as f:
        file_data = f.read()

    box_data = extract_box_data(file_data, ('moov', 'trex'))
    if u32.unpack(box_data[0:4])[0] != 0x0000000000000000:
        assert False, 'box_data extract failed, box_data: %s' % box_data
    if u32.unpack(box_data[4:8])[0] != 1:
        assert False, 'box_data extract failed, box_data: %s' % box_data

# Generated at 2022-06-26 11:40:02.720326
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:40:10.426798
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('sample-fragments/audio-0.dat', 'rb') as f:
        audio_data = f.read()
    box_data_for_moof = extract_box_data(audio_data, [b'moov', b'mvex', b'moof'])
    assert box_data_for_moof[-4:] == b'mdat'

if __name__ == '__main__':
    print('Unit test for extract_box_data:')
    test_extract_box_data()
    print('Passed.')

# Generated at 2022-06-26 11:40:13.488157
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # set up and run the test
    ism_f_d_1 = IsmFD()
    # set up expected result
    assert False
    # verify result
    assert False


# Generated at 2022-06-26 11:40:24.678427
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    params_0 = {u'test': True}

# Generated at 2022-06-26 11:40:26.499807
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    ism_f_d_0.real_download()


# Generated at 2022-06-26 11:45:33.470729
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = "http://localhost:8000/ism/test/manifest.ism/Manifest"
    http.get(url)
    #ism_f_d_0 = IsmFD()
    #pass

test_IsmFD_real_download()

# Generated at 2022-06-26 11:45:38.281359
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()
    try:
        ism_f_d_1.real_download(filename='test_downloads/sample.ism', info_dict=None)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 11:45:45.516803
# Unit test for function write_piff_header
def test_write_piff_header():
    fragment_fd = FragmentFD()
    with io.BytesIO() as f:
        write_piff_header(f, {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000,
            'timescale': 10000,
            'language': 'eng',
            'sampling_rate': 44100,
            'height': 0,
            'width': 0,
            'nal_unit_length_field': 4
        })
        data = f.getvalue()


# Generated at 2022-06-26 11:45:51.389922
# Unit test for function extract_box_data
def test_extract_box_data():
    file_path = 'test.ism'
    with open(file_path, 'rb') as f:
        content = f.read()
        extract_box_data(content, [b'moov'])
    print('test_extract_box_data pass')

if __name__ == '__main__':
    test_extract_box_data()

# Generated at 2022-06-26 11:45:57.055007
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    ism_f_d_0.real_download('filename', {'fragments': [{'url': 'segment.urlsegment.url'}], 'download_params': {'track_id': 0, 'sampling_rate': 'sampling.rate', 'bits_per_sample': 'bits.per.sample', 'channels': 'channels', 'codec_private_data': 'codec.private.data'}})


if __name__ == "__main__":
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:45:59.441589
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    ism_f_d_0.real_download(filename = '', info_dict = {})

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:46:00.487243
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-26 11:46:02.770140
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()
    assert ism_f_d_1.real_download('filename', 'info_dict') == False


# Generated at 2022-06-26 11:46:10.070268
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_manifest_url = 'http://video.ch9.ms/ch9/f3d3/cffdd0b8-61f9-4a74-89d0-55955f18f3d3/ScriptCS_mid.ism/ScriptCS_mid-Frag9'
    # test_manifest_url = 'http://video.ch9.ms/ch9/f3d3/cffdd0b8-61f9-4a74-89d0-55955f18f3d3/ScriptCS_mid.ism/ScriptCS_mid-Frag2'

    # http://video.ch9.ms/ch9/f3d3/cffdd0b8-61f9-4a74-89d0-55955f18f3d3/ScriptCS_mid.ism/ScriptCS_mid

# Generated at 2022-06-26 11:46:17.461528
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    ism_f_d_0.real_download('/tmp/test.mp4', {'title': 'Test', 'fragments': [{'duration': 1.0, 'url': 'http://test_url'}], '_download_params': {'track_id': 1, 'fourcc': 'AACL'}})

if __name__ == '__main__':
    test_case_0()
    test_IsmFD_real_download()