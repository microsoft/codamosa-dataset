

# Generated at 2022-06-26 11:37:02.588644
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url_0 = 'http://www.example.com'
    str_0 = 'a1a1b1a8bc70a89e49ccfd113aed0820'
    tuple_0 = (str_0,)
    var_0 = IsmFD(url_0)
    var_1 = extract_box_data(tuple_0, tuple_0)

# Generated at 2022-06-26 11:37:13.597320
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://dash.edgesuite.net/envivio/dashpr/clear/Manifest.mpd'
    first_manifest_data = compat_urllib_request.urlopen(
        url).read().decode('utf-8')
    manifest_url = re.search(
        r'(http://.+?/Manifest\(format=mpd-time-csf\).mpd)', first_manifest_data).group(1)
    seg_list = []
    for i in range(250):
        seg_list.append({'url': str(i)})

    class DummyInfo():
        pass

    info = DummyInfo()

# Generated at 2022-06-26 11:37:20.989144
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Setup args and expected result.
    filename = 'filename'
    info_dict = {
        'fragments': [
            {'url': 'https://fragment_url'},
        ]
    }
    # Instantiate IsmFD, setup and call method under test.
    ismfd = IsmFD(None, None, None)
    ismfd.real_download(filename, info_dict)


# Generated at 2022-06-26 11:37:22.423578
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # The parameter "params" is null
    ismfd = IsmFD()


# Generated at 2022-06-26 11:37:24.313675
# Unit test for function write_piff_header
def test_write_piff_header():
    # TODO: Please re-create this unit test. Today, this functions doesn't exist
    pass



# Generated at 2022-06-26 11:37:35.857749
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    output_stream = BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 5000
    params['timescale'] = 10000000
    params['language'] = 'und'
    params['height'] = 360
    params['width'] = 640
    params['sampling_rate'] = 44100
    params['channels'] = 2
    params['bits_per_sample'] = 16

# Generated at 2022-06-26 11:37:36.873260
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:37:38.914817
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Set up local variables
    ism_fd = IsmFD()
    return


# Generated at 2022-06-26 11:37:46.643912
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:37:47.667395
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:38:00.553207
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {})

# Generated at 2022-06-26 11:38:06.105556
# Unit test for constructor of class IsmFD
def test_IsmFD():
    path_0 = '/usr/local/bin/youtube-dl'
    path_1 = '/usr/local/bin/youtube-dl'
    bytes_0 = b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& '
    float_0 = 759.0
    var_0 = box(bytes_0, float_0)
    var_1 = IsmFD(path_1, path_0)


# Generated at 2022-06-26 11:38:18.431427
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing IsmFD.real_download')

    global test_count
    test_count = 0

    # Create a new instance of class IsmFD
    ism_fd = IsmFD()

    # Test with unset params
    try:
        ism_fd.real_download()
        test_fail('IsmFD.real_download failed with unset params')
    except TypeError as err:
        test_success()

    # Test with filename as string
    try:
        ism_fd.real_download('https://example.com/media.ism/media.ismv', None)
        test_fail('IsmFD.real_download failed with filename as string')
    except TypeError as err:
        test_success()

    # Test with filename as non-string

# Generated at 2022-06-26 11:38:20.163308
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

if __name__ == '__main__':
    import sys
    sys.exit(0)  # nothing executed

# Generated at 2022-06-26 11:38:31.213745
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = FakeYDL()
    url_0 = 'https://kk.com/'
    info_dict_0 = DictObject()
    ext_0 = 'mp4'
    info_dict_0.fragments = []
    info_dict_0._download_params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 234, 'timescale': 123, 'language': 'b1', 'height': 1, 'width': 2, 'channels': 3, 'bits_per_sample': 4, 'sampling_rate': 5}
    test_case_0()
    info_dict_0.filename = 'test-%(height)s-%(width)s-%(track_id)s.%(ext)s'

# Generated at 2022-06-26 11:38:43.452778
# Unit test for function extract_box_data
def test_extract_box_data():
    expected_data = b'\x9e\xc7\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:38:56.710859
# Unit test for function extract_box_data
def test_extract_box_data():
    test_box = b'\x00\x00\x00\x2c\x6d\x6f\x6f\x76\x00\x00\x00\x1c\x6d\x76\x68\x64\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    extracted_box = extract_box_data(test_box, b'moov/mvhd')

# Generated at 2022-06-26 11:39:04.919764
# Unit test for function write_piff_header
def test_write_piff_header():

    # Run code from Music from Memory
    # Load piff.txt into a dictionary, then call write_piff_header.
    f = open('piff.txt', 'r')
    piff = {}
    for line in f:
        line = line.split('=')
        piff[line[0]] = line[1].strip()
    f.close()
    piff = write_piff_header(piff)
    f = open('piff_out.txt', 'w')
    f.write(piff)
    f.close()
    return piff


# Generated at 2022-06-26 11:39:14.343099
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:39:19.845975
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # pass

    try:
        with open('test.ism', 'rb') as f:
            data = f.read()
    except:
        data = b''
    ydl = YoutubeDL({
        'outtmpl': u'%(id)s%(ext)s',
        'quiet': True,
    })
    fd = IsmFD(ydl, {})
    # assert fd.real_download(u'test.ism', {
    #     '_type': 'multi_fragment_video',
    #     'id': '0',
    #     'playlist': '',
    #     'fragments': [{'url': '', 'duration': 0, 'title': ''}],
    #     'title': '',
    #     'duration': 0,
    #     '_download

# Generated at 2022-06-26 11:39:42.829320
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:39:51.546407
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& ',)
    data = b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& '
    extracted_box_data = extract_box_data(data, box_sequence)
    assert extracted_box_data == b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& '


# Generated at 2022-06-26 11:40:00.333402
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test_common import test_get_video_info
    from .utils import (
        find_xpath_attr,
        get_element_by_id,
        xpath_with_ns,
    )
    from xml.dom.minidom import parseString as parse_xml

    # Test case 0
    test_case_0()
    # Test case 1
    kwargs = {}
    kwargs['url'] = 'regex://https?://smf\.blob\.core\.windows\.net/ism/Manifest\?(?:.*\&)?sr=(?P<id>[0-9]{4})'

# Generated at 2022-06-26 11:40:11.811162
# Unit test for function write_piff_header
def test_write_piff_header():
    memstream = io.BytesIO()
    write_piff_header(memstream, {
        'track_id': 1,
        'fourcc': 'AVC1',
        'codec_private_data': '0164001fffe1001927640020acd9428100000000',
        'nal_unit_length_field': 1,
        'height': 480,
        'width': 640,
        'duration': 1000,
        'timescale': 10,
    })
    mp4_header = memstream.getvalue()
    assert mp4_header[:4] == b'moov'
    assert u32.unpack(mp4_header[4:8]) == len(mp4_header[8:])  # moov size
    assert mp4_header[8:12] == b'mvhd'


# Generated at 2022-06-26 11:40:19.381022
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'filename'
    info_dict = {'fragments': [{'url': 'segment_url'}], '_download_params': {}}
    params = {'noprogress': 'internal'}
    fd = IsmFD(params)
    result = fd.real_download(filename, info_dict)
    assert type(result) == bool
    info_dict.update({'fragments': [{'url': 'segment_url'}], '_download_params': {'track_id': 1}, 'duration': 1, 'sampling_rate': 44100})
    result = fd.real_download(filename, info_dict)
    assert type(result) == bool

    result = fd.set_filename(filename)
    assert type(result) == str
    result = fd

# Generated at 2022-06-26 11:40:20.934174
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-26 11:40:23.095241
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case from file
    from ._test_IsmFD import test_case_0
    test_case_0()


# Generated at 2022-06-26 11:40:23.661235
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:40:28.285021
# Unit test for constructor of class IsmFD
def test_IsmFD():
    bytes_0 = b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& '
    float_0 = 759.0
    var_0 = box(bytes_0, float_0)

    test_case_0()


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:40:36.510266
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'de\x00\x00\x00\x00\x00\x00\x00\x00', [b'de']) == b'\x00\x00\x00'
    assert extract_box_data(b'de\x00\x00\x00\x00\x00\x00\x00\x00', [b'ad']) == None
    assert extract_box_data(b'de\x00\x00\x00\x00\x00\x00\x00\x00', [b'de', b'ad']) == None



# Generated at 2022-06-26 11:40:57.400012
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test.mp4', 'wb') as stream:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000,
            'codec_private_data': '28ee2c8050001f8d80001f8d907f01',
            'width': 1280,
            'height': 720,
            'nal_unit_length_field': 4,
        }
        write_piff_header(stream, params)


# Generated at 2022-06-26 11:41:04.218517
# Unit test for function extract_box_data
def test_extract_box_data():
    t1 = (b'moov', b'udta', b'meta')
    t2 = (b'udta', b'meta')
    t3 = (b'metd',)
    test_buffer = b'\x00\x00\x00\x1f\x6d\x6f\x6f\x76\x00\x00\x00\x1d\x75\x64\x74\x61\x00\x00\x00\x18\x6d\x65\x74\x61\x00\x00\x00\x0c\x6d\x65\x74\x64\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:41:08.939179
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x24ftypiso2\x00\x00\x02\x00piff'
    box_sequence = ['ftyp', 'piff']
    data_reader = io.BytesIO(data)
    assert extract_box_data(data, box_sequence) == data_reader.read()



# Generated at 2022-06-26 11:41:16.796570
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:41:19.654080
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        params = {}
        write_piff_header(f, params)

if __name__ == '__main__':
    test_case_0()
    test_write_piff_header()

# Generated at 2022-06-26 11:41:20.369179
# Unit test for constructor of class IsmFD
def test_IsmFD():
    f = IsmFD()
    #print('test_IsmFD:')


# Generated at 2022-06-26 11:41:28.543507
# Unit test for constructor of class IsmFD
def test_IsmFD():
    var_0 = IsmFD()
    # Test class IsmFD, attribute total_downloaded
    assert var_0.total_downloaded == 0, 'Class IsmFD, attribute total_downloaded should be 0, is %d.' % var_0.total_downloaded
    # Test class IsmFD, attribute frag_len
    assert var_0.frag_len == 0, 'Class IsmFD, attribute frag_len should be 0, is %d.' % var_0.frag_len
    # Test class IsmFD, attribute done
    assert var_0.done == False, 'Class IsmFD, attribute done should be False, is %s.' % var_0.done
    # Test class IsmFD, attribute tempfilename

# Generated at 2022-06-26 11:41:36.135720
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    params_0 = OrderedDict({
        'test': False,
    })
    ismfd_0 = IsmFD(params_0)
    # args to IsmFD.real_download: ([], 'filename', 'info_dict')
    assert ismfd_0.real_download(*([]), **{
        'filename': 'filename',
        'info_dict': 'info_dict',
    }) == True

if __name__ == "__main__":
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:41:37.734384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    instance = None
    instance = IsmFD(params)
    assert isinstance(instance, IsmFD)


# Generated at 2022-06-26 11:41:44.970974
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    params = {
        'format': 'ism',
    }

# Generated at 2022-06-26 11:42:34.734864
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url_0 = u'https://upv-dailymotion.akamaized.net/cdn/dailymotion-v5/_definst_/fr/1/video/00000/0/000005038_mp4_h264_aac_hq.ism/chunklist.m3u8?auth=1579510962-1261-q4yj6b5a-10d9e9ae1fbc5bd186d8e06ae83e11ec'
    content = load_fixture('chunklist.m3u8')
    urlhandle = compat_urllib_request.URLopener()

# Generated at 2022-06-26 11:42:43.199749
# Unit test for function extract_box_data
def test_extract_box_data():
    var_0 = b'moov'
    var_1 = b'mvhd'

# Generated at 2022-06-26 11:42:47.086180
# Unit test for function write_piff_header
def test_write_piff_header():
    bytes_0 = b'\xb2\xb1\x91\xf4\x1f\xc0\x0fN\x14u\xf7& '
    float_0 = 759.0
    var_0 = box(bytes_0, float_0)

    stream_0 = io.BytesIO(var_0)
    params_0 = {'duration': int(float_0), 'track_id': time.time()}
    write_piff_header(stream_0, params_0)



# Generated at 2022-06-26 11:42:55.433522
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00'
    expected_value = '\x00\x00\x00\x04\x00\x00\x00\x00'
    actual_value = extract_box_data(data, b'\x00\x00\x00\x10')

    assert(expected_value == actual_value)

if __name__ == '__main__':
    test_extract

# Generated at 2022-06-26 11:42:56.746551
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True


# Generated at 2022-06-26 11:43:04.634118
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'AVC1',
        'track_id': 1,

        # H264 specific parameters
        'codec_private_data': '0164001FFFE100186764001FFFE100186764001FFFE100186764001FFFE100186764001FFFE1001AC4F100FAFFE100186764001FFFE100186764001FFFE100186764001FFFE100186764001FFFE100186764001FFFE100186764001FFFE1001627A0006D31FFFFC0',
        'nal_unit_length_field': 4,
        'height': 720,
        'width': 1280,

        # Common parameters
        'duration': 0,
    }


# Generated at 2022-06-26 11:43:09.813318
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    config = {
        'username': 'admin',
        'password': os.getenv('PASSWORD', 'admin'),
        'nopart': True,
    }
    ydl = YDL(config)
    url = 'http://ismlive.akamaized.net/history/cnn_int/cnn_int_01/dashsmil/cnn_int_01.smil/cnn_int_01.smil.m3u8'
    result = ydl.extract_info(url, download=False)
    downloader = IsmFD(ydl, {'outtmpl': 'video-%(id)s.mp4'})
    #downloader.params['test'] = True
    downloader.real_download(result['url'], result)


# Generated at 2022-06-26 11:43:19.502977
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'fourcc': 'H264',
        'track_id': 1,
        'duration': 24000,
        'timescale': 30000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001927640014ac96146688012a801852c4321c',
        'nal_unit_length_field': 4,
    }
    buf = io.BytesIO()
    write_piff_header(buf, params)

# Generated at 2022-06-26 11:43:21.793639
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # TODO
    ismfd = IsmFD()

    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:43:27.331269
# Unit test for function write_piff_header
def test_write_piff_header():
    track_id = 0
    fourcc = 'AACL'
    duration = 0
    timescale = 0
    language = 'und'
    height = 0
    width = 0
    is_audio = True
    creation_time = 0
    modification_time = 0
    ftyp_payload = b'isml'
    ftyp_payload += u32.pack(1)
    ftyp_payload += b'piff' + b'iso2'
    mvhd_payload = u64.pack(0)
    mvhd_payload += u64.pack(0)
    mvhd_payload += u32.pack(0)
    mvhd_payload += u64.pack(0)
    mvhd_payload += s1616.pack(1)
    mvhd_

# Generated at 2022-06-26 11:44:49.495952
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    var_0 = IsmFD()
    var_1 = 'test_frag_index'
    var_2 = 'test_test'
    var_3 = 'no'
    var_4 = 'test_continue'
    var_5 = 'yes'
    var_6 = 'test_skip'
    var_7 = 'no'
    var_8 = 'test_fragment_retries'
    var_9 = 'no'
    var_10 = 'test_out'
    var_11 = 'test_playlist_min_filesize'
    var_12 = 'test_playlist_end'
    var_13 = 'test_writedescription'
    var_14 = 'no'
    var_15 = 'test_format'
    var_16 = 'test_noprogress'
   

# Generated at 2022-06-26 11:44:55.648832
# Unit test for function extract_box_data
def test_extract_box_data():
    var_0 = b'\xff\x00\x01\x02\x03\x04\x05'
    var_1 = b'\x01\x02\x03\x04\x05\x06\x07'
    bytes_0 = b'\x00\x00\x06\x00' + var_0 + b'\x00\x00\x08\x01' + var_1
    var_2 = extract_box_data(bytes_0, (var_0, var_1))
    #assert (var_2 == var_1)


# Generated at 2022-06-26 11:44:57.763194
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Assert that IsmFD is a class inherited from ExternalFD
    assert issubclass(IsmFD, ExternalFD)


# Generated at 2022-06-26 11:45:03.834163
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Setup
    url = 'http://example.com/video.ismv'
    video_id = 'example_video'
    password = ''
    params = {
        'http_chunk_size': (2 * 1024 * 1024),
        'keep_fragments': False,
        'ffmpeg_output_params': [],
        'http_headers': {},
        'test': False,
        'skip_unavailable_fragments': True,
        'nopart': False,
        'fragment_retries': 10,
        'continuedl': False,
        'proxy': None,
        'nocheckcertificate': False,
        'outtmpl': 'example_video.ismv',
    }
    downloader = IsmFD(url, video_id, params)
    # downloader.

# Generated at 2022-06-26 11:45:12.422965
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:45:20.592381
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:45:21.521213
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:45:23.366907
# Unit test for function extract_box_data
def test_extract_box_data():
    # this function is called with 0 arguments.
    assert (len(compat_urllib_error.Request()) == 0)


# Generated at 2022-06-26 11:45:33.562637
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:45:34.390853
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

