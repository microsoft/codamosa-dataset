

# Generated at 2022-06-26 11:37:02.542488
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    str_0 = ""
    dict_0 = {}
    bool_0 = False
    dict_0['_download_params'] = dict_0

    dict_0['url'] = str_0
    dict_0['fragments'] = [dict_0]

    test_IsmFD_real_download.num_of_test_cases += 1
    try:
        IsmFD(bool_0, dict_0).real_download(str_0, dict_0)
    except AssertionError:
        test_IsmFD_real_download.num_of_fail_cases += 1
        print('test_IsmFD_real_download: test case %s failed' % (test_IsmFD_real_download.num_of_test_cases))

# Generated at 2022-06-26 11:37:13.553388
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = FragmentFD()

    codec_private_data = '000000016742C00D9078BB01000001679CEB069E10300100000030080000000140420F000001B03C834C001000001BA0137880'  # AVC1 codec private data

    track1_params = {
        'track_id': 1,
        'duration': 2375000,
        'timescale': 10000,
        'language': 'eng',
        'height': 1080,
        'width': 1920,
        'fourcc': 'AVC1',
        'codec_private_data': codec_private_data,
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, track1_params)


# Generated at 2022-06-26 11:37:15.314110
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


# Generated at 2022-06-26 11:37:17.372308
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

# End of testcases for IsmFD

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:37:20.457056
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

# Unit test to verify if ctor of class IsmFD throws assertion error

# Generated at 2022-06-26 11:37:22.658092
# Unit test for function extract_box_data
def test_extract_box_data():
    result = extract_box_data('\x00' * 4, [b'test'])
    assert type(result) == NoneType



# Generated at 2022-06-26 11:37:32.252055
# Unit test for function write_piff_header
def test_write_piff_header():
    try:
        fd = FragmentFD()
        params = {
            'track_id': 0,
            'fourcc': 'H264',
            'duration': 10000,
            'timescale': 3000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 44100,
        }
        write_piff_header(fd, params)
        #print("test_write_piff_header: OK")
    except Exception as e:
        print("test_write_piff_header:", e)



# Generated at 2022-06-26 11:37:42.050523
# Unit test for function write_piff_header
def test_write_piff_header():
    stream_0 = io.BytesIO()
    params_0 = {'fourcc': 'avc1', 'track_id': 2, 'duration': 1000000, 'sampling_rate': 48000, 'height': 720, 'language': 'eng', 'channels': 2, 'bits_per_sample': 16, 'nal_unit_length_field': 4, 'codec_private_data': '0164001fffe100167674d40001f9d3a601c01e000428ee3c80', 'width': 1280}
    write_piff_header(stream_0, params_0)
    with open('write_piff_header.mp4', 'wb') as output:
        output.write(stream_0.getvalue())


# Generated at 2022-06-26 11:37:54.441637
# Unit test for function extract_box_data
def test_extract_box_data():
    moof_box_data = b'\x00\x00\x00\x2c\x6d\x6f\x6f\x66\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x28\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:38:04.129730
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 12345,
        'sampling_rate': 44100,
        'channels': 2,
    })


# Generated at 2022-06-26 11:38:17.178623
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ext = IsmFD()
    print('Test Failed')


# Generated at 2022-06-26 11:38:28.465701
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'fourcc': 'AACL',
        'duration': 200000000,
        }
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:38:32.805842
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD(params={}, ydl=None)
    # Attempt to call the constructor without arguments
    # This fails because the signature requires 'test' to be specified
    # with a default value of None, so we're not really sure what to do
    # here.
    try:
        fd = IsmFD()
    except TypeError:
        pass
    return True


# Generated at 2022-06-26 11:38:40.827066
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 2, 'fourcc': 'AACL', 'duration': 2000000000, 'timescale': 2048000, 'language': 'eng', 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100}
    write_piff_header(stream, params)
    stream.seek(0)
    assert stream.read() == bytes_0

# Generated at 2022-06-26 11:38:48.812667
# Unit test for function extract_box_data
def test_extract_box_data():
    bytes_0 = b'\x00\x00\x00,moof\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00'
    box_data = extract_box_data(bytes_0, (b'moof', b'trak'))

# Generated at 2022-06-26 11:38:59.114128
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert bytes_0 == b'\x00\x00\x00,moof\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00'

if __name__ == '__main__':

    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:39:09.981814
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-26 11:39:12.526225
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ismfd = IsmFD()

    filename = 'test_filename'
    info_dict = {
        'fragments': [
            {
                'url': 'test_url',
            },
            {
                'url': 'test_url2',
            },
        ],
        '_download_params': {},
    }
    assert ismfd.real_download(filename, info_dict) == False


# Generated at 2022-06-26 11:39:17.673634
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info_dict = {u'fragments': [{u'url': u'http://example.com/path/to/segment', u'duration': 1.0}], u'_download_params': {u'track_id': 1234, u'fourcc': b'avc1', u'timescale': 10000000, u'duration': 3600, u'width': 640, u'height': 360, u'codec_private_data': u'01640028ffe100067640028acd94163c80'}}
    filename = 'test_video.ism'

    # Call method
    ret = IsmFD.real_download(None, filename, info_dict)

    fd = open(filename, 'rb')
    assert ret == True
    assert fd.read() == bytes_0
    # fd.close

# Generated at 2022-06-26 11:39:29.047997
# Unit test for method real_download of class IsmFD