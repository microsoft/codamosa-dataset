

# Generated at 2022-06-26 11:36:48.719360
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:36:55.905159
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    ism_f_d_0 = IsmFD(bool_0, list_0)
    bool_0 = False
    str_0 = ''
    dict_0 = {'a': bool_0, 'b': str_0, 'c': bool_0}
    ism_f_d_0.real_download(bool_0, dict_0)

# Generated at 2022-06-26 11:36:58.967758
# Unit test for constructor of class IsmFD
def test_IsmFD():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    ism_f_d_0 = IsmFD(bool_0, list_0)


# Generated at 2022-06-26 11:37:00.395232
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


# Generated at 2022-06-26 11:37:08.954900
# Unit test for function write_piff_header
def test_write_piff_header():
    params1 = {
        'codec_private_data': '000000016764001EACD9081000001005B88000001B7100000100000030010000003C1392A0ED180124E4B1A8C1F943A0',
        'duration': 29951772,
        'fourcc': 'AVC1',
        'language': 'eng',
        'track_id': 1,
        'width': 640,
        'height': 360
    }
    assert write_piff_header(io.BytesIO(), params1) is None

# Generated at 2022-06-26 11:37:18.198054
# Unit test for function extract_box_data
def test_extract_box_data():
    moof_payload = b'\x00\x00\x00\x34'
    moof_payload += b'moof'
    moof_payload += b'\x00\x00\x00\x28'
    moof_payload += b'traf'
    moof_payload += b'\x00\x00\x00\x1c'
    moof_payload += b'trun'
    moof_payload += b'\x00\x00\x00\x10'
    moof_payload += b'\x00\x00\x00\x03'
    moof_payload += b'\x00\x00\x00\x04'
    moof_payload += b'\x00\x00\x00\x05'



# Generated at 2022-06-26 11:37:29.170023
# Unit test for function extract_box_data
def test_extract_box_data():
    data = "http://example.com/ism/scale/111456/manifest(guid=e90e4889-0b8e-4c61-a7ff-3c3a4a8cedbe,format=mp4,audiotrack=audio_en,bitrate=111456).ismc"
    box_sequence = ['http://example.com/ism/scale/111456/manifest(guid=e90e4889-0b8e-4c61-a7ff-3c3a4a8cedbe,format=mp4,audiotrack=audio_en,bitrate=111456).ismc']
    extract_box_data(data, box_sequence)


# Generated at 2022-06-26 11:37:36.052837
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        sa_0 = {'sampling_rate': 48000, 'track_id': 1, 'fourcc': 'AACL', 'channels': 2, 'bits_per_sample': 16, 'language': 'eng', 'duration': 30000000}
        test_write_piff_header.write_piff_header(stream, sa_0)

if __name__ == '__main__':
    test_write_piff_header()

# Generated at 2022-06-26 11:37:45.180432
# Unit test for function write_piff_header
def test_write_piff_header():
    track_id = int(0x18d0)
    fourcc = 'AVC1'
    duration = int(0)
    timescale = int(0xec6c)
    language = 'und'
    height = int(0x4e)
    width = int(0x4e)
    is_audio = width == 0 and height == 0
    creation_time = modification_time = int(time.time())

    ftyp_payload = b'isml'  # major brand
    ftyp_payload += u32.pack(1)  # minor version
    ftyp_payload += b'piff' + b'iso2'  # compatible brands

    mvhd_payload = u64.pack(creation_time)
    mvhd_payload += u64.pack(modification_time)


# Generated at 2022-06-26 11:37:47.656285
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

# Generated at 2022-06-26 11:38:04.364584
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    ism_f_d_0 = IsmFD(bool_0, list_0)
    str_0 = '$|!^]Bm\x0e'
    dict_0 = {str_0:str_0}
    ism_f_d_0.real_download(str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:38:07.457309
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Testcase setup
    ism_f_d = IsmFD(None, None)
    # Testcase execution
    # Testcase verification


# Generated at 2022-06-26 11:38:11.191310
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:38:13.366950
# Unit test for function extract_box_data
def test_extract_box_data():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    byte_array_0 = bytearray()
    ism_f_d_0 = IsmFD(bool_0, list_0)
    box_sequence = []
    assert (extract_box_data(bytearray(), []) == None)



# Generated at 2022-06-26 11:38:18.991720
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'test_filename'
    info_dict = {
        'fragments': [{'url': 'test_url'}]
    }
    test_case_0()
    ism_f_d_0 = IsmFD(False, [])
    ism_f_d_0.real_download(filename, info_dict)

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:38:19.900667
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:38:24.699094
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        test_case_0()
    except NameError as err:
        print("NameError: {0}".format(err))

if __name__ == "__main__":
    try:
        test_IsmFD()
    except NameError as err:
        print("NameError: {0}".format(err))

# Generated at 2022-06-26 11:38:26.108131
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


# Generated at 2022-06-26 11:38:28.373133
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:38:36.457468
# Unit test for function write_piff_header
def test_write_piff_header():
    strem_0 = io.BytesIO()
    track_id_0 = 0
    str_0 = 'test string'
    duration_0 = 0
    timescale_0 = 10000000
    language_0 = 'und'
    height_0 = 0
    width_0 = 0
    is_audio_0 = width_0 == 0 and height_0 == 0
    creation_time_0 = 0
    modification_time_0 = 0
    int_0 = int(0)
    ftyp_payload_0 = str_0.encode('utf-8')
    u32_pack_0 = u32.pack(8)
    bytes_0 = bytearray(b'mvhd')
    bytes_1 = bytearray(b'ftyp')

# Generated at 2022-06-26 11:39:00.384513
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    # Note: params is a dictionary
    params = {'track_id': 0,
              'fourcc': 'AACL',
              'duration': 10,
              'timescale': 10000000,
              'language': 'und',
              'height': 0,
              'width': 0,
              'channels': 2,
              'bits_per_sample': 16,
              'sampling_rate': 48000,
              'codec_private_data': '',
              'nal_unit_length_field': 4}
    write_piff_header(stream, params)
    # Note: After running the function write_piff_header,
    # the stream's buffer has data in it.
    header = stream.getvalue()
    # Note: The header is a bytearray.


# Generated at 2022-06-26 11:39:02.432574
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

test_IsmFD_real_download()

# Generated at 2022-06-26 11:39:12.353182
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    var_0 = None
    ism_f_d_0 = IsmFD(var_0, var_0)
    var_1 = "filename"

# Generated at 2022-06-26 11:39:13.901679
# Unit test for function extract_box_data
def test_extract_box_data():
    data_reader = io.BytesIO(b'test')
    assert box_type == b'test'


# Generated at 2022-06-26 11:39:16.010692
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    var_0 = None
    var_1 = {}
    ism_f_d_0 = IsmFD(var_0, var_0)
    ism_f_d_0.real_download(var_0, var_1)


# Generated at 2022-06-26 11:39:18.390698
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class Mock_IsmFD(IsmFD):
        """Mock for IsmFD"""
        def __init__(self):
            super(Mock_IsmFD, self).__init__(None, None)
    mock_ism_f_d_0 = Mock_IsmFD()


# Generated at 2022-06-26 11:39:27.000051
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(0x1a) + b'moov' + u8.pack(0) + u32.pack(0)
    data += u32.pack(0x1a) + b'mvex' + u8.pack(0) + u32.pack(0)
    data += u32.pack(0x1a) + b'mehd' + u8.pack(0) + u32.pack(0)
    assert extract_box_data(data, (b'mehd',)) == u32.pack(0)


# Generated at 2022-06-26 11:39:35.613109
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {}
    params['track_id'] = 100
    params['fourcc'] = 'vp09'
    params['duration'] = 100
    params['timescale'] =1000
    params['language'] = 'en'
    params['height'] = 1080
    params['width'] = 1920
    params['is_audio'] = False

    params['sampling_rate'] = 48000
    params['channels'] = 2
    params['bits_per_sample'] = 16

    params['codec_private_data'] = '01640033ffe1001767640033acd9402c8750f91b15a0fbf'
    stream_dummy = io.BytesIO()
    write_piff_header(stream_dummy, params)


test_write_piff_header()

# Generated at 2022-06-26 11:39:39.299144
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = None
    var_1 = None
    var_2 = None
    # Call method
    # Uncomment below to generate output for testing
    #output = ism_f_d_0.real_download(var_1, var_2)


# Generated at 2022-06-26 11:39:50.512257
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd_0 = IsmFD()
    ism_fd_0.report_skip_fragment(0)
    assert ism_fd_0.params == {'noprogress': True, 'quiet': True}, 'ism_fd_0.params != {"noprogress": True, "quiet": True}'

# Generated at 2022-06-26 11:40:12.877840
# Unit test for function extract_box_data
def test_extract_box_data():
    bytes_0 = b'test'
    try:
        _return_value = extract_box_data(bytes_0, [])
    except TypeError as _e:
        assert type(_e) is TypeError

    bytes_1 = b'\x00\x00\x00\x00test'
    try:
        _return_value = extract_box_data(bytes_1, [])
    except TypeError as _e:
        assert type(_e) is TypeError

    bytes_2 = b'\x00\x00\x00\x00test'
    try:
        _return_value = extract_box_data(bytes_2, [b'abcd'])
    except TypeError as _e:
        assert type(_e) is TypeError


# Generated at 2022-06-26 11:40:15.299862
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # case 1
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:40:21.358074
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 0, 'language': 'und', 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100}
    write_piff_header(stream, params)
#
#
# # Unit test for function write_piff_header
# def test_write_piff_header_1():
#     stream = io.BytesIO()
#     params = {'track_id': 1, 'fourcc': 'H264', 'duration': 0, 'language': 'und', 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100}
#     write_p

# Generated at 2022-06-26 11:40:22.494729
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True


# Generated at 2022-06-26 11:40:27.505760
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        inst_fd = IsmFD(params={})
        if not isinstance(inst_fd, IsmFD):
            raise AssertionError("%s constructor failed" % (str(IsmFD),))
    except Exception as inst_e:
        raise AssertionError("%s constructor failed" % (str(IsmFD),) + ":" + str(inst_e))


# Generated at 2022-06-26 11:40:29.360850
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(test_case_0(), (b'test',)) == None


# Generated at 2022-06-26 11:40:38.748229
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import  FileDownloader

    ydl = YoutubeDL({'forcejson': True})
    # Right now there is no way to handle the PIFF data
    # so we need to set --force-generic-extractor
    fd = IsmFD({'force-generic-extractor': True}, ydl)
    # self.to_screen(u'[debug] Calling _download_webpage')
    # self.report_destination(filename)
    fd._download_webpage(u'http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd')
    # self.to_screen(u'[debug] Calling _real_extract')
    fd._real_ext

# Generated at 2022-06-26 11:40:39.301969
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-26 11:40:43.668185
# Unit test for function write_piff_header
def test_write_piff_header():
    # Create a FakeFile instance
    f = io.BytesIO()

    # Plugin a FragmentWriter instance to it
    f = FragmentFD(f, 'wb')

    # Write the initialization segment to the FakeFile instance
    write_piff_header(f, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1337411,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16
    })

    # Check if the bytes of the FakeFile instance equals to the expected result
    # This is a very basic test, and you should set your own
    assert f.getvalue().rstrip() == b''


# Generated at 2022-06-26 11:40:49.641502
# Unit test for function extract_box_data
def test_extract_box_data():
    # Test with fourcc = 'TEST'
    if extract_box_data(b'test', [b'TEST']) != b'':
        raise TypeError('test_extract_box_data failed: test failed')
    # Test with fourcc = 'DEST'
    if extract_box_data(b'test', [b'DEST']) != None:
        raise TypeError('test_extract_box_data failed: test failed')



# Generated at 2022-06-26 11:41:06.149712
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing real_download of IsmFD')
    print('Not implemented')
    assert 1 == 1  # TODO: implement your test here
    print('Success!')


# Generated at 2022-06-26 11:41:07.503232
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:41:09.760123
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD({})
    is_none = ism_f_d_0 is None


# Generated at 2022-06-26 11:41:13.598921
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test_piff_header.ismv', 'wb') as piff_header_test:
        write_piff_header(piff_header_test, {'track_id': 1, 'fourcc': 'AACL', 'duration': 25, 'sampling_rate': 44100, 'channels': 2})


# Generated at 2022-06-26 11:41:17.388883
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'avc1', 'duration': 50, 'timescale': 10000000, 
              'language': 'und', 'height': 0, 'width': 0}
    stream = io.BytesIO()
    try:
        write_piff_header(stream, params)
    except:
        return 0
    return 1


# Generated at 2022-06-26 11:41:18.160767
# Unit test for constructor of class IsmFD
def test_IsmFD():
    var_0 = IsmFD(None, None)



# Generated at 2022-06-26 11:41:24.865148
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    box_sequence = ["isml", "moov", "trak", "mdia", "minf", "stbl", "stco"]


# Generated at 2022-06-26 11:41:26.846493
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    if not test_case_0():
        print('Method real_download from class IsmFD failed')


# Generated at 2022-06-26 11:41:27.600192
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:41:37.694845
# Unit test for function write_piff_header
def test_write_piff_header():


    # Constants
    FOURCC = 'f4c0'
    DURATION = 1234
    WIDTH = 4321
    HEIGHT = 8765
    CODEC_PRIVATE_DATA = 'private data'

    video_params_0 = {
        'fourcc': FOURCC,
        'track_id': 0,
        'duration': DURATION,
        'timescale': 10000000,
        'height': HEIGHT,
        'width': WIDTH,
        'codec_private_data': CODEC_PRIVATE_DATA
    }

    # Constants
    FOURCC = 'f4c0'
    DURATION = 1234
    WIDTH = 4321
    HEIGHT = 8765
    CODEC_PRIVATE_DATA = 'private data'

   

# Generated at 2022-06-26 11:41:57.523768
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # We pass a test case.
    test_case_0()


if __name__ == '__main__':
    # We run the test case
    test_IsmFD()

# Generated at 2022-06-26 11:42:00.494535
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()
    assert ism_f_d_0.FD_NAME == 'ism'


# Generated at 2022-06-26 11:42:06.387793
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Case where fragments is not defined.
    ism_f_d_0 = IsmFD()
    ism_f_d_0.params = {
        'skip_unavailable_fragments': True,
        'cachedir': 'test_IsmFD_real_download',
        'fragment_retries': 0,
        'test': False,
        'quiet': False,
        'writedescription': False,
        'simulate': False,
        'outtmpl' : 'test_IsmFD_real_download.ts',
    }
    info_dict_0 = {
        'id': '0',
    }
    var_0 = ism_f_d_0.real_download('test_IsmFD_real_download.ts', info_dict_0)
    # Case where

# Generated at 2022-06-26 11:42:16.418231
# Unit test for function write_piff_header
def test_write_piff_header():
    sample_packet = io.BytesIO()
    sample_packet.name = 'sample.ism'

# Generated at 2022-06-26 11:42:22.266330
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x80ftypiso5\x00\x00\x00\x01isomiso5'
    assert extract_box_data(test_data, [b'ftyp']) == b'iso5\x00\x00\x00\x01isomiso5'
    assert extract_box_data(test_data, [b'moot']) == None
    assert extract_box_data(test_data, [b'ftyp', b'isom']) == b'iso5\x00\x00\x00\x01isomiso5'


# Generated at 2022-06-26 11:42:28.155219
# Unit test for function write_piff_header
def test_write_piff_header():

    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 12000000,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000
    }
    #write_piff_header(stream, params)

    # Expected result
    #
    #ftyp_payload = b'isml'
    #ftyp_payload += u32.pack(1)
    #ftyp_payload += b'piff' + b'iso2'

    #mdhd_payload = u64.pack(int(time.time()))
    #mdhd_payload += u64.pack(int(time.time()))
    #

# Generated at 2022-06-26 11:42:38.814753
# Unit test for function write_piff_header
def test_write_piff_header():
    test_stream = io.BytesIO()
    params = {'sampling_rate': 3, 'bits_per_sample': 16, 'track_id': 4, 'codec_private_data': '0', 'fourcc': 'AACL', 'duration': 1}
    write_piff_header(test_stream, params)

# Generated at 2022-06-26 11:42:45.120491
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = b''
    data = b''
    if extract_box_data(data, box_sequence) is not None:
        raise Exception('Error!')
    data = b'\x00\x00\x00\x00'
    if extract_box_data(data, box_sequence) is not None:
        raise Exception('Error!')
    data = b'\x00\x00\x00\x00'
    box_sequence = b'\x00\x00\x00\x00'
    if extract_box_data(data, box_sequence) is not None:
        raise Exception('Error!')
    data = b'\x00\x00\x00\x00'

# Generated at 2022-06-26 11:42:46.019294
# Unit test for function extract_box_data
def test_extract_box_data():
    # Use case 0
    test_case_0()


# Generated at 2022-06-26 11:42:46.828673
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ctx = {}
    assert True


# Generated at 2022-06-26 11:43:15.835530
# Unit test for function write_piff_header
def test_write_piff_header():
    ism_file_data = FragmentFD(None, None, None, None, None)
    params = {
        'track_id': ism_file_data.track,
        'fourcc': 'AACL',
        'duration': ism_file_data.duration,
        'timescale': ism_file_data.timescale,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': ism_file_data.channels,
        'bits_per_sample': ism_file_data.bits_per_sample,
        'sampling_rate': ism_file_data.sampling_rate,
    }
    var_0 = write_piff_header(None, params)



# Generated at 2022-06-26 11:43:20.952812
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    io_0 = io.BytesIO()
    ism_f_d_0 = IsmFD({}, {'fp': io_0})
    ism_f_d_0.report_retry_fragment(None, 1, 0, 1)
    ism_f_d_0.report_skip_fragment(1)
    ism_f_d_0.report_error('giving up after 2 fragment retries')

# Generated at 2022-06-26 11:43:22.021031
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:43:23.036683
# Unit test for constructor of class IsmFD
def test_IsmFD():
    i = IsmFD(None, None, None)
    assert i is not None

# Generated at 2022-06-26 11:43:30.417736
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1234,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'is_audio': True,
        'creation_time': 1547661114,
        'modification_time': 1547661114
    }
    write_piff_header(stream, params)
    pass

# Generated at 2022-06-26 11:43:40.006770
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("Running test on method real_download...")
    ism_f_d_0 = IsmFD()

# Generated at 2022-06-26 11:43:42.296637
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    class_0 = IsmFD(None)
    class_0.real_download(ism_f_d_0, list_0)


# Generated at 2022-06-26 11:43:46.341063
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    file_name = 'file_name'
    info_dict = dict()
    info_dict['fragments'] = [0, 1, 2, 3, 4, 5]
    ism_fd = IsmFD(is_live=False, params=dict())
    ism_fd.real_download(file_name, info_dict)


# Generated at 2022-06-26 11:43:49.009050
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {}
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:43:50.225581
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert True



# Generated at 2022-06-26 11:44:29.361575
# Unit test for function write_piff_header
def test_write_piff_header():
    import cStringIO
    stream = cStringIO.StringIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 5,
        'sampling_rate': 44100,
        }
    # test_case_0
    params['fourcc'] = 'AACL'
    params['track_id'] = 1
    params['duration'] = 5
    params['sampling_rate'] = 44100
    write_piff_header(stream,params)
    print(stream.getvalue())
    #test_case_1

# Generated at 2022-06-26 11:44:32.670186
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD({'fragment_retries': 0})
    file_0 = 'filename_0'
    dict_0 = {'fragments': [], 'duration': 0, 'timescale': 0, 'track_id': 0, 'height': 0, 'width': 0, 'bits_per_sample': 0, 'sampling_rate': 0, 'channels': 0, 'language': 'language_0', 'fourcc': 'fourcc_0'}
    ism_f_d_0.real_download(file_0, dict_0)


# Generated at 2022-06-26 11:44:33.390355
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()
    return True


# Generated at 2022-06-26 11:44:33.734217
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:44:41.150375
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    media_url = 'http://fmpdashplayready1-vh.akamaihd.net/i/multiplatform-test/clear/clear_800_600/manifest.ismc'
    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s', 'quiet': True, 'skip_download': True})
    result = ydl.extract_info(media_url, download=False)
    ism_f_d = IsmFD(ydl, media_url, result['fragments'], {'test': True})
    ism_f_d.real_download(os.path.join(ydl.ydl.temp_name_prefix, u'test_video.ism'), result)
    pass

if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-26 11:44:43.017938
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD()
    assert ism_fd != None


# Generated at 2022-06-26 11:44:44.768486
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD(None, None, None)
    # assert ism_f_d is not None

test_case_0()

# Generated at 2022-06-26 11:44:50.022306
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 0, 'fourcc': 'AACL', 'sampling_rate': 44100, 'channels': 2, 'duration': 50*1000}
    write_piff_header(stream, params)

    # Verify output
    stream.seek(0)
    assert stream.read().startswith(b'\x00\x00\x00\x00ftyp')
    print('PASS: write_piff_header()')



# Generated at 2022-06-26 11:44:53.065451
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD({})
    ism_f_d_1.real_download('filename', {'fragments': [{'url': 'url'}]})


# Generated at 2022-06-26 11:44:55.826590
# Unit test for function write_piff_header
def test_write_piff_header():
    file_0 = io.BytesIO()
    # Write header in PIFF format with params
    # Assert that header from the file_0 is equal to the header with params
    write_piff_header(file_0, dict())
    var_0 = file_0.getvalue()


# Generated at 2022-06-26 11:46:15.867098
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    ism_f_d_1 = IsmFD()
    ism_f_d_2 = IsmFD()
    ism_f_d_3 = IsmFD()
    ism_f_d_4 = IsmFD()
    ism_f_d_5 = IsmFD()
    ism_f_d_6 = IsmFD()
    ism_f_d_7 = IsmFD()
    ism_f_d_8 = IsmFD()
    ism_f_d_9 = IsmFD()
    ism_f_d_10 = IsmFD()
    ism_f_d_11 = IsmFD()
    ism_f_d_12 = IsmFD()
    ism_

# Generated at 2022-06-26 11:46:18.871860
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()
    list_0 = [ism_f_d_0, ism_f_d_0, ism_f_d_0]
    var_0 = box(ism_f_d_0, list_0)


# Generated at 2022-06-26 11:46:20.443014
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:46:23.279867
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod().failed)

# Generated at 2022-06-26 11:46:24.913045
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_0 = IsmFD()
    # test case 0
    test_case_0()

test_class_list = [IsmFD]


# Generated at 2022-06-26 11:46:26.640266
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    fd_0 = IsmFD()
    #Test with an arbitrary None value for argument filename
    ism_f_d_0 = fd_0.real_download(None, None)


# Generated at 2022-06-26 11:46:27.082003
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert False


# Generated at 2022-06-26 11:46:34.545917
# Unit test for function write_piff_header
def test_write_piff_header():
    with FragmentFD(io.BytesIO()) as dest_stream:
        write_piff_header(dest_stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000,
            'timescale': 10000,
            'width': 1920,
            'height': 1080,
            'codec_private_data': (
                '000000016764001FACD9001F9410108D5003E3B00'
                '000003000168E91C01400101F6AFB0800'
            ),
        })