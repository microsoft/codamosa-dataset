

# Generated at 2022-06-26 11:36:58.208152
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    bool_0 = True
    url_0 = pytest.PlaceHolder(compat_urllib_request.Request)
    url_1 = pytest.PlaceHolder(compat_urllib_request.Request)
    var_0 = write_piff_header(bool_0, url_0)
    var_1 = extract_box_data(bool_0, url_1)

# Generated at 2022-06-26 11:37:09.933046
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x0001\x00\x00\x00\x02\x00\x00\x00\x03'
    box_sequence = (b'1', b'2', b'3')
    assert extract_box_data(data, box_sequence) == b''

    data = b'\x00\x00\x00\x000\x00\x00\x00\x02\x00\x00\x00\x03'
    box_sequence = (b'1', b'2', b'3')
    try:
        extract_box_data(data, box_sequence)
    except compat_urllib_error.HTTPError as e:
        assert e.code == 400
    else:
        assert False


# Generated at 2022-06-26 11:37:18.891734
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:37:21.641130
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD({})
    assert ism_fd.FD_NAME == 'ism'



# Generated at 2022-06-26 11:37:29.855205
# Unit test for function extract_box_data
def test_extract_box_data():
    data = bytearray(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    box_sequence = [b'aaa']
    expected_value = bytearray(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    returned_value = extract_box_data(data, box_sequence)
    # Unit test asserts that the function has returned the expected value
    assert returned_value == expected_value



# Generated at 2022-06-26 11:37:33.704773
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Tests whether an instance of IsmFD class can be created.
    #
    # Returns:
    #     None.
    #
    # Raises:
    #     None.
    obj = IsmFD()


# Generated at 2022-06-26 11:37:34.815504
# Unit test for function write_piff_header
def test_write_piff_header():
    test_case_0()


# Generated at 2022-06-26 11:37:36.343556
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 11:37:45.362036
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    bool_0 = False
    float_0 = 542.0902
    var_0 = IsmFD(bool_0, float_0)
    bool_1 = True
    str_0 = 'tools.py'

# Generated at 2022-06-26 11:37:50.805100
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_info_extractor(IsmFD())
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()