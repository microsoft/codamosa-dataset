

# Generated at 2022-06-26 11:37:00.894449
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 10000000
    params['timescale'] = 10000000
    params['language'] = 'und'
    params['height'] = 0
    params['width'] = 0
    params['is_audio'] = True 
    params['creation_time'] = int(time.time())
    params['modification_time'] = int(time.time())
    params['sampling_rate'] = 2
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['codec_private_data'] = 'abcdefg'
    write_piff_header(stream, params)  # TODO: Test this case.


# Generated at 2022-06-26 11:37:03.964885
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:37:09.305331
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialization for test_IsmFD_real_download
    test_IsmFD_real_download1 = IsmFD()
    # Assertion 'str_0' == '\\\\C', filename 'test.py', line 31
    assert(test_IsmFD_real_download1.real_download() == True)


# Generated at 2022-06-26 11:37:18.461592
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    segments= [{'url': 'https://mf.amn.com/test-r?test=test_IsmFD_real_download'}]
    info_dict = {'fragments': segments}
    filename = '\\\\C'
    bool_0 = bool()
    bool_1 = bool()
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1 = bool_0
    if bool_1:
        return False
    bool_1

# Generated at 2022-06-26 11:37:30.796832
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test of case 0
    params = {'fourcc': 'AACL', 'duration': 21600000, 'channels': 2, 'track_id': 1, 'sampling_rate': 44100, 'bits_per_sample': 16}
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:37:32.804984
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD('\\\\C', '\\\\C', '\\\\C', False)


# Generated at 2022-06-26 11:37:37.741983
# Unit test for function extract_box_data
def test_extract_box_data():
    # One test case
    data = bytearray([0, 0, 0, 0, 0, 0, 0, 0])
    box_sequence = (u'box',)
    try:
        extract_box_data(data, box_sequence)
    except compat_urllib_error.URLError:
        pass



# Generated at 2022-06-26 11:37:41.201755
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = [b'abcd']
    data = b''
    try:
        extract_box_data(data, box_sequence)
    except compat_urllib_error.HTTPError:
        pass



# Generated at 2022-06-26 11:37:49.386986
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'blob:http://test.com/test'
    dl = IsmFD()
    assert dl.params.get('outtmpl') == '%(id)s.ismv'
    assert dl.params.get('fragment_retries') == 10
    assert dl.params.get('test') == False
    assert dl.params.get('skip_unavailable_fragments') == True
    assert dl.params.get('noprogress') == False
    assert dl.params.get('keepvideo') == True

# Generated at 2022-06-26 11:38:00.664757
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import mock, compat_urllib_error

    def _download_fragment(self, ctx, url, info_dict):
        return True, 'fragment content'

    _real_download_IsmFD, IsmFD._real_download = IsmFD._real_download, _download_fragment
    ismfd = IsmFD({'fragment_retries': 0, 'skip_unavailable_fragments': True}, {'fragments': [{'url': 'segment_url'}]}, None, None)
    assert ismfd.real_download('filename', {'_download_params': {}, 'fragments': [{'url': 'segment_url'}]}) is True


# Generated at 2022-06-26 11:41:20.000248
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    var_0 = {}

# Generated at 2022-06-26 11:41:22.874971
# Unit test for constructor of class IsmFD
def test_IsmFD():
    arg_0 = {

    }

    test_case_0()
    yield var_0

# Generated at 2022-06-26 11:41:24.666221
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

test_IsmFD()

# Generated at 2022-06-26 11:41:32.238439
# Unit test for function extract_box_data
def test_extract_box_data():

    print ("Testing function extract_box_data")

    var_res = extract_box_data(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", b"\x00\x00\x00\x00")
    print ("%s" % repr(var_res))
    assert var_res == b""

    print ("No errors occured during testing of function extract_box_data")



# Generated at 2022-06-26 11:41:41.583056
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 9015000,
        'height': 720,
        'width': 1280,
        'nal_unit_length_field': 4,
        'codec_private_data': '0164001effe100176764001facd940800f80b0034c014042e012c58404058402800000168ee3c80'
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:41:43.133115
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {}
    ismfd = IsmFD(params)



# Generated at 2022-06-26 11:41:45.274212
# Unit test for function extract_box_data
def test_extract_box_data():
    assert False == "var_0 = extract_box_data(var_1, var_2)"


# Generated at 2022-06-26 11:41:56.192846
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD(params={})
    return



# Generated at 2022-06-26 11:42:04.536124
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    
    var_0 = __test__test_case_0()
    var_1 = {}
    
    # Don't care about this for now
    var_2 = var_1.get('fragments')
    
    # var_1['fragments'][:1] if var_1.get('test', False) else var_1['fragments']
    var_3 = var_2[:1]
    
    # var_1.get('test', False)
    var_4 = var_1.get('test', False)
    
    # var_3 if var_4 else var_2
    var_5 = var_3 if var_4 else var_2
    
    
    
    
    
    
    
    
    
    
    
    pass

test_IsmFD_real

# Generated at 2022-06-26 11:42:09.952083
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    var_0 = IsmFD()
    var_1 = {}
    var_0.real_download('/tmp/youtubedl/DDNqqOuV7Oo/playlist.m3u8', var_1)
    pass


# Generated at 2022-06-26 11:46:37.523599
# Unit test for constructor of class IsmFD
def test_IsmFD():
    var_5 = IsmFD("https://www.youtube.com/api/manifest/dash/id/bf5bb2419360daf1/source/youtube?as=fmp4_audio_clear,fmp4_sd_hd_clear&sparams=ip,ipbits,expire,source,id,as&ip=0.0.0.0&ipbits=0&expire=19000000000&signature=51AF5F39AB0CEC3E5497CD9C900EBFEAECCCB5C7.8506521BFC350652163895D4C26DEE124209AA9E&key=ik0", None)