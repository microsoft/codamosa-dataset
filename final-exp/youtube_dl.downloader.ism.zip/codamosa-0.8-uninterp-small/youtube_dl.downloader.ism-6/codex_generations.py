

# Generated at 2022-06-26 11:36:56.779853
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismfd = IsmFD()


# Generated at 2022-06-26 11:37:03.230968
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 0,
        'sampling_rate': 22500,
        'channels': 1
    }
    write_piff_header(stream, params)
    print(stream.getvalue())
    stream.close()
    print('[+] test for write_piff_header')


# Generated at 2022-06-26 11:37:14.084334
# Unit test for function write_piff_header
def test_write_piff_header():
    file_0 = io.BytesIO()

# Generated at 2022-06-26 11:37:21.167413
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # =========== Arguments initialization ===========
    # Argument 'ctx'
    ctx = {
        'total_frags': 1,
        'filename': 'C:\\fakepath\\test',
    }
    # Argument 'info_dict'
    info_dict = {
        'fragments': [
            {
                'url': 'https://testurl.net/test.ism/Fragments(0)',
            },
        ],
        '_download_params': {
            'fourcc': 'H264',
            'track_id': 1,
            'duration': 500,
            'timescale': 10000000,
            'language': 'und',
            'width': 640,
            'height': 360,
            'codec_private_data': '6764003cffffffff01',
        },
    }

   

# Generated at 2022-06-26 11:37:32.310514
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://example.invalid/video/15s/ism/segment-9202.ism'
    http_headers = {}
    ydl = YDL()
    ydl.add_default_info_extractors()
    res = ydl.extract_info(url, download=False)
    fd = IsmFD(ydl, res)

    # Test add_headers
    real_add_headers = fd.add_headers({})
    assert(real_add_headers) == {}

    # Test real_download
    filename = 'some_file'
    info_dict = {}
    fragments = [None]
    info_dict['fragments'] = fragments
    info_dict['_download_params'] = {}
    info_dict['_download_params']['track_id'] = 5
   

# Generated at 2022-06-26 11:37:35.306315
# Unit test for constructor of class IsmFD
def test_IsmFD():
    file_0 = IsmFD(0x000, 0x000)
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:37:44.709790
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as buf:
        params = {
            'fourcc': 'H264',
            'track_id': 1,
            'duration': 10000000,
            'timescale': 10000000,
            'width': 1280,
            'height': 720,
            'sampling_rate': 44100,
            'channels': 2,
            'nal_unit_length_field': 4,
            'codec_private_data': '000000016742C00D9608DE1EE32A00007D8DE03F55DE0F18DE24000BDE40000CDE40000CDE400009DE400009DE4000000010274000168EBECB59D',
        }
        write_piff_header(buf, params)
        buf.seek(0)
        assert buf.read()

# Generated at 2022-06-26 11:37:47.044084
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD()



# Generated at 2022-06-26 11:37:58.488789
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE
    test_case_0()
    test_IsmFD()
    youtube_dl = YoutubeDL()
    youtube_dl.add_info_extractor(YoutubeIE(youtube_dl))

# Generated at 2022-06-26 11:38:07.169278
# Unit test for function write_piff_header
def test_write_piff_header():
    buf = io.BytesIO()

    write_piff_header(buf, {
        'sampling_rate': 48000,
        'channels': 2,
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 1000,
    })

    data = buf.getvalue()

# Generated at 2022-06-26 11:38:31.124108
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # get info_dict
    self.params['test'] = True
    info_dict = self._get_info_dict(url, video_id)
    info_dict['_download_params'] = {}
    info_dict['_download_params']['fourcc'] = 'H264'
    info_dict['_download_params']['track_id'] = 1
    info_dict['_download_params']['timescale'] = 10000000
    info_dict['_download_params']['duration'] = 1355300000
    info_dict['_download_params']['height'] = 1080
    info_dict['_download_params']['width'] = 1920
    # create temp directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-26 11:38:43.316071
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:38:56.562086
# Unit test for function write_piff_header
def test_write_piff_header():
    # Success case
    params = {
        'track_id':0,
        'fourcc':'AACL',
        'duration':1000,
        'timescale':1000,
        'language':'und',
        'height':0,
        'width':0,
        'channels':1,
        'bits_per_sample':16,
        'sampling_rate':16000,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:38:58.414748
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD()


# Generated at 2022-06-26 11:39:03.499305
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test_write_header.ismv', 'wb') as stream:
        test_params = {
            'track_id': 0x01,
            'sampling_rate': 44100,
            'fourcc': 'AACL'
        }
        write_piff_header(stream, test_params)



# Generated at 2022-06-26 11:39:13.194551
# Unit test for function write_piff_header
def test_write_piff_header():
    # testcase 0, Audio
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'channels': 2
        }
    # testcase 1, Audio
    params2 = {
        'track_id': 2,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'channels': 2
        }
    # testcase 2, Video

# Generated at 2022-06-26 11:39:16.169937
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(3) + b'cont' + u32.pack(4) + b'abcd'
    box_type = extract_box_data(data, (b'cont',))
    print(str(box_type))
    assert box_type == b'abcd'


# Generated at 2022-06-26 11:39:21.327152
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:39:28.829823
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test_case_0.ismv', 'wb') as fh:
        write_piff_header(
            fh,
            {
                'track_id': 1,
                'duration': 2000000000,
                'timescale': 10000000,
                'sampling_rate': 48000,
                'channels': 2,
                'bits_per_sample': 16,
                'fourcc': 'AACL',
            }
        )


# Generated at 2022-06-26 11:39:31.233648
# Unit test for function write_piff_header
def test_write_piff_header():
    # test_write_piff_header
    fp = io.BytesIO()
    params = dict()
    write_piff_header(fp, params)
    pass



# Generated at 2022-06-26 11:39:45.384657
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # case 0
    ism_f_d_0 = IsmFD()


# Generated at 2022-06-26 11:39:56.307827
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 0xaabbccdd,
        'duration': 0x00112233,
        'fourcc': 'H264',
        'timescale': 1,
        'height': 720,
        'width': 1280,
        'sampling_rate': 44100,
        'nal_unit_length_field': 4,
        'channels': 2,
        'bits_per_sample': 16,
        'nal_unit_length_field': 4,
        'codec_private_data': '0000000167640032acd94080'
    }
    buffer = io.BytesIO()
    write_piff_header(buffer, params)

# Generated at 2022-06-26 11:40:01.930676
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id':1, 'fourcc':'AACL', 'codec_private_data': '1210', 'duration':2, 'sampling_rate':4, 'channels':2, 'bits_per_sample':16}
    stream = io.BytesIO()
    write_piff_header(stream, params)
    print(stream.getvalue())
    #with open('/Users/jianingy/git/douban/douban/piff/piff_header.txt', 'wb') as f:
    #    f.write(stream.getvalue())

# Generated at 2022-06-26 11:40:12.905801
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 951,
            'timescale': 3000,
            'language': 'eng',
            'height': 0,
            'width': 0,
            'codec_private_data': '1188F',
            'sampling_rate': 441000,
            'channels': 2,
            'bits_per_sample': 16
        }
        write_piff_header(stream, params)
        #print(binascii.hexlify(stream.getvalue()))

# Generated at 2022-06-26 11:40:22.902747
# Unit test for function extract_box_data
def test_extract_box_data():
    # Test case 0: Only one box in the data, extract the whole data
    box_data_1 = b'\x00\x00\x00\x0c' + b'abcd' + b'abcdefgh'
    box_data_2 = extract_box_data(box_data_1, [b'abcd'])
    assert(box_data_2 == b'abcdefgh')
    # Test case 1: The data contains two boxes and we extract the first box
    box_data_3 = b'\x00\x00\x00\x0c' + b'abcd' + b'abcdefgh' + b'\x00\x00\x00\x10' + b'efgh' + b'abcdefghijklmn'

# Generated at 2022-06-26 11:40:33.319897
# Unit test for function write_piff_header
def test_write_piff_header():
    # Case 0: Video track
    v_params = {
        'fourcc': 'H264',
        'track_id': 1,
        'duration': 500,
        'timescale': 10000000,
        'codec_private_data': '0164001fffe100176764001facd9c801010427e9000003000b27e9000003000c604280f',
        'width': 768,
        'height': 432
    }
    output = io.BytesIO()
    write_piff_header(output, v_params)

# Generated at 2022-06-26 11:40:41.331038
# Unit test for constructor of class IsmFD
def test_IsmFD():

    # Test 1
    # Test constructor
    # Result: should return an object whose variables have the default values
    ism_f_d_1 = IsmFD()
    assert ism_f_d_1.params["concurrent_segments"] == 10
    assert ism_f_d_1.params["fragment_retries"] == 10
    assert ism_f_d_1.params["skip_unavailable_fragments"] == True
    assert ism_f_d_1.params["keep_fragments"] == False

    # Test 2
    # Test constructor
    # Result: should return an object whose variables have the values input

# Generated at 2022-06-26 11:40:52.334961
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Set class attributes to test them
    ism_f_d = IsmFD()
    ism_f_d.params = {'part_size': '10485760'}
    ism_f_d.params['retries'] = 0
    ism_f_d.params['test'] = True
    ism_f_d.params['fragment_retries'] = 0
    ism_f_d.params['fragment_timeout'] = 10
    ism_f_d.params['skip_unavailable_fragments'] = False
    ism_f_d.to_stderr = sys.stderr.write
    ism_f_d.to_stdout = sys.stdout.write
    ism_f_d.to_screen = sys.stderr.write

# Generated at 2022-06-26 11:40:55.660642
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        ism_f_d = IsmFD()
    except AttributeError:
        print("test of class IsmFD is failed")
    else:
        print("test of class IsmFD is succeeded")

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:41:03.123250
# Unit test for function write_piff_header
def test_write_piff_header():
    ism_f_d_0 = IsmFD()
    ism_f_d_1 = IsmFD()
    ism_f_d_2 = IsmFD()

    track_id_0 = ism_f_d_0.track_id
    track_id_1 = ism_f_d_1.track_id
    track_id_2 = ism_f_d_2.track_id
    fourcc_0 = ism_f_d_0.fourcc
    fourcc_1 = ism_f_d_1.fourcc
    fourcc_2 = ism_f_d_2.fourcc
    duration_0 = ism_f_d_0.duration
    duration_1 = ism_f_d_1.duration
    duration_2 = ism_

# Generated at 2022-06-26 11:41:28.995375
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 20000000
    #params['timescale'] = 400000
    params['language'] = 'und'
    params['height'] = 0
    params['width'] = 0
    is_audio = 0
    params['is_audio'] = is_audio
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['sampling_rate'] = 48000
    params['nal_unit_length_field'] = 4


# Generated at 2022-06-26 11:41:35.992925
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD()
    ism_f_d.FD_NAME = 'ism'
    ism_f_d.real_download('abc.mkv',
        {
            'fragments': 'http://192.168.2.39/vod/big_buck_bunny_720p_surround.ism/QualityLevels(280000)/Fragments(video=2800000)'
        }
    )


# Generated at 2022-06-26 11:41:36.855218
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


# Generated at 2022-06-26 11:41:44.423845
# Unit test for function write_piff_header
def test_write_piff_header():
    
    params = {
                'track_id': 1,
                'fourcc': 'H264',
                'duration': 30000000,
                'timescale': 10000000,
                'language': 'und',
                'height': 0,
                'width': 0,
                'codec_private_data': '0000000167428029af00000168ce3880',
                'nal_unit_length_field': 4
            }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:41:46.986553
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert isinstance(IsmFD(), IsmFD)
    assert isinstance(IsmFD(), FragmentFD)
    assert issubclass(IsmFD(), FragmentFD)


# Generated at 2022-06-26 11:41:57.502272
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {}
    
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 50000000
    params['timescale'] = 10000000
    params['language'] = 'und'
    params['height'] = 0
    params['width'] = 0
    params['is_audio'] = False
    params['creation_time'] = int(time.time())
    params['modification_time'] = int(time.time())

# Generated at 2022-06-26 11:42:04.282413
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()

# Generated at 2022-06-26 11:42:06.736979
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()
    print(ism_f_d_0)

# test calls to extract_box_data

# Generated at 2022-06-26 11:42:15.302291
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD()
    print("Unit test for constructor of class IsmFD")
    print("Type of object ism_fd : ", type(ism_fd))
    print("dir(ism_fd) : ", dir(ism_fd))
    print("ism_fd.FD_NAME : ", ism_fd.FD_NAME)
    print("ism_fd.__doc__ : ", ism_fd.__doc__)
    print("ism_fd.__module__ : ", ism_fd.__module__)
    print("ism_fd.__class__ : ", ism_fd.__class__)


# Generated at 2022-06-26 11:42:16.359143
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD()


# Generated at 2022-06-26 11:43:04.725990
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        ism_f_d_1 = IsmFD()
        assert 1 == 1, 'Constructor test for class ism_f_d_1 passed'
    except AssertionError as err:
        print('Constructor test for class ism_f_d_1 failed: '+ err.args[0])


# Generated at 2022-06-26 11:43:13.883725
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test case 0
    fragment = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'avc1',
        'duration': 10000,
        'timescale': 10000000,
        'language': 'en',
        'width': 1280,
        'height': 720,
        'nal_unit_length_field': 4,
        'codec_private_data': '0164001fffe100186764001facd9402028162420bcf5b04d7cab123a223ac69a8dc0c',
    }
    write_piff_header(fragment, params)

    with open('test/file_fragment/testcase0.ism', 'rb') as file:
        file_fragment = file.read()

# Generated at 2022-06-26 11:43:17.696863
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d = IsmFD()
    # real_download is not a class method
    assert_raises(TypeError, ism_f_d.real_download, ism_f_d, '', '')


# Generated at 2022-06-26 11:43:22.862684
# Unit test for function write_piff_header
def test_write_piff_header():
    # Create a memory stream for testing
    with io.BytesIO() as mem_stream:
        # Create a FragmentFD object for testing
        write_piff_header(mem_stream, params)
        mem_stream.seek(0)
        if mem_stream.read(4) == b'ftyp':
            print("Unit test for function write_piff_header passed")
        else:
            print("Unit test for function write_piff_header failed")

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:43:29.677027
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(
            f,
            {
                'track_id': 1,
                'fourcc': 'H264',
                'duration': 2000000,
                'timescale': 10000000,
                'codec_private_data': '01640033acffc8',
                'height': 1080,
                'width': 1920,
            }
        )
        print(f.getvalue())


# Generated at 2022-06-26 11:43:36.527287
# Unit test for function write_piff_header
def test_write_piff_header():
    with open('test_write_piff_header.ismv', 'wb') as test_file:
        write_piff_header(test_file, {
            'track_id': 1,
            'duration': 1000000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 44100,
            'fourcc': 'AACL',
        })


# Generated at 2022-06-26 11:43:39.001475
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Method real_download in class IsmFD is called')

if __name__ == "__main__":
    # Unit test
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:43:45.227237
# Unit test for function write_piff_header
def test_write_piff_header():
    io_stream = io.BytesIO()
    params = {
        'track_id':1,
        'fourcc':'H264',
        'duration':60000000,
        'width':640,
        'height':360,
        'codec_private_data':'0164001FFFFC0101274280F185C0101114D01010127A1880F19E9B010101',
    }
    write_piff_header(io_stream, params)
    print(io_stream.getvalue())



# Generated at 2022-06-26 11:43:51.796097
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test.ismv', 'wb') as outf:
        params = {}
        params['track_id'] = 1
        params['fourcc'] = 'avc1'
        params['duration'] = 10000000
        params['timescale'] = 10000000
        params['language'] = 'und'
        params['width'] = 1280
        params['height'] = 720

# Generated at 2022-06-26 11:43:54.882903
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('Testing IsmFD constructor...')
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# vi:set ai et ts=4 sw=4 sts=4 fenc=utf-8:

# Generated at 2022-06-26 11:44:43.696874
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_1 = IsmFD()
    if not ((ism_f_d_1.params.get('fragment_base_url') == None) and
        (ism_f_d_1.params.get('fragment_retries') == 10) and
        (ism_f_d_1.params.get('skip_unavailable_fragments') == False)):
        raise AssertionError("Failed to instantiate IsmFD")
    ism_f_d_2 = IsmFD({
            'fragment_base_url': "http://base.com/",
            'fragment_retries': 2,
            'skip_unavailable_fragments': True,
        })

# Generated at 2022-06-26 11:44:45.382645
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()
    ism_f_d_1.real_download()


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 11:44:46.575443
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d = IsmFD()
    return ism_f_d


# Generated at 2022-06-26 11:44:54.939224
# Unit test for function write_piff_header
def test_write_piff_header():
    class TestStream(io.BytesIO):
        def __init__(self):
            io.BytesIO.__init__(self)
            self.len_before = 0
        def write(self, data):
            self.len_before += len(data)
            io.BytesIO.write(self, data)
        def get_len(self):
            return self.len_before

    # Test data
    test_param = dict()
    test_param['track_id'] = 0x210
    test_param['fourcc'] = 'H264'
    test_param['duration'] = 50000000
    test_param['timescale'] = 10000000
    test_param['language'] = 'eng'
    test_param['height'] = 0
    test_param['width'] = 0
    test_param['channels'] = 2

# Generated at 2022-06-26 11:45:01.641312
# Unit test for function write_piff_header
def test_write_piff_header():
    ism_f_d_0 = IsmFD()
    with io.BytesIO() as f:
        write_piff_header(
            f,
            params={
                'track_id': 1,
                'fourcc': 'H264',
                'duration': 10000000,
                'timescale': 10000000,
                'channels': 2,
                'bits_per_sample': 16,
                'sampling_rate': 44100,
                'language': 'und',
                'height': 0,
                'width': 0,
                'codec_private_data': ''
            }
        )
        ism_f_d_0.header = f.getvalue()
    return ism_f_d_0


# Generated at 2022-06-26 11:45:02.913806
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_1 = IsmFD()
    assert ism_f_d_1.FD_NAME == 'ism'



# Generated at 2022-06-26 11:45:03.805295
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD()


# Generated at 2022-06-26 11:45:12.412409
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # Test with invalid manifest url
    manifest_url = ''
    manifest = {}
    params = {}

    ism_f_d_1 = IsmFD()
    assert not ism_f_d_1.real_download(manifest_url, manifest, params), 'test_IsmFD_real_download assert#1 has failed.'

    # Test with invalid manifest file
    manifest_url = 'http://www.test.com/manifest.ism'
    manifest = {}
    params = {}

    ism_f_d_2 = IsmFD()
    assert not ism_f_d_2.real_download(manifest_url, manifest, params), 'test_IsmFD_real_download assert#2 has failed.'

    # Test with invalid filename

# Generated at 2022-06-26 11:45:20.595254
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_f_d_1 = IsmFD()

# Generated at 2022-06-26 11:45:27.688985
# Unit test for function write_piff_header
def test_write_piff_header():
    # test case 0
    with io.open('test_header_0.ismv', 'wb') as ts:
        write_piff_header(ts, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 5000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '0000000167640032ACD94000F7FC5A5A8010FFFFC00000168EBA3002A04EDA360400060400D95FC000'
        })
