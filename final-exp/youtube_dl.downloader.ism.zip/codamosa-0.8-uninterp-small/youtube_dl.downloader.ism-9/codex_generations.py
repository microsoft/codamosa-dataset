

# Generated at 2022-06-26 11:36:55.310644
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD()

if __name__ == '__main__':
    test_case_0()
    test_IsmFD()

# Generated at 2022-06-26 11:36:56.916649
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    testcase_0_IsmFD_real_download()



# Generated at 2022-06-26 11:37:07.963414
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Using a non-existing url
    url = 'http://www.youtube.com/watch?v=9bZkp7q19f0&' + \
          'playnext=1&playnext_from=TL&index=21'

    # Test case 0
    ismfd = IsmFD(url, {}, {})
    assert ismfd != None
    assert ismfd.FD_NAME == 'ism'
    assert ismfd.url == url
    assert ismfd.params == {}

    # Test case 1
    ismfd = IsmFD(url, {'format': '720x480'}, {})
    assert ismfd != None

    # Test case 2
    ismfd = IsmFD(url, {'format': '720x480', 'noplaylist': True}, {})
   

# Generated at 2022-06-26 11:37:17.934980
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing real_download')
    data = [
        (u'http://www.youtube.com/watch?v=foobar',
         {'_type': 'url', 'url': 'http://www.youtube.com/watch?v=foobar'}),
        (u'http://www.youtube.com/watch?v=foobar',
         {'_type': 'url', 'url': 'http://www.youtube.com/watch?v=foobar'}),
    ]

    for d in data:
        pass
        # TODO: Implement test
        # self._downloader.params['format'] = d[0]
        # ydl = YoutubeDL(self._downloader.params)
        # fd = IsmFD(ydl, d[1])
        # fd.real_download('foo.tmp

# Generated at 2022-06-26 11:37:30.345130
# Unit test for function write_piff_header
def test_write_piff_header():
    # For this test case we provide a stream to write the mp4 header data to
    # and the parameter dictionary to pass the function
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 18000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'bits_per_sample': 16,
        'channels': 2,
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-26 11:37:31.936725
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Class IsmFD has no method real_download
    pass


# Generated at 2022-06-26 11:37:42.487914
# Unit test for function write_piff_header
def test_write_piff_header():
    sample_rate = 44100
    duration = 676
    width = 320
    height = 240
    channels = 2
    bits_per_sample = 16
    fourcc = 'AACL'
    track_id = 1


# Generated at 2022-06-26 11:37:54.912499
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ytdl.utils import FileDownloader
    from ytdl.extractor import YoutubeIE
    from ytdl.postprocessor import AudioConvertor
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'


# Generated at 2022-06-26 11:38:04.522370
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:38:16.721508
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    file_0 = IsmFD(None, None, None, None)
    test_value_0 = 'w3qp'
    test_value_1 = 'n'
    test_value_2 = 'v[^#&`i'
    test_value_3 = '=8!b'
    test_value_4 = 'kf'
    test_value_5 = '0bz&'
    test_value_6 = '<r'
    test_value_7 = '^'
    test_value_8 = 'h'
    test_value_9 = 'd#S'
    test_value_10 = 'tb5R'
    test_value_11 = 'u<'
    test_value_12 = '*{'
    test_value_13 = 'a'
    test_

# Generated at 2022-06-26 11:38:31.813175
# Unit test for function extract_box_data
def test_extract_box_data():
    # Test boundary condition: no box
    ret = extract_box_data("", ["box1", "box2"])
    assert ret is None
    # Test boundary condition: no match
    data = u32.pack(0) + b"box1"
    ret = extract_box_data(data, ["box2", "box3"])
    assert ret is None


# Generated at 2022-06-26 11:38:37.727881
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create instance
    test_instance = IsmFD()

    # Test method with valid args
    arg_0_value = None
    arg_1_value = None
    valid_return_value = None

    assert test_instance.real_download(arg_0_value, arg_1_value) == valid_return_value, "Method did not return expected value"


# Generated at 2022-06-26 11:38:39.677378
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD()


# Generated at 2022-06-26 11:38:48.136767
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:39:00.849356
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        float_0 = 2235.9
        var_0 = box(float_0, float_0)
        write_piff_header(stream, var_0)
        stream.seek(0)
        var_1 = stream.read()
        # var_1 should be correct

# Generated at 2022-06-26 11:39:02.523041
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

# Generated at 2022-06-26 11:39:05.404412
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info_dict = {}
    filename = "test_file.ism"
    fd = IsmFD(info_dict, filename)
    fd.real_download(filename, info_dict)


# Generated at 2022-06-26 11:39:07.481559
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD([], {})
    except:
        pass

# Generated at 2022-06-26 11:39:13.817656
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    with open(os.path.join(TEST_DATA_DIR, 'ism.txt'), 'rb') as f:
        # Test the case in which the format of the manifest is not recognized
        with patch('youtube_dl.downloader.fragment.FragmentFD._download_fragment', return_value=(True, None)):
            with patch('youtube_dl.utils.write_bin_chunked', return_value=True):
                result = IsmFD().real_download(f, globals()['info_dict'])
                assert not result


# Generated at 2022-06-26 11:39:19.799767
# Unit test for function write_piff_header
def test_write_piff_header():
    byte_stream = io.BytesIO()

    # test case 0 (throws an exception)
    try:
        write_piff_header()
        assert(False)
    except TypeError:
        pass

    # test case 1
    params = {'duration': 10.0, 'track_id': 10}
    write_piff_header(byte_stream, params)

# Generated at 2022-06-26 11:39:52.187177
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {})

# Generated at 2022-06-26 11:39:54.151910
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:40:00.660076
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': '',
        'duration': 0,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'is_audio': 0,
        'creation_time': 0,
        'modification_time': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 22050,
    }
    write_piff_header(stream, params)

test_write_piff_header()

# Generated at 2022-06-26 11:40:02.887954
# Unit test for function write_piff_header
def test_write_piff_header():
    # Internal test case 0
    test_case_0()


# Generated at 2022-06-26 11:40:13.793959
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    float_2 = float_1 = float_0 = float(var_0)


test_cases = [
    test_case_0,
    test_IsmFD_real_download,
]

if __name__ == '__main__':
    import sys
    import json
    import argparse
    from io import IOBase

    class ArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            sys.stderr.write('error: %s\n' % message)
            self.print_help()
            sys.exit(2)

    parser = ArgumentParser(description='Test suite for IsmFD.py')
    parser.add_argument('-v', action='count', help='Be verbose')

# Generated at 2022-06-26 11:40:15.450490
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:40:16.217211
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-26 11:40:27.945101
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x2a\x74\x72\x65\x78\x00\x00\x00\x00\x00\x00\x00\x24\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00'
    assert extract_box_data(test_data, (b'trex',)) == b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-26 11:40:37.877184
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_fd = IsmFD({})

# Generated at 2022-06-26 11:40:47.413363
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x01\x00\x00\00' + b'\x00\x00\x00\x01' + b'\x00\x00\x00\00' + b'\x00\x00\x00\x02' + b'\x00\x00\x00\00' + b'\x00\x00\x00\x03' + b'\x00\x00\x00\00' + b'\x00\x00\x00\x04'

# Generated at 2022-06-26 11:41:16.460594
# Unit test for function write_piff_header
def test_write_piff_header():
    stream_0 = io.BytesIO()
    write_piff_header(stream_0, {})
    pass


# Generated at 2022-06-26 11:41:19.818611
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as c:
        c.write(u"testing")
        c.seek(0)
        write_piff_header(c, {"track_id": 1, "fourcc": "EC_3", "duration": 300, "language": "und", "height": 1080})


# Generated at 2022-06-26 11:41:21.921416
# Unit test for constructor of class IsmFD
def test_IsmFD():
    func_test_IsmFD = IsmFD()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:41:27.535749
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:41:28.898384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD()
    ism_fd.to_screen('')


# Generated at 2022-06-26 11:41:36.747986
# Unit test for function write_piff_header
def test_write_piff_header():
    out_file = io.BytesIO()
    write_piff_header(out_file, {
        'fourcc': 'H264',
        'track_id': 1,
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100166764001facd9408001fffff96001468ee3c80',
    })
    print(out_file.getvalue())



# Generated at 2022-06-26 11:41:44.339865
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:41:53.823900
# Unit test for function write_piff_header
def test_write_piff_header():
    # Testing if error raised for unsupported input types
    try:
        s = io.BytesIO()
        write_piff_header(s, 100)
    except ValueError:
        pass
    except:
        print('Expected ValueError to be raised')
    else:
        print('Expected ValueError to be raised')

    # Testing if error raised for unsupported input types
    try:
        s = io.BytesIO()
        write_piff_header(s, 100)
    except ValueError:
        pass
    except:
        print('Expected ValueError to be raised')
    else:
        print('Expected ValueError to be raised')

    # Testing if error raised for unsupported input types

# Generated at 2022-06-26 11:42:02.417263
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('test_output.ismv', 'wb') as output:
        params = {
            'track_id': 1,
            'fourcc': 'AVC1',
            'height': 1440,
            'width': 2560,
            'duration': 2411712,
            'codec_private_data': '0164001fffe100176764001facd940880000010601e001e94635e942a10000000300200000000000000000000000000000000000000000000'
        }
        write_piff_header(output, params)
        # print(output.read())
    print('test')

if __name__ == '__main__':
    # test_write_piff_header()
    # print(box(0.0, 0.0))
    test_case_0()

# Generated at 2022-06-26 11:42:08.678461
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 7,
        'fourcc': 'AACL',
        'duration': 1617,
        'timescale': 2165,
        'language': 'und',
        'sampling_rate': 7,
        'channels': 7,
        'bits_per_sample': 7,
    }
    write_piff_header(io.BytesIO(), params)



# Generated at 2022-06-26 11:42:42.864738
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()


# Generated at 2022-06-26 11:42:48.178970
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("Testing method real_download of class IsmFD")
    seg = {
        'url': '/video_8_v4_track2.ism/QualityLevels(2592400)/Fragments(video=6340000)'
    }
    info_dict = {
        'fragments': [
            seg,
        ]
    }
    info_dict['_download_params'] = {
        'fourcc': 'AACL',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'duration': 6.0,
        'timescale': 10000000,
        'track_id': 0x1
    }

    fd = IsmFD()
    fd.real_download("test.ismv", info_dict)


# Generated at 2022-06-26 11:42:57.206698
# Unit test for function write_piff_header
def test_write_piff_header():
    test_video_params = {
        'track_id': 1,
        'fourcc': 'H264',
        'height': 1080,
        'width': 1920,
        'duration': 18000000,
        'codec_private_data': '01640028ffe10017674d401f9a03c038b0e2a77e60c0',
        'nal_unit_length_field': 4,
    }

    test_audio_params = {
        'track_id': 2,
        'fourcc': 'AACL',
        'channels': 2,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'duration': 18000000,
    }


# Generated at 2022-06-26 11:42:58.067317
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-26 11:43:03.504424
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # obj_0 = IsmFD(test_case_0())
    # assert obj_0.real_download() == 'test'

    # obj_0 = IsmFD(test_case_0())
    # assert obj_0.real_download(test_case_0()) == 'test'

    # obj_0 = IsmFD(test_case_0())
    # assert obj_0.real_download(test_case_0(), test_case_0()) == 'test'

    pass


# Generated at 2022-06-26 11:43:07.242809
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    you_get.common.logger.init()
    you_get.common.verbose = 4
    you_get.common.any_download = lambda *x: test_case_0()

    params = {'track_id':1, 'fourcc':'AACL'}
    fd = IsmFD(lambda *args: (True, None), None, '', '', params)
    fd.real_download('', 'filename')



# Generated at 2022-06-26 11:43:08.160069
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

test_IsmFD()

# Generated at 2022-06-26 11:43:10.622786
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:43:20.117406
# Unit test for function write_piff_header
def test_write_piff_header():
    # TODO: if it's a unit test, it should not use files, but use a io.BytesIO instead
    fourcc = 'H264'


# Generated at 2022-06-26 11:43:26.533495
# Unit test for function write_piff_header
def test_write_piff_header():
    d0 = {'ks': 'py', 'codec_private_data': '01640039', 'track_id': 1,
          'fourcc': 'h264', 'sampling_rate': 44100, 'duration': 282299,
          'language': 'eng', 'nal_unit_length_field': 4, 'height': 576,
          'width': 720, 'channels': 2, 'bits_per_sample': 16}

# Generated at 2022-06-26 11:44:06.242782
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create a new instance of class IsmFD
    var_1 = IsmFD()

    # Assert that there is an attribute filename with value "ism.ism" for instance var_1
    assert(hasattr(var_1, 'filename') and var_1.filename == "ism.ism")

    # Assert that there is an attribute FD_NAME with value "ism" for instance var_1
    assert(hasattr(var_1, 'FD_NAME') and var_1.FD_NAME == "ism")

    # Assert that there is an attribute params with value None for instance var_1
    assert(hasattr(var_1, 'params') and var_1.params == None)

    # Assert that there is an attribute _progress_hooks with value [] for instance var_1

# Generated at 2022-06-26 11:44:07.730160
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:44:17.069597
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 0x1,
        'fourcc': 'H264',
        'duration': 0,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'track_id': 0x1,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
        'codec_private_data': '01640029ffe100111001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001',
    }

# Generated at 2022-06-26 11:44:24.781646
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 9,
        'fourcc': 'AVC1',
        'duration': 10000,
        'timescale': 10000000,
        'language': 'und',
        'height': 10,
        'width': 20,
        'codec_private_data': '0164001ff678bf000000300e0000001e6764001f4d0014aa000a80201f480032ac32e56',
        'nal_unit_length_field': 4,
    }
    mystring = io.StringIO()
    write_piff_header(mystring, params)
    len(mystring.getvalue())

# Generated at 2022-06-26 11:44:25.640656
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert_equal(fd.FD_NAME, 'ism')


# Generated at 2022-06-26 11:44:29.372681
# Unit test for function write_piff_header
def test_write_piff_header():
    # Input arguments
    try:
        test_case_0()
    except compat_urllib_error.URLError:
        IOError
    except (OSError, IOError, Exception) as exception:
        #unreachable
        raise


# Generated at 2022-06-26 11:44:34.799738
# Unit test for function write_piff_header
def test_write_piff_header():
    # Assign a value to variables
    params = {
        'track_id': 0,
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'duration': 0,
        'timescale': 48000,
        'language': 'eng'
    }

    print(write_piff_header(params))
    assert(True)

# Generated at 2022-06-26 11:44:38.809313
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 4294967295,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    write_piff_header(stream, params)
    print('write_piff_header result=', stream.getvalue())


# Generated at 2022-06-26 11:44:41.592654
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # test_case_0
    real_download(float_0, float_0)

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:44:43.120464
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismfd = IsmFD()

test_IsmFD()

# Generated at 2022-06-26 11:45:56.443830
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .ism import IsmFD

    pass


# Generated at 2022-06-26 11:45:57.815245
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    float_0 = 2235.9
    var_0 = box(float_0, float_0)
    print('')


# Generated at 2022-06-26 11:45:59.375580
# Unit test for function write_piff_header
def test_write_piff_header():
    test_stream = io.BytesIO()
    test_params = {}
    write_piff_header(test_stream, test_params)


# Generated at 2022-06-26 11:46:06.335664
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:46:14.101419
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    params = {
        'fragments': [
            {'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Fragments(video=0)'},
            {'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Fragments(video=1)'},
        ]
    }

# Generated at 2022-06-26 11:46:21.359353
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from os.path import isfile
    from . import InfoExtractor
    from .common import InfoDict

    class FakeInfoExtractor(InfoExtractor):
        _WORKING = True

        IE_NAME = 'test'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [],
            }
    ie = FakeInfoExtractor()
    info_dict = InfoDict()
    info_dict['url'] = 'http://example.com'
    info_dict['id'] = 'test'
    info_dict['title'] = 'test'
    info_dict['formats'] = []
    info_dict['duration'] = 0.25
    info_dict['extractor'] = ie


# Generated at 2022-06-26 11:46:29.706047
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:46:31.461183
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:46:33.412824
# Unit test for method real_download of class IsmFD