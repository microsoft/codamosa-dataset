

# Generated at 2022-06-26 11:36:57.706191
# Unit test for function extract_box_data
def test_extract_box_data():

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('Exception in test #0: ' + str(e))
    else:
        if var_0:
            print('Test #0: Pass')
        else:
            print('Test #0: Fail')


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 11:37:06.377021
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    dict_0 = {}
    dict_1 = {}
    dict_0 = collections.OrderedDict()
    dict_1 = collections.OrderedDict()
    dict_2 = collections.OrderedDict()
    segments = [dict_2]
    dict_1['fragments'] = segments
    dict_1['tbr'] = 50.0
    fd = IsmFD()
    fd.real_download(dict_1, dict_0)
    test_case_0()
    return True


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:37:14.992699
# Unit test for function write_piff_header
def test_write_piff_header():
    tracks = []
    tracks.append({
        'track_id': 0,
        'fourcc': 'H264',
        'duration': 10000,
        'height': 720,
        'width': 1280,
    })
    tracks.append({
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
    })
    stream = io.BytesIO()
    for params in tracks:
        write_piff_header(stream, params)


# Generated at 2022-06-26 11:37:17.587287
# Unit test for function write_piff_header
def test_write_piff_header():
    filename = ''
    mode = 'rb'
    fd = open(filename, mode)
    params = {}
    write_piff_header(fd, params)
    fd.close()


# Generated at 2022-06-26 11:37:20.754273
# Unit test for function extract_box_data
def test_extract_box_data():
    #assert_equals(test_case_0, test_case_0)
    test_case_0()


# Generated at 2022-06-26 11:37:31.890104
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('output_2.mp4', 'wb+') as fp:
        params = {
            'track_id': 0,
            'fourcc': 'H264',
            'duration': 3000,
            #'timescale': 90000,
            #'language': 'eng',
            'height': 720,
            'width': 1280,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
            'codec_private_data': '0164001fffe100166764001facd9b9588001400140742f00fb8fc003d60323cc0008080000c8a0000'
        }
        write_piff_header(fp, params)
        fp.seek(0)
        print(fp.read())

# Generated at 2022-06-26 11:37:33.370794
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_fd_obj_0 = IsmFD()


# Generated at 2022-06-26 11:37:41.107571
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test = IsmFD('', {})
    # TODO: uncomment these values once the test is actually run
    #assert test.real_download('', '') == True
    #assert test.real_download('', {}) == False
    #assert test.real_download('', '') == False
    #assert test.real_download('', '') == False
    #assert test.real_download('', '') == False
    #assert test.real_download('', '') == False
    #assert test.real_download('', '') == False


# Generated at 2022-06-26 11:37:47.716263
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Try case 0, no info
    dict_0 = {}
    bytes_0 = b'\x87'
    var_0 = extract_box_data(dict_0, bytes_0)
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_8 = {}
    dict_10 = {}
    dict_11 = {}
    dict_10['fragments'][0:1] = [dict_11]
    dict_9 = {}
    dict_10['fragments'] = dict_9
    dict_9 = {}
    dict_7 = {}
    dict_7['total_frags'] = len(dict_9)
    dict_6['filename'] = dict_7
    dict

# Generated at 2022-06-26 11:37:49.152541
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert False  # TODO: implement your test here



# Generated at 2022-06-26 11:38:00.906701
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-26 11:38:06.061326
# Unit test for constructor of class IsmFD
def test_IsmFD():
    int_0 = 2550
    dict_0 = {int_0: int_0}
    list_0 = [dict_0]
    dict_1 = {int_0: list_0}
    str_0 = ""
    dict_2 = {int_0: str_0, int_0: str_0, int_0: str_0}
    ismfd_0 = IsmFD(dict_1, dict_2)


# Generated at 2022-06-26 11:38:08.553016
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismFD = IsmFD({})
    test_case_0()


# Generated at 2022-06-26 11:38:20.275131
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-26 11:38:26.752521
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Testing IsmFD constructor
    """
    ydl = FakeYDL()
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = True
    test_case_0()  # Just to prevent unused variable warnings
    test_IsmFD = IsmFD(ydl=ydl)
    return test_IsmFD



# Generated at 2022-06-26 11:38:35.542784
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data_1 = extract_box_data(b'\x00\x00\x00\x00'
                                   b'ftyp\x00\x00\x00\x00'
                                   b'\x00\x00\x00\x00'
                                   b'moov\x00\x00\x00\x00'
                                   b'\x00\x00\x00\x00',
                                   (b'moov',))
    assert test_data_1 == b'\x00\x00\x00\x00'

# Generated at 2022-06-26 11:38:46.359030
# Unit test for function write_piff_header
def test_write_piff_header():
    # Assume we're using Python 2
    p = io.BytesIO()
    write_piff_header(p, {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'duration': 1,
    })
    test_case_0()
    p.seek(0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 11:38:54.834211
# Unit test for function write_piff_header
def test_write_piff_header():
    #Test case 0.
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'video/mp4', 'duration': 1000000000, 'timescale': 10000000, 'language': 'eng', 'height': 0, 'width': 0}
    write_piff_header(stream, params)

if __name__ == '__main__':
    test_write_piff_header()
    test_case_0()

# Generated at 2022-06-26 11:39:06.123471
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = "filename"
    info_dict = {"fragments": [{"url": "http://bla"}]}
    params = {"fragment_retries": 2,
              "skip_unavailable_fragments": True,
              "_download_params": {"track_id": 2,
                                   "duration": 2,
                                   "timescale": 2,
                                   "language": "und",
                                   "fourcc": "AACL",
                                   "sampling_rate": 2,
                                   "height": 2,
                                   "width": 2}
              }
    ctx = {
        'filename': filename,
        'total_frags': 1,
    }
    obj_IsmFD = IsmFD(params)
    #obj_ffmpeg_fd = FFmpegFD()
    obj_IsmFD

# Generated at 2022-06-26 11:39:14.888927
# Unit test for function extract_box_data
def test_extract_box_data():
    data_0 =  b'\x00\x00\x00\x10\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03'
    expected_data_1 = b'\x00\x00\x00\x08\x00\x00\x00\x01\x00\x00\x00\x02'
    expected_data_2 = b'\x00\x00\x00\x05\x00\x00\x00\x02\x00\x00\x00\x03'
    box_sequence_1 = [b'\x00\x00\x00\x01', b'\x00\x00\x00\x02']