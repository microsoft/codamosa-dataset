

# Generated at 2022-06-26 11:37:03.086344
# Unit test for function write_piff_header
def test_write_piff_header():
    # Open file descriptor for write
    w_fd = io.open('/tmp/test_case_1.mp4', 'wb')
    # Write piff header
    write_piff_header(w_fd, {})
    # Close file descriptor
    w_fd.close()


# Generated at 2022-06-26 11:37:05.555829
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:37:07.777759
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_f_d_0 = IsmFD(u'f4v', u'f4v')


# Generated at 2022-06-26 11:37:17.894820
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:37:30.298362
# Unit test for function write_piff_header
def test_write_piff_header():
    str_0 = '5s@w%S,S2WhPE`A8S'

# Generated at 2022-06-26 11:37:41.111009
# Unit test for function write_piff_header
def test_write_piff_header():
    import pytest
    from datetime import date
    from os import path
    day_0 = date(2000, 1, 1)
    day_1 = date(2001, 2, 3)
    file_0 = path.join(path.dirname(__file__), 'write_piff_header-0.ismv')
    file_1 = path.join(path.dirname(__file__), 'write_piff_header-1.ismv')
    with io.open(file_0, 'wb') as stream_0:
        write_piff_header(stream_0, {
            'track_id': 1,
            'sampling_rate': 44100,
            'channels': 2,
            'duration': (day_1 - day_0).total_seconds() * 10000000,
        })

# Generated at 2022-06-26 11:37:47.696108
# Unit test for function extract_box_data
def test_extract_box_data():
    str_0 = '5s@w%S,S2WhPE`A8S'
    ism_f_d_0 = IsmFD(str_0, str_0)
    data = ism_f_d_0._retrieve_info_video(ism_f_d_0.url_base)
    print(data)

    s_r = io.BytesIO(data)
    box_data = extract_box_data(data, [b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stsd', b'avc1', b'avcC'])

    avcc_reader = io.BytesIO(box_data)
    avcc_version = u8.unpack(avcc_reader.read(1))[0]

# Generated at 2022-06-26 11:37:58.805223
# Unit test for function write_piff_header
def test_write_piff_header():
    # Open file for test
    f_test = open('test', 'w')
    # Test case 0
    str_0 = '5s@w%S,S2WhPE`A8S'
    ism_f_d_0 = IsmFD(str_0, str_0)

# Generated at 2022-06-26 11:38:07.355121
# Unit test for function write_piff_header
def test_write_piff_header():
    output_file = 'write_piff_header.mp4'
    with open(output_file, 'wb') as f:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'width': 640,
            'height': 480,
            'duration': 10000000,  # 1 sec
            'sampling_rate': 44100,
            'channels': 1,
            'bits_per_sample': 16,
            'codec_private_data': '000000016764001f9a9a9a0003002af8a000001914944415428400000000002a000003000002a00000001000000000000000000000000010000000000000000000000000000000000000000',
        }
        write_piff_header(f, params)

# Test for function IsmFD with FragmentFD

# Generated at 2022-06-26 11:38:19.275222
# Unit test for function write_piff_header
def test_write_piff_header():
    # assert Raises
    with pytest.raises(Exception) as excinfo:
        write_piff_header(None,
                          {'track_id': 1, 'fourcc': '', 'duration': 1, 'timescale': 1, 'language': '',
                           'height': 0, 'width': 0})
    error = str(excinfo.value)
    assert error == 'Codec type is not supported!'

    # assert Success
    buf = io.BytesIO()
    write_piff_header(buf,
                      {'track_id': 1, 'fourcc': '', 'duration': 1, 'timescale': 1, 'language': '',
                       'height': 0, 'width': 0})

# Generated at 2022-06-26 11:38:36.033204
# Unit test for function write_piff_header
def test_write_piff_header():
    str_0 = ""
    test_0 = io.BytesIO(str_0)
    write_piff_header(test_0, {'track_id': 14, 'fourcc': 'H264', 'duration': 0, 'codec_private_data': '0164001fffe100176764001facd9402028d8401d4bd0801c58e01400000300030068ea00e1f826c0'})

if __name__ == '__main__':
    test_write_piff_header()

# Generated at 2022-06-26 11:38:39.417244
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({})
    assert 'ism' == fd.FD_NAME
    return fd


# Generated at 2022-06-26 11:38:47.965616
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {}
    params['track_id'] = 0
    params['fourcc'] = 'avc1'
    params['duration'] = 0
    params['codec_private_data'] = '000000016742C0DCE388080808080080'
    params['nal_unit_length_field'] = 4
    params['height'] = 480
    params['width'] = 858
    params['sampling_rate'] = 48000
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['language'] = 'und'
    write_piff_header(stream, params)
    stream.seek(0)

# Generated at 2022-06-26 11:38:56.658987
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD(
        'https://manifest_url',
        {'test': False, 'fragment_retries': 10, 'skip_unavailable_fragments': True}
    )
    assert ism_fd.params['test'] is False
    assert ism_fd.params['fragment_retries'] == 10
    assert ism_fd.params['skip_unavailable_fragments'] is True



# Generated at 2022-06-26 11:39:02.162269
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    str_0 = '5s@w%S,S2WhPE`A8S'
    assert IsmFD.real_download(IsmFD, str_0) == True, 'Did not correctly apply real_download of class IsmFD'

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:39:05.398957
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info_dict = {}
    filename = 'empty'
    # Call the method
    test_IsmFD_instance = IsmFD()
    test_IsmFD_instance.real_download(filename, info_dict)



# Generated at 2022-06-26 11:39:14.715833
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:39:20.178276
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://dal-a.akamaihd.net/media/jerry/audio/jerry-kramer-summer-2014/jerry-summer-2014-14-island-adventures.ism/jerry-summer-2014-14-island-adventures.ism/manifest'
    ism_obj = IsmFD()

# Generated at 2022-06-26 11:39:31.772379
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    with open('ism_test_cases.json') as f:
        data = json.loads(f.read())
        test_case_0_data = data[0]
        test_case_1_data = data[1]
        test_case_2_data = data[2]
        test_case_3_data = data[3]
        test_case_4_data = data[4]

        params_0_data = test_case_0_data['params']
        filename_0_data = test_case_0_data['filename']
        info_dict_0_data = test_case_0_data['info_dict']
        self_0_data = test_case_0_data['self']
        

# Generated at 2022-06-26 11:39:32.939105
# Unit test for constructor of class IsmFD
def test_IsmFD():
    obj = IsmFD()

    test_case_0()

# Generated at 2022-06-26 11:39:43.881035
# Unit test for function write_piff_header
def test_write_piff_header():
    pass


# Generated at 2022-06-26 11:39:45.649879
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    wtih_0 = IsmFD()
    wtih_0.real_download()


# Generated at 2022-06-26 11:39:56.548507
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
  filename = 'test.out'
  info_dict = {'fragments':
               [{'url': 'http://test_url'}],
               '_download_params':
               {'fourcc': 'mp4a',
                'codec_private_data':
                '060800000302000003060000ac44001210',
                'track_id': '5s@w%S,S2WhPE`A8S'}}
  ytdl = YtdlFD(YoutubeDL({'test': True}))
  ism = IsmFD(ytdl)
  assert ism._download_fragment(ism, info_dict['fragments'][0]['url'], info_dict) == ('fake data', '')
  assert ism._finish_frag_download(ism) == None

# Generated at 2022-06-26 11:39:57.734217
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

# Generated at 2022-06-26 11:40:07.392682
# Unit test for function extract_box_data
def test_extract_box_data():
    assert(extract_box_data(b'\x00'*8, (b'abcd',)) == b'\x00'*4)
    assert(extract_box_data(b'\x00'*60, (b'abcd',)) == b'\x00'*4)
    assert(extract_box_data(b'abcd' + b'\x00'*4, (b'abcd',)) == b'\x00'*4)
    assert(extract_box_data(b'abcd' + b'\x00'*52, (b'abcd',)) == b'\x00'*4)


# Generated at 2022-06-26 11:40:16.953927
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    tstr = '6s@U8%S,S2WhPE`A8S'
    #pdb.set_trace()
    # print(type(tstr),len(tstr))
    # print(tstr - 0x00)
    # print(tstr - 0x0C)
    # print(tstr - 0x0D)
    # print(tstr - 0x0B)
    # print(tstr - 0x0E)
    
    tstr2 = '6s@U8%S,S2WhPE`A8S'
    #pdb.set_trace()
    # print(type(tstr2),len(tstr2))
    # print( tstr2 - 0x00)
    # print( tstr2 - 0x0C)
    # print( tstr2

# Generated at 2022-06-26 11:40:21.007366
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Testing whether output of method matches expected value
    with YouTubeDL(params={'cachedir': False}) as ydl:
        ydl.add_default_info_extractors()
        ydl.download(['http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest', ' --extract-audio --audio-format mp3 --audio-quality 0 -o "%(autonumber)s-%(title)s.%(ext)s"'])


# Generated at 2022-06-26 11:40:31.057209
# Unit test for function write_piff_header
def test_write_piff_header():
    test_piff_header = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 29491200,
        'timescale': 10000000,
        'height': 960,
        'width': 540,
        'language': 'und',
        'codec_private_data': '0164001fffe10098e1412c03620580284fb9280c00125f8c4e4d4f7261636c65206e756d62657220312e310000001c6764001cacd9000001c850000fffc80120f49e8ffed8048a519b0fffc40026c0'
    }
    write_piff_header(test_piff_header, params)
    assert test_

# Generated at 2022-06-26 11:40:32.516627
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD(params={'test': True})

test_case_0()

# Generated at 2022-06-26 11:40:41.216036
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 50000000,
        'sampling_rate': 48000,
        'codec_private_data': '000000016764003C9AC400000168EBA3000',
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)