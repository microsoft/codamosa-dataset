

# Generated at 2022-06-26 11:37:00.702487
# Unit test for function write_piff_header

# Generated at 2022-06-26 11:37:11.949214
# Unit test for function write_piff_header
def test_write_piff_header():
    # Create outputs
    int_0 = 924
    dict_0 = {int_0: int_0, int_0: int_0}
    stream_0 = io.BytesIO()
    try:
        stream_1 = write_piff_header(stream_0, dict_0)
    except (UnicodeEncodeError, compat_urllib_error.URLError) as var_1:
        stream_1 = False
        print(var_1)
    # Create expected values
    byte_0 = b'\x00\x00\x00\x00'
    byte_1 = b'ftyp'
    byte_2 = b'\x00\x00\x00\x16'
    byte_3 = b'isml'

# Generated at 2022-06-26 11:37:20.137496
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ctx = {
        'filename': "filename",
        'total_frags': 0,
    }
    FD_NAME = 'ism'
    segments = [{"url": "url"}]
    info_dict = {}
    info_dict['fragments'] = segments
    fragment_retries = 0
    skip_unavailable_fragments = True
    track_written = False
    frag_index = 0
    frag_index += 1
    if frag_index <= ctx['fragment_index']:
        frag_index += 1
    count = 0

# Generated at 2022-06-26 11:37:31.153978
# Unit test for function extract_box_data
def test_extract_box_data():
    data = bytes.fromhex("00000014moov000000a4mvhd0000010000000000000000000000000001000001000000000100000000000000000200000001000000010000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000018hdlr000000007465726D00000000000068736D626272000100000000000000000000007465726D00000000417272617900000400140014000000000000000000000000010000000100000001000000000000000000000100000000000000000000000000000000000000")
    box_sequence = b'moov'
    assert extract_box_data(data, [box_sequence]) == data
    box_sequence = b'moo'
    assert extract_box_data(data, [box_sequence]) is None

# Generated at 2022-06-26 11:37:41.917500
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = io.BytesIO()
    box_data.write(b'\x00\x00\x00\x10ftyp')
    box_data.write(b'\x00\x00\x00\x0Cmoov')
    box_data.write(b'\x00\x00\x00\x10mvhd')
    box_data.write(b'\x00\x00\x00\x0Ctrak')
    box_data.write(b'\x00\x00\x00\x0Ctkhd')
    box_data.write(b'\x00\x00\x00\x0Cmdia')
    box_data.write(b'\x00\x00\x00\x0Cminf')

# Generated at 2022-06-26 11:37:44.326577
# Unit test for function write_piff_header
def test_write_piff_header():
    int_0 = 924
    dict_0 = {int_0: int_0, int_0: int_0}
    write_piff_header(int_0, dict_0)

# Generated at 2022-06-26 11:37:46.512665
# Unit test for function write_piff_header
def test_write_piff_header():
    test_case_0()


# Generated at 2022-06-26 11:37:58.096463
# Unit test for constructor of class IsmFD
def test_IsmFD():
    sample_ism_url = 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/somerandomletters/s1/prog_index.m3u8'
    sample_ism_url_params = 'manifest_type=smooth'
    sample_ism_output = 'greatest_video.ismv'

    ydl = YoutubeDL(default_params)
    ydl.add_default_info_extractors()
    fd = ydl.get_info_extractor(sample_ism_url)
    info_dict = fd._real_extract(sample_ism_url + '?' + sample_ism_url_params)
    fd.real_download(sample_ism_output, info_dict)


# Generated at 2022-06-26 11:38:01.974875
# Unit test for function write_piff_header
def test_write_piff_header():
    int_0 = 924
    dict_0 = {int_0: int_0, int_0: int_0}
    var_0 = write_piff_header(int_0, dict_0)

    print("\t" + str(var_0))


# Generated at 2022-06-26 11:38:13.673578
# Unit test for function extract_box_data

# Generated at 2022-06-26 11:38:29.761843
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    sys.argv = ['you-get', 'https://test.test']
    yg = YouGet()
    yg.prepare()
    info_dict = {'test': 0}
    obj = IsmFD()
    ret = obj.real_download('test', info_dict)

if __name__ == '__main__':
    test_case_0()
    test_IsmFD_real_download()

# Generated at 2022-06-26 11:38:32.200405
# Unit test for function write_piff_header
def test_write_piff_header():
    print('Testing write_piff_header')
    test_case_0()

if __name__ == '__main__':
    test_write_piff_header()

# Generated at 2022-06-26 11:38:35.678076
# Unit test for function write_piff_header
def test_write_piff_header():
    test_case_0()

if __name__ == '__main__':
    print('Testing for function write_piff_header')
    test_write_piff_header()
    print('Done')

# Generated at 2022-06-26 11:38:46.424353
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    int_0 = 924
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}
    frag_index = 0
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}
    dict_0 = {int_0: int_0, int_0: int_0}


# Generated at 2022-06-26 11:38:46.999390
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-26 11:38:51.098203
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class_0 = IsmFD
    var_0 = IsmFD.__new__(class_0)
    return var_0



# Generated at 2022-06-26 11:38:54.942296
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    track_id = 924
    dict_0 = {'track_id': track_id}
    for i in range(5):
        test_case_0()
    test_case_0()

# Generated at 2022-06-26 11:39:00.296196
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b"\x00\x00\x00\x00\x00\x00\x00\x00"
    box_sequence = (b"\x00\x00\x00\x00",)
    try:
        result = extract_box_data(data, box_sequence)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 11:39:09.721031
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'https://manifest_url.com/path'
    params = {
        'username': 'username',
        'password': 'password',
        'proxy': 'http://proxy.com/path'
    }
    ism_fd = IsmFD(url, params)
    assert ism_fd.url == url
    assert ism_fd.params.get('username') == params.get('username')
    assert ism_fd.params.get('password') == params.get('password')
    assert ism_fd.params.get('proxy') == params.get('proxy')
    assert ism_fd.params.get('usenetrc') == False


# Generated at 2022-06-26 11:39:14.170454
# Unit test for constructor of class IsmFD
def test_IsmFD():
    int_0 = 924
    dict_0 = {int_0: int_0, int_0: int_0}
    obj_0 = IsmFD(int_0, int_0, int_0)
    obj_0.FD_NAME = {int_0: int_0, int_0: int_0}
    obj_0.real_download(int_0, int_0)
