

# Generated at 2022-06-26 11:36:47.738073
# Unit test for function write_piff_header
def test_write_piff_header():
    print("Test: function write_piff_header")
    test_case_0()

# Module to test write_piff_header

# Generated at 2022-06-26 11:36:59.159592
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ctx = {
        'dest_stream': io.BytesIO(),
        'fragment_counter': 0,
        'tmpfilename': 'tmp_filename',
        'total_frags': 1,
    }
    test_IsmFD = IsmFD()

    str_0 = {'duration': 437, 'formats': [{'ext': 'mp4', 'protocol': 'm3u8', 'url': 'https://example.com/video1.mp4/master.m3u8'}], 'id': 'video1', 'is_live': False, 'protocol': 'm3u8', 'title': 'video1', 'url': 'https://example.com/video1.mp4/master.m3u8', 'width': 320}
    test_IsmFD.download(str_0)



# Generated at 2022-06-26 11:37:10.875907
# Unit test for constructor of class IsmFD
def test_IsmFD():
    case0_in = {
        '_type': 'URL',
        'id': 'https://media.example.com/media.ism/QualityLevels(96000)/Fragments(audio=0)',
        'display_id': 'https://media.example.com/media.ism/QualityLevels(96000)/Fragments(audio=0)',
        'url': 'https://media.example.com/media.ism/QualityLevels(96000)/Fragments(audio=0)',
    }

# Generated at 2022-06-26 11:37:11.858410
# Unit test for function write_piff_header
def test_write_piff_header():
    test_case_0()



# Generated at 2022-06-26 11:37:12.839024
# Unit test for constructor of class IsmFD
def test_IsmFD():
  test_case_0()

# Generated at 2022-06-26 11:37:24.264400
# Unit test for function extract_box_data
def test_extract_box_data():
    with io.BytesIO() as f:
        write_piff_header(f, {
            'track_id': 1,
            'language': 'und',
            'sampling_rate': 44100,
            'bits_per_sample': 16,
            'fourcc': 'AACL',
            'duration': 1000000000,
            'channels': 2,
        })

        f.seek(0, 0)
        box_data = extract_box_data(f.read(), (b'ftyp',))
        assert box_data == (b'isml' b'\x00\x00\x00\x01' b'piff' b'iso2')

if __name__ == "__main__":
    test_case_0()
    # Unit test for function extract_box_data
    test_ext

# Generated at 2022-06-26 11:37:35.804917
# Unit test for constructor of class IsmFD
def test_IsmFD():
    file_name = 'a'
    params = {
        'url': 'url',
        'downloader': 'downloader',
    }
    obj_0 = IsmFD(file_name, params)
    assert obj_0.__class__ == IsmFD
    assert obj_0.file_name == 'a'
    assert obj_0.params == {
        'url': 'url',
        'downloader': 'downloader',
    }
    assert obj_0.file_handle is None
    assert obj_0.filename == 'a'
    assert obj_0.temp_name is None
    assert obj_0.resume_len == 0
    assert obj_0.total_frags == 0
    assert obj_0.fragment_index == 0

# Generated at 2022-06-26 11:37:37.549669
# Unit test for function extract_box_data
def test_extract_box_data():
    # assert(extract_box_data(0, 0) == 0)
    pass


# Generated at 2022-06-26 11:37:39.953056
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('\n=================================================')
    print('Testing function real_download of class IsmFD')

    test_case_0()


# Generated at 2022-06-26 11:37:43.981205
# Unit test for function extract_box_data
def test_extract_box_data():
    str_0 = b'\x00\x00\x00\x00'
    
    bytearray_0 = bytearray(str_0, 'utf-8')
    var_0 = binascii.hexlify(bytearray_0)
    
    assert var_0 == '00000000'


# Generated at 2022-06-26 11:37:55.605256
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD('all', {}, {}, None)


# Generated at 2022-06-26 11:38:05.141014
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import dbm.gnu
    import tempfile
    import os
    from downloader import SafeFD

    # create temp file
    _, filename = tempfile.mkstemp()

    # init info_dict
    info_dict = {}

# Generated at 2022-06-26 11:38:17.574076
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    uuid = '1234567-4356-3453-3456-3453456'

# Generated at 2022-06-26 11:38:19.928969
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD('', {}, lambda a: a) != None


if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-26 11:38:31.033239
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b"\x00\x00\x00\x24moov\x00\x00\x00\x16\x6d\x6f\x6f\x76mdat\x00\x00\x00\x10\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01"
    data_reader = io.BytesIO(data)
    box_size = u32.unpack(data_reader.read(4))[0]

# Generated at 2022-06-26 11:38:37.587821
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'codec_private_data': '01640028ffe1001427640028ac2c80880001000468ee3c80',
            'nal_unit_length_field': 4,
            'duration': 1000,
            'sampling_rate': 1,
            'bits_per_sample': 16,
            'channels': 2,
            'width': 0,
            'height': 0,
        }
        write_piff_header(stream, params)


# Generated at 2022-06-26 11:38:47.453690
# Unit test for function extract_box_data
def test_extract_box_data():
    data_0 = b'a\x00\x00\x00'
    data_1 = extract_box_data(data_0, ('a',))

    data = b'b\x00\x00\x00c'
    data_1 = extract_box_data(data, ('c',))

    data_2 = b'de\x00\x00\x00'
    data_4 = b''
    data_5 = b'd\x00\x00\x00e\x00\x00\x00f'
    data_6 = b''
    data_7 = b'e\x00\x00\x00f'
    data_3 = extract_box_data(data_2 + data_4, ('de',))
    data_3 = b'd'
    data_8 = extract_

# Generated at 2022-06-26 11:38:52.208294
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.FD_NAME == 'ism', 'FD_NAME of IsmFD is incorrect'


if __name__ == '__main__':
    test_case_0()
    test_IsmFD()

# Generated at 2022-06-26 11:39:04.029520
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import YoutubeIE
    from .compat import compat_urllib_request
    from .utils import sanitize_open
    from .common import urlopen

    url = 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/clear/3487332662001/5d5cd8f5-5b55-41a5-9c7b-8f6daa737ea1/6/1507387527000/master.m3u8?fastly_token=NWNkMDU2N2MtNzAwZi00MTUwLTgwMmEtMzk5N2FhNGM2Y2Y2'
    ism_fd = IsmFD(url, {}, YoutubeIE())

    # test download method


# Generated at 2022-06-26 11:39:13.670367
# Unit test for function write_piff_header
def test_write_piff_header():
    bytes_0 = b'\x00\x00\x00\x1cftypismlpiffiso2'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xab\x85\x02\x00\x00\x00\x00\x00\x00\x00'
    bytes_2 = b'\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:39:40.547292
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 166667,
        'width': 1280,
        'height': 720,
        'codec_private_data': '01640028ffe1000f6742c0028e858026301000468ee3880'
    }
    write_piff_header(stream, params)
    var_0 = stream.getvalue()

# Generated at 2022-06-26 11:39:44.282014
# Unit test for function write_piff_header
def test_write_piff_header():
    test_stream = io.BytesIO()
    test_params = {
        'track_id': 0,
        'fourcc': 0,
        'duration': 0,
    }
    write_piff_header(test_stream, test_params)


# Generated at 2022-06-26 11:39:52.637709
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
        'track_id': 1,
        'fourcc': 'AACL',
        'codec_private_data': '1208',
        'duration': 8904500,
        'language': 'und',
        'title': '',
        'height': 0,
        'width': 0,
    }
    write_piff_header(stream, params)
    print(stream.getvalue())

# Generated at 2022-06-26 11:39:56.556291
# Unit test for constructor of class IsmFD
def test_IsmFD():
    filename = 'ism'
    info_dict = dict()
    ism_downloader = IsmFD(filename)
    ism_downloader.real_download(filename, info_dict)


if __name__ == '__main__':
    test_case_0()
    test_IsmFD()

# Generated at 2022-06-26 11:40:07.475734
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 0x1,
            'fourcc': 'AACL',
            'duration': 0xa9c0,
            'sampling_rate': 0xac44,
            'channels': 1,
            'bits_per_sample': 0x10,
            'language': 'und',
        })

        written_bytes = stream.getvalue()
        assert len(written_bytes) == 0x1f4
        assert written_bytes[-5:] == b'moov'
        assert written_bytes[-9:-5] == b'\x01\xf0\0\0'

test_case_0()
test_write_piff_header()

# Generated at 2022-06-26 11:40:17.019062
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    self = IsmFD(dict(params=dict(
                                  skip_unavailable_fragments=True,
                                  fragment_retries=100,
                                  test=False,
                                  ism_headers={'User-Agent': 'Foo'})))

    # Call method with:
    #
    # filename: str
    # info_dict: dict
    #
    # Return type: bool

    rv = self.real_download(
        filename=str(''),
        info_dict=dict(fragments=list([dict(url='str'), dict(url='str')])))
    print('rv:', rv)
    exit(rv)

if __name__ == '__main__':
    test_case_0()

    test_IsmFD_real_download()

# Generated at 2022-06-26 11:40:18.727764
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD()


# Generated at 2022-06-26 11:40:29.505720
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-26 11:40:38.877875
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # in case of get_fragment_retries, skip_unavailable_fragments and test set to None, True and False, respectively
    info_dict_0 = {'fragments': [{'url': '0123456789'}]}
    info_dict_0['fragments'][0]['duration'] = 1.0
    info_dict_0['fragments'][0]['title'] = '0123456789'
    info_dict_0['fragments'][0]['fragment'] = '0123456789'
    info_dict_0['fragments'][0]['fragment_index'] = '0123456789'
    info_dict_0['fragments'][0]['byterange_start'] = '0123456789'
    info

# Generated at 2022-06-26 11:40:46.771737
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    p = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'language': 'eng',
        'width': 640,
        'height': 480,
        'sampling_rate': 48000,
        'codec_private_data': '0000000167428029EE0000030001033E96',
    }
    write_piff_header(f, p)

if __name__ == '__main__':
    test_case_0()
    test_write_piff_header()

# Generated at 2022-06-26 11:41:40.940567
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_case_0()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-26 11:41:43.769095
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('++ Start testing IsmFD() class.')
    # TODO: init IsmFD class

    print('-- End testing IsmFD() class.')

if __name__ == '__main__':
    # test_IsmFD()
    test_case_0()

# Generated at 2022-06-26 11:41:52.094615
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'track_id': 1,
        'fourcc': 'H264',  # codec
        'duration': 3000000000,  # 100 seconds
        'timescale': 10000000,  # 10,000,000 means time is expressed in 100 nanosecond units
        'language': 'eng',
        'width': 1920,
        'height': 1080,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'codec_private_data': '6764001f4d4037c01fc4d903f9ca00000110030030342e302e323033303700000000',
        'nal_unit_length_field': 4,
    }

    extract_box_data(bytes_0, [bytes_1])

# Generated at 2022-06-26 11:41:57.306215
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x10aaaa\x00\x00\x00\x10bbbb'
    box_data = extract_box_data(data, ('aaaa'.encode(),))
    assert(box_data == b'bbbb')


# Generated at 2022-06-26 11:42:04.164260
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'avc1',
        'duration': 0,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    stream = io.BytesIO(stream.getvalue())

    assert box(b'ftyp', stream.read(12)) == b'\x00\x00\x00\x1cftypisml\x00\x00\x01piffiso2'
    assert box(b'moov', stream.read(12)) == b'\x00\x00\x00\x1cmoov'
    stream.read(8)

# Generated at 2022-06-26 11:42:14.809267
# Unit test for function extract_box_data
def test_extract_box_data():
    data_0 = b'\x00\x00\x00\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    data_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    box_sequence_0 = (b'\x00\x00\x00\x00', )
    result_0 = extract_box_data(data_0, box_sequence_0)
    assert result_0 == data_1
   

# Generated at 2022-06-26 11:42:18.543863
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    params = {'outtmpl': 'SuperSpeedway_720.ism'}
    ism_fd = IsmFD(url, params)
    ism_fd.real_download()

# Generated at 2022-06-26 11:42:25.032438
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # test_vbr_methods.py
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    assert (success), (False)
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    assert (success), (False)
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    # The following assertions are only tested for this particular
    # method.
    assert (success), (False)
    # The following assertions are only

# Generated at 2022-06-26 11:42:35.770871
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info_dict = {
        'fragments': [
            {'url': 'A'}
        ]
    }
    params = {
        'test': True,
        'fragment_retries': 2
    }
    ism_fd = IsmFD({}, params)
    ism_fd._download_fragment = lambda ctx, url, info_dict: (True, b'T')
    ism_fd._prepare_and_start_frag_download = lambda ctx: None
    ism_fd._append_fragment = lambda ctx, frag_content: None
    ism_fd._finish_frag_download = lambda ctx: None
    ism_fd.report_retry_fragment = lambda err, frag_index, count, fragment_retries: None
   

# Generated at 2022-06-26 11:42:43.816723
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 0,
        'timescale': 1,
        'height': 0,
        'width': 0,
        'language': 'und',
        'codec_private_data': '0000000167640033ACD9048C0D04BF9200003002B64B4000003002B64B401C890B800000F19C001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001001000000982E2800000168EBEC60',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
