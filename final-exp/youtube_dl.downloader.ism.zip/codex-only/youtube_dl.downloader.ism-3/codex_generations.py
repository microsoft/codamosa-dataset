

# Generated at 2022-06-24 12:03:19.228474
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Create an instance of class IsmFD
    from ydl_helper.DownloadProcess import DownloadProcess
    from ydl_helper.Downloader import Downloader
    dl = DownloadProcess()

# Generated at 2022-06-24 12:03:21.247431
# Unit test for function box
def test_box():
    assert box(b'moov', b'hello') == b'\x0c\x00\x00\x00moovhello'

# Generated at 2022-06-24 12:03:29.302817
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:40.662345
# Unit test for function full_box
def test_full_box():
    # ftyp
    assert full_box(b'ftyp', 1, 0, b'av01') == b'\x00\x00\x00\x0cftyp\x00\x01av01'
    assert full_box(b'ftyp', 0, 0, b'av01') == b'\x00\x00\x00\x0cftypav01'
    # stsd
    assert full_box(b'stsd', 0, 0, b'') == b'\x00\x00\x00\x0cstsd\x00\x00\x00\x00'
    # avcC

# Generated at 2022-06-24 12:03:45.291492
# Unit test for function full_box
def test_full_box():
    data = '\x00\x00\x01\x00'
    assert full_box('\x66\x74\x79\x70', 1, 0x100, data) == b'\x00\x00\x0d\x66t\x79\x70\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00'



# Generated at 2022-06-24 12:03:53.619161
# Unit test for function write_piff_header
def test_write_piff_header():
    o = io.BytesIO()
    write_piff_header(o, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10,
        'timescale': 1000,
        'codec_private_data': '0164002afffe100178c015c01041b000001000168ee3c80',
        'width': 1280,
        'height': 720,
    })


# Generated at 2022-06-24 12:03:55.548372
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    io_loop = tornado_iostream.IOLoop.current()
    IsmFD.get_fragment_headers()



# Generated at 2022-06-24 12:04:01.259900
# Unit test for function box
def test_box():
    assert box(b'mdat', b'foo') == b'\x00\x00\x00\x0Bmdatfoo'
test_box()



# Generated at 2022-06-24 12:04:07.755666
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    FD_TEST_FILE = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    FD_TEST_OPTS = {
        'format': 'ism',
        'fragment-duration': 4,
        'fragment-retries': 10,
        'test': True,
    }
    def _run(FD_TEST_OPTS):
        ydl_opts = {
            'format': 'ism',
            'fragment-duration': 4,
            'fragment-retries': 10,
            'test': True,
        }
        result = False

# Generated at 2022-06-24 12:04:14.493296
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys, os
    sys.path.append(os.path.join('..', 'youtube_dl'))
    sys.path.append(os.path.join('..', 'youtube_dl', 'YoutubeDL'))
    from YoutubeDL import YoutubeDL
    from FragmentFD import FragmentFD
    from IsmFD import IsmFD
    filename = 'test.mp4'

# Generated at 2022-06-24 12:04:17.369012
# Unit test for function extract_box_data
def test_extract_box_data():
    # Parse avcC box data
    avcc_box = binascii.unhexlify(b'01640033ffe100186764001fffe100acd9441a48800dc0c0083e80')
    extracted_avcc_box = extract_box_data(avcc_box, [b'stsd', b'avc1', b'avcC'])
    assert extracted_avcc_box == avcc_box, "Extracted avcC doesn't match original one"



# Generated at 2022-06-24 12:04:22.586839
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {
        'id': '0',
        'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism',
        'title': 'Super Speedway (1080p)',
        'ext': 'mp4',
        'fragments': [{
            'url': 'QualityLevels(2160000)/Fragments(video=0)'
        }]
    }
    test = IsmFD(info_dict)
    print(test.FD_NAME)
    print(test.__doc__)

# Generated at 2022-06-24 12:04:31.005458
# Unit test for function write_piff_header
def test_write_piff_header():
    piff_hdr = io.BytesIO()
    bitrate = 300000

# Generated at 2022-06-24 12:04:40.384484
# Unit test for function write_piff_header
def test_write_piff_header():
    stream_audio = io.BytesIO()
    stream_video = io.BytesIO()
    write_piff_header(stream_audio, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 123456789,
        'sampling_rate': 44100,
        'channels': 2,
        'language': 'eng',
        'codec_private_data': '1210',
    })

# Generated at 2022-06-24 12:04:42.608567
# Unit test for function extract_box_data
def test_extract_box_data():
    pattern = b'\x00' * 36
    box_sequence = (b'moov', b'moof', b'mfhd')
    box_data = extract_box_data(pattern + box(b'moof', box(b'mfhd', b'\x00' * 8)) + pattern, box_sequence)
    assert box_data == b'\x00' * 8



# Generated at 2022-06-24 12:05:05.575579
# Unit test for function extract_box_data
def test_extract_box_data():
    data = binascii.unhexlify(
        '0000000c6162636465666768696b6c6d6e6f'
        '0000000a7472616e73616374696f6e00'
        '0000000d777269746564696e666f616263646566676869'
    )
    assert extract_box_data(data, (b'abcdefghiklmn',)) == b'abcdefghiklmn'
    assert extract_box_data(data, (b'writteninfabcedfghi',)) == b'writteninfabcedfghi'
    assert extract_box_data(data, (b'abcdefghiklmn', b'writteninfabcedfghi')) == b'writteninfabcedfghi'



# Generated at 2022-06-24 12:05:07.273239
# Unit test for function box
def test_box():
    assert box("mdat", "...") == b'mdat\x00\x00\x00\x08...'



# Generated at 2022-06-24 12:05:09.176695
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .utils import IsmFD_tester
    IsmFD_tester(IsmFD)()

# Generated at 2022-06-24 12:05:11.759754
# Unit test for function full_box
def test_full_box():
    assert full_box(b"moov", 1, 0x2, b"") == b'\x00\x00\x00\x0cmoov\x01\x00\x00\x02'



# Generated at 2022-06-24 12:05:23.124192
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()

# Generated at 2022-06-24 12:05:33.645948
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:05:35.854418
# Unit test for function box
def test_box():
    assert box('mvhd', '') == b'd\x00\x00\x00\x08mvhd\x00\x00\x00\x00'


# Generated at 2022-06-24 12:05:44.065273
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://c.brightcove.com/services/mobile/streaming/index/rendition.m3u8?assetId=1824686811001&videoId=1824650741001'
    self = IsmFD(url, {})

# Generated at 2022-06-24 12:05:56.082315
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:06:01.834972
# Unit test for function write_piff_header
def test_write_piff_header():
    p = {
        'track_id': 0x1,
        'width': 0,
        'height': 0,
        'fourcc': 'mp4a',
        'duration': 1000 * 10000,
        'channels': 2,
        'sampling_rate': 48000,
        'bits_per_sample': 16,
        'language': 'und',
    }
    stream = io.BytesIO()
    write_piff_header(stream, p)
    print(stream.getvalue().hex())
    return stream



# Generated at 2022-06-24 12:06:13.215625
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert full_box(box_type, version, flags, payload) == binascii.unhexlify('00000020' + '6d6f6f76' + '00000000' + '0000000000000000' + '0000000000000000')


# Generated at 2022-06-24 12:06:18.108904
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'AVC1',
            'duration': 180000,
            'timescale': 10000000,
            'height': 1080,
            'width': 1920,
            'language': 'eng',
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
        })

# Generated at 2022-06-24 12:06:28.499691
# Unit test for function box
def test_box():
    if u32.pack(8 + len(b'\x00\x00\x00\x00')) != b'\x00\x00\x00\x00\x00\x00\x00\x08' and \
            box(b'mvhd', bytes([0]*4)) != b'\x00\x00\x00\x00\x00\x00\x00\x08mvhd\x00\x00\x00\x00':
        raise ValueError('Unit test failed')



# Generated at 2022-06-24 12:06:32.785680
# Unit test for function box
def test_box():
    assert box('\x00\x00\x00\x00', b'') == b'\x00\x00\x00\x08\x00\x00\x00\x00'



# Generated at 2022-06-24 12:06:35.444221
# Unit test for function box
def test_box():
    assert box('abcd', 'efgh') == b'\x00\x00\x00\x0cabcdefgh'


# Generated at 2022-06-24 12:06:46.219831
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test constructor
    fd = IsmFD()
    # Missing 'url' field
    assert fd.get_real_downloader({}) is None
    # Missing 'manifest_url' field
    assert fd.get_real_downloader({'url': 'http://example.com/file.isml/QualityLevels(999000)/Fragments(video=0)'}) is None
    # Test constructor with optional 'fragments' field

# Generated at 2022-06-24 12:06:48.447326
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = ''
    info_dict = ''
    obj = IsmFD()
    assert obj.real_download(filename, info_dict) == True

# Generated at 2022-06-24 12:06:53.989072
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism = IsmFD({'f':'test.ism/Manifest'}, None)
    assert(esm.proto == 'http' or esm.proto == 'https')
    assert(esm.template_url is not None)
    assert(esm.fragment_id_prefix is not None)
    assert(esm.http_method == 'GET')
    assert(esm.http_proto == 'http_req_headers')
    assert(esm.http_client == 'httpclient')
    assert(esm.is_dash is not False)

# Generated at 2022-06-24 12:06:57.813202
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://media.ch9.ms/ch9/4eec/89a96dae-9f9b-448b-bf92-300e1b2f4eec/ASPNETCore.mp4'
    ismfd = IsmFD()
    ismfd.real_download('filename', {'fragment_index' : 5, 'fragments' : []})


# Generated at 2022-06-24 12:07:09.260102
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data_for_ftyp = b'\x00\x00\x00\x1C'  # moov box size
    box_data_for_ftyp += b'ftyp'  # box type
    box_data_for_ftyp += b'isml'  # major brand
    box_data_for_ftyp += b'\x00\x00\x00\x01'  # minor version
    box_data_for_ftyp += b'piff'  # compatible brands
    box_data_for_ftyp += b'iso2'  # compatible brands
    assert extract_box_data(box_data_for_ftyp, (b'ftyp', )) == b'\x00\x00\x00\x00\x00\x00\x00\x01piffiso2'

# Generated at 2022-06-24 12:07:21.286002
# Unit test for function full_box
def test_full_box():
    def compare(res, expected):
        assert res == expected
        print(expected.encode('hex'))
    res = full_box(b'moov', 0, 0, b'')
    compare(res, b'\x00\x00\x00\x10moov\x00\x00\x00\x00\x00\x00\x00')
    res = full_box(b'moov', 1, 0, b'')
    compare(res, b'\x00\x00\x00\x10moov\x01\x00\x00\x00\x00\x00\x00')
    res = full_box(b'moov', 1, 1, b'')

# Generated at 2022-06-24 12:07:31.106683
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
        This unit test method checks the real_download method of the class IsmFD. The method is tested for three cases
        :return:
    """
    # case 1
    # eg :1. extract_box_data(fragment_content, [b'moof', b'traf', b'tfhd'])
    #   where fragment_content is "0000000015f45404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404e2b94042010000006500000080202000000650000008020201000000650000008020200000065000000802020100000065000000802020000006500000080202010000006500000080202000000

# Generated at 2022-06-24 12:07:40.636316
# Unit test for function box

# Generated at 2022-06-24 12:07:51.128921
# Unit test for function write_piff_header
def test_write_piff_header():
    print('Unit test for function write_piff_header()')
    fout = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 30,
        'codec_private_data': '67642A0AFC100098A10098FFC100000C895F8FFC100000C901D0C0',
        'nal_unit_length_field': 4,
        'height': 480,
        'width': 640,
    }
    write_piff_header(fout, params)

# Generated at 2022-06-24 12:08:00.578295
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'dummy_data'

    box_type_0 = b'boxt0'
    box_type_1 = b't0box'
    assert extract_box_data(data, (box_type_0, box_type_1)) == b''

    box_type_1 = b'boxt1'
    tmp_data = box(box_type_1, b'box_data')
    data = box(box_type_0, tmp_data + b'dummy_data')
    assert extract_box_data(data, (box_type_0, box_type_1)) == b'box_data'



# Generated at 2022-06-24 12:08:04.065059
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # This test is needed as a workaround to Python failing to import
    # a module with a conflicting name in the same package
    pass


# This function is not called by YouTubeDL right now and is here just to test the implementation
# of this downloader.

# Generated at 2022-06-24 12:08:15.110387
# Unit test for function extract_box_data
def test_extract_box_data():
    from .smoothstreams import SmoothStreamsIE
    from .fragment import FragmentFD

    def verify(box_type, field_names, values, box_data=None):
        if box_data is None:
            box_data = extract_box_data(box_data, (box_type,))
        assert len(box_data) == sum([struct.size for struct in field_names])
        box_reader = io.BytesIO(box_data)
        for field_name, struct, value in zip(field_names, field_names, values):
            print('Reading %s' % field_name)
            assert struct.unpack(box_reader.read(struct.size))[0] == value


# Generated at 2022-06-24 12:08:17.293746
# Unit test for function box
def test_box():
    assert box(b'moov', b'1234') == b'\x00\x00\x00\nmoov1234'


# Generated at 2022-06-24 12:08:26.048133
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Test for IsmFD class constructor"""
    params = {'prefer_free_formats': False}
    params.update(DEFAULT_OUTTMPL_ARGS)

    params['prefer_free_formats'] = False
    assert IsmFD.can_download('http://mediaplatform.streamingmediahosting.com/index.php/edge/policy?i=0.12839400%2Fvod%2Fsmil:BigBuckBunny/manifest.ism', params)
    assert not IsmFD.can_download('http://mediaplatform.streamingmediahosting.com/index.php/edge/policy?i=0.12839400%2Fvod%2Fsmil:BigBuckBunny/manifest.f4m', params)

    params['prefer_free_formats'] = True

# Generated at 2022-06-24 12:08:35.534983
# Unit test for function extract_box_data
def test_extract_box_data():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '01640028ffe1001967640028acd91203',
        'duration': 16400280,
        'timescale': 90000,
        'sampling_rate': 44100,
        'width': 1280,
        'height': 720,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    piff_header_data = stream.getvalue()

    assert len(piff_header_data) == 922

    extract_box_data(piff_header_data, [b'ftyp'])
    extract_box_data(piff_header_data, [b'moov', b'mvhd'])

    st

# Generated at 2022-06-24 12:08:38.857568
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264'
    }
    write_piff_header(f, params)
    assert len(f.getvalue()) > 0

# Generated at 2022-06-24 12:08:41.225737
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD is not None

if __name__ == '__main__':
    sys.exit(test_IsmFD())

# Generated at 2022-06-24 12:08:48.562929
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Input and expected output
    url = 'http://www.example.com/?trackId=1'
    params = {'fragment_retries': '5', 'skip_unavailable_fragments': True, 'test': True}
    expected_output = {
        'path': 0,
        'frag_index': 0,
        'retries': 0
    }

    # Test
    result = IsmFD._build_fragment_retry_dict(url, params)
    assert result == expected_output

test_IsmFD()

# Generated at 2022-06-24 12:08:56.084615
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor import gen_extractors
    from .downloader import gen_default_process
    from .downloader import FileDownloader
    from .downloader import _check_options
    from .downloader import gen_open_fn
    from .downloader import _match_entry
    from .downloader import _real_main
    from .downloader import _real_initialize
    from .downloader import _real_run
    import sys

# Generated at 2022-06-24 12:09:01.432715
# Unit test for function box
def test_box():
    assert box('abcd', '123') == b'\x00\x00\x00\x0b' + b'abcd' + b'123'



# Generated at 2022-06-24 12:09:04.205555
# Unit test for function box
def test_box():
    assert box(b'abcd', b'efgh') == b'\x00\x00\x00\x0cefghabcd'
    return True


# Generated at 2022-06-24 12:09:12.123994
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..fragments import decode_fragment_url
    fd = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 30000000
    params['timescale'] = 10000000
    params['height'] = 270
    params['width'] = 480
    params['codec_private_data'] = '01640028ffe1000867640028acb90100'
    params['nal_unit_length_field'] = 4
    write_piff_header(fd, params)



# Generated at 2022-06-24 12:09:16.415215
# Unit test for function full_box
def test_full_box():
    f = open("full_box.mp4", "wb")
    f.write(full_box(b'ftyp',0,0,b'abcdeghijklmnoopqrstuvwxyz'))


# Generated at 2022-06-24 12:09:22.199217
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = FragmentFD()
    params = {
        'track_id':                1,
        'fourcc':                'AACL',
        'duration':800,
        'timescale': 44100,
        'channels':2,
        'bits_per_sample': 16,
        'sampling_rate':44100,
    }

    write_piff_header(stream, params)
    print(stream.getvalue())


# Generated at 2022-06-24 12:09:30.991564
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x00xxx\x00\x00\x00\x00', [b'xxx']) == b''
    assert extract_box_data(b'\x00\x00\x00\x00xxx\x00\x00\x00\x00', [b'xxx', b'yyy']) == b''
    assert extract_box_data(b'\x00\x00\x00\x00xxx\x00\x00\x00\x00yyy\x00\x00\x00\x00', [b'xxx', b'yyy']) == b''

# Generated at 2022-06-24 12:09:46.114968
# Unit test for function full_box
def test_full_box():
    with io.BytesIO() as h:
        h.write(full_box('mvhd', 0, 0x01, ''))
        from .test import test_full_box as tfb
        if h.getvalue() == tfb:
            return True
        else:
            return False



# Generated at 2022-06-24 12:09:49.487766
# Unit test for function box
def test_box():
    box_type = b'moov'
    payload = b'hello'
    assert box(box_type, payload) == b'\x00\x00\x00\x0Cmoovhello'


# Generated at 2022-06-24 12:09:57.194828
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 50, 'language': 'und',
              'timescale': 10000000, 'height': 0, 'width': 0, 'channels': 2,
              'bits_per_sample': 16, 'sampling_rate': 44100}
    with io.open('test.piff', 'w+b') as f:
        write_piff_header(f, params)
    with io.open('test.piff', 'rb') as f:
        print(f.read())



# Generated at 2022-06-24 12:10:06.743897
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import io

    track_id = 0x01
    fourcc = 'NONE'
    duration = 0
    timescale = 10000000
    language = 'und'
    height = 0
    width = 0

    input_stream = io.BytesIO(b'')
    output_stream = io.BytesIO()
    write_piff_header(output_stream, locals())
    output_stream.seek(0)

    with open(os.path.join(os.path.dirname(__file__), 'test_files', 'piff_header.raw'), 'rb') as f:
        assert output_stream.read() == f.read()



# Generated at 2022-06-24 12:10:18.216660
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from .mp4 import Mp4FragmentFD
    from .common import FileDownloader, warning
    from ..extractor import get_info_extractor
    from ..utils import md5

    def write_data(self, data):
        self.written_data += data

    with warning('ignore', 'Old version'):
        yt_ie = get_info_extractor('Youtube', FileDownloader({}))

# Generated at 2022-06-24 12:10:30.904456
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Preparations
    import io
    from .test.test_utils import load_test_data, make_temp_file, make_temp_directory
    from .compat import compat_urllib_request, compat_urllib_error, compat_http_cookiejar
    from .utils import read_batch_urls
    from .downloader import FileDownloader
    from .fragment import FragmentFD

    fd = IsmFD()
    class Test_FileDownloader:
        def __init__(self, params):
            self.params = params
        def to_screen(self, message, skip_eol=False):
            pass
        def to_stdout(self, message):
            pass
        def report_warning(self, message):
            pass

# Generated at 2022-06-24 12:10:41.270908
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for real_download of class IsmFD
    """
    import pickle
    import re
    import os
    import sys
    import inspect
    import urllib
    import urllib.request
    import urllib.error
    import urllib.parse
    import json
    import shutil

    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    os.chdir(current_dir)
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()



# Generated at 2022-06-24 12:10:45.392329
# Unit test for function box
def test_box():
    header = box(b'moov', b'')
    assert u32.unpack(header)[0] == 12

# Function moov_box
# Return the 'moov' box which can be used for writing into 
# the file 'track'

# Generated at 2022-06-24 12:10:49.870143
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD(params={'ism_url':'http://test-manifests.dashif.org/dash-if-reference/dash.js/samples/dash-if-reference-player/live-stream.mpd'})



# Generated at 2022-06-24 12:10:50.906811
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

# Generated at 2022-06-24 12:10:59.625977
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'moov', b'mvex', b'trex')

# Generated at 2022-06-24 12:11:02.406187
# Unit test for function box
def test_box():
    assert(box('xyz', 'abc') == b'00000014xyzabc')
    #assert(box('abc', 'def') == b'00000014xyzabc')


# Generated at 2022-06-24 12:11:14.701593
# Unit test for function write_piff_header
def test_write_piff_header():
    from collections import OrderedDict
    
    params = OrderedDict()
    params['track_id'] = 1
    params['fourcc'] = 'AACL'
    params['duration'] = 70813
    params['timescale'] = 44100
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['sampling_rate'] = 44100
    params['language'] = 'und'
    params['codec_private_data'] = ''
    
    f = io.BytesIO()
    write_piff_header(f, params)
    
    f.seek(0)
    assert f.read(4) == b'ftyp'
    
    f.seek(12)
    assert f.read(4) == b'isml'

# Generated at 2022-06-24 12:11:21.481555
# Unit test for function box
def test_box():
    assert box('moov', '') == '\x00\x00\x00\x0Cmoov'
    assert box('moov', '\x00' * 4) == '\x00\x00\x00\x10moov\x00\x00\x00\x00\x00\x00\x00\x00'
    assert box('moov', '\x00' * 5) == '\x00\x00\x00\x11moov\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:11:25.016274
# Unit test for function full_box
def test_full_box():
    assert full_box(b'fgtl', 0x01, 0x01, b'0123456789') == b'\x00\x00\x00\x12fgtl\x00\x00\x01\x010123456789'



# Generated at 2022-06-24 12:11:33.003256
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x39moov\x00\x00\x00\x33trak\x00\x00\x00\x2Dmdia\x00\x00\x00\x27minf\x00\x00\x00\x1Bstbl\x00\x00\x00\x17stco\x00\x00\x00\x0C\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 12:11:39.789626
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Check if IsmFD class can download an ism file
    # given its url
    base_url = "http://lax-hlslive.hls.adaptive.level3.net/hls/live/221604/0c/saturn/2011/masters/24/0/0/0/"
    manifest_file = "manifest-fra.ismc"
    ismfd = IsmFD(base_url + manifest_file)
    # Define the variables 'filename', 'info_dict' and download the
    # ism files

# Generated at 2022-06-24 12:11:43.836528
# Unit test for function box
def test_box():
    assert box('ftyp', 'mp42') == '\x00\x00\x00\x0cftymp42'
    assert box('\x00\x00\x00\x00', '\x00\x00\x00\x00') == '\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:11:51.339982
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()

# Generated at 2022-06-24 12:12:00.963506
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://test/test.ismv'
    info_dict = {}
    info_dict['_type'] = 'http'
    info_dict['url'] = url
    info_dict['http_headers'] = {}
    info_dict['fragments'] = [{'url': 'http://test/test.ismv?byte1'}]
    info_dict['_download_params'] = {}
    info_dict['_download_params']['track_id'] = 4
    info_dict['_download_params']['fourcc'] = 'avc1'
    info_dict['_download_params']['timescale'] = 90000
    info_dict['_download_params']['height'] = 720
    info_dict['_download_params']['width'] = 1280

# Generated at 2022-06-24 12:12:11.637101
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = b'dinf', b'dref', b'url '
    box_data = extract_box_data(b'\x00\x00\x00\x1C' + b'dinf' + b'\x00\x00\x00\x00' + b'dref' + b'\x00\x00\x00\x18' + b'url ' + b'\x00\x00\x00\x00' + b'http://example.com', box_sequence)
    assert box_data == b'\x00\x00\x00\x00' + b'url ' + b'\x00\x00\x00\x00'

# Generated at 2022-06-24 12:12:16.638027
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://someurl/manifest(format=mpd-time-csf).mpd'
    params = { 'url': url }
    ydl = YoutubeDL(params)
    # test that the constructor of IsmFD sets correct values for params and ydl
    ismfd = IsmFD(params, ydl)
    assert ismfd.params == params
    assert ismfd.ydl == ydl



# Generated at 2022-06-24 12:12:29.593555
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:12:41.621879
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 5000,
        'timescale': 10000000,
        'language': 'en',
        'height': 480,
        'width': 640,
        'codec_private_data': '0164001fffe1001867640029acd9350261613c0db0',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:12:48.924670
# Unit test for function extract_box_data
def test_extract_box_data():
    data = binascii.unhexlify(b'0000002c6674797069736d6c20776f6f20626172636861722120776f6f646c6561726e20666c61736821206265697420626172636861722062656469742062617263686172206663766168792066686376616879157069636b2073756d746e656420627920576f726b65742046696e616c')

# Generated at 2022-06-24 12:13:01.003547
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'AACL'
    params['duration'] = 2
    params['timescale'] = 10000000
    params['language'] = 'eng'
    params['height'] = 720
    params['width'] = 1280
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['sampling_rate'] = 48000
    params['codec_private_data'] = ''
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:13:09.948464
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:13:14.095513
# Unit test for function full_box
def test_full_box():
    return full_box('mdhd', 0, 0, b'') == b'\x00\x00\x00\x18mdhd\x00\x00\x00\x00\x00\x00\x00'
