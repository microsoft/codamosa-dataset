

# Generated at 2022-06-24 12:03:17.421009
# Unit test for function box
def test_box():
    box('free', b'123') == b'\x00\x00\x00\x0bfree123'
# End unit test for function box


# Generated at 2022-06-24 12:03:19.224335
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'



# Generated at 2022-06-24 12:03:20.915321
# Unit test for function full_box
def test_full_box():
    assert full_box(b'free', 0, 0x1, b'abcd')


# Generated at 2022-06-24 12:03:24.708543
# Unit test for function full_box
def test_full_box():
    assert full_box("box_type", 1, 2, "payload") == b'\x00\x00\x00\x0c'+"box_type"+b'\x01'+b'\x00\x00\x00\x02'+"payload"


# Generated at 2022-06-24 12:03:36.540689
# Unit test for function extract_box_data
def test_extract_box_data():
    # Test with a FTYP box
    data = box(b'ftyp', b'RMP4')
    assert extract_box_data(data, (b'ftyp',)) == b'RMP4'
    data = box(b'ftyp', b'RMP4')
    assert extract_box_data(data, (b'moov',)) == None
    # Test with nested boxes
    data = box(b'ftyp', b'RMP4')
    data += box(b'moov', b'')
    assert extract_box_data(data, (b'ftyp',)) == b'RMP4'
    data = box(b'ftyp', b'RMP4')
    data += box(b'moov', b'')

# Generated at 2022-06-24 12:03:40.661097
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = ''
    info_dict = {}
    expected = False
    real_download = IsmFD.real_download(filename, info_dict)
    assert expected == real_download
IsmFD.real_download = test_IsmFD_real_download

########################################################################
# Common Functions For Extractors

# Generated at 2022-06-24 12:03:50.882766
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:01.301148
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:03.687348
# Unit test for function box
def test_box():
    assert box(b'abcd', b'efgh') == binascii.unhexlify(b'00000008abcdefgh')
test_box()



# Generated at 2022-06-24 12:04:09.097918
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD({'url': 'http://example.com/manifest.ism/Streams(audio,video)', 'fragments': [{'url': 'http://example.com/init_segment.mp4'}, {'url': 'http://example.com/media_segment1.mp4'}, {'url': 'http://example.com/media_segment1.mp4'}]})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:04:10.780777
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:04:15.410295
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 7, u32.pack(8)) == b'\x00\x00\x00\x20moov' + b'\x01' + b'\x00\x07\x00\x00' + b'\x00\x00\x00\x08'



# Generated at 2022-06-24 12:04:19.669472
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b''
    actual = full_box(box_type, version, flags, payload)
    expect = b'\x00\x00\x00\x14moov\x00\x00\x00\x00\x00\x00'
    assert actual == expect


# Generated at 2022-06-24 12:04:24.379376
# Unit test for function box
def test_box():
    assert(box(b'moov', b'7') == b'\x00\x00\x00\x0dmoov7')
    assert(box(b'moov', b'') == b'\x00\x00\x00\x08moov')


# Generated at 2022-06-24 12:04:28.514911
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'
    assert box(b'moov', b'\x00\x01\x02\x03') == b'\x00\x00\x00\x10moov\x00\x01\x02\x03'
test_box()


# Generated at 2022-06-24 12:04:30.263213
# Unit test for function box
def test_box():
    assert box("abcd", "efgh") == b'\x00\x00\x00\x0cefgh'



# Generated at 2022-06-24 12:04:40.096287
# Unit test for function extract_box_data
def test_extract_box_data():
    import random

    def generate_data(size):
        random.seed()
        data = io.BytesIO()
        while data.tell() < size:
            box_type = random.getrandbits(32)
            box_size = random.getrandbits(32) & 0xfffffffe
            if box_size == 0:
                box_size = 8
            data.write(u32.pack(box_size))
            data.write(u32.pack(box_type))
            box_data = ''
            for _ in range(box_size - 8):
                box_data += random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')

# Generated at 2022-06-24 12:04:45.692162
# Unit test for function full_box
def test_full_box():
    version = 1
    flags = 0
    payload = '\x00\x00\x00\x00'
    assert full_box('fLaC',version, flags, payload) == '\x00\x00\x00\x10fLaC\x01\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:04:51.227215
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import CommonIE

    url = 'http://video.ted.com/talks/podcast/AlGore_2006-480p.mp4'
    print('downloading ' + url)
    ydl = YoutubeDL({
        'outtmpl': u'%(id)s.%(ext)s',
        'quiet': True,
        'simulate': True,
    })
    ie = CommonIE()
    info_dict = ie.extract(ydl, url)
    params = {
        'isfm': True,
    }
    ism = IsmFD(url, params)
    ism.real_download(info_dict['id'] + '.mp4', info_dict)



# Generated at 2022-06-24 12:04:54.207566
# Unit test for function box
def test_box():
    assert box('moov', '') == b'\x00\x00\x00\x0cmoov'
    assert box('moov', '0' * 100) == b'\x00\x00\x00lmoov' + b'0' * 100


# Generated at 2022-06-24 12:05:04.586579
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:05:09.966294
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'format': 'ism'})
    out = fd._download_fragment({}, 'http://example.com/test.ism/test.m4s', {})
    assert out == (False, None)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:05:15.966728
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = { 
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 3,
        'timescale': 3,
        'nal_unit_length_field': 2,
        'sampling_rate': 4,
        'channels': 4,
        'bits_per_sample': 4,
        'height': 5, 
        'width': 5,
        'language': 'en'
    }
    write_piff_header(stream, params)
    


# Generated at 2022-06-24 12:05:18.029908
# Unit test for constructor of class IsmFD
def test_IsmFD():
   ismfd = IsmFD()

if __name__ == '__main__':
   test_IsmFD()

# Generated at 2022-06-24 12:05:19.012346
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return None

# Generated at 2022-06-24 12:05:22.092474
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mdat', 0, 0, b'frag') == binascii.unhexlify(b'0000001c6d646174000000046d757267')



# Generated at 2022-06-24 12:05:24.251540
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == b'\x00\x00\x00\x0cabcd1234'


# Generated at 2022-06-24 12:05:31.409410
# Unit test for function write_piff_header
def test_write_piff_header():
    piff_stream = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'AACL'
    params['duration'] = 0
    params['timescale'] = 1
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['sampling_rate'] = 44100
    write_piff_header(piff_stream, params)
    print(binascii.hexlify(piff_stream.getvalue()).decode('utf-8'))
    # test_write_piff_header()


# Generated at 2022-06-24 12:05:35.584463
# Unit test for function box
def test_box():
    box_type = "abcd"
    payload = "defg"
    actual = box(box_type, payload)
    expected = u32.pack(8 + len(payload)) + box_type + payload
    assert actual == expected



# Generated at 2022-06-24 12:05:40.001059
# Unit test for constructor of class IsmFD
def test_IsmFD():
    name = "IsmFD"
    params = {
        'outtmpl': 'outtmpl',
        'format': 'format',
    }
    info_dict = {
        'fragments': [
            {},
        ]
    }
    ydl = YoutubeDL(params)
    fd = IsmFD(ydl, info_dict)
    assert name == fd.FD_NAME

# Generated at 2022-06-24 12:05:40.529398
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:05:47.081234
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'height': 0,
        'width': 0,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'duration': 18814000,
    }
    write_piff_header(stream, params)
    expected =  b'ftypismlpiffiso2'

# Generated at 2022-06-24 12:05:56.818736
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Dummy parameters
    params = {
        'ism_version': 8,
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 4000000,
        'timescale': 10000000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'nal_unit_length_field': 4,
        'codec_private_data': '000000016742E0DFABB80'
    }

    # Create new IsmFD
    IsmFD(params)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:06:06.494871
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor.common import InfoExtractor

    def mock_append_fragment(*args):
        pass

    def mock_finish_frag_download(*args):
        pass

    info_dict = dict()
    info_dict['fragments'] = list()

    fragments = [{'url':'http://test.com/test1'},{'url':'http://test.com/test2'}]

    info_dict['fragments'].extend(fragments)
    info_dict['track_id'] = 'test_track'
    info_dict['duration'] = '1'

    file_desc = io.BytesIO()


# Generated at 2022-06-24 12:06:10.599921
# Unit test for function full_box
def test_full_box():
    assert full_box('ftyp', 0, SELF_CONTAINED, b'isom') == b'\x00\x00\x00\x1cftyp\x00\x01isom'
# End of test_full_box



# Generated at 2022-06-24 12:06:16.522698
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:06:21.941882
# Unit test for function box
def test_box():
    a = box("moov", "mvhd")
    assert(len(a) == 12)
    assert(a[:4] == b"\x00\x00\x00\x14")
    assert(a[4:8] == b"moov")
    assert(a[8:] == b"mvhd")



# Generated at 2022-06-24 12:06:23.943575
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = IsmFD(parameters = {})

    # TODO: Implement test
    assert False, 'Test not implemented'


# Generated at 2022-06-24 12:06:27.732202
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:06:31.417096
# Unit test for function box
def test_box():
    assert box(b'\00\00\00\00', b'') == b'\00\00\00\10\00\00\00\00'



# Generated at 2022-06-24 12:06:40.543040
# Unit test for function write_piff_header
def test_write_piff_header():
    from tempfile import NamedTemporaryFile
    from .helpers import make_sure_directory_exists
    temp = NamedTemporaryFile(mode='wb', dir='temp', delete=False)
    make_sure_directory_exists(temp.name)
    # Video
    params = {
        'track_id': 1,
        'duration': 10000000,
        'height': 480,
        'width': 854,
        'fourcc': 'H264',
        'codec_private_data': '0000000167640029AC2C71EDB0',
    }
    write_piff_header(temp.file, params)
    temp.close()
    # Audio

# Generated at 2022-06-24 12:06:49.730944
# Unit test for function extract_box_data
def test_extract_box_data():
    # Note: The following input is not valid mp4, but only for demonstration purpose
    a = '\x14\x00\x00\x00\x00\x00\x00\x00' \
        '\x11\x00\x00\x00\x01\x00\x00\x00' \
        '\x12\x00\x00\x00\x01\x00\x00\x00' \
        '\x13\x00\x00\x00\x01\x00\x00\x00' \
        '\x14\x00\x00\x00\x01\x00\x00\x00'

# Generated at 2022-06-24 12:06:52.989729
# Unit test for function full_box
def test_full_box():
    assert full_box('abcd', 1, 0, '1234') == b'\x00\x00\x00\x0cabcd\x01\x00\x00\x001234'



# Generated at 2022-06-24 12:06:55.254070
# Unit test for function box
def test_box():
    assert box('abcd', 'efgh') == b'\x00\x00\x00\x0cefgh'


# Generated at 2022-06-24 12:06:58.489062
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov',1,1,b'') == b'moov\x00\x00\x00\x05\x01\x11\x80\x80\x80'

# Generated at 2022-06-24 12:06:59.801129
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:07:10.280502
# Unit test for function write_piff_header
def test_write_piff_header():
    mdat = io.BytesIO()
    mdat.write(b'video data')
    mdat.seek(0)

    stream = io.BytesIO()
    params = {}
    params['thumbnail'] = None
    params['fourcc'] = 'H264'
    params['duration'] = 10000
    params['timescale'] = 10000000
    params['language'] = 'und'
    params['height'] = 576
    params['width'] = 720
    params['codec_private_data'] = '000000016764001fACD0012C547FA913'
    params['track_id'] = 1
    write_piff_header(stream, params)

    stream.seek(0)
    stream.seek(8, 1)
    assert stream.read(4) == b'piff'
    stream

# Generated at 2022-06-24 12:07:21.832698
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        video_params = {
            'track_id': 1,
            'fourcc': 'H264',
            'codec_private_data': '0000000167640028AC2C01E800F01C35BD00F00E8C84201F00000168CE3880',
            'duration': 1000000,
            'timescale': 10000000,
            'height': 720,
            'width': 1280,
        }
        write_piff_header(f, video_params)

        mp4_bytes = f.getvalue()

# Generated at 2022-06-24 12:07:31.529744
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x03\x04' + b'data1'
    data += b'\x00\x00\x03\x04' + b'box1'
    data += b'\x00\x00\x03\x04' + b'data2'
    data += b'\x00\x00\x03\x04' + b'box1'
    data += b'\x00\x00\x03\x04' + b'data3'
    data += b'\x00\x00\x03\x04' + b'box2'
    data += b'\x00\x00\x03\x04' + b'data4'
    data += b'\x00\x00\x03\x04' + b'box1'

# Generated at 2022-06-24 12:07:33.819901
# Unit test for function full_box
def test_full_box():
    assert full_box("test", 1, 1, "test") == binascii.unhexlify("00000014746573740000000001000000000074657374")



# Generated at 2022-06-24 12:07:42.657589
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 1, b'\00') == b'\x00\x00\x00\x0cmoov\x01\x01\x00\x00'
    assert full_box(b'moov', 1, 2, b'\00') == b'\x00\x00\x00\x0cmoov\x01\x02\x00\x00'
    assert full_box(b'moov', 1, 3, b'\00') == b'\x00\x00\x00\x0cmoov\x01\x03\x00\x00'

# Generated at 2022-06-24 12:07:52.222401
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:03.456323
# Unit test for function extract_box_data
def test_extract_box_data():
    #  generate sample_entry
    sample_entry_payload = u8.pack(0) * 6  # reserved
    sample_entry_payload += u16.pack(1)  # data reference index
    sample_entry_payload += u32.pack(0) * 2  # reserved
    sample_entry_payload += u16.pack(2)
    sample_entry_payload += u16.pack(16)
    sample_entry_payload += u16.pack(0)  # pre defined
    sample_entry_payload += u16.pack(0)  # reserved
    sample_entry_payload += u1616.pack(44100)
    codec_private_data = binascii.unhexlify('ffa39c8001e05a530000000000000000')
    avcc_payload = u8

# Generated at 2022-06-24 12:08:14.286476
# Unit test for constructor of class IsmFD
def test_IsmFD():
    if len(sys.argv) < 3:
        print('Usage: %s <ISM manifest URL> <output file>' % sys.argv[0])
        sys.exit(1)
    manifest_url = sys.argv[1]
    output_file = sys.argv[2]
    params = {
        'fragment_retries': 10,
        'test': True,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }
    _downloader = IsmFD(params)
    _downloader.real_download(output_file, {"fragments": [{"url": manifest_url}]})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:08:18.151588
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Only run the tests if f4mtest.py is installed
    f4mtest_installed = False
    try:
        import f4mtest
        f4mtest_installed = True
    except ImportError:
        pass

    if f4mtest_installed:
        from f4mtest import test_IsmFD
        test_IsmFD('ism', [{
            'params': ['--fragment-retries', '0'],
            'expect': '4ab22f0d9a8a2b0e7c1617fa609afe05',
        }])

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:08:26.920497
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:36.216956
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:08:41.757397
# Unit test for function write_piff_header
def test_write_piff_header():
    import os


# Generated at 2022-06-24 12:08:44.233671
# Unit test for function box
def test_box():
    assert(b'\x00\x00\x00\x05abcd' == box(b'abc', b'd'))
box_t = box



# Generated at 2022-06-24 12:08:53.618144
# Unit test for function write_piff_header
def test_write_piff_header():
    import os

    def gen_sample_fragment(params):
        with io.BytesIO() as stream:
            write_piff_header(stream, params)
            yield (0, stream.getvalue(), params['track_id'], params['fourcc'])
    
    def helper(params):
        ref_stream = io.BytesIO()
        write_piff_header(ref_stream, params)
        ref_stream.seek(0)
        with io.BytesIO() as stream:
            ffd = FragmentFD(stream)

            # Write PIFF header and first fragment
            ffd.writeheaders(gen_sample_fragment(params))
            stream.seek(0)

            if not stream.read() == ref_stream.read():
                print('!')
            else:
                print('.')



# Generated at 2022-06-24 12:09:04.463747
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:09:09.811586
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:13.208702
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Return true if IsmFD constructor does not raise any exception."""
    params = {'track_id' : 1, 'fourcc' : 'AACL', 'duration' : 10000, 'timescale' : 10000000, 'language' : 'und', 'height' : 0, 'width' : 0, 'sampling_rate' : 44100}
    IsmFD(params)
    return True

if __name__ == '__main__':
    print(test_IsmFD())

# Generated at 2022-06-24 12:09:24.338382
# Unit test for function extract_box_data
def test_extract_box_data():
    data = (
        b'\x00\x00\x00\x06ftyp'
        b'\x00\x00\x00\x00\x00\x00\x01abc'
        b'\x00\x00\x00\x10bdef'
        b'\x00\x00\x00\x05g'
        b'\x00\x00\x00\x01h'
    )
    assert extract_box_data(data, [b'bdef', b'g']) == b'\x00\x00\x00\x05g\x00\x00\x00\x01h'
    assert extract_box_data(data, [b'abc']) == b''

# Generated at 2022-06-24 12:09:32.171182
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Set up
    import io
    import os
    import tempfile
    import subprocess
    import sys
    temp_dir = tempfile.mkdtemp(prefix="temp_")
    temp_file_path = os.path.join(temp_dir, "temp_file.ism")
    temp_file = io.open(temp_file_path, mode="wb")
    current_path = os.getcwd()
    os.chdir(temp_dir)
    test_url = "http://www.youtube.com/watch?v=uQnLIe_zaIU"
    download_dict = {
        "fragments": [],
    }
    download_dict["fragments"].append({
        "url": test_url,
    })

# Generated at 2022-06-24 12:09:41.551176
# Unit test for function write_piff_header
def test_write_piff_header():

    from .mp4 import MP4Muxer
    from .fragment import FragmentMuxer

    muxer = MP4Muxer(FragmentMuxer())
    # This dict is a copy of the dict used in MP4Muxer
    # It's not the same as the dict used in FragmentFD

# Generated at 2022-06-24 12:09:45.448664
# Unit test for function box
def test_box():
    assert box(b'avcC', b'\x01') == b'\x00\x00\x00\navcC\x01\x00\x00\x00\x00'



# Generated at 2022-06-24 12:09:55.323690
# Unit test for function write_piff_header
def test_write_piff_header():
    s = io.BytesIO()
    write_piff_header(s, {'track_id': 1, 'fourcc': 'AACL', 'sampling_rate': 44100, 'channels': 2, 'duration': 1752})

# Generated at 2022-06-24 12:10:06.165103
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x0Aabcd\x00\x00\x00\x0Cxyz\x00\x00\x00\x0Aefgh', (b'abcd', b'xyz')) == b'efgh'
    assert extract_box_data(b'\x00\x00\x00\x0Aabcd\x00\x00\x00\x08xyz\x00\x00\x00\x0Eefgh', (b'abcd', b'xyz')) == None

# Generated at 2022-06-24 12:10:13.356463
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:22.518643
# Unit test for function extract_box_data
def test_extract_box_data():
    # UUID box test
    uuid_box_data = b'\x71\xE9\x57\xF6\xBD\x4E\x4D\x48\x85\x6D\xC8\x43\x04\xD5\x28\x8D'
    uuid_box_data += b'\x8B\x0D\x51\x5E\x8C\xF6\x5B'
    data = box(b'uuid', uuid_box_data)
    assert extract_box_data(data, [b'uuid']) == uuid_box_data
    # mvhd box test

# Generated at 2022-06-24 12:10:35.042461
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # A manifest that use isml
    manifest_url='http://amssamples.streaming.mediaservices.windows.net/683f7e47-bd83-4427-b0a3-26a6c4547782/BigBuckBunny.ism/manifest(format=mpd-time-csf)',
    ydl = YoutubeDL({'fragment_retries': 10})
    fd = IsmFD(ydl, manifest_url)
    assert fd.params['test'] is False
    assert fd.params['fragment_retries'] == 10
    ydl = YoutubeDL({'test': True, 'fragment_retries': 10})
    fd = IsmFD(ydl, manifest_url)
    assert fd.params['test'] is True

# Generated at 2022-06-24 12:10:39.312467
# Unit test for function full_box
def test_full_box():
    assert full_box('test',1,1,'test') == '\x00\x00\x00\x0f\x74\x65\x73\x74\x01\x00\x00\x00\x01test'

# Generated at 2022-06-24 12:10:43.480006
# Unit test for function box
def test_box():
    assert box(b'moov', b'hello') == b'\x00\x00\x00\x0Emoovhello'
    assert box(b'boox', b'') == b'\x00\x00\x00\x0Cboox'


# Generated at 2022-06-24 12:10:54.915623
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl = YoutubeDL({
        'playlist_items': [
            'PLwP_SiAcdui0KVebT0mU9Apz359a4ubsC',
            'PLwP_SiAcdui1GIm3fAHy3PWxLf9E_uleA',
            'PLwP_SiAcdui0KVebT0mU9Apz359a4ubsC',
            'PLwP_SiAcdui1GIm3fAHy3PWxLf9E_uleA',
        ],
        'playlist_random': True,
    })
    ydl.add_default_info_extractors()

# Generated at 2022-06-24 12:11:06.545252
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test for a video
    for params in ({'track_id': 1, 'fourcc': 'H264', 'codec_private_data': '01640028ffe1001427640028ac2c80808080808080',
                    'width': 400, 'height': 600, 'duration': 10 * 3600, 'nal_unit_length_field': 4},
                   {'track_id': 1, 'fourcc': 'AVC1', 'codec_private_data': '01640028ffe1001427640028ac2c80808080808080',
                    'width': 400, 'height': 600, 'duration': 10 * 3600, 'nal_unit_length_field': 4}):
        result = io.BytesIO()
        write_piff_header(result, params)

# Generated at 2022-06-24 12:11:16.821639
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:26.095458
# Unit test for function box
def test_box():
    assert box(b'moov', b'hello') == b'\x00\x00\x00\x0cmoovhello'
    assert box(b'moov', b'h\xea\x6c\x6c\x6f') == b'\x00\x00\x00\x0cmoovh\xea\x6c\x6c\x6f'
    assert box(b'moov', b'Hello') != b'\x00\x00\x00\x0cmoovhello'
    assert box(b'moov', b'h\xea\x6c\x6c\x6f') != b'\x00\x00\x00\x0cmoovh\xea\x6c\x6c\x6f'

ftyp

# Generated at 2022-06-24 12:11:29.147556
# Unit test for function box
def test_box():
    assert box(b'moov', b'payload') == b'\x00\x00\x00\x0Fmoovpayload'
    assert box(b'payload', b'') == b'\x00\x00\x00\x0Apayload'


# Generated at 2022-06-24 12:11:33.228644
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 20000,
        'sampling_rate': 48000,
        'nal_unit_length_field': 4,
    }
    with open('ismtest.ismv', 'wb') as stream:
        write_piff_header(stream, params)



# Generated at 2022-06-24 12:11:38.200331
# Unit test for function write_piff_header
def test_write_piff_header():
    from .testutils import TMedia
    from .testutils import TFragmentFD
    from ..utils import encode_data_uri
    from ..utils import human_readable_filesize as hrf
    from ..compat import compat_str
    from ..downloader.fragment import FragmentFD

# Generated at 2022-06-24 12:11:47.395350
# Unit test for function full_box
def test_full_box():
    # 1. Testing for all the bytes in the output of the full_box
    # Checks with different values for the flags and version
    output = full_box(b"ftyp", 1 ,0xFFFFFFFF, b"mp42")
    assert binascii.hexlify(output) == b'00000018ftyp01ffffffff00000000000000000000006D703432000000'
    output = full_box(b"moov", 1, 0xFFFFFFF1, b"mp42")
    assert binascii.hexlify(output) == b'00000018moov01fffffff100000000000000000000006D703432000000'
    output = full_box(b"ftyp", 1, 0xFFFFFFF1, b"mp42")

# Generated at 2022-06-24 12:11:59.164397
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:12:03.888015
# Unit test for function box
def test_box():
    assert box(b'mvhd', u32.pack(0) + u16.pack(0) + u16.pack(1)) == b'\x00\x00\x00\x0E' + b'mvhd' + b'\x00\x00\x00\x00' +  b'\x00\x00' + b'\x01\x00'

# ftyp: container: file type and compatibility

# Generated at 2022-06-24 12:12:10.946435
# Unit test for function full_box
def test_full_box():
    assert(full_box(b'moov', 0, 0, b'sample')) == (
        b'\x00\x00\x00\x0fmoov\x00\x00\x00\x00sample')
    assert(full_box(b'moov', 1, 0x1234, b'sample')) == (
        b'\x00\x00\x00\x10moov\x00\x00\x01\x00\x12\x00\x00\x00sample')



# Generated at 2022-06-24 12:12:15.528531
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for non existing file
    if __name__ == '__main__':
        sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
        sys.exit(
            unittest.main(
                testRunner=unittest.TextTestRunner(verbosity=2),
                argv=sys.argv))



# Generated at 2022-06-24 12:12:27.181626
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:12:35.309359
# Unit test for function extract_box_data
def test_extract_box_data():
    # test case
    data = b'\x00\x00\x00\x18' + b'moov' + b'\x00\x00\x00\x04' + b'udta' + b'\x00\x00\x00\x08' + b'\x00\x00\x00\x00' + b'meta'
    box_sequence = (b'udta', b'meta')
    expected = b'\x00\x00\x00\x08' + b'\x00\x00\x00\x00'
    assert(extract_box_data(data, box_sequence) == expected)

    box_sequence = (b'moov', b'udta', b'meta')
    expected = b'\x00\x00\x00\x08'

# Generated at 2022-06-24 12:12:36.066133
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass #TODO



# Generated at 2022-06-24 12:12:45.682555
# Unit test for function extract_box_data
def test_extract_box_data():
    assert 'styp' == extract_box_data(b"\x00\x00\x00\tstypaa", ('styp'))
    assert 'aa' == extract_box_data(b"\x00\x00\x00\fstypaaa\x00\x00\x00\x07stypbb", ('styp', 'styp'))
    assert 'bb' == extract_box_data(b"\x00\x00\x00\x17stypaaa\x00\x00\x00\x0bstypbb\x00\x00\x00\x07stypcc", ('styp', 'styp', 'styp'))

# Generated at 2022-06-24 12:12:58.298109
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..extractor.ism import IsmFD
    from ..utils import _prepare_manifest_url, _get_ism_info_dict

    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

    content = compat_urllib_request.urlopen(manifest_url).read().decode('utf-8')
    smth_url, smth_filename = _prepare_manifest_url(manifest_url, compat_urllib_parse.urlparse(manifest_url).path)
    fd = IsmFD(smth_url, smth_filename, {'nopart': True}, test = True)

# Generated at 2022-06-24 12:13:08.678827
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing method real_download of class IsmFD')

    import os
    from .RtmpFD import RtmpFD
    from .HdsFD import HdsFD

    test_content_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    dest_path = os.path.join(os.path.abspath('.'), 'test.ts')

    if os.path.exists(dest_path):
        os.unlink(dest_path)

    ism_fd = IsmFD(test_content_url)
    ism_fd.real_initialize()

    fd = RtmpFD(test_content_url)
    fd.real_initialize()

# Generated at 2022-06-24 12:13:12.782893
# Unit test for constructor of class IsmFD
def test_IsmFD():
	params = {'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'}
	IsmFD(params).real_download('test_IsmFD', params)
