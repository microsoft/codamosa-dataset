

# Generated at 2022-06-24 12:03:19.552217
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 60 * 60,
        'codec_private_data': '014d401fffe10017674d401967640015674d40256755f01e0c0127f1c08e000000000000000001b008d4019768401c769401876a401976b401c76c4014c4d400430032f01c001e8000000000028ee3c80',
        'width': 1280,
        'height': 720,
        'display_aspect_ratio': 16.0 / 9
    }
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:03:28.166749
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    test_file = 'ismcount.ism/manifest()'
    cached_copy_of_test_file = os.path.join(tempfile.gettempdir(), os.path.basename(test_file))
    try:
        urllib.urlretrieve(test_file, cached_copy_of_test_file)
    except IOError:
        print('Error: can\'t find test file')
        return

    import json
    import hashlib
    import os
    with open(cached_copy_of_test_file) as f:
        playlist_data = json.loads(f.read())
    segments = playlist_data['fragments']
    info_dict = {}
    info_dict['fragments'] = segments[:2]
    info_dict['url'] = playlist_data['url']
   

# Generated at 2022-06-24 12:03:35.781021
# Unit test for function box
def test_box():
    assert(box('mvhd', '\x00' * 108) == '\x00\x00\x00\x6c\x6d\x76\x68\x64\x00\x00\x00\x00' + '\x00' * 100)
if __name__ == '__main__':
    test_box()


# Generated at 2022-06-24 12:03:43.053228
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test the constructor of class IsmFD
    """
    download_params= {
        'fourcc': 'AVC1',
        'codec_private_data': '0401e067ffe100186764001facd941000105600000000168ce0',
        'track_id': 1,
        'timescale': 10000000,
        'duration': 288400000,
        'sampling_rate': 44100,
        'width': 1280,
        'height': 720,
    }
    test_class = IsmFD('sample.ism', 'test.ism', params=download_params)



# Generated at 2022-06-24 12:03:48.975282
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:50.794080
# Unit test for function box
def test_box():
    #print(box(b'\xa9alb', b'\x00'))
    expected_result = u32.pack(9) + b'\xa9alb' + b'\x00'
    result = box(b'\xa9alb', b'\x00')
    assert(result == expected_result)
    return True



# Generated at 2022-06-24 12:04:01.168544
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:11.005894
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov\x14\x00\x00\x00' + \
           b'mvhd\x01\x00\x00\x00' + b'\x01\x02\x03\x04' + b'\x05\x06\x07\x08' + \
           b'trak\x02\x00\x00\x00' + \
           b'tkhd\x02\x00\x00\x00' + b'\x09\x0a\x0b\x0c' + b'\x0d\x0e\x0f\x10' + \
           b'\x11\x12\x13\x14'

# Generated at 2022-06-24 12:04:20.228396
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test_download import _TEST_MANIFEST_CONTENT
    from .test_download import _TEST_MANIFEST_PARAMS
    from .test_download import _TEST_MANIFEST_URL

    from .downloader import YoutubeDL

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    parsed_url = compat_urllib_parse.urlsplit(_TEST_MANIFEST_URL)
    fd = IsmFD(ydl, {})

# Generated at 2022-06-24 12:04:21.880549
# Unit test for function box
def test_box():
    print(box(u32.pack(1), u32.pack(2)))


# Generated at 2022-06-24 12:04:27.883781
# Unit test for function extract_box_data
def test_extract_box_data():
    ftyp_payload = b'isml'  # major brand
    ftyp_payload += u32.pack(1)  # minor version
    ftyp_payload += b'piff' + b'iso2'  # compatible brands
    ftyp = box(b'ftyp', ftyp_payload)
    mvhd_payload = u64.pack(int(time.time()))
    mvhd_payload += u64.pack(int(time.time()))
    mvhd_payload += u32.pack(10000000)
    mvhd_payload += u64.pack(0)
    mvhd_payload += s1616.pack(1)  # rate
    mvhd_payload += s88.pack(1)  # volume

# Generated at 2022-06-24 12:04:34.003215
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00&' + b'moov' + b'\x00\x00\x00$' + b'\x00\x00\x00\x14' + b'\x6d\x6f\x6f\x76' + b'\x00\x00\x00\x08' + b'\x74\x72\x61\x6b' + b'\x00\x00\x00\x0c' + b'\x6d\x64\x69\x61' + b'\x00\x00\x00\x0c' + b'\x6d\x68\x64\x72'

# Generated at 2022-06-24 12:04:36.884034
# Unit test for function box
def test_box():
    assert box('abcd', 'str') == b'\x00\x00\x00\x0b' + b'abcd' + b'str'
# End unit test



# Generated at 2022-06-24 12:04:44.975131
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import std_headers

    params_test = {
        'noplaylist': True,
        'skip_unavailable_fragments': False,
        'test': True,
        'format': 'ism'
    }
    params_real = {
        'noplaylist': True,
        'skip_unavailable_fragments': True,
        'format': 'ism'
    }



# Generated at 2022-06-24 12:04:48.695444
# Unit test for function box
def test_box():
    b = box('moov', '\x00\x00\x00\x00')
    assert b == '\x00\x00\x00\x0cmoov\x00\x00\x00\x00'


# Generated at 2022-06-24 12:04:50.615592
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({}, {}, {}, {})
    assert fd.FD_NAME == 'ism'

# Generated at 2022-06-24 12:05:01.743846
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import shutil
    youtube_dl_path = os.path.dirname(os.path.realpath(__file__))
    shutil.copy(os.path.join(youtube_dl_path, 'tests', 'test.ismv'), os.path.join(youtube_dl_path, 'test.ismv'))
    extractor_class = get_extractor_by_name('ism')
    ie = extractor_class('http://localhost:8080/test.ism/manifest')
    info_dict = ie.extract('http://localhost:8080/test.ism/manifest')
    filename = os.path.join(youtube_dl_path, 'test.mp4')
    IsmFD.real_download(None, filename, info_dict)

# Generated at 2022-06-24 12:05:12.677870
# Unit test for function write_piff_header
def test_write_piff_header():
    with FragmentFD() as stream:
        write_piff_header(stream, { 'track_id': 1, 'duration': 1000000, 'fourcc': 'AACL', 'codec_private_data': '1210', 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100 })

# Generated at 2022-06-24 12:05:19.343003
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD('', {'url': 'http://example.com/manifest.ism', 'ismc_url': 'http://example.com/manifest.ismc'})
    assert test_IsmFD.url == 'http://example.com/manifest.ism'
    assert test_IsmFD.preference == -50
    assert test_IsmFD.extractor_key == 'IsmFD'


# Generated at 2022-06-24 12:05:29.076012
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(_ISM_IE)
    ie.add_info_extractor(_ISML_IE)
    ie.add_info_extractor(_MS_IE)

    url = 'http://mediaplatstorage1.blob.core.windows.net/windows-media-plat/bbb_30fps/bbb_30fps.ism/Manifest'
    fd = ie._download_webpage(url, None, note='Downloading m3u8 information', errnote='unable to download m3u8 information')
    assert(fd.name == 'ism')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:05:37.405683
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:05:45.080024
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {'track_id': 1, 'fourcc': 'H264', 'duration': 10000, 'timescale': 10000000,
            'language': 'eng', 'width': 960, 'height': 540, 'codec_private_data': '014d401fffe10017674d4015f30000aabfbc5b224230ca0c0a0003c80000003008000000300800',
        }
        write_piff_header(stream, params)
        b = stream.getvalue()
        print(len(b))
        print(binascii.hexlify(b))
        assert len(b) == 2237

# Generated at 2022-06-24 12:05:56.164303
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_urlretrieve, compat_kOn_error, compat_kOn_complete
    from ..compat import compat_kOn_progress
    f = io.BytesIO()

# Generated at 2022-06-24 12:05:59.490314
# Unit test for function full_box
def test_full_box():
    assert full_box(b'abcd', 2, 0xFFFFF234, b'\0\0\0\0') == b'\x00\x00\x00\x1Cabcd\x02\xFF\xFF\xF2\x34\0\0\0\0'



# Generated at 2022-06-24 12:06:07.859744
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:06:18.872457
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 250000000,
        'timescale': 25,
        'language': 'und',
        'fourcc': 'H264',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001767640028ac2c80de9010d4f4c074f4c8f40404040404040404020000002990c8000030080000d9ffc50000000168ce3880',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)
    stream.seek(0)
    assert len(stream.read()) == 2348



# Generated at 2022-06-24 12:06:30.286146
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = io.BytesIO()
    # Write a small file with just the Twenkle PIFF header
    write_piff_header(box_data, {'track_id':1, 'fourcc':'H264', 'duration':100, 'timescale':2, 'codec_private_data':'0164001fffe10017674d001cac80001bb800000100000001038014015c6a0a6a8e6fdb1b3c20d50e2d5164567e2ff2f4c4b4ba8414354be162f9ff7e46d1cabffebb554510101000001a000000f2740600052801000100'})
    box_data.seek(0)
    # Get the avcC data

# Generated at 2022-06-24 12:06:40.082199
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x3c\x66\x74\x79\x70'
    data += b'\x69\x73\x6d\x6c\x00\x00\x00\x01'
    data += b'\x00\x00\x00\x00\x69\x73\x6d\x6c'
    data += b'\x69\x73\x6f\x32\x00\x00\x00\x01'
    data += b'\x00\x00\x00\x00\x69\x73\x6d\x6c'
    data += b'\x68\x64\x72\x6c\x00\x00\x00\x0c'

# Generated at 2022-06-24 12:06:47.578341
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00+' + b'moov' + b'\x00\x00\x00\x1C' + b'\x00\x00\x00\x0B' + b'trak' + b'\x00\x00\x00\x08' + b'mdia'
    box_sequence = (b'moov', b'trak', b'mdia')
    assert extract_box_data(data, box_sequence) == b'\x00\x00\x00\x08'
# Extract PIFF fragment box data and fill placeholder data.

# Generated at 2022-06-24 12:06:58.478474
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x0Cmoov\x00\x00\x00\x00'
    assert full_box(b'ftyp', 0, 0, b'') == b'\x00\x00\x00\x0Cftyp\x00\x00\x00\x00'
    assert full_box(b'mp4v', 0, 0, b'') == b'\x00\x00\x00\x0Cmp4v\x00\x00\x00\x00'

# Generated at 2022-06-24 12:07:02.696510
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('http://www.example.com/manifest.ism/manifest', None)
    assert fd.manifest_url == 'http://www.example.com/manifest.ism/manifest'



# Generated at 2022-06-24 12:07:12.168806
# Unit test for function write_piff_header
def test_write_piff_header():
    import unittest
    from ..compat import compat_StringIO, compat_etree_fromstring

    def check_piff_header(root, expected):
        moov = root.find('{urn:mpeg:dash:schema:mpd:2011}MPD')
        moov_ns = moov.nsmap[None]
        print('Moov Namespace: %s' % moov_ns)
        resp = moov.find('{%s}Period/{%s}AdaptationSet/{%s}Representation' % (moov_ns, moov_ns, moov_ns))
        ftyp = resp.find('{%s}SegmentTemplate/{%s}Initialization' % (moov_ns, moov_ns))

# Generated at 2022-06-24 12:07:18.047457
# Unit test for function full_box
def test_full_box():
    assert full_box('\x00\x00\x00\x00', 0, 0, '\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
# End of unit test



# Generated at 2022-06-24 12:07:21.932631
# Unit test for function full_box
def test_full_box():
    assert full_box(b'foo ', 0, 1, b'bar') == b'\x00\x00\x00\x0cfoo \x00\x00\x01bar'


# Generated at 2022-06-24 12:07:26.383512
# Unit test for function box
def test_box():
    assert box('stts', '\x00\x00\x00\x08' + '\x00\x00\x00\x00') == '\x00\x00\x00\x10stts\x00\x00\x00\x08\x00\x00\x00\x00'



# Generated at 2022-06-24 12:07:39.829587
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # test extraction of track_id
    self = IsmFD()
    self.params = {
        'test': True,
    }
    self.params['skip_unavailable_fragments'] = True

# Generated at 2022-06-24 12:07:41.494031
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:07:50.818888
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'format': 'ism',
        'fragments': [
            {
                'url': 'http://host/1.ism/Frag1',
                'duration': 5,
            },
            {
                'url': 'http://host/1.ism/Frag2',
                'duration': 5,
            },
        ]
    }
    temp_dir = tempfile.mkdtemp()
    filename = path.join(temp_dir, 'test.mp4')
    fd = IsmFD(params, filename)
    assert isinstance(fd, IsmFD)
    shutil.rmtree(temp_dir)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:07:56.341541
# Unit test for function box
def test_box():
    assert box(b'mvhd', binascii.hexlify(u32.pack(1))) == (
        b'\x00\x00\x00\x00\x6d\x76\x68\x64\x00\x00\x00\x01')


# Generated at 2022-06-24 12:08:01.157414
# Unit test for function box
def test_box():
    box_type = b'\x66\x6f\x6f'
    payload = b'\x62\x61\x72'
    assert (box(box_type, payload) == b'\x00\x00\x00\x0b' + box_type + payload)



# Generated at 2022-06-24 12:08:04.410658
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    IsmFD().real_download('test', {'fragments':[{'url':'test'}]})



# Generated at 2022-06-24 12:08:15.194009
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:20.340998
# Unit test for function full_box
def test_full_box():
    box_type = b'fTY'
    version = 2
    flags = 123
    payload = b'apl'
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x0cftY' + b'\x02' + b'\x00\x00\x00{' + b'apl'
    print('Function full_box works')

# Generated at 2022-06-24 12:08:29.456941
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:08:33.317944
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == binascii.unhexlify('000000006d6f6f76')
    assert box(b'moov', b'mdat') == binascii.unhexlify('000000046d6f6f76mdat')

# Generated at 2022-06-24 12:08:43.104506
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'H264', 'codec_private_data': '000000016742C00D971D0138C149000001B0', 'duration': 120000, 'width': 640, 'height': 480, 'nal_unit_length_field': 4, 'sampling_rate': 44100, 'channels': 2, 'bits_per_sample': 16}
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:08:45.267065
# Unit test for function box
def test_box():
    return box(b'\x00\x00\x00\x00',b'\x00\x00\x00\x00')



# Generated at 2022-06-24 12:08:54.295725
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    with tempfile.NamedTemporaryFile('w') as f:
        url = 'http://example.com/index.ism'
        fragments = [0, 1]
        info_dict = {
            'headers': {},
            'duration': 100,
            'fragments': fragments,
            '_download_params': {
                'is_audio': True,
                'fourcc': 'AACL',
                'track_id': 1,
                'codec_private_data': 'deadbeef',
                'sampling_rate': 44100,
            },
        }
        fd = IsmFD(url, f, params={})
        fd.real_download(f.name, info_dict)


# Generated at 2022-06-24 12:08:55.632677
# Unit test for function box
def test_box():
    pass


# Generated at 2022-06-24 12:09:05.475984
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import YoutubeDLDownloader
    from .extractor import YoutubeExtractor
    from .extractor.common import InfoExtractor
    from .utils import FileDownloader
    
    info_extractor = YoutubeExtractor()
    downloader = YoutubeDLDownloader(info_extractor)

# Generated at 2022-06-24 12:09:12.216447
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x34ftyp\x00\x00\x02\x00mp42isom\x00\x00\x00\x00'

# Generated at 2022-06-24 12:09:23.157945
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 313245,
        'timescale': 125000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)
    stream.seek(0)

    assert box(b'ftyp', b'isml' + u32.pack(1) + b'piff' + b'iso2') == stream.read(20)  # File Type Box

# Generated at 2022-06-24 12:09:31.453384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test constructor
    ism_fd = IsmFD({
        'fragment-prefix': 'http://example.com/',
        'fragments': [
            "http://example.com/frag1.ism",
            "http://example.com/frag2.ism",
            "http://example.com/frag3.ism",
            "http://example.com/frag4.ism",
            "http://example.com/frag5.ism",
        ],
        'protocol': 'ism',
    })

    assert ism_fd.params['fragment_base_url'] == 'http://example.com/'

# Generated at 2022-06-24 12:09:37.191577
# Unit test for function full_box
def test_full_box():
    version = 0
    flags = 0
    payload = "\x00\x00\x00\x01"

# Generated at 2022-06-24 12:09:43.689820
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('http://manifest', 'http://segment', {'params': {'limit_rate': '256k'}})
    assert fd.rate_limit == 32
    assert fd.retries == 10
    assert fd.fragment_index == 1
    assert fd.fragment_retries == 0
    assert fd.skip_unavailable_fragments == True
    assert fd.test == False
    assert fd.start_offset == 0
    assert fd.end_offset == -1


test_IsmFD()

# Generated at 2022-06-24 12:09:46.213372
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test to confirm that class IsmFD can be instantiated
    IsmFD({})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:09:53.959494
# Unit test for function full_box
def test_full_box():
    payload = u32.pack(0)
    box = full_box(b'ftyp', 0, 1, payload)
    box_size = u32.unpack(box[:4])[0]
    assert box_size == 12
    assert box[4:8] ==  b'ftyp'
    assert box[8] == 0
    assert box[9] == 0
    assert box[10] == 0
    assert box[11] == 1
    assert box[12] == 0
    assert box[13] == 0
    assert box[14] == 0
    assert box[15] == 0

# Generated at 2022-06-24 12:10:04.764224
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 1000,
        'width': 1920,
        'height': 1088
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:10:15.299534
# Unit test for function extract_box_data
def test_extract_box_data():
    import re

# Generated at 2022-06-24 12:10:18.510595
# Unit test for function box
def test_box():
    payload = b''
    assert box(b'moov', payload) == b'\x00\x00\x00\x08moov' + payload
# End of unit test



# Generated at 2022-06-24 12:10:23.706095
# Unit test for function box
def test_box():
    assert (box('moov', 'payload') == b'\x00\x00\x00\x0fp\xaayload')



# Generated at 2022-06-24 12:10:28.032166
# Unit test for function full_box
def test_full_box():
    f = io.BytesIO()
    f.write(full_box(b'moov', 0, 0, ''))
    assert f.getvalue() == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 12:10:35.513335
# Unit test for function full_box
def test_full_box():
    assert isinstance(full_box('ftyp', 1, 0x000001, b'\x00\x00\x00\x00'), bytes)
    assert full_box('ftyp', 1, 0x000001, b'\x00\x00\x00\x00') == \
        b'\x00\x00\x00\x18ftyp\x01\x00\x00\x00\x00\x00\x00\x00'    

MOOV_BOX = b'moov'
MVHD_BOX = b'mvhd'
TRAK_BOX = b'trak'
TKHD_BOX = b'tkhd'
EDTS_BOX = b'edts'
ELST_BOX = b'elst'
MDIA_BOX = b'mdia'
MDHD_

# Generated at 2022-06-24 12:10:40.914102
# Unit test for function box
def test_box():
    exp = ''.join([u32.pack(8+len(payload))+box_type+payload for (box_type, payload) in [('a','b'),('c','d')]])
    ret = box('a', 'b') + box('c', 'd')
    assert exp == ret


# Generated at 2022-06-24 12:10:45.233870
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Invoke constructor of Class IsmFD
    """
    IsmFD('http://video.univision.com/media/hls/live/live3420/live3420.m3u8?channel=m3u8&type=live')


# Generated at 2022-06-24 12:10:55.227240
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as buf:
        write_piff_header(buf, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': int(10 * 1.0 / 15),
            'sampling_rate': 44100,
            'nal_unit_length_field': 4,
            'codec_private_data': '67640019ac580a00f51ffbe0700000030080000300c0000096038000003002e2e9078c',
        })
        buf.seek(38)
        assert buf.read(4) == b'soun'
        buf.seek(108)
        assert buf.read(4) == b'avc1'

# Generated at 2022-06-24 12:11:01.916601
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:14.086407
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()

# Generated at 2022-06-24 12:11:21.502191
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import *
    from .mp4 import *
    from .fragment import *
    from collections import OrderedDict
    params = OrderedDict()
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 10000000
    params['timescale'] = 10000000

# Generated at 2022-06-24 12:11:28.919660
# Unit test for function write_piff_header
def test_write_piff_header():
    s = io.BytesIO()
    write_piff_header(s, {
        'track_id':1,
        'duration':2400,
        'timescale':48000,
        'width':1920,
        'height':1080,
        'sampling_rate':48000,
        'fourcc':'H264',
        'codec_private_data':'01640033acac80854c5c5cf5',
    })

# Generated at 2022-06-24 12:11:36.145974
# Unit test for constructor of class IsmFD
def test_IsmFD():
    #print('test_IsmFD()')
    import xbmc
    from .downloader import GetFile
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .player import DummyPlayer

    try:
        from .HttpFD import test_HttpFD
    except:
        import HttpFD
        test_HttpFD = HttpFD.test_HttpFD

    url_a = 'http://abc.com/video.ism/manifest(fragmentTime=10)'
    dash_test_lst = [
        # test1:
        # 1. test http
        {
            'url_a': url_a,
        },
    ]

    dash_test_lst[0].update(GetFile.parse_ism_url(url_a))

    dash_test_l

# Generated at 2022-06-24 12:11:42.306293
# Unit test for function extract_box_data
def test_extract_box_data():
    mdat_data = b'mdat' + u32.pack(0)
    moof_data = b'moof' + u32.pack(8 + len(mdat_data)) + mdat_data
    ftyp_data = b'ftyp' + u32.pack(8 + len(moof_data)) + moof_data
    assert extract_box_data(ftyp_data, (b'moof', b'mdat')) == mdat_data


# Generated at 2022-06-24 12:11:42.777480
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True


# Generated at 2022-06-24 12:11:48.212856
# Unit test for function full_box
def test_full_box():
    assert full_box('abcd', 0, 0, b'xyz') == b'\x00\x00\x00\x0babcd\x00\x00\x00\x00xyz'
    assert full_box('abcd', 1, 0, b'xyz') == b'\x00\x00\x00\x0babcd\x01\x00\x00\x00xyz'
    assert full_box('abcd', 1, 0xabcd, b'xyz') == b'\x00\x00\x00\x0babcd\x01\xab\xcd\x00xyz'

# Generated at 2022-06-24 12:11:57.488766
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    temp_filename = tempfile.mktemp()

# Generated at 2022-06-24 12:12:05.744607
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import fake_filesystem
    import fake_filesystem_shutil
    import fake_tempfile
    import tempfile

    filename = sys.path[0] + '/test.ismv'

    # Fake 'os', 'io' and 'shutil' modules.
    fake_os = fake_filesystem.FakeOsModule(fake_filesystem.FakeFileOpen(fake_filesystem.FakeFile))
    fake_io = fake_filesystem.FakeOsModule(fake_filesystem.FakeFileOpen(fake_filesystem.FakeFile))
    fake_shutil = fake_filesystem.FakeOsModule(fake_filesystem_shutil.FakeShutilModule, wrap_stream=True)
    fake_tempfile = fake_filesystem.FakeOsModule(fake_tempfile.FakeTempfileModule)

# Generated at 2022-06-24 12:12:13.967002
# Unit test for function full_box
def test_full_box():
    box_type = b"foob"
    version = 0
    flags = 0
    payload = b"foobar"
    result = full_box(box_type, version, flags, payload)
    expect_result = b'\x00\x00\x00\x10foob\x00\x00\x00\x00foobar'
    if result != expect_result:
        print("Expect " + str(expect_result) + " but get " + str(result))
        return False
    return True
#print("test_full_box: " + str(test_full_box()))


# Generated at 2022-06-24 12:12:20.736464
# Unit test for function extract_box_data
def test_extract_box_data():
    from .fragment import PssHdlrStream
    from ..compat import compat_urllib_parse_urlparse
    from ..downloader.http import HttpFD

# Generated at 2022-06-24 12:12:25.694396
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'') == b'\x00\x00\x00\x0C\x6d\x76\x68\x64\x00\x00\x00\x00'



# Generated at 2022-06-24 12:12:29.819363
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {}
    info_dict['fragments'] = []
    info_dict['_download_params'] = {}
    params = {}
    testIsmFD = IsmFD(info_dict, params)
    assert('IsmFD' in testIsmFD.FD_NAME)


# Generated at 2022-06-24 12:12:41.488869
# Unit test for function write_piff_header
def test_write_piff_header():
    import collections
    import io
    fd = io.BytesIO()
    params = collections.OrderedDict([
        ('track_id', 2),
        ('fourcc', 'AACL'),
        ('duration', 10000),
        ('sampling_rate', 44100),
        ('timescale', 44100),
        ('bits_per_sample', 16),
        ('channels', 2),
    ])
    write_piff_header(fd, params)

# Generated at 2022-06-24 12:12:43.117279
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'



# Generated at 2022-06-24 12:12:49.964547
# Unit test for function extract_box_data
def test_extract_box_data():
    ftyp = box(b'ftyp', b'')
    moov = box(b'moov', b'')
    mdat = box(b'mdat', b'')
    data = ftyp + moov + mdat
    assert extract_box_data(data, (b'moov',)) == b''
test_extract_box_data()



# Generated at 2022-06-24 12:12:52.202883
# Unit test for function full_box
def test_full_box():
    assert full_box('ftyp', 1, 2, 'helloworld') == b'\x00\x00\x00\x10ftyp\x01\x00\x02\x00helloworld'



# Generated at 2022-06-24 12:12:55.995495
# Unit test for function box
def test_box():
    assert b' \x00\x00\x00hello' == box(b' ', b'hello')



# Generated at 2022-06-24 12:13:02.386292
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 0, b'\x00') == binascii.unhexlify('00000014000000006d6f6f76010000000000')



# Generated at 2022-06-24 12:13:10.399425
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-24 12:13:19.630843
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL({})
    ydl.process_ie_result(
        {'id': 'test1', 'url': 'http://example.org/',
         'fragments': [{'url': 'http://example.org/segment1.ism/QualityLevels(40000)/Fragments(audio=0,format=mp4a.40.2,vide=0)', 'length': '1'}],
         '_download_params': {'track_id': 1, 'fourcc': 'AACL', 'bits_per_sample': 16, 'samplie_rate': 48000, 'channels': 2, 'duration': 10000000, 'codec_private_data': '', 'language': 'eng'}})
    info_dict = ydl.prepare_filename(ydl.result)
    f