

# Generated at 2022-06-24 12:03:19.784077
# Unit test for function write_piff_header
def test_write_piff_header():
    import subprocess
    from ..utils import (
        encode_data_uri,
        update_url_query,
    )

    ism_url = 'http://127.0.0.1:0/'

    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 65536,
        'height': 0,
        'width': 0,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)

    piff_header_data = stream.getvalue()

# Generated at 2022-06-24 12:03:27.444086
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class args:
        pass

    my_args = args()
    my_args.url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest?format=mpd-time-csf&amp;amp;amp;mpd=1800&amp;amp;amp;time=00:00:00&amp;amp;amp;rate=800000"
    my_args.outtmpl = "test.ism"
    my_args.test = True
    ism_fd = IsmFD(my_args, None)

# Generated at 2022-06-24 12:03:31.213798
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    res = IsmFD.real_download('filename', {
        'fragments': [
            {'url': 'url1'},
            {'url': 'url2'},
            {'url': 'url3'},
        ]
    })
    assert(res is True)
# Test method real_download of class IsmFD
# test_IsmFD_real_download()



# Generated at 2022-06-24 12:03:38.427793
# Unit test for function write_piff_header
def test_write_piff_header():
    # Video
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'width': 400,
        'height': 300,
        'sampling_rate': 25,
        'codec_private_data': '0164001fffe100176764001facd9412e994c20300',
        'nal_unit_length_field': 4,
    })

# Generated at 2022-06-24 12:03:39.996600
# Unit test for function box
def test_box():
    u32.pack(8+len('1234567890')) == box_type()


# Generated at 2022-06-24 12:03:47.036275
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:50.613952
# Unit test for function box
def test_box():
    assert box('b\x00\x00\x00', b'XXXX') == b'\x00\x00\x00\nXXXX'



# Generated at 2022-06-24 12:03:51.189389
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:04:00.279920
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import sys
    import tempfile
    from ..utils import (
        decode_mp4,
    )
    test_expect = os.path.join(os.path.dirname(__file__), 'data', 'test.hex')
    test_actual = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-24 12:04:08.949336
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = "http://ams-i.akamaihd.net/hls/live/221431/aljazeera_eng/AJAMStreaming-SD/1.m3u8"
    params = {
        'format_id': 'hls_variant_native',
        'skip_unavailable_fragments': True,
        'fragment_retries': 0,
        'fragment_timeout': 10,
        'test': False,
        'keep_fragments': False,
    }
    params.update(url_result)

    ctx = {
        'filename': 'test_IsmFD_real_download',
        'total_frags': 10,
    }
    from sys import stderr as stderr_
    ctx['dest_stream'] = stderr_



# Generated at 2022-06-24 12:04:19.144681
# Unit test for function extract_box_data
def test_extract_box_data():
    import binascii
    box_data = b'%'  # binary data with \x prefix
    box_data = binascii.unhexlify(box_data)
    box_data = box(b'mdat', box_data)
    box_data = box(b'ftyp', b'piff' + b'piff' + b'piff' + b'piff' + b'piff') + box_data
    box_data = box(b'moov', b'ftyp' + b'free' + box_data)
    data_reader = io.BytesIO(box_data)
    box_sequence = (b'moov', b'mdat')
    box_data = extract_box_data(box_data, box_sequence)
    assert box_data == b'ftyp' + b

# Generated at 2022-06-24 12:04:29.062148
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    url = 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/akfire-ia801402-its-a-feast/akfire-ia801402-its-a-feast-2733616/master.m3u8'
    fd = IsmFD(ydl=ydl, params=ydl.params, info_dict={'fragments': [{'url': url}], '_download_params': {}})
    filename = '/tmp/test_ism.ism'
    success = fd.real_download(filename, {'fragments': [{'url': url}], '_download_params': {}})

# Generated at 2022-06-24 12:04:39.592877
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    _filename = "vince.ism.mp4"

# Generated at 2022-06-24 12:04:42.570372
# Unit test for function full_box
def test_full_box():
    test_payload = ' '
    assert full_box('moov', 0, 0, test_payload) == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00  '
    

# Generated at 2022-06-24 12:04:49.234929
# Unit test for function write_piff_header
def test_write_piff_header():
    from .hls import HLSStreamWriter
    from .muxer import Muxer
    from .utils import setproctitle, get_args
    from ..utils import parse_codecs
    import contextlib
    import requests

    setproctitle('youtube-dl-ts.test_write_piff_header')

# Generated at 2022-06-24 12:04:49.725018
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-24 12:04:54.521559
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:05:01.941513
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    if not os.path.exists('piffs'):
        os.mkdir('piffs')
    params = {}
    tempfilename = 'piffs/test_write_piff_header.ismv'
    with io.open(tempfilename, 'wb') as stream:
        write_piff_header(stream, params)
    if os.path.exists(tempfilename):
        os.remove(tempfilename)
    else:
        raise Exception('Test failed')



# Generated at 2022-06-24 12:05:09.363789
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    '''
    Unit test function for IsmFD real_download method
    '''
    params = {'skip_unavailable_fragments': True,
              'restrictfilenames': True,
              'outtmpl': '%(id)s.%(ext)s'}
    from ydl_junkyard.extractor import youtube
    ie = youtube.YoutubeIE()
    yt_info = ie._real_extract(
        'https://www.youtube.com/watch?v=J---aiyznGQ')

# Generated at 2022-06-24 12:05:19.912767
# Unit test for function extract_box_data
def test_extract_box_data():
    def _test_extract_box_data(box_data, box_sequence, expected_data):
        box_data = binascii.unhexlify(box_data.replace(' ', '').encode('ascii'))
        box_sequence = [part.encode('ascii') for part in box_sequence.split()]
        expected_data = binascii.unhexlify(expected_data.replace(' ', '').encode('ascii'))
        assert extract_box_data(box_data, box_sequence) == expected_data


# Generated at 2022-06-24 12:05:25.482352
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import FFmpegPostProcessor
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    from .postprocessor import get_postprocessor
    from .YoutubeDL import YoutubeDL
    from .compat import urlopen
    from .utils import UpdateChecker
    from .cache import Cache

    def _download_with_interstitial(ydl_or_ie, info_dict):
        """
        Fake download function that adds a stalling interstitial page
        """
        html = 'TEST INTERSTITIAL PAGE'
        ie = ydl_or_ie
        if not isinstance(ie, InfoExtractor):
            ie = ydl_or_ie._ies[-1]
        if ie.IE_NAME != 'generic':
            raise ValueError('Only generic extractor is allowed')
        ie._

# Generated at 2022-06-24 12:05:35.087123
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Test method real_download of class IsmFD.
    """
    # Setup
    video = video_description('flv720')
    video.codec_private_data = '0142c01effe10011674d401f9a42e001ffff'
    video_info = {
        'width': 1280,
        'height': 720,
        'duration': 23.973,
        'resolution': None,
        'filesize': None,
        'bitrate': None,
        'fourcc': 'H264',
        'video': video,
        'audio': None,
    }

# Generated at 2022-06-24 12:05:36.597242
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_IsmFD_real_download.real_download_called = True
    return True


# Generated at 2022-06-24 12:05:44.449279
# Unit test for function extract_box_data
def test_extract_box_data():
    root_type = 'root'
    root_seq_type = 'root-seq'
    entry_type = 'entry'
    entry_seq_type = 'entry-seq'
    text_type = 'text'
    entries_count = 3
    entries = [u32.pack(8) + entry_type + u32.pack(8) + text_type + b'text'] * 3
    entries = b''.join(entries)
    seq_box = u32.pack(8 + len(entries)) + root_seq_type + entries
    root_box = u32.pack(8 + len(seq_box) + 8) + root_type + seq_box + u32.pack(8) + entry_type + u32.pack(8) + text_type + b'text'
    extract_res = extract_box

# Generated at 2022-06-24 12:05:48.090212
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234') == b'\x00\x00\x00\x0cabcd1234'


# Generated at 2022-06-24 12:05:54.851910
# Unit test for constructor of class IsmFD
def test_IsmFD():
    parameters = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 100000,
        'sampling_rate': 44100,
        'codec_private_data': '1210',
        'nal_unit_length_field': 4,
    }

    output_stream = io.BytesIO()

    write_piff_header(output_stream, parameters)
    values = output_stream.getvalue()
    print (values)


# Generated at 2022-06-24 12:05:59.009208
# Unit test for function box
def test_box():
    assert box(b'moov', b'123') == b'\x00\x00\x00\x0cmoov123'


# Generated at 2022-06-24 12:06:07.601248
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('Testing IsmFD constructor...')
    print('To test this, you need to have a ISM manifest file called \'ism_manifest.txt\'.')
    print('The file should contain the path to the ISM manifest, starting from \'http://[IP]:[PORT]/Common/\'. e.g.:')
    print('/root/smooth/Test.ism/Manifest')
    print('and a URL prefix, e.g.:')
    print('http://[IP]:[PORT]/Common/')
    file = open('ism_manifest.txt', 'r')
    prefix = file.readline()
    manifest_path = file.readline()
    print('Prefix: ' + prefix)
    print('Manifest path: ' + manifest_path)
    url = prefix + manifest_path

# Generated at 2022-06-24 12:06:18.115077
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00' * 8 + b'\x01' * 8 + b'\x00' * 8
    assert extract_box_data(data, (b'\x00\x00\x00\x08', b'\x01\x00\x00\x00')) == b'\x01\x00\x00\x00'
    data = b'\x00' * 12 + b'\x01' * 4 + b'\x00' * 8
    assert extract_box_data(data, (b'\x00\x00\x00\x0c', b'\x01\x00\x00\x00')) == b'\x01\x00\x00\x00'



# Generated at 2022-06-24 12:06:42.721858
# Unit test for function box
def test_box():
    byte = box('moof', 'foom')
    assert byte == b'\x00\x00\x00\x0cmooffoom'


# Generated at 2022-06-24 12:06:51.240461
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:06:57.392345
# Unit test for function full_box
def test_full_box():
    assert full_box('mvhd', 0, 0, 'payload') == '\x00\x00\x00\x1C'\
											'mvhd'\
											'\x00'\
											'\x00\x00\x00'\
											'payload'


# Generated at 2022-06-24 12:07:08.710694
# Unit test for function write_piff_header
def test_write_piff_header():

    def _mock_read(num_bytes):
        return b"\x00" * num_bytes

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'eng',
        'height': 390,
        'width': 640,
        'bits_per_sample': 16,
        'channels': 2,
        'sampling_rate': 44100,
    }

    result = io.BytesIO()
    write_piff_header(result, params)

    # fast check of result
    mfhd_payload = u32.pack(1)
    mfhd_payload += u32.pack(0)

# Generated at 2022-06-24 12:07:20.916027
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:07:31.024270
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:07:36.443196
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'  # empty ftyp box
    assert extract_box_data(box_data, [b'ftyp']) == b''
    
    box_data = b'\x14\x00\x00\x00' + b'moov' + b'\x00\x00\x00\x00'  # empty moov box
    assert extract_box_data(box_data, [b'moov']) == b'\x00\x00\x00\x00'
    

# Generated at 2022-06-24 12:07:54.770463
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:00.889066
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test case #1
    filename = 'videos/list/manifest.ismv'

# Generated at 2022-06-24 12:08:04.271007
# Unit test for constructor of class IsmFD
def test_IsmFD():
    w = IsmFD({})
    assert w.supported()
    assert w.url_result('http://example.com/media.ism')
    assert not w.url_result('http://example.com/media.ssm')


# Generated at 2022-06-24 12:08:15.378946
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(
            f, {
                'track_id': 1,
                'fourcc': 'AACL',
                'duration': 0,
                'sampling_rate': 44100,
                'channels': 2,
                'bits_per_sample': 16,
            })
        print(binascii.hexlify(f.getvalue()))
        f.seek(0)

# Generated at 2022-06-24 12:08:24.746311
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = io.BytesIO()
    test_data.write(u32.pack(8))
    test_data.write(b'box1')
    test_data.write(u32.pack(16))
    test_data.write(b'box1.1')
    test_data.write(u32.pack(16))
    test_data.write(b'box2')
    test_data.write(u32.pack(16))
    test_data.write(b'box2.1')
    test_data.write(u32.pack(16))
    test_data.seek(0)
    res = extract_box_data(test_data.read(), (b'box1',))
    assert res == (u32.pack(16) + b'box1.1')

# Generated at 2022-06-24 12:08:35.168977
# Unit test for function write_piff_header
def test_write_piff_header():
    func_name = 'test_write_piff_header'
    print('TEST::{}'.format(func_name))
    stream = io.BytesIO()

# Generated at 2022-06-24 12:08:38.125584
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD({'test' : 'True'}, {'fragments' : ['segment0', 'segment1']})
    print(test_IsmFD)

# Generated at 2022-06-24 12:08:39.863196
# Unit test for function full_box
def test_full_box():
    print(full_box(b'test', 1, 0, b'test'))


# Generated at 2022-06-24 12:08:45.486541
# Unit test for function box
def test_box():
    content = b"\x00\x00\x00\x00\x00\x00\x00\x00" + \
              b"abcdabcdabcdabcd" + b"\x00\x00\x00\x08" + \
              b"abcdabcdabcdabcd"
    assert box(b"abcdabcdabcdabcd", b"abcdabcdabcdabcd") == content


# Generated at 2022-06-24 12:08:54.523652
# Unit test for function write_piff_header
def test_write_piff_header():
    # Note: We assume codec_private_data is a hex string
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 0,
        'timescale': 10000,
        'width': 480,
        'height': 272,
        'codec_private_data': '01640029ffe100968274002a9d90000019f90880039000c400b6025c1d81',
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:09:00.353971
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import requests
    import urllib.parse
    import shutil
    import os

    # 対象URLを取得する
    url = 'http://www.youtube.com/watch?v=DwZ7Y1AJ6SQ'
    # video_idの取得
    video_id = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['v'][0]
    # URLからタイトルを取得する
    title = YoutubeDL(params={'skip_download': True}).extract_info(url, download=False)['title']
    # cookieを取得する
    cookie = requests.get(url).cookies

    # 読み込みモードで

# Generated at 2022-06-24 12:09:07.914622
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='wb', prefix='piff-', suffix='.mp4') as tmp_file:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 60000000,
            'timescale': 10000000,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
            'codec_private_data': 'ff',
            'height': 0,
            'width': 0,
            'language': 'eng'
        }
        write_piff_header(tmp_file, params)


# Generated at 2022-06-24 12:09:14.607336
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.compat import io
    from youtube_dl.extractor import common as extractor
    from youtube_dl.utils import ISM_REGEX
    import youtube_dl.utils
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    import binascii
    # Testing real_download with a sample fragment
    ismFD = IsmFD()

# Generated at 2022-06-24 12:09:18.658226
# Unit test for function box
def test_box():
    assert(box(u32.pack(0x6C6D7668), u32.pack(0)) == u32.pack(8) + u32.pack(0x6C6D7668) + u32.pack(0))


# Generated at 2022-06-24 12:09:28.684929
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys
    import json
    import re
    import base64

    if len(sys.argv) < 4:
        print('usage: %s manifest-url output-file video-id [track-id]' % sys.argv[0])
        sys.exit(0)

    manifest_url = sys.argv[1]
    output_filename = sys.argv[2]
    video_id = sys.argv[3]

    track_id = None
    if len(sys.argv) >= 5:
        track_id = sys.argv[4]

    print('Manifest URL: ', manifest_url)
    print('Output file: ', output_filename)
    print('Video id: ', video_id)
    if track_id:
        print('Track id: ', track_id)

# Generated at 2022-06-24 12:09:33.795272
# Unit test for function full_box
def test_full_box():
    print(full_box(b'moov', 1, 0, b""))
# End of unit test



# Generated at 2022-06-24 12:09:45.075348
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:50.851935
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest_url = "http://manifest.us.llnw.net/{0}/1395129/1395129.isml/manifest"
    content_id = '1395129'
    fd = IsmFD(content_id, manifest_url)
    fd.real_download("file.mp4", fd.manifest_data)


test_IsmFD_real_download()

 

# Generated at 2022-06-24 12:09:52.380129
# Unit test for function write_piff_header
def test_write_piff_header():
    # TODO: implement unit test
    pass

# Generated at 2022-06-24 12:09:54.854342
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0x0, 0x0, b'') == b'\x00\x00\x00\x10moov\x00\x00\x00\x00'



# Generated at 2022-06-24 12:09:56.626273
# Unit test for function full_box
def test_full_box():
    print(full_box(b'abcd',1,0,b'1234'))


# Generated at 2022-06-24 12:10:03.091494
# Unit test for function extract_box_data
def test_extract_box_data():
    data = (b'dinf'
            b'\x00\x00\x00\x20'
            b'url '
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x01'
            b'DREF'
            b'\x00\x00\x00\x1c'
            b'url '
            b'\x00\x00\x00\x01'
            b'DREF'
            b'\x00\x00\x00\x00'
            b'    ')
    output_data = extract_box_data(data, (b'dinf', b'DREF'))
    assert output_data == b'\x00\x00\x00\x00'

# Generated at 2022-06-24 12:10:05.516609
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = IsmFD({}, {})
    assert downloader.FD_NAME == 'ism'


# Generated at 2022-06-24 12:10:17.083318
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    f = FragmentFD(io.BytesIO())

# Generated at 2022-06-24 12:10:22.862018
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = binascii.unhexlify(b'0000003c69736d6c00000001000000006176633100000030000000f4240200000003b80000001000000000e2346000003b9e812b')
    assert extract_box_data(test_data, (b'ftyp', b'avc1', b'avcC')) == binascii.unhexlify(b'00000001284d56e5dc110000000101000003000100000300010000006b40281448')



# Generated at 2022-06-24 12:10:30.262312
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:43.291198
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:10:54.637279
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    with tempfile.TemporaryFile() as f:
        write_piff_header(f, {'track_id': 1, 'fourcc': 'H264', 'codec_private_data': '01640028ffe100197272796dc588088000001b079d9ceec000000300c8000001b0715ba11c000003d0', 'duration': 11678700, 'nal_unit_length_field': 4, 'height': 640, 'width': 360, 'timescale': 10000000, 'sampling_rate': 44100, 'channels': 2, 'bits_per_sample': 16})
        assert f.tell() == 754



# Generated at 2022-06-24 12:11:06.610172
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD_class(IsmFD):
        def download(self, filename, info_dict):
            return True

    params = {
        'url': 'http://mediaplatstorage5.blob.core.windows.net/hb-isa/hb-isa.ism/Manifest?sr=b&sv=2012-02-12&si=a2&sig=%2Bw7f0nRKk%2FgWIRcQ4YV9X6C%2FVqZ6@SZ6VpUaPc%3D&se=2014-08-31T17:51:04Z&sp=r',
        'test': True,
        'track': 9,
    }
    ism = IsmFD_class(params)
    return True

# Generated at 2022-06-24 12:11:17.000444
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test_utils import assert_raises_regexp
    from .test_utils import setup_test_download_directory
    from .test_utils import get_test_cases
    from .test_utils import get_test_templates
    from .test_utils import remove_test_downloaded_files

    download_dir, tmp_dir, _ = setup_test_download_directory()
    test_cases = get_test_cases('testcases/testdata/fragments/')
    test_templates = get_test_templates('testcases/testdata/fragment_downloader/')

    def _test(testcase, template, **download_kwargs):
        source = test_cases[testcase]
        template = test_templates[template]

# Generated at 2022-06-24 12:11:19.752191
# Unit test for function box
def test_box():
    assert(box('a', 'b') == b'\x00\x00\x00\x0aab')



# Generated at 2022-06-24 12:11:25.516117
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .youtube_dl.extractor.mixcloud import MixcloudIE
    extractor = MixcloudIE({})
    url = 'https://www.mixcloud.com/latinas/latinas-e-seus-amigos-novembro-de-2019/'
    extractor.url = url
    extractor._real_extract()
    for entry in extractor.FORMATS:
        fd = IsmFD(entry['url'], entry, None, None, None)
        url = entry['url']
        fd._download_webpage(url, u'Unable to download webpage')
        fd._real_download(u'http://127.0.0.1/test.ism', extractor.info_dict)
test_IsmFD_real_download.skip = 'not implemented'



# Generated at 2022-06-24 12:11:28.206973
# Unit test for function full_box
def test_full_box():
    assert full_box(b'ftyp', 0, 0, b'isom') == b'\x00\x00\x00\x0cftyp\x00isom'


# Generated at 2022-06-24 12:11:29.258654
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass # TODO: write unit test


# Generated at 2022-06-24 12:11:32.326722
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    test class IsmFD
    """
    fd = IsmFD(None)
    print('IsmFD test completed successfully')


if __name__ == '__main__':
    """
    main function
    """
    test_IsmFD()

# Generated at 2022-06-24 12:11:44.961085
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 1, 'duration': 57000000000, 'fourcc': 'H264', 'sampling_rate': 1, 'bits_per_sample': 16, 'height': 1080, 'codec_private_data': '69643f973e753938ec99148e09061e0c0164002cac0bcc380b584e1313100000428de0f5d83f5dc17000001674d4011c28ee45d9'}
    write_piff_header(stream, params)
    result = stream.getvalue()

# Generated at 2022-06-24 12:11:57.120233
# Unit test for function extract_box_data
def test_extract_box_data():
    data = io.BytesIO()
    fourcc = 'avc1'

# Generated at 2022-06-24 12:11:59.570855
# Unit test for function write_piff_header
def test_write_piff_header():
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)


# Generated at 2022-06-24 12:12:07.352809
# Unit test for function extract_box_data
def test_extract_box_data():
    from .m3u8.piff import extract_box_data

# Generated at 2022-06-24 12:12:09.664216
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'


# Generated at 2022-06-24 12:12:18.024576
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = u32.pack(0x18) + b'moov' + u32.pack(0x10) + b'mvhd' + u32.pack(0) * 5
    assert extract_box_data(test_data, (b'mvhd', )) == u32.pack(0) * 5
    assert extract_box_data(test_data, (b'mvhd', b'xyz')) == u32.pack(0) * 5
    assert extract_box_data(test_data, (b'xyz', b'mvhd')) == u32.pack(0) * 5
    assert extract_box_data(test_data, (b'xyz', b'xyz')) is None



# Generated at 2022-06-24 12:12:20.601161
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-24 12:12:26.759417
# Unit test for constructor of class IsmFD
def test_IsmFD():
    global ismfd
    ismfd = IsmFD(params=None)
    assert ismfd is not None
    print("The object is successfully created")
    return ismfd

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:12:35.456555
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile

    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 1000,
        'width': 1280,
        'height': 720,
        'time_scale': 25,
        'codec_private_data': u'000000016764001eac2b4014228012a4d40248d9f7a42c0',
    }

    f = io.BytesIO()
    write_piff_header(f, params)
    result = f.getvalue()

    f = open(tempfile.mktemp(suffix='.ismv'), 'wb')
    write_piff_header(f, params)
    f.close()

    # print result.encode('hex')


# Generated at 2022-06-24 12:12:45.673271
# Unit test for function extract_box_data
def test_extract_box_data():
    def get_box_data(data, box_type):
        return extract_box_data(data, [box_type])

    # Example data taken from
    # https://developer.apple.com/library/content/documentation/QuickTime/QTFF/QTFFChap2/qtff2.html#//apple_ref/doc/uid/TP40000939-CH204-SW1
    data_reader = io.BytesIO(
        b'\x00\x00\x00\x1c'  # box size
        b'test'  # box type
        b'\x00\x00\x00\x08'  # box size
        b'\x00\x00\x00\x04'  # test subbox size
        b'stst'  # test subbox type
    )

# Generated at 2022-06-24 12:12:51.265353
# Unit test for function box
def test_box():
    assert(box('avc1', '') == binascii.unhexlify('00000010 61766331'))
# End test_box


# Generated at 2022-06-24 12:12:57.689002
# Unit test for function full_box
def test_full_box():
    assert full_box('avc1', 1, 2, 'test') == binascii.unhexlify('0000000C77617663310000000001000474657374')
    assert full_box('free', 0, 0, 'test') == binascii.unhexlify('000000046665656574657374')



# Generated at 2022-06-24 12:13:08.684576
# Unit test for function extract_box_data
def test_extract_box_data():
    fd = FragmentFD(None, 'Dash', '0')
    fd.headers = {}
    fd.headers['Content-Type'] = 'video/mp4'
    fd.download(None)
    box_data = extract_box_data(
        fd.read(float('inf')),
        ('moov', 'mvex', 'trex')
    )
    assert len(box_data) == 32
    assert u32.unpack(box_data[0:4])[0] == 0x12
    assert u32.unpack(box_data[4:8])[0] == 0x1
    assert u32.unpack(box_data[8:12])[0] == 0x0