

# Generated at 2022-06-24 12:03:19.138762
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .smoothstreams import SmoothstreamsFD
    assert issubclass(SmoothstreamsFD, IsmFD)
    assert issubclass(IsmFD, FragmentFD)

    # Test constructor with required arguments
    IsmFD({'url': 'http://example.com'})

    # Test constructor with all arguments
    params = {
        'url': 'http://example.com',
        'filename': 'test.ism',
        'referrer': 'http://example.com',
        'test': True,
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'youtube_include_dash_manifest': True,
        'expected_status': (200, 206),
        'required_version': '2018.10.18',
    }

# Generated at 2022-06-24 12:03:27.867058
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:35.336721
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'codec_private_data': '',
        'duration': int(29.988 * 10000000),
    }

    write_piff_header(stream, params)
    output = stream.getvalue()
    assert len(output) == 296



# Generated at 2022-06-24 12:03:37.112741
# Unit test for function box
def test_box():
    assert u32.pack(8 + len([payload]) == 4 + [box_type]) + [box_type] + [payload]


# Generated at 2022-06-24 12:03:44.258634
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = b'\x00\x00\x00\x10aaaaaaaa'
    assert extract_box_data(box_data, (b'aaaa',)) == b'aaaa'
    assert extract_box_data(box_data, (b'aaaa', b'aaaa')) is None
    box_data = b'\x00\x00\x00\x10aaaaaaaa\x00\x00\x00\x18bbbbbbbbbbbbbbbb'
    assert extract_box_data(box_data, (b'aaaa', b'bbbb')) == b'bbbbbbbbbbbbbbbb'



# Generated at 2022-06-24 12:03:53.279367
# Unit test for function full_box
def test_full_box():
    box_type = "mvhd"
    version = 0
    flags = 0
    payload = u32.pack(0)
    payload += u32.pack(0)
    payload += (u32.pack(0) + u32.pack(0) + u32.pack(0)) * 2
    payload += u32.pack(0) * 3
    payload += u32.pack(0) * 2
    payload += u32.pack(0) * 24
    payload += u32.pack(1)

    print('box_type', box_type)
    print('version', version)
    print('flags', flags)
    print('payload', payload)
    print('result', full_box(box_type, version, flags, payload))


# Generated at 2022-06-24 12:03:58.147424
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
   
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
   
    info_dict = None
    filename = '/home/julien/test_IsmFD.ism'

    downer = IsmFD()
    downer.real_download(filename, info_dict)


# Generated at 2022-06-24 12:04:07.446694
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .downloader.http import HttpFD
    from .compat import compat_urllib_error
    from .extractor.ism import IsmFD, FragmentFD

    def _download_fragment(self, ctx, url):
        raise compat_urllib_error.HTTPError('http://example.com/m3u8', 500, '', None, None)

    def _append_fragment(self, ctx, frag_content):
        pass

    FragmentFD._download_fragment = _download_fragment
    FragmentFD._append_fragment = _append_fragment

    ydl = FakeYDL()
    ydl.params['fragment_retries'] = 5
    ydl.params['test'] = True

# Generated at 2022-06-24 12:04:14.272433
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .downloader.http_dashsegments import dashsegments_download_with_metadata
    from .downloader.ism import ism_download_with_metadata
    from ..compat import parse_qsl

    workdir = tempfile.mkdtemp()

# Generated at 2022-06-24 12:04:22.216828
# Unit test for function write_piff_header
def test_write_piff_header():
    import requests
    import tempfile
    import shutil
    import os
    import subprocess
    import stat
    import re
    import sys
    import platform

    is_native_windows = 'PROGRAMFILES(X86)' in os.environ

    if platform.system() != 'Windows':
        return


# Generated at 2022-06-24 12:04:30.974305
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import iso8601_to_unix
    from .dash import test_write_sample
    from .encryption import test_encrypt_fragments
    from .m4a import test_write_m4a_header
    from .mp4 import write_mfhd
    from .muxer import write_fragment_header
    from .smoothstreaming import test_write_ss_header


# Generated at 2022-06-24 12:04:40.356053
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:04:47.539282
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:53.133002
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
  # Build segment list
  segment_list = []
  # Build fragment
  frag = {}
  frag['url'] = 'http://test.test/test.test'
  segment_list.append(frag)
  # Build info_dict
  info_dict = {}
  info_dict['fragments'] = segment_list
  # Build params
  params = {'test': 1, 'fragment_retries': 1, 'skip_unavailable_fragments': True}
  # Build ctx
  ctx = {}
  ctx['total_frags'] = 1
  # Build downloader
  downloader = IsmFD()
  # Test
  downloader._prepare_and_start_frag_download(ctx)
  track_written = False

# Generated at 2022-06-24 12:05:04.469610
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ..common import InfoExtractor
    from .common import Instance, MockFragmentFD, parse_options
    from .test_common import build_test_result

    fd_list = []
    result_list = []

    ie = InfoExtractor(None)
    ie.url = 'http://ism.com/path'

    def _write_frag_content(file, content, info_dict):
        pass

    def _append_frag_content(file, frag_content):
        fd_list[-1].append_frag_content(frag_content)

    def _close_files(files):
        fd_list[-1].close_files(files)


# Generated at 2022-06-24 12:05:08.086637
# Unit test for function box
def test_box():
    assert(box(b'abcd', b'') == b'\x00\x00\x00\x0cabcd')
    assert(box(b'abcd', b'\x01\x02\x03\x04') == b'\x00\x00\x00\x10abcd\x01\x02\x03\x04')



# Generated at 2022-06-24 12:05:16.473148
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:05:18.167706
# Unit test for function box
def test_box():
    assert box('mdat', '') == binascii.a2b_hex('00000010mdat')


# Generated at 2022-06-24 12:05:23.267474
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version  = 0
    flags    = 0
    payload  = b''
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'
# End of test_full_box()


# Generated at 2022-06-24 12:05:33.656652
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_io
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 150000000,
        'timescale': 10000000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
    }
    stream = compat_io.BytesIO()
    write_piff_header(stream, params)
    stream.seek(0)

# Generated at 2022-06-24 12:05:42.035585
# Unit test for constructor of class IsmFD
def test_IsmFD():

    FRAG_URL = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(230000)/Fragments(video=0)'
    FILENAME = 'test.ism'

    info_dict = {}
    info_dict['fragments'] = [{'url': FRAG_URL}]
    info_dict['_download_params'] = {}
    info_dict['_download_params']['track_id'] = 1
    info_dict['_download_params']['fourcc'] = 'H264'
    info_dict['_download_params']['duration'] = 8000000
    info_dict['_download_params']['timescale'] = 10000000

# Generated at 2022-06-24 12:05:47.979665
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .fragment import FragmentFD
    from .http import HTTPFD
    from .smoothstreams import SmoothStreamsFD
    from .dash import DASHFD
    from .hds import HDSFD
    from .hls import HLSFD
    from .http import HTTPFD
    from .ism import IsmFD
    from .mpd import MpdFD
    from .rtmp import RTMPFD
    from .smoothstreams import SmoothStreamsFD
    from .utils import (
        subtitles_filename,
        unique_filename,
        match_filter_func,
    )


# Generated at 2022-06-24 12:05:57.659311
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import inspect
    import shutil
    import tempfile

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.utils import prepend_extension
    from youtube_dl.compat import compat_urllib_error
    from .test_utils import FakeYDL
    from .test_fileserver import http_server, fileserver_thread

    ydl = FakeYDL()
    ydl.add_info_extractor(YoutubeIE())

    # Prepare test environment
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 12:06:05.235223
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    from .fragment import _test_decode_header

    test_params = {
        'sampling_rate': 8,
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000 * 10000000,
        'codec_private_data': '0000000167428029D5801B3'
    }
    with tempfile.NamedTemporaryFile(suffix='.ismv') as f:
        write_piff_header(f, test_params)
        f.seek(0)
        _test_decode_header(f.name)



# Generated at 2022-06-24 12:06:17.125788
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class YDStreamFD:
        def __init__(self):
            #self.filename = filename
            self.total_frags = 0
            self.frag_index = 0

        def real_download(self, filename, info_dict):
            self.filename = filename
            if 'fragments' in info_dict:
                self.total_frags = len(info_dict['fragments'])
            return True


# Generated at 2022-06-24 12:06:28.010620
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:06:39.220181
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import pytest
    from sys import platform
    from os import path
    from subprocess import Popen, PIPE
    from py_common_subs import md5sum

    from ytdl.downloader import FD_NAME_TO_CLASS
    from ydl_fs import FileFD

    def run_downloader(url, pytest_config, params, verification_mode=False, count_verification_fragments=0):
        pytest_tmpdir = path.join(pytest_config.rootdir, 'tmp')
        base_url = 'https://download-tests.ytdl-org.test/downloads'
        if verification_mode:
            output_path = 'output-verification.ismv'
        else:
            output_path = 'output.ismv'

# Generated at 2022-06-24 12:06:49.046983
# Unit test for function extract_box_data
def test_extract_box_data():
    data_1 = b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00'
    result = extract_box_data(data_1, (b'typ', b'std'))
    assert result is None
    data_2 = b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00'
    result = extract_box_

# Generated at 2022-06-24 12:07:01.213651
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:07:11.510021
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import random
    import string
    import hashlib
    import json


# Generated at 2022-06-24 12:07:15.423903
# Unit test for function full_box
def test_full_box():
    assert full_box('abcd', 1, 0xFFFFFF, 'befg') == b'\x00\x00\x00\x0dabcd\x01\xff\xff\xffbefg'



# Generated at 2022-06-24 12:07:16.194425
# Unit test for function full_box
def test_full_box():
    pass



# Generated at 2022-06-24 12:07:26.442565
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Define all variables that may be used in this unit test's code
    test_ManifestFD_parse_manifest_url_params_real_download_manifest_url = (
        'https://s3-ap-southeast-2.amazonaws.com/vod.releases.yowie.com.au/480p_h264_1413/480p_h264_1413.ism/Manifest(format=m3u8-aapl)')
    test_IsmFD_real_download_segments = [{'url': 'https://s3-ap-southeast-2.amazonaws.com/vod.releases.yowie.com.au/480p_h264_1413/480p_h264_1413-Frag1'}]
    test_IsmFD_real_download_filename

# Generated at 2022-06-24 12:07:35.291526
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'\xde\xad\xbe\xef') == b'\x00\x00\x00\x14moov\x00\x00\x00\x00\x00\x00\xde\xad\xbe\xef'
    assert full_box(b'moov', 1, 0, b'\xde\xad\xbe\xef') == b'\x00\x00\x00\x14moov\x01\x00\x00\x00\x00\x00\xde\xad\xbe\xef'

# Generated at 2022-06-24 12:07:43.446642
# Unit test for function write_piff_header
def test_write_piff_header():
    import hashlib
    from ..utils import (
        encode_data_uri,
        decode_data_uri,
    )

# Generated at 2022-06-24 12:07:49.694651
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://vjs.zencdn.net/v/oceans.ism/Manifest'
    #os.getcwd()
    #'/Users/shashank/Documents/work/YtbDownloader/youtube-dl'
    
    # construct a argument list from information from the url

# Generated at 2022-06-24 12:07:57.609066
# Unit test for function box
def test_box():
    assert box(b'vmhd', u16.pack(0) + u8.pack(1) + u88.pack(0) * 3) == b'\x00\x00\x00\x14vmhd\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'.replace(b'\x00', b'\177')



# Generated at 2022-06-24 12:08:01.341752
# Unit test for function box
def test_box():
    assert box(b'abcd', b'123456789') == b'\x00\x00\x00\x0fabcd123456789'


# Generated at 2022-06-24 12:08:06.040765
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    output_file = "output.mp4"

    test_url = "http://playready.directtaps.net/smoothstreaming/TTLSS720VC1/To_The_Limit_720.ism/Manifest"

    format_param = "format=mp4"
    frags_zipped_param = "frags_zipped=True"

    test_params = "?{}&{}".format(format_param,frags_zipped_param)

    ismfd = IsmFD()

    ismfd.params["test"] = True

    test_url = test_url + test_params

    ismfd.real_download(output_file, get_info_dict(test_url))

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-24 12:08:18.786872
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for method real_download of class IsmFD
    """
    from .test.test_decrypt import check_real_decrypt
    from .common import PluginContext
    from .extractor import gen_extractors
    from .downloader import gen_extractor_classes
    from .downloader.IsmFD import IsmFD


    plugin_context = PluginContext()
    plugin_context.plugin_configs = {}

    self = IsmFD()
    self.params = {
        "fragment_retries": 5,
        "skip_unavailable_fragments": True,
    }

    # Skip the unit test if the method real_download can not be called
    # because of the lack of parameter info_dict of type dict
    # Parameter filename of type str
    # Parameter info_dict of

# Generated at 2022-06-24 12:08:27.654324
# Unit test for function write_piff_header
def test_write_piff_header():

    def read_stream(path):
        with io.open(path, 'rb') as stream:
            return stream.read()

    path = './byte_streams/piff_header.dat'

    piff_params = {
        'track_id': 1,
        'duration': 10000000,
    }

    # write header to stream
    stream = io.BytesIO()
    write_piff_header(stream, piff_params)

    # compare dumped header with test file
    assert stream.getvalue() == read_stream(path)

    # verify that second fragment is same as first
    stream = io.BytesIO()
    write_piff_header(stream, piff_params)
    assert stream.getvalue() == read_stream(path)



# Generated at 2022-06-24 12:08:38.903658
# Unit test for function full_box
def test_full_box():
    assert(full_box('\x70\x6f\x6f\x6d', 0x0, 0x0, '\x00\x00\x00\x00\x00\x00\x00\x00') == '\x00\x00\x00\x10\x70\x6f\x6f\x6d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-24 12:08:49.538524
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:08:51.641260
# Unit test for function box
def test_box():
    assert box('abcd', '12345678') == b'\x00\x00\x00\x10abcd12345678'


# Generated at 2022-06-24 12:09:03.097831
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import random

    random.seed(0)
    for _ in range(1):
        params = {}
        params['duration'] = random.randint(1, 1000000)
        params['track_id'] = random.randint(1, 1000000)
        params['sampling_rate'] = random.randint(1, 1000000)
        params['channels'] = random.randint(1, 1000000)
        params['bits_per_sample'] = random.randint(1, 1000000)
        params['codec_private_data'] = compat_chr(random.randint(1, 1000000))
        params['height'] = random.randint(1, 1000000)
        params['width'] = random.randint(1, 1000000)
        params['nal_unit_length_field'] = random.randint

# Generated at 2022-06-24 12:09:05.314467
# Unit test for function box
def test_box():
    assert box(b'a', b'') == b'\x00\x00\x00\x08a'
    assert box(b'abcd', b'a') == b'\x00\x00\x00\x0Babcd\x61'


# Generated at 2022-06-24 12:09:12.187107
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:18.546018
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD("http://a1.akamaized.net/media/multibitrate/parse/channels/1/testchannel/channel1_800.ismc/channel1_800.ism/QualityLevels(331)/Fragments(video=0)")
    print("test_IsmFD", fd.url)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:09:22.389326
# Unit test for function full_box
def test_full_box():
    if(full_box('test', 0x01, 0xFFFFFFFF, 'test') != '\x00\x00\x00\x13test\x01\xff\xff\xff\xfftest'):
        raise ValueError('Unit test for full_box failed!')

# Generated at 2022-06-24 12:09:26.578040
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x0c' + 'sbi' + b'\x00\x01\x02\x03' == box('sbi', b'\x00\x01\x02\x03')
# /Unit test for function box



# Generated at 2022-06-24 12:09:34.028546
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Write a temporary test file.
    import tempfile
    tempfile_descriptor, tempfile_path = tempfile.mkstemp('.ism')
    tempfile_file = os.fdopen(tempfile_descriptor, 'wb')
    tempfile_file.write(b'http://example.com/segment1.ts\n')
    tempfile_file.write(b'http://example.com/segment2.ts\n')
    tempfile_file.close()

    # Read the temporary test file, and delete it.
    info_dict = {}
    info_dict['url'] = tempfile_path

# Generated at 2022-06-24 12:09:43.854557
# Unit test for function box
def test_box():
    assert box(b"mvhd", b"") == b"\x00\x00\r\x00"+b"mvhd" + b"\x00"*8
    assert box(b"tkhd", b"") == b"\x00\x00\x1b\x00"+b"tkhd" + b"\x00"*(8+1)
    assert box(b"mdhd", b"") == b"\x00\x00\x15\x00"+b"mdhd" + b"\x00"*(8+1)
    assert box(b"hdlr", b"") == b"\x00\x00\x1a\x00"+b"hdlr" + b"\x00"*1

# Generated at 2022-06-24 12:09:51.275371
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'
    assert box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x10moov\x00\x00\x00\x00'
    assert box(b'moov', b'\x00\x00\x00\x00'*2) == b'\x00\x00\x00\x14moov\x00\x00\x00\x00\x00\x00\x00\x00'
# End unit test for function box



# Generated at 2022-06-24 12:10:00.535844
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_etree_fromstring
    from ..utils import (
        determine_ext,
    )

    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000000000,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    })

    c = stream.getvalue()
    print(c)
    print(len(c))

    tree = compat_etree_fromstring(c)

    assert determine_ext(tree) == 'mp4'


# Generated at 2022-06-24 12:10:05.514714
# Unit test for function full_box
def test_full_box():
    assert full_box(b'ftyp', 3, 0, b'mp42isom') == b'\x00\x00\x00\x10ftyp\x03\x00\x00mp42isom'
test_full_box()



# Generated at 2022-06-24 12:10:09.334668
# Unit test for constructor of class IsmFD
def test_IsmFD():
    FD = IsmFD('http://example.com/fragments.ism/Manifest', None)
    assert FD.__class__ == IsmFD
    assert FD.FD_NAME == 'ism'
    assert FD._TEMP_FILENAME_PREFIX == 'smooth-'



# Generated at 2022-06-24 12:10:11.293792
# Unit test for function full_box
def test_full_box():
    return full_box(b'moov', 0, 0, b'movietest')

# Generated at 2022-06-24 12:10:13.634481
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    re_test=re.compile(r'Hello world')
    m=re_test.search('Hello world')
    assert(m)

# Generated at 2022-06-24 12:10:19.334866
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for IsmFD
    Check to make sure IsmFD can handle manifest.ism
    """
    ydl = YoutubeDL({})
    fd = ydl.add_info_extractor(IsmFD(ydl, {'url': "http://contoso.com/manifest.ism"}))
    assert fd.get_url() == 'http://contoso.com/manifest.ism'

# Generated at 2022-06-24 12:10:30.835613
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://example.com/manifest.ismc'
    ismfd = IsmFD(url)
    # Test equals methods
    assert(ismfd == IsmFD(url))
    assert(ismfd != IsmFD(url + '/'))
    assert(ismfd != IsmFD(url, {'protocol': 'https'}))
    # Test protocol and manifest_url
    assert(ismfd.url == url)
    assert(ismfd.protocol == 'm3u8')
    assert(ismfd.manifest_url == url)
    # Test repr
    assert(repr(ismfd) == '<ismfd manifest_url="http://example.com/manifest.ismc">')
    # Test repr again with different protocol

# Generated at 2022-06-24 12:10:43.563597
# Unit test for function extract_box_data
def test_extract_box_data():
    from .test import _read_data
    from .test import TEST_DATA
    import json

    test_data = _read_data(TEST_DATA['-4hiOr9XCak.mp4'])
    sample_entry_box_data = extract_box_data(test_data, ['moov', 'trak', 'mdia', 'minf', 'stbl', 'stsd', 'mp4a'])

# Generated at 2022-06-24 12:10:55.086310
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(
            stream,
            {
                'track_id': 0x1,
                'fourcc': 'H264',
                'duration': 0xffffffff,
                'timescale': 48000,
                'height': 1080,
                'width': 1920,
                'language': 'en',
                'codec_private_data': '0000000167640028ACD91240',
            }
        )


# Generated at 2022-06-24 12:10:59.728343
# Unit test for function box
def test_box():
    assert '00000020'.decode('hex') == box('mvhd', '00'.decode('hex') * 20)

full_box = lambda ver, flags: lambda box_type, payload: box(box_type, u8.pack(ver) + u24.pack(flags) + payload)

# Generated at 2022-06-24 12:11:11.881662
# Unit test for function extract_box_data
def test_extract_box_data():
    data = (b'\x00\x00\x00\x10moov' +
            b'\x00\x00\x00\x10mvhd' +
            b'\x00\x00\x00\x10trak' +
            b'\x00\x00\x00\x10tkhd')
    box_sequence = [b'moov', b'mvhd']
    box_data = extract_box_data(data, box_sequence)
    assert box_data == b'\x00\x00\x00\x10mvhd'
    box_sequence = [b'moov', b'trak', b'tkhd']
    box_data = extract_box_data(data, box_sequence)

# Generated at 2022-06-24 12:11:20.418764
# Unit test for function extract_box_data
def test_extract_box_data():
    import tempfile
    testfile = tempfile.NamedTemporaryFile()
    stream = testfile.file
    write_piff_header(stream, {'track_id': 1, 'fourcc': 'AACL', 'duration': 10000000,
                               'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 48000})
    stream.seek(0)
    data = b''
    while True:
        buf = stream.read(1024)
        if not buf:
            break
        data += buf
    assert(u1616.unpack(extract_box_data(data, [b'stsd']))[0] == 1)

# Generated at 2022-06-24 12:11:27.217558
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(
        b'moov'
        b'\x00\x00\x00\x10'  # moov size = 16
        b'mvhd'  # mvhd box
        b'\x00\x00\x00\x10'  # mvhd size = 16
        b'mdia'  # mdia box
        b'\x00\x00\x00\x10'  # mdia size = 16
        b'mdhd'  # mdhd box
        b'\x00\x00\x00\x10'  # mdhd size = 16
    , (b'moov', b'mdia', b'mdhd')) == b'\x00\x00\x00\x10'  # mvhd size = 16



# Generated at 2022-06-24 12:11:34.744306
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:45.377008
# Unit test for function full_box
def test_full_box():
    # version
    assert full_box(0,0,0,0)[4] == 0
    assert full_box(0,1,0,0)[4] == 1

    # flags
    assert full_box(0,0,0,0)[5] == 0
    assert full_box(0,0,1,0)[5] == 1

    #  0x00000001
    assert full_box(0,0,0x00000001,0)[5] == 1
    #  0x00000010
    assert full_box(0,0,0x00000010,0)[6] == 1
    #  0x00000100
    assert full_box(0,0,0x00000100,0)[7] == 1
    #  0x00001000

# Generated at 2022-06-24 12:11:51.124923
# Unit test for function box
def test_box():
    assert box(b'fmt ', b'\x10\x00\x00\x00') == b'\x0c\x00\x00\x00fmt \x10\x00\x00\x00'


# Generated at 2022-06-24 12:11:56.832453
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x08ftyp\x00\x00\x00\x20moov\x00\x00\x00\x80mdia\x00\x00\x00\x88hlll'
    print(binascii.hexlify(extract_box_data(data, [b'moov', b'mdia'])))



# Generated at 2022-06-24 12:12:03.476972
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b'payload'
    payload_size = len(payload)
    expected_box = u32.pack(8 + payload_size) + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload
    print(expected_box)
    actual_box = full_box(box_type, version, flags, payload)
    print(actual_box)
    assert expected_box == actual_box
    print('test_full_box passed')
test_full_box()


# Generated at 2022-06-24 12:12:10.021733
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    def _download_fragment(self, ctx, url, info_dict=None):
        success, info_dict = self._do_download(url, filename, info_dict)
        return True, bytearray(b'')

    elem = {'file': 'file1'}
    url = 'https://url/'
    info_dict = {
        'id': 'id',
        'title': 'title',
        'ext': 'ism',
        'fragments': [],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'sampling_rate': 44100,
            'duration': 1183
        }
    }

    frag_fd = IsmFD()

# Generated at 2022-06-24 12:12:18.330402
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:12:30.439740
# Unit test for function extract_box_data
def test_extract_box_data():
    box1 = box('test', 'test')
    box2 = box('test2', 'test2')
    box3 = box('test3', 'test3')
    box4 = box('test4', 'test4')
    box5 = box('test5', 'test5')
    box6 = box('test6', 'test6')
    box7 = box('test7', 'test7')
    box8 = box('test8', 'test8')
    box9 = box('test9', 'test9')

    data = box1 + box2 + box3 + box4 + box5 + box6 + box7 + box8 + box9
    assert extract_box_data(data, ('test7', )) == 'test7'
    assert extract_box_data(box3, ('test3', )) == 'test3'

# Generated at 2022-06-24 12:12:31.507081
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({})


# Generated at 2022-06-24 12:12:35.355136
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Basic unit test for testing constructor
    """
    IsmFD({})


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:12:42.492065
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialize context
    _tmp_filename = 'xJYBQSQc7q.ism'

    # Test case 1
    params = {'format': 'ismv'}
    ism_fd = IsmFD(_tmp_filename, params)

# Generated at 2022-06-24 12:12:43.538053
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-24 12:12:49.716380
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x01b\x01\x00\x00\x00\x01m\x01\x00\x00\x00\x01t\x01\x00\x00\x00\x01b\x01\x00\x00\x00\x01m\x01\x00\x00\x00\x01t\x01'
    assert extract_box_data(data, (b'b', b'm', b't')) == b'\x01\x00\x00\x00\x01'
    assert extract_box_data(data, (b'm', b't')) == b'\x01\x00\x00\x00\x01'

# Generated at 2022-06-24 12:12:51.764883
# Unit test for function full_box
def test_full_box():
    payload = "abc"
    full_box("abc",0,1,payload)
    # print("succeed")
# test_full_box()


# Generated at 2022-06-24 12:13:01.505248
# Unit test for function extract_box_data
def test_extract_box_data():
    # Example code
    data = u32.pack(2) + b'abcd' + u32.pack(3) + b'efgh' + u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'abcd', b'efgh')) == u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'abcd')) == u32.pack(3) + b'efgh' + u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'abcd', b'xyzy')) == ''



# Generated at 2022-06-24 12:13:10.170516
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:13:19.574612
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for a URL we know to be an ISM manifest
    test_url = 'http://portalvhdsx7x11kadsm6.blob.core.windows.net/1d95a076-a8b4-4a94-9c22-b8a7b9c53b62/mp4:038e5245-c5e5-46d7-a325-f89892bf6600.ism/manifest(format=mpd-time-csf)'