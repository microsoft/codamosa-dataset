

# Generated at 2022-06-24 12:03:18.115933
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:03:26.904281
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('test.mp4', 'rb') as f:
        movie_box = f.read()

# Generated at 2022-06-24 12:03:34.515343
# Unit test for function full_box
def test_full_box():
    box_type = b'\x66\x6f\x6f'
    version = 0x00
    flags = 0x00
    payload = b''
    expected_result = b'\x00\x00\x00\x0c' + box_type + b'\x00\x00\x00\x00' + payload
    actual_result = full_box(box_type, version, flags, payload)
    assert(expected_result == actual_result)



# Generated at 2022-06-24 12:03:37.031786
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Simple unit test for IsmFD
    """
    IsmFD().real_download("", {})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:03:40.161837
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'format': 'ism'}, None)
    return fd

# Constructor of class IsmFD
IsmFD.download = download = test_IsmFD()



# Generated at 2022-06-24 12:03:42.225545
# Unit test for function box
def test_box():
    assert box('abcd', 'efgh') == u32.pack(12) + 'abcd' + 'efgh'


# Generated at 2022-06-24 12:03:48.677424
# Unit test for function write_piff_header
def test_write_piff_header():
    # Extract function ...
    def do_write_piff_header(f, params):
        with io.open(f, 'wb') as stream:
            write_piff_header(stream, params)
    # ... and test code
    from os.path import exists
    from os import unlink
    f = 'test_write_piff_header.ism'
    if exists(f):
        unlink(f)

# Generated at 2022-06-24 12:03:52.966494
# Unit test for function full_box
def test_full_box():
    _box_type = b'\x6A\x70\x32\x67\x6D\x70\x34\x32'
    _version = 0
    _flags = 0
    _payload = b'\x00\x00\x00\x14\x66\x74\x32\x6D\x70\x34\x32\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    _full_box = full_box(_box_type,_version,_flags,_payload)

# Generated at 2022-06-24 12:03:59.650479
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    duration = 5000000000 # 50s
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': duration,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        }
    write_piff_header(fd, params)
    assert fd.tell() == 96

# Generated at 2022-06-24 12:04:01.383188
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD()
    print(test_IsmFD)


# Generated at 2022-06-24 12:04:06.523496
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .fragment_fd import FragmentFD
# The __init__ method has been defined before to allow forward references

    test_IsmFD_real_download.__test__ = False  # to be able to run the test method without the self argument

    def real_download(ctx):
        FragmentFD.real_download(ctx)

    class ctx(object):
        def __init__(self):
            self.params = {}
            self.filename = None
            self.total_frags = 0

    ctx = ctx()
    real_download(ctx)


# Generated at 2022-06-24 12:04:08.909946
# Unit test for function box
def test_box():
    payload = b'something'
    box_type = b'BOX '
    assert box(box_type, payload) == b'\x00\x00\x00\x0eBOX something'



# Generated at 2022-06-24 12:04:13.104121
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest_url = 'https://amssamples.streaming.mediaservices.windows.net/3e3b9fce-9d9a-48a0-955e-8f8a9df971dd/BigBuckBunny.ism/manifest'
    tmp_filename = 'test_temp.ismv'

# Generated at 2022-06-24 12:04:21.709691
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:24.782603
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    arg1 = 'filename'
    arg2 = {'fragments': [{'url': 'test_url'}], '_download_params': {'track_id': 4256}}
    exp = True
    
    fd = IsmFD()
    act = fd.real_download(arg1, arg2)
    
    assert act == exp



# Generated at 2022-06-24 12:04:26.115769
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL({})
    dl = IsmFD(ydl)
    assert dl.FD_NAME == 'ism'


# Generated at 2022-06-24 12:04:38.125786
# Unit test for function write_piff_header
def test_write_piff_header():
    objs = {}
    objs['params'] = {}
    objs['params']['track_id'] = 0
    objs['params']['fourcc'] = 'H264'
    objs['params']['duration'] = 0
    objs['params']['timescale'] = 10000000
    objs['params']['language'] = 'und'
    objs['params']['height'] = 0
    objs['params']['width'] = 0
    objs['params']['channels'] = 2
    objs['params']['bits_per_sample'] = 16
    objs['params']['sampling_rate'] = 44100
    objs['params']['codec_private_data'] = '0164002AAB0DFC' # fake value

# Generated at 2022-06-24 12:04:45.835273
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # This is a test case for testing the method real_download of class IsmFD
    print("Testing real_download method of class IsmFD")
    # The following data represent the input object
    # that the function under test will receive as an argument:
    # the object is an instance of class IsmFD
    class object:
        def __init__(self):
            self.params = {'test': False}
            self._downloader = None
            self.ytdl = None
            self.report_error = None
            self.report_skip_fragment = None
            self.report_retry_fragment = None
            self.report_destination = None
            self._prepare_and_start_frag_download = None
            self._download_fragment = None
            self._append_fragment = None

# Generated at 2022-06-24 12:04:50.066309
# Unit test for function full_box
def test_full_box():
    version = 0x01
    flags = 0x10
    payload = b'whatever'
    assert full_box(b'ftyp', version, flags, payload) == b'\x00\x00\x00\x14ftyp\x01\x00\x00\x10whatever'


# Generated at 2022-06-24 12:04:51.274612
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD.test('http://test.com/test.ism')

# Generated at 2022-06-24 12:05:02.753634
# Unit test for function full_box
def test_full_box():
    assert len(full_box(b'mvhd', b'\x00', b'\x00\x00\x00', b'\x01\x02\x03\x04')) == 20
    assert len(full_box(b'trak', b'\x00', b'\x00\x00\x00', b'\x01\x02\x03\x04')) == 20
    assert len(full_box(b'mdat', b'\x00', b'\x00\x00\x00', b'\x01\x02\x03\x04')) == 20
    assert len(full_box(b'mvex', b'\x00', b'\x00\x00\x00', b'\x01\x02\x03\x04')) == 20
   

# Generated at 2022-06-24 12:05:10.482866
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = binascii.unhexlify(b'00000014667479703367703500000100000097E100000100000001000568EBECB5600000026746800000100000001000568EBECB56000000267468')
    box_data = extract_box_data(test_data, (b'ftyp', b'tkhd'))
    assert box_data == binascii.unhexlify(b'746800000100000001000568EBECB56')



# Generated at 2022-06-24 12:05:12.638260
# Unit test for function box
def test_box():
    assert box('mdat', 'test') == b'\x00\x00\x00\x0e' + b'mdat' + b'test'



# Generated at 2022-06-24 12:05:15.162445
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'



# Generated at 2022-06-24 12:05:26.953680
# Unit test for function extract_box_data
def test_extract_box_data():
    sequence1 = [b'ftyp', b'avc1', b'avcC']

# Generated at 2022-06-24 12:05:33.021680
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .http import HTTPFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .ism import IsmFD
    from .smoothstreams import SmoothStreamsFD
    from .wvm import WVMFD

    ism_fd = IsmFD(params=dict())
    http_fd = IsmFD(params=dict())
    dash_fd = IsmFD(params=dict())
    hls_fd = IsmFD(params=dict())
    smoothstreams_fd = IsmFD(params=dict())
    wvm_fd = IsmFD(params=dict())
    assert issubclass(ism_fd.__class__, IsmFD)
    assert issubclass(http_fd.__class__, HTTPFD)

# Generated at 2022-06-24 12:05:39.659507
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': b'avc1',
            'duration': 1000,
            'timescale': 10000000,
            'language': 'eng',
            'height': 1080,
            'width': 1920,
        }
        write_piff_header(stream, params)

        stream.seek(0)
        ftyp_size, = u32.unpack(stream.read(4))
        assert ftyp_size == 24
        ftyp_box_type, = stream.read(4)
        assert ftyp_box_type == b'ftyp'
        isml, = stream.read(4)
        assert isml == b'isml'

# Generated at 2022-06-24 12:05:40.676838
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass # TODO: implement your test here

# Generated at 2022-06-24 12:05:44.158047
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_file = "http://playready.directtaps.net/smoothstreaming/TTLSS720VC1/To_The_Limit_720.ism/Manifest"
    abr = IsmFD(test_file)
    assert abr is not None


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:05:56.083708
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_StringIO
    from .smoothstreams import get_ism_manifest

    params = dict(
        track_id=1,
        fourcc='AVC1',
        duration=0,
        timescale=1000,
        width=1280,
        height=720,
        language='und',
        codec_private_data='0164001fffe100197703019e661645fddc0f4bb12af43884020008c616631e6000001f9d917a8',
        nal_unit_length_field=4
    )
    stream = compat_StringIO()
    write_piff_header(stream, params)
    # stream is written as a binary file, so we need to decode the result.
    moov_payload = stream.get

# Generated at 2022-06-24 12:05:57.365630
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD({})


# Generated at 2022-06-24 12:06:03.223817
# Unit test for function full_box
def test_full_box():
    hex_dump('dummy', full_box('avc1', 0, 0, '\x00'*4))
    assert full_box('avc1', 0, 0, '\x00'*4) == '\x00\x00\x00\x14avc1\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 12:06:06.765395
# Unit test for function full_box
def test_full_box():
    print(full_box(b'moov', 0, 0, b''))



# Generated at 2022-06-24 12:06:18.159157
# Unit test for constructor of class IsmFD
def test_IsmFD():

    # Test case #1
    print("Test case #1: sample stream 1")
    ydl_opts = {
        'noplaylist': True,
        'format': 'ismv',
    }
    url = 'http://perf.ismlive.akadns.net/live/smil:bbb.isml/bbb.m3u8'
    with YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(url, download=True)
        fd = IsmFD(ydl, info_dict)
        assert fd.real_download('', info_dict)

    # Test case #2
    print("Test case #2: sample stream 2")

# Generated at 2022-06-24 12:06:30.259959
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test parameters
    test_url = 'https://content.uplynk.com/channel/ac3e3e48c3ed475d829c54d41540f0ae.m3u8?oac=BAH&ohr=5&ohc=30&oht=86400&ohv=4&ohs=4'
    test_data = 'test data'

    # Create a mock of FragmentFD
    fragmentFD_mock = MagicMock()
    fragmentFD_instance = IsmFD()

    # Perform the test
    fragmentFD_instance.real_download(test_url, test_data)

    # Asserts
    fragmentFD_mock.assert_called_with(test_url, test_data)

# Generated at 2022-06-24 12:06:37.862399
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'sintel.ism'

# Generated at 2022-06-24 12:06:48.109909
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .dash import DASHFD

# Generated at 2022-06-24 12:06:50.025657
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({
        'outtmpl': '%(outtmpl)s'
    })
    return fd

__all__ = ['IsmFD']

# Generated at 2022-06-24 12:06:59.808082
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    data = {
        'track_id': 1,
        'duration': 10,
        'sampling_rate': 22050,
        'fourcc': 'AACL',
    }
    write_piff_header(f, data)

# Generated at 2022-06-24 12:07:10.282257
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for method real_download of class IsmFD.
    """

    # Set up test variables
    filename = 'filename'
    info_dict = {'fragments':[{'url':'segment'}]}
    params = {'test':False}

    # Instantiate object
    ismfd_obj = IsmFD(urls=[], params=params)

    # Test
    ismfd_obj.real_download(filename, info_dict)

    # Test real_download with fragment_retries > 0
    # Set up test variables
    params = {'fragment_retries':1, 'test':False}
    info_dict = {'fragments':[{'url':'segment'}]}

    # Instantiate object

# Generated at 2022-06-24 12:07:16.135079
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    fd.params = dict(url = 'http://example.com', manifest_url = 'http://manifest.com',
                     test = True, verbose = False)
    # Need to mock the following functions:
    # _download_fragment: download fragment and return status (True or False) and content
    # _append_fragment: write fragment content to file
    fd._download_fragment = lambda *x: (True, 'test')
    fd._append_fragment = lambda *x: x[1]

# Generated at 2022-06-24 12:07:26.384995
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # prepare mock data
    retval = (True, 'mock data')
    # prepare mock ctx
    ctx = {
        'filename': 'mock filename',
        'total_frags': 1,
    }
    # prepare mock info_dict
    info_dict = {
        'fragments': [
            {'url': 'mock url'},
        ],
        '_download_params': {
            'track_id': 1,
        },
    }
    # prepare mock data_stream
    data_stream = io.BytesIO(b'test file data')
    # prepare mock dest_stream
    dest_stream = io.BytesIO()
    def mock_dest_stream_write(data):
        assert data == b'test file data'
    dest_stream.write = mock_dest_stream_write

# Generated at 2022-06-24 12:07:32.283842
# Unit test for function box
def test_box():
    assert box('abcd', '') == b'\x00\x00\x00\x0cabcd'
#    


# Generated at 2022-06-24 12:07:34.977861
# Unit test for function full_box
def test_full_box():
    assert full_box('moov', 0, 0, 'hello') == b'moov\x00\x00\x00\x0c\x00\x00\x00\x00hello'


# Generated at 2022-06-24 12:07:39.284016
# Unit test for function box
def test_box():
    assert box(b'abcd', b'') == b'\x00\x00\x00\x0Cabcd'
    assert box(b'1234', b'HELLO') == b'\x00\x00\x00\x0A1234534C4C4F'

# Generated at 2022-06-24 12:07:50.438433
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHIE
    from .dash import dash_manifest
    from .dash import dash_manifest_base
    from .scte35 import scte35_extract
    rtmpdump_version = '2.4'

    manifest_url = 'https://amssamples.streaming.mediaservices.windows.net/49b57c87-f5f3-48b3-ba22-c55cfdffa9cb/Sintel.ism/manifest'
    test_manifest = 'sintel_ism.txt'

    d = IsmFD(manifest_url, params={'outtmpl': test_manifest})
    # fetch the manifest from server
    d.download(test_manifest)
    # read in the manifest to use for comparison

# Generated at 2022-06-24 12:08:01.673294
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'moov', b'mvhd')
    moov_payload = full_box(b'mvhd', 1, 0, u64.pack(0) * 2 + u32.pack(1) * 9 + s1616.pack(1) + s88.pack(1) + u16.pack(0) + u32.pack(0) * 2 + unity_matrix + u32.pack(0) * 6 + u32.pack(0xffffffff))  # Movie Header Box
    moov = box(b'moov', moov_payload)
    moov_with_stuffs = b'\x00\x00\x01\x02' + moov + b'\x00\x00\x02\x03'

# Generated at 2022-06-24 12:08:03.986669
# Unit test for function box
def test_box():
    assert box('abcd', 'efgh') == binascii.unhexlify(
    '00000008 61626364  66677268'.replace(' ', ''))


# Generated at 2022-06-24 12:08:07.216830
# Unit test for function box
def test_box():
    assert box('ftyp', 'msdh') == '\x00\x00\tmsdh'


# Generated at 2022-06-24 12:08:11.204281
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """"""
    pass



# Generated at 2022-06-24 12:08:12.167238
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download(): pass



# Generated at 2022-06-24 12:08:21.586574
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'duration': 10000000,
        'fourcc': 'AACL',
        'channels': 2,
        'sampling_rate': 48000,
        'bits_per_sample': 16,
    })


# Generated at 2022-06-24 12:08:29.496512
# Unit test for function extract_box_data
def test_extract_box_data():
    s = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

# Generated at 2022-06-24 12:08:38.192740
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:47.619713
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = b'\x00\x00\x00\x2Cftyp\x00\x00\x00\x00isml\x00\x00\x01\x00piff\x00\x00\x00\x00iso2'
    assert extract_box_data(box_data, (b'ftyp', )) == b'\x00\x00\x00\x00isml\x00\x00\x01\x00piff\x00\x00\x00\x00iso2'
    assert extract_box_data(box_data, (b'ftyp', b'piff')) == b'\x00\x00\x00\x00iso2'



# Generated at 2022-06-24 12:09:00.283919
# Unit test for function full_box
def test_full_box():
    payload = u32.pack(0)
    result = full_box(b"avcC", 0, 0, payload)
    expected = b'\x00\x00\x00\x10'+b'avcC'+b'\x00'+b'\x00\x00\x00\x00'+payload
    assert(result == expected)


# Generated at 2022-06-24 12:09:07.844506
# Unit test for function extract_box_data
def test_extract_box_data():
    assert binascii.hexlify(extract_box_data(
        u32.pack(50) + b'moof' + u32.pack(42) + b'mdat' + b'\x00' * (50 - 12),
        [b'moof', b'mdat'])) == b'000000002a6d64617400'
    assert binascii.hexlify(extract_box_data(
        u32.pack(14) + b'moof' + u32.pack(6) + b'mdat' + b'\x00' * (14 - 12),
        [b'moof', b'mdat'])) == b''



# Generated at 2022-06-24 12:09:13.048663
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    import json
    params = {
        'track_id': 1,
        'duration': 2,
        'timescale': 1000,
        'language': 'spa',
        'height': 480,
        'width': 640,
        'codec_private_data': '000000016742C000BED76D11B831FFC7',
    }
    bio = io.BytesIO()
    write_piff_header(bio, params)
    print(encode_data_uri(bio.getvalue(), 'application/octet-stream'))
    print(json.dumps(params))



# Generated at 2022-06-24 12:09:24.332365
# Unit test for function write_piff_header
def test_write_piff_header():
    o = io.BytesIO()
    write_piff_header(o, {
        'track_id': 1,
        'fourcc': 'H264',
        'height': 576,
        'width': 720,
        'nal_unit_length_field': 4,
        'codec_private_data': '67640011acd9000368eb0281049fe098',
        'duration': 100000,
        'timescale': 90000,
    })

# Generated at 2022-06-24 12:09:32.697803
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:38.548143
# Unit test for function box
def test_box():
    assert box(b'mp4a', b'\x00\x00\x00\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x10mp4a\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:09:46.807900
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file_path = 'test.mp4'
    with io.open(test_file_path, 'wb') as test_file:
        params = {
            'track_id': 1,
            'duration': 1000000000,
            'fourcc': 'H264',
            'height': 720,
            'width': 1280,
            'nal_unit_length_field': 4,
            'codec_private_data': '0000000167640033ACD90800E62E01F1615047BACD90800138438020D2B000'
        }
        write_piff_header(test_file, params)
        test_file.seek(4)
        assert test_file.read(4) == b'moov'


# Generated at 2022-06-24 12:09:56.759590
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-24 12:10:02.757299
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:11.843226
# Unit test for function extract_box_data
def test_extract_box_data():
    data_reader = io.BytesIO(binascii.unhexlify(
        b'000000246674797069736D6C0000001869736D6C61766331696D766B0000002069736D766B6D6469610000002069736D6469616D7367656E000000187673636D616C73637265000000107636D616C6E6F6D6500000018767370636163636F756E74000000147670636163636F756E7431'
    ))

# Generated at 2022-06-24 12:10:21.767087
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 27188500,
        'timescale': 90000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fff0000000168ea40eb0b0000a0c910001200096001458001000568ebecb22c',
    }
    write_piff_header(stream, params)


# Generated at 2022-06-24 12:10:30.685776
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:38.077000
# Unit test for function full_box
def test_full_box():
    box_type = "mvhd"
    version = 1
    flags = 0
    payload = u32.pack(0) + u32.pack(0) + u32.pack(0) + u64.pack(0)
    assert full_box(box_type, version, flags, payload) == box(box_type, u8.pack(version) + u32.pack(flags)[1:] + payload)
    assert full_box(box_type, version, flags, payload) != box(box_type, u8.pack(version-2) + u32.pack(flags)[1:] + payload)
    assert full_box(box_type, version, flags, payload) != box(box_type, u8.pack(version) + u32.pack(flags)[2:] + payload)

# Generated at 2022-06-24 12:10:42.082199
# Unit test for function full_box
def test_full_box():
    assert full_box('ftyp', 1, 0xAABBCCDD, 'test') == '\x00\x00\x00\x11ftyp\x01\xAA\xBB\xCC\xDDtest'



# Generated at 2022-06-24 12:10:52.095419
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1000428ee80a000001b002220018a835f6d46f6fa4e4ff72c188'
    }
    write_piff_header(stream, params)
    with open('./piff.mp4', 'wb') as f:
        f.write(stream.getvalue())
    print("test success")
    return stream


# Generated at 2022-06-24 12:10:55.065967
# Unit test for function full_box
def test_full_box():
    assert full_box('abcd', 0, 0x0, b'') == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x00'

# Generated at 2022-06-24 12:11:06.846847
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractors.generic import YoutubeIE
    from .downloader import YoutubeDL
    from .options import Options
    from .utils import config
    from .compat import get_filesystem_encoding

    import tempfile

    def test_center(self, *args, **kwargs):
        print(
            "test_center():\n called with args:\n%s\n and kwargs:\n %s" % (
                args, kwargs
            )
        )

    main_dir = os.path.dirname(__file__)
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 12:11:14.193014
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000,
        'timescale': 90000,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'height': 720,
        'width': 1280,
    }
    write_piff_header(stream, params)


# Generated at 2022-06-24 12:11:22.510272
# Unit test for function write_piff_header
def test_write_piff_header():
    import io
    stream = io.BytesIO()

# Generated at 2022-06-24 12:11:24.439036
# Unit test for function box
def test_box():
    assert(box(b'mdat', b'') == b'\x00\x00\x00\x08mdat')



# Generated at 2022-06-24 12:11:38.077043
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = dict(track_id=1, fourcc='AACL', duration=0, sampling_rate=44100, codec_private_data='1190')
    write_piff_header(fd, params)

# Generated at 2022-06-24 12:11:42.818520
# Unit test for function full_box
def test_full_box():
    data = (u32.pack(12) + b'free' + u8.pack(0) + u32.pack(0))
    assert full_box(b'free', 0, 0, b'') == data
# Begin unit test for function full_box


# Generated at 2022-06-24 12:11:49.647212
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    #testing
    from . import YoutubeDL
    from .extractor import common
    from .utils import DateRange

    #creating and setting up fake downloader
    ydl = YoutubeDL()
    ydl.params['nopart'] = True
    ydl.params['continuedl'] = False
    ydl.prepare_filename = lambda name: name
    ydl.add_info_extractor = lambda ie: None
    ydl.add_default_info_extractors()
    ydl.process_ie_result = lambda i, ie, r, c: None
    def report_error(msg, tb=None):
        raise Exception(msg)
    ydl.report_error = lambda msg, tb=None: report_error(msg, tb=None)

    #creating fake info dict
    info_dict

# Generated at 2022-06-24 12:11:53.269466
# Unit test for function box
def test_box():
    box('abcd', b'1234') == b'\x00\x00\x00\x0cabcd1234'
    box('abcd', b'123456789') == b'\x00\x00\x00\x12abcd123456789'


# Generated at 2022-06-24 12:12:02.004201
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x04bla\x00\x00\x00\x04bli\x00\x00\x00\x04blo'
    # This should extract "li"
    assert extract_box_data(data, (b'bla', b'bli',)) == b'bli'
    # This should extract "o"
    assert extract_box_data(data, (b'bla', b'bli', b'blo',)) == b'blo'
    # This should raise exception
    try:
        extract_box_data(data, (b'bla', b'bli', b'blo', b'blo',))
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:12:12.633819
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:12:15.202752
# Unit test for function full_box
def test_full_box():
    # Check function full_box
    box_type = b'moov'
    #print box_type
    payload = u8.pack(version) + u32.pack(flags)[1:] + payload
    return box(box_type, payload)



# Generated at 2022-06-24 12:12:26.677532
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest

# Generated at 2022-06-24 12:12:27.451916
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:12:39.216527
# Unit test for function write_piff_header
def test_write_piff_header():
    _input_params = {
        'track_id': 0x1,
        'duration': 0xffffffffffffffff,
        'timescale': 0xffffffff,
        'channels': 0xffff,
        'bits_per_sample': 0xffff,
        'sampling_rate': 0xffffffff,
    }
    stream = io.BytesIO()
    write_piff_header(stream, _input_params)
    actual = stream.getvalue()

# Generated at 2022-06-24 12:12:52.954535
# Unit test for function write_piff_header
def test_write_piff_header():
    import os.path
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 30,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'is_audio': False,
        'codec_private_data': '0000016742C00DFFE0300C20000000168CE3C80DE01000000301101110320A0801000584E800000FA40008BFFD90001000468EBECB1E',
    }
    with io.open(os.path.join(os.path.dirname(__file__), 'test.ismv'), 'rb') as f:
        test_file = f.read()
    test_stream = io.BytesIO()


# Generated at 2022-06-24 12:13:01.963003
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD.fd_class = IsmFD

# Generated at 2022-06-24 12:13:10.243927
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # preparation of test
    import sys
    import os
    import subprocess
    try:
        os.remove("output.ismv")
    except OSError:
        pass
    # test