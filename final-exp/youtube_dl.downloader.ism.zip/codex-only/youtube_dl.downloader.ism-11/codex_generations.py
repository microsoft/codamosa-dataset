

# Generated at 2022-06-24 12:03:17.637326
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\0\0\0\x24moov\0\0\0\x14trak\0\0\0\x10tkhd\0\0\1\x1afoo\0\0\0\x14trak\0\0\0\x10tkhd\0\0\2\x1abar'
    assert extract_box_data(data, (b'moov', b'trak', b'tkhd', b'foo')) == b'\0\0\1\x1afoo'
    assert extract_box_data(data, (b'moov', b'trak', b'tkhd', b'bar')) == b'\0\0\2\x1abar'


# Generated at 2022-06-24 12:03:26.436331
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:35.022260
# Unit test for function full_box
def test_full_box():
    assert full_box(b'pdin', 0, 0, b'\x00\x00\x00\x00\x00\x00\x00'*1) == b'\x00\x00\x00\x00\x70\x64\x69\x6e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00~'



# Generated at 2022-06-24 12:03:40.383005
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'mdat\x00\x00\x00\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    box_sequence = (b'mdat',)
    expected_result = b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    assert(expected_result == extract_box_data(data, box_sequence))



# Generated at 2022-06-24 12:03:48.032463
# Unit test for function full_box
def test_full_box():
    if full_box('ftyp', 1, 1, 'mp42') != binascii.unhexlify('00000018' + 'ftyp' + '01' + '00000001' + 'mp42'):
        raise ValueError('Unit test for function full_box has failed')
# Unit tests for module
# Run unit tests for this module using the following command line:
# python -m youtube_dl.downloader.dash.mp4 \
# --test-full-box

# Generated at 2022-06-24 12:03:50.380819
# Unit test for constructor of class IsmFD
def test_IsmFD():
    if __name__ == '__main__':
        assert IsmFD.FD_NAME == 'ism'

# Generated at 2022-06-24 12:03:54.462917
# Unit test for function box
def test_box():
    # box type = 'mdat'
    assert box(b'mdat', b'') == b'\x08mdat'
    # box type = 'trak'
    assert box(b'trak', b'') == b'\x08trak'


# Generated at 2022-06-24 12:04:02.954408
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import re
    test_cases = [
        {
            'filename': 'ism://manifest',
            'options': {},
            'expected_status': False,
        },
        {
            'filename': 'ism://manifest',
            'options': {'track_id': 1234, 'fourcc': 'AACL', 'duration': 1234, 'timescale': 1000000},
            'expected_status': True,
        },
    ]

    for test_case in test_cases:
        fd = IsmFD(test_case['filename'], test_case['options'])
        if test_case['expected_status']:
            assert fd
        else:
            assert fd is None

# Generated at 2022-06-24 12:04:05.976310
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mvhd', 2, 0, b'') == b'\x00\x00\x00\x0Cmvhd\x00\x02\x00\x00\x00\x00'

# Generated at 2022-06-24 12:04:07.808002
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234') == b'\x00\x00\x00\x0cabcd1234'



# Generated at 2022-06-24 12:04:10.737034
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234') == b'\x00\x00\x00\x0Cabcd1234'


# Generated at 2022-06-24 12:04:12.382267
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    result = IsmFD().real_download('filename', 'info_dict')
    assert result == True



# Generated at 2022-06-24 12:04:17.760205
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    ismFD = IsmFD('http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd')
    assert(ismFD.manifest_url == 'http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd')

# Generated at 2022-06-24 12:04:29.025386
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:04:30.203635
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD({}).FD_NAME == 'ism'


# Generated at 2022-06-24 12:04:35.214724
# Unit test for function box
def test_box():
    assert box(b'aa', b'bb') == b'\x00\x00\x00\x0aaa' + b'bb'
    assert box(b'aa', b'') == b'\x00\x00\x00\x08aa'



# Generated at 2022-06-24 12:04:39.992241
# Unit test for function write_piff_header
def test_write_piff_header():
    handle = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'NONE',
        'duration': 1234567890,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'language': 'eng'
    }
    write_piff_header(handle, params)
    print(handle.getvalue())

# Generated at 2022-06-24 12:04:47.247103
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:04:51.709201
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x0fmoov\x00\x00\x00\x01\x00\x00\x00\x01trak\x00\x00\x00\x01\x00\x00\x00\x01tkhd'
    assert extract_box_data(data, b'moovtraktkhd') == b''
    assert extract_box_data(data, b'moovtrak') == data[8:16]
    assert extract_box_data(data, b'moov') == data[8:]



# Generated at 2022-06-24 12:04:52.282419
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:05:03.909744
# Unit test for function extract_box_data
def test_extract_box_data():
    f = FragmentFD()
    f.write(b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00'
            b'\x00\x00\x00\x00')
    f.seek(0)

# Generated at 2022-06-24 12:05:10.731910
# Unit test for function full_box
def test_full_box():
    version = 0x01
    box_type = b"test"[::-1]
    flags = 0x000000
    payload = b"test payload"[::-1]
    expected = b'\x00\x00\x00\x17test\x01\x00\x00\x00\x00\x00\x00test payload'[::-1]
    assert full_box(box_type, version, flags, payload) == expected



# Generated at 2022-06-24 12:05:11.287588
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:05:22.249753
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()


# Generated at 2022-06-24 12:05:27.535384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    test = IsmFD()
    assert test.FD_NAME == 'ism'


# Generated at 2022-06-24 12:05:29.302975
# Unit test for function box
def test_box():
    assert box(b'SARU', b'Hello') == b'\x00\x00\x00\x0eSARUHello'


# Generated at 2022-06-24 12:05:33.744646
# Unit test for function full_box
def test_full_box():
    box_type = 'abcd'
    version = 0x1
    flags = 0x2
    payload = 'payload'
    result = full_box(box_type, version, flags, payload)
    assert result == '\n\x00\x00\x00abcd\x01\x00\x02\x00\x00payload'


# Generated at 2022-06-24 12:05:40.087078
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'sampling_rate': 0,
        'codec_private_data': '01640028ffe1000b67640028ac2b400f060028aac03c00220216038c0028aac03c0022128000009080400808080808080',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:05:43.388411
# Unit test for function extract_box_data
def test_extract_box_data():
    send_data = box(b'abcd', box(b'efgh', box(b'ijkl', u32.pack(123))))
    assert extract_box_data(send_data, (b'abcd', b'efgh', b'ijkl')) == u32.pack(123)



# Generated at 2022-06-24 12:05:49.256903
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'url': 'http://msft.selcdn.ru/manifest/manifest_medium.ism/manifest(format=mpd-time-csf)'})

# Generated at 2022-06-24 12:05:58.425682
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .common import dict_selection

    ydl = FakeYDL()
    ydl.params['skip_download'] = True

    test_cases = [
        # test1.smoothstreaming.com
        'http://playready.directtaps.net/pr/svc/rightsmanager.asmx?UseSimpleNonPersistentLicense=1&PlayRight=1&ContentKey=EAtsIJQPd5pFiRUrV9Layw==&log=1',
        # test2.isma.streaming.mediaservices.windows.net
        'http://media.w3.org/2010/05/sintel/trailer.mp4',
    ]


# Generated at 2022-06-24 12:06:01.932477
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 2, b'hello') == b'\x00\x00\x00\x0e\x6d6f6f76\x01\x00\x00\x02hello'



# Generated at 2022-06-24 12:06:11.836923
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import YoutubeIE
    from ..utils import prepend_extension

    ie = YoutubeIE({})
    ism_fd = IsmFD(ie, {'format_id': '22'})

    assert ism_fd.format_id() == '22'

    assert ism_fd.destination(prepare_filename('test.ismv')) == prepend_extension('test.ismv', 'mp4')

# Generated at 2022-06-24 12:06:16.017864
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import pytest
    from youtube_dl.utils import *

    if __name__ == '__main__':
        # pytest.main()
        raise NotImplementedError('TODO: Add unit tests')


# Generated at 2022-06-24 12:06:19.379167
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism = IsmFD({'url': 'http://test.com/test.ism/manifest(format=mpd-time-csf)'})
    assert ism.fd_name() == 'ism'

    test_IsmFD.test_counter += 1

test_IsmFD.test_counter = 0

# Generated at 2022-06-24 12:06:30.285800
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert False
    # FIXME
    # 1. Download the XML and get the list of fragments, that's a single URL
    xml_url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    xml_req = compat_urllib_request.Request(xml_url)
    xml_req.add_header('Icy-MetaData', '1')
    xml_data = urlopen(xml_req).read()
    xml_code = re.search(r',[^,]*,([0-9]*),', xml_data).group(1)
    xml_manifest = urlopen(xml_url + '?str=' + xml_code).read()
    playlist = parse_xml(xml_manifest)['playlist']

# Generated at 2022-06-24 12:06:31.564786
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD(None, {'format': 'ism'}, None, None)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:06:35.090137
# Unit test for constructor of class IsmFD
def test_IsmFD():
    extractor = IsmFD(None, {'format': 'ism'}, None)
    assert extractor.FD_NAME == 'ism'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:06:38.743321
# Unit test for function full_box
def test_full_box():
    test_box_type = u32.unpack(full_box(box_type=u32.pack(0x6D6F6F76), version=0, flags=0, payload=u32.pack(0)))
    assert test_box_type[0] == 0x6D6F6F76

# Generated at 2022-06-24 12:06:48.999325
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_str

    class TestYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.test_result = {
                'downloaded_bytes': 0,
                'dest_filename': ''
            }
            super(TestYDL, self).__init__(*args, **kwargs)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-24 12:06:52.962756
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with valid input
    test_IsmFD_valid_input = IsmFD(params={}, _downloader=None)
    # Test with invalid input
    try:
        IsmFD(params='params', _downloader=None)
    except TypeError:
        pass
    except:
        raise AssertionError('Unexpected exception thrown')

test_IsmFD()


# Generated at 2022-06-24 12:07:01.718208
# Unit test for function extract_box_data
def test_extract_box_data():
    data = extract_box_data(
        u32.pack(160) + b'moov' + b'a' * 152,
        (b'moov',))
    assert len(data) == 152

    data = extract_box_data(
        u32.pack(160) + b'moov' + u32.pack(152) + b'mvex' + u32.pack(152) + b'trex' + u32.pack(64) + b'ab' + u32.pack(40) + b'cd' + b'e' * 44,
        (b'moov', b'mvex', b'trex', b'ab'))
    assert len(data) == 64


# Generated at 2022-06-24 12:07:11.720899
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:07:15.092376
# Unit test for function box
def test_box():
    assert box('a'.encode(), '1234'.encode()) == b'\x00\x00\x00\r' + 'a'.encode() + \
                                                '1234'.encode()



# Generated at 2022-06-24 12:07:25.814042
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for method real_download of class IsmFD
    """
    import sys
    import os
    import tempfile
    import shutil
    import random
    from youtube_dl.YoutubeDL import YoutubeDL

    # Test parameters
    param_test = {
        'url': 'http://www.dailymotion.com/video/x2a4e4w_how-to-become-a-security-guard-in-alberta_news',
        'playlistend': 1,
        'noplaylist': True,
        'quiet': True,
        'simulate': True
    }

    # Test
    print('Testing method real_download of class IsmFD...')
    tmp_dir = None
    out_file = None

# Generated at 2022-06-24 12:07:31.402342
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.__name__ == 'IsmFD'



# Generated at 2022-06-24 12:07:36.846777
# Unit test for function extract_box_data
def test_extract_box_data():
    def sanity(data, box_sequence, expected):
        data_reader = io.BytesIO(data)
        while True:
            box_size = u32.unpack(data_reader.read(4))[0]
            box_type = data_reader.read(4)
            if box_type == box_sequence[0]:
                box_data = data_reader.read(box_size - 8)
                if len(box_sequence) == 1:
                    assert(box_data == expected)
                    return
                sanity(box_data, box_sequence[1:], expected)
                return
            data_reader.seek(box_size - 8, 1)
        assert(False)

# Generated at 2022-06-24 12:07:42.531321
# Unit test for function full_box
def test_full_box():
    payload = "test payload"
    assert full_box("test", version=0, flags=0, payload=payload).encode('hex') == "000000007465737400000000" + '{:08x}'.format(8+len(payload))+"74657374" + "00000400" + "74657374206170706c6579"



# Generated at 2022-06-24 12:07:52.157874
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000,
            'timescale': 10000,
            'height': 720,
            'width': 1280,
            'codec_private_data': '01640022ffe10014674d001f9a041421f9a12ff81068020e0e45d1a9a0e95f1c05b88032f10800',
        })
        stream.seek(0)

# Generated at 2022-06-24 12:07:54.577600
# Unit test for function full_box
def test_full_box():
    #TODO:
    print(full_box('free', 0, 0, ''))


# Generated at 2022-06-24 12:08:03.190004
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:08:06.071103
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
    assert box(b'moov', b'\x00\x00\x00\x08mvhd') == b'\x00\x00\x00\x14moov\x00\x00\x00\x08mvhd'


# Generated at 2022-06-24 12:08:15.612365
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:24.690485
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    track_id = 1
    fourcc = 'mp4a'
    duration = 8000000

# Generated at 2022-06-24 12:08:27.258416
# Unit test for function full_box
def test_full_box():
    assert binascii.hexlify(full_box(b'hvc1', 1, 0x00000, b'wtf')) == b'0000000c687633310000000000000'



# Generated at 2022-06-24 12:08:36.305684
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'https://manifest.us.sling.com/v2/hls/102.ism/Manifest?format=m3u8-aapl-v3'
    ydl = YoutubeDL()
    info_dict = ydl.extract_info(url, download=False)

# Generated at 2022-06-24 12:08:39.525958
# Unit test for function box
def test_box():
    assert box('mdat', '') == b'\x00\x00\x00\nmdat'
    assert box('mdat', 'asdf') == b'\x00\x00\x00\rmdatasdf'
test_box()


# Generated at 2022-06-24 12:08:49.948978
# Unit test for function extract_box_data
def test_extract_box_data():
    import random
    import struct
    def build_box(box_type, box_size):
        payload = "".join([chr(random.randint(0,255)) for x in range(box_size - 8)])
        return struct.pack(">i4s", box_size, box_type) + payload
    data = build_box("A", 12)
    data += build_box("B", 16)
    data += build_box("C", 20)
    box_data = extract_box_data(data, ["A"])
    assert len(box_data) == 4
    box_data = extract_box_data(data, ["B"])
    assert len(box_data) == 8
    box_data = extract_box_data(data, ["C"])
    assert len(box_data) == 12

# Generated at 2022-06-24 12:09:00.746466
# Unit test for function extract_box_data
def test_extract_box_data():
    fragment = FragmentFD()
    fragment.url = 'https://dash-mse-test.commondatastorage.googleapis.com/media/cars-format0-track1-init.mp4'
    fragment.headers = {'Range': 'bytes=0-%d' % (8 * 1024)}
    fragment.open()
    data = fragment.read()
    fragment.close()
    ftyp_payload = extract_box_data(data, [b'ftyp'])
    assert ftyp_payload[:4] == b'isml', ftyp_payload[:4]
    assert ftyp_payload[4:] == b'\x00\x00\x00\x01piffiso2', ftyp_payload[4:]

# Generated at 2022-06-24 12:09:05.709992
# Unit test for function box
def test_box():
    content = b'\x00' * 5
    result = box(b'moov', content)
    assert result == b'\x00\x00\x00\x0dmoov\x00\x00\x00\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Python 2.7 compatibility

# Generated at 2022-06-24 12:09:08.288209
# Unit test for function full_box
def test_full_box():
    assert full_box(b'avc1', 0, 0, b'') == b'\x00\x00\x00\x0Cavc1\x00\x00\x00\x00'



# Generated at 2022-06-24 12:09:09.557140
# Unit test for constructor of class IsmFD
def test_IsmFD():

    from ytdl.extractor.fragment.ism import IsmFD

    assert IsmFD.FD_NAME == 'ism'

# Generated at 2022-06-24 12:09:11.548937
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'\x00' * 108) == bytes.fromhex('0000007c6d7668640000000000000000000000000000000000000000000000000000000000000040000000fffefffffffeffff000000000000000000000000000000010000000000000000000000000000000100000000000000000000000000000001fffffffc000000000000000000000064000000000001fffffffc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')


# Generated at 2022-06-24 12:09:12.341169
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:09:22.027356
# Unit test for function extract_box_data
def test_extract_box_data():
    assert(
        extract_box_data(b'\x00\x00\x00\x1cftyp\x00\x00\x00\x00isml\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00piff\x00\x00\x00\x00iso2', [b'ftyp']) ==
        b'\x00\x00\x00\x00isml\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00piff\x00\x00\x00\x00iso2'
    )



# Generated at 2022-06-24 12:09:27.799351
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {
        'fragments': [{'url': 'fragment_1'}, {'url': 'fragment_2'}]
    }

    ydl = FakeYDL()

    ism_fd = IsmFD(ydl, info_dict)
    assert ism_fd.total_frags == 2
    assert ism_fd.done == 0
    assert ism_fd.frag_index == 0


# Generated at 2022-06-24 12:09:34.397890
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import InfoExtractor
    import os

    class FakeYDL(object):

        params = {}

        class FakeIE(InfoExtractor):
            _VALID_URL = ''

            @staticmethod
            def ie_key():
                return ''


# Generated at 2022-06-24 12:09:39.432765
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'
    assert box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x10moov\x00\x00\x00\x00'


# Generated at 2022-06-24 12:09:45.535854
# Unit test for constructor of class IsmFD

# Generated at 2022-06-24 12:09:55.414781
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..compat import parse_qsl
    from ..utils import parse_iso8601
    test_url = 'https://d2zihajmogu5jn.cloudfront.net/bipbop-advanced/bipbop_16x9_variant.m3u8'
    # The key 'start-date' is optional and is needed for live streams.
    test_info = dict(
            (k, compat_urllib_parse_unquote(v))
            for k, v in parse_qsl(test_url.partition('?')[2]))

# Generated at 2022-06-24 12:10:06.259494
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:18.149877
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD().FD_NAME == 'ism'
    assert IsmFD.FD_NAME == 'ism'


# Generated at 2022-06-24 12:10:21.428125
# Unit test for function box
def test_box():
    assert u32.pack(0x08) + b'mdat' == box(b'mdat', b'')
    assert u32.pack(0x07) + b'mdat' + b'\x00' == box(b'mdat', b'\x00')



# Generated at 2022-06-24 12:10:30.036955
# Unit test for function box
def test_box():
    # box('ftyp', b'qt  \0\0\0\0isomiso2avc1\0')
    assert box('ftyp', b'qt  \0\0\0\0isomiso2avc1\0'
               ) == b'\x00\x00\x00\x14ftypqt  \0\0\0\0isomiso2avc1\0'
# end::ut3[]
# end::ut2[]


# Generated at 2022-06-24 12:10:42.494001
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000,
            'timescale': 10000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'sampling_rate': 48000,
            'channels': 2,
            'bits_per_sample': 16,
            'codec_private_data': '0000000167640033ACD88B8C800000030080000001000688E300A020100000012E24A568AD7CB3A',
        }
        write_piff_header(stream, params)
        result = stream.getvalue()

# Generated at 2022-06-24 12:10:50.378332
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('f:\\test.mp4', 'rb') as f:
        data = f.read()
    box_data = extract_box_data(data, ('ftyp', 'mp42',))
    assert box_data == b'isml\x00\x00\x00\x18piff\x00\x00\x00\x04iso2\x00\x00\x00\x04piff\x00\x00\x00\x04iso2'



# Generated at 2022-06-24 12:10:59.061251
# Unit test for function full_box
def test_full_box():
    box_type = b'mvhd'
    version = 0
    flags = 0
    payload = u32.pack(0) + u32.pack(int(time.time() * 1000)) + u32.pack(1) + unity_matrix

# Generated at 2022-06-24 12:11:10.985462
# Unit test for function box
def test_box():
    '''verify the function box is working according to the spec'''
    assert box(b'mvhd', u32.pack(0) * 2) == b'\x00\x00\x00\x14mvhd\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert box(b'mvhd', u32.pack(12345678) * 2) == b'\x00\x00\x00\x14mvhd\x00\x00\x04\xbf\x46\xde\x42\x00\x00\x00\x00\x00\x00\x04\xbf\x46\xde\x42'
    assert box

# Generated at 2022-06-24 12:11:19.338169
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import is_url
    from .compat import parse_qs
    import os.path
    import shutil
    from io import BytesIO
    from .downloader import Downloader


    class FakeYDL(object):
        def __init__(self):
            self.params = {'outtmpl': 'test'}
        def to_screen(self, s):
            pass
        def trouble(self, s, tb=None):
            raise Exception('trouble: ' + s)
        def report_error(self, s, tb=None):
            raise Exception('report_error: ' + s)
        def download(self, info_dict):
            if isinstance(info_dict, dict):
                info_dict = [info_dict]

# Generated at 2022-06-24 12:11:27.740845
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    video_params = {
        'track_id': 0x1,
        'fourcc': 'AVC1',
        'duration': 9572,
        'timescale': 10000000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd94080001f8c701e2fc25a28180000003008000001c58d0',
        'nal_unit_length_field': 4,
    }

# Generated at 2022-06-24 12:11:30.759838
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'


# Generated at 2022-06-24 12:11:31.336629
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:11:37.974587
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:40.578696
# Unit test for function box
def test_box():
    assert box('ftyp', 'isom') == b'\x00\x00\x00\nftypisom'



# Generated at 2022-06-24 12:11:46.480439
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:51.992080
# Unit test for function full_box
def test_full_box():
    box_type = 'stts'
    version = 0
    flags = 0
    payload = u32.pack(1)
    size = len(payload) + 12
    assert full_box(box_type, version, flags, payload) == u32.pack(size) + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload
#    full_box(box_type, version, flags, payload) == u32.pack(size) + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload
#    assert 1==2


# Generated at 2022-06-24 12:12:01.282673
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # initialize class IsmFD
    ydl = YoutubeDL({'verbose': False, 'nooverwrites': True, 'quiet': True, 'simulate': True, 'skip_download': True, 'format': 'bestvideo[protocol^=http]/bestaudio'})
    ydl.add_default_info_extractors()
    ydl_fd = IsmFD(ydl, {'format': 'bestvideo[protocol^=http]/bestaudio'}, {})

    # create test environment
    def load_manifest_json(url):
        with io.open('test/manifest.json', 'rb') as f:
            return f.read()
    ydl_fd.ydl.cache.load_manifest_json = load_manifest_json


# Generated at 2022-06-24 12:12:11.673300
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000000,
            'timescale': 10000000,
            'height': 0,
            'width': 0,
            'sampling_rate': 48000,
            'channels': 2,
            'bits_per_sample': 16,
            'codec_private_data': '1210',
            'language': 'eng',
        }
        write_piff_header(stream, params)
        mvex_header = full_box(b'mehd', 1, 0, u64.pack(10000000))  # Movie Extends Header Box

# Generated at 2022-06-24 12:12:14.886709
# Unit test for function box
def test_box():
    assert box(b'free', b'') == b'\x00\x00\x00\x08free'
    assert box(b'free', b'12345678') == b'\x00\x00\x00\x10free12345678'



# Generated at 2022-06-24 12:12:21.290576
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # mock
    import pytube

    class _Mock_Mock:

        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return _Mock_Mock()

        @classmethod
        def __getattr__(cls, name):
            if name in ('__file__', '__path__'):
                return '/dev/null'
            elif name[0] == name[0].upper():
                mock_type = type(name, (), {})
                mock_type.__module__ = __name__
                return mock_type
            else:
                return _Mock_Mock()
    patcher1 = patch.object(pytube, 'Youtube', autospec=True)

# Generated at 2022-06-24 12:12:25.855262
# Unit test for function box
def test_box():
    box1 = box(b'moov', b'')
    assert u32.unpack(box1[:4]) == [8]
    assert box1[4:] == b'moov'


# Generated at 2022-06-24 12:12:34.217917
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'channels': 2,
        'duration': 4000000
    })

# Generated at 2022-06-24 12:12:36.452107
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Unit test for method real_download of class IsmFD
    """
    # Create target instance
    target_obj = IsmFD()
    # Call method real_download(filename, info_dict)
    target_obj.real_download('filename', {})

##############################################################################################################

# Class VideoFD

# Generated at 2022-06-24 12:12:37.285207
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:12:46.371612
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:12:53.928061
# Unit test for function box
def test_box():
    assert box('foo ', b'abcdefg') == (
        b'\x00\x00\x00\x14'   # payload length
        b'foo '               # box type
        b'abcdefg')           # payload

# Box types
FTYP = b'ftyp'
MOOV = b'moov'
MVHD = b'mvhd'
TRAK = b'trak'
TKHD = b'tkhd'
MDIA = b'mdia'
MDHD = b'mdhd'
HDLR = b'hdlr'
MINF = b'minf'
SMHD = b'smhd'
DINF = b'dinf'
DREF = b'dref'
URL = b'url '
STBL = b'stbl'
STSD = b'stsd'
AVC1

# Generated at 2022-06-24 12:13:01.966658
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class ret_IsmFD(IsmFD):
        def _download_fragment(self, ctx, url, info_dict):
            fail_dl = self.params.get('fail_dl')

# Generated at 2022-06-24 12:13:08.218143
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl_opts = {
        'fragment_retries': 100,
        'skip_unavailable_fragments': True,
        'test': True
    }
    ydl = YoutubeDL(ydl_opts)
    info_dict = {
        'fragments': [{
            'url': 'https://manifest.googlevideo.com/api/manifest/dash/'
        }],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 238756,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0
        }
    }