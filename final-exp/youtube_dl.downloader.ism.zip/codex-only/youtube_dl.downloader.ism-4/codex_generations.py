

# Generated at 2022-06-24 12:03:11.681046
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.__name__ == 'IsmFD'



# Generated at 2022-06-24 12:03:19.823496
# Unit test for function box
def test_box():
    # Box parameters
    box_type = 'abcd'
    payload = '123456'
    expected_output = u32.pack(8 + len(payload)) + box_type + payload
    actual_output = box(box_type, payload)
    assert actual_output == expected_output, 'expected output \n%s\nbut got \n%s' % (expected_output, actual_output)


# Generated at 2022-06-24 12:03:25.062921
# Unit test for function write_piff_header
def test_write_piff_header():
    temp_file = io.BytesIO()
    params = {
        "track_id": 1,
        "fourcc": "H264",
        "duration": 10000,
        "timescale": 10000,
        "language": "und",
        "height": 240,
        "width": 320,
        "codec_private_data": "0000000167640032ACB80012E1FFE10014FA0BB80384C000F086e0d68a0",
        "nal_unit_length_field": 4
    }
    write_piff_header(temp_file, params)
    bytes = temp_file.getvalue()


# Generated at 2022-06-24 12:03:36.024087
# Unit test for function write_piff_header
def test_write_piff_header():
    import json, sys
    import hashlib

    def _compute_md5(name):
        h = hashlib.md5()
        with io.open(name, 'rb') as f:
            while True:
                chunk = f.read(4096)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    params = json.loads(sys.argv[1])
    params['track_id'] = 1
    with io.open(sys.argv[2], 'wb') as f:
        write_piff_header(f, params)
    print(_compute_md5(sys.argv[2]))

test_write_piff_header()


# Generated at 2022-06-24 12:03:44.711847
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:03:58.602612
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test 2.1
    import sys, datetime
    # Test 2.2
    test_params = {
        'progress_hooks': [
            lambda d: sys.stdout.write(
                'Downloaded {0:.2%}\n'.format(d.get('downloaded_bytes', 0) / float(d['total_bytes']))
            if d['status'] == 'downloading' else ''
        )],
        'test': True,
    }
    def _run_test(url, params):
        t0 = datetime.datetime.now()
        with IsmFD(params) as dl:
            result = dl.download([url])
        sys.stdout.write('Download time: {0}\n'.format(datetime.datetime.now() - t0))

# Generated at 2022-06-24 12:04:01.427354
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # test basic constructor of IsmFD
    IsmFD("http://www.youtube.com/get_video_info?video_id=C0DPdy98e4c")



# Generated at 2022-06-24 12:04:11.276584
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    stream = BytesIO()
    params = dict(
        track_id = 1,
        fourcc='AVC1',
        duration=100,
        #timescale=30,
        width=640,
        height=480,
        #language='eng',
        #channels=2,
        #bits_per_sample=16,
        #sampling_rate = 44100,
        codec_private_data='67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ffe1001b67428029ff',
    )
    write_

# Generated at 2022-06-24 12:04:16.273188
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD(params=test_params)
    assert test_IsmFD.FD_NAME == 'ism'
    assert test_IsmFD.params == test_params

test_params = {
    'test': True,
    'fragment_retries': 1,
    'skip_unavailable_fragments': True,
}


# Generated at 2022-06-24 12:04:21.671283
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .youtube_dl.YoutubeDL import YoutubeDL
    ydl_opts = {
        'quiet': True,
        'skip_download': True,
        'forceurl': True,
        'forcetitle': True,
        'forceprintid': True,
        'simulate': True,
    }

# Generated at 2022-06-24 12:04:27.699295
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    class BoxTest(unittest.TestCase):
        def test_extract_box_data(self):
            import binascii

# Generated at 2022-06-24 12:04:33.182692
# Unit test for constructor of class IsmFD
def test_IsmFD():
#Create an instance of class IsmFD
    my_IsmFD = IsmFD()

if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-24 12:04:41.178414
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # download example
    import youtube_dl
    opt = {
        'fragment-retries': 10,
        'test': True,
    }
    ydl = youtube_dl.YoutubeDL(opt)

    manifest_url = 'https://amssamples.streaming.mediaservices.windows.net/683f7e47-bd83-4427-b0a3-26a6c4547782/BigBuckBunny.ism/manifest(format=mpd-time-csf)'

# Generated at 2022-06-24 12:04:48.175192
# Unit test for function full_box
def test_full_box():
	print("Testing full_box(b'fmt ', 0, 0, b'\x00' * 3)")
	print(full_box(b'fmt ', 0, 0, b'\x00' * 3))
	#Expected output: b'\x00\x00\x00\x10fmt \x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
#test_full_box()


# Generated at 2022-06-24 12:04:52.252018
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'moov\x00\x00\x00\x08'
    assert box(u8.pack(0x04), u8.pack(0x02)) == b'\x00\x00\x00\x0A\x04\x00\x02'



# Generated at 2022-06-24 12:05:02.010226
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'stbl', b'tsd')
    data_reader = io.BytesIO(open('stbl.tsd', 'r').read())
    box_size = u32.unpack(data_reader.read(4))[0]
    box_type = data_reader.read(4)
    assert box_type == box_sequence[0]
    box_data = data_reader.read(box_size - 8)
    assert extract_box_data(box_data, box_sequence[1:]) == open('tsd.tsd', 'r').read()


# Generated at 2022-06-24 12:05:05.885500
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor

    ie = InfoExtractor()
    ie.add_info_extractor(IsmFD())
    ie.extract('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest')


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:05:09.266992
# Unit test for function full_box
def test_full_box():
    expected_full_box = binascii.a2b_hex('00 00 00 0c') + b'mvhd' + binascii.a2b_hex('01 00 00 00 00 00 01 00')
    assert full_box(b'mvhd', 1, 1, b'') == expected_full_box, "full_box is not correct"



# Generated at 2022-06-24 12:05:14.689633
# Unit test for function full_box
def test_full_box():
    VERSION = 1
    GENERATION_FLAGS = 0x00000008
    PAYLOAD = b'\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03'
    b = full_box(b'moov', VERSION, GENERATION_FLAGS, PAYLOAD)
    assert u32.unpack(b[:4])[0] == len(b)
    assert b[4:8] == b'moov'
    assert u8.unpack(b[8:9])[0] == VERSION
    assert u32.unpack(b[9:13])[0] == GENERATION_FLAGS
    assert b[13:] == PAYLOAD
test_full_box()


# Generated at 2022-06-24 12:05:26.649240
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import os.path
    import threading
    import socket
    import base64
    import hashlib
    import re
    import errno

    HOST = 'localhost'
    PORT = random.randrange(1024, 65535)
    real_download_test_dir = os.path.dirname(os.path.abspath(__file__))
    ISM_test_dir = os.path.join(real_download_test_dir, "ISM_test_dir")
    manifest_file_path = os.path.join(ISM_test_dir, "manifest")
    manifest_json_file_path = os.path.join(ISM_test_dir, "manifest.json")

# Generated at 2022-06-24 12:05:28.489517
# Unit test for function box
def test_box():
    assert(box(b'abcd', b'123') == b'\x00\x00\x00\x0babcd123')


# Generated at 2022-06-24 12:05:29.764749
# Unit test for constructor of class IsmFD
def test_IsmFD():
    utils.run_test_class(IsmFD)

# Unit test

# Generated at 2022-06-24 12:05:36.643450
# Unit test for function write_piff_header
def test_write_piff_header():
    # On Windows, console uses Windows CP, and we need to encode as UTF-16 to be able to write that to a file.
    # We use io.open() for that purpose.
    with io.open('test_fragment.ismv', 'wb') as test:
        write_piff_header(test, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 30000000,
            'timescale': 10000000,
            'height': 480,
            'width': 640,
            'codec_private_data': '0000000167640032acd904c0',
        })



# Generated at 2022-06-24 12:05:44.477689
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:05:56.126035
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:06:05.576042
# Unit test for function write_piff_header
def test_write_piff_header():
    import os

    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'height': 240,
        'width': 320,
        'duration': 5000000000,
        'fourcc': 'H264',
        'language': 'und',
        'codec_private_data': '01640028ffe100156cc10dc5883008d803801f00040001b67c0101164080101002000ffff01000001e845fc4a',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

    file_path = './write_piff_header.ism'
    if os.path.isfile(file_path):
        os.unlink(file_path)

# Generated at 2022-06-24 12:06:17.300645
# Unit test for constructor of class IsmFD
def test_IsmFD():
    segment_urls = [
        'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/QualityLevels(230000)/Fragments(video=0)'
    ]

# Generated at 2022-06-24 12:06:28.205764
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .m3u8_native import M3U8FD
    # Test audio PIFF
    url = 'aHR0cDovL2dvbGFuZy5tZWRpYXRyYW5zZmVyLmNvbS9nYW1lY2hhdC9ncC9tb2R1bGUvYWR2aXNvZnQvZmlsZS50eHQ='
    username = 'cHJvamVjdC10dXMtY2hhdA=='
    password = 'cHJvamVjdC10dXMtY2hhdA=='

# Generated at 2022-06-24 12:06:39.352619
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl = YoutubeDL(params={
        'quiet': True,
        'nooverwrites': True,
        'skip_download': True,
        'format': 'ism',
        'outtmpl': 'test_IsmFD_real_download.ism',
        'fragment_retries': 1,
    })
    ydl.add_info_extractor(SmoothStreamsIE())
    ydl.add_info_extractor(SmoothStreamsPlaylistIE())
    ydl.add_info_extractor(DashSegmentsIE())
    test_url = 'http://delivery1.dash.live.switch.ch/test/unit/test_dash.mpd'
    info = ydl.extract_info(test_url, download=False)

# Generated at 2022-06-24 12:06:46.183554
# Unit test for function full_box
def test_full_box():
    box_type='abcd'
    version=1
    flags=1
    payload='123'
    assert full_box(box_type, version, flags, payload)=='\x00\x00\x00\x0babcd\x01\x00\x01\x00\x00123'



# Generated at 2022-06-24 12:06:51.562937
# Unit test for function extract_box_data
def test_extract_box_data():
    dummy_data = b'\x00\x00\x00\tmoov'
    assert extract_box_data(dummy_data, [b'moov']) == b''
    dummy_data = b'\x00\x00\x00\x0cmoov\x00\x00\x00\x06mvhd\x00\x00\x00\x00'
    assert extract_box_data(dummy_data, [b'moov', b'mvhd']) == b'\x00\x00\x00\x00'



# Generated at 2022-06-24 12:06:58.747842
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # http://www.hydrogenaudio.org/forums/index.php?showtopic=69280
    test_url = "http://www.pandora.com/radio/radio.mpd"
    test_file = "/tmp/test.piff"

    ydl = YoutubeDL(YoutubeDL.params)
    ydl.add_info_extractor(IsmIE)
    ydl.add_default_info_extractors()
    setattr(ydl, 'process_video_result', lambda info: info)
    #ydl.process_ie_result(ydl.extract_info(test_url, download=True))
    try:
        os.remove(test_file)
    except OSError:
        pass


# Generated at 2022-06-24 12:07:06.935523
# Unit test for function write_piff_header
def test_write_piff_header():
    import unittest

    class PiffHeaderTests(unittest.TestCase):
        def _run_test(self, params):
            stream = io.BytesIO()
            write_piff_header(stream, params)
            stream.seek(0)
            ftyp = stream.read(8)
            self.assertEqual(ftyp, b'\0\0\0\x18ftypisml')
            moov = stream.read()

# Generated at 2022-06-24 12:07:18.383227
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:07:27.464284
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:07:29.712237
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == '\x00\x00\x00\x0c' 'abcd' '1234'



# Generated at 2022-06-24 12:07:33.476807
# Unit test for function full_box
def test_full_box():
    payload = u8.pack(1) + u32.pack(2)[1:] + b'is payload'
    assert full_box(b'moov', 1, 2, b'is payload') == box(b'moov', payload)



# Generated at 2022-06-24 12:07:42.436952
# Unit test for function write_piff_header
def test_write_piff_header():
    import logging
    import os
    import struct
    import tempfile
    from ..utils import (
        determine_ext,
        HEADRequest,
        parse_codecs,
        sanitize_open,
        sanitize_filename,
        SearchInfoExtractor,
        update_url_query,
        verify_url,
    )
    logging.basicConfig(level= logging.DEBUG)
    '''
    Download a sample video
    '''
    class MyIE(SearchInfoExtractor):
        def _real_initialize(self):
            self._downloader.cache.remove('-1')
            
    ie = MyIE()
    ie.initialize()

# Generated at 2022-06-24 12:07:52.094687
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_params = {
        'skip_unavailable_fragments': True,
        'format': 'ism',
        'manifest_url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
        'live': True,
        'playback_url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism',
        'outtmpl': 'C:/Users/admin/Desktop/%(id)s.%(format)s',
    }
    fd = IsmFD(test_params)
    print(fd.FD_NAME)
    print(fd.outtmpl)

# Generated at 2022-06-24 12:08:03.400572
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ret = 1
    tmpfile = tempfile.NamedTemporaryFile(suffix = ".ism")
    tmpfile.close()

    try:
        os.remove(tmpfile.name)
    except:
        pass

    from .YoutubeDl import YoutubeDL
    from .YoutubeDl.extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
        YoutubeChannelIE,
        _make_result,
        _parse_age_limit,
    )
    from .YoutubeDl import YoutubeDL

    ydl = YoutubeDL({'quiet': True, 'no_warnings': True, 'playlist_items': [45]})

    ydl.add_info_extractor(YoutubeIE(ydl))
    ydl.add_info_extractor(YoutubePlaylistIE(ydl))
    y

# Generated at 2022-06-24 12:08:14.529762
# Unit test for function extract_box_data
def test_extract_box_data():
    data1 = box(b'foo', b'bar')
    data2 = box(b'foo', box(b'bar', b'baz'))
    data3 = box(b'foo', box(b'bar', box(b'baz', b'qux')))
    assert extract_box_data(data1, (b'foo',)) == b'bar'
    assert extract_box_data(data2, (b'foo', b'bar')) == b'baz'
    assert extract_box_data(data3, (b'foo', b'bar', b'baz')) == b'qux'
    # Test malformed data
    data4 = b'hello'

# Generated at 2022-06-24 12:08:21.346462
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x0a\x6d\x6f\x6f\x76\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x61\x76\x63\x31'
    assert extract_box_data(data, (b'moov', b'avc1')) == b'\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 12:08:29.344584
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class Options:
        hls_prefer_native = None
        hls_prefer_ffmpeg = None
        hls_use_mpegts = None

    opts = Options()
    opts.hls_prefer_native = False
    opts.hls_prefer_ffmpeg = True
    opts.hls_use_mpegts = False

# Generated at 2022-06-24 12:08:30.263355
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass



# Generated at 2022-06-24 12:08:38.730237
# Unit test for constructor of class IsmFD
def test_IsmFD():
    q = IsmFD({})
    IsmFD.params = {}
    IsmFD.params['fragment_retries'] = 2
    IsmFD.params['skip_unavailable_fragments'] = False
    IsmFD.params['test'] = False

    assert not q.real_download('a', {'_download_params': {'track_id': 1, 'fourcc': 'AACL', 'duration': 0}})
    assert IsmFD.real_download('a', {'_download_params': {'track_id': 1, 'fourcc': 'AACL', 'duration': 0}})

# Generated at 2022-06-24 12:08:41.288794
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test IsmFD Constructor
    """
    instance = IsmFD({}, {}, None)
    assert isinstance(instance, IsmFD)


# Generated at 2022-06-24 12:08:51.442049
# Unit test for function full_box
def test_full_box():
    assert full_box(b'\xaf\xd9\x68\x6b', 0, 0, b'') == b'\x00\x00\x00\x10\xaf\xd9\x68\x6b\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 12:09:02.756435
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from .download import _make_readers

    streams, reader = _make_readers('https://www.youtube.com/watch?v=F7rJc-rkAYg', {})
    with reader.open(streams[0]) as stream:
        stream = BytesIO()
        params = {
            'track_id': 1,
            'duration': 30,
            'timescale': 90000,
            'fourcc': 'AACL',
            'channels': 2,
            'sampling_rate': 44100,
            'bits_per_sample': 16,
        }
        write_piff_header(stream, params)
        return stream.getvalue()

if __name__ == '__main__':
    print(test_write_piff_header())


# Generated at 2022-06-24 12:09:10.387142
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()
    params = {
        'track_id': 1,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'duration': 1548552931,
        'fourcc': 'AACL',
    }
    write_piff_header(out, params)

# Generated at 2022-06-24 12:09:22.083342
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-24 12:09:24.384192
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
test_box()


# Generated at 2022-06-24 12:09:32.595801
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import make_ht_bytes
    from io import BytesIO

    stream = BytesIO()

# Generated at 2022-06-24 12:09:42.838628
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'width': 1280,
        'height': 720,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
    }
    params['duration'] = 25000
    params['language'] = 'spa'
    write_piff_header(stream, params)
    print(stream.getvalue().hex())

# Generated at 2022-06-24 12:09:45.448793
# Unit test for function box
def test_box():
    assert(box('foo ', 'bar') == '\x00\x00\x00\nfoo bar')



# Generated at 2022-06-24 12:09:48.132148
# Unit test for function box
def test_box():
    assert box('abcd', 'defg') == b'\x00\x00\x00\x0cabcd' + b'defg'


# Generated at 2022-06-24 12:09:57.841487
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:10:03.467129
# Unit test for function write_piff_header
def test_write_piff_header():
    is_audio = True
    track_id = 1
    duration = 1000000000
    timescale = 10000000
    language = 'und'
    fourcc = 'AACL'
    creation_time = modification_time = int(time.time())
    params = {
        'track_id': track_id,
        'fourcc': fourcc,
        'duration': duration,
        'timescale': timescale,
        'language': language,
        'is_audio': is_audio,
        'creation_time': creation_time,
        'modification_time': modification_time,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    print(stream.getvalue())
    return True

test_write_piff_header()



# Generated at 2022-06-24 12:10:06.674918
# Unit test for function box
def test_box():
    assert box(b'\x00\x00\x00\x00', b'') == b'\x00\x00\x00\x08\x00\x00\x00\x00'



# Generated at 2022-06-24 12:10:15.889116
# Unit test for function extract_box_data
def test_extract_box_data():
    header = b'\x00\x00\x00\x0cfoob\x00\x00\x00\x0cfoob\x00\x00\x00\x0cfoob'
    assert extract_box_data(header, [b'foob']) == b'\x00\x00\x00\x0cfoob'
    assert extract_box_data(header, [b'foob', b'foob']) == b'\x00\x00\x00\x0cfoob'
    assert extract_box_data(header, [b'foob', b'foob', b'foob']) == b''



# Generated at 2022-06-24 12:10:17.579364
# Unit test for function full_box
def test_full_box():
    # Todo
    pass


# Generated at 2022-06-24 12:10:23.896422
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test the constructor of class IsmFD
    """
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor

    # Build a mock YoutubeDL object
    ydl = YoutubeDL({})
    ydl.prepare_filename = lambda _: '-'  # Don't create files

    # Build a mock IsmFD object
    ism_fd = IsmFD(ydl, {})
    # This should not raise any exception
    ism_fd.real_download('-', {'fragments': [], '_download_params': {'track_id': 0}})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:10:32.657538
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x1cftyp\x00\x00\x00\x00ismlpiffiso2\x00\x00\x00\x18p\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10p\x11\x12\x13\x14\x15\x16\x17\x18', [b'ftyp'])
    assert box_data == b'ismlpiffiso2'

# Generated at 2022-06-24 12:10:36.660722
# Unit test for function box
def test_box():
    assert box(b'frma', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x0cfrma\x00\x00\x00\x00'

# Generated at 2022-06-24 12:10:48.482303
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 4000000,
        'timescale': 10000000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000
    }
    write_piff_header(output, params)
    raw = output.getvalue()
    assert raw[0:12] == b'\x00\x00\x00\x20ftypisml\x00\x00\x00\x00'

# Generated at 2022-06-24 12:10:58.109069
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest.mock as mock
    from .test.helper import TestHelper
    # Mock extract_box_data(..., ('moof', ...))
    box_sequence_moof = ('moof',) + box_sequence
    box_sequence_moof_checksum = TestHelper.hash(box_sequence_moof)
    with mock.patch('os.walk') as mock_walk:
        mock_walk.return_value = [
            ('.', [], ['output_moof.mp4']),
        ]
        with mock.patch('smoothstreams.fragment.extract_box_data', return_value=box_sequence_moof_checksum) as mock_moof_extractor:
            # extract_box_data(..., box_sequence)
            box_data = extract_box_

# Generated at 2022-06-24 12:11:07.582191
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    IsmFD unit test
    """

    params = {
        'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
        'test': True,
    }
    urlh = IsmFD(params)
    assert urlh.params['url'] == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    assert urlh.params['test'] == True

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:11:15.684944
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'test data'
    test_data_boxes = [
        box(b'ftyp', b'test 1'),
        box(b'moov', box(b'test 2', test_data))
    ]
    assert extract_box_data(b''.join(test_data_boxes), [b'moov', b'test 2']) == test_data
    try:
        extract_box_data(b''.join(test_data_boxes), [b'moov', b'foo'])
        assert False, 'Should raise'
    except RuntimeError:
        pass


# Generated at 2022-06-24 12:11:23.476419
# Unit test for function full_box
def test_full_box():
    assert u'00000018' == binascii.hexlify(u32.pack(24))
    assert u'00010000' == binascii.hexlify(u32.pack(256))
    assert u'4040404040404040' == binascii.hexlify(u64.pack(0x4040404040404040))
    assert u'0a000000' == binascii.hexlify(u32.pack(0x0a))
    assert u'70100000' == binascii.hexlify(u32.pack(0x70100000))
    assert u'0040404040404040' == binascii.hexlify(u64.pack(0x0040404040404040))
    assert u'dd000000' == binascii

# Generated at 2022-06-24 12:11:26.069028
# Unit test for function full_box
def test_full_box():
    print(full_box('\x08\xaf\xfd\x8f', 2, 1, "1"))


# Generated at 2022-06-24 12:11:33.799289
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:11:34.970018
# Unit test for function box
def test_box():
    assert box("abcd", "pay load") == '\x00\x00\x00\x10' 'abcd' 'pay load'

# Generated at 2022-06-24 12:11:45.468543
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'vp09',
        'duration': 100000,
        'timescale': 10000,
        'height': 1080,
        'width': 1920,
    }
    write_piff_header(stream, params)
    s = stream.getvalue()
    assert s.startswith(b'\x00\x00\x00\x20ftypismlpiffiso2')

# Generated at 2022-06-24 12:11:57.022467
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .http import HttpFD
    from .dash import DashFD
    from .smoothstreams import SmoothStreamsFD
    from .adobepass import AdobePassFD
    for downloader_cls in (HttpFD, DashFD, SmoothStreamsFD, AdobePassFD):
        downloader = downloader_cls()
        downloader.params = {
            'fragment_base_url': 'https://mf.snappystream.com/fragments/'
        }
        manifest = 'https://mf.snappystream.com/playlist/v12/playlist.m3u8'
        fd = IsmFD(downloader, manifest)
        assert fd.manifest_url == manifest
        assert fd.manifest_type == 'ism/manifest'

# Generated at 2022-06-24 12:12:02.596942
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('https://www.nfl.com/live', {
        '_download_params': {
            'fourcc': 'H264',
            'duration': 3.14,
            'codec_private_data': 'deadbeaf',
        },
        'fragments': [{'url': 'https://www.nfl.com/live/fragment1'}],
    }, {})

    assert fd.params['fragment_retries'] == 10

# Generated at 2022-06-24 12:12:12.861281
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        params = {
                'track_id': 1,
                'fourcc': 'H264',
                'duration': 10000,
                'timescale': 10000,
                'language': 'eng',
                'width': 1920,
                'height': 1080,
                'channels': 2,
                'bits_per_sample': 16,
                'sampling_rate': 48000,
                'codec_private_data': '0000000167640032acd93f6004000000301020004000000'.encode('utf-8')
            }
        write_piff_header(f, params)
        #print(f.getvalue())

# Generated at 2022-06-24 12:12:19.610301
# Unit test for constructor of class IsmFD
def test_IsmFD():
    original_url = 'http://smooth.example.com/Manifest'
    m = IsmFD._get_ism_video_manifest(original_url)
    # The manifest should be parsed correctly
    assert m.data['media_url'] == 'http://smooth.example.com/QualityLevels({bitrate})/Fragments(video={start time})'
    assert m.data['is_live'] == False
    assert m.data['fragments'][2]['url'] == 'http://smooth.example.com/QualityLevels(450000)/Fragments(video=200000)'
    assert m.data['duration'] == 12.66
    # The fragment list should be validated
    assert m.validate_fragment_list() == True
    # The live edge should be found
    assert m.live_edge == 2

# Generated at 2022-06-24 12:12:20.812097
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass
# Unit test code for class IsmFD

# Generated at 2022-06-24 12:12:21.878714
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-24 12:12:32.662202
# Unit test for function extract_box_data
def test_extract_box_data():
    moov_payload = full_box(b'mvhd', 1, 0, u64.pack(0) * 5)  # Movie Header Box

# Generated at 2022-06-24 12:12:38.386349
# Unit test for function full_box
def test_full_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'



# Generated at 2022-06-24 12:12:45.717582
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHDownloader
    from .http import HttpFD
    try:
        HttpFD.download('https://dash-mse-test.commondatastorage.googleapis.com/media/car-20120827-manifest.mpd')
    except:
        DASHDownloader.download('https://dash-mse-test.commondatastorage.googleapis.com/media/car-20120827-manifest.mpd')
    return IsmFD('https://dash-mse-test.commondatastorage.googleapis.com/media/car-20120827-manifest.mpd', {})

# Generated at 2022-06-24 12:12:52.582739
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://example.com/path/to/movie.ism/Manifest'
    ism_fd = IsmFD(url)

    assert ism_fd.url == url
    assert ism_fd.params == {
        'fragment_base_url': 'http://example.com/path/to/movie.ism/',
        'manifest_url': url,
        'fragment_prefix': None,
        'fragment_suffix': None,
    }
    assert ism_fd.manifest_type == 'ism'



# Generated at 2022-06-24 12:13:01.923832
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Download some sample ISM media
    # Eventually, may use a public URL to some interesting media
    # For now, the test is limited to syntactically correct URLs
    performance_checker = PerformanceChecker(100000)


# Generated at 2022-06-24 12:13:08.195272
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .f4mfd import make_f4m_manifest
    from .common import determine_ext
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import sanitize_open
    from .compat import encodeFilename, compat_str
    from .compat import compat_urllib_parse_unquote

    MANIFEST_FILE = 'manifest.f4m'
    DOWNLOADER_PARAMS = {
        'format': 'ism',
        'test': True,
    }
    OUTPUT_FILENAME = 'output.ism'
    expected_file = os.path.join(os.path.dirname(__file__), 'tests', 'test.ism')

    # Create a full f4m manifest

# Generated at 2022-06-24 12:13:17.543372
# Unit test for function write_piff_header
def test_write_piff_header():
    # Input params to write_piff_header, can be kept in json file.
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 30000,
        'timescale': 10000000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'nal_unit_length_field': 4,
        'codec_private_data': '01640029ffe1001267640029acd93938809da000300e310c3c8403000003000100000d2880'
    }
    stream_buf = io.BytesIO()
    write_piff_header(stream_buf, params)
    stream_buf.seek(0)
    print('length of buffer', stream_buf.getbuffer().nbytes)