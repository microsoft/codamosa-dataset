

# Generated at 2022-06-24 12:03:13.497829
# Unit test for function box
def test_box():
    assert box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'



# Generated at 2022-06-24 12:03:15.982166
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'



# Generated at 2022-06-24 12:03:24.669611
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x10' + b'ftyp' + b'\x00\x00\x00\x00\x00\xaa\xbb\xcc\xdd' + b'\x00\x00\x00\x10' + b'ftyp' + b'\x00\x00\x00\x00\x00\xaa\xbb\xcc\xdd'
    assert (extract_box_data(data, [b'ftyp']) == b'\x00\x00\x00\x00\x00\xaa\xbb\xcc\xdd')

# Generated at 2022-06-24 12:03:36.509254
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:39.325223
# Unit test for constructor of class IsmFD
def test_IsmFD():
    manifest_file = 'test.ism/Manifest'
    mani = IsmFD.urlopen(manifest_file)
    IsmFD.decode(mani.read())

# Generated at 2022-06-24 12:03:40.204994
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD("",{})
    assert fd.FD_NAME == 'ism'



# Generated at 2022-06-24 12:03:42.960232
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl_testutils.run_FD_test(IsmFD, 'test')
# Test cases for method download of class IsmFD
ydl_testcases.add_FD_list_test('ism', 'test', {
    'skip_download': True,
    'simulate': True,
    'simulate_filesize': '0.0',
    'simulate_filesize_variance': '0.0',
    'target': 'IsmFD_real_download.mp4',
})

# Generated at 2022-06-24 12:03:46.596090
# Unit test for function box
def test_box():
    assert box(b'free', b'Free space') == b'\x00\x00\x00\x0ffreeFree space'


# Generated at 2022-06-24 12:03:53.842484
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 42,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)
    #expected = b'\x00\x00\x00\x1a\x66\x74\x79\x70\x69\x73\x6d\x6c\x00\x00\x00\x00\x00\x01\x70\x69\x66\x66\x69\x73\x6f\x32\x00\x00\x00\x1a\x6d\x6f\x6f\x76\x00\x00\x00\x84\x6

# Generated at 2022-06-24 12:03:59.109929
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing method real_download of class IsmFD...')
    from ytdl_extension.user_functions import IsmFD
    from ytdl_extension.user_functions import real_download
    from ytdl_extension.user_functions import ism_real_download
    from ytdl_extension.user_functions import get_real_downloader
    from ytdl_extension import DownloadError
    from ytdl_extension import Size
    test_url = 'https://www.example.com/'
    test_filename = 'test.ism'
    test_info_dict = {}
    test_ismfd = IsmFD(params = {'extra_param': 'extra_value'})

# Generated at 2022-06-24 12:04:08.078342
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        "track_id": 1,
        "fourcc": 'AACL',
        "duration": 200000,
        "channels": 2,
        "bits_per_sample": 16,
        "sampling_rate": 44100,
    })

# Generated at 2022-06-24 12:04:12.177669
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('https://example.com/', {})
    assert fd.FD_NAME == 'ism'
    assert fd.params == {}

if __name__ == '__main__':
    # Simple unit tests for fragment downloader
    from tests import run_downloader

    run_downloader(IsmFD)
    run_downloader(IsmFD, {'username': 'foo', 'password': 'bar'})

# Generated at 2022-06-24 12:04:13.550675
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD(None, None, None)


# Generated at 2022-06-24 12:04:16.216074
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test.test_utils import open_stream
    handle = open_stream('piff_header_test.ismv')
    write_piff_header(handle, {'fourcc': 'AACL', 'track_id': 1, 'codec_private_data': '1210', 'duration': 190000, 'height': 720, 'width': 1280})
    handle.close()


# Generated at 2022-06-24 12:04:18.169732
# Unit test for function box
def test_box():
    assert box(b'adts', b'adts') == b'\x00\x00\x00\nadtsadts'


# Generated at 2022-06-24 12:04:29.026190
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:04:31.596646
# Unit test for function full_box
def test_full_box():

    assert full_box('abcd', 0, 0, b'\x01\x02\x03') == b'\x00\x00\x00\x0babcd\x00\x00\x00\x03\x01\x02\x03'

# Generated at 2022-06-24 12:04:42.646878
# Unit test for function write_piff_header
def test_write_piff_header():
    fourccs = ['AVC1', 'H264', 'AACL']

# Generated at 2022-06-24 12:04:46.215498
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov' + b'foob' + (b'\0' * 4) + b'mdat' + b'bar' + (b'\0' * 4)
    assert extract_box_data(data, (b'moov',)) == b'foob'
    assert extract_box_data(data, (b'mdat',)) == b'bar'



# Generated at 2022-06-24 12:04:49.428685
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 2, b'') == b'moov\x00\x00\x00\x08\x01\x00\x00\x00\x02'


# Generated at 2022-06-24 12:04:57.852635
# Unit test for function write_piff_header
def test_write_piff_header():
    video_params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'width': 1280,
        'height': 720,
        'duration': 100000,
        'codec_private_data': '01640028ffe100188e3c80d301104003c1cff9e10ca012c8761005b8801400019f0127400300011040050001d9e0117800028014034201040',
        'nal_unit_length_field': 4,
    }
    fd = io.BytesIO()
    write_piff_header(fd, video_params)
    print(fd.getvalue())

# Generated at 2022-06-24 12:05:04.828476
# Unit test for function full_box
def test_full_box():
    res = full_box(b'ftyp',1,0x02,b'aa')
    print(res)
    print(len(res))
    print(b'\x00\x00\x00\x10ftyp\x01\x00\x00\x02aa')
    print(len(b'\x00\x00\x00\x10ftyp\x01\x00\x00\x02aa'))
    assert binascii.hexlify(res) == b'0000000c66747970310000006161'
    assert len(res) == 12


# Generated at 2022-06-24 12:05:11.070066
# Unit test for function full_box
def test_full_box():
    payload = b'\x00\x00\x01'
    box_type = '\x00\x00\x00\x01'
    ret = full_box(box_type, 0, 0, payload)
    expected = ('\x00\x00\x00\x0c' + box_type + '\x00' +
                '\x00\x00\x00' + payload)
    assert ret == expected

# Generated at 2022-06-24 12:05:18.368628
# Unit test for function write_piff_header
def test_write_piff_header():
    # Anonymous class that re-implements write&seek of stream
    class Stream(object):
        def __init__(self):
            self.buffer = io.BytesIO()

        def getvalue(self):
            return self.buffer.getvalue()

        def write(self, s):
            self.buffer.write(s)

        def seek(self, pos, whence=0):
            self.buffer.seek(pos, whence)

        def __del__(self):
            self.buffer.close()

    stream = Stream()

# Generated at 2022-06-24 12:05:26.250756
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov' + b'\x0c' + \
           b'cmov' + b'\x06' + \
           b'dcom' + \
           b'cmvd'
    assert binascii.hexlify(extract_box_data(data, [b'moov'])) == b'636d6f760000000664636f6d64636d766564'
    assert extract_box_data(data, [b'moov', b'cmov']) == b'cmvd'



# Generated at 2022-06-24 12:05:32.855936
# Unit test for constructor of class IsmFD
def test_IsmFD():
    '''
    Test constructor of class IsmFD
    '''
    manifest_url = 'http://example.com/Manifest'
    params = {
        'url': manifest_url,
        'fragment_base_url': 'http://example.com/Fragments(%s)',
        'fragments': [
            {'url': 'http://example.com/Fragments(video=2200000)'},
        ],
    }

# Generated at 2022-06-24 12:05:41.513191
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    import json

    data = '00000280667479704D4D4F4B67547970346D703432'.decode('hex') + '000000000c6a50202000002800000000000000010000000100'.decode('hex')
    box_sequence = [b'mdia', b'minf', b'stbl', b'stsd', b'avc1']
    exp_data = '6a50202000002800000000000000010000000100'.decode('hex')
    assert extract_box_data(data, box_sequence) == exp_data
    data = '00000280667479704D4D4F4B67547970346D703432'.decode('hex') + '000000000c6a50202000002800000000000000010000000100'.decode('hex')

# Generated at 2022-06-24 12:05:47.671106
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:05:51.549595
# Unit test for function box
def test_box():
	assert box(b'moov', b'\x00\x00\x00\x20') == b'\x00\x00\x00\x28moov\x00\x00\x00\x20'



# Generated at 2022-06-24 12:05:58.635691
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    try:
        params = {'track_id': 1, 'fourcc': 'H264', 'duration': 90000, 'timescale': 90000, 'language': 'und', 'height': 720, 'width': 1280, 'codec_private_data': '01640032ac2a84020018f90d927c0032ac2a84020007c42800368eb0a4c00', 'nal_unit_length_field': 4}
        write_piff_header(stream, params)
    except Exception as e:
        raise e
    finally:
        stream.close()

# Generated at 2022-06-24 12:06:06.426171
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'payload') == b"\x00\x00\x00\x10moov\x00\x00\x00payload"
    assert full_box(b'mvhd', 0, 0, b'payload') == b"\x00\x00\x00\x12mvhd\x00\x00\x00\x00payload"
    assert full_box(b'uuid', 1, 0x01, b'payload') == b"\x00\x00\x00\x17uuid\x01\x00\x00\x01payload"
# Unit test: End


# Generated at 2022-06-24 12:06:10.552305
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_fd = IsmFD()
    assert ism_fd.real_download(['http://example.com/'], {'fragments': [['segment_url', 'segment_file']]}) == True
    assert ism_fd.real_download(['http://example.com/'], {'fragments': [['segment_url', 'segment_file']]}) == False



# Generated at 2022-06-24 12:06:14.130176
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class TestIsmFD(IsmFD):
        def __init__(self):
            pass

    ismfd = TestIsmFD()
    assert isinstance(ismfd, IsmFD)

# Generated at 2022-06-24 12:06:17.597092
# Unit test for function box
def test_box():
    assert box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'


# Generated at 2022-06-24 12:06:28.433224
# Unit test for function box
def test_box():
    assert box(b'moov', b'payload') == b'\x00\x00\x00\x0epayload'
    assert box(b'moov', b'') == b'\x00\x00\x00\n\x00\x00\x00\x00'

atom_ftyp = box(b'ftyp', b'isomiso2avc1iso6mp41')

atom_free = box(b'free', b'\x00' * 8)


# Generated at 2022-06-24 12:06:36.848074
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x10moov\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert full_box(b'moov', 0, 1, b'') == b'\x00\x00\x00\x10moov\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:06:46.491520
# Unit test for function box
def test_box():
    assert '\x00\x00\x00\x0cstypisom' == box(b'styp', b'isom')
    assert '\x00\x00\x00\x14frag\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x01\x00\x00\x00\x01' == box(b'frag', b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x01\x00\x00\x00\x01')



# Generated at 2022-06-24 12:06:52.529746
# Unit test for function full_box
def test_full_box():
    assert full_box(b'\x66\x6f\x6f', 0, 0, b'\x62\x61\x72') == b'\x00\x00\x00\x08' + b'\x66\x6f\x6f' + b'\x00' b'\x00\x00\x00' + b'\x62\x61\x72'



# Generated at 2022-06-24 12:07:01.384248
# Unit test for function box
def test_box():
    result = box('\xa9alb',
                 '\x00' + '\x00' * 2 + '\x00' + 'My Album')
    expected_result = (0x00000018, '\xa9alb' + '\x00' + '\x00' * 2 + '\x00' + 'My Album')
    assert len(result) == expected_result[0]
    assert result[4:] == expected_result[1]

# def box(box_type, payload):
#     return u32.pack(8 + len(payload)) + box_type + payload
# def test_box():
#     result = box('\xa9alb',
#                  '\x00' + '\x00' * 2 + '\x00' + 'My Album')
#     assert len(result) ==

# Generated at 2022-06-24 12:07:05.440184
# Unit test for function box
def test_box():
    payload = b'test'
    box_type = b'test'
    assert box(box_type, payload) == b'\x00\x00\x00\x0ctesttest'



# Generated at 2022-06-24 12:07:07.860698
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == b'\x00\x00\x00\x0cabcd1234'



# Generated at 2022-06-24 12:07:17.413343
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x10ftyp\x00\x00\x00\x00\x00\x00\x00\x06isml', (b'ftyp',)) == b'\x00\x00\x00\x00\x00\x00\x00\x06isml'
    assert extract_box_data(b'\x00\x00\x00\x10ftyp\x00\x00\x00\x00\x00\x00\x00\x06isml', (b'moov',)) == None



# Generated at 2022-06-24 12:07:26.992296
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = '00000024moof00000010traf00000018tfhd00000000000000020000002c000100000024tfdt000000000100000000000000b400000014trun00000000000000040000db000000010100000000050000005f000000010000000000000000000000'
    assert extract_box_data(binascii.unhexlify(test_data), (b'moof', b'traf', b'tfdt')) == binascii.unhexlify('00000014tfdt000000000100000000000000b4')
    assert extract_box_data(binascii.unhexlify(test_data), (b'moof', b'traf', b'trun')) == binascii.unhexlify('00000014trun00000000000000040000db000000010100000000050000005f000000010000000000000000000000')
    assert extract_box_data

# Generated at 2022-06-24 12:07:33.640580
# Unit test for function extract_box_data
def test_extract_box_data():
    import random, string
    random_str = lambda s: ''.join(random.choice(string.ascii_uppercase) for x in range(s))
    test_data = random_str(10) + u32.pack(20) + random_str(4) + u32.pack(30) + random_str(10)
    test_box_sequence = (random_str(4), random_str(4))
    assert extract_box_data(test_data, test_box_sequence) == u32.pack(20) + random_str(4)

# Generated at 2022-06-24 12:07:39.797389
# Unit test for function write_piff_header
def test_write_piff_header():
    test = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['duration'] = 0
    params['fourcc'] = 'AACL'
    params['codec_private_data'] = '1210'
    params['height'] = 0
    params['width'] = 0
    params['timescale'] = 10000000
    write_piff_header(test, params)
    print(test.getvalue())
    test.close()

# Generated at 2022-06-24 12:07:50.940466
# Unit test for function write_piff_header

# Generated at 2022-06-24 12:07:55.786030
# Unit test for function full_box
def test_full_box():
    assert full_box(b'abcd', 1, 1, b'efgh') == b'\x00\x00\x00\x0babcd\x00\x01\x00\x00\x00efgh'



# Generated at 2022-06-24 12:07:58.508883
# Unit test for function full_box
def test_full_box():
    assert full_box('test', 1, 2, 'payload') == '\x00\x00\x00\x0e"test\x01\x00\x00\x02payload'



# Generated at 2022-06-24 12:08:03.940159
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create an instance of IsmFD
    ismfd = IsmFD()
    # Create an info dict
    info_dict = dict()
    # Assign value to key 'fragments' of info_dict
    info_dict['fragments'] = []
    # Assign value to key 'protocol' of info_dict
    info_dict['protocol'] = 'm3u8_native'
    # Assign value to key 'total_bytes' of info_dict
    info_dict['total_bytes'] = -1
    # Assign value to key '_download_params' of info_dict
    info_dict['_download_params'] = dict()
    # Assign value to key 'fourcc' of info_dict
    info_dict['fourcc'] = 'AACL'
    # Assign value to key '

# Generated at 2022-06-24 12:08:14.881637
# Unit test for function write_piff_header
def test_write_piff_header():
    from hashlib import sha256
    import random
    import base64

    def random_str(n):
        return random.choice(string.ascii_lowercase) * n

    #######################
    # Test Case 1, audio
    #######################
    params = {}
    params['track_id'] = 1
    params['duration'] = 0
    params['fourcc'] = 'AACL'
    params['sampling_rate'] = 48000
    params['timescale'] = 1
    params['language'] = 'und'
    params['codec_private_data'] = random_str(64)

    # Create and read stream
    stream_out = io.BytesIO()
    write_piff_header(stream_out, params)

# Generated at 2022-06-24 12:08:19.181913
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD_test(IsmFD):
        def real_download(self, filename, info_dict):
            assert filename == 'foo.smil'
            assert info_dict == {'a': 'b'}

    IsmFD_test('foo.smil', False, {'a': 'b'}).download()

# Generated at 2022-06-24 12:08:27.470747
# Unit test for function full_box
def test_full_box():
    box_type = 'avc1'
    version = 0
    flags = 0
    payload = ''
    test_result = full_box(box_type, version, flags, payload)
    assert len(test_result) == 32
    assert test_result[0:4].encode('hex') == '00000018'
    assert test_result[4:8].encode('hex') == '61766331'
    assert test_result[8:9].encode('hex') == '00'
    assert test_result[9:12].encode('hex') == '000000'
    assert test_result[12:32].encode('hex') == ''
    

# Generated at 2022-06-24 12:08:36.487206
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractors.common import InfoExtractor

    class TestInfoExtractor(InfoExtractor):

        _TEST = {
            'url': 'http://www.example.com/foo.ism/Manifest',
            'file': 'foo.ism',
            'info_dict': {
                'id': 'foo',
                'ext': 'ism',
            },
            'params': {
                'skip_download': True,
            },
        }

    ie = TestInfoExtractor()
    ie.add_info_extractor('ism', IsmFD)

# Generated at 2022-06-24 12:08:46.343099
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .piff import parse_piff_header

    data = io.BytesIO()
    write_piff_header(data, {
        'track_id': 1,
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'fourcc': 'H264',
        'width': 1280,
        'height': 720,
        'nal_unit_length_field': 4,
        'codec_private_data': '01640028ffe1001867640028acd9c80140028acd90001071000003008044000a80800000a0e06010768ebecb22c',
    })
    data.seek(0)
    parsed_header = parse_piff_header(data)

# Generated at 2022-06-24 12:08:49.153715
# Unit test for function box
def test_box():
    data = box(b'moov', b'')
    assert u32.unpack(data)[0] == 8
    assert data[4:] == b'moov'


# Generated at 2022-06-24 12:08:52.764012
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('D:\\STS\\streams\\sample_1.mp4','rb') as f:
        data = f.read()

    moov_data = extract_box_data(data, [b'moov'])
    print (moov_data)



# Generated at 2022-06-24 12:09:03.817523
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .fragment import FragmentFD
    from .smoothstreams import SmoothStreamsFD

    segment_urls = [
        'https://sample-assets.gpac.io/dash/bbb/bbb-180-a1/audio-aacl.mp4',
        'https://sample-assets.gpac.io/dash/bbb/bbb-180-a1/audio-aacl.mp4'
    ]
    extra_params = {
        'fragment_retries': 5, 'skip_unavailable_fragments': False,
        'fragment_size': 1024 * 1024, 'num_downloads': 5, 'http_chunk_size': 1024 * 1024,
        'headers': {'User-Agent': 'Test User Agent'}
    }
    original_download_fragment = Frag

# Generated at 2022-06-24 12:09:13.755113
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'H264',
              'duration': 70000000, 'timescale': 10000000,
              'height': 0, 'width': 0, 'channels': 2,
              'bits_per_sample': 16, 'sampling_rate': 44100,
              'language': 'und',
              'codec_private_data': '00000001674d4027fda8ad0a62f80f15'}
    with io.BytesIO() as stream:
        write_piff_header(stream, params)

# Generated at 2022-06-24 12:09:15.811828
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass
    # TODO: Implement test



# Generated at 2022-06-24 12:09:27.020308
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as out:
        write_piff_header(
            out, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 90000,
            'timescale': 90000,
            'height': 1920,
            'width': 1080,
            'codec_private_data': '01640028ffe10013867a4780f0415a402000428ee3c80f00000167c0028ee3c80',
        })

# Generated at 2022-06-24 12:09:29.337567
# Unit test for function full_box
def test_full_box():
    assert binascii.hexlify(full_box('abcd', 0, 0, 'efgh')) == '0000000c616263640000000065666768'


# Generated at 2022-06-24 12:09:38.125521
# Unit test for function box
def test_box():
    assert(box(b'\x66\x6f\x6f\x42', b'') == b'\x00\x00\x00\x0cfoobB\x00\x00\x00\x00')
    assert(box(b'\x66\x6f\x6f\x42', b'hello world') == b'\x00\x00\x00\x14foobBhello world')



# Generated at 2022-06-24 12:09:47.281342
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request
    from .utils import match_filter_func
    from .common import FileDownloaderTest
    from .extractor import list_extractors
    from .supported import supported_extractors
    from .common import get_suitable_downloader


# Generated at 2022-06-24 12:09:56.905578
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'track_id': 1,
        'fourcc': 'avc1',
        'height': 720,
        'width': 1280,
        'duration': 100,
        'timescale': 10,
        'language': 'und',
        'codec_private_data': '01640028ffe1001867640028ac2c80281398002807480022c834c020',
    })
    val = f.getvalue()
    assert len(val) == 884
    assert binascii.hexlify(val[0:8]) == b'6d766864'  # mvhd
    assert binascii.hexlify(val[8:12]) == b'00180000'

# Generated at 2022-06-24 12:10:07.677630
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.extractor.generic import GenericIE
    from .youtube_dl.utils import DateRange
    from .youtube_dl.downloader.http import HttpFD
    from .youtube_dl.compat import urllib_error, compat_urllib_request
    import subprocess
    import tempfile
    import os
    import shutil
    import pytest

    DATA_PATH = os.path.join(os.path.dirname(__file__), 'manifest_test_data')

    def _download_manifest(manifest_url, params={}):
        def downloader_factory(ydl, params):
            return HttpFD(ydl, params)

        ydl = YoutubeDL(params)
        ydl.add_info_ext

# Generated at 2022-06-24 12:10:18.243459
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .utils import _FakeYDL
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor
    from .compat import urljoin
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_http_client


# Generated at 2022-06-24 12:10:24.843892
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(
        binascii.unhexlify(b'006a6d6666747970336770336964310000036d64686400120000000100000000000000010000000000000001000000000000000000ffffffff00000001000000000000000000ffffffff0000000000000000000000000000000100000000000000000000000000000001000000000000000000000001000000000000000000000000000000000000000000000001000000000000000000ffffffff0000000100000000000000000000000000000000000000000000000000000000000000'),
        (b'mfhd', b'frma')
    ) == b'd683c914'

# Generated at 2022-06-24 12:10:32.826365
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'ftyp', b'isml' + u32.pack(1) + b'piff' + b'iso2')
    assert data == b'\x00\x00\x00\x1cftypisml\x00\x00\x00\x01piffiso2'
    assert extract_box_data(data, [b'ftyp']) == b'isml\x00\x00\x00\x01piffiso2'
    assert extract_box_data(data, [b'moov']) == None



# Generated at 2022-06-24 12:10:42.353129
# Unit test for function extract_box_data
def test_extract_box_data():
    data = '\x00\x00\x00\x28moov\x00\x00\x00\x14trak\x00\x00\x00\x0csoun\x00\x00\x00\x08mp4a\x00\x00\x00\x00\x00\x00\x00\x00aaaaaa'
    assert extract_box_data(data, ('moov', 'trak', 'soun')) == '\x00\x00\x00\x08mp4a\x00\x00\x00\x00\x00\x00\x00\x00aaaaaa'



# Generated at 2022-06-24 12:10:43.582801
# Unit test for function full_box
def test_full_box():
    assert full_box('ftyp', 0, 0, 'abc') == binascii.a2b_hex('0000001466747970' + '00000000' + '616263')



# Generated at 2022-06-24 12:10:47.559469
# Unit test for function box
def test_box():
    assert(box(b'junk', b'junk') == (
b'\x00\x00\x00\x0cjunkjunk'
    ))
test_box()



# Generated at 2022-06-24 12:10:54.874522
# Unit test for function extract_box_data
def test_extract_box_data():
    # Create data with a nested box structure
    box_data = b''
    for box_type in ('level1', 'level2', 'level3'):
        box_size = 8 + 4  # Size of 4 bytes
        box_data += u32.pack(box_size) + box_type.encode('ascii') + u32.pack(1234)
    # Verify
    assert extract_box_data(box_data, ('level1', 'level2', 'level3')) == u32.pack(1234)



# Generated at 2022-06-24 12:11:06.493455
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-24 12:11:13.519504
# Unit test for function extract_box_data
def test_extract_box_data():
    m = b'\x00\x00\x00\x42ftypisml\x00\x00\x00\x00\x00\x00\x00\x00\x69\x73\x6d\x6c\x69\x73\x6f\x32'
    m += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 12:11:21.144773
# Unit test for function write_piff_header
def test_write_piff_header():
    from ykdl.compact import BytesIO
    import json
    test_param = {
        "track_id": 1,
        "fourcc": "H264",
        "duration": 27671299,
        "timescale": 10000000,
        "language": "und",
        "height": 720,
        "width": 1280,
        "codec_private_data": "0164001fffe10019674d001f9a0028a00980",
        "nal_unit_length_field": 4,
    }
    output_buffer = BytesIO()
    write_piff_header(output_buffer, test_param)
    output_buffer.seek(0)
    decoder_config_record_payload = None

# Generated at 2022-06-24 12:11:28.461340
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://amssamples.streaming.mediaservices.windows.net/49b57c87-f5f3-48b3-ba22-c55cfdffa9cb/Sintel.ism/manifest'
    ie = IsmFD(url)
    result = ie.real_download('test_IsmFD_real_download.ism', {})
    print(result)


# Generated at 2022-06-24 12:11:39.671558
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x18ftypisom\x00\x00\x02\x00mp42isom\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(data, ('ftyp', )) == b'isom\x00\x00\x02\x00mp42isom\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(data, ('ftyp', 'isom')) == b'\x00\x00\x02\x00mp42isom\x00\x00\x00\x00\x00\x00\x00\x00\x00'
   

# Generated at 2022-06-24 12:11:52.065055
# Unit test for function box
def test_box():
    import binascii
    assert binascii.hexlify(box(b'mooo', b'hooo')) == b'0000000c6d6f6f6f686f6f6f'


# Generated at 2022-06-24 12:11:57.905082
# Unit test for function full_box
def test_full_box():
    box_type = b'mvhd'
    version = 0
    flags = 0
    payload = b'pay'
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x1c'+b'mvhd'+b'\x00'+b'\x00\x00\x00'+b'pay'
test_full_box()



# Generated at 2022-06-24 12:12:06.233065
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'abcabcabcabcabcabcabcabcabcabcabcabcabc'
    assert extract_box_data(data, (b'a', b'a', b'a')) == b'abcabcabc'
    assert extract_box_data(data, (b'b', b'b', b'b')) == b'abcabcabc'
    assert extract_box_data(data, (b'c', b'c', b'c')) == b'abcabcabc'
    assert extract_box_data(b'', (b'bc', b'ed')) == None
    assert extract_box_data(b'', (b'bc', b'ed')) == None
    assert extract_box_data(b'', (b'bc', b'ed')) == None

# Generated at 2022-06-24 12:12:06.958337
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:12:08.569989
# Unit test for function full_box
def test_full_box():
    box_type = b"mdat"
    version = 0
    flags = 0
    payload = b""
    fullBox = full_box(box_type, version, flags, payload)
    assert fullBox == b"\x00\x00\x00\x0cmdat\x00\x00\x00\x00"



# Generated at 2022-06-24 12:12:17.421744
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x10test\x00\x00\x00\x10test\x00\x00\x00\x10test', ['test']) == b'\x00\x00\x00\x10test'
    assert extract_box_data(b'\x00\x00\x00\x10test\x00\x00\x00\x10test\x00\x00\x00\x10test', ['test', 'test']) == b'\x00\x00\x00\x10test'

# Generated at 2022-06-24 12:12:29.719784
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    # Create params
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 15, 'timescale': 10000000, 'language': 'und', 'width': 640, 'height': 360, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100}
    # Write header
    write_piff_header(f, params)

# Generated at 2022-06-24 12:12:41.516956
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import testutils
    dl = testutils.FakeYDL()
    fd = IsmFD(dl,
               {
                   'test': True,
                   'url': 'http://test.test/test.ism/Manifest',
                   '_download_params': {
                       'track_id': 0,
                       'fourcc': 'AVC1',
                       'codec_private_data': '0164001FFFE1001767640029ACD35C1'
                   }
               }
               )
    info_dict = {
        'fragments': [{'url': 'http://test.test/test.ism/QualityLevels(90870)/Fragments(video=0)'}],
        '_download_params': fd.params['_download_params']
    }
    assert fd.real_download

# Generated at 2022-06-24 12:12:48.694008
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:12:51.866331
# Unit test for function box
def test_box():
    assert(box(b'moov', b'payload') == b'\x00\x00\x00\x0epayload')


# Generated at 2022-06-24 12:13:02.835870
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    with tempfile.NamedTemporaryFile(mode='w+') as tmp:
        params = {
            'format': 'ism',
            'url': 'http://example.com/file.ism/Manifest'
        }

# Generated at 2022-06-24 12:13:10.660069
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test on-demand fragment downloading
    ism_fd = IsmFD(params={'fragment_base_url': 'https://mycdn.net'})