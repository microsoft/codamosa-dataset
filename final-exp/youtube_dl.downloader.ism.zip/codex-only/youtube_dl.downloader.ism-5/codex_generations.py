

# Generated at 2022-06-24 12:03:21.725579
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    context = {
        'filename': 'test.ism',
        'total_frags': 1,
    }

    segments = [{
        'url': 'http://www.microsoft.com',
        'byterange': (0, 0)
    }]

    info_dict = {
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 0,
            'timescale': 10000000,
            'language': 'eng',
            'height': 0,
            'width': 0,
            'sampling_rate': 44100
        },
        'fragments': segments
    }

    fd = IsmFD()
    fd.fd_name = 'ism'


# Generated at 2022-06-24 12:03:24.831161
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x0cstts\x00\x00\x00\x00' == box(b'stts', b'\x00\x00\x00\x00')


# Generated at 2022-06-24 12:03:34.329587
# Unit test for function box
def test_box():
    assert (box(b'moov', b'').hex() == '00000008' + '6d6f6f76' + '00000000')
    assert (box(b'moov', b'abc').hex() == '0000000b' + '6d6f6f76' + '616263')
    assert (box(b'moov', b'\x00\x01\x02\x03\x04').hex() == '0000000d' + '6d6f6f76' + '00010203' + '04')



# Generated at 2022-06-24 12:03:39.106540
# Unit test for function box
def test_box():
    assert box('free', 'dead') == b'\x08dead\x00dead'
    assert box('free', 'beef') == b'\x08beef\x00beef'
    assert box('free', '\x00' * 10) == b'\x10\x00free\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:03:43.162648
# Unit test for function full_box
def test_full_box():
    TEST_VECTOR = b'\x1a\x45\xdf\xa3'
    assert full_box(b'\x6a\x70\x32\x20', 1, 0x6a70, b'\x00\x00\x00\x00')[4:] == TEST_VECTOR
    return
test_full_box()



# Generated at 2022-06-24 12:03:47.596152
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 0, b'') == b'\x00\x00\x00\x0cmoov\x01\x00\x00\x00'



# Generated at 2022-06-24 12:03:52.475020
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'') == b'\x00\x00\x00\x0c\x6d\x76\x68\x64\x00\x00\x00\x00'
# end function test_box


# Generated at 2022-06-24 12:03:58.869911
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return IsmFD._test_real_download(
        'IsmFD',
        {'fragments': [{'url': 'http://example.com/a.ism/QualityLevels(320)/Fragments(video=0)', 'duration': 2}]},
        {'skip_unavailable_fragments': False, 'fragment_retries': 0, 'test': True})

# Generated at 2022-06-24 12:04:07.886710
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_result = False

# Generated at 2022-06-24 12:04:12.168147
# Unit test for function full_box
def test_full_box():
    assert full_box(b'avc1', 0, 0, b'\x00\x00\x00') == b'\x00\x00\x00\x0cavc1\x00\x00\x00\x00'



# Generated at 2022-06-24 12:04:15.365677
# Unit test for function box
def test_box():
    assert box(b'moov', b'payload') == b'moovpayload'
    assert box(b'moov', b'superlongtestpayload') == b'moovsuperlongtestpayload'



# Generated at 2022-06-24 12:04:18.407760
# Unit test for function box
def test_box():
    assert box(b'abcd', b'\x00\x01\x02\x03') == b'\x00\x00\x00\x0cabcd\x00\x01\x02\x03'



# Generated at 2022-06-24 12:04:20.269508
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-24 12:04:23.221951
# Unit test for function full_box
def test_full_box():
    assert full_box(b"\0\0\0\0", 1, 0, b'') == b'\0\0\0\x14\0\0\0\0\1\0\0\0\0\0\0\0'

# Generated at 2022-06-24 12:04:24.897228
# Unit test for function full_box
def test_full_box():
    print(full_box(b'ftyp', 1, 0, b'avc1'))


# Generated at 2022-06-24 12:04:28.071072
# Unit test for function box
def test_box():
    c = box(b'wham', b'')
    assert u32.unpack(c[0:4])[0] == 12
    assert c[4:8] == b'wham'
    assert c[8:12] == b''

# Generated at 2022-06-24 12:04:38.942012
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import parse_m3u8
    from .extractor.ism import IsmFD

    test_values = [
        {
            'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
            'info_dict': {
                'id': '1',
                'ext': 'mp4',
                'title': 'SuperSpeedway',
            },
            'params': {
                'skip_download': True,
            }
        }
    ]
    for test_value in test_values:
        _, info = parse_m3u8(test_value['url'], None)
        IsmFD(info=info).real_download('', test_value['info_dict'])


# End of unit test

# Generated at 2022-06-24 12:04:46.456989
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    # Constructor test of IsmFD with default argument
    fd_ism = IsmFD()
    assert fd_ism.params == {'noprogress': True}
    assert fd_ism.method == 'GET'
    assert fd_ism.is_dash == True
    assert fd_ism.is_live == True
    assert fd_ism.fragment_retries == 10
    assert fd_ism.fragment_retry_sleep == 0.5
    assert fd_ism.skip_unavailable_fragments == True
    assert fd_ism.retries == 10
    assert fd_ism.fragment_progress_hook == None
    assert fd_ism.test == False
    assert fd_ism

# Generated at 2022-06-24 12:04:52.275909
# Unit test for function write_piff_header
def test_write_piff_header():
    piff_stream = io.BytesIO()
    TEST_PARAMS = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 500000000,
        'timescale': 120000000,
        'codec_private_data': '01640029ffe1000867640029ac56000b5c88001c8478001103e90301500003a9801188000140184000000000000000301000168ea0140',
        'sampling_rate': 48000,
    }
    write_piff_header(piff_stream, TEST_PARAMS)

# Generated at 2022-06-24 12:05:03.945069
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:05:14.522075
# Unit test for function write_piff_header
def test_write_piff_header():

    class FakedStream:
        def write(self, b):
            self.data += b
            return len(b)

    stream = FakedStream()
    stream.data = b''

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000,
        'timescale': 10000000,
        'nal_unit_length_field': 4,
        'codec_private_data': '000000016764001FACD8D8C00E2AC05B00E2AC05B832C2478',
        'height': 480,
        'width': 640,
    }

    write_piff_header(stream, params)

    data = stream.data

    # make sure every box has correct size
    offset = 0

# Generated at 2022-06-24 12:05:19.581288
# Unit test for function extract_box_data
def test_extract_box_data():
    assert(extract_box_data(b'moovb\x00\x00\x00\x00\x00\x00\x00\x00', [b'moov']) == b'\x00\x00\x00\x00\x00\x00\x00\x00')


# Generated at 2022-06-24 12:05:25.142101
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0x01,
        'fourcc': 'H264',
        'duration': 0x0dbba000,
        'timescale': 0x01e1000,
        'sampling_rate': 48000,
        'channels': 2,
        'language': 'eng',
        'height': 0,
        'width': 0,
        'codec_private_data': '000000016764002aac200100178de800d6d401f9e0ed58fffffeb2'
    }
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:05:27.971800
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Instance options
    opts = {
        'usenetrc': False,
        'username': 'xxx',
        'password': 'yyy',
        'verbose': True,
        'quiet': False,
    }

    # Create instance of IsmFD
    ismfd = IsmFD(opts)

    # Run test
    ismfd.test()


# Command line entry point.
if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:05:37.311061
# Unit test for function write_piff_header
def test_write_piff_header():
    """ Test for write_piff_header """
    from io import BytesIO
    from collections import namedtuple
    Params = namedtuple('Params', ('track_id', 'fourcc', 'duration',
        'timescale', 'language', 'height', 'width', 'nal_unit_length_field',
        'channels', 'bits_per_sample', 'sampling_rate',
        'codec_private_data'))

# Generated at 2022-06-24 12:05:41.965030
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b'test_payload'
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x10moov\x00\x00\x00\x00\x04test_payload'



# Generated at 2022-06-24 12:05:45.374807
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('/tmp/test.piff', 'wb') as stream:
        write_piff_header(stream, {'track_id': 1, 'fourcc': 'AACL', 'duration': 50, 'sampling_rate': 48000, 'channels': 2, 'bits_per_sample': 16})
#test_write_piff_header()



# Generated at 2022-06-24 12:05:56.363874
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:06:05.700526
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = Downloader()
    downloader.params.update({"simulate": True,
                              "nooverwrites": True,
                              "keepvideo": True,
                              "skip_download": True,
                              "format": "best[protocol^=m3u8]"
                              })

    # If a valid video id is specified, these three lines will retrieve the metadata for the video.
    # The test cases for snippet extraction and extraction of m3u8 is performed below.
    # The metadata is stored in 'info_dict'

# Generated at 2022-06-24 12:06:17.386768
# Unit test for function extract_box_data
def test_extract_box_data():

    # Test get first box and the size is long enough
    data = b'\x00\x00\x00\x10' + b'moov' + b'\x00\x00\x00\x10' + b'trak' + \
           b'\x00\x00\x00\x10' + b'mvhd' + b'\x00\x00\x00\x10' + b'tkod'
    box_sequence = (b'moov',)

# Generated at 2022-06-24 12:06:28.270202
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import get_info_extractor
    from .jsinterp import JSInterpreter
    from .common import FileDownloader
    from .downloader import FileDownloader as _FileDownloader
    from .utils import strip_jsonp

    url = 'http://stream.flowplayer.org/bauhaus/624x260.ism'
    stream_info = get_info_extractor(
        url)(FileDownloader({}), url).result['_type']
    js_url = stream_info['url']

    js_contents = _FileDownloader({}).read_compat_str(
        compat_urllib_request.urlopen(js_url).read())

# Generated at 2022-06-24 12:06:31.522120
# Unit test for function box
def test_box():
    assert box('mvhd', 'payload') == u32.pack(12) + 'mvhd' + 'payload'

# Generated at 2022-06-24 12:06:40.584109
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'url': 'http://www.example.com/'})
    assert not fd.params['nopart']
    assert not fd.params['test']

if __name__ == '__main__':
    import sys
    download_url = sys.argv[1]
    output_file = sys.argv[2]

    cmd = ['ffmpeg', '-i', '-']
    cmd.extend(sys.argv[3:])
    ffmpeg_proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)

    ydl_opts = {
        'format': 'ism',
        'outtmpl': '-',
        'skip_download': True,
        'quiet': True
    }

# Generated at 2022-06-24 12:06:47.093781
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(0x00000020) + b'moov' + u32.pack(0x0000001C) + b'mvhd' \
           + u32.pack(0x00000020) + b'trak' + u32.pack(0x00000020) + b'tkhd'
    assert extract_box_data(data, (b'moov', b'trak', b'tkhd')) == u32.pack(0x00000020)
test_extract_box_data()


# Generated at 2022-06-24 12:06:54.069417
# Unit test for function full_box
def test_full_box():
    data = u8.pack(0) + u32.pack(0)[1:] + u16.pack(0x0010)
    assert (full_box('soun', 0, 0, data)  == '\x00\x00\x00\x12soun\x00\x00\x00\x00\x00\x00\x00\x00\x10')
    print('ok')
# /Unit test for function full_box



# Generated at 2022-06-24 12:07:00.335568
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(18) + b'ftyp' + u32.pack(12) + b'iso2' + u32.pack(16) + b'moov' + u32.pack(8) + b'mvhd' + u32.pack(12) + b'free'
    assert  b'iso2' == extract_box_data(data, (b'ftyp',))
    assert  b'free' == extract_box_data(data, (b'moov', b'mvhd',))



# Generated at 2022-06-24 12:07:07.186744
# Unit test for function extract_box_data
def test_extract_box_data():
    assert (
        extract_box_data(
            b'moov' + extract_box_data(
                b'mdat'
                + u32.pack(8) + b'moov'  # Boxes 'moov'
                + u32.pack(8) + b'mdat',  # Boxes 'mdat'
                (b'mdat',)
            ),
            (b'moov',)
        ) == b''
    )



# Generated at 2022-06-24 12:07:11.381097
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('http://video.mp4', {}, None)
    assert fd.FD_NAME == 'ism'


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:07:22.798948
# Unit test for function extract_box_data
def test_extract_box_data():
    print('test_extract_box_data')
    file_data = open('piff.mp4', 'rb').read()
    new_data = extract_box_data(file_data, [b'moov', b'mvhd'])
    print(u64.unpack(new_data[8:16]))
    new_data = extract_box_data(file_data, [b'moov', b'trak', b'tkhd'])
    print(u64.unpack(new_data[20:28]))
    new_data = extract_box_data(file_data, [b'moov', b'trak', b'mdia', b'mdhd'])
    print(u64.unpack(new_data[16:24]))

# Generated at 2022-06-24 12:07:25.177793
# Unit test for constructor of class IsmFD
def test_IsmFD():
    dl = IsmFD()
    assert dl.__class__.__name__ == 'IsmFD'



# Generated at 2022-06-24 12:07:34.294643
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    class DummyParams(object):
        def __init__(self, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)

    class DummyReportError(object):
        def __init__(self):
            self.calls = 0

        def __call__(self, *args, **kwargs):
            self.calls += 1

    class DummyYFD(object):
        @staticmethod
        def supported():
            return True

        def real_download(self, *args, **kwargs):
            return True

    class DummyFragFD(FragmentFD):
        def __init__(self):
            self._downloader = None
            self._prepare_and_start_frag_download_calls = 0
            self._finish_frag

# Generated at 2022-06-24 12:07:37.087679
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264PR/SuperSpeedway_720.ism/Manifest'
    fd = IsmFD(url, {}, None)
    assert fd.manifest_url == url


# Generated at 2022-06-24 12:07:37.541190
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:07:44.839359
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor with fixed values
    params = {
                'preferredcodec': 'h264',
                'preferredquality': 'high',
                'preferredcustomlanguage' : 'English',
                'preferredcustomquality': '720'
             }
    ismfd = IsmFD(params)
    assert(ismfd.__class__.__name__ == 'IsmFD')
test_IsmFD()


# Generated at 2022-06-24 12:07:49.782251
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b'sample'
    expected = b'\x00\x00\x00\x0e' + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload
    assert full_box(box_type, version, flags, payload) == expected



# Generated at 2022-06-24 12:07:54.786892
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Test whether the IsmFD constructor actually works.
    """
    IsmFD('http://ism/')



# Generated at 2022-06-24 12:08:03.292658
# Unit test for function extract_box_data
def test_extract_box_data():
    from .piff import PiffFD
    data = PiffFD().read_box_data_raw(b'stbl')

# Generated at 2022-06-24 12:08:14.466131
# Unit test for function extract_box_data
def test_extract_box_data():
    import pprint
    from .f4m_parser import parse_flv_header
    from .common import update_url_query
    from ..compat import compat_urllib_request
    from ..utils import (
        ExtractorError,
        encode_compat_str,
    )
    from ..compat import (
        compat_chr,
        compat_struct_unpack,
    )
    
    video_url = 'http://link.theplatform.com/s/NnzsPC/media/guid/2410887629/564251483001/564251483001.f4m?mbr=true'

# Generated at 2022-06-24 12:08:19.629536
# Unit test for function box
def test_box():
    assert(box(b'mvhd', b'') ==
           b'\x00\x00\x00\x0Cmvhd\x00\x00\x00\x00')
    assert(box(b'tfhd', b'\x01') ==
           b'\x00\x00\x00\x0Ftfhd\x01\x00\x00\x00')



# Generated at 2022-06-24 12:08:28.732831
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:37.549119
# Unit test for constructor of class IsmFD
def test_IsmFD():

    class MockInfoDict(dict):
        pass


# Generated at 2022-06-24 12:08:39.924528
# Unit test for function box
def test_box():
    assert(len(box('ftyp', 'isom')) == 12)
    assert(len(box('tst ','tstval')) == 16)
    assert(len(box('tst ','')) == 12)
# Function box end, test end


# Generated at 2022-06-24 12:08:50.208772
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD_Stub(IsmFD):
        def __init__(self, ydl, params):
            # Stub constructor calls super constructor of FragmentFD
            super(IsmFD_Stub, self).__init__(ydl, params)

    params = {
        'test': 1,
        'retries': 0,
        'include_header': 1,
        'fragment_duration': 5.0,
        'playlist_start': 0.0,
        'playlist_end': None,
        'playlist_duration': None,
        'keep_fragments': 1,
        'outtmpl': 'foo.out',
        'fragment_retries': 0,
        'skip_unavailable_fragments': True,
    }
    ydl = FakeYDL()
    fragment

# Generated at 2022-06-24 12:08:52.461136
# Unit test for function box
def test_box():
    print(box("ftyp", payload=b'isomiso2avc1mp41'))
    return None
#test_box()



# Generated at 2022-06-24 12:09:03.640708
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing real_download method of class IsmFD')
    filename = 'ism'

# Generated at 2022-06-24 12:09:10.973382
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import Downloader
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .compat import compat_urllib_request, compat_urllib_error
    import sys
    import re
    if sys.version_info < (3, 0):
        compat_str = unicode
    else:
        compat_str = str
    # Get arguments
    args = {}
    # args['url'] = 'http://e-m-b-e-d-d-e-d.com/downloads/Komm-s%C3%BC%C3%9Fer-Tod-HD-1.mp4'
    # args['outtmpl'] = 'Komm-s%C3%BC%C3%9Fer-Tod-HD-1.mp4'
   

# Generated at 2022-06-24 12:09:22.441634
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:29.639740
# Unit test for function full_box
def test_full_box():
    version = 1
    flags = 0
    payload = b"\x01\x02\x03\x04"
    assert full_box(b'av01', version, flags, payload) == b'\x00\x00\x00\x12av01\x01\x00\x00\x00\x01\x02\x03\x04'
    assert full_box(b'av01', version, flags, b'') == b'\x00\x00\x00\x08av01\x01\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 12:09:41.499149
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(f, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000000,
            'sampling_rate': 48000,
            'channels': 2,
            'nal_unit_length_field': 4,
            'codec_private_data': '68f5b6fffe1001437673d07e741c00000167640028ac2ec435b6fffe10101000568ebecb22c',
        })
        f.seek(0)

# Generated at 2022-06-24 12:09:51.120841
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://test.url'
    params = {'ism_id': 'http://test.ism/path'}
    fd = IsmFD(params, url)
    assert fd.url == url
    assert fd.params['ism_id'] == 'http://test.ism/path'
    assert fd.params['fragment_base_url'] == ''
    assert fd.params['manifest_base_url'] == url
    assert fd.params['base_url'] == url
    assert fd.params['skip_unavailable_fragments'] == True

    url = 'http://test.url'
    params = {'ism_id': 'http://test.ism/path', 'fragment_base_url': 'http://test.fragment/base/'}

# Generated at 2022-06-24 12:10:01.065792
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:10:10.969788
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {
        "fragments": [
            {
                "url": "http://xxx/a.ism/Fragments(...)",
                "duration": "1.3",
                "title": "Fragment 1",
                "segment_num": 0
            },
            {
                "url": "http://xxx/b.ism/Fragments(...)",
                "duration": "1.6",
                "title": "Fragment 2",
                "segment_num": 1
            },
            {
                "url": "http://xxx/c.ism/Fragments(...)",
                "duration": "1.6",
                "title": "Fragment 3",
                "segment_num": 2
            }
        ]
    }

# Generated at 2022-06-24 12:10:16.436964
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://www.example.com'
    params = {
            'force_smil_url': True
    }

    fd = IsmFD(url, params)

    assert(fd.params['force_smil_url'] == params['force_smil_url'])

# Generated at 2022-06-24 12:10:28.239598
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x26\x73\x6b\x79\x64\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    data_reader = io.BytesIO(data)
    box_size = u32.unpack(data_reader.read(4))[0]
    box

# Generated at 2022-06-24 12:10:39.716769
# Unit test for function write_piff_header
def test_write_piff_header():
    bf = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 1175, 'timescale': 44100, 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 0, 'sampling_rate': 44100}
    write_piff_header(bf, params)

# Generated at 2022-06-24 12:10:51.705524
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import Downloader
    from .utils import format_bytes

    import tempfile

    url = 'http://example.com/test.ism/test.ism/Manifest'
    dl = Downloader({'format': 'ism', 'fragment_retries': 10, 'test': True})
    result = dl.extract(url)
    (os_f, filename) = tempfile.mkstemp()
    dl.process_info(result['info_dict'], IsmFD(dl.params), filename, None)
    f = io.open(filename, 'rb')
    data = f.read()
    f.close()
    os.close(os_f)
    os.remove(filename)

    assert len(data) > 0
    assert data.startswith(b'ftyp')


# Generated at 2022-06-24 12:10:59.842561
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL()

    with open('tests/testdata/smoothstreaming/playlist.ismc', 'rb') as f:
        playlist = f.read().decode('utf-8')

    smoothstreaming_info = dict(
        _type='smoothstreaming',
        protocol='mss',
        playlist=playlist,
        manifests=['http://test.com/Manifest'],
        _download_params=dict(
            fourcc='AACL',
            duration=3060,
            sampling_rate=44100,
            track_id=1,
            codec_private_data='1210',
            timescale=10000000,
        )
    )
    fd = IsmFD(ydl, smoothstreaming_info, {})

# Generated at 2022-06-24 12:11:01.326176
# Unit test for function box
def test_box():
    return box('ftyp', 'isom') == b'\x00\x00\x00\x10ftypisom'
# End unit test for function box


# Generated at 2022-06-24 12:11:13.546808
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:11:19.583342
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    data = {
        'ext': 'mp4', # assumed
        'protocol': 'ism',
        'title': 'test',
        'url': 'test',
        'fragments': [
            {
                'url': 'test',
            },
        ],
        '_download_params': {
            'fourcc': 'AACL',
            'duration': 0,
            'sampling_rate': 0,
        },
    }
    fd = IsmFD(params={'test': True})
    assert fd.real_download('test', data) == True

# Generated at 2022-06-24 12:11:24.971209
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'box1', full_box(b'box2', 1, 2, box(b'box3', b'foo')))
    assert extract_box_data(data, (b'box1', b'box2', b'box3')) == b'foo'
    assert extract_box_data(data, (b'box1', b'box2')) == box(b'box3', b'foo')



# Generated at 2022-06-24 12:11:38.075282
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest_url = "https://amssamples.streaming.mediaservices.windows.net/622b189f-ec39-43f2-93a2-201ac4e31ce1/BigBuckBunny.ism/manifest"

# Generated at 2022-06-24 12:11:47.395432
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 10000, 'language': 'en', 'bits_per_sample': 16,
              'channels': 2, 'sampling_rate': 48000}

    stream = io.BytesIO()
    write_piff_header(stream, params)

    expected = io.BytesIO()
    expected.write(b'\x00\x00\x00&ftyp')
    expected.write(b'isml\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00')
    expected.write(b'piffiso2')
    expected.write(b'\x00\x00\x00\x1amoov')

# Generated at 2022-06-24 12:11:57.152649
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    webm_url = 'https://www.youtube.com/watch?v=5mK8WcFnBvE'
    youtube_dl_arguments = {'format': 'webm', 'writeinfojson': True, 'writesubtitles': True, 'simulate': True, 'skip_download': True}
    ydl = YoutubeDL(youtube_dl_arguments)
    info_dict = ydl.extract_info(webm_url, download=False)
    with open('/root/Downloads/test/test.webm', 'wb') as webm_file:
        fd = IsmFD()
        fd.params = {'test': True}
        fd.real_download(webm_file, info_dict)


test_IsmFD_real_download()

# Generated at 2022-06-24 12:11:59.865438
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD([], {'fragments': []})
    assert isinstance(fd,IsmFD)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:12:02.320407
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 0, b'') == b'\x00\x00\x00\x0cmoov\x01\x00\x00\x00'
test_full_box()



# Generated at 2022-06-24 12:12:04.451779
# Unit test for function box
def test_box():
    assert(box(b"xxxx", b"yyyy") == b'      xxxx' + b'yyyy')


# Generated at 2022-06-24 12:12:14.293538
# Unit test for function full_box
def test_full_box():
    payload_len = u32.pack(8)
    payload_type = 'mdhd'
    payload_version = u8.pack(0)
    payload_flags = u32.pack(0)[1:]
    payload_creation_time = u64.pack(int(time.time()))
    payload_modification_time = u64.pack(int(time.time()))
    payload_timescale = u32.pack(90000)
    payload_duration = u32.pack(0)
    payload_language = u1616.pack(10)
    payload_quality = u16.pack(0)
    payload = (payload_creation_time + payload_modification_time + payload_timescale
               + payload_duration + payload_language + payload_quality)

# Generated at 2022-06-24 12:12:19.439089
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ytdl.downloader import Downloader
    from ytdl.extractor import ManifestExtractor
    from ytdl.options import options
    from ytdl.utils import match_filter_func

    options.verbose = True
    options.test = True
    options.fragment_retries = 3
    options.skip_unavailable_fragments = True
    match_filter = match_filter_func(['ism'])

    sys.stderr.write('Testing IsmFD...\n')


# Generated at 2022-06-24 12:12:27.850021
# Unit test for function box
def test_box():
    print("Running test for function box")
    expected="\x00\x00\x00\x0c\x66\x74\x79\x70\x69\x6f\x6f\x6f\x6f"
    result=box('ftyp', 'iooo')
    assert result==expected, "Box function is broken, expect: %s, result: %s" % (expected, result)
    print("test_box passed.")
# End test for function box


# Generated at 2022-06-24 12:12:35.748627
# Unit test for function write_piff_header
def test_write_piff_header():
    import unittest

    video_params_test = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'codec_private_data': '0164001fffe1001907dfdf7e428080808080809601070041ffe100158782d41054',
        'nal_unit_length_field': 4,
        'duration': 1608300,
        'timescale': 10000000,
        'width': 1280,
        'height': 720
    }


# Generated at 2022-06-24 12:12:40.013833
# Unit test for function box
def test_box():
    result = box(b'hdlr', b'')
    assert(result == b'\x00\x00\x00\x0c' b'hdlr' b'\x00\x00\x00\x00\x00\x00\x00\x00')



# Generated at 2022-06-24 12:12:47.780852
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_IsmFD_real_download.fd = IsmFD(
        {'url': 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd'},
        {'outtmpl': '%(id)s.mp4'}
    )
    # Running real_download method

# Generated at 2022-06-24 12:13:00.170380
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mvhd', 1, 0, b'\0'*4) == b'\x00\x00\x00(\x6d\x76\x68\x64\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 12:13:09.386401
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    info_dict = {
        'id': 'sxleu1xgpgbf',
        'extractor': 'IsmFD',
        'title': 'How It’s Made: Wheel-Thrown Ceramics',
        'formats': [],
        '_type': 'url',
        'url': 'http://www.sciencechannel.com/tv-shows/how-its-made/videos/how-its-made-wheel-thrown-ceramics/',
        'display_id': 'How It’s Made: Wheel-Thrown Ceramics',
        'ie_key': 'IsmFD',
    }
    self_test(info_dict)

# If run as script

# Generated at 2022-06-24 12:13:18.883374
# Unit test for function extract_box_data
def test_extract_box_data():
    # Tests extract_box_data with a PIFF file (Box sequences for mdat, 'mdat' and stsd, 'moov', 'trak', 'mdia', 'minf', 'stbl', 'stsd')
    # Reads the sample piff file and applies the function to mdat and stsd
    test_piff_url = 'http://video.ch9.ms/build/2011/slides/TOOL-579T_Sutter.pptx'
    with compat_urllib_error.urlopen(test_piff_url) as test_piff_data:
        mdat_data = extract_box_data(test_piff_data.read(), ('moov', 'trak', 'mdia', 'minf', 'stbl', 'stsd'))
    assert mdat_data
    mdat_data = extract