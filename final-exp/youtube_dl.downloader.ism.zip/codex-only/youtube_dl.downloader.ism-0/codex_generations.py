

# Generated at 2022-06-24 12:03:11.637246
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'



# Generated at 2022-06-24 12:03:22.876382
# Unit test for function full_box
def test_full_box():
    from .test import get_test_file
    from .psp import PSPIE
    ie = PSPIE(get_test_file('rmvb', 'RV40'))

# Generated at 2022-06-24 12:03:27.686288
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:33.323630
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # common test argument
    url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-ondemand/mp4-onDemand-mpd-AV-BS.mpd'
    params = {
        'src_url': url,
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1551,
        'timescale': 10000000,
        'language': 'und',
        'width': 640,
        'height': 480,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'codec_private_data': '01640028affe1000daf28a6'
    }

# Generated at 2022-06-24 12:03:39.619901
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ret = True
    url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest"
    params = {'noprogress': True, 'test': True, 'format': 'ism', 'fragment_retries': 0}
    filename = "E:\downloads_test\test.ism"
    IsmFD().real_download(filename, get_video_info(url, params))
    return ret

# Generated at 2022-06-24 12:03:50.041798
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:03:59.771918
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'width': 1280,
        'height': 720,
        'codec_private_data': '0000000167640033AC2C80DEB70938A3CE3',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-24 12:04:09.249940
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:15.512408
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:23.029522
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:04:31.098032
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'track_id': 0,
        'fourcc': 'AACL',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'duration': 130100000,
    })

# Generated at 2022-06-24 12:04:40.411926
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov' + u32.pack(0) + b'\x00\x00\x00\x01' # 1 track
    data += b'trak\x00\x00\x00\x5c'
    data += b'tkhd\x00\x00\x00\x18'
    data += u8.pack(0) * 16 + u32.pack(0)
    data += u64.pack(1) + u64.pack(0) + u64.pack(100)
    data += b'mdia\x00\x00\x00\x28'
    data += b'hdlr\x00\x00\x00\x16'
    data += u32.pack(0) * 2 + b'vide' + u32.pack(0) * 3
    data

# Generated at 2022-06-24 12:04:45.737749
# Unit test for function box
def test_box():
    # base box
    assert box('free', b'') == b'\x00\x00\x00\x08free'
    # full box
    assert box('free', b'\x01\x02\x03\x04') == b'\x00\x00\x00\x0cfree\x01\x02\x03\x04'



# Generated at 2022-06-24 12:04:47.597439
# Unit test for function box
def test_box():
    assert box('abcd', '4567') == b'\x00\x00\x00\x08abcd4567'



# Generated at 2022-06-24 12:04:53.068896
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['smoothstreams']
    info_dict = youtube_ie._real_extract('smoothstreams:game:nba')
    return IsmFD.download_fragments(info_dict['entries'][0], info_dict)

if __name__ == '__main__':
    print(test_IsmFD())

# Generated at 2022-06-24 12:05:04.437245
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import float_hex

    f = io.BytesIO()
    # From https://www.youtube.com/watch?v=pJo1FxKBZC8
    write_piff_header(
        f, {
            'track_id': 1,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
            'duration': float_hex(0.8592),
            'timescale': 48000,
            'language': 'eng',
            'fourcc': 'AACL',
        })

# Generated at 2022-06-24 12:05:14.634955
# Unit test for function full_box
def test_full_box():
    print(full_box('ftyp', 0, 0, 'avc1'))
    print(full_box('ftyp', 0, 0, 'avc1'))
    print(full_box('ftyp', 0, 0, 'avc1'))


# Generated at 2022-06-24 12:05:26.563424
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .ism import IsmFD
    from .common import FileDownloader
    from .extractor import YoutubeIE
    params = {}
    params['test'] = True
    params['fragment_retries'] = 0
    params['skip_unavailable_fragments'] = True
    params['fragment_base_url'] = 'http://0.0.0.0:8000/test/'
    params['fragment_base_path'] = './'
    params['fragment_format'] = 'd.mp4'
    params['fragment_duration'] = 1
    params['duration'] = 4
    fd = IsmFD(params)
    info_dict = {}

# Generated at 2022-06-24 12:05:32.961389
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    s = Sess()

# Generated at 2022-06-24 12:05:37.055375
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = FakeYDL({'fragment_retries': 3})
    manifest_url = 'http://manifest_url'
    ism = IsmFD(ydl, manifest_url)
    assert ism.manifest_url == manifest_url
    assert ism.ydl == ydl

if __name__ == '__main__':
    sys.exit(test_IsmFD())

# Generated at 2022-06-24 12:05:44.816447
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import encode_data_uri
    
    # Test for invalid input to check for boundry conditions
    with pytest.raises(ValueError):
        IsmFD('Invalid URL', {'fragments':[]}, YoutubeDL({'quiet': True}))

    # Test for non existent URL
    with pytest.raises(ValueError):
        IsmFD('http://non_existent_url', {'fragments':[]}, YoutubeDL({'quiet': True}))
    
    # Test for wrong URL
    with pytest.raises(ValueError):
        IsmFD('https://github.com/ytdl-org/youtube-dl', {'fragments':[]}, YoutubeDL({'quiet': True}))
    


# Generated at 2022-06-24 12:05:51.815012
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    youtube_dl = YoutubeDL({'fragment_retries': 0, 'skip_unavailable_fragments': True, 'test': True})
    youtube_dl.download = lambda x: False
    IsmFD('https://fake.url/playlist.isml', youtube_dl, {}).real_download('fake_filename', {'fragments': [{'url': 'fake_segment_url'}]})



# Generated at 2022-06-24 12:05:59.914890
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(
        b'\x01\x00\x00\x00'
        b'\x00\x00\x00\x00'
        b'\x02\x00\x00\x00'
        b'\x00\x00\x00\x00',
        (b'\x01\x00\x00\x00', )
    ) == b'\x00\x00\x00\x00'


# Generated at 2022-06-24 12:06:02.855513
# Unit test for function box
def test_box():
    assert(box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x0Cmoov\x00\x00\x00\x00')



# Generated at 2022-06-24 12:06:16.947559
# Unit test for function write_piff_header
def test_write_piff_header():
    import io
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000,
        'timescale': 10000000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 24000,
    }
    with io.BytesIO() as stream:
        write_piff_header(stream, params)
        b = stream.getvalue()
    assert b.startswith(u32.pack(0x1a36f90a))  #  ftyp moov
    assert b[16:24] == b'ftyp'
    assert b[24: 28] == b'isml'
    assert b[28: 32] == u32.pack(1)

# Generated at 2022-06-24 12:06:17.684779
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-24 12:06:20.258840
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-24 12:06:25.572531
# Unit test for function box
def test_box():
    assert box('abcd', 'efghi') == b'\x00\x00\x00\x0deabcd\xefghi'

ftyp_box = (b'ftypisom' + u32.pack(0) * 2 + b'isomiso2avc1mp41' + u8.pack(0) * 4)

# Generated at 2022-06-24 12:06:27.023843
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Since IsmFD just downloads something, no need to test it
    return


# Generated at 2022-06-24 12:06:30.441842
# Unit test for constructor of class IsmFD
def test_IsmFD():
    r = IsmFD({'url': 'http://blah.com/manifest.ism'})
    assert r.FD_NAME == 'ism'

# Generated at 2022-06-24 12:06:35.329482
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # Run the real_download method of the class IsmFD with the values:
    # filename = ""
    # info_dict = {"fragments" : [{}, {}, {}]}
    # if the following asserts are correct
    # assert success
    # assert track_written
    pass


# Generated at 2022-06-24 12:06:41.290340
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\nmoov'
    assert box(b'moov', b'\x00\x00\x00\x06soun') == b'\x00\x00\x00\x14moov\x00\x00\x00\x00\x00\x00\x00\x06soun'


# Generated at 2022-06-24 12:06:44.733227
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test the IsmFD constructor
    """
    try:
        IsmFD('http://test.test/test.ism/test.isml')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 12:06:46.670782
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'payload') == b'\x00\x00\x00\x10mvhdpayload'



# Generated at 2022-06-24 12:06:50.628958
# Unit test for function extract_box_data
def test_extract_box_data():
    from .common import random_hex
    data = bytes.fromhex(random_hex(1000000))
    box_sequence = b'foob'
    for i in range(1000):
        data = data[:i] + box(box_sequence, box(box_sequence, data[i:]))
    assert box_sequence == extract_box_data(data, (box_sequence, box_sequence))


# Generated at 2022-06-24 12:06:54.497054
# Unit test for function full_box
def test_full_box():
    box_type = "abcd"
    payload = "efgh"
    res = full_box(box_type,1,1,payload)
    assert res == b'\x00\x00\x00\x0cabcd\x01\x00\x00\x01efgh'


# Generated at 2022-06-24 12:07:00.813491
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor

    ie = InfoExtractor()
    # Test video-only manifest
    ie.add_info_extractor(IsmFD.ie_key())

# Generated at 2022-06-24 12:07:03.698969
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x08 ftyp' == box(b'ftyp', b'')


# Generated at 2022-06-24 12:07:12.279148
# Unit test for function full_box
def test_full_box():
    version = 0
    flags = 0
    box_type = b'ftyp'
    payload = b'mp42' + (b'\x00' * 4) + b'mp42'
    print("Testing full_box")
    result = full_box(box_type, version, flags, payload)
    expected = b'\x00\x00\x00$ftypmp42\x00\x00\x00mp42'
    assert result == expected



# Generated at 2022-06-24 12:07:12.892578
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-24 12:07:24.047539
# Unit test for constructor of class IsmFD
def test_IsmFD():
    video_url = 'http://example.org/video.ism/Manifest'
    fd = IsmFD(ydl_params={})
    assert fd.suitable('http://example.org/video.ism/Manifest')
    assert fd.suitable('http://example.org/video.ism/Manifest(format=mpd-time-csf)')
    assert fd.suitable('http://example.org/video.ism/Manifest?parameter=value')
    assert fd.suitable(video_url) is False
    assert fd.suitable(u'http://example.org/video.ism/Manifest')
    assert fd.suitable(u'http://example.org/video.ism/Manifest(format=mpd-time-csf)')

# Generated at 2022-06-24 12:07:26.143257
# Unit test for function box
def test_box():
    assert box('free', 'payload') == b'\x00\x00\x00\nfreepayload'


# Generated at 2022-06-24 12:07:34.989643
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    import binascii


# Generated at 2022-06-24 12:07:41.836350
# Unit test for function extract_box_data
def test_extract_box_data():
    data_reader = io.BytesIO(binascii.unhexlify(b"6D6976655A966552434C5300000008007469746C650003766D6864004B0000007469746C650000007469746C650003766D68640000000000"))
    boxes = extract_box_data(data_reader.read(), [b'moov', b'trak', b'mdia', b'mdhd'])
    if boxes:
        print(boxes)
        assert(boxes == binascii.unhexlify(b"0000000400000000000400000000000000"))


# Generated at 2022-06-24 12:07:50.777304
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\0\0\0\x10stsd\0\0\0\x10tsd\0\0\0\0', [b'stsd']) == b'tsd\0\0\0\0'
    assert extract_box_data(b'\0\0\0\x10stsd\0\0\0\x10tsd\0\0\0\0', [b'stsd', b'tsd']) == b''
    assert extract_box_data(b'\0\0\0\x10stsd\0\0\0\x10tsd\0\0\0\0', [b'sts']) == None



# Generated at 2022-06-24 12:07:57.883105
# Unit test for function full_box
def test_full_box():
    box_type = b'frag'
    version = 2
    flags = 0x00
    payload = b'\x00\x00\x00\x00'
    bb = full_box(box_type, version, flags, payload)
    assert(bb[4:8] == box_type)
    assert(bb[8] == version)
    assert(bb[9:12] == b'\x00\x00\x00')
    assert(bb[12:] == payload)



# Generated at 2022-06-24 12:08:06.415998
# Unit test for function full_box
def test_full_box():
    assert binascii.hexlify(full_box(b'moov', 0, 0, b'12345678')) == b'00000014' + b'moov' + b'00' + b'00000000' + b'12345678'
    assert binascii.hexlify(full_box(b'moov', 0, 1, b'12345678')) == b'00000014' + b'moov' + b'00' + b'00000001' + b'12345678'
    assert binascii.hexlify(full_box(b'moov', 0, 2, b'12345678')) == b'00000014' + b'moov' + b'00' + b'00000002' + b'12345678'

# Generated at 2022-06-24 12:08:11.336560
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
    assert box(b'moov', b'aaa') == b'\x00\x00\x00\x0bmoovaaa'
# End unit test for function box



# Generated at 2022-06-24 12:08:21.109626
# Unit test for function write_piff_header
def test_write_piff_header():
    import struct
    import binascii
    import hashlib

# Generated at 2022-06-24 12:08:26.149782
# Unit test for function full_box
def test_full_box():
    assert full_box(b'\x00\x00\x00\x18',1,0b10000000,b'\x00\x00\x00\x00') == b'\x00\x00\x00\x18\x00\x00\x00\x18\x01\x80\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:08:29.064386
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD({}, None)
    assert ism_fd.FD_NAME == 'ism'
    assert ism_fd.__class__.__name__ == 'IsmFD'

# Generated at 2022-06-24 12:08:37.845477
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Method `real_download` of class `IsmFD` unit test
    """
    downloader = DummyYoutubeDl()
    extractor = DummyIE(downloader)
    info_dict = {
        'format': 'ism',
        'fragments': [{
            'url': 'https://www.example.com/fragment_1.ism',
        }],
        '_download_params': {
            'track_id': 1,
        },
    }


# Generated at 2022-06-24 12:08:48.016218
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:08:59.130159
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .utils import FakeYDL, FakeFD, _TEST_FILE_URL
    from .extractor import YoutubeIE
    fake_ytdl = FakeYDL()
    fake_ytdl.add_info_extractor(YoutubeIE)
    fake_ytdl.params['writesubtitles'] = True
    fake_ytdl.params['allsubtitles'] = True
    fake_ytdl.params['noplaylist'] = True
    fake_ytdl.params['writethumbnail'] = True
    fake_ytdl.params['forcetitle'] = True
    fakeismfd = IsmFD(fake_ytdl, {'url': _TEST_FILE_URL}, 'test_frag')

# Generated at 2022-06-24 12:09:02.072339
# Unit test for function box
def test_box():
    assert box('abcd', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x08abcd\x00\x00\x00\x00'



# Generated at 2022-06-24 12:09:10.074688
# Unit test for function extract_box_data

# Generated at 2022-06-24 12:09:14.050274
# Unit test for function full_box
def test_full_box():
    version = 0
    flags = 0
    payload = 'aaaa'
    box_type = 'free'

    f = full_box(box_type, version, flags, payload)

# Generated at 2022-06-24 12:09:25.205344
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .http_fd import HttpFD
    from .dash import DASHIE
    from .dash import parse_mpd_formats
    from .downloader import Downloader
    from .FragmentFD import FragmentFD
    from .ttml import TTMLFD

    def _add_ns(uri, tag):
        return '{%s}%s' % (uri, tag)

    def _add_ns_map(ns_map):
        return {key: _add_ns(ns_map[key], key) for key in ns_map}

    # Add namespaces to be used in XPath expressions in _parse_mpd_formats

# Generated at 2022-06-24 12:09:32.718175
# Unit test for function full_box
def test_full_box():
    assert full_box(b'\x00\x00\x00\x00', 0, 0, b'') == b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert full_box(b'\x01\x02\x03\x04', 0, 0, b'') == b'\x00\x00\x00\x00\x01\x02\x03\x04\x00\x00\x00\x00'

# Generated at 2022-06-24 12:09:38.445993
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Sample test for constructor of class IsmFD
    :return:
    """
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '-', 'quiet': True, 'logger': YoutubeDL.null_logger()})
    ie = IsmFD(ydl=ydl)
    assert ie.__class__.__name__ == 'IsmFD'

# Generated at 2022-06-24 12:09:46.731361
# Unit test for function write_piff_header
def test_write_piff_header():
    sample_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 2000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16
    }
    stream = io.BytesIO()
    write_piff_header(stream, sample_params)

# Generated at 2022-06-24 12:09:55.890570
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 80000000,  # 2 secs
        'timescale': 30000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe10014668eb3c816010d8a0f0c9a376e47a0000001e670028ac2bb71f0028ac2bb71f',  # AVC SPS/PPS
    }
    out = io.BytesIO()
    write_piff_header(out, params)
    print(binascii.hexlify(out.getvalue()).decode('ascii'))



# Generated at 2022-06-24 12:10:01.979263
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_url = "http://wams.edgesuite.net/media/MPTExpressionData02/BigBuckBunny_640x360_30fps_768kbps.ism/manifest"
    # test_url = "http://wams.edgesuite.net/media/MPTExpressionData02/BigBuckBunny_640x360_30fps_768kbps.ism/manifest(format=mpd-time-csf)"
    # test_url = "http://wams.edgesuite.net/media/MPTExpressionData02/BigBuckBunny_640x360_30fps_768kbps.ism/manifest(format=fmp4-vod-hd)"
    # test_url = "http://wams.edgesuite.net/media/MPTExpressionData

# Generated at 2022-06-24 12:10:11.226556
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 3000,
        'timescale': 10000000,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'width': 1280,
        'height': 720,
        'codec_private_data': '0164001fffe1000b6773580f0000000168ce3c80',
    }
    with io.BytesIO() as stream:
        write_piff_header(stream, params)

# Generated at 2022-06-24 12:10:21.240594
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from . downloader import YoutubeDL
    from . extractor import YoutubeIE
    from . utils import ExtractorError

    ydl = YoutubeDL({'nooverwrites': True, 'skip_download': True, 'test': True})

# Generated at 2022-06-24 12:10:26.037694
# Unit test for function full_box
def test_full_box():
    assert full_box(b'abcd', 0, 0, b'0123') == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x00'
    assert full_box(b'abcd', 0, 1, b'0123') == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x01'
    assert full_box(b'abcd', 1, 0, b'0123') == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x00'

# Generated at 2022-06-24 12:10:31.032879
# Unit test for function box
def test_box():
    assert(box(b'moov', b'') == b'\x00\x00\x00\x0Cmoov')
    assert(box(b'mvhd', b'\x00\x00\x00\x01') == b'\x00\x00\x00\x10mvhd\x00\x00\x00\x01')
# Test done


# Generated at 2022-06-24 12:10:35.448613
# Unit test for function full_box
def test_full_box():
    assert full_box('\x00\x00\x00\x00', 0, 0, '') == '\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 12:10:47.108006
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import BytesIO
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'height': 0,
        'width': 0,
        'language': 'und',
        'codec_private_data': '000000016764001EACD907880810010042C00100000300010000003006000001B852D43C0000000168CA3C80',
    }
    stream = BytesIO()
    write_piff_header(stream, params)
    print(stream.getvalue().encode('hex'))



# Generated at 2022-06-24 12:10:50.471010
# Unit test for function full_box

# Generated at 2022-06-24 12:10:51.212880
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass
#


# Generated at 2022-06-24 12:10:58.050885
# Unit test for function extract_box_data
def test_extract_box_data():
    test_input_data = b'\x00\x00\x00\x00test1\x00\x00\x00\x00test2'
    assert extract_box_data(test_input_data, [b'test1', b'test2']) == b''
    assert extract_box_data(test_input_data, [b'wrong']) is None
    assert extract_box_data(test_input_data, [b'test1']) == b'test2'



# Generated at 2022-06-24 12:11:16.628648
# Unit test for function write_piff_header
def test_write_piff_header():
    def check_piff_header(params, expected=None):
        stream = io.BytesIO()
        write_piff_header(stream, params)
        stream.seek(0)
        if expected:
            assert stream.read() == expected
        return stream.read()

    # Video test
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['codec_private_data'] = '000000016742C00D971DCB801F00000030080000003008DA3880'
    params['duration'] = int(1e8)

# Generated at 2022-06-24 12:11:23.176741
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-mpd-AV-NBS.mpd'
    file_name = 'output.mp4'
    I = IsmFD(url, {'outtmpl': file_name})
    I.download()
    print('Download finished!')
    return True


if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-24 12:11:29.894516
# Unit test for function write_piff_header
def test_write_piff_header():
    test_piff_1 = io.BytesIO()
    write_piff_header(test_piff_1, {
        'track_id': 0x1,
        'duration': 60000000,
        'timescale': 10000000,
        'height': 540,
        'width': 960,
        'codec_private_data': '274280f58e0101dc01170000003008000001bd959f265c080000016b0039e8e00000167640039e8b769855c90f1d1807a09d00',
    })

# Generated at 2022-06-24 12:11:41.085093
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'hi') == b'\x00\x00\x00\x0Chi\x00\x00\x00\x00'
    assert full_box(b'moov', 0, 0x10, b'hi') == b'\x00\x00\x00\x0Chi\x00\x00\x10\x00'
    assert full_box(b'moov', 0, 0x10203040, b'hi') == b'\x00\x00\x00\x0Chi\x00\x10\x20\x40'

# Generated at 2022-06-24 12:11:47.979832
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
# End unit test



# Generated at 2022-06-24 12:11:54.006214
# Unit test for function full_box
def test_full_box():
    t = full_box('sv3d', 0, 0, 'helloworld')
    assert(u32.unpack(t[:4])[0] == 20)
    assert(t[4:8] == 'sv3d')
    assert(u8.unpack(t[8:9])[0] == 0)
    assert(u32.unpack(t[8:12])[0] == 0)
    assert(t[12:] == 'helloworld')
    return t


# Generated at 2022-06-24 12:12:01.879792
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = binascii.unhexlify(b'6469746c65666978')
    assert extract_box_data(box_data, (b'ftyp',)) == box_data
    box_data = binascii.unhexlify(b'6d6f6f763c647265666102656173696f6e20312e3020287573696e672d61727261792d636e29')
    assert extract_box_data(box_data, (b'moov', b'trak', b'mdia', b'minf', b'dinf', b'dref', b'url ')) == box_data



# Generated at 2022-06-24 12:12:08.572953
# Unit test for function box
def test_box():
    assert(box(b'ftyp', b'mp42') == b'\x00\x00\x00\x0cftypmp42')
    assert(box(b'ftyp', b'isom') == b'\x00\x00\x00\x0cftypisom')
    assert(box(b'typx', b'oooo') == b'\x00\x00\x00\x0ctypxoooo')
# End Unit test


# Generated at 2022-06-24 12:12:15.013904
# Unit test for function box
def test_box():
    assert box('free', 'S' * 3) == binascii.a2b_hex('0000000c66726565005300530053')
    assert box('free', 'S' * 4) == binascii.a2b_hex('0000000d667265650053005300530053')
    assert box('free', 'S' * 12) == binascii.a2b_hex('0000001566726565005300530053005300530053005300530053005300530053')



# Generated at 2022-06-24 12:12:21.283408
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialize parameters
    filename = 'test filename'
    info_dict = {'fragments': [{'duration': 1, 'title': None, 'url': 'http://example.com/fragment?segment=1', 'byterange': '0-4095', '_initialization_url': 'http://example.com/initialization?segment=1', 'fragment_index': 1}, {'duration': 1, 'title': None, 'url': 'http://example.com/fragment?segment=2', 'byterange': '0-4095', '_initialization_url': 'http://example.com/initialization?segment=2', 'fragment_index': 2}], 'duration': 2, 'fragment_index': 1}

# Generated at 2022-06-24 12:12:27.320898
# Unit test for function box
def test_box():
    assert(box(b'foob', b'foo') == b'\x00\x00\x00\x0bfoobfoo')
    assert(box(b'\xff'*4, b'') == b'\x00\x00\x00\x08\xff'*4)


# Generated at 2022-06-24 12:12:32.808421
# Unit test for function write_piff_header
def test_write_piff_header():
    in_byte = io.BytesIO()
    write_piff_header(in_byte, {'track_id': 1, 'fourcc': 'AVC1', 'duration': 0, 'codec_private_data': '01640032ffda7b00', 'width': 1920, 'height': 1080})
    print(in_byte.getvalue())



# Generated at 2022-06-24 12:12:43.936222
# Unit test for constructor of class IsmFD
def test_IsmFD():
    u = YoutubeDL({}).urlopen
    ism_urls = (
        'http://media.example.com/media/segment1.ism/QualityLevels(90000)/Fragments(audio=0,format=mp3,index=0)',
        'http://media.example.com/media/segment1.ism/Manifest(video,format=mp4,audio=1)',
        'http://media.example.com/media/segment1.ism/Manifest(video,format=webm,audio=1)',
    )
    for url in ism_urls:
        ismf = IsmFD(url, {}, u)
        # No test
        ismf.real_download(None, {})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-24 12:12:46.509200
# Unit test for function box
def test_box():
    print(u32.pack(8 + len("payload")))
    print(box("box_type", "payload"))



# Generated at 2022-06-24 12:12:52.293733
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == '\x00\x00\x00\x0c' + 'abcd' + '1234'
    assert box('abcd', '1') == '\x00\x00\x00\x0b' + 'abcd' + '1'



# Generated at 2022-06-24 12:12:57.514386
# Unit test for function full_box
def test_full_box():
    assert(full_box("\xa9xyz", 0, 0, "abc") == "abc\x00\x00\x00\x02\xa9xyz\x00\x00\x00\x00")



# Generated at 2022-06-24 12:13:04.250340
# Unit test for function box
def test_box():
    payload = b'\x00\x00\x00\x00'
    box_type = b'moov'
    box_data = b'\x00\x00\x00\x08moov\x00\x00\x00\x00'
    assert box(box_type, payload) == box_data


# Generated at 2022-06-24 12:13:08.153016
# Unit test for function box
def test_box():
    assert box('AAAA', '') == b'\x00\x00\x00\nAAAA'
    assert box('AAAA', '\x00' * 10) == b'\x00\x00\x00\x15AAAA\x00'*10

# Generated at 2022-06-24 12:13:09.629640
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

if __name__ == '__main__':
    test_IsmFD()