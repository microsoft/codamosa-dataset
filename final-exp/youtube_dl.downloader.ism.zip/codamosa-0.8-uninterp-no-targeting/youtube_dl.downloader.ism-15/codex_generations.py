

# Generated at 2022-06-22 07:14:00.937087
# Unit test for function full_box
def test_full_box():
    payload = ""
    flags = 0
    version = 1
    box_type = "ftyp"
    expected = "0000001466747970" + "01" + "00000000" + payload
    actual = full_box(box_type, version, flags, payload)
    assert binascii.hexlify(actual).lower() == expected.lower()
test_full_box()

# Generated at 2022-06-22 07:14:09.157010
# Unit test for function extract_box_data
def test_extract_box_data():
    assert(extract_box_data(box(b'uuuu', u32.pack(1)), [b'uuuu']) == u32.pack(1))
    assert(extract_box_data(box(b'uuuu', box(b'vvvv', u32.pack(1))), [b'uuuu', b'vvvv']) == u32.pack(1))
    assert(extract_box_data(box(b'uuuu', box(b'vvvv', u32.pack(1))), [b'vvvv']) == None)
    assert(extract_box_data(box(b'uuuu', box(b'vvvv', u32.pack(1))), [b'wwww']) == None)

# Generated at 2022-06-22 07:14:13.753838
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'\x00\x00\x00\x00') == binascii.unhexlify('00000018' + '6d6f6f76' + '00' + '00000000' + '00000000')


# Generated at 2022-06-22 07:14:24.997840
# Unit test for function extract_box_data
def test_extract_box_data():
    ftyp_data = b'\x00\x00\x00\x14ftypisom\x00\x00\x02\x00iso2avc1mp41\x9a\x3a\x00\x0b\x86'
    assert extract_box_data(ftyp_data, (b'ftyp', )) == ftyp_data[8:]

# Generated at 2022-06-22 07:14:36.307458
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:39.308953
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'') == b'\x00\x00\x00\x0c' + b'mvhd' + b''
# End unit test

# Generated at 2022-06-22 07:14:50.041016
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import determine_temp
    from .test import TEST_AUDIO_AAC, TEST_VIDEO_H264

    with io.open(determine_temp(), 'wb') as outf:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 113600,
            'timescale': 44100,
            'language': 'mis',
            'sampling_rate': 44100,
        }
        write_piff_header(outf, params)


# Generated at 2022-06-22 07:15:03.010836
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        # {'track_id': 1, 'fourcc': 'H264', 'height': 720, 'codec_private_data': '01640029ffe10017674d4015a8a0280300a0034c05000001e2739ce80', 'width': 1280, 'duration': 14}
        write_piff_header(stream, {'track_id': 1, 'fourcc': 'H264', 'height': 720, 'codec_private_data': '01640029ffe10017674d4015a8a0280300a0034c05000001e2739ce80', 'width': 1280, 'duration': 14})
        # {'track_id': 2, 'fourcc': 'AACL', 'sampling_rate': 48000, 'channels': 2,

# Generated at 2022-06-22 07:15:12.392546
# Unit test for function extract_box_data
def test_extract_box_data():
    from .fragment import test_data
    from .fragment import FragmentFD
    from .common import RandSeq
    from .dash import _extract_aes_key_iv, _aes_decrypt

    data = test_data.decode('hex')
    iv_size = 16
    box_data = extract_box_data(data, (b'uuid', b'moov', b'piff', b'tenc'))
    box_data = box_data[8:]
    version = u8.unpack(box_data[:1])[0]
    if version == 0:
        kid = box_data[3:3 + 16]
        box_data = box_data[3 + 16:]

# Generated at 2022-06-22 07:15:20.621531
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(binascii.unhexlify(b'000000a4000000006d6f6f760000000400000080696d61676500000000000000200000000100000001000000000000000000000100000000000000000000000000000000000000010000001800000000000100000000000000000000000000000000000000010000002400000000f4000000000000000000000000000000000000000000040000000100000001000000000000000000000000000100000000000000010000001800000001000000010000000000000000000000000000000000000000000000'), [b'moov', b'udta', b'yrrc'])
    assert box_data == binascii.unhexlify(b'0000001800000000000100000000000000000000000000000000000000010000002400000000f4000000000000000000000000000000000000000000040000000100000001000000000000000000000000000100000000000000010000001800000001000000010000000000000000000000000000000000000000000000')

# Generated at 2022-06-22 07:15:30.304686
# Unit test for function write_piff_header
def test_write_piff_header():
    pass



# Generated at 2022-06-22 07:15:37.271766
# Unit test for function box
def test_box():
    assert box(b'mdhd', u32.pack(0)) == b'\x00\x00\x00\x10mdhd\x00\x00\x00\x00\x00\x00\x00\x00'
    assert box(b'mdhd', u32.pack(1)) == b'\x00\x00\x00\x11mdhd\x00\x00\x00\x01\x00\x00\x00\x00\x00'
    #assert box(b'mdhd', u64.pack(1)) == b'\x00\x00\x00\x11mdhd\x00\x00\x00\x01\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:15:45.740056
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000 * 10000000 / 90,
        'timescale': 10000000,
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 90,
    }
    write_piff_header(stream, params)
    print(binascii.hexlify(stream.getvalue()))



# Generated at 2022-06-22 07:15:51.932927
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'codec_private_data': '01640028ffec0100000300012000c40f130000',
        'fourcc': 'AVC1',
        'sampling_rate': 44100,
        'duration': 10000,
        'width': 1280,
        'height': 720,
    }
    write_piff_header(stream, params)
    expected_box = u32.pack(8 + 12 + 140) + b'moov'
    expected_mvhd = u32.pack(8 + 96) + b'mvhd'
    expected_mvhd += u8.pack(1) + u32.pack(0)

# Generated at 2022-06-22 07:16:02.464982
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = Downloader("ism://manifest/adaptive")
    temp = tempfile.mkstemp(prefix="downloader_test_")
    e = IsmFD(downloader, {}, {"file": temp[1]})
    os.remove(temp[1])
    e.to_screen("ISM")
    e.report_error("ISM")
    e.report_warning("ISM")
    e.report_retry_fragment("ISM", 0, 0, 1)
    e.report_skip_fragment(0)
    assert e.get_num_frags() == 0
    assert e.get_frag_index() == 0
    assert e.overwrite_existing_fragments()
    assert not e.get_frag_filename(1)

# Generated at 2022-06-22 07:16:08.099588
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Create an object of class IsmFD
    ismfd = IsmFD({}, [])

    # Test extract_info function
    # data: the data returned from a http request
    data = "hello world"
    # Test for a valid data
    info = ismfd.extract_info(data, {'nolength': True})
    # Test for wrong data (None type)
    try:
        ismfd.extract_info(None, {'nolength': True})
    except ValueError as e:
        # Expect
        pass
    except:
        # Unexpected
        assert False

    # Test _prepare_and_start_frag_download function

# Generated at 2022-06-22 07:16:11.244643
# Unit test for function full_box
def test_full_box():
    assert full_box('free', 0, 0, b'\x00' * 1) == b'\x00\x00\x00\x09free\x00\x00\x00\x00'

# Generated at 2022-06-22 07:16:14.714364
# Unit test for function box
def test_box():
    assert ('\x00\x00\x00\x0eftypmp42\x00\x00\x00\x00mp42isom' ==
        box('ftyp', 'mp42\x00\x00\x00\x00mp42isom'))



# Generated at 2022-06-22 07:16:26.382310
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Constructor of class IsmFD
    # @param params [in] parameters to initialize IsmFD
    # @return initialized IsmFD
    # @retval None failed to initialize IsmFD
    url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264PR/SuperSpeedway_720.ism/Manifest"
    params = {
        'url': url,
        'proxy': None,
        'filepath': 'SuperSpeedway_720.ism',
    }
    # Constructor of class IsmFD
    ism_fd = IsmFD(params)
    # @param result [out] result of function IsmFD.real_extract()
    # @return True succeeded
    # @return False failed
    result = ism_fd.real_extract(params, {})

# Generated at 2022-06-22 07:16:34.575720
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(8 + len(b'mdat')) + b'mdat' + u32.pack(8 + len(b'fmp4')) + b'ftyp' + b'fmp4'
    assert extract_box_data(data, [b'mdat']) == b'fmp4'
    assert extract_box_data(data, [b'mdat', b'ftyp']) == b'fmp4'
    assert extract_box_data(data, [b'ftyp', b'mdat']) is None
    data = u32.pack(8 + len(b'mdat')) + b'mdat' + u32.pack(8 + len(b'test')) + b'moi!' + b'test'
    assert extract_box_data(data, [b'mdat']) == b'test'

# Generated at 2022-06-22 07:16:49.120934
# Unit test for function full_box
def test_full_box():
    assert full_box('\x00\x00\x00\x00', 1, 0x40000000, '\x00\x00\x00\x00') == '\x14\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x40\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 07:16:57.768762
# Unit test for function full_box
def test_full_box():
    box_type = "mdat"
    version = 0
    flags = 0
    payload = "a" * 8
    str_ = full_box(box_type,version,flags,payload)
    assert len(str_) == 16
    box_type1 = str_[8:12]
    assert box_type == box_type1
    version1 = str_[12]
    assert version == version1
    flags1 = str_[13:16]
    assert flags1 == flags
    payload1 = str_[16:]
    assert payload == payload1



# Generated at 2022-06-22 07:17:06.762030
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ytdl.downloader.http import HttpFD
    from ytdl.utils import calc_xor_checksum
    from .ism import IsmFD
    from .ism import extract_box_data
    import tempfile
    dummy_fd = HttpFD(None, None, None)
    dummy_fd.params = {'continuedl': True}
    dummy_fd.add_progress_hook(lambda *a: None)
    dummy_fd.report_error = lambda *a: None
    dummy_fd.report_warning = lambda *a: None
    dummy_fd.report_retry_fragment = lambda *a: None
    dummy_fd.report_skip_fragment = lambda *a: None
    dummy_fd.to_screen = lambda *a: None
    dummy_fd.set_cookies

# Generated at 2022-06-22 07:17:10.600316
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    ydl = YoutubeDL({})
    result = IsmFD(ydl, {})
    assert result.params == {}
    assert result.ydl == ydl



# Generated at 2022-06-22 07:17:15.447380
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with parameters passed as a string
    info_dict = {}
        
    # Test without parameters passed as a string
    # No need to test IsmFD as it doesn't have any constructor overload.
    # The parameters are passed as a dictionary instead of a string

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:17:25.271553
# Unit test for function extract_box_data
def test_extract_box_data():
    try:
        import pytest
    except ImportError:
        return
    # Test 1

# Generated at 2022-06-22 07:17:34.533970
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    write_piff_header(fd, dict(
        track_id=1,
        fourcc='AVC1',
        duration=400000,
        language='eng',
        timescale=90000,
        width=800,
        height=600,
        codec_private_data='000000016742c01e9a03142bd9401e00000030001e8c1ff8c01fc40a50000031400'))
    fd.seek(0)

# Generated at 2022-06-22 07:17:41.098748
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    params = {'cachedir': None, 'noprogress': False, 'outtmpl': u'%(id)s.%(ext)s', 'nooverwrites': False, 'ratelimit': None, 'retries': 10, 'writedescription': True, 'buffersize': None, 'subtitleslang': None, 'matchtitle': None, 'postprocessors': None, 'nopart': False, 'listformats': None, 'format': u'bestaudio/best', 'writesubtitles': False, 'outtmpl': u'video.mp4'}


# Generated at 2022-06-22 07:17:48.135450
# Unit test for function full_box
def test_full_box():
    assert full_box('frma', 0, 0, b'') == b'\x00\x00\x00\x10frma\x00\x00\x00\x00'
    assert full_box('ftyp', 0, 0, 'isml') == b'\x00\x00\x00\x18ftyp\x00' + b'isml'


# Generated at 2022-06-22 07:17:48.604873
# Unit test for function box
def test_box():
    return None



# Generated at 2022-06-22 07:18:04.435200
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mvhd', 1, 0, b'some payload') == b'\x00\x00\x00\x14mvhd\x00\x01\x00\x00\x00\x00some payload'


# Generated at 2022-06-22 07:18:16.848022
# Unit test for function write_piff_header
def test_write_piff_header():
    """
    b'typical' params:
    {
        'bits_per_sample': 16,
        'channels': 2,
        'codec_private_data': '01640089f0fa0098f0fa0098f0fa0098f0fa0098f0fa0098f0fa0098f0fa',
        'duration': 536000000,
        'fourcc': 'AACL',
        'height': 540,
        'sampling_rate': 44100,
        'track_id': 1,
        'width': 960
    }
    """

    fragment_file = io.BytesIO()
    
    # 'typical' params for audio

# Generated at 2022-06-22 07:18:27.938535
# Unit test for function extract_box_data
def test_extract_box_data():
    moov = box(b'moov', box(b'foo1', box(b'foo2', box(b'bar', b''))))
    assert extract_box_data(moov, (b'bar',)) == b''
    assert extract_box_data(moov, (b'foo2',)) == box(b'bar', b'')
    assert extract_box_data(moov, (b'foo1',)) == box(b'foo2', box(b'bar', b''))
    assert extract_box_data(moov, (b'foo1', b'foo2')) == box(b'bar', b'')
    assert extract_box_data(moov, (b'foo1', b'bar')) == b''

# Generated at 2022-06-22 07:18:33.814323
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.__name__ == 'IsmFD'
    assert IsmFD.__module__ == 'youtube_dl.downloader.ism'

    tfd = IsmFD()
    assert tfd.__class__.__name__ == 'IsmFD'
    assert tfd.__class__.__module__ == 'youtube_dl.downloader.ism'

# Generated at 2022-06-22 07:18:41.109098
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:51.887436
# Unit test for function full_box
def test_full_box():
    #bbox = full_box(b"ftyp", 0, 0, "isomiso2avc1mp41")
    bbox = full_box(b"a", 0, 0, "a")
    f = io.BytesIO(bbox)
    data = f.read(8)
    assert len(data) == 8
    assert box_length(data) == len(bbox)
    assert box_type(data) == b"a"
    assert f.read(1) == b'\x00' # version
    assert f.read(3) == b'\x00\x00\x00' # flags
    assert f.read(1) == b'a'
    assert f.read() == b''

# Video Track

# Generated at 2022-06-22 07:18:53.694495
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Test the method real_download of class IsmFD
    """
    pass



# Generated at 2022-06-22 07:19:04.124387
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    #Test 1 (success): check if the filename is writeable when
    #instance is created without destination parameter.
    params = dict(filename = os.path.join('test_folder', 'output.ism'))
    fd = IsmFD(params)
    res = fd.real_download('', None)
    assert res

    #Test 2 (failure): check if the filename is writeable when
    #instance is created with destination parameter.
    params = dict(filename = os.path.join('test_folder', 'output.ism'),
        destination = os.path.join('test_folder', 'output.ism'))
    fd = IsmFD(params)
    res = fd.real_download('', None)
    assert res

    #Test 3 (failure): check if the filename is writeable when
    #instance is

# Generated at 2022-06-22 07:19:04.754271
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:19:06.959586
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD('http://foo.com')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:19:44.937872
# Unit test for function box
def test_box():
    assert box(b"ftyp", b"msdh") == b"\x00\x00\x00\x0Cftypmsdh"



# Generated at 2022-06-22 07:19:48.634814
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234567890') == b'\x00\x00\x00\x12abcd1234567890'



# Generated at 2022-06-22 07:19:49.171129
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:19:54.481369
# Unit test for function full_box
def test_full_box():
    # result = full_box('mvhd'.encode(), 0, 0, '')
    result = full_box(b'mvhd', 0, 0, b'')
    assert len(result) == 20
    assert result == b'\x00\x00\x00\x14mvhd\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 07:19:59.678286
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    import ytdl_IsmFD
    ydl_fd = ytdl_IsmFD.IsmFD({'format':'ism'}, None, None)
    assert ydl_fd.params['format'] == 'ism'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:20:11.109510
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:20:15.465173
# Unit test for function box
def test_box():
    assert (box('free', 'hello') ==
            binascii.unhexlify('0000000C666572656568656C6C6F'))
    assert (box('mdat', 'hello') ==
            binascii.unhexlify('000000046D64617468656C6C6F'))



# Generated at 2022-06-22 07:20:23.583813
# Unit test for function write_piff_header
def test_write_piff_header():
    import unittest2
    from ..compat import compat_HTTPError
    from ..utils import (
        encode_data_uri,
        parse_duration,
    )


# Generated at 2022-06-22 07:20:29.243204
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ret_val = True

# Generated at 2022-06-22 07:20:29.945599
# Unit test for function full_box
def test_full_box():
  assert full_box('avc1','version','flags','payload')


# Generated at 2022-06-22 07:21:41.557840
# Unit test for function box
def test_box():
    assert box(b'moov', b'\x01\x02\x03\x04') == b'\x00\x00\x00\x0Emoov\x01\x02\x03\x04'


# Generated at 2022-06-22 07:21:48.006815
# Unit test for function write_piff_header
def test_write_piff_header():
    io = io.BytesIO()
    write_piff_header(io, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10,
        'nal_unit_length_field': 4,
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe10018676400186980f9d0be8001868e2a69f1e002a0a86f3e8f',
    })

# Generated at 2022-06-22 07:21:49.883963
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("testing IsmFD.test_IsmFD_real_download")
    pass # TODO: Implement test



# Generated at 2022-06-22 07:21:52.946111
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Constructor testing
    """
    IsmFD({'url': 'http://test.com'})

# Generated at 2022-06-22 07:21:53.573843
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:22:02.439631
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import FileDownloader
    from .utils import make_HTTPS_handler


# Generated at 2022-06-22 07:22:04.401790
# Unit test for function box
def test_box():
    assert box(b'\x01'*4, b'\x02'*10) == b'\x00\x00\x00\x18' + b'\x01'*4 + b'\x02'*10



# Generated at 2022-06-22 07:22:14.938806
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(26) + b'moov'
    data += u32.pack(23) + b'trak'
    data += u32.pack(20) + b'tkhd'
    data += u32.pack(4) + u32.pack(0x41)
    assert extract_box_data(data, (b'tkhd',)) == u32.pack(0x41)
    data = u32.pack(26) + b'moov'
    data += u32.pack(23) + b'trak'
    data += u32.pack(16) + b'edts'
    data += u32.pack(12) + b'elst'
    data += u32.pack(4) + u32.pack(0x42)

# Generated at 2022-06-22 07:22:17.855475
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test import test_IsmFD
    test_IsmFD.test_real_download(IsmFD)



# Generated at 2022-06-22 07:22:21.054017
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD('http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8')

if __name__ == '__main__':
    test_IsmFD()