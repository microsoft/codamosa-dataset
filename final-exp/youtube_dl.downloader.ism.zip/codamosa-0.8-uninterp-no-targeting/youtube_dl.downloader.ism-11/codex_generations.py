

# Generated at 2022-06-22 07:14:00.641564
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # First I need to create a file with the needed data
    from .smoothstreams import video_data, video_data_summary

    # Then I create the proper info_dict
    from .smoothstreams import _get_token_data_dict
    info_dict = _get_token_data_dict(video_data)
    vid_obj = info_dict['_type']

# Generated at 2022-06-22 07:14:05.274505
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'ftyp', b'moov', b'mvex', b'mehd')
    data = '0000000d6674797069736d6c020000006d6f6f760000000000000010'
    data = binascii.a2b_hex(data)
    box_data = extract_box_data(data, box_sequence)
    assert box_data == '0000000000000000'
test_extract_box_data()



# Generated at 2022-06-22 07:14:15.905120
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # we need to construct a dictionary to pass to the test class
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1500000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'is_audio': True,
    }

    # create a file-like object for write
    fp = io.BytesIO()

    # write the piff header to the file-like object
    write_piff_header(fp, params)

    # we need to rewind the file pointer so it can be read
    fp.seek(0)

    # file name is not needed because we are reading from a file object
    # but we need to construct one
    fn = 'test.ism'

   

# Generated at 2022-06-22 07:14:22.259391
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'
    assert box(b'moov', b'\x01\x00\x00\x00') == b'\x00\x00\x00\x10moov\x01\x00\x00\x00'
# End of unit test for function box



# Generated at 2022-06-22 07:14:34.260360
# Unit test for function write_piff_header
def test_write_piff_header():
    f_out = io.BytesIO()

# Generated at 2022-06-22 07:14:40.952079
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD

if __name__ == '__main__':
    test = IsmFD()
    test.download(url = 'http://video.ch9.ms/ch9/844c/f13d94b0-03b9-4030-8c2e-f2b86d88a44c/high_bandwidth_Web.ism/high_bandwidth_Web.m4s', filename = 'example.mp4')

# Generated at 2022-06-22 07:14:52.744755
# Unit test for function extract_box_data
def test_extract_box_data():
    # test for non-leaf boxes
    test_data = b'\x00\x00\x00\x24ftyp\x00\x00\x00\x00mp42isom\x00\x00\x02\xf0free\x00\x00\x00\x00test'
    assert extract_box_data(test_data, (b'ftyp', b'mp42')) == b'\x00\x00\x00\x00'
    assert extract_box_data(test_data, (b'ftyp', b'isom')) == b'\x00\x00\x02\xf0'
    # test for leaf boxes
    assert extract_box_data(test_data, (b'free', b'')) == b'test'

# Generated at 2022-06-22 07:15:05.517288
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00'
    assert full_box(b'moov', 0, 1, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x01'
    assert full_box(b'moov', 0, 0xffffffff, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\xff\xff'

# Generated at 2022-06-22 07:15:13.217164
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        # Audio
        params = {
            'track_id': 0,
            'language': 'eng',
            'fourcc': 'AACL',
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
            'duration': 1890000,
        }
        write_piff_header(stream, params)
        payload = stream.getvalue()
        assert payload.startswith(b'ftyp')
        assert payload.find(b'ftyp') < payload.find(b'moov') < payload.find(b'mdat')

        # Video

# Generated at 2022-06-22 07:15:25.009387
# Unit test for function write_piff_header
def test_write_piff_header():
    with open('moov.piff', 'wb') as f:
        write_piff_header(f, {
            'track_id': 1,
            'fourcc': 'AVC1',
            'duration': 0,
            'width': 1280,
            'height': 720,
            'codec_private_data': '000000016764001f0033ac3a0e95845080001805000000301082f401c000000b401000001056034800010000010000000168e93384001200000d00da9058a104800',
        })


# Generated at 2022-06-22 07:22:51.475025
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest = {'fragments': [
        {'url': 'domain1.com/frag1', 'duration': 10},
        {'url': 'domain1.com/frag2', 'duration': 15}
    ]}
    info_dict = {'fragments': [
        {'url': 'domain1.com/frag1', 'duration': 10},
        {'url': 'domain1.com/frag2', 'duration': 15}
    ]}
    info_dict['_download_params'] = {'track_id': 5, 'fourcc': 'avcl', 'duration': 25, 'timescale': 1000, 'width': 500, 'height': 500, 'codec_private_data': '01234'}
    downloader = IsmFD()

# Generated at 2022-06-22 07:22:56.296885
# Unit test for function full_box
def test_full_box():
    return full_box('ftyp'.encode('ascii'), 0, 0, 'mp42'.encode('ascii'))



# Generated at 2022-06-22 07:23:04.793802
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Tests for the constructor of class IsmFD
    """
    class IsmFD(IsmFD):
        def __init__(self, downloader=None, params=None):
            IsmFD.__init__(self, downloader, params)
            test_fd = self
            while test_fd.fd is None:
                time.sleep(0.01)
            self.fd = test_fd.fd

    downloader = object()
    params = {'fileformat':'ism'}
    fd = IsmFD(downloader, params)
    assert fd.downloader is downloader
    assert fd.params == params
    assert fd.report_error == downloader.report_error
    assert fd.to_screen == downloader.to_screen

# Generated at 2022-06-22 07:23:14.734648
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08\x6D\x6F\x6F\x76'
    assert box(b'mvhd', b'') == b'\x00\x00\x00\x12\x6D\x76\x68\x64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00'

# Generated at 2022-06-22 07:23:26.325606
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # You can use the testing code below to test your implementation of real_download.
    from ydl.downloader.f4m import F4MFD
    params = {
        'url': 'http://www.sample-videos.com/video/f4m/20140408104040863/manifest.f4m',
        'model': 'ism',
        'test': True
    }
    # You may need to change the above "url" value to test different videos.
    fd = F4MFD(params)
    info_dict = fd._real_extract()
    info_dict['_download_params']['duration'] = info_dict['fragments'][0]['duration']

# Generated at 2022-06-22 07:23:34.514436
# Unit test for function box
def test_box():
    assert box('ftyp', 'isml') == b'\x00\x00\x00\x08ftypisml'
    assert box('moov', '\x00\x00\x00\x08' + 'free' + '\x00\x00\x00\x00') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x08free\x00\x00\x00\x00'
