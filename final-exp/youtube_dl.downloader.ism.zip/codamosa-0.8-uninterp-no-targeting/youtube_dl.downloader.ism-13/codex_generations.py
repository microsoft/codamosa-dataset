

# Generated at 2022-06-22 07:14:00.597761
# Unit test for function write_piff_header
def test_write_piff_header():
    s = io.BytesIO()

# Generated at 2022-06-22 07:14:04.212164
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Unit tests for IsmFD
    # import sys
    # sys.modules.pop('_IsmFD')
    from youtube_dl.extractor import ishows
    # Basic test
    ishows.IsmFD('/tmp.ism', {})


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:14:14.264997
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:25.108691
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = dict()
    info_dict['url'] = 'https://anvato-a.akamaihd.net/eventasx/EN/2016/11/13/lax/20161113lax_0.ism/Manifest'

# Generated at 2022-06-22 07:14:29.707173
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    fd = IsmFD()
    fd.real_download(filename, info_dict)
    assert os.path.isfile(filename)
    os.remove(filename)
    assert filename not in os.listdir()
    
    
# Definition of class IsmstreamFD

# Generated at 2022-06-22 07:14:33.410157
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {'name': 'ism', 'url': None, 'output': None, 'test': True}
    try:
        IsmFD(params)
    except:
        print("Unexpected error")

test_IsmFD()

# Generated at 2022-06-22 07:14:42.378826
# Unit test for function extract_box_data
def test_extract_box_data():
    if not hasattr(test_extract_box_data, "n_tests"):
        test_extract_box_data.n_tests = 0
    test_extract_box_data.n_tests += 1

    def check_it(data, box_sequence, expected):
        actual = extract_box_data(data, box_sequence)
        if actual != expected:
            print('Test failed: %r %r %r %r' % (data, box_sequence, actual, expected))
            return 1
        return 0

    failures = 0
    failures += check_it(b'\x00\x00\x00\x00', [], None)
    failures += check_it(b'\x00\x00\x00\x10\x00\x00\x00\x00', [], None)


# Generated at 2022-06-22 07:14:44.318661
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_fd = IsmFD(None)
    assert test_fd.FD_NAME == 'ism'


# Generated at 2022-06-22 07:14:55.502180
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing IsmFD.real_download')
    dest_stream = io.BytesIO()
    if True:
        params_dict = {'url': 'http://example.com/manifest',
                       'fragment_base_url': 'http://example.com/segment'}
    else:
        params_dict = {}
    with open('../media/ism/prog_index.m3u8') as manifest_file:
        manifest = manifest_file.read()

# Generated at 2022-06-22 07:15:07.476056
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import common
    from .extractor import common
    from .downloader.external import external_downloader

    common.params = {}
    common.params[u'noplaylist'] = True

# Generated at 2022-06-22 07:15:32.439372
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'duration': 7000000000,
        'fourcc': 'H264',
        'nal_unit_length_field': 4,
        'codec_private_data': '0164001fffe10017674d402020000000168ea203fc0c00000300010000030000030000030000030000030000102031e023c0c00002080208010722ea0808880013880137f000f0b96eb0f8c8e5280',
        'height': 720,
        'width': 1280,
    }

    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:15:38.008820
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'track_id': 1,
        'duration': 11101802067,
        'timescale': 10000000
    }
    output = io.BytesIO()
    write_piff_header(output, params)


if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-22 07:15:50.226403
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:15:55.510871
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import get_info_extractor
    for name, ie in get_info_extractor(None).iteritems():
        if name != 'ism':
            continue

# Generated at 2022-06-22 07:16:02.015312
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00'
    assert extract_box_data(data, (b'',)) == b''
    data += b'moov'
    data += b'\x00\x00\x00\x00'
    data += b'mvhd'
    data += b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(data, (b'mvhd',)) == b''
    data += b'mvhd'
    data += b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(data, (b'mvhd',)) == b''

# Generated at 2022-06-22 07:16:04.725633
# Unit test for function box
def test_box():
    assert (b'\x00\x00\x00\x0e'b'free'b'\x00\x00\x00\x04'b'abcd') == box(b'free', b'abcd')



# Generated at 2022-06-22 07:16:06.635313
# Unit test for function write_piff_header
def test_write_piff_header():
    from .piff_test import get_test_params
    params = get_test_params()
    with io.BytesIO() as stream:
        write_piff_header(stream, params)
        print(stream.getvalue().encode('hex'))

# Generated at 2022-06-22 07:16:15.932542
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Input parameters for method real_download of class IsmFD
    filename = 'ism-test.ism'

# Generated at 2022-06-22 07:16:21.463039
# Unit test for function full_box
def test_full_box():
    assert (full_box(
        b'moov',
        1,
        0x29,
        b'\x00\x00\x00\x00') == b'\x00\x00\x00\x00moov\x00\x01\x29\x00\x00\x00\x00')



# Generated at 2022-06-22 07:16:25.376349
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    This function tests the constructor of class IsmFD
    """
    t_i_d = IsmFD('http://web.microsoftstream.com/video/1/1/1', None)
    assert t_i_d.FD_NAME == 'ism'