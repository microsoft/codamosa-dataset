

# Generated at 2022-06-22 07:14:00.723044
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for method real_download of class IsmFD
    """
    import os
    import youtube_dl
    import time
    import shutil
    import tempfile
    from __main__ import run_ydl
    from __main__ import extract_info
    from __main__ import params
    from .test_main import make_ydl
    from .test_main import make_url_result
    from .test_main import make_info_dict
    from .test_main import make_temp_file
    from .test_main import make_temp_dir
    from .test_main import make_fragments_info_dict
    from .test_main import make_chunk_fragments_info_dict
    from .test_main import add_params

    # Unit test for real_download method
    # Set some

# Generated at 2022-06-22 07:14:08.904531
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test 1, correct manifest
    manifest_url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest"


# Generated at 2022-06-22 07:14:20.265374
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    params = {'track_id': 1, 'fourcc':'H264', 'duration': 251658240 , 'language': 'und',
              'height': 1080, 'width': 1920, 'bits_per_sample': 16,
              'channels': 2,  'sampling_rate': 44100,
              'codec_private_data': '0164001f6e23f6cd07efa8f4265d4b4f964a90b4d8c1112bdcf08a7'}
    stream = BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:14:32.257631
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 111,
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:14:41.733432
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {'track_id': 1, 'fourcc': 'H264', 'duration': 10000, 'codec_private_data': '01640033acb40281ffe1001467640033ac8c0282c4410010668e74001428de680c0dc0', 'sampling_rate': 44100, 'nal_unit_length_field': 4, 'height': 480, 'width': 852})
        assert stream.tell() == 0x1b48

# Generated at 2022-06-22 07:14:53.424290
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'duration': 789000,
        'language': 'eng',
    })
    test_stream = io.BytesIO()
    fd.write_piff_header(test_stream, {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'duration': 789000,
        'language': 'eng',
    })

# Generated at 2022-06-22 07:14:54.171107
# Unit test for function write_piff_header
def test_write_piff_header():
    pass



# Generated at 2022-06-22 07:15:06.772268
# Unit test for function write_piff_header
def test_write_piff_header():
    io_stream = io.BytesIO()
    params = dict(track_id=1, fourcc='AACL', duration=166000000, sampling_rate=48000, channels=2, bits_per_sample=16)
    write_piff_header(io_stream, params)
    stream_result = io_stream.getvalue().decode()

# Generated at 2022-06-22 07:15:12.027070
# Unit test for function box
def test_box():
    assert(box('abcd', '1') == '\x08\x00\x00\x00abcd1')
    assert(box('abcd', b'1') == b'\x08\x00\x00\x00abcd1')



# Generated at 2022-06-22 07:15:20.060424
# Unit test for function full_box
def test_full_box():
    # flags = 0x3, payload = '0x123456'
    ref_box = b'\x00\x00\x00\x0f\x66\x74\x79\x70\x33\x67\x70\x34\x00\x00\x00\x03\x12\x34\x56'
    assert full_box(b'ftyp', 0x3, 0x3, b'\x12\x34\x56') == ref_box



# Generated at 2022-06-22 07:15:36.135306
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ismManifest = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    yt_dl = youtube_dl.YoutubeDL(params={
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'format': 'ism',
        'noplaylist': True
    })
    ismFD = IsmFD(yt_dl, ismManifest)
    info_dict = {}
    print(ismFD.real_download('output.mp4', info_dict))

# Generated at 2022-06-22 07:15:38.453745
# Unit test for function box
def test_box():
    assert(box('abcd', '1') == b'\x00\x00\x00\x09abcd1')



# Generated at 2022-06-22 07:15:41.526274
# Unit test for function box
def test_box():
    assert box(b'abcd', b'efgh') == binascii.unhexlify('00000008' '61626364' '65666768')



# Generated at 2022-06-22 07:15:44.413274
# Unit test for function box
def test_box():
    expected = binascii.unhexlify('00000010asdf')
    if box('asdf', '') == expected:
        return True
    return False



# Generated at 2022-06-22 07:15:56.572936
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    IsmFD_class = IsmFD(None)
    IsmFD_class.report_error = mock_print
    IsmFD_class.report_skip_fragment = mock_print
    IsmFD_class.report_retry_fragment = mock_print
    IsmFD_class._append_fragment = mock_print
    IsmFD_class._download_fragment = mock_print
    IsmFD_class._prepare_and_start_frag_download = mock_print
    IsmFD_class._finish_frag_download = mock_print

# Generated at 2022-06-22 07:15:58.778229
# Unit test for function box
def test_box():
    box_type = "abcd"
    payload = "AAAA"
    assert (box(box_type, payload) ==
            b'\x00\x00\x00\n' + box_type + payload)



# Generated at 2022-06-22 07:16:02.240566
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x19moov\x00\x00\x00\x10mvhd\x00\x00\x00\x04abcd', [b'moov', b'mvhd'])
    assert (box_data == b'abcd')
#print(test_extract_box_data())



# Generated at 2022-06-22 07:16:07.464312
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:16:16.466376
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL, ISM_DICT
    from .test_downloader import MockHttpServerTestCase, FILE_DUMP_FD_NAME
    import os

    class TestISMD(MockHttpServerTestCase):
        def __init__(self, *args, **kwargs):
            super(TestISMD, self).__init__(*args, **kwargs)
            self.data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'downloaderdata')

# Generated at 2022-06-22 07:16:27.927011
# Unit test for function box
def test_box():
    assert box(b'abc', b'def') == b'\x00\x00\x00\x0babcdef'
    assert box(b'abc', b'12345678') == b'\x00\x00\x00\x0fabc12345678'
    assert box(b'abc', b'123456789') == b'\x00\x00\x00\x11abc123456789'
    assert box(b'abc', b'123456789a') == b'\x00\x00\x00\x12abc123456789a'


# Generated at 2022-06-22 07:16:39.627541
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:16:44.550353
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info_dict = {
        'fragments': [
            {
                'url': 'https://some_url',
            }
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'sampling_rate': 44100,
            'duration': 44098,
            'channels': 2,
            'bits_per_sample': 16
        },
        'fragment_base_url': 'https://some_url'
    }
    ism_fd = IsmFD()
    fake_dest_stream = io.BytesIO()
    ism_fd.params.update({
        'fragment_retries': 10,
        'skip_unavailable_fragments': True
    })
    self_real_download = ism_

# Generated at 2022-06-22 07:16:50.250098
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:16:52.028780
# Unit test for function box
def test_box():
    assert(box(b'a',b'hello') == b'\x00\x00\x00\x08ahello')


# Generated at 2022-06-22 07:16:56.590275
# Unit test for function full_box
def test_full_box():
    assert full_box('\x00\x00\x00\x00',0,0,'\x00\x00\x00\x00') == '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 07:17:04.513199
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://www.dailymotion.com/cdn/manifest/video/x2e9m0a.ism/version=5/format=json/'
    # First argument is retrieved from real_download(filename, info_dict)
    filename = 'test_IsmFD_real_download.ism'
    # Second argument is retrieved from real_download(filename, info_dict)
    info_dict = json.loads(urllib.request.urlopen(url).read().decode('utf-8'))
    # Change the info_dict to test possibilities of real_download

# Generated at 2022-06-22 07:17:05.565162
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD()
# ###################



# Generated at 2022-06-22 07:17:16.415958
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # test_urls = ['http://origin-pdl.channel.or.jp/2/mxs/m/movie/jstm_hd.ism/manifest',
    #              'http://origin-pdl.channel.or.jp/2/mxs/m/movie/jstm_hd.ism/manifest_mp4']
    test_urls = ['http://origin-pdl.channel.or.jp/2/mxs/m/movie/jstm_hd.ism/Manifest',
                 'http://origin-pdl.channel.or.jp/2/mxs/m/movie/jstm_hd.ism/Manifest_mp4']
    for test_url in test_urls:
        pprint.pprint(IsmFD(test_url))


# Generated at 2022-06-22 07:17:18.078798
# Unit test for function box
def test_box():
    expected = binascii.unhexlify('00000010ftypisom')
    assert box('ftyp', 'isom') == expected


# Generated at 2022-06-22 07:17:28.540887
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import FileDownloader
    from .common import InfoExtractor
    from .compat import compat_urllib_error
    def _download_webpage(*args, **kargs):
        return 'webpage'

# Generated at 2022-06-22 07:17:59.039872
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import create_test_stream
    stream = create_test_stream(
        lambda s: write_piff_header(s, {'track_id': 1, 'fourcc': 'H264', 'codec_private_data': '01640029ffdec3003484eb8e20', 'duration': 50000}))
    stream.seek(4)
    assert stream.read(4) == b'ftyp'
    assert stream.read(4) == b'moov'
    moov_size = u32.unpack(stream.read(4))[0]
    stream.seek(moov_size, io.SEEK_CUR)
    assert stream.read(4) == b'free'
    assert stream.read(4) == b'uuid'



# Generated at 2022-06-22 07:18:10.482689
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:15.439065
# Unit test for function full_box
def test_full_box():
    assert full_box('box_type', 0, 0, 'payload') == '\x00\x00\x00\x14'\
        'box_type\x00\x00\x00\x00'\
        'payload'



# Generated at 2022-06-22 07:18:23.900591
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 333666666,
        'timescale': 10000000,
        'is_fragmented': True,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
        'height': 1080,
        'width': 1920,
        'language': 'eng',
        'nal_unit_length_field': 4,
        'codec_private_data': '01640028ffe10017847640028ac32c840',
    }
    write_piff_header(fd, params)
    header = binascii.hexlify(fd.getvalue())

# Generated at 2022-06-22 07:18:28.297627
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
    assert box(b'ftyp', b'qt  ') == b'\x00\x00\x00\x0cftypqt  '
# End of test for function box


# Generated at 2022-06-22 07:18:33.763824
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = binascii.unhexlify('000000006D7668640000000A00000000000000000A00000000')
    box_sequence = (b'mvhd', )
    assert extract_box_data(box_data, box_sequence) == binascii.unhexlify('0000000A00000000000000000A00000000')



# Generated at 2022-06-22 07:18:45.709302
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """ Test IsmFD's real_download function """
    # Since tests are run in a separate process we need to
    # be able to find youtube_dl as a module
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    # Mock out PhantomJS
    class MockPhantomJS(object):
        def __init__(self, *args, **kwargs):
            return

        def run(self, *args, **kwargs):
            with open('test/testfile.ism', 'rb') as in_file:
                data = in_file.read()
            return data

    # Mock out YoutubeDL
    class MockYoutubeDL(object):
        def __init__(self, *args, **kwargs):
            return


# Generated at 2022-06-22 07:18:56.564441
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # In order to test the function real_download() implemented in this file,
    # we must first download some sample video
    # The downloaded video should be either PL01 or PL02
    master_url = 'http://pl.clipwatching.com/manifest.php'
    # master_url = 'https://fr.clipwatching.video/manifest.php'
    # master_url = 'https://ru.clipwatching.video/manifest.php'
    from .dash import DashSegmentsFD

    # Get the DASH manifest corresponding to the URL above
    # Then we will find the URL for the ISM manifest in that DASH manifest
    dl_dash = Downloader(params={})
    dash_manifest = dl_dash.urlopen(master_url)
    # dash_manifest is a string representing the DASH manifest

    # Par

# Generated at 2022-06-22 07:19:07.255205
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://download.microsoft.com/download/0/F/0/0F0ED21D-78F7-4838-9FDE-C8BC30A85C91/20121204_1157_cnn_alpacas_768k.ism/manifest(format=mpd-time-csf)'
    result = IsmFD(url).real_download('out.ism', {'fragments': [{'url': 'http://download.microsoft.com/download/0/F/0/0F0ED21D-78F7-4838-9FDE-C8BC30A85C91/20121204_1157_cnn_alpacas_768k.ism/QualityLevels(220000)/Fragments(video=0)'}]})
    print(result)


# Generated at 2022-06-22 07:19:13.410368
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    context = {"test":"test"}
    yt_url = "blabla"
    yt_config = {"info": "info"}
    fd = IsmFD()
    fd.params = {"fragment_retries": 0, "skip_unavailable_fragments": True}
    with pytest.raises(KeyError):
        fd.real_download(context, yt_url, yt_config)

# Generated at 2022-06-22 07:20:14.718975
# Unit test for function box
def test_box():
    assert box('abcd', b'hello world') == b'\x00\x00\x00\x10abcdhello world'


# Generated at 2022-06-22 07:20:17.001736
# Unit test for function box
def test_box():
    assert box(b'moov', b'1234') == (b'\x00\x00\x00\x0cmoov1234')


# Generated at 2022-06-22 07:20:22.432021
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print('Testing method real_download of class IsmFD')
    # Prepare necessary variables
    test_IsmFD_filename = 'test_IsmFD_filename'
    test_IsmFD_info_dict = 'test_IsmFD_info_dict'
    # Execute test method and check receive variables
    test_IsmFD_result = test_IsmFD.real_download(
        filename=test_IsmFD_filename,
        info_dict=test_IsmFD_info_dict
    )


# Generated at 2022-06-22 07:20:23.395986
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # pylint: disable=line-too-long
    # TODO
    pass

# Generated at 2022-06-22 07:20:32.649668
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class FakeInfoDict:
        def __init__(self, fragments):
            self._download_params = {
                'codec_private_data': '01000000ffe100186764001eacd9c56e5588c2a1048f8c88834838d84800001001780180080010000001000000010016040c008000b000c2401dc3d811a2c7ed14000001000000000000000100000000000000000000000000b8c2ffc',
                'fourcc': 'H264',
                'duration': 126308,
                'track_id': 1,
                'sampling_rate': 48000,
                'channels': 2
            }
            self.fragments = fragments

    class FakeYDL:
        def to_screen(self, message):
            print(message)


# Generated at 2022-06-22 07:20:43.601370
# Unit test for constructor of class IsmFD

# Generated at 2022-06-22 07:20:54.860669
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:21:01.644724
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000000000,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:21:04.742470
# Unit test for function box
def test_box():
    assert(box('mvhd', bytes()) == b'\x00\x00\x00\x0c' b'mvhd' + bytes())
# end unit test


# Generated at 2022-06-22 07:21:15.205506
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Set context for the unittest experiments
    ctx = {}
    ctx['total_frags'] = 5
    #Set the temp file that will be created at the beggining of the real_download method and will be deleted at the end
    with tempfile.NamedTemporaryFile(delete=False) as ctx['temp_file']:
        ctx['dest_stream'] = open(ctx['temp_file'].name, 'wb')
        info_dict = {}
        # Set the _download_params dictionary with the parameters of the method write_piff_header()