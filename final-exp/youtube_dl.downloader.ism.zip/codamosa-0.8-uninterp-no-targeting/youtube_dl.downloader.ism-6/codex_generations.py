

# Generated at 2022-06-22 07:13:54.865844
# Unit test for constructor of class IsmFD
def test_IsmFD():
    key=urllib.urlopen("https://s.players.brightcove.net/4221396001/4221396001_4826431883001_4826430420001.key").read()
    init_url="https://players.brightcove.net/4221396001/4221396001_4826431883001_4826430420001-init.m4s"
    url="https://players.brightcove.net/4221396001/4221396001_4826431883001_4826430420001-frag%d.m4s"
    init_frag_content=urllib.urlopen(init_url).read()
    init_frag_data=extract_box_data(init_frag_content,[b'moof',b'traf',b'tfhd'])

# Generated at 2022-06-22 07:13:57.542644
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = IsmFD()
    downloader.real_download(filename='filename', info_dict={})
test_IsmFD_real_download()


# Generated at 2022-06-22 07:14:02.262610
# Unit test for function box
def test_box():
    assert '\x00\x00\x00\n\x91\x00\x00\x00\x00\x01\x02\x03' == box(b'\x91\x00\x00\x00', b'\x00\x01\x02\x03')

# Video sample description

# Generated at 2022-06-22 07:14:08.786104
# Unit test for function full_box
def test_full_box():
    box_type = b'b\xaat'
    version = b'\x01'
    flags = b'\xff\xf6\x3f'
    payload = b'payload'
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x10b\xaat\x01\xff\xf6\x3fpayload'

FULL_BOX_DATA = full_box(b'd\xaat\xa9', b'\x01', b'\x00\x00\x00', b'')


# Generated at 2022-06-22 07:14:12.568276
# Unit test for function box
def test_box():
    box_type = b"free"
    payload = b"testing"
    assert box(box_type, payload) == b'\x00\x00\x00\nfreetesting'


# Generated at 2022-06-22 07:14:14.006428
# Unit test for function box
def test_box():
    assert len(box('moov', '')) == 8


# Generated at 2022-06-22 07:14:25.343832
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import parse_segment_template
    from .common import http_head, encode_data_uri
    from .extractor import gen_extractors

    url = 'ism://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/manifest'
    content = http_head(url)
    manifest = content['location']

    # Manaully construct manifest_url and manifest_type.
    manifest_url, _ = encode_data_uri(manifest, 'utf-8', {
        'format': 'utf-8'
    })
    manifest_type = None

    # Manaully construct extractor.
    extractors = gen_extractors(url, manifest_url, manifest_type)

    # Manaully construct info_dict.

# Generated at 2022-06-22 07:14:33.734513
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = Downloader({'progress_hooks': []})

# Generated at 2022-06-22 07:14:45.091716
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    class TestExtractBoxData(unittest.TestCase):
        def do_test(self, data, box_sequence, expected_value):
            self.assertEquals(extract_box_data(data, box_sequence), expected_value)
        def test_extract_box_data(self):
            self.do_test(b'\x00\x00\x00\x10test\x00\x00\x00\x10data1\x00\x00\x00\x10data2', ('test',), b'data1\x00\x00\x00\x10data2')
    unittest.main()

# Generated at 2022-06-22 07:14:48.614024
# Unit test for function full_box
def test_full_box():
    assert (full_box(b'moov', 0, 0, b'')) == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-22 07:15:07.858917
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import get_info_extractor
    from .common import parse_iso8601
    from .utils import HEADRequest

    ie = get_info_extractor('ism')

    youtube_url = 'http://www.youtube.com/watch?v=mQ0D8-eRO_o'
    req = HEADRequest(youtube_url)
    video_id = 'mQ0D8-eRO_o'

# Generated at 2022-06-22 07:15:11.782468
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == '\x00\x00\x00\n\x61\x62\x63\x641234'
# end unit test for box


# Generated at 2022-06-22 07:15:23.646703
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:15:28.614555
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'
    assert fd._prepare_and_start_frag_download is not None
    assert fd._finish_frag_download is not None
    assert fd._download_fragment is not None


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:15:31.743311
# Unit test for function box
def test_box():
    assert box(b'mvhd', u32.pack(1)) == b'\x00\x00\x00\x0c\x6d\x76\x68\x64\x00\x00\x00\x01'


# Generated at 2022-06-22 07:15:41.760796
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader.common import FileDownloader

    # Construct a IsmFD
    test_params = {
        'usenetrc': False,
        'username': 'testuser',
        'password': 'testpass',
        'video_password': 'videopass',
    }

# Generated at 2022-06-22 07:15:47.929741
# Unit test for function full_box
def test_full_box():
    box_type = 'mdat'
    version = 1
    flags = 0
    payload = b'moo'
    if full_box(box_type, version, flags, payload) == u32.pack(12) + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload:
        return True
    else:
        return False


# Generated at 2022-06-22 07:15:49.950757
# Unit test for function full_box
def test_full_box():
    print(full_box('mvhd' , 0,0,unity_matrix))

# Generated at 2022-06-22 07:15:56.521534
# Unit test for function full_box
def test_full_box():
    ex_box_type = b"abcd"
    ex_version = 1
    ex_flags = 2
    ex_payload = b"1234"
    assert(full_box(ex_box_type, ex_version, ex_flags, ex_payload) == b"\x00\x00\x00\x0dabcd\x01\x00\x00\x00\x00\x001234")


# Generated at 2022-06-22 07:16:00.455831
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'duration': 10000000,
    })
    stream.seek(0)
    return stream.read()

# Note: self-contained versions of this function are in piff_encryptor.py and piff_fragmenter.py

# Generated at 2022-06-22 07:16:10.374089
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return True



# Generated at 2022-06-22 07:16:18.231108
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class FakeInfoDict:
        """
        Dummy info dict
        """

# Generated at 2022-06-22 07:16:29.591143
# Unit test for function write_piff_header
def test_write_piff_header():
    import hashlib
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 100000000,
        'timescale': 10000000,
        'language': 'und',
        'codec_private_data': '0142C01480FFC001FAD5D5DA80001000568EBECB22C',
        'nal_unit_length_field': 4,
        'width': 1280,
        'height': 720
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    assert hashlib.sha1(stream.getvalue()).hexdigest() == 'c82d8c18fa1d2fbf9e3a13f39d099a6bdc81f53d'

# Generated at 2022-06-22 07:16:36.822587
# Unit test for function box
def test_box():
    assert box('free', 'a') == b'\x00\x00\x00\x09freea'

mdat_header = b'\x00\x00\x00\x00mdat'

STSD_ENTRY_FIELDS = u32.pack(2) + u32.pack(1)  # number of entries, always use first
STSD_FIELDS = u8.pack(0) + u8.pack(0) + u8.pack(0) + u8.pack(0) + u8.pack(0) + u8.pack(0)

# Generated at 2022-06-22 07:16:46.197920
# Unit test for function full_box
def test_full_box():
    # reference: https://developer.apple.com/library/content/documentation/QuickTime/QTFF/QTFFChap2/qtff2.html#//apple_ref/doc/uid/TP40000939-CH204-BBCCHHEB
    # full box
    test_box_type = b'mdat'
    test_version = 0
    test_flags = 0
    test_payload = b'test_payload'
    test_box_bytes = full_box(test_box_type, test_version, test_flags, test_payload)
    assert test_box_bytes[0:8] == b'\x00\x00\x00\x10' + test_box_type, 'full box'


# Generated at 2022-06-22 07:16:48.044458
# Unit test for function box
def test_box():
    assert box(
        b'moov',
        b''
    ) == b'\x00\x00\x00\x08moov'


# Generated at 2022-06-22 07:16:59.701076
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import make_tempdir
    from ..utils import encode_data_uri

    def check(params):
        fd = io.BytesIO()
        write_piff_header(fd, params)
        return fd.getvalue()

    with make_tempdir() as td:
        params = {
            'fourcc': 'AVC1',
            'track_id': 0,
            'duration': 37120000,
            'height': 0,
            'width': 0,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
            'codec_private_data': '000000',
        }

# Generated at 2022-06-22 07:17:05.274213
# Unit test for function full_box
def test_full_box():
    version = 8
    box_type = b'FBOX'
    flags = 0x413
    payload = b'ABC'
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x00FBOX\x08\x00\x04\x13ABC'



# Generated at 2022-06-22 07:17:05.938273
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
	pass

# Generated at 2022-06-22 07:17:15.597086
# Unit test for function full_box
def test_full_box():
    assert(full_box(b'moov', 1, 0x12345678, b'RANDOM') == b'\x00\x00\x00\x14moov\x01\x12\x34\x56RANDOM')

TRACK_TYPES = {
    b'mp4v': b'VideoHandler',
    b'soun': b'SoundHandler',
    b'text': b'TextHandler',
    b'srt': b'TextHandler',
    b'ssa': b'TextHandler',
    b'vide': b'VideoHandler',
    b'soun': b'SoundHandler',
    b'hint': b'HintHandler',
}



# Generated at 2022-06-22 07:17:33.724107
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10,
            'width': 640,
            'height': 480,
            'codec_private_data': '0000016764001FF8C07BFFFF0001000468CE00030059C8D080'
        })
        stream.seek(0)

# Generated at 2022-06-22 07:17:40.984171
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:17:51.825893
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 0,
        'timescale': 10000000,
        'fourcc': 'AACL',
        'codec_private_data': '1210',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:18:00.138374
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x18ftyp\x00\x00\x00\x00isml' \
           b'\x00\x00\x00\x12mdat\x00\x00\x00\x00\x00\x00\x00\x00' \
           b'\x00\x00\x00\x16mdat\x00\x00\x00\x00\x00\x00\x00\x00' \
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:18:09.714234
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('Testing IsmFD..')
    fd=IsmFD()
    fd.real_download('', {
            'fragments':[{
                'duration':1.0,
                'url':'http://'},
                {'duration':2.0,
                'url':'http://'}],
            '_download_params':{'track_id':1,
                 'fourcc':'AACL',
                 'duration':5.0,
                 'timescale':10.0,
                 'language':'cmn',
                 'height':0,
                 'width':0}
            })


# Generated at 2022-06-22 07:18:21.822960
# Unit test for constructor of class IsmFD
def test_IsmFD():
    def test_IsmFD_download(url, params = None, filename = None):
        # Initialize params
        if params is None:
            params = {}
        if filename is None:
            filename = '%(id)s.%(ext)s'
        # Initialize IsmFD object
        ism = IsmFD()

# Generated at 2022-06-22 07:18:25.298952
# Unit test for function full_box
def test_full_box():
    expected = binascii.unhexlify('000000086674687900000000')
    actual = full_box(b'ftxy', 0, 0, b'')
    assert(expected == actual)



# Generated at 2022-06-22 07:18:36.482719
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl = YoutubeDL({})
    url_map = {'https://manifest.us.llnwd.net/e1/uds/destination/wildlife/discovery/2014/09/19/2507981_1280x720_1500.ism/2507981_1280x720_1500-video=934000-audio=963000-subtitle=0-captions=0-metadata=0_sd_track=0_en-US=0.mp4?download=true':
               'http://127.0.0.1:19877/get-video?download=true'}
    ydl.urlopen = lambda _: FakeHttpResponse(get_files(url_map))
    # Test file is not downloaded
    assert not os.path.exists('2507981_1280x720_1500.ism')

   

# Generated at 2022-06-22 07:18:48.733849
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create a temporary file in the system's temporary directory
    tmp_fd, tmp_file = tempfile.mkstemp()

    # Open a file in write binary mode
    os.close(tmp_fd)
    with open(tmp_file, 'wb') as file:
        
        # Download the video stream from the given URL and save it to a file
        Downloader(params).real_download(file, info_dict)

    # Rename the file
    os.replace(tmp_file, 'video.mp4')

test_IsmFD_real_download()

# Get audio stream descriptor
audio_stream = [stream for stream in info_dict['formats'] if stream['format_note'] == 'audio only'][0]

# Get the download parameters of the audio stream

# Generated at 2022-06-22 07:18:58.793860
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import glob
    import shutil

    def _test_write_piff_header(params, is_audio):
        print('Testing writing PIFF header with parameters: ' + str(params))
        stream = io.BytesIO()
        write_piff_header(stream, params)
        stream_data = stream.getvalue()
        fragment_size = len(stream_data)
        print('Stream size: %d' % (fragment_size))
        stream.seek(0)

        piff_f4f_dir = os.path.join('test', 'resources', 'media', 'f4f', 'piff')
        if os.path.exists(piff_f4f_dir):
            shutil.rmtree(piff_f4f_dir)

# Generated at 2022-06-22 07:19:26.685476
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    This method is a test for the constructor of class IsmFD
    """
    print("From test_IsmFD")
    url = "http://test.com"
    params = {}
    print("Creation of class IsmFD with url " + url + " and params " + str(params) + ". Verify that it does not error out")
    IsmFD(url, params)    
    
if __name__=="__main__":
    test_IsmFD()

# Generated at 2022-06-22 07:19:31.650583
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:19:35.505778
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234') == b'\x08\x00\x00\x00abcd1234'
    assert box(b'test', b'') == b'\x08\x00\x00\x00test'
    assert box(b'test', b'1234') == b'\x0c\x00\x00\x00test1234'


# Generated at 2022-06-22 07:19:43.000254
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (box(b'abcd', b'abcde'),
                    box(b'fghi', b'fghij'),
                    box(b'klmn', b'klmno'))
    data = b''.join(box_sequence)
    assert extract_box_data(data, (b'abcd', b'fghi')) == b''.join(box_sequence[1:])
    assert extract_box_data(data, (b'klmn',)) == b'klmno'



# Generated at 2022-06-22 07:19:46.469323
# Unit test for function extract_box_data
def test_extract_box_data():
    msg = extract_box_data('abcdabcdabcdabcdabcdabcdabcdabcd'.decode('hex'), ['piff', 'piff', 'abcd'])
    assert len(msg) == 12
    assert msg == 'abcdabcdabcd'


# Generated at 2022-06-22 07:19:49.672033
# Unit test for function box
def test_box():
    assert  b'\x00\x00\x00\x0cftypmp42' == box(b'ftyp', b'mp42')



# Generated at 2022-06-22 07:19:57.421117
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'duration': 1000,
            'timescale': 10,
            'fourcc': 'AVC1',
            'height': 1280,
            'width': 720,
            'language': 'en',
            'codec_private_data': '0164001fffe10067640028acd9402812660f8c8000001b58eb2f4b01010000000168ce0379000000001767640028acd9402812660f8c8000001b58eb2f4b01010000000568eb2f4b',
        }
        write_piff_header(stream, params)
    return stream.getvalue()



# Generated at 2022-06-22 07:20:08.558636
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DashFD
    from .common import FileDownloader
    
    # Test constructor
    IsmFD()

    # Test real_download
    class TestIsmFD(IsmFD):
        def __init__(self):
            self.real_download = lambda filename, info_dict: True

    fd = TestIsmFD()
    assert not fd._download_fragment(None, None, None)
    assert fd.real_download("filename", {"fragments": [{"url": "url"}]})

    # Test _get_fragment_retries
    fd = IsmFD()
    fd.params = {}
    assert fd._get_fragment_retries() == 0
    fd.params = {"fragment_retries": 1}
    assert fd._get

# Generated at 2022-06-22 07:20:18.464663
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    p = IsmFD()

# Generated at 2022-06-22 07:20:24.289734
# Unit test for function write_piff_header
def test_write_piff_header():
    test_params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 285514593,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd90780',
    }
    test_stream = io.BytesIO()
    write_piff_header(test_stream, test_params)

# Generated at 2022-06-22 07:21:08.798485
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD()

# Generated at 2022-06-22 07:21:14.060378
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:21:21.680227
# Unit test for function full_box

# Generated at 2022-06-22 07:21:23.558066
# Unit test for function full_box
def test_full_box():
    print(full_box('moov', 0, 0, 'test'))


# Generated at 2022-06-22 07:21:25.270448
# Unit test for function box
def test_box():
    assert box('free', b'12345678') == '\x10\x00\x00\x00free12345678'


# Generated at 2022-06-22 07:21:27.059728
# Unit test for function box
def test_box():
    assert(b"\x00\x00\x00\x0C"+b"abcd"+b"\x00") == box(b"abcd", b"\x00")


# Generated at 2022-06-22 07:21:32.756188
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264', 'codec_private_data': 'profile:v100,width:352,height:288,codec:avc1,frameRate:25.000000,level:31,sprop-parameter-sets:Z0IAH+ZAAAHuQgAA2QEAAAMBAAAeAA=', 'duration': 3.16, 'width': 352, 'height': 288}
    write_piff_header(stream, params)
    stream.seek(0)
    box_data = stream.read()
    assert len(box_data) == 0



# Generated at 2022-06-22 07:21:40.524247
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from youtube_dl.extractor.azmedien import AzMedienBaseIE
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ism = IsmFD(ydl, {'url': 'http://a.b.c/d'})
    assert ism.url == 'http://a.b.c/d'
    assert ism.track_id == 0
    assert ism.name == 'ism'
    assert ism.params == {}
    assert ism.ydl == ydl
    assert not ism.to_screen
    assert ydl.params['fragment_retries'] == 10
    ydl.params['fragment_retries'] = 0
    assert ydl.params['fragment_retries'] == 0

# Generated at 2022-06-22 07:21:45.343449
# Unit test for function extract_box_data
def test_extract_box_data():
    data = (
        b'\x00\x00\x00\x1C' + b'ftyp' +  # ftyp
        b'\x00\x00\x00\x4C' + b'moov' +  # moov
        b'\x00\x00\x00\x40' + b'trak' +  # trak
        b'\x00\x00\x00\x34' + b'mdia' +  # mdia
        b'\x00\x00\x00\x2C' + b'minf' +  # minf
        b'\x00\x00\x00\x24' + b'stbl' +  # stbl
        b'\x00\x00\x00\x1C' + b'avc1')


# Generated at 2022-06-22 07:21:49.352982
# Unit test for function box
def test_box():
    box_type=b"edts"
    payload=b"aaaaaaaa"
    result=box(box_type, payload)
    assert(result==b'\x10\x00\x00\x00edtsaaaaaaaa')

