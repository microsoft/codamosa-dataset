

# Generated at 2022-06-22 07:14:01.662868
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00' * 16 + b'moov' + b'\x00' * 12 + b'mvex' + b'\x00' * 8 + b'mehd' + b'\x00' * 8
    box_sequence = ('moov', 'mvex', 'mehd')
    if extract_box_data(data, box_sequence) != b'\x00' * 8:
        raise ValueError('Unit test for function extract_box_data failed')



# Generated at 2022-06-22 07:14:10.715806
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    from random import randint
    from time import time
    

# Generated at 2022-06-22 07:14:21.405082
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:25.574012
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 1, b'payload') == b'\x00\x00\x00\x14moov\x01\x00\x01\x00\x00payload'


# Generated at 2022-06-22 07:14:36.647774
# Unit test for function write_piff_header
def test_write_piff_header():
    file = io.BytesIO()
    params = {
        'fourcc': 'H264',
        'codec_private_data': '0000000167428029ffe1001f67428029acd94040',
        'track_id': 1,
        'duration': 5000000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'language': 'eng',
    }
    write_piff_header(file, params)
    header = file.getvalue()

# Generated at 2022-06-22 07:14:41.384196
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0
    flags = 0
    payload = b''
    assert full_box(box_type, version, flags, payload) == b'moov\x00\x00\x00\x00\x00\x00'




# Generated at 2022-06-22 07:14:53.225098
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:15:01.727402
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x08moov'
    assert box(b'moov', b'foo') == b'\x00\x00\x00\x0bmoovfoo'
    assert box(b'moov', b'\x10\x20\x30') == b'\x00\x00\x00\x0bmoov\x10\x20\x30'



# Generated at 2022-06-22 07:15:07.380391
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("test_IsmFD")

    # Create an instance of IsmFD
    ismFD = IsmFD("ism")

    # If test fails, stop program
    assert ismFD

# Unit tests for IsmFD

# Generated at 2022-06-22 07:15:20.097156
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:15:37.625657
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': int(10 / 2 * 1e7),
            'timescale': int(1e7),
            'sampling_rate': 48000,
            'channels': 2,
        })

# Generated at 2022-06-22 07:15:42.015204
# Unit test for function full_box
def test_full_box():
    assert full_box('fmt ', 0, 0, b'\x00' * 9) == box(b'fmt ', b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
# ---


# Generated at 2022-06-22 07:15:48.086906
# Unit test for function full_box
def test_full_box():
    payload = b'\x00\x00\x01\x00\x00\x00\x01\x18\x05\x00\x01\xb0\x10\x00\x01\xb2\x00\x00\x01\xb5\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x0c\x6a\x50\x20\x20\x0d\x61\x6e\x64\x72\x6f\x69\x64'
    box_type = b'mdhd'
    version = 0
    flags = 0

# Generated at 2022-06-22 07:15:51.469320
# Unit test for function full_box
def test_full_box():
    assert(full_box('ftyp', 1, 1, 'mp42') == '\x00\x00\x00\x10ftyp\x01\x00\x00\x01mp42')



# Generated at 2022-06-22 07:16:02.167215
# Unit test for function write_piff_header
def test_write_piff_header():
    from .flv import write_flv_file
    params = {
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'duration': 45000,
        'channels': 2,
        'bits_per_sample': 16
    }
    testfile = io.BytesIO()
    write_flv_file(testfile, [], params)
    write_piff_header(testfile, params)
    testfile.seek(8)
    assert u32.unpack(testfile.read(4)) == 155
    assert testfile.read(4) == b'moov'
    assert u32.unpack(testfile.read(4)) == 147
    assert testfile.read(4) == b'mvhd'

# Generated at 2022-06-22 07:16:10.059782
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'payload') == (
        b'\x00\x00\x00\x14moov\x00\x00\x00\x01\x00\x00\x00\x00payload')
    assert full_box(b'moov', 1, 0, b'payload') == (
        b'\x00\x00\x00\x14moov\x00\x00\x00\x01\x00\x00\x00\x00payload')



# Generated at 2022-06-22 07:16:17.092619
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 2507088,
        'sampling_rate': 22050,
        'channels': 2,
        'bits_per_sample': 16
    }
    with io.open(r'C:\git\Microsoft\video_encryption\mss_samples\a1.mp4', 'rb') as stream:
        stream.seek(0, 2)
        stream_size = stream.tell()
        stream.seek(0)
        write_piff_header(stream, params)
        stream.seek(0, 2)
        assert stream.tell() == stream_size


# Generated at 2022-06-22 07:16:28.533289
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:16:35.058327
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'froz', box(b'nemo', box(b'bres', b'')))
    assert extract_box_data(data, (b'nemo', b'bres')) == b''
    assert extract_box_data(data, (b'bres')) is None
    assert extract_box_data(data, (b'bres',)) is None
    assert extract_box_data(data, (b'nemo',)) == box(b'nemo', box(b'bres', b''))
    assert extract_box_data(data, (b'froz', b'nemo', b'bres')) == b''


# Generated at 2022-06-22 07:16:36.485235
# Unit test for function box
def test_box():
    assert box('free', 'asdf') == binascii.unhexlify('00000008666f7265asdf');


# Generated at 2022-06-22 07:17:00.413137
# Unit test for function extract_box_data
def test_extract_box_data():
    TEST_DATA = b'\x00' * 4 + b'box1' + b'\x00' * 4 + b'box2' + b'\x00' * 4 + b'\x00\x00\x00\x08' + b'box3' + b'\x00' * 4
    assert extract_box_data(TEST_DATA, (b'box1', b'box2')) == b'\x00\x00\x00\x08' + b'box3' + b'\x00' * 4
    assert extract_box_data(TEST_DATA, (b'box1', b'box2', b'box3')) == b'\x00' * 4

# Generated at 2022-06-22 07:17:02.051452
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert 1 == 1
    return

# Generated at 2022-06-22 07:17:05.716717
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Constructor of class IsmFD
    assert isinstance(IsmFD({
        'noprogress' : True,
        'skip_unavailable_fragments': True,
    }), IsmFD)


# Generated at 2022-06-22 07:17:16.501640
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x10mvex\x00\x00\x00\x10trex\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(test_data, ['trex']) == b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:17:17.606557
# Unit test for function box
def test_box():
    box('ftyp', 'isom')
    


# Generated at 2022-06-22 07:17:27.092239
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Use test manifest (manifest_ism.py) to test IsmFD initialization
    from .manifest_ism import manifest_url, test_subtitles
    from .subtitles import subtitles_filename
    from .manifest import Manifest  # Avoid circular import in Python < 3.5
    info_dict = {
        '_type': 'ism',
        'id': 'ism',
        'url': manifest_url,
        'subtitles': test_subtitles,
        'subtitles_filename': subtitles_filename,
    }
    downloader = IsmFD(Manifest(info_dict))
    assert downloader.params.get('url_handle')

# Generated at 2022-06-22 07:17:36.075682
# Unit test for function full_box
def test_full_box():
    assert full_box(b'avc1', 0, 0, b'abcdef') == b'\x00\x00\x00\x13avc1\x00\x00\x00\x00\x00\x00abcdef'
    assert full_box(b'avc1', 1, 0, b'abcdef') == b'\x00\x00\x00\x13avc1\x01\x00\x00\x00\x00\x00abcdef'
    assert full_box(b'avc1', 0, 1, b'abcdef') == b'\x00\x00\x00\x13avc1\x00\x01\x00\x00\x00\x00abcdef'

# Generated at 2022-06-22 07:17:40.626945
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    fragments = [{'url': 'http://proxy.example.com/file1',
                  'length': 1234}]
    info_dict = {'manifest_url': 'http://manager.example.com/manifest',
                 'fragments': fragments}
    params = {'test': True}
    fd = IsmFD('http://manager.example.com/manifest',
               params, {'outtmpl': 'file'})
    assert fd.real_download('file', info_dict) is False


# Generated at 2022-06-22 07:17:47.753741
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("test_IsmFD")
    ydl = FakeYDL()
    url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism"
    fd = IsmFD(ydl, url)
    assert fd.url == url



# Generated at 2022-06-22 07:17:49.823437
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test init class
    Test = IsmFD(None, None, None)
    # Test real_download of class
    Test.real_download(None, None)
    