

# Generated at 2022-06-22 07:13:54.754086
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test.test_fragments import get_test_fragment
    with io.BytesIO() as buf:
        write_piff_header(buf, get_test_fragment('piff-test.ismv'))
        assert buf.getvalue() == get_test_fragment('piff-test-moov.ismv')



# Generated at 2022-06-22 07:13:58.870290
# Unit test for function box
def test_box():
    assert box(b'uuid', b'1234') == b'\x00\x00\x00\x0cuuid1234'
    assert box(b'uuid', b'12345') == b'\x00\x00\x00\ruuid12345'


# Generated at 2022-06-22 07:14:07.137652
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    # Test IsmFD class
    FD_test_class = IsmFD()
    # Dummy arguments
    filename = 'test_0.ismv'
    # Create dummy manifest
    manifest = open(temp_dir + '/test.ism/Manifest', 'w')

# Generated at 2022-06-22 07:14:12.775508
# Unit test for function full_box
def test_full_box():
    assert full_box('\x66\x72\x61\x67', 1, 0, 'payload') == '\x00\x00\x00\x0e\x66\x72\x61\x67\x01\x00\x00\x00payload'


# Generated at 2022-06-22 07:14:17.043324
# Unit test for function full_box
def test_full_box():
    box_type = str('mdat')
    version = 1
    flags = 0
    payload = str('test')
    assert full_box(box_type, version, flags, payload) == '\x00\x00\x00\x09mdat\x01\x00\x00\x00test'



# Generated at 2022-06-22 07:14:23.231913
# Unit test for function full_box
def test_full_box():
    box_type = b'moov'
    version = 0x1
    flags = 0x2
    payload = b'\x00\x00\x00\x00'
    assert full_box(box_type,version,flags,payload) == b"\x00\x00\x00\x0cmoov\x00\x00\x01\x02\x00\x00\x00\x00"


# Generated at 2022-06-22 07:14:31.384560
# Unit test for function extract_box_data
def test_extract_box_data():
    moof_data = box(b'moof', full_box(b'mfhd', 0, 0, u32.pack(0)))
    mdat_data = box(b'mdat', u32.pack(0))
    ftyp_data = box(b'ftyp', u32.pack(0))
    data = ftyp_data + mdat_data + moof_data + mdat_data
    assert extract_box_data(data, (b'moof',)) == moof_data


# Generated at 2022-06-22 07:14:37.513724
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'url': 'http://smf.blob.core.windows.net/samples/1mb/dash1.mpd'})
    assert False


# Generated at 2022-06-22 07:14:39.608693
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

if __name__ == '__main__':
    test_IsmFD()

# vim: set expandtab shiftwidth=4 tabstop=4:

# Generated at 2022-06-22 07:14:49.748918
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test on a real example
    yt_url = 'https://www.youtube.com/watch?v=dTTUDBh0Hvk'
    downloader_params = {
        'fragment_retries': 2, 'skip_unavailable_fragments': True, 'playlist_items': '0-1'
    }
    downloader_options = {'verbose': True}

# Generated at 2022-06-22 07:15:08.927683
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test data
    from .extractor import IsmFD
    from .common import InfoExtractor
    from .common import FileDownloader
    from .common import expected_warnings
    from .common import compat_http_server
    from io import BytesIO
    from io import StringIO
    import os
    import sys
    import tempfile
    import time
    import unittest
    import urllib.request, urllib.parse, urllib.error
    import xml.dom.minidom
    expected_warnings.append('Matroska (WebM) file detected')
    expected_warnings.append('Using forward slashes')
    expected_warnings.append('Downloading MPD manifests as m3u8 playlists')
    expected_warnings.append('This URL is encrypted')

# Generated at 2022-06-22 07:15:09.718371
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-22 07:15:11.882223
# Unit test for function full_box
def test_full_box():
    return u32.pack(8 + len(payload)) + box_type + payload



# Generated at 2022-06-22 07:15:21.066572
# Unit test for function box
def test_box():
    assert box(b'stts', b'') == binascii.unhexlify(b'0000000073747473')

FTYP = b'ftyp'
MOOV = b'moov'
MVHD = b'mvhd'
TRAK = b'trak'
TKHD = b'tkhd'
TREF = b'tref'
EDTS = b'edts'
ELST = b'elst'
TRAF = b'traf'
TFHD = b'tfhd'
TRUN = b'trun'
MDIA = b'mdia'
MDHD = b'mdhd'
HDLR = b'hdlr'
MINF = b'minf'
VMHD = b'vmhd'
SMHD = b'smhd'
DINF = b'dinf'
DREF = b

# Generated at 2022-06-22 07:15:33.076771
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ydl.Extractor import YoutubeIE
    from ydl.downloader.http import HttpFD
    from ydl.downloader.http import SegmentInfo
    from ydl.utils import DownloadError
    from ydl.utils import sanitize_open

    class MockYoutubeIE(YoutubeIE):
        def _real_extract(self, url):
            if not url.startswith('http://'):
                raise DownloadError('invalid URL: ' + url)
            video_id = url
            title = 'video title'
            duration = 10
            ism_url = 'http://example.com/video.ism'
            return {
                'id': video_id,
                'title': title,
                'duration': duration,
                'formats': [{'url': ism_url}],
            }

# Generated at 2022-06-22 07:15:42.676284
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:15:54.911832
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x18ftypiso5\x00\x00\x00\x00mp42\x00\x00\x00\x00isomiso2mp41\x00\x00\x02!\x00\x00\x00\x14ftypisom\x00\x00\x00\x00isomiso2avc1mp41\x00\x00\x02\x21\x00\x00\x00\x14ftypisom\x00\x00\x00\x00isomiso2mp41\x00'
    box_data = extract_box_data(data, (b'moov', b'mvhd'))

# Generated at 2022-06-22 07:15:59.606254
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('test_extract_box_data.mp4', 'rb') as f:
        data = f.read()
    assert data == extract_box_data(data, (b' ', b'tst'))
    assert u32.pack(1) == extract_box_data(data, (b'tst', b'cnt'))



# Generated at 2022-06-22 07:16:01.263376
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('Testing IsmFD constructor')
    ism_fd = IsmFD()
    assert ism_fd.FD_NAME == 'ism'



# Generated at 2022-06-22 07:16:06.806934
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-22 07:16:18.560667
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == b'\x00\x00\x00\nabcd1234'
# End unit test



# Generated at 2022-06-22 07:16:29.863276
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_chr
    from itertools import chain
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 10, 'width': 640, 'height': 480, 'timescale': 100000, 'sampling_rate': 48000, 'channels': 2, 'bits_per_sample': 16, 'language': 'und', 'codec_private_data': '000000016742C00D965608801400901B03E0301F02000004C4A1AAC'}
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:16:37.033863
# Unit test for function extract_box_data
def test_extract_box_data():
    b1 = 'moov'
    b2 = 'trak'
    b3 = 'mdia'
    b4 = 'minf'
    b5 = 'stbl'
    b6 = 'stsd'
    b7 = 'mp4a'


# Generated at 2022-06-22 07:16:43.718160
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'fourcc': b'AACL',
        'duration': 480000000,
        'codec_private_data': '1210'
    }
    write_piff_header(stream, params)
    stream.seek(0)
    return stream.read()


# Generated at 2022-06-22 07:16:47.008855
# Unit test for function box
def test_box():
    assert(box(b'moov', b'\x00\x00\x00\x00') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00')


# Generated at 2022-06-22 07:16:58.777186
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'ftyp', b'isml')
    assert extract_box_data(data, [b'ftyp',]) == b'isml'
    assert extract_box_data(data, [b'moov',]) is None
    data = box(b'moov', box(b'trak', b''))
    assert extract_box_data(data, [b'moov', b'trak']) == b''
    assert extract_box_data(data, [b'moov', b'ftyp']) is None

# Generated at 2022-06-22 07:17:02.107197
# Unit test for function full_box
def test_full_box():
    payload = 'test'
    assert full_box('mvhd', version=0x00, flags=0x00, payload=payload) == '\x00\x00\x00\x20mvhd\x00\x00\x00\x00\x00test'



# Generated at 2022-06-22 07:17:06.709679
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Open a file
    fd = IsmFD(params={'filename': 'test'})
    assert fd is not None

    # Try to download a none-existing file
    fd = IsmFD(params={'filename': 'none-existing-file'})
    assert fd is None



# Generated at 2022-06-22 07:17:10.498674
# Unit test for function box
def test_box():
    assert box('abcd', '\x00\x00\x00\x00') == '\x00\x00\x00\x0cabcd\x00\x00\x00\x00'
# /Unit test for function box


# Generated at 2022-06-22 07:17:13.695056
# Unit test for function box
def test_box():
    import lib.f4mfile.box as box
    print("Testing box")
    assert box("moov", "") == b'\x00\x00\x00\x08moov'



# Generated at 2022-06-22 07:17:28.151578
# Unit test for function box
def test_box():
    assert box(b"ftyp", b"qt  ") == (b"\x00\x00\x00\x10" + b"ftyp" + b"qt  ")


# Generated at 2022-06-22 07:17:36.832844
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import time
    print('Testing real_download() of class IsmFD')

# Generated at 2022-06-22 07:17:40.069507
# Unit test for function full_box
def test_full_box():
    assert(
        full_box('f4v\x00\x00\x00', 0, 1, u32.pack(2)) ==
        b'\x00\x00\x00\x10f4v\x00\x00\x00\x00\x01\x00\x00\x00\x02'
    )



# Generated at 2022-06-22 07:17:45.238964
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismfd = IsmFD({'url': 'http://mp4.f54.v.nokia.com/orig/2012/03/12/8a73c2a7-800c-4b4d-963e-3f7b5e5a1dbd/8a73c2a7-800c-4b4d-963e-3f7b5e5a1dbd_2.mp4', 'noplaylist': False, 'test': True}, {}, None)
    ismfd._downloader = youtube_dl.YoutubeDL()
    ismfd._downloader.params = {'quiet': True, 'continuedl': False}


# Generated at 2022-06-22 07:17:50.915174
# Unit test for function box
def test_box():
    assert box(b'free', b'\x00' * 20) == b'\x00\x00\x00\x28free\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 07:17:59.033327
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 0,
        'timescale': 10000000,
        'codec_private_data': '01640028ffe10019674d401ef941000a096c1b00d1e2048002860fffa39c5814ce91000000fc401f941000a096c1b00d1e2048002860fffa39c5814ce91010000',
        'height': 720,
        'width': 1280,
        'nal_unit_length_field': 4
    }

# Generated at 2022-06-22 07:18:02.454292
# Unit test for function full_box
def test_full_box():
    assert full_box(b'abcd', 0, 0, b'') == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x00'



# Generated at 2022-06-22 07:18:14.306524
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AVC1',
            'duration': 0x11e60,
            'timescale': 0xb240,
            'language': 'und',
            'height': 1440,
            'width': 1920,
            'codec_private_data': '0164001fffe1001b67640029acd9d07b01000428ee1c02c3808c1c3818c08d78008014000a8b8e5f58040000000fc000422c069001e9c8b4c10ec03d',
            'nal_unit_length_field': 4,
        }
        write_piff_header(stream, params)

# Generated at 2022-06-22 07:18:26.096425
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    class Options(object):
        """
        Options for IsmFD
        """

        def __init__(self, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)

    class YoutubeDL(object):
        """
        Mocking YoutubeDL class
        """

        def __init__(self, params):
            self.params = params

    # Create IsmFD instance

# Generated at 2022-06-22 07:18:36.882403
# Unit test for function write_piff_header
def test_write_piff_header():
# Sample video file is the video created by the following command
# ffmpeg -i sample_video_1280x720_5mb.mp4 -vcodec copy -an sample_video_1280x720_5mb.h264

    with io.open('sample_video_1280x720_5mb.h264', 'rb') as f:
        codec_private_data = binascii.hexlify(f.read(5)).decode('ascii')

    # Create stream and write PIFF header
    f = io.BytesIO()

# Generated at 2022-06-22 07:19:04.062090
# Unit test for function extract_box_data
def test_extract_box_data():
    moof_data = open('C:/Users/Sergey/PycharmProjects/untitled/venv/Lib/site-packages/cookies/moof.bin', 'rb').read()
    tfdt_data = extract_box_data(moof_data, (b'moof', b'trak', b'mdia', b'minf', b'stbl', b'tfhd', b'tfdt'))
    moof_time = u64.unpack(tfdt_data[4:])[0]
    print(moof_time)
    print(time.time())



# Generated at 2022-06-22 07:19:07.794547
# Unit test for function full_box
def test_full_box():
    payload = u8.pack(0x7) + u32.pack(0x3)[1:] + b'payload'
    assert full_box(b'abcd', 0x7, 0x3, payload) == box(b'abcd', payload)



# Generated at 2022-06-22 07:19:11.152642
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'foobar', box(b'hello', box(b'world', b'42')))
    assert extract_box_data(data, (b'foobar', b'hello', b'world')) == b'42'



# Generated at 2022-06-22 07:19:23.234739
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors

# Generated at 2022-06-22 07:19:33.908946
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_url = 'http://test.com/test.ism/test.m3u8'
    test_info_dict = {'manifest_url': test_url, 'fragments': [{'duration': 1, 'url': 'http://test.com/test.ism/test.mp4'}], '_download_params': {'fourcc': 'AVC1', 'track_id': 1, 'duration': 0, 'language': 'und', 'timescale': 10000000, 'codec_private_data': '01640028ffe10014274fe1002028ff650028001001001867640028acd90690c4000001090c4000000015a2fa0080', 'height': 0, 'width': 0}}

# Generated at 2022-06-22 07:19:44.759017
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..downloader import YoutubeDL
    from ..utils import PreferredUrlOrderList
    ydl = YoutubeDL()
    ydl.params['test'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['keep_fragments'] = False

    ydl.add_info_extractor(IsmIE())
    ydl.add_info_extractor(IsmaIE())
    ydl.add_info_extractor(SmoothStreamingIE())
    ydl.add_info_extractor(MsStreamIE())
    ydl.add_info_extractor(MsPressIE())
    ydl.add_info_extractor(GenericIE())
    ydl.add_info_extractor(HDSFD())

# Generated at 2022-06-22 07:19:47.183332
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'test_IsmFD_real_download'
    #TODO write test for real_download
    return True

# Generated at 2022-06-22 07:19:50.172198
# Unit test for function box
def test_box():
    import binascii
    res = box(b'abcd', b'1234')
    expected = binascii.unhexlify('0000000c616263640000001234')
    assert res == expected


# Generated at 2022-06-22 07:20:01.319693
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # If a test fails it will be reported as failed test (see common/output.py:output_results)
    # The summary result of this test set is the result of the final test
    result = True

    # Setup
    # Download a single fragment

# Generated at 2022-06-22 07:20:10.376062
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://www.example.com'
    params = {'fragments': [{'url': 'http://www.example.com/file.ism/fileSeg1-frag1'}]}
    info_dict = {'_download_params': {'track_id': 0}, 'fragments': [{'url': 'http://www.example.com/file.ism/fileSeg1-frag1'}]}
    ismFd = IsmFD(params, None, None)
    assert ismFd.real_download(url, info_dict) == True


# Generated at 2022-06-22 07:21:13.696075
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import YoutubeDL
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kargs):
            super(FakeYDL, self).__init__(*args, **kargs)
            self.to_screen = lambda *a, **k: None
            self.cache.remove()

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kargs):
            super(FakeInfoExtractor, self).__init__(*args, **kargs)
            self._downloader = FakeYDL()

    gen_extractors()
    t_ie = FakeInfoExtractor({})

# Generated at 2022-06-22 07:21:21.431423
# Unit test for constructor of class IsmFD
def test_IsmFD():
    with tempfile.NamedTemporaryFile(mode='wb') as temp_file:
        temp_file.write(b'Hello, world')
        temp_file.flush()
        with open(temp_file.name, 'rb') as temp_file_open:
            ism_fd = IsmFD(temp_file_open, temp_file.name, None)
            assert ism_fd.params['test'] == False
            assert ism_fd.params['fragment_retries'] == 0
            assert ism_fd.params['skip_unavailable_fragments'] == True
            assert ism_fd.params['keep_fragments'] == False


# Generated at 2022-06-22 07:21:30.395214
# Unit test for function write_piff_header
def test_write_piff_header():
    test_stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'AVC1', 'duration': 1284000000, 'timescale': 1, 'language': 'eng', 'height': 0, 'width': 0}
    write_piff_header(test_stream, params)

# Generated at 2022-06-22 07:21:32.907126
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'payload') == b'\x00\x00\x00\x10mvhdpayload'
    assert len(box(b'mvhd', b'payload')) == 16
    

# Generated at 2022-06-22 07:21:38.184856
# Unit test for function extract_box_data
def test_extract_box_data():
    box_types = (b'moov', b'mvhd')
    test_box_data = b'moov\x00\x00\x00\x00\x00\x00\x00\x00\x01mvhd\x00\x00\x00\x00\x00\x00\x00\x00'
    extract_box_data(test_box_data, box_types) == box_types[1]
test_extract_box_data.dependencies = []



# Generated at 2022-06-22 07:21:41.620960
# Unit test for function write_piff_header
def test_write_piff_header():
    data = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 1000,
        'fourcc': 'AACL',
        'timescale': 48000,
        'sampling_rate': 24000,
        'channels': 2
    }
    write_piff_header(data, params)

# Generated at 2022-06-22 07:21:47.175700
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'AACL', 'codec_private_data': '12345678901234567890123456789012', 'duration': 2000, 'language': 'und', 'height': 240, 'width': 320}
    write_piff_header(stream, params)
    output = stream.getvalue()

# Generated at 2022-06-22 07:21:53.609215
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import YoutubeDL
    from .extractor import gen_extractors
    from .__main__ import parseOpts

    gen_extractors()
    ydl = YoutubeDL(parseOpts())
    fd = IsmFD(ydl, params={'filename': 'test.ism'})
    assert fd.FD_NAME == 'ism'

# Generated at 2022-06-22 07:21:57.493302
# Unit test for function full_box
def test_full_box():
    payload = "payload"
    type1 = 'type1'
    version = 1
    flags = 0x1
    assert full_box(type1, version, flags, payload) == '\x00\x00\x00\x11type1\x01\x00\x00\x00payload'



# Generated at 2022-06-22 07:22:05.846412
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x1c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x04', [b'\x00\x00\x00\x00', b'\x00\x00\x00\x03', b'\x00\x00\x00\x04'])
    assert box_data == b'\x00\x00\x00\x10'
test_extract_box