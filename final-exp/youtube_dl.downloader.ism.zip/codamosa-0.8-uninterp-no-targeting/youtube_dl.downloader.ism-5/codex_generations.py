

# Generated at 2022-06-22 07:13:52.543846
# Unit test for function full_box
def test_full_box():
    assert (full_box('avc1', 0, 0, '') == '\x00\x00\x00\x0cavc1\x00\x00\x00\x00')



# Generated at 2022-06-22 07:14:03.123840
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00' * 100
    assert extract_box_data(test_data, (b'',)) == test_data
    test_data = b'\x00' * 4 + b'\x01' + b'\x00' * (100-5)
    assert extract_box_data(test_data, (b'\x01',)) == test_data[5:]
    test_data = b'\x00' * 4 + b'\x01' + b'\x00' * 4 + b'\x02' + b'\x00' * (100-9)
    assert extract_box_data(test_data, (b'\x01', b'\x02',)) == test_data[9:]

# Generated at 2022-06-22 07:14:05.287164
# Unit test for function box
def test_box():
    assert box(b'moov', b'movie-data') == b'\x00\x00\x00\x10moovmovie-data'


# Generated at 2022-06-22 07:14:16.011664
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file_name = 'test.ismv'
    def check_box(stream, box_type, header_size, payload_size):
        current_pos = stream.tell()
        stream.seek(current_pos - header_size)
        size = u32.unpack(stream.read(4))[0]
        assert box_type == stream.read(4)
        if payload_size is not None:
            assert size - 8 == payload_size
        stream.seek(current_pos)

# Generated at 2022-06-22 07:14:27.615096
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.can_download({
        'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
        'ext': 'ism',
    })
    assert IsmFD.can_download({
        'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(30000)/Fragments(Video=7000)',
        'ext': 'mp4',
    })

# Generated at 2022-06-22 07:14:37.710046
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.ism import IsmFD
    from .common import FileDownloader
    ismFD = IsmFD()

    #Test 1
    ism_params = {'fragments': 'test_fragments'}
    info_dict = {'_filename': 'test_filename', '_download_params': ism_params, '_fatal_error': False}
    fd = FileDownloader({}, info_dict, {})
    ismFD.real_download('test_filename', info_dict)
    assert fd.params['test'] is False

    #Test 2
    ism_params = {'test': True, 'fragments': 'test_fragments'}

# Generated at 2022-06-22 07:14:48.566987
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # prepare
    test_file = os.path.join(os.path.dirname(__file__), 'media', 'test1.mpd')
    result_file = os.path.join(os.path.dirname(__file__), 'media', 'test1.ism')
    fd = IsmFD(ydl=YoutubeDL())
    # execute

# Generated at 2022-06-22 07:15:01.344521
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = b'\x00\x00\x00\x01soun\x00\x00\x00\x01\x00\x00\x00\x01'
    assert extract_box_data(box_data, (b'moov', b'soun')) == b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    assert extract_box_data(box_data, (b'moov', b'soun', b'mp4a')) == b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'

# Generated at 2022-06-22 07:15:12.165767
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'AVC1',
        'track_id': 0,
        'duration': 0,
        'width': 640,
        'height': 480,
        'codec_data': '0000000167640014ACD940404040404040404040404040404040404040404040404040404040404040404040404040404010168EBE1',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:15:21.319810
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        # Write piff header with audio
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
            'duration': 50000
        }
        write_piff_header(stream, params)

        # Assert if piff header is written correctly

# Generated at 2022-06-22 07:16:29.651458
# Unit test for function extract_box_data
def test_extract_box_data():
    from ..utils import bytes_to_intlist
    s = b'\x00\x00\x00\x1c'  # size
    s += b'ftyp'  # type
    s += b'isml'  # major brand
    s += b'\x00\x00\x00\x01'  # minor version
    s += b'piff' + b'iso2'  # compatible brands
    s += b'\x00\x00\x00\x14'  # size
    s += b'moov'  # type
    s += b'\x00\x00\x00\x08'  # size
    s += b'mvhd'  # type
    s += b'\x00\x00\x00\x01'  # version

# Generated at 2022-06-22 07:16:34.189021
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    from pytube import YouTube

    url = 'https://www.youtube.com/watch?v=9bZkp7q19f0'
    yt = YouTube(url)
    stream = yt.streams.filter(mime_type='video/mp4').first()
    stream.download(filename='test')

    pass

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-22 07:16:43.294245
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('piff.ismv', 'wb') as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10200000,
            'timescale': 10000000,
            'width': 1280,
            'height': 720,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
            'codec_private_data': '01640032ac02808080faf005002a020101ff00',
        })



# Generated at 2022-06-22 07:16:47.988633
# Unit test for function write_piff_header
def test_write_piff_header():
    out_f = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 0,
        'timescale': 10000000,
        'language': 'und',
        'height': 400,
        'width': 400,
        'codec_private_data': '0142e0afd6e000bafad8038080808080808080ab1',
    }
    write_piff_header(out_f, params)

# Generated at 2022-06-22 07:16:59.797803
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:17:04.653966
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'
    assert box(b'moov', b'\x00') == b'\x00\x00\x00\rmoov\x00'


# Generated at 2022-06-22 07:17:08.304542
# Unit test for function full_box
def test_full_box():
    assert full_box(b'fmp4', 1, 0x1, b'') == b"\x00\x00\x00\x0Bfmp4\x01\x00\x00\x01\x00"



# Generated at 2022-06-22 07:17:13.107935
# Unit test for function full_box
def test_full_box():
    class DummyPayload(object):
        def __bytes__(self):
            return b'\0'
    assert full_box(b'moov', 0, 0, DummyPayload()) == b'moov\0\0\0\0\0\0\0\0'



# Generated at 2022-06-22 07:17:22.426182
# Unit test for function write_piff_header
def test_write_piff_header():
    # https://msdn.microsoft.com/en-us/library/windows/desktop/ee663575(v=vs.85).aspx
    # The following is a description of the fields found in a PIFF sample (taken from an actual PIFF file)
    buf = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 3284665508,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    write_piff_header(buf, params)

# Generated at 2022-06-22 07:17:29.463971
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import read_batch_urls
    FileDownloader({'nopart': True,
                    'fragment_retries': 10,
                    'buffer_size': 1024,
                    'test': True}).add_info_extractor(gen_extractors(read_batch_urls('ismlist'))[0])()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:18:38.966420
# Unit test for constructor of class IsmFD
def test_IsmFD():
    manifest_url = 'http://smf.blob.core.windows.net/samples/c3b6abc5-78c1-476f-afd6-e8006cd5bd6f.ism/manifest'
    codec_private_data = '000000016742a00c000a098c0c0080'
    params = {
        'duration': 124.0,
        'track_id': 1,
        'timescale': 10000000,
        'height': 0,
        'width': 0,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16
    }

    ism = IsmFD(params, [manifest_url])
    info = ism.real_extract()

# Generated at 2022-06-22 07:18:51.560832
# Unit test for function extract_box_data
def test_extract_box_data():
    assert (extract_box_data(b'\x00\x00\x00\x18\x75\x6E\x6B\x73\x00\x00\x00\x02\x00\x00\x00\x1D\x6D\x6F\x6F\x76\x00\x00\x00\x01\x00\x00\x00\x0C\x6D\x64\x69\x61\x61\x61\x61\x61\x61\x61\x61', (b'moov', b'mvhd'))) == b'\x00\x00\x00\x01'

# Generated at 2022-06-22 07:19:00.916026
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file = io.BytesIO()
    # write_piff_header(test_file, {'track_id': 1, 'fourcc': 'H264', 'duration': 223271, 'timescale': 10000000, 'height': 720, 'width': 1280, 'codec_private_data': '0164001fffe1001867640029ac56b403021e000001f4040404020c110107010101010101010100d7ff000000f2e20100000168ee3c80'})
    # write_piff_header(test_file, {'track_id': 1, 'fourcc': 'mp4a', 'duration': 223271, 'timescale': 10000000, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100, 'codec_

# Generated at 2022-06-22 07:19:04.190761
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x08ftypisom' == box(b'ftyp', b'isom')



# Generated at 2022-06-22 07:19:14.874908
# Unit test for function extract_box_data
def test_extract_box_data():
    moof_data = (
        b'\x00\x00\x00\x2C' + b'moof' +
        b'\x00\x00\x00\x1C' + b'mfhd' +
        b'\x00\x00\x00\x08' + b'\x00\x00\x00\x01' +
        b'\x00\x00\x00\x14' + b'trak' +
        b'\x00\x00\x00\x08' + b'\x00\x00\x00\x01'
    )
    mfhd_data = (
        b'\x00\x00\x00\x08' + b'\x00\x00\x00\x01'
    )
    assert extract_

# Generated at 2022-06-22 07:19:22.590360
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {
        'url': 'http://example.com',
        'fragments': [  # Fragment Info
            {'url': 'http://site/a/1.ism', 'duration': 1, 'title': '1.ism'},
            {'url': 'http://site/a/2.ism', 'duration': 1, 'title': '2.ism'},
        ],
    }
    _IsmFD = IsmFD(info_dict)



# Generated at 2022-06-22 07:19:28.551009
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:19:40.274350
# Unit test for function extract_box_data
def test_extract_box_data():
    box_size = u32.pack(49)
    box_type = b'moov'
    box_data = box_size + box_type + u8.pack(0) * 41
    assert extract_box_data(box_data, [b'moov']) == u8.pack(0) * 41
    assert extract_box_data(box_data, [b'moov', b'cmov']) is None
    box_size = u32.pack(44)
    box_type = b'mvex'
    box_data = box_size + box_type + u8.pack(0) * 36
    box_size = u32.pack(39)
    box_type = b'mehd'
    box_data += box_size + box_type + u8.pack(0) * 31
   

# Generated at 2022-06-22 07:19:44.012359
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        test_IsmFD_object = IsmFD()
    except:
        assert False, 'Could not instantiate IsmFD object'


# Generated at 2022-06-22 07:19:53.497074
# Unit test for function extract_box_data
def test_extract_box_data():
    import re

# Generated at 2022-06-22 07:21:02.582180
# Unit test for function full_box
def test_full_box():
    version_expected = 1
    flags_expected = 0x0
    box_type_expected = b'moov'
    payload_expected = b'\x00\x00\x00\x00'

    output = full_box(box_type_expected, version_expected, flags_expected, payload_expected)

    if not isinstance(output, bytes):
        raise Exception("Output is not a bytes object")

    # test header
    header = output[0:8]
    if header != b'\x00\x00\x00\x00moov':
        raise Exception("Issue with header content")

    # test version
    version = output[8]
    if version != version_expected:
        raise Exception("Issue with version content")

    # test flags
    flag_mask = output[9:12]

# Generated at 2022-06-22 07:21:06.710084
# Unit test for function box
def test_box():
    packed = box('uuid'.encode('ascii'), binascii.unhexlify('00000000000000000000000000000000'))
    assert packed == binascii.unhexlify('0000000000000757575646600000000000000000000000000000000')


# Generated at 2022-06-22 07:21:08.210822
# Unit test for function full_box
def test_full_box():
    with open(r'E:\test\test_full_box.mp4','w') as f:
        f.write(full_box(b'moov', 0, 0, b''))


# Generated at 2022-06-22 07:21:13.664280
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.ism import IsmFD
    from .utils import compat_urllib_parse_urlparse, compat_urllib_parse_unquote

    stream_list_url = 'http://playready.directtaps.net/pr/svc/rightsmanager.asmx?PlayRight=1&UseSimpleNonPersistentLicense=1'
    manifest_url = 'http://playready.directtaps.net/pr/svc/rightsmanager.asmx?PlayRight=1&UseSimpleNonPersistentLicense=1'

    ie = InfoExtractor({})
    ie.add_info_extractor('ism', IsmFD)

    # Get license url

# Generated at 2022-06-22 07:21:22.580573
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .common import get_filesystem_encoding
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import prepend_extension

    # The easiest way to test IsmFD is the test a playready encrypted ISM file
    # Currently, the only such video is this one:
    # https://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/manifest
    url = 'https://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/manifest'

    # If the file was already downloaded, we can use it
    # (to avoid downloading 4.3Mb every time we run the unittest)
   

# Generated at 2022-06-22 07:21:28.641722
# Unit test for function box
def test_box():
    print(box('stts', '\x00\x00\x00\x00'))
    print(box('stts', '\x00\x00\x00\x01'))
    print(box('stts', '\x00\x00\x00\x02'))
    print(box('stts', '\x00\x00\x00\x03'))
    print(box('stts', '\x00\x00\x00\x04'))
    print(box('stts', '\x00\x00\x00\x05'))
    print(box('stts', '\x00\x00\x00\x06'))
    print(box('stts', '\x00\x00\x00\x07'))

# Generated at 2022-06-22 07:21:30.152479
# Unit test for function box
def test_box():
    assert box(b'abcd', b'payload') == b'\x00\x00\x00\x10abcdpayload'



# Generated at 2022-06-22 07:21:38.212692
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ''' test_IsmFD.py: Unit test for constructor of class IsmFD. '''

    params = {
        'noprogress': True,
        'print_debug_info': False,
        'quiet': True,
        'prefer_insecure': False,
        'prefer_free_formats': False,
        'fragment_retries': 10,
        'test': False,
        'format': 'ism',
    }


# Generated at 2022-06-22 07:21:40.417345
# Unit test for function box
def test_box():
    assert (box(b'ftyp', b'isomiso2avc1mp41') == b'\x00\x00\x00\x14ftypisomiso2avc1mp41')



# Generated at 2022-06-22 07:21:46.372299
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    def my_test_download(filename):
        assert filename == 'test.mp4'

    extractor = IsmFD()
    extractor.to_screen = lambda x: None
    extractor._download_fragment = lambda *args: (True, b'\x00\x00\x00\x00')
    extractor._finish_frag_download = lambda x: None
    extractor._prepare_and_start_frag_download = lambda x: None
    extractor._append_fragment = my_test_download

    assert extractor.real_download(
        filename='test.mp4',
        info_dict={
            'fragments': [],
            '_download_params': {},
        }
    ) is True