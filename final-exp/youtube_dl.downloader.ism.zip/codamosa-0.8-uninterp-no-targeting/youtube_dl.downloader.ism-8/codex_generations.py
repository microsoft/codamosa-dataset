

# Generated at 2022-06-22 07:14:01.456602
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info_dict = {
        'url': 'http://some.ism/Manifest',
        'fragments': [
            {
                'url': 'http://some.ism/Fragment1',
                'duration': 10
            },
            {
                'url': 'http://some.ism/Fragment2',
                'duration': 5
            },
            {
                'url': 'http://some.ism/Fragment3',
                'duration': 15
            }
        ]
    }

# Generated at 2022-06-22 07:14:05.693669
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from . import YoutubeDL
    ret = IsmFD.real_download(YoutubeDL({'fragment_retries':2, 'fragment_size':1048576, 'dump_intermediate_pages':True, 'skip_unavailable_fragments':False}), 'filename', {'fragments': [{'url': 'url'}], '_download_params': {}})
    assert ret == True


# Generated at 2022-06-22 07:14:16.292727
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with default parameters
    manifest_url = 'http://wamsprodglobal001acs.origin.mediaservices.windows.net/d36a01a2-cd52-4f56-99f1-d3f10bcf51b4/Big%20Buck%20Bunny%20Trailer.ism/Manifest'
    params = {}
    ism = IsmFD.create_getdescriptor(manifest_url, params)
    assert (ism.basename == 'Big Buck Bunny Trailer.mp4')
    assert (ism.manifest_url == manifest_url)
    assert (ism.params == dict(fragment_retries=0, skip_unavailable_fragments=True, test=False))

    params['fragment_retries'] = 2

# Generated at 2022-06-22 07:14:22.059108
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'\x00\x00\x00\x00\x00\x00\x00\x00') == b'\x00\x00\x00\x14mvhd\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-22 07:14:24.882428
# Unit test for function box
def test_box():
    assert box('abcd', '1234') == b'\x00\x00\x00\x0cabcd1234'


# Generated at 2022-06-22 07:14:28.815266
# Unit test for constructor of class IsmFD
def test_IsmFD():
    def get_fd(params):
        return IsmFD(params)

    test_download_method_for_live(get_fd, 'ism')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:14:30.668017
# Unit test for constructor of class IsmFD
def test_IsmFD():
    #Constructor of class IsmFD
    IsmFD("")

# Generated at 2022-06-22 07:14:33.039702
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# class IsmFD

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-22 07:14:43.271003
# Unit test for function write_piff_header
def test_write_piff_header():
    from struct import unpack
    import io
    #Test for audio
    params = {
        'track_id': 0,
        'fourcc': 'AACL',
        'duration': 1,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'language': 'und',
        'channels': 2,
        'bits_per_sample': 16
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

    stream.seek(0)
    assert u32.unpack(stream.read(4))[0] == 0x3c  # ftyp
    assert stream.read(4) == b'ftyp'
    assert u32.unpack(stream.read(4))[0] == 0x14  # ftyp payload size
   

# Generated at 2022-06-22 07:14:50.617493
# Unit test for constructor of class IsmFD
def test_IsmFD():
    output_fname = 'output.mp4'
    # TODO: Add unit test
    url = 'http://www.example.com/myvideo.ism/manifest(format=m3u8-aapl)'
    if os.path.exists(output_fname):
        os.remove(output_fname)
    ret = IsmFD().download(url, output_fname)
    assert(ret and os.path.exists(output_fname))



# Generated at 2022-06-22 07:15:12.169662
# Unit test for function write_piff_header
def test_write_piff_header():
    """Test that a PIFF header is properly written."""
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 0x1,
        'fourcc': 'H264',
        'duration': int(1000.0 / 25 * 10000000),
        'timescale': 10000000,
        'height': 0,
        'width': 0,
    })
    stream.seek(0)

# Generated at 2022-06-22 07:15:24.077276
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = dict(track_id=1, fourcc='H264', duration=10000, channels=2, bits_per_sample=16, sampling_rate=44100,
                      height=576, width=720, codec_private_data='01640028ffe1001867640028ac2b4020')
        write_piff_header(stream, params)
        stream.seek(0)
        hex_stream = ''.join(['%0.2x' % b for b in stream.read()])

# Generated at 2022-06-22 07:15:34.266620
# Unit test for function write_piff_header
def test_write_piff_header():
    import sys
    import struct
    import tempfile
    import zlib
    with tempfile.TemporaryFile() as f:
        with io.open(f.fileno(), 'wb', closefd=False) as stream:
            write_piff_header(stream, {
                'fourcc': 'H264',
                'track_id': 1,
                'duration': 30000000,
                'sampling_rate': 44100,
                'channels': 2,
                'height': 1080,
                'width': 1920,
                'codec_private_data': '01640028ffe1000b674d401f9a49e1ce44890f80c',
            })

# Generated at 2022-06-22 07:15:39.745481
# Unit test for function full_box
def test_full_box():
    assert full_box(b"ftyp", 2, 0, b"isom") == binascii.unhexlify(b'000000006674797020000000669736f6d')
    assert full_box(b"mvhd", 1, 0, b"") == binascii.unhexlify(b'000000006d7668640100000000000000')



# Generated at 2022-06-22 07:15:51.136623
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    data = {'fourcc': 'H264', 'language': 'rus', 'sampling_rate': 44100, 'width': 1280, 'height': 720, 'track_id': 1, 'duration': 2000, 'codec_private_data': '000000016742e01f9a0d800000167640028ac2ec801b8018000030080000300c000034a000f18800000010000000168e94f0001f48000f1880000000168e94a01b801885e000001b7f300a010000300c01000034a01e2a01000001e2a020000'}
    write_piff_header(output, data)
    return output.getvalue()


# Generated at 2022-06-22 07:16:00.425956
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'url': 'http://pdl.vimeocdn.com/115601/131/37930850.ism/37930850-00001.ism',
        'fragments': [{'url': 'http://pdl.vimeocdn.com/115601/131/37930850-00001.ism'}, {'url': 'http://pdl.vimeocdn.com/115601/131/37930850-00002.ism'}]}, {}, None)
    return fd

if __name__ == '__main__':
    fd = test_IsmFD()
    fd.download('test.mp4')

# Generated at 2022-06-22 07:16:05.223355
# Unit test for function write_piff_header
def test_write_piff_header():
    def _test(params):
        stream = io.BytesIO()
        write_piff_header(stream, params)
        actual = stream.getvalue()
        stream = io.BytesIO(actual)
        fd = FragmentFD(stream)
        assert fd.read_box()[0] == b'moov'
        assert actual == stream.read()
    _test({'track_id': 1, 'duration': 99, 'sampling_rate': 44100, 'fourcc': 'AACL'})

# Generated at 2022-06-22 07:16:05.679530
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:16:07.452627
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD(None, {}, None)

# Generated at 2022-06-22 07:16:11.961378
# Unit test for function full_box
def test_full_box():
    if full_box('moov', 1, 0, '') != '\x00\x00\x00\x0cmoov\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00':
        return False
    return True

# Generated at 2022-06-22 07:16:39.614884
# Unit test for function full_box
def test_full_box():
    box_type = 'moov'
    version = 0
    flags = 0
    payload = ''
    assert full_box(box_type, version, flags, payload) == b'moov\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:16:50.729981
# Unit test for function extract_box_data
def test_extract_box_data():
    # stco_box
    abox_type = b'moov'
    a = box(abox_type,b'abcd')
    bbox_type = b'trak'
    b = box(bbox_type,b'efgh')
    cbox_type = b'mdia'
    c = box(cbox_type,b'ijkl')
    dbox_type = b'minf'
    d = box(dbox_type,b'ijkl')
    ebox_type = b'stbl'
    e = box(ebox_type,b'ijkl')
    fbox_type = b'stco'
    f = box(fbox_type,b'ijkl')
    s = a + b + c + d + e + f

# Generated at 2022-06-22 07:16:55.716462
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'moov\x08\x00\x00\x00abcdstbl\x10\x00\x00\x00stsd\x0c\x00\x00\x00def',
                            (b'moov', b'stbl', b'stsd')) == b'def'



# Generated at 2022-06-22 07:16:56.897519
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    fd.download('http://example.com', None)
    assert(False)  # This line should never be reached

# Generated at 2022-06-22 07:17:05.529651
# Unit test for function write_piff_header
def test_write_piff_header():
    movie = io.BytesIO()
    write_piff_header(movie, {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 20000,
        'width': 1280,
        'height': 720,
        'timescale': 10000000,
        'codec_private_data': '00000003014D402C29BC0F5C04D801010000003005D8777C010107F4F4000001B80000010000008000001C402005D8777C010107F4F40000008000001C4028000001800000001000001000000000000000000000000000000000000000000',
        'nal_unit_length_field': 4,
    })
    ftyp_payload = movie.getvalue()[8:24]
    assert ftyp_payload == b

# Generated at 2022-06-22 07:17:16.373441
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor.ism import IsmFD
    import webvtt

    path = []

    def _download(self, filename, info_dict):
        path.append(filename)

        count = 0
        while count <= 0:
            try:
                count += 1
                return True, ''.join(pytest.main(['-q', '-1', '-a', path[0]]))
            except compat_urllib_error.HTTPError as err:
                if count <= 0:
                    pass
        return True
    IsmFD._download_fragment = _download

    def _temp_name(self, filename):
        path.append(filename)
        return filename

# Generated at 2022-06-22 07:17:20.400814
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    m = IsmFD()
    args = {}
    info_dict = {}
    m.real_download('/home/son/Desktop/PythonUnittest/ts/ism_fd.mp4', info_dict)

if __name__ == "__main__":
    test_IsmFD_real_download()

# Generated at 2022-06-22 07:17:24.897914
# Unit test for function box
def test_box():
    print('Testing function box')
    assert b'\x00\x00\x00\x0c' + b'mdat' + b'\x00\x00\x00\x00' == box(b'mdat', b'\x00\x00\x00\x00')
    print('Function box pass unit test')


# Generated at 2022-06-22 07:17:26.291407
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:17:32.456167
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    test_manifest_url = 'http://127.0.0.1:8000/static/smooth/manifest.mpd'
    ismfd = IsmFD(test_manifest_url, {'outtmpl': 'test_outtmpl'})
    assert ismfd.manifest_url == test_manifest_url
    assert ismfd.params['outtmpl'] == 'test_outtmpl'


# Generated at 2022-06-22 07:18:13.141492
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:15.437333
# Unit test for function box
def test_box():
    assert box('____', b'') == b'\x00\x00\x00\x08____'



# Generated at 2022-06-22 07:18:18.531771
# Unit test for function full_box
def test_full_box():
    assert u'646174610000000100000000' == binascii.hexlify(full_box(b'data', 1, 0, b''))



# Generated at 2022-06-22 07:18:30.146293
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:32.861332
# Unit test for function box
def test_box():
    assert box('mdat', 'payload-box-data') == binascii.a2b_hex('00000018mdatpayload-box-data')


# Generated at 2022-06-22 07:18:35.968903
# Unit test for function full_box
def test_full_box():
    from .test import FullBoxTest
    FullBoxTest(full_box).run()



# Generated at 2022-06-22 07:18:37.350796
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert True

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:18:42.845314
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 0x01, b'') == b'\x00\x00\x00\x10moov\x01\x00\x00\x00\x00\x00\x00\x00'
assert test_full_box()



# Generated at 2022-06-22 07:18:54.316832
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 10000, 'lang': 'eng', 'sampling_rate': 48000, 'channels': 2, 'bits_per_sample': 16, 'height': 240, 'width': 320}
    write_piff_header(output, params)
    assert output.getvalue() == b'ftypisml' + u32.pack(1) + b'piffiso2' + b'moov' + u32.pack(299) + b'mvhd' + u8.pack(1) + u32.pack(0) + u64.pack(0) + u32.pack(10000000) + u64.pack(10000) + s1616.pack(1) + s88.pack(1) + u

# Generated at 2022-06-22 07:19:01.369643
# Unit test for function full_box
def test_full_box():
    box_type = b'\x00\x00\x00\x00'
    payload = b'\x00\x00\x00\x00'
    version = 0
    flags = 0
    full_b = full_box(box_type, 0, 0, payload)
    assert full_b == b'\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-22 07:20:17.134913
# Unit test for function box
def test_box():
    expected = u32.pack(8 + len('ABCD')) + b'abcd'+ b'ABCD'
    result = box(b'abcd', b'ABCD')
    assert expected == result
    assert expected == b'\x00\x00\x00\x0cabcdABCD'



# Generated at 2022-06-22 07:20:23.553212
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:20:27.728105
# Unit test for function box
def test_box():
    test_str = b'\x00\x00\x00\x08' + b'test' + b'\x1a\x45\xdf\xa3'
    assert box(b'test', b'\x1a\x45\xdf\xa3') == test_str


# Generated at 2022-06-22 07:20:30.290575
# Unit test for function box
def test_box():
    assert(box(b'esds', b'\x01\x02\x03') == b'\x00\x00\x00\x0Fesds\x01\x02\x03')



# Generated at 2022-06-22 07:20:35.121282
# Unit test for function full_box
def test_full_box():
    # Video case
    version = u8.pack(0)
    flags = u32.pack(0)

# Generated at 2022-06-22 07:20:45.132208
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import YoutubeIE
    from .downloader import FileDownloader
    from .common import FileDownloader
    from .common import YoutubeDL
    from .common import get_cachedir


# Generated at 2022-06-22 07:20:56.857753
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    with tempfile.TemporaryFile(mode='wb') as f:
        params = {'track_id': 1, 'fourcc': 'H264', 'duration': 1000000000, 'timescale': 10000000,
                  'language': 'en', 'height': 0, 'width': 0,
                  'codec_private_data': '016742e01ffff'}
        write_piff_header(f, params)
        f.seek(0)
        hexlified = binascii.hexlify(f.read()).decode('utf-8')

# Generated at 2022-06-22 07:20:59.403735
# Unit test for function extract_box_data
def test_extract_box_data():
    f = FragmentFD('test/test_data/fragment.ism')
    data = f.read_metadata()
    assert extract_box_data(data, (b'moov', b'mtrak', b'mdia', b'minf', b'stbl'))



# Generated at 2022-06-22 07:21:10.982026
# Unit test for function box
def test_box():
    # Test 1
    type = 'abcd'
    payload = '1234'
    result = box(type, payload)
    expected = u32.pack(len(payload)+8) + type + payload
    if result != expected:
        print('box test one failed:')
        print('r:',result)
        print('e:',expected)

    # Test 2
    type = 'efgh'
    payload = '5678'
    result = box(type, payload)
    expected = u32.pack(len(payload)+8) + type + payload
    if result != expected:
        print('box test two failed:')
        print('r:',result)
        print('e:',expected)

    # Test 3
    type = 'ijkl'
    payload = '9101112'

# Generated at 2022-06-22 07:21:15.166713
# Unit test for function write_piff_header
def test_write_piff_header():
    import io
    import random
    stream = io.BytesIO()
    # Test moof box