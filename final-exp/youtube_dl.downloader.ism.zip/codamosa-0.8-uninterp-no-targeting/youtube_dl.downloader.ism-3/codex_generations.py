

# Generated at 2022-06-22 07:14:05.044923
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:10.870389
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Creating instance of IsmFD and checking whether created instance is correct one
    # or not
    assert isinstance(IsmFD(FragmentFD, "http://mediaplatstorage1.blob.core.windows.net/wowzasrvskybmr/SkyNewsHD_1%40294040.ism/manifest(format=mpd-time-csf)", None), IsmFD)

if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-22 07:14:21.515284
# Unit test for function full_box
def test_full_box():
    assert full_box('mvhd', 1, 0, u32.pack(0) + u64.pack(0) + u32.pack(0x10000)) == b'\x00\x00\x00\x10mvhd\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:14:25.229202
# Unit test for function box
def test_box():
    assert box(b'moov', b'box_payload') == b'\x00\x00\x00\x0cmoovbox_payload'

# Item location atom used in FDSS

# Generated at 2022-06-22 07:14:36.440364
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri

    mp4_header = io.BytesIO()
    write_piff_header(
        mp4_header, {
            'track_id': 1, 'fourcc': 'AACL', 'language': 'und',
            'sampling_rate': 44100, 'duration': 18000000, 'timescale': 18000,
        })

# Generated at 2022-06-22 07:14:42.040592
# Unit test for function full_box
def test_full_box():
    assert(full_box('mvhd', 0, 0, u32.pack(0) + u32.pack(0) + u32.pack(0x10000) + u16.pack(1) + u16.pack(0)) == binascii.unhexlify(b'6d76686400000000000000010000000000000000001000100000000000000000000000000010000'))



# Generated at 2022-06-22 07:14:48.393857
# Unit test for function full_box
def test_full_box():
    assert full_box(box_type=b'\x66\x6f\x6f', version=1, flags=1, payload=b'\x00') == b'\x00\x00\x00\x0d\x66\x6f\x6f' + b'\x01\x00\x00\x00' + b'\x00\x00\x00\x00' + b'\x00'



# Generated at 2022-06-22 07:14:50.953930
# Unit test for function box
def test_box():
    assert box('free', '\x00'*10) == '\x00\x00\x00\x14free\x00'*10
# End unit test



# Generated at 2022-06-22 07:15:04.090572
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()

# Generated at 2022-06-22 07:15:12.977988
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'aaaaaaaa\x00\x00\x00\x00\x00\x00\x00\x00', [b'a']) == b''
    assert extract_box_data(b'aaaaaaaa\x00\x00\x00\x08\x00\x00\x00\x00bbbbbbbb', [b'a']) == b'bbbbbbbb'
    assert extract_box_data(b'aaaaaaaa\x00\x00\x00\x08\x00\x00\x00\x00bbbbbbbb', [b'b', b'a']) == b''

# Generated at 2022-06-22 07:15:35.300682
# Unit test for function box
def test_box():
    box_type = b'mvhd'
    payload = u32.pack(0) + u32.pack(1) + (u32.pack(0) * 7) + u16.pack(1) + u16.pack(0) + (u32.pack(0) * 2) + u16.pack(1) + u16.pack(0) + (u32.pack(0) * 32) + u32.pack(16384)

# Generated at 2022-06-22 07:15:39.611410
# Unit test for function box
def test_box():
    print('test_box')
    print(box(b'moov', b'Payload'))
    print(box(b'moov', b'Payload') == b'\x00\x00\x00\x11moovPayload')
# End unit test for function box



# Generated at 2022-06-22 07:15:51.924236
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:15:53.639762
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'

# Generated at 2022-06-22 07:15:57.659979
# Unit test for function full_box
def test_full_box():
    assert(full_box('moov', 0, 0, '\0'*4) == '\x00\x00\x00\x10moov\x00\x00\x00\x00\x00\x00\x00\x00')



# Generated at 2022-06-22 07:16:05.369778
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test 1: Download Smokey and the Bandit 1977 movie
    # http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-frag/mp4-live-frag_isoffmain_DIS_23009_1_v_2_1c2_2011_source_360p_video.mp4
    print('Testing method real_download of class IsmFD with Smokey and the bandit movie 1977')
    info = {}
    info['fragments'] = []

# Generated at 2022-06-22 07:16:10.420927
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.ism import IsmFD

    ie = InfoExtractor()
    ie.add_info_extractor('ism', [
            {'test': 'ism', 'file': 'fake-url'},
            {'test': 'ism', 'file': 'fake-url'},
            {'test': 'ism', 'file': 'fake-url'},
            ])

    test_IsmFD_real_download.verbose = True


# Generated at 2022-06-22 07:16:18.952887
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as buf:
        params = dict(
            track_id=1,
            fourcc='H264',
            duration=5000,
            width=400,
            height=300,
            timescale=25000,
            language='eng',
            codec_private_data='0164002affe1001b67640028acd9e11fca13ec0033c8182000030080000',
            nal_unit_length_field=4,
        )
        write_piff_header(buf, params)

# Generated at 2022-06-22 07:16:26.288198
# Unit test for function full_box
def test_full_box():
    # box_type (12 bytes): box type
    box_type = bytes('ftypisom','utf8')
    # version (8 bytes): box version
    version = 0
    # flags (24 bytes): box flags
    flags = 0
    # payload (1 byte): box payload
    payload = bytes('', 'utf8')
    # Run full_box()
    full_box(box_type, version, flags, payload)



# Generated at 2022-06-22 07:16:28.361356
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'


# Generated at 2022-06-22 07:16:45.894158
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mapa', 0, 0, b'Hello') == b'\x00\x00\x00\x0fmapa\x00\x00\x00\x00Hello'



# Generated at 2022-06-22 07:16:50.735220
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    with tempfile.TemporaryFile() as f:
        write_piff_header(
            f,
            {
                'fourcc': 'H264',
                'track_id': 1,
                'duration': 0x1000,
                'nal_unit_length_field': 4,
                'codec_private_data': '01640033ffe1001867640033acdac802ea8032aac0a062e5343251c001000468ee3c80',
                'width': 640,
                'height': 480,
            })
        f.seek(0)

# Generated at 2022-06-22 07:16:54.820474
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:16:59.446361
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create instance of IsmFD
    fd = IsmFD(None)
    
    # Test arguments
    filename = 'filename'
    info_dict = {
        'fragments': [
            {
                'url': 'url1'
            },
            {
                'url': 'url2'
            }
        ],
        '_download_params': {
            'fourcc': 'fourcc',
            'sampling_rate': 'sampling_rate',
            'duration': 'duration',
            'track_id': 'track_id',
            'height': 'height',
            'width': 'width',
            'language': 'language',
        }
    }
    
    # Call method real_download of class IsmFD
    fd.real_download(filename, info_dict)

# Unit test

# Generated at 2022-06-22 07:17:08.575318
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-22 07:17:20.148063
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor.common import InfoExtractor, YaIE
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .compat import compat_urllib_parse, compat_urllib_error
    from .utils import encode_data_uri
    from io import BytesIO

    class IsmManifestIE(YaIE):
        def _real_extract(self, url):
            """
            return the parsed manifest in the format expected by IsmFD
            """
            # TODO
            pass

    class FakeFD(HttpFD):
        def __init__(self, test, downloader):
            self.test = test
            HttpFD.__init__(self, downloader)


# Generated at 2022-06-22 07:17:25.161798
# Unit test for function full_box
def test_full_box():
    box_type, version, flags, payload = 'mvhd', 0, 0, ''
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x0c' + b'mvhd' + b'\x00' + b'\x00\x00\x00' + b''


# Generated at 2022-06-22 07:17:34.410752
# Unit test for function box

# Generated at 2022-06-22 07:17:40.985471
# Unit test for function extract_box_data
def test_extract_box_data():
    box_payload = full_box(b'moov', 0, 0, b'')
    box_payload += full_box(b'mvhd', 0, 0, u32.pack(0) * 24)
    box_payload += box(b'trak', full_box(b'mdia', 0, 0, box(b'minf', full_box(b'stbl', 0, 0, box(b'stsd', u32.pack(1))))))
    box_payload += full_box(b'mvex', 0, 0, box(b'trex', u32.pack(0) * 4))
    print(extract_box_data(box_payload, (b'mvhd',)))

# Generated at 2022-06-22 07:17:47.476391
# Unit test for function full_box
def test_full_box():
    print('box_type:', box_type)
    print('version:', version)
    print('flags:', flags)
    print('payload:', payload)
    print('return:', box(box_type, u8.pack(version) + u32.pack(flags)[1:] + payload))


# Generated at 2022-06-22 07:18:09.574558
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 4096,
        'timescale': 2048,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    moov_box = stream.getvalue()

# Generated at 2022-06-22 07:18:21.667964
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:33.212645
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHFD
    from .dash import DASHF4MFD
    from .http import HTTPFD


# Generated at 2022-06-22 07:18:38.521861
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://www.sample-videos.com/video/ism/ism_test.ismc'
    filename = 'ism_test.ism'
    ismd = IsmFD()
    ismd.download(url, filename)

test_IsmFD_real_download()


# https://tools.ietf.org/html/draft-pantos-http-live-streaming-17

# Generated at 2022-06-22 07:18:51.023770
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 0x1,
        'duration': 10000000,
        'timescale': 10000000,
        'fourcc': 'AVC1',
        'width': 1280,
        'height': 720,
        'codec_private_data': '01640028ffe1020049zzz907f69880eadc602e2aa860028eeaadc602e2aa8b740028b7a185002a2',
    }

# Generated at 2022-06-22 07:18:57.483234
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x18' + b'moov' + b'\x00\x00\x00\x10' + b'mvhd' + b'\x00\x00\x00\x00', (b'moov', b'mvhd'))
    assert box_data == b'\x00\x00\x00\x10' + b'mvhd' + b'\x00\x00\x00\x00'



# Generated at 2022-06-22 07:19:00.930537
# Unit test for function full_box
def test_full_box():
	assert(full_box(b'mvhd',0,0,b'') == b'\x00\x00\x00\x0c' + b'mvhd' + b'\x00' + b'\x00\x00\x00' + b'' )


# Generated at 2022-06-22 07:19:05.727086
# Unit test for function full_box
def test_full_box():
    if full_box("moov",1,0,0) != b'moov\x00\x00\x00\x0c\x01\x00\x00\x00\x00\x00\x00':
        raise Exception("full_box failed")



# Generated at 2022-06-22 07:19:07.490959
# Unit test for function full_box
def test_full_box():
    print('testing: ', full_box('stsd', 'sd', 'flag', 'payload'))


# Generated at 2022-06-22 07:19:10.859692
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Just construct an instance of the FD and run its _real_initialize"""
    fd = IsmFD()
    fd._real_initialize()

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:19:41.765612
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    with tempfile.NamedTemporaryFile(suffix='.ismv') as temp_output_file:
        output_path = temp_output_file.name
        params = {
            'fourcc': 'H264',
            'track_id': 1,
            'duration': 10000000,
            'timescale': 10000000,
            'width': 1280,
            'height': 720,
            'language': 'eng',
            'codec_private_data': '0000000167640028AC56B9100000168EE883C0005E881400000300800000167640028AC56B9100000168EE883C0005E881400000300000328E0',
        }

# Generated at 2022-06-22 07:19:44.410696
# Unit test for function write_piff_header
def test_write_piff_header():
    bytes_io = io.BytesIO()
    params = {}
    write_piff_header(bytes_io, params)



# Generated at 2022-06-22 07:19:50.719201
# Unit test for constructor of class IsmFD
def test_IsmFD():
    FD_NAME = 'ism'
    ydl = YoutubeDL(params={
        'quiet': True,
        'skip_download': True,
        'format': FD_NAME
    })
    ism_info = {
        'url': 'http://example.com'
    }
    fd = IsmFD(ydl, ism_info)
    assert fd.FD_NAME == FD_NAME


# Generated at 2022-06-22 07:20:02.351959
# Unit test for function write_piff_header
def test_write_piff_header():
    params_video = {}
    params_video['track_id'] = 1
    params_video['fourcc'] = 'H264'
    params_video['duration'] = 1328
    params_video['timescale'] = 25
    params_video['language'] = 'en'
    params_video['width'] = 640
    params_video['height'] = 360
    params_video['codec_private_data'] = '0164001fffe1001167640029acd9407bfc010000382edf11980114002f24a05d4000c8aa'
    params_video['nal_unit_length_field'] = 4
    params_video['sampling_rate'] = 44100
    params_video['channels'] = 2
    params_video['bits_per_sample'] = 16

    params_video_

# Generated at 2022-06-22 07:20:13.743278
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .utils import sanitize_open
    from .extractor import gen_extractors
    from .downloader import gen_extractor_classes

    for ie in gen_extractors():
        for ie_cls in gen_extractor_classes(ie):
            t = type(
                ie.ie_key(), (object,),
                dict((ie_cls.ie_key(), ie_cls) for ie_cls in ie_cls.__bases__)
            )()
            t.get_info = lambda *args, **kwargs: kwargs
            t.report_warning = lambda *args, **kwargs: None
            t.to_screen = lambda *args, **kwargs: None

# Generated at 2022-06-22 07:20:22.758291
# Unit test for function box
def test_box():
    # A function "box" must exist
    assert 'box' in globals(), 'Function "box" is not defined'

    # First argument must be a type of string
    assert isinstance(box('moov', ''), str), 'The returned value must be a string'
    assert isinstance(box('ftyp', ''), str), 'The returned value must be a string'
    assert isinstance(box('mdat', ''), str), 'The returned value must be a string'

    # The returned value must be a box
    # moov
    assert u32.unpack(box('moov', '')[0:4])[0] == 8, 'The returned value must be a box'

    # ftyp

# Generated at 2022-06-22 07:20:24.444354
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD({})
    assert test_IsmFD

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:20:32.970117
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:20:44.085459
# Unit test for function box
def test_box():
    assert box(b'moov', b'data') == b'\x00\x00\x00\x0cmoovdata'

FTYP = b'mp42'
FRAGMENT_VERSION = b'\x01\x00\x00\x00'
MOOV_HEADER = b'moov'
MOOV_TRAK_HEADER = b'trak'
MOOV_TRAK_TKHD_HEADER = b'tkhd'
MOOV_TRAK_MDIA_HEADER = b'mdia'
MOOV_TRAK_MDIA_MDHD_HEADER = b'mdhd'
MOOV_TRAK_MDIA_HDLR_HEADER = b'hdlr'

# Generated at 2022-06-22 07:20:55.436945
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import urllib.request
    import tempfile
    from .downloader import IsmFD
    from .extractor import get_info_extractor
    from .utils import sanitize_open

    mybestfd = IsmFD(urllib.request.Request('http://www.example.com/'))
    mybestfd._download_webpage_handle = urllib.request.urlopen
    mybestfd._downloader = get_info_extractor(
        'http://example.org/media.ism/Info', downloader=mybestfd._downloader)
    mybestfd._do_download = True
    mybestfd._progress_hooks = [lambda *args: sys.stdout.write('\r[download] %s\n' % args[1])]

    filename = tempfile.mktemp

# Generated at 2022-06-22 07:22:41.096993
# Unit test for function full_box
def test_full_box():
    payload = box(b'mdhd', u32.pack(0) + u32.pack(0) + u32.pack(0))
    assert full_box(b'mdhd', 0, 0, payload) == b'\x00\x00\x00\x1a\x6d\x64\x68\x64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-22 07:22:42.093027
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    raise NotImplementedError('Test not implemented!')



# Generated at 2022-06-22 07:22:43.609786
# Unit test for function box
def test_box():
    print(bytes(box('mvhd', 'test')))
test_box()



# Generated at 2022-06-22 07:22:46.458064
# Unit test for function box
def test_box():
    assert box(b'abcd', b'1234') == b'\x00\x00\x00\x0cabcd1234'
test_box()



# Generated at 2022-06-22 07:22:51.595106
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b'payload') == b'\x00\x00\x00\x14moov\x00\x00\x00\x00payload'
    assert full_box(b'moov', 1, 2, b'payload') == b'\x00\x00\x00\x15moov\x01\x00\x02\x00payload'
    assert full_box(b'moov', 2, 2, b'payload') == b'\x00\x00\x00\x15moov\x02\x00\x02\x00payload'

# Generated at 2022-06-22 07:23:02.279474
# Unit test for function write_piff_header
def test_write_piff_header():
    def test_write_piff_header_helper(track_id, fourcc, duration, timescale_, language_, height_, width_, expected_stream_data):
        assert write_piff_header(
            io.BytesIO(),
            {
                'track_id': track_id,
                'fourcc': fourcc,
                'duration': duration,
                'timescale': timescale_,
                'language': language_,
                'height': height_,
                'width': width_,
            }
        ).getvalue() == expected_stream_data

    # Video track

# Generated at 2022-06-22 07:23:14.278695
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_file = 'test_file'

    class FakeFileObject:
        def __init__(self):
            self.written_data = b''
            self.written_data_on = 0
            self.written_data_off = 0

        def seek(self, offset, whence=io.SEEK_SET):
            if whence == io.SEEK_SET:
                self.written_data_off = offset
            elif whence == io.SEEK_CUR:
                self.written_data_off += offset
            elif whence == io.SEEK_END:
                self.written_data_off = len(self.written_data) + offset
            else:
                raise ValueError('invalid whence value: %r' % (whence,))

        def tell(self):
            return self.written_data_off



# Generated at 2022-06-22 07:23:24.460045
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Generating a random key
    k = ''.join(random.choice('0123456789abcdef') for _ in range(16))
    # Using different key for header and segment encryption
    header_k = ''.join(random.choice('0123456789abcdef') for _ in range(16))
    # Generating a random iv
    iv = os.urandom(16)
    # Header initialization vector
    header_iv = os.urandom(16)
    # Generating a random frag count
    frag_count = random.randint(10, 30)
    # Generating a random seg count
    seg_count = random.randint(10, 30)
    # Generating a random seg duration
    seg_duration = random.randint(10, 30)
    # Generating a random seg_size

# Generated at 2022-06-22 07:23:26.922862
# Unit test for function box
def test_box():
    # Test 1
    assert binascii.hexlify(box('abcd', 'efgh')) == b'000000086162636465666768'
    print("Passed test for box")