

# Generated at 2022-06-22 07:13:58.978387
# Unit test for function full_box
def test_full_box():
    assert(full_box(b'\x01'*4, 1, 0x2, b'\x00') == b'\x00\x00\x00\x08\x01\x01\x01\x01\x01\x00\x00\x00\x00')



# Generated at 2022-06-22 07:14:02.453002
# Unit test for constructor of class IsmFD
def test_IsmFD():
    #Declare instance of class IsmFD
    ismFD = IsmFD()
    #Checking the type of instance
    assert isinstance(ismFD, IsmFD)



# Generated at 2022-06-22 07:14:12.081552
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {'segment_base_url': 'https://s.ism-s.mov.ai/video/movies/', 'sid': '0e6bfdd1'}
    fd = IsmFD(params)
    fd.download('https://manifest.ism-s.mov.ai/0e6bfdd1.ism/manifest(format=mpd-time-csf)',
                {'fragments': [
                    {'duration': 1.02, 'url': 'https://s.ism-s.mov.ai/video/movies//1.mp4'},
                    {'duration': 1.02, 'url': 'https://s.ism-s.mov.ai/video/movies//2.mp4'},
                ]})


# Generated at 2022-06-22 07:14:19.496293
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys
    sys.exit(IsmFD().download(['https://d2lkynw8ed91j6.cloudfront.net/u/b/media/9f9c00e81bbacd0e7fdf858eb1501d07/ism_manifest.ism/ism_manifest.ism'])[0])


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:14:30.385851
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_url = 'http://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest'
    ism_fd = IsmFD(ism_url)
    assert_equals(ism_fd.FD_NAME, 'ism')
    assert_equals(ism_fd.params['file_format'], 'ism')
    assert_equals(ism_fd.params['total_frags'], 0)
    assert_equals(ism_fd.params['available_frags'], 0)
    assert_equals(ism_fd.params['frag_index'], 0)

test_IsmFD()

# Generated at 2022-06-22 07:14:38.990598
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # Test skip unavailable fragments
    params = {
        'skip_unavailable_fragments': True,
    }
    fragments = [
        {'url': 'http://example.com/fragment_1'},
        {'url': 'http://example.com/fragment_2'},
        {'url': 'http://example.com/fragment_3'},
    ]
    info_dict = {
        'format': 'ism',
        'protocol': 'mss',
        'fragments': fragments,
    }

    class MockYDL:
        def to_screen(self, msg):
            pass
        def report_warning(self, msg):
            pass
        def report_error(self, msg):
            pass


# Generated at 2022-06-22 07:14:49.754010
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import pytest
    info_dict = {'fragments': [{'url': "http://example.com"}]}

    expected_headers = {"Range": "bytes=0-"}

    content = b'<some content>'

# Generated at 2022-06-22 07:15:02.642567
# Unit test for function extract_box_data
def test_extract_box_data():
    ftyp_payload = b'isml'  # major brand
    ftyp_payload += u32.pack(1)  # minor version
    ftyp_payload += b'piff' + b'iso2'  # compatible brands
    ftyp_box = box(b'ftyp', ftyp_payload)

    test_data = ftyp_box + u32.pack(9) + b'moov'
    assert extract_box_data(test_data, [b'moov']) is None
    test_data = ftyp_box + u32.pack(9) + b'moov' + u64.pack(0)
    assert extract_box_data(test_data, [b'moov']) == test_data[17:]

# Generated at 2022-06-22 07:15:12.365316
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x0bpy\x00\x00\x00\x00' == box(b'py', b'')
    assert b'\x00\x00\x00\x04ftypmp42' == box(b'ftyp', b'mp42')

# Generated at 2022-06-22 07:15:24.270214
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Dummy info dict (a bit redundant with the params required below, but well)
    info_dict = {
        'fragments': [
            {
                'url': 'http://dummy/testfile.ismv'
            }
        ]
    }

    from hashlib import sha256

# Generated at 2022-06-22 07:15:39.437020
# Unit test for function full_box
def test_full_box():
    if(full_box('moov', 1, 0x1, u32.pack(0)) != b'moov\x00\x00\x00\x1c\x01\x00\x00\x00\x01\x00\x00\x00\x00'):
        raise Exception('result not match')

# Generated at 2022-06-22 07:15:51.708817
# Unit test for function extract_box_data
def test_extract_box_data():
    dref_payload = u32.pack(1)  # entry count
    dref_payload += full_box(b'url ', 0, SELF_CONTAINED, b'')  # Data Entry URL Box
    dref_data = full_box(b'dref', 0, 0, dref_payload)  # Data Reference Box

    stsd_payload = u32.pack(1)  # entry count
    stsd_payload += box(b'undf', b'')
    stsd_data = full_box(b'stsd', 0, 0, stsd_payload)  # Sample Description Box

    stbl_payload = stsd_data
    stbl_payload += full_box(b'stts', 0, 0, u32.pack(0))  # Decoding Time to Sample Box


# Generated at 2022-06-22 07:16:02.317429
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x08ftypmp42\x00\x00\x00\x00\x00\x00\x00\x00mp42isom' == box(b'ftyp', b'mp42isom')


# ADTS Constants and Utilities [ISO/IEC 13818-7]
SYNCWORD = 0xfff
MPEG_AUDIO_ID = 0  # MPEG-4 only
MPEG_AUDIO_LAYER_UNDEF = 0  # MPEG-4 only
MPEG_AUDIO_LAYER_2 = 2
MPEG_AUDIO_LAYER_3 = 3
AOT_AAC_MAIN = 1  # [MPEG-4 Part 3]
AOT_AAC_LC = 2  # [MPEG-4 Part 3]


# Generated at 2022-06-22 07:16:03.220296
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test = IsmFD({})
    assert test.FD_NAME == 'ism'

# Generated at 2022-06-22 07:16:08.712330
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b''.join((
        u32.pack(20), b'mbox',
        u32.pack(16), b'box2',
        u32.pack(12), b'box1',
        u32.pack(8), b'box0',
        u32.pack(4), b'box0',
    ))
    box_data = extract_box_data(data, (b'box0',))
    assert box_data == b'box0'
    box_data = extract_box_data(data, (b'box0', b'box1'))
    assert box_data == b''.join((
        u32.pack(8), b'box0',
        u32.pack(4), b'box0',
    ))

# Generated at 2022-06-22 07:16:17.195689
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test file mp4
    test_urls = []

# Generated at 2022-06-22 07:16:28.615307
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:16:31.010775
# Unit test for function full_box
def test_full_box():
    assert(full_box(b'moov', 1, 1, b'') == b'\x00\x00\x00\x0cmoov\x01\x00\x00\x00\x00\x00\x00\x01')


# Generated at 2022-06-22 07:16:36.738475
# Unit test for function full_box
def test_full_box():
    raw_data = full_box('stts', version=0, flags=0, payload='')
    assert len(raw_data) == 20
    assert raw_data[0:8] == b'\x00\x00\x00\x10\x73\x74\x74\x73'
    assert raw_data[8:12] == b'\x00\x00\x00\x00'
    assert raw_data[12:16] == b'\x00\x00\x00\x00'
    assert raw_data[16:20] == b'\x00\x00\x00\x00'



# Generated at 2022-06-22 07:16:46.864197
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {'track_id': 1, 'fourcc': 'H264', 'duration': 150000, 'height': 720, 'width': 1280, 'codec_private_data': '68ca9f14011200000fac100b840200001f4d0018617076170706c6191000468ee3c80'})

# Generated at 2022-06-22 07:17:05.496526
# Unit test for function write_piff_header
def test_write_piff_header():
    import unittest

    class WritePiffHeaderTest(unittest.TestCase):
        def test_write_piff_header(self):
            stream = io.BytesIO()
            params = {
                'track_id': 0,
                'fourcc': 'AACL',
                'duration': 10000,
                'timescale': 1000000,
                'channels': 2,
                'bits_per_sample': 16,
                'sampling_rate': 48000
            }
            write_piff_header(stream, params)

# Generated at 2022-06-22 07:17:16.328679
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'test'

        def __init__(self, downloader=None):
            super(TestIE, self).__init__(downloader)


# Generated at 2022-06-22 07:17:16.889634
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-22 07:17:25.641135
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 0, 0, b"") == b'moov\x00\x00\x00\x00'
    assert full_box(b'moov', 0, 1, b"") == b'moov\x00\x00\x00\x01'
    assert full_box(b'moov', 1, 0, b"") == b'moov\x00\x01\x00\x00'
    assert full_box(b'moov', 1, 1, b"") == b'moov\x00\x01\x00\x01'


# Generated at 2022-06-22 07:17:32.842026
# Unit test for function full_box
def test_full_box():
    #from https://github.com/ffmpeg/FFmpeg/blob/master/tests/fate/qtmux.mov
    assert full_box(b'moov', 0, 0, b'') == b'\x00\x00\x00\x0cmoov\x00\x00\x00\x00\x00\x00\x00'
    assert full_box(b'uuid', 1, 2, b'foobar') == b'\x00\x00\x00\x14uuid\x01\x00\x02\x00\x00foobar'

# Generated at 2022-06-22 07:17:34.156961
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:17:39.761510
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return IsmFD(params={'url': 'http://example.com/test.ism', 'filesize': 100000, 'test': True}).real_download(filename='test.mp4', info_dict={'fragments': [{'url': 'http://example.com/test.ism'}], '_download_params': {'track_id': 1, 'fourcc': 'AVC1', 'duration': 100, 'timescale': 100000, 'language': 'eng', 'height': 100, 'width': 100}})



# Generated at 2022-06-22 07:17:47.985015
# Unit test for function extract_box_data
def test_extract_box_data():
    with open('E:\\Test\\videoplayback.mp4', 'rb') as f:
        data = f.read()
        print(type(data))
    print(extract_box_data(data, (b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stsd', b'avc1', b'avcC')))

test_extract_box_data()

# Generated at 2022-06-22 07:17:59.170504
# Unit test for function full_box
def test_full_box():
    box_type = b"mvhd"
    version = 1
    flags = 0

# Generated at 2022-06-22 07:18:05.544145
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = {
        'track_id': 1,
        'sampling_rate': 48000,
        'bits_per_sample': 16,
        'channels': 1,
        'fourcc': 'AACL',
        'duration': int(time.time() * 10000000)
    }
    write_piff_header(fd, params)
    print(fd.getvalue())



# Generated at 2022-06-22 07:18:19.514571
# Unit test for function box
def test_box():
    assert box('abcd', 'efgh') == b'\x00\x00\x00\x0cabcd' + 'efgh'



# Generated at 2022-06-22 07:18:27.637460
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # dl = IsmFD(params={'url':'https://smoothstreaming.platform.silverlight.edgesuite.net/mediadownloader/smoothstreaming-duration-test-isml.isml/Manifest',
    #                   'test':True})
    dl = IsmFD(params={'url': 'https://smoothstreaming.platform.silverlight.edgesuite.net/mediadownloader/smoothstreaming-duration-test-isml.isml/Manifest'})
    print('dll init finished')
    print(dl)


# Generated at 2022-06-22 07:18:33.061010
# Unit test for function full_box
def test_full_box():
    box = full_box('ftyp', 0, 0, 'mp41')
    assert box == b'\x00\x00\x00\x10' + b'ftyp' + b'\x00' + b'\x00\x00\x00' + b'mp41'
test_full_box()


# Generated at 2022-06-22 07:18:44.965677
# Unit test for function write_piff_header
def test_write_piff_header():
    import sys
    import os
    import re
    import subprocess
    import tempfile
    from .download import download
    from .utils import read_iso639_2

    def get_qasf_header(file_name):
        pattern = re.compile(b'^FTYP.*?MVHD.*?moov.*?trak.*?mdia.*?minf.*?stbl.*?stsd.*?(mp4a|avc1).*?(esds|avcC).*?$', re.DOTALL)
        output = (subprocess.check_output(['qasf.exe', file_name])
                  if sys.platform == 'win32'
                  else subprocess.check_output('qasf', [file_name]))
        m = re.search(pattern, output)

# Generated at 2022-06-22 07:18:54.388043
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(24) + b'abcd' + u32.pack(12) + b'efgh' + u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'abcd', b'efgh')) == u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'efgh', b'abcd')) == u32.pack(4) + b'ijkl'
    assert extract_box_data(data, (b'abcd', b'abcd')) == u32.pack(12) + b'efgh' + u32.pack(4) + b'ijkl'



# Generated at 2022-06-22 07:18:54.768098
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD()

# Generated at 2022-06-22 07:19:00.669053
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    def test_content(test_params, params, expected_content, expected_exc_msg=None):
        test_params['track_id'] = 1
        test_params['duration'] = 1000
        test_params['timescale'] = 1000
        test_params['language'] = 'und'

# Generated at 2022-06-22 07:19:04.414257
# Unit test for function box
def test_box():
    assert box(b'xyzt', b'abcdef') == b'\x00\x00\x00\x10xyztabcdef'


# Generated at 2022-06-22 07:19:08.185996
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFDTest(IsmFD):
        """
        Constructor test for IsmFD
        """
        def download(self, filename, info_dict):
            return self.real_download(filename, info_dict)
    return IsmFDTest



# Generated at 2022-06-22 07:19:10.336091
# Unit test for function box
def test_box():
    assert box(b'aaa', b'bb') == u32.pack(8 + 2) + b'aaa' + b'bb'


# Generated at 2022-06-22 07:19:46.273687
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = [b'tsvc', b'tsvc', b'ccst']
    data = b'\x00\x00\x00\x0c' + b'tsvc' + b'\x00\x00\x00\x0c' + b'tsvc' + b'\x00\x00\x00\x0c' + b'ccst'
    assert extract_box_data(data, box_sequence) == b''


# Generated at 2022-06-22 07:19:55.649917
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from copy import copy

    def run_test(params):
        vid = io.BytesIO()
        write_piff_header(vid, params)
        return vid.getvalue()

    def get_video_params():
        params = DEFAULT_VIDEO_PARAMS.copy()
        params['duration'] = 360000000
        params['fourcc'] = 'H264'
        params['codec_private_data'] = '0164001fffe100bc674d401f2b84010e28f00a01e0039400000301000328f580410001200030f3e00fdd5'
        return params

    def get_audio_params():
        params = DEFAULT_AUDIO_PARAMS.copy()
        params['duration'] = 360000000

# Generated at 2022-06-22 07:20:05.717818
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:20:16.484527
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    #https://dash.akamaized.net/dash264/TestCases_Vectors/ClearCut_20120702/mp4box/bipbop_4x3_variant.mpd
    url = "https://dash.akamaized.net/dash264/TestCases_Vectors/ClearCut_20120702/mp4box/bipbop_4x3_variant.mpd"
    manifest_url = url
    manifest_url_stream = urlopen(manifest_url)
    manifest_url_stream_read = manifest_url_stream.read()
    manifest_url_stream.close()
    manifest = manifest_url_stream_read.decode('utf-8')
    manifest_doc = compat_etree_fromstring(manifest)

# Generated at 2022-06-22 07:20:24.113653
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .common import get_testdata_files_path
    from .common import download_files
    from .downloader import YoutubeDL
    with open(get_testdata_files_path() + 'ism/test.ism', 'rb') as stream:
        ism_manifest = stream.read()

# Generated at 2022-06-22 07:20:32.740735
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.params['username'] = 'garrettholliman'
    ydl.params['password'] = 'garrett200'

# Generated at 2022-06-22 07:20:43.684242
# Unit test for function extract_box_data
def test_extract_box_data():
    from .smoothstreams import SmoothStreamsTestRequestHandler, SmoothStreamsTestRequestHandler, SmoothStreamsTestRequestHandler, SmoothStreamsTestRequestHandler
    from .fragment import FragmentFD
    from ..compat import (
        compat_urllib_error,
        compat_urlparse,
    )
    from ..downloader.http import HEADRequest
    from ..utils import HEADRequestHandler
    from ..extractor.common import InfoExtractor
    from ..extractor.m3u8 import M3U8IE
    import random
    import socket
    import threading
    import uuid
    import BaseHTTPServer
    import urlparse
    import re
    import os
    import shutil
    import tempfile
    smooth_streams_test_server = SmoothStreamsTestRequestHandler
    fragment_fd = FragmentFD
   

# Generated at 2022-06-22 07:20:50.084335
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'test1', box(b'test2', box(b'test3', b'')))
    assert extract_box_data(data, (b'test1', b'test2')) == box(b'test3', b'')
    assert extract_box_data(data, (b'test1')) == box(b'test2', box(b'test3', b''))

# Generated at 2022-06-22 07:20:53.696936
# Unit test for constructor of class IsmFD
def test_IsmFD():
   ydl = YoutubeDL({})
   test_IsmFD = IsmFD(ydl)
   assert test_IsmFD.ydl == ydl
   assert test_IsmFD.fd_name == IsmFD.FD_NAME


# Generated at 2022-06-22 07:21:05.283927
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:21:57.122689
# Unit test for constructor of class IsmFD
def test_IsmFD():
    dummy_url = 'http://dummy.url/'
    dummy_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'duration': 10
    }
    dummy_f = IsmFD(dummy_url, dummy_params)
    assert dummy_f is not None


# Generated at 2022-06-22 07:22:05.535838
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    sys.setrecursionlimit(50000)

    list_url = "https://www.nasa.gov/multimedia/nasatv/NTV-Public-IPS.m3u8"
    #list_url = "https://raw.githubusercontent.com/rg3/youtube-dl/master/test/test-chop.m3u8"
    #list_url = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
    formats = {'default': [None, None]}
    params = {'fragment_retries': '10'}
    IsmFD().download([list_url], 'ISMVideo', formats, params)


if __name__ == '__main__':
    test_IsmFD_real_

# Generated at 2022-06-22 07:22:16.345183
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import urllib_error
    from .utils import prepare_filename
    ydl = FakeYDL()
    filenames = []
    for i, url in enumerate(['http://example.com/one', 'http://example.com/two']):
        class FakeIE(InfoExtractor):
            _VALID_URL = 'http://example.com/test'

# Generated at 2022-06-22 07:22:26.807534
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'channels': 2,
    }
    data = io.BytesIO()
    write_piff_header(data, params)
    data_hex = binascii.hexlify(data.getvalue())

# Generated at 2022-06-22 07:22:29.313642
# Unit test for function full_box
def test_full_box():
    assert full_box("moov","02","0000","01234567") == "0000000cmoov0001000001234567"

# Generated at 2022-06-22 07:22:31.392097
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == b'\x00\x00\x00\x0cmoov'


# Generated at 2022-06-22 07:22:38.072007
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    youtube_dl_instance = YoutubeDL({})
    youtube_dl_instance.cache = None
    test_IsmFD = IsmFD(youtube_dl_instance, {})
    assert test_IsmFD.real_download('filename', {'fragments': [{'url': 'url'}, {'url': 'url'}]}) == True


# Generated at 2022-06-22 07:22:49.352342
# Unit test for function extract_box_data
def test_extract_box_data():
    assert(extract_box_data(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', (b'\x00\x00\x00\x00',)) == None)
    assert(extract_box_data(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', (b'\x00\x00\x00\x01',)) == None)

# Generated at 2022-06-22 07:22:53.527118
# Unit test for function box
def test_box():
    assert box(b"ftyp",b"mp42") == b"\x00\x00\x00\x0c"+b"ftyp"+b"mp42"
    assert box(b"moov",b"mp42") == b"\x00\x00\x00\x0c"+b"moov"+b"mp42"



# Generated at 2022-06-22 07:23:03.077198
# Unit test for constructor of class IsmFD