

# Generated at 2022-06-22 07:13:54.829174
# Unit test for constructor of class IsmFD
def test_IsmFD():
    mpd_params = {
        'skip_unavailable_fragments': True,
        'fragment_retries': 10,
        'test': True,
        'track_id': 1,
        'language': 'eng',
        'height': 480,
        'width': 640,
        'codec_private_data': '0164001effe1001967640019ac4ce33c01010000030001000003000100',
        'fourcc': 'AVC1'
    }


# Generated at 2022-06-22 07:13:56.730194
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """ Single test for method real_download of class IsmFD"""
    # TODO: Implement
    pass

# Generated at 2022-06-22 07:14:05.684037
# Unit test for constructor of class IsmFD

# Generated at 2022-06-22 07:14:12.149005
# Unit test for function full_box
def test_full_box():
    #print('test_full_box')
    data = u8.pack(0)*2 + u32.pack(1) + u32.pack(0xFFFFFFFC) + b'DWD'
    size = len(data)
    data = u32.pack(size) + b'abcd' + data
    assert full_box(b'abcd', 0, 0xFFFFFFFC, b'DWD') == data
    assert full_box(b'abcd', 0, 1, b'DWD') == data
    #print('test_full_box passed!')


# Generated at 2022-06-22 07:14:23.977457
# Unit test for function write_piff_header
def test_write_piff_header():
    resultFile = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 9 * 10000000,
        'timescale': 10000000,
        'height': 480,
        'width': 640,
        'nal_unit_length_field': 4,
        'codec_private_data': '0164001fffe1002883280b98207696ffce1d0d7540001fac1649401f9e92c0003b24810c800',  # noqa
    }
    write_piff_header(resultFile, params)
    print(resultFile.getvalue().hex())


# Generated at 2022-06-22 07:14:32.620640
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    test_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 273592791,
        'timescale': 10000000,
        'language': 'und',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    write_piff_header(output, test_params)

# Generated at 2022-06-22 07:14:37.750861
# Unit test for function extract_box_data
def test_extract_box_data():
    extracted_data = extract_box_data(sample_file_data, (b'moov', b'mvhd'))
    assert extracted_data == sample_file_mvhd_data


# Generated at 2022-06-22 07:14:48.614803
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # Create an instance of IsmFD for testing
    ism_fd_0 = IsmFD()

    # Assign values to instance attributes of ism_fd_0
    ism_fd_0._prepare_and_start_frag_download = lambda ctx: None
    ism_fd_0._download_fragment = lambda ctx, url, info_dict: (None, None)
    ism_fd_0._append_fragment = lambda ctx, frag_content: None
    ism_fd_0._finish_frag_download = lambda ctx: None
    ism_fd_0.report_retry_fragment = lambda err, frag_index, count, fragment_retries: None
    ism_fd_0.report_skip_fragment = lambda frag_index: None


# Generated at 2022-06-22 07:14:50.872286
# Unit test for function full_box
def test_full_box():
    try:
        full_box("xxxx")
    except Exception as err:
        print("test_full_box : " + str(err))


# Generated at 2022-06-22 07:14:56.893725
# Unit test for function box
def test_box():
    test_box_type = 'reco'
    test_payload = 'test payload'
    assert box(test_box_type, test_payload) == '\x00\x00\x00\x14reco\x00\x00\x00\x0ctest payload'

ALL_BOXES = {}



# Generated at 2022-06-22 07:15:20.048512
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:15:21.113569
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass



# Generated at 2022-06-22 07:15:24.610743
# Unit test for function full_box
def test_full_box():
    fb = full_box(b"soma",1,0,u32.pack(0))
    assert u32.unpack(fb)[0] == 16
    assert u32.unpack(fb,4)[0] == 1


# Generated at 2022-06-22 07:15:28.732275
# Unit test for function box
def test_box():
    assert(box(b'mvhd',b'') == b'\x00\x00\x00\x0c\x6d\x76\x68\x64\x00\x00\x00\x00')



# Generated at 2022-06-22 07:15:36.639154
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Test whether the real_download method of class IsmFD works properly."""
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .http import HEADRequest
    from .common import urljoin
    from .compat import urlparse
    from .utils import match_filter_func
    from .compat import compat_str
    from .compat import compat_urllib_error
    import datetime
    
    
    

    
    # Step1: create a data object for IsmFD
    video_url = "http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest"
    extractor = IsmFD()

# Generated at 2022-06-22 07:15:41.368554
# Unit test for function full_box
def test_full_box():
    assert full_box(b'movx', 1, 1, b'abcdef') == b'\x00\x00\x00\x1c' + b'movx' + b'\x00' + b'\x00\x00\x01' + b'abcdef'



# Generated at 2022-06-22 07:15:52.088833
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        "track_id": 1,
        "fourcc": "H264",
        "duration": 10000000,
        "timescale": 10000000,
        "language": "eng",
        "height": 480,
        "width": 640,
        "codec_private_data": "01640029ffe1001a6764001fffe1001768ebecb22c",
        "nal_unit_length_field": 4
    }
    write_piff_header(stream, params)
    stream.seek(0)
    assert 0x66697470 == u32.unpack(stream.read(4))[0]  # 'ftyp'


# Generated at 2022-06-22 07:15:53.351940
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return


# Generated at 2022-06-22 07:15:58.215700
# Unit test for function box
def test_box():
    assert box(b'moov', b'') == binascii.unhexlify(b'000000006d6f6f76')
    assert box(b'moov', b'\xFF') == binascii.unhexlify(b'000000016d6f6f766fff')

# Only for unit testing

# Generated at 2022-06-22 07:16:02.757518
# Unit test for function full_box
def test_full_box():
    box_type = b"mdat"
    version = 0
    flags = 0x00000000
    payload = b"10000000"
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x10mdat\x00\x00\x00\x00\x10\x00\x00\x00'


# Generated at 2022-06-22 07:16:14.478887
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({}, {}, {}, {})

    assert fd.FD_NAME == 'ism'
    assert fd.params == {}



# Generated at 2022-06-22 07:16:26.102313
# Unit test for function write_piff_header
def test_write_piff_header():
    params_audio = {
        'track_id': 1,
        'fourcc': 'mp4a',
        'duration': 10000,
        'timescale': 10000000,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }

# Generated at 2022-06-22 07:16:32.346215
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('For Testing')
    # Test with some valid url
    url = 'http://127.0.0.1/ism.ism/Manifest'
    # Test with url = None
    url = None
    # Test with url not match
    url = 'http://127.0.0.1/'
    print('Test Constructor of IsmFD')
    print('url = ' + url)
    ismfd = IsmFD(url)
    print(ismfd)
    del ismfd

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:16:44.512060
# Unit test for function write_piff_header
def test_write_piff_header():
    _test = BytesIO()


# Generated at 2022-06-22 07:16:56.108478
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x12ftypavcml', (b'ftyp',)) == b'avcml'

# Generated at 2022-06-22 07:16:57.092893
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismFD = IsmFD('http://www.example.com')
    assert ismFD.params == {}

# Generated at 2022-06-22 07:16:57.480630
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-22 07:16:59.659126
# Unit test for function box
def test_box():
    assert box(b'abcd', b'sample payload') == b'\x00\x00\x00\x10abcdsample payload'


# Generated at 2022-06-22 07:17:00.800028
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return None

# Generated at 2022-06-22 07:17:05.059014
# Unit test for function box
def test_box():
    assert box('mdat', b'\xaa\xbb\xcc\xdd') == b'\x00\x00\x00\x10mdat\xaa\xbb\xcc\xdd'



# Generated at 2022-06-22 07:17:27.691872
# Unit test for function write_piff_header
def test_write_piff_header():
    """
    Run tests for function write_piff_header
    """
    from ..utils import encode_data_uri
    from io import BytesIO
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 100000,
        'codec_private_data': '000000016742E00D965C0024B6089D41C82042E100000000168EB7C8C',
    }
    stream = BytesIO()
    write_piff_header(stream, params)
    encoded_stream = encode_data_uri(stream.getvalue(), 'application/octet-stream')
    print(encoded_stream)

# Generated at 2022-06-22 07:17:32.500190
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_ism_url = 'http://ec2-23-22-76-101.compute-1.amazonaws.com/isml/Metallica-NothingElseMatters-1080p.ism/Manifest'
    real_IsmFD(test_ism_url, 'ism_test.ism')


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:17:40.198337
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ytdl.downloader import YoutubeDL
    from ytdl.extractor import gen_extractors
    from ytdl.PostProcessor import FFmpegMergerPP, FFmpegEmbedSubtitlePP
    from ytdl.Utils import make_HTTPS_handler
    from ytdl import FileDownloader
    from pathlib import Path
    from io import BytesIO

    def get_dest_filename(info_dict, format_id):
        filename = info_dict['title']
        ext = '.' + (info_dict.get('ext', 'mp4') or 'flv')
        filename = sanitize_filename(filename) + ext
        return filename

    output_template = Path('./output/%(title)s-%(id)s.%(ext)s')

# Generated at 2022-06-22 07:17:51.728768
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10,
        'timescale': 48000,
        'width': 1920,
        'height': 1080,
        'nal_unit_length_field': 4,
        'codec_private_data': '274280e14d9b2419134869400f1c4907f07b21e176c1843f003d69d6b2000000016742c01e4d4d4034d4d4034d4d4034d4d400000fa0b0b0f433cb6ce',
    }
    write_piff_header(stream, params)


# Generated at 2022-06-22 07:18:00.672613
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # initialization
    info_dict = {
      'fragments': [
        {
          'url': 'https://edge.api.brightcove.com/playback/v1/accounts/57838016001/videos/5769380284001/fragments/http_master.m3u8?videoId=5769380284001',
        },
      ],
    }
    params = {}
    output_path = 'test_download_output'
    filename = os.path.join(output_path, 'test_IsmFD_real_download.ism')
    test_fd = IsmFD(params, output_path, filename)

    # testing
    test_fd.real_download('test_output/test_IsmFD_real_download.ism', info_dict)


# Generated at 2022-06-22 07:18:02.276559
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD


# Generated at 2022-06-22 07:18:10.173096
# Unit test for function write_piff_header
def test_write_piff_header():
    with open('%s.mp4' % __name__, 'wb') as f:
        write_piff_header(f, dict(
            track_id=1,
            fourcc='avc1',
            duration=200000,
            timescale=100000,
            language='und',
            height=480,
            width=851,
            codec_private_data='000000016764001fffe100161616161610000000168ee3c80',
            nal_unit_length_field=4,
        ))

# Generated at 2022-06-22 07:18:22.256345
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:18:33.815402
# Unit test for constructor of class IsmFD
def test_IsmFD():

    # Prepare test data
    import copy
    test_data = copy.deepcopy(standard_initialize_test_data)
    test_data["fragments"] = test_data["fragments"][0:1]
    test_data["_download_params"]["duration"] = test_data["fragments"][0]["duration"]
    test_data["_download_params"]["track_id"] = 10000
    test_data["_download_params"]["fourcc"] = "AACL"
    test_data["_download_params"]["sampling_rate"] = 44100
    test_data["_download_params"]["channels"] = 2
    test_data["_download_params"]["bits_per_sample"] = 16

    # Execute test

# Generated at 2022-06-22 07:18:38.946026
# Unit test for function write_piff_header
def test_write_piff_header():
    with FragmentFD() as f:
        params = {
            'track_id' : 1,
            'duration' : 1000000,
            'fourcc' : 'AACL',
            'channels' : 2,
            'bits_per_sample' : 16,
            'sampling_rate' : 48000
        }
        write_piff_header(f, params)
        return f.read()


# Generated at 2022-06-22 07:19:22.774632
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    ie = gen_extractors(ydl, [u'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism'])[0]
    res = ie.extract(u'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism')
    assert 'formats' in res
    f = res['formats'][0]
    assert f['format_id'] == 'ism'
    assert f['protocol'] == 'm3u8_native'

# Generated at 2022-06-22 07:19:29.816678
# Unit test for function write_piff_header
def test_write_piff_header():
    if not True:
        # Disable unit test in current context
        return

    fourcc = 'avc1'
    params = {'track_id': 1, 'fourcc': fourcc, 'duration': 60000000, 'timescale': 90000, 'language': 'xx', 'width': 1280, 'height': 720, 'codec_private_data': '0164001ffe10017674d40014f965604001e94101e9403003c03801c2000000016764001ca4dd308087e943080'}
    stream = io.BytesIO()
    write_piff_header(stream,params)
    stream.seek(0)
    with open('write_piff_header.piff', 'wb') as file:
        file.write(stream.read())


# Generated at 2022-06-22 07:19:32.802645
# Unit test for function box
def test_box():
    assert box(b'abcd', b'xyz') == b'\x00\x00\x00\nabcdxyz'
test_box()


# Generated at 2022-06-22 07:19:38.298566
# Unit test for function full_box
def test_full_box():
    _payload = u8.pack(0) + u32.pack(0xFF)[1:]
    _full = u32.pack(8 + len(_payload)) + b'free' + _payload
    assert full_box(b'free', 0, 0xFF, _payload) == _full



# Generated at 2022-06-22 07:19:42.876404
# Unit test for function full_box
def test_full_box():
    print('Running unit test for function full_box')
    ret = full_box(b'moov', 1, 0, b'abc')
    expected = u32.pack(12) + b'moov' + u8.pack(1) + u32.pack(0)[1:] + b'abc'
    assert ret == expected
    print('PASSED')
    return 0


# Generated at 2022-06-22 07:19:51.064157
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:20:02.878667
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x10mp4a\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x02\x00\x00\x00\x0cavcC\x00\x00\x00\x00\x00\x00\x01\x02\x00\x00\x00\x0cmp4a\x00\x00\x00\x00\x00\x00\x01\x02\x00\x00\x00\x0c'
    extracted_data = extract_box_data(data, [b'mp4a', b'avcC'])

# Generated at 2022-06-22 07:20:14.224368
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = FakeYtdl(params={
        'quiet': True,
        'writeinfojson': True,
        'outtmpl': os.path.join(os.path.dirname(__file__), '%(id)s.%(ext)s'),
        'noplaylist': True,
    })

    # TEST 1: Download of ismv for YouTube short video
    ok = downloader.download(['http://video.ch9.ms/ch9/2a76/566b4875-e34c-45f5-acb5-1ff92a762a76/Windows10HowToMixedReality_ch9.ism/manifest'])
    assert ok, 'Download of ismv failed'

    # TEST 2: Download of isma for YouTube long video

# Generated at 2022-06-22 07:20:17.929640
# Unit test for function full_box
def test_full_box():
    assert full_box(b'maoo',0,0,b'NULL') == b'\x00\x00\x00\nmaoo\x00\x00\x00\x00NULL'


# Generated at 2022-06-22 07:20:20.197335
# Unit test for function full_box
def test_full_box():
    assert(full_box(b'moov', 1, 0, b'') == b'\x00\x00\x00\x0cmoov\x01\x00\x00\x00')
