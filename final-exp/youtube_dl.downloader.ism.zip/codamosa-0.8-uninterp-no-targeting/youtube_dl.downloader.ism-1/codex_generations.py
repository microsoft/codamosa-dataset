

# Generated at 2022-06-22 07:13:59.114095
# Unit test for function box
def test_box():
    assert ''.join(x.encode('hex') for x in
        box('mvhd', u32.pack(0) * 3 + u64.pack(0) * 2 + u32.pack(0x00010000) + u32.pack(10000) + u32.pack(0x0100) + u16.pack(0) + u16.pack(1) + u32.pack(0) * 2 + u32.pack(0x00010000) * 2 + u32.pack(0) * 6)) == '0000006d6d76686400000000010000000100000001000003e8030000014d9400000100000000010000000000000100000000000000000000000000000000000000010000000000000000000000000000000000000100000000000000000000000000000000000001000000000000000000000014d94000001010000'



# Generated at 2022-06-22 07:14:07.375754
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    def _download_fragment(self, ctx, fragment_url, info_dict):
        return True, 'test_res'

    IsmFD._download_fragment = _download_fragment

    obj = IsmFD(None)

    class Options(object):
        def __init__(self):
            self.test = False
    obj.params = Options()
    obj.report_skip_fragment = lambda x: None
    obj.report_retry_fragment = lambda x, y, z, w: None


# Generated at 2022-06-22 07:14:19.182175
# Unit test for function box

# Generated at 2022-06-22 07:14:31.385874
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    url = "http://a1518.v1949e.c1949.g.vm.akamaistream.net/7/1518/1949/1d259e9f/1a1a1e3e/ecv.isml/ecv-audio=96000-video=300000-9fc4f4b4.ism/manifest"
    for ie in gen_extractors():
        if ie.suitable(url) and ie.IE_NAME == 'ism':
            break
    else:
        # no suitable info extractor
        return
    info = ie.extract(url)

# Generated at 2022-06-22 07:14:43.109337
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Currently, this unit test works only on Windows operating system.
    if sys.platform.startswith('win'):
        # Video: MP4, 640x360, 30 fps, video only, 6.2 MB
        ydl_opts = {
            'skip_download': True,
            'simulate': True,
            'quiet': True,
            'writesubtitles': False,
            'writeautomaticsub': False,
            'skip_unavailable_fragments': False,
            'outtmpl': 'test_temp.%(ext)s',
        }
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            # This youtube_dl option is required in order to use the IsmFD
            ydl.params['youtube_include_dash_manifest'] = False
           

# Generated at 2022-06-22 07:14:49.604845
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Description: method real_download of class IsmFD is not a function. It is a method of a class, whose first argument must be the class instance.
    """
    ismfd = IsmFD()

    def real_download(self, filename, info_dict):
        pass
    ismfd.real_download = real_download
    #ismfd.real_download(filename, info_dict)


# IsmFD is a subclass of FragmentFD

# Generated at 2022-06-22 07:14:55.881513
# Unit test for function box
def test_box():
    assert box(b'foo', b'bar') == b'\x00\x00\x00\x0bfoobar'
    assert box(b'foo', b'') == b'\x00\x00\x00\tfoo'
    assert box(b'foo', b'a' * 100) == b'\x00\x00\x00`foo' + b'a' * 100


# Generated at 2022-06-22 07:15:07.652833
# Unit test for function write_piff_header
def test_write_piff_header():
    file = io.BytesIO()

# Generated at 2022-06-22 07:15:12.380190
# Unit test for function box
def test_box():
    b = box(b'moov', b'payload')
    assert u32.unpack(b[:4])[0] == len(b)
    assert b[4:8] == b'moov'
    assert b[8:] == b'payload'



# Generated at 2022-06-22 07:15:16.179172
# Unit test for function full_box
def test_full_box():
    assert full_box(b'ftyp', 1, 0, b'amfv') == b'\x00\x00\x00\x0cftyp\x01\x00\x00\x00amfv'

# Generated at 2022-06-22 07:15:31.923594
# Unit test for function box
def test_box():
    assert box('abcd', '12345678') == b'\x08\x00\x00\x00abcd12345678'
    assert box('abcd', '123') == b'\x0b\x00\x00\x00abcd123\x00\x00\x00'


# Generated at 2022-06-22 07:15:38.009354
# Unit test for function full_box
def test_full_box():
    box_type = b"abcd"
    version = 0
    flags = 0
    payload = b"01234567"
    lower = u32.pack(len(box_type) + 8 + len(payload)) + box_type + u8.pack(version) + u32.pack(flags)[1:] + payload
    upper = full_box(box_type, version, flags, payload)
    assert(lower == upper)
    return
test_full_box()



# Generated at 2022-06-22 07:15:41.964197
# Unit test for function box
def test_box():
    assert box('abcd', 'abcdabcdabcdabcd') == b'\x00\x00\x00\x00\x00\x00\x00\x14abcdabcdabcdabcd'



# Generated at 2022-06-22 07:15:44.832686
# Unit test for function box
def test_box():
    assert binascii.unhexlify('00000014667479707174202020000000') == box(b'ftyp', b'qt   ')



# Generated at 2022-06-22 07:15:47.929051
# Unit test for function box
def test_box():
    assert box('mvhd', 'payload') == b'\x00\x00\x00\x0Fmvhdpayload'



# Generated at 2022-06-22 07:15:53.698082
# Unit test for function full_box
def test_full_box():
    payload = u8.pack(0) + u32.pack(0)[1:]
    if b'testBoxType' not in full_box(b'testBoxType',0,0,payload):
        return False
    if len(full_box(b'testBoxType',0,0,payload)) != 16:
        return False
    return True


# Generated at 2022-06-22 07:15:58.509156
# Unit test for function box
def test_box():
    assert b'\x00\x00\x00\x00\x66\x74\x79\x70\x71\x74\x20\x00\x00\x00\x00' == box(b'moov', b'\x71\x74\x20\x00\x00\x00')

# Generated at 2022-06-22 07:16:00.370333
# Unit test for function full_box
def test_full_box():
	assert full_box('ftyp',0,0,'') == '\x00\x00\x00\x0cftyp\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-22 07:16:11.330662
# Unit test for function full_box
def test_full_box():
    box_type = 'mvhd'
    version = 0
    flags = 0
    payload = u32.pack(0)+ u32.pack(0)
    payload = payload + unity_matrix + u32.pack(0)+ u32.pack(0)
    payload = payload + u32.pack(0)+ u16.pack(1)+ u16.pack(0)
    payload = payload + u32.pack(0)+ u32.pack(0) + u32.pack(0)
    payload = payload + u32.pack(0) + u32.pack(0x10000)+ u32.pack(0)
    payload = payload + u32.pack(0) + u32.pack(0x10000) + u32.pack(0)

# Generated at 2022-06-22 07:16:21.017275
# Unit test for function write_piff_header
def test_write_piff_header():
    import sys
    from ..utils import make_http_requests
    my_output_stream = io.BytesIO()

# Generated at 2022-06-22 07:16:54.293063
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test PIFF MPEG-4 audio
    stream = io.BytesIO()
    params = {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 2000000000,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'channels': 2,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:16:56.824804
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = ''.join([
        u32.pack(len(x) + 8),
        x
    ])
    box_sequence = ['moov', 'trak', 'mdia', 'minf', 'stbl', 'stsd', 'avc1', 'avcC']
    assert box_sequence[-1] == str(extract_box_data(box_data, box_sequence))



# Generated at 2022-06-22 07:17:00.864340
# Unit test for function box
def test_box():
    assert box('mvhd', '') == b'\x00\x00\x00\x00mvhd'
    assert box('mvhd', 'test') == b'\x00\x00\x00\x08mvhdtest'



# Generated at 2022-06-22 07:17:04.766473
# Unit test for function box
def test_box():
    assert(box(b'\x00\x00\x00\x00', b'') == b'\x00\x00\x00\x08\x00\x00\x00\x00')



# Generated at 2022-06-22 07:17:15.703452
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'codec_private_data': '010203',
        'height': 720,
        'width': 1280,
    }
    write_piff_header(fd, params)

# Generated at 2022-06-22 07:17:25.489852
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    import binascii

    # This is a AVI video file but with a dummy avi header and the actual avi structure is into the "JUNK" chunk.

# Generated at 2022-06-22 07:17:34.689587
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-22 07:17:39.294356
# Unit test for function box
def test_box():
    binary_data = box(b'ftyp', b'-3g6\x00\x00\x00\x01-3g6\x00\x00\x00\x01isomiso2avc1mp41')
    assert binary_data == binascii.unhexlify(b'1866747970263367360010013267360010016973006f6d00690073006f00320061007600630031006d007000340031')
# End unit test for function box



# Generated at 2022-06-22 07:17:40.440826
# Unit test for function box
def test_box():
    assert box(b'moov', b'acbd') == b'\x00\x00\x00\x0cmoovacbd'


# Generated at 2022-06-22 07:17:45.918859
# Unit test for function box
def test_box():
    from . import boxes
    print(box(boxes.BOX_mdat, b'abc')) == b'\x00\x00\x00\x0bmdatabc'



# Generated at 2022-06-22 07:18:14.091766
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    _test_IsmFD_real_download(test_IsmFD_real_download.__name__)



# Generated at 2022-06-22 07:18:15.501092
# Unit test for function box
def test_box():
    return None

# Generated at 2022-06-22 07:18:19.874664
# Unit test for function full_box
def test_full_box():
    fbox = full_box('test','1','1','1')
    print(fbox)
    assert(fbox == '\x00\x00\x00\x09test\x01\x01\x00\x00\x00\x01')


# Generated at 2022-06-22 07:18:31.543366
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']


# Generated at 2022-06-22 07:18:38.239977
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
        Unit test for constructor of class IsmFD
    """
    url = 'https://mediadl.microsoft.com/mediadl/iisnet/c1/Manifest(format=mpd-time-csf)'
    ism_fd = IsmFD(url, {'test':False})
    ism_fd.real_download('test.mp4', {})

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:18:50.294261
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .ism import IsmFD
    from .ism import extract_box_data
    import io
    import binascii
    # test for method _download_fragment of class IsmFD

# Generated at 2022-06-22 07:18:55.624312
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('start test_IsmFD')
    params = {'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
              'playlist_id': '0',
              'output': '/tmp/test_IsmFD.ismv'}
    ismfd = IsmFD(params)
    print('end test_IsmFD')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:19:02.212752
# Unit test for function full_box
def test_full_box():
    box_type = b'abcd'
    version = 0
    flags = 0
    payload = b'1234'
    f = lambda: False
    assert full_box(box_type, version, flags, payload) == b'\x00\x00\x00\x0cabcd\x00\x00\x00\x00\x00\x1234'
    try:
        full_box(box_type, version, flags, f)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-22 07:19:08.916986
# Unit test for constructor of class IsmFD
def test_IsmFD():
    module = sys.modules[__name__]
    for attr_name in ['FragmentFD', 'F4mFD']:
        module_attr = getattr(module, attr_name, None)
        if module_attr:
            break
    assert module_attr is not None, 'Cannot find a suitable super class'
    IsmFD.__bases__ = (module_attr,)


# For convenience, Register IsmFD as a supported downloader
f4m.add_downloader(IsmFD)

# Generated at 2022-06-22 07:19:20.942378
# Unit test for function write_piff_header
def test_write_piff_header():
    import json
    from .mp4 import write_mfhd
    from .mp4 import write_tfhd
    from .mp4 import write_trun
    from .mp4 import write_tfdt
    from .mp4 import write_sdtp
    from .mp4 import write_sidx
    from .mp4 import write_moof
    from .mp4 import write_mdat
    f = io.BytesIO()

# Generated at 2022-06-22 07:20:30.208622
# Unit test for function write_piff_header
def test_write_piff_header():
    from .download import fragment_retrieve_rendition_key
    from .crypto import aes_decrypt_text
    import random
    stream = io.BytesIO()

# Generated at 2022-06-22 07:20:30.754466
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-22 07:20:34.516216
# Unit test for function box
def test_box():
    assert box(b'moov', b'abc') == b'\x00\x00\x00\x0bmoovabc'



# Generated at 2022-06-22 07:20:44.828300
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'moov\x00\x00\x00\x00trak\x00\x00\x00\x00mdia\x00\x00\x00\x00minf\x00\x00\x00\x00', [b'moov', b'trak', b'mdia', b'minf']) == b''
    try:
        extract_box_data(b'moov\x00\x00\x00\x00trak\x00\x00\x00\x00mdia\x00\x00\x00\x00minf\x00\x00\x00\x00', [b'moov', b'pfof', b'mdia', b'minf'])
    except AssertionError:
        pass

# Generated at 2022-06-22 07:20:49.984853
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mdhd', 0, 0, b'') == b'\x00\x00\x00\x0cmdhd\x00\x00\x00\x00\x00\x00\x00'
    
    

# Generated at 2022-06-22 07:20:53.947063
# Unit test for function full_box
def test_full_box():
    assert full_box(b'a', 1, 2, b'abc') == box(b'a', u8.pack(1) + u32.pack(2)[1:] + b'abc')
# (End) of unit test for function full_box



# Generated at 2022-06-22 07:21:01.156543
# Unit test for function extract_box_data
def test_extract_box_data():
    piff_header = {
        'track_id': 1,
        'duration': 23.99,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'fourcc': 'AACL',
    }
    data = io.BytesIO()
    write_piff_header(data, piff_header)
    data.seek(0)
    avcc = extract_box_data(data.read(), (b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stsd', b'mp4a', b'esds', b'dec3'))
    assert u32

# Generated at 2022-06-22 07:21:12.199945
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x28moov\x00\x00\x00\x30trak\x00\x00\x00\x28mdia\x00\x00\x00\x30minf\x00\x00\x00\x18stbl'
    assert extract_box_data(test_data, (b'moov', b'trak', b'mdia', b'minf')) == b'\x00\x00\x00\x18stbl'
    try:
        extract_box_data(test_data, (b'moov', b'trak', b'mdia', b'minf'))
        # If succeed, there must be a bug in this function
        assert False
    except AssertionError:
        raise

# Generated at 2022-06-22 07:21:16.326828
# Unit test for function box
def test_box():
    assert box(b'mvhd', b'\x00' * 10) == b'\x00\x00\x00\x1c' + b'mvhd' + b'\x00' * 10
# End of unit test for function box



# Generated at 2022-06-22 07:21:20.944464
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    path = os.path.dirname(
        os.path.realpath(__file__)) + '/test_data/test_fragment_downloading.py'

    lines = ''
    with open(path) as test_data:
        lines = test_data.readlines()

    for line in lines[1:]:
        exec(line, globals())


# Generated at 2022-06-22 07:22:47.204603
# Unit test for function full_box
def test_full_box():
    version = 0
    flags = 0
    payload = "payload"
    assert full_box("box_type", version, flags, payload) == "\x00\x00\x00\x0cbox_type\x00\x00\x00payload"



# Generated at 2022-06-22 07:22:51.349819
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Url of the file to test
    url='http://localhost/ism/fragments'
    # Name of the file to download
    path='test'
    # Testing download
    IsmFD().real_download(path, {'fragments':[{'url':url},{'url':url}]})
    # Testing fail download
    IsmFD().real_download(path, {'fragments':[{'url':'http://localhost/ism/fail'},{'url':'http://localhost/ism/fail'}]})

if __name__ == "__main__":
    test_IsmFD_real_download()

# Generated at 2022-06-22 07:23:02.113397
# Unit test for function extract_box_data
def test_extract_box_data():
    assert (
        extract_box_data(
            b'test\xa3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
            (b'test',)) ==
        b'\xa3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    assert (
        extract_box_data(
            b'test\xac\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
            (b'test',)) ==
        b'')

# Generated at 2022-06-22 07:23:14.106959
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialize test parameter
    url = 'http://localhost/manifest.isml/manifest(format=mpd-time-csf)'
    real_download_params = {'protocol':'mss',
                            'manifest_url': url,
                            'fragment_base_url': url,
                            'include_filter': [720],
                            'outtmpl': '/tmp/download.mp4',
                            'format': 'mpd-time-csf',
                            'retries': 10,
                            'test': True,
                            'savevideoinfo': True,
                            'skip_unavailable_fragments': True}

    # Initialize test object and download video
    downloader = IsmFD(None, None, None, None, real_download_params)
    # Prepare fragment download

# Generated at 2022-06-22 07:23:16.511212
# Unit test for function box
def test_box():
    assert box('abcd', 'ABCD') == b'\x00\x00\x00\x10abcdABCD'



# Generated at 2022-06-22 07:23:20.222086
# Unit test for function box
def test_box():
    expect = b'\x00\x00\x00\x0cftypmp42\x00\x00\x00\x00mp42'
    actually = box(b'ftyp', b'mp42mp42')
    print(expect)
    print(actually)
    assert expect == actually



# Generated at 2022-06-22 07:23:29.593147
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test Case
    # - Test Case
    #   - ism
    #   - ism
    path_to_data_file = '/home/michael/Downloads/inBigData/mp4_repo/ism/ism/michael-mimoun-2.ism'
    with open(path_to_data_file, 'rb') as f:
        manifest = f.read().decode('utf-8')
    format = 'ism'

# Generated at 2022-06-22 07:23:40.677074
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Setup test variables
    info_dict = {}
    filename = None
    segments = [
        {
            'url': 'http://ns354444.ip-94-23-34.eu/vod/bipbopall.ism/Manifest'
        },
        {
            'url': 'http://ns354444.ip-94-23-34.eu/vod/bipbopall.ism/QualityLevels(400000)/Fragments(video=700000-701000)'
        }
    ]
    info_dict['fragments'] = segments

    # Test
    fd = IsmFD()
    assert fd.real_download(filename, info_dict) == True

