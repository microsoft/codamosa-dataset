

# Generated at 2022-06-22 07:13:55.217111
# Unit test for function box
def test_box():
    assert box(b'payl', b'oad') == b'\x00\x00\x00\x0c' + b'payl' + b'oad'
# End of Unit test for function box



# Generated at 2022-06-22 07:14:04.794187
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:14:15.158778
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(u32.pack(8) + b'mvhd' + u16.pack(0), [b'mvhd']) == u16.pack(0)
    assert extract_box_data(u32.pack(10) + b'mvhd' + u16.pack(0) + b'foo', [b'mvhd', b'foo']) == b''
    assert extract_box_data(u32.pack(8) + b'sthd' + u16.pack(0), [b'mvhd']) == None
    assert extract_box_data(u32.pack(8) + b'mvhd' + u32.pack(8) + b'foo', [b'mvhd', b'foo']) == None

# Generated at 2022-06-22 07:14:25.321481
# Unit test for function write_piff_header
def test_write_piff_header():
    test_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 20000000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'language': 'eng'
    }

    stream = io.BytesIO()
    write_piff_header(stream, test_params)

    out = stream.getvalue()
    assert b'ftyp' in out
    assert b'moov' in out
    assert b'trak' in out
    assert b'mdia' in out
    assert b'minf' in out
    assert b'stbl' in out
    assert b'stsd' in out
    assert b'smhd' in out
    assert b'hdlr' in out

# Generated at 2022-06-22 07:14:36.507209
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:47.593774
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:14:59.918666
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    stream = io.BytesIO()

# Generated at 2022-06-22 07:15:11.573841
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import shutil
    import os
    from .common import InfoDict
    from .compat import compat_urllib_error
    from .downloader import FragmentFD
    from .utils import (
        HEADRequest,
        prepend_extension,
    )

    class IsmFD(FragmentFD):

        def _prepare_and_start_frag_download(self, ctx):
            ctx['dest_stream'] = io.open(self.filename, 'wb')
            ctx['fragment_index'] = 1
            ctx['filename'] = prepend_extension(self.filename, 'frag')


# Generated at 2022-06-22 07:15:23.438733
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO

    # Test for audio PIFF
    with BytesIO() as stream:
        test_input = {
            'track_id': 1,
            'fourcc': 'AACL',
            'sampling_rate': 48000,
            'height': 0,
            'width': 0,
            'duration': 123456789,
        }
        write_piff_header(stream, test_input)
        data = stream.getvalue()
        assert len(data) == 424
        assert data.startswith(u32.pack(424))
        assert data[4:8] == b'moov'

    # Test for video PIFF

# Generated at 2022-06-22 07:15:33.854030
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x0cmoov\x00\x00\x00\x0c\x00\x00\x00\rfree\x00\x00\x00\r\x00\x00\x00\x0cskip\x00\x00\x00\x0c'
    assert extract_box_data(test_data, (b'moov',)) == b'\x00\x00\x00\x0cfree\x00\x00\x00\r\x00\x00\x00\x0cskip\x00\x00\x00\x0c'
    assert extract_box_data(test_data, (b'free',)) == b''



# Generated at 2022-06-22 07:15:48.702974
# Unit test for function box
def test_box():
    assert box(b'moov', b'test') == b'\x00\x00\x00\x0cmoovtest'

# Generated at 2022-06-22 07:15:57.409325
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AVC1',
            'duration': 10000000,
            'sampling_rate': 48000,
            'codec_private_data': '0000000167640033ACD22C801B80010000003010800000030080001079A65FC00000001681EFAE01800C00080810008000100000168E06FFE3000200',
            'width': 640,
            'height': 360,
        }

        write_piff_header(stream, params)

# Generated at 2022-06-22 07:16:02.581319
# Unit test for function write_piff_header
def test_write_piff_header():
    payload = io.BytesIO()
    write_piff_header(payload, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640032ffec82808d0d537a586b4c4bde9e00f01100000320010a45f7e4340114d801f7e420011400010022c07b8abc5380300010004640032ac028080',
    })

# Generated at 2022-06-22 07:16:08.198985
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    from .smoothstreams import SmoothStreamsFD
    import yaml

    yaml_text = open('test_data/smoothstreams_playlist.yaml', 'r').read()
    testdata = yaml.load(yaml_text)

    params = {'source_url': testdata['info_dict']['source_url']}
    info_dict = testdata['info_dict']
    sub_params = {}
    sub_params['filename'] = testdata['sub_params']['filename']

    smoothstreams = SmoothStreamsFD(sub_params, params)
    info_dict = smoothstreams.extract(smoothstreams.params['source_url'])

    filename = 'ism_saved_video.ism'

# Generated at 2022-06-22 07:16:16.936492
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
# Test case 1: playlist_id=86
    filename = 'ism_86.ism'

# Generated at 2022-06-22 07:16:28.361792
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264',
              'codec_private_data': '6764001EAC2B40282752B900FA0175308D',
              'sampling_rate': 44100, 'channels': 2,
              'bits_per_sample': 16, 'duration': 8000000000}
    write_piff_header(f, params)

# Generated at 2022-06-22 07:16:35.955537
# Unit test for function extract_box_data
def test_extract_box_data():
    import os
    test_file_path = os.path.join(os.path.dirname(__file__), 'test_extract_box_data.m4s')
    with open(test_file_path, 'rb') as f:
        data = f.read()
    extracted_data = extract_box_data(data, (b'moof', b'mdat'))

# Generated at 2022-06-22 07:16:38.732235
# Unit test for function box
def test_box():
    assert box('abcd', '0123456789') == b'\x00\x00\x00\x12abcd0123456789'



# Generated at 2022-06-22 07:16:43.579981
# Unit test for function extract_box_data
def test_extract_box_data():
    # data
    assert extract_box_data(b'\x00\x00\x00\x1cftyp\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00ismlpiffiso2', [b'moov']) == None

# Generated at 2022-06-22 07:16:47.244478
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(0x10) + b'moov' + u32.pack(0x18) + b'mvhd' + u32.pack(0x1) + u32.pack(0x2c) + u32.pack(0x3)
    assert u32.unpack(extract_box_data(data, [b'moov', b'mvhd']))[0] == 0x2c


# Generated at 2022-06-22 07:17:14.923368
# Unit test for function box
def test_box():
    payload = b'test'
    box('test', payload)
    pass


# Generated at 2022-06-22 07:17:18.561143
# Unit test for constructor of class IsmFD
def test_IsmFD():
    manifest = 'https://testmanifest.azureedge.net/bbb/bbb.ism/Manifest'
    params = {'fragment_retries': 0, 'skip_unavailable_fragments': True}
    ismFD = IsmFD(params, manifest)
    assert ismFD is not None



# Generated at 2022-06-22 07:17:22.224431
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # fd = IsmFD()
    # filename = 'demo.ismv'
    # info_dict = 'demo.ism'
    # fd.real_download(filename, info_dict)
    return True
test_IsmFD_real_download()


# Generated at 2022-06-22 07:17:24.770675
# Unit test for constructor of class IsmFD
def test_IsmFD():
    FD_Ism = IsmFD()


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:17:29.959970
# Unit test for function box
def test_box():
    assert b"\x00\x00\x00\x0cfoobar" == box(b"foob", b"ar")
    assert b"\x00\x00\x00\x01foobar" == box(b"foob", b"")
    assert b"\x00\x00\x00\x0cfoobar" == box(b"foobar", b"")


# Generated at 2022-06-22 07:17:38.309039
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # DO NOT MODIFY
    import os
    import sys
    #sys.path.append('D:\zur\ytdl.git\youtube_dl\youtube_dl')
    print(os.getcwd())
    from .kaltura_downloader import info_dict
    from .kaltura_downloader import downloader_params
    from .kaltura_downloader import test_IsmFD_real_download
    from .kaltura_downloader import test_IsmFD_real_download_segments

    segments = test_IsmFD_real_download_segments()
    info_dict = test_IsmFD_real_download_info_dict()
    downloader_params = test_IsmFD_real_download_downloader_params()

    info_dict['_download_params'] = downloader_

# Generated at 2022-06-22 07:17:50.555967
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("Test for real_download of class IsmFD")
    # Initialization of variables
    manifest_url = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    extract_audio = False
    expected_result = True
    ydl_options = {}
    ydl = YoutubeDL(ydl_options)
    # Necessary files and dirctory
    io.open('test', 'wb').close()
    # Test steps
    print("Start testing...")
    print("Initialize class IsmFD")

# Generated at 2022-06-22 07:17:58.882848
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov' + b'trak' + b'mdia' + b'minf' + b'stbl' + b'stsd' + b'avc1' + u8.pack(0) * 6
    if extract_box_data(data, [b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stsd', b'avc1']) != u8.pack(0) * 6:
        raise RuntimeError('test_extract_box_data failed')


test_extract_box_data()



# Generated at 2022-06-22 07:18:10.279952
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from pprint import pprint

    def _test_audio_piff_header(params):
        stream = BytesIO()
        write_piff_header(stream, params)
        stream.seek(0)
        boxes = []
        while True:
            data = stream.read(u32.size)
            if not data:
                break
            size = u32.unpack(data)[0]
            box_type = stream.read(4)
            if size == 1:
                size = u64.unpack(stream.read(u64.size))
            box_data = stream.read(size - u32.size - len(box_type))
            boxes.append((box_type, box_data))
        return boxes


# Generated at 2022-06-22 07:18:15.688357
# Unit test for function full_box
def test_full_box():
    assert full_box(b'test', 1, 0x1FF, b'string') == b'\x00\x00\x00\x0f' + b'test' + b'\x01' + b'\xff\xff\xff\xff' + b'string'



# Generated at 2022-06-22 07:19:23.409991
# Unit test for function full_box
def test_full_box():
    """
    >>> full_box('mdat'.encode(), 0, 0, 'I am a box'.encode())
    b'\\x00\\x00\\x00\\x14mdat\\x00\\x00\\x00\\x00I am a box'
    """
    pass



# Generated at 2022-06-22 07:19:28.831020
# Unit test for function full_box
def test_full_box():
    msg = 'dummy'
    box_type = b'moov'
    version = 0
    flags = 0
    expected = b'\x00\x00\x00\x0Cmoov\x00\x00\x00\x00'
    actual = full_box(box_type, version, flags, msg)
    assert actual == expected


# Generated at 2022-06-22 07:19:32.467928
# Unit test for function box
def test_box():
    assert box('ftyp', 'isom') == b'\x00\x00\x00\x0cftypisom'

# Note: In Python 2.6, struct.pack and struct.unpack don't handle long numbers

# Generated at 2022-06-22 07:19:38.778954
# Unit test for function full_box
def test_full_box():
    assert b'\x00\x00\x00\x10\x66\x74\x79\x70\x6d\x70\x34\x32\x00\x00\x00\x00\x6d\x6f\x6f\x76' ==  full_box(b'ftyp', 0, 0, b'mp42')

# Generated at 2022-06-22 07:19:47.608548
# Unit test for function extract_box_data

# Generated at 2022-06-22 07:19:56.328572
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import blackbox
    from os.path import join
    from copy import deepcopy
    from .utils import (
        determine_ext,
        fix_html_entities,
    )
    from .extractor import (
        gen_extractors,
    )

    import threading
    from queue import Queue
    from .common import (
        setOption,
    )
    import time
    import os

    _TRACE_LEVEL = 2

    _PLAY_PATH = "mp4:bmw_teaser_300.mp4"
    _HOST = "79.175.165.164"
    _APPLICATION_NAME = "vod"
    _STREAM_NAME = _PLAY_PATH

# Generated at 2022-06-22 07:19:58.678627
# Unit test for function box
def test_box():
    assert box('xxxx', 'yyyy') == b'\x00\x00\x00\x0cxxxxyyyy'



# Generated at 2022-06-22 07:20:08.457466
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("Testing IsmFD")
    test_url = "https://domain.com/segment"
    info = {
        'fragments': [
            {
                'url': test_url
            }
        ]
    }
    ydl = YoutubeDL()
    ydl.params.update({
        "skip_unavailable_fragments": True,
        "fragment_retries": 0,
        "test": True,
        "outtmpl": "out.mp4",
        "_downloader": DummyDownloader()
    })
    fd = IsmFD(ydl, None, None)
    assert(fd._real_download(test_url, info))

test_IsmFD()

# Generated at 2022-06-22 07:20:18.385871
# Unit test for function write_piff_header
def test_write_piff_header():
    s = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 200000,
        'timescale': 10000000,
        'language': 'eng',
        'fourcc': 'H264',
        'height': 480,
        'width': 640,
        'codec_private_data': '000000016742C00DFFE1000003001000003007FFE1',
    }
    write_piff_header(s, params)

# Generated at 2022-06-22 07:20:20.304469
# Unit test for function box
def test_box():
    assert box(b'abcd', b'efghijkl') == b'\x00\x00\x00\x10abcd' + b'efghijkl'


# Generated at 2022-06-22 07:23:17.031890
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YDL()
    ydl.add_default_info_extractors()

    url = 'http://media.w3.org/2010/05/bunny/movie.ism/Manifest'
    print(IsmFD.can_download(url))

    dl = IsmFD(ydl, {'outtmpl': '%(id)s.%(ext)s'})
    dl.report_destination(True)

# Generated at 2022-06-22 07:23:27.338505
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor import common
    from .extractor.ism import IsmFD
    from .downloadermock import DownloaderMock
    from .common import parseOpts
    import os.path
    import shutil
    import tempfile

    def _create_test_file(filename, content):
        with open(filename, 'wb') as out:
            out.write(content)

    with DownloaderMock() as dl:
        # Create a temp directory
        tmp_dir = tempfile.mkdtemp(prefix='test_ism_')
        # Prepare a test ISMV file
        ismv_filename = os.path.join(tmp_dir, 'test.ismv')
        ismv_content = b'\x00' * 65536

# Generated at 2022-06-22 07:23:38.808056
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Arrange
    test_count = 0
    # test 1
    test_count += 1
    url = 'http://dashtest.azurewebsites.net/media/wowza/MultiRate/MultiRate.ism/Manifest'
    FD_params = {'test': True, 'fragments': True}
    info_dict = prepare_info_dict(url, FD_params)
    filename = 'D:\\output.mpd'
    test_fd = IsmFD(FD_params)
    # Act
    result = test_fd.real_download(filename, info_dict)
    # Assert
    # print(result)
    assert result == True, 'test %d failed' % test_count

