

# Generated at 2022-06-22 07:13:53.765174
# Unit test for function full_box
def test_full_box():
    boxStr1=full_box(b'moov',0,0,b'')
    boxStr2=b'\x00\x00\x00\x08moov\x00\x00\x00\x00'
    assert(boxStr1==boxStr2)
    return



# Generated at 2022-06-22 07:14:04.544549
# Unit test for function box
def test_box():
    assert box('ftyp', 'isom') == b'\x00\x00\x00\x0cftypisom'
    assert box('styp', 'isom') == b'\x00\x00\x00\x0cstypisom'
    assert box('moov', 'isom') == b'\x00\x00\x00\x0cmoovisom'
    assert box('free', 'isom') == b'\x00\x00\x00\x0cfreeisom'
    assert box('\x00\x00\x00\x00', 'isom') == b'\x00\x00\x00\x0c\x00\x00\x00\x00isom'



# Generated at 2022-06-22 07:14:14.450426
# Unit test for function full_box
def test_full_box():
    assert full_box(b'mvhd', 0, 0, b'') == b'\x00\x00\x00\x10mvhd\x00\x00\x00\x00\x00\x00\x00\x00'
    assert full_box(b'mvhd', 0, 0x00100000, b'') == b'\x00\x00\x00\x10mvhd\x00\x00\x00\x01\x00\x00\x00\x00'
    assert full_box(b'mvhd', 1, 0, b'') == b'\x00\x00\x00\x10mvhd\x01\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 07:14:17.732587
# Unit test for function box
def test_box():
    assert box(b'foo', b'bar') == b'\x00\x00\x00\nfoobar'



# Generated at 2022-06-22 07:14:20.501011
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Testing constructor of class IsmFD
    extractor = IsmFD()
    print(type(extractor))


# Generated at 2022-06-22 07:14:32.519323
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    youtube_dl.utils.file_io.std_headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8'
    ydl = YoutubeDL({})
    ydl.params['fragment_retries'] = 0
    ydl.params['test'] = False
    ydl.params['skip_unavailable_fragments'] = True

# Generated at 2022-06-22 07:14:38.061424
# Unit test for function write_piff_header
def test_write_piff_header():
    filename = "test.ismv"
    param = {'track_id': 1, 'fourcc': 'H264', 'duration': 94000000, 'timescale': 10000000, 'language': 'eng',
             'height': 960, 'width': 544, 'codec_private_data': '01640028ffe1000577f4801400d14e5a'}
    with io.open(filename, 'wb') as stream:
        write_piff_header(stream, param)

# Generated at 2022-06-22 07:14:48.964268
# Unit test for constructor of class IsmFD
def test_IsmFD():
    manifest_url = 'https://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest'
    parameters = {
        'skip_unavailable_fragments': False,
        'fragment_retries': 10,
        'test': True,
        'ignore_discontinuity': True
    }
    ism_FD = IsmFD(manifest_url, parameters)
    assert ism_FD.downloader is None
    assert ism_FD.manifest_url == 'https://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest'
    assert ism_FD.params == parameters



# Generated at 2022-06-22 07:14:54.376875
# Unit test for function full_box
def test_full_box():
    assert full_box(b'moov', 1, 0, b'\x00\x00\x00\x00') == b'\x00\x00\x00\x14moov\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 07:14:58.343567
# Unit test for function full_box
def test_full_box():
    assert full_box('moov', '1', '1', '1') == b'moov\x08\x01\x00\x00\x01\x01'



# Generated at 2022-06-22 07:15:22.423784
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'\x00\x00\x00\x10ftypftyp\x00\x00\x00\x10ftypmp42', (b'ftyp', b'ftyp')) == b'\x00\x00\x00\x10ftypmp42'
    assert extract_box_data(b'\x00\x00\x00\x00ftypftyp\x00\x00\x00\x10ftypmp42', (b'ftyp', b'ftyp')) == b'ftypmp42'
    assert extract_box_data(b'\x00\x00\x00\x00ftypftyp\x00\x00\x00\x10ftypmp42', (b'ftyp', b'mp42')) == None




# Generated at 2022-06-22 07:15:34.007051
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import sys

    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'duration': 10000,
            'timescale': 10000000,
            'height': 1080,
            'width': 1920,
            'language': 'en',
            'fourcc': 'H264',
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
            'nal_unit_length_field': 4,
            'codec_private_data': '0000000167640033ACD9004019FFFFCF0000000168E274000003001160A5FF5CCA0B1',
        })

# Generated at 2022-06-22 07:15:45.739501
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-22 07:15:57.662286
# Unit test for function extract_box_data
def test_extract_box_data():
    assert box(b'type', b'data') == b'\x00\x00\x00\x10type\x00\x00\x00\x00\x00\x00\x00\x04data'
    assert box(b'boxs', box(b'type', b'data')) == b'\x00\x00\x00\x14boxs\x00\x00\x00\x00\x00\x00\x00\x10type\x00\x00\x00\x00\x00\x00\x00\x04data'
    assert extract_box_data(box(b'boxs', box(b'type', b'data')), (b'boxs', b'type')) == b'data'
test_extract_box_data()



# Generated at 2022-06-22 07:16:03.886068
# Unit test for function write_piff_header

# Generated at 2022-06-22 07:16:09.422041
# Unit test for function full_box
def test_full_box():
    version = 1
    flags = 0
    payload = ''
    assert full_box(b'test', version, flags, payload) == '\x00\x00\x00\x0b' + 'test' + '\x01\x00\x00\x00\x00'



# Generated at 2022-06-22 07:16:17.636261
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # get a video id for testing
    video_id = 'l0Ep2ZiyxCY'
    with youtube_dl.YoutubeDL({}) as ydl:
        # get detailed information about the video
        info_dict = ydl.extract_info(video_id, download=False)
    # get information about the ism fragments
    ism_info_dict = info_dict['formats'][1]['manifest_url']
    # create an object of class IsmFD
    fd = IsmFD(ism_info_dict, {})
    # test the constructor
    assert fd.result_is_temp() == True
    assert fd.get_filename() == 'l0Ep2ZiyxCY.ism'
    assert fd.get_bytes_remaining() is None

# Unit test

# Generated at 2022-06-22 07:16:22.740473
# Unit test for function box
def test_box():
    assert('\x00\x00\x00\x10stts' == box('stts', '\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'))



# Generated at 2022-06-22 07:16:28.577239
# Unit test for function write_piff_header
def test_write_piff_header():
    #with io.open('E:\\test_write_piff_header.mp4', 'wb') as f:
    with io.BytesIO() as f:
        write_piff_header(f, dict(track_id=1, fourcc='AACL', sampling_rate=44100, duration=123456789))
        print("%s" % binascii.b2a_hex(f.getvalue()))


# Generated at 2022-06-22 07:16:34.268888
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ie = gen_extractors(u'ism')[0]
    urls = ie._TESTS[0]
    url = urls['url']
    print(url)
    fd = ie.url_result(url)
    print(fd.real_download('test.ismv', {'fragments': [{'url': 'test_url'}], '_download_params': {'track_id': 1}}))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-22 07:17:07.325982
# Unit test for function box
def test_box():
    assert(hexstr(box('abcd', '1234')) == 
        '0000000d616263640000001234')


# Generated at 2022-06-22 07:17:14.713029
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'duration': 10000000,
            'fourcc': 'AACL',
            'bits_per_sample': 16,
            'sampling_rate': 44100,
            'channels': 2,
        }
        write_piff_header(stream, params)

# Generated at 2022-06-22 07:17:24.570240
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        "track_id": 1,
        "fourcc": 'H264',
        "duration": 60000000,
        "timescale": 10000000,
        "language": "und",
        "height": 480,
        "width": 640,
        "codec_private_data": "0164001fffe10067640028ac2b4028a82014b020e139699014004e240025a814b8f1c4721c4800864b3c9c0",
        "sampling_rate": 48000,
        "bits_per_sample": 16,
        "channels": 2,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:17:34.034224
# Unit test for function write_piff_header
def test_write_piff_header():
    track_id = 1
    fourcc = 'AACL'
    duration = 10000000
    timescale = 10000000
    language = 'und'
    height = 0
    width = 0
    is_audio = width == 0 and height == 0
    creation_time = modification_time = int(time.time())

    ftyp_payload = b'isml'  # major brand
    ftyp_payload += u32.pack(1)  # minor version
    ftyp_payload += b'piff' + b'iso2'  # compatible brands
    # File Type Box


    mvhd_payload = u64.pack(creation_time)
    mvhd_payload += u64.pack(modification_time)
    mvhd_payload += u32.pack(timescale)
    mv

# Generated at 2022-06-22 07:17:40.952690
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.extractor import get_info_extractor
    from .youtube_dl.extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'TestIsm'
        IE_DESC = 'Test Ism File'

        _VALID_URL = r'http://*'

        def _real_extract(self, url):
            ie = get_info_extractor('ism')
            return ie._real_extract(ie, url)

    ie = TestIE()


# Generated at 2022-06-22 07:17:50.511422
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    with open(os.path.join(os.path.dirname(__file__), 'test_data', 'ism', 'smoothstreaming_playlist.ism'), 'rb') as f:
        ism_data = f.read()
    info_dict = {}
    info_dict['url'] = 'test url'
    info_dict['fragments'] = []
    info_dict['fragments'].append({
        "url": "test url",
        "duration": 4.0,
    })
    fd = IsmFD()
    fd.real_download('test.mp4', info_dict)

# Generated at 2022-06-22 07:18:00.653048
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 2,
        'fourcc': 'H264',
        'duration': 50 * 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 480,
        'width': 854,
        'nal_unit_length_field': 4,
        'codec_private_data': '000000016764001FFFE10011B6794A4C8001F649090800003000003008000001058A000003000003008000001058A000003000003008000001058A0000',
    })
    data = stream.getvalue()

# Generated at 2022-06-22 07:18:03.225597
# Unit test for function box
def test_box():
    assert box('a', 'b') == '\x00\x00\x00\x0aab'



# Generated at 2022-06-22 07:18:15.466913
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    write_piff_header(
        fd,
        {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000000000000,  # 0x174876e800
            'sampling_rate': 44100,
            'channels': 2,
            'language': 'und'
        }
    )

# Generated at 2022-06-22 07:18:23.958603
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '0000000167640032acd9400000140001e998c0100000300f9eb1f01fd070e01fd400000004d4011c20000000168ea605000001bbc80001000003283f9eb1f01fd070e01fd400000001e0b7e000001bbc8000000001605f0d9000000077179321f',
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'duration': 50000000,
    }
    write_piff_header(stream, params)
    output = stream.getvalue()

# Generated at 2022-06-22 07:20:14.605583
# Unit test for function full_box
def test_full_box():
    assert full_box(b'abcd', 1, 0, b'efgh') == b'\x00\x00\x00\x0cabcd\x01\x00\x00\x00efgh'
    assert full_box(b'abcd', 1, 0x1234, b'efgh') == b'\x00\x00\x00\x0cabcd\x01\x00\x12\x34efgh'



# Generated at 2022-06-22 07:20:23.209209
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'duration': 100,
        'sampling_rate': 44100,
        'track_id': 1,
        'fourcc': 'AACL',
    })
    f.seek(0)
    assert f.read(8) == b"\x00\x00\x00\x1f\x66\x74\x79\x70"  # ftyp
    assert f.read(8) == b"\x00\x00\x01\x9c\x6d\x6f\x6f\x76"  # moov
    assert f.read(8) == b"\x00\x00\x00\x1c\x6d\x76\x68\x64"  # mv

# Generated at 2022-06-22 07:20:30.936478
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest

    for box_sequence in ((b'abcd',), (b'abcd', b'efgh'), (b'abcd', b'efgh', b'ijkl')):
        assert extract_box_data(b'\x00\x00\x00\x00' + b'abcd' + b'\x00\x00\x00\x00' + b'efgh' + b'\x00\x00\x00\x00' + b'ijkl', box_sequence) == b'\x00\x00\x00\x00' + box_sequence[-1]



# Generated at 2022-06-22 07:20:41.774348
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    params = {'format': 'ism', 'url': 'https://www.youtube.com/watch?v=EzwjPtPHRpQ', 'playlist_index': 1, 'playlistend': 2}
    from .downloader import YoutubeDL
    from .postprocessor import FFmpegMetadataPP
    from .extractor import get_info_extractor
    from .extractor.youtube import YoutubePlaylistIE
    from .extractor.common import InfoExtractor
    ydl = YoutubeDL()
    ydl.params['simulate'] = True
    ydl.params['test'] = True
    # ydl.set_options(params)
    InfoExtractor.preprocess_url(ydl, 'fakeurl')
    ie = get_info_extractor('fakeid')
    # ie.extract(url)
    info

# Generated at 2022-06-22 07:20:45.473563
# Unit test for function full_box
def test_full_box():
    assert full_box("styp", 0, 0, "") == '\x00\x00\x00\x08styp\x00\x00\x00\x00'



# Generated at 2022-06-22 07:20:54.618588
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    >>> test_IsmFD()
    True
    """
    args = [
        'https://www.youtube.com/v/o9f-Fg1nKjw?version=3',
        '--test',
        '--test-ism',
        '--skip-unavailable-fragments',
        '--no-mtime',
        '-o',
        '/dev/null',
    ]
    return IsmFD.__test(args)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 07:21:06.388943
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    sys.path.append(r'D:\Software\Video\youtube-dl')
    from youtube_dl.YoutubeDL import YoutubeDL
    from selenium import webdriver
    from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
    from selenium.webdriver.firefox.options import Options
    from selenium.webdriver.support.ui import WebDriverWait
    from bs4 import BeautifulSoup
    from urllib.parse import urlparse
    from time import sleep
    from json import loads

    filename = 'F:\\test.mp4'

# Generated at 2022-06-22 07:21:16.633798
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
        'codec_private_data': '0164001fffe1001927640022acd9414084db4c8c6586f43bb2326b917888c08221d8a1fb6c27b6a83c6f1d6e2e6a24b9a9f9df2bbcb40010daf3d3217840088c22405b80',
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-22 07:21:21.320320
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    from .fragment import FragmentFD
    from .common import FileDownloader

    fd_ism = IsmFD()

    assert(isinstance(fd_ism, IsmFD))
    assert(isinstance(fd_ism, FragmentFD))
    assert(isinstance(fd_ism, FileDownloader))

    return fd_ism


# Generated at 2022-06-22 07:21:29.030035
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file_path = 'C:\\Users\\Wes\\Downloads\\test.mp4'
    test_file = io.open(test_file_path, 'wb')
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 2420.833333,
        'height': 0,
        'width': 0,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(test_file, params)
    test_file.close()
#test_write_piff_header()
