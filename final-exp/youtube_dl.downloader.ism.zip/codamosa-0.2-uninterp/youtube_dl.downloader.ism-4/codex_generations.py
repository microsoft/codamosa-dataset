

# Generated at 2022-06-18 13:30:45.937468
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:30:51.575604
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    info_dict = youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    IsmFD(info_dict['url'], info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:31:01.026418
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:31:13.919602
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.ism import IsmFD
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_ur

# Generated at 2022-06-18 13:31:19.265505
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:31:28.311295
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    gen_extractors()
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import get_cachedir

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ie = InfoExtractor(FileDownloader(params=None))
    ie.add_info_extractor(IsmFD)
    ie.extract(url)
    assert ie.get_filename(url) == 'SuperSpeedway_720.ism'
    assert ie.get_filename(url, info_dict={'id': 'foo'}) == 'foo.ism'

# Generated at 2022-06-18 13:31:33.617157
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - YoutubeDL object
    #   params - dictionary
    # Output:
    #   IsmFD object
    ydl = YoutubeDL()
    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'test': False,
    }
    ismfd = IsmFD(ydl, params)
    assert isinstance(ismfd, IsmFD)


# Generated at 2022-06-18 13:31:45.950424
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:31:58.433664
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .utils import match_filter_func
    from .compat import urlparse
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:32:07.279528
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs
    from .downloader.http import HttpFD
    from .utils import encode_data_uri
    from .extractor.youtube import YoutubeIE
    from .extractor.generic import GenericIE
    from .extractor.youtube import YoutubePlaylistIE
    from .extractor.youtube import YoutubeChannelIE
    from .extractor.youtube import YoutubeSearchIE
    from .extractor.youtube import YoutubeShowIE
    from .extractor.youtube import YoutubeIE
    from .extractor.youtube import YoutubePlaylistIE
    from .extractor.youtube import YoutubeChannelIE
    from .extractor.youtube import YoutubeSearchIE
    from .extractor.youtube import YoutubeShowIE
    from .extractor.youtube import YoutubeIE

# Generated at 2022-06-18 13:32:34.253115
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x0cmoov\x00\x00\x00\x0c\x00\x00\x00\x0cmoov\x00\x00\x00\x0c'
    assert extract_box_data(data, (b'moov',)) == b'\x00\x00\x00\x0c'
    assert extract_box_data(data, (b'moov', b'moov')) == b'\x00\x00\x00\x0c'
    assert extract_box_data(data, (b'moov', b'moov', b'moov')) == b'\x00\x00\x00\x0c'

# Generated at 2022-06-18 13:32:43.899425
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_extractor_classes_by_name
    from .downloader import gen_extractor_classes_by_url

    # Test constructor of class IsmFD
    extractors = gen_extractors()
    downloaders = gen_downloaders(extractors)
    openers = gen_openers(downloaders)
    extractor_classes = gen_extractor_classes(extractors)
    extractor_classes_by_name = gen_extractor_classes_by_name(extractors)
    extractor_classes_by_url = gen_extractor_classes_by_url(extractors)



# Generated at 2022-06-18 13:32:53.968365
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import get_testdata_file
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import sanitize_open

    # Test with a video that has a single fragment
    # (https://github.com/ytdl-org/youtube-dl/issues/17093)
    url = 'https://www.microsoft.com/en-us/download/details.aspx?id=53419'
    with get_testdata_file('smooth/Manifest.ism', 'rb') as f:
        manifest = f.read()
    with get_testdata_file('smooth/QualityLevels(90000)/Fragments(video=0)', 'rb') as f:
        fragment = f.read()

# Generated at 2022-06-18 13:33:02.242563
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:14.763862
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import urlparse

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

# Generated at 2022-06-18 13:33:26.260664
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 13:33:30.621665
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://www.example.com/')
            return
    assert False, 'ism extractor not found'

# Generated at 2022-06-18 13:33:42.678088
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urll

# Generated at 2022-06-18 13:33:53.181436
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:02.944441
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a ISM manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {'test': True})
    assert ism_fd.params['test']
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.manifest_data is None
    assert ism_fd.fragment_index == 0
    assert ism_fd.fragment_retries == 0
    assert ism_fd.fragment_skip_unavailable == True
    assert ism_fd.fragment_duration == 0
    assert ism_

# Generated at 2022-06-18 13:34:22.186577
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a file that has a single fragment
    # Test with a file that has multiple fragments
    # Test with a file that has multiple fragments and test option
    # Test with a file that has multiple fragments and skip_unavailable_fragments option
    # Test with a file that has multiple fragments and skip_unavailable_fragments and test option
    # Test with a file that has multiple fragments and fragment_retries option
    # Test with a file that has multiple fragments and fragment_retries and test option
    # Test with a file that has multiple fragments and fragment_retries and skip_unavailable_fragments option
    # Test with a file that has multiple fragments and fragment_retries and skip_unavailable_fragments and test option
    pass


# Generated at 2022-06-18 13:34:32.948494
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_http_client
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_struct_calcsize
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_urandom
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_struct_calcsize
    from ..compat import compat_chr

# Generated at 2022-06-18 13:34:41.831529
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    # Called from __main__; parameters should be removed in final version
    filename = 'test_IsmFD_real_download.ism'

# Generated at 2022-06-18 13:34:50.051431
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test case 1:
    # Test with a valid manifest URL
    # Expected result:
    # The constructor should return an instance of IsmFD
    test_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    test_fd = IsmFD(test_url, {})
    assert isinstance(test_fd, IsmFD)

    # Test case 2:
    # Test with a invalid manifest URL
    # Expected result:
    # The constructor should return None
    test_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'
    test_fd = IsmFD(test_url, {})
   

# Generated at 2022-06-18 13:34:56.366874
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001867640029ac4000001b7735d808080',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:34:59.201253
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Create an instance of class IsmFD
    ismFD = IsmFD()
    # Check if the instance is created successfully
    assert ismFD is not None


# Generated at 2022-06-18 13:35:08.378874
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:35:16.213560
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:35:24.276048
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:35:32.698699
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0000000167640029ACD941FCA03C58B0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:36:13.829020
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a manifest that has only one segment
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

# Generated at 2022-06-18 13:36:21.679140
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse


# Generated at 2022-06-18 13:36:23.056174
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:36:33.454992
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:36:38.610123
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    info_dict['_download_params']['fourcc'] = 'AACL'
    info_dict['_download_params']['sampling_rate'] = 44100
    info_dict['_download_params']['codec_private_data'] = '000000016764001eac2b4016d40'
    info_dict['_download_params']['nal_unit_length_field'] = 4
    info_dict['_download_params']['duration'] = info_dict['duration'] * 10000000
    info

# Generated at 2022-06-18 13:36:49.793304
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001967640028acd90780',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:36:52.908574
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    # TODO: implement your test here
    raise SkipTest  # removed or not implemented yet


# Generated at 2022-06-18 13:37:05.032371
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001467640028ac2c8080',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:37:12.486001
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat

# Generated at 2022-06-18 13:37:23.598077
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:38:40.119278
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a manifest file
    manifest_file = 'ism_manifest.xml'
    with open(manifest_file, 'rb') as f:
        manifest_data = f.read()

# Generated at 2022-06-18 13:38:49.544153
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .mp4 import write_mp4_header
    from .mp4 import write_mp4_footer
    from .mp4 import write_mp4_fragment
    from .mp4 import write_mp4_fragment_header
    from .mp4 import write_mp4_fragment_footer
    from .mp4 import write_mp4_fragment_data
    from .mp4 import write_mp4_fragment_data_header
    from .mp4 import write_mp4_fragment_data_footer
    from .mp4 import write_mp4_fragment_data_body
    from .mp4 import write_mp4_fragment_data_body_header
    from .mp4 import write_mp4_fragment_

# Generated at 2022-06-18 13:38:57.178312
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'test.ism'

# Generated at 2022-06-18 13:39:02.051434
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:39:06.629856
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_downloader_classes
    from .downloader import gen_suitable_downloader_classes
    from .downloader import get_suitable_downloader
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import YoutubeDL
    from .downloader import FileDownloader
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import YoutubeDL
    from .downloader import FileDownloader
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor

# Generated at 2022-06-18 13:39:12.728087
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - FakeYoutubeDL object
    #   params - download parameters
    # Assert:
    #   IsmFD object is created
    ydl = FakeYoutubeDL()
    params = {'fragment_retries': 0, 'skip_unavailable_fragments': True}
    ismfd = IsmFD(ydl, params)
    assert ismfd


# Generated at 2022-06-18 13:39:19.958105
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_error

# Generated at 2022-06-18 13:39:24.208493
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:39:30.044984
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_chunks
    from .test import get_test_data_file
    from .test import get_test_data_subfile
    from .test import get_test_data_subfile_path
    from .test import get_test_data_filesize
    from .test import get_test_data_subfilesize
    from .test import get_test_data_subfile_offset
    from .test import get_test_data_subfile_offset_end
    from .test import get_test_data_subfile_range
    from .test import get_test_data_subfile_range_end
    from .test import get_test_data_subfile_range_size
    from .test import get_test_data_subfile_range_size_end
    from .test import get_test_data_

# Generated at 2022-06-18 13:39:35.123701
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlparse

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
    }

    stream = io.BytesIO()
    write_piff_header(stream, params)
    stream.seek(0)
    data_uri = encode_data_uri(stream.read())