

# Generated at 2022-06-18 13:30:31.873501
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:30:41.922447
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_chr,
        compat_urllib_request,
    )
    from ..downloader.common import (
        HEADRequest,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.http_head import (
        HEADContentTooShortError,
    )
    from ..downloader.fragment import (
        FragmentFD,
    )
    from ..downloader.dash import (
        parse_mpd_formats,
        get_formats,
    )
    from ..downloader.dash import (
        DASHDownloader,
    )
    from ..downloader.dash import (
        DASHFragmentFD,
    )

# Generated at 2022-06-18 13:30:51.923260
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.ismv')
    with io.open(temp_file, 'wb') as f:
        write_piff_header(f, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '01640028ffe1001867640028acd941f9a09082f98104001426ffc80100000168e8e03c8',
        })

# Generated at 2022-06-18 13:31:01.228113
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1cftyp\x00\x00\x00\x00isml\x00\x00\x00\x01piff\x00\x00\x00\x00iso2\x00\x00\x00\x1cftyp\x00\x00\x00\x00isml\x00\x00\x00\x01piff\x00\x00\x00\x00iso2'
    assert extract_box_data(data, (b'ftyp',)) == b'\x00\x00\x00\x00isml\x00\x00\x00\x01piff\x00\x00\x00\x00iso2'

# Generated at 2022-06-18 13:31:14.144192
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:19.476510
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:31:28.490019
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_unquote_to_bytes
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit

# Generated at 2022-06-18 13:31:35.555810
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:31:46.740702
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:59.448439
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({'url': 'http://example.com/manifest.ism/Manifest'}, None)
    assert fd.url == 'http://example.com/manifest.ism/Manifest'
    assert fd.params == {}
    assert fd.info_dict == None
    assert fd.fd_name == 'ism'
    assert fd.ie_key == 'ism'
    assert fd.available == True
    assert fd.fragment_index == 0
    assert fd.total_frags == 0
    assert fd.frag_url == None
    assert fd.frag_filename == None
    assert fd.frag_downloader == None
    assert fd.frag_progress_hooks == None
    assert fd.frag_retries == 0
   

# Generated at 2022-06-18 13:32:19.303103
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    from ..utils import encode_data_uri

    def _test_write_piff_header(params):
        with tempfile.NamedTemporaryFile(suffix='.ismv') as f:
            write_piff_header(f, params)
            f.flush()
            return encode_data_uri(f.name, 'video/mp4')


# Generated at 2022-06-18 13:32:22.880595
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download = IsmFD(ie.params).download
            break
    return ie

# Generated at 2022-06-18 13:32:33.799799
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    ism_fd = IsmFD({'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'}, {})
    assert ism_fd.params['url'] == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

    # Test with an invalid manifest
    ism_fd = IsmFD({'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'}, {})

# Generated at 2022-06-18 13:32:43.103419
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:32:53.350155
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:59.913974
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'filename'
    info_dict = {'fragments': [{'url': 'url'}], '_download_params': {'track_id': 0, 'fourcc': 'fourcc', 'duration': 0, 'timescale': 10000000, 'language': 'und', 'height': 0, 'width': 0}}
    # Construct the object
    ismfd = IsmFD(params={'test': False})
    # Call the test method
    ismfd.real_download(filename, info_dict)


# Generated at 2022-06-18 13:33:11.761752
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '01640028ffe1001867640028acd941f9a03c569b4000003000168e91c4012a01fffe1001416e932c0',
        }
        write_piff_header(stream, params)

# Generated at 2022-06-18 13:33:23.476015
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a manifest file
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, params={})
    assert ism_fd.url == manifest_url
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.params == {}

    # Test with a fragment URL
    fragment_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(30000)/Fragments(video=0)'

# Generated at 2022-06-18 13:33:34.619228
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    # Test for constructor of class IsmFD

# Generated at 2022-06-18 13:33:46.441295
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:19.476095
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    from ..utils import (
        encode_data_uri,
        determine_ext,
    )
    from ..compat import (
        compat_urllib_request,
    )


# Generated at 2022-06-18 13:34:29.843899
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    from ..utils import (
        encode_data_uri,
        determine_ext,
    )
    from ..extractor import (
        gen_extractors,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )
    from ..downloader.fragment import (
        FragmentFD,
    )
    from ..downloader.dash import (
        DashSegmentsFD,
    )
    from ..downloader.hls import (
        HlsFD,
    )
    from ..downloader.ism import (
        IsmFD,
    )

# Generated at 2022-06-18 13:34:36.934736
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info_dict = youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    IsmFD(info_dict['url'], youtube_ie.params)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:43.405683
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:51.658990
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.params == {}

    # Test with an invalid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'
    ism_fd = IsmFD(manifest_url, {})
    assert ism_fd.manifest_url == manifest_url

# Generated at 2022-06-18 13:34:52.924058
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import _test_write_piff_header
    _test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:35:01.189725
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import YoutubeIE
    from .downloader import FileDownloader
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit

# Generated at 2022-06-18 13:35:09.805522
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:35:18.164337
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    # Test constructor of class IsmFD
    # Test case 1:
    #   Test with a valid manifest url
    #   Expected result:
    #       IsmFD is constructed successfully
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ie = InfoExtractor(gen_extractors(), gen_downloaders(), FileDownloader())
    ie.add_info_extractor(IsmIE.ie_key())
    ie

# Generated at 2022-06-18 13:35:22.923624
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie = ie()
            break
    else:
        raise ValueError('Could not find ism extractor')
    ie.download('http://www.example.com/')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:30.878916
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:33.129579
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    return True

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:35.272448
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            return ie
    assert False, 'ism extractor not found'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:40.278409
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ydl = YoutubeDL({'simulate': True})
    ie = gen_extractors(ydl, ['https://example.com/'])[0]
    fd = IsmFD(ydl, ie, {'fragments': [{'url': 'https://example.com/'}]})
    assert fd.params['fragment_base_url'] == 'https://example.com/'
    assert fd.params['fragment_base_path'] == ''
    assert fd.params['fragment_filename'] == '%(fragment_index)d.ism'
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments'] == True

# Generated at 2022-06-18 13:36:51.641548
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:36:53.123158
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-18 13:37:05.308644
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor import YoutubeIE
    from .downloader import FileDownloader
    from .utils import DateRange
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urluns

# Generated at 2022-06-18 13:37:12.588295
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:37:21.014937
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a manifest file
    manifest_url = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    ydl = YoutubeDL({'outtmpl': '%(id)s.ism'})
    ydl.add_info_extractor(IsmFD(ydl, {'url': manifest_url}))
    ydl.download([manifest_url])

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:37:23.552139
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:40:02.196007
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.add_downloader(gen_downloaders())

    fd = IsmFD(ie, {'url': 'http://example.com/test.ism/Manifest'})
    assert fd.ie == ie
    assert fd.params == {'url': 'http://example.com/test.ism/Manifest'}
    assert fd.info_dict == {}
    assert fd.fd is None
    assert fd.params['test'] is False
    assert fd.params['fragment_retries'] == 10
   