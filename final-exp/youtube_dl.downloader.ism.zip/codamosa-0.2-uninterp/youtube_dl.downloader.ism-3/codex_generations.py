

# Generated at 2022-06-18 13:30:25.509485
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1cftypisml\x00\x00\x00\x01piffiso2'
    assert extract_box_data(data, (b'ftyp',)) == b'isml\x00\x00\x00\x01piffiso2'
    assert extract_box_data(data, (b'ftyp', b'piff')) == b'iso2'
    assert extract_box_data(data, (b'ftyp', b'piff', b'iso2')) == b''
    assert extract_box_data(data, (b'ftyp', b'piff', b'iso3')) is None

# Generated at 2022-06-18 13:30:34.307797
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '01640028ffe1001927400d1d8d401f9f0140001bffe10018688b0c0c0',
        })

# Generated at 2022-06-18 13:30:41.400917
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - FakeYoutubeDL object
    #   params - Parameters to be passed to the constructor
    # Output:
    #   IsmFD object
    ydl = FakeYoutubeDL()

# Generated at 2022-06-18 13:30:51.552212
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00'
    box_sequence = (b'ftyp', b'moov', b'mvhd')
    assert extract_box_data(data, box_sequence) == None
    data = b'\x00\x00\x00\x00'
    box_sequence = (b'ftyp', b'moov', b'mvhd')
    assert extract_box_data(data, box_sequence) == None
    data = b'\x00\x00\x00\x00'
    box_sequence = (b'ftyp', b'moov', b'mvhd')
    assert extract_box_data(data, box_sequence) == None
    data = b'\x00\x00\x00\x00'

# Generated at 2022-06-18 13:31:00.983281
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1000b67640028ac2c8080',
        'nal_unit_length_field': 4
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:10.496081
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - an instance of YoutubeDL
    #   params - a dictionary of parameters
    # Output:
    #   an instance of IsmFD
    ydl = YoutubeDL()
    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'test': False
    }
    ismfd = IsmFD(ydl, params)
    assert ismfd.params == params
    assert ismfd.ydl == ydl


# Generated at 2022-06-18 13:31:13.205883
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:31:23.113735
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x0cmoov\x00\x00\x00\x0cmoov\x00\x00\x00\x0cmoov', [b'moov'])
    assert box_data == b'\x00\x00\x00\x0cmoov'
    box_data = extract_box_data(b'\x00\x00\x00\x0cmoov\x00\x00\x00\x0cmoov\x00\x00\x00\x0cmoov', [b'moov', b'moov'])
    assert box_data == b'\x00\x00\x00\x0cmoov'
    box_data = extract_box_data

# Generated at 2022-06-18 13:31:31.685565
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request


# Generated at 2022-06-18 13:31:44.371810
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()