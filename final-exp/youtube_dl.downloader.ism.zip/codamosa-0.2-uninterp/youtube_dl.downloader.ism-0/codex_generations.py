

# Generated at 2022-06-18 13:30:33.734339
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:30:40.926720
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader

    # Test constructor of class IsmFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            break
    for de in gen_downloaders():
        if de.FD_NAME == 'ism':
            break

# Generated at 2022-06-18 13:30:51.268540
# Unit test for function write_piff_header
def test_write_piff_header():
    import io
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:00.747300
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test for constructor of class IsmFD
    """
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .common import FileDownloaderParams

    ydl_opts = {
        'noplaylist': True,
        'quiet': True,
        'format': 'ism',
        'outtmpl': '%(id)s.ism',
        'writesubtitles': True,
        'allsubtitles': True,
        'subtitleslangs': ['en'],
        'skip_download': True,
        'test': True,
    }
    params = FileDownloaderParams().parse(ydl_opts, downloader=FileDownloader)
    params['test'] = True
    params['fragment_retries'] = 0
   

# Generated at 2022-06-18 13:31:13.593567
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .common import FileDownloaderParams
    from .compat import compat_urllib_error

    # Test for a video with a single fragment
    url = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    params = FileDownloaderParams()
    params.test = True
    params.format = 'ism'
    params.fragment_retries = 0
    params.skip_unavailable_fragments = False
    params.outtmpl = '%(id)s.ism'
    params.noprogress = True
    params.quiet

# Generated at 2022-06-18 13:31:18.856077
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:31:27.968575
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:31:35.221860
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:31:46.741502
# Unit test for function write_piff_header
def test_write_piff_header():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest

    class TestWritePiffHeader(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-18 13:31:59.496633
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:32:19.788684
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    youtube_info = youtube_ie._real_extract(youtube_url)
    youtube_params = youtube_info['_download_params']
    youtube_params['track_id'] = 1
    youtube_params['fourcc'] = 'AACL'
    youtube_params['sampling_rate'] = 44100
    youtube_params['channels'] = 2
    youtube_params['bits_per_sample'] = 16
    youtube_params['duration'] = youtube_info['duration']
    youtube_params['timescale'] = youtube_info['formats'][0]['tbr']

# Generated at 2022-06-18 13:32:30.370475
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Unit test for method real_download of class IsmFD
    """
    # Test case 1
    # Input:
    # filename = 'test.ism'
    # info_dict = {'fragments': [{'url': 'http://test.com/test.ism/QualityLevels(400000)/Fragments(video=0)'}]}
    # Output:
    # True

    # Test case 2
    # Input:
    # filename = 'test.ism'
    # info_dict = {'fragments': [{'url': 'http://test.com/test.ism/QualityLevels(400000)/Fragments(video=0)'}]}
    # Output:
    # False

    # Test case 3
    # Input:
    # filename = 'test.ism'
    # info_dict = {'

# Generated at 2022-06-18 13:32:40.097555
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '0000000167640032ACD900000168EB52402000568CA3C80',
    }

    with io.BytesIO() as stream:
        write_piff_header(stream, params)
        data = stream.getvalue()


# Generated at 2022-06-18 13:32:50.269273
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1cmoov\x00\x00\x00\x14trak\x00\x00\x00\x0cmdia\x00\x00\x00\x0cminf\x00\x00\x00\x08stbl\x00\x00\x00\x04stts'
    assert extract_box_data(data, (b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stts')) == b''
    assert extract_box_data(data, (b'moov', b'trak', b'mdia', b'minf', b'stbl')) == b'\x00\x00\x00\x04stts'

# Generated at 2022-06-18 13:32:59.513295
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs
    from .utils import encode_data_uri

    ydl = FakeYDL()
    ydl.params['fragment_retries'] = 10
    ydl.params['skip_unavailable_fragments'] = False
    ydl.add_info_extractor(InfoExtractor(ydl))
    ydl.add_info_extractor(IsmFD(ydl))


# Generated at 2022-06-18 13:33:11.505562
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:23.249060
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']

# Generated at 2022-06-18 13:33:34.384354
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9428e5b9c020100000030080000003008000001ca0c000001ca0c0000000168ee3c80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)
    stream.seek(0)

# Generated at 2022-06-18 13:33:46.206126
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib_parse_urlencode

# Generated at 2022-06-18 13:33:51.141940
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.download(youtube_ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:11.618512
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import get_info_extractor
    from .downloader import FileDownloader
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error

    class MockOpener(object):
        def __init__(self, test_instance):
            self.test_instance = test_instance

        def open(self, req, timeout=None):
            url = req.get_full_url()
            if url == 'http://example.com/manifest':
                return self.test_instance.manifest_mock
            elif url == 'http://example.com/segment1':
                return self.test_instance.segment1_mock

# Generated at 2022-06-18 13:34:21.065583
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:34:31.990609
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import FileDownloader
    from ytdl.compat import compat_urllib_error
    from ytdl.postprocessor import FFmpegMergerPP
    from ytdl.postprocessor.ffmpeg import FFmpegPostProcessor
    from ytdl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ytdl.postprocessor.ffmpeg import FFmpegMetadataPP
    from ytdl.postprocessor.ffmpeg import FFmpegSubtitlesConvertorPP
    from ytdl.postprocessor.ffmpeg import FFmpegFixupStretchedPP

# Generated at 2022-06-18 13:34:41.183792
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .common import FileDownloader
    from .utils import prepend_extension
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin


# Generated at 2022-06-18 13:34:44.070399
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://www.example.com')
            return
    assert False, 'ism extractor not found'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:47.942940
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.download(youtube_ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:55.141761
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    ism_fd = IsmFD(info_dict['url'], info_dict['_download_params'])
    assert ism_fd.FD_NAME == 'ism'
    assert ism_fd.params['track_id'] == 1
    assert ism_fd.params['fourcc'] == 'H264'
    assert ism_fd.params['duration'] == 8
    assert ism_fd.params['timescale'] == 10000000
    assert ism_fd.params['language'] == 'und'

# Generated at 2022-06-18 13:35:03.578459
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class

# Generated at 2022-06-18 13:35:12.725378
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import fakefile
    from ..utils import (
        determine_ext,
        determine_protocol,
    )
    from ..extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from ..compat import (
        compat_urllib_request,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )
    from ..downloader.ism import (
        IsmFD,
    )
    from ..downloader.dash import (
        DashSegmentsFD,
    )
    from ..downloader.hls import (
        HlsFD,
    )


# Generated at 2022-06-18 13:35:20.405198
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:35:45.508682
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://manifest.us.rtl.nl/rtlxl/network/a1/a1_npo1/a1_npo1_bb_bb.isml/a1_npo1_bb_bb-audio=128000-video=500000-subtitle=teletext.ism'
    youtube_ie.url_result(url)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:35:54.083198
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension

    # Test for constructor of class IsmFD

# Generated at 2022-06-18 13:36:04.571051
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension
    from .postprocessor import FFmpegPostProcessor
    from .postprocessor.common import PostProcessor
    from .postprocessor.ffmpeg import FFmpegPostProcessorError
    from .postprocessor.ffmpeg import FFmpegExtractAudioPP
    from .postprocessor.ffmpeg import FFmpegMergerPP
    from .postprocessor.ffmpeg import FFmpegMetadataPP
    from .postprocessor.ffmpeg import FFmpegVideoConvertorPP
    from .postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from .postprocessor.ffmpeg import FFmpegFixupStretchedPP

# Generated at 2022-06-18 13:36:14.146167
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_urllib_request
    from ..utils import (
        encode_data_uri,
        determine_ext,
    )
    from ..extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from ..downloader import (
        get_suitable_downloader,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )

    class FakeFD(io.BytesIO):
        def __init__(self, *args, **kwargs):
            io.BytesIO.__init__(self, *args, **kwargs)
            self.name = 'test.mp4'


# Generated at 2022-06-18 13:36:21.894967
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    # Test constructor of IsmFD

# Generated at 2022-06-18 13:36:32.381708
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .test import write_test_data
    from .test import make_test_stream
    from .test import make_test_params
    from .test import make_test_data
    from .test import make_test_fragment
    from .test import make_test_fragments
    from .test import make_test_fragment_fd

    # Test 1
    stream = make_test_stream()
    params = make_test_params()
    data = make_test_data()
    fragment = make_test_fragment()
    fragments = make_test_fragments()
    fragment_fd = make_test_fragment_fd()
    write_piff_header(stream, params)
    stream.seek(0)
    data = stream.read()

# Generated at 2022-06-18 13:36:43.630179
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd941fc8d80800b0fc0101056e5f16e3f',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:36:53.971120
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:37:05.992428
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:37:12.892984
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']

# Generated at 2022-06-18 13:37:57.606944
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor import YoutubeIE
    from .downloader import FileDownloader
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib

# Generated at 2022-06-18 13:38:05.509410
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:38:06.542829
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-18 13:38:12.210848
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_urllib_request,
        compat_urllib_parse,
        compat_urllib_error,
    )
    from ..downloader.common import (
        DownloadError,
    )
    from ..downloader.http import (
        HEADRequest,
    )
    from ..downloader.http.headers import (
        HEADRequest as HEADRequest_,
    )
    from ..downloader.http.cookies import (
        compat_cookiejar,
    )
    from ..downloader.http.cookies import (
        compat_cookiejar,
    )
    from ..downloader.http.cookies import (
        compat_cookiejar,
    )

# Generated at 2022-06-18 13:38:20.573017
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_request_urlopen
    from ..compat import compat_urllib_request_Request
    from ..compat import compat_ur

# Generated at 2022-06-18 13:38:22.786965
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(filename, info_dict) of class IsmFD
    # TODO: implement your test here
    raise SkipTest  # removed or not implemented for now



# Generated at 2022-06-18 13:38:31.201261
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:38:36.846432
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'fragments': [
            {
                'url': 'http://example.com/fragment1.ism',
            },
            {
                'url': 'http://example.com/fragment2.ism',
            },
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 44100,
        },
    }
    # Perform the test
    test_obj = IsmFD()

# Generated at 2022-06-18 13:38:42.202361
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ie = gen_extractors(IsmFD.ie_key())[0]()
    assert ie.ie_key() == 'ism'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.example.com/video.ism') == True
    assert ie.suitable('http://www.example.com/video.ism/manifest') == True
    assert ie.suitable('http://www.example.com/video.ism/manifest(format=m3u8-aapl)') == True
    assert ie.suitable('http://www.example.com/video.ism/manifest(format=mpd-time-csf)') == True

# Generated at 2022-06-18 13:38:50.102055
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd90888c010140001b2740001000000012000c48d88001468ee3c80',
        'nal_unit_length_field': 4,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:39:43.749961
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://www.example.com/')
            return
    assert False, 'ism extractor not found'



# Generated at 2022-06-18 13:39:50.736230
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_unquote_to_bytes

# Generated at 2022-06-18 13:39:59.270958
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders

    # Test for constructor of class IsmFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            break
    else:
        assert False, 'ism extractor not found'

    for de in gen_downloaders():
        if de.FD_NAME == 'ism':
            break
    else:
        assert False, 'ism downloader not found'

    # Test for constructor of class IsmFD
    fd = IsmFD(ie, {'url': 'http://example.com/test.ism/Manifest'}, {})
    assert fd.ie == ie
    assert fd.params == {}

# Generated at 2022-06-18 13:40:06.105290
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '0164001fffe100176764001facd9428e5b921000001b8018d9c3c80800c0',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)