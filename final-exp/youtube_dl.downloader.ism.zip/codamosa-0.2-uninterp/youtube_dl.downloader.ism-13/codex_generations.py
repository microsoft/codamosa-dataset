

# Generated at 2022-06-18 13:30:37.545905
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request


# Generated at 2022-06-18 13:30:48.268869
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:30:58.604578
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '0164001fffe1001667640029acd941c5f0101000468ee3c80f',
        'nal_unit_length_field': 4,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:10.993314
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open


# Generated at 2022-06-18 13:31:21.497132
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:24.170598
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:31:28.202387
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    info_dict = youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    IsmFD(info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:31:34.254823
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'https://manifest.us.llnwd.net/i/videos/tve/cnn/2015/03/03/cnn_newsroom_with_brooke_baldwin_150303_190000_vod_,400,700,1000,1800,2500,3200,master.m3u8?null=0'
    info_dict = youtube_ie._real_extract(url)
    IsmFD(info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:31:46.247637
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:31:51.764229
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.download(youtube_ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:32:12.484455
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_http_client
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_struct_calcsize
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urlparse
    from .compat import compat_str
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib

# Generated at 2022-06-18 13:32:21.982388
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import make_test_stream
    stream = make_test_stream()

# Generated at 2022-06-18 13:32:33.141082
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:42.435038
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801b001000001b58913000001000000012000c48d88001468ee3c80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:32:52.709546
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {'test': True})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.params['test'] == True
    assert ism_fd.params['fragment_base_url'] == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels({bitrate})/Fragments(video={start time})'

# Generated at 2022-06-18 13:32:54.867873
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:33:04.060467
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor import common
    from .downloader import FileDownloader
    from .downloader.http import HttpFD
    from .downloader.f4m import F4mFD
    from .downloader.ism import IsmFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.hls import HlsFD
    from .downloader.m3u8 import M3u8FD
    from .downloader.rtmp import RtmpFD
    from .downloader.smoothstreaming import SmoothStreamingFD
    from .downloader.fragment import FragmentFD
    from .downloader.external import ExternalFD
    from .downloader.rtmpdump import RtmpdumpFD
    from .downloader.hds import HdsFD
    from .downloader.http import HttpFD

# Generated at 2022-06-18 13:33:16.765591
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .utils import sanitize_open
    from .utils import encodeFilename
    from .utils import prepend_extension
    from .utils import write_json_file
    from .utils import read_json_file
    from .utils import sanitize_open
    from .utils import DateRange
    from .utils import DateRange
    from .utils import DateRange
    from .utils import DateRange
    from .utils import DateRange
    from .utils import DateRange

# Generated at 2022-06-18 13:33:27.650806
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:39.436284
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:34:02.681147
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote

# Generated at 2022-06-18 13:34:07.346450
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.ie_key() == 'ism':
            ie.download(ie.url)
            break

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:08.024749
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-18 13:34:18.646035
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:34:28.783193
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .mp4 import write_mp4_header
    from .mp4 import write_mp4_fragment
    from .mp4 import write_mp4_fragment_header
    from .mp4 import write_mp4_fragment_data
    from .mp4 import write_mp4_fragment_footer
    from .mp4 import write_mp4_footer
    from .mp4 import write_mp4_fragment_data_box
    from .mp4 import write_mp4_fragment_data_box_header
    from .mp4 import write_mp4_fragment_data_box_data
    from .mp4 import write_mp4_fragment_data_box_footer
    from .mp4 import write_mp4_

# Generated at 2022-06-18 13:34:34.890359
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl_opts - options of YoutubeDL
    #   params - parameters for IsmFD
    # Assertion:
    #   The constructor of IsmFD should return an instance of IsmFD
    ydl_opts = {}
    params = {}
    ismfd = IsmFD(ydl_opts, params)
    assert isinstance(ismfd, IsmFD)


# Generated at 2022-06-18 13:34:43.557052
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
        })

# Generated at 2022-06-18 13:34:51.752684
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:52.391019
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-18 13:35:00.270410
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:36:01.259630
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    box_sequence = (b'\x00\x00\x00\x00',)
    assert extract_box_data(data, box_sequence) == b''

    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    box_sequence = (b'\x00\x00\x00\x00',)
    assert extract_box_data(data, box_sequence) == b'\x00\x00\x00\x00'


# Generated at 2022-06-18 13:36:10.993454
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:19.676013
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']

# Generated at 2022-06-18 13:36:25.630779
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.manifest_data == None
    assert ism_fd.params == {}
    assert ism_fd.fragment_index == 0
    assert ism_fd.fragment_retries == 0
    assert ism_fd.skip_unavailable_fragments == True
    assert ism_fd.test == False

    # Test with a manifest that has a different extension
    manifest_

# Generated at 2022-06-18 13:36:36.177486
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import struct
    import re

    def get_piff_header(params):
        stream = io.BytesIO()
        write_piff_header(stream, params)
        return stream.getvalue()

    def get_piff_header_size(params):
        return len(get_piff_header(params))

    def get_piff_header_size_with_codec_private_data(params):
        params['codec_private_data'] = '01640028ffe1001427640028ac2c8080'
        return get_piff_header_size(params)


# Generated at 2022-06-18 13:36:39.661518
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(filename, info_dict)
    # of class IsmFD
    # Called from __main__; parameters should be removed in final version
    # filename = 'test.ism'
    # info_dict = {'fragments': [{'url': 'http://test.com/test.ism/QualityLevels(400000)/Fragments(video=0)'}]}
    # params = {'test': True}
    # IsmFD(params).real_download(filename, info_dict)
    pass


# Generated at 2022-06-18 13:36:42.911498
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    params = {
        'noprogress': True,
        'format': 'ism',
    }
    ism_fd = IsmFD(params, info_dict)
    ism_fd.real_download('test.ism', info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:47.612364
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:36:56.408653
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:37:07.748848
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_chr
    from ..compat import compat_urllib_request
    from ..compat import compat_urlparse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib