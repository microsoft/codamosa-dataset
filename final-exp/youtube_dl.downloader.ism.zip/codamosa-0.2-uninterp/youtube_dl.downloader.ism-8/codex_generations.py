

# Generated at 2022-06-18 13:30:27.374390
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:30:31.283828
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.download('http://www.youtube.com/watch?v=BaW_jenozKc')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:30:38.931831
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders

    # Test for constructor of class IsmFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            ism_fd = ie._real_initialize()
            assert isinstance(ism_fd, IsmFD)
            break

    # Test for constructor of class FragmentFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            ism_fd = ie._real_initialize()
            assert isinstance(ism_fd, FragmentFD)
            break

    # Test for constructor of class FileDownloader
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            ism_fd = ie._real_initialize

# Generated at 2022-06-18 13:30:41.234354
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:30:51.483316
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:00.917113
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat

# Generated at 2022-06-18 13:31:13.815177
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DashFD
    from .http import HttpFD
    from .smoothstreams import SmoothstreamsFD
    from .m3u8 import M3U8FD
    from .ism import IsmFD
    from .fragment import FragmentFD
    from .utils import sanitize_open

    assert issubclass(IsmFD, FragmentFD)
    assert IsmFD.FD_NAME == 'ism'
    assert IsmFD.supports('http://example.com/manifest.ism/Manifest')
    assert not IsmFD.supports('http://example.com/manifest.ism/Manifest', {'source_url': 'http://example.com/manifest.ism/Manifest'})

# Generated at 2022-06-18 13:31:21.582901
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd941f8a0f8c400b6e000f68ee3c80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:30.791619
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'fragments': [
            {
                'url': 'http://example.com/fragment1',
            },
            {
                'url': 'http://example.com/fragment2',
            },
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 100,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0,
        },
    }

    # Constructor test

# Generated at 2022-06-18 13:31:36.623086
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:31:59.826270
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request

    # Test constructor of class IsmFD
    # Test case 1:
    #   Input:
    #       url: http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest
    #       params: {'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
    #                'extractor_key': 'IsmFD',
    #                'preferredcodec': 'mp4',
    #                'pre

# Generated at 2022-06-18 13:32:08.723542
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 13:32:16.710037
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    # Test for constructor of class IsmFD

# Generated at 2022-06-18 13:32:27.070996
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO

    from .fragment import FragmentFD

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:32:29.326114
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:32:39.427222
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:32:49.448414
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_http_client
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_struct_calcsize
    from .compat import compat_urlparse
    from .compat import compat_str
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:32:58.847251
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid url
    url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4-onDemand.mpd'
    ismfd = IsmFD(url, {}, None)
    assert ismfd.url == url
    assert ismfd.params == {}
    assert ismfd.info_dict == {}
    assert ismfd.fd_name == 'ism'
    assert ismfd.ie_key == 'ism'
    assert ismfd.ie == None
    assert ismfd.available == True
    assert ismfd.done == False
    assert ismfd.frag_index == 0
    assert ismfd.total_frags == 0
    assert ismfd.filename

# Generated at 2022-06-18 13:33:05.144414
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:17.853698
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:33:38.416703
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'
    assert fd.params == {}
    assert fd.info_dict == {}
    assert fd.frag_index == 0
    assert fd.total_frags == 0
    assert fd.filename == None
    assert fd.dest_stream == None
    assert fd.frag_downloader == None
    assert fd.params.get('test', False) == False
    assert fd.params.get('fragment_retries', 0) == 0
    assert fd.params.get('skip_unavailable_fragments', True) == True


# Generated at 2022-06-18 13:33:50.071055
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test for audio
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:33:58.513661
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:34:10.805319
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:34:20.390197
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:34:31.317480
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test constructor of class IsmFD
    """
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ismfd = IsmFD(manifest_url, {}, None)
    assert ismfd.manifest_url == manifest_url
    assert ismfd.manifest == None
    assert ismfd.fragment_index == 0
    assert ismfd.fragment_count == 0
    assert ismfd.total_frags == 0
    assert ismfd.filename == None
    assert ismfd.dest_stream == None
    assert ismfd.params == {}
    assert ismfd.info_dict == {}
    assert ismfd

# Generated at 2022-06-18 13:34:38.341927
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'fragments': [
            {
                'url': 'http://example.com/fragment1',
            },
            {
                'url': 'http://example.com/fragment2',
            },
        ],
    }

    # Constructor test
    # TODO: Construct object and test for desired values
    # IsmFD(ydl, params)

    # TODO: Test real_download() response
    # IsmFD.real_download(filename, info_dict)


# Generated at 2022-06-18 13:34:46.267581
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()

# Generated at 2022-06-18 13:34:54.205761
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    def _test_write_piff_header(params):
        stream = StringIO()
        write_piff_header(stream, params)
        stream.seek(0)
        return stream.read()

    def _test_write_piff_header_with_mp4box(params):
        with tempfile.NamedTemporaryFile(suffix='.mp4') as f:
            write_piff_header(f, params)
            f.flush()
            output = subprocess.check_output(['MP4Box', '-info', f.name])

# Generated at 2022-06-18 13:35:02.571384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension
    from .extractor.common import InfoExtractor

    # Test for constructor of IsmFD
    # Test for constructor of FragmentFD
    # Test for constructor of FileDownloader
    # Test for constructor of InfoExtractor
    # Test for constructor of YoutubeIE
    # Test for constructor of YoutubePlaylistIE
    # Test for constructor of YoutubeSearchIE
    # Test for constructor of YoutubeChannelIE
    # Test for constructor of YoutubeUserIE
    # Test for constructor of YoutubeFavouritesIE
    # Test for constructor of YoutubeRecommendedIE
    # Test for constructor of YoutubeSubscriptionsIE
    # Test

# Generated at 2022-06-18 13:35:48.466591
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .mp4 import write_mp4_header
    from .m4a import write_m4a_header
    from .m4s import write_m4s_header
    from .m4v import write_m4v_header
    from .m4p import write_m4p_header
    from .m4b import write_m4b_header
    from .m4r import write_m4r_header
    from .m4a import write_m4a_header
    from .m4s import write_m4s_header
    from .m4v import write_m4v_header
    from .m4p import write_m4p_header
    from .m4b import write_m4b_header
    from .m4r import write_m

# Generated at 2022-06-18 13:35:52.587126
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    return True

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:02.928304
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import get_testdata_stream
    from .mp4 import write_piff_header
    from .mp4 import box
    from .mp4 import full_box
    from .mp4 import u32
    from .mp4 import u64
    from .mp4 import unity_matrix
    from .mp4 import TRACK_ENABLED
    from .mp4 import TRACK_IN_MOVIE
    from .mp4 import TRACK_IN_PREVIEW
    from .mp4 import SELF_CONTAINED
    from .mp4 import box
    from .mp4 import full_box
    from .mp4 import u32
    from .mp4 import u64
    from .mp4 import unity_matrix
    from .mp4 import TRACK_ENABLED
    from .mp4 import TRACK_IN_M

# Generated at 2022-06-18 13:36:12.753944
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:36:20.937233
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:36:24.939633
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    ism_fd = IsmFD(info_dict['url'], info_dict)
    ism_fd.real_download('test.ismv', info_dict)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:36:30.024215
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:36:34.838469
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']

# Generated at 2022-06-18 13:36:39.909827
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:36:51.336601
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:38:01.870203
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .compat import compat_urllib_request

    # Create a test manifest

# Generated at 2022-06-18 13:38:09.004765
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .mp4 import write_mp4_header
    from .mp4 import test_write_mp4_header
    from .mp4 import test_write_mp4_header_2
    from .mp4 import test_write_mp4_header_3
    from .mp4 import test_write_mp4_header_4
    from .mp4 import test_write_mp4_header_5
    from .mp4 import test_write_mp4_header_6
    from .mp4 import test_write_mp4_header_7
    from .mp4 import test_write_mp4_header_8
    from .mp4 import test_write_mp4_header_9
    from .mp4 import test_write_mp4

# Generated at 2022-06-18 13:38:14.036470
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000000,
            'timescale': 10000000,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
        })

# Generated at 2022-06-18 13:38:22.259351
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:38:30.736195
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_http_client
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_str
    from .compat import compat_urlparse
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib

# Generated at 2022-06-18 13:38:36.430473
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_urllib_request,
        compat_urllib_parse,
    )
    from ..extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
    )

    def _test_write_piff_header(url, expected_data_uri):
        ie = YoutubeIE()
        info = ie._real_extract(url)

# Generated at 2022-06-18 13:38:37.703922
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:38:42.919859
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import get_testdata_stream
    from ..utils import (
        determine_ext,
        determine_protocol,
        mimetype2ext,
    )

    # Test audio
    for mimetype in ('audio/mp4', 'audio/aac', 'audio/aacp'):
        ext = mimetype2ext(mimetype)
        stream = io.BytesIO()
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 1000,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
        })
        stream.seek(0)
        assert determine_ext(stream) == ext
        assert determine_protocol(stream)

# Generated at 2022-06-18 13:38:50.468765
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:38:57.946983
# Unit test for function extract_box_data