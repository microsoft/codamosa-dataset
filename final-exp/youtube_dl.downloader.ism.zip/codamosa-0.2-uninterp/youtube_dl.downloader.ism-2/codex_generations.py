

# Generated at 2022-06-18 13:30:40.023094
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a valid manifest
    manifest_url = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s', 'quiet': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.process_ie_result(ydl.extract_info(manifest_url, download=False))
    ydl.process_ie_result(ydl.extract_info(manifest_url, download=False))

# Generated at 2022-06-18 13:30:46.096496
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:30:56.541048
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a video
    video_url = 'http://media.w3.org/2010/05/sintel/trailer.mp4'

# Generated at 2022-06-18 13:30:58.617146
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import _test_write_piff_header
    _test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:31:10.993553
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:31:21.498269
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.suitable('http://www.example.com')
            ie.suitable('http://www.example.com/')
            ie.suitable('http://www.example.com/video.ism/manifest')
            ie.suitable('http://www.example.com/video.ism/manifest(format=m3u8-aapl)')
            ie.suitable('http://www.example.com/video.ism/manifest(format=mpd-time-csf)')
            ie.suitable('http://www.example.com/video.ism/manifest(format=m3u8-aapl-v3)')
           

# Generated at 2022-06-18 13:31:29.803629
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:31.070357
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:31:43.667578
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001467640028ac2c8080',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:54.972003
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {}, None)
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.params == {}
    assert ism_fd.info_dict == {}
    assert ism_fd.downloader is None

    # Test with an invalid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'
    ism_fd = IsmFD(manifest_url, {}, None)
    assert ism_fd

# Generated at 2022-06-18 13:32:08.507906
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:32:16.571718
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:32:26.926797
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001927640015acd9405a5dc0101056e5f7264656e5f736c617368690028e92b8fc0018e92b8fc0018e92b8fc0018e92b8fc001',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:32:29.193765
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:32:38.319224
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x20ftyp\x00\x00\x00\x00isml\x00\x00\x00\x01piff\x00\x00\x00\x00iso2'
    assert extract_box_data(data, (b'ftyp',)) == b'\x00\x00\x00\x00isml\x00\x00\x00\x01piff\x00\x00\x00\x00iso2'
    assert extract_box_data(data, (b'ftyp', b'piff')) == b'\x00\x00\x00\x00iso2'



# Generated at 2022-06-18 13:32:48.049215
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.suitable('http://www.example.com/')
            ie.suitable('http://www.example.com/test.ism')
            ie.suitable('http://www.example.com/test.ism/Manifest')
            ie.suitable('http://www.example.com/test.ism/Manifest(format=m3u8-aapl)')
            ie.suitable('http://www.example.com/test.ism/Manifest(format=mpd-time-csf)')

# Generated at 2022-06-18 13:32:57.708509
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:09.124847
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    class TestCase(object):
        def __init__(self, name, params, expected):
            self.name = name
            self.params = params
            self.expected = expected
    test_cases = []
    # Populate test cases
    test_cases.append(TestCase(
        name='TestCase 1',
        params={
            'test': False,
            'fragment_retries': 0,
            'skip_unavailable_fragments': True,
        },
        expected=True,
    ))
    test_cases.append(TestCase(
        name='TestCase 2',
        params={
            'test': False,
            'fragment_retries': 0,
            'skip_unavailable_fragments': False,
        },
        expected=True,
    ))

# Generated at 2022-06-18 13:33:21.347520
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:31.984599
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(data, (b'\x00\x00\x00\x00',)) == b'\x00\x00\x00\x00\x00\x00\x00\x00'