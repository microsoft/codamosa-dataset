

# Generated at 2022-06-18 13:30:27.332377
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:30:35.961881
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlparse

    stream = io.BytesIO()

# Generated at 2022-06-18 13:30:46.343440
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:30:54.269462
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:30:58.742833
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://www.example.com/')
            return
    assert False, 'ism extractor not found'

# Generated at 2022-06-18 13:31:01.058951
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:31:13.975076
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri


# Generated at 2022-06-18 13:31:19.300927
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)

# Generated at 2022-06-18 13:31:28.348272
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    # Test constructor of class IsmFD
    # Test case 1:
    #   input:
    #       url = 'http://example.com/test.ism/Manifest'
    #       params = {'format': 'ism'}
    #   output:
    #       IsmFD object
    url = 'http://example.com/test.ism/Manifest'
    params = {'format': 'ism'}
    ismfd = IsmFD(url, params)
    assert isinstance(ismfd, IsmFD)

    #

# Generated at 2022-06-18 13:31:34.311487
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import re

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:31:45.521808
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass


# Generated at 2022-06-18 13:31:57.761426
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a manifest file
    manifest_file = os.path.join(os.path.dirname(__file__), 'test_data', 'ism', 'ism_manifest.ism')
    with open(manifest_file, 'rb') as f:
        manifest_data = f.read()

# Generated at 2022-06-18 13:32:06.783580
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    from .dash import DASHFD
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import prepend_extension
    from .compat import compat_urllib_request
    import tempfile
    import shutil
    import os
    import sys

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-')

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a FileDownloader

# Generated at 2022-06-18 13:32:15.311711
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:32:25.677312
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:36.256387
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open


# Generated at 2022-06-18 13:32:45.612063
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:32:55.805525
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:05.913898
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_chr,
        compat_urllib_request,
    )
    from .mp4 import (
        write_mp4_header,
        write_mp4_fragment,
        write_mp4_fragment_header,
    )
    from .aac import (
        write_aac_header,
        write_aac_frame,
    )
    from .h264 import (
        write_h264_header,
        write_h264_frame,
    )
    from .mp3 import (
        write_mp3_header,
        write_mp3_frame,
    )
    from .vorbis import (
        write_vorbis_header,
        write_vorbis_frame,
    )


# Generated at 2022-06-18 13:33:18.452195
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:49.384986
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .utils import prepend_extension
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_

# Generated at 2022-06-18 13:33:55.159406
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'filename'
    info_dict = {
        'fragments': [
            {
                'url': 'url',
            },
        ],
        '_download_params': {
            'track_id': 'track_id',
        },
    }
    params = {
        'test': False,
    }
    # Constructor test
    fd = IsmFD(params)
    # Method test
    fd.real_download(filename, info_dict)



# Generated at 2022-06-18 13:33:58.247421
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ie = gen_extractors(IsmFD.ie_key())[0]()
    assert ie.ie_key() == 'ism'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:10.696435
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:34:20.309857
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    from ..compat import (
        compat_urllib_error,
    )
    from ..utils import (
        determine_ext,
    )
    from ..extractor import (
        YoutubeIE,
    )
    from ..downloader import (
        FileDownloader,
    )
    from ..compat import (
        compat_urllib_error,
    )
    from ..utils import (
        determine_ext,
    )
    from ..extractor import (
        YoutubeIE,
    )
    from ..downloader import (
        FileDownloader,
    )
    from ..compat import (
        compat_urllib_error,
    )
    from ..utils import (
        determine_ext,
    )

# Generated at 2022-06-18 13:34:31.213771
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs
    from .extractor.ism import IsmFD
    from .utils import encode_data_uri


# Generated at 2022-06-18 13:34:40.591324
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri


# Generated at 2022-06-18 13:34:46.078768
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd94080000030001000003000168ea8c8',
        'nal_unit_length_field': 4
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:34:54.065639
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:35:02.476265
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ie = gen_extractors(IsmFD.ie_key())[0]()
    assert ie.ie_key() == 'ism'
    assert ie.suitable(None) == False
    assert ie.suitable(
        'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest') == True
    assert ie.suitable(
        'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest(format=mpd-time-csf)') == True

# Generated at 2022-06-18 13:35:41.556974
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.suitable(None)
            ie.extract(None)
            return
    assert False, 'ism extractor not found'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:35:47.691870
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1000b67640028ac2c802814480028eea000b9a12001448801f',
        'nal_unit_length_field': 4
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:35:56.687700
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:36:06.966880
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a real manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

# Generated at 2022-06-18 13:36:16.585399
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    from .common import FakeYDL
    from .common import FakeHttpServer
    from .common import parse_m3u8_master
    from .common import parse_m3u8_playlist
    from .common import read_files
    from .common import write_files
    from .common import make_m3u8_playlist
    from .common import make_m3u8_master
    from .common import make_m3u8_fragment
    from .common import make_m3u8_key
    from .common import make_m3u8_iframe_playlist
    from .common import make_m3u8_media
    from .common import make_m3u8_stream_inf
    from .common import make_m3u

# Generated at 2022-06-18 13:36:21.620769
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_unquote_to_bytes
    from .compat import compat_urll

# Generated at 2022-06-18 13:36:27.197540
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test case 1:
    #   - Test constructor of class IsmFD
    #   - Test case for invalid URL
    #   - Expected result:
    #       + Raise exception
    #       + Print error message
    try:
        IsmFD('http://www.youtube.com/watch?v=BaW_jenozKc')
    except Exception as e:
        print(e)

    # Test case 2:
    #   - Test constructor of class IsmFD
    #   - Test case for valid URL
    #   - Expected result:
    #       + Create IsmFD object

# Generated at 2022-06-18 13:36:38.155689
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:36:49.321092
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib_parse_urlparse

# Generated at 2022-06-18 13:36:57.289179
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:37:32.877593
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_StringIO
    from ..utils import determine_ext

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd90411fc40080f14d921f0101056e5f1e0b001f9797000100000030080000000168ebe3c80',
        'nal_unit_length_field': 4,
    }
    stream = compat_StringIO()
    write_piff_header(stream, params)
    stream.seek(0)
    assert determine_

# Generated at 2022-06-18 13:37:42.119180
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:37:49.780188
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_info_extractor(IsmIE())
    result = ydl.extract_info(
        'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
        download=False)
    assert result['extractor'] == 'ism'
    assert result['protocol'] == 'mss'
    assert result['id'] == 'SuperSpeedway_720'
    assert result['title'] == 'SuperSpeedway_720'
    assert result['duration'] == 10
    assert result['formats'][0]['format_id'] == 'SuperSpeedway_720'
    assert result['formats'][0]['ext'] == 'mp4'

# Generated at 2022-06-18 13:37:58.105060
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {'test': True})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.params == {'test': True}
    assert ism_fd.manifest_type == 'ism'

# Generated at 2022-06-18 13:38:05.692854
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_urllib_request,
        compat_urllib_parse,
    )
    from ..extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
        YoutubeChannelIE,
    )
    from ..downloader import (
        YoutubeDL,
    )
    from ..postprocessor import (
        FFmpegExtractAudioPP,
    )


# Generated at 2022-06-18 13:38:11.737068
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:38:19.766851
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    params = {
        'format': 'ism',
        'outtmpl': '%(id)s.%(ext)s',
        'noplaylist': True,
    }
    ism_fd = IsmFD(params, youtube_ie)
    ism_fd.real_download(params['outtmpl'] % {'id': info_dict['id'], 'ext': 'ism'}, info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:38:28.170697
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case 1:
    #   Test real_download method of IsmFD class
    #   Input:
    #       filename = 'test.ism'
    #       info_dict = {
    #           'fragments': [
    #               {
    #                   'url': 'http://example.com/fragment1',
    #                   'duration': 10
    #               },
    #               {
    #                   'url': 'http://example.com/fragment2',
    #                   'duration': 10
    #               }
    #           ]
    #       }
    #   Expected:
    #       return True
    filename = 'test.ism'

# Generated at 2022-06-18 13:38:34.509046
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
    )
    from ..downloader.common import (
        DownloadError,
    )
    from ..downloader.http import (
        HEADRequest,
    )
    from ..downloader.http.headers import (
        HEADRequestHeaders,
    )
    from ..downloader.http.cookies import (
        CookieJar,
    )
    from ..downloader.http.fragment import (
        FragmentFD,
    )
    from ..downloader.http.file import (
        PartialHttpFD,
    )
    from ..downloader.http.range import (
        Range,
    )

# Generated at 2022-06-18 13:38:40.091747
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ismfd = IsmFD(manifest_url, {}, None)
    assert ismfd.manifest_url == manifest_url
    assert ismfd.manifest_type == 'ism'

    # Test with an invalid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'
    ismfd = IsmFD(manifest_url, {}, None)
    assert ismfd.manifest_url == manifest_url
    assert ismfd.manifest_type == 'ism'

