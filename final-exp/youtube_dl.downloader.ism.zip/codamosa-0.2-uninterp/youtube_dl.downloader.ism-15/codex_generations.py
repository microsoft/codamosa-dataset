

# Generated at 2022-06-18 13:30:34.927693
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_unquote_to_bytes
    from .compat import compat_urll

# Generated at 2022-06-18 13:30:45.888304
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from ..utils import (
        determine_ext,
        mimetype2ext,
    )
    from ..extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from ..compat import (
        compat_urllib_request,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )

    def get_piff_header(url, params):
        stream = BytesIO()
        write_piff_header(stream, params)
        stream.seek(0)
        return stream.read()


# Generated at 2022-06-18 13:30:56.270976
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'formats': [{
                    'format_id': 'fake',
                    'url': 'http://fake.com/fake.ism/manifest',
                    'ext': 'ism',
                }],
            }

    ie = FakeInfoExtractor

# Generated at 2022-06-18 13:30:56.736643
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-18 13:31:08.286323
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    url = 'ism://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest'
    ie = InfoExtractor(FileDownloader())
    info_dict = ie._real_extract(url)
    fd = IsmFD(ie, compat_urllib_request.Request(url), info_dict)
    fd.real_download('test.ism', info_dict)
    print(encode_data_uri(open('test.ism', 'rb').read()))


# Generated at 2022-06-18 13:31:11.004644
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass


# Generated at 2022-06-18 13:31:19.957173
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:28.810185
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:31:29.364834
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-18 13:31:35.938991
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_ie_extractors
    from .downloader import gen_suitable_downloader_classes
    from .downloader import gen_downloader_classes
    from .downloader import gen_ie_downloader_classes
    from .downloader import gen_info_extractor_classes
    from .downloader import gen_suitable_info_extractors
    from .downloader import gen_info_downloader_classes
    from .downloader import gen_suitable_downloaders
    from .downloader import gen_downloaders
    from .downloader import gen_ie_downloaders
    from .downloader import gen_info_extractors

# Generated at 2022-06-18 13:31:59.545140
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .test import write_test_data
    from .test import compare_test_data
    from .test import make_test_data_dir
    from .test import make_test_file_path
    from .test import make_test_file_name
    from .test import make_test_file_url
    from .test import make_test_file_fd
    from .test import make_test_file_stream
    from .test import make_test_file_object
    from .test import make_test_file_data
    from .test import make_test_file_url_data
    from .test import make_test_file_fd_data
    from .test import make_test_file_stream_data
    from .test import make_test_file_object_data

# Generated at 2022-06-18 13:32:08.352460
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:32:16.455744
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    ie = gen_extractors(IsmFD.ie_key())[0]()
    assert ie.ie_key() == 'ism'
    assert ie.suitable(None) == False
    assert ie.suitable(
        {'ext': 'ism', 'url': 'http://example.com/test.ism/Manifest'}) == True
    assert ie.suitable(
        {'ext': 'ism', 'url': 'http://example.com/test.ism/Manifest',
         'protocol': 'mss'}) == True
    assert ie.suitable(
        {'ext': 'ism', 'url': 'http://example.com/test.ism/Manifest',
         'protocol': 'mss'}) == True

# Generated at 2022-06-18 13:32:26.797597
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile

# Generated at 2022-06-18 13:32:31.920705
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.download(youtube_ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:32:41.256949
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:32:51.560687
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:32:55.538281
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.ie_key() == 'ism':
            return ie
    return None

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:33:03.159164
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import get_test_data_file
    from .fragment import FragmentFD
    from .mp4 import write_piff_header


# Generated at 2022-06-18 13:33:15.903876
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url)
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.manifest_type == 'ism'
    assert ism_fd.params['fragment_base_url'] == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(30000)/Fragments(video=0)'
    assert ism_fd.params['fragment_format'] == 'Seg{start time}-Frag{fragment number}'
    assert ism_

# Generated at 2022-06-18 13:33:37.501102
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:49.430578
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:33:57.686126
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:34:10.210419
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:19.945199
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .common import FileDownloader
    from .utils import prepend_extension
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_ur

# Generated at 2022-06-18 13:34:26.069731
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest')
            return
    assert False, 'ism extractor not found'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:36.804975
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1cftypiso2\x00\x00\x02\x00piff\x00\x00\x00\x00'
    assert extract_box_data(data, (b'ftyp',)) == b'iso2\x00\x00\x02\x00piff\x00\x00\x00\x00'
    assert extract_box_data(data, (b'moov',)) is None

# Generated at 2022-06-18 13:34:44.939059
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:34:53.059058
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001467640028ac2c8080',
        'nal_unit_length_field': 4,
    }
    write_piff_header(out, params)

# Generated at 2022-06-18 13:35:01.365321
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 13:35:25.979178
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse


# Generated at 2022-06-18 13:35:33.943547
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    from .mp4 import Atoms
    from .mp4 import AtomsError

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, 'test.ismv')

# Generated at 2022-06-18 13:35:35.217569
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:35:40.911501
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_

# Generated at 2022-06-18 13:35:47.140831
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 13:35:56.218579
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    # Test for constructor of class IsmFD
    # Test for constructor of class FragmentFD
    # Test for constructor of class FileDownloader
    # Test for constructor of class YoutubeDL
    # Test for constructor of class InfoExtractor
    # Test for constructor of class ExtractorError
    # Test for constructor of class GeoRestrictedError
    # Test for constructor of class RegexNotFoundError
    # Test for constructor of class DownloadError
    # Test for constructor of class SameFileError
    # Test for constructor of class PostProcessingError
    # Test for constructor of class UnavailableVideoError
    # Test for constructor of class ContentTooShortError
    # Test for constructor of class MaxDownloadsReached
    # Test for constructor of class UnsupportedError
    # Test for constructor of class Extractor
    # Test for constructor of

# Generated at 2022-06-18 13:36:06.492467
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:36:16.103612
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import tempfile
    import shutil
    import subprocess
    import re

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:36:21.092911
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:36:26.749324
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open


# Generated at 2022-06-18 13:36:55.773378
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '000000016764001facd941d942170610000000168ee3c80',
        'nal_unit_length_field': 4,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:37:07.366152
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:37:17.153121
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor import get_info_extractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_unquote_to_bytes
    from .compat import compat_urllib_parse

# Generated at 2022-06-18 13:37:28.120209
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    info_dict = {
        'id': 'test',
        'ext': 'ism',
        'title': 'test',
        'duration': 10,
        'formats': [{
            'format_id': 'test',
            'url': 'http://test.com/test.ism/manifest',
            'ext': 'ism',
            'protocol': 'mss',
            'fragments': [{
                'url': 'http://test.com/test.ism/QualityLevels(96000)/Fragments(audio=0)',
                'duration': 10
            }]
        }]
    }
    extractors = gen_extractors(info_dict)
    assert len(extractors) == 1

# Generated at 2022-06-18 13:37:33.910252
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - YoutubeDL object
    #   params - dict
    #   info_dict - dict
    # Expected Output:
    #   IsmFD object
    ydl = YoutubeDL()
    params = {}
    info_dict = {}
    ismFD = IsmFD(ydl, params, info_dict)
    assert isinstance(ismFD, IsmFD)


# Generated at 2022-06-18 13:37:42.082445
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'filename': 'test_filename',
        'fragments': [
            {
                'url': 'test_url_1',
            },
            {
                'url': 'test_url_2',
            },
        ],
        '_download_params': {
            'track_id': 1,
        },
    }

    # Perform the test
    ism_fd = IsmFD()
    ism_fd.params = {
        'test': True,
    }
    result = ism_fd.real_download(test_data['filename'], test_data)

    # Verify the results
    assert result == True


# Generated at 2022-06-18 13:37:49.680569
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension

    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class

# Generated at 2022-06-18 13:37:57.958222
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote

# Generated at 2022-06-18 13:37:59.875902
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:38:07.396205
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunspl

# Generated at 2022-06-18 13:38:48.130444
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_urllib_parse_urlunsplit
    from .compat import compat_urllib_

# Generated at 2022-06-18 13:38:52.762241
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1cftypisml\x00\x00\x00\x00\x00\x00\x00\x01piffiso2\x00\x00\x00\x1cftypisml\x00\x00\x00\x00\x00\x00\x00\x01piffiso2\x00\x00\x00\x1cftypisml\x00\x00\x00\x00\x00\x00\x00\x01piffiso2'

# Generated at 2022-06-18 13:38:59.240207
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_error
    from .utils import encode_data_uri

    # Test manifest

# Generated at 2022-06-18 13:39:03.882374
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:39:06.365732
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - an instance of YoutubeDL
    #   params - a dictionary of parameters
    # Output:
    #   an instance of IsmFD
    ydl = YoutubeDL()
    params = {'fragment_retries': 10, 'skip_unavailable_fragments': True}
    assert IsmFD(ydl, params)

# Generated at 2022-06-18 13:39:09.780804
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    #
    # This test is not implemented yet
    pass


# Generated at 2022-06-18 13:39:17.198220
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:39:24.659402
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:39:30.654391
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from ..utils import (
        determine_ext,
        determine_protocol,
    )
    from ..extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from ..compat import (
        compat_str,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )
    from ..downloader.fragment import (
        FragmentFD,
    )
    from ..downloader.dash import (
        DashSegmentsFD,
    )
    from ..downloader.ism import (
        IsmFD,
    )

# Generated at 2022-06-18 13:39:33.922494
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'fragments': [
            {
                'url': 'http://example.com/fragment_1.ism',
            },
            {
                'url': 'http://example.com/fragment_2.ism',
            },
        ],
    }

    # Perform the test
    result = IsmFD.real_download('filename', test_data)

    # Verify the results
    assert result == True
