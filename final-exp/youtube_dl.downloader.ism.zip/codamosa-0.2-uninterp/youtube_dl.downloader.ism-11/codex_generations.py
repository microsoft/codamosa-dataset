

# Generated at 2022-06-18 13:30:25.194447
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlparse
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib

# Generated at 2022-06-18 13:30:27.845013
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    fd = IsmFD()
    fd.real_download('filename', {'fragments': [{'url': 'url'}, {'url': 'url'}]})


# Generated at 2022-06-18 13:30:36.455995
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:30:43.059044
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders

    # Test constructor of class IsmFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            ism_fd = IsmFD(ie, {'url': 'http://example.com/test.ism/Manifest'})
            assert ism_fd.ie == ie
            assert ism_fd.params == {'url': 'http://example.com/test.ism/Manifest'}
            break
    else:
        raise AssertionError('Cannot find ism extractor')

    # Test constructor of class IsmFD

# Generated at 2022-06-18 13:30:51.421387
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a manifest file
    manifest_file = 'ism_manifest.xml'
    manifest_url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4-onDemand.mpd'
    manifest_data = compat_urllib_request.urlopen(manifest_url).read()
    with open(manifest_file, 'wb') as f:
        f.write(manifest_data)
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s', 'quiet': True, 'skip_download': True, 'forceurl': True, 'forcetitle': True, 'forceduration': True, 'forcefilename': True, 'simulate': True})
    y

# Generated at 2022-06-18 13:31:00.884925
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a manifest file
    manifest_file = 'ism_manifest.ism'
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism'
    manifest_content = compat_urllib_request.urlopen(manifest_url).read()
    with open(manifest_file, 'wb') as f:
        f.write(manifest_content)

# Generated at 2022-06-18 13:31:13.757571
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:31:14.404568
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-18 13:31:18.595444
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:31:27.721854
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 480,
        'width': 640,
        'codec_private_data': '01640028ffe1001767640028acd9c801010120004d401e3f80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:50.657454
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'filename'
    info_dict = {
        'fragments': [
            {
                'url': 'url',
            },
        ],
        '_download_params': {
            'track_id': 0,
        },
    }
    params = {
        'test': False,
    }

    # Constructor test
    fd = IsmFD(params)

    # Run method
    result = fd.real_download(filename, info_dict)

    # Validation
    assert result is True



# Generated at 2022-06-18 13:32:02.138518
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:04.020634
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass


# Generated at 2022-06-18 13:32:05.813666
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:32:14.546525
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test 1
    params = {
        'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest',
        'format': 'ism',
        'skip_unavailable_fragments': True,
        'fragment_retries': 10,
        'test': True,
    }
    ism_fd = IsmFD(params)
    assert ism_fd.params == params

    # Test 2

# Generated at 2022-06-18 13:32:24.864528
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .common import FileDownloaderParams
    from .compat import compat_urllib_request
    from .utils import url_basename
    from .extractor.ism import IsmFD

    url = 'http://media.w3.org/2010/05/sintel/trailer.mp4'

# Generated at 2022-06-18 13:32:35.361844
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader.common import FileDownloader
    from .utils import prepend_extension
    from .compat import compat_urlparse

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

# Generated at 2022-06-18 13:32:44.815516
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    info_dict = {}
    info_dict['url'] = url
    info_dict['ext'] = 'ism'
    info_dict['fragments'] = [{'url': 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(30000)/Fragments(video=0)'}]

# Generated at 2022-06-18 13:32:55.004061
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:33:04.302567
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_chr,
        compat_urllib_request,
    )
    from ..extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
    )
    from ..downloader import (
        YoutubeDL,
    )
    from ..postprocessor import (
        FFmpegMergerPP,
    )
    from ..extractor.common import (
        InfoExtractor,
    )
    from ..extractor.youtube import (
        YoutubePlaylistIE,
    )
    from ..utils import (
        encode_data_uri,
    )
    from ..compat import (
        compat_chr,
        compat_urllib_request,
    )
    from ..downloader import (
        YoutubeDL,
    )
   

# Generated at 2022-06-18 13:33:34.526929
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:33:42.070127
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for constructor of class IsmFD
    # Input:
    #   ydl - YoutubeDL object
    #   params - dict
    #   downloader - Downloader object
    # Expected Output:
    #   IsmFD object
    ydl = YoutubeDL()
    params = {}
    downloader = Downloader(ydl)
    ismfd = IsmFD(ydl, params, downloader)
    assert isinstance(ismfd, IsmFD)


# Generated at 2022-06-18 13:33:52.682440
# Unit test for function write_piff_header
def test_write_piff_header():
    import io
    import unittest
    from .test_fragment import TestFragmentFD

    class TestWritePiffHeader(unittest.TestCase):
        def test_write_piff_header(self):
            stream = io.BytesIO()

# Generated at 2022-06-18 13:33:56.110199
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.download('http://www.example.com/')
            return
    assert False, 'ism extractor not found'

# Generated at 2022-06-18 13:34:02.883620
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:14.492314
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    stream = io.BytesIO()

# Generated at 2022-06-18 13:34:22.701150
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import prepend_extension
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_robotparser
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote

# Generated at 2022-06-18 13:34:33.628186
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:39.223541
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:34:45.044813
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_downloader_classes
    from .downloader import gen_suitable_downloader_classes
    from .downloader import get_suitable_downloader
    from .downloader import YoutubeDL
    from .utils import prepend_extension
    from .utils import match_filter_func
    from .utils import format_bytes
    from .utils import format_seconds
    from .utils import unescapeHTML
    from .utils import unescapeFilePath
    from .utils import unescapeURL
    from .utils import clean_html
    from .utils import remove_quotes
    from .utils import remove_end
    from .utils import remove_start
    from .utils import int

# Generated at 2022-06-18 13:36:01.390905
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:11.129930
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:16.572435
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 720,
            'width': 1280,
            'codec_private_data': '01640028ffe1001867640028acd9c801010120004d401e3f80',
        })

# Generated at 2022-06-18 13:36:21.643139
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:36:32.121667
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:36:35.755353
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00'
    box_sequence = [b'ftyp', b'moov', b'mvhd']
    assert extract_box_data(data, box_sequence) == None



# Generated at 2022-06-18 13:36:47.170429
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:56.174836
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '01640028ffe1000b67640028ac2c80'
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:37:07.625816
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:37:17.767022
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import read_test_data
    from .test import write_test_data
    from .test import compare_test_data
    from .test import make_test_data_dir

    test_data_dir = make_test_data_dir(__file__)
    test_data_path = test_data_dir / 'test_write_piff_header.ismv'
