

# Generated at 2022-06-18 13:30:27.292387
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass


# Generated at 2022-06-18 13:30:35.925961
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_downloader_classes
    from .downloader import gen_suitable_downloader_classes
    from .downloader import get_suitable_downloader
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor
    from .downloader import get_info_extractor

# Generated at 2022-06-18 13:30:42.654834
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_http_client
    from .compat import compat_str
    from .compat import compat_urlparse
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_struct_calcsize
    from .compat import compat_struct_error
    from .compat import compat_struct
   

# Generated at 2022-06-18 13:30:44.347530
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    # TODO: implement your test here
    raise SkipTest  # removed or not implemented yet


# Generated at 2022-06-18 13:30:46.293875
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(filename, info_dict) of class IsmFD
    # TODO: implement your test here
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-18 13:30:56.629251
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    # Test for constructor of class IsmFD
    # Test case 1:
    #   Input:
    #       url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    #       ie = InfoExtractor()
    #       params = {
    #           'username': 'test',
    #           'password': '1234',
    #           'usenetrc': False,
    #           'verbose': True,
    #           'quiet

# Generated at 2022-06-18 13:31:08.285549
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '0000000167640028ac2b4028',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:19.395271
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001967640028acd9c801010120004d401e3f80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:28.419574
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_response
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_request
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse
    from .compat import compat_urll

# Generated at 2022-06-18 13:31:35.514243
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:04.844124
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import parse_duration

    # Test constructor of IsmFD
    # Test case 1:
    #   input:
    #       url: http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest
    #       params:
    #           format: mp4
    #           manifest_type: smoothstreaming
    #           ism_id: 1
    #           skip_unavailable_fragments: True
    #           fragment_retries: 10
    #           test: True
    #   expected:
    #       IsmFD instance
    #       info_

# Generated at 2022-06-18 13:32:13.624451
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:32:23.519344
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:32:34.304474
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd941f8b5f08001f4c401f59c401c000000003008000001b80180000003008000001b801800000',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:32:43.996993
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    url = 'ism://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest'
    ie = InfoExtractor()
    ie.add_info_extractor(IsmIE())
    ie.add_info_extractor(MssIE())
    ie.add_info_extractor(SmoothStreamsIE())
    ie.add_info_extractor(DashIE())
    ie.add_info_extractor(HlsIE())
    ie.add_info_extractor(M3u8IE())
    ie.add_info

# Generated at 2022-06-18 13:32:54.061220
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:01.704387
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:14.176987
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.ism/Manifest',
                    'format_id': 'ism',
                }],
            }

    class FakeRequest(compat_urllib_request.Request):
        def __init__(self, url, headers={}):
            self.url = url
            self.headers = headers

        def get_full_url(self):
            return self.url



# Generated at 2022-06-18 13:33:25.960100
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ismfd = IsmFD(manifest_url)
    assert ismfd.manifest_url == manifest_url
    assert ismfd.manifest_type == 'ism'
    assert ismfd.manifest_data == None
    assert ismfd.fragment_url_template == None
    assert ismfd.fragment_base_url == None
    assert ismfd.fragment_base_path == None
    assert ismfd.fragment_parameters == None
    assert ismfd.fragment_duration == None
    assert ismfd.fragment_retries == 0


# Generated at 2022-06-18 13:33:36.842649
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:56.291556
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open


# Generated at 2022-06-18 13:34:02.959831
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import (
        compat_urllib_request,
        compat_urllib_parse,
        compat_urllib_error,
    )
    from ..downloader.common import (
        DownloadError,
        ContentTooShortError,
    )
    from ..downloader.http import (
        HEADRequest,
        HEADNoRedirectHandler,
    )
    from ..downloader.http.headers import (
        HEADRequestHeaders,
        HEADResponseHeaders,
    )
    from ..downloader.http.cookies import (
        CookieJar,
    )
    from ..downloader.http.request import (
        sanitize_openers,
    )
    from ..downloader.http.fragment import (
        FragmentFD,
    )

# Generated at 2022-06-18 13:34:14.631250
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .compat import parse_qs

    def _test_IsmFD(url, expected_track_id):
        downloader = FileDownloader({})
        info_dict = downloader.url_result(url)
        assert info_dict['extractor_key'] == 'IsmFD'
        assert info_dict['_type'] == 'fragment'
        assert info_dict['fragment_base_url'] == 'http://wams.edgesuite.net/media/MPTExpressionData02/BigBuckBunny_1080p24_IYUV_2ch.ism/QualityLevels(90000)/Fragments(video=0)'

# Generated at 2022-06-18 13:34:22.766493
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:33.673868
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001767640029acd941c5601e8d00d907ffc0018ee3c80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:34:35.781435
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            return ie
    assert False, 'ism extractor not found'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:40.701740
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'filename'
    info_dict = {
        'fragments': [
            {
                'url': 'url',
            },
        ],
    }
    params = {
        'test': False,
    }
    # Constructor test
    fd = IsmFD(params)
    # Method test
    assert fd.real_download(filename, info_dict) == True


# Generated at 2022-06-18 13:34:46.157614
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .utils import prepend_extension
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib

# Generated at 2022-06-18 13:34:54.122129
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:35:02.475103
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:35:39.322957
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:35:45.718161
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_chr

    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'width': 1280,
        'height': 720,
        'codec_private_data': '0000000167640033ACD9A03F80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:35:54.440625
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen

    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
        'nal_unit_length_field': 4,
    }

    data = io.BytesIO()
    write_piff_header(data, params)
    data = data.getvalue()


# Generated at 2022-06-18 13:35:55.304638
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-18 13:36:05.581791
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import parse_qs, compat_urllib_error
    from .downloader.http import HttpFD
    from .utils import encode_data_uri

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.ism/Manifest',
                    'ext': 'mp4',
                    'protocol': 'ism',
                    'format_id': 'ism',
                }],
            }

    class FakeHttpFD(HttpFD):
        def real_download(self, filename, info_dict):
            return True


# Generated at 2022-06-18 13:36:15.173046
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:36:22.598068
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ie = InfoExtractor(gen_extractors(), gen_downloaders(), FileDownloader())
    info_dict = ie.extract(url)
    assert info_dict['id'] == 'SuperSpeedway_720'
    assert info_dict['ext'] == 'ism'
    assert info_dict['title'] == 'SuperSpeedway_720'
    assert info_dict['duration']

# Generated at 2022-06-18 13:36:33.241580
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:44.398471
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:36:49.071768
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'fragments': [
            {
                'url': 'http://example.com/fragment1',
            },
            {
                'url': 'http://example.com/fragment2',
            },
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000000,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0,
            'channels': 2,
            'bits_per_sample': 16,
            'sampling_rate': 44100,
        },
    }
    # Construct the object

# Generated at 2022-06-18 13:37:45.349087
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001867640028acd941f9f030028acd941f9f03c0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:37:53.470934
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_http_client
    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    from .compat import compat_struct_calcsize
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urlparse
    from .compat import compat_str
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib

# Generated at 2022-06-18 13:38:01.516998
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .downloader import gen_extractor_classes
    from .downloader import gen_downloader_classes
    from .downloader import gen_suitable_downloader_classes

    # Test if IsmFD is included in the list of extractor classes
    extractor_classes = gen_extractor_classes()
    assert IsmFD in extractor_classes

    # Test if IsmFD is included in the list of downloader classes
    downloader_classes = gen_downloader_classes()
    assert IsmFD in downloader_classes

    # Test if IsmFD is included in the list of suitable downloader classes
    suitable_downloader_classes = gen_suitable_downloader_classes('http://example.com/video.ism/manifest')


# Generated at 2022-06-18 13:38:07.086457
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    test_data = {
        'filename': 'test_filename',
        'fragments': [
            {
                'url': 'test_url',
            },
        ],
        '_download_params': {
            'track_id': 1,
        },
    }

    # Constructor test
    fd = IsmFD(params={})

    # Run method
    fd.real_download(test_data['filename'], test_data)


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-18 13:38:07.557651
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-18 13:38:12.954967
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001967640028acd9d401010120004d401e3f80b5fc00000168ea600f060028ee8f00d9',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:38:21.056723
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:38:29.698335
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:38:35.557713
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:38:41.076809
# Unit test for function extract_box_data