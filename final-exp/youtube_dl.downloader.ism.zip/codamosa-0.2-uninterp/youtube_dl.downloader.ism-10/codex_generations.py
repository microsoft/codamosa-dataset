

# Generated at 2022-06-18 13:30:25.935810
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001767640029acd94080001b8d8f5a0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:30:29.897473
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.suitable(None)
            ie.extract(None)
            return
    assert False, 'ism extractor not found'



# Generated at 2022-06-18 13:30:31.869867
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_write_piff_header
    test_write_piff_header(write_piff_header)



# Generated at 2022-06-18 13:30:39.396373
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:30:45.373696
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:30:55.550440
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001927400d1d9a0312f0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:03.085949
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.ism/Manifest',
                    'ext': 'ism',
                    'format_id': 'ism',
                }],
            }

    class FakeFileDownloader(FileDownloader):
        def real_download(self, filename, info_dict):
            return True


# Generated at 2022-06-18 13:31:06.426073
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    #
    # This test is not implemented.
    pass


# Generated at 2022-06-18 13:31:10.012979
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    # TODO: implement your test here
    raise SkipTest


# Generated at 2022-06-18 13:31:16.295209
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'ism':
            ie.extract('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest')
            break

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:31:35.273489
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class IsmFD
    # Test for constructor of class

# Generated at 2022-06-18 13:31:46.741128
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_chr

    stream = io.BytesIO()

# Generated at 2022-06-18 13:31:59.454802
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640029ffe1001f67640029ac72c80d9d8c0101400000fa400a0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:32:08.155123
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:17.367487
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open
    from .utils import encodeFilename

    # Test for constructor of class IsmFD
    # Test for constructor of class FileDownloader
    # Test for constructor of class InfoExtractor
    # Test for constructor of class YoutubeIE
    ie = gen_extractors(u'youtube')[0]
    # Test for constructor of class YoutubePlaylistIE
    ie = gen_extractors(u'youtube:playlist')[0]
    # Test for constructor of class YoutubeUserIE
    ie = gen_extractors(u'youtube:user')[0]


# Generated at 2022-06-18 13:32:27.741180
# Unit test for function extract_box_data

# Generated at 2022-06-18 13:32:38.248150
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:32:44.719349
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info_dict = youtube_ie.result['entries'][0]
    fd = IsmFD(info_dict['url'], info_dict)
    fd.real_download('test.ismv', info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:32:54.869072
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe1001767640029acd9d401010120004d401e3f80f00a0',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:33:04.060596
# Unit test for function write_piff_header

# Generated at 2022-06-18 13:33:28.958982
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    info_dict = youtube_ie._downloader.cache.load('BaW_jenozKc')
    IsmFD(youtube_ie._downloader, info_dict)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:33:40.751475
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:33:51.587953
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create a mock instance of class IsmFD
    ismfd = IsmFD()
    # Create a mock instance of class YoutubeDL
    ydl = YoutubeDL()
    # Create a mock instance of class InfoExtractor
    ie = InfoExtractor()
    # Set the method real_download of class IsmFD to the mock instance of class YoutubeDL
    ismfd.real_download = ydl.download
    # Set the method _download_webpage of class YoutubeDL to the mock instance of class InfoExtractor
    ydl._download_webpage = ie.extract
    # Set the method _download_webpage of class InfoExtractor to the mock instance of class YoutubeDL
    ie._download_webpage = ydl.download
    # Set the method _download_webpage of class YoutubeDL to the mock instance of class InfoExtractor
    ydl

# Generated at 2022-06-18 13:33:57.672634
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    stream = io.BytesIO()

# Generated at 2022-06-18 13:34:08.617097
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie._real_extract(url)
    params = {
        'format': 'ism',
        'test': True,
    }
    ism_fd = IsmFD(params, info_dict)
    assert ism_fd.FD_NAME == 'ism'
    assert ism_fd.params == params
    assert ism_fd.info_dict == info_dict
    assert ism_fd.real_download('test.ism', info_dict) == True

# Generated at 2022-06-18 13:34:18.867446
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-18 13:34:24.381286
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders

    # Test for constructor of class IsmFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            for de in gen_downloaders():
                if de.FD_NAME == 'ism':
                    IsmFD(ie, de)
                    break
            break

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:34:27.035126
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class IsmFD
    pass



# Generated at 2022-06-18 13:34:37.319200
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test with a simple manifest
    manifest_url = 'https://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest'
    ydl = YoutubeDL({'format': 'ism', 'noplaylist': True, 'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(IsmIE())
    ydl.add_info_extractor(IsmFD())
    ydl.process_ie_result(ydl.extract_info(manifest_url, download=False))
    ydl.download([manifest_url])

    # Test with a manifest with multiple tracks

# Generated at 2022-06-18 13:34:43.604123
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    box_sequence = (b'\x00\x00\x00\x00',)
    assert extract_box_data(data, box_sequence) == b''
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    box_sequence = (b'\x00\x00\x00\x00',)
    assert extract_box_data(data, box_sequence) == b'\x00\x00\x00\x00'