

# Generated at 2022-06-18 13:30:27.373384
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:30:36.033937
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1000867640028ac2c8028ac2c802880',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:30:39.029275
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    youtube_ie = gen_extractors()['youtube']
    youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-18 13:30:45.052850
# Unit test for constructor of class IsmFD

# Generated at 2022-06-18 13:30:55.110513
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ism_fd = IsmFD(manifest_url, {})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.params == {}

    # Test with an invalid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest_invalid'
    ism_fd = IsmFD(manifest_url, {})
    assert ism_fd.manifest_url == manifest_url
    assert ism_fd.params == {}


# Generated at 2022-06-18 13:31:01.331671
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test case data
    filename = 'filename'
    info_dict = {
        'fragments': [
            {
                'url': 'url',
            },
        ],
        '_download_params': {
            'track_id': 1,
        },
    }
    # Construct the object
    fd = IsmFD()
    # Call the method
    result = fd.real_download(filename, info_dict)
    # Check the result
    assert result == True


# Generated at 2022-06-18 13:31:14.289762
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a valid manifest
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ismfd = IsmFD(manifest_url, {}, None)
    assert ismfd.manifest_url == manifest_url
    assert ismfd.manifest_type == 'ism'
    assert ismfd.manifest_data == None
    assert ismfd.fragment_base_url == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/QualityLevels(30000)/Fragments(video=0)'
    assert ismfd.fragment_param_name == 'video'
    assert ismfd.fragment

# Generated at 2022-06-18 13:31:22.696758
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100176764001facd9c801010120004d401e3f80',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-18 13:31:31.373650
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:31:37.227111
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(test_data, [b'\x00\x00\x00\x00']) == b''
    test_data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert extract_box_data(test_data, [b'\x00\x00\x00\x00', b'\x00\x00\x00\x00']) == b''