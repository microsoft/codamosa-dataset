

# Generated at 2022-06-12 16:59:33.672917
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ism import IsmFD
    IsmFD('', '', '', '')
    return True


# Generated at 2022-06-12 16:59:39.433868
# Unit test for function write_piff_header
def test_write_piff_header():
    mdat_payload = b'\x00\x00\x00\x01\x09\x10\x00\x00\x00\x01\x67\x4d\x40\x1f\x96\x11\x01\x00\x04\x68\xce\x3c\x20\x00\x00\x03\x00\x80\x00\x00\x07\x1d\x00\x00\x00\x03\x00\x08\x00\xc0\x00\x00\x07\x1d\x00\x00\x00\x01\x68\xeb\xe3\xc0'
    stream = io.BytesIO()

# Generated at 2022-06-12 16:59:45.259444
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ismfd = IsmFD()

    filename = 'test_filename'
    info_dict = {
        'fragments': {
            'url': 'some_url'
        }
    }

    ismfd.real_download(filename, info_dict)
    assert False, "Test is not implemented, yet."



# Generated at 2022-06-12 16:59:54.209462
# Unit test for constructor of class IsmFD
def test_IsmFD():
    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.ism')
    with open(filename, 'rb') as f:
        test_data = f.read()
    ism = IsmManifest(test_data)
    fd = IsmFD(ism)

    test_case = {
        'correct': True,
        'reported': None,
        'dest_filename': 'test',
    }

    result = fd.real_download(test_case['dest_filename'], ism.info_dict)
    assert test_case['correct'] == result


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:00:02.745301
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 1000, 'timescale': 10000000, 'language': 'und',
    'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 125, 'codec_private_data': 'AGKyr6Q=',
    'nal_unit_length_field': 4}
    # Open a dummy file stram to write PIFF header
    with io.BytesIO() as b:
        write_piff_header(b, params)
        # Write a temp file to test the header
        with open('piffheader.piff', 'wb') as f:
            f.write(b.getvalue())
# Test
if __name__ == '__main__':
    test_write

# Generated at 2022-06-12 17:00:08.549315
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:00:20.646933
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    _downloader = DummyYdl()
    _downloader.params = {}
    for attr in ('test', 'fragment_retries', 'skip_unavailable_fragments'):
        if attr in _downloader.params:
            del _downloader.params[attr]

# Generated at 2022-06-12 17:00:34.810309
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:00:46.378845
# Unit test for function write_piff_header
def test_write_piff_header():
    import random
    test_file = 'test_write_piff_header.ismv'
    test_piff_header = {}
    test_piff_header['track_id'] = random.randint(0,9)
    test_piff_header['fourcc'] = 'AVC1'
    test_piff_header['duration'] = random.randint(0,999999999)
    test_piff_header['timescale'] = random.randint(0,999999999)
    test_piff_header['language'] = 'und'
    test_piff_header['height'] = random.randint(0,999999999)
    test_piff_header['width'] = random.randint(0,999999999)

# Generated at 2022-06-12 17:00:54.909744
# Unit test for function write_piff_header
def test_write_piff_header():
    out_stream = io.BytesIO()
    params = {
        'language': 'fre',
        'track_id': 1,
        'duration': 0,
        'timescale': 1,
        'sampling_rate': 44100,
        'fourcc': 'AACL'
    }
    write_piff_header(out_stream, params)

    out_stream.seek(0)
    box_type = out_stream.read(4)

    if box_type == b'moov':
        pass
    else:
        raise ValueError('Box type is not moov')

# Generated at 2022-06-12 17:01:19.017375
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:01:31.836960
# Unit test for constructor of class IsmFD
def test_IsmFD():
    sample_info = {
        'protocol': 'mss',
        'url': '',
        'fragments': [
            {
                'url': '',
                'duration': 4.008,
            },
            {
                'url': '',
                'duration': 4.005,
            },
            {
                'url': '',
                'duration': 3.997,
            },
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'MP42',
            'duration': 12.01,
            'timescale': 1000,
            'language': 'eng',
            'height': 0,
            'width': 0,
        }
    }
    ismfd = IsmFD(sample_info['url'], sample_info, {})
    return

# Generated at 2022-06-12 17:01:43.184937
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:01:44.364633
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True


# Generated at 2022-06-12 17:01:51.517721
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    1. Get info dict from url using IsmFD.url_result()
    2. Call IsmFD.real_download()
    3. Test if real_download() method has returned True
    """
    url = 'http://s1.example.com/manifest(format=m3u8-aapl-v3).ism'
    info_dict = IsmFD().url_result(url)
    assert IsmFD().real_download(
        filename=None, info_dict=info_dict), 'Test for class IsmFD have failed!'

# Generated at 2022-06-12 17:02:03.511663
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass
# __main__
if __name__ == '__main__':
    # Initialize logging
    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("pafy").setLevel(logging.WARNING)
    # Launch unit test
    unittest.main(exit=False, verbosity=2)
    # Set a file to download and initialize a downloader
    filename = 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/clear/5865e0dc03e5490db3d836b5ffacfaa1/03/54/401/manifest.m3u8'
    downloader = IsmFD

# Generated at 2022-06-12 17:02:04.191217
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

# Generated at 2022-06-12 17:02:15.609773
# Unit test for function extract_box_data
def test_extract_box_data():
    def gen_box(box_type, box_data=b''):
        return box(box_type, box_data)

    box_data = gen_box(b'ftyp') + gen_box(b'moov') + gen_box(b'mvhd', gen_box(b'vmhd'))
    assert extract_box_data(box_data, (b'vmhd',)) == gen_box(b'vmhd')

    box_data = gen_box(b'ftyp') + gen_box(b'moov') + gen_box(b'mvhd',
                                                            gen_box(b'vmhd') + gen_box(b'mdhd', gen_box(b'minf')))

# Generated at 2022-06-12 17:02:28.893408
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD(IsmFD):
        def real_download(self, filename, info_dict):
            font_url = 'http://download.microsoft.com/download/E/6/7/E675FFFC-2A6D-4AB0-B3EB-27C9F8C8F696/PowerPointViewer.exe'
            print("DEBUG: Inside Mock of IsmFD")
            print("DEBUG: Downloading font from: {0}".format(font_url))
            font_file = self.ydl.temp_name('font.exe')
            font_stream = open(font_file, 'wb')
            retcode = self.ydl.urlopen(font_url, font_stream.write)
            if retcode == 0:
                font_stream.close()
                return False
            font_stream

# Generated at 2022-06-12 17:02:40.236071
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHIE
    dash = DASHIE(
        params={
            'noplaylist': True,
            'skip_unavailable_fragments': True,
            'audio_template': 'manifest/QualityLevels($Bandwidth$)/Fragments(%s=%d)',
            'ignore_namespace_attribute_error': False,
        }
    )
    fd = IsmFD(
        ydl=None,
        params={
            'test': True,
            'skip_unavailable_fragments': True,
            'audio_template': 'manifest/QualityLevels($Bandwidth$)/Fragments(%s=%d)',
        },
        ie=dash,
        video_id='foo',
    )
    return fd


# Generated at 2022-06-12 17:02:55.227664
# Unit test for function extract_box_data
def test_extract_box_data():
    box_type = 'mvex'
    box_data = extract_box_data(open('D:\\20180629141932.mp4', 'rb').read(), [b'moov', b'udta', b'meta', b'ilst'])
    print(box_data)



# Generated at 2022-06-12 17:03:04.911141
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 0,
            'height': 720,
            'width': 1280,
            'language': 'und',
            'codec_private_data': '0164001fffe10028e927808800000300010000030001ec2a715240029f50714000468ee3c80',
        })
        stream.seek(0)

# Generated at 2022-06-12 17:03:15.516330
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_urls = {'fragments': [{'duration': 3, 'url': 'http://cdnec.video.taobao.com/player/ugc/video/20160106/20160106225904_1003931266.ts?v=84529&ex_h=p6_c&ex_f=w&ex_d=p'}],
                 '_download_params': {'track_id': 1, 'fourcc': 'AVC1', 'codec_private_data': '0164001FFFE100186764001FA402816D907ACA58C80000019000168CE3980000033CB53C0',
                                      'width': 640, 'height': 360, 'duration': 3, 'timescale': 10000000}}
    with NamedTemporaryFile() as f:
        Is

# Generated at 2022-06-12 17:03:16.818204
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print(IsmFD)

# Constructor unit test
if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-12 17:03:17.696023
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-12 17:03:23.633310
# Unit test for function extract_box_data
def test_extract_box_data():
    mdat_data = u32.pack(8) + b'mdat'
    moov_data = box(b'mdat', mdat_data)
    moov_data = box(b'foob', moov_data)
    moov_data = box(b'moof', moov_data)
    assert extract_box_data(moov_data, [b'moof', b'foob', b'mdat']) == mdat_data



# Generated at 2022-06-12 17:03:35.120770
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_params = {
        'url': 'http://www.example.com/file.ism',
        'format': 'ism',
        'play_path': '',
        'manifest_params': {
            'is_live': True,
            'queue_size': -1,
        },
    }
    test_FD = IsmFD()
    test_FD.params = test_params
    test_FD.to_screen = lambda msg, *args: print(msg % args)

# Generated at 2022-06-12 17:03:43.308051
# Unit test for constructor of class IsmFD
def test_IsmFD():
    id_info = {
        'id': u'3068d9a9-9361-42c8-b0a1-eba1d6712bc8',
        'name': u'Test name',
        'uploader': u'Test channel',
        'description': u'Test description',
        'upload_date': u'20130910'
    }
    params = {
        'username': 'user',
        'password': 'pass',
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'test': True
    }
    ismfd = IsmFD(params, id_info)
    assert ismfd.FD_NAME == 'ism', \
        'IsmFD.FD_NAME should be ism, but got %s' % ismfd

# Generated at 2022-06-12 17:03:48.617221
# Unit test for constructor of class IsmFD
def test_IsmFD():
    video_url = 'https://example.com/video.ism/Manifest'
    download = IsmDownload(video_url)
    info_dict = download.extract()
    download2 = IsmDownload(video_url)
    assert download == download2



# Generated at 2022-06-12 17:03:58.202139
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .utils import urlopen
    from .compat import compat_urllib_parse
    ie = InfoExtractor()
    ie.add_info_extractor(IsmFD())
    url = 'http://wams.edgesuite.net/media/MPTExpressionData02/BigBuckBunny_720p_30fps_st_aac_16x9_1mbps.ism/manifest'
    res = urlopen(url).read()
    info_dict = compat_urllib_parse.parse_qs(res)
    info_dict = dict([(x, y[0]) for x, y in info_dict.items()])
    info_dict['url'] = url
    info_dict['ext'] = 'ism'

# Generated at 2022-06-12 17:04:31.689095
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:04:34.397325
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ismFD = IsmFD({})
    fd = ismFD

    assert(fd.FD_NAME == 'ism')


# Generated at 2022-06-12 17:04:41.919191
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import FragmentFD
    youtube_dl = mock.MagicMock()
    youtube_dl.params = {}
    ism_fd = IsmFD(youtube_dl)

# Generated at 2022-06-12 17:04:43.737426
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Create an instance of class IsmFD
    IsmFD(params={})

# Generated at 2022-06-12 17:04:53.139722
# Unit test for function write_piff_header
def test_write_piff_header():
    import json
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1576,
        'timescale': 44100,
        'language': 'und',
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
    }
    f = io.BytesIO()
    write_piff_header(f, params)
    piff_header = f.getvalue()
    print(binascii.hexlify(piff_header))
    out = io.open('test.ismv', 'wb')
    out.write(piff_header)
    out.close()
# test_write_piff_header()



# Generated at 2022-06-12 17:05:02.184223
# Unit test for function write_piff_header
def test_write_piff_header():
    header_data = b''

# Generated at 2022-06-12 17:05:08.755486
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'language': 'und',
        'fourcc': 'H264',
        'duration': 14000000,
        'timescale': 10000000,
        'height': 0,
        'width': 0,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    return stream.getvalue()



# Generated at 2022-06-12 17:05:18.178567
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x20\x64\x69\x6d\x6d\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x6d\x6d\x6f\x64\x00\x00\x00\x0c\x6d\x6e\x6f\x6f\x00\x00\x00\x06\x6d\x6e\x6f\x6f\x76\x00'

# Generated at 2022-06-12 17:05:27.335693
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000000,
        'timescale': 10000000,
        'language': 'und',
        'width': 0,
        'height': 0,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)
    data = stream.getvalue()
    assert len(data) == 1084
    assert data[0:8] == b'\x00\x00\x04\x1cftyp'
    assert data[8:12] == b'isml'

# Generated at 2022-06-12 17:05:29.295868
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({})
    assert isinstance(fd, IsmFD)


# Generated at 2022-06-12 17:06:26.014656
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = (b'moov', b'trak', b'mdia')

# Generated at 2022-06-12 17:06:27.680774
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD()
    except Exception:
        pass

# Generated at 2022-06-12 17:06:29.721259
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .ism import IsmFD
    from .fragment import FragmentFD
    
    ismfd = IsmFD()

# Generated at 2022-06-12 17:06:33.387869
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Init IsmFD
    ismFD = IsmFD()
    # generate test data
    filename = ""
    info_dict = {}
    # call method real_download
    ismFD.real_download(filename, info_dict)

# Generated at 2022-06-12 17:06:41.035518
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    ydl = YoutubeDL(YoutubeDL.get_default_config())

# Generated at 2022-06-12 17:06:48.071624
# Unit test for function write_piff_header
def test_write_piff_header():
    box_position = 0
    box_type = 0
    box_size = 0
    
    audio_params = {
        'track_id': 1, 'fourcc': 'AACL', 'duration': 10000000, 'timescale': 48000,
        'sampling_rate': 48000, 'channels': 2, 'bits_per_sample': 16, 'language': 'und'
    }
    

# Generated at 2022-06-12 17:06:54.186452
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('url')
    assert fd.FD_NAME ==  'ism'
    assert fd.params ==  {}
    assert fd.available() ==  False
    assert fd.test(test = True) ==  True
    assert fd.download('filename') ==  False



# Generated at 2022-06-12 17:07:01.236546
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen

    def _test_piff_header(params):
        stream = io.BytesIO()
        write_piff_header(stream, params)
        stream.seek(0)
        try:
            return compat_urlopen('data:application/octet-stream,' + encode_data_uri(stream.read())).read()
        except compat_urllib_error.HTTPError:
            return b''

    assert _test_piff_header({
        'fourcc': 'AACL',
        'track_id': 1,
        'codec_private_data': '0000000199',
        'duration': 500000000,
        'sampling_rate': 44100,
    }) == b''
    # assert _test_piff_

# Generated at 2022-06-12 17:07:02.521816
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Test for method real_download of class IsmFD
    """
    pass



# Generated at 2022-06-12 17:07:03.445078
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # TODO
    return None