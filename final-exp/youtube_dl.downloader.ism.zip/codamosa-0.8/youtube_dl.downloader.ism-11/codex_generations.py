

# Generated at 2022-06-12 16:59:56.685351
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    if False:
        test_IsmFD_real_download()
    # Check real_download function of module youtube_dl.extractor.ism
    # Check execution flow:
    # Assertion if ctx['fragment_index'] == 0 and ctx['total_frags'] == 1
    # Exception thrown if True
    # Assertion if ctx['fragment_index'] == 0 and ctx['total_frags'] == 1
    # Exception thrown if True
    # Assertion if ctx['fragment_index'] == 0 and ctx['total_frags'] == 1
    # Exception thrown if True
    # Assertion if ctx['fragment_index'] == 0 and ctx['total_frags'] == 1
    # Exception thrown if True
    # Assertion if ctx['fragment_

# Generated at 2022-06-12 17:00:02.544438
# Unit test for function write_piff_header
def test_write_piff_header():
    # 1) Test when generating an QAAC audio file
    buf = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000,
        'timescale': 48000,
        'language': 'eng',
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(buf, params)

# Generated at 2022-06-12 17:00:10.441392
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    info_dict = {'fragments': ['frag1', 'frag2']}
    # Call method, here filename and ctx are unused
    IsmFD.real_download('filename', info_dict)

    # Asserts
    # TODO: Implement unit tests for method real_download of class IsmFD


# End of Unit test for method real_download of class IsmFD (auto-generated)



# Generated at 2022-06-12 17:00:20.092374
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import pytest
    from utils import prepare_mock_downloader
    from ytdl.extractor import Manifest
    
    with prepare_mock_downloader() as (downloader, info_dict):
        info_dict['url'] = 'http://example.com/manifest.ism/manifest'
        info_dict['_type'] = 'ism'
        manifest = Manifest(downloader, info_dict)
        
        info_dict['fragments'] = manifest.get_fragments_info()
        
    IsmFD(downloader, info_dict).real_download('/tmp/test.mp4', info_dict)


# Generated at 2022-06-12 17:00:34.134699
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:00:45.941061
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    URL = 'http://example.com/playlist.ism/Manifest'
    # json from example.com/playlist.ism/Manifest
    with open("test/test_IsmFD_real_download_files/playlist.ism%2FManifest.json", "rb") as f:
        json_str = f.read()
    playlist = json.loads(json_str.decode('utf-8'))
    params = {'track_id': 1, 'fourcc': b'AACL', 'duration': 42949672960, 'timescale': 10000000, 'language': b'und', 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 48000}
    params_ = params.copy()

# Generated at 2022-06-12 17:00:51.412363
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'duration': 1400,
              'timescale': 1000,
              'track_id': 1,
              'language': 'eng',
              'sampling_rate': 16000,
              'channels': 1
              }
    stream = io.BytesIO()
    write_piff_header(stream, params)

test_write_piff_header()


# Generated at 2022-06-12 17:00:54.478498
# Unit test for function extract_box_data
def test_extract_box_data():
    size = u32.pack(40)
    type = b'test'
    data = b'testdata'
    assert extract_box_data(size + type + size + type + data, [type, type]) == data



# Generated at 2022-06-12 17:01:07.077892
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    output.write(u32.pack(0))  # placeholder for size
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 2000000000,
        'timescale': 10000000,
        'width': 960,
        'height': 540,
        'codec_private_data': '01640028ffe1000568ce0300',
    }
    write_piff_header(output, params)
    output = output.getvalue()
    ftyp = output[:16]
    moov = output[16:]
    assert len(ftyp) == 16
    assert len(moov) == 548
    assert ftyp == b'ftyp'

# Generated at 2022-06-12 17:01:21.233956
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:01:37.806117
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    # Write PIFF header
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'height': 480,
        'width': 854,
        'duration': 12000,
        'timescale': 12000,
        'language': 'eng',
        'nal_unit_length_field': 4,
        'codec_private_data': '01640028ffe1001467640028ac2c8080',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:01:41.254340
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # TODO:
    pass


# Generated at 2022-06-12 17:01:51.825743
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://glbnationwide-vh.akamaihd.net/i/HD_LIVESTREAM_GEO_ONEWAY/3CCB7B924C55CF05834FFB63769E7D10_,59,416,832,1248,_MPEG_4_LIVE_.ism/manifest(format=m3u8-aapl-v3)'

# Generated at 2022-06-12 17:01:59.479872
# Unit test for constructor of class IsmFD
def test_IsmFD():
    stream = IsmFD('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest', {})
    assert stream.url == 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    assert stream.params == {}

# Generated at 2022-06-12 17:02:12.192046
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import try_get
    from .common import parse_xml, Mimetype
    from .downloader import WgetDownloader
    from .utils import encodeFilename
    from .compat import compat_urllib_request, compat_urllib_error
    from .external import find_executable


# Generated at 2022-06-12 17:02:21.393523
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:02:25.932513
# Unit test for constructor of class IsmFD
def test_IsmFD():
    _t = IsmFD({'url': 'http://example.com'}, {}, None)
    assert _t.downloader is None
    assert _t.params == {}
    assert _t.fd_name == "ism"



# Generated at 2022-06-12 17:02:38.326907
# Unit test for function extract_box_data
def test_extract_box_data():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'duration': 250000,
            'timescale': 1000,
            'height': 720,
            'width': 1280,
            'language': 'eng',
            'fourcc': 'H264',
            'codec_private_data': '000000016742C01E971DFB80A000001F6740028DE278000000300803E9000001F6640011044E27B00000F43A00000167640011044E27B00000F43A0000024F72656D706C65466C61670000000000000000000000000000000000000000000000000000000000000000000000000000000000000000028E0',  # noqa
        })
        R0 = stream.getvalue()


# Generated at 2022-06-12 17:02:41.760275
# Unit test for function write_piff_header
def test_write_piff_header():
    # Currently the function's output tested by function test_mp4v2_download_and_convert()
    # TODO: write a proper unit test for it
    pass



# Generated at 2022-06-12 17:02:53.419369
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_fd = IsmFD({})
    test_fd.real_download = lambda filename, info_dict: True
    test_fd.download = lambda filename: False

# Generated at 2022-06-12 17:03:13.101946
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import Downloader
    from .downloader import get_suitable_downloader
    from .extractor import is_m3u8
    from .extractor import is_ism

    downloader = Downloader(
        get_suitable_downloader('http://example.com/foo.ism/Manifest'))
    info = downloader.extract_info(
        False,
        {'url': 'http://example.com/foo.ism/Manifest'},
        False,
        False)

    # assertIsInstance(info, dict)
    assert is_ism(info)

if __name__ == '__main__':
    # test_IsmFD()
    pass

# Generated at 2022-06-12 17:03:20.881455
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_ytdl = YoutubeDL({})
    # Boring test:
    #  test_ytdl.add_info_extractor(IsmIE)
    #  test_ytdl.add_info_extractor(MssIE)
    #  test_ytdl.add_info_extractor(DashIE)
    #  test_ytdl.download(['http://smf.blob.core.windows.net/samples/videos/bigbuckbunny.ism/Manifest'])
    test_ytdl.add_info_extractor(IsmIE)
    #test_ytdl.download(['http://www.nasa.gov/multimedia/nasatv/NTV-Public-IPS.m3u8'])

# Generated at 2022-06-12 17:03:33.495999
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 4 * 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    with io.BytesIO() as stream:
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:03:39.150596
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import OnDemandPagedList
    f = io.BytesIO()
    video_params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 3000000000,
        'timescale': 10000000,
        'language': 'und',
        'codec_private_data': '000000016764001facd95401e10000000168ce03f80',
        'width': 640,
        'height': 480,
    }

# Generated at 2022-06-12 17:03:46.778414
# Unit test for function extract_box_data
def test_extract_box_data():
    with io.BytesIO(
        b'moov' + u32.pack(len(b'mvhd') + 8) + b'mvhd' + u8.pack(0) + u32.pack(0) * 2 + u32.pack(1) * 2
    ) as reader:
        assert extract_box_data(reader.read(), (b'moov', b'mvhd')) == u8.pack(0) + u32.pack(0) * 2 + u32.pack(1) * 2

# Generated at 2022-06-12 17:03:48.409130
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Test method real_download of class IsmFD"""
    pass

# Generated at 2022-06-12 17:03:58.127758
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import os
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError

    with open('test.ismv', 'wb') as t:
        pass

    # Test upto date version
    ydl = YoutubeDL({'outtmpl': 'test.ismv'})
    ydl.add_info_extractor('ism')
    test_url = 'http://video.ch9.ms/ch9/1b2d/09a5e6f9-6c45-4a99-8b5d-67227e6c1b2d/PIFF_INF_2.mp4'
    with ydl:
        try:
            # Download a video to test
            ydl.download([test_url])
        except DownloadError as e:
            pass

    os.remove

# Generated at 2022-06-12 17:04:06.363217
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x0cmoov' + b'\x00\x00\x00\x04trak' + b'\x00\x00\x00\x04mdia' + b'\x00\x00\x00\x04mvhd' + b'\x00\x00\x00\x14\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x05'

# Generated at 2022-06-12 17:04:11.964184
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    fd.real_download(fd.fd_name,fd.fd_info_dict)
    test_fragment_fd('ism',fd.fd_name,fd.fd_info_dict)

if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-12 17:04:20.022684
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys

    params = {
        'url': 'http://wamsprd22001.origin.mediaservices.windows.net/5d5c38a1-7f4e-4f4d-b2ab-bb7a51b5c5b5/5d5c38a1-7f4e-4f4d-b2ab-bb7a51b5c5b5_c.ism/Manifest',
        'skip_unavailable_fragments': True
    }
    fd = IsmFD(params, None)

# Generated at 2022-06-12 17:04:39.479394
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD

    for ie in gen_extractors():
        if ie.IE_NAME == 'ism':
            fd = ie.ie_key_map['ism'](ie)
    assert isinstance(fd, IsmFD)



# Generated at 2022-06-12 17:04:45.657502
# Unit test for constructor of class IsmFD
def test_IsmFD():

    test_url = 'http://www.youtube.com/watch?v=t12345678901'

    # Create a testinfo_dict
    yt_info = {'url': test_url}

# Generated at 2022-06-12 17:04:56.175999
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:05:03.734276
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['test'] = True
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['fragment_retries'] = 3

    dummy_fragment = {
        'url': 'http://foo.com/bar.ism',
        'duration': 2,
        'title': 'title',
        'fragment_index': 0,
    }

    dummy_segment_list = [dummy_fragment]


# Generated at 2022-06-12 17:05:14.743555
# Unit test for constructor of class IsmFD
def test_IsmFD():

    class _DummyYDL(object):
        def __init__(self):
            self.params = {}
            self.logger = None

    ydl = _DummyYDL()
    test_ism_url_fragment = 'http://playready.directtaps.net/144/smoothstreaming/TTLSS720VC1/To_The_Limit_720.ism/QualityLevels(30000)/Fragments(video=0)'

# Generated at 2022-06-12 17:05:21.512618
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    video_id = 'ZL_1'
    dest_stream = io.BytesIO()

# Generated at 2022-06-12 17:05:33.668890
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ctx = {'dest_stream': open('test.ismv', 'wb'), 'frag_downloader': lambda x, y: (False, 'frag_content')}
    info_dict = {'_download_params': {'track_id': 2, 'duration': 98753,
                  'sampling_rate': 48000, 'fourcc': 'AACL', 'channels': 2, 'bits_per_sample': 16}}
    fd = IsmFD()

    segments = [
        {'url': 'http://example.com/a'},
        {'url': 'http://example.com/b'},
        {'url': 'http://example.com/c'}
    ]
    assert fd._real_download(ctx, segments, info_dict)

# Generated at 2022-06-12 17:05:37.637954
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test manual constructor
    ydl = YoutubeDL(YoutubeDL().params)
    fd = IsmFD(ydl, ydl.params)
    assert fd.ydl is ydl


# Generated at 2022-06-12 17:05:45.429322
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:05:57.273124
# Unit test for function write_piff_header
def test_write_piff_header():

    params = {
        'track_id': 1,
        'duration': 2000,
        'timescale': 90000,
        'width': 1280,
        'height': 720,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'nal_unit_length_field': 4,
        'codec_private_data': '01640023ffe1001f674d40101036e76d68640023e9a02d006b280003004000013688b3c403ec3d1f93aefd3002c4e34000020f4d400b52207e4e13f3f821e1d7eef',
    }

    f = io.BytesIO()

# Generated at 2022-06-12 17:06:27.891378
# Unit test for function write_piff_header
def test_write_piff_header():
    from .common import MPD_SOURCE_PREFIX
    from ..utils import encode_data_uri

    audio_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'duration': 1999,
    }
    video_params = {
        'track_id': 2,
        'fourcc': 'H264',
        'width': 1280,
        'height': 720,
        'codec_private_data': '000000016742C00D9654040A029009583F700000168CE3880',
        'duration': 1999,
    }
    stream = io.BytesIO()

# Generated at 2022-06-12 17:06:33.018264
# Unit test for function extract_box_data
def test_extract_box_data():
    data_reader = io.BytesIO(b'\xff' * 10)
    print(repr(extract_box_data(data_reader.read(), [b'fmp4'])))
    data_reader.seek(0, 0)
    print(repr(extract_box_data(data_reader.read(), [b'styp'])))



# Generated at 2022-06-12 17:06:40.784809
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Initializing FDs
    ismFD = IsmFD()
    # Testing whether the ISM FD is compatible with the given URL
    assert ismFD.suitable(
        'http://amssamples.streaming.mediaservices.windows.net/83f5e59d-ad5a-4eb3-b5f4-4ae24bfab4d1/TOS-trailer.ism/manifest(format=mpd-time-csf)') is True
    assert ismFD.suitable(
        'https://public.tableau.com/workbooks/Tableau_Desktop_Version_Comparison.twb') is False
    # Testing file extension
    assert ismFD.file_ext() == 'ism'

    # Mocking __init__ method

# Generated at 2022-06-12 17:06:47.943761
# Unit test for function write_piff_header
def test_write_piff_header():
    from . import aac
    from . import avc
    from . import hds
    from . import hls
    from . import mp4
    from . import smoothstreams
    from .extractor import (
        AudioStream,
        VideoStream,
        FileDescriptor,
        MediaStream,
        Track,
        AudioTrack,
        VideoTrack,
        FragmentedMediaStream,
    )


# Generated at 2022-06-12 17:06:58.681239
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import os
    import ssl
    import tempfile
    from .common import FakeYDL

    # Creating a temporary output file
    output_file = tempfile.mktemp(prefix='test_IsmFD', suffix='.ism')

    sctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
    sctx.load_verify_locations(cafile='D:\\yufei\\git\\youtube-dl\\test\\test_data\\ca-bundle.pem')

    fake_ydl = FakeYDL()

# Generated at 2022-06-12 17:07:07.862948
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..compat import compat_string_type, compat_chr
    from .fragment import FragmentFD
    from ..utils import determine_ext
    from io import BytesIO

    params = {
        'fourcc': 'H264',
        'width': 640,
        'height': 360,
        'track_id': 1,
        'duration': 777,
        'sampling_rate': 44100,
        'codec_private_data': '0164001fffe100b27f64000facd940800c1096003e902f47b80800200003000120003000401fb85921e5',
    }
    piff_file_path = determine_ext('', 'piff')
    stream = BytesIO()
    fd = FragmentFD(stream, 'wb')
    write_

# Generated at 2022-06-12 17:07:12.257902
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(21) + b'ftyp'
    data += u32.pack(7) + b'moov'
    data += u32.pack(5) + b'mvhd'
    assert(extract_box_data(data, [b'ftyp', b'moov', b'mvhd']) == b'')



# Generated at 2022-06-12 17:07:19.680718
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:07:26.105260
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    '''Test real_download of class IsmFD'''
    print('Testing real_download')
    ydl = YoutubeDL({})
    ydl.add_info_extractor(youtube_ie)
    ydl.add_info_extractor(MSNIE())
    ydl.add_info_extractor(IsmIE())
    ydl.add_info_extractor(IsmFD)
    ydl._ies = [IsmFD()]
    ydl.prepare_filename('http://b20vodhls-f.akamaihd.net/i/mp4root/BigBuckBunny_640x360_500k,500k,1000k,1600k,2500k,4000k,_550.mp4/master.m3u8')

# Generated at 2022-06-12 17:07:34.932102
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 100,
        'width': 640,
        'height': 360,
        'codec_private_data': (
            '000000016764001f9a0f00000168ee3c88'
            'c0'),
    })

# Generated at 2022-06-12 17:08:16.164820
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        track_id = 0xF
        sampling_rate = 44100
        fourcc = 'AACL'
        channels = 2
        bits_per_sample = 16
        duration = 1000000
        write_piff_header(stream, {'fourcc': fourcc, 'track_id': track_id, 'sampling_rate': 44100, 'duration': duration})

# Generated at 2022-06-12 17:08:19.423796
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 17:08:26.962865
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:08:34.088418
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys
    import os
    sys.path.insert(0,os.path.abspath('../../'))
    from ydl import YoutubeDL
    ydl = YoutubeDL({
        "outtmpl": "%(id)s",
        "fragment_retries": 100,
        "skip_unavailable_fragments": True,
        "keepvideo": True,
        "writesubtitles": True
    })
    IsmFD(ydl=ydl)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:08:36.735729
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Constructor of class IsmFD
    IsmFD('http://media.example.com/p/360p.ism/Manifest', {})

    # Constructor of class FragmentFD
    FragmentFD('http://media.example.com/p/360p.ism/Manifest', {})

# Generated at 2022-06-12 17:08:41.485990
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import os
    import tempfile
    # https://www.youtube.com/watch?v=pf6Oi7VZ0zE
    sys.argv = ['test_IsmFD_real_download', '-u', 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/clear/08b68f09b8617a89d3f8b7d0580811c17a7f9e9b8a61d2a1fbc32bc2d8978d8d/1/master.m3u8']
    ydl = YoutubeDL( {} )
    fd = IsmFD( ydl )

# Generated at 2022-06-12 17:08:45.726176
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(
        b'\x00\x00\x00\x3cmoov\x00\x00\x00\x2ctrak\x00\x00\x00\x00mdia\x00\x00\x00\x00minf\x00\x00\x00\x00dinf\x00\x00\x00\x00dref\x00\x00\x00\x00url ',
        (b'dref', b'url ')
    ) == b''



# Generated at 2022-06-12 17:08:52.111926
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import os
    import tempfile
    import shutil
    from .downloader import YoutubeDL
    from .compat import urllib_error
    from .utils import DateRange


# Generated at 2022-06-12 17:09:01.631091
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class options:
        username = 'spiderman'
        password = 'PeterParker'
        ap_mso = 'WWE'
        force_generic_extractor = True
        skip_unavailable_fragments = False
        hls_fragment_retries = 0
        hls_use_mpegts = True

    class infoDict:
        pass

    class params:
        pass

    opts = options()
    params = params()

    info = infoDict()
    info['fragments'] = [{'url': 'https://ssl-live-ism.20150402.cdn.cloud9.zone/ismlive/live/live/live/wwe/wwe/wwe_1600.ism/QualityLevels(650000)/Fragments(audio=VideoPlayer=127810)'}]

# Generated at 2022-06-12 17:09:10.352048
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # This test requires the YouTube to be open
    # Open YouTube : http://www.youtube.com/
    from .youtube_dl.extractor import youtube
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.utils import EncodingsFile

    info_dict = {}

    video_id = 'WmVYZWkmIy4'
    url = 'http://www.youtube.com/watch?v=%s' % video_id

    youtube_dl = YoutubeDL({'simulate': True, 'quiet': True})

    # Obtain the video webpage and set in info_dict
    youtube.extract(youtube_dl, {'url': url})
    info_dict = youtube_dl.extract_info(url, download=False)