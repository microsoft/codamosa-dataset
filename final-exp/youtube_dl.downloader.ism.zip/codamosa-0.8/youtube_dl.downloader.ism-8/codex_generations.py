

# Generated at 2022-06-12 16:59:43.652035
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 2,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'height': 1080,
        'width': 1920,
    }
    write_piff_header(stream, params)
    stream.seek(0)
    print(stream.read().encode('hex'))



# Generated at 2022-06-12 16:59:48.931185
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = YoutubeDL({})
    fd = IsmFD(downloader)
    IsmFD.download = lambda *_: True
    assert fd.real_download(
        "foo.ism",
        {
            "fragments": [
                {
                    "url": "http://example.com/foo.ism/Streams(video-1)"
                },
                {
                    "url": "http://example.com/foo.ism/Streams(audio-1)"
                },
            ]
        }
    )


# Generated at 2022-06-12 16:59:57.002299
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    from itertools import izip, cycle

    def _encode_hex(stream):
        for b in stream:
            yield '%02x' % b

    f = FragmentFD(BytesIO())
    params = {}
    params['track_id'] = 1
    params['height'] = 0
    params['width'] = 0
    params['duration'] = 1
    params['fourcc'] = 'mp4a'
    params['sampling_rate'] = 48000
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['language'] = 'und'
    write_piff_header(f.stream, params)

# Generated at 2022-06-12 17:00:02.822837
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    try:
        from urllib.parse import urlsplit
    except ImportError as e:
        from urlparse import urlsplit
    from ...compat import (
        compat_urllib_error,
        compat_urllib_request,
    )
    from ...utils import (
        str_or_none,
        struct,
        struct_unpack,
        urlencode_postdata,
        unified_strdate,
    )
    from .ism import (
        IsmFD,
    )

    class _MockInfoDict(dict):
        pass

    class _MockYDL(object):
        def __init__(self):
            self.params = {
                'test': False,
            }
            self.report_error = self._report_error

# Generated at 2022-06-12 17:00:08.590984
# Unit test for function extract_box_data
def test_extract_box_data():
    def test_extract_box_data_sub(data, box_sequence, expected):
        assert extract_box_data(data, box_sequence) == expected
    from ..compat import compat_chr
    data = u32.pack(8) + b'moov' + (u32.pack(16) + b'mvhd' + u32.pack(0) * 3)
    test_extract_box_data_sub(data, [b'moov'], u32.pack(16) + b'mvhd' + u32.pack(0) * 3)
    test_extract_box_data_sub(data, [b'mvhd'], u32.pack(0) * 3)


# Generated at 2022-06-12 17:00:20.666541
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    f = tempfile.TemporaryFile()
    write_piff_header(
        f,
        {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10000,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
        })
    f.seek(0)

# Generated at 2022-06-12 17:00:34.865551
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialize objects
    video_url = "https://fra-download.video.itunes.apple.com/videoplayback/A1QCngX-NxgQAKdByzdEYPjHhfZWOiZ/14/1628/1628.m4s?cid=3216943722&frmt=sg_web&sbls=sbls_url&srb=sim&sv=false&v=900000&e=1593411100&h=68a20a09f1334ca05dcf9c7c4e3d4e7f"
    dest_stream = io.BytesIO()

# Generated at 2022-06-12 17:00:42.433713
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('/tmp/piff_header.tmp', 'wb') as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'duration': 20000000,
            'timescale': 10000000,
            'fourcc': 'AACL',
            'sampling_rate': 48000,
            'channels': 2,
            'bits_per_sample': 16,
        })

# Generated at 2022-06-12 17:00:50.118471
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("test_IsmFD\n=====")
    params = {
        "url": "http://www.youtube.com/watch?v=hKHZhxp3sKo&feature=fvwrel",
        "istest": True
    }
    ismfd = IsmFD(params)
    print("\n===== end test_IsmFD\n")


if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-12 17:00:55.675907
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd.FD_NAME == 'ism'
    assert fd.params == {}
    assert fd.seg_index is None
    assert fd.title is None
    assert fd.url is None
    assert fd.continued is False


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:01:14.460451
# Unit test for constructor of class IsmFD
def test_IsmFD():
    frag_url = 'http://video.pl/manifest.isml/QualityLevels(220000)/Fragments(video=17000)'
    ismfd = IsmFD(params={}, info_dict={'fragments': [{'url': frag_url}]})
    assert ismfd.FD_NAME == 'ism'



# Generated at 2022-06-12 17:01:27.611591
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest_url = 'https://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    params = {
        'filesize': '-1',
        'format': 'ism',
        'fragment_retries': '10',
        'headers': 'Origin=http%3A%2F%2Fwww.nfl.com\r',
        'http_chunk_size': '100000000',
        'prefer_insecure': 'yes',
        'skip_unavailable_fragments': 'yes',
        'test': 'yes',
        'playlistend': '1',
        'playliststart': '1',
    }

    def test_download(url):
        youtube_dl_Object = youtube_dl.YoutubeDL

# Generated at 2022-06-12 17:01:36.481452
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1234567890000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    f = io.BytesIO()
    write_piff_header(f, params)
    written = f.getvalue()
    assert u32.unpack(written[:4])[0] == 1024
    assert written[12:16] == b'moov'
    assert u32.unpack(written[16:20])[0] == 976

# Generated at 2022-06-12 17:01:38.513278
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    assert True  # TODO: implement your test here


# Generated at 2022-06-12 17:01:46.492848
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ctx = {"prepare_and_start_frag_download":(lambda self_, ctx: None),
           "download_fragment":(lambda self_, ctx, arg1, info_dict: (True, 'frag_content')),
           "append_fragment":(lambda self_, ctx, frag_content: None),
           "finish_frag_download":(lambda self_, ctx: None),
           "report_retry_fragment":(lambda self_, err, frag_index, count, fragment_retries: None),
           "report_skip_fragment":(lambda self_, frag_index: None),
           "report_error":(lambda self_, err_msg: None)}

# Generated at 2022-06-12 17:01:56.344517
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0x1,
        'fourcc': "AACL",
        'duration': 1000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'codec_private_data': "1408"
    }
    write_piff_header(stream, params)
    print(binascii.hexlify(stream.getvalue()))


# Generated at 2022-06-12 17:01:57.763671
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-12 17:02:05.357734
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest

    class ExtractBoxDataTest(unittest.TestCase):
        def test_extract_box_data(self):
            data = (
                b'\x00\x00\x00\x00'
                b'box1'
                b'\x00\x00\x00\x00'
                b'box2'
                b'\x00\x00\x00\x00'
                b'box3'
            )
            self.assertEqual(extract_box_data(data, (b'box2',)), b'')
            self.assertEqual(extract_box_data(data, (b'box1', b'box2')), b'')

# Generated at 2022-06-12 17:02:14.514794
# Unit test for function extract_box_data
def test_extract_box_data():
    from .fragment import (
        test_header_fragment_metadata,
        test_header_fragment_data,
    )
    metadata_content = extract_box_data(test_header_fragment_metadata, (b'moov', b'mdat'))
    data_content = extract_box_data(test_header_fragment_data, (b'moov', b'mdat'))
    assert len(metadata_content) == 0
    assert len(data_content) == 4
    assert u32.unpack(data_content)[0] == 0x0037e2f1

# Generated at 2022-06-12 17:02:27.241149
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Test IsmFD.real_download()."""
    video_url = 'ism/azure/624/624.ism/Manifest'

# Generated at 2022-06-12 17:06:34.165246
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264PR/SuperSpeedway_720.ism/Manifest'
    help_test_download_url(url, IsmFD)


# Generated at 2022-06-12 17:06:37.947919
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

test_IsmFD_real_download.__annotations__ = dict(
    self='IsmFD',
    filename=str,
    info_dict=dict
)


# Generated at 2022-06-12 17:06:47.936294
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .compat import parse_qs
    from .extractor.common import InfoExtractor
    from .common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None, params=None):
            if params is None:
                params = {}
            super(FakeInfoExtractor, self).__init__(downloader=downloader, params=params)
            self._ies = gen_extractors()
            self._ies.append(self)


# Generated at 2022-06-12 17:06:59.341263
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 30,
        'timescale': 10000000,
        'language': 'eng',
        'codec_private_data': '0164001fffe1001667640020acb997a00148e230005c89e484005',
        'width': 640,
        'height': 480
    }

# Generated at 2022-06-12 17:07:10.017760
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # Set test environment
    os.environ['YOU_GET_TEST'] = 'test'

    # Set test resources
    # Write file to caches directory
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    with open(os.path.join(cache_dir, 'a.frag'), 'wb') as f:
        f.write(b'aaaaaaaaaa')
    with open(os.path.join(cache_dir, 'b.frag'), 'wb') as f:
        f.write(b'bbbbbbbbbb')
    with open(os.path.join(cache_dir, 'c.frag'), 'wb') as f:
        f.write(b'cccccccccc')

    # Prepare test data
    test_data = dict()

# Generated at 2022-06-12 17:07:16.768277
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test with a live stream
    ismFD = IsmFD({'url': 'http://smoothstreaming.wondershare.com/video/fine-cuisine-hd-medium-5mb-manifest.ism/Manifest?cid=0'})
    ismFD.download({'test': True})


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:07:24.324212
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL(params={})
    idict = {
        '_type': 'playlist',
        'id': 'PLu1tG0bDRVv2_nBJ8fqG3q0h7JHMHdXwb',
        'title': 'title',
    }
    ie = ISMPlaylistIE(ydl)
    result = ie._real_extract(idict)
    assert result['title'] == idict['title']
    assert result['id'] == idict['id']
    assert 'entries' in result


test_cases = [
    test_IsmFD,
]

if __name__ == '__main__':
    for test_case in test_cases:
        ret = test_case()
        assert ret == True

# Generated at 2022-06-12 17:07:32.489717
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("IsmFD Test: test_IsmFD")
    test_IsmFD_instance = IsmFD({'username': '123', 'password': '123'}, {'fragments_metadata': '1'}, {})
    print("IsmFD Test: test_IsmFD_instance {0}".format(test_IsmFD_instance))
    assert test_IsmFD_instance
    print("IsmFD Test: test_IsmFD PASS")


# Generated at 2022-06-12 17:07:45.065201
# Unit test for function extract_box_data
def test_extract_box_data():
    box_stream = io.BytesIO()
    box_stream.write(u32.pack(4) + b'aaa0')
    box_stream.write(u32.pack(8) + b'aaa1')
    box_stream.write(u32.pack(16) + b'aaa2')
    box_stream.write(u32.pack(20) + b'aaa3')
    box_stream.write(u32.pack(28) + b'aaa4')
    box_stream.write(u32.pack(48) + b'aaa5')
    box_stream.write(u32.pack(56) + b'aaa6')
    box_stream.seek(0, 0)
    expected_data = box_stream.read(4 + 8 + 16 + 20)

# Generated at 2022-06-12 17:07:53.750541
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=1059063783001'
    params = {'ratebypass': 'yes', 'noplaylist': True}

    # Get the cookies
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36'}
    mobj = compat_urllib_request.Request(url, None, headers)
    cj = compat_cookiejar.CookieJar()