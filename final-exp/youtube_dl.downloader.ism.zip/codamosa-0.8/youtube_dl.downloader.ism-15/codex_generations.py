

# Generated at 2022-06-12 16:59:44.212985
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'H264',
        'track_id': 1,
        'codec_private_data': '0000000167640033ACD904D0C8FFFE00E29FEFA8982E800342C00FC4DD2B3880',
        'duration': 90000,
        'width': 720,
        'height': 480
    }
    write_piff_header(stream, params)
    assert len(stream.getvalue()) == 652



# Generated at 2022-06-12 16:59:55.005237
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:00:03.405227
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """ Test the constructor of IsmFD object """
    from .dashsegments import SegmentFD
    from .http import HttpFD
    from .http import HlsFD
    from .wvm import WvmFD
    from .smoothstreams import SmoothstreamsFD
    from .mpd import MpdFD
    from .f4m import F4mFD
    from .dummy import DummyFD
    from .downloader import Downloader
    ydl = Downloader()

# Generated at 2022-06-12 17:00:06.512426
# Unit test for function extract_box_data
def test_extract_box_data():
    box1 = box(b'box1', box(b'box2', box(b'target', b'hello')))
    assert extract_box_data(box1, [b'target']) == b'hello'


FRAGMENT_URL_PATH = '/Fragments(video={video_id},format={format_id}={fragment_id})'


# Generated at 2022-06-12 17:00:19.346171
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL()
    ydl.add_info_extractor(IsmIE())
    ydl.add_fragment_downloader(IsmFD())

    url = 'http://media.ch9.ms/ch9/7c27/6b2da7f9-24f0-4a1e-ba49-5b5dd5347c27/ngconf-keynote.ism'
    ydl.download([url])
    filename = 'ngconf-keynote.ism'
    ext = 'ism'

    # test1 IsmFD._real_download
    fd = IsmFD(ydl, {'continuedl': True, 'max_filesize': sys.maxsize})
    assert fd is not None


if __name__ == '__main__':
    test_Ism

# Generated at 2022-06-12 17:00:33.100209
# Unit test for constructor of class IsmFD
def test_IsmFD():
    info = {
        'id': 'test',
        'ext': 'ism',
        'title': 'test',
        'duration': 1,
        'creator': 'Unknown',
        'thumbnail': '',
        'description': '',
        'categories': [],
        'upload_date': '20120607',
        'uploader': 'Unknown',
        'uploader_id': 'Unknown',
        'location': '',
        'player_url': '',
        'tags': [],
        'chapters': None,
        'subtitles': None,
        'automatic_captions': None,
        'age_limit': None,
    }

    d = _common_IsmFD('http://test.com/media/media.ism', info)
    assert d.fd_name == 'ism'
   

# Generated at 2022-06-12 17:00:45.319829
# Unit test for function write_piff_header
def test_write_piff_header():
    test_stream = io.BytesIO()

# Generated at 2022-06-12 17:00:46.415902
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # IsmFD.download()
    pass

# Generated at 2022-06-12 17:00:56.853192
# Unit test for function write_piff_header
def test_write_piff_header():
    import re
    import struct
    from .test.test_compat import hex_dump

    test_data = dict(
        track_id=1,
        fourcc='H264',
        duration=10000000,
        timescale=10000000,
        language='und',
        height=720,
        width=1280,
        channels=2,
        bits_per_sample=16,
        sampling_rate=44100,
        nal_unit_length_field=4,
        codec_private_data=('67640029acd93c0201016742c01e964901e92ee80140000030001'
                            '00003006000000300600000300600000300600000300600000000000000000000000000')
    )

    test_stream = io.BytesIO()
    write_piff_header

# Generated at 2022-06-12 17:00:59.989851
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Helper method for HasExtractorsFD

# Generated at 2022-06-12 17:01:19.864116
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:01:27.509976
# Unit test for function write_piff_header
def test_write_piff_header():
    s = io.BytesIO()
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'mp4a'
    params['duration'] = 10
    params['sampling_rate'] = 44100
    params['channels'] = 2
    params['bits_per_sample'] = 16
    write_piff_header(s, params)
    print(s.getvalue())



# Generated at 2022-06-12 17:01:33.010594
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import youtube_dl
    params = {
        'url': 'http://smf.blob.core.windows.net/samples/videos/bigbuckbunny.ism/Manifest',
        'play_path': 'bigbuckbunny',
    }
    youtube_dl.add_default_caching_params(params)
    _download_geo_restricted(params, False)

# Generated at 2022-06-12 17:01:43.608708
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': int(29.0 * 10000000.0),
        'timescale': 10000000,
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:01:55.162858
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = bytes([
        0, 0, 0, 1, ord('a'),  # box size
        ord('a'), ord('b'), ord('c'), ord('d')  # box type
    ])
    assert extract_box_data(test_data, [b'abcd']) == b''
    test_data = bytes([
        0, 0, 0, 4, ord('a'),  # box size
        ord('a'), ord('b'), ord('c'), ord('d'),  # box type
        1, 2, 3, 4
    ])
    assert extract_box_data(test_data, [b'abcd']) == b'\x01\x02\x03\x04'


# Generated at 2022-06-12 17:02:01.277232
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'randomskip': 5,
        'continuedl': False,
        'logtostderr': '',
        'writedescription': ''
    }
    ydl = YoutubeDL(params)
    ydl.add_info_extractor({})
    fd = ydl.get_fd('ism')
    assert fd.FD_NAME == 'ism'


# Generated at 2022-06-12 17:02:13.610673
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:02:15.278792
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Check that IsmFD can be created
    IsmFD('http://example.com')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:02:16.614916
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:02:29.884212
# Unit test for function write_piff_header
def test_write_piff_header():
    # Retrieve test case settings
    test_case = test_cases.current
    test_case_name = test_cases.get_name()
    test_case_description = test_cases.get_description()

    # MP4Box
    print("[%s] [%s] Running MP4Box command" % (test_case_name, test_case_description))
    mp4box_command = "MP4Box -isma -out %s %s" % (test_case_output, test_case_input)
    mp4box_command_result = os.system(mp4box_command)
    if mp4box_command_result != 0:
        print("[%s] [%s] MP4Box result: %s" % (test_case_name, test_case_description, mp4box_command_result))


# Generated at 2022-06-12 17:03:04.481355
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    class FakeManifest(object):
        """
        An object that acts as a fake Manifest.
        """
        def __init__(self, data):
            self.data = data

    class FakeInfoDict(object):
        """
        An object that acts as a fake InfoDict.
        """
        def __init__(self):
            self.data = {
                'fragments': [
                    {
                        'url': '/segment/test.ism/Frag1',
                    },
                    {
                        'url': '/segment/test.ism/Frag2',
                    },
                ],
            }

    class FakeFD(object):
        """
        An object that acts as a fake FragmentFD.
        """

# Generated at 2022-06-12 17:03:15.344999
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:03:24.540642
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test case 1
    """
    Test with no params
    """
    sample_url = 'https://manifest_url'
    ism_fd = IsmFD(sample_url)
    assert ism_fd.url == 'https://manifest_url'
    assert ism_fd.params == {'nooverwrites': True, 'cachedir': False, 'test': False, 'quiet': True, 'skip_unavailable_fragments': True}
    assert ism_fd.fragment_index == 0
    assert ism_fd.is_test == False
    assert ism_fd.nooverwrites == True
    assert ism_fd.restrictfilenames == True
    assert ism_fd.proxy == None
    assert ism_fd.usenetrc == False

# Generated at 2022-06-12 17:03:28.240252
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_url = 'http://example.com/test/test.ism/manifest'
    params = {'mount_point': '/test'}
    fd_test = IsmFD(test_url, params)

# Generated at 2022-06-12 17:03:38.233894
# Unit test for function write_piff_header
def test_write_piff_header():
    class OutputStream:
        def __init__(self):
            self.b = io.BytesIO()
        def __enter__(self):
            return self.b
        def __exit__(self, exc_type, exc_value, traceback):
            if exc_type is None:
                self.b.close()

    fourcc = 'AACL'
    params = {
            'track_id': 1,
            'fourcc': fourcc,
            'duration': 1000,
            'timescale': 10000000,
            'language': 'und',
            'height': 0,
            'width': 0,
            'codec_private_data': '1210',
            'sampling_rate': 8000,
            'channels': 1,
            'bits_per_sample': 16,
            }

# Generated at 2022-06-12 17:03:46.256778
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'url'
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 280000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    info_dict = {'_download_params': params}
    segments = [{'url': url}]
    info_dict['fragments'] = segments
    _download_retval = (True, b'unused')

    class _InfoExtractor(object):
        IE_NAME = 'unused'
        params = {'skip_unavailable_fragments': True}


# Generated at 2022-06-12 17:03:47.422295
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:03:55.700026
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 2,
        'fourcc': 'AACL',  # audio
        'duration': 0,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'language': 'eng',
    }
    write_piff_header(stream, params)
    expected = b'ftypisom\x00\x00\x00\x20piffisom\x00\x00\x00\x20iso2'
    assert stream.getvalue().startswith(expected)

# Generated at 2022-06-12 17:04:04.958579
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .IsmFD import IsmFD
    from .utils import Request
    from .compat import parse_qsl
    import os
    import json
    import tempfile

    # Input variables
    filename = os.path.join(tempfile.gettempdir(), "test_IsmFD_real_download.ism")
    info_dict = {}
    info_dict['fragments'] = [{u'url': u'https://test/test.ism/QualityLevels(400000)/Fragments(video=0)'}, {u'url': u'https://test/test.ism/QualityLevels(400000)/Fragments(video=1)'}, {u'url': u'https://test/test.ism/QualityLevels(400000)/Fragments(video=2)'}]

# Generated at 2022-06-12 17:04:16.465226
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    def test_function(self):
        return self.real_download(filename, info_dict)

    filename = 'abcde'
    info_dict = {}
    info_dict['fragments'] = []
    info_dict['fragments'].append({'url': 'http://blah'})
    info_dict['fragments'].append({'url': 'http://blah'})

    info_dict['_download_params'] = {}
    info_dict['_download_params']['track_id'] = 1
    info_dict['_download_params']['fourcc'] = ""
    info_dict['_download_params']['duration'] = 0
    info_dict['_download_params']['timescale'] = 10

# Generated at 2022-06-12 17:04:58.592410
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .common import FakeYDL
    from ..compat import urlopen
    from ..utils import encode_data_uri

    # open file on disk
    ydl = FakeYDL()
    f = IsmFD(ydl, {'fragments': [], 'http_headers': {}})
    f
    assert f.total_frags == 0
    assert f.ydl is ydl
    assert f.params['http_headers'] == {}

    # open stringio
    f = IsmFD(ydl, {'fragments': [], 'http_headers': {}}, test=True)
    assert f.test is True
    f
    assert f.total_frags == 1
    assert f.ydl is ydl
    assert f.params['http_headers'] == {}

    # open data URI

# Generated at 2022-06-12 17:05:05.062877
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    try:
        tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        tmp_file.close()
        downloader = IsmFD(params)
        downloader.real_download(tmp_file.name, info_dict)
        os.remove(tmp_file.name)
    except:
        tmp_file.close()
        os.remove(tmp_file.name)
        raise


# Extractor for MS Smooth Streaming manifests

# Generated at 2022-06-12 17:05:15.769324
# Unit test for function write_piff_header
def test_write_piff_header():

    stream = io.BytesIO()

# Generated at 2022-06-12 17:05:25.822790
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file_name = u'test_write_piff_header.ismv'
    with io.open(test_file_name, 'w+b') as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 1000,
            'timescale': 10000000,
            'bits_per_sample': 16,
            'sampling_rate': 48000,
        }
        write_piff_header(stream, params)
        assert stream.seek(0, 2) == 242
    with io.open(test_file_name, 'rb') as stream:
        assert stream.read(4) == b'moov'
        assert stream.read(4) == b'\x00\x00\x00\xF2'

# Generated at 2022-06-12 17:05:38.392588
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:05:48.830771
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x45zmoof\x00\x00\x00\x28mfhd\x00\x00\x00\x00\x01\x00\x00\x00\x01traf\x00\x00\x00\x1Dtfhd\x00\x00\x00\x0C\x00\x00\x00\x01\x00\x00\x00\x01trun\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', (b'traf',))

# Generated at 2022-06-12 17:05:58.814709
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'http://dal-a.video.cdn.aol.com/content/aol.com/aolvideo/videoplaylist/aol.com/aolvideo/videoplaylist/baaf1b3d3c7a2a3864f59ff0bbb8f20e.ism/baaf1b3d3c7a2a3864f59ff0bbb8f20e-890-400.mp4'
    seg_index = 0
    seg_url = url.rsplit('.', 1)[0] + '-%d-%d.mp4' % (seg_index, 400)
    test_IsmFD_real_download()
    # response = urllib2.urlopen(seg_url)
    # test_IsmFD_real

# Generated at 2022-06-12 17:06:00.659480
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import youtube_dl
    import youtube_dl.downloader.hls
    IsmFD.real_download(youtube_dl.downloader.hls.IsmFD, "example.ism", {"fragments": [],})
    


# Generated at 2022-06-12 17:06:12.887495
# Unit test for function write_piff_header
def test_write_piff_header():
    mdat = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 50000000, 'timescale': 10000, 'height': 1080, 'width': 1920, 'codec_private_data': '0164001fffe1001000000014018c01000001190100000105010000010401000001050120002317b264700'}
    write_piff_header(mdat, params)

# Generated at 2022-06-12 17:06:25.330904
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys
    import os
    import re

    # sys.path.append(sys.path[0] + '/../../../')
    from youtubedl_api.youtube_dl.YoutubeDL import YoutubeDL
    from youtubedl_api.youtube_dl.utils import (
        compat_urllib_request,
        compat_urlparse,
        compat_urlencode,
        compat_http_client,
        compat_urllib_error
    )

    ydl_opts = {
    }
    ydl = YoutubeDL(ydl_opts)

    def downloader(url):
        def download(filename, info_dict):
            return IsmFD().real_download(filename, {'fragments': [{'url': url}]})
        return download


# Generated at 2022-06-12 17:07:46.146380
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:07:46.919835
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-12 17:07:54.367118
# Unit test for function write_piff_header
def test_write_piff_header():
    # for video stream
    params1 = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 1000,
        'language': 'cze',
        'width': 1920,
        'height': 1080,
        'codec_private_data': '67640029ffe100198e1c401fffe10017801401f1620028ee3c033c5401f9649014014000003001c8d4012201da06e00030883ffffe7c'
    }
    # for audio stream

# Generated at 2022-06-12 17:07:59.404921
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:08:08.615134
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .dash import DashFD
    from .http import HttpFD
    from .downloader import YoutubeDL
    import os
    import shutil
    for test_url in ['http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4-onDemand-mpd-AV-BS.mpd', 
            'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live/mp4-live-mpd-AV-NBS.mpd']:
        dash_fd = DashFD().download([test_url], 1)
        assert 'fps' in dash_fd.params
        assert dash_fd.params['fps'] == 25

# Generated at 2022-06-12 17:08:13.447035
# Unit test for function write_piff_header
def test_write_piff_header():
    params = dict(
        track_id=1,
        fourcc='H264',
        duration=30000,
        language='fra',
        width=1920,
        height=1080,
        codec_private_data='01640028ffec816ecb0022897c6548c85480080',
    )
    with io.BytesIO() as stream:
        write_piff_header(stream, params)
        return stream.getvalue()



# Generated at 2022-06-12 17:08:15.989081
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Testing real_download method of class IsmFD
    params = {
        'fragment_retries': 0,
        'test': False
    }
    ## TODO  write test for this method


# Generated at 2022-06-12 17:08:25.549719
# Unit test for function extract_box_data
def test_extract_box_data():
    box1_data = b'stts'
    data = u32.pack(12) + box1_data
    assert(extract_box_data(data, (b'stts',)) == box1_data)

    box2_data = b'stco'
    box1_data += u32.pack(8) + box2_data
    data = u32.pack(8+8+len(box2_data)) + box1_data
    assert(extract_box_data(data, (b'stts', b'stco')) == box2_data)

    data = u32.pack(8*5) + b'ftyp' + b'free' + b'free' + b'free' + b'free'
    box1 = b'stts'

# Generated at 2022-06-12 17:08:28.856726
# Unit test for function extract_box_data
def test_extract_box_data():
    from .test import test_extract_box_data
    test_extract_box_data(extract_box_data)
test_extract_box_data()



# Generated at 2022-06-12 17:08:36.843966
# Unit test for function write_piff_header
def test_write_piff_header():
    from .f4v import f4v_extract_frag_map, f4v_read_moof
    from .f4m import F4M, F4X
    import re
    import requests
    import os
    import json
    import contextlib

    def read_piff_segments(fobj, is_live, frag_urls, f4m_params, http_proxy):
        # Open an HTTP connection to the first fragment URL
        frag_fd = FragmentFD(frag_urls[0], is_live, fobj, http_proxy)

        # Parse the PIFF header
        piff_headers = {}
        while True:
            box_header = fobj.read(8)
            if len(box_header) < 8:
                break