

# Generated at 2022-06-12 16:59:48.296422
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD({})
    assert fd.FD_NAME == 'ism'


# Generated at 2022-06-12 16:59:56.597854
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Line of code before is inserted to avoid printing INFO outputs
    # of different modules imported at the top of this file.
    logging.root.setLevel(logging.WARNING)
    from youtube_dl.downloader.ism import IsmFD
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.fragment import FragmentFD
    fragment_filename = 'test_fragment_filename.ts'
    print('fragment_filename = ', fragment_filename)
    ydl = YoutubeDL({})
    print('ydl = ', ydl)
    test_IsmFD_fd = IsmFD(ydl, {'url': 'http://example.com/video.ism'}, {'info_dict': {}}, {'filename': fragment_filename})

# Generated at 2022-06-12 17:00:02.462149
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from .fragment import FragmentFD
    from .mss_ttml import TEST_TTML1_AS_XML

    # Build header
    fragment = FragmentFD(io.BytesIO(TEST_TTML1_AS_XML.encode('utf-8')), is_mss_fragment=True)
    fragment._write_piff_header(dict(
        track_id=1,
        fourcc='wvtt',
        duration=0,
        sampling_rate=45000,
        language='und'
    ))
    fragment.close()

    # Compare to expected result

# Generated at 2022-06-12 17:00:05.149208
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = b'\x00\x00\x00\x15' + b'moov' + b'\x00\x00\x00\x06' + b'trak'
    assert extract_box_data(box_data, (b'moov', b'trak')) == b''



# Generated at 2022-06-12 17:00:07.534500
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    assert fd is not None


# Generated at 2022-06-12 17:00:20.008075
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import determine_ext
    from .dashsegments import SegmentInfo, SegmentFD
    from .fragment import FragmentFD
    from .http import HttpFD, compat_urllib_error
    from .ism import IsmFD
    from .smoothstreams import SmoothStreamsFD
    from .smoothstreams import DASH_MANIFEST_URL_TEMPLATE
    from .utils import encode_data_uri
    from .utils import sanitize_open
    from .utils import write_json_file
    from .utils import _dict_get_case_insensitive
    from .youtube_dl import YoutubeDL
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.extractor import get_info_extractor
    from .youtube_dl.extractor.dash import _parse

# Generated at 2022-06-12 17:00:33.997386
# Unit test for function write_piff_header
def test_write_piff_header():
    import struct

    fd = io.BytesIO()
    params = {
        'fourcc': 'AVC1',
        'duration': 10000000,
        'height': 720,
        'width': 1280,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'codec_private_data': '0164001fffe100b827466d001f0b4000100000030010000003001830283012a029900400000030010000000f602030001a81e0816900042c01e0d6e5e6f5f9ecb9',
        'nal_unit_length_field': 4,
    }
    write_piff_header(fd, params)
    frag = fd.getvalue()
   

# Generated at 2022-06-12 17:00:45.863033
# Unit test for function write_piff_header
def test_write_piff_header():
    data = io.BytesIO()
    params = {'fourcc': 'H264', 'height': 1080, 'width': 1920, 'duration': 90000, 'track_id': 1, 'nal_unit_length_field': 4}
    params['codec_private_data'] = '0000000167640029ACD940A14E8'
    write_piff_header(data, params)

# Generated at 2022-06-12 17:00:51.933009
# Unit test for function extract_box_data
def test_extract_box_data():
    data = binascii.unhexlify('00000010moov0000020014trak0000020018tkhd0000020018mdiareftype00000200244dinf00000200244dref000002002c37564c0000020038url0000020114stbl0000020114stsd0000020114mp4a0000020114esds00000201140000000100000003000000f247000400100006000100000000000002000100000010000000010000003c000000')
    assert box('moov', box('trak', box('tkhd', box('mdia', box('minf', box('dinf', box('dref', box('url ', ' ')))))))) == extract_box_data(data, [b'moov', b'trak', b'tkhd', b'mdia', b'minf', b'dinf', b'dref', b'url '])



# Generated at 2022-06-12 17:00:55.417637
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # First argument is URL of manifest file and second argument is URL of video file
    ism_fd = IsmFD(1,2,3)
    assert ism_fd.FD_NAME == 'ism'


test_IsmFD()

# Generated at 2022-06-12 17:01:17.240072
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ...

# class IsmFD

# class DashSegmentsFD

# class DashManifestFD

DASH_SEGMENT_TEMPLATE_RE = re.compile(
    r'[^}]*$', re.DOTALL)  # anything not including closing curly brackets

DASH_MPD_TEMPLATE_URL = '%s/MPDs/%s/manifest.mpd'

DASH_TEMPLATE_URL = '%s/%sSegments/%s/%s'


# Generated at 2022-06-12 17:01:30.233835
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    temp_file = tempfile.NamedTemporaryFile()
    fake_info_dict = {'fragments': [{'url': 'http://example.com/1.ismv'}, {'url': 'http://example.com/2.ismv'}], '_download_params': {'sampling_rate': 44100.0, 'fourcc': 'AACL', 'track_id': 1, 'duration': 10000000, 'bits_per_sample': 16, 'channels': 2}}
    fake_params = {'test': True}
    ismfd = IsmFD(temp_file.name, fake_info_dict, fake_params)
    assert(ismfd.real_download(temp_file.name, fake_info_dict) == True)
    temp_file.close()

# Testing class IsmFD

# Generated at 2022-06-12 17:01:35.901607
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL({})
    assert isinstance(IsmFD(ydl, {})._prepare_and_start_frag_download({}), type(None))
    assert isinstance(IsmFD(ydl, {})._download_fragment({}, 'url', {}), type(None))
    assert isinstance(IsmFD(ydl, {})._finish_frag_download({}), type(None))

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:01:40.751530
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Test method real_download"""
    # Create an instance of class IsmFD
    ism_fd = IsmFD([])
    # Get parameters of the method real_download of class IsmFD
    params = inspect.getargspec(IsmFD.real_download)
    # The param 'filename' should be positional
    assert params.args[0] == 'filename'
    assert params.keywords is None
    # The param 'filename' should be a str
    assert params.defaults is None
    # The param 'filename' should have the default value '-'
    assert len(params.args) == 2
    # The param 'info_dict' should be named
    assert params.varargs is None
    # The param 'info_dict' should be a dict
    assert params.defaults == ()

    # Check the call of method real

# Generated at 2022-06-12 17:01:51.518387
# Unit test for constructor of class IsmFD
def test_IsmFD():
  #this is a video download test, including the option test and the fragment_retry
  #option test.
  ydl_opts = {
    'outtmpl': '%(id)s%(ext)s',
    'quiet': True,
    'format': 'ism',
    'fragment_retries': 10,
    'test': True
  }
  ydl = YDL(ydl_opts)
  url = 'http://ssai.demo.ooyala.com/v2/hZbSubsZs0s8Y4s4V7C1hMfT6D-I6QEu'
  result = ydl.extract_info(url, download=True)
  assert 'video' in result['formats'][0]

# Generated at 2022-06-12 17:01:56.612072
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # TODO: write unit test for constructor of class IsmFD
    assert False, "TODO: write unit test for constructor of class IsmFD"



# Generated at 2022-06-12 17:02:04.963380
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dashsegments import SegmentFD
    from .dashmanifest import DASHManifest
    from .http import HttpFD
    from .http import HEADRequest
    from .downloader import get_suitable_downloader
    from .downloader import Downloader

    manifest_url = 'http://playready.directtaps.net/smoothstreaming/TTLSS720VC1/To_The_Limit_720.ism/Manifest'

    manifest_doc = HEADRequest(manifest_url).get_response().read()
    manifest = DASHManifest(manifest_doc, manifest_url)

    segment_url, _, _ = manifest.get_segment_info('video', 0)

    segment_doc = HttpFD().download(segment_url, None).read()

    info_dict = SegmentFD.get_

# Generated at 2022-06-12 17:02:15.937739
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:02:28.972236
# Unit test for function write_piff_header
def test_write_piff_header():
    # Test function output with audio track
    test_output = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 0,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    write_piff_header(test_output, params)

# Generated at 2022-06-12 17:02:40.309929
# Unit test for function write_piff_header
def test_write_piff_header():
    for forcc in ('H264', 'AVC1'):
        for track_type in ('audio', 'video'):
            stream = io.BytesIO()
            params = {
                'track_id': 1,
                'fourcc': 'AVC1',
                'duration': 0,
                'width': 100,
                'height': 100,
                'codec_private_data': '0000000167640032acd9432f',
                'sampling_rate': 48000,
                'channels': 2,
                'bits_per_sample': 16,
            }
            if track_type == 'audio':
                del params['width']
                del params['height']
            write_piff_header(stream, params)

# Generated at 2022-06-12 17:03:08.586157
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:03:11.733249
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    Test for real_download method of class IsmFD
    """
    assert IsmFD.FD_NAME == 'ism',\
           'invalid FD_NAME'

# Generated at 2022-06-12 17:03:20.815362
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .http import HTTPFD
    from .http import M3U8FD
    from .ism import IsmFD
    from .ism import IsmManifestFetcherBase
    from .smoothstreaming import SmoothFD
    from .smoothstreamingmeta import SmoothStreamingMetaFD
    from .dashmanifest import MpdFD
    from ..compat import (
        compat_urllib_request,
        compat_http_client,
    )


# Generated at 2022-06-12 17:03:32.732004
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """ Test IsmFD constructor """
    # Test 1: no params
    with patch('youtube_dl.downloader.common.get_elapsed_time'):
        IsmFD()
    # Test 2: params
    with patch('youtube_dl.downloader.common.get_elapsed_time'):
        IsmFD(params={'a': 'b'})
    # Test 3: context
    with patch('youtube_dl.downloader.common.get_elapsed_time'):
        class DummyContext(object):
            params = None
        ctx = DummyContext()
        IsmFD(context=ctx)
        ctx.params = {'a': 'b'}
        IsmFD(context=ctx)


# Generated at 2022-06-12 17:03:43.334600
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    def extract_box_data(data, box_sequence):
        data_reader = io.BytesIO(data)
        while True:
            box_size = u32.unpack(data_reader.read(4))[0]
            box_type = data_reader.read(4)
            if box_type == box_sequence[0]:
                box_data = data_reader.read(box_size - 8)
                if len(box_sequence) == 1:
                    return box_data
                return extract_box_data(box_data, box_sequence[1:])
            data_reader.seek(box_size - 8, 1)
    def box(box_type, payload):
        return u32.pack(8 + len(payload)) + box_type + payload



# Generated at 2022-06-12 17:03:55.417458
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    ctx = {
        'filename': 'test_real_download.mp4',
        'total_frags': len(segments),
    }
    # real_download(self, filename, info_dict)
    # As a test, we download the first fragment from the Sintel movie
    # which is 137468 bytes
    fragment_retries = 0
    skip_unavailable_fragments = True
    track_written = False
    frag_index = 0
    for i, segment in enumerate(segments):
        frag_index += 1
        print("Downloading fragment=",segment['url'])
        count = 0

# Generated at 2022-06-12 17:04:04.658771
# Unit test for function write_piff_header
def test_write_piff_header():

    stream = io.BytesIO()
    write_piff_header(stream, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'sampling_rate': 44100,
    })

# Generated at 2022-06-12 17:04:16.179731
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import urlopen, urlretrieve
    url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4-onDemand.mpd'
    with urlopen(url) as f:
        mpd_data = f.read()
    info_dict = {
        'url': url,
        'id': 'test',
        'ext': 'mp4',
        'title': 'test',
        'duration': 100,
        'thumbnail': '',
        'description': '',
        'uploader': '',
        'timestamp': 0,
        'upload_date': '',
    }
    mp4_filename = u'test.mp4'

# Generated at 2022-06-12 17:04:18.165198
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print(IsmFD('https://some-stream/manifest.ism'))



# Generated at 2022-06-12 17:04:28.201310
# Unit test for function write_piff_header
def test_write_piff_header():
    id = 0 # DVD
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 32000000,
        'timescale': 10000000,
        'language': 'eng',
        'sampling_rate': 48000,
        'channels': 2,
        'bits_per_sample': 16
    }
    out = io.BytesIO()
    write_piff_header(out, params)

# Generated at 2022-06-12 17:05:31.534455
# Unit test for function extract_box_data
def test_extract_box_data():
    TEST_DATA = b'\x00\x00\x00\x00moov\x00\x00\x00\x00trak\x00\x00\x00\x00mdia'
    assert extract_box_data(TEST_DATA, b'moov') == b''
    assert extract_box_data(TEST_DATA, b'trak') == b''
    assert extract_box_data(TEST_DATA, b'mdia') == b''
    assert extract_box_data(TEST_DATA, (b'moov', b'trak')) == b''
    assert extract_box_data(TEST_DATA, (b'moov', b'mdia')) == b''
    assert extract_box_data(TEST_DATA, (b'trak', b'mdia')) == b''

# Generated at 2022-06-12 17:05:35.401792
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--ism_url', type=str,
        help='Url to ism manifest')
    args = parser.parse_args()

    downloader = YoutubeDL(params={'ism_url': args.ism_url})
    downloader.add_info_extractor(lambda id: IsmIE(downloader))
    info = downloader.extract_info(u'', download=False)
    IsmFD(downloader).real_download(filename=None,info_dict=info)

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:05:44.341602
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '016400122742c024a8b0885009416d067aab01f0055a8b0240019040028ee3c80',
        'duration': 12345678,
        'timescale': 90000,
        'width': 1280,
        'height': 720,
        'language': 'eng'
    }
    write_piff_header(out, params)

# Generated at 2022-06-12 17:05:56.468396
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    # Video
    params = {'track_id': 1, 'fourcc': 'AVC1', 'duration': 1000000000, 'timescale': 10000000, 'height': 768, 'width': 1024,
        'codec_private_data': '0164001fffe100176764001facd9c280005b931010001000003000168ebe3c80'}
    write_piff_header(stream, params)
    stream.seek(0)
    result = binascii.hexlify(stream.read()).decode('ascii')

# Generated at 2022-06-12 17:05:57.060263
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:06:02.327868
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import get_suitable_downloader
    from .extractor import get_info_extractor
    # Download a ISM-V2 Live stream with encryption

# Generated at 2022-06-12 17:06:05.085019
# Unit test for function write_piff_header
def test_write_piff_header():
    from .piff_test import PiffTest
    piff = PiffTest()
    piff.test_write_piff_header()



# Generated at 2022-06-12 17:06:16.506111
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    # New stream
    stream1 = BytesIO()
    # Add dummy data for test
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '000000016742C02000DAC7D98CAF0000016764001F4D4000168CE3880',
        'duration': 13.333333,
        'timescale': 10000000,
        'language': 'und',
        'height': 576,
        'width': 1024,
        'nal_unit_length_field': 4
    }
    write_piff_header(stream1, params)
    # Stream is not empty
    assert stream1.tell() > 0
    # Stream contains moov box

# Generated at 2022-06-12 17:06:28.820820
# Unit test for function write_piff_header
def test_write_piff_header():
    st = io.BytesIO()
    track_id = 1
    fourcc = 'AACL'
    duration = 11420
    language = 'und'
    height = 0
    width = 0
    is_audio = width == 0 and height == 0
    params = {}
    params['track_id'] = track_id
    params['fourcc'] = fourcc
    params['duration'] = duration
    params['language'] = language
    params['height'] = height
    params['width'] = width
    write_piff_header(st, params)
    text = st.getvalue()
    if bytes is str:
        text = text.decode('utf-8')
    text += '\n'
    text = text.replace(' ', '\n')

# Generated at 2022-06-12 17:06:38.114023
# Unit test for function write_piff_header
def test_write_piff_header():
    import struct
    # fullbox(ftyp) = 8 + 4 + 4 + 4 + 4 = 24
    # fullbox(mvhd) = 24 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 36*4 + 4 = 144
    # fullbox(tkhd) = 24 + 4 + 4 + 4 + 4 + 4 + 2 + 2 + 2 + 2 + 36*4 = 104
    # fullbox(mdhd) = 24 + 4 + 4 + 4 + 4 + 4 + 2 + 2 = 48
    # box(hdlr) = 8 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 0x0c
    # fullbox(smhd) = 24 + 2 + 2 = 28
    # fullbox(vmhd) = 24 + 2 + 2 + 2
    # fullbox(dref) = 8