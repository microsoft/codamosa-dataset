

# Generated at 2022-06-12 16:59:51.221521
# Unit test for function extract_box_data

# Generated at 2022-06-12 16:59:53.484308
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    gen_extractors()

# Generated at 2022-06-12 17:00:02.130119
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    self = IsmFD()
    filename = "filename"
    info_dict = {}
    info_dict['fragments'] = ["fragments1", "fragments2"]
    self.params = {'fragment_retries': 0, 'skip_unavailable_fragments': True}
    # mock _download_fragment
    self._download_fragment = mock.Mock(return_value=(True, "test"))
    # mock extract_box_data
    extract_box_data = mock.Mock(return_value="test")
    # mock _append_fragment
    self._append_fragment = mock.Mock()
    # mock report_skip_fragment
    self.report_skip_fragment = mock.Mock()
    # mock report_retry_frag

# Generated at 2022-06-12 17:00:08.141227
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': '',
        'height': 1080,
        'width': 1080,
        'duration': 12345,
        'timescale': 1000,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'nal_unit_length_field': 4,
        'codec_private_data': '',
    }

    with io.BytesIO() as stream:
        write_piff_header(stream, params)
        stream.seek(0)

# Generated at 2022-06-12 17:00:20.416880
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .compat import bytes_to_intlist

    import tempfile
    import uuid
    temp_dir = tempfile.mkdtemp(prefix=u'yt-test-IsmFD')


# Generated at 2022-06-12 17:00:29.276172
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test download of onlive.tv streaming file
    _, info_dict = update_url_query(
        'https://cdn-videos-2.onlive.com/hls/hq/hq.m3u8',
        {'fake_m3u8_formats': '[{"format_id": "priority", "protocol": "hls", "ext": "mp4"}]'}
    )
    IsmFD().process_info(info_dict)

# Generated at 2022-06-12 17:00:37.868248
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import tempfile
    import shutil
    import subprocess
    cmd = sys.executable + ' ./download_media.py'
    print(cmd)
    tempdir = tempfile.mkdtemp()
    print("Dir is %s" % tempdir)
    try:
        subprocess.check_call(cmd, shell=True, cwd=tempdir)
    except:
        shutil.rmtree(tempdir)
        raise

# Generated at 2022-06-12 17:00:45.459558
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    info_dict = IsmFD._real_extract(test_url)
    print('extract_ism test: ' + info_dict['_filename'])
    assert info_dict['ext'] == 'mp4'
    assert info_dict['duration'] == '2:02'
    assert info_dict['description'] == 'YT description'

##test_IsmFD()

# Generated at 2022-06-12 17:00:54.555063
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x1A' + b'abcd' + b'\x00\x00\x00\x0A' + b'abcd' + b'\x00\x00\x00\x02' + b'abcd' + b'\x00\x00\x00\x02' + b'abcd', [b'cdab', b'cdab'])
    assert box_data == b'\x00\x00\x00\x02' + b'abcd'
test_extract_box_data()


# Generated at 2022-06-12 17:01:07.165492
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    #
    print("Running tests for IsmFD.real_download")
    test_method = 'real_download'
    #
    #
    print("Test %s" % (test_method) )
    fname = "test.ism"
    from .dummy_thread import DummyThread


# Generated at 2022-06-12 17:01:30.328375
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import iso8601_to_unix
    from ..dash import write_piff_header, FragmentFD


# Generated at 2022-06-12 17:01:33.271186
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Simple unit test for IsmFD class"""
    IsmFD(params={
        'url': 'http://www.example.com/',
        'test': '1',
    }, downloader=None)



# Generated at 2022-06-12 17:01:38.126293
# Unit test for constructor of class IsmFD
def test_IsmFD():
    stream = IsmFD()
    test_info_dict = dict()
    test_info_dict['fragments'] = []
    stream.real_download(None, test_info_dict)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:01:50.984442
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:01:52.787529
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:02:03.733833
# Unit test for function write_piff_header
def test_write_piff_header():

    CHUNK_SIZE = 100

    # set up params
    params = dict()
    params['track_id'] = 0x01
    params['duration'] = 16000
    params['timescale'] = 10000000
    params['fourcc'] = 'AACL'
    params['sampling_rate'] = 48000
    params['channels'] = 2

    # set up a buffer to store data
    buf = io.BytesIO()

    # write PIFF header
    write_piff_header(buf, params)

    # write sample
    buf.write(u32.pack(0x100))  # sample size
    buf.write(full_box(b'sdtp', 0, 0, u8.pack(0x10)))  # sample description index + sample dependency flags + sample is leading + sample depends on + sample is depedent

# Generated at 2022-06-12 17:02:14.942122
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ism_fd = IsmFD()
    test_manifest = 'ism://d.yimg.com/m/up/ypp/default/player/manifest.f4m'
    try:
        ism_fd._real_initialize(test_manifest)
    except Exception as e:
        print(e)
        return
    ism_fd.params['skip_unavailable_fragments'] = True
    ism_fd.params['test'] = True
    info_dict = ism_fd._real_extract(test_manifest)
    ism_fd.real_download(info_dict['_filename'], info_dict)


# Method real_download of class IsmFD is tested.
test_IsmFD_real_download()

# Generated at 2022-06-12 17:02:28.147926
# Unit test for function write_piff_header
def test_write_piff_header():
    def test_header(params, expected_header):
        with io.BytesIO() as f:
            write_piff_header(f, params)
            actual_header = binascii.hexlify(f.getvalue())
        assert actual_header == expected_header


# Generated at 2022-06-12 17:02:39.817301
# Unit test for function write_piff_header
def test_write_piff_header():
    import sys
    import hashlib
    import tempfile
    from .utils import (
        encode_base64,
        open_files,
    )


# Generated at 2022-06-12 17:02:51.890246
# Unit test for function write_piff_header
def test_write_piff_header():
    #  Example of an audio header
    params1 = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000,
        'timescale': 10000000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
    }
    stream1 = io.BytesIO()
    write_piff_header(stream1, params1)
    stream1.seek(0)
    assert stream1.read(4) == b'moov'

    #  Example of a video header

# Generated at 2022-06-12 17:03:08.606288
# Unit test for function write_piff_header
def test_write_piff_header():
    class Stream:
        def __init__(self):
            self.buffer = io.BytesIO()

        def write(self, s):
            self.buffer.write(s)


# Generated at 2022-06-12 17:03:18.103873
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    write_piff_header(f, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 90 * 10000000,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffec0128ffe4016920004d4010120004d401016880',
    })

# Generated at 2022-06-12 17:03:19.758865
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for IsmFD._download
    # TODO: Check for correct download
    pass


# Generated at 2022-06-12 17:03:26.135261
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

# Generated at 2022-06-12 17:03:35.975402
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    '''
    Test download of a fragment from a ISM manifest
    '''
    # Test common initializations
    FD_test_common_initialization()

    assert FD_test_common_manifest_initialization()

    try:
        assert FD_test_common_is_drm()
        assert FD_test_common_encryption_initialization()
    except pytest.skip.Exception:
        pass

    # Test variations
    frg_manifest = FD_test_common_manifest_only_fragment()
    # TODO: This specific case can not be tested with the current infrastructure
    # if frg_manifest:
    #     FD_test_ism_manifest(frg_manifest)

    return True

# Utility functions

# Generated at 2022-06-12 17:03:44.888213
# Unit test for function write_piff_header
def test_write_piff_header():
    import json

    params = dict(
        # common
        track_id = 1,
        # audio
        fourcc = 'AACL',
        duration = 9125,
        sampling_rate = 44100,
        channels = 2,
        bits_per_sample = 16,
        # video
        # fourcc = 'H264',
        # duration = 9125,
        # codec_private_data = '000000016742C01EAC0280A002888E560000000168CE3880',
        # nal_unit_length_field = 4,
    )
    params['duration'] = int(params['duration'] * params.get('sampling_rate', params.get('timescale', 10000000)) / params.get('timescale', 10000000))
    f = io.BytesIO()
    write_piff_

# Generated at 2022-06-12 17:03:47.945453
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Create an instance of IsmFD, and test whether its constructor is working or not.
    IsmFD()

# Generated at 2022-06-12 17:03:57.866236
# Unit test for function write_piff_header
def test_write_piff_header():
    from ..utils import encode_data_uri
    from ..compat import compat_bytes

    test_params = {
        'track_id': 1,
        'fourcc': 'H264',
        'sampling_rate': 0,
        'channels': 1,
        'bits_per_sample': 16,
        'duration': 100000,
        'timescale': 1000000,
        'language': 'eng',
        'height': 0,
        'width': 0,
        'codec_private_data': '01640028fda9fc0011e962a0db0b001260720d880019f8b8c0000014de9a350019f91bd60001f0801801480b0b80',
    }
    fake_stream = io.BytesIO()
    write_piff

# Generated at 2022-06-12 17:03:58.458010
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:04:06.537446
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://playready.directtaps.net/pr/svc/rightsmanager.asmx'

# Generated at 2022-06-12 17:04:58.517446
# Unit test for constructor of class IsmFD
def test_IsmFD():
    dash_manifest_url = 'https://dash.akamaized.net/dash264/TestCases/2a/qualcomm/1/MultiRate.mpd'
    ism_manifest_url = 'https://dash.akamaized.net/dash264/TestCases/2a/qualcomm/1/Manifest.ism'

    # download a DASH manifest
    dash_manifest_content = compat_urllib_request.urlopen(dash_manifest_url).read()

    # parse the DASH manifest
    dash_manifest_doc = xml.etree.ElementTree.fromstring(dash_manifest_content)
    dash_manifest_namespace = dash_manifest_doc.tag[1:].split('}')[0]

    # find the video AdaptationSet element
    dash_video_ad

# Generated at 2022-06-12 17:05:07.021833
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test creation of object.
    """

    fd = IsmFD({
        'fragments': [
            {'url': 'http://example.com/1.ismv', 'duration': 10, 'title': 'fake_frag'},
            {'url': 'http://example.com/2.ismv', 'duration': 10, 'title': 'fake_frag'},
        ],
    })
    assert fd.params['test'] is False
    assert fd.params['skip_unavailable_fragments'] is True
    assert fd.params['fragment_retries'] == 0


# Generated at 2022-06-12 17:05:17.288138
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import binascii
    from itertools import groupby

    def get_mdat_size(filename):
        with open(filename, 'rb') as piff_stream:
            return read_mdat_size(piff_stream)

    def get_moov_pos(filename):
        with open(filename, 'rb') as piff_stream:
            return read_moov_pos(piff_stream)

    def get_fragment_offset(filename):
        with open(filename, 'rb') as piff_stream:
            moov_pos = get_moov_pos(filename)
            piff_stream.seek(moov_pos)
            piff_stream.seek(read_moof_pos(piff_stream))

# Generated at 2022-06-12 17:05:26.226624
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params ={'track_id': 1, 'fourcc': 'avc1', 'duration': 0, 'timescale': 10000000, 'language': 'und', 'height': 0, 'width': 0, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 44100, 'codec_private_data': b'01640028ffe100136764001fffe100ba9d804015ee6f247'}
        write_piff_header(stream, params)
        print(stream.tell())
        print(len(stream.getvalue()))
        print(stream.getvalue())
        #print(hex(stream.getvalue()))

# Generated at 2022-06-12 17:05:32.899940
# Unit test for constructor of class IsmFD
def test_IsmFD():
    file_data = {
        'url': 'some_url',
        'fragments': [
            {
                'url': 'some_url',
                'duration': 10.0,
                'title': 'some_title'
            }
        ],
        '_download_params': {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 10.0,
            'timescale': 10000000.0
        }
    }
    dest_stream = io.BytesIO()
    ism_fd = IsmFD(dest_stream, None, None, None, None)
    ism_fd.real_download(None, file_data)
    assert dest_stream.getvalue()[:8] == b'moov     '

# Generated at 2022-06-12 17:05:43.087873
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE

    def ff_download(ydl, *args, **kwargs):
        return ydl.extract_info(YOUTUBE_URL, download=True)

    ie = InfoExtractor()
    ie.add_info_extractor(YoutubeIE(ydl=None, ie=ie))
    ie.add_info_extractor(IsmFD(ydl=FakeYDL(), ie=ie))

    result = ff_download(ie)

# Generated at 2022-06-12 17:05:45.642429
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {}
    write_piff_header(stream, params)
    assert stream.getvalue().startswith(b'moov')


# Generated at 2022-06-12 17:05:57.545579
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Test constructor of class"""
    import json
    from io import BytesIO
    from test_downloads import expect_info_dict

    # template of sample info dict

# Generated at 2022-06-12 17:06:00.774416
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test = IsmFD()
    test.FD_NAME = 'ism'
    test.real_download('filename', 'info_dict')


# Generated at 2022-06-12 17:06:12.886689
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import random
    import hashlib

    sys.path.append('..')
    sys.path.append('../..')
    from yt_dl.utils import fake_http_server, fake_https_server, IsmFD, is_test_video_available, sanitize_open, \
        parse_fragment_base_url

    if not is_test_video_available():
        print('Test video is not available. Skipping.')

    url = 'ism://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/manifest'
    # url = 'ism://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/QualityLevels(

# Generated at 2022-06-12 17:07:24.697224
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url='https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8' #ok
    ydl = YDL()
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(url, download=False)
    ismFD=IsmFD(ydl, info_dict)


# Generated at 2022-06-12 17:07:29.196631
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Test the constructor of the IsmFD class
    """
    test_instance = IsmFD({'username': '', 'password': ''}, {})
    assert test_instance.FD_NAME == 'ism'
    assert test_instance.params == {'username': '', 'password': ''}


# Generated at 2022-06-12 17:07:36.718565
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import tempfile
    # This test requires ffmpeg
    try:
        subprocess.call(['ffmpeg', '-h'], stdout=(open(os.path.devnull, 'w')), stderr=subprocess.STDOUT)
    except (OSError, IOError):
        return
    # This test requires f4mtester (https://github.com/tokland/f4m-proxy-tester)
    try:
        subprocess.call(['f4mproxy', '-h'], stdout=(open(os.path.devnull, 'w')), stderr=subprocess.STDOUT)
    except (OSError, IOError):
        return
    url = url_or_none('http://localhost:8888/ism/BigBuckBunny.ism/Manifest')

# Generated at 2022-06-12 17:07:45.578737
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    file_url = 'http://test-us-qa-dash.ma.stage.vlive.io/medias/test/test.ism/test_01.mp4'
    params = {
        'outtmpl': 'test.ism',
        'hls_segment_stream_data': True,
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
        'noprogress': True,
    }
    filename = params['outtmpl']
    ydl = YoutubeDL(params)

# Generated at 2022-06-12 17:07:53.161398
# Unit test for function write_piff_header
def test_write_piff_header():
    from .common import Source
    from .fragment import FragmentWriter

    with io.BytesIO() as f:
        params = {'track_id': 1, 'timescale': 10000000, 'duration': 30000000, 'codec_private_data': '000003b0010000a088ac0883014c0013000001000003000003c0', 'height': 720, 'width': 1280}
        write_piff_header(f, params)
        f.seek(0)

        source = Source(f)
        writer = FragmentWriter(params, FragmentFD(source))
        writer.write_header()

# Generated at 2022-06-12 17:08:01.854165
# Unit test for function write_piff_header
def test_write_piff_header():
    def write_piff_header_test(params):
        frag_stream = io.BytesIO()
        write_piff_header(frag_stream, params)
        expected_hexstr = params['expected']
        assert binascii.hexlify(frag_stream.getvalue()) == expected_hexstr.encode('utf-8')


# Generated at 2022-06-12 17:08:10.972486
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:08:20.414599
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # testing ism_url
    ism_url = 'ism://mediadl.microsoft.com/mediadl/iisnet/cnn/big/cnn_big.isml/cnn_big_300000'
    # testing bitrate for selection
    bitrate = 320000

    ism_fd = IsmFD(ism_url, bitrate)

    assert ism_fd.url == ism_url
    assert ism_fd.bitrate == bitrate
    assert not ism_fd.manifest_url
    assert not ism_fd.manifest_params
    assert not ism_fd.is_live
    assert ism_fd.use_cdn
    assert ism_fd.frag_duration == 10
    assert not ism_fd.frag_index


# Generated at 2022-06-12 17:08:21.050614
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:08:24.164446
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD('http://54.187.101.14/istestv2/m2d/1M/manifest.ism', {})
    except Exception:
        assert False

if __name__ == '__main__':
    test_IsmFD()