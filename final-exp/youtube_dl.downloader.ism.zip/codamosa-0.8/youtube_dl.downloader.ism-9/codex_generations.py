

# Generated at 2022-06-12 16:59:37.524881
# Unit test for function extract_box_data
def test_extract_box_data():
    # Example data taken from https://github.com/mifi/lossless-cut/blob/master/testdata/sample-fragmented.mp4
    data = binascii.unhexlify(b'000000000000001469736d6c00000001000001180000000100000001000000000000010000000488ce06c')
    assert extract_box_data(data, (b'moov',)) == binascii.unhexlify(b'00000001828d4d4f0000000118000000000000000100000001000000000000010000000488ce06c')



# Generated at 2022-06-12 16:59:48.019780
# Unit test for function write_piff_header
def test_write_piff_header():
    f = FragmentFD(io.BytesIO())
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000,
        'codec_private_data': '110016',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    write_piff_header(f, params)
    f.seek(0)

# Generated at 2022-06-12 16:59:53.760354
# Unit test for function extract_box_data
def test_extract_box_data():
    test_file_box = box(b'test', b'')
    test_file_moov = box(b'moov', test_file_box)
    test_file_mdat = box(b'mdat', b'')
    test_file_data = test_file_moov + test_file_mdat
    test_box_data = extract_box_data(test_file_data, (b'moov', b'test'))
    assert test_box_data == test_file_box



# Generated at 2022-06-12 17:00:02.372005
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    wgetmock.mock('http://test.m3u8', body='', content_type='application/vnd.apple.mpegurl')
    wgetmock.mock('http://test.ism/init', body='', content_type='video/mp4')
    wgetmock.mock('http://test.ism/1', body='', content_type='video/mp4')
    wgetmock.mock('http://test.ism/2', body='', content_type='video/mp4')
    wgetmock.mock('http://test.ism/3', body='', content_type='video/mp4')
    wgetmock.mock('http://test.ism/4', body='', content_type='video/mp4')

# Generated at 2022-06-12 17:00:16.566343
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHIE
    from .dash import make_is_live
    from .dash import format_bytes
    from .dash import GetPropsMixin
    from .common import urljoin
    from .downloader import FileDownloader
    from .utils import sanitize_open

    downloader = FileDownloader(params={})
    downloader.params.update({
        'outtmpl': 'tmp/%(manifest_id)s.%(ext)s',
        'format': 'ism',
        'writedescription': 'false',
        'writeannotations': 'false',
        'writeinfojson': 'false',
        'simulate': 'false',
        'skip_unavailable_fragments': 'false',
    })

    ism_url = 'https://manifest_url/Manifest'
   

# Generated at 2022-06-12 17:00:29.167025
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:00:38.809814
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    f = io.BytesIO()
    write_piff_header(f, {'track_id': 1, 'fourcc': 'H264',
                          'duration': 1000, 'height': 240, 'width': 320,
                          'codec_private_data': '01640033'})
    with open(os.path.join(os.path.dirname(__file__), 'piff_header_out.piff'), 'rb') as g:
        assert f.getvalue() == g.read()



# Generated at 2022-06-12 17:00:48.486278
# Unit test for function write_piff_header
def test_write_piff_header():
    codec_private_data = '01640033FFFA0000FFFFFE00010425C68080'
    data = '01000000F87E0000010701060001020001254944415428C519CCFFA9ADF1F856D'
    fd = io.BytesIO()
    write_piff_header(fd, {
        'fourcc': 'H264',
        'track_id': 1,
        'duration': 100000000,
        'codec_private_data': codec_private_data,
        'height': 320,
        'width': 240,
        })
    fd.write(u32.pack(8 + len(data)) + b'mdat' + binascii.unhexlify(data.encode('utf-8')))
    import re

# Generated at 2022-06-12 17:00:58.191915
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    This function implements the unit test for IsmFD constructor.
    To run the unit test execute the following command:
    $ python3 -m py_compile youtube_dl/downloader/ism.py
    $ python3 -m unittest youtube_dl.downloader.ism.IsmFD
    """
    from unittest import TestCase
    import youtube_dl.extractor.ism as I
    import youtube_dl.downloader.ism as F
    mock = lambda a: a
    I.urlopen = mock
    mock = lambda a: a
    F.urlopen = mock
    mock = lambda a: a
    I.compat_urllib_error.HTTPError = mock

    class IsmFD_Test(TestCase):
        def test_IsmFD_Test(self):
            url = ''
            info

# Generated at 2022-06-12 17:01:03.438507
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:01:24.461171
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Arrange
    segment_urls = [{}, {}]
    info_dict = {
        'fragments': segment_urls,
        '_download_params': {
            'track_id': 0,
        }
    }
    params = {
        'test': False
    }
    instance = IsmFD()

    # Act
    result = instance.real_download('filename', info_dict)

    # Assert
    assert result == True


if __name__ == "__main__":
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:01:35.249568
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import parseOpts
    from .extractor import gen_extractors
    from .utils import UNICODE_SIG, determine_ext
    opts, args = parseOpts(['-i', 'https://someurl.com/video.ism'])
    info_dict = {}
    opts.test = True
    opts.forcejson = True
    opts.fragment_retries = 1
    ies = gen_extractors(opts, [args[0]])
    ie = ies[0]
    info_dict = ie.extract(args[0])
    fd = IsmFD(opts, info_dict, info_dict['url'], info_dict['ie_key'])

# Generated at 2022-06-12 17:01:44.844970
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    params = dict(fourcc='H264',
                  codec_private_data='000000016742C00D971FEC0A6E408001000000000030010000003000003000003004000167640029AC56138000003000003000003006801400D971FEC0A6E408001000000042C401E951B44540',
                  width=640,
                  height=360,
                  track_id=1,
                  duration=461700000)
    write_piff_header(f, params)

# Generated at 2022-06-12 17:01:53.112851
# Unit test for constructor of class IsmFD
def test_IsmFD():
    DASH_MANIFEST_URL = 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd'
    output_path = './test_video.ismv'
    fd = IsmFD()

# Generated at 2022-06-12 17:02:03.764440
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:02:09.667971
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test import *
    from .extractor import *
    from .jsinterp import *
    from .common import *
    from .downloader import *
    from .utils import *
    from .compat import *


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:02:14.970456
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    # From https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/ism.py
    # Tested separately since it uses an URL that is not there anymore
    return

# Generated at 2022-06-12 17:02:28.198450
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    from ..utils import determine_ext
    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
        compat_http_client,
        compat_urllib_parse,
    )
    stream = io.BytesIO()

# Generated at 2022-06-12 17:02:39.860779
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import tempfile
    import json

    mp4_output = tempfile.TemporaryFile()

    urls = [
        'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/manifest',
        'http://playready.directtaps.net/smoothstreaming/SSWSS720H264PR/SuperSpeedway_720.ism/manifest',
        'http://playready.directtaps.net/smoothstreaming/SSWSS720VC1/SuperSpeedway_720.ism/manifest',
    ]

    for url in urls:
        print('Testing %s' % url)
        mp4_output.seek(0)
        mp4_output.truncate()

# Generated at 2022-06-12 17:02:51.890257
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(f, {'track_id': 1, 'fourcc': 'AACL', 'duration': 600000000, 'sampling_rate': 44100, 'channels': 2})
        piff_hdr = f.getvalue()
    assert piff_hdr.startswith(b'ftypisml')

# Generated at 2022-06-12 17:03:04.573653
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD


# Generated at 2022-06-12 17:03:15.388280
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:03:24.860387
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class TestIsmFD(IsmFD):

        def __init__(self, ydl, params):
            IsmFD.__init__(self, ydl, params)
            self._downloader = ydl
            self._params = params

        def _download_fragment(self, ctx, url, info_dict):
            return True, b''

        def _append_fragment(self, ctx, frag_content):
            pass


# Generated at 2022-06-12 17:03:35.724462
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test_fragment import TestFragmentFD as FragmentFD
    from .test_dash import TestDASHFD
    from ..extractor import YoutubeIE
    
    f = io.BytesIO()
    stream = FragmentFD(f)
    
    
    
    params = {'track_id': 1, 'duration': 245, 'height': 480, 'width': 852, 'fourcc': 'AVC1', 'timescale': 10000000, 'codec_private_data': '0164C401FFF17B808D2C0CE18C48B8B8'}
    write_piff_header(stream, params)
    expected_ftyp = box(b'ftyp', b'ismlpiffiso2') # File Type Box

# Generated at 2022-06-12 17:03:44.696795
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = (
        b'mdat\x00\x00\x00\x08helloMOOTH' +
        b'mdat\x00\x00\x00\x08worldMOOTH' +
        b'mdat\x00\x00\x00\x08!#$%&MOOTH'
    )
    assert test_data == extract_box_data(test_data, (b'mdat',))
    assert b'hello' == extract_box_data(test_data, (b'mdat', b'hello'))
    assert b'world' == extract_box_data(test_data, (b'mdat', b'world'))
    assert b'!#$%&' == extract_box_data(test_data, (b'mdat', b'!#$%&'))

# Generated at 2022-06-12 17:03:56.594598
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import (
        FakeYDL,
        FakeFile,
        FakeInfoDict,
        FindFD,
    )
    import sys
    import os
    import tempfile
    import datetime


# Generated at 2022-06-12 17:04:03.022955
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 11230000,
        'width': 800,
        'height': 600,
        'timescale': 48000,
        'nal_unit_length_field': 4,
        'codec_private_data': '0164001ffe1001867640028acd9c0380808080fef0b1251d7ec8'
    }
    write_piff_header(stream, params)
    data = stream.getvalue()
    assert data[8:12] == b'ftyp'
    assert data[44:48] == b'moov'
    assert data[76:80] == b'trak'
    assert data[156:160] == b

# Generated at 2022-06-12 17:04:04.628467
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:04:10.325755
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.f4m import F4mFD
    from .compat import compat_str

    HttpFD.download = lambda _, __, ___: (True, u32.pack(0) + b'ftyp' + u32.pack(12) + b'isml' + u32.pack(1) + b'piff' + b'iso2')

# Generated at 2022-06-12 17:04:19.289044
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

# Generated at 2022-06-12 17:04:43.458038
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import YoutubeDL
    from .extractor import Cache
    from .utils import determine_ext
    from .postprocessor import FFmpegMergerPP
    import os

    dest_stream = open(os.path.join('.', 'dest.mp4'), 'wb')

# Generated at 2022-06-12 17:04:48.481436
# Unit test for function write_piff_header
def test_write_piff_header():

    from os import close
    from os.path import join
    from tempfile import mkstemp

    from ..utils import encode_base64


    params = {
        'track_id': 0x1,
        'fourcc': 'H264',
        'duration': 1000000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 1080,
        'width': 1920,
        'codec_private_data': encode_base64(u32.pack(1)[1:] + u8.pack(0x67) + u8.pack(0x42) + u8.pack(0x00) + u8.pack(0x29))
    }

    _, path = mkstemp()

# Generated at 2022-06-12 17:04:58.481328
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:05:09.502555
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    write_piff_header(stream, {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 250,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 22050,
    })

# Generated at 2022-06-12 17:05:12.764919
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test creating an instance
    print('Testing creating of IsmFD')
    IsmFD('http://example.com', {})
    print('Tested creating of IsmFD, passed')


# Generated at 2022-06-12 17:05:16.243079
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # TODO : Add test
    return True

# Generated at 2022-06-12 17:05:26.226307
# Unit test for function extract_box_data
def test_extract_box_data():
    data = bytes.fromhex('000000F47363616C6C329D000000F47363616C6C3203000000F47363616C6C3213000000F47363616C6C3236000000F47363616C6C3251000000F47363616C6C327D000000F47363616C6C32B8000000F47363616C6C32E4000000F47363616C6C3311000000F47363616C6C333D000000F47363616C6C336A000000F47363616C6C3396000000F47363616C6C33C3000000F47363616C6C33F000000FF0000002D6D6F6F76000000E800000066747970')

# Generated at 2022-06-12 17:05:38.539252
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import tempfile
    import os
    import random

    def str_(x):
        return ''.join([random.choice(string.ascii_letters + string.digits) for i in range(x)])

    # Create a sample file name
    filename = str_(10)

    # Create a sample manifest
    manifest = []
    manifest += '<?xml version="1.0" encoding="utf-8"?>'
    manifest += '<manifest xmlns="http://schemas.microsoft.com/iis/media/v4/TM/TaskDefinition#" version="1.0">'
    manifest += '<id>{%s}</id>' % str_(4)
    manifest += '<name>%s</name>' % str_(5)
    manifest += '<type>static</type>'

# Generated at 2022-06-12 17:05:43.691367
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Unit test for constructor of class IsmFD
    """
    test_fd = IsmFD('http://example.com/manifest.mpd', {})
    assert test_fd.proto == 'ism'
    assert test_fd.params == {}
    assert not test_fd.fd.closed



# Generated at 2022-06-12 17:05:52.300815
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    def _download_fragment(ctx, frag_url, info_dict):
        ctx['frag_index'] += 1
        return True, frag_content
    frag_content = b'\x00\x00\x00\x20moof'
    frag_url = 'http://example.com'
    info_dict = {
        'fragments': [{
            'url': frag_url,
        }],
        '_download_params': {
            'track_id': 1,
        },
    }
    filename = os.path.join(os.path.dirname(__file__), 'test.piff')
    ctx = {
        'filename': filename,
        'total_frags': 1,
        'fragment_index': 0,
    }
    IsmFD._download

# Generated at 2022-06-12 17:06:18.785218
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://test-url'
    video_id = 'test-video-id'
    test_IsmFD = IsmFD({}, '', {'url': url, 'video_id': video_id})
    assert test_IsmFD.params == {'test': False}, 'constructor of IsmFD is broken'

# Generated at 2022-06-12 17:06:30.981157
# Unit test for function write_piff_header
def test_write_piff_header():
    def test_header(params, expected_header):
        stream = io.BytesIO()
        write_piff_header(stream, params)
        header = binascii.hexlify(stream.getvalue()).upper()
        assert header == expected_header


# Generated at 2022-06-12 17:06:39.545326
# Unit test for function write_piff_header
def test_write_piff_header():
    import re
    import subprocess as sp
    import os
    import sys
    sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..")))
    from ytdl.YTDL import my_ydl
    from ytdl.YTDL import DownloadError
    if __name__ == "__main__":
        from ytdl.YTDL import ydl_opts


# Generated at 2022-06-12 17:06:46.110123
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http_guided import IsmFD
    from io import BytesIO
    from .utils import encode_data_uri

    class DummyIE(InfoExtractor):
        _WORKING = True

# Generated at 2022-06-12 17:06:49.472287
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # method real_download of class IsmFD
    from .IsmFD import IsmFD
    IsmFD.download = IsmFD.real_download

    pass


# Generated at 2022-06-12 17:06:58.519448
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print("test_IsmFD")
    ydl = YoutubeDL({})
    # url = "https://smf.blob.core.windows.net/samples/videosamples/de/bigbuck.ism/Manifest"
    url = "https://smf.blob.core.windows.net/samples/videosamples/de/bigbuck.ism/Manifest(format=m3u8-aapl)"
    result = True
    try:
        isfd = IsmFD(ydl, {"url": url})
    except Exception as e:
        result = False
        print("Failed to create IsmFD")
    if result:
        print("IsmFD created")



# Generated at 2022-06-12 17:07:07.863290
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Arrange
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    params = {
        'username': '',
        'password': '',
        'force_resume': True,
        'noprogress': True,
        'retries': 0,
        'prefer_ffmpeg': True,
        'test': True,
        'skip_unavailable_fragments': False,
    }

    # Act
    ismFD = IsmFD(url, params)

    # Assert
    assert ismFD.params == params
    assert ismFD.url == url
    assert ismFD.use_proxy == False
    assert ismFD.priority == 0



# Generated at 2022-06-12 17:07:16.261053
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0x1,
        'fourcc': 'H264',
        'duration': 10000,
        'timescale': 10000,
        'language': 'und',
        'width': 1920,
        'height': 1080,
        'nal_unit_length_field': 4,
        'codec_private_data': '000000016742802997da000300010000030000030000030000038a28b5f430005d4000005d848d4005c9e9d4000000005e9041ba800004c4f6b4d6f64655f68647032',
    }
    write_piff_header(stream, params)

    stream.seek(0)
    actual_output = stream.read()

# Generated at 2022-06-12 17:07:23.119989
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    if sys.version_info[0] >= 3:
        import io
        import urllib.request
        import urllib.parse
        import http.client
    else:
        import urllib2
        import httplib
        import io
    class compat_HTTPErrorProcessor(urllib2.BaseHandler):
        def http_error_404(self, req, fp, code, msg, headers):
            import urllib2
            response = self.parent.error('http', req, fp, code, msg, headers)
            self.parent.reset()
            return response
        http_error_default = http_error_404

# Generated at 2022-06-12 17:07:32.584692
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {}
    params['track_id'] = 1
    params['fourcc'] = 'AACL'
    params['duration'] = 1000000000
    params['sampling_rate'] = 48000
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['language'] = 'und'
    buffer = io.BytesIO()
    write_piff_header(buffer, params)

# Generated at 2022-06-12 17:08:53.001314
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import time
    import random
    # random.seed(int(time.time()))


# Generated at 2022-06-12 17:09:02.670523
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import fakefile
    from .codec import get_codec_params

    duration = 10
    timescale = 10000000
    width = 640
    height = 480
    sampling_rate = 44100
    channels = 2
    track_id = 1
    language = 'eng'
    codec_private_data = '01000468EE3C80F'
    video_codec = 'H264'
    audio_codec = 'AACL'

    test_video_fragment = FragmentFD(fakefile(100))
    test_audio_fragment = FragmentFD(fakefile(100))

    test_stream = io.BytesIO()
    video_params = get_codec_params(video_codec, codec_private_data, width, height)
    audio_params = get_codec_params

# Generated at 2022-06-12 17:09:11.050600
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .downloader import gen_openers
    from .common import FileDownloader
    from .compat import parse_qs

    # extractor for testing ISM download with test parameter
    class IsmFDTestExtractor(IsmFD):
        NAME = 'ism-test'

        _TEST = True

        def _real_initialize(self):
            self._downloader.params.update({
                'noprogress': True,
                'format': 'ism-test',
                'outtmpl': 'ism-test-%(playlist_index)s.mp4',
                'test': True,
            })

        def _real_extract(self, url):
            self._downloader.params['test'] = False

# Generated at 2022-06-12 17:09:18.197348
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """Create an instance of IsmFD and set its properties."""
    ydl = YoutubeDL({})
    fd = IsmFD(ydl, {})
    # These attributes should exist.
    assert fd.supported_extensions
    assert fd.fd_name
    assert fd.format_id
    # These attributes are inherited from FragmentFD
    assert fd.params
    assert fd.ydl
    assert fd.frag_index

if __name__ == '__main__':
    test_IsmFD()