

# Generated at 2022-06-12 16:59:36.905863
# Unit test for function extract_box_data

# Generated at 2022-06-12 16:59:47.790786
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    global ISMFD_TEST_DATA

# Generated at 2022-06-12 16:59:56.256491
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:00:02.166270
# Unit test for function extract_box_data
def test_extract_box_data():
    import random
    from tempfile import NamedTemporaryFile
    from ..utils import (
        decode_packed_codes,
        encode_packed_codes,
    )
    from .common import (
        FragmentFDTestCase,
        TestData,
    )
    from .fragment import(
        add_fragment_header_content,
        defragment_fragments,
    )
    from .test_fragment import (
        create_fragments_from_string,
    )
    data = ''.join(chr(random.randint(0, 127)) for _ in range(1024)) + 'abcde'

# Generated at 2022-06-12 17:00:06.767841
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:00:19.479637
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:00:33.322725
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    seg_url = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.ism/Manifest(format=mpd-time-csf)'

# Generated at 2022-06-12 17:00:35.109150
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # standard test
    print(IsmFD)



# Generated at 2022-06-12 17:00:44.929985
# Unit test for constructor of class IsmFD
def test_IsmFD():
    params = {
        'ext': 'mpd',
        'format_id': 'ism',
        'url': 'https://wams.edgesuite.net/media/MPTExpressionData01/BigBuckBunny_1080p24_IYUV_2ch.ism/manifest(format=mpd-time-csf)',
        'extract-audio': '1',
        'audio-format': 'aac'
    }
    try:
        test_fd = IsmFD(params)
    except FormatError:
        pass

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:00:51.501923
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """IsmFD constructor unit test"""
    params = {'format': 'ism'}
    expected_fn = 'filename.ism'

    # Test default constructor
    ismfd = IsmFD(params, expected_fn)
    assert ismfd.params == {}
    assert ismfd.expected_filename == 'filename.ism'

    # Test constructor with format parameter
    params = {'format': 'ism'}
    expected_fn = 'filename.ism'
    ismfd = IsmFD(params, expected_fn)
    assert ismfd.params == {}
    assert ismfd.expected_filename == 'filename.ism'

    # Test constructor with format parameter and other parameters

# Generated at 2022-06-12 17:01:05.008359
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_manifest = IsmFD('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest')
    print("Constructor of class IsmFD: PASS")
    return ism_manifest


# Generated at 2022-06-12 17:01:18.613880
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD()
    print('\n--- Testing Success Case 1: valid input ---\n')
    try:
        test_IsmFD.real_download(
            'filename',
            {   'fragments':
                    {   'segments': ['download1.ismv', 'download2.ismv', 'download3.ismv']
                    }
            }
        )
    except:
        import traceback
        print('FAIL')
        print(traceback.format_exc())
    else:
        print('PASS')
    print('\n--- Testing Success Case 2: valid input ---\n')

# Generated at 2022-06-12 17:01:31.463323
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # create a test file with four boxes, big endian
    test_data = u32.pack(12) + b'box1' + u32.pack(12) + b'box2' + u32.pack(12) + b'box3' + u32.pack(12) + b'box4'

    # create a fake instance of IsmFD
    ismfd = IsmFD({})

    # test the extraction of one particular box
    assert ismfd.extract_box_data(test_data, [b'box1']) == u32.pack(12) + b'box2' + u32.pack(12) + b'box3' + u32.pack(12) + b'box4'

# Generated at 2022-06-12 17:01:43.144667
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()

    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 0x1234abcd,
        'timescale': 44100,
        'language': 'eng',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'height': 720,
        'width': 1280,
    }
    write_piff_header(stream, params)


# Generated at 2022-06-12 17:01:52.589459
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:02:03.704259
# Unit test for function write_piff_header
def test_write_piff_header():
    from .mp4 import Atoms
    from .mp4 import Storage
    from .mp4 import Mp4Stream
    
    stream = io.BytesIO()
    params = {'track_id': 1, 'fourcc': 'H264', 'duration': 30000000, 'timescale': 30000, 'height': 144, 'width': 176, 'language': 'und', 'codec_private_data': '000000016742c00d971e00216e0f00000030080000fcec00374ce06c1'}
    write_piff_header(stream, params)
    
    storage = Storage(stream.getvalue())
    mp4_stream = Mp4Stream(storage)
    atoms = Atoms(mp4_stream)
    atoms.load()
    
    assert atoms[0].name == 'ftyp'

# Generated at 2022-06-12 17:02:05.679768
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD = IsmFD()


# Generated at 2022-06-12 17:02:16.237437
# Unit test for constructor of class IsmFD
def test_IsmFD():
    urlopen = compat_urllib_request.urlopen
    ismurl = 'http://www.example.com:80/'
    ism_content = b'ismcontent'

# Generated at 2022-06-12 17:02:29.171699
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = FragmentFD()

    write_piff_header(fd, dict(track_id=1,
                               fourcc='AACL',
                               duration=120000000000,
                               language='eng',
                               channels=2,
                               bits_per_sample=16,
                               sampling_rate=48000,))
    print(binascii.hexlify(fd.getvalue()))

# Generated at 2022-06-12 17:02:40.409516
# Unit test for function extract_box_data
def test_extract_box_data():
    data_reader = io.BytesIO(b'\x00\x00\x00\x34moov\x00\x00\x00\x1c\x00\x00\x00\x14trak\x00\x00\x00\x08\x00\x00\x00\x08udta')
    box_size, box_type = u32.unpack(data_reader.read(4)), data_reader.read(4)
    assert box_size == 52 and box_type == b'moov'
    box_size, box_type = u32.unpack(data_reader.read(4)), data_reader.read(4)
    assert box_size == 28 and box_type == b'trak'

# Generated at 2022-06-12 17:03:03.085999
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    data = get_testdata_file('520385.manifest')
    from .extractor.ism import _process_mpd_formats
    formats = _process_mpd_formats(data)

# Generated at 2022-06-12 17:03:03.459293
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return True



# Generated at 2022-06-12 17:03:14.762031
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'\x00\x00\x00\x12ftyp\x00\x00\x00\x08h264\x00\x00\x00\x08avc1\x00\x00\x00\x08piff'
    box_data = extract_box_data(test_data, [b'ftyp', b'h264'])
    assert box_data == b'\x00\x00\x00\x08h264'
    box_data = extract_box_data(test_data, [b'ftyp', b'h264', b'avc1'])
    assert box_data == b'\x00\x00\x00\x08h264\x00\x00\x00\x08avc1'
    box_data = extract_box

# Generated at 2022-06-12 17:03:23.638991
# Unit test for function extract_box_data
def test_extract_box_data():
    fd = FragmentFD()
    fd.prepare_chunk('264', [b'1', b'2', b'3', b'4'])
    write_piff_header(fd, {'track_id': 1, 'fourcc': 'H264', 'duration': 10, 'timescale': 10000000, 'language': 'und', 'codec_private_data': '01640033acd941800f01e0e898f00a0f420003c8ce0000016742c00d9a00000168ce3c80'})
    fd.close()
    fd.buffer.seek(0)

# Generated at 2022-06-12 17:03:35.120153
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'bits_per_sample': 16,
        'channels': 2,
        'codec_private_data': '1210',
        'duration': 30000000,
        'sampling_rate': 44100,
        'fourcc': 'AACL',
        'width': 854,
        'height': 480
    }

    output = io.BytesIO()
    write_piff_header(output, params)
    output.seek(0)

# Generated at 2022-06-12 17:03:40.653438
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:03:45.451736
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    manifest_url = 'https://wowzaec2demo.streamlock.net/vod-multitrack/_definst_/smil:ElephantsDream/ElephantsDream.smil/manifest.f4m'
    ie = IsmFD().extract(manifest_url)
    ie.download('video.mp4')


if __name__ == '__main__' and len(sys.argv) > 1:
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:03:56.741354
# Unit test for function write_piff_header
def test_write_piff_header():
    import hashlib
    import uuid
    import struct

    def _write_piff_header(stream, params):
        prev_pos = stream.tell()
        piff_header = io.BytesIO()
        write_piff_header(piff_header, params)
        stream.write(piff_header.getvalue())
        return stream.tell() - prev_pos

    class FragmentFD(_FragmentFD):
        def __init__(self, stream, params):
            super(FragmentFD, self).__init__(stream, params)
            self.piff_header_size = _write_piff_header(stream, params)

        def write_fragment(self, fragment_index, data, params):
            moof_box = io.BytesIO()

# Generated at 2022-06-12 17:04:05.336516
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import os, sys, tempfile
    # Test real_download(self, filename, info_dict)
    _, temp_filename = tempfile.mkstemp()

# Generated at 2022-06-12 17:04:15.359783
# Unit test for constructor of class IsmFD
def test_IsmFD():
    f = IsmFD('https://variety-ehs.akamaized.net/hls/live/621575/PREM19_UHD/master.m3u8?hdnea=st=1499073189~exp=1499076089~acl=/hls/live/621575/PREM19_UHD/*~hmac=d2bf5a5e14a5bcc955205482057c09afd42f8dda2f3f0b4a0f4bc4e9ca88dc62')
    print(f.get_url() + "\n")


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:04:52.440441
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DASHFD
    from .dashsegments import DASHSegmentsFD
    from .m3u8 import M3U8FD
    from .m3u8_native import M3U8
    from .ism import ISMFD
    from .fragment import CommonFD
    from .fragment import _sanitize_open
    from .utils import (
        parse_ism_formats,
        _check_executable,
        _encode_data_uri,
        match_filter_func,
        get_meta_field,
    )

    # assert ism_fd.ISMFD.FD_NAME
    # assert ism_fd.ISMFD.is_enabled()
    assert ISMFD.can_download(DASHFD.FD_NAME)

# Generated at 2022-06-12 17:05:01.641991
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'track_id': 1,
        'duration': 73928000,
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    stream.seek(0)

# Generated at 2022-06-12 17:05:13.271267
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import YoutubeDL
    from .extractor.common import InfoExtractor
    from .extractor.microsoft_smoothstream import MicrosoftSmoothStreamIE
    from .compat import compat_urllib_request
    from .utils import encode_data_uri
    import os

    class FakeMicroSoftSmoothStreamIE(MicrosoftSmoothStreamIE):
        def _download_smil(self, url, video_id):
            if url is None:
                return self._download_webpage(video_id, video_id, 'Downloading video SMIL data')
            elif url.find('test/test') > -1:
                return self._download_webpage(url, video_id, 'Downloading video SMIL data')
            else:
                raise NotImplementedError()


# Generated at 2022-06-12 17:05:25.151010
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'fourcc': 'AACL',
        'bits_per_sample': 16,
        'channels': 2,
        'codec_private_data': '',
        'duration': 0,
        'sampling_rate': 44100,
        'track_id': 1,
        'nal_unit_length_field': 4,
    }
    output = io.BytesIO()
    write_piff_header(output, params)

# Generated at 2022-06-12 17:05:29.171432
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .smoothstreams import SmoothStreamsIE
    from .youtube import YoutubeIE

    smoothstreams_manifest = extract_manifest_url(SmoothStreamsIE(), 'smoothstreams:east:high')
    youtube_manifest = extract_manifest_url(YoutubeIE(), 'https://www.youtube.com/watch?v=nYh-n7EOtMA')

    print('Testing ismfrag downloader on smoothstreams...')
    IsmFD().download(smoothstreams_manifest)
    print('Testing ismfrag downloader on youtube...')
    IsmFD().download(youtube_manifest)

    return len(IsmFD._downloaders)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:05:36.458843
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = "http://video.ch9.ms/build/2011/ppt/keynote-eis.ism/manifest(format=mpd-time-csf)"
    url_info = url_result(url)
    ismfd = IsmFD(url_info['url'], params={'track_id': 20})
    assert ismfd.track_id == 20


# Generated at 2022-06-12 17:05:44.778748
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    class CountingFile(io.BytesIO):
        def write(self, data):
            self.bytes_written += len(data)
            io.BytesIO.write(self, data)


# Generated at 2022-06-12 17:05:56.710365
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ismFD = IsmFD(test_url, {'noprogress': True})
    print('Test IsmFD constructor: %s' % ismFD)


# Test for download PIFF file
#test_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
test_url = 'http://playready.directtaps.net/smoothstreaming/TTLSS720VC1/To_The_Limit_720.ism/Manifest'
test_params = {'noprogress': True}

# Generated at 2022-06-12 17:05:57.967748
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test the method real_download of class IsmFD
    pass


# Test if the method real_download of class IsmFD is been subclassed

# Generated at 2022-06-12 17:06:02.857771
# Unit test for constructor of class IsmFD
def test_IsmFD():
    print('Start test!')
    #print('Test 1: Empty constructor')
    #result = IsmFD();
    #if not result:
    #    print('Test 1: Failed')
    #else:
    #    print('Test 1: OK')

    print('Test 2: Constructor with empty dictionary')
    result = IsmFD({});
    if not result:
        print('Test 2: Failed')
    else:
        print('Test 2: OK')
    print('Test 2: End')

    print('Test 3: Constructor with empty dictionary')
    result = IsmFD({});
    if not result:
        print('Test 3: Failed')
    else:
        print('Test 3: OK')
    print('Test 3: End')

    print('End test!')

# Generated at 2022-06-12 17:06:32.289926
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.open('/tmp/test.ismv', 'wb')

# Generated at 2022-06-12 17:06:40.313205
# Unit test for function write_piff_header
def test_write_piff_header():
    # run: python -m doctest -v __init__.py
    # run: py.test --doctest-modules youtube_dl/extractor/smoothstreams
    # mock stream
    stream = io.BytesIO()
    # write audio piff header
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 125000000,
        'timescale': 10000000,
        'language': 'eng',
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)
    # get stream content
    stream.seek(0)
    content = stream.read()
    # check headers length
    assert len(content) == 123 + 36 + 21
    # check that header is correct

# Generated at 2022-06-12 17:06:47.689024
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000,
        'timescale': 90000,
        'language': 'deu',
        'width': 1920,
        'height': 1080,
        'codec_private_data': '0142c01e1fac11de90c80000a0690000010142c01e1f9b470802000000ae060001e2c80000b0690000010142c01e1f9b470802000000ae060001e2c80000'
    }
    write_piff_header(stream, params)
    header = stream.getvalue()

# Generated at 2022-06-12 17:06:58.454574
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
        url = 'http://video.ted.com/talks/podcast/AlGore_2006-480p.mp4.ism/AlGore_2006-480p.mp4.ism'
        downloader = YoutubeDL(params={'fragment_retries': 0})

# Generated at 2022-06-12 17:07:04.064658
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    from .common import get_suitable_downloader, set_downloader
    downloader = get_suitable_downloader(IsmFD)
    set_downloader(downloader)
    for ie in gen_extractors():
        m = re.match(r'https?://[^/]+/[^/]+\.([^/.]+)\.([^/.]+)/', ie.IE_NAME)
        if m and m.group(2) == 'ism':
            ie.download(ie.suitable_download_url('http://www.nfl.com/videos/nfl-network-gameday/0ap2000000246091/NFL-Network-Gameday-Peyton-Manning-is-in-danger'))


# Generated at 2022-06-12 17:07:13.496570
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .YoutubeDL import YoutubeDL
    from .extractor import YoutubeIE
    from .extractor import gen_extractors

    extractors = gen_extractors()
    ie = YoutubeIE(YoutubeDL())
    extractor = next(ex for ex in extractors if ex.ie_key() == 'Youtube')
    ie.extractor = extractor


# Generated at 2022-06-12 17:07:14.989798
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test constructor of class IsmFD
    fd = IsmFD(params={})

    assert fd.params == {}

# Generated at 2022-06-12 17:07:21.976564
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .extractor import gen_extractors
    from .compat import is_py2

    # test_ism_fd_real_download.py
    url = 'http://amssamples.streaming.mediaservices.windows.net/91492735-c523-432b-ba01-faba6c2206a2/AzureMediaServicesPromo.ism/manifest(format=m3u8-aapl)'

    # Download the manifest before firing up get_info
    manifest = compat_urllib_request.urlopen(url).read()

    class TestIsmFD(IsmFD):
        JS_TO_GET_BANDWIDTH = None

        @staticmethod
        def suitable(url):
            return True


# Generated at 2022-06-12 17:07:27.910994
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO

    def compare(params, expected_output):
        stream = BytesIO()
        write_piff_header(stream, params)
        output = stream.getvalue()
        assert output == expected_output


# Generated at 2022-06-12 17:07:36.060949
# Unit test for function write_piff_header
def test_write_piff_header():
    cur_stream = io.BytesIO()
    test_params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 30,
        'timescale': 90000,
        'language': 'eng',
        'width': 800,
        'height': 600,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '0164c401fffe10011e2735f7f80f0000016742c01fff4c4d4034aa05488000168ce3880'
    }
    write_piff_header(cur_stream, test_params)
    cur_stream.seek(0)

# Generated at 2022-06-12 17:08:48.324338
# Unit test for function write_piff_header
def test_write_piff_header():
    from .testcases import piff_header_params

    stream = io.BytesIO()
    write_piff_header(stream, piff_header_params['h264'])

    stream.seek(0)
    result = stream.read()
    print('box size:', len(result))
    assert len(result) == piff_header_params['h264']['res']['length']
    assert binascii.hexlify(result) == piff_header_params['h264']['res']['hex'].encode('utf-8')

    stream = io.BytesIO()
    write_piff_header(stream, piff_header_params['aacl'])

    stream.seek(0)
    result = stream.read()
    print('box size:', len(result))


# Generated at 2022-06-12 17:08:56.487459
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import os
    import tempfile

    # Check if the directory where we want to write the test file exists
    try:
        dirname = os.path.dirname(sys.argv[1])
        os.stat(dirname)
    except:
        print('Directory %s does not exist' % dirname)
        print('Please create it before running the test. Exiting')
        sys.exit(1)
    # Clean up the file (if it already exists)
    try:
        os.unlink(sys.argv[1])
    except OSError:
        pass
    # Setup the test configuration

# Generated at 2022-06-12 17:08:57.409174
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    return IsmFD().real_download(None, None)

# Generated at 2022-06-12 17:09:07.025694
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0,
        'fourcc': 'AACL',
        'sampling_rate': 48000,
        'channels': 2,
        'duration': 662800000
    }
    write_piff_header(stream, params)
    print(stream.getvalue())

# Generated at 2022-06-12 17:09:13.572822
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import os
    sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    sys.modules['__main__'].params['skip_unavailable_fragments'] = '--skip-unavailable-fragments' in sys.argv
    sys.modules['__main__'].params['fragment_retries'] = 10
    sys.modules['__main__'].params['test'] = '--test' in sys.argv
    sys.modules['__main__'].params['outtmpl'] = '%s.ismv' % os.path.splitext(os.path.basename(__file__))[0]