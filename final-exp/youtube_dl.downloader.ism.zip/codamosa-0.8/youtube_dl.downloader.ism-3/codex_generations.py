

# Generated at 2022-06-12 16:59:51.421298
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ytdl.YoutubeDL import YoutubeDL
    ydl_opts = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'test': False
    }
    ydl = YoutubeDL(ydl_opts)
    manifest_url = 'http://media.example.com/manifest.ismc'
    ydl.add_info_extractor(InfoExtractor())
    ydl.add_fragment_downloader(IsmFD())
    info = ydl.extract_info(manifest_url)
    # mock the download of the manifest

# Generated at 2022-06-12 17:00:01.188347
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://www.example.com'
    info_dict = {
        'fragments': [{
            'url': url,
        }],
        '_download_params': {
            'track_id': 2,
            'fourcc': 'AACL',
            'sampling_rate': 44100,
            'duration': 32964536,
            'width': 640,
            'height': 480,
        }
    }
    ismfd = IsmFD(url, info_dict)

    assert ismfd._prepare_and_start_frag_download.__name__ == '_prepare_and_start_frag_download'
    assert ismfd._finish_frag_download.__name__ == '_finish_frag_download'
    assert ismfd._download

# Generated at 2022-06-12 17:00:15.052801
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Init params
    params = {
        'track_id': '1',
        'fourcc': 'AACL',
        'duration': 10,
        'timescale': 10000000,
        'language': 'eng',
        'channels': 2,
        'sampling_rate': 3,
        'bits_per_sample': 16,
    }

    # Init bytesIO
    output = io.BytesIO()

    # Write PIFF header
    write_piff_header(output, params)

    result = output.getvalue()
    output.close()

    # Check 'ftyp'
    assert result[0:8] == b'\x00\x00\x00\x20ftyp'
    assert result[8:12] == b'isml'

# Generated at 2022-06-12 17:00:19.161937
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import sys
    if sys.version_info < (2, 7):
        return False
    from ydl.downloader.ism import IsmFD
    test_IsmFD.__self__ = IsmFD(None, {})
    return True


# Generated at 2022-06-12 17:00:32.843113
# Unit test for constructor of class IsmFD
def test_IsmFD():
    manifest_url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ie = IsmFD()
    ie.report_destination(None)
    info_dict = ie._download_webpage(manifest_url, None, 'Downloading manifest')
    ie.params['nopart'] = True
    ie.real_download('test_IsmFD', info_dict)

test_IsmFD()


# Local Variables:
# eval:(load-file "../youtube-dl/youtube_dl/extractor/__init__.py")
# eval:(load-file "../youtube-dl/youtube_dl/__init__.py")
# eval:(setq youtube-dl-info-dict
#       (list
#       

# Generated at 2022-06-12 17:00:45.147298
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:00:56.001917
# Unit test for function write_piff_header
def test_write_piff_header():
    io_stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 200000,
        'timescale': 90000,
        'language': 'eng',
        'height': 720,
        'width': 1280,
        'codec_private_data': '0164001fffe100186764001facd9c0',
    }
    write_piff_header(io_stream, params)

# Generated at 2022-06-12 17:01:05.143130
# Unit test for function write_piff_header
def test_write_piff_header():
    fh = io.BytesIO()
    write_piff_header(fh, {'track_id': 1, 'fourcc': 'H264', 'height': 640, 'width': 480, 'sampling_rate': 44100, 'channels': 2, 'duration': 10000000, 'codec_private_data': '0164001fffe1001967640029ac56e08205837b909e003780e00', 'language': 'und'})
    fh.seek(0)
    return fh.read()


# Generated at 2022-06-12 17:01:18.770489
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    IsmFD._real_download()
    """
    print('Testing IsmFD._real_download()')
    import os, sys
    from yt_dl_savedata import YoutubeDL
    from extraction_used_funcs import get_fragment_filename
    # Testing parameters
    filename = 'test_filename'
    manifest_string = open('test_data/manifest.xml', 'r').read()

# Generated at 2022-06-12 17:01:29.498323
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 1000,
            'timescale': 10000000,
            'codec_private_data': '0000000167640033ACD9B401E2A00480422456E54E10C856EE28808800000030080000001427E0E079011401600000F1A5BC5FEC',
        })
        print(binascii.hexlify(stream.getvalue()))
#test_write_piff_header()



# Generated at 2022-06-12 17:02:01.785290
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import tempfile
    import os
    import shutil
    import subprocess

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-12 17:02:11.090739
# Unit test for function write_piff_header
def test_write_piff_header():
    assert write_piff_header(None, {'track_id': 2, 'fourcc': 'AACL', 'duration': 42, 'sampling_rate': 44100, 'language': 'eng'}) is None
    assert write_piff_header(None, {'track_id': 2, 'fourcc': 'H264', 'duration': 42, 'language': 'eng', 'codec_private_data': '01234', 'nal_unit_length_field': 5, 'width': 800, 'height': 600}) is None


# Generated at 2022-06-12 17:02:17.725384
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import shutil
    from  youtube_dl.utils import make_HTTPServer
    from  youtube_dl.utils import make_IncompleteHttpDl
    with make_HTTPServer(handler=IsmFD.partial_download_handler) as server:
        with make_IncompleteHttpDl(
                server.get_url(), downloader_options={'format': 'ism',
                'fragment_retries': 3,
                'skip_unavailable_fragments': False}) as dl:
            dl.prepare()
            assert dl.test_result() is None

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:02:31.449483
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD(params={'url':'http://example.com/1/Manifest'})

    assert fd.params['url'] == 'http://example.com/1/Manifest'
    assert fd.params['timeout'] == 5
    assert fd.params['fragment_retries'] == 0
    assert fd.params['skip_unavailable_fragments'] == True
    assert fd.params['test'] == False
    assert fd.params['extra_http_headers'] == 'xxx'
    assert fd.params['fragment_base_url'] == 'http://example.com/1/Manifest'
    assert fd.params['output_format'] == 'ism'
    assert fd.params['noprogress'] == False
    assert fd.params['test_fps']

# Generated at 2022-06-12 17:02:41.382522
# Unit test for function extract_box_data
def test_extract_box_data():
    data = binascii.unhexlify('00000010667479707001000000147466647265737300000000000000106674797070010000001474666472657377000000000000001066747970700100000014746664726573700100000010667479707001000000147466647265737200000000000010667479707001000000147466647265737300000000')
    assert binascii.hexlify(extract_box_data(data, (b'typ',))) == b'74666472657373'
    assert binascii.hexlify(extract_box_data(data, (b'typ', b'typ'))) == b'74666472657377'

# Generated at 2022-06-12 17:02:53.167516
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {'fourcc': 'AH', 'channels': 2, 'sampling_rate': 44100, 'bits_per_sample': 16, 'track_id': 1, 'duration': 333333}
    stream = io.BytesIO()
    write_piff_header(stream, params)
    print(stream.getvalue().encode('hex'))

# Generated at 2022-06-12 17:03:02.030708
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(11) + b'moov' + b'aaa' + u32.pack(11) + b'moov' + b'bbb' + u32.pack(11) + b'moov' + b'ccc'
    assert extract_box_data(data, [b'moov']) == b'aaa'
    assert extract_box_data(data, [b'moov', b'moov']) == b'bbb'
    assert extract_box_data(data, [b'moov', b'moov', b'moov']) == b'ccc'



# Generated at 2022-06-12 17:03:06.667428
# Unit test for function extract_box_data
def test_extract_box_data():
    test_data = b'moov\x00\x00\x00\x08'
    assert extract_box_data(test_data, [b'moov']) == b''



# Generated at 2022-06-12 17:03:14.028395
# Unit test for function extract_box_data
def test_extract_box_data():
    from io import BytesIO
    data = b'\x00\x00\x00\x20moov\x00\x00\x00\x10\x00\x00\x00\x08mvex\x00\x00\x00\x04abcd\x00\x00\x00\x04fooo'
    box_sequence = b'moov', b'mvex', b'abcd', b'fooo'
    assert extract_box_data(data, box_sequence) == b''



# Generated at 2022-06-12 17:03:23.216703
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.can_download_url('http://server/manifest.ism') is True
    assert IsmFD.can_download_url('http://server/manifest.ism/SomeOtherStuff') is True
    assert IsmFD.can_download_url('http://server/manifest.ism/Manifest') is True
    assert IsmFD.can_download_url('http://server/manifest.ism/Manifest(format=m3u8-aapl)') is True
    assert IsmFD.can_download_url('http://server/manifest.ism/Streams(video=1)') is True
    assert IsmFD.can_download_url('http://server/manifest.ism/QualityLevels(12345)/Fragments(video=1)') is True
    assert IsmFD.can_download_

# Generated at 2022-06-12 17:03:47.983989
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:03:57.898306
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 0,
        'height': 720,
        'width': 1280,
        'codec_private_data': '0000000167640000ACD9000001C58698000003000003000003008D1E9EE1000000000'
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)
    batch = [line.strip() for line in stream.getvalue().decode('utf-8').split('\n') if line.strip()]
    # assert(batch == [
    #     '00 00 00 b4 ftyp',
    #     '00 00 00 b4 moov',
    #     '00 00 00 92 mvhd',
    #     '00 00

# Generated at 2022-06-12 17:04:06.217776
# Unit test for function write_piff_header
def test_write_piff_header():
    from codecs import getreader

    from .testcases import (
        TEST_PHP_FILE_PIFF_AUDIO_CONTENT_ID,
        TEST_PHP_FILE_PIFF_VIDEO_CONTENT_ID,
    )

    from .test_php import (
        load_php_file,
    )

    # check audios
    audio_files = (TEST_PHP_FILE_PIFF_AUDIO_CONTENT_ID, )
    for audio_file in audio_files:
        params = load_php_file(audio_file)
        encoded_fds = io.BytesIO()
        write_piff_header(encoded_fds, params)
        encoded_fds.seek(0)
        decoded_stream = io.BytesIO(encoded_fds.read())
        decoded

# Generated at 2022-06-12 17:04:09.168967
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.open('moov.bin', 'wb') as f:
        write_piff_header(f, {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 20000000,
            'timescale': 10000000,
            'sampling_rate': 48000,
            'language': 'und',
        })


# Generated at 2022-06-12 17:04:18.845677
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD_test(IsmFD):
         # prevent request to the web
        def _download_fragment(self, *args):
            return (True, '')

    # file descriptor

# Generated at 2022-06-12 17:04:28.639595
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ytdl.downloader.http import HttpFD

    # init youtube-dl instance
    ydl = YoutubeDL({})
    # init HttpFD instance
    httpfd = HttpFD(ydl, {'nooverwrites': True, 'continuedl': False, 'noprogress': True, 'quiet': True,
                          'restrictfilenames': True, 'nopart': True, 'updatetime': False})
    # init IsmFD instance
    info_dict = {'_download_params': {'track_id': 131074, 'fourcc': 'AACL', 'duration': 5342568, 'timescale': 10000000,
                                      'language': 'eng', 'height': 0, 'width': 0, 'sampling_rate': 48000}}
    ismfd = IsmFD

# Generated at 2022-06-12 17:04:34.951279
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from youtube_dl.utils import prepend_extension
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.compat import parse_qs
    from tempfile import NamedTemporaryFile
    import urllib.request

    # These are obtained from a real use case
    download_params = {
        'codec_private_data': '010a764c80080000ffe100168ee3c80d9ed807e028120d2',
        'duration': 50000,
        'fourcc': 'H264',
        'height': 720,
        'language': 'und',
        'sampling_rate': 44100,
        'track_id': 1,
        'width': 1280
    }

    ydl = YoutubeDL({})
   

# Generated at 2022-06-12 17:04:42.237498
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .common import FakeHttpDl
    from .common import DummyFileDownloader

    ydl = FakeYDL()
    ydl.params = {
        'quiet': True,
        'skip_unavailable_fragments': True,
        'test': False,
        'fragment_retries': 0,
    }

    from ydl.extractor.common import InfoExtractor
    from ydl.extractor.youtube import YoutubeIE

    ie = InfoExtractor(ydl, {})
    ie.possible_ie = ie.gen_extractor_classes()

    samples = []

# Generated at 2022-06-12 17:04:52.527212
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 1010000000,  # 11 sec
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe1001e67640028acd93012f840000030001000003000164040028acd9300f8400043450040',
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)
    assert stream.getvalue() == b'ftypisml' + u32.pack(1) + b'piffiso2' + \
        b'moov' + u32.pack(1346) + b'mvhd' + u8.pack

# Generated at 2022-06-12 17:04:53.106594
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:05:37.844970
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ytdl.downloader.common import FileDownloader
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['skip_download'] = False
    ydl.add_info_extractor(
        IsmIE(ydl)
    )
    ydl.add_progress_hook(lambda d: False)
    filename = 'test.ism'
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

# Generated at 2022-06-12 17:05:48.818736
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0x1b,
        'fourcc': 'AACL',
        'duration': 96000,
        'timescale': 96000,
        'language': 'eng',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:05:52.337251
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    stream = IsmFD(ydl=ydl)
    # We test if the class IsmFD is instantiated correctly
    assert isinstance(stream, IsmFD)
    # We test if each attribute is instantiated correctly
    assert stream.ydl == ydl
    assert stream.params == {}
    assert stream.name == None

# Generated at 2022-06-12 17:06:02.503379
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass
#     video_url = "http://amssamples.streaming.mediaservices.windows.net/634cd01c-6822-4630-8444-8dd6279f94c6/BigBuckBunny.ism/manifest"
#     video_id = "BigBuckBunny"
#     download_params = {
#         "track_id": 1,
#         "fourcc": "H264",
#         "duration": 1071401,
#         "timescale": 10,
#         "language": "und",
#         "codec_private_data": "0164001fffe1001667640029ac560027869400000300010000030015c489f0000000168ebecb22c00f",
#         "width": 1280,
#         "height": 720


# Generated at 2022-06-12 17:06:14.285563
# Unit test for function write_piff_header
def test_write_piff_header():
    io = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10,
        'timescale': 10000000,
        'language': 'eng',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    write_piff_header(io, params)


# Generated at 2022-06-12 17:06:27.085169
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    url = "http://www.loopdeloops.net/clips/clips/bunny.ism/Manifest"
    info_dict = {
        'id': 'bunny',
        'extractor_key': 'IsmFD',
        'ext': 'mp4',
        'title': "Big Buck Bunny",
        'duration': 599.35,
        'formats': ['http://dash.edgesuite.net/akamai_test/BigBuckBunny_Trailer_400-240_v2_1Mbps.mov-IIS_2pass.ism/Manifest'],
    }
    ie = InfoExtractor()
    ie._cache_file = lambda *args: None
    fd = ie._download_fd_from_url(url, info_dict)

# Generated at 2022-06-12 17:06:36.983876
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:06:43.868768
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_params = {
        'token': 'AQAAAAA',
        'track_id': 0
    }
    test_params2 = {
        'token': 'AQAAAAA',
        'track_id': 1
    }
    test_params3 = {
        'token': 'AQAAAAA',
        'track_id': 2
    }
    test_params4 = {
        'token': 'AQAAAAA',
        'track_id': 3
    }
    test_URL = 'http://origin-multimediatest.akamaized.net/multibitrate/multibitrate-v2.ism/multibitrate-v2.m3u8'

# Generated at 2022-06-12 17:06:50.011669
# Unit test for function extract_box_data
def test_extract_box_data():
    ftyp_payload = b'isml'  # major brand
    ftyp_payload += u32.pack(1)  # minor version
    ftyp_payload += b'piff' + b'iso2'  # compatible brands

    mvhd_payload = u64.pack(0)
    mvhd_payload += u64.pack(0)
    mvhd_payload += u32.pack(0)
    mvhd_payload += u64.pack(0)
    mvhd_payload += s1616.pack(0)  # rate
    mvhd_payload += s88.pack(0)  # volume
    mvhd_payload += u16.pack(0)  # reserved
    mvhd_payload += u32.pack(0) * 2 

# Generated at 2022-06-12 17:06:58.106018
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    info = {
        'fragments': [
            {'url': 'http://localhost:8080/QQQQQQQQ?set-cookie=a=b;Path=/'},
            {'url': 'http://localhost:8080/RRRRRRRR?set-cookie=a=b;Path=/'},
            {'url': 'http://localhost:8080/SSSSSSSS?set-cookie=a=b;Path=/'},
            {'url': 'http://localhost:8080/FFFFFFFF?set-cookie=a=b;Path=/'},
        ]
    }