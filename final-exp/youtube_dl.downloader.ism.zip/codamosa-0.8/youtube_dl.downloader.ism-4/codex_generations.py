

# Generated at 2022-06-12 17:00:00.899990
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4onDemand_source.mpd'
    proxy = 'http://127.0.0.1:8118'
    params = {
        'outtmpl': 'tmp',
        'format': 'ism',
        'proxy': proxy
    }

    fd = IsmFD(url, params)
    return fd
# print(test_IsmFD())

# Generated at 2022-06-12 17:00:14.659981
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("Testing IsmFD: real_download()")

    import os
    import sys
    import shutil
    import tempfile

    tmp_dir = os.path.join(tempfile.gettempdir(), str(os.getpid()))
    os.mkdir(tmp_dir, 0o700)
    os.chdir(tmp_dir)
    if sys.platform == "win32":
        # Set current directory to long path format to allow long filenames creation
        import ctypes
        kernel32 = ctypes.windll.kernel32
        GetShortPathNameW = kernel32.GetShortPathNameW
        GetShortPathNameW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint]

# Generated at 2022-06-12 17:00:23.099071
# Unit test for function write_piff_header
def test_write_piff_header():
    from .utils import TEST_DIR
    from .fragment import FragmentFD
    from ..utils import stream_url

    def run_write_piff_header_test(params):
        stream = FragmentFD(io.BytesIO(), 'wb')

        write_piff_header(stream, params)

        stream.seek(0)
        test_stream = FragmentFD(stream_url(TEST_DIR + '/' + params['test_file']), 'rb')
        assert stream.read() == test_stream.read()


# Generated at 2022-06-12 17:00:24.891345
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for real_download method of class IsmFD
    return True



# Generated at 2022-06-12 17:00:38.870252
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:00:44.660706
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00\x00\x00\x1c' b'moov' b'\x00\x00\x00\x0c' b'mvhd' b'\x00\x00\x00\x00'
    assert extract_box_data(data, (b'mvhd',)) == b'\x00\x00\x00\x00'



# Generated at 2022-06-12 17:00:55.676196
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # NOTE: Just test time and timezone conversion
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 360,
        'width': 640,
        'codec_private_data': '01640029ffeca1040032e9b2e22000001b589138000100000030080000003008021880',
        'nal_unit_length_field': 4,
    }

    for s in ('+08', '-12'):
        os.environ['TZ'] = 'UTC' + s

        with tempfile.TemporaryFile() as tmp:
            write_piff_header(tmp, params)
            tmp.seek(0, 0)

# Generated at 2022-06-12 17:00:56.813580
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = IsmFD(None)

# Generated at 2022-06-12 17:01:08.380038
# Unit test for function extract_box_data
def test_extract_box_data():
    mdat_box = '6D64617400000000000000AC00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000014000000010400000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'
    atsz_box = '6174737A0000000100000001'

# Generated at 2022-06-12 17:01:11.703786
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD()
    fd.real_download("filename", {'fragments': [{'url': 'url'}]})

# Generated at 2022-06-12 17:01:34.816696
# Unit test for function extract_box_data
def test_extract_box_data():
    BOX_SEQUENCE = (b'stsd', b'mp4a')

# Generated at 2022-06-12 17:01:44.572733
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
        Testing the IsmFD Class
    """
    from .dash import DASHFD
    from ..extractor import get_info_extractor

    for ie in get_info_extractor(['ism']):
        if ie.IE_NAME == 'ism':
            break
    for ie in get_info_extractor(['dash']):
        if ie.IE_NAME == 'dash':
            break


# Generated at 2022-06-12 17:01:55.415153
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import get_testdata_stream
    # Write to temp file for testing
    import tempfile
    fd = tempfile.TemporaryFile(suffix='.ismv')
    write_piff_header(fd, {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'codec_private_data': '67428029fc5c0000b8ed991e0048000568ef2c00',
    })
    fd.seek(0)
    assert fd.read() == get_testdata_stream('write_piff_header.ismv').read()



# Generated at 2022-06-12 17:02:04.562296
# Unit test for function write_piff_header
def test_write_piff_header():
    test_params_audio = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'channels': 6,
        'bits_per_sample': 16,
        'sampling_rate': 48000
    }
    test_params_video = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 100000,
        'width': 800,
        'height': 600,
        'codec_private_data': '000000016742000fa70000afeb403e8000000001668ce3c80'
    }
    for test_params in (test_params_audio, test_params_video):
        stream = io.BytesIO()
        write_piff_header(stream, test_params)
       

# Generated at 2022-06-12 17:02:12.535606
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:02:20.007183
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    write_piff_header(output, dict(
        track_id=1,
        fourcc='H264' if True else 'AACL',
        duration=10 * 1000 * 1000,
        codec_private_data='4D4028EFFCA27A0DCA93471A526A8020D2CFCB1C5EBD0E3DC3A9FC021CF0FA4C',
        width=1280,
        height=720,
        nal_unit_length_field=4,
    ))
    print(binascii.hexlify(output.getvalue()))



# Generated at 2022-06-12 17:02:34.050656
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'test.ism'

# Generated at 2022-06-12 17:02:46.607029
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'H264',
            'duration': 10 * 60 * 60 * 1000 * 1000 * 10,
            'timescale': 10000000,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
            'codec_private_data': '01640029ffe1000167640029acd94020',
        }
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:02:56.173134
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    stderr = sys.stderr
    sys.stderr = open('/dev/null', 'w')
    ydl = YoutubeDL({'noplaylist': True})

# Generated at 2022-06-12 17:03:05.536916
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'avc',
        'codec_private_data': '01640028ffe1006d32640141f480028ffe1006d68ee3660f2e94f040',
        'nal_unit_length_field': 4,
        'channels': 2,
        'sampling_rate': 48000,
        'bits_per_sample': 16,
        'duration': 10000000
    }
    write_piff_header(stream, params)
    stream.seek(0)
    # C:\Users\Wang\AppData\Roaming\Python\Python36\site-packages\tensorflow\tensorboard\tensorboard\plugins\video\resources\example.mp4

# Generated at 2022-06-12 17:03:31.905028
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Assert that method real_download exists in class IsmFD
    assert 'real_download' in dir(IsmFD), 'Method real_download does not exist in class IsmFD'
    print('Method real_download exists.')

# Generated at 2022-06-12 17:03:42.612656
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': b'H264',
        'duration': 10000000,
        'sampling_rate': 44100,
        'timescale': 10000000,
        'nal_unit_length_field': 4,
        'codec_private_data': '000000016742802995f948009071822c00f05f30'
    }
    write_piff_header(out, params)

    with open('tmp/test_write_piff_header.mp4', 'wb') as f:
        f.write(out.getvalue())


# Generated at 2022-06-12 17:03:44.149314
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # create a IsmFD
    IsmFD()


# Generated at 2022-06-12 17:03:50.005112
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    downloader = YoutubeDL(FakeYoutubeDl())
    filename = "test.ism"
    info_dict = {}
    instance = IsmFD(downloader, filename, info_dict)
    result = instance.real_download(filename, info_dict)
    assert isinstance(result, bool)

# Generated at 2022-06-12 17:03:59.295827
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import os
    import tempfile
    import shutil
    from .common import (
        BUNCH_OF_URL_OK_TEST,
        BUNCH_OF_URL_ERROR_TEST,
        get_temp_filename,
        get_temp_dir,
    )
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.ism

    # Simulate input: a fragment file downloaded
    # and save to a unique temporary file
    fragment_filename = get_temp_filename(suffix='.ism')
    with open(fragment_filename, 'wb') as fragment_output_file:
        fragment_output_file.write('test fragment file')

    # Instantiate the FragmentFD class for test
    fragment_fd = youtube_dl.downloader.fragment.FragmentFD()



# Generated at 2022-06-12 17:04:07.045385
# Unit test for function write_piff_header
def test_write_piff_header():
    class FakeStream():
        def __init__(self, params={}):
            self._params = params
            self._first_write = b''
            self._second_write = b''
        @property
        def params(self):
            return self._params
        def write(self, data):
            if not self._first_write:
                self._first_write = data
            else:
                self._second_write = data
    test_params = {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 12345,
        'nal_unit_length_field': 4,
        'language': 'und',
        'sampling_rate': 44100,
        'bits_per_sample': 16
    }
    test_stream = FakeStream(test_params)
   

# Generated at 2022-06-12 17:04:14.464842
# Unit test for constructor of class IsmFD
def test_IsmFD():
    IsmFD(1,2)
    time.sleep(10)
    real_download = _get_method(IsmFD, 'real_download')
    real_download(1,2)
    time.sleep(10)
    extract_box_data(1, [2])
    time.sleep(10)
    write_piff_header(1,2)
    time.sleep(10)

t = threading.Thread(target = test_IsmFD)
t.start()

# Generated at 2022-06-12 17:04:21.609533
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    stream_url = 'http://s2.smu.cdn.edgesuite.net/c8/videos/smu_1327_300.ism/smu_1327_300/smu_1327_300-audio=96000-video=400000-1364187572.ism/QualityLevels(400000)/Fragments(Audio=96000)'
    expected_url = 'http://s2.smu.cdn.edgesuite.net/c8/videos/smu_1327_300.ism/smu_1327_300/smu_1327_300-audio=96000-video=400000-1364187572.ism/QualityLevels(400000)/Fragments(Audio=96000)'
    
    params = {}
    params['test'] = 'True'

# Generated at 2022-06-12 17:04:27.094024
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # test parameters
    params = {'noprogress': True,
              'fragment_retries': 10,
              'skip_unavailable_fragments': True}
    # init IsmFD
    ismfd = IsmFD(params)
    # test IsmFD
    assert ismfd.params == params
    assert ismfd.FD_NAME == "ism"
    assert ismfd.continued_dl == False


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:04:34.101099
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:05:39.622229
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys, os
    test_dir_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(test_dir_path, '..'))
    from test_download_manager import test_download_manager
    from test_downloader import test_downloader
    from test_utils import test_utils
    test_downloader.test_utils = test_utils
    test_downloader.test_download_manager = test_download_manager
    test_IsmFD.test_downloader = test_downloader
    test_IsmFD.test_download_manager = test_download_manager
    test_IsmFD.test_utils = test_utils
    IsmFD.test_utils = test_utils

# Generated at 2022-06-12 17:05:49.602781
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    url1 = 'https://media.example.com/media/bbb-360p.ism/QualityLevels(840999)/Fragments(video=0)'
    url2 = 'https://media.example.com/media/bbb-360p.ism/QualityLevels(840999)/Fragments(video=746000)'
    file1 = io.BytesIO(b'<Box: size=0x27B, type=moov, payload=<Box: size=0x271, type=mvhd>')
    file2 = io.BytesIO(b'<Box: size=0x27B, type=moov, payload=<Box: size=0x271, type=mvhd>')
    returncode1 = 1
    returncode2 = 0

# Generated at 2022-06-12 17:05:57.801240
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    params = {'noplaylist': True}
    ydl = FakeYDL()
    ydl.add_info_extractors()
    fd_dict = {'url': 'http://example.com/extractor.ism/Manifest'}
    ydl.params = params
    result = False
    try:
        ctx = {'filename': 'test-output'}
        fd = IsmFD(ydl, ctx, fd_dict)
        info_dict = {}
        fd.real_download(
            fd_dict['url'], info_dict)
    except Exception as e:
        result = True
    assert not result


# Generated at 2022-06-12 17:06:03.790278
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Arrange:
    # Create object instance of IsmFD
    ismFD = IsmFD(None, params=None, downloader=None)
    assert ismFD != None

    # Assure:
    # Assert constant values
    assert ismFD.FD_NAME == 'ism'



# Generated at 2022-06-12 17:06:12.378403
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    from .compat import compat_urllib_request
    from .compat import compat_HTTPError

    # Test for method _download_fragment of class IsmFD

    # Input Parameters
    #
    # ctx:
    #     A dictionary containing the following keys:
    #         filename: output filename
    #         total_frags: total number of fragments
    # fragment_index: index of the fragment to be downloaded
    #
    # Test Data
    ctxTestData = {}
    ctxTestData['filename'] = "test"
    ctxTestData['total_frags'] = 1000
    ctxTestData['status'] = {}

# Generated at 2022-06-12 17:06:24.735028
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    
    url = "http://wamsprodglobal001acs.origin.mediaservices.windows.net/2b7cdb16-0df1-49c5-8d2c-a757b4a4e4bb/BigBuckBunny.ism/manifest"
    
    info_dict = {}
    
    from ytdl_isd import IsdFD
    isd = IsdFD()
    isd.params = {'test': True}
    isd.report_destination = lambda *x: None
    isd.to_screen = lambda *x: None
    isd.report_retry_fragment = lambda *x: None
    isd.report_skip_fragment = lambda *x: None
    isd.report_error = lambda *x: None
    isd.real

# Generated at 2022-06-12 17:06:29.764962
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    with open(os.devnull, 'wb') as f:
        write_piff_header(f, {'track_id': 1, 'fourcc': 'H264', 'duration': 5 * 10000000, 'width': 1280, 'height': 720, 'codec_private_data': '000000016742e01eac32001542fcf07b'})



# Generated at 2022-06-12 17:06:38.785695
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    params = {'sampling_rate': 48000, 'width': 1920, 'bits_per_sample': 16, 'track_id': 0, 'channels': 2, 'codec_private_data': '0000000167640011acD9001f849fc01e9583a00030001000003000168e8001e6d3c01eac2b403031307c8fc00300300007c8fc0030030000c80000a4104007e800000500000', 'height': 1080, 'duration': 0, 'fourcc': 'AVC1', 'nal_unit_length_field': 4}
    with tempfile.TemporaryFile('wb+') as f:
        write_piff_header(f, params)
        f.seek(0)

# Generated at 2022-06-12 17:06:46.900742
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test_fragment import fragment_fd
    assert write_piff_header(fragment_fd(), {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1,
        'timescale': 1,
        'language': 'und',
        'height': 0,
        'width': 0,
    }) is None

# Generated at 2022-06-12 17:06:56.649325
# Unit test for function write_piff_header
def test_write_piff_header():
    test_data = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
        'codec_private_data': '1188f'
    }
    stream = io.BytesIO()
    write_piff_header(stream, test_data)
    print(stream.getvalue().hex())