

# Generated at 2022-06-12 16:59:56.741910
# Unit test for function write_piff_header
def test_write_piff_header():
    out = io.BytesIO()
    write_piff_header(out, {'track_id': 1, 'fourcc': 'AVC1',
                            'duration': 10000000, 'timescale': 10000000,
                            'language': 'eng', 'width': 640, 'height': 480,
                            'codec_private_data': '0164001f28ee300d965684746d05000001b589e6000100000030080112000568ce18c00'})

# Generated at 2022-06-12 17:00:02.632205
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """Test method real_download for class IsmFD"""
    filename = 'output.ismv'
    info_dict = {
    }

    ifd = IsmFD()
    ifd.real_download(filename, info_dict)
    ifd.report_progress(123, 234)


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:00:16.907229
# Unit test for constructor of class IsmFD
def test_IsmFD():
    filename = 'video_url'

# Generated at 2022-06-12 17:00:30.130199
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1300000,
        'timescale': 10000000,
        'language': 'und',
        'height': 720,
        'width': 1280,
        'codec_private_data': '01640028ffe10004d4db4e2eba5c5050000000000000030001000c48d8800280164001fffe10010268ee3cb0c1e43cb89e8cb0c1e43cb8abf100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
    }
    stream = io.BytesIO()
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:00:36.261268
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    write_piff_header(fd, {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 0x1f4,
        'timescale': 0x3e8,
        'language': 'en',
        'height': 0,
        'width': 0,
        'sampling_rate': 0xac44,
        'channels': 2,
        'bits_per_sample': 16
    })

# Generated at 2022-06-12 17:00:39.534195
# Unit test for function write_piff_header
def test_write_piff_header():
    from .headers import write_piff_header

    with io.BytesIO() as f:
        params = {
            'is_audio': True,
            'codec_private_data': '-1',
            'fourcc': 'aacl',
            'channels': 2,
            'sampling_rate': 48000,
            'bits_per_sample': 16,
            'duration': 0,
            'track_id': 1,
            'timescale': 48000,
        }
        write_piff_header(f, params)



# Generated at 2022-06-12 17:00:48.890825
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['skip_download'] = True
    ydl.params['simulate'] = True
    ydl.params['test'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['quiet'] = True
    ydl.params['dump_single_json'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    # ISM with audio track

# Generated at 2022-06-12 17:00:58.322495
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Open the file for reading
    _f = open(r"C:\Users\User\Downloads\ism\ism_seg_1", "r")
    # Get the data
    data = _f.read()
    # Close the file
    _f.close()

    url = "https://amssamples.streaming.mediaservices.windows.net/634cd01c-6822-4630-8444-8dd6279f94c6/BigBuckBunny.ism/manifest(format=mpd-time-csf)"

# Generated at 2022-06-12 17:01:08.632989
# Unit test for function write_piff_header
def test_write_piff_header():
    class FakeStream():
        def __init__(self):
            self.buf = io.BytesIO()
        def write(self, data):
            self.buf.write(data)
    params = {
        'track_id': 0xfa,
        'fourcc': 'AACL',
        'duration': 0xa2c,
        'timescale': 0x4ed,
        'language': 'eng',
        'channels': 0x8,
        'bits_per_sample': 0x78,
        'sampling_rate': 0xb3,
    }
    stream = FakeStream()
    write_piff_header(stream, params)
    file_contents = stream.buf.getvalue()

# Generated at 2022-06-12 17:01:22.056538
# Unit test for constructor of class IsmFD
def test_IsmFD():
    for url in [
        'a.ism',
        'a.ism/manifest',
        'a.ism/manifest(format=mpd-time-csf)',
        'a.ism/QualityLevels(96000)/Fragments',
    ]:
        assert IsmFD._is_url(url)
    for url in [
        'a.ismx',
        'a.ism/manifest(format=foo)',
        'a.ism/manifest(format=mpd-time-csf,foo)',
        'a.ism/manifest(format=mpd-time-csf,foo=0)',
        'a.ism/QualityLevels(96000foo)/Fragments',
    ]:
        assert not IsmFD._is_url(url)

# Generated at 2022-06-12 17:01:38.513316
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    filename = 'ism-1.ism'
    info_dict = {'fragments' : [{'url' : 'ism-1.ism'}]}
    real_download(filename, info_dict)


# Generated at 2022-06-12 17:01:44.148979
# Unit test for constructor of class IsmFD
def test_IsmFD():
    import ytdl.extractor.ism

    assert ytdl.extractor.ism.IsmFD.__name__ == 'IsmFD'
    assert ytdl.extractor.ism.IsmFD.FD_NAME == 'ism'

# Generated at 2022-06-12 17:01:50.300320
# Unit test for constructor of class IsmFD
def test_IsmFD():
    key = u'lskdjfkljkldfjgkljdfkljgkljdfgkldf'
    url = u'http://smooth.example.com/Manifest'
    params = {
        'skip_unavailable_fragments': True,
    }
    ism_fd = IsmFD(key, url, params)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:02:03.017301
# Unit test for function write_piff_header
def test_write_piff_header():
    try:
        from httplib import HTTPConnection
        from urlparse import urlparse
    except ImportError:
        from http.client import HTTPConnection
        from urllib.parse import urlparse
    import os
    import errno
    from ..utils import (
        parse_m3u8_master_playlist
    )

    # Define a dummy HTTP server

# Generated at 2022-06-12 17:02:14.815963
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_IsmFD.FD_CLASS = IsmFD
    IsmFD.download = IsmFD.real_download
    test_IsmFD.params['url'] = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    test_IsmFD.params['skip_unavailable_fragments'] = False
    test_IsmFD.params['test'] = True
    test_IsmFD.params['nopart'] = True
    test_IsmFD.params['quiet'] = True
    test_IsmFD.params['test'] = True
    test_IsmFD.params['outtmpl'] = 'test.mp4'
    test_IsmFD.params['fragment_retries'] = 10

#

# Generated at 2022-06-12 17:02:27.866529
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    if True:
        # Test audio header
        params = {
            'fourcc' : 'AACL',
            'track_id' : 1,
            'bits_per_sample' : 16,
            'channels' : 2,
            'sampling_rate' : 44100,
            'duration' : 934000,
            'timescale' : 44100,
            'language' : 'und',
        }
        with io.BytesIO() as bytes_io:
            write_piff_header(bytes_io, params)

# Generated at 2022-06-12 17:02:39.696847
# Unit test for function write_piff_header
def test_write_piff_header():
    from .helpers import BytesIO
    from .piff import write_piff_header, FragmentFD

    stream = BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 0,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 640,
        'codec_private_data': '6764001efac9ac8020201f',
    }
    write_piff_header(stream, params)
    print(stream.getvalue())

# Generated at 2022-06-12 17:02:51.753584
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 0x10,
        'fourcc': 'H264',
        'duration': 0x3a98,
        'timescale': 0x3e8,
        'height': 0,
        'width': 0,
        'language': 'und',
        'codec_private_data': '6764001f9aca000f27e0a9b8f2931e08bf2f41a1b83d3010001300c1fffe1001867641f9aca800958408d8da0f014f92c0'
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:02:54.534666
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test for method real_download of class IsmFD
    print('Test for method real_download of class IsmFD')
    print('The method is not implemented yet, please add testing code in the future')
    pass


# Generated at 2022-06-12 17:03:04.447180
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Tests that the constructor of IsmFD class works correctly
    ismFD = IsmFD('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 17:03:17.552668
# Unit test for constructor of class IsmFD

# Generated at 2022-06-12 17:03:29.368836
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import json
    from youtube_dl.extractor import DASHIE
    from youtube_dl.utils import FileDownloader
    from .test_downloader import FakeYDL
    from .test_downloader import MockHttpServer

    class FakeIE(DASHIE):
        def __init__(self, downloader, params, url):
            super(FakeIE, self).__init__(downloader, params, url)

# Generated at 2022-06-12 17:03:40.755912
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    ##
    ## 1. Initialize
    ##
    from io import BytesIO
    from .common import FileDownloader

    handle, temp_path = get_tmp_file()
    handle.close()

    fd_test = IsmFD()
    params = {
        'url': 'http://host/manifest',
        'fragments': [
            {'url': 'http://host/frag1'},
            {'url': 'http://host/frag2'},
        ],
        '_downloader': FileDownloader('test', {}, None),
        'outtmpl': temp_path,
    }
    fd_test.params = params

# Generated at 2022-06-12 17:03:47.829824
# Unit test for function write_piff_header
def test_write_piff_header():
    import os, json
    class StringStream(io.BytesIO):
        def write(self, data):
            return super(StringStream, self).write(data.encode('utf-8'))
    def check_box(data):
        def read(count):
            nonlocal data
            result = data[:count]
            data = data[count:]
            return result
        size = u32.unpack(read(4))[0]
        box_type = read(4)
        #print(size, box_type, data)
        if box_type == b'ftyp':
            _, major_brand, minor_version, compatible_brands = u32.unpack(read(12))
            print('ftyp', major_brand, minor_version, compatible_brands)

# Generated at 2022-06-12 17:03:57.802489
# Unit test for function write_piff_header
def test_write_piff_header():

    class Stream(io.BytesIO):
        def seek(self, offset, whence=0):
            pass

    stream = Stream()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'codec_private_data': '0164001fffe100178e10e94408f20b145fec0a1323cff0ee6a1880cff7b6f0a8a7b063e9b97080000000168ebe8e8b0163c0',
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:03:59.502169
# Unit test for function write_piff_header
def test_write_piff_header():
    test_file = io.BytesIO()
    test_write_piff_header(test_file)

# Generated at 2022-06-12 17:04:00.077363
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:04:05.188752
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(f, {
            'track_id': 1,
            'duration': 1000,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
            'fourcc': 'AACL',
        })
        #f.seek(0)
        #print(f.read())
        #assert f.read() == b''



# Generated at 2022-06-12 17:04:07.867376
# Unit test for constructor of class IsmFD
def test_IsmFD():
    stream = IsmFD('http://foo.bar', {})
    print(stream.FD_NAME)



# Generated at 2022-06-12 17:04:14.312814
# Unit test for function write_piff_header
def test_write_piff_header():
    test_data = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 96000,
        'timescale': 96000,
        'language': 'und',
        'width': 854,
        'height': 480,
        'codec_private_data': '01640032ffc100000030140142e0028ee3c80f00a0c00155888b8e00000297',
        'nal_unit_length_field': 4,
    }

# Generated at 2022-06-12 17:04:40.316151
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFDMock(IsmFD):
        def __init__(self, ydl, params):
            pass

        def real_download(self, filename, info_dict):
            return True
    ydl = YoutubeDL({'username': 'test_user', 'password': 'test_pass'})
    ismfd = IsmFDMock(ydl, {'skip_unavailable_fragments': False, 'fragment_retries': 3})

# Generated at 2022-06-12 17:04:45.257887
# Unit test for constructor of class IsmFD
def test_IsmFD():
    def test(params):
        fd = IsmFD(params)
        assert fd.params == params
    params = {
        'outtmpl': '%(id)s.mp4',
        'fragment_base_url': 'https://example.com/fragment',
        'manifest_url': 'https://example.com/manifest',
        'fragment_duration': 5,
        'skip_unavailable_fragments': True,
        'fragment_retries': 0,
        'test': False,
        'noprogress': True,
    }
    test(params)


# Generated at 2022-06-12 17:04:55.719520
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    """
    https://github.com/rg3/youtube-dl/issues/12
    """
    
    # works properly
    real_download('http://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/Manifest(format=mpd-time-csf)')
    
    # works properly
    real_download('http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest')
    
    # works properly
    real_download('http://playready.directtaps.net/smoothstreaming/SSWSS720H264PR/SuperSpeedway_720.ism/Manifest')
    
    # works properly

# Generated at 2022-06-12 17:05:03.429994
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 2,
            'fourcc': 'H264',
            'duration': 10,
            'codec_private_data': '01640028ffe100192740010016401602800000030080000300c0000300c0000000000000000000001b8',
            'nal_unit_length_field': 4,
        }
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:05:14.698702
# Unit test for function write_piff_header
def test_write_piff_header():
    piff_header = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000000,
        'width': 640,
        'height': 360,
        'channels': 1,
        'bits_per_sample': 16,
        'sampling_rate': 22050,
        'sampling_rate': 22050,
        'codec_private_data': '0164001FFFE100058CAD19B3E2F2A9F00C0064001FFFE100058CAD19B3E2F2A9F05D014001640DE0',
    }
    write_piff_header(piff_header, params)
    piff_header.seek(0)

# Generated at 2022-06-12 17:05:21.487746
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:05:26.262018
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import gen_extractors
    assert IsmFD.can_download('http://example.com/file.ism/Manifest', {'fragments' : []})
    e = IsmFD(gen_extractors(), {'fragments': []})
    assert e.get_id() == "ism"
    assert e.get_name() == "ism"



# Generated at 2022-06-12 17:05:38.582867
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    segment_urls = []
    for i in range(0, 100):
        segment_urls.append({'url':'common.ism/QualityLevels(60000)/Fragments(audio=0,video=%d)' % i})
    for i in range(0, 100):
        segment_urls.append({'url':'common.ism/QualityLevels(30000)/Fragments(audio=0,video=%d)' % i})
    fragments = []
    fragments.append({'url':'common.ism/QualityLevels(60000)/Fragments(audio=0,video=0)'})
    fragments.append({'url':'common.ism/QualityLevels(30000)/Fragments(audio=0,video=0)'})

# Generated at 2022-06-12 17:05:39.345745
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-12 17:05:40.275979
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:06:12.934554
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for download segments in a ISM manifest file.
    url = "http://origin-multiplatform-f.akamaihd.net/z/multi/april11/hdworld/hdworld_,512x288_450_b,640x360_700_b,768x432_1000_b,1024x576_1400_m,.mp4.csmil/manifest.f4m?hdcore=3.7.0&g=PHCZXDFNZWBP"
    test = IsmFD(url)

# Generated at 2022-06-12 17:06:25.376752
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .dash import DashFD


# Generated at 2022-06-12 17:06:35.533559
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .utils import FakeYDL
    from .extractor.generic import GenericIE
    from .downloader.f4m import F4mFD

# Generated at 2022-06-12 17:06:39.091266
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import Downloader
    from .external_downloader import ExternalFD
    from .utils import sanitize_open

    # Create a test downloader with IsmFD as downloader for _ismv urls
    d = Downloader({})
    d.add_info_extractor(None)
    d.add_down

# Generated at 2022-06-12 17:06:47.071759
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 96,
        'sampling_rate': 48000,
        'codec_private_data': 'ffc0210e12c0',
        'channels': 2
    }
    write_piff_header(fd, params)

    fd.seek(0)

# Generated at 2022-06-12 17:06:58.183579
# Unit test for function write_piff_header
def test_write_piff_header():
    import os
    import sys
    import pytest
    sys.modules['__main__'] = os


# Generated at 2022-06-12 17:07:07.827577
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:07:08.392592
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass

# Generated at 2022-06-12 17:07:11.438178
# Unit test for function extract_box_data
def test_extract_box_data():
    data = box(b'moov', box(b'mvhd', u8.pack(0)))
    assert extract_box_data(data, [b'moov', b'mvhd']) == u8.pack(0)

# Generated at 2022-06-12 17:07:17.732531
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .downloader import Downloader
    from .extractor import gen_extractors
    downloader = Downloader()
    info_dict = downloader.gen_extractor()._real_extract("http://manifest.us.rd.llnwd.net/vod//smil:cnn/cnn_iphone.smil/media-b2051_1.m4s")
    assert info_dict['fragments'][0]['url'] == "http://manifest.us.rd.llnwd.net/vod/smil:cnn/cnn_iphone.smil/media-b2051_1.m4s"

# Generated at 2022-06-12 17:08:59.435711
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import test
    import urllib
    import urllib.request
    import urllib.parse
    import urllib.response
    import sys
    import os
    import hashlib
    import errno
    import re
    import json
    import tempfile
    import unittest
    import collections
    import functools
    import datetime
    import shutil
    import random
    import time
    import gzip
    import zlib
    import socket
    import subprocess
    import http.client
    import http.cookies
    import http.cookiejar
    import email.message
    import email.utils
    from io import StringIO, BytesIO
    import socketserver
    import http.server
    import threading
    import base64
    from functools import partial
    from collections import deque

# Generated at 2022-06-12 17:09:07.528899
# Unit test for function extract_box_data
def test_extract_box_data():
    box_data = extract_box_data(b'\x00\x00\x00\x16plyr\x00\x00\x00\x0e1.2.2\x006\x00\x00\x00\x00', [b'plyr'])
    assert box_data == b'1.2.2\x006\x00\x00\x00\x00'
    box_data = extract_box_data(box_data, [b'6'])
    assert box_data == b''
    box_data = extract_box_data(box_data, [b'7'])
    assert box_data == None



# Generated at 2022-06-12 17:09:10.416535
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD("url")
    except ValueError:
        print("Correct Error: Value Error")



# # Run unit test when this file is executed as main program
# if __name__ == '__main__':
#     test_IsmFD()

# Generated at 2022-06-12 17:09:21.721285
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = dict(fourcc='H264', track_id=1, duration=500, width=1920, height=1080,
                  sampling_rate=44100, language='und', nal_unit_length_field=4,
                  codec_private_data=('0164001fffe10019276400240fa58a12c0f02010000016742c00c8401f5a60000000011c08004800'
                                      '0000e1028a2c0100000168ce3c80'))
    write_piff_header(stream, params)