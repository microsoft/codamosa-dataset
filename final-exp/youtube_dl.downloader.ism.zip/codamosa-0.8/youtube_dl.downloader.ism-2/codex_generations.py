

# Generated at 2022-06-12 16:59:38.224632
# Unit test for function write_piff_header
def test_write_piff_header():
    file = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16
    }
    write_piff_header(file, params)
    data = file.getbuffer()
    assert data[:12] == b'\x00\x00\x00\x1cftypisml\x00\x00\x00\x01piffiso2'

# Generated at 2022-06-12 16:59:45.511633
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'report_download_progress': False, 'progress_hooks': []})

    ydl.add_default_info_extractors()
    with ydl:
        ydl.download(['http://www.microsoft.com/silverlight/mediaplayer/content/content/streaming.ism/manifest'])


test_IsmFD.test = True

# Generated at 2022-06-12 16:59:55.150066
# Unit test for function write_piff_header
def test_write_piff_header():
    track_id = 1
    fourcc = 'AVC1'
    duration = 1.5
    timescale = 10000000
    language = 'und'
    height = 0
    width = 0
    is_audio = width == 0 and height == 0
    creation_time = modification_time = int(time.time())

    test_params = {'track_id': 1, 'fourcc': 'AVC1', 'duration': 1.5, 'timescale': 10000000, 'language': 'und', 'height': 0, 'width': 0}

    out = io.BytesIO()
    write_piff_header(out, test_params)

# Generated at 2022-06-12 16:59:57.437330
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('http', {}, None, 'ism', 'IsmFD')
    fd.to_screen('IsmFD')

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:00:05.036124
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .utils import IsmFD
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request, compat_urllib_error
    from .downloader import common

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self):
            InfoExtractor.__init__(self)

        def _real_initialize(self):
            pass

    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'

    ie = FakeInfoExtractor()

    req = compat_urllib_request.Request(url)
    req.add_header('User-Agent', common.IE_USER_AGENT)

# Generated at 2022-06-12 17:00:18.648607
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Downloads a ISM stream and exits
    """
    assertlen(sys.argv, 2)
    fd = IsmFD(params=None)
    # The test result should be similar
    # http://playready.directtaps.net/pr/svc/rightsmanager.asmx?o=U

# Generated at 2022-06-12 17:00:32.604127
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import time
    import sys
    from ydl_mp4 import FragmentFD

    #Mock classes
    class IsmFD(FragmentFD):
        def _download_fragment(self, fragment_index, fragment_url, video_id, retries):
            print("Downloading fragment {}/{} from {}".format(fragment_index, 1, fragment_url))
            return "mp4-fragment", 1
    #Unit test code
    class TestIsmFD_real_download:

        def setUp(self):
            self.test_obj = IsmFD()

        def test_real_download(self):
            self.test_obj.params = {'test': True}
            self.test_obj.to_screen = lambda msg: print(msg)
            filename = "test_output.ism"



# Generated at 2022-06-12 17:00:37.699211
# Unit test for function write_piff_header
def test_write_piff_header():
    output = io.BytesIO()
    params = {
        'track_id': 1,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
        'fourcc': 'AACL',
        'duration': 10000000,
        'timescale': 10000000
    }
    write_piff_header(output, params)

# Generated at 2022-06-12 17:00:44.928782
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://s3.amazonaws.com/AKIAJOWA3YPRKL6U74RQ/smil:TruTv_768x432_1100kbps_24fps_aac_stereo_192kbps_44100Hz_1.smil/jwplayer.smil'
    fd = IsmFD(url, params={'test': True, 'prefer_free_formats': False, 'format': 'ism'})
    return fd



# Generated at 2022-06-12 17:00:55.889244
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from ydl.YoutubeDL import YoutubeDL
    from ydl.extractor import gen_extractors
    import sys
    import tempfile
    import os
    from .constants import get_testdata_path

    sys.argv = ['youtubedl', '--no-cache-dir', '--no-check-certificate']

    gen_extractors()

    data_path = get_testdata_path()
    fd = IsmFD(YoutubeDL({}), {'destination': 'test.ismv'}, {})

# Generated at 2022-06-12 17:01:19.115382
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class options:
        extract_flat = False
        merge_output_format = None
        hls_prefer_native = None
        hls_prefer_ffmpeg = None
        hls_use_mpegts = None
        hls_segment_filename = None
        hls_segment_size = None
        hls_start_offset = None
        hls_base_url = None


# Generated at 2022-06-12 17:01:31.882286
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:01:43.225952
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..extractor import YTDLExtractor
    from .common import FakeYDL
    from ..utils import encode_data_uri

    ydl_opts = {
        'outtmpl': 'test.ism',
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'continuedl': False,
        'quiet': True,
        'nooverwrites': True,
        'logger': FakeYDL(),
    }

    class TestExtractor(YTDLExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Test Extractor'

        _VALID_URL = r'^https?://(?:www\.)?example\.com/'


# Generated at 2022-06-12 17:01:54.501921
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 1000,
        'language': 'es',
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000
    }
    test_buffer = io.BytesIO()
    stream = io.BufferedWriter(test_buffer)
    write_piff_header(stream, params)
    stream.flush()
    box_type, box_length = u32.unpack(test_buffer.getvalue()[:8])
    assert box_type == b'ftyp'
    assert box_length == 20
    box_type, box_length = u32.unpack(test_buffer.getvalue()[28:36])

# Generated at 2022-06-12 17:01:56.612412
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:02:07.649798
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    write_piff_header(fd, {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '0000000167640033acaffc81800001e67b81000468ee3c80',
        'duration': 50000000,
        'height': 360,
        'width': 640,
        'language': 'eng',
    })

# Generated at 2022-06-12 17:02:09.142030
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.FD_NAME == 'ism'



# Generated at 2022-06-12 17:02:16.039360
# Unit test for function extract_box_data
def test_extract_box_data():
    import os
    with io.open(os.path.join(os.path.dirname(__file__), 'files/bbb_dash.mpd'), 'rb') as f:
        mpd = f.read()
    assert binascii.hexlify(extract_box_data(mpd, (b'ftyp',))) == b'69736d6c0100000069736f32'
    assert binascii.hexlify(extract_box_data(mpd, (b'ftyp', b'piff'))) == b'69736f32'



# Generated at 2022-06-12 17:02:17.095024
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass



# Generated at 2022-06-12 17:02:20.122016
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        yd_IsmFD = IsmFD({'outtmpl': 'test'})
        assert True
    except:
        assert False


# Generated at 2022-06-12 17:02:35.369727
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import UrlFD
    from .downloader import FD_NAME

    for name, fd in IsmFD.get_info_extractors().items():
        if name in FD_NAME:
            assert isinstance(fd, UrlFD)

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:02:46.838653
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_url_1 = 'https://test_origin.test/test_manifest.ism/Manifest'
    test_url_2 = 'https://test_origin.test/test_manifest.ism/QualityLevels(50541)/Fragments(Video=0)'
    test_segments = [{'url': test_url_2}]

# Generated at 2022-06-12 17:02:48.952817
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Creating the object
    ismFD = IsmFD()



# Generated at 2022-06-12 17:02:49.943420
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# Generated at 2022-06-12 17:02:52.025183
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ism_fd = IsmFD(None)
    assert ism_fd.FD_NAME == 'ism'


# Generated at 2022-06-12 17:02:58.840451
# Unit test for function write_piff_header
def test_write_piff_header():
    audio_params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'channels': 2,
        'duration': 75000000,
        'timescale': 10000000,
    }
    video_params = {
        'track_id': 2,
        'fourcc': 'H264',
        'codec_private_data': '01640032ac019a3e735f8d8d02e2e2bfa100000030010000003001000000480fca34c80fca34c',
        'height': 720,
        'width': 1280,
        'duration': 75000000,
        'timescale': 10000000,
    }

# Generated at 2022-06-12 17:03:06.694081
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as f:
        write_piff_header(f, {'track_id': 1, 'fourcc': 'AACL', 'duration': 0, 'height': 0, 'width': 0, 'sampling_rate': 44100, 'channels': 2, 'bits_per_sample': 16})
        assert f.tell() == 476
    with io.BytesIO() as f:
        write_piff_header(f, {'track_id': 1, 'fourcc': 'AVC1', 'duration': 0, 'height': 720, 'width': 1280, 'codec_private_data': '000000016742C00D971E01000001B27676311280E24C4', 'nal_unit_length_field': 4})
        assert f.tell() == 584


# Generated at 2022-06-12 17:03:16.737026
# Unit test for function extract_box_data
def test_extract_box_data():
    from .smoothstream import SmoothStreamFD
    from ..compat import (compat_urllib_request, compat_urllib_parse,compat_urllib_error)
    from ..compat import compat_b64decode

    mp4_url = 'https://ams-i.akamaihd.net/i/multiplatform-prod/captions/2016/02/04/6038623887001/Captions-EN_US-6038623887001-AJA.jsonp.txt'
    media_url = ''
    page = compat_urllib_request.urlopen(mp4_url).read().decode('utf-8')
    page = page[page.find('(') + 1:page.rfind(')')]
    data = compat_json.loads(page)

# Generated at 2022-06-12 17:03:24.615310
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = dict()
    params['track_id'] = 1
    params['fourcc'] = 'H264'
    params['duration'] = 652330000000
    params['timescale'] = 10000000
    params['language'] = 'und'
    params['height'] = 480
    params['width'] = 640
    params['channels'] = 2
    params['bits_per_sample'] = 16
    params['sampling_rate'] = 44100

# Generated at 2022-06-12 17:03:35.554092
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .playlist import PlaylistFD

    # First line is URL from which we download the playlist
    # Second line contains the word "SINGLE" when we expect exact one segment
    for testline in (
        'https://ams-p-msl.akamaized.net/playready/\nSINGLE',
        'https://ams-p-msl.akamaized.net/playready/',
    ):
        url, single = testline.strip().split()
        url = url.rstrip('/')

        playlist = PlaylistFD(url)
        playlist_data = playlist.download(params={'skip_unavailable_fragments': False})
        assert playlist_data == url

        playlist = PlaylistFD(url)

# Generated at 2022-06-12 17:04:02.167370
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO

    stream = BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 9100100000,
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
        'language': 'und',
        'height': 1080,
        'width': 1920,
        'codec_private_data': '67640029ffe1001a67640029acd941f8',
    }

    write_piff_header(stream, params)
    print(stream.getvalue().encode('hex'))


# Generated at 2022-06-12 17:04:08.814067
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor.common import InfoExtractor
    from .downloader import _extract_m3u8_formats
    from .utils import parse_iso8601

    ie = InfoExtractor(IsmFD)
    ie.params['noplaylist'] = True
    ie.params['skip_download'] = True
    ie.params['subtitles'] = True

# Generated at 2022-06-12 17:04:17.142427
# Unit test for function write_piff_header
def test_write_piff_header():
    from copy import copy

# Generated at 2022-06-12 17:04:26.536700
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class test_args():
        url = 'https://x18z179cwizy3qz3r5p5r5r5-kodi.akamaized.net/video/chunklist_w1608168563.m3u8'
        test = False

    test_args.filepath = 'output1.mp4'
    test_args.username = 'test_username'
    test_args.password = 'test_password'
    test_args.fragment_retries = 2
    test_args.skip_unavailable_fragments = False
    ism_fd = IsmFD(test_args)
    ism_fd.real_download(test_args.filepath, 'test_info_dict')

# Generated at 2022-06-12 17:04:33.671214
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:04:36.765306
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.isml/.m3u8"
    dl = IsmFD().real_download(url)
    print(dl)



# Generated at 2022-06-12 17:04:43.640780
# Unit test for function write_piff_header
def test_write_piff_header():
    from ykdl.util.odict import ODict
    params = ODict(
        track_id = 1,
        fourcc = 'avc1',
        width = 1920,
        height = 1080,
        duration = 1000000000,
        timescale = 1000,
        codec_private_data = "0164001fffe10027840e7b40001f40c0c0020000e3000002f80600001769672c3c3b3d6c9e6f77cb6c00",
        language = 'en',
        channels = 2,
        bits_per_sample = 16,
        sampling_rate = 48000,
        nal_unit_length_field = 4
    )
    with io.BytesIO() as stream:
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:04:53.518146
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO
    s = BytesIO()
    write_piff_header(s, {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 20000,
        'timescale': 10000,
        'language': 'eng',
        'height': 480,
        'width': 640,
    })

# Generated at 2022-06-12 17:05:02.411861
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from tests.helper import setUpYDL
    from tests.helper import FakeYDL

    class FakeInfoDict(dict):
        def __init__(self):
            dict.__init__(self)
            self['_download_params'] = {'height': 720}

    ydl = setUpYDL(dict(format='720p',
                        test=True))
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_info_extractor(SmoothStreamsIE())
    ydl.add_info_extractor(IStreamIE())
    ydl.add_info_extractor(IsmFD())
    fake_info_dict = FakeInfoDict()
    fake_ydl = FakeYDL()
    fake_ydl

# Generated at 2022-06-12 17:05:13.956116
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AVC1',
        'duration': 1000,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'sampling_rate': 44100,
        'codec_private_data': '0000000167428029EE1C852E4011000000300100000030000030176E401C814',
        'channels': 2,
        'bits_per_sample': 16,
    }

# Generated at 2022-06-12 17:06:03.100440
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test for audio only
    compat_urllib_request.urlopen = MagicMock()

# Generated at 2022-06-12 17:06:14.677195
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = dict(
            track_id=1,
            fourcc='AACL',
            duration=10,
            timescale=1,
            language='abc',
            channels=2,
            bits_per_sample=16,
            sampling_rate=32,
        )
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:06:27.368864
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Please note that this unit test is not complete, as it is not
    # possible to test downloading an ISM manifest with python.
    # The test can currently only see that the method is present.
    assert IsmFD.real_download, "method real_download() is missing"

if __name__ == "__main__":
    # Get a logger for the module
    logger = logging.getLogger(__name__)
    # Set the logging level for this module
    logger.setLevel(logging.DEBUG)
    # Create a handler for the logger, so that logging messages are
    # printed to the console
    handler = logging.StreamHandler()
    # Set the logging level of the handler
    handler.setLevel(logging.DEBUG)
    # Add the handler to the logger
    logger.addHandler(handler)
    # Run unit tests

# Generated at 2022-06-12 17:06:37.054961
# Unit test for function extract_box_data
def test_extract_box_data():
    box_sequence = [b"moov", b"trak", b"mdia", b"minf", b"stbl", b"stsd", b"avc1", b"avcC"]

# Generated at 2022-06-12 17:06:46.388420
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Create a parameters object for use with the IsmFD object
    params = {'skip_unavailable_fragments': True,
                 'fragment_retries': 0,
                 'test': False,
                 'quiet': False,
                 'file_id': 337580}

    # Create a IsmFD object and assign fake values for fields not used by real_download
    obj = IsmFD()
    obj.to_screen = lambda x: x
    obj.report_warning = lambda x: x
    obj.report_error = lambda x: x
    obj.report_skip_fragment = lambda x: x
    obj.report_retry_fragment = lambda err, frag_index, count, fragment_retries: x
    obj.report_destination = lambda filename: x

# Generated at 2022-06-12 17:06:57.768808
# Unit test for function write_piff_header
def test_write_piff_header():
    fd = io.BytesIO()
    params = {
        'fourcc': 'H264',
        'codec_private_data': '01640029ffe1001f67640029ac33001860d7a000001b08fe00008d00010000009a7605060301000468eea0',
        'duration': 0,
        'height': 720,
        'width': 1280,
        'track_id': 1,
    }
    write_piff_header(fd, params)

# Generated at 2022-06-12 17:07:03.582062
# Unit test for function extract_box_data
def test_extract_box_data():
    import unittest
    # No data provided
    with self.assertRaises(ValueError):
        extract_box_data(b'', [b'ftyp'])

    # Box not found in data
    with self.assertRaises(ValueError):
        extract_box_data(b'\x00\x00\x00\x00\x00\x00\x00\x00', [b'ftyp'])

    # Box found in data
    data = b'\x00\x00\x00\x08\x00\x00\x00\x00ftyp\x00\x00\x00\x00\x00\x00\x00\x00'
    ftyp_box = extract_box_data(data, [b'ftyp'])

# Generated at 2022-06-12 17:07:08.342858
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # create a IsmFD with default argument
    ismfd = IsmFD({})

    # get the download method and its output
    method_rtn = ismfd.real_download(filename = "", info_dict = {"fragments":[{"url":""}]} )

    # check that it return True
    assert method_rtn == True



# Generated at 2022-06-12 17:07:16.690695
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD("http://video.ted.com/talks/podcast/BrunoLatour_2012G-480p.ism")
    except AssertionError:
        pass
    try:
        IsmFD("http://video.ted.com/talks/podcast/BrunoLatour_2012G-480p.ism/manifest")
    except AssertionError:
        pass
    try:
        IsmFD("http://video.ted.com/talks/podcast/BrunoLatour_2012G-480p.ism/manifest(video,format=mp4-480p)")
    except AssertionError:
        pass


# Generated at 2022-06-12 17:07:23.485162
# Unit test for function write_piff_header
def test_write_piff_header():
    from io import BytesIO

    from ..utils import (
        decode_mpeg4_header,
        encode_mpeg4_header,
        write_piff_header,
    )

    # Prepare data:
    stream = BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 2965,
        'timescale': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100,
    }
    # Execute function:
    write_piff_header(stream, params)
    assert decode_mpeg4_header(BytesIO(stream.getvalue())) == params
    stream.seek(0, 0)
    # Execute function again:
    write_piff_