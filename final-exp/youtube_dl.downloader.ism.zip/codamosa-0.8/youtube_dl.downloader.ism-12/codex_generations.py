

# Generated at 2022-06-12 16:59:53.869483
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Run the above class constructor and print results
    :return: 
    """

    url = 'https://amssamples.streaming.mediaservices.windows.net/bc57e088-27ec-44e0-ac20-a85ccbcd50da/AzureMediaServicesPromo.ism/manifest(format=mpd-time-csf)'
    params = {'skip_unavailable_fragments': True, 'fragment_retries': 3}
    downloader = IsmFD(params)
    downloader.real_download(url, None)

if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-12 16:59:57.548206
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'\x00' * 8 + b'moov' + b'\x00' * 4 + b'trak' + b'\x00' * 4
    assert extract_box_data(data, (b'moov', b'trak')) == b'\x00' * 4



# Generated at 2022-06-12 17:00:03.237408
# Unit test for function extract_box_data
def test_extract_box_data():
    data = b'moov\x00\x00\x00\x00moov'
    assert extract_box_data(data, [b'moof', b'moof']) == b''
    data = b'moov\x00\x00\x00\x00moov'
    assert extract_box_data(data, [b'moov', b'moov']) == b''
    data = b'moov\x00\x00\x00\x00moov'
    assert extract_box_data(data, [b'moov']) == b'moov'
    data = b'moov\x00\x00\x00\x00moov'
    assert extract_box_data(data, [b'moof']) == b''

# Generated at 2022-06-12 17:00:08.840936
# Unit test for function write_piff_header
def test_write_piff_header():
    mock_stream = io.BytesIO()
    params = {
        "track_id": 1,
        "fourcc": "AACL",
        "duration": 800000000,
        "channels": 2,
        "sampling_rate": 44100,
        "bits_per_sample": 16
    }
    write_piff_header(mock_stream, params)
    # print(mock_stream.getvalue().hex())
    expected_value = "6d6f6f76" + "12000000" + "746b6864" + "00000001" + "00000000" + "ffffffff" + "00000000" + "00000000" +\
        "0000000000000000" + "0000000000000000" + "00000000" + "00000000" + "00000000" + "00000001" + "00000000" +\
        "00000000" + "00000000"

# Generated at 2022-06-12 17:00:20.793603
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    import io
    from .common import (
        create_descriptor_tag,
        create_descriptor_length,
    )


# Generated at 2022-06-12 17:00:22.467387
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # TODO
    pass



# Generated at 2022-06-12 17:00:36.011754
# Unit test for function write_piff_header
def test_write_piff_header():
    import os

    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'codec_private_data': '0164001fffe1001967640028ac2c80808080e10c01401b60',
        'timescale': 1,
        'duration': 2,
        'width': 1280,
        'height': 720,
    }
    write_piff_header(stream, params)
    actual = stream.getvalue()
    filename = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), 'fixtures/test.ismv')
    with open(filename, 'rb') as f:
        expected = f.read()
    assert actual == expected



# Generated at 2022-06-12 17:00:37.416706
# Unit test for constructor of class IsmFD
def test_IsmFD():
    my_IsmFD = IsmFD()

    # Unittest for attribute FD_NAME
    assertEquals(my_IsmFD.FD_NAME, 'ism')


# Generated at 2022-06-12 17:00:47.907348
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as output:
        metadata_params = {
            'track_id': 1,
            'duration': 10 * 10000000,
            'timescale': 10000000,
            'fourcc': 'H264',
            'codec_private_data': '0164001fffe1001667640096acb43ee19f9d907186ae8f10001056e001000568ebecb22c',
            'nal_unit_length_field': 4,
            'width': 1920,
            'height': 1080}
        write_piff_header(output, metadata_params)
        output.seek(0)

# Generated at 2022-06-12 17:00:58.838766
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Do we really need to create a test file? 
    filename = ''

# Generated at 2022-06-12 17:01:22.736222
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(30) + b'moov'
    data += u32.pack(12) + b'mvhd'
    data += u32.pack(10) + b'udta'
    data += u32.pack(20) + b'uuid'
    data += u32.pack(6) + b'stts'
    data += u32.pack(22) + b'udta'

    assert len(extract_box_data(data, [b'mvhd'])) == 12
    assert len(extract_box_data(data, [b'udta'])) == 26
    assert len(extract_box_data(data, [b'uuid'])) == 20
    assert len(extract_box_data(data, [b'moov', b'mvhd'])) == 12


# Generated at 2022-06-12 17:01:30.819346
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Set information for fragment and segments
    frag_index = 1
    frag_count = 1
    total_frags = 1
    fragments = [{'url': 'fragment1.ism', 'duration': '1.0'}]
    segment = ({'url': 'fragment1.ism', 'duration': '1.0'})
    info_dict = {"fragments": fragments}

    # set params if method download

# Generated at 2022-06-12 17:01:37.479323
# Unit test for constructor of class IsmFD
def test_IsmFD():
    try:
        IsmFD(None, None)
        IsmFD(None, None) >= IsmFD(None, None)
        IsmFD(None, None) <= IsmFD(None, None)
    except Exception:
        traceback.print_exc()
        assert False


# Generated at 2022-06-12 17:01:46.033044
# Unit test for function write_piff_header
def test_write_piff_header():
    from .fragment import FragmentFD
    from .piff import write_piff_header
    from .utils import get_tmp_files_dir, read_files_dir, delete_files_dir, TEST_FILES_DIR, close_object
    files_dir = u'piff_test'
    files_dir = get_tmp_files_dir(files_dir)
    stream = io.BytesIO()

# Generated at 2022-06-12 17:01:59.735388
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        write_piff_header(stream, {
            'track_id': 1,
            'channel': 1,
            'duration': 1000,
            'timescale': 1000,
            'language': 'zxx',
            'height': 1,
            'width': 1,
            'sampling_rate': 44100000,
            'fourcc': 'AACL',
            'codec_private_data': '',
        })
        out = stream.getvalue()
        assert out[:8] == b'\x00\x00\x00\x00\x00\x00\x00\x18'
        assert out[8:16] == b'ftypisml'

# Generated at 2022-06-12 17:02:12.190797
# Unit test for function write_piff_header
def test_write_piff_header():
    fake_params_audio = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 836 * 10 * 10000000,
        'timescale': 10000000,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 48000,
    }
    fake_params_video = {
        'track_id': 2,
        'fourcc': 'H264',
        'codec_private_data': '0000000167640029ac56d401010000000168ee3c80',
        'duration': 836 * 10 * 10000000,
        'timescale': 10000000,
        'width': 1920,
        'height': 1080,
    }
    stream = io.BytesIO()

# Generated at 2022-06-12 17:02:19.248601
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'fourcc': 'AACL',
        'track_id': 1,
        'duration': 0,
        'timescale': 44100,
        'sampling_rate': 44100,
    }
    write_piff_header(stream, params)
    moov_position = stream.tell()
    assert moov_position == 8 + 24 + 24 + 8 + 24 + 8 + 16 + 24 + 24 + 8 + 8 + 24 + 8 + 24 + 24 + 8 + 16 + 24 + 24 + 8 + 8 + 24 + 8 + 24 + 24
    params['duration'] = 1024
    write_piff_header(stream, params)
    assert stream.tell() == moov_position
    stream.seek(moov_position)

# Generated at 2022-06-12 17:02:32.773402
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Load test data
    data = compat_urllib_request.urlopen('http://127.0.0.1/segment/').read()
    segment = json.loads(data.decode('utf-8'))
    data = compat_urllib_request.urlopen('http://127.0.0.1/info/').read()
    info_dict = json.loads(data.decode('utf-8'))
    # Create IsmFD object
    fd = IsmFD()
    # Call method real_download of class IsmFD
    filename = '/tmp/YT-DL-TEST-ismfd.ismv'
    shell_exec('rm %s' % filename)
    result = fd.real_download(filename, info_dict)
    # Check result of test
    # TODO: Add

# Generated at 2022-06-12 17:02:42.037561
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    inputfilename = 'ism_input.json'
    inputfile = codecs.open(inputfilename, 'r', 'utf-8')
    inputjson = json.load(inputfile)
    inputfile.close()

    # Create output file for verify
    outputfilename = 'ism_output.dat'
    outputfile = open(outputfilename, 'wb')

    retval = IsmFD(dict()).real_download(outputfile, inputjson)


# Generated at 2022-06-12 17:02:53.642358
# Unit test for function write_piff_header
def test_write_piff_header():
    # create a BytesIO object
    stream = io.BytesIO()
    # call the function
    params = {
        'track_id': 1,
        'fourcc': 'avc1',
        'duration': 1000,
        'timescale': 10000000,
        'language': "und",
        'height': 360,
        'width': 1280,
        'codec_private_data': "0000000167640029ACD901F3C89B55B00B0FC2D8",
        'nal_unit_length_field': 4,
    }
    write_piff_header(stream, params)
    # get the content from the BytesIO object
    res = stream.getvalue()
    # close the BytesIO object
    stream.close()
    # compare with the expected result
    assert res

# Generated at 2022-06-12 17:03:19.989181
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():

    class IsmFD(FragmentFD):
        def __init__(self, params):
            super(IsmFD.self).__init__(params)

    fd = IsmFD({'test': False})
    fd.params = {'skip_unavailable_fragments': True, 'fragment_retries': 0}

    fd.download = FakeYDL.download


    fd.real_download = FakeYDL.real_download
    # test the function real_download


if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:03:26.363624
# Unit test for function extract_box_data
def test_extract_box_data():
    def get_box_data(data):
        return extract_box_data(data, (b'moov', b'mvex', b'trex'))

    # Verify that it can extract data outside of the context of a real video file

# Generated at 2022-06-12 17:03:36.576951
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        params = {
            'track_id': 1,
            'fourcc': 'AVC1',
            'duration': 7000,
            'timescale': 1000,
            'codec_private_data': '01640028ffe9028e027bff',
            'width': 1280,
            'height': 720
        }
        write_piff_header(stream, params)

# Generated at 2022-06-12 17:03:38.987036
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # TODO: Implement unit test for real_download for class IsmFD
    print('TODO: Implement unit test for real_download for class IsmFD')

# Generated at 2022-06-12 17:03:46.692313
# Unit test for function write_piff_header
def test_write_piff_header():
    fourcc = 'AACL'
    duration = 10000000
    language = 'und'
    channels = 2
    bits_per_sample = 16
    sampling_rate = 48000
    f = io.BytesIO()
    write_piff_header(f, {'track_id': 1, 'fourcc': fourcc, 'sampling_rate': sampling_rate, 'channels': channels, 'bits_per_sample': bits_per_sample, 'language': language, 'duration': duration})
    f.seek(0)
    header = f.read()
    assert header[8:16] == b'moov'
    assert header[36:40] == u32.pack(1)
    assert header[144:152] == u32.pack(duration * sampling_rate // 10000000)
    assert header[488:492]

# Generated at 2022-06-12 17:03:57.217684
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    from .utils import std_headers
    from .compat import compat_urllib_request

    request = compat_urllib_request.Request("")
    request.add_header("User-Agent", std_headers()["User-Agent"])

    info_extractor = YoutubeIE()
    info_dict = info_extractor._extract_info("", request)
    info_dict["_downloader"] = InfoExtractor()
    info_dict["_downloader"].params = {
        "outtmpl": "",
        "quiet": True,
    }

    url_handler = IsmFD(info_dict)
    url_handler.real_download("", info_dict)


# Generated at 2022-06-12 17:04:05.692715
# Unit test for function extract_box_data
def test_extract_box_data():
    moov = box(b'moov', u32.pack(0))
    print(moov, extract_box_data(moov, (b'moov',)))
    udta = box(b'udta', u32.pack(0))
    moov = box(b'moov', udta)
    print(moov, extract_box_data(moov, (b'moov', b'udta')))
    trak = box(b'trak', u32.pack(0))
    moov = box(b'moov', trak + udta)
    print(moov, extract_box_data(moov, (b'moov', b'udta')))
    mdia = box(b'mdia', u32.pack(0))

# Generated at 2022-06-12 17:04:14.018262
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    params = {
        #'debug_printtraffic': True,
        'save_filename': 'ss.ismv',
        'skip_unavailable_fragments': False,
    }
    ismfd = IsmFD(params, url)
    ismfd.run()
    return True

# ------------------------------------------------------------------------------


# Generated at 2022-06-12 17:04:21.312923
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import _add_ns, _dash_ns
    from .dash import _add_ns_xsd
    from .dash import _add_ns_itags
    from .dash import _add_ns_yt
    from .dash import _add_ns_media
    from .dash import _add_ns_smpte
    from ytdl.Extractor import get_info_extractor
    from ytdl.compat import urlparse
    import xml.etree.ElementTree as ET

    urllib = compat_urllib_request.import_module('urllib.request')
    req = urllib.urlopen('https://manifest.us-west-2.amazonaws.com/hls/live/562472/xmas/xmas.m3u8')

# Generated at 2022-06-12 17:04:21.923966
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass



# Generated at 2022-06-12 17:05:14.867404
# Unit test for function write_piff_header
def test_write_piff_header():
    o = io.BytesIO()
    params = {'track_id':1,'fourcc':'ABCD','duration':1234,'timescale':1,'language':'en-US','codec_private_data':'123'}
    write_piff_header(o, params)
    assert(True)



# Generated at 2022-06-12 17:05:16.158419
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # TODO: Implement this unit test
    print("Not implemented")

# Generated at 2022-06-12 17:05:21.622025
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = "http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-and-onDemand/mp4-live.mpd"
    ismFD = IsmFD(url, {}, {}, {})
    assert ismFD.FD_NAME == 'ism'



# Generated at 2022-06-12 17:05:29.008014
# Unit test for function write_piff_header
def test_write_piff_header():
    fp = io.BytesIO()
    params = {'fourcc': 'H264', 'track_id': 0, 'width': 1280, 'height': 720, 'timescale': 10000000, 'duration': 40000000}

# Generated at 2022-06-12 17:05:31.535944
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pass


# M3u8FD = IsmFD, fragment_duration = 10000



# Generated at 2022-06-12 17:05:42.319176
# Unit test for constructor of class IsmFD
def test_IsmFD():
    test_dict1 = {'fragments': [{'url': 'http://a.com/1.ism/QualityLevels(2)/Fragments(video=1)'}, {'url': 'http://a.com/1.ism/QualityLevels(2)/Fragments(video=2)'}], 'f4m_formats': [{'manifest': 'http://a.com/1.ism', 'protocol': 'ism', 'resolution': '640x360', 'format_id': 'q02'}]}

# Generated at 2022-06-12 17:05:47.325153
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    config_file = os.path.join(os.path.dirname(__file__), 'test_data', 'config.json')
    params = json.load(open(config_file))
    params['_download_params'] = json.loads(params['_download_params'])
    return IsmFD._download('test.ismv', params)


# Generated at 2022-06-12 17:05:57.431082
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .downloader import get_suitable_downloader
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .common import InfoExtractor
    from .compat import urlopen
    from collections import defaultdict
    from itertools import count
    from random import choice
    from sys import stderr
    from threading import Lock
    from time import sleep
    from urllib.error import URLError
    from .YoutubeDL import YoutubeDL

    # Extract streams from a real video
    def extract_streams(extractor, video_id):
        downloader = get_suitable_downloader(
            YoutubeDL({'quiet': True, 'skip_download': True}),
            {'url': 'http://example.com/' + video_id})
        ie = extractor.ie

# Generated at 2022-06-12 17:06:03.027425
# Unit test for method real_download of class IsmFD

# Generated at 2022-06-12 17:06:14.587717
# Unit test for function extract_box_data
def test_extract_box_data():
    assert extract_box_data(b'foob', (b'foob',)) == b''
    assert extract_box_data(b'abcdabcdabcdabcdabcdabcd', (b'abcd',)) == b'abcdabcdabcdabcdabcdabcd'
    assert extract_box_data(b'baxxbaxx', (b'baxx',)) == b''
    assert extract_box_data(b'baxxbaxxbaxxbaxx', (b'baxx', b'baxx')) == b'baxx'
    assert extract_box_data(b'foobfoob', (b'foob',)) == b''

# Generated at 2022-06-12 17:07:22.848804
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {}
    params['track_id'] = 1

# Generated at 2022-06-12 17:07:32.472586
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import io
    
    url = 'http://download.tsi.telecom-paristech.fr/gpac/dataset/dash/manifest-frag.mpd'
    params = {
        'format': 'ismv',
    }
    outtmpl = '1-test2.ismv'
    
    ismFD = IsmFD(url, params, outtmpl)
    
    # Test with empty filename
    filename = ''

# Generated at 2022-06-12 17:07:38.807619
# Unit test for function write_piff_header
def test_write_piff_header():
    stream = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 10000000,
        'timescale': 10000000,
        'language': 'und',
        'width': 1920,
        'height': 1080,
        'codec_private_data': '6764001f9fa30030300d903e9fa30030300d8c20001b72747265616d44726976726f2e6d7033',
        'nal_unit_length_field': 4
    }
    write_piff_header(stream, params)

# Generated at 2022-06-12 17:07:44.454035
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from ..downloader import FileDownloader
    from ..extractor import gen_extractors
    import tempfile
    import os
    import shutil

    # We need to set options to enable HLS downloading

# Generated at 2022-06-12 17:07:46.582346
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """ Test for constructor of class IsmFD
    """
    test_IsmFD = IsmFD({})
    assert isinstance(test_IsmFD, IsmFD) == True


# Generated at 2022-06-12 17:07:48.591908
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    unittest_IsmFD_real_download(IsmFD)

if __name__ == '__main__':
    test_IsmFD_real_download()

# Generated at 2022-06-12 17:07:55.560018
# Unit test for function write_piff_header
def test_write_piff_header():
    with io.BytesIO() as stream:
        duration = 8000
        params = {'track_id': 1, 'fourcc': 'H264', 'height': 240, 'width': 360, 'duration': duration, 'language': 'und', 'nal_unit_length_field': 4, 'codec_private_data': '3140312a00002e00', 'timescale': 10000000}
        write_piff_header(stream, params)
        stream.seek(0)

# Generated at 2022-06-12 17:08:04.628068
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:08:13.357112
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    import os
    params = {'track_id': 1, 'fourcc': 'AACL', 'duration': 1000, 'timescale': 10000000, 'language': 'und', 'height': 0, 'width': 0, 'is_audio': False, 'creation_time': 1000, 'modification_time': 2000, 'channels': 2, 'bits_per_sample': 16, 'sampling_rate': 90000}
    fd, name = tempfile.mkstemp(suffix='.mp4')
    os.close(fd)
    f = io.open(name, 'wb')
    write_piff_header(f, params)
    f.close()
    f = io.open(name, 'rb')
    header = f.read()
    f.close()

# Generated at 2022-06-12 17:08:23.403226
# Unit test for method real_download of class IsmFD