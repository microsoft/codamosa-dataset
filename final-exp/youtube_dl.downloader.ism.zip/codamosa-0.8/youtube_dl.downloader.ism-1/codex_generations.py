

# Generated at 2022-06-12 16:59:46.892533
# Unit test for function write_piff_header
def test_write_piff_header():
    params = dict(
        track_id=1,
        fourcc='H264',
        codec_private_data='0164001fffe1001867640029acd9405a33592000428018021fdaa0e4e1f2',
        width=854,
        height=480,
        sampling_rate=22050,
        channels=2,
        bits_per_sample=16,
        duration=4000,
        timescale=1000,
    )
    data = write_piff_header(io.BytesIO(), params)

# Generated at 2022-06-12 16:59:55.542202
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from .test_downloader import FakeYDL
    class IsmFDFake(IsmFD):
        def __init__(self, ydl):
            IsmFD.__init__(self, ydl)
            self.url = None
        def _download_fragment(self, ctx, url, info_dict):
            self.url = url
            return True, b''
    ydl = FakeYDL()
    ydl.params = {
        'skip_unavailable_fragments': True,
        'test': True,
        'outtmpl': '%(id)s.%(ext)s',
    }
    ydl.add_info_extractor(IsmIE('https://manifest.foo/Manifest'))

# Generated at 2022-06-12 17:00:03.866580
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()

# Generated at 2022-06-12 17:00:15.870531
# Unit test for constructor of class IsmFD
def test_IsmFD():
    filename = 'test.mp4'
    fragments = [
        dict(url='https://test.com/test.ism/Manifest?1'),
        dict(url='https://test.com/test.ism/Manifest?2'),
    ]
    params = {
        'fragments': fragments,
        'test': True,
        '_start_file': True,
    }
    info_dict = {
        'fragments': fragments,
        '_download_params': params,
    }

    fd = IsmFD(filename, params)

    assert(fd.name == filename)
    assert(fd.params == params)



# Generated at 2022-06-12 17:00:23.533054
# Unit test for function write_piff_header

# Generated at 2022-06-12 17:00:37.393983
# Unit test for function extract_box_data
def test_extract_box_data():
    from ..utils import encode_data_uri

# Generated at 2022-06-12 17:00:47.873983
# Unit test for function extract_box_data
def test_extract_box_data():
    # Test case 1
    expected_output = b'\x1f\x8b\x08\x00i\xb3\x9d\x4e\x00\x03\xcd\xcb\x2f\x4b\xcc\x4d\x51\x28\xcf\x2f\xca\x49\x51\x04\x00\xf2\x19\xb2\x12\x00\x00\x00'

# Generated at 2022-06-12 17:00:58.851454
# Unit test for function write_piff_header
def test_write_piff_header():
    io_stream = io.BytesIO()
    video_params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 1000,
        'timescale': 10000000,
        'height': 720,
        'width': 1280,
        'codec_private_data': '012a573f8b0d43d0a50b',
    }
    audio_params = {
        'track_id': 2,
        'fourcc': 'AAAC',
        'duration': 100,
        'timescale': 10000000,
        'sampling_rate': 16000,
        'channels': 2,
        'bits_per_sample': 16,
    }

    write_piff_header(io_stream, video_params)

# Generated at 2022-06-12 17:01:01.664238
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test_fragments import tfrag_write
    tfrag_write(write_piff_header)



# Generated at 2022-06-12 17:01:10.094314
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Test IsmFD.real_download by feeding it a sample fragment.
    # This test is a regression test. If it fails, then something
    # in the IsmFD.real_download method that calls the _download_fragment method
    # has changed and the test needs to be updated. 
    sample_fragment_url = 'https://video.twimg.com/ext_tw_video/1168667859618459648/pu/fragments/1162/mono.ism/fragment1162_0_0_96.aac'
    temp_file_path = mktemp()
    sample_fragment = compat_urllib_request.urlopen(sample_fragment_url).read()
    audio_codec_private_data = '1208'

# Generated at 2022-06-12 17:01:29.447830
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'quiet': True, 'ignoreerrors': True, 'skip_download': True, 'noplaylist': True})
    fd = IsmFD(ydl, {})
    fd.real_download('test',{'url':'https://secure.conviva.com/hls/manifest-h264.ism/manifest(format=m3u8-aapl-v3)'})


# Generated at 2022-06-12 17:01:37.350091
# Unit test for function write_piff_header
def test_write_piff_header():
    #
    # byte range: 0 - 8383
    #
    with io.open('tests/files/piff_header.ismv', 'rb') as fp:
        result = fp.read()
    assert(len(result) == 8384)
    stream_out = io.BytesIO()
    params = {
        'track_id': 1,
        'fourcc': 'H264',
        'duration': 300100,
        'timescale': 10000000,
        'language': 'und',
        'width': 1280,
        'height': 720,
        'codec_private_data': '0164001fffe100176764001facd9428f5f00d84300000030080000168e93672a88',
    }
    write_piff_header(stream_out, params)


# Generated at 2022-06-12 17:01:45.941850
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    # Initialization
    ydl = YoutubeDL(dict())
    downloader = IsmFD(ydl)
    ydl.params['quiet'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['simulate'] = True
    ydl.params['continuedl'] = True
    ydl.params['noprogress'] = True
    ydl.params['logger'] = YoutubeDLLogger()
    ydl.params['forcejson'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['test'] = True
    ydl.params['writedescription'] = False
    ydl.params['writeinfojson'] = False
    ydl.params['writethumbnail'] = False

# Generated at 2022-06-12 17:01:51.051146
# Unit test for constructor of class IsmFD
def test_IsmFD():
    class IsmFD(FragmentFD):
        def __init__(self, ydl, params):
            super(IsmFD, self).__init__(ydl, params)
    ydl = YoutubeDL()
    ydl.params = {'fragment_retries': 0}
    fd = IsmFD(ydl, ydl.params)
    assert fd.params == {'fragment_retries': 0}

# Generated at 2022-06-12 17:02:03.447187
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Assume 'test.ism' file exists
    # test.ism is the segment list of https://mediaplatstorage1.blob.core.windows.net/windowsmediacontent/silverlight/test.ism/manifest
    stream = IsmFD('test.ism', None)
    # Params populates the manifest url and other information

# Generated at 2022-06-12 17:02:15.026374
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    test_params = {
        'fragments': [{
            'url': 'https://url1.com',
            'duration': 10
        }],
        '_download_params': {
            'track_id': 1
        },
    }

    test_IsmFD = IsmFD()


# Generated at 2022-06-12 17:02:26.264898
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import test_fragment_fd
    from .mp4 import MP4FragmentFD
    class TestStream(object):
        def __init__(self):
            self.buf = io.BytesIO()
        def write(self, bytes):
            self.buf.write(bytes)
        def getvalue(self):
            return self.buf.getvalue()

    stream = TestStream()
    mp4 = MP4FragmentFD(test_fragment_fd)
    params = mp4.guess_params()
    write_piff_header(stream, params)
    stream.buf.seek(0)
    return stream.getvalue()


# Generated at 2022-06-12 17:02:38.589641
# Unit test for function extract_box_data
def test_extract_box_data():
    from .aes import aes_cbc_decrypt
    from .cipher_params import CipherParams, PiffParams
    from .mp4_crypto import extract_hex_from_base64
    from .piff import write_piff_header
    from .pssh import write_pssh_box
    from ..utils import (
        encode_base64,
        encode_hex,
        decode_hex,
        random_bytes,
    )

    encryption_key = random_bytes(16)
    iv = random_bytes(16)
    unencrypted_data = (u32.pack(8) + b'dinf' + u32.pack(8) + b'url ' + u8.pack(0) + u8.pack(1))
    cipher_params = CipherParams()
    cipher_params.key_

# Generated at 2022-06-12 17:02:51.336947
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:02:53.377052
# Unit test for constructor of class IsmFD
def test_IsmFD():
    fd = IsmFD('http://example.com/file.ism', {})
    assert fd.FD_NAME == 'ism'

# Generated at 2022-06-12 17:03:23.447130
# Unit test for function extract_box_data
def test_extract_box_data():
    data = u32.pack(0x74) + b'moov'
    data += u32.pack(0x1c) + b'mvhd'  # full box
    data += u8.pack(0) + u32.pack(0) + u64.pack(0x12345678) + u64.pack(0x87654321)
    data += u32.pack(0x24) + u64.pack(0x11223344) + u64.pack(0x55667788)
    data += u32.pack(0x10)
    data += u32.pack(0x40) + b'trak'  # box
    data += u32.pack(0x18) + b'mdia'
    data += u32.pack(0x1c) + b'mdhd'  #

# Generated at 2022-06-12 17:03:32.650006
# Unit test for constructor of class IsmFD
def test_IsmFD():
    ydl = YoutubeDL({'debug_printtraffic': True, 'skip_unavailable_fragments': True, 'quiet': True})
    ydl.add_info_extractor(IsmIE.ie_key())
    ydl.add_default_info_extractors()
    ydl.test_handle_fragment(
        'http://wams.edgesuite.net/media/MPTExpressionData02/Big%20Buck%20Bunny%20Trailer_1080p.ism/manifest',
        expected_status=250,
        expected_title='Big Buck Bunny Trailer'
    )

# Generated at 2022-06-12 17:03:43.256894
# Unit test for constructor of class IsmFD
def test_IsmFD():
    url = 'http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'
    ydl = YoutubeDL({'simulate': True})
    url_data = ydl.urlopen(url)
    ydl.prepare_filename(url_data)

    # Test case 1: simulate = False
    ydl = YoutubeDL({})
    url_data = ydl.urlopen(url)
    assert isinstance(ydl._test_get_fragmenter(url_data), IsmFD)

    # Test case 2: simulate = True
    ydl = YoutubeDL({'simulate': True})
    url_data = ydl.urlopen(url)

# Generated at 2022-06-12 17:03:44.427718
# Unit test for constructor of class IsmFD
def test_IsmFD():
    return IsmFD(params={})


# Generated at 2022-06-12 17:03:53.897853
# Unit test for function extract_box_data
def test_extract_box_data():
    test_avcc_data = b'\x00\x00\x00+\x61\x76\x63\x43\x00\x00\x00\x00\x01\x64\x00\x1e\xff\xe1\x00\x19\x67\x64\x00\x1e\xac\xd9\x40\xc0'
    assert u32.unpack(extract_box_data(test_avcc_data, (b'avcC',)))[0] == 1  # configuration version



# Generated at 2022-06-12 17:04:03.240477
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    print("Testing method real_download...")
    filepath = "/tmp/video.mpd"
    os.remove(filepath)
    ismfd = IsmFD()


# Generated at 2022-06-12 17:04:08.053051
# Unit test for function write_piff_header
def test_write_piff_header():
    from itertools import takewhile
    stream = io.BytesIO()

# Generated at 2022-06-12 17:04:14.496503
# Unit test for function write_piff_header
def test_write_piff_header():
    from .test import write_test_data_stream
    from .piff import read_piff_header

    stream = io.BytesIO()
    write_piff_header(stream, {'track_id': 1, 'fourcc': 'H264', 'sampling_rate': 44100, 'codec_private_data': '000000016742C00DDE91A0000000168CA0040080000003008000001C0'})
    stream.seek(0)
    assert read_piff_header(stream) == {'track_id': 1, 'fourcc': 'H264', 'sampling_rate': 0, 'codec_private_data': binascii.hexlify(b'000000016742C00DDE91A0000000168CA0040080000003008000001C0')}
    write_

# Generated at 2022-06-12 17:04:23.659450
# Unit test for constructor of class IsmFD
def test_IsmFD():
    # Test the default constructor of class IsmFD
    ismFD = IsmFD()
    assert(ismFD.FD_NAME == "ism")
    assert(ismFD.params == {})

    # Test the user-customized constructor of class IsmFD
    ismFD2 = IsmFD(params={'foo': 'bar'})
    assert(ismFD2.FD_NAME == "ism")
    assert(ismFD2.params == {'foo': 'bar'})

if __name__ == "__main__":
    test_IsmFD()

# Generated at 2022-06-12 17:04:31.652262
# Unit test for constructor of class IsmFD
def test_IsmFD():
    downloader = YoutubeDL()
    downloader.params['format'] = 'ism'
    downloader.params['url'] = 'http://www.videolean.com/video/course/lesson/id/1706/youtube-seo-best-practices/'
    downloader.params['outtmpl'] = '%(title)s-%(id)s.%(ext)s'
    downloader.params['test'] = True
    downloader.prepare_filename()
    fd = IsmFD(downloader, False)
    assert fd.params['format'] == 'ism'
    assert fd.params['url'] == 'http://www.videolean.com/video/course/lesson/id/1706/youtube-seo-best-practices/'
    assert fd.params['outtmpl']

# Generated at 2022-06-12 17:05:07.223278
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .smoothstreams import SmoothStreamsFD
    from .common import InfoExtractor

    fd = SmoothStreamsFD('http://www.smoothstreams.tv/premium.php?stream=ustvnow')
    original_fd_from_url = InfoExtractor._fd_from_url
    InfoExtractor._fd_from_url = lambda x, y: fd
    ie = InfoExtractor()

    ie.extract('http://www.smoothstreams.tv/premium.php?stream=ustvnow')
    InfoExtractor._fd_from_url = original_fd_from_url

# Generated at 2022-06-12 17:05:17.360913
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import sys
    import mock
    import tempfile
    import os
    import yaml
    import time
    import hashlib

    sys.modules['compat_urllib_error'] = mock.MagicMock()
    sys.modules['compat_urllib_request'] = mock.MagicMock()
    sys.modules['compat_urllib_request'].build_opener = mock.MagicMock()
    sys.modules['compat_urllib_request'].build_opener.return_value.open = mock.MagicMock()
    sys.modules['compat_urllib_parse'] = mock.MagicMock()
    sys.modules['compat_urllib_parse'].unquote = mock.MagicMock()
    sys.modules['compat_urllib_parse'].unquote

# Generated at 2022-06-12 17:05:26.818771
# Unit test for function write_piff_header
def test_write_piff_header():
    fourcc = 'H264'
    track_id = 1
    duration = 10000000
    sampling_rate = 48000
    channels = 2
    bits_per_sample = 16
    width = 640
    height = 480

# Generated at 2022-06-12 17:05:29.826943
# Unit test for constructor of class IsmFD
def test_IsmFD():
    """
    Constructor test
    """
    ytdl = YoutubeDL({})
    ytdl.add_info_extractor(IsmIE)
    ytdl.add_info_extractor(GenericIE)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:05:41.476072
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile
    with tempfile.TemporaryFile(mode='wb+') as f:
        params = {
            'track_id': 1,
            'fourcc': 'AACL',
            'duration': 500,
            'sampling_rate': 44100,
            'channels': 2,
            'bits_per_sample': 16,
        }
        write_piff_header(f, params)
        f.seek(0)

# Generated at 2022-06-12 17:05:44.310171
# Unit test for constructor of class IsmFD
def test_IsmFD():
    dl = IsmFD(None, None)
    print(dl.FD_NAME)


if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:05:56.425432
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'sampling_rate': 44100,
        'bits_per_sample': 16,
        'channels': 2,
        'duration': 3000,
        'timescale': 10000000,
        'language': 'und'
    }

    f = io.BytesIO()
    write_piff_header(f, params)


# Generated at 2022-06-12 17:06:04.137329
# Unit test for function write_piff_header
def test_write_piff_header():
    import tempfile

# Generated at 2022-06-12 17:06:12.428065
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import pytest

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError

    ydl = YoutubeDL()
    ydl.params['skip_unavailable_fragments'] = False
    #test
    with pytest.raises(DownloadError):
        ydl.download(['http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'])

    #test when skip_unavailable_fragments is True
    ydl = YoutubeDL()
    ydl.params['skip_unavailable_fragments'] = True
    ydl.download(['http://playready.directtaps.net/smoothstreaming/SSWSS720H264/SuperSpeedway_720.ism/Manifest'])

# Generated at 2022-06-12 17:06:24.855617
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    import System
    import Microsoft
    import clr
    clr.AddReference("System")
    clr.AddReference("Microsoft.VisualStudio.TestTools.UnitTesting")
    clr.AddReference("Scripting")
    clr.AddReference("Scripting.FileSystemObject")
    import Microsoft.VisualStudio.TestTools.UnitTesting
    import System
    import Scripting
    import Scripting.FileSystemObject

    class PyTest(unittest.TestCase):
        def test_IsmFD_real_download(self):
            # Input parameter(s):
            #   filename: (String)
            #   info_dict: (Dictionary)
            # Output parameter(s):
            #   None

            filename = 'a'
            info_dict = {'fragments': [{'url': 'b'}]}

           

# Generated at 2022-06-12 17:07:34.347723
# Unit test for function write_piff_header
def test_write_piff_header():
    f = io.BytesIO()
    params = {
        'track_id': 1,
        'duration': 10000,
        'sampling_rate': 44100,
        'channels': 2,
        'bits_per_sample': 16,
        'fourcc': 'AACL',
    }
    write_piff_header(f, params)
    with open('./tests/unit/data/piff_aacl_header_sample.mp4', 'rb') as g:
        sample_header = g.read()
    assert f.getvalue() == sample_header



# Generated at 2022-06-12 17:07:44.746378
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    #
    # Create an instance of IsmFD, call the method real_download with a set of parameters and check that no
    # exception is raised.
    """
        This method is used to test the real_download method of the IsmFD class.
    """
    from sys import argv
    import logging

    try:
        url = argv[1]
        params = {}
        if len(argv) > 2:
            params = eval(argv[2])
    except:
        logging.error("Usage: %s url [params]" % argv[0])
        return 2

    ydl = YoutubeDL(params)
    ie = IsmFD(ydl)
    info_dict = {}
    filename = ''
    ie.real_download(filename,info_dict)



# Generated at 2022-06-12 17:07:45.308611
# Unit test for constructor of class IsmFD
def test_IsmFD():
    pass


# Generated at 2022-06-12 17:07:52.815579
# Unit test for function extract_box_data

# Generated at 2022-06-12 17:07:54.249694
# Unit test for constructor of class IsmFD
def test_IsmFD():
    assert IsmFD.FD_NAME == 'ism'

if __name__ == '__main__':
    test_IsmFD()

# Generated at 2022-06-12 17:07:59.284943
# Unit test for function write_piff_header
def test_write_piff_header():
    params = {
        'track_id': 1,
        'fourcc': 'AACL',
        'duration': 0,
        'timescale': 10000000,
        'language': 'und',
        'height': 0,
        'width': 0,
        'channels': 2,
        'bits_per_sample': 16,
        'sampling_rate': 44100
    }
    with io.BytesIO() as stream:
        write_piff_header(stream, params)

        stream.seek(0)
        output = stream.read()

# Generated at 2022-06-12 17:08:08.506173
# Unit test for constructor of class IsmFD
def test_IsmFD():
    from .dash import DashFD
    from .ismd import IsmdFD
    from .m3u8 import M3u8FD


# Generated at 2022-06-12 17:08:12.874339
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    pers = Persistence(persistence_file)
    pers.load()
    ydl = YoutubeDL(pers.get_params())
    info_dict = dict(fragments=[
        {'url': 'test'},
        {'url': 'test'},
    ])
    ism = IsmFD(ydl, info_dict)
    # I don't know how to test it
    pass


# Generated at 2022-06-12 17:08:22.572139
# Unit test for function write_piff_header
def test_write_piff_header():
    # ftyp, moov
    fd = io.BytesIO()
    # dummy params
    params = {}
    params['fourcc'] = 'AVC1'
    params['track_id'] = 1
    params['duration'] = 10
    params['timescale'] = 10
    params['language'] = 'und'
    params['height'] = 10
    params['width'] = 10
    params['codec_private_data'] = '01234'
    write_piff_header(fd, params)

# Generated at 2022-06-12 17:08:34.386146
# Unit test for method real_download of class IsmFD
def test_IsmFD_real_download():
    extractor = GetFD('ism')