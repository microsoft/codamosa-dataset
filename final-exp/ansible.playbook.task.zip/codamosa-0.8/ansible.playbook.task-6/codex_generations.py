

# Generated at 2022-06-11 11:00:53.900895
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    a = Task()
    assert a.get_vars() == {}
    assert True

# Generated at 2022-06-11 11:01:04.170747
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    class MockTaskInclude(TaskInclude):
        def __init__(self, data):
            super(MockTaskInclude, self).__init__(data)
        def serialize(self):
            return "all.yml"
    class MockTask(Task):
        def __init__(self, data):
            super(MockTask, self).__init__(data)
    o = MockTaskInclude({})
    p = MockTask({})
    o.attach(p)
    print(o.get_first_parent_include())
    assert o.get_first_parent_include().serialize() == "all.yml"
    print("Test of method get_first_parent_include in class Task succeeded")

# Generated at 2022-06-11 11:01:05.975661
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.preprocess_data(dict(action='test'))

# Generated at 2022-06-11 11:01:17.580227
# Unit test for method get_name of class Task
def test_Task_get_name():
    a = Task()
    # Test case 1:
    # If a._role is not None, then we want to return the name of the role
    a._role = "localhost"
    assert a.get_name() == "localhost"

    # Test case 2:
    # If the action exists in a._attributes, then we want to return the name of the action
    a._attributes = {"action": "copy"}
    assert a.get_name() == "copy"

    # Test case 3:
    # If the task has a parent, then we want to return the name of the parent's action
    b = Task()
    b._attributes = {"action": "test"}
    a._attributes = {}
    a._parent = b
    assert a.get_name() == "test"

    # Test case 4:
    # If a

# Generated at 2022-06-11 11:01:28.141818
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task.register_as_var = True
    task.action = 'shell'
    task.args = {'free_form': 'ls'}
    task.name = "shell"
    assert task.get_name() == "shell"
    task.register_as_var = False
    assert task.get_name() == "shell"
    task.register_as_var = True
    task.name = ''
    assert task.get_name() == '<ansible.builtin.shell>"ls"'
    task.name = 'ls'
    assert task.get_name() == 'ls'
    task.name = '<ansible.builtin.shell>ls'
    assert task.get_name() == '<ansible.builtin.shell>ls'


# Generated at 2022-06-11 11:01:30.962136
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    Test_Task = Task
    Test_Task._finalized = Test_Task._squashed = False

    Test_Task.deserialize(dict())

    assert Test_Task._role is None


# Generated at 2022-06-11 11:01:32.389265
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    t = Task()
    t.preprocess_data(None)


# Generated at 2022-06-11 11:01:33.088347
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    pass

# Generated at 2022-06-11 11:01:45.896403
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create an empty object Task to test it
    task = Task()

    # Create an object Task with data to test it
    data = '''
- name: Create new file
  command: touch /home/username/newfile.txt
'''
    task_data = '''
---
- name: Create new file
  command: touch /home/username/newfile.txt
'''

# Generated at 2022-06-11 11:01:55.242605
# Unit test for method get_name of class Task
def test_Task_get_name():
    
    run_unit_test(Task, 'get_name', {'name': 'value'}, expected_result="value")
    run_unit_test(Task, 'get_name', {'name': 'test'}, expected_result="test")
    run_unit_test(Task, 'get_name', {'comment': 'this is a test'}, expected_result="COMMENT")
    run_unit_test(Task, 'get_name', {'tags': 'include_role'}, expected_result="include_role")
    run_unit_test(Task, 'get_name', {'name': 'MY_TASK_NAME'}, expected_result="MY_TASK_NAME")

# Generated at 2022-06-11 11:02:20.810329
# Unit test for method __repr__ of class Task
def test_Task___repr__():
   task1 = Task("test_Task___repr__",'shell','echo hello',True,dict(),True,True,True,None)
   
   assert repr(task1) == """<Task: name: None action: shell loop: None when: True async_val: None async_poll: None vars: {} tags: True create_tmp: True ignore_errors: True rescue: [] always: [] delegate_to: None
   
values: {}>
"""

# Generated at 2022-06-11 11:02:22.277903
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    r = Role()
    assert r.post_validate() == None


# Generated at 2022-06-11 11:02:33.925742
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    C.INVALID_TASK_ATTRIBUTE_FAILED=False
    t = Task()
    t.vars['a'] = 1
    t._parent = Mock()
    t._parent.get_include_params.side_effect = lambda: {'b': 2}
    assert t.get_include_params() == {'a': 1, 'b': 2}
    t._parent.get_include_params.assert_called_once()
    assert not t._parent.get_vars.called
    assert not t._parent.get_vars.called

    C.INVALID_TASK_ATTRIBUTE_FAILED=True
    t = Task()
    t.vars['a'] = 1
    t._parent = Mock()
    t._parent.get_include_params.side

# Generated at 2022-06-11 11:02:37.050626
# Unit test for method get_name of class Task
def test_Task_get_name():
    ds = {'name': "TEST-1TASK"}
    task = Task(ds)
    assert task.get_name() == "TEST-1TASK"
    return task


# Generated at 2022-06-11 11:02:44.378700
# Unit test for method post_validate of class Task

# Generated at 2022-06-11 11:02:55.729101
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
        class ModuleSpec(object):
            def __init__(self, name, argument_spec, supports_check_mode=False, bypass_checks=False, no_log=False,
                         check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                         required_one_of=None, add_file_common_args=False, supports_diff=True, required_if=None,
                         required_by=None):
                self.name = name
                self.supports_check_mode = supports_check_mode
                self.check_invalid_arguments = check_invalid_arguments
                self.bypass_checks = bypass_checks
                self.argument_spec = argument_spec
                self.mutually_exclusive = mutually_exclusive
                self.required_together = required_together
                self.required

# Generated at 2022-06-11 11:02:59.725153
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    """ Test for Task : __repr__ """
    _test_task___repr__(passed_path='/opt/ansible/lib/ansible/playbook/block.py')

# Generated at 2022-06-11 11:03:09.256534
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Task(loop='{{ foo }}') # would cause exception, see fixed method
    # Task.__repr__() # missing 1 required positional argument: 'action'
    # Task('shell', '{{ host }}', args={'_uses_shell': 'true', 'chdir': '/tmp'}, loop='{{ foo }}') #
    task = Task('shell', '{{ host }}', args={'_uses_shell': 'true', 'chdir': '/tmp'})
    task.post_validate(templar=None)
    expected_result = "Task({'action': 'shell', 'args': {'_uses_shell': 'true', 'chdir': '/tmp', '_raw_params': '{{ host }}'}})"
    assert task.__repr__() == expected_result
    # Task(action='shell', args={'chdir

# Generated at 2022-06-11 11:03:19.940691
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a new task for unit test
    task = Task()
    # Create a new inventory for unit test
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[])
    # Define a test data set
    test_data = '''
    - block:
        - local_action:
            module: debug
            msg: "Test"
    '''
    task.load(test_data, template=None, owner=None, task_uuid='123')
    task.post_validate(is_delegated_vars=False, loader=DataLoader())

# Generated at 2022-06-11 11:03:30.943337
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Create instance of class with task definition.
    task = Task({'action': 'command', 'args': {'_raw_params': 'echo hi'}})
    # The preprocess_data method should take in account the action field
    # and the args._raw_params field.
    try:
        task.preprocess_data()
    except:
        pass

    # If args._raw_params is not of type string then the code should raise an error
    # Create instance of class with task definition.
    task = Task({'action': 'command', 'args': {'_raw_params': {'echo hi': 10}}})
    # The preprocess_data should raise an error as the args._raw_params is not a string.
    failed = False
    try:
        task.preprocess_data()
    except:
        failed = True

# Generated at 2022-06-11 11:04:07.164862
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude

    task = Task()
    assert task.get_vars() == dict()

    task = Task(vars=dict(var1='value1'))
    assert task.get_vars() == dict(var1='value1')

    parent = Task(vars=dict(var1='parentValue1', var2='parentValue2'))

    task = Task(vars=dict(var1='value1'), _parent=parent)
    assert task.get_vars() == dict(var1='value1', var2='parentValue2')

    parent = Block(vars=dict(var1='parentValue1', var2='parentValue2'), _parent=parent)


# Generated at 2022-06-11 11:04:18.055321
# Unit test for method preprocess_data of class Task

# Generated at 2022-06-11 11:04:27.811217
# Unit test for method get_name of class Task
def test_Task_get_name():
    
    task = Task()

    name = task.name  # from Base
    assert name is None

    name = task.get_name()
    assert name == ''

    task._attributes['name'] = 'task-name'
    name = task.get_name()
    assert name == 'task-name'

    task._role = namedtuple('Role', ['name'])(name='role-name')
    name = task.get_name()
    assert name == 'role-name : task-name'

    task._parent = namedtuple('Parent', ['get_name'])(get_name=lambda: 'parent-name')
    name = task.get_name()
    assert name == 'parent-name : role-name : task-name'
test_Task_get_name()

# Generated at 2022-06-11 11:04:39.447726
# Unit test for method deserialize of class Task
def test_Task_deserialize():
  '''
  Unit test for method deserialize of class Task
  '''
  C.INVALID_TASK_ATTRIBUTE_FAILED = False
  task_name = 'Test task_name'
  block_name = 'Test block_name'
  implicit = 'False'
  resolved_action = 'The action to be resolved'
  task = Task()
  data = {'task_name':task_name,'block_name':block_name,'action':'command','implicit':implicit,'resolved_action':resolved_action}
  task.deserialize(data)
  assert task.task_name == task_name
  assert task.block_name == block_name
  assert task.action == 'command'
  assert task.implicit == implicit
  assert task.resolved_action == resolved_

# Generated at 2022-06-11 11:04:45.314261
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    data = {"action": "command", "args": {"_raw_params": "echo", "chdir": "/tmp"}, "register": "result"}
    t = Task.load(data)
    assert str(t) == "command | echo | chdir=/tmp"
    t.name = "Test"
    assert str(t) == "Test"


# Generated at 2022-06-11 11:04:53.540518
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    import copy
    import sys
    import os
    import pytest
    # Data to be used in these unit tests. Can be modified by test author if needed.
    raw_data = {}
    raw_data['action'] = 'ansible.builtin.command'
    raw_data['args'] = {}
    raw_data['args']['_raw_params'] = 'echo "foo bar"'
    raw_data['args']['chdir'] = '~'
    raw_data['delegate_to'] = 'localhost'
    raw_data['ignore_errors'] = 'yes'
    raw_data['loop'] = '{{ item }}'
    raw_data['loop_control'] = {'loop_var': 'item'}
    raw_data['name'] = 'foo'
    raw_data['register'] = 'result'

# Generated at 2022-06-11 11:04:58.649921
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Tests that Task.post_validate() raises an error when the input is invalid.
    # Args:
    #    first_arg - The first argument.
    #    second_arg - The second argument.
    #    third_arg - The third argument.
    my_task = Task()
    my_task.post_validate()


# Generated at 2022-06-11 11:05:09.283978
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    class AnsibleUndefinedVariable(Exception):
        pass
    class AnsibleParserError(Exception):
        pass
    class AnsibleError(Exception):
        pass
    class AnsibleCollectionConfig(object):
        pass
    class AnsibleTask(object):
        pass
    class AnsibleModule(object):
        pass
    class AnsibleRunner(object):
        pass
    class AnsibleInventory(object):
        pass
    class AnsiblePlugin(object):
        pass
    class AnsiblePlay(object):
        pass
    class AnsiblePlaybook(object):
        pass
    class AnsibleFile(object):
        pass
    class AnsibleConnection(object):
        pass
    class AnsibleTemplate(object):
        pass
    class AnsibleVault(object):
        pass
    class AnsibleCache(object):
        pass


# Generated at 2022-06-11 11:05:11.949124
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    ds = dict()
    result = task.preprocess_data(ds)
    assert len(result) >= 1


# Generated at 2022-06-11 11:05:21.813433
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop1
    from units.mock.collections import MockAnsibleCollection

    # Helper function used to generate `args` dictionary
    # to check against.
    #
    # `args` dict has the following structure:
    # {
    #     '_raw_params': '{{test_var}}',
    #     'test_var': 'test',
    # }
    def make_test_args(test_var):
        return dict(
            _raw_params='{{test_var}}',
            test_var=test_var,
        )

    # Helper function used to generate a `data` dictionary


# Generated at 2022-06-11 11:06:05.778815
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_include = TaskInclude()

    task_include.deserialize({u'action': u'include', u'args': {u'_raw_params': u'common_tasks', u'_uses_delegate_to': False, u'_uses_become': False, u'_uses_async': False, u'free-form': u'common_tasks'}, u'name': u'Include common tasks', u'loop': {}, u'delegate_to': u'', u'register': u'', u'loop_control': {}, u'when': u'', u'changed_when': u'', u'ignore_errors': False})

    task = Task()


# Generated at 2022-06-11 11:06:08.000650
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # the method post_validate  of class Task is not callable
    pass

# Generated at 2022-06-11 11:06:09.145155
# Unit test for method deserialize of class Task
def test_Task_deserialize():
  pass


# Generated at 2022-06-11 11:06:20.571374
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    data = {}
    assert Task().preprocess_data(data) == {}
    # Test data['action']
    data = {'action': 'ping'}
    assert Task().preprocess_data(data) == {'action': 'ping'}
    # Test data['local_action']
    data = {'local_action': 'ping'}
    assert Task().preprocess_data(data) == {'action': 'ping'}
    # Test data['action'] and data['local_action'] at the same time
    data = {'action': 'ping', 'local_action': 'ping'}
    assert Task().preprocess_data(data) == {'action': 'ping'}
    # Test data['args']
    data = {'args': {}}

# Generated at 2022-06-11 11:06:31.191022
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = AnsibleLoader(cs)
    t1 = Task()
    t1._loader = loader
    t1.role = Role()
    t1.role.name = "foo"
    t1.role._role_path = os.path.join(os.path.dirname(__file__), "data/roles/role_v2")
    t1.role.collection = None
    t1._variable_manager = VariableManager()
    t1.action = "shell"
    t1.args = dict(free_form='echo test')
    t1.tags = ['foo', 'bar']

# Generated at 2022-06-11 11:06:34.030080
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    ####Prepare test data
    ####Create test object
    test_obj = Task
    ####Run test
    ret = test_obj.get_first_parent_include()
    ####Check result
    assert ret is None

# Generated at 2022-06-11 11:06:40.588828
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    a = AnsibleOptions(connection='local', module_path=None, forks=100, become=None, become_method=None, become_user=None, check=False, diff=False)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    t = Task()
    t.post_validate()



# Generated at 2022-06-11 11:06:51.382291
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # FIXME: use pytest
    fake_loader = DictDataLoader({})
    fake_inventories = MagicMock()
    variable_manager = VariableManager(loader=fake_loader, inventories=fake_inventories)
    t = Task()
    t._variable_manager = variable_manager

    t.vars = {'var1': 'value1', 'var2': 'value2'}

    p = Play()
    p.vars = {'play_var1': 'play_value1'}

    t._parent = p
    res = t.get_vars()
    assert res == {'play_var1': 'play_value1', 'var1': 'value1', 'var2': 'value2'}


# Generated at 2022-06-11 11:06:54.998195
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    """
    # Task.__repr__
    >>> t=Task()
    >>> print (t)
    None
    >>> t.action = "shell"
    >>> print (t)
    shell
    """


# Generated at 2022-06-11 11:07:01.525468
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    _play = Play()
    _tqm = None
    _loader = DataLoader()
    _variable_manager = VariableManager()
    _block = Block()
    _task = Task()
    _block.block  = [_task] 
    _task.args = None
    _task.action = 'debug'
    _task.async_val = 0
    _task.async_poll_interval = 1
    _task.post_validate(None)



# Generated at 2022-06-11 11:08:49.182158
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    """Unit test for method preprocess_data of class Task:

        The reason to test this method is that it deals with complex
        data structures and needs to be correct for correct working
        of the rest of Ansible.
    """

# Generated at 2022-06-11 11:08:56.075098
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    vars = VariableManager()
    play_context = PlayContext()
    templar = Templar(vars, play_context)

    # Test with correct arguments
    play = Play()
    parent_block = Block()
    parent_block._role = None
    parent_block.statically_loaded = False
    parent_block._parent = None
    parent_block._play = play
    parent_block._loader = None
    parent_block.post

# Generated at 2022-06-11 11:09:07.857729
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    def _mock_init(self, **_):
        self._loader = None
        self._variable_manager = None
        self._block = None
        self._play = None
        self._role = None
        self._task_include = None
        self._handler = None
        self._loop = None
        self._dep_chain = None
        self._role_name = None
        self._finalized = False
        self._squashed = False
        self._use_role = None
        self._is_import_playbook = False
        self._is_import_role = False
        self._vars_prompt = None
       

# Generated at 2022-06-11 11:09:17.344294
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # create a playbook object
    playbook = Playbook()
    # create a task object
    task = Task()
    playbook.tasks = [task]

    # create a block object
    block = Block()
    block.statically_loaded = True
    task._parent = block
    assert not task.get_first_parent_include()

    # create a parent task object
    parent_task = Task()
    block.block = [parent_task]

    # create a task_include object
    task_include = TaskInclude()
    parent_task._parent = task_include
    assert task.get_first_parent_include()

    # create a handler_task_include object
    handler_task_include = HandlerTaskInclude()
    parent_task._parent = handler_task_include
    assert task.get_first_parent_include

# Generated at 2022-06-11 11:09:17.998547
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    pass

# Generated at 2022-06-11 11:09:24.823447
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    tk = Task()
    tk.deserialize({'vars': {'a': 1}, 'name': 'a', 'args': {'1': '1'}, 'action': 'shell', 'when': '1'})
    assert tk.vars == {'a': 1}
    assert tk.name == 'a'
    assert tk.args == {'1': '1'}
    assert tk.action == 'shell'
    assert tk.when == '1'

# Generated at 2022-06-11 11:09:35.147406
# Unit test for method preprocess_data of class Task

# Generated at 2022-06-11 11:09:45.531533
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Create test object
    task = Task()
    # Create mock of class AttributeLoader

# Generated at 2022-06-11 11:09:47.748038
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    assert(task.deserialize({'name': 'test'}) == None)


# Generated at 2022-06-11 11:09:59.221272
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    m = ModuleLoader()
    ds = yaml.safe_load('''---
- hosts: 127.0.0.1
  gather_facts: False
  tasks:
    - shell: 'echo 1'
      register: results
    - shell: 'echo 2'
      when: "'2' in results.stdout"
      register: results
''')
    pb = Playbook.load(ds, variable_manager=VariableManager(), loader=m)
    # pprint.pprint(pb.serialize())

    t = pb.get_tasks()[0]
    t._validate_attributes()
    t._post_validate(Templar(loader=DictDataLoader()))

    t.register = 'results' # for debug

    assert t.when == "'2' in results.stdout"
