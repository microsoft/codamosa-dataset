

# Generated at 2022-06-25 06:16:31.164899
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    task = Task()
    role = Role()
    role.name = "test_name"
    role.port = 80
    task.role = role
    task.action = "test_action"
    task.args = {'test': 'test'}
    task.delegate_to = "test_delegate_to"
    task.run_once = True
    task.ignore_errors = True
    task.async_val = "test_async_val"
    task.poll = 10
    task.free_form = "test_free_form"
    task.tags = ["tag"]
    task.when = ["when"]
    task._squashed = True
    task._finalized = True

    result = task.serialize()
    task = Task()
    task.deserialize(result)

# Generated at 2022-06-25 06:16:39.614039
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_data = {}
    task_data['parent'] = {}
    task_data['parent']['name'] = "test_parent_name"
    task_data['parent']['parent'] = {}
    task_data['parent']['parent']['name'] = "test_parent_parent_name"
    task_data['parent']['statically_loaded'] = True
    task_data['parent_type'] = 'Block'
    task_data['role'] = {}
    task_data['role']['name'] = "test_role_name"

# Generated at 2022-06-25 06:16:44.738742
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    # set the instance variable loader to None
    task_0._loader = None
    task_0_data = {}
    task_0_expected_return = None
    task_0_actual_return = task_0.deserialize(task_0_data)
    assert task_0_actual_return == task_0_expected_return
    task_0_expected_data = {}
    task_0_actual_data = task_0.serialize()  # serialize the deserialized data
    assert task_0_actual_data == task_0_expected_data


# Generated at 2022-06-25 06:16:47.992530
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

    try:
        task_0.deserialize('ecKjO7ZhuRfR')
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 06:16:49.550709
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data_0 = {}
    task_0.deserialize(data_0)



# Generated at 2022-06-25 06:16:59.934642
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.template import Templar
    _loader = DataLoader()
    _variable_manager = VariableManager()
    _variable_manager.set_inventory(Inventory(_loader, [host_0,host_1]))

# Generated at 2022-06-25 06:17:09.509089
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task(args_parser='ModuleArgsParser')
    dict_0 = dict()
    dict_0['tags'] = 'tag'
    dict_0['local_action'] = 'action'
    dict_0['delegate_to'] = 'delegate_to'
    dict_0['args'] = 'args'
    dict_0['action'] = 'action'
    dict_0['vars'] = 'vars'
    str_0 = task_0.preprocess_data(dict_0)
    return str_0


# Generated at 2022-06-25 06:17:13.358195
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data_0 = dict()
    task_0.deserialize(data_0)


# Generated at 2022-06-25 06:17:16.458217
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    return_value = task_0.get_include_params()
    assert type(return_value) == dict
    

# Generated at 2022-06-25 06:17:18.952393
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    test_0 = Task()
    try:
        test_0.post_validate()
    except:
        pass
    except Exception:
        pass



# Generated at 2022-06-25 06:17:34.277303
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task(var_0)
    task_0._post_validate_vars(attr=None, value=None, templar=None)


# Generated at 2022-06-25 06:17:36.355676
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_0 = {}
    task_0 = Task()
    task_0.preprocess_data(var_0)


# Generated at 2022-06-25 06:17:39.634092
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Setup
    var_0 = {}
    var_0 = Task()

    # Test
    var_0.deserialize(var_0)


# Generated at 2022-06-25 06:17:45.197625
# Unit test for method serialize of class Task
def test_Task_serialize():
    var_1 = {}
    var_2 = Task(None, None, None, None)
    var_2.deserialize(var_1)
    var_3 = var_2.serialize()
    assert var_3 == var_1

# Generated at 2022-06-25 06:17:48.032265
# Unit test for method serialize of class Task
def test_Task_serialize():
    var_0 = Task(loader=None, variable_manager=None, use_handlers=True, play=None, parent=None, role=None, task_tags=None, role_name=None, implicit=False, task_dep=None, role_dep=None)
    print(var_0.serialize())


# Generated at 2022-06-25 06:17:50.286188
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    print("Test: Method deserialize of class Task")
    var_0 = {}
    res_0 = var_0
    assert res_0 == "undefined"

# Generated at 2022-06-25 06:17:51.943726
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_1 = ModuleArgsParser(var_0).parse()
    return var_1


# Generated at 2022-06-25 06:17:54.555767
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    var = Task()
    var.post_validate(var)
    var._validate_attributes(var_0)
    var.serialize()
    var.deserialize(var)
    var.set_loader(var)
    var._get_parent_attribute(var)
    var.all_parents_static()
    var.get_first_parent_include()

# Generated at 2022-06-25 06:17:55.287757
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    var_0 = {}


# Generated at 2022-06-25 06:17:56.427719
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_task = Task()
    var_task.preprocess_data()

# Generated at 2022-06-25 06:18:20.936766
# Unit test for method get_first_parent_include of class Task

# Generated at 2022-06-25 06:18:30.920455
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    print('Testing Task __repr__ method')
    var_0 = {}
    var_1 = {}
    var_1['action'] = 'ping'
    var_2 = {}
    var_2['meta'] = var_1
    var_3 = Task()
    var_4 = var_3.preprocess_data(var_0)
    var_5 = var_3.post_validate(var_4)
    var_6 = var_3.serialize()
    var_7 = Task()
    var_7.deserialize(var_6)
    var_8 = var_7.post_validate(var_5)
    var_9 = var_7.serialize()
    var_10 = var_7.__repr__()
    var_11 = {}

# Generated at 2022-06-25 06:18:32.844244
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_task = Task(data=var_0)
    var_task.preprocess_data()

if __name__=="__main__":
    test_case_0()

# Generated at 2022-06-25 06:18:33.501818
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    var_0 = {}


# Generated at 2022-06-25 06:18:34.508728
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    with pytest.raises(Exception):
        test_case_0()



# Generated at 2022-06-25 06:18:38.075695
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_0 = Task()
    var_1 = Task()
    var_2 = {}
    var_1.preprocess_data(var_2)
    var_0.preprocess_data(var_2)


# Generated at 2022-06-25 06:18:41.515063
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Instantiate an instance of the 'Task' class
    task = Task()
    # Calls preprocess_data and returns the result
    result = task.preprocess_data()
    # Test fails as result does not match expected
    assert result == (None), "Expected {}, but got {}".format(None, result)


# Generated at 2022-06-25 06:18:42.962737
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    var_1 = {}


# Generated at 2022-06-25 06:18:44.996185
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    global var_0
    var_0 = {}
    task_0 = Task()
    var_0 = task_0.get_vars()
    assert var_0 == {}
    print('Test get_vars finished.')


# Generated at 2022-06-25 06:18:48.149052
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_0 = Task()
    test_0.deserialize('')


# Generated at 2022-06-25 06:19:04.238243
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    var_0 = {}
    x = Task()
    x.deserialize(var_0)


# Generated at 2022-06-25 06:19:15.609465
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    test_0 = Task()
    test_1 = Task()
    test_2 = Task()
    test_3 = Task()
    test_4 = Task()
    test_5 = Task()
    test_6 = Task()
    test_7 = Task()
    test_8 = Task()
    test_9 = Task()
    test_10 = Task()
    test_11 = Task()
    test_12 = Task()
    test_13 = Task()
    test_14 = Task()
    test_15 = Task()
    test_16 = Task()
    test_17 = Task()
    test_18 = Task()
    test_19 = Task()
    test_20 = Task()
    test_21 = Task()
    test_22 = Task()
    test_23 = Task()
    test_24 = Task()

# Generated at 2022-06-25 06:19:16.763544
# Unit test for method __repr__ of class Task
def test_Task___repr__():

    print(Task(var_0))


# Generated at 2022-06-25 06:19:18.911871
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    t = Task()
    t.deserialize({})


# Generated at 2022-06-25 06:19:29.612242
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    var_1 = {}
    var_1['action'] = "asdf"
    var_1['args'] = {}
    var_1['delegate_to'] = "asdf"
    var_1['environment'] = "asdf"
    var_1['ignore_errors'] = False
    var_1['when'] = "asdf"
    var_1['register'] = "asdf"
    var_1['run_once'] = False
    var_1['any_errors_fatal'] = False
    var_1['changed_when'] = "asdf"
    var_1['loop'] = "asdf"
    var_1['loop_control'] = {}
    var_1['raw'] = "asdf"
    var_1['failed_when'] = "asdf"
    var_1['until']

# Generated at 2022-06-25 06:19:31.337814
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    var_11 = Task()
    var_11.deserialize(var_0)


# Generated at 2022-06-25 06:19:33.752404
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # var_0 = {}
    # task_0 = Task()
    # result = task_0.get_vars()
    # assert result == var_0
    pass


# Generated at 2022-06-25 06:19:35.345554
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    var_0 = Task()
    input = {}
    var_0.deserialize(input)


# Generated at 2022-06-25 06:19:45.436744
# Unit test for method __repr__ of class Task

# Generated at 2022-06-25 06:19:50.355617
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    myhost = {}

    task = Task(play=None, ds={}, role=None, task_vars={'hostvars': {'myhost': {}}}, loader=None, variable_manager=None)
    task.preprocess_data(myhost)



# Generated at 2022-06-25 06:20:15.224478
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    data = {
        '_uuid': '76d5f3a3-cab5-4998-9d85-2ad9f4f4cd96',
        '_lineage': '76d5f3a3-cab5-4998-9d85-2ad9f4f4cd96',
        'action': 'command'
    }

    task = Task()
    task.deserialize(data)

# Generated at 2022-06-25 06:20:19.078036
# Unit test for method serialize of class Task
def test_Task_serialize():
    for task,expected_result in task_serialize.items():
        output = task.serialize()
        assert expected_result == output
        test_case_0()


# Generated at 2022-06-25 06:20:21.879091
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data = {'vars': []}
    task_0.deserialize(data)


# Generated at 2022-06-25 06:20:25.104978
# Unit test for method get_name of class Task
def test_Task_get_name():
    # Create object
    test_case_0()

    # Call method and test
    assert task_0.get_name() == 'meta'



# Generated at 2022-06-25 06:20:27.194348
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    # str(task)
    task.__repr__()
    assert True


# Generated at 2022-06-25 06:20:28.440840
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    print(task_0)


# Generated at 2022-06-25 06:20:36.305479
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    # This test fails on error: 't' has no attribute '_parent'
    # (FIXME: Problem with mocking Task)
    # (FIXME: Bug or Feature: 't' has no attribute '_parent' fails)
    # (FIXME: Bug or Feature: Task.__init__() fails)
    t = Task()
    Task_get_first_parent_include = t.get_first_parent_include()
    assert Task_get_first_parent_include is None


# Generated at 2022-06-25 06:20:44.662986
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    task_1 = Task()
    task_1._attributes['action'] = 'test'
    task_1._attributes['args'] = {'key1': 'value1', 'key2': 'value2'}
    task_1._attributes['delegate_to'] = 'localhost'

    new_ds = task_1.preprocess_data({})
    assert new_ds['action'] == 'test'
    assert len(new_ds['args'].keys()) == 2
    assert new_ds['delegate_to'] == 'localhost'



# Generated at 2022-06-25 06:20:52.619245
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_obj = Task()
    task_obj.action = "include_tasks"
    vars = {'var1' : 'value1', 'var2' : 'value2'}
    task_obj.vars = vars
    task_obj.get_include_params()
    assert task_obj.vars == vars
    task_obj.action = "block"
    vars = {}
    task_obj.get_include_params()
    assert task_obj.vars == {}


# Generated at 2022-06-25 06:20:55.700855
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task(action='setup', name='Gather facts', ignore_errors=False, register='setup_facts', until='setup_done')
    assert task_1.__repr__() == u'<Task name:Gather facts>'


# Generated at 2022-06-25 06:21:12.305568
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.vars = dict(foo="bar")
    task.post_validate(None)


# Generated at 2022-06-25 06:21:19.001802
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    def test_Task_preprocess_data_cases_0():
        task_preprocess_0 = Task()
        task_preprocess_1 = {'register': 'shell_0', 'with_items': [{'item_0': 'item_1'}, {'item_2': 'item_3'}, {'item_4': 'item_5'}], 'connect_timeout': 5, 'loop_control': {'loop_var': 'item_0'}, 'action': 'shell', '_ansible_no_log': False, 'remote_user': 'root', '_ansible_verbosity': 3, '_ansible_non_local': False, '_ansible_debug': False}

# Generated at 2022-06-25 06:21:30.017201
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    t = Task()
    assert t._attributes['any_errors_fatal'] == C.DEFAULT_ANY_ERRORS_FATAL
    assert t._attributes['changed_when'] == C.DEFAULT_TASK_CHANGED_WHEN
    assert t._attributes['ignore_errors'] == C.DEFAULT_TASK_IGNORE_ERRORS
    assert t._attributes['register'] == C.DEFAULT_TASK_REGISTER
    assert t._attributes['retries'] == C.DEFAULT_TASK_RETRIES
    assert t._attributes['until'] == C.DEFAULT_TASK_UNTIL
    assert t._attributes['retry_files'] == C.DEFAULT_TASK_RETRY_FILES
    assert t._attributes['force_handlers']

# Generated at 2022-06-25 06:21:31.403765
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    assert test_Task_preprocess_data.__doc__ is not None


# Generated at 2022-06-25 06:21:43.601883
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    from units.mock.loader import DictDataLoader
    from units.mock.loader import DictDataLoader
    from units.mock.path import MockPath
    from units.mock.vault import MockVaultSecret
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    #from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({
        "test_task.yml": """
        - hosts: all
          tasks:
            - name: test
              debug:
                var: test1
        """
    })

    #invent = InventoryManager(loader=loader, sources=["test_invent.yml"])
    varman = VariableManager()
    # varman.set_inventory(invent)


# Generated at 2022-06-25 06:21:49.969570
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    # Setup
    task = Task()
    task.action = 'include'
    task.vars = {'foo': 'bar'}
    task_include = Task()
    task_include.action = 'include'
    task_include.vars = {'baz': 'bar'}
    task_include._parent = task
    task_include.all_parents_static = lambda : True

    # Expected result
    exp_result = {'baz': 'bar', 'foo': 'bar'}

    # Actual result
    result = task_include.get_include_params()

    # Assertions
    assert result == exp_result
    assert task_include.get_include_params() == exp_result

# Generated at 2022-06-25 06:21:54.860171
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_0.name = "test_playbook_task"
    print(task_0.get_name())



# Generated at 2022-06-25 06:21:58.510838
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Setup
    task_1 = Task()
    task_1.load({
		'action': 'Shell',
		'args' : {
			'run_command': 'echo hello world'
		}
    })

    # Assertion
    task_1.post_validate(templar=None)


# Generated at 2022-06-25 06:22:04.841092
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    def test_yaml_deserialize(test_file):
        fd = open(test_file, 'r')
        ds = yaml.load(fd.read())
        fd.close()

        for task_ds in ds:
            task = Task().deserialize(task_ds)

    test_yaml_deserialize('test/unit/module_utils/test_Task.yaml')


# Generated at 2022-06-25 06:22:06.390749
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    assert_equal(task_0.get_first_parent_include(), None)


# Generated at 2022-06-25 06:22:27.758561
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    assert task_0.get_vars() == {}


# Generated at 2022-06-25 06:22:31.009986
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    assert task_0.get_name() is None
    task_0._attributes['name'] = 'test name'
    assert task_0.get_name() == 'test name'



# Generated at 2022-06-25 06:22:42.574091
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    task_1.deserialize({'action': 'test.action'})
    assert task_1.action == 'test.action'

    task_2 = Task()
    task_2.deserialize({'action': 'test.action', 'parent': {'_attributes': {'name': 'block.name'}}})
    assert task_2.action == 'test.action'
    assert task_2.block.name == 'block.name'

    task_3 = Task()
    task_3.deserialize({'action': 'test.action', 'parent': {'_attributes': {'name': 'block.name'}, 'parent': {'_attributes': {'name': 'play.name'}}}})
    assert task_3.action == 'test.action'

# Generated at 2022-06-25 06:22:45.173389
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    """
    test the __repr__ method of the class Task
    """
    task_0 = Task()
    assert task_0.__repr__() is not None


# Generated at 2022-06-25 06:22:47.906367
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    vars_0 = task_0.get_include_params
    assert(vars_0 == {})
    print("Test case 0 passed")


# Generated at 2022-06-25 06:22:53.250068
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    task_0 = Task(loader=None, variable_manager=None, task_vars=dict())
    to_unicode = lambda x: to_text(x, errors='surrogate_then_replace')

    # Ansible version 2.9 case #
    from ansible.vars.hostvars import HostVars
    yaml__data_yaml_1 = '''
    - debug:
        msg: hello
      register: test
    - command: echo hi
      when: test.rc == 0
      tags:
      - always
      - block_0
    '''
    data_yaml_1 = yaml.safe_load(to_unicode(yaml__data_yaml_1))
    variable_manager__task_vars_1 = dict()

# Generated at 2022-06-25 06:22:57.252556
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # The object Task() is created to test the method get_vars()
    task_0 = Task()
    # The following call the method get_vars()
    resp = task_0.get_vars()
    # The result is assessed
    assert resp == {}



# Generated at 2022-06-25 06:23:03.606005
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    task_0 = Task()
    task_0.name = "task_name"
    task_0.action = "task_action"
    task_0.tags = ["tag_A", "tag_B"]
    task_0.when = "task_when"

    task_serialized = task_0.serialize()
    #print task_serialized

    task_1 = Task()
    task_1.deserialize(task_serialized)

    #Test for variable name
    assert task_0.name == task_1.name

    #Test for variable action
    assert task_0.action == task_1.action

    #Test for variable tags
    assert set(task_0.tags) == set(task_1.tags)

    #Test for variable when
    assert task_0.when == task_1.when

# Generated at 2022-06-25 06:23:13.754988
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.role = 'role_0'
    task_0.action = 'action_0'
    task_0.register = 'register_0'
    task_0.notify = 'notify_0'
    task_0.tags = 'tags_0'
    task_0.when = 'when_0'
    task_0.changed_when = 'changed_when_0'
    task_0.failed_when = 'failed_when_0'
    task_0.until = 'until_0'
    task_0._blocks = 'blocks_0'
    task_0.always_run = 'always_run_0'
    task_0.any_errors_fatal = 'any_errors_fatal_0'

# Generated at 2022-06-25 06:23:24.256615
# Unit test for method serialize of class Task
def test_Task_serialize():
    my_task = Task()
    my_task.name = "test"
    my_task.action = "test_action"
    my_task.when = "test_when"
    my_task.loop = "test_loop"
    my_task.async_val = 1
    my_task.poll = 0
    my_task.register="test_register"
    my_task.ignore_errors=True
    my_task.notify=["test_notify_1","test_notify_2"]
    my_task.tags=["test_tag_1","test_tag_2"]
    my_task.until=["test_until_1","test_until_2"]
    my_task.changed_when=["test_changedWhen_1","test_changedWhen_2"]
    my_task.failed

# Generated at 2022-06-25 06:23:46.037327
# Unit test for method deserialize of class Task

# Generated at 2022-06-25 06:23:51.453311
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task() # explicit creation of Task object
    task_0.preprocess_data({'action': 'ping', 'with_items': '{{ items }}'})

    task_1 = Task()
    task_1.preprocess_data({})

    task_2 = Task()
    task_2.preprocess_data({'action': 'ping', 'ignore_errors': True})


# Generated at 2022-06-25 06:23:55.172467
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_0.name = 'test name'
    assert task_0.get_name() == 'test name'


# Generated at 2022-06-25 06:24:01.712993
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    result = True
    task_0 = Task()
    data = {'action': {'module': 'debug', 'msg': 'this is a test'}}
    action_0 = 'debug'
    args = {'msg': 'this is a test'}
    delegate_to = None
    # replace 'ansible.builtin' with 'ansible.builtin.debug'
    # replace 'ansible.builtin.debug' with 'ansible.builtin.ansible.builtin.debug'
    # replace 'ansible.builtin.debug' with 'ansible.builtin.ansible.builtin.ansible.builtin.debug'
    # ...

# Generated at 2022-06-25 06:24:07.826449
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    ds = dict(action='debug', msg='{{foo}}')
    fds = dict(foo='bar')
    task_0 = Task.load(ds=ds)
    task_0._parent = Block()
    task_0._parent.vars = fds
    result = task_0.get_vars()
    assert fds == result


# Generated at 2022-06-25 06:24:09.567034
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    # Check the value of attribute name of class Task
    assert task_1.name == ""


# Generated at 2022-06-25 06:24:20.431833
# Unit test for method post_validate of class Task
def test_Task_post_validate():

    test_role_name = 'test_role'

    # define/configure:
    # - mock_valid_attrs_allowed
    # - mock_variable_manager
    # - mock_templar
    # - expected output


# Generated at 2022-06-25 06:24:27.417005
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = dict()
    task_0.vars['tags'] = "default"
    task_0.vars['tags'] = "default"
    #print("\n\nTestcase 0 : test_Task_get_vars\n")
    #print("Expected Result:")
    expected_result = dict()
    expected_result['tags'] = 'default'
    #print("\nActual Result")
    actual_result = task_0.get_vars()
    #print(actual_result)


# Generated at 2022-06-25 06:24:35.597295
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    assert task_0.get_first_parent_include() == None


from ansible.playbook.block import Block
from ansible.playbook.conditional import Conditional
from ansible.playbook.taggable import Taggable
from ansible.playbook.roles.role import Role
from ansible.playbook import ModuleArgsParser
from ansible.playbook.task_helpers import TaskLoader, TaskMutator
from ansible.playbook.attribute import Attribute
from ansible.utils.sentinel import Sentinel
from ansible.playbook.play_context import PlayContext
from ansible.plugins.loader import get_all_plugin_loaders
from ansible.errors import AnsibleError, AnsibleParserError
from ansible.module_utils._text import to_native

# Generated at 2022-06-25 06:24:40.493959
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.deserialize({})


# Generated at 2022-06-25 06:25:00.088085
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    default_collection_config = AnsibleCollectionConfig.default_collection
    AnsibleCollectionConfig.default_collection = "community.general"
    # get_include_params should return a dict with the only element 'ansible_version' = version of ansible
    # since this is the only variable where the key doesn't start with 'ansible_*'
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/vars/manager.py#L85
    task_1 = Task()
    assert(isinstance(task_1.get_include_params(), dict))
    assert(len(task_1.get_include_params()) == 1)
    assert('ansible_version' in task_1.get_include_params())

# Generated at 2022-06-25 06:25:03.199587
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    assert task_0.get_name() == 'task'



# Generated at 2022-06-25 06:25:05.739060
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0.post_validate()


# Generated at 2022-06-25 06:25:08.541417
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_0.name = 'test_name'

    # Expected result is None
    assert task_0.get_name() == 'test_name'


# Generated at 2022-06-25 06:25:10.735357
# Unit test for method get_name of class Task
def test_Task_get_name():
    obj = Task()
    if isinstance(obj.get_name(), str) is True:
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-25 06:25:17.262235
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    args = dict(name='test', action='file', args={'state': 'directory', 'path': '/foo/bar/baz'}, local_action='setup', delegate_to='127.0.0.1')
    task_0 = Task(**args)
    inst = task_0.post_validate(VariableManager())
    assert task_0 == inst


# Generated at 2022-06-25 06:25:30.379667
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Case 1
    task_1 = Task()
    task_1.action = 'shell'
    task_1.vars = dict(a = 'a_value')
    assert task_1.get_include_params() == dict()

    # Case 2
    task_2 = Task()
    task_2.action = 'include_tasks'
    task_2.vars = dict(b = 'b_value')
    assert task_2.get_include_params() == dict(b = 'b_value')

    # Case 3
    task_3 = Task()
    task_3.action = 'import_tasks'
    task_3.vars = dict(c = 'c_value')
    assert task_3.get_include_params() == dict(c = 'c_value')

    # Case 4


# Generated at 2022-06-25 06:25:33.649999
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    data = {}
    task_1 = Task()
    task_1.deserialize(data)
    assert task_1

# unit test for method serialize of class Task

# Generated at 2022-06-25 06:25:35.686045
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert repr(task_0) == Task.__repr__(task_0)


# Generated at 2022-06-25 06:25:45.939831
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    # import is here to avoid import loops
    from ansible.playbook.task_include import TaskInclude

    ##############
    # Set up test
    ##############

    data = dict()

    ##################################
    # Construct and validate arguments
    ##################################

    task_0 = Task()

    # Construct arguments
    task_0.deserialize(data)

    ####################
    # Perform assertion
    ####################

    # Performs a deep comparison between two complex objects
    # First argument is the object to compare to and the second argument is the
    # object to compare with
    obj0 = 0;
    obj1 = 0;
    assert cmp(obj0, obj1) == 0
