

# Generated at 2022-06-25 06:16:17.922140
# Unit test for method serialize of class Task
def test_Task_serialize():
    print('Test Task serialize begin')

    task_0 = Task()
    serialized = task_0.serialize()

    assert serialized is not None
    assert type(serialized) == dict

    print('Test Task serialize end')


# Generated at 2022-06-25 06:16:19.472732
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    try:
        task.get_include_params()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:16:23.114673
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Create task obj with 1 argument
    task_0 = Task(action='')
    actual = task_0.__repr__()
    expected = '<Task:  >'
    assert actual == expected


# Generated at 2022-06-25 06:16:25.137583
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    var = dict()
    task = Task()
    task.vars = var

    result = task.get_vars()

    assert result == var


# Generated at 2022-06-25 06:16:35.969344
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Default constructor call
    task_0 = Task()
    task_0.preprocess_data(None)

    # Constructor call with parameters
    task_1 = Task()
    variable_manager_0 = VariableManager()
    variable_manager_0.hostvars = dict()
    variable_manager_0.hostvars['hostvars'] = '/etc/ansible/roles'
    variable_manager_0.hostvars['hostvars'] = '/etc/ansible/roles'
    HostVars.hostvars = dict()
    HostVars.hostvars['hostvars'] = '/etc/ansible/roles'
    HostVars.hostvars['hostvars'] = '/etc/ansible/roles'
    var_0 = dict()

# Generated at 2022-06-25 06:16:37.700922
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    test_case_0()


# Generated at 2022-06-25 06:16:49.246510
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Converting with_items from a str to a list
    task_0 = Task()
    task_0.vars = dict()
    task_0._loader = DictDataLoader({})
    task_0._attributes = {}
    task_0.vars['test_var_0'] = 'example_0'
    task_0.args = {}
    task_0.args['with_items'] = '{{ test_var_0 }}'
    task_0.post_validate(None)
    task_0.preprocess_data({})
    assert task_0.args['with_items'] == 'example_0'
    # Converting with_items from a str to a list again
    task_0 = Task()
    task_0.vars = dict()

# Generated at 2022-06-25 06:16:51.594306
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    assert task.__repr__() == '<Task>'


# Generated at 2022-06-25 06:16:54.881153
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    assert len(test_case_0()) == 0


# Generated at 2022-06-25 06:16:56.104521
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    var_0 = task_0.get_first_parent_include()


# Generated at 2022-06-25 06:17:19.646214
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = {'a': 'b'}
    result = task_0.get_vars()
    assert result == {'a': 'b'}


# Generated at 2022-06-25 06:17:27.127261
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Create a dictionary ds that represents an Ansible task
    ds = dict(action=dict(module='command', args=dict(_raw_params='ls /')))

    # Instantiate a task from the dictionary and get its preprocessed data
    task = Task().load(ds)
    t_data = task.preprocess_data(ds)

    # Assert the preprocessed data is good
    assert t_data == dict(name='<unnamed>', action='command', args=dict(_raw_params='ls /', chdir=None, creates=None, removes=None, executable=None, warn=True), delegate_to=None)


# Generated at 2022-06-25 06:17:31.334752
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.preprocess_data(dict())
    assert True


# Generated at 2022-06-25 06:17:33.939867
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    assert task_0.get_name() == '<Task()>', 'Value should be <Task()>'


# Generated at 2022-06-25 06:17:43.214101
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    loader = DictDataLoader({})
    inv = Inventory(loader=loader,
                    variable_manager=VariableManager(),
                    host_list='hosts')

    pb = Playbook.load(loader=loader,
                       variable_manager=VariableManager(loader=loader, inventory=inv),
                       procesors=None,
                       uri='dummy.pb',
                       loader_cache=False,
                       use_handlers=False)


# Generated at 2022-06-25 06:17:51.862218
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test with a valid 'block' and 'vars' attribute.
    # NOTE: 'block' and 'vars' are not attributes of the Task class.
    test_0 = Task()
    test_0_data = { 'block': 'helo', 'vars': 'world'}
    test_0_preprocessed = test_0.preprocess_data(test_0_data)
    expected = { 'block': 'helo', 'vars': 'world' }
    assert test_0_preprocessed == expected

    # Test with a valid 'action' attribute.
    # NOTE: 'action' is an attribute of the Task class.
    test_1 = Task()
    test_1_data = { 'action': 'helo'}

# Generated at 2022-06-25 06:18:01.178400
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_1 = Task()
    task_1.name = 'my task'
    task_1.action = 'my action'
    task_1.vars = {'my_var': 'is set'}

    task_2 = Task()
    task_2.name = 'thing'
    task_2.action = 'something'
    task_2.vars = {'my_var': 'is NOT set'}
    task_2._parent = task_1

    task_3 = Task()
    task_3.name = 'thing'
    task_3.action = 'something'
    task_3.vars = {'my_var': 'is NOT set'}
    task_3._parent = task_2

    result = task_3.get_include_params()

# Generated at 2022-06-25 06:18:11.617662
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_1 = Task()
    task_1._attributes = {'environment': {'A': 'B'}}
    task_1._parent = task_0

# Generated at 2022-06-25 06:18:19.399862
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.action = "ping"
    task.delegate_to = "localhost"
    task.connection = "local"
    task.delegate_facts = True
    task.when = True

# Generated at 2022-06-25 06:18:28.991926
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()

    # Testing dict:
    ds = dict(
        name = 'A task',
        action = 'shell echo "test"',
        args = dict(
            _raw_params = '',
            chdir = '/path/to/somewhere/')
        )

    task_1.preprocess_data(ds)

    assert task_1.action == 'shell'
    assert task_1._attributes['action'] == 'shell'
    assert task_1.resolved_action == 'shell'
    assert task_1._attributes['resolved_action'] == 'shell'
    assert task_1.args['_raw_params'] == 'echo "test"'
    assert task_1._attributes['args']['_raw_params'] == 'echo "test"'

# Generated at 2022-06-25 06:18:50.071098
# Unit test for method serialize of class Task

# Generated at 2022-06-25 06:18:51.705152
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize({'action': 'shell'})


# Generated at 2022-06-25 06:18:56.493159
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    import __main__
    import sys

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    task_0 = Task()

    # call method post_validate of class Task
    task_0.post_validate()




# Generated at 2022-06-25 06:19:08.227865
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    # Test data with defaults
    test_data = {
        'environment': 'CTEST=true',
        'tags': ['tag_1', 'tag_2'],
        'when': 'True'
    }
    # test variables defined within the environment
    test_data['environment'] = "TEST_VAR=\"{{ansible_env['TEST_VAR']}}\""
    test_data = task_0.preprocess_data(test_data)
    assert isinstance(test_data, dict)
    assert isinstance(test_data['environment'], str)
    assert test_data['environment'] == 'TEST_VAR="{{ansible_env["TEST_VAR"]}}"'
    assert isinstance(test_data['tags'], list)

# Generated at 2022-06-25 06:19:16.349250
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:19:27.381009
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task.load(dict(action={'module': 'test_module_0', 'args': {'foo': 'bar'}}))
    assert task.get_include_params() == dict()

    task = Task.load(dict(action={'module': 'test_module_1', 'args': {'foo': 'bar'}}))
    assert task.get_include_params() == task.vars

    task = Task.load(dict(action={'module': 'test_module_2', 'args': {'foo': 'bar'}}))
    assert task.get_include_params() == task.vars

    task = Task.load(dict(action={'module': 'test_module_0', 'args': {'foo': 'bar'}}))
    assert task.get_include_params() == dict()

# Unit

# Generated at 2022-06-25 06:19:30.053059
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task()
    data = task_1.__repr__()
    # AssertionError: not equal
    assert data



# Generated at 2022-06-25 06:19:33.582128
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    t = Task()
    t.action = 'command'
    t.args = {'_raw_params': 'uptime'}
    t.vars = {'test': 'hello'}
    assert t.get_include_params() == {'test': 'hello'}


# Generated at 2022-06-25 06:19:40.720914
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    yaml_string = '''
    - name: hello world
      action: command
      args: touch /tmp/file1
      environment:
        VAR1: val1
        VAR2: val2
      when:  1
    '''
    task = Task.load(yaml_string)

# Generated at 2022-06-25 06:19:43.260346
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task._attributes['action'] = 'copy'
    task._attributes['name'] = 'test'
    assert repr(task) == "TASK: copy => test"


# Generated at 2022-06-25 06:20:02.585283
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # test case 1: deserialize a task, at first, it is not a task.
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.includes import Include
    task_1 = Task()
    data_1 = dict()
    task_1.deserialize(data_1)
    assert isinstance(task_1, Task)

    task_2 = Task()
    # test case 2: there is a play in the parent
    parent_2 = Task()
    data_2 = dict()
    parent_2.deserialize(data_2)
    task_2._parent = parent_2
    task_2.deserialize(data_2)
    assert isinstance(task_2, Task)

# Generated at 2022-06-25 06:20:10.539246
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    ds = {
        'environment': {
            'env1': '{{ foo }}'
        },
        'vars': {
            'var1': 'bar'
        }
    }
    t = task_0.preprocess_data(ds)
    assert 'environment' in t
    assert t['environment']['env1'] == '{{ foo }}'
    assert t['vars']['var1'] == 'bar'


# Generated at 2022-06-25 06:20:13.435628
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize(dict(action='setup'))
    assert task.action == 'setup'
    assert task.resolved_action == 'setup'


# Generated at 2022-06-25 06:20:15.807527
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    """
    Tests the get_vars() method of Task.
    """
    # This is not a meaningful test. I just needed to add something so coverage tools don't throw errors.
    assert Task().get_vars() == {}

# Generated at 2022-06-25 06:20:28.176916
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Testing the following task with method preprocess_data:
    #
    # - name: replace with_items item
    #   shell: echo '{{item}}'
    #   with_items:
    #     - four
    #     - five
    #     - six
    #   when: item != 'five'
    #   loop_control:
    #     loop_var: item
    #
    task_1 = Task()
    task_1.action = 'shell'
    task_1.args = {'_raw_params': 'echo \'{{item}}\'', '_uses_shell': True}
    task_1.when = 'item != \'five\''
    task_1.loop = ['four', 'five', 'six']
    task_1.loop_control = {'loop_var': 'item'}


# Generated at 2022-06-25 06:20:35.304123
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0_preprocess_data = task_0.preprocess_data()
    assert task_0_preprocess_data.get('action') == 'meta'
    assert task_0_preprocess_data.get('args') == {}
    assert task_0_preprocess_data.get('delegate_to') == None
    assert task_0_preprocess_data.get('vars') == []

# Generated at 2022-06-25 06:20:44.049403
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_result = True
    # initialize a Task object
    task_0 = Task()
    # instantiate a Role object
    data = dict()
    data['role'] = dict()
    cwd = os.getcwd()
    data['role']['_role_path'] = cwd
    role = Role()
    role.deserialize(data['role'])
    # set the role attribute of task_0
    task_0._role = role
    # set the parent attribute of task_0
    task_0._parent = role
    task_0.deserialize(data)


# Generated at 2022-06-25 06:20:45.766463
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    result = task_0.__repr__()
    assert result == "<ansible.playbook.task.Task object at 0x31e7890>"


# Generated at 2022-06-25 06:20:52.014100
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Create task object and run test
    task_0 = Task()
    task_0.vars = {'misc': 'misc'}
    result = task_0.get_vars()
    assert result == {'misc': 'misc'}


# Generated at 2022-06-25 06:20:57.370318
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    x = Task()
    yaml = '''action: new action'''

    x.deserialize(yaml)
    print(x.action)

if __name__ == '__main__':
    test_Task_deserialize()

# Generated at 2022-06-25 06:21:18.232709
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    attr_exclude = [('when', 'when', True)]
    attr_none_values = [('ignore_errors', False),('async_val', 0),('poll', 0),('register', None),('tags', None),('until', None),('retries', None),('changed_when', None),('failed_when', None),('delay', 0),('environment', None),('first_available_file', None),('notify', []),('delegate_to', None)]

# Generated at 2022-06-25 06:21:24.241808
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.deserialize({'__ansible_module__': u'command',
                        '__ansible_version__': 2.9,
                        'action': u'command',
                        'args': {'_raw_params': u'/bin/false',
                                 '_uses_shell': True,
                                 'chdir': None,
                                 'creates': None,
                                 'executable': None,
                                 'removes': None,
                                 'warn': True}},)
    assert 'args' in task_0._attributes
    assert task_0.action == u'command'


# Generated at 2022-06-25 06:21:31.223628
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    block_1 = Block()
    block_1.deserialize({u'type': u'block', u'block': [{u'type': u'task', u'include_tasks': {u'name': u'../../common/tasks/main.yml'}, u'include': u'../../common/tasks/main.yml'}], u'name': u'block2'})
    task_1 = Task()

# Generated at 2022-06-25 06:21:43.349370
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:21:45.646693
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert task_0.__repr__() == 'Task ()\n<BLANKLINE>'


# Generated at 2022-06-25 06:21:56.995160
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    res = Task()

    # No exception here - everything is OK
    res.deserialize({'action': 'test', 'args': {}})

    # All exception types are tested here
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleAssertionError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleParserError

    # All exception types are tested here
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleAssertionError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-25 06:22:06.765275
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # unit test: validate loop_control
    ds = dict(loop_control=dict(label='test-loop'))
    task = Task()
    task._loader = DictDataLoader({})
    task.preprocess_data(ds)

    if task.loop_control.label != 'test-loop':
        raise AssertionError('dictionary not set')

    # unit test: validate loop_control with bad keys
    ds = dict(loop_control=dict(not_allowed='test-loop'))
    task = Task()
    task._loader = DictDataLoader({})
    with pytest.raises(AnsibleParserError):
        task.preprocess_data(ds)

    # unit test: validate environment
    ds = dict(environment=dict(VARIABLE='test-env'))

# Generated at 2022-06-25 06:22:15.823342
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    # AnsibleModule is a stub

# Generated at 2022-06-25 06:22:18.206979
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Create a method object
    task_0 = Task()
    # Test method with an expected result
    assert task_0.get_vars() == dict()


# Generated at 2022-06-25 06:22:21.431412
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    assert task_1.get_name() is None
    task_1._attributes['name'] = "Hello"
    assert task_1.get_name() == "Hello"


# Generated at 2022-06-25 06:22:46.156001
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.load({
        u'action': {
            u'__ansible_module__': u'debug',
            u'msg': u'Hello, World!'
        }
    })

    assert task.preprocess_data({u'action': u'debug', u'args': {u'msg': u'Hello, World!'}})



# Generated at 2022-06-25 06:22:47.913878
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    try:
        task_0.get_first_parent_include()
        check = 0
    except:
        check = 1
    assert check == 0


# Generated at 2022-06-25 06:22:50.246577
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data(): 
    task_0 = Task()
    task_0.preprocess_data({'action': {'__ansible_module__': 'win_ping'}, 'args': {}, 'delegate_to': None})


# Generated at 2022-06-25 06:22:53.012988
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    assert task_0.serialize() is not None


# Generated at 2022-06-25 06:22:56.122240
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task(dict(action='x', args=dict(a='1', b='c')))
    # Verify __repr__ of task_0
    assert task_0.__repr__() == 'task: x'


# Generated at 2022-06-25 06:23:02.552842
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.action = 'async_status'
    task_0.args = dict()
    task_0.delegate_to = None
    task_0.delegate_facts = None
    task_0.become = None
    task_0.become_user = None
    task_0.become_method = None
    task_0.become_flags = None
    task_0.become_methods = None
    task_0.become_pass = None
    task_0.become_exe = None
    task_0.tags = list()
    task_0.name = None
    task_0.any_errors_fatal = None
    task_0.block = None
    task_0.ignore_errors = None
    task_0.notify

# Generated at 2022-06-25 06:23:04.749321
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    """
    task_0 = Task()
    print(task_0.get_vars())
    """
    pass


# Generated at 2022-06-25 06:23:07.624821
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()
    task.vars.update({'var': 'test'})
    assert task.get_vars() == {'var': 'test'}



# Generated at 2022-06-25 06:23:10.810914
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # data
    task_w = Task()

    # action
    task_r = task_w.get_include_params()

    # assertion
    assert isinstance(task_r, dict)


# Generated at 2022-06-25 06:23:15.609539
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_1 = Task()
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)
    task_1.post_validate(None)


# Generated at 2022-06-25 06:23:27.652611
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    result= task_0.get_name()
    assert result == 'TASK'


# Generated at 2022-06-25 06:23:30.110474
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    task_1.deserialize({'name': 'test_case_1'})
    assert task_1.get_name() == 'test_case_1'


# Generated at 2022-06-25 06:23:42.660693
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Test for data structure
    task_1 = Task()
    task_1.vars = {'hostvars': {'host1': {u'ansible_host': u'192.168.2.2', u'ansible_port': 22, u'ansible_user': u'user1'},
                                'host3': {u'ansible_host': u'192.168.2.3', u'ansible_port': 22, u'ansible_user': u'user3'},
                                'host2': {u'ansible_host': u'192.168.2.4', u'ansible_port': 22, u'ansible_user': u'user2'}}}

# Generated at 2022-06-25 06:23:48.822461
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_name = "test_Task_get_name"
    task_5 = Task()
    task_5._parent = task_name

    assert task_5.get_name() == task_name

# test attribute retention

# Generated at 2022-06-25 06:23:53.412455
# Unit test for method serialize of class Task
def test_Task_serialize():
    test_case_result = dict()
    test_case_result['method'] = 'Task.serialize'
    test_case_result['result'] = 'Fail'
    task_0 = Task()
    serialize_0 = task_0.serialize()
    if serialize_0 == dict():
        test_case_result['result'] = 'Pass'
    assert test_case_result['result'] == 'Pass'


# Generated at 2022-06-25 06:23:55.841814
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_0._attributes['name'] = 'task_name_0'
    assert "Execute the command in remote shell" == task_0.get_name()


# Generated at 2022-06-25 06:23:56.751712
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()



# Generated at 2022-06-25 06:23:58.324715
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert task_0.__repr__() == "TASK"


# Generated at 2022-06-25 06:24:04.155201
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    assert task_1.get_name() == ''
    task_2 = Task()
    task_2.name = 'test_name'
    assert task_2.get_name() == 'test_name'


# Generated at 2022-06-25 06:24:14.346117
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    # vars is empty
    task_1 = {
        'action': 'include_role',
        'vars': {}
    }
    task_mapping = {'include_tasks': task_1}
    task_0.deserialize(task_mapping)
    task_0.deserialize(task_mapping)
    task_0.get_include_params()
    # vars is not empty
    task_2 = {
        'action': 'include_role',
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
            'var3': 'value3'
        }
    }
    task_mapping = {'include_tasks': task_2}

# Generated at 2022-06-25 06:24:28.690216
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = {'foo': 'bar', 'baz': ['a', 'b', 'c']}
    returned_value_0 = task_0.get_vars()
    assert returned_value_0 == task_0.vars


# Generated at 2022-06-25 06:24:30.453061
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    task_repr_0 = repr(task_0)

    assert task_repr_0


# Generated at 2022-06-25 06:24:37.817340
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    task_0 = Task()
    ret_0 = task_0.preprocess_data(ds={'_ignore_errors': False, 'action': 'raw shell', 'register': 'shell_out', 'args': {'_raw_params': '/bin/false', '_uses_shell': True}, 'when': True, 'become': False, 'delegate_to': '127.0.0.1'})

# Generated at 2022-06-25 06:24:41.317106
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()


# Generated at 2022-06-25 06:24:50.720844
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    t = Task()
    t.ActionModule = "copy"
    t.vars = {
        "Test": {
            "foo": "bar",
            "ansible_winrm_server_cert_validation": "ignore",
            "ansible_winrm_transport": "credssp",
            "ansible_winrm_scheme": "https",
            "ansible_winrm_https_transport_credssp_accept_server_cert": "true",
            "ansible_winrm_path": "c:\\Windows\\System32\\WindowsPowerShell\\v1.0\\",
            "ansible_winrm_password": "***",
            "ansible_winrm_cert_validation": "ignore",
            "ansible_winrm_username": "Administrator"
        }
    }

# Generated at 2022-06-25 06:24:52.345379
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # test for preprocess_data with empty dict arg
    task_2 = Task(ds={})
    task_2.preprocess_data({})


# Generated at 2022-06-25 06:24:56.506109
# Unit test for method get_name of class Task
def test_Task_get_name():
    try:
        task_1 = Task()
        task_1.name = 'test_task_name'
        assert task_1.get_name() == 'test_task_name'
        del task_1
    except AssertionError:
        assert False


# Generated at 2022-06-25 06:25:03.344049
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_1 = Task()
    first_parent_include = task_1.get_first_parent_include()
    assert_equal(first_parent_include, None)
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()
    task_3 = Task()
    task_1._parent = task_0
    task_2._parent = task_1
    task_3._parent = task_2
    first_parent_include = task_3.get_first_parent_include()
    assert_equal(first_parent_include, None)


# Generated at 2022-06-25 06:25:14.398387
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    def _get_task(data):
        block = Block.load(
            data=dict(
                tasks=[data],
            ),
            play=dict(),
            variable_manager=VariableManager(),
            loader=MockDataLoader(),
        )
        task = block.block[0]
        task.preprocess_data()
        return task

    def _task_to_dict(task):
        data = task.serialize()
        # del data['parent']
        del data['module_name']
        return data

    # _preprocess_vars is defined in Base, and is used to load a dictionary
    # or list of dictionaries in a standard way

# Generated at 2022-06-25 06:25:17.050145
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    result = task_0.get_vars()
    assert type(result) == dict
    assert result == {}

# Generated at 2022-06-25 06:25:28.386996
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.deserialize(data)


# Generated at 2022-06-25 06:25:39.416964
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task = Task()
    task.parent = Task()
    task.parent.parent = Task()
    task.parent.parent.parent = Task()
    block = Block()
    block.parent = Task()
    block.parent.parent = Task()
    task_include = TaskInclude()
    task_include.parent = Task()
    task_include.parent.parent = Task()

    # case 0:
    # there is no parent for the task
    assert task.get_first_parent_include() == None

    # case 1:
    # there are many ancestors for the task, but no one of them is a task_include
    assert task.parent.parent.parent.get_first_parent_include() == None

    # case 2:
    # there is a block as parent

# Generated at 2022-06-25 06:25:43.660675
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    # Test for the method deserialize of class Task
    task_0.deserialize()

    # Test for the method deserialize of class Task when attribute is None
    task_1 = Task()
    task_1.deserialize(None)


# Generated at 2022-06-25 06:25:51.743781
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    assert(isinstance(task_0, Task))
    task_1 = Task()
    assert(isinstance(task_1, Task))

    task_2 = Task()
    assert(isinstance(task_2, Task))
    task_3 = Task()
    assert(isinstance(task_3, Task))

    task_4 = Task()
    assert(isinstance(task_4, Task))
    task_5 = Task()
    assert(isinstance(task_5, Task))

    task_6 = Task()
    assert(isinstance(task_6, Task))
    task_7 = Task()
    assert(isinstance(task_7, Task))


# Generated at 2022-06-25 06:26:03.292481
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()