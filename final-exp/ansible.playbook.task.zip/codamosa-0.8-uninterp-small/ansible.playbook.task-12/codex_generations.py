

# Generated at 2022-06-25 06:16:18.638497
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data = {}
    task_0.deserialize(data)


# Generated at 2022-06-25 06:16:20.103811
# Unit test for method get_name of class Task
def test_Task_get_name():
    Task1 = Task()
    Task1._attributes["name"] = "taskname"
    assert Task1.get_name() == "taskname"

# Generated at 2022-06-25 06:16:23.756070
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    # Test execution
    task_0.preprocess_data({'name': 'localhost', 'arguments': {'_raw_params': '-m ping', '_uses_shell': False}})


# Generated at 2022-06-25 06:16:35.907081
# Unit test for method serialize of class Task
def test_Task_serialize():
    # serialize: serialize the task into data, which will be used in deserialize
    # in the ansible-playbook process
    task_0 = Task()

    def _serialize():
        return task_0.serialize()

    # the task_0 is not squashed yet, we can serialize it
    assert task_0._squashed == False
    assert task_0._finalized == False

    # If the object is squashed or finalized, then it cannot be serialized
    task_0.squash()
    task_0._squashed = True
    assert _serialize() == None

    task_0.finalize()
    task_0._finalized = True
    # if the object is finalized, it's serialization will a normal serialization
    assert _serialize() != None


# Generated at 2022-06-25 06:16:40.119461
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_obj = Task()
    serialize_result = task_obj.serialize()
    assert isinstance(serialize_result, dict)



# Generated at 2022-06-25 06:16:50.692407
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize('')

# Generated at 2022-06-25 06:16:57.441609
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    task_1.name = "my_task_name_1"
    task_1.action = "command"
    task_1.args = {'_uses_shell': True, '_raw_params': 'my_raw_params_1'}
    name_1 = task_1.get_name()
    assert name_1 == "command | my_raw_params_1"


# Generated at 2022-06-25 06:17:00.693829
# Unit test for method get_name of class Task
def test_Task_get_name():
    # Initialization
    task_0 = Task()
    task_0.action = "shell"
    
    # Execution
    task_name = task_0.get_name()
    
    # Verification
    assert task_name == "shell"


# Generated at 2022-06-25 06:17:07.416602
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # Test a simple task
    task_0 = Task()

    # Test a task with a parent
    task_1 = Task()
    block_0 = Block()
    task_1._parent = block_0
    assert task_1.get_first_parent_include() == None

    # Test a task with a Block parent and a grandparent TaskInclude
    task_2 = Task()
    block_1 = Block()
    task_2._parent = block_1
    block_1._parent = TaskInclude()
    assert isinstance(task_2.get_first_parent_include(), TaskInclude)

   

# Generated at 2022-06-25 06:17:14.171736
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    # test case 0: no parent
    task_0 = Task()
    result_0 = task_0.get_first_parent_include()
    assert result_0 is None

    # test case 1: parent is TaskInclude
    task_1 = Task()

    # parent is TaskInclude
    task_include_1 = TaskInclude()
    task_1._parent = task_include_1
    result_1 = task_1.get_first_parent_include()
    assert result_1 == task_include_1

    # test case 2: parent is not TaskInclude and one of its ancestor is TaskInclude
    # parent is not TaskInclude
    task_2 = Task()
    block_0 = Block()
    block_1 = Block()
    block_2 = Block()
    task_2._parent = block_0

# Generated at 2022-06-25 06:17:51.654370
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()

    task_vars = dict()
    task_vars['key1'] = 'value1'
    task_vars['key2'] = 'value2'
    task_0.vars = task_vars

    parent_task_vars = dict()
    parent_task_vars['key3'] = 'value3'
    parent_task_vars['key4'] = 'value4'

    parent_Task = Task()
    parent_Task.vars = parent_task_vars

    task_0._parent = parent_Task

    # Test case when 'tags' and 'when' are NOT present
    task_vars['tags'] = ''
    task_vars['when'] = ''
    parent_task_vars['tags'] = ''

# Generated at 2022-06-25 06:17:54.486556
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    t = Task()
    t.name = 'test'
    t.action = 'copy'
    task_to_str = 'TASK: test (copy)'
    assert t.__repr__() == task_to_str


# Generated at 2022-06-25 06:18:00.543274
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    block_0 = Block()
    block_1 = Block()
    block_1._parent = block_0
    role_0 = RoleInclude()
    role_0._role = None
    role_1 = RoleInclude()
    role_1._role = None
    role_1._parent = role_0
    handlerTaskInclude_0 = HandlerTaskInclude()
    handlerTaskInclude_0._parent = block_0
    handlerTaskInclude_1 = HandlerTaskInclude()
    handlerTaskInclude_1._parent = block_1
    handlerTaskInclude_2 = HandlerTaskInclude()
    handlerTaskInclude_

# Generated at 2022-06-25 06:18:03.486855
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    repr_retval_0 = repr(task_0)
    assert repr_retval_0 is not None



# Generated at 2022-06-25 06:18:13.476691
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    # Test values
    task_0.action = 'shell'
    task_0.args = {
        'follow': True,
        'chdir': '/home/ec2-user/ansible/playbooks',
        'creates': '/etc/nginx/ssl/dev.example.com.pem',
        'executable': None,
        '_uses_shell': True,
        '_raw_params': 'meu comando shell',
        'removes': '/etc/nginx/sites-enabled/default'
    }

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-25 06:18:18.217893
# Unit test for method get_name of class Task
def test_Task_get_name():
    test_case_0()
    print('\nIn task.py: test_Task_get_name()')
    task_name = 'test_task_0'
    task_0 = Task()
    task_0.name = task_name
    assert task_0.get_name() == task_name
    print('test_Task_get_name() passed!')


# Generated at 2022-06-25 06:18:21.124988
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    result = str(task_0.__repr__())
    assert result is not None
    print("TEST: Task.__repr__(): result="+result)


# Generated at 2022-06-25 06:18:23.407460
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.deserialize({})
    assert task_0.__class__.__name__ == "Task"


# Generated at 2022-06-25 06:18:29.905056
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # From test/units/module_utils/basic.py
    # Recreate a task with a given loaders
    example_task_dict = {'action': 'shell', 'args': 'ls -l'}
    task = Task.load(example_task_dict, loader=None, variable_manager=VariableManager(), loader_class=DataLoader)
    assert repr(task) == '<Task {}>'

    # From test/units/module_naming/test_module_naming.py
    # Recreate a task with a given loaders
    example_task_dict = {'action': 'test_collection.test', 'args': {'arg': 'test'}}
    task = Task.load(example_task_dict, loader=MockCollectionLoader(), variable_manager=VariableManager(), loader_class=DataLoader)

# Generated at 2022-06-25 06:18:32.230697
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    test_case = TestCase()
    task_0 = Task()
    post_validate = task_0.post_validate()
    assert post_validate == True, "Last line should be True"


# Generated at 2022-06-25 06:19:03.984365
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Create a new instance of Task
    # Deserialize the Task
    task_0 = Task.deserialize(data)
    # Serialize the Task
    task_1 = Task.serialize(task_0)


# Generated at 2022-06-25 06:19:12.319195
# Unit test for method preprocess_data of class Task

# Generated at 2022-06-25 06:19:16.841093
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = dict(a=1, b=2)
    task_0._parent = Task()
    task_0._parent.vars = dict(b=3, c=4)
    assert task_0.get_vars() == dict(a=1, b=3, c=4)


# Generated at 2022-06-25 06:19:21.324231
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    jsonString = task_0.serialize()
    task_1 = Task()
    task_1.deserialize(jsonString)

test_case_0()
test_Task_deserialize()

# Generated at 2022-06-25 06:19:24.100249
# Unit test for method serialize of class Task
def test_Task_serialize():
    # Create the object with all its dependent objects
    task_0 = Task()

    # Get task
    task = task_0.serialize()
    print(task)



# Generated at 2022-06-25 06:19:26.232682
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task._attributes['name'] = 'test'

    assert task.get_name() == 'test'


# Generated at 2022-06-25 06:19:35.701740
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test set 1
    task = Task()

# Generated at 2022-06-25 06:19:45.498290
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()
    task_1.vars = {'ansible_version': {'major': 2, 'minor': 9, 'revision': 4}, 'ansible_user': 'vagrant', 'ansible_host': '10.1.1.2', 'ansible_connection': 'ssh', 'ansible_python_interpreter': '/usr/bin/python3'}
    expected_1 = {'ansible_version': {'major': 2, 'minor': 9, 'revision': 4}, 'ansible_user': 'vagrant', 'ansible_host': '10.1.1.2', 'ansible_connection': 'ssh', 'ansible_python_interpreter': '/usr/bin/python3'}
    actual_1 = task_1.get_vars()
    assert actual_1

# Generated at 2022-06-25 06:19:48.367274
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    '''
    AnsibleModule class post_validate method.
    '''
    task_0 = Task()
    assert isinstance(task_0, Task) is True


# Generated at 2022-06-25 06:19:52.570286
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0.post_validate(None)

task_0 = Task()
task_0.post_validate(None)


# Generated at 2022-06-25 06:20:12.587280
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    ds_0 = {"loop": "{{ lookup('sequence', '1 2') }}"}
    task_0._variable_manager = VariableManager()
    task_0._loader = None
    task_0.preprocess_data(ds_0)
    if task_0.loop != '{{ lookup(\'sequence\', \'1 2\') }}' or task_0.loop_control != {'loop_var': 'item'} or task_0.environment != {}:
        raise AssertionError()


# Generated at 2022-06-25 06:20:21.088214
# Unit test for method get_name of class Task
def test_Task_get_name():
    task1 = Task()
    task2 = Task()
    task3 = Task()
    block = Block()
    block.block = [task1, task2, task3]
    p = Play()
    p.hosts = ['localhost']
    p.tasks = [block]
    assert p.get_tasks()[0].get_name() == 'block'
    assert p.get_tasks()[0].block[0].get_name() == 'block'
    assert p.get_tasks()[0].block[1].get_name() == 'block'
    assert p.get_tasks()[0].block[2].get_name() == 'block'


# Generated at 2022-06-25 06:20:28.253461
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    pb_0 = Task()
    pb_1 = Task()
    pb_0.vars = {"var": True}
    pb_0.action = "action"
    pb_1.action = "action"
    pb_0._parent = pb_1
    assert pb_0.get_include_params() == {"var": True}
    pb_0.action = "action2"
    assert pb_0.get_include_params() == {"var": True}


# Generated at 2022-06-25 06:20:30.792383
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    expected_result = ""

    assert task_0.__repr__() == expected_result

# Generated at 2022-06-25 06:20:40.203584
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    task_0.vars = {u'single_var': u'value_var', u'list_var': [1, 2]}
    task_0.action = 'include_tasks'
    task_1 = Task()
    task_1.vars = {u'list_var': [3, 4]}
    task_1._parent = task_0
    include_params = task_1.get_include_params()
    assert len(include_params) == 2
    assert include_params[u'single_var'] == u'value_var'
    assert include_params[u'list_var'] == [1, 2]


# Generated at 2022-06-25 06:20:41.446852
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    pass


# Generated at 2022-06-25 06:20:43.658067
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0.post_validate()


# Generated at 2022-06-25 06:20:53.688271
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    my_loader = DictDataLoader({
        '/my/path/to/my/file.yaml': """
            ---
            become: yes
        """,
    })

    my_var_manager = VariableManager()
    my_var_manager.extra_vars = {
        'foo': 'bar'
    }

    my_collection_loader = Mock()


# Generated at 2022-06-25 06:21:02.302395
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    play = Play.load(dict(
        hosts='testhost',
        gather_facts='no',
        roles=dict(),
        tasks=[dict(meta=dict(from_task=0)), dict(name='do nothing')]
    ), loader=_loader())

    # check that task without a name works
    assert play.get_tasks()[0].name is None
    # check that task without a name is properly serialized
    assert play.get_tasks()[0].serialize() == dict(meta=dict(from_task=0))

# Generated at 2022-06-25 06:21:07.267038
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task._attributes['name'] = 'test'
    assert task.get_name() == 'test'


# Generated at 2022-06-25 06:21:34.923477
# Unit test for method get_name of class Task
def test_Task_get_name():
    try:
        task_0 = Task()
        task_1 = Task()
        # Test of method get_name of class Task
        ansible_result_0 = task_0.get_name()
        ansible_result_1 = task_1.get_name()
        # Test of comparison
        assert ansible_result_0 == ansible_result_1
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 06:21:40.515187
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    # test for assertionError
    try:
        task_0.post_validate("templar")
        raise AssertionError("Should have raised an assertion error but did not.")
    except AssertionError as e:
        pass
    except Exception as e:
        raise AssertionError("Should have raised an assertion error but got %s instead." % e)

# Generated at 2022-06-25 06:21:46.884903
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    host = Host('localhost')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    t = Task()
    t.action = 'test'
    p = Play().load(dict(name='test play', hosts=['localhost'], tasks=[t.serialize()]), variable_manager=variable_manager, loader=loader)
    assert p[0].action == 'test'


# Generated at 2022-06-25 06:21:50.001393
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    data = dict(environment=dict(var_name='var_value'))
    task_0 = Task()
    task_0.post_validate(data, None)
    assert 'var_name' in task_0.get_vars()


# Generated at 2022-06-25 06:21:56.319406
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    if not type(task_0.deserialize()) == type(None):
        print('Error in test_Task_deserialize, expected type None')
    else:
        print('Test test_Task_deserialize passed')


# Generated at 2022-06-25 06:22:00.463311
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert task_0.__repr__() == '<Task (no_attr)>'


# Generated at 2022-06-25 06:22:02.580977
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_0 = Task()
    assert test_0.deserialize == Task.deserialize


# Generated at 2022-06-25 06:22:05.361198
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.preprocess_data('test')


# Generated at 2022-06-25 06:22:07.171998
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert repr(task_0) == "<Task: tasks>", repr(task_0)


# Generated at 2022-06-25 06:22:13.908804
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    collection_list = [u'ansible.builtin']
    ds = dict()
    ds[u'action'] = u'ping'
    new_ds = dict()
    action = u'ping'
    args = None
    delegate_to = None
    vars = dict()
    k = 'action'
    if k.replace("with_", "") in lookup_loader:
        task_0._preprocess_with_loop(ds, new_ds, k, None)
    elif C.INVALID_TASK_ATTRIBUTE_FAILED or k in task_0._valid_attrs:
        new_ds[k] = None
    else:
        display.warning("Ignoring invalid attribute: %s" % k)
    v = 'ping'
   

# Generated at 2022-06-25 06:22:26.841581
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.preprocess_data()

# Generated at 2022-06-25 06:22:30.638375
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # Run test case
    r = test_case_0()

    # Check result


# Generated at 2022-06-25 06:22:33.683818
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    ds = {}
    templar = Templar()

    res_0 = task_0.preprocess_data(ds)
    assert not res_0


# Generated at 2022-06-25 06:22:40.650218
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    task_1._valid_attrs = {'action': task_1.get_action(), 'local_action': task_1.get_action(), 'args': task_1.get_args(), 'delegate_to': task_1.get_delegate_to()}
    task_1._attributes = {'action': 'copy', 'local_action': 'copy', 'args': {'src': '/etc/hosts'}, 'delegate_to': 'localhost'}
    task_1._variable_manager = object()
    assert task_1._preprocess_data({}) == {'action': 'copy', 'args': {'src': '/etc/hosts'}, 'delegate_to': 'localhost'}

# Generated at 2022-06-25 06:22:50.323067
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    test_fn = get_fixture_path('test_Task_vars.yml')
    ds = {}
    ds_template = {}
    ds_merged = {}

    with open(test_fn, 'r') as f:
        data = yaml.safe_load(f)
        ds = data['ds']
        ds_template = data['ds_template']
        ds_merged = data['ds_merged']

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))

    loader.set_basedir(get_fixture_path('test_Task_vars'))

    task_0 = Task()
    task_0.load_data(ds, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 06:22:55.838472
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    dict_obj = dict()
    task_0.vars = dict_obj
    task_0.action = 'action'
    expected_result = dict()
    expected_result['action'] = 'action'
    actual_result = task_0.get_vars()
    assert actual_result == expected_result


# Generated at 2022-06-25 06:23:01.081876
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.action = "shell"
    task.args = {
        "_raw_params": "ls",
    }
    task.args['changed_when'] = "False"
    task.args['failed_when'] = "True"
    task.args['register'] = "out"
    task.delegate_to = None

    task.post_validate({})
    assert task.failed_when == "True"
    assert task.changed_when == "False"
    assert task.register == "out"
    assert task.resolved_action == "shell"


# Generated at 2022-06-25 06:23:05.322996
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0._role = Role()
    task_0._role.statically_loaded = True
    new_ds = task_0.preprocess_data(dict(action=dict(name="test")))
    assert 'action' in new_ds and new_ds['action'] == 'test'


# Generated at 2022-06-25 06:23:06.681403
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_case_1()


# Generated at 2022-06-25 06:23:10.709473
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    # In this test lists are compared unordered.
    # Unordered comparison of lists.
    assert_star_equals(task_0.get_vars, {}, repr(task_0.get_vars))


# Generated at 2022-06-25 06:23:28.353584
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_1 = Task()
    task_1._task_type = None
    task_1._uuid = None
    task_1._role = None
    task_1._block = None
    task_1._parent = None
    task_1._play = None
    task_1._loader = None
    task_1._variable_manager = None
    task_1._action = None
    task_1._implicit = None
    task_1._resolved_action = None

    print(task_1.serialize())

# Generated at 2022-06-25 06:23:37.925149
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.automatically_set_tags = False
    task_0.async_val = None
    task_0.async_seconds = None
    task_0.always_run = False
    task_0.block = None
    task_0.any_errors_fatal = None
    task_0.become = None
    task_0.become_flags = []
    task_0.become_method = None
    task_0.become_user = None
    task_0.changed_when = None
    task_0.check_mode = False
    task_0.connection = 'smart'
    task_0.container = None
    task_0.delegate_facts = False
    task_0.delegate_to = None
    task_0.depend

# Generated at 2022-06-25 06:23:48.942200
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    test_Task_preprocess_data_1()
    test_Task_preprocess_data_2()
    test_Task_preprocess_data_3()
    test_Task_preprocess_data_4()
    test_Task_preprocess_data_5()
    test_Task_preprocess_data_6()
    test_Task_preprocess_data_7()
    test_Task_preprocess_data_8()
    test_Task_preprocess_data_9()
    test_Task_preprocess_data_10()
    test_Task_preprocess_data_11()
    test_Task_preprocess_data_12()
    test_Task_preprocess_data_13()
    test_Task_preprocess_data_14()
    test_Task_preprocess_data_15()
    test_Task

# Generated at 2022-06-25 06:23:55.732882
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    from ansible.playbook.role import Role

    task = Task()
    task.action = 'myaction'
    task.args = {'arg1': 'myarg'}
    task.delegate_to = 'myhostname'

    role = Role()
    role.name = 'rolename'
    role.vars = {'rolevar': 'rolevalue'}
    task._role = role

    block = Block()
    block.vars = {'blockvar': 'blockvalue'}
    block.tags = ['blocktag']
    block.when = ['blockwhen']
    task._parent = block

    play = Play()
    play.vars = {'playvar': 'playvalue'}
    play.tags = ['playtag']
    play.when = ['playwhen']
    block._parent = play

   

# Generated at 2022-06-25 06:24:02.037277
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    import sys
    import ansible.playbook.accelerate
    import ansible.playbook.auto_resolve_arguments
    import ansible.playbook.block
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task

    # Create a task object
    task_0 = Task()

    # Create a parent object
    parent_0 = Task()
    parent_0.vars = {'test_key': 'test_value'}

    # Set parent to task
    task_0._parent = parent_0

    # Retrieve all vars from task and its parents
    ret = task_0.get_vars()

    # Compare the two dicts and make sure they are the same
    assert ret == parent

# Generated at 2022-06-25 06:24:06.487397
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    parent_data = {}
    parent_type = "Block"
    p = Block()
    task_0.deserialize({'parent': parent_data, 'parent_type': parent_type})
    assert task_0._parent == p


# Generated at 2022-06-25 06:24:10.419268
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    # There is no reason to test this method because it
    # returns the value of a static property in the superclass
    # if the code is changed then, this test will cause an error
    # if the superclass method is not updated to match.
    pass


# Generated at 2022-06-25 06:24:20.488623
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Given scenario 1
    task_0 = Task()
    task_0.action = 'setup'
    task_0.module_args = 'filter=ansible_date_time'
    # Preprocess data
    task_0.preprocess_data({})
    # Assert expected
    assert task_0.action == 'setup'
    assert task_0.args == {'filter': 'ansible_date_time'}
    assert task_0.args['filter'] == 'ansible_date_time'
    assert task_0.module_args == 'filter=ansible_date_time'

    # Given scenario 2
    task_1 = Task()
    task_1.action = 'shell'
    task_1.module_args = 'uname -r'
    # Preprocess data
    task_1.preprocess_

# Generated at 2022-06-25 06:24:21.701401
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.post_validate()

# Generated at 2022-06-25 06:24:30.089176
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    # Test with no vars set, expect empty dict
    task_1 = Task()
    assert task_1.get_include_params() == dict()

    # Test with parent but not include type task, expect empty dict
    task_2 = Task(vars={'k1': 'v1', 'k2': 'v2'}, parent=task_1)
    assert task_2.get_include_params() == dict()

    # Test with include type parent, vars set, expect vars set
    task_3 = Task(vars={'k1': 'v1', 'k2': 'v2'}, parent=task_2)
    assert task_3.get_include_params() == {'k1': 'v1', 'k2': 'v2'}

    # Test child of non-include parent, vars set but

# Generated at 2022-06-25 06:25:01.603092
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test 1: local_action
    my_task = Task()
    my_dict = { 'local_action': 'test_action'}
    my_task._parent = { 'hosts':'test_hosts', 'connection':'test_connection' }
    my_task.preprocess_data(my_dict)
    assert my_task.action == 'test_action'
    assert my_task.delegate_to == 'test_hosts'

    # Test 2: delegate_to
    my_dict = { 'local_action': 'test_action', 'delegate_to':'delegated' }
    my_task._parent = { 'hosts':'test_hosts', 'connection':'test_connection' }
    my_task.preprocess_data(my_dict)
    assert my_task.delegate

# Generated at 2022-06-25 06:25:12.165009
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    ds_0 = dict(
        fail=None,
        loop=None,
        loop_control=None,
        name=None,
        register=None,
        retries=None,
        run_once=None,
        tags=None,
        until=None,
        when=None,
        action=dict(
            module=None,
            args=None,
            _raw_params=None
        )
    )

# Generated at 2022-06-25 06:25:15.376737
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data = {}
    task_0.deserialize(data)


# Generated at 2022-06-25 06:25:23.614145
# Unit test for method serialize of class Task

# Generated at 2022-06-25 06:25:27.459408
# Unit test for method get_name of class Task
def test_Task_get_name():

    task_0 = Task()

    # Make sure the return value is of correct type
    assert isinstance(task_0.get_name(), str)

    # Make sure the return value is correct
    assert task_0.get_name() == 'task'


# Generated at 2022-06-25 06:25:34.440260
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    task_0.action = 'setup'
    task_0.vars = {'ansible_facts': {'hostname': 'nodename.nodedomain'}}
    all_vars = task_0.get_include_params()
    assert (all_vars == {'ansible_facts': {'hostname': 'nodename.nodedomain'}})


# Generated at 2022-06-25 06:25:42.831257
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    def _make_task(action):
        task_0 = Task()
        data_0 = {'action': action}
        task_0.load(data=data_0)
        task_0.preprocess_data()
        return task_0

    # Case 1: test loads and runs preprocess_data with each action from the _ACTION_BLACKLIST
    for action in C._ACTION_BLACKLIST:
        task_0 = _make_task(action)
        assert task_0.action == 'include_tasks'

    # Case 2: test loads and runs preprocess_data with each action from the _ACTION_WHITELIST
    for action in C._ACTION_WHITELIST:
        task_0 = _make_task(action)
        assert task_0.action == action

    # Case 3: test loads and runs

# Generated at 2022-06-25 06:25:48.539919
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Set up test object
    task_0 = Task()
    task_0.action = "shell"
    task_0.args={}

    # Call test function
    result_0 = task_0.get_include_params()

    # Check result
    assert result_0 == {}


# Generated at 2022-06-25 06:25:51.480379
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()

    task_0.name = "task"
    #TODO
    #   assert task_0.get_name() == None


# Generated at 2022-06-25 06:25:55.535073
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert task_0.__repr__() == "Task(name=None)"
