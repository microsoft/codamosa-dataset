

# Generated at 2022-06-25 06:16:30.848911
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert repr(task_0)


# Generated at 2022-06-25 06:16:38.367523
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:16:43.080622
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    d = dict(action='test', async_val=10, async_jid='test', poll=10, register='test', ignore_errors=True)
    t = Task()

    try:
        t.deserialize(d)
    except AnsibleError:
        assert False, "Test case for Task deserialize failed"



# Generated at 2022-06-25 06:16:55.300943
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    task_1 = Task()
    task_2 = Task()

# Generated at 2022-06-25 06:17:06.142679
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    '''
    Ansible-task-0: Load a task by deserialize
    '''

# Generated at 2022-06-25 06:17:13.145389
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.preprocess_data(dict(name='test_case', action='debug', module='debug'))
    assert task.action == 'debug' and task.name == 'test_case' and task.module == 'debug'


# Generated at 2022-06-25 06:17:18.613964
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Ensure this environment variable isn't set, to prevent unexpected external plugins from loading
    if os.environ.get("ANSIBLE_INVALID_TASK_ATTRIBUTE_FAILED", None):
        del os.environ["ANSIBLE_INVALID_TASK_ATTRIBUTE_FAILED"]

    # No fail on invalid task attribute
    ###############################
    ds = dict(
        a=50,
        b=dict(
            c=dict(
                d="test"
            ),
            x=10,
            y="y",
        ),
    )
    task_1 = Task(ds)
    task_1.preprocess_data(ds)
    assert list(ds.keys()) == ['a', 'b']
    assert ds['a'] == 50

# Generated at 2022-06-25 06:17:23.192942
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.preprocess_data({'action': 'user', 'vars': {'task_var_0': 'task_var_value_0'}})
    assert task_0.vars == {'task_var_0': 'task_var_value_0'}
    assert task_0.action == 'user'


# Generated at 2022-06-25 06:17:27.996667
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0._attributes = dict()
    task_0._extras = dict()
    task_0.vars = dict()
    new_ds = dict()
    task_0.post_validate(templar=None)
    task_0._preprocess_data(new_ds)
    task_0._load_data()


# Generated at 2022-06-25 06:17:37.167377
# Unit test for method get_vars of class Task
def test_Task_get_vars():

    # Create a task with vars and role
    test_task = Task()

    test_task.vars = dict(
        foo=1,
    )

    setattr(test_task, '_role', Role())
    getattr(test_task, '_role').vars = dict(
        foo=2,
        bar="baz",
    )

    vars_result = test_task.get_vars()

    assert vars_result['foo'] == 1

    assert vars_result['bar'] == "baz"


# Generated at 2022-06-25 06:17:48.829193
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = {'a': 'b', 'c': 'd'}
    assert task_0.get_vars() == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-25 06:17:50.472222
# Unit test for method serialize of class Task
def test_Task_serialize():
    # All tests for Task can go here
    task = Task()
    assert task.serialize() == {}


# Generated at 2022-06-25 06:17:59.167553
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Create the task object
    task_1 = Task()

    # Assign values to action
    task_1.action = 'include'

    # Assign values to tags
    task_1.tags = ['notify']

    # Assign values to vars
    task_1.vars = {
        'include_vars': {
            'file': '/home/persons/homedir/ansible_var.yml'
        }
    }
    value = task_1.get_include_params()

    # Verify the expected results
    assert value == {
        'include_vars': {
            'file': '/home/persons/homedir/ansible_var.yml'
        }
    }


# Generated at 2022-06-25 06:18:01.179450
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    result = task_0.__repr__()
    assert result == '<Task>'


# Generated at 2022-06-25 06:18:11.618153
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    from ansible.parsing.vault import VaultLib
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    vault_pass = '$ANSIBLE_VAULT;1.1;AES256'

    ########
    # Tests of preprocess_data using _VALID_TRANSFORMS
    ########

    # There are 2 tests per data type; the first sends the task.preprocess_data
    # a raw value, and the second sends the task a value that has already been
    # preprocessed.

    # First for strings
    task_1 = Task()
    task_1._validate_attributes = Mock(return_value=None)
    task_1._variable_manager = Mock()
    task_1._loader = DictData

# Generated at 2022-06-25 06:18:13.437090
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task()
    task_1.__repr__()


# Generated at 2022-06-25 06:18:20.728864
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Generating random temporary module_path and modified_module_utils
    module_path = "/tmp/ansible_test_" + str(randint(0, 999999)) + ".py"
    modified_module_utils = "/tmp/ansible_test_modified_module_utils"
    # Create a test module
    tmp_module_file = open(module_path, "w")
    tmp_module_file.write("#!/usr/bin/python\n")
    tmp_module_file.write("print(\"hello world\")\n")
    tmp_module_file.close()

    # Generating test data
    data = dict()
    data['action'] = "testmodule"
    data['action'] = module_path

    ds = dict()
    ds['action'] = dict()

# Generated at 2022-06-25 06:18:30.733200
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    result = task_0.__repr__()
    print(result)

# Generated at 2022-06-25 06:18:36.055939
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible_collections.ansible.builtin.plugins.include import Include as TaskInclude
    task_0 = Task()
    result = task_0.get_first_parent_include()
    assert result is None
    task_0._parent = TaskInclude()
    result = task_0.get_first_parent_include()
    assert isinstance(result, TaskInclude)
    task_0._parent._parent = TaskInclude()
    result = task_0.get_first_parent_include()
    assert isinstance(result, TaskInclude)


# Generated at 2022-06-25 06:18:47.107360
# Unit test for method get_include_params of class Task

# Generated at 2022-06-25 06:19:07.636303
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:19:16.634090
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Test when include params are not defined
    task_1 = Task()
    task_1.set_loader(DictDataLoader())
    task_1.action = 'include_tasks'
    assert task_1.get_include_params() == {}
    # Test when include params are defined
    task_2 = Task()
    task_2.set_loader(DictDataLoader())
    task_2.action = 'include_tasks'
    task_2.vars = dict(foo="bar")
    assert task_2.get_include_params() == dict(foo="bar")
    # Test when action is not include_tasks
    task_3 = Task()
    task_3.set_loader(DictDataLoader())
    task_3.action = "setup"

# Generated at 2022-06-25 06:19:21.119506
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0_ds = dict()
    task_0_templar = Templar(loader=None, variables={})
    task_0_ds['action'] = dict()
    task_0_templar.set_available_variables(task_0_ds['action'])
    task_0_post_validate_ds = task_0.preprocess_data(task_0_ds)
    assert(len(task_0_post_validate_ds) == 1)
    assert('args' in task_0_post_validate_ds)

# Generated at 2022-06-25 06:19:31.427830
# Unit test for method deserialize of class Task

# Generated at 2022-06-25 06:19:34.158023
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    Task().deserialize({'action': {'__ansible_module__': 'setup', '__ansible_arguments__': None},
                        'args': {},
                        'name': 'Gathering Facts',
                        'delegate_to': None})



# Generated at 2022-06-25 06:19:36.916340
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    print(task_0)

# Generated at 2022-06-25 06:19:42.533746
# Unit test for method get_name of class Task
def test_Task_get_name():
    
    # test variables for this method
    task_0 = Task()
    task_1 = Task()
    task_1_name = "a_task"
    
    
    # test code for this method
    task_0.get_name()
    task_1.name = task_1_name
    task_1.get_name()


# Generated at 2022-06-25 06:19:44.605956
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()

    assert not isinstance(task_1.get_vars(), list)
    #assert isinstance(task.get_vars(), dict)


# Generated at 2022-06-25 06:19:54.166044
# Unit test for method get_name of class Task
def test_Task_get_name():
    from ansible_collections.cisco.aci.plugins.module_utils.aci import ACIModule
    from ansible.module_utils.six import PY3
    task_name = "the task name"

    if PY3:
        task_action = "cisco.aci.aci"
        task_module_utils = ACIModule
    else:
        task_action = "aci"
        task_module_utils = "cisco.aci.aci"

    task = Task()
    task.action = task_action
    task.module_utils = task_module_utils
    task._attributes["name"] = task_name
    assert task.get_name() == task_name

# Generated at 2022-06-25 06:20:04.604422
# Unit test for method deserialize of class Task

# Generated at 2022-06-25 06:20:15.508383
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert '<task' in task_0.__repr__()


# Generated at 2022-06-25 06:20:27.862435
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task

# Generated at 2022-06-25 06:20:31.566864
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    print("TEST CASE 0")
    test_case_0()

if __name__ == "__main__":
    test_Task_get_include_params()

# Generated at 2022-06-25 06:20:34.132581
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_1 = Task()
    assert(task_1.get_include_params() == {})

# Generated at 2022-06-25 06:20:46.034601
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_0 = Task()
    data_0 = {"action": 1}
    local_action_0 = 1
    data_0["action"] = local_action_0
    args_0 = 0
    data_0["args"] = args_0
    delegate_to_0 = 5
    data_0["delegate_to"] = delegate_to_0
    tags_0 = 6
    data_0["tags"] = tags_0
    ignore_errors_0 = 1
    data_0["ignore_errors"] = ignore_errors_0
    register_0 = 7
    data_0["register"] = register_0
    until_0 = 8
    data_0["until"]

# Generated at 2022-06-25 06:20:51.365469
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_case_0()

###############################################
#
# TEST CASE:
#
# - Task class
# - method serialize
#
###############################################


# Generated at 2022-06-25 06:21:02.342674
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Create a task and set its required attributes
    task = Task()
    task.action = 'test'
    task.args = dict(test=1)
    # Create an AnsibleVariableManager object
    variable_manager = AnsibleVariableManager()
    # Create an AnsibleLoader object
    loader = DataLoader()
    variable_manager = AnsibleVariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))
    # Create the task by calling the method preprocess_data
    task.preprocess_data(data=dict(action='test', args={'test': 1}), variable_manager=variable_manager, loader=loader)
    assert task.action == 'test'
    assert task.args == dict(test=1)

# Generated at 2022-06-25 06:21:14.168741
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import HandlerTaskInclude

    class TestClass:
        def test_case_0(self):
            task_0 = Task()
            res = task_0.get_include_params()
            assert res, 'An error occurred while processing include params'

        def test_case_1(self):
            task_0 = Task()
            task_0.vars = {}
            res = task_0.get_include_params()
            assert res, 'An error occurred while processing include params'

        def test_case_2(self):
            task_0 = TaskInclude()
            task_0.vars = {}
            res = task_0.get_include_params()

# Generated at 2022-06-25 06:21:24.351243
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()

    class FakeActionPlugins(object):
        def __init__(self):
            self.static_vars = {'foo': 'bar'}

    def setup_module(self):
        self.task.action = 'fake'
        self.task._action_plugin = FakeActionPlugins()

    def test_get_include_params(self):
        self.task.vars = {'one': 'two', 'three': 'four'}
        self.assertEqual({'one': 'two', 'three': 'four', 'foo': 'bar'}, self.task.get_include_params())

        self.task.vars = {'foo': 'buh'}
        self.assertEqual({'foo': 'buh'}, self.task.get_include_params())


# Generated at 2022-06-25 06:21:27.155560
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()
    # Create variables for method get_vars()
    expected_result = {}
    result = task_1.get_vars()
    # Test for equality
    assert result == expected_result


# Generated at 2022-06-25 06:21:47.491270
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # define a task
    task_0 = Task()
    # define a role
    role_0 = Role()
    role_0.name = "r0"
    role_0.hosts = "rhost"
    role_0.vars = {"r0_var": "r0_value"}
    # define a block
    block_0 = Block()
    block_0.vars = {"b0_var": "b0_value"}
    # define a play
    play_0 = Play()
    play_0.name = "p0"
    play_0.hosts = "phost"
    play_0.vars = {"p0_var": "p0_value"}
    play_0._included_file = "/path/to/file"

    # Assign role_0 to task_0


# Generated at 2022-06-25 06:21:53.059831
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Test empty object
    task_0 = Task()
    assert task_0.preprocess_data({}) == {}

    # Test with not None argument
    task_1 = Task()
    assert type(task_1.preprocess_data({'action': {'module': 'meta', '_raw_params': 'refresh_inventory'}})) == dict


# Generated at 2022-06-25 06:21:57.450042
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    # Test if method returns the 'vars' specified in the task
    assert task_0.get_include_params() == task_0.vars
    # Test the return value if there is an implicit parent
    task_0 = Task()
    parent = MagicMock()
    parent.get_include_params.return_value = {"x": "abc", "a": "123"}
    task_0._parent = parent
    assert task_0.get_include_params() == {"x": "abc", "a": "123"}

# Generated at 2022-06-25 06:21:59.797208
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test_case_0()

# Generated at 2022-06-25 06:22:09.984583
# Unit test for method serialize of class Task
def test_Task_serialize():
    # set up
    task_0 = Task()
    task_0._attributes['action'] = 'action'
    task_0._attributes['name'] = 'name'
    task_0._attributes['tags'] = 'tags'
    task_0._attributes['when'] = 'when'
    task_0._attributes['register'] = 'register'
    task_0._attributes['ignore_errors'] = 'ignore_errors'
    task_0._attributes['delegate_to'] = 'delegate_to'
    task_0._attributes['delegate_facts'] = 'delegate_facts'
    task_0._attributes['vars'] = 'vars'
    task_0._attributes['with_dict'] = 'with_dict'

# Generated at 2022-06-25 06:22:21.424993
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Init variables
    ds = dict()
    # task_1 is a Task.
    task_1 = Task()
    # variable_manager_2 is a VariableManager.
    variable_manager_2 = VariableManager()

    # Args to test function
    # task_1.
    # variable_manager_2.

    # Start test
    import textwrap
    t = textwrap.dedent('''
        ---
        tasks:
        - foo:
            bar: x
            bu: y
        vars:
          echo: xyz
    ''')
    t = [t]
    loader = DataLoader()
    inv_source = InventorySource('/dev/null')
    inv = Inventory(loader, variable_manager_2, inv_source)

# Generated at 2022-06-25 06:22:32.899546
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    role_1 = Role()
    block_1 = Block()

    # test case 1
    task_1.preprocess_data(dict(action=dict(module="copy")))
    assert task_1.action == "copy"

    # test case 2
    task_1.preprocess_data(dict(action=dict(module="copy", args=dict(src="/file/source", dest="/file/dest"))))
    assert task_1.args.get("src") == "/file/source"
    assert task_1.args.get("dest") == "/file/dest"

    # test case 3
    task_1.preprocess_data(dict(action=dict(module="copy", args=dict(src="/file/source", dest="/file/dest"))))

# Generated at 2022-06-25 06:22:38.282090
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    #tasks = []
    #task_0 = Task()

    #print("task_0 is %r" % task_0)

    #assert task_0.__repr__() is not None
    assert True


# Generated at 2022-06-25 06:22:48.257768
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-25 06:22:54.306556
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    input_data = {
        'action': 'vars',
        'args': {
            'foo': 'value',
        },
        'deprecated': 'do not use'
    }

    expected_output = {
        'action': 'vars',
        'args': {
            'foo': 'value',
        },
    }

    task.preprocess_data(input_data)
    assert task.serialize() == expected_output


# Generated at 2022-06-25 06:23:28.597176
# Unit test for method get_name of class Task
def test_Task_get_name():
    dict_ = dict(name="test_task_0", action=dict())
    task_0 = Task(task_ds=dict_)
    assert task_0.get_name() == "test_task_0"


# Generated at 2022-06-25 06:23:32.969273
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    task_0 = Task()
    block = Block()
    task = Task()
    include = TaskInclude()
    task.role = Role()
    include.task = task
    block.role = Role()
    block.block=[include, task_0]
    task_0._parent = block
    task_0.get_first_parent_include()


# Generated at 2022-06-25 06:23:34.233811
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task.name = 'display_name'
    task.__repr__()



# Generated at 2022-06-25 06:23:46.098849
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import RoleTask
    from ansible.playbook.block import Block
    import pytest

    # Note that the first parent of RoleTask is a Block
    # and the parent of Block is a Role.
    role = Role()
    block = Block()
    role_task = RoleTask()
    task_include = TaskInclude()
    role.task_blocks = [block]
    block.block = [role_task]
    role_task._parent = block
    block._parent = role
    task_include._parent = None

    # First parent of RoleTask is a Block
    task = role_task
    assert task.get_first_parent_include() is None

    #

# Generated at 2022-06-25 06:23:48.533436
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    assert repr(task).startswith('TASK')


# Generated at 2022-06-25 06:23:50.179898
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    task_1.deserialize({})


# Generated at 2022-06-25 06:24:00.122861
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    parent_data = {
        'action': 'include_tasks',
        'name': '../../../../../../../../../../../../../etc/passwd',
        'loop': '{{ ansible_play_hosts }}'
    }

    parent_type = 'TaskInclude'
    try:
        p = TaskInclude()
        p.deserialize(parent_data)
        task_1._parent = p
    except Exception as e:
        raise e

    role_data = None

    task_1.implicit = True
    task_1.resolved_action = None


# Generated at 2022-06-25 06:24:05.680067
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task()
    expected_result_1 = "Task"
    actual_result_1 = task_1.__repr__()
    assert actual_result_1 == expected_result_1


# Generated at 2022-06-25 06:24:14.475718
# Unit test for method deserialize of class Task

# Generated at 2022-06-25 06:24:26.429973
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0_0_0 = Task()
    task_0_0_1 = Task()
    task_0_1_0 = Task()
    task_0_1_1 = Task()

    task_0_0_1._parent = task_0_0_0
    task_0_1_1._parent = task_0_1_0

    task_0_0_0._parent = task_0_0_0
    task_0_1_0._parent = task_0_0_0

    task_0_0_1.resolved_action = 'action_0'
    task_0_0_0.resolved_action = '{{action_1}}'
    task_0_1_0.resolved_action = 'action_2'
    task_0_1_1.resolved_action

# Generated at 2022-06-25 06:24:49.900809
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    #Setting up test values

    task_0 = Task()
    templar = Templar(loader=None)
    templar.environment = Environment()
    ds = {}
    new_ds = {}
    templar.set_available_variables(ds)
    test_result = task_0._get_parent_attribute('tags')
    assert test_result == Sentinel
    test_result = task_0._post_validate_vars(attr = 'vars', value = None, templar = templar)
    test_result = task_0._post_validate_action(attr = 'action', value = None, templar = templar)
    test_result = task_0._post_validate_local_action(attr = 'local_action', value = None, templar = templar)


# Generated at 2022-06-25 06:25:00.182519
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    print(Task.get_vars.__doc__)
    print('\n\n')

    # Test case 1:
    task_1 = Task()
    task_1.vars = {'k_1': 'v_1'}

    # Expected result:
    expected_result_1 = {'k_1': 'v_1'}

    # Actual result:
    actual_result_1 = task_1.get_vars()

    if expected_result_1 == actual_result_1:
        print('Test case 1 passed: get_vars() method works properly')
    else:
        print('Test case 1 failed: get_vars() method does not work properly')

    print('\n\n')

    # Test case 2:
    task_2 = Task()
    task_2._parent = Block

# Generated at 2022-06-25 06:25:12.048270
# Unit test for method deserialize of class Task

# Generated at 2022-06-25 06:25:17.441660
# Unit test for method get_name of class Task
def test_Task_get_name():
    print("\n\n########### Unit test for method get_name of class Task ############\n")
    name = "The task"
    task_0 = Task()
    task_0._attributes['name'] = name
    print("Test get_name method in Task class: The name of task is: " + task_0.name)


# Generated at 2022-06-25 06:25:22.778088
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    print('Testing Task.__repr__')
    task_0 = Task()
    assert repr(task_0) == '<Task()>'

# Generated at 2022-06-25 06:25:24.391358
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    assert(task.get_name() == 'None')


# Generated at 2022-06-25 06:25:27.080587
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    '''test_Task_deserialize'''

    task_0 = Task()
    assert task_0.deserialize(data=None) is False


# Generated at 2022-06-25 06:25:28.495367
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0.post_validate()



# Generated at 2022-06-25 06:25:39.447392
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Test for default value for member '_attributes'
    task = Task()
    task.deserialize({'action': 'ping', 'name': 'ping'})
    assert task.action == 'ping'
    assert task.name == 'ping'
    assert task._attributes == dict()
    assert task._parent is None
    assert task._role is None
    assert task.tags == list()
    assert task.when == list()
    assert task.resolved_action is None
    assert task.implicit is False
    # Test for value for member '_attributes'
    task = Task()
    task.deserialize({'action': 'ping', 'name': 'ping', 'tags': ['rhel']})
    assert task.action == 'ping'
    assert task.name == 'ping'

# Generated at 2022-06-25 06:25:44.611049
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    x = Task()
    v = yaml.load("""action: command
args:
  warn: false
  executable: /usr/bin/python
  chdir: /home/user/demo
  _raw_params: python setup.py test
delegate_to: localhost
""", Loader=yaml.SafeLoader)
    x.deserialize(v)
