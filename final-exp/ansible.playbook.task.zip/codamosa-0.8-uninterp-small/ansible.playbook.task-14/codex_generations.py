

# Generated at 2022-06-25 06:16:28.461466
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    ansible = Ansible()

    t = Task()
    t.deserialize({'action': 'setup', 'tags': ['test', 'setup'], 'when': 'setup'})

    assert t.action == 'setup'
    assert t.tags == ['test', 'setup']
    assert t.when == 'setup'
    assert t.resolved_action == 'setup'

    t = Handler()
    t.deserialize({'action': 'setup', 'tags': ['test', 'setup'], 'when': 'setup', 'notify_list': ['test_notify']})

    assert t.action == 'setup'
    assert t.tags == ['test', 'setup']
    assert t.when == 'setup'
    assert t.resolved_action == 'setup'

# Generated at 2022-06-25 06:16:36.794981
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # define an instance of task class
    task_1 = Task()
    # define an instance of VaultSecret class
    vault_secret_1 = VaultSecret()
    # set vault secret class to task class
    task_1.set_vault_secrets([vault_secret_1])

    # define an instance of System class
    system_1 = system()
    # define plugin loader
    plugin_loader_1 = system_1.get_plugin_loader()
    # define action plugin loader
    action_plugin_loader_1 = plugin_loader_1.get('action_loader')
    # define connection plugin loader
    connection_plugin_loader_1 = plugin_loader_1.get('connection_loader')
    # define lookup plugin loader
    lookup_plugin_loader_1 = plugin_loader_1.get('lookup_loader')
   

# Generated at 2022-06-25 06:16:40.236383
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    task_1.preprocess_data(dict(action=dict(module='my_module', foo='bar')))


# Generated at 2022-06-25 06:16:44.937424
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0._parent = Mock()
    task_0._parent.get_vars = Mock(return_value = {})
    task_0.vars = {'ansible_version': '2.4.1.0',
                   'ansible_facts_modified': {'ansible_all_ipv4_addresses': ['192.168.138.1', '127.0.0.1', '192.168.100.10']}}

    result = task_0.get_vars()

    assert result == task_0.vars


# Generated at 2022-06-25 06:16:49.687020
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_deserialize_0 = Task()
    if isinstance(task_deserialize_0, Base):
        if hasattr(task_deserialize_0, 'deserialize'):
            task_deserialize_0_deserialize = getattr(task_deserialize_0, 'deserialize')
            assert_true(callable(task_deserialize_0_deserialize))


# Generated at 2022-06-25 06:16:54.933372
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    try:
        task_0.preprocess_data('dummy_data')
    except Exception as ex:
        assert type(ex).__name__ == 'AnsibleParserError'
    else:
        raise Exception('AnsibleParserError not thrown')


# Generated at 2022-06-25 06:16:57.630232
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.action = 'shell'
    task.action = 'setup'
    task.local_action = 'setup'
    task.local_action = 'shell'


# Generated at 2022-06-25 06:17:06.700749
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task0 = Task()
    task0.deserialize({"action": "test_action", "name": "test_name", "implicit": True, "resolved_action": "test_action"})
    assert task0.action == "test_action", "test failed"
    assert task0.name == "test_name", "test failed"
    assert task0.implicit == True, "test failed"
    assert task0.resolved_action == "test_action", "test failed"


# Generated at 2022-06-25 06:17:09.309329
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task_ds = dict(name='test',
                   vars=dict(test_var=1),
                   action='test',
                   test=dict(test_test=2),
                   anything_else=3)
    task.load(task_ds, variable_manager=None, loader=None)
    task.preprocess_data()


# Generated at 2022-06-25 06:17:12.208874
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    try:
        task_1.preprocess_data({'action': 'dummy_action'})
    except Exception as e:
        return

    # Sorry, but you've got an error, task_1 is not empty after preprocess_data



# Generated at 2022-06-25 06:17:36.280070
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # This test case verifies that the get_include_params method returns a dictionary
    # when the action is either import_playbook, include_playbook and import_tasks
    task_0 = Task()
    task_0.action = "include_playbook"
    task_0.vars = {"foo": "bar"}
    include_params = task_0.get_include_params()
    assert include_params == task_0.vars
    task_0.action = "import_playbook"
    task_0.vars = {"foo": "bar"}
    include_params = task_0.get_include_params()
    assert include_params == task_0.vars
    task_0.action = "import_tasks"
    task_0.vars = {"foo": "bar"}

# Generated at 2022-06-25 06:17:38.951122
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task()
    assert repr(task_1) == 'Task(name=None)'



# Generated at 2022-06-25 06:17:49.219336
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    test = Task()

# Generated at 2022-06-25 06:17:58.584505
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()

# Generated at 2022-06-25 06:18:04.752569
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()

    # Test with valid input
    test_data = {'action':'shell', 'args':'ls -al', 'delegate_to':'localhost', 'title':'unittest', 'tags':['test', 'unit']}
    task_0.post_validate({"host": "hostname", "connection": "local", "vars": {"var_0": "foo"}}, task_0.post_validate, test_data)


# Generated at 2022-06-25 06:18:14.624089
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    #importing TaskInclude and HandlerTaskInclude here to avoid import loops
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    #Creating a task tree for testing
    task_0 = Task()
    task_0.action = 'setup'
    task_0.resolved_action = 'setup'
    task_0.async_val = -1
    task_0.async_seconds = 1800
    task_0.block = None

    task_include_0 = TaskInclude()
    task_include_0._parent = task_0
    task_include_0.statically_loaded = True
    task_include_0.action = 'include'
    task_include_0.args = dict()
    task_include_0

# Generated at 2022-06-25 06:18:19.516876
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_2 = Task()
    task_2.action='include_role'
    task_2.vars={'role_name': 'abc'}
    task_2.get_include_params()
    print("-----------test_Task_get_include_params------------")
    print(task_2.get_include_params())
    print("-----------test_Task_get_include_params------------")

if __name__ == '__main__':
    test_case_0()
    test_Task_get_include_params()

# Generated at 2022-06-25 06:18:26.242946
# Unit test for method get_name of class Task
def test_Task_get_name():
    # setup
    task_name = "test"
    task_object = Task(name=task_name)

    # result
    result = task_object.get_name()

    # verify
    assert task_name == result


# Generated at 2022-06-25 06:18:35.091282
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test if the method preprocess_data() raises an AnsibleAssertionError if the task does not have a name.
    task_0 = Task()
    task_0.name = None
    with pytest.raises(AnsibleAssertionError) as excinfo:
        task_0.preprocess_data({})
    assert "preprocess_data() is being called without a valid name" in str(excinfo.value)


    # Test if the method preprocess_data() returns a dict.
    # Test if the method preprocess_data() returns an empty dict with input ds = {}
    task_0 = Task()
    task_0.name = "Print a message"
    assert isinstance(task_0.preprocess_data({}), dict)
    assert task_0.preprocess_data({}) == {}

   

# Generated at 2022-06-25 06:18:43.229843
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    parent_data = {'serialized_data': 'serialized_data', 'vars': {}}
    data = {'action': 'setup', 'serialized_data': 'serialized_data', 'parent_type': 'Block', 'parent': parent_data, 'role': {}, 'resolved_action': 'setup', 'implicit': False, 'name': 'setup', 'vars': {}, 'when': 'True', 'block': {}, 'block_launch_errors': 'block_launch_errors', 'start': 'start', 'loop': 'loop', 'loop_control': {'index_var': 'my_item', 'loop_var': 'my_list'}}

    task_0.deserialize(data)
    assert task_0.serialize() == data


# Generated at 2022-06-25 06:19:11.865126
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    task_0.action = 'set_fact'

    task_0.vars = dict()
    task_0.vars['item1'] = 'value'
    task_0.vars['item2'] = 'value'
    task_0.vars['item3'] = 'value'
    task_0.vars['item4'] = 'value'

    task_0.vars['item5'] = 'value'
    task_0.vars['item6'] = 'value'
    task_0.vars['item7'] = 'value'
    task_0.vars['item8'] = 'value'

    task_0.vars['item9'] = 'value'
    task_0.vars['item10'] = 'value'
    task_0.vars

# Generated at 2022-06-25 06:19:14.607396
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    repr = task_0.__repr__()
    assert repr == "TASK: test_case_0 [not_a_real_name]"


# Generated at 2022-06-25 06:19:20.923301
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    test_case = "task_post_validate"

    # Load test fixtures
    # Setup fake task ds
    task_ds = dict(
        name="test_task_post_validate",
        action="shell",
        args="echo 'Hello Ansible!'",
        until="echo 'Bye!'",
        changed_when="echo 'Hello Ansible!' | grep 'Hello Ansible!'",
        fail="echo 'Bye!' | grep 'Hello Ansible!'",
        loop="{{ test_loop_items }}",
        loop_control="echo '{{ item }}'",
        loop_args="echo '{{ item }}'",
        vars="{{ test_var }}"
    )
    task_0 = Task()

    # Test post_validate
    task_0._validate_loop = Mock()
    task_0._

# Generated at 2022-06-25 06:19:25.132613
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Create an instance of Task
    task_0 = Task()

    # Verify if the method __repr__ of the class Task returns a string
    if not isinstance(task_0.__repr__(), str):
        raise Exception('Method __repr__ of class Task does not return a string')


# Generated at 2022-06-25 06:19:28.011873
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_2 = Task(action="ping", args={})
    repr_value = repr(task_2)
    assert repr_value == "Task(action='ping', args={})"


# Generated at 2022-06-25 06:19:35.267746
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_1 = Task()
    task_1.action = 'setup'
    task_2 = Task()
    task_2.action = 'debug'
    task_1._role = task_2
    # TODO: Fix serializer, not working
    #assert task_1.serialize() == dict([('action', 'debug'), ('task_0', dict([('action', 'debug'), ('task_1', dict([('action', 'setup')]))]))])

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 06:19:38.442044
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    expected_result = "Task(action:{},loop:{},pause:{},when:{})".format(task_0.action,task_0.loop,task_0.pause,task_0.when)
    assert expected_result == task_0.__repr__()

# Generated at 2022-06-25 06:19:43.486534
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_1 = Task()
    task_2 = Task()
    task_1.vars = dict(test_1=1)
    task_2.vars = dict(test_2=2)
    task_1.set_loader(object)
    task_2.set_loader(object)
    task_2._parent = task_1
    assert task_2.get_include_params() == dict(test_1=1)

# Generated at 2022-06-25 06:19:48.522094
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.preprocess_data({'loop': 'localhost', 'name': "dummy task"})


# Generated at 2022-06-25 06:19:53.327587
# Unit test for method get_vars of class Task
def test_Task_get_vars():

    # Reset static variables for test
    Task._squashed = False
    Task._finalized = False

    task_0 = Task()
    # call get_vars of method Task
    task_0.get_vars()


# Generated at 2022-06-25 06:20:13.907425
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    empty_ds = dict(
        action="include_tasks",
        args=dict(
            tasks=["/etc/ansible/tasks/foo.yml"]
        )
    )
    empty_host = Host()
    empty_vars = VariableManager()
    empty_t = Task.load(ds=empty_ds, block=None, role=None, task_include=None, use_handlers=True, variable_manager=empty_vars, loader=None)

    assert empty_t.get_include_params() == {}


# Generated at 2022-06-25 06:20:15.459184
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    assert(task_0.post_validate() != None)

# Generated at 2022-06-25 06:20:25.782738
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Initialize test variables
    task = Task()
    task._valid_attrs = {
        'foo': Attribute(),
    }
    task._attributes = {
        'foo': 'bar',
    }
    templar = MagicMock()
    templar.template.return_value = 'baz'
    # Execute code under test
    task.post_validate(templar)
    # Verify attributes
    assert task._attributes['foo'] == 'baz'


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 06:20:26.906791
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    test_case_0()


# Generated at 2022-06-25 06:20:38.411154
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    # Create a task that extends task_0
    task_1 = Task()

    # Create a task that extends task_1
    task_2 = Task()

    # Setup chain of parent tasks
    # task_2 -> task_1 -> task_0
    task_2._parent = task_1
    task_1._parent = task_0

    task_0_vars =  {'name': 'value', 'key': 'value1'}
    task_1_vars = {'name': 'value', 'key': 'value1', 'action': 'shell', 'ignore_errors': False, 'become': False, 'become_user': 'root'}

# Generated at 2022-06-25 06:20:44.422280
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    ################################################################################################################################
    # Preprocessing task data
    ################################################################################################################################
    ################################################################################################################################
    # 1.
    ################################################################################################################################
    task_1 = Task()
    d1 = dict()
    d1['role'] = 'foobar'
    d1['include_role'] = 'foobar'
    d1['include'] = 'foobar'
    d1['import_tasks'] = 'foobar'
    d1['import_playbook'] = 'foobar'
    d1['import_role'] = 'foobar'
    d1['vars'] = 'foobar'
    d1['vars_files'] = 'foobar'
    d1['include_vars'] = 'foobar'

# Generated at 2022-06-25 06:20:54.886463
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Create instance of class Task
    task_0 = Task()
    # Create instance of class Role
    role_0 = Role()
    # Create instance of class Play
    play_0 = Play()
    # Create instance of class Play
    play_1 = Play()
    # Create instance of class PlayContext with default parameters
    context_0 = PlayContext()
    # Create instance of class PlayContext with default parameters
    context_1 = PlayContext()
    # Create instance of class PlayContext with default parameters
    context_2 = PlayContext()
    # Create instance of class PlayContext with default parameters
    context_3 = PlayContext()
    # Create instance of class TaskInclude with default parameters
    task_include_0 = TaskInclude()
    # Create instance of class TaskInclude with default parameters
    task_include_1 = TaskInclude()
   

# Generated at 2022-06-25 06:20:57.927607
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_0.name = 'I am a task'

    assert task_0.get_name() == 'I am a task'


# Generated at 2022-06-25 06:21:05.698797
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    ################################################################################
    #Test for specified task and parent
    ################################################################################
    #Test that task is returned when no parent
    task_0 = Task()
    task_0.__dict__['_parent'] = None
    if task_0.get_first_parent_include() is not None:
        raise AssertionError()

    #Test that parent is returned when parent is not of type TaskInclude
    task_1 = Task()
    task_1.__dict__['_parent'] = object()
    if task_1.get_first_parent_include() is not None:
        raise AssertionError()

    #Test that parent is returned when parent is of type TaskInclude
    task_2 = Task()
    task_2.__dict__['_parent'] = TaskInclude()

# Generated at 2022-06-25 06:21:07.858168
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # instantiate task object
    task_obj = Task()

    # use get_vars() method
    task_obj.get_vars()


if __name__ == "__main__":
    test_case_0()
    test_Task_get_vars()

# Generated at 2022-06-25 06:21:26.413476
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.attribute_class = TaskAttribute

# Generated at 2022-06-25 06:21:31.856618
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    tp = Task()

# Generated at 2022-06-25 06:21:36.449628
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_1 = Task()
    assert(task_1.post_validate == Task.post_validate)

    templar = Task()
    task_1.post_validate(templar)

# Generated at 2022-06-25 06:21:46.886284
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Setup test
    task_0 = Task()
    task_0.vars = {'tags': 'foo', 'when': 'bar'}
    task_1 = Task()
    task_1.vars = {'tags': 'foo', 'when': 'bar'}
    task_0.parents = [task_1]
    task_1.vars = {'tags': 'foo', 'when': 'bar'}
    task_0.parents = [task_1]
    task_0.vars = {'tags': 'foo', 'when': 'bar'}
    task_0._final_done = False

    # Invoke method
    all_vars = task_0.get_vars()

    # Check result
    assert all_vars == {'tags': 'foo', 'when': 'bar'}


# Generated at 2022-06-25 06:21:49.059826
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Get an instance of task
    task_1 = Task()

    # Test get_include_params of the instance
    task_1.get_include_params()


# Generated at 2022-06-25 06:21:55.182934
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    host1 = Host()
    host2 = Host()

    # set up the host objects
    host1.name = 'host1'
    host1.build_group_variables()
    host1.vars = dict(a=10)

    host2.name = 'host2'
    host2.build_group_variables()
    host2.vars = dict(b=20)

    # prepare a role
    role = Role()
    role.name = 'role'
    role.build_role_data()
    role.vars = dict(c=30)

    loop_terms = [dict(a=1), dict(a=2)]

    # test a simple task without loop, delegate_to, and role

# Generated at 2022-06-25 06:22:00.424255
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    task_1.preprocess_data(dict(name='name_1'))
    assert task_1.name == 'name_1'

    task_1.preprocess_data(dict(name='name_2'))
    assert task_1.name == 'name_2'

    assert task_1.action is None
    task_1.preprocess_data(dict(action='action_1'))
    assert task_1.action == 'action_1'

    assert task_1.local_action is None
    task_1.preprocess_data(dict(local_action='local_action_1'))
    assert task_1.local_action == 'local_action_1'

    assert task_1.args is None

# Generated at 2022-06-25 06:22:10.331810
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_1 = Task()
    assert task_1.get_first_parent_include() is None

    task_2 = Task()
    from ansible.playbook.task_include import TaskInclude
    include_1 = TaskInclude()
    task_2._parent = include_1
    assert task_2.get_first_parent_include() is include_1

    task_3 = Task()
    include_2 = TaskInclude()
    task_3._parent = include_2

    task_4 = Task()
    include_3 = TaskInclude()
    task_4._parent = include_3
    task_3._parent = task_4

    assert task_3.get_first_parent_include() is include_2

    task_5 = Task()
    include_4 = TaskInclude()
    task_5

# Generated at 2022-06-25 06:22:21.703239
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Using the dict:
    # {'name': 'foo', 'action': 'ping', 'loop': '{{test_items}}'}
    #
    # The task should look like this after preprocessing:
    # {'loop': ['a', 'b', 'c', 'd'], 'name': 'foo', 'action': 'ping', '_uses_delegate': False, '_raw_params': '', '_uses_shell': False, '_uses_become': False, '_uses_sudo': False, '_uses_no_log': False, '_always_run': False, '_uses_async': False}
    test_dict = {'name': 'foo', 'action': 'ping', 'loop': '{{test_items}}'}

    # Setup a variables manager to process the test data
    # Note: using D

# Generated at 2022-06-25 06:22:26.122374
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    # Method get_name of class Task should return a string
    assert isinstance(task_0.get_name(), str)


# Generated at 2022-06-25 06:22:38.819355
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    expected_value = "Task(name=None, action=None, use_role_defaults=False)"
    actual_value = task_0.__repr__()
    assert actual_value == expected_value

# Generated at 2022-06-25 06:22:40.542667
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    try:
        task_0.preprocess_data({})
    except:
        pass


# Generated at 2022-06-25 06:22:43.355909
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    res_0 = repr(task_0)
    assert_equal(type(res_0), str)


# Generated at 2022-06-25 06:22:47.398367
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    data = {'name': 'test_task', 'when': 'False'}
    task_0.preprocess_data(data)
    assert task_0.when == 'False'
    assert task_0.name == 'test_task'


# Generated at 2022-06-25 06:22:54.538186
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    data = {}
    data[u'action'] = 'debug: msg="This is a test"'
    data[u'async'] = 2
    data[u'async_status_interval'] = 1.0
    data[u'changed_when'] = 'False'
    data[u'connection'] = 'ssh'
    data[u'debugger_enabled'] = True
    data[u'delegate_to'] = 'targethost'
    data[u'delegate_facts'] = True
    data[u'dependencies'] = ['services_installed', 'packages_installed', 'time_synced']
    data[u'environment'] = '{{ environment_vars }}'
    data[u'failed_when'] = 'False'
    data[u'free_form'] = True


# Generated at 2022-06-25 06:22:58.393963
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Create a simple task
    task = Task()

    # Get the vars from the task
    vars = task.get_vars()

    # Test the result
    assert vars == dict(), 'The vars are not an empty dictionary'


# Generated at 2022-06-25 06:23:01.475407
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    assert task_0.get_first_parent_include() == None, "Return value of get_first_parent_include() is not:None"


# Generated at 2022-06-25 06:23:08.936123
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_1 = Task()
    task_2 = Task()
    task_1.deserialize({'action': 'setup'})
    assert task_1.serialize() == {'action': 'setup'}
    task_1.deserialize({'action': 'setup', 'name': 'gathering facts'})
    assert task_1.serialize() == {'action': 'setup', 'name': 'gathering facts'}

if __name__ == '__main__':
    test_case_0()
    test_Task_serialize()
    print('Run test cases successfully')

# Generated at 2022-06-25 06:23:13.827144
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    ds = '''
        - debug:
            msg: "test"
            var1: "test1"
        - debug:
            msg: "test2"
      '''
    new_ds = task_0.preprocess_data(ds)
    assert new_ds == {'var1': 'test1', 'msg': 'test'}



# Generated at 2022-06-25 06:23:20.362197
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Not using parent, task name is None,
    # expected_result = {}
    task_0 = Task()
    print(task_0._attributes)
    # task_0._name = "Play"
    # expected_result = {}
    # assert task_0.get_vars() == expected_result
    # assert task_0.get_vars() == {'name': 'Play'}


if __name__ == '__main__':
    test_Task_get_vars()

# Generated at 2022-06-25 06:23:36.170353
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    """
    Test get_first_parent_include
    """
    task_0 = Task()
    task_1 = Task()
    task_1.line_number = 5
    task_2 = Task()
    task_2.line_number = 10
    task_0.parent = task_1
    task_1.parent = task_2
    res = task_0.get_first_parent_include()
    assert res, "Task does not have a parent TaskInclude"
    assert res.line_number == task_1.line_number, "TaskInclude has not the expected line number"


# Generated at 2022-06-25 06:23:48.007169
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    loop_var_name = "hostvars"
    loop_var_value = "{{ hostvars }}"
    task_0 = Task()
    ds = dict()

    # subject 1
    ds['with_items'] = loop_var_value
    new_ds = task_0._preprocess_with_loop(ds, dict(), loop_var_name, loop_var_value)
    assert len(new_ds) == 2
    assert 'with_items' in new_ds
    assert new_ds['with_items'] == loop_var_value
    assert 'loop_control' in new_ds
    assert new_ds['loop_control']['loop_var'] == loop_var_name
    assert new_ds['loop_control']['loop_var_value'] == loop_var_value

    # subject

# Generated at 2022-06-25 06:23:51.226529
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    try:
        task_0.__repr__()
    except Exception as err:
        print("Test case 0: Fail")
        print("Error: " + str(err))
    else:
        print("Test case 0: Success")


# Generated at 2022-06-25 06:23:54.798692
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()
    result_1 = task_1.get_vars()
    assert not result_1


# Generated at 2022-06-25 06:24:01.443957
# Unit test for method get_include_params of class Task

# Generated at 2022-06-25 06:24:11.032240
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:24:16.829892
# Unit test for method serialize of class Task
def test_Task_serialize():
    '''
    Unit test for method serialize of class Task
    '''
    data = dict()
    data["action"] = "shell"
    data["name"] = "mytask"
    data["_ansible_no_log"] = False
    data["_ansible_check_mode"] = False
    data["_ansible_diff"] = False
    data["_ansible_verbosity"] = 0

    task_0 = Task()
    task_0.deserialize(data)
    task_0.serialize()


# Generated at 2022-06-25 06:24:23.038472
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Return Value.
    return_value = 'testReturnValue'
    # Create a Task object
    task_1 = Task()
    # Set class attribute vars with the return value
    task_1.vars = return_value

    # Return task_1.get_vars()
    return task_1.get_vars()


# Generated at 2022-06-25 06:24:29.630145
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    data = {'action': 'ping', 'args': {'_raw_params': 'localhost', '_uses_shell': False, '_raw_args': 'localhost'}, 'changed_when': None, 'delegate_to': 'localhost', 'environment': None, 'failed_when': None, 'loop': None, 'loop_control': {'loop_var': 'item'}, 'name': 'ping', 'register': 'ping_result', 'until': None, 'vars': {'ansible_python_interpreter': '/usr/bin/python3'}, 'when': 'inventory_hostname in groups["localhost"]'}
    task_0.deserialize(data)


# Generated at 2022-06-25 06:24:37.231164
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    task_1.static_load(dict(action=dict(module='shell', args='ls')))

    assert isinstance(task_1.action, dict)
    assert task_1.action['module'] == 'shell'
    assert task_1.action.get('args') == 'ls'

    # FIXME: test with_
    # FIXME: test when

    task_2 = Task()
    task_2.static_load(dict(action=dict(module='shell', args='ls')))

    assert isinstance(task_2.action, dict)
    assert task_2.action['module'] == 'shell'
    assert task_2.action.get('args') == 'ls'

    # FIXME: test with_
    # FIXME: test when


# Generated at 2022-06-25 06:25:20.737251
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    obj_task_0 = Task()
    obj_task_1 = Task()

    task_ds_0 = {'local_action': 'ping', 'action': 'ping', 'local_action': 'ping', 'action': 'ping', u'name': u'ping', 'shell': 'ping', 'command': 'ping', 'args': {}, 'any_errors_fatal': False, 'ignore_errors': 'no'}
    task_ds_1 = {'local_action': 'ping', 'action': 'ping', 'local_action': 'ping', 'action': 'ping', u'name': u'ping', 'shell': 'ping', 'command': 'ping', 'args': {}, 'any_errors_fatal': False, 'ignore_errors': 'no'}


# Generated at 2022-06-25 06:25:23.796207
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    assert task_0.__repr__() == '<Task(task_0)>'


# Method called by the unit test assertion below

# Generated at 2022-06-25 06:25:32.482753
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Load a task from yaml
    task_0 = Task.load(dict(action=dict(module='ping')))

    # Verify preprocess_data method
    ret = task_0.preprocess_data(dict(action=dict(module='ping')))
    assert ret == {'action': {'module': 'ping'},
                   'args': {},
                   'delegate_to': None}

    # Load a task from dict
    task_1 = Task(action=dict(module='ping'))

    # Verify preprocess_data method
    ret = task_1.preprocess_data(dict(action=dict(module='ping')))
    assert ret == {'action': {'module': 'ping'},
                   'args': {},
                   'delegate_to': None}


# Generated at 2022-06-25 06:25:41.398424
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()
    assert len(task.get_vars()) == 0

    block = Block()
    task._parent = block
    assert len(task.get_vars()) == 0

    block.vars = {'a': 1, 'b': 2, 'c': 3}
    #vars are not included in Task.get_vars()
    assert len(task.get_vars()) == 0

    task.vars = {'a': 2, 'b': 4, 'c': 6}
    #vars are not included in Task.get_vars()
    assert len(task.get_vars()) == 0

    block2 = Block()
    block2.vars = {'a': 3, 'b': 5, 'c': 7}
    block._parent = block2

# Generated at 2022-06-25 06:25:43.199830
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    repr_0 = repr(task_0)


# Generated at 2022-06-25 06:25:52.319535
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = {'dict_0': {'key_0': 'value_0', 'key_1': 'value_1'}, 'dict_1': {'key_0': 'value_0', 'key_1': 'value_1'}}
    assert task_0.get_vars() == {'dict_0': {'key_0': 'value_0', 'key_1': 'value_1'}, 'dict_1': {'key_0': 'value_0', 'key_1': 'value_1'}}
    task_0.vars = {'list_0': ['value_0', 'value_1'], 'list_1': ['value_0', 'value_1']}

# Generated at 2022-06-25 06:26:03.320289
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Init data
    data = {
        'always_run': True,
        'async': 10,
        'async_val': 10,
        'become': True,
        'become_method': 'sudo',
        'become_user': 'root',
        'delegate_to': 'localhost',
        'environment': {'ENV': 'env'},
        'no_log': True,
        'register': 'result',
        'remote_user': 'foo',
        'retries': 1,
        'until': ['foo', 'bar'],
        'vars': {'var': 'value'},
        'version_added': 2.4,
        'when': 'when'
    }

    from ansible.playbook.task_include import TaskInclude