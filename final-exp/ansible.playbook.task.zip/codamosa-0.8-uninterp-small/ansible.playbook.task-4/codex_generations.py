

# Generated at 2022-06-25 06:16:35.869639
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict()  # dict
    task_0.vars = dict

# Generated at 2022-06-25 06:16:40.426516
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    test = Task()
    test.vars = {'blah': 'bleh'}
    assert test.get_include_params() == {'blah': 'bleh'}


# Generated at 2022-06-25 06:16:42.215156
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task.action = 'setup'
    assert task.get_name() == 'setup'


# Generated at 2022-06-25 06:16:44.201361
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.preprocess_data({'changed_when': "{{ test }}", 'when': '1'})
    task.post_validate(templar=MagicMock())



# Generated at 2022-06-25 06:16:45.977654
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_1 = Task()
    task_2 = Task()
    task_2.post_validate(task_1)


# Generated at 2022-06-25 06:16:58.430423
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    task_0.module_name = 'some_module'
    task_0.loop = 'some_list_var'
    task_0.block = 'some_block'
    task_0.action = 'some_action'
    task_0.implicit = True
    task_0.resolved_action = 'some_resolved_action'
    task_0.notify = ['some_handler', ]
    task_0.when = ['some_condition', ]
    task_0.tags = ['some_tag', ]

    r = task_0.serialize()
    assert r['module_name'] == 'some_module'
    assert r['block'] == 'some_block'
    assert r['loop'] == 'some_list_var'

# Generated at 2022-06-25 06:17:10.175461
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    parameters_1 = { 'uri': 'https://github.com/ansible/ansible/pull/%s', 'action': 'win_uri', 'when': 'ansible_distribution != "Windows"', 'delegate_to': 'localhost', 'register': 'file1', 'with_items': 'file3', 'tags': [ 'debug' ], 'until': 'file1|success', 'args': { 'version': '1.0.5', 'dest': 'file1' }, 'collections': [ 'ansible.builtin', 'ansible_collections.my_namespace.my_collection' ] }
    task_1 = Task()
    task_1.deserialize(parameters_1)
    task_1.post_validate(None)

# Generated at 2022-06-25 06:17:12.711580
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    result = task_0.get_vars()
    assert isinstance(result, dict)


# Generated at 2022-06-25 06:17:15.862017
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task(loader=Mock())
    loader_0 = Mock()
    result_0 = task_0.deserialize(loader=loader_0)


# Generated at 2022-06-25 06:17:24.828456
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    task = Task()
    assert isinstance(task.get_first_parent_include(), TaskInclude) == False
    block = Block()
    task = Task()
    block.block = [task]
    assert isinstance(task.get_first_parent_include(), TaskInclude) == False
    task_include = TaskInclude()
    task_include.block = [task]
    assert isinstance(task.get_first_parent_include(), TaskInclude) == True

if __name__ == '__main__':
    test_Task_get_first_parent_include()

# Generated at 2022-06-25 06:17:52.622404
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.action = 'shell'
    task._valid_attrs = {'action': {'type': 'string'},
                         'other': {'type': 'string'}}
    task._ds = {'action': 'shell', 'other': 'hello'}
    task._loader = None
    task._variable_manager = None
    task._block = None
    task._role = None
    task._task_vars = None

    task._parent = None
    task.implicit = False
    task.resolved_action = None

    task._templar = None

    # Test case with non-empty collection and empty default_collection
    C.COLLECTIONS_PATHS = ['collections/']
    collections_list = ['test_collection.test_module']
    default_collection = ''
    result

# Generated at 2022-06-25 06:17:53.663188
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    repr_0 = repr(task_0)


# Generated at 2022-06-25 06:17:59.709433
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    Task_obj = Task()
    Task_obj.vars = {}
    Task_obj.action = "debug"
    Task_obj.args = dict(msg='Hello World')
    Task_obj.delegate_to = "local"
    Task_obj.tags = ["tag1", "tag2"]
    Task_obj.when = "false"
    Task_obj.changed_when = "changed"
    Task_obj.failed_when = "failed"
    Task_obj.always_run = "false"
    Task_obj.loop = "items"
    Task_obj.register = "result"
    Task_obj.ignore_errors = "true"
    Task_obj.notify = ["hand1", "hand2"]
    Task_obj.first_available_file = "/etc/motd"

# Generated at 2022-06-25 06:18:04.806519
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    ret = task_0.post_validate()
    assert ret is None, "Return value of Task.post_validate is: %r" % ret
    #assert ret == "Return value of Task.post_validate is: %r" % ret, "Return value of Task.post_validate is: %r" % ret
    return ret


# Generated at 2022-06-25 06:18:14.612542
# Unit test for method get_name of class Task
def test_Task_get_name():

    # Tests for get_name method
    task_1 = Task()
    # test_1:
    task_1._attributes = {'name': 'name_1'}
    name = task_1.get_name()
    assert name == 'name_1'
    # test_2:
    task_1._attributes = {'action': 'copy', 'args': {'src': 'src_1', 'dest': 'dest_1'}}
    name = task_1.get_name()
    assert name == 'copy src_1 dest_1'
    # test_3:
    task_1._attributes = {'action': 'copy', 'args': {'_raw_params': 'copy_1 src_1 dest_1'}}
    name = task_1.get_name()

# Generated at 2022-06-25 06:18:25.075273
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    data = {
        'action': {
            'module': 'command',
            'args': 'echo "foo"',
        }
    }
    assert task_0.preprocess_data(data) == {
        'action': 'command',
        'register': 'command_0',
        'when': True,
        'loop_control': {
            'loop_var': 'item',
        },
        'delegate_to': None,
        'args': {
            '_raw_params': 'echo "foo"',
            '_uses_shell': False,
        },
        'vars': {},
    }

    task_1 = Task()

# Generated at 2022-06-25 06:18:28.951282
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()

    task_0.post_validate(templar=None)

if __name__ == "__main__":
    pytest.main(args=[__file__, '-v'])

# Generated at 2022-06-25 06:18:37.217475
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.playbook.task_include import TaskInclude

    attribs = {
        'action': 'action_0',
        'local_action': 'local_action_0',
        'args': {
            'arg_0': 'value_0',
            'arg_1': 'value_1',
            'arg_2': 'value_2',
            'arg_3': 'value_3'
        },
        'delegate_to': 'delegate_to_0'
    }

    task_0 = Task()

    task_0._variable_manager = 'variable_manager_0'
    task_0._loader = 'loader_0'
    task_0._templar = 'templar_0'
    task_0._tqm = 'tqm_0'

    task_0

# Generated at 2022-06-25 06:18:42.011341
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    assert task_1.get_name() == "TASK", "Task's get_name failed"


# Generated at 2022-06-25 06:18:52.803563
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0_dict = {'action': 'shell', 'args': {'_raw_params': 'ls', 'chdir': '', 'creates': '', 'executable': '', 'removes': '', 'stdin': '', 'warn': True}, 'block': [], 'changed_when': '', 'delegate_to': '', 'failed_when': '', 'loop': '', 'loop_args': {}, 'name': '', 'notify': [], 'register': '', 'retries': 3, 'run_once': False, 'until': ''}

    task_0.deserialize(task_0_dict)


# Generated at 2022-06-25 06:19:10.661213
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    expected_result = '<Task name="AnsibleModule" object at 0x7f9e9c60e7d0>'
    task_instance = Task()
    result = task_instance.__repr__()
    assert result == expected_result, "Task.__repr__() returned an unexpected result. Result: \
                                      %s. Expected result: %s" % (result, expected_result)


# Generated at 2022-06-25 06:19:12.682472
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    assert True

if __name__ == '__main__':
    test_case_0()
    test_Task_get_first_parent_include()

# Generated at 2022-06-25 06:19:14.318689
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    assert task_0.post_validate(None) is None


# Generated at 2022-06-25 06:19:22.324543
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    success = task_0.deserialize({'action': 'setup', 'args': {'fact_path': '/tmp/test', 'filter': 'ansible_all_ipv4_addresses', 'gather_subset': 'all'}, 'loop': '', 'loop_control': {}, 'name': 'setup', 'until': '', 'vars': {'ansible_all_ipv4_addresses': '10.0.10.1, 192.168.0.2'}})


# Generated at 2022-06-25 06:19:32.385417
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # General task execution tests.
    task_0 = Task()

    #'block': field indicates the start of a block. The block will contain 1 or more tasks within it.
    task_0.vars = {u'block': u'BLOCK_TEST'}
    task_0.environment = [u'ANSIBLE_TEST']
    task_0.when = u'when_value'
    task_0.until = u'until_value'
    task_0.action = u'action_value'
    task_0.ignore_errors = False

# Generated at 2022-06-25 06:19:38.136853
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    class ParentTask(Task):
        def __init__(self, name="parent"):
            super(ParentTask, self).__init__(name)
    class ParentTaskInclude(TaskInclude):
        def __init__(self, name="parent"):
            super(ParentTaskInclude, self).__init__(name)
    class ChildTask(Task):
        def __init__(self, name="parent"):
            super(ChildTask, self).__init__(name)

    # This is a single path for parent and parent_type
    parent = ParentTaskInclude()
    task = ChildTask()
    task._parent = parent

    assert_equals(task.get_first_parent_include(), parent)


# Generated at 2022-06-25 06:19:41.522755
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    assert task_1.get_name() is None
    task_1._attributes['name'] = 'foo'
    assert task_1.get_name() == 'foo'


# Generated at 2022-06-25 06:19:44.319587
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Create variables
    task_0 = Task()

    # Call test method
    task_0.preprocess_data(None, None)
    task_0.preprocess_data(None, None, None, None)


# Generated at 2022-06-25 06:19:54.741680
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    block_0 = Block()
    block_0._parent = TaskInclude()
    block_0._parent._parent = TaskInclude()
    block_0._parent._parent._parent = TaskInclude()
    block_0._parent._parent._parent._parent = TaskInclude()
    block_0._parent._parent._parent._parent._parent = TaskInclude()

    task_0 = Task()
    task_0._parent = block_0
    task_0._parent._vars = dict({u'bar': u'inherited from block'})

# Generated at 2022-06-25 06:20:01.827374
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_weight = Task.WEIGHT
    task_0 = Task()
    assert task_0.__repr__() == "<Task: {}>"
    task_0.set_loader(DataLoader())
    assert "loader" not in task_0.__repr__()
    task_0.set_name("foo")
    assert "name" in task_0.__repr__()
    task_0.set_weight(task_weight)


# Generated at 2022-06-25 06:20:18.116204
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task.action = ModuleAction()
    task.action.module_name = 'test'
    assert repr(task) == 'TASK: test'


# Generated at 2022-06-25 06:20:19.615913
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_0 = Task()
    result = task_0.get_include_params()
    assert result is not None
    assert result == {}


# Generated at 2022-06-25 06:20:24.334591
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_1 = Task()
    task_1.action = 'ping'
    task_1.args = dict(_raw_params='localhost', others='test')
    task_1.when = "[A_VARIABLE] is defined"
    task_1.post_validate(s_vals_1)


# Generated at 2022-06-25 06:20:27.455255
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_0 = Task()
    task_0._parent = 'seventy-six'
    assert task_0.get_first_parent_include() == 'seventy-six'


# Generated at 2022-06-25 06:20:39.092138
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Test function Task.deserialize with valid data
    task_0 = Task()
    task_0.deserialize(None)
    task_0.deserialize({})

    task_1 = Task()

# Generated at 2022-06-25 06:20:41.385581
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    assert task.post_validate(None) == None


# Generated at 2022-06-25 06:20:50.275588
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Create Task instance
    task_0 = Task()
    #import pdb;pdb.set_trace()
    # Create dummy value for parameter data
    data = {"action": "my_action", "args": "my_params", "delegate_to": "localhost"}

    # Call method deserialize of class Task with parameter data
    task_0.deserialize(data)

    # Check attribute action value is same as data
    assert task_0.action == "my_action"
    # Check attribute args value is same as data
    assert task_0.args == "my_params"
    # Check attribute delegate_to value is same as data
    assert task_0.delegate_to == "localhost"



# Generated at 2022-06-25 06:21:01.009840
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    """
    Returns all variables (including those from parent blocks) for the task.
    :return: All variables for the task.
    """
    task_0 = Task()

# Generated at 2022-06-25 06:21:09.279356
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    temp_task = Task()
    raw_task = {'action': {'module': 'test_task_module', 'args': {'arg1': 'arg1_value'}}}
    temp_task.preprocess_data(raw_task)
    assert temp_task.action == 'test_task_module'
    assert temp_task.args['arg1'] == 'arg1_value'


# Generated at 2022-06-25 06:21:11.543349
# Unit test for method get_name of class Task
def test_Task_get_name():
    """
    Test that Task get_name returns the expected value
    """
    task_1 = Task()
    task_1._attributes.update({'name': 'test_moo'})
    assert(task_1.get_name() == 'test_moo')



# Generated at 2022-06-25 06:21:29.855722
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()

# Generated at 2022-06-25 06:21:31.043909
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    result = Task().deserialize({})
    assert result is None


# Generated at 2022-06-25 06:21:36.352594
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task(action='action_0')
    task_0.name = 'name_0'
    name_0 = task_0.__repr__()
    assert name_0 == "<task action:action_0 name:name_0>"


# Generated at 2022-06-25 06:21:46.774173
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test No. 0
    task_0 = Task()

    task_0.preprocess_data(ds={'firstkey': 'first value'})

    task_0.get_validated_keys(ds={'firstkey': 'first value'})

    task_0._load_vars(ds={'firstkey': 'first value'})

    task_0._load_list_of_blocks(ds={'firstkey': 'first value'})

    task_0._post_validate_loop(attr="loop", value="first value", templar="not templar")

    task_0._post_validate_environment(attr="loop", value="first value", templar="not templar")


# Generated at 2022-06-25 06:21:49.515282
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task(vars=dict(a=1))
    assert isinstance(task_1.get_vars(), dict)
    assert task_1.get_vars()['a'] == 1


# Generated at 2022-06-25 06:21:55.670685
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    t_obj = Task()
    task_data = {'task1_data': 'task1_data'}
    t_obj.deserialize(task_data)
    assert t_obj._attributes['task1_data'] == 'task1_data'

# Generated at 2022-06-25 06:21:57.791858
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    assert task_0.get_vars() == {}, "ERROR: method get_vars of class Task returns {}"


# Generated at 2022-06-25 06:22:02.365233
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    (task_0, task_0_ds) = make_task_0()
    task_0_vars = task_0.get_vars()
    assert task_0_vars == {}


# Generated at 2022-06-25 06:22:11.498719
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    '''
    Task.deserialize
    '''

    # Task initialisation
    task_0 = Task()

    # Start of Task.deserialize, call to Task.deserialize
    # Task.deserialize call serialize, call to Task.serialize
    # End of Task.serialize, returning None
    # Task.serialize call get_validate_attrs, call to Task.get_validate_attrs
    # End of Task.get_validate_attrs, returning {'name': {'required': True}, 'action': {'aliases': ['operation', 'module'], 'default': 'main'}, 'local_action': {'aliases': ['local_operation'], 'required': False}, 'args': {'aliases': ['parameters'], 'required': False}, 'delegate_to': {'ali

# Generated at 2022-06-25 06:22:19.209941
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    with pytest.raises(AnsibleParserError):
        task_0.preprocess_data({
            "name": None,
            "action": "test_command",
            "delegate_to": None,
            "args": {
                "foo": "bar"
            },
            "run": {
                "foo": "bar"
            }
        })
    return


# Generated at 2022-06-25 06:22:42.480651
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    task_0 = Task()
    task_1 = TaskInclude()
    task_0._parent = task_1
    assert task_0.get_first_parent_include() == task_1


# Generated at 2022-06-25 06:22:46.879420
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    try:
        task_0 = Task()
        # Success, we did not get an exception.
    except Exception as e:
        print('Exception occurred: {}'.format(e))
        return
    else:
        print('WARNING: expected but did not receive an exception for test_Task_deserialize')
        return


# Generated at 2022-06-25 06:22:48.432934
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    target = 'TASK'
    actual = task_0.__repr__()
    assert target == actual


# Generated at 2022-06-25 06:22:58.438718
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task = Task()
    # Create a mock object of the class TaskInclude
    mockTaskInclude = mocker.create_autospec(TaskInclude)
    mockTaskInclude.all_parents_static.return_value = True
    mockTaskInclude.get_include_params.return_value = dict()

    # Set the parent of task to be the mockTaskInclude
    task._parent = mockTaskInclude
    task._role = None
    task.action = None
    task.implicit = False
    task.resolved_action = None
    task.vars = dict()
    task.args = dict()
    task.delegate_to = None

    # Call method get_first_parent_include of class Task on var task
    task.get_first_parent_include()

    # Assert that method get_first

# Generated at 2022-06-25 06:23:08.581943
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    ansible_ds_0 = {}
    ansible_ds_0['action'] = 'action_value'
    ansible_ds_0['args'] = 'args_value'
    ansible_ds_0['delegate_to'] = 'delegate_to_value'
    ansible_ds_0['local_action'] = 'local_action_value'
    ansible_ds_0['when'] = 'when_value'
    ansible_ds_0['async'] = 'async_value'
    ansible_ds_0['poll'] = 'poll_value'
    ansible_ds_0['until'] = 'until_value'
    ansible_ds_0['retries'] = 'retries_value'

# Generated at 2022-06-25 06:23:16.683178
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    task_1 = Task()
    
    #Verify that we return the correct result
    task_1.action = "test"
    task_1.resolved_action = "test"
    task_1.name = "test"
    assert task_1.__repr__() == "<Task \"test\" (test)>", 'Expected different behavior for Task.__repr__()'

    #Verify that we return the correct result
    task_1.action = "test"
    task_1.resolved_action = "test"
    task_1.name = "test"
    task_1.delegate_to = "test"

# Generated at 2022-06-25 06:23:20.974274
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    import yaml
    with open('/tmp/test_playbook/yamltasks.yml') as f:
        yaml_data = yaml.load(f)
    task_0 = Task()
    task_0.deserialize(yaml_data)


# Generated at 2022-06-25 06:23:26.373082
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Create an instance of Task
    task_0 = Task()
    # Use the instantiated object to call the method
    assert task_0.__repr__() == "Task(name=None)"
    # Create an instance of Task
    task_1 = Task()
    # Use the instantiated object to call the method
    assert task_1.__repr__() == "Task(name=None)"


# Generated at 2022-06-25 06:23:27.996318
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # the method is tested by class test_playbook_include in test/test_playbook_include.py
    pass

# Generated at 2022-06-25 06:23:34.994269
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # Testing with no task
    task_0 = Task()
    assert task_0.get_include_params() == dict()

    # Testing with some vars
    task_0 = Task()
    task_0.vars = dict(var_0="val_0", var_1="val_1")
    assert task_0.get_include_params() == dict(var_0="val_0", var_1="val_1")

    # Testing with parent and some vars
    task_0 = Task()
    task_0._parent = Task()
    task_0.vars = dict(var_0="val_0", var_1="val_1")
    assert task_0.get_include_params() == dict(var_0="val_0", var_1="val_1")

    # Testing with parent and

# Generated at 2022-06-25 06:23:54.099370
# Unit test for method __repr__ of class Task
def test_Task___repr__():

    # Create data structure for test
    task_0 = Task()

# Generated at 2022-06-25 06:23:55.621541
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0.deserialize(None)


# Generated at 2022-06-25 06:23:56.459409
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    pass


# Generated at 2022-06-25 06:24:02.467151
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    task_0.action = 'test_action'
    task_0.environment = {'test_env_var_0': 'test_environment'}
    task_0.resolved_action = 'test_resolved_action'
    task_0.when = 'test_when'
    task_0.tags = ['test_tag_0', 'test_tag_1']
    task_0.run_once = True
    task_0.name = 'test_name'
    task_0.notify = ['test_handler_0', 'test_handler_1']
    task_0.changed_when = 'test_changed_when'
    task_0.args = {'test_arg_0': 'test_arg',  'test_arg_1': 'test_arg'}
   

# Generated at 2022-06-25 06:24:07.044783
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    arg_set = set()
    arg_set.add(None)
    arg_set.add(arg_set)
    arg_set.add(list())
    arg_set.add(list(['action', 'local_action', 'args', 'delegate_to']))
    arg_set.add(set())
    arg_set.add(tuple())
    arg_set.add(dict())
    arg_set.add(dict(action=dict(), local_action=dict(), args=dict(), delegate_to=dict()))

    # init
    test_obj = Task()

    def get_vars_stub():
        return dict()

    test_obj._get_vars = get_vars_stub


# Generated at 2022-06-25 06:24:10.684608
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    yaml_task_0 = "action: ping\nargs: {}\nignore_errors: true"
    task_0 = Task()
    task_0.deserialize(yaml_task_0)
    assert task_0.action == 'ping'
    assert task_0.ignore_errors == True


# Generated at 2022-06-25 06:24:14.030180
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()

    task_1 = Task()
    # Validate the return value
    assert task_1.__repr__() == '<Task()>'

    task_2 = Task()
    # Validate the return value
    assert task_2.__repr__() == '<Task()>'


# Generated at 2022-06-25 06:24:17.350550
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    try:
        task_1 = Task(action='test name')
        str_repr = task_1.__repr__()
        assert isinstance(str_repr, str)
    except:
        raise AssertionError


# Generated at 2022-06-25 06:24:22.961943
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # In the test module, the current_task_level = 0, task_level = 2
    task_0 = Task()
    task_0.vars = {'k':'v'}
    assert task_0.current_task_level == 0
    assert task_0.get_vars() == {'k':'v'}

    # In the test module, the current_task_level = 1, task_level = 3
    task_1 = Task()
    task_1.current_task_level = 1
    task_1.vars = {'x':'y'}
    task_0._parent = task_1
    assert task_0.current_task_level == 1
    assert task_0.get_vars() == {'k':'v'}

    # In the test module, the current_task

# Generated at 2022-06-25 06:24:28.655014
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()

    task_0.action = 'test_action'
    task_0.name = 'test_name'
    task_0.role = Role()
    task_0.static = True
    task_0.tags = ['test_tag']

    task_0._variable_manager = 'test_variable_manager'
    task_0._loader = 'test_loader'

    print(str(task_0))
    print(task_0.__repr__())
    print(repr(task_0))


# Generated at 2022-06-25 06:24:46.567479
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Create Task instance
    task = Task()

    # Create Task instance
    task = Task()

    # Create Task instance
    task = Task()

    # Create Task instance
    task = Task()


if __name__ == '__main__':
    test_Task_post_validate()
    test_case_0()

# Generated at 2022-06-25 06:24:51.008622
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task("task_name")
    task_0.__repr__()


# Generated at 2022-06-25 06:24:57.809761
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    '''
    Test deserialize method of class Task
    '''
    task_0 = Task()
    data_0 = dict()
    data_0['action'] = 'ansible.builtin.fail'
    data_0['args'] = dict()
    data_0['args']['msg'] = 'it failed'
    data_0['args']['_raw_params'] = 'it failed'
    task_0.deserialize(data=data_0)


# Generated at 2022-06-25 06:25:10.165726
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    import sys
    import random
    import string

    # Generate test_case_0 for class Task
    task_instance = Task()

    # Set up test_case_0 attributes based on an automatically generated random string
    setattr(task_instance, 'name', ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10)))

    # Generate test_case_1 for class Task
    task_instance_1 = Task()

    # Set up test_case_1 attributes based on an automatically generated random string
    setattr(task_instance_1, 'name', ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10)))

# Generated at 2022-06-25 06:25:15.218239
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # This is how to make a fake Task object.
    fake_task = Task()

    # This is how to make a fake JobVars object.
    fake_job_vars = JobVars()

    # This is how to call the method.
    fake_task.post_validate(templar=fake_job_vars)



# Generated at 2022-06-25 06:25:19.280307
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    # test with obj = Task()
    task_0.post_validate()

    # test with obj = Task() and templar
    task_0.post_validate(templar="templar")

# Generated at 2022-06-25 06:25:30.568609
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    '''
    This function tests if the Task class method post_validate
    throws an AssertionError if the argument templar is not an instance of
    of the Templar class and raises an AssertionError exception if the
    argument fails this test.
    '''
    filename = "foo/bar/myfilename.yml"
    # test 1: testing when the parameter templar is not an instance of Templar
    data = dict(action=dict(module='shell', args='id'), delegate_to='localhost')
    task = Task()
    task._role = "foo/bar"
    task.action = 'shell'
    task.args = 'id'
    task.delegate_to = 'localhost'
    task._ds = data
    task._loader = DictDataLoader({filename: yaml.dump(data)})
    task

# Generated at 2022-06-25 06:25:33.490420
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    try:
        task_0.get_vars()
    except SystemExit:
        pass


# Generated at 2022-06-25 06:25:41.455061
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0._validate_attributes = MagicMock()
    task_0._validate_attributes.return_value = None

    task_0._post_validate_vars = MagicMock(return_value=None)
    task_0._post_validate_tags = MagicMock(return_value=None)
    task_0._post_validate_when = MagicMock(return_value=None)
    task_0._post_validate_registered = MagicMock(return_value=None)
    task_0._post_validate_failed = MagicMock(return_value=None)
    task_0._post_validate_changed = MagicMock(return_value=None)

# Generated at 2022-06-25 06:25:49.912403
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    '''
    Ansible task object is instantiated and
    get_include_params method is tested
    '''
    task_1 = Task()
    task_1.vars = [{"key": "value"}]
    assert task_1.get_include_params() == [{'key': 'value'}]
    task_2 = Task()
    task_2.vars = [{"key_1": "value_1"}, {"key_2": "value_2"}]
    assert task_2.get_include_params() == [{'key_1': 'value_1'}, {'key_2': 'value_2'}]
