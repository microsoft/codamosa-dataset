

# Generated at 2022-06-25 06:16:28.301013
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    fake_loader = DictDataLoader({})
    fake_tmp_path = '/tmp/foo'
    fake_curr_path = '/tmp/foo/foo.yaml'

    fake_loader.set_basedir(fake_tmp_path)
    fake_ordereddict = {
        'hosts': 'sathish',
        'become': False,
        'tasks': [{
            'name': 'ping',
            'action': 'ping',
            'tags': ['foo'],
            'when': 'ansible_lsb.major_release == 14'
        },
        {
            'name': 'ping server',
            'action': 'ping',
            'tags': ['foo'],
            'when': 'ansible_lsb.major_release == 12'
        }
        ]
    }
   

# Generated at 2022-06-25 06:16:36.597915
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude

    module_params = {'foo': 'bar', 'bar': 'baz'}
    task_0 = Task()
    task_0.action = 'include_role'
    task_0._attributes = module_params

    include_role = TaskInclude()
    include_role._attributes = {'tasks': [task_0]}
    include_role.action = 'include_role'

    task_1 = Task()
    task_1._parent = include_role

    assert task_1.get_include_params() == module_params

    task_0.action = 'do_something_else'
    assert task_1.get_include_params() == {}

    task_0.action = 'include_role'

# Generated at 2022-06-25 06:16:46.157586
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    '''
    Unit test for method deserialize of class Task
    '''
    task_deserialize = Task()
    data = {}
    data['name'] = "test_task_name"
    data['action'] = "test_action"
    data['delegate_to'] = "test_delegate_to"
    data['delegate_facts'] = None
    data['loop'] = {
        '_list': [1, 2, 3]
    }
    data['when'] = "test_when"
    data['rescue'] = 'test_rescue'
    data['always'] = 'test_always'
    data['changed_when'] = 'test_changed_when'
    data['failed_when'] = 'test_failed_when'
    data['tags'] = ['test_tag']

# Generated at 2022-06-25 06:16:58.633916
# Unit test for method serialize of class Task
def test_Task_serialize():
    global test_Task_serialized

# Generated at 2022-06-25 06:17:10.359814
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Changes made:
    # '''Tests all play attributes as well as recursive loading of roles and blocks'''
    # added the line below to address the error:
    # """Failed: Module import failed for ansible.playbook.task_include"""
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import become_loader
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Initialize the task object
    # obj = Task()

# Generated at 2022-06-25 06:17:17.305494
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    data = {'action': 'get_url', 'async_val': 0, 'poll': 0, 'when': 'true'}
    task_1 = Task()
    return_code = task_1.deserialize(data)
    assert return_code == None
    assert task_1._attributes == {'action': 'get_url', 'async_val': 0, 'poll': 0, 'when': 'true'}


# Generated at 2022-06-25 06:17:18.432469
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    output = task_0.__repr__()


# Generated at 2022-06-25 06:17:24.612159
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task_tp = Task()
    task_tc = Task()
    task_tc.set_loader(DataLoader())
    task_tc.load({'include': 'roles/common.yml'})
    task_tp.set_loader(DataLoader())
    task_tp.load({'roles':[{'name':'common'}]})
    task_tp.add_child(task_tc)
    assert task_tc == task_tp.get_first_parent_include()


# Generated at 2022-06-25 06:17:32.246362
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # test the initialization of task without any value
    task_1 = Task()
    assert task_1.get_include_params() == dict(), "get_include_params return a non empty dictionary"
    # test the initialization of task with values
    task_2 = Task({'action': 'test', 'vars': {'test': 'test_value'}})
    assert task_2.get_include_params() == dict(), "get_include_params return a non empty dictionary"
    assert isinstance(task_2, Task), "task_2 is not an instance of class Task"
    assert isinstance(task_2.vars, dict), "no dictionary instance returned"
    assert task_2.vars.get('test') == 'test_value', "get_vars instance method failed"

# Generated at 2022-06-25 06:17:36.438455
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()
    task_0.vars = dict()
    task_0.action = 'shell'
    task_0.args = dict()
    task_0.environment = dict()
    task_0.resolved_action = 'shell'
    task_0.delegate_to = None
    task_0.set_loader(BaseLoader())
    ds = {'environment': [{'TEST_VAR': 'value'}]}
    result = task_0.preprocess_data(ds)
    assert result['environment'] == {'TEST_VAR': 'value'}


# Generated at 2022-06-25 06:17:52.598180
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # <>_0 is a Task instance
    with pytest.raises(AnsibleError) as excinfo:
        task_0 = Task()
    assert excinfo.value.args[0] == 'block_type is not set'

    # Create a Task instance <>_1 without block_type
    task_1 = Task()
    assert task_1.get_vars() == {}

    # Create a Task instance <>_2 with block_type and vars
    task_2 = Task()
    task_2._attributes['block_type'] = 'foo'
    task_2._attributes['vars'] = {
        'a': 'b',
        'c': 'd'
    }

# Generated at 2022-06-25 06:17:53.802413
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    task_1.deserialize(data={'action': 'copy'})


# Generated at 2022-06-25 06:17:57.594419
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    
    # test case 1
    task_0 = Task()
    parent_0 = HandlerTaskInclude()
    parent_1 = TaskInclude()
    parent_2 = Task()
    task_0._parent = parent_2
    parent_2._parent = parent_1
    parent_1._parent = parent_0
    result_0 = task_0.get_first_parent_include()
    
    assert result_0 == parent_1


# Generated at 2022-06-25 06:17:59.397602
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()
    assert_equals(task_1.get_vars(), dict())

# Generated at 2022-06-25 06:18:09.867502
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    task.vars = {}
    class parent:
        def get_include_params(self):
            return {}
    parent = parent()
    # Test attribute not specified in vars of task:
    assert task.get_include_params() == {}
    # Test attribute specified in vars of task:
    task.vars = {'a': 'b'}
    assert task.get_include_params() == {'a': 'b'}
    # Test attribute specified in vars of included yaml:
    task.action = 'include'
    assert task.get_include_params() == {'a': 'b'}
    # Test attribute specified in vars of included yaml:
    task.vars = {}
    task.action = 'include_role'
    assert task.get_include_params()

# Generated at 2022-06-25 06:18:10.331511
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    pass

# Generated at 2022-06-25 06:18:17.012425
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    task_0.vars = {'key1': 'value1', 'key2': 'value2'}

    assert task_0.get_vars() == {'key1': 'value1', 'key2': 'value2'}


# Generated at 2022-06-25 06:18:26.509556
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task()
    assert task_1.get_vars() == {}
    task_1.vars = {"a":"A","b":"B"}
    assert task_1.get_vars() == {"a":"A","b":"B"}

    role_1 = Role()
    role_1.vars = {"role_1_var":"role_1_val"}
    task_1._role = role_1

    block_1 = Block()
    block_1.vars = {"block_1_var":"block_1_val"}
    block_1._parent = task_1

    task_2 = Task()
    task_2.vars = {"task_2_var":"task_2_val"}
    task_2._parent = block_1


# Generated at 2022-06-25 06:18:35.208700
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    """Test Task class preprocess_data method"""

    #
    # Setup test data
    #

    # Define the structure of the task to test
    task_test_data = dict(
        action='test_action', # Module to execute
        args=dict(
            arg1='arg1',
            arg2='arg2',
            arg3='arg3',
        )
    )

    #
    # Perform the test
    #

    # Create a test task
    task_x = Task()

    # Run the preprocess_data method
    task_x.preprocess_data(task_test_data)

    #
    # Verify the test results
    #

    # FIXME: TASK_NO_VALIDATORS
    # It is expected that a test for attribute validation is also added here
    # when the TAS

# Generated at 2022-06-25 06:18:36.479213
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    task_name = task_0.get_name()
    assert task_name == 'meta'

# Generated at 2022-06-25 06:18:50.598041
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    result = task_0.serialize()
    assert result == dict(
        _attributes=dict(),
        _parent=None,
        _role=None,
        _squashed=False,
        _finalized=False,
        implicit=False,
        resolved_action=None,
    )


# Generated at 2022-06-25 06:18:59.217937
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_0 = Task()
    task_0._attributes['action'] = 'setup'
    task_0._attributes['first_available_file'] = 'setup'
    task_0._attributes['run_once'] = 'setup'
    task_0._attributes['any_errors_fatal'] = 'setup'
    task_0._attributes['changed_when_new'] = 'setup'
    task_0._attributes['changed_when_re'] = 'setup'
    task_0._attributes['changed_when_results'] = 'setup'
    task_0._attributes['tags'] = 'setup'
    task_0._attributes['loop'] = 'setup'
    task_0._attributes['loop_control'] = 'setup'
    task_0._attributes['until'] = 'setup'
   

# Generated at 2022-06-25 06:19:09.939246
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # test a variety of ways the module can be specified
    fragment = dict(
        action = dict(
            module = 'shell',
            args = 'echo hi'
        )
    )
    task_0 = Task()
    task_0.load(fragment)
    assert isinstance(task_0, Task)
    assert task_0.data['action'] == "shell"
    assert task_0.data['args'] == dict(module='shell', args='echo hi')

    fragment = dict(
        command = 'echo hi'
    )
    task_0 = Task()
    task_0.load(fragment)
    assert isinstance(task_0, Task)
    assert task_0.data['action'] == "command"

# Generated at 2022-06-25 06:19:14.070088
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    '''
    Test Task.get_vars()
    '''
    task_0 = Task()
    # Test returns the same type and value as the original
    assert isinstance(task_0.get_vars(), dict)
    assert task_0.get_vars() == dict()


# Generated at 2022-06-25 06:19:17.946992
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_0 = Task()
    task_0_data = {'when': {'value': {'value': 'True'}, 'type': 'boolean'}, 'loop': {'type': 'string', 'value': []}}
    task_0.deserialize(task_0_data)
    assert task_0._attributes == {'when': {'value': {'value': 'True'}, 'type': 'boolean'}, 'loop': {'type': 'string', 'value': []}}


# Generated at 2022-06-25 06:19:22.590183
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_1 = Task()
    task_1.deserialize({u'action': u'name', u'__ansible_module__': u'ping', u'__ansible_arguments__': u'', u'__ansible_version__': 2.7})


# Generated at 2022-06-25 06:19:25.436496
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    print(task)
    print(task.__repr__())
    task2 = Task()
    print(task2)
    print(task2.__repr__())

# Generated at 2022-06-25 06:19:35.268351
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Init the class
    task = Task()
    # Declare variables for test case
    filepath = 'http://www.ansible.com'

# Generated at 2022-06-25 06:19:39.751076
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize({'name': 'some_name', 'action': 'some_action'})
    assert task.name == 'some_name'
    assert task.action == 'some_action'

# Generated at 2022-06-25 06:19:48.557863
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_0 = Task()
    var_list = ['name', 'version']
    task_0.vars = dict(zip(var_list, var_list))
    task_0.args = dict(zip(var_list, var_list))
    task_0.connection = var_list[0]
    task_0.action = var_list[0]
    task_0.async_val = var_list[0]
    task_0.delegate_to = var_list[0]
    task_0.poll = var_list[0]
    task_0.check_mode = var_list[0]
    task_0.notify = var_list[0]
    task_0.register = var_list[0]
    task_0.until = var_list[0]
    task_

# Generated at 2022-06-25 06:20:17.059045
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # test_object = Task(self)

    # test_object.get_include_params()
    assert True == True


# Generated at 2022-06-25 06:20:28.999744
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    yaml_data = '''
    - name: "Test Task"
      tags:
        - test
        - test_action
      test_falsy: False
      shell: "echo {{ test_action }}"
    '''
    task_0 = Task()
    # Execute method preprocess_data
    task_0.preprocess_data(yaml_data=yaml_data, vault_password='TESTING')

    # Assertions for method preprocess_data of class Task
    assert task_0.get_name() == 'Test Task'
    assert task_0.action == 'shell'
    assert task_0.args['_raw_params'] == '"echo {{ test_action }}"'
    assert task_0._attributes['delegate_to'] is None

# Generated at 2022-06-25 06:20:32.594491
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize({
        'action': 'fail',
        'args': {

        },
        'delegate_to': 'localhost',
        'when': 'ansible_os_family == "Linux"'
    })

    assert task.action == 'fail'
    assert task.when == 'ansible_os_family == "Linux"'



# Generated at 2022-06-25 06:20:37.171840
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_0 = Task()
    task_0.post_validate(templar=object)

test_cases = [test_case_0, ]

if __name__ == '__main__':
    for test in test_cases:
        test()

# Generated at 2022-06-25 06:20:38.777688
# Unit test for method get_name of class Task
def test_Task_get_name():
    assert Task().get_name() == 'Meta'


# Generated at 2022-06-25 06:20:49.323990
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_0 = Task()
    data_0 = {}
    task_0.deserialize(data_0)

    parent_data_0 = {}
    role_data_0 = {}
    data_0 = {'parent': parent_data_0, 'role': role_data_0}
    task_0.deserialize(data_0)

    role_data_0 = {}
    data_0 = {'parent': parent_data_0, 'role': role_data_0}
    task_0.deserialize(data_0)

    parent_data_0 = {}

# Generated at 2022-06-25 06:20:50.181749
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_1 = Task(name="test_task")
    assert repr(task_1) == "<Task: test_task>"

# Generated at 2022-06-25 06:21:00.942228
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_1 = Task()
    ds = dict(action=dict(module='foo', args=dict(bar=dict(baz='tester'))))
    task_1.preprocess_data(ds)
    assert task_1.action == 'foo'
    assert task_1.args == dict(bar=dict(baz='tester'))

    # when_example:
    # - debug:
    #     msg: "{{ ansible_uptime_seconds }}"
    #   when: ansible_uptime_seconds > 0
    task_2 = Task()
    # TODO: what to test for this case?

# Generated at 2022-06-25 06:21:07.599859
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    t = Task()
    t.vars = dict(a='a', b='b', c='c')
    assert t.get_include_params() == dict(a='a', b='b', c='c')
    t._parent = mock.MagicMock()
    t._parent.get_include_params.return_value = dict(a='a', b='b',c='c', d='d')
    assert t.get_include_params() == dict(a='a', b='b', c='c', d='d')
    t._parent.get_include_params.return_value = dict(a='a', b='b', c='c', d='d')
    t.action = 'include'

# Generated at 2022-06-25 06:21:11.988013
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_0 = Task()
    result = task_0.get_name()
    assert result == 'meta'


# Generated at 2022-06-25 06:21:44.050414
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    '''
    [{
        # test_case_1
        'data': dict(
            action='some_action',
            local_action='some_local_action',
            args={'some': 'some_args'},
            delegate_to='delegate_to_some'
        )
    }]
    '''
    new_ds = {
        'action': 'some_action',
        'args': {'some': 'some_args'},
        'delegate_to': 'delegate_to_some',
        'local_action': 'some_local_action'
    }

    def args_parser_parse():
        return 'some_action', {'some': 'some_args'}, 'delegate_to_some'

    task_1 = Task()

# Generated at 2022-06-25 06:21:45.261478
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    pass


# Generated at 2022-06-25 06:21:51.825267
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template.safe_eval import SafeEval
    from ansible.template.template import Templar
    import ansible.template.template

    # Create two task includes and two blocks, set them to be the parent of
    # one another, then call each other's parent to form a tree.
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()

    block_0 = Block()
    block_0.post_validate({}, Templar(loader=None, variables={}))
    block_1 = Block()
    block_1.post_validate({}, Templar(loader=None, variables={}))

    task_include_0.set_loader(None)
    task_

# Generated at 2022-06-25 06:21:58.236055
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    test_case_0()

if __name__ == '__main__':
    import sys
    import os
    import pytest

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    pytest.main([__file__])

# Generated at 2022-06-25 06:22:08.345883
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()

# Generated at 2022-06-25 06:22:14.494327
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    #Exception test case
    def run(data):
        task_0 = Task()
        task_0.deserialize(data)

# Generated at 2022-06-25 06:22:22.887982
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task_1 = Task()
    # Tests when function post_validate is called with no arguments
    try:
        task_1.post_validate()
    except TypeError:
        pass
    else:
        raise AssertionError("No exception was raised")
    # Tests when function post_validate is called with a non-Templar object
    template_1 = Mock()
    try:
        task_1.post_validate(template_1)
    except TypeError:
        pass
    else:
        raise AssertionError("No exception was raised")

# Generated at 2022-06-25 06:22:33.481571
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # create Task object
    task_obj = Task()

# Generated at 2022-06-25 06:22:40.259225
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    task_0 = Task()

    data = {'action': 'shell', 'environment': {'ANSIBLE_ANSIBLE_TEST': '2'}, 'async_val': 45, 'changed_when': 'False', 'delegate_to': 'localhost', 'failed_when': 'False', 'name': 'shell', 'register': 'out_shell', 'role': {'role_name': 'test'}, 'serial': 2, 'until': 'False', 'vars': {}, 'when': 'False'}
    task_0.deserialize(data)



# Generated at 2022-06-25 06:22:50.216517
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task_res = Task()
    

# Generated at 2022-06-25 06:23:06.724650
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    with pytest.raises(AssertionError):
        test_case_0()
    with pytest.raises(AssertionError):
        task_1 = Task(dict(), dict(), dict(), dict(), dict())


# Generated at 2022-06-25 06:23:08.276068
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()
    assert task.get_vars() == {}


# Generated at 2022-06-25 06:23:16.494938
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    play_host = Host("host_0")
    play_host.set_variable("host_var_0","host_var_0_value")
    group = Group("group_1")
    group.set_variable("group_var_0","group_var_0_value")
    group.add_host(play_host)
    inventory = AnsibleInventory(hosts=[play_host],groups=[group])
    variable_manager = VariableManager(loader=DefaultLoader(), inventory=inventory)

    # Create Task object
    task = Task()
    task.name = "task_0"

# Generated at 2022-06-25 06:23:26.896499
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    test_task = Task().load({
        'action': 'name',
        'vars': {'var1': 'value1'},
        'args': {'arg1': 'value1', 'arg2': 'value2'},
    })
    assert test_task.get_include_params() == {'var1': 'value1'}
    test_task_include = TaskInclude().load({
        'vars': {'var2': 'value2'},
        'include': 'action=name2 arg3=value3',
        'vars_files': ['/tmp/foo', '/tmp/bar'],
    })

# Generated at 2022-06-25 06:23:29.133215
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()

    # Verify if the return type is a string
    assert isinstance(task_0.__repr__(), str)


# Generated at 2022-06-25 06:23:31.067297
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    """
    Task.post_validate() Test Case
    """
    # Test conditions:
    #
    # Task
    task_0 = Task()

    assert task_0.post_validate() == None
    # Test results
    #assert ? == ?

# Generated at 2022-06-25 06:23:43.793113
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()

    # Initialize
    # 1. value[0]: is a dict, with keys 'path', 'tasks', and 'vars'.
    #    'path' has value '/path/to/playbook/playbook_0.yml',
    #    'tasks' has value [],
    #    'vars' has value  {}
    # 2. task_ds[0]: is a dict, with key 'include_tasks', and value '/path/to/playbook/tasks/include_0.yml'
    # 3. value[0]['path']: is a string
    # 4. value[0]['tasks']: is a list, with one element
    # 5. value[0]['vars']: is a dict
    # 6. task_0.variable_manager: is

# Generated at 2022-06-25 06:23:46.771527
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    print(task_0.__repr__())


# Generated at 2022-06-25 06:23:54.366739
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize({'name': 'test_Task_deserialize'})
    assert task._attributes['name'] == 'test_Task_deserialize'
    assert task.name == 'test_Task_deserialize'


# Generated at 2022-06-25 06:24:01.215706
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_1 = Task(ds={'vars': {u'var1': u'foo', u'var2': u'bar'}})
    assert task_1.get_vars() == {u'var1': u'foo', u'var2': u'bar'}
    task_1 = Task(ds={'vars': {u'var1': u'foo', u'var2': u'bar'}})
    # NOTE: Task.get_vars does not return when and tags because they are used
    # by the flag of the task in the task queue to execute or skip it.
    task_1.vars = {u'var1': u'foo', u'var2': u'bar', u'when': u'True', u'tags': ['foo']}

# Generated at 2022-06-25 06:24:15.764383
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # task_0 = Task()
    # assert repr(task_0) == 'Task()'
    pass


# Generated at 2022-06-25 06:24:27.337935
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Test empty object
    task_0 = Task()
    task_0_ds = dict()
    task_0_new_ds = task_0._preprocess_data(task_0_ds)
    expected_task_0_new_ds = dict()
    assert task_0_new_ds == expected_task_0_new_ds

    # Test object with arguments
    task_1 = Task()

# Generated at 2022-06-25 06:24:35.532251
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task0 = Task()
    assert task0.get_first_parent_include() == None

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()

    task1.block = [task2, task3]
    task2.block = [task4, task5]
    task3.block = [task3, task4]
    task4.block = [task5, task4]
    task5.block = [task4, task3]

    assert len(task0.get_first_parent_include()) == 0
    assert task1.get_first_parent_include() == None
    assert task2.get_first_parent_include() == None
    assert task3.get_first_parent_include() == None

# Generated at 2022-06-25 06:24:46.610242
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    def _get_data_to_deserialize():
        # import is here to avoid import loops
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.handler_task_include import HandlerTaskInclude

# Generated at 2022-06-25 06:24:51.073024
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    task = Task()
    task = TaskInclude()
    assert task.get_first_parent_include() == task

# Generated at 2022-06-25 06:24:54.067429
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    print('Test Task: __repr__')
    testTaskObj = Task()
    testTaskObj.__repr__()
    testTaskObj.__repr__()


# Generated at 2022-06-25 06:24:59.374683
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Test case setup
    task = Task()
    task.create_role()
    task.add_parent()
    task.add_child()
    task.set_loader(MagicMock())

    # Test case execution
    #get_vars
    result = task.get_vars()

    #Verification
    assert isinstance(result, dict) is True
    assert len(result) is 0


# Generated at 2022-06-25 06:25:11.989515
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task_0 = Task()

# Generated at 2022-06-25 06:25:21.841664
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task_0 = Task()
    expected = "TASK"
    assert task_0.__repr__() == expected

    task_0.action = 'wait'
    task_0.name = 'pause'
    task_0.async_val = 1
    task_0.poll = 0
    expected = "TASK: pause wait=1 poll=0"
    assert task_0.__repr__() == expected

    task_0.action = 'debug'
    task_0.args = dict(msg='hi')
    task_0.delegate_to = 'localhost'

    expected = "TASK: debug msg='hi' poll=0"
    assert task_0.__repr__() == expected

    task_0.include_role = dict(name='common')


# Generated at 2022-06-25 06:25:29.658665
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    task_0 = Task()
    block_0 = Block()
    task_include_0 = TaskInclude()
    handler_0 = Handler()

    block_0.add_task(task_include_0)
    block_0.add_task(task_0)
    block_0.add_task(handler_0)

    ti = task_0.get_first_parent_include()
    assert ti == task_include_0

# Generated at 2022-06-25 06:26:03.301901
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    """
    Test case for method deserialize of class Task
    """
    # Initialization
    task_0 = Task()

    # Testing