

# Generated at 2022-06-21 01:35:24.615902
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    '''
    Unit test for method Task.preprocess_data of class Task
    '''
    # set up object
    task = Task()

    # set up dummy metadata
    task._role = Role()

    # set up dummy loader
    task._loader = DictDataLoader({})
    result = task.preprocess_data({"first_variable": "first_value"})
    assert result.get('first_variable') is "first_value"

    # test for error
    with pytest.raises(AnsibleError):
        result = task.preprocess_data({"become": "yes"})


# Generated at 2022-06-21 01:35:31.520324
# Unit test for method load of class Task
def test_Task_load():
    
    # -----
    # Setup
    # -----

    # load() consumes a data structure, either a dict or a list, and
    # recursively creates task/block/role/include objects and associates
    # them with each other as appropriate. It returns a list of top level
    # objects, which are typically task/block objects.
 
    # -------
    # Cleanup
    # -------

    # Restore any patched functions.
    pass



# Generated at 2022-06-21 01:35:42.179217
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    import inspect
    import unittest
    from ansible.playbook.task_include import TaskInclude
    # Get the "Task", and "TaskInclude" class to unit test
    set_loader = inspect.getmembers(Task, predicate=inspect.ismethod)[0][1]
    TaskInclude_copy = inspect.getmembers(TaskInclude, predicate=inspect.ismethod)[0][1]
    # Create an empty task and an empty task include
    mytask = Task()
    mytaskinc = TaskInclude()
    # Create a loader
    loader = DictDataLoader({})
    # Set the loader
    set_loader(mytask, loader)
    TaskInclude_copy(mytaskinc, exclude_tasks=True)
    # Set the parent of the task to the TaskInclude
    mytask._

# Generated at 2022-06-21 01:35:54.153684
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    '''
    ansible.playbook.task.Task: get_include_params
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.hostvars import HostVars

    task_include = TaskInclude()
    play_context = PlayContext()

    task = Task()
    task._loader = None
    task._variable_manager = None
    task._parent = task_include

    task._attributes['action'] = 'setup'

    task_include._attributes['tags'] = frozenset(['all'])
    task_include._attributes['loop'] = 'hostvars'
    task_include._attributes['loop_control'] = LoopControl

# Generated at 2022-06-21 01:35:57.370591
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # create a task object
    task = Task()

    # test __repr__
    assert repr(task) == '<Task />'

# Generated at 2022-06-21 01:36:00.786100
# Unit test for method get_name of class Task
def test_Task_get_name():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    task = Task()
    result = task.get_name()
    assert(result == "")


# Generated at 2022-06-21 01:36:06.156997
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    assert str(task) == "<0 Task:%s::%s (implicit:%s)>" % (task.action, task.name, task.implicit)

# Generated at 2022-06-21 01:36:17.454444
# Unit test for constructor of class Task
def test_Task():

    # test Task() constructor, if no name is defined, name is set to 'test'
    task1 = Task()
    assert task1.name == 'test', 'Task: If no name is defined, name is set to "test"'

    # test Task() constructor, if no action is defined, action is set to dict()
    task2 = Task()
    assert task2.action == dict(), 'Task: If no action is defined, action is set to dict()'

    # test Task() constructor, if no args is defined, args is set to dict()
    task3 = Task()
    assert task3.args == dict(), 'Task: If no args is defined, args is set to dict()'

    # test Task() constructor, if no delegate_to is defined, delegate_to is set to ''
    task4 = Task()
    assert task4.delegate_

# Generated at 2022-06-21 01:36:18.945244
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    assert True

# Generated at 2022-06-21 01:36:26.779558
# Unit test for method copy of class Task
def test_Task_copy():
    host = Host()
    loader = DataLoader()
    variable_manager = VariableManager()
    play1 = Play()
    play2 = Play()
    block1 = Block()
    block2 = Block()
    role = Role()
    t1 = Task()
    t2 = Task()
    t11 = Task()
    t21 = Task()
    t22 = Task()
    t1.load(dict(name="test", action="test"), play=play1, blocks=[block1, block2], role=role, task_include=t11, use_handlers=True, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:36:46.062310
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    t = Task()
    t.vars = {'a': 1, 'b': 2, 'tags': 'test', 'when': 'test'}
    r = {'a': 1, 'b': 2}
    assert t.get_vars() == r


# Generated at 2022-06-21 01:36:57.616381
# Unit test for constructor of class Task
def test_Task():
    # Create a task
    task = Task()
    assert task.tags == None
    assert task.when == None
    assert task._role == None
    assert task.action == None
    assert isinstance(task.args, dict)
    assert task.delegate_to == None
    assert task.notify == None
    assert task.environment == None
    assert task.first_available_file == None
    assert task.local_action == None
    assert task.poll == None
    assert task.register == None
    assert task.transport == None
    assert task.vars == None
    assert hasattr(task, '_validate_vars')
    assert task.run_once == False
    assert task.any_errors_fatal == None
    assert task.changed_when == None
    assert task.failed_when == None


# Generated at 2022-06-21 01:37:09.397814
# Unit test for method get_name of class Task
def test_Task_get_name():
    # Test existence and call of get_name
    task = Task()
    assert task.get_name() is None, 'Task.get_name should return None'

    # Test if get_name returns the name and if it is the right type
    task = Task()
    task._attributes['name'] = 'Test'
    assert task.get_name() == 'Test', 'Task.get_name should return a name'
    assert isinstance(task.get_name(), string_types), 'Task.get_name should return a string as type'

    # Test if get_name returns the name and if it is the right type
    task = Task()
    task._attributes['name'] = ['Test']
    assert task.get_name() == 'Test', 'Task.get_name should return a name'

# Generated at 2022-06-21 01:37:14.925526
# Unit test for constructor of class Task
def test_Task():
    from ansible.inventory.host import Host

    host = Host('127.0.0.1')
    task = Task()
    assert task.__class__.__name__ == 'Task'
    assert task.hosts == [host]
    assert task.name == 'TASK'
    assert task.action == 'meta'
    # load_action_plugin('meta')

# Generated at 2022-06-21 01:37:24.799209
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task_vars = dict(
        action='set_fact',
        delegate_to='localhost',
        loop_control=dict(loop_var='item', label='{{item}}'),
        loop='{{ _playbook | list_playbook_paths }}',
    )
    task_valid_attrs = C.TASK_VALID_ATTRIBUTES
    task_valid_attrs.update(C.COMMON_VALID_ATTRIBUTES)
    task = Task(task_vars, task_valid_attrs, C.TASK_COMMON_ATTRIBUTES)
    assert task.get_include_params() == dict()

# Generated at 2022-06-21 01:37:31.938112
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    assert repr(task) == '<Task>'

# Things are still in testing but also production now
# Since this is assignement of a list and iteration through it
# to check if something is in it, it will always have the same results
# We can not mock a dict,
# Therefore we use the same list as in the real code

# Generated at 2022-06-21 01:37:45.001496
# Unit test for method deserialize of class Task

# Generated at 2022-06-21 01:37:56.871151
# Unit test for method serialize of class Task
def test_Task_serialize():
    # create a temporary directory and file
    tempdir = tempfile.gettempdir()
    tempdir = os.path.join(tempdir, "test_Task_serialize")
    if os.path.exists(tempdir):
        shutil.rmtree(tempdir)
    os.mkdir(tempdir)

    temp_file = os.path.join(tempdir, "test_serialize")
    with open(temp_file, 'w') as f:
        f.write("""---
- hosts: all
  tasks:
    - name: test serialize
      command: this is a test
""")

    # create a temporary inventory file
    temp_inventory_file = os.path.join(tempdir, "test_inventory")
    with open(temp_inventory_file, 'w') as f:
        f

# Generated at 2022-06-21 01:38:03.556326
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # Test cases for method get_first_parent_include of class Task
    first_parent_include = Task(dict())
    assert first_parent_include.get_first_parent_include() is None

    assert first_parent_include.get_first_parent_include() is None
    # Currently we are not testing the case where parent is provided
    # and whether that parent is itself included in another task
    # because when we can get the parent of a task then we can test
    # this functionality
    # assert first_parent_include.get_first_parent_include() is None


# Generated at 2022-06-21 01:38:06.129171
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # main
    t = Task()
    t.get_first_parent_include()


# Generated at 2022-06-21 01:38:27.185795
# Unit test for constructor of class Task
def test_Task():
    ds = dict(action='shell', args='ls')
    block_snippet = dict(block=ds)
    task = Task.load(block_snippet)
    assert task._attributes['action'] == 'shell'


# Generated at 2022-06-21 01:38:39.353467
# Unit test for method get_name of class Task
def test_Task_get_name():
    # test get_name
    task = Task()
    task._attributes['static'] = True
    task._attributes['name'] = u'ping'
    assert task.get_name().encode('utf-8') == b'ping'
    # test get_name when static and name are not set
    task = Task()
    assert task.get_name() is None
    # test get_name when static is false
    task = Task()
    task._attributes['static'] = False
    task._attributes['name'] = u'ping'
    assert task.get_name().encode('utf-8') is None
    # test get_name when name is not set
    task = Task()
    task._attributes['static'] = True
    assert task.get_name().encode('utf-8') is None
    #

# Generated at 2022-06-21 01:38:45.751317
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    # Set up object
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict(foo='bar')
    templar = Templar(loader=None, variables=variable_manager)
    task = Task()
    task.post_validate(templar)
    assert task.action == 'meta'
    assert task.args == dict(_raw_params='setup')
    task.action = 'some_action'
    try:
        task.post_validate(templar)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
    task.args = dict(a=1, b=2, c=3)
    task.post_validate(templar)
    assert task.action

# Generated at 2022-06-21 01:38:51.982318
# Unit test for method get_name of class Task
def test_Task_get_name():

    # create an instance of the class we want to test
    t = Task()
    t.action = 'setup'

    # call the function we are testing
    results = t.get_name()

    # assert the results
    assert results == 'setup'



# Generated at 2022-06-21 01:38:54.945667
# Unit test for constructor of class Task
def test_Task():
    '''
    constructor test for class Task
    '''
    task = Task()
    assert task

# Generated at 2022-06-21 01:39:07.966053
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    t = Task()
    # Setup a templar for use
    mocker.patch('ansible.template.Templar._load_template', return_value=dict())
    templar = Templar(loader=DictDataLoader(dict()))
    # Setup a 'mock' task that we can call post_validate on
    tsk = Task()
    # Decrement the inventory usage in the task, so that we can use it
    # We want to avoid needing to load an inventory.
    tsk.decrement_listening_priorities()
    # Get the inventory being used by the templar
    inv = templar.available_variables.get('inventory', None)
    # Setup some data that we can use to populate our test task

# Generated at 2022-06-21 01:39:18.596251
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():

    import ansible.playbook.block
    t = Task()
    t._parent = ansible.playbook.block.Block()
    assert t.all_parents_static()

    t._parent._parent = ansible.playbook.block.Block()
    assert t.all_parents_static()

    t._parent._parent = ansible.playbook.block.Block()
    t._parent._parent.statically_loaded = False
    assert not t.all_parents_static()

    t = Task()
    assert t.all_parents_static()

    t._parent = ansible.playbook.task_include.TaskInclude()
    t._parent.statically_loaded = False
    assert t.all_parents_static()

# Generated at 2022-06-21 01:39:19.584116
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize({})


# Generated at 2022-06-21 01:39:25.865693
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    arg_0 = 'test arg_0'


    # Arguments close to function Task.__init__
    arg_1 = b'arg_1'


    # Arguments close to function Task.__init__
    arg_2 = 'arg_2'


    # Arguments close to function Task.__init__
    tmp_obj = Task(arg_0, arg_1, arg_2, 
                   loader=C.DEFAULT_LOADER, variable_manager=C.DEFAULT_VARIABLE_MANAGER,
                   shared_loader_obj=False, play=None
                   )

    # Test function Task.__repr__ with arguments

# Generated at 2022-06-21 01:39:37.524809
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    """Task: deserialize method unit test"""
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # Test setup
    data = dict()
    data['parent'] = dict()
    data['parent_type'] = 'Block'
    data['role'] = dict()
    data['implicit'] = True
    data['resolved_action'] = 'test'
    data['name'] = 'test'
    data['action'] = 'test'
    data['block'] = 'test'
    data['when'] = 'test'
    data['async_val'] = 1
    data['changed_when'] = 'test'
    data['check_mode'] = True
    data['delay'] = 1

# Generated at 2022-06-21 01:39:58.278589
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # given:
    class ParentTask(object):
        def __init__(self):
            self.implicit = False
            self.resolved_action = 'test_action'
            self._role = None
            self._attributes = dict()
    task = Task()
    task._loader = DictDataLoader({})
    task._variable_manager = None
    task._attributes = dict()
    task._parent = ParentTask()
    # when:
    result = task.__repr__()
    # then:
    assert isinstance(result, str)
    assert result == 'test_action'


# Generated at 2022-06-21 01:40:02.705571
# Unit test for method get_name of class Task
def test_Task_get_name():
    '''
    Unit test for method get_name of class Task
    '''

    task = Task()
    task.name = 'test name'
    assert task.get_name() == 'test name'


# Generated at 2022-06-21 01:40:13.302382
# Unit test for method copy of class Task
def test_Task_copy():

  mock_base = MagicMock()
  mock_base.copy.return_value = "copied_base"
  mock_base_type = create_autospec(Base)
  mock_base_type.return_value = mock_base
  mock_base_type.copy.return_value = "copied_base"


# Generated at 2022-06-21 01:40:19.166816
# Unit test for constructor of class Task
def test_Task():
    t = Task()
    assert t._parent is None
    assert t._role is None
    assert t._uuid == "TASK"
    assert isinstance(t.vars, dict)
    assert t.name is None
    assert t.loop is None
    assert t.action is None
    assert t.args == dict()


from ansible.playbook.role import Role
from ansible.playbook.role_include import IncludeRole
from ansible.playbook.block import Block
from ansible.template import Templar

# Generated at 2022-06-21 01:40:23.731334
# Unit test for method copy of class Task
def test_Task_copy():

    mytask = Task()
    assert mytask.copy() is not None
    assert mytask.copy().__class__.__name__ == 'Task'
    assert mytask.copy() != mytask



# Generated at 2022-06-21 01:40:31.862102
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    # creating object without args
    t = Task()
    # creating mock to be used as an argument
    x = Mock(name='x')
    x.all_parents_static.return_value = True
    t._parent = x

    assert(t.all_parents_static() == True)
    x.assert_has_calls(call.all_parents_static())

    # creating object without args
    t = Task()
    # creating mock to be used as an argument
    x = Mock(name='x')
    x.all_parents_static.return_value = False
    t._parent = x

    assert(t.all_parents_static() == False)
    x.assert_has_calls(call.all_parents_static())

    # creating object without args
    t = Task()
    t._parent = None

# Generated at 2022-06-21 01:40:42.046577
# Unit test for method load of class Task
def test_Task_load():
    from ansible.errors import AnsibleParserError, AnsibleUndefinedVariable
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    import t_path.ansible_collections.nsbl.test.plugins.module_utils.test as test
    # Value is normal
    # test_dict = {'foo': ['bar', 'baz'], 'bazinga': 'foo'}
    # test_list = [{'foo': ['bar', 'baz'], 'bazinga': 'foo'}]
    # test_str = '{"foo": ["bar", "baz"], "bazinga": "foo"}'
    # Return None
    # Return None
   

# Generated at 2022-06-21 01:40:45.373968
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    print(format("test Task set_loader implementation", "*^90"))
    task = Task()
    task.set_loader("loader")
    assert task._loader == "loader"


# Generated at 2022-06-21 01:40:52.108348
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    t_include = TaskInclude()
    t = Task()
    t._parent = t_include
    assert t.get_first_parent_include() == t_include

TaskModule = Task

# Generated at 2022-06-21 01:40:59.712841
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    t = Task()
    assert t.get_first_parent_include() is None

    class TaskIncludeSub(TaskInclude):
        def __init__(self): pass

    t1 = TaskInclude()
    t2 = TaskIncludeSub()
    t.set_parent(t1)
    t1.set_parent(t2)
    assert t.get_first_parent_include() is t1

    class TaskSub(Task):
        def __init__(self): pass

    t3 = TaskSub()
    t2.set_parent(t3)
    assert t3.get_first_parent_include() is t1


# Generated at 2022-06-21 01:41:22.749970
# Unit test for method get_name of class Task
def test_Task_get_name():
    """
    Test function for method get_name of class Task.
    """
    
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(foo='bar')
    

# Generated at 2022-06-21 01:41:24.877866
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Makes sure we can handle an empty task
    #
    # Task()
    task = Task()
    assert task
    task.post_validate(templar=None)

# Generated at 2022-06-21 01:41:26.092343
# Unit test for method serialize of class Task
def test_Task_serialize():

    s = Task(dict())
    s.serialize()


# Generated at 2022-06-21 01:41:27.870975
# Unit test for constructor of class Task
def test_Task():
    t = Task()
    assert t._attributes['name'] == 'task'
    assert t._attributes['_attrs']['name'].private == True



# Generated at 2022-06-21 01:41:32.291896
# Unit test for method get_name of class Task
def test_Task_get_name():
    current_task = Task()
    current_task._parent = Block()
    current_task._parent._parent = Play()
    current_task.name = 'hello'

    assert current_task.get_name() == 'hello'

# Generated at 2022-06-21 01:41:42.979111
# Unit test for method deserialize of class Task

# Generated at 2022-06-21 01:41:51.754788
# Unit test for constructor of class Task
def test_Task():
    # create a task
    Task(dict())
    try:
        Task(1)
    except AnsibleError as e:
        pass
    else:
        raise

    task1 = Task(dict(action=dict(module='command', args='ls -l')))
    assert task1.action == 'command'
    assert task1.args == dict(args='ls -l')
    assert task1.action is not None

    task2 = Task(dict(action=dict(module='command', args=dict(chdir='/tmp', _raw_params='ls -l'))))
    assert task2.action == 'command'
    assert task2.args == dict(chdir='/tmp', _raw_params='ls -l')
    assert task2.action is not None


# Generated at 2022-06-21 01:41:58.575400
# Unit test for method serialize of class Task
def test_Task_serialize():
    t = Task()
    t._finalized = True
    t.deserialize({'action': 'setup', 'name': 'gather info', 'tags': ['always'], 'when': 'ansible_facts.distribution != "Debian"'})
    assert t.serialize() == {'action': 'setup', 'name': 'gather info', 'tags': ['always'], 'when': 'ansible_facts.distribution != "Debian"'}



# Generated at 2022-06-21 01:42:09.572837
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Tests for when dictionary not passed in
    t = Task()
    t.preprocess_data()
    assert t.resolved_action is None == True

    # Tests for when action is not in the dictionary
    test_dict = {'foo': 'bar'}
    t = Task()
    t.preprocess_data(test_dict)
    assert t.action is None == True

    # Tests for when action is in the dictionary
    test_dict = {'action': 'test'}
    t = Task()
    t.preprocess_data(test_dict)
    assert t.action == 'test'

    # Tests for when action is in the dictionary and delegate_to is not
    test_dict = {'action': 'test'}
    t = Task()
    t.preprocess_data(test_dict)

# Generated at 2022-06-21 01:42:12.208844
# Unit test for method get_name of class Task
def test_Task_get_name():
    t = Task()
    t.name = 'test name'
    assert t.get_name() == t.name



# Generated at 2022-06-21 01:42:31.129429
# Unit test for method get_name of class Task
def test_Task_get_name():
    T = Task()
    T.register_loader(DataLoader())

    data_samples = [
        (
            {'action': 'copy'},
            'copy'
        ),
        (
            {'action': 'copy', 'name': 'test'},
            'test'
        ),
        (
            {'action': 'copy', 'name': '{{test}}'},
            '{{test}}'
        ),
    ]
    for data, expected_value in data_samples:
        T.load_data(data)
        result = T.get_name()
        assert result == expected_value



# Generated at 2022-06-21 01:42:38.378760
# Unit test for constructor of class Task
def test_Task():

    block = Block()
    task = Task()
    task.load({})
    assert task._attributes['name'] is None
    assert task._parent is None

    task2 = Task()
    task2.load({'block': block, 'name': 'foo'})
    assert task2._attributes['name'] == 'foo'
    assert task2._parent is block

    task3 = Task()
    task3.load({'block': block})
    assert task3._attributes['name'] is None
    assert task3._parent is block

# Generated at 2022-06-21 01:42:43.315098
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    host = Host()
    task = Task()
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    task.post_validate(templar=templar)
    

# Generated at 2022-06-21 01:42:47.959902
# Unit test for method deserialize of class Task
def test_Task_deserialize():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play import Play
  loader = DataLoader()
  inventory = InventoryManager(loader=loader, sources='localhost,')
  variable_manager = VariableManager(loader=loader, inventory=inventory)
  play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-21 01:42:58.828873
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    p1 = Play()
    p2 = Play()
    b1 = Block()
    b2 = Block()
    b1.load(dict(name='testBlock', tasks=[dict(action='debug', args=dict(msg='test'))]))
    b2.load(dict(name='testBlock', tasks=[dict(action='debug', args=dict(msg='test'))]))
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    ti1.load(dict(static=0))
    ti2.load(dict(static=1))
    h

# Generated at 2022-06-21 01:43:10.053083
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    import ansible.playbook.task_include  as task_include
    import ansible.playbook.block as block
    import ansible.playbook.role_include as role_include
    test_item = Task()
    test_item.args = {}
    test_item.action = 'testaction'

# Generated at 2022-06-21 01:43:10.943865
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    pass

# Generated at 2022-06-21 01:43:12.688854
# Unit test for method get_name of class Task
def test_Task_get_name():
    test_task = Task()
    test_task._attributes['name'] = "my name"
    assert test_task.get_name() == "my name"


# Generated at 2022-06-21 01:43:19.221720
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    args = dict()
    args['handler'] = "handler"
    args['loop'] = "loop"
    task_data = dict()
    task_data['action'] = "action"
    task_data['any_errors_fatal'] = "any_errors_fatal"
    task_data['async'] = "async"
    task_data['async_val'] = "async_val"
    task_data['block'] = "block"
    task_data['changed'] = "changed"
    task_data['connection'] = "connection"
    task_data['container'] = "container"
    task_data['delegate_to'] = "delegate_to"
    task_data['environment'] = "environment"
    task_data['failed'] = "failed"
    task_data['failed_when']

# Generated at 2022-06-21 01:43:25.357308
# Unit test for method load of class Task
def test_Task_load():
    host_list = [dict(hostname = 'localhost', port = 22)]
    loader, _, _, inventory = collections_loader(host_list)

# Generated at 2022-06-21 01:43:48.979039
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    # Setup testcase with default values
    task = Task()
    task.action = 'command'
    task.args = dict()
    task.delegate_to = 'localhost'
    task.collections = None
    task.role = None
    task.run_once = False
    task.register = 'result'
    task.when = ''
    task.async_val = 0
    task.async_timeout = 10
    task.notify = []
    task.poll = 0
    task.until = ''
    task.retries = 1
    task.delay = 0
    task.first_available_file = None
    task.local_action = ''
    task.transport = 'smart'
    task.vars = dict()
    task.tags = []
    task.environment = dict()
    task.no

# Generated at 2022-06-21 01:43:58.068840
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    display=Display()
    loader=DataLoader()
    vault_secrets=None
    vault_password_files=None
    new_stdin=None
    variable_manager=VariableManager()

# Generated at 2022-06-21 01:44:08.020844
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    data = load_data_from_file('task_params.yml')
    t = Task()
    t.deserialize(data)
    assert t.action == 'ping'
    assert t.args['data'] == 'pong'
    assert t.delegate_to == '{{ inventory_hostname }}'
    assert t.ignore_errors == True
    assert t.when == 'ansible_facts["distribution"] == "Ubuntu"'
    assert t.loop == '{{ play_hosts }}'
    assert t.loop_control == {"label": "item1"}
    assert t.register == 'shell_out'
    assert t.tags == ['tag1', 'tag2']
    assert t.vars['var1'] == 'var1'
    assert len(t.loop_with_items) == 2

# Generated at 2022-06-21 01:44:09.391564
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    obj = Task()
    assert repr(obj)

# Generated at 2022-06-21 01:44:18.251864
# Unit test for constructor of class Task
def test_Task():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    block = Block()
    block.block = [ { 'name' : 'test_block' } ]
    module_name = 'ping'
    module_args = 'pong'
    delegate_to = 'localhost'
    loop_control = None
    loop = 'pong'
    first_available_file = 'test-file-path'
    until = None
    retries = 3
    delay = 10
    register = 'test_register'
    when = None
    run_once = True
    tags = ['tag1', 'tag2']
    store_errors_on_failed = False
    ignore_errors_on_failed = False

# Generated at 2022-06-21 01:44:26.979698
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    my_obj = Task()
    my_obj.deserialize({"action": {"shell": "echo foo"}, "register": "result", "name": "this is a name", "any_errors_fatal": True})
    assert my_obj.implicit is False
    assert my_obj.resolved_action == "shell"
    assert my_obj.serialize() == {'block': 0, 'name': 'this is a name', 'action': {'shell': 'echo foo'}, 'any_errors_fatal': True, 'register': 'result'}

# Generated at 2022-06-21 01:44:34.925389
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    t1 = Task()
    t2 = Task()
    t2._parent = t1
    t3 = Task()
    t3._parent = t2
    t4 = Task()
    t4._parent = t3
    assert t4.get_first_parent_include() == None
    t5 = Task()
    assert t5.get_first_parent_include() == None


# Generated at 2022-06-21 01:44:36.939520
# Unit test for method serialize of class Task
def test_Task_serialize():
    obj = Task()
    obj.serialize()
    pass
