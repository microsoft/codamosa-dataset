

# Generated at 2022-06-21 01:35:13.498642
# Unit test for method post_validate of class Task
def test_Task_post_validate():

    task = Task()
    task._variable_manager = '_variable_manager'
    task._loader = '_loader'

    # Calling post_validate method without required arguments raises
    # AnsibleParserError
    with pytest.raises(AnsibleParserError):
        task.post_validate()


# Generated at 2022-06-21 01:35:26.202101
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible_collections.ansible.builtin.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    import os
    from ansible.utils.display import Display

# TODO - Need to create a mock ansible-playbook command to trigger test_cases
#    test_cases = [
#        {'task': {'name': 'test task 1'},
#         'expected':
#         }
#    ]

#    for test_case in test_cases:
#        display = Display()
#        play_context = PlayContext()
#        play = Play.load({

# Generated at 2022-06-21 01:35:37.714656
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    data = {
        "when": "ansible_facts['distribution'] == 'Ubuntu'",
        "_raw_params": "xyz",
        "action": "command",
        "delegate_to": "localhost",
        "args": {
            "_raw_params": "xyz"
        }
    }
    task_ds = task.preprocess_data(data)
    assert task_ds["action"] == "command"
    assert task_ds["delegate_to"] == "localhost"
    assert task_ds["args"]["_raw_params"] == "xyz"
    assert task_ds["args"]["cmd"] == "xyz"
    assert task_ds["when"] == "ansible_facts['distribution'] == 'Ubuntu'"

# Generated at 2022-06-21 01:35:47.393932
# Unit test for constructor of class Task
def test_Task():
    # constructor without arguments
    t = Task()
    assert t.action == 'meta'
    assert t.args == dict()
    assert t.delegate_to is None

    # constructor with action
    t = Task(action='copy')
    assert t.action == 'copy'
    assert t.args == dict()
    assert t.delegate_to is None

    # constructor with action and args (dict)
    t = Task(action='copy', args=dict(src='a.txt', dest='b.txt'))
    assert t.action == 'copy'
    assert t.args == dict(src='a.txt', dest='b.txt')
    assert t.delegate_to is None

    # constructor with action and args (dict), delegate_to

# Generated at 2022-06-21 01:35:51.444990
# Unit test for method get_name of class Task
def test_Task_get_name():
    aTask = Task()
    aTask.set_loader(DictDataLoader({}))
    aTask.action = 'command'
    aTask._attributes['name'] = 'test_get_name'

    assert aTask.get_name() == 'test_get_name'


# Generated at 2022-06-21 01:36:02.534942
# Unit test for method copy of class Task
def test_Task_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    task = Task()

# Generated at 2022-06-21 01:36:09.179479
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    task.vars = {'tags': 'foo'}
    task.action = 'notify'
    assert task.get_include_params() == {'tags': 'foo'}

    task.action = 'include'
    assert task.get_include_params() == {}



# Generated at 2022-06-21 01:36:11.603750
# Unit test for method deserialize of class Task
def test_Task_deserialize():
	t = Task()
	t.deserialize(data)
	assert t.action == 'setup'
	assert t.args == {'filter': 'ansible_local'}
	assert t.delegate_to == 'test'

# Generated at 2022-06-21 01:36:24.085192
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    Task_instance = Task()
    Task_instance.deserialize({"action": "shell", "become": False, "delegate_to": "", "environment": {}, "loop": "", "loop_control": {"loop_var": ""}, "no_log": False, "register": "", "remote_user": "", "until": "", "when": "", "with_items": "", "with_sequence": "", "args": {}, "tags": [], "vars": {}})
    assert Task_instance.action == 'shell'
    assert Task_instance.become is False
    assert Task_instance.delegate_to == ''
    assert Task_instance.environment == {}
    assert Task_instance.loop == ''
    assert Task_instance.loop_control == {"loop_var": ""}
    assert Task_instance

# Generated at 2022-06-21 01:36:36.422091
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    try:
        _json = json
    except ImportError:
        try:
            import simplejson as _json
        except ImportError:
            # Python 2.6
            import json as _json

    # Unit test for method get_include_params of class Task
    # Input data for test case task_include_params

# Generated at 2022-06-21 01:37:00.652758
# Unit test for method load of class Task
def test_Task_load():
    # Set up mock variables
    ds = dict()
    ds["action"] = "Action"
    ds["args"] = dict()
    ds["delegate_to"] = "Delegate To"
    impl = Base()

    # Run method
    task_impl = Task()
    result = task_impl.load(ds=ds, variable_manager=impl, loader=impl)
    assert(result is None)

# Generated at 2022-06-21 01:37:01.247597
# Unit test for method get_name of class Task
def test_Task_get_name():
    pass

# Generated at 2022-06-21 01:37:02.987256
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()
    assert task.serialize() is not None



# Generated at 2022-06-21 01:37:12.202988
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Test with an action not in the task
    task = Task()
    task._attributes['action'] = 'test'
    task._attributes['name'] = 'test'
    assert task.__repr__() == "TASK 'test' (test)"
    # Test with an action in the task
    task._attributes['action'] = 'test1'
    assert task.__repr__() == "TASK 'test1' (test)"
    # Test with a task without a name
    task._attributes['name'] = None
    assert task.__repr__() == "TASK 'test1'"
    # Test with a task with a name set to an empty string
    task._attributes['name'] = ''
    assert task.__repr__() == "TASK ''"
    # Test with a task

# Generated at 2022-06-21 01:37:22.785090
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()

# Generated at 2022-06-21 01:37:31.304022
# Unit test for method get_name of class Task
def test_Task_get_name():
    task_1 = Task()
    setattr(task_1, '_attributes', {"name": "test_name_1"})
    assert task_1.get_name() == "test_name_1"

    task_2 = Task()
    setattr(task_2, '_attributes', {"name": None})
    assert task_2.get_name() == None


# Generated at 2022-06-21 01:37:37.295573
# Unit test for method copy of class Task
def test_Task_copy():
  task = Task()
  debug = "preprocessor basic-branch"
  exclude_tasks = True
  exclude_parent = True

  task.copy(exclude_parent = True, exclude_tasks =  True)

# Generated at 2022-06-21 01:37:44.531390
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    obj = Task(None)
    def side_effect(attr):
        if attr == 'statically_loaded':
            return True
        if attr == '_parent':
            return Task(None)
        return Sentinel
    obj.get_first_parent_include = mock.MagicMock(return_value=Task(None))
    obj.get_first_parent_include().__getattribute__ = mock.MagicMock(side_effect=side_effect)
    assert obj.all_parents_static() == True


# Generated at 2022-06-21 01:37:56.648127
# Unit test for method load of class Task
def test_Task_load():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


    # Create a new AnsibleTask object
    task_ds = {
        'name': 'task',
    }
    task = Task.load(task_ds, None, None, None)

    # Check that the name of this AnsibleTask is correctly set
    # Note that this test is not the most straightforward way to check the AnsibleTask 'name' property. Directly calling Task.load.name is not possible.
    assert task._attributes['name'] == 'task'

    # Create a new AnsibleTask object
    task_ds = {
        'name': 'task',
        'action': 'action',
        'args': {},
    }
    task = Task.load(task_ds, None, None, None)

    #

# Generated at 2022-06-21 01:38:00.264923
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # TODO: mock required to include Playbook() and Role()
    task = Task(None, {})
    task.post_validate()



# Generated at 2022-06-21 01:38:11.913681
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task._attrs = {'a': 'b'}
    assert task.__repr__() == 'Task(a=b)'


# Generated at 2022-06-21 01:38:14.785084
# Unit test for method get_name of class Task
def test_Task_get_name():
    pass

# Generated at 2022-06-21 01:38:17.316129
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task._attributes['name'] = 'test_var'
    assert task.get_name() == 'test_var'



# Generated at 2022-06-21 01:38:25.476366
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    from ansible.module_utils._text import to_text

    def _unsafe_wrap(value):
        return UnsafeProxy(value)

    def _unsafe_unwrap(value):
        if isinstance(value, UnsafeProxy):
            return value.value
        return value

    def to_safe_text(value, encoding='utf-8'):
        if isinstance(value, text_type):
            return value
        if isinstance(value, binary_type):
            return to_text(value, encoding=encoding)

        return to_text(value)

    pc = Play

# Generated at 2022-06-21 01:38:29.659448
# Unit test for method __repr__ of class Task
def test_Task___repr__():

    # Setup
    task = Task()

    # Exercise
    task___repr__result = task.__repr__()

    # Verify
    assert task___repr__result == '<Task (/path/to/playbook/:0)>'


# Generated at 2022-06-21 01:38:39.651500
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    # first use case in documentation
    x = Task()
    x.statically_loaded = False
    assert not x.all_parents_static()

    # second use case
    x._parent = Task()
    x._parent.statically_loaded = False
    x._parent._parent = Task()
    x._parent._parent.statically_loaded = False
    x._parent._parent._parent = Task()
    assert not x.all_parents_static()

    # third use case
    x = Task()
    x.statically_loaded = False
    x._parent = Task()
    x._parent.statically_loaded = True
    x._parent._parent = Task()
    x._parent._parent.statically_loaded = False
    assert not x.all_parents_static()

    # fourth use case
    x = Task()

# Generated at 2022-06-21 01:38:46.153771
# Unit test for method copy of class Task

# Generated at 2022-06-21 01:38:54.609312
# Unit test for method get_name of class Task
def test_Task_get_name():
    host_name = 'localhost'
    host_vars = {}
    host_options = {}
    host = Host(name=host_name, host_vars=host_vars, host_options=host_options)
    task = Task()
    task.get_name()
    name = task._attributes['name']  # Change the task name

    assert_equal(name, task.get_name())



# Generated at 2022-06-21 01:39:03.138411
# Unit test for method copy of class Task
def test_Task_copy():
    task = Task()
    task._parent = Block()
    task._role = Role()
    
    copy = task.copy()
    assert copy != task
    assert copy._parent != task._parent
    assert copy._role != task._role
    assert copy.implicit == task.implicit
    assert copy.resolved_action == task.resolved_action

# Generated at 2022-06-21 01:39:05.767559
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    obj = Task()
    assert obj.all_parents_static() == True

# Generated at 2022-06-21 01:39:29.497670
# Unit test for method get_name of class Task
def test_Task_get_name():
    parent = Block()
    role = Role()
    role.get_name = lambda: 'role'
    task = Task()
    name = 'test'
    task.set_loader = lambda a: None
    task._attributes = {'name': name}
    assert name == task.get_name()
    task._parent = parent
    assert 'task' == task.get_name()
    task._role = role
    assert 'role' == task.get_name()

# Generated at 2022-06-21 01:39:38.835682
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    data = {
        "action": "command", # this is required arg we are faking for the test,
                            # normally this is a string but for the purposes of this test
                            # we will be using a dict to represent the module info
        "args": {
            "cmd": "echo",
            "chdir": "shell",
            "_raw_params": "Hello World"
        },
        "environment": {
            "SHELL": "/bin/bash",
            "TERM": "ansi"
        },
        "changed_when": "True",
        "failed_when": "True",
        "vars": {
            "var1": {
                "var2": "var3"
            }
        },
        "tags": ["tag1", "tag2"]
    }

# Generated at 2022-06-21 01:39:45.545011
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()

    task.action = 'ping'
    assert task.get_name() == 'ping'

    task.name = 'ping'
    assert task.get_name() == 'ping'

    task.name = 'ping_it'
    assert task.get_name() == 'ping_it'


# Generated at 2022-06-21 01:39:48.568996
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    # This import creates the class
    from ansible.playbook.task import Task
    Task()


# Generated at 2022-06-21 01:39:59.311738
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task.action = 'debug'
    task.resolved_action = 'debug'
    task.args = {}

    # Check when fully qualified path is not provided
    task.args['msg'] = "/foo/bar/baz"
    assert task.get_name() == 'debug (msg)/foo/bar/baz'

    # Check when fully qualified path is provided
    task.args['msg'] = "/foo/bar/baz"
    assert task.get_name() == 'debug (msg)/foo/bar/baz'

    # Check when task is not a debug task
    task.action = 'copy'
    assert task.get_name() == 'copy'


# Generated at 2022-06-21 01:40:02.040585
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    obj = Task(task_include=None)
    obj.set_loader(loader=None)

# Generated at 2022-06-21 01:40:09.922169
# Unit test for method load of class Task
def test_Task_load():

    loader1 = DataLoader()
    variable_manager1 = VariableManager()
    variable_manager1._extra_vars = {'tags': ['foo', 'bar']}

    task1 = Task()
    task1._variable_manager = variable_manager1
    task1._loader = loader1

    task1.load({'block': 'block', 'tags': ['foo', 'bar'], 'when': 'when', 'name': 'name', 'action': 'action'}, parent_block=loader1.task_compile('block'))



# Generated at 2022-06-21 01:40:19.126273
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext
    # Initializing member variables
    vault_secrets_file = DEFAULT_VAULT_PASSWORD_FILE
    vault_password = AnsibleUnsafeText('')
    v = VaultLib(password_files=[vault_secrets_file])
    if vault_password:
        v.read_vault_password_files(None)
    vault_password = v.get_decryption

# Generated at 2022-06-21 01:40:29.544579
# Unit test for method serialize of class Task
def test_Task_serialize():
    args = dict(action='get_url', module_defaults=["foo"],
                loop=42, tags=['a','b'], when='c', local_action='d', with_items=[1,2,3],
                register='d', ignore_errors=False,
                delegate_to='e', delegate_facts=False, environment=dict(a='b'),
                changed_when='f', failed_when='g', until='h', delay='i', rescue='j', always='k',
                loop_control=dict(loop_var='l', loop_items='m'),
                _raw_params='n', args=dict(foo='bar'), async_val=78, poll=1, run_once=True)

    module_args = dict(a='b', c='d')
    module_vars = dict(e='f')

# Generated at 2022-06-21 01:40:34.353691
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Unit test for method post_validate of class Task
    # Setup test objects
    t = Task()
    # Example call to method
    t.post_validate()

# Generated at 2022-06-21 01:41:14.599838
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.post_validate(obj)


# Generated at 2022-06-21 01:41:25.122204
# Unit test for constructor of class Task
def test_Task():
    # check that it accepts keywords that are in the _valid_attrs
    T = Task(name="foo", foo="bar", when="baz", run_once=False, delegate_to="localhost")
    for attr in T._valid_attrs:
        value = getattr(T, attr)
        # some default values
        if value is DEFAULT_KEEP or value is DEFAULT_NULL:
            value = None
        assert T._attributes[attr] == value

    # but nothing else
    try:
        T = Task(name="foo", foobar="baz")
        assert False
    except AnsibleParserError:
        pass

    # verifies that the implicit constructor works
    T1 = Task(dict(name="foo"))
    T2 = Task(dict(name="foo", action="bar"))

# Generated at 2022-06-21 01:41:36.625736
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    tasks = [
        Task(action='setup', name='Gather facts'),
        Task(action='debug', name='Debug', args={
            'msg': 'System {{inventory_hostname}}'
        }),
        Task(action='debug', name='Debug', args={
            'msg': 'System {{inventory_hostname}}'
        })
    ]
    tasks[1].static = False
    tasks[2].static = False
    tasks[1]._parent = tasks[0]
    tasks[2]._parent = tasks[0]
    tasks[0]._parent = None
    assert tasks[0].all_parents_static() == True
    assert tasks[2].all_parents_static() == False
    assert tasks[1].all_parents_static() == False


# Generated at 2022-06-21 01:41:38.388721
# Unit test for method load of class Task
def test_Task_load():
    t = Task()
    mock_ds = Mock()
    t.load(mock_ds)

# Generated at 2022-06-21 01:41:41.796562
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    # mock_loader = mock.Mock()
    # task = Task('name')
    # task.set_loader(mock_loader)
    # assert task._loader == mock_loader
    pass



# Generated at 2022-06-21 01:41:42.393235
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    pass

# Generated at 2022-06-21 01:41:45.568120
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Create an instance of class Task without mandatory attributes
    task = Task()
    # Use the method without arguments
    repr_ = task.__repr__()
    # Verify the instance returned
    assert repr_ is None


# Generated at 2022-06-21 01:41:53.054589
# Unit test for method deserialize of class Task
def test_Task_deserialize():
  obj = Task(name="foo",play=play_some_play)
  setattr(obj,'_attributes',{'tags':None})
  setattr(obj,'_play',play_some_play)
  setattr(obj,'_role',role_some_role)
  obj.deserialize(data={'parent': None, 'role': None, 'tags': {}})


# Generated at 2022-06-21 01:42:01.124971
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    r = Role()
    r.role_name = 'debug'
    r.role_path = 'N/A'
    r.roles_path = 'N/A'
    b = Block()
    t = Task()
    t._role = r
    t._parent = b
    t._attributes['name'] = 'mytesttask'
    t._attributes['action'] = 'testaction'
    assert repr(t) == '<Task (debug): mytesttask>'



# Generated at 2022-06-21 01:42:12.396209
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    import copy
    import os
    import sys
    import pytest
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.unicode import to_bytes, to_unicode

    def _task__init__(self):
        Base.__init__(self)
        self._parent = None
        self._role = None
        self.loop = None


# Generated at 2022-06-21 01:42:50.554169
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    slot1 = None  # TODO: put expected value here
    slot2 = None  # TODO: put expected value here
    slot3 = None  # TODO: put expected value here

    # Call function and check return values and side effects.
    # TODO: uncomment these as necessary
    # assert task.post_validate(slot1) == expected
    # assert task.post_validate(slot2) == expected
    # assert task.post_validate(slot3) == expected



# Generated at 2022-06-21 01:42:59.658665
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    """
      test method all_parents_static of class Task
    """
    # define the following constant
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_1['tasks'] = [dict_2]
    dict_2['include'] = dict_3
    dict_2['when'] = 'test'
    dict_3['static'] = False
    dict_3['test'] = 'test'
    list_1 = dict()
    dict_2['vars'] = list_1
    dict_2['register'] = 'test'
    dict_2['free_form'] = 'test'
    dict_4 = dict()
    dict_4['name'] = 'a'
    dict_4['value'] = 'a'

# Generated at 2022-06-21 01:43:10.428432
# Unit test for method get_name of class Task

# Generated at 2022-06-21 01:43:14.945997
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task._preprocess_data()
    task.preprocess_data()
    task.preprocess_data(use_handlers=False)
    task.preprocess_data(use_handlers=True)

# Generated at 2022-06-21 01:43:17.552648
# Unit test for constructor of class Task
def test_Task():

    task = Task()
    assert task is not None


# Generated at 2022-06-21 01:43:28.433684
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    assert task.get_name() == ""
    task.action="setup"
    assert task.get_name() == "setup"
    task.action="ping"
    task.args={
        "_raw_params":"localhost",
        "data":"hello world"
    }
    assert task.get_name() == "ping localhost"
    task.action="shell"
    task.args={
        "_raw_params":"cat /tmp/output | wc -l",
        "creates":"/tmp/output",
        "executable":"/bin/bash"
    }
    assert task.get_name() == "shell cat /tmp/output | wc -l"

# Generated at 2022-06-21 01:43:29.944173
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # FIXME:
    return True



# Generated at 2022-06-21 01:43:39.449866
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    #################################################
    # Task.get_include_params() include_role_tasks #
    #################################################

    desc = "Task.get_include_params() get include params"
    t = Task() # initiating the object outside the function.
    t.vars = {'role_name': 'MyRole'}
    t.action = 'include_role'
    params = t.get_include_params()
    expected_result = {'role_name': 'MyRole'}
    assert params == expected_result,\
    "Task.get_include_params() should return a dictionary of paramaters for the include."

    ############################################
    # Task.get_include_params() include_tasks #
    ############################################

    desc = "Task.get_include_params() get include params"
    t = Task()

# Generated at 2022-06-21 01:43:44.833638
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    parent = Task()
    parent._parent = Task()
    parent.statically_loaded = False
    parent._parent.statically_loaded = False
    result = parent.all_parents_static()
    assert result == False


# Generated at 2022-06-21 01:43:48.569521
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    pb = Playbook.load('../../ansible/test/sanity/inventory/hosts', variable_manager=VariableManager(), loader=Loader())
    task = pb.get_tasks()[0][0]
    print(task.all_parents_static())
if __name__=="__main__":
    test_Task_all_parents_static()