

# Generated at 2022-06-21 01:35:17.122484
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    assert Task().all_parents_static() == True

# Generated at 2022-06-21 01:35:18.196141
# Unit test for method load of class Task
def test_Task_load():
    # This method is tested in test_tasks.
    pass


# Generated at 2022-06-21 01:35:25.807354
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    t = Task()
    m = mock.mock_open()
    with mock.patch("ansible.playbook.task.open", m, create=True):
        t.set_loader("/path/to/collections")
    m.assert_called_with("/path/to/collections/ansible_collections/ansible/builtin/action_plugins/all.yaml", "rb")
# end class Task



# Generated at 2022-06-21 01:35:33.294381
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Create an instance of class Task to test preprocess_data
    task = Task()
    # Assert the default value of _search_paths
    assert task._search_paths == [u'roles/']

    # Assert the default value of _loader
    assert task._loader == None

    # Assert the default value of _role
    assert task._role == None

    # Assert the default value of _tqm
    assert task._tqm == None

    # Assert the default value of _variable_manager
    assert task._variable_manager == None

    # Assert the default value of argspec
    assert task.argspec == None

    # Assert the default value of _loop
    assert task._loop == None

    # Assert the default value of _loop_type

# Generated at 2022-06-21 01:35:39.497498
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    t = Task()
    t.action = "include"
    t._parent = TaskInclude()
    t.vars = {'a': 1, 'b': 2, 'c':3}
    assert t.get_include_params() == {'a': 1, 'b':2, 'c':3}


# Generated at 2022-06-21 01:35:43.858962
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    mock_loader = MagicMock()
    task = Task()
    task.set_loader(mock_loader)
    assert task._loader is mock_loader



# Generated at 2022-06-21 01:35:51.299248
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    for test_case in test_Task_preprocess_data.cases:
        task = test_case['task']

        # validation for test_case
        assert isinstance(task._ds, dict)
        assert isinstance(task._valid_attrs, dict)
        assert isinstance(task._attributes, dict)
        assert isinstance(task._variable_manager, object)
        assert isinstance(task._loader, object)
        assert isinstance(task._parent, object)
        assert isinstance(task._role, object)
        assert isinstance('id', str)
        assert isinstance('block', int)
        assert isinstance('when', str)
        assert isinstance('async_val', int)
        assert isinstance('poll', int)
        assert isinstance('always_run', bool)

# Generated at 2022-06-21 01:36:02.479167
# Unit test for method copy of class Task
def test_Task_copy():
	t=Task();
	r1=t.copy();
	assert r1.__dict__ == t.__dict__;
	assert id(r1) != id(t);
	assert id(r1._parent) == id(t._parent);
	assert id(r1._role) == id(t._role);
	assert r1.resolved_action == t.resolved_action;
	# assert id(r1.resolved_action) == id(t.resolved_action);
	assert r1.implicit == t.implicit;
	assert id(r1.implicit) == id(t.implicit);
	assert r1.action == t.action;
	assert id(r1.action) == id(t.action);
	assert r1.loop == t.loop;

# Generated at 2022-06-21 01:36:04.204520
# Unit test for method serialize of class Task

# Generated at 2022-06-21 01:36:15.703583
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    from ansible.vars.hostvars import HostVars

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    task = Task()
    variable_manager = VariableManager()
    variable_manager._fact_cache['ansible_facts'] = dict()
    variable_manager._fact_cache['ansible_facts']['env'] = dict()
    variable_manager._fact_cache['ansible_facts']['env']['ANSIBLE_YAML_FILENAME'] = "task"
    variable_manager._fact_cache['ansible_facts']['env']['ANSIBLE_YAML_LINE_NUMBER'] = "1"

# Generated at 2022-06-21 01:36:31.166234
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task.name = 'ping'
    assert task.get_name() == 'ping'


# Generated at 2022-06-21 01:36:32.678648
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.post_validate(None)


# Generated at 2022-06-21 01:36:36.525012
# Unit test for method get_name of class Task
def test_Task_get_name():
    # Task is a subclass of Base for which we have a test for get_name
    # Nothing to test here
    pass

# Generated at 2022-06-21 01:36:39.997111
# Unit test for method copy of class Task
def test_Task_copy():
    data1 = dict(
        action = dict(module = 'setup')
    )
    task = Task()
    task.load(data1, variable_manager=None, loader=None)
    module = task.action

    new_module = task.copy()

    assert type(module) == type(new_module)
    assert module.__dict__ == new_module.__dict__


# Generated at 2022-06-21 01:36:41.379562
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()

    task.post_validate('templar')


# Generated at 2022-06-21 01:36:50.022827
# Unit test for constructor of class Task
def test_Task():

    t = Task()
    assert t.__class__.__name__ == 'Task'
    assert t.action == 'meta'
    assert t.loop == None
    assert t.ignore_errors == False
    assert t.any_errors_fatal == False
    assert t.register == None
    assert t.delegate_to == None
    assert t.notify == []
    assert t.first_available_file == None
    assert t.local_action == None
    assert t.transport == 'smart'
    assert t.remote_user == None
    assert t.sudo == False
    assert t.sudo_user == None
    assert t.sudo_pass == False
    assert t.changed_when == None
    assert t.failed_when == None
    assert t.needs_info_module == False
    assert t.poll

# Generated at 2022-06-21 01:36:51.288472
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    pass


# Generated at 2022-06-21 01:36:52.556297
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    '''
    Unit test for method set_loader of class Task
    '''
    pass

# Generated at 2022-06-21 01:36:56.222715
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    t = Task()
    if t.all_parents_static() == True:
        print("Success")
    else:
        print("Failure")

# Generated at 2022-06-21 01:37:07.855098
# Unit test for method preprocess_data of class Task

# Generated at 2022-06-21 01:37:35.568042
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()
    data = task.serialize()
    assert data
    assert data['_ansible_verbose_always'] == False
    assert data['any_errors_fatal'] == False
    assert 'always_run' not in data
    assert 'changed_when' not in data
    assert 'check_mode' not in data
    assert 'continue_on_error' not in data
    assert 'delimiter' not in data
    assert 'environment' not in data
    assert 'failed_when' not in data
    assert 'first_available_file' not in data
    assert 'ignore_errors' not in data
    assert 'loop' not in data
    assert 'loop_control' not in data
    assert 'notify' not in data
    assert 'poll' not in data
    assert 'register' not in data
   

# Generated at 2022-06-21 01:37:41.845051
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    #
    # Test method post_validate of class Task
    #
    # This test method has not been implemented yet, because we think
    # it is not essential for the daily business.
    #
    print(__name__ + ': Unittest for method post_validate of class Task')


# Generated at 2022-06-21 01:37:54.905595
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    t = Task()
    assert t.get_first_parent_include() == None
    assert None == t.deserialize({}).get_first_parent_include()
    assert None == t.deserialize({'parent': {}}).get_first_parent_include()
    assert None == t.deserialize({'parent': {'_attributes': {}}}).get_first_parent_include()
    # next assertion is a problem.
    # The deserialize loads the parent attribute, but it doesn't set it in the Task
    # so there is no parent in the end.
    # This may also be a problem in other deserialize methods in this file.
    # assert None == t.deserialize({'parent': {'_attributes': {'tags': {}}}}).get_first_parent_include()

# test

# Generated at 2022-06-21 01:38:00.759177
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    t = Task()
    data = {u'action': u'shell', u'name': u'list /etc/hosts', u'args': {u'_raw_params': u'cat /etc/hosts', u'creates': u'/tmp/etc-hosts', u'removes': u'/tmp/etc-hosts'}}
    t.deserialize(data)
    assert t.action == u'shell'
    assert t.name == u'list /etc/hosts'
    assert t.args == {u'_raw_params': u'cat /etc/hosts', u'creates': u'/tmp/etc-hosts', u'removes': u'/tmp/etc-hosts'}


# Generated at 2022-06-21 01:38:09.897405
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.task_vars = {'a': 'value', 'b': {'d': 'd_value'}}
    task.block_vars = {'b': {'c': 'c_value'}}
    task.role = Role()
    task.role.vars = {'b': {'b_key': 'b_value'}}

    # test dictionary concatenation
    data = {}
    data['vars'] = {'a': 'new_value', 'b': {'c': 'new_c_value', 'b_key': 'new_b_value'}}
    task._preprocess_data(data)

# Generated at 2022-06-21 01:38:13.974267
# Unit test for method copy of class Task
def test_Task_copy():
    # Test for method copy (1/1) of class Task
    # Testing: Return a Task object with a parent, but no other attributes set
    a = Task()
    t = Task()
    t._parent = a
    assert t.copy() == a



# Generated at 2022-06-21 01:38:18.306020
# Unit test for method load of class Task
def test_Task_load():
    '''
    Unit test for method load of class Task
    '''
    task = Task()
    task.load(dict(action='action',))
    assert isinstance(task.data, dict)
    assert task.action == 'action'
    assert task.args == dict()
    assert task.delegate_to == ''


# Generated at 2022-06-21 01:38:28.998547
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    
    # Create mock objects

# Generated at 2022-06-21 01:38:38.001504
# Unit test for constructor of class Task
def test_Task():
    '''
    task.py
    --------
    This is a test for the constructor of the class Task
    '''
    # Create YML structure for the test
    yaml_str = '''
    ---
    - name: Test task
      action: test
    '''
    yaml_ds = yaml.load(yaml_str)
    #print(yaml_ds)
    
    # Execute the code
    task = Task()
    task._load_data(yaml_ds[0])
    #print(task)
    
    # Assert test
    assert task is not None
    assert task.name == 'Test task'
    assert task.action == 'test'

# Generated at 2022-06-21 01:38:47.198576
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Save backup
    import ansible
    backup_ansible = ansible
    from ansible.module_utils.parsing.convert_bool import boolean
    ansible.module_utils.parsing.convert_bool.boolean = mock_boolean
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    # Set-up data
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:39:02.967155
# Unit test for method load of class Task
def test_Task_load():
    loader_mock = MagicMock()
    t = Task()
    t.load(loader_mock, dict(name='task_name', action=dict(module='setup')))
    assert t.action == 'setup'
    assert t.name == 'task_name'


# Generated at 2022-06-21 01:39:04.596523
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task._attributes['name'] = 'helloworld'
    #test the real output vs the expected output
    assert 'helloworld' == task.get_name()


# Generated at 2022-06-21 01:39:17.459806
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    class TestTaskInclude:
        pass
    class TestTask:
        def __init__(self, task_include=None):
            self._parent = task_include
    class TestTaskWithoutParent(TestTask):
        def __init__(self):
            self._parent = None

# Generated at 2022-06-21 01:39:19.938585
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    pass # TODO


# Generated at 2022-06-21 01:39:21.568867
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    result = task.__repr__()
    assert result == 'TASK: None'

# Generated at 2022-06-21 01:39:23.089989
# Unit test for method get_name of class Task
def test_Task_get_name():

    # Getting the value of name attribute
    task = Task()
    value = task.get_name()
    # Validating the value of name attribute
    assert value is None


# Generated at 2022-06-21 01:39:26.600477
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    T = Task()
    # return the value of the get_vars method
    # check if the value of the get_vars method is correct with isinstance
    # 
    pass


# Generated at 2022-06-21 01:39:37.807226
# Unit test for method load of class Task
def test_Task_load():
    from ansible.module_utils.six import PY3

    task = Task()
    task.load({
        '__ansible_module__': 'ping',
        '__ansible_arguments__': {
            'data': 'testdata'
        }
    })

    assert task.action == 'ping'
    assert isinstance(task.args, dict)
    assert task.args['data'] == 'testdata'

    task = Task()
    task.load({
        '__ansible_module__': 'ping',
        '__ansible_arguments__': {
            'data': 'testdata'
        },
        'delegate_to': 'localhost'
    })

    assert task.action == 'ping'
    assert isinstance(task.args, dict)

# Generated at 2022-06-21 01:39:50.625166
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    Task._variable_manager = Mock()
    Task._variable_manager.get_vars = Mock(return_value = {'vars': False })
    Task._loader = Mock()
    Task._loader.get_basedir = MagicMock(return_value = '/path/to/test/')


# Generated at 2022-06-21 01:39:59.088874
# Unit test for constructor of class Task
def test_Task():
    ds = dict(
        action='test',
        register='test_result',
        tags=[1, 2, 3],
        until=[4, 5, 6]
    )
    t = Task()
    t.load(ds)
    assert t.action == 'test'
    assert t.tags == [1, 2, 3]
    assert t.until == [4, 5, 6]
    assert t.register == 'test_result'

    # Verify that the keys were removed from the dictionary
    for key in ds.keys():
        assert not ds[key]



# Generated at 2022-06-21 01:40:18.767310
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import tempfile
    import yaml
    import os
    import json
    import pprint
    import shutil
    import ansible.plugins.loader

    data = {'hosts': 'localhost', 'become': False, 'tasks': [{'name': 'Example Task', 'action': {'module': 'command', 'args': 'echo hi'}}]}


# Generated at 2022-06-21 01:40:28.567050
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task2 = Task()
    task3 = Task()
    task3.action = "include_role"
    task3.args = {'name': 'foo'}
    task3.collection_name = "test"
    task3.collection_version = "1.0"
    task2.action = "include_role"
    task2.args = {'name': 'foo'}
    task2.collection_name = "test"
    task2.collection_version = "1.0"
    task.action = "include_role"
    task.args = {'name': 'foo'}
    task.collection_name = "test"
    task.collection_version = "1.0"
    task._parent = task2
    task2._parent = task3
    templar = MagicM

# Generated at 2022-06-21 01:40:40.895032
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    ansible_vars = {}
    ansible_vars['ansible_collection_path'] = []
    ansible_vars['ansible_config'] = './ansible.cfg'
    ansible_vars['ansible_executable'] = '/usr/bin/ansible'
    ansible_vars['ansible_facts'] = {'log_dir': '/var/log/ansible', 'pkg_mgr': 'apt', 'python_version': 3, 'system_vendor': 'Google', 'system_vendor_id': 'ptp'}
    ansible_vars['ansible_inventory_sources'] = ['127.0.0.1']
    ansible_vars['ansible_managed'] = 'Ansible managed: Do not edit this file manually!'

# Generated at 2022-06-21 01:40:42.966552
# Unit test for constructor of class Task
def test_Task():

    t = Task()
    assert t is not None
    assert t.__class__.__name__ == 'Task'


# Generated at 2022-06-21 01:40:48.840759
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    t = Task()
    t._parent = Task()
    t._parent.vars ={"vars1","abc"}
    t.vars = {"vars2","xyz"}
    t.action = "setup"
    assert t.get_include_params() == {"vars1","abc"}
    t.action = "something"
    assert t.get_include_params() == {"vars1","abc","vars2","xyz"}

# Generated at 2022-06-21 01:40:59.232518
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()
    dict1 = dict()
    dict1['k1'] = 'v1'
    dict2 = dict()
    dict2['k2'] = 'v2'
    dict3 = dict()
    dict3['k3'] = 'v3'
    class1 = Playbook()
    class1._variable_manager = dict1
    class2 = Task()
    class2._parent = class1
    class2.vars = dict2
    class3 = Task()
    class3._parent = class2
    class3.vars = dict3
    result = class3.get_vars()
    assert result == {'k1': 'v1', 'k3': 'v3'}


# Generated at 2022-06-21 01:41:10.988039
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():

    from ansible.playbook.block import Block

    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext

    # Instantiate a DataLoader() and a VariableManager() objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/home/vagrant/ansible_source/test/unit/inventory'])
    variables = VariableManager(loader=loader, inventory=inventory)

    # Instantiate a PlayContext() and a Task() objects
    context = PlayContext(loader=loader, inventory=inventory, variable_manager=variables, options=None, passwords=dict())
    block = Block()

# Generated at 2022-06-21 01:41:13.633908
# Unit test for method get_vars of class Task
def test_Task_get_vars():


    task = Task()
    task.vars = {'foo': 42}
    assert task.get_vars() == {'foo': 42}

# Generated at 2022-06-21 01:41:17.558765
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    args = {
            'action': 'command',
            'args': {'_raw_params': "{{  a }}"}}
    t = Task()
    t.load(args, variable_manager=VarsModule())
    t.set_loader(DataLoader())


# Generated at 2022-06-21 01:41:24.876304
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    """
        Unit test for method set_loader of class Task
    """
    # Arrange
    t = Task()
    loader = DictDataLoader({
        'default': {'my_tasks': """---
- name: working
  ping:
"""},
    })

    # Act
    t.set_loader(loader)

    # Assert



# Generated at 2022-06-21 01:41:44.078065
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    task = Task()
    task.set_loader(loader)

# Generated at 2022-06-21 01:41:48.428280
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()

    task.vars = {'test': 'var'}

    method_vars = task.get_vars()

    assert method_vars == {'test': 'var'}



# Generated at 2022-06-21 01:41:55.753435
# Unit test for method serialize of class Task
def test_Task_serialize():
    t = Task()

# Generated at 2022-06-21 01:41:57.426625
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    """Test method all_parents_static of class Task"""
    pass


# Generated at 2022-06-21 01:42:08.450907
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude


# Generated at 2022-06-21 01:42:14.473292
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    from ansible.errors import AnsibleError
    from ansible.module_utils import six
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    templar = Templar(loader=None)

    # TODO: Test disabled due to error in implementation
    # _valid_attrs = {
    #     'async': FieldAttribute(isa='int'),
    #     'async_poll_delay': FieldAttribute(isa='int'),
    #     'with_items': FieldAttribute(isa='list'),
    #     'with_file': FieldAttribute(isa='list

# Generated at 2022-06-21 01:42:18.582798
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    #
    # test get_vars method
    #
    task = Task()
    task.vars = {'var1':'value1'}
    assert task.get_vars() == {'var1':'value1'}, "ansible.playbook.task.Task.get_vars() Failed"


# Generated at 2022-06-21 01:42:21.259429
# Unit test for method load of class Task
def test_Task_load():
    # Test function Task._load start
    # Test function Task._load end
    pass


# Generated at 2022-06-21 01:42:31.428680
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    task = Task()
    task._parent = Task()

    assert task.all_parents_static()

    task._parent = Task()
    task._parent._parent = Task()
    assert task.all_parents_static()

    task._parent._parent = Task()
    task._parent._parent._parent = Task()
    assert task.all_parents_static()

    task._parent = Task()
    task._parent._parent = Task()
    task._parent._parent.statically_loaded = False
    assert task.all_parents_static()

    task._parent = Task()
    task._parent._parent = Task()
    task._parent._parent._parent = Task()
    task._parent._parent._parent.statically_loaded = False
    assert task.all_parents_static()



# Generated at 2022-06-21 01:42:35.927675
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    Task.get_first_parent_include()

# ### END OF Transplanted from ansible/playbook/task.py ###


# ### BEGIN OF Transplanted from ansible/playbook/play_context.py ###
# (plus modifications)


# Generated at 2022-06-21 01:43:10.356058
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    assert Task().all_parents_static() == True


# Generated at 2022-06-21 01:43:16.463558
# Unit test for method copy of class Task
def test_Task_copy():
    # following variables should be modified according to the output of the
    # task or handler that is being tested
    delegate_to = None
    no_log = False
    name = 'test_task'
    run_once = None
    ignore_errors = False
    any_errors_fatal = None
    sudo = False
    sudo_user = None
    remote_user = None
    connection = 'local'
    environment = None
    umask = None
    become = False
    become_user = None
    become_method = None
    become_flags = None
    when = None
    tags = None
    gather_facts = 'no'
    vars = {}
    # loop control
    loop_control = None
    # raw params
    _raw_params = None
    # action
    action = 'debug'
    args = {}

# Generated at 2022-06-21 01:43:24.504174
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    t = Task()
    ti = TaskInclude()
    t._parent = ti
    ti._parent = t
    t._parent._parent = ti
    ti._parent._parent = t
    assert t.get_first_parent_include() == t._parent



# Generated at 2022-06-21 01:43:25.930531
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    assert task.get_name() == ''



# Generated at 2022-06-21 01:43:38.099338
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    import json
    from collections import namedtuple

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = Options(connection='smart', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 01:43:47.065590
# Unit test for method get_name of class Task
def test_Task_get_name():
    '''
    Unit test for method get_name of class Task
    '''
    new_task_obj = Task()
    ansible_collections_name = 'foo.bar'
    action = 'debug'
    new_task_obj.action = action
    new_task_obj.ansible_collections_name = ansible_collections_name
    expected = '%s.%s' % (ansible_collections_name, action)
    result = new_task_obj.get_name()
    assert result == expected


# Generated at 2022-06-21 01:43:57.417776
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    task1 = Task()
    task2 = Task()
    task3 = Task()
    task_include = TaskInclude()
    parent = block
    task1.set_loader(DictDataLoader({}))
    task2.set_loader(DictDataLoader({}))
    task_include.set_loader(DictDataLoader({}))
    task3.set_loader(DictDataLoader({}))
    task1.set_parent(parent)
    task_include.set_parent(task1)
    task2._parent = task_include
    task3._parent = task2
    assert task3.all_parents_static() == True



# Generated at 2022-06-21 01:44:07.305105
# Unit test for method preprocess_data of class Task

# Generated at 2022-06-21 01:44:16.899272
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    import os
    task = Task()
    task.module_name = 'command'
    task.action = 'command'
    task.module_args = 'echo Hello Ansible'
    task.name = 'Test Ansible Module'
    task.block = 'main'
    task.delegate_to = 'localhost'
    task.no_log = False
    task.run_once = True
    task.any_errors_fatal = False
    task.loop_control = ''
    task.until = ''
    task.retries = 0
    task.register = 'ansible_output'
    task.changed_when = ''
    task.failed_when = ''
    task.ignore_errors = False
    task.vars = {}
    task.env = {}
    task.tags = []

# Generated at 2022-06-21 01:44:28.364774
# Unit test for method load of class Task
def test_Task_load():
    """Test load() of Playbook/Task."""
    # OSError
    task_ds = {
        'include': '{{ missing }}'
    }
    expected_msg = "the field 'include' has an invalid value, which appears to include a variable that is undefined. " \
                   "The error was: 'missing' is undefined\n\nThe error appears to have been in '{task_file}': line " \
                   "{line_num}, column {col_num}, but may\nbe elsewhere in the file depending on the exact syntax " \
                   "problem.\n".format(task_file='{task_file}', line_num={line_num}, col_num={col_num})