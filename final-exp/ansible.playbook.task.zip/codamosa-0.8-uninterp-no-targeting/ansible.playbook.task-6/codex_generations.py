

# Generated at 2022-06-21 01:35:24.858290
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager()
    TaskExecutor()
    playbook = PlaybookExecutor(loader=loader, inventory=inventory)
    task = Task()
    task.post_validate('templar')
    task.all_parents_static()
    task.get_first_parent_include()
    task.get_action_name()
    task.get_action_args()

# Generated at 2022-06-21 01:35:29.231168
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    with pytest.raises(AnsibleParserError):
        task_preprocess_data_test = Task()
        task_preprocess_data_test.preprocess_data({
            'a': {},
            'b': 'test_action'
        })


# Generated at 2022-06-21 01:35:34.255567
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    test_task = Task('test_task')
    assert test_task.__repr__() == "[TASK] name: test_task", "Incorrect test_Task___repr__"


# Generated at 2022-06-21 01:35:42.489072
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    t = Task()
    t.deserialize({u'deprecated': False, u'name': u'foo', u'args': {'key': 'val'}, u'static': True, u'delegate_to': u'', u'environment': {}, u'when': [], u'block': 2})

    assert t.deprecated is False
    assert t.name == u'foo'
    assert t.args == {'key': 'val'}
    assert t.static is True
    assert t.delegate_to == u''
    assert t.environment == {}
    assert t.when == []
    assert t.block == 2


# Generated at 2022-06-21 01:35:54.892127
# Unit test for method deserialize of class Task

# Generated at 2022-06-21 01:35:58.295207
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    task.action = "copy"
    task.vars = dict(src="test")
    task.connection = "ansible.netcommon.local"
    parent = Task()
    parent.action = "file"
    parent.vars = dict(path="test")
    parent.async_val = 0
    task.parent = parent
    expected = {"src": "test"}
    actual = task.get_include_params()
    assert actual == expected and task.implicit == False

# Generated at 2022-06-21 01:36:02.759424
# Unit test for constructor of class Task
def test_Task():
    '''
    Basic function of class Task
    '''
    # The task is required parameter
    task = Task(dict(action=dict()))
    # If task is not dict, it will raise an exception
    try:
        task = Task(dict(action=''))
    except Exception as e:
        assert isinstance(e, AnsibleParserError)



# Generated at 2022-06-21 01:36:14.972382
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    ansible_vars = dict()
    templar = Templar(loader=None, variables=ansible_vars)
    dict_obj = dict()
    dict_obj['action'] = 'command'
    dict_obj['args'] = dict()
    dict_obj['args']['chdir'] = '/tmp'
    dict_obj['args']['_raw_params'] = 'ls -l'
    dict_obj['delegate_to'] = 'localhost'
    dict_obj['environment'] = dict()
    dict_obj['environment']['HOME'] = '/root'
    dict_obj['environment']['PATH'] = '/usr/bin:/bin'
    dict_obj['environment']['XDG_RUNTIME_DIR'] = '/run/user/0'
    dict_obj

# Generated at 2022-06-21 01:36:23.762692
# Unit test for method copy of class Task
def test_Task_copy():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from collections import Mapping
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.template.vars import AnsibleVars
    from ansible.plugins.loader import get_all_plugin_loaders

    # Instantiate a module for testing

# Generated at 2022-06-21 01:36:27.966639
# Unit test for constructor of class Task
def test_Task():
    """
    Test the task object constructor.
    """
    ds = dict()
    t = Task()
    assert t._task.__name__ == 'Task'

# Generated at 2022-06-21 01:36:56.919102
# Unit test for method copy of class Task
def test_Task_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    include_instance = TaskInclude()
    include_instance._parent = include_instance
    task_instance = Task()
    task_instance.action = 'set_fact'
    task_instance._parent = include_instance
    block_instance = Block()
    block_instance._parent = task_instance
    task_instance._parent = block_instance
    task_instance.copy()

# Generated at 2022-06-21 01:36:58.832139
# Unit test for method get_name of class Task
def test_Task_get_name():
    assert Task.get_name() == 'task'

####################################################################################
# Class: Block
####################################################################################

# Generated at 2022-06-21 01:37:11.385368
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.action = 'setup'
    task._valid_attrs['environment'] = True
    task.environment = {}

    # bare unit test without templar
    result = task._post_validate_environment(attr='environment', value=None, templar=None)
    assert result is None

    # bare unit test with templar
    task.environment = {'foo': 'bar', 'bar': '{{ foo }}'}
    templar = Dictable()

    result = task._post_validate_environment(attr='environment', value=task.environment, templar=templar)
    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'foo' in result
    assert 'bar' in result
    assert result['foo'] == 'bar'

# Generated at 2022-06-21 01:37:13.752413
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    task.deserialize()


# Generated at 2022-06-21 01:37:23.496348
# Unit test for method load of class Task
def test_Task_load():
    loader = DictDataLoader({
        'foo.yml': """
        - hosts: all
          tasks:
            - debug:
                var: hello
            - debug:
                var: goodbye
        """,
        'bar.yml': """
        - hosts: all
          tasks:
            - debug:
                var: hello
            - debug:
                var: goodbye
        """,
        'vars.yml': """
          test_var_1:
            - "{{ some_var }}"
          test_var_2: ['hello', 'goodbye']
        """,
        'vault.yml': """
          test_var_3:
            - "{{ some_var }}"
          test_var_4: ['hello', 'goodbye']
        """,

    })
    loader.set_basedir

# Generated at 2022-06-21 01:37:35.959991
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import os
    import json

    # Initialize necessary data structures
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create a temporary directory
    temp_directory = tempfile.mkdtemp()

    # Create a inventory with a host, a group and a child group
    # Create a task file with tasks that access group and host vars
    # Create a play that refers to the inventory, task file and sets the strategy to free
    # Create a playbook that refers to the above play and runs it

# Generated at 2022-06-21 01:37:40.796475
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    ds = dict(action="setup")
    task = Task.load(ds=ds, role="test_role")
    result = task.get_vars()
    assert result == {}
    pass

# Generated at 2022-06-21 01:37:46.041413
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    assert task.get_include_params() == {}
    task = Task({}, action='include')
    task.vars = {'a': 1}
    assert task.get_include_params() == task.vars
    task.vars = {'a': 1}
    task = Task({}, action='include_role')
    task.vars = {'a': 1}
    assert task.get_include_params() == task.vars
    task = Task({}, action='playbook')
    assert task.get_include_params() == {}
    task.vars = {'a': 1}
    assert task.get_include_params() == {}

# Generated at 2022-06-21 01:37:47.899984
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    t = Task()
    assert t._loader is None
    t.set_loader('loader_data')
    assert t._loader == 'loader_data'

# Generated at 2022-06-21 01:37:50.631988
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    o = Task()
    o.set_loader(loader='loader')

    assert o._attributes.get('_loader') == 'loader'
    assert o._loader == 'loader'



# Generated at 2022-06-21 01:38:23.188400
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    '''
    Make sure that the all_parents_static method of the Task class
    properly inspects the Task's parentage for staticity.
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a Task
    task = Task()

    # Create a TaskInclude
    task_include = TaskInclude()

    # Create a HandlerTaskInclude
    handler_task_include = HandlerTaskInclude()

    # Create a Task and make it's parent the TaskInclude
    # parent and check that the method returns False
    # since the Task and TaskInclude are not both statically_loaded
    assert not task.all_parents_static()

    # Set statically_loaded on the Task

# Generated at 2022-06-21 01:38:35.946496
# Unit test for method load of class Task
def test_Task_load():
    D = dict()
    D['__ansible_module__'] = 'module'
    D['action'] = 'action'
    D['args'] = 'args'
    D['async_val'] = 'async_val'
    D['changed_when'] = 'changed_when'
    D['delegate_to'] = 'delegate_to'
    D['environment'] = 'environment'
    D['failed_when'] = 'failed_when'
    D['loop'] = 'loop'
    D['loop_args'] = 'loop_args'
    D['loop_control'] = 'loop_control'
    D['register'] = 'register'
    D['remote_user'] = 'remote_user'
    D['retries'] = 'retries'
    D['until'] = 'until'

# Generated at 2022-06-21 01:38:42.115501
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    test_1 = {"vars": {
        "foo": "test",
        "bar": "test2"
         }
    }
    d = Task()
    d.post_validate(None)
    d._attributes = test_1
    assert d.get_vars() == test_1['vars']

    test_2 = {"vars": {
            "foo": "test",
            "tags": "test2"
        }
    }
    d._attributes = test_2
    assert d.get_vars() == test_2['vars']


# Generated at 2022-06-21 01:38:43.224913
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    t = Task()
    t.post_validate(Templar())

# Generated at 2022-06-21 01:38:56.864371
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()

    task._role = Role()
    task._variable_manager = DictData()
    task._loader = DictData()
    new_ds = dict()
    collections_list = []
    default_collection = 'ansible_collections.ansible'
    if collections_list:
        if default_collection not in collections_list:
            collections_list.insert(0, default_collection)
    else:
        collections_list = [default_collection]
    if collections_list and 'ansible.builtin' not in collections_list and 'ansible.legacy' not in collections_list:
        collections_list.append('ansible.legacy')
    ds = dict()
    ds["action"] = "debug"
    ds["args"] = dict()

# Generated at 2022-06-21 01:39:10.010888
# Unit test for method get_name of class Task
def test_Task_get_name():
    args = dict(action='test', async_=None, async_poll_interval=0, become=None, become_user=None,
                check_mode=False, delay=None, ignore_errors=False, loop='', name='', no_log=False, poll=0,
                register='', retries=0, run_once=False, until='', vars={}, with_items=[], with_first_found=None,
                with_flattened=[], with_loop=[], with_subelements=[], with_together=None, with_dict=[])
    t = Task()
    t.load(args=args)
    if t.get_name() == '':
        print('Task.get_name(): PASS')
    else:
        print('Task.get_name(): FAIL')


# Generated at 2022-06-21 01:39:17.288881
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # create dummy instances of Play, Role
    play = Play()
    role = Role()
    # create dummy instances of Task and Block
    # which includes Task
    task = Task()
    task.action = 'name'
    block = Block()
    block.block = ['task', 'block_task']
    block.role = role
    block.dynamic_block_items = ['block_task']
    block.parent = play
    task.parent = block
    task.vars = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    # Task's action is specified, so parent TaskInclude's vars is ignored
    block.action = 'include_tasks'
    result = task.get_include_params()

# Generated at 2022-06-21 01:39:29.673311
# Unit test for method copy of class Task
def test_Task_copy():
    """
    Test Task.copy()
    """
    import copy
    import ansible.template
    # 'Task' is a type of a
    a = Task()
    # p - parent
    p = Task()
    a._parent = p
    # r - role
    r = Role()
    a._role = r
    a.implicit = True
    a.resolved_action = "Fake Action"

    b = a.copy()
    assert(a is not b)
    assert(a._parent is not b._parent)
    assert(a._role is not b._role)
    assert(a.implicit == b.implicit)
    assert(a.resolved_action == b.resolved_action)

    a._parent = None
    a._role = None
    a.implicit = False
    a

# Generated at 2022-06-21 01:39:39.672610
# Unit test for method load of class Task
def test_Task_load():


    # mock object for templar
    templar = MagicMock()

    # mock object for PlayContext
    PlayContext = MagicMock()

    from ansible.vars.manager import VariableManager
    class VariableManager(VariableManager):
        pass

    # initialise object attributes
    ia_play_context = PlayContext()
    ia_task_vars = dict()
    ia_variable_manager = VariableManager()


    # initialise object
    task = Task(play_context=ia_play_context,
                task_vars=ia_task_vars,
                variable_manager=ia_variable_manager)

    # test function
    task.load('tasks', task_ds={'block': 'foo'})



# Generated at 2022-06-21 01:39:51.279446
# Unit test for method serialize of class Task
def test_Task_serialize():
    t = Task()

# Generated at 2022-06-21 01:40:18.195563
# Unit test for method serialize of class Task

# Generated at 2022-06-21 01:40:22.795990
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    my_task = Task("TEST", "/path/to/TEST")

    # Ensure that the task can be represented correctly
    assert repr(my_task) == "TEST"


# Generated at 2022-06-21 01:40:31.349916
# Unit test for method load of class Task
def test_Task_load():
    task = fake_load(Task(), {}, [], [], 'role', None, loader=None, variable_manager=None)

    #  Test __init__() with no-args

# Generated at 2022-06-21 01:40:33.956630
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    test_preprocess_data(Task)


# Generated at 2022-06-21 01:40:39.226926
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task=Task()
    task.vars = {'type':'test'}
    task._parent = Task()
    task._parent.vars = {'name':'parent_vars'}
    task.get_vars()
    assert task.get_vars()=={'name':'parent_vars', 'type':'test'}



# Generated at 2022-06-21 01:40:48.925043
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    t = Task()
    assert not t.all_parents_static()
    b = Block()
    b.statically_loaded = False
    t._parent = b
    assert not t.all_parents_static()
    ti = TaskInclude()
    ti.statically_loaded = True
    t._parent = ti
    assert t.all_parents_static()
    ti.statically_loaded = False
    assert not t.all_parents_static()
    hti = HandlerTaskInclude()
    hti.statically_loaded = True
    ti._parent = ti
    assert t.all_parents_static()
    h

# Generated at 2022-06-21 01:40:51.512470
# Unit test for method load of class Task
def test_Task_load():
    module = task.Task()
    assert module != None


# Generated at 2022-06-21 01:40:52.492499
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    pass

# Generated at 2022-06-21 01:41:01.472830
# Unit test for method serialize of class Task
def test_Task_serialize():
    hosts = [
        "localhost",
    ]
    current_path = os.path.dirname(os.path.realpath(__file__))
    parent_path = os.path.abspath(os.path.join(current_path, os.pardir))
    sys.path.insert(0, parent_path)
    from test.units.compat import unittest
    from test.units.compat.mock import patch, MagicMock
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 01:41:04.701730
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    t = Task()
    ds = dict(action='test', name='test_name')
    assert_equals(t.preprocess_data(ds), ds)


# Generated at 2022-06-21 01:41:24.331033
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    assert task.get_name() == None
    task.name = "test"
    assert task.get_name() == "test"
    task.action = "test"
    assert task.get_name() == "test"

# Generated at 2022-06-21 01:41:35.539981
# Unit test for method serialize of class Task
def test_Task_serialize():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    host = Host(name="test", groups=["group1"])
    host.set_variable("ansible_connection", "local")
    host.set_variable("ansible_python_interpreter", "/usr/bin/python")

    group = Group(name="group1")
    group.add_host(host)

    # block = dict(
    #     when = "{{ value }}",
    #     tasks = [
    #         dict(name="Test", get_url=dict(url="http://www.example.com/index.html", dest="/tmp/index.html"))
    #     ]
    # )

# Generated at 2022-06-21 01:41:44.065304
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    fake_ds = {"action": "fake_action", "local_action": "fake_local_action",
               "args": "fake_args", "delegate_to": "fake_delegate_to",
               "other": "fake_other", "tags": "fake_tags"}

    new_ds = {"action": "fake_action", "local_action": "fake_local_action",
               "args": "fake_args", "delegate_to": "fake_delegate_to",
               "other": "fake_other", "tags": "fake_tags"}

    fake_task = Task()
    output = fake_task.preprocess_data(fake_ds)
    assert output == new_ds

# Generated at 2022-06-21 01:41:53.656528
# Unit test for constructor of class Task
def test_Task():
    # Test with no attributes
    t = Task()
    assert t._attributes['name'] is None
    assert t._attributes['action'] is None
    assert t._attributes['notify'] == []
    assert t._attributes['vars'] == {}
    assert t._attributes['environment'] == {}
    assert t._attributes['delegate_to'] is None
    assert t._attributes['run_once'] is False
    assert t._attributes['local_action'] is None
    assert t._attributes['transport'] is None
    assert t._attributes['connection'] is None
    assert t._attributes['loop'] is None
    assert t._attributes['loop_control'] == DEFAULT_LOOP_CONTROL

    # Test with attributes

# Generated at 2022-06-21 01:41:57.721000
# Unit test for method copy of class Task
def test_Task_copy():
    t = Task()
    t._valid_attrs = {'name': {},
                      'action': {},
                      'args': {},
                      'any_errors_fatal': {}}
    t._init_attributes()
    t.action = 'ping'
    t.args = {'data': 'this should not be here'}
    new_t = t.copy()
    assert not new_t.action == t.action
    assert not new_t.args == t.args


# Generated at 2022-06-21 01:41:59.591488
# Unit test for method get_name of class Task
def test_Task_get_name():
    obj = Task(name='unit_test_Task')
    assert obj.get_name() == 'unit_test_Task'

# Generated at 2022-06-21 01:42:04.959590
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    def test_set_loader(self, ds):
        '''
        Sets the loader on this object and recursively on parent, child objects. This is used primarily after the
        Task has been serialized/deserialized, which does not preserve the loader.
        '''
        pass
    pass



# Generated at 2022-06-21 01:42:08.194383
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    my_task = Task()
    my_task.vars = {'a':1, 'b':2}
    assert my_task.get_vars() == {'a':1, 'b':2}


# Generated at 2022-06-21 01:42:13.500355
# Unit test for method load of class Task
def test_Task_load():
    test_task = Task()
    loader = DictDataLoader({
        "pass.yml": """
        - name: task1
          debug:
        """
    })
    play_ds = dict(
        name="A Test Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(include='pass.yml')
        ]
    )
    play = Play().load(play_ds, loader=loader, variable_manager=variable_manager, loader_cache={})
    assert test_task._load_tasks(play_ds, play, variable_manager=variable_manager, loader=loader)[0].action == 'debug'


# Generated at 2022-06-21 01:42:18.040818
# Unit test for method copy of class Task
def test_Task_copy():
    t = Task.load(
        dict(action=dict(module='test'), register='test_task_var'))
    t_copy = t.copy()
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # task is not templated yet

# Generated at 2022-06-21 01:42:48.323683
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    t = Task()

    assert True == t.all_parents_static()

    t._parent = Task()
    assert False == t.all_parents_static()

# Generated at 2022-06-21 01:42:58.941630
# Unit test for method get_name of class Task
def test_Task_get_name():
    data = {'use_delegate_to': True, 'name': 'test task', 'run_once': True}
    obj = Task()
    obj.name = 'test task'
    obj.loop = ['1', '2']
    obj.delegate_to = 'some_host'
    obj.delegate_facts = True
    obj.run_once = True
    obj.register = 'result'
    obj.changed_when = 'changed'
    obj.include_role = dict(name='common')
    obj.include_tasks = 'common.yml'
    obj.tags = ['always']
    obj.async_val = 10
    obj.poll = 0
    obj.when = 'True'
    obj.local_action = 'shell ping'
    obj.action = 'shell'
    obj.register

# Generated at 2022-06-21 01:43:09.412119
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager
    #from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    #loader = DataLoader()
    #variable_manager = VariableManager()
    #inventory = InventoryManager(loader=loader, sources='localhost,')
    #play_context = PlayContext()

    #test_task = Task()
    #test_task.post_validate()
    return True


# Generated at 2022-06-21 01:43:11.975994
# Unit test for method serialize of class Task
def test_Task_serialize():
        serialize_action = "serialize"

        # action is expected to be a string
        if not isinstance(serialize_action, str):
            print('serialize_action is not a string')
            return False
        return serialize_action


# Generated at 2022-06-21 01:43:15.548075
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Arrange
    task = Task()
    task._validate_attributes = MagicMock()

    # Act
    result = task.post_validate(MagicMock())

    # Assert
    assert result == None
    assert task._validate_attributes.called == True


# Generated at 2022-06-21 01:43:27.235128
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task(None)
    task.vars = {'test_var': 10}
    task._parent = Task(None)
    task._parent.vars = {}
    task._parent.vars = {'test_parent': 20}
    task._parent._parent = Task(None)
    task._parent._parent.vars = {}
    task._parent._parent.vars = {'test_parent2': 30}
    expected_result = {'test_var': 10, 'test_parent': 20, 'test_parent2': 30}
    test_result = task.get_vars()
    assert test_result == expected_result

# Generated at 2022-06-21 01:43:35.721710
# Unit test for method load of class Task
def test_Task_load():
    my_task = Task()
    my_task._load()
    assert my_task._loader == None, 'Expected None, but got {0}'.format(my_task._loader)
    assert my_task._variable_manager == None, 'Expected None, but got {0}'.format(my_task._variable_manager)
    assert my_task.statically_loaded == False, 'Expected False, but got {0}'.format(my_task.statically_loaded)
    assert my_task.action == '', 'Expected , but got {0}'.format(my_task.action)
    assert my_task.name == None, 'Expected None, but got {0}'.format(my_task.name)

# Generated at 2022-06-21 01:43:41.176139
# Unit test for constructor of class Task
def test_Task():
    t = Task()
    t = Task.load(dict(action='setup', ignore_errors=True))
    t = Task.load(dict(action='setup', ignore_errors='True'), play=dict(become=dict(method='sudo')))

# Generated at 2022-06-21 01:43:49.921402
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():

    # Task is not a TaskInclude and neither is it's parent.
    task = Task()
    assert task.get_include_params() == {}

    # Task is a TaskInclude.
    task = TaskInclude()
    assert task.get_include_params() == {}

    # Task is not a TaskInclude but it's parent is.
    task = Task()
    task._parent = TaskInclude()
    assert task.get_include_params() == {}

    # Task is a TaskInclude
    task = TaskInclude()
    # and so is it's parent.
    task._parent = TaskInclude()
    assert task.get_include_params() == {}

    # Task is not a TaskInclude but it's parent is.
    task = Task()
    task._parent = TaskInclude()
    # And so is

# Generated at 2022-06-21 01:43:50.795742
# Unit test for method copy of class Task
def test_Task_copy():
    pass
