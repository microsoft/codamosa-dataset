

# Generated at 2022-06-21 01:35:31.166913
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['all'])
    variable_manager.set_inventory(inventory)

    task_vars_dict = {
        'a': '1',
        'b': '2',
        'c': '3',
    }
    task_ds = {
        'a': 'one',
        'b': 'two',
        'c': 'three',
    }

    task_block_ds = {
        'block': {
            'a': 'A',
            'b': 'B',
            'c': 'C',
        }
    }


# Generated at 2022-06-21 01:35:42.039850
# Unit test for method copy of class Task
def test_Task_copy():
    data_dict = {}
    data_dict['handler'] = []
    data_dict['loop'] = '{{debug_info.serial}}'
    data_dict['when'] = '{{debug_info.serial}}'
    args_parser = ModuleArgsParser(task_ds=data_dict)
    (action, args, delegate_to) = args_parser.parse()
    data_dict['action'] = action
    data_dict['args'] = args
    data_dict['delegate_to'] = delegate_to
    t = Task.load(data=data_dict)
    new_task = t.copy()
    assert isinstance(new_task, Task)
    assert new_task._attributes == t._attributes
    assert new_task._role == t._role
    assert new_task.implicit == t.implicit

# Generated at 2022-06-21 01:35:43.507070
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    assert "FIXME" in dir(Task)

# Generated at 2022-06-21 01:35:46.226284
# Unit test for method load of class Task
def test_Task_load():
    a = Task()
    # Test to load data structure onto an object of class Task
    a._load()



# Generated at 2022-06-21 01:35:55.780034
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    t = Task()
    data = dict()
    data['action'] = 'ping'
    data['args'] = {'_raw_params': 'www.baidu.com'}
    data['delegate_to'] = None
    data['block'] = True
    data['changed_when'] = 'changed'
    data['delay'] = 1
    data['environment'] = {'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8'}
    data['failed_when'] = 'failed'

# Generated at 2022-06-21 01:35:58.576691
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    import collections
    
    test_task = Task()
    test_task.post_validate(collections)



# Generated at 2022-06-21 01:36:02.376805
# Unit test for method get_name of class Task
def test_Task_get_name():
	task = Task()
	assert(task.get_name() == None)
	new_ds = {}
	new_ds['name'] = "Print Hello"
	task.preprocess_data(new_ds)
	assert(task.get_name() == "Print Hello")



# Generated at 2022-06-21 01:36:11.199265
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    my_vars = dict(a=1, b=2)
    my_args = dict(parser=dict(arg1="bar", arg2="foo", arg3="baz"))
    my_task = Task(dict(vars=my_vars, role=dict(name="my_role"), args=my_args))
    res = my_task.get_include_params()
    assert res == my_vars


# Generated at 2022-06-21 01:36:23.898200
# Unit test for method serialize of class Task
def test_Task_serialize():

    import pytest
    import sys
    import unittest

    from ansible.module_utils.six.moves import builtins
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils import context_objects as co


    class TestTaskSerialize(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_serialize(self):
            pass


# Generated at 2022-06-21 01:36:31.746841
# Unit test for constructor of class Task
def test_Task():  # pylint: disable=no-self-use
    '''
    Constructor of class Task should return a Task object
    '''

    task_name = 'Test Task'
    task_ds = dict(action='test_action')

    task = Task.load(task_ds, task_name=task_name, play=None)
    assert isinstance(task, Task)

# Generated at 2022-06-21 01:37:06.418387
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    # Given a task T
    T = Task()

    # When I call the get_vars method
    vars = T.get_vars()

    # Then I should get the T vars
    assert vars == {}


# Generated at 2022-06-21 01:37:12.437556
# Unit test for constructor of class Task
def test_Task():
    '''
    constructor of class Task
    '''
    block = Block()
    role = Role()
    loader = None
    variable_manager = None
    task = Task(block, role, loader, variable_manager)
    assert task._parent == block
    assert task._role == role
    assert task._loader == loader
    assert task._variable_manager == variable_manager


# Generated at 2022-06-21 01:37:15.387377
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    # Here is the code to perform unit test for Task.set_loader(self, loader):
    task = Task()
    loader = Task()
    task.set_loader(loader)


# Generated at 2022-06-21 01:37:19.532670
# Unit test for method get_name of class Task
def test_Task_get_name():
    '''
    Task: name
    '''
    tmp = Task()
    tmp._attributes['name'] = "name"
    assert tmp.get_name() == "name"


# Generated at 2022-06-21 01:37:28.225006
# Unit test for method get_vars of class Task

# Generated at 2022-06-21 01:37:30.970910
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()
    res = task.deserialize(data=dict())
    assert res is None


# Generated at 2022-06-21 01:37:43.280108
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    my_task = Task()
    my_task.vars = {'a':0}
    my_task._parent = DummyParent()
    my_task._parent.vars = {'a':1, 'b':2}
    my_task._parent._parent = DummyParent()
    my_task._parent._parent.vars = {'a':3, 'b':4, 'c':5}
    my_task.action = 'some_action'
    # assertEqual checks if the result is the same as the value.
    assertEqual(my_task.get_include_params(), {'a':0, 'b':2, 'c':5})

# Generated at 2022-06-21 01:37:45.678914
# Unit test for method deserialize of class Task
def test_Task_deserialize():

    # FIXME: Deserialize is not implemented
    pass

# Generated at 2022-06-21 01:37:47.982124
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    t = Task()
    t.post_validate()

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-21 01:37:48.483085
# Unit test for method load of class Task
def test_Task_load():
	pass

# Generated at 2022-06-21 01:38:10.884747
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    # Can't instantiate abstract class Task with abstract methods action,
    # delegate_to, get_vars, get_include_params, serialize
    pass

# Generated at 2022-06-21 01:38:17.228952
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    ti = TaskInclude.load(
        "",
        data={'static': True, 'name': 'mytest', 'tasks': [
            {'name': 'mytask', 'action': 'debug', 'args': {'msg': 'hello'}}]},
        variable_manager=None, loader=None, play=None)
    t = ti.get_tasks()[0]
    assert t.get_first_parent_include() == ti



# Generated at 2022-06-21 01:38:18.733362
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # FIXME:
    pass


# Generated at 2022-06-21 01:38:23.219928
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    '''
      Unit test for method post_validate of class Task
    '''
    fake_ds = dict()
    task = Task.load(fake_ds, None, None)
    templar = VariableManager()
    task.post_validate(templar)

# Generated at 2022-06-21 01:38:25.157594
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    assert True == True # executed without error





# Generated at 2022-06-21 01:38:33.602093
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    
    p = Play().load({
        'name': 'foobar',
        'hosts': ['all'],
        'tasks': [
            {'include_vars': 'vars.yml'}
        ]
    }, variable_manager=VariableManager(), loader=DictDataLoader())
    block = [block for block in p.compile()][0]
    i = [include for include in block.compile()][0]
    task = [task for task in i.compile()][0]
    assert task.get_include_params() == {}

# Generated at 2022-06-21 01:38:45.010947
# Unit test for method get_name of class Task
def test_Task_get_name():
    test_cases = [{'name': 'Task', 'data': {'name': 'Task'}},
                  {'name': 'Task', 'data': {'name': 'Task', 'name2': 'Task2'}},
                  {'name': 'Task', 'data': {'name': 'Task', 'name': 'Task'}},
                  {'name': 'Task', 'data': {}}]
    for test_case in test_cases:
        task = Task()
        task.args = test_case['data']
        assert task.get_name() == test_case['name'], 'Expected %s, got %s for data %s' % (
            test_case['name'], task.get_name(), test_case['data'])

# Generated at 2022-06-21 01:38:57.518614
# Unit test for method get_name of class Task
def test_Task_get_name():
    from ansible.playbook.task import Task
    from ansible.errors import AnsibleParserError
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    #initialize the task
    mytask=Task()
    mytask._attributes['name']='foo_bar'
    assert mytask.get_name()=='foo_bar'
    #test with strip_internal_keys=True
    assert mytask.get_name(strip_internal_keys=True)=='foo_bar'
    #Test with strip_internal_keys=False, internal_key_regexp=None

# Generated at 2022-06-21 01:39:03.290850
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()
    task.action = 'file'
    task.args = {'path': '/etc/motd', 'content': 'hello world'}
    assert task.name == 'file /etc/motd content=hello world'



# Generated at 2022-06-21 01:39:12.570194
# Unit test for constructor of class Task
def test_Task():
    pass
#    logger = logging.getLogger('Task')
#    # simple task
#    task = Task()
#    # normal task
#    task = Task(name='normal', action='command', args='echo "hello"', register='out')
#    # normal task with delegate_to
#    task = Task(name='normal', action='command', args='echo "hello"', register='out', delegate_to='127.0.0.1')
#    # simple notify
#    task = Task(name='normal', action='meta', notify='127.0.0.1')
#    # simple block
#    block = Block(block=['127.0.0.1'])
#    # simple block with delegate_to
#    block = Block(block=['127.0.0.1'], delegate_to='127.

# Generated at 2022-06-21 01:39:37.493721
# Unit test for method load of class Task

# Generated at 2022-06-21 01:39:50.440135
# Unit test for method deserialize of class Task
def test_Task_deserialize():
  # We are just testing the docstring example here
  # We do not test all of the many references in the yaml
  yaml_data = '''
  - name: Detect memory corruption
    include_tasks: ./tasks/debug/mem_debug.yml
    when: ansible_processor_cores * ansible_processor_vcpus == 2
  '''
  import os
  import sys
  import yaml
  ansible_basedir = os.path.dirname(__file__)
  data = yaml.load(yaml_data)
  n = Task(play=None,
           ds=data[0],
           connection_info=None,
           become_info=None,
           variable_manager=None)
  data_ser = n.serialize()

# Generated at 2022-06-21 01:39:54.593031
# Unit test for constructor of class Task
def test_Task():
    task = Task()

# add class to our list of ansible modules
C.MODULE_REQUIRE_ARGS = frozenset(('command', 'shell', 'script'))

# Generated at 2022-06-21 01:40:00.051619
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Create a mock to replace the ansible.module_utils.basic.AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock to replace the ansible.config.loader.Config class
    mock_Config = mock.MagicMock()
    mock_Config.config.get.return_value = None
    mock_Config.config.get.return_value = None
    _actual = Task(module_defaults=mock_AnsibleModule, config=mock_Config)
    expected = u'<Task: no task>'
    assert _actual.__repr__() == expected


# Generated at 2022-06-21 01:40:11.707960
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # without parent
    new_task = Task()
    assert new_task.get_include_params() == dict()

    # the action has not included
    new_task = Task()
    new_task.action = 'not_include'
    assert new_task.get_include_params() == dict()

    # with two parents
    new_task = Task()
    new_task.action = 'include'
    new_task.vars['foo'] = 'new_task'
    parent_task = Task()
    parent_task.action = 'include'
    parent_task.vars['bar'] = 'parent_task'
    grandparent_task = Task()
    grandparent_task.action = 'include'
    grandparent_task.vars['foobar'] = 'grandparent_task'
    parent_task._parent

# Generated at 2022-06-21 01:40:23.012938
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    with pytest.raises(AnsibleParserError) as e:
        task.preprocess_data({"name": "test_preprocess", "action": {"module": "os_router"}})

# Generated at 2022-06-21 01:40:24.933679
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # unit tests for Task.__repr__ method
    return


# Generated at 2022-06-21 01:40:29.036763
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    action = "hello"
    args = dict()
    task_executor = "task_executor"
    task_loader = "task_loader"
    variable_manager = "variable_manager"
    loader = "loader"
    tmp = Task(action, args, task_executor, task_loader, variable_manager, loader)
    assert tmp.__repr__


# Generated at 2022-06-21 01:40:33.085858
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    temp = Task(task_args = dict())
    value = temp.__repr__()
    assert value == "TASK"


# Generated at 2022-06-21 01:40:35.728711
# Unit test for method copy of class Task
def test_Task_copy():
    '''
    Unit test for method copy of class Task
    '''
    pass

# Generated at 2022-06-21 01:41:00.008050
# Unit test for method serialize of class Task
def test_Task_serialize():
    '''
    Unit test for method serialize of class Task
    '''
    args = dict(
        action='shell',
        async_val='100',
        poll='0',
        ignore_errors=False,
        executable='',
        _raw_params='ls',
        delegate_to='localhost',
        register='shell_out',
        environment=dict(),
        no_log='False',
        changed_when='False'
    )
    t = Task(task_include=dict(), **args)

# Generated at 2022-06-21 01:41:03.048739
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # TODO
    #task = Task(play=play, role=None, task_include=None, block=None, role_allow_duplicates=True, load_from_file=False)
    #ret = task.get_include_params()
    #assert ret is None
    pass


# Generated at 2022-06-21 01:41:08.015538
# Unit test for method copy of class Task
def test_Task_copy():
    '''
    Test method copy of class Task
    '''
    task_object = Task()
    assert task_object.copy()
    assert task_object.copy(exclude_parent=True)
    assert task_object.copy(exclude_tasks=True)


# Generated at 2022-06-21 01:41:11.849790
# Unit test for constructor of class Task
def test_Task():

    # test basic instantiation
    t = Task()
    assert t.name == 'Unnamed task', 'Task constructor not setting default values'

    # test basic assignment
    t = Task(name='Test task')
    assert t.name == 'Test task', 'Task constructor not setting name'

    # test assignment from a dict
    ds = dict(
        name='Test task',
        action=dict(module='ping'),
    )
    t = Task.load(ds)
    assert t.name == 'Test task', 'Task constructor not setting name'
    assert isinstance(t.action, ActionModule)
    assert t.action._attributes['module_name'] == 'ping'

# Generated at 2022-06-21 01:41:22.946461
# Unit test for method load of class Task
def test_Task_load():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    loader = DataLoader()
    # vars_manager=VariableManager()
    # inventory_manager=InventoryManager(loader=loader, sources=['localhost,'])
    # play_context=PlayContext()
    # play=Play()

    #self=Task().load(data=dict(action='shell', args='free -m', name='test load function of ansible'),
    #                block=Block(), task_include=None, role=None, use_handlers=False

# Generated at 2022-06-21 01:41:26.669629
# Unit test for method serialize of class Task
def test_Task_serialize():
	tsk = Task(None, None)
	assert tsk.serialize() == dict(action='meta', args={}, delegate_to=None, environment=None, ignore_errors=False, loop=None, loop_args=None, loop_control=None, no_log=False, register=None, tags=None, until=None, when=None, vars=None)


# Generated at 2022-06-21 01:41:38.609762
# Unit test for method get_name of class Task
def test_Task_get_name():
    def test_get_name(self, d, expected):
        self.assertEqual(self.task.get_name(d), expected)
        
    t = Task()

# Generated at 2022-06-21 01:41:48.408848
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, loader.get_basedir())
    pbex = PlaybookExecutor()

# Generated at 2022-06-21 01:41:56.110926
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    static_parent = TaskInclude('static_file')
    static_parent._attributes['static'] = True
    task = Task()
    task._parent = static_parent
    assert task.all_parents_static()

    dynamic_parent = TaskInclude('dynamic_file')
    dynamic_parent._attributes['static'] = False
    task._parent = dynamic_parent
    assert not task.all_parents_static()


# Generated at 2022-06-21 01:42:06.023585
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    # Mock the object
    options = MagicMock()
    options.connection = 'ssh'
    loader = MagicMock()
    variable_manager = MagicMock()
    display = MagicMock()
    templar = MagicMock()
    t = Task(loader=loader, variable_manager=variable_manager, display=display)
    t._attributes['action'] = '-'
    t._attributes['args'] = {}
    t._attributes['delegate_to'] = None
    # Call the method
    t.post_validate(templar)
    # Return the method output
    assert t.action == '-'
    assert t.args == {}
    assert t.delegate_to is None


# Generated at 2022-06-21 01:42:26.233921
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    my_task = Task()
    my_task.post_validate(my_task)

# Generated at 2022-06-21 01:42:30.014631
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # Set up
    unit_under_test = Task('')
    # Exercise
    repr(unit_under_test)



# Generated at 2022-06-21 01:42:37.618081
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    t1 = TaskInclude()
    t2 = Task()
    b1 = Block()
    b1._parent = t1
    t2._parent = b1
    assert t2.get_first_parent_include() == t1

if __name__ == '__main__':
    test_Task_get_first_parent_include()


# Generated at 2022-06-21 01:42:47.494822
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
  # Test a positive case
  task = Task()

# Generated at 2022-06-21 01:42:50.062463
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    # FIXME: add unit test
    pass

# Generated at 2022-06-21 01:42:59.535169
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.module_utils.common.collections import AnsibleCollection
    mock_module_utils_common_collections = mocker.patch('ansible.module_utils.common.collections.AnsibleCollection')
    mock_module_utils_common_collections.return_value = AnsibleCollection()

    mock_collection = mocker.patch.object(CollectionLoader, 'get_collection_info', return_value={'version': '1.0.0'})

    mock_ansible_module_utils_common_collections = mocker.patch.object(AnsibleCollectionConfig, 'default_collection', new_callable=PropertyMock, return_value=None)

    task = Task()
    task.preprocess_data({'resolved_action': 'include_tasks'})


# Generated at 2022-06-21 01:43:10.356918
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    import ansible.loader
    #Instantiate class Task
    task = Task()
    #Passing an object of type AnsibleLoader to the method set_loader of class Task
    task.set_loader(ansible.loader.AnsibleLoader())

    #Instantiate class TaskInclude
    task = TaskInclude()
    #Passing an object of type AnsibleLoader to the method set_loader of class TaskInclude
    task.set_loader(ansible.loader.AnsibleLoader())

    #Instantiate class HandlerTaskInclude
    task = HandlerTaskInclude()
    #Passing an object of type AnsibleLoader to the method set_loader of class HandlerTaskInclude
    task.set

# Generated at 2022-06-21 01:43:13.475467
# Unit test for method load of class Task
def test_Task_load():
    v1 = Task()
    v1.load(dict(action='action'))
    assert v1.action == 'action'

# Generated at 2022-06-21 01:43:20.563592
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()

# Generated at 2022-06-21 01:43:22.121371
# Unit test for method get_name of class Task
def test_Task_get_name():
    task = Task()



# Generated at 2022-06-21 01:43:49.504972
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    # Test data, we test with wrong data
    ds = {'name': 'test_task_preprocess_data', 'action': 'wrong', 'args': {'a': '1'}, 'other': 'value', 'vars': {}}
    # Create new task
    task = Task()
    # Run preprocess_data
    try:
        task.preprocess_data(ds)
    except AnsibleError:
        print("AnsibleError was raised as expected")
        return 0
    else:
        print("AnsibleError was not raised")
        return 1

# Generated at 2022-06-21 01:43:51.277745
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task.action = "show"
    task.args = {}
    task.delegate_to = None


# Generated at 2022-06-21 01:43:53.807615
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = get_test_task()
    env = task.get_vars()
    assert isinstance(env, dict)
    return env


# Generated at 2022-06-21 01:43:59.549012
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    ti = TaskInclude()
    t = Task()
    t._parent = ti
    assert t.get_first_parent_include() == ti


parent_loader_action_to_inherit = {'include_role': 'tags',
                                   'include_tasks': 'tags',
                                   'import_role': 'tags',
                                   'import_playbook': 'tags',
                                   'import_tasks': 'tags',
                                   'import_playbook': 'tags',
                                   'import_playbook': 'tags',
                                   'import_playbook': 'tags',
                                   'import_playbook': 'tags',
                                   'import_playbook': 'tags'
                                   }



# Generated at 2022-06-21 01:44:10.022253
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    def _parse_yaml(yaml_str):
        tasks = []
        yaml_str = yaml_str[0] + '\n\n' + yaml_str[1]
        fake_loader = DataLoader()
        task_ds = fake_loader.load(yaml_str)[0]
        task = Task()
        task.load_data(task_ds, {})
        tasks.append(task)
        task_blocks = task.get_blocks()

# Generated at 2022-06-21 01:44:18.628021
# Unit test for method copy of class Task
def test_Task_copy():
    task = Task()
    task.exclude_parent = True
    task.exclude_tasks = False
    task.copy()
    assert task.exclude_parent == True
    assert task.exclude_tasks == False

# Generated at 2022-06-21 01:44:25.288637
# Unit test for method serialize of class Task
def test_Task_serialize():
    task_serialize_obj = Task()
    task_serialize_obj.deserialize({
        "name": "task-serialize", "action": "serialize"
    })
    try:
        task_serialize_obj.serialize()
    except Exception as e:
        assert("ansible_facts.env" in to_native(e))

# Generated at 2022-06-21 01:44:37.679570
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    # test that a Task instance has attribute _attributes
    task = Task()
    task_instance_attribute = task._attributes
    assert task_instance_attribute is not None
    # test that all attributes are not None
    assert task.env is not None
    assert task.action is not None
    assert task.when is not None
    assert task.local_action is not None
    assert task.notify is not None
    assert task.async_val is not None
    assert task.poll is not None
    assert task.register is not None
    assert task.changed_when is not None
    assert task.failed_when is not None
    assert task.delegate_to is not None
    assert task.until is not None
    assert task.run_once is not None
    assert task.ignore_errors is not None

# Generated at 2022-06-21 01:44:47.671575
# Unit test for method load of class Task
def test_Task_load():
    my_class = Task
    result = my_class.load(loader, templar, task_ds, play=None, variable_manager=None, loader=None, use_handlers=False)
    assert result is not None
    assert result.get_name() is not None
    assert result.get_name() == 'Test name'
    assert result.action is not None
    assert result.action == 'ping'
    assert result.args is not None
    assert result.args == {}
    assert result.block is None
    assert result.any_errors_fatal is False
    assert result.always_run is False
    assert result.async_val is None
    assert result.async_seconds is None
    assert result.attributes is not None
    assert result.attributes.keys() == ['name']
    assert result.att