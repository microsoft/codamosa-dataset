

# Generated at 2022-06-23 07:16:14.872596
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()
    data = {}
    for attr in task._valid_attrs:
        data[attr] = None
    task.deserialize(data)
    serialized_data = task.serialize()
    assert serialized_data.get('parent') == serialized_data.get('role') == serialized_data.get('parent_type') == None
    assert serialized_data.get('implicit') == False
    assert serialized_data.get('resolved_action') == None

# Generated at 2022-06-23 07:16:25.602836
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    # This test is a proof of concept to illustrate how to create a
    # hierachical structure of tasks, blocks and includes (blocks)
    # The test can be executed with pytest cli command
    # py.test --cov=lib/ansible tests/units/test_parsing.py
    #
    # This test is tested with pytest version 3.3.1

    # Create a variable dictionary
    variable_manager = variable_manager.VariableManager()
    variable_manager.set_host_variable('localhost', 'foobar', 'foobar')
    variable_manager._options_vars = {'foobar': 'foobar'}

    # Create an include task
    t = Task()
    t._role = None
    t._parent = None
    t.action = 'include_tasks'

# Generated at 2022-06-23 07:16:30.539797
# Unit test for method __repr__ of class Task
def test_Task___repr__():

    module = AnsibleModule(argument_spec={})
    result = dict(
        ansible_facts=dict(key='value'),
        changed=False,
        key='value'
    )
    expected = '<Task name: test>'

    task = Task('test', module, result)
    assert task.__repr__() == expected

# Generated at 2022-06-23 07:16:43.097895
# Unit test for method set_loader of class Task
def test_Task_set_loader():
  try:
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from io import StringIO


  except ImportError:
    pass


  # test_Task_set_loader()
  # 1.
  task = Task()

  task.set_loader(loader=None)


  # 2.
  task = Task()

  block = Block()

  task._parent = block

  task._loader = None

  task._role = None

  task.implicit = False

  task.resolved_action = None

  task.set_loader(loader=None)


  # 3.
  task = Task()

  block = Block()

  task._parent = block

  task._loader = None

  task._role = None

  task.implicit = False


# Generated at 2022-06-23 07:16:46.618278
# Unit test for constructor of class Task
def test_Task():
    t = Task()

if __name__ == "__main__":
    test_Task()

# Generated at 2022-06-23 07:16:56.797007
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.template import Templar

    from collections import namedtuple

    from units.mock.loader import mock_loader
    from units.mock.path import mock_unfrackpath_noop

    from ansible import context
    context._init_global_context(
        options=Dict(),
        variables=Dict(),
    )

    # create parent task to test multi-level var delegation

# Generated at 2022-06-23 07:17:03.091202
# Unit test for method get_vars of class Task
def test_Task_get_vars():

    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import ansible.constants as C
    import yaml

    def dumps(data, **kwargs):
        return yaml.dump(data, Dumper=AnsibleDumper, **kwargs)

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    block_data = dict()


# Generated at 2022-06-23 07:17:09.869347
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()

    assert {} == task.get_vars()

    task._parent = Task()
    assert {} == task.get_vars()

    task.vars = {'a': 1}
    assert {'a': 1} == task.get_vars()

    task._parent.vars = {'b': 2}
    assert {'a': 1, 'b': 2} == task.get_vars()

    task.vars = {'c': 3, 'a': 4}
    assert {'c': 3, 'a': 4, 'b': 2} == task.get_vars()

# Generated at 2022-06-23 07:17:20.062463
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    m_ansible_fact_cacheable = MagicMock(return_value=False)
    m_unfrackpath = MagicMock(return_value='ansible.module_utils.basic')
    m_action_loader = MagicMock(return_value='action_loader')
    m_loader_find_plugin = MagicMock(return_value='loader_find_plugin')
    m_filter_loader = MagicMock(return_value='filter_loader')
    m_cache = {}

# Generated at 2022-06-23 07:17:22.740422
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    task = Task()
    task._parent = 'test'
    assert task.all_parents_static()

# Generated at 2022-06-23 07:17:24.562454
# Unit test for method load of class Task
def test_Task_load():
    """Test Task.load(), the method to load a task.
    """
    pass


# Generated at 2022-06-23 07:17:28.136328
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task_get_vars=Task()
    all_vars=dict()
    assert task_get_vars.get_vars()==all_vars
    
    

# Generated at 2022-06-23 07:17:30.876339
# Unit test for method get_name of class Task
def test_Task_get_name():
    hosting = Task()
    assert hosting.name == None
    assert hosting.get_name() ==None


# Generated at 2022-06-23 07:17:42.674775
# Unit test for constructor of class Task
def test_Task():
    task = Task()
    assert task._attributes['name'] == "TASK"
    assert task._attributes['action'] is None
    assert task._attributes['local_action'] is None
    assert task._attributes['args'] is None
    assert task._attributes['delegate_to'] is None
    assert task._attributes['notify'] == []
    assert task._attributes['changed_when'] is None
    assert task._attributes['failed_when'] is None
    assert task._attributes['until'] is None
    assert task._attributes['always_run'] is False
    assert task._attributes['async_val'] == 0
    assert task._attributes['poll'] == 0
    assert task._attributes['register'] is None
    assert task._attributes['ignore_errors'] is False
    assert task._

# Generated at 2022-06-23 07:17:50.702376
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    block = Block()
    block.vars = dict()
    block.vars['test_var'] = 'test_value'


    task = Task()
    task.action = 'test_action'
    task.vars = dict()
    task.vars['test_var'] = 'test_value'
    task._parent = block
    task._finalized = True

    # test exception: block._parent not initialized
    with pytest.raises(Exception) as e_info:
        task.preprocess_data('ds')

    # test exception: ds not a dict

# Generated at 2022-06-23 07:17:53.114088
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    # ansible/playbook/__init__.py
    assert False, "Test not implemented"

# Generated at 2022-06-23 07:17:54.309069
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    Task.get_vars()


# Generated at 2022-06-23 07:17:57.715909
# Unit test for method get_name of class Task

# Generated at 2022-06-23 07:18:00.248552
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task._attributes['action'] = "test"
    assert repr(task) == '<Task(test)>'


# Generated at 2022-06-23 07:18:02.053460
# Unit test for method get_name of class Task
def test_Task_get_name():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    task_obj = Task(dict(
        name=AnsibleVaultEncryptedUnicode('test'),
        ))
    assert task_obj.get_name() == 'test'

# Generated at 2022-06-23 07:18:06.468717
# Unit test for method copy of class Task
def test_Task_copy():
    (task, parent) = Task.__new__.call_args[0]
    task.copy()
    task.copy.assert_called_once_with(exclude_parent=False, exclude_tasks=False)

# Generated at 2022-06-23 07:18:11.795562
# Unit test for method load of class Task
def test_Task_load():
    collection_loader = mock()
    loader = mock()
    task_vars = mock()
    variable_manager = mock()
    hosts = mock()
    t = Task()
    t.load(loader=loader, block=None, task_ds={}, role=None, task_vars=task_vars, variable_manager=variable_manager, loader_cache=None)


# Generated at 2022-06-23 07:18:20.492151
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    templar = Templar(loader, variable_manager, context)
    play = Play()
    block = Block()
    task = Task()
    block.append(task)
    play.append(block)

    variable_manager.set_vars({"test_val": 1})
    variable_manager.set_nonpersistent_facts({"test_val": 2})

    #

# Generated at 2022-06-23 07:18:21.894295
# Unit test for method load of class Task
def test_Task_load():
  pass # no tests implemented

# Generated at 2022-06-23 07:18:24.949302
# Unit test for method serialize of class Task
def test_Task_serialize():
    """ Unit test for `serialize` method of `Task` class. """
    my_path = os.path.dirname(os.path.abspath(__file__))
    source = my_path + os.sep + 'my_task_1.yaml'
    with open(source, 'r') as stream:
        data = yaml.load(stream, Loader=SafeLoader)
    task = Task()
    task.deserialize(data)
    task.serialize()



# Generated at 2022-06-23 07:18:37.145707
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()

# Generated at 2022-06-23 07:18:48.921947
# Unit test for method preprocess_data of class Task
def test_Task_preprocess_data():
    task = Task()
    task.action = 'test_action'
    task.args = {'test_arg': 'test_arg_value'}
    task._attributes = {'test_attr': 'test_attr_value'}
    task.tags = ['test_tag']
    task.when = 'test_when_value'
    task._parent = 'test_parent'
    task._role = 'test_role'
    task.resolved_action = 'test_resolved_action_name'
    result = task.preprocess_data({'test_key': 'test_value'})

# Generated at 2022-06-23 07:19:00.569715
# Unit test for method copy of class Task
def test_Task_copy():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    parent = Block()
    role = Role()
    x = Task(parent=parent, role=role)
    x._loader = True
    x._blocks = True
    x._vars = True
    x.action = 'action'
    x.args = 'args'
    x.delegate_to = 'delegate_to'
    x.environment = 'environment'
    x.ignore_errors = 'ignore_errors'
    x.loop = 'loop'
    x.loop_args = 'loop_args'
    x.loop_control = 'loop_control'
    x.name = 'name'
    x.no_log = 'no_log'
    x.notify = 'notify'
    x.poll

# Generated at 2022-06-23 07:19:07.313742
# Unit test for method serialize of class Task

# Generated at 2022-06-23 07:19:11.932242
# Unit test for method get_name of class Task
def test_Task_get_name():
    p = Playbook()
    pb = PlaybookInclude()
    itr = PlayIterator(p)
    t = Task()
    a = t.get_name()
    assert a == 'task', a

# Generated at 2022-06-23 07:19:16.261263
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    task = Task()
    # test a failure condition, since we can't construct loader object
    try:
        task.set_loader(None)
        assert False
    except:
        assert True
    

# Generated at 2022-06-23 07:19:27.081636
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    yaml_data = '''
    - name: Add a new user
      user:
        name: testuser
        state: present
      register: testuser'''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    my_loader = AnsibleConstructor.load(yaml_data)
    instance = None
    if isinstance(my_loader, AnsibleBaseYAMLObject):
        instance = my_loader
    else:
        for key in my_loader:
            for task in key:
                instance = task
    assert instance.all_parents_static()

# Generated at 2022-06-23 07:19:40.357577
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    obj1 = Task()
    obj1._loader = 'dummy'
    assert obj1._loader == 'dummy'
    assert obj1._parent is None
    obj1._parent = 'dummy'
    assert obj1._parent == 'dummy'
    obj1._attributes['implicit'] = 'dummy'
    assert obj1._attributes['implicit'] == 'dummy'
    obj1._attributes['resolved_action'] = 'dummy'
    assert obj1._attributes['resolved_action'] == 'dummy'
    obj2 = Task()
    obj2._role = 'dummy'
    assert obj2._role == 'dummy'
    obj2.implicit = 'dummy'
    assert obj2.implicit == 'dummy'

# Generated at 2022-06-23 07:19:51.447634
# Unit test for method load of class Task
def test_Task_load():
  import yaml
  from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.text.converters import to_bytes
  class VaultSecret(object):
    """ Encapsulates a vault secret """
    def __init__(self):
      self._text = None

    def set_text(self, text):
      self._text = text

    def serialize(self):
      return yaml.safe_dump({'_text': self._text}, encoding=None, default_flow_style=None, allow_unicode=True, width=1024)

  '''
  We create a Task object in order to test the method load
  '''
  v = VaultSecret()

# Generated at 2022-06-23 07:19:57.127701
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    task = Task()
    task.name = 'a task'
    task.action  = 'a action'
    ret = task.__repr__()
    assert ret.startswith('<Task: a task')
    assert ret.endswith('>')


# Generated at 2022-06-23 07:19:57.996946
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    pass

# Generated at 2022-06-23 07:20:02.250489
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    A = dict(a='a')
    B = dict(b='b')
    t = Task()
    t2 = Task()
    t2._parent = t
    t2._attributes['vars'] = A
    t3 = Task()
    t3._parent = t2
    t3._attributes['vars'] = B
    result = t3.all_parents_static()
    assert result is True
    

# Generated at 2022-06-23 07:20:04.956570
# Unit test for method post_validate of class Task
def test_Task_post_validate():
    task = Task()
    task.post_validate()

if __name__ == '__main__':
    test_Task_post_validate()
# end class Task



# Generated at 2022-06-23 07:20:17.303226
# Unit test for method load of class Task
def test_Task_load():
    # generate a string of random bytes
    str_random = lambda N: ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(N))
    import uuid
    filename = str(uuid.uuid4())
    # filename = 'test_Task_load_filename'
    # write random bytes to temp file
    with open(filename, 'w') as f:
        f.write(str_random(random.randint(10,100)))
    # generate random value for attrs
    attrs = dict()
    for i in range(random.randint(2,10)):
        attrs[str(uuid.uuid4())] = str_random(random.randint(10,100))
    # generate random value for loader

# Generated at 2022-06-23 07:20:20.416392
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    test_task = Task()
    test_task.vars = {'first_key':'first_value', 'second_key':'second_value'}
    assert test_task.get_vars() == {'first_key':'first_value', 'second_key':'second_value'}

# Generated at 2022-06-23 07:20:32.841512
# Unit test for method serialize of class Task
def test_Task_serialize():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    # Setup mock objects
    mock_playcontext = PlayContext()
    mock_play = Play.load(dict(
        name="mock play name",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='mock_module'))]
    ), variable_manager=mock.MagicMock(), loader=mock.MagicMock())
    mock_block = mock_play.compile()
    mock_task = Task.load(data=dict(action=dict(module='mock_module')), block=mock_block, role=mock.MagicMock(), task_include=None)
    #

# Generated at 2022-06-23 07:20:41.213103
# Unit test for method serialize of class Task
def test_Task_serialize():
    args_parser = ModuleArgsParser(task_ds=ds, collection_list=collections_list)
    (action, args, delegate_to) = args_parser.parse()

    # the command/shell/script modules used to support the `cmd` arg,
    # which corresponds to what we now call _raw_params, so move that
    # value over to _raw_params (assuming it is empty)
    if action in C._ACTION_HAS_CMD:
        if 'cmd' in args:
            if args.get('_raw_params', '') != '':
                raise AnsibleError("The 'cmd' argument cannot be used when other raw parameters are specified."
                                   " Please put everything in one or the other place.", obj=ds)
            args['_raw_params'] = args.pop('cmd')


# Generated at 2022-06-23 07:20:52.447635
# Unit test for method serialize of class Task

# Generated at 2022-06-23 07:20:55.598853
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    task = Task()
    task.vars = {}
    task.action = 'action'
    assert task.get_include_params() == {}

# Generated at 2022-06-23 07:21:05.699911
# Unit test for method copy of class Task
def test_Task_copy():
    task = Task()
    task.name = 'test'
    task.action = 'print'
    task.when = 'true'
    task.async_val = 1
    task.poll = 1
    task.until = 1
    task.retries = 1
    task.delay = 1
    task.ignore_errors = True
    task.first_available_file = '/foo/bar'
    task.local_action = 'foo.bar'
    task.environment = dict()
    task.tags = ['foo', 'bar']
    task.any_errors_fatal = True
    task.connection = 'local'
    task.become = True
    task.become_method = 'sudo'
    task.become_user = 'vagrant'
    task.vars = dict()
    task.args = dict()

# Generated at 2022-06-23 07:21:13.343123
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    import ansible.playbook.task_include as ti
    t = Task()
    ti_obj = ti.TaskInclude()
    ti_obj.name = "ti_obj"
    t.set_loader("loader_obj")
    t._parent = "parent_obj"
    ti_obj.task_include = t
    t.get_first_parent_include()
    assert (t._loader, ti_obj.name) == (ti_obj._loader, ti_obj.name)



# Generated at 2022-06-23 07:21:15.633698
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    task = Task()
    assert task._loader == None

    # setting loader to one value
    task.set_loader("loader")
    assert task._loader == "loader"

    # setting loader to another value, should work
    task.set_loader("loader2")
    assert task._loader == "loader2"


# Generated at 2022-06-23 07:21:23.573798
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    # initialize a task object and set its testable properties
    task = Task()
    task._role = Role()
    task._parent = Block()

    # call the method under test
    actual_return = task.__repr__()

    # assert that the method returned a string
    assert isinstance(actual_return, str)


# Generated at 2022-06-23 07:21:29.297616
# Unit test for constructor of class Task
def test_Task():
    t = Task()
    assert t.action == 'meta'
    assert t.delegate_to is None
    assert t.deprecated is None
    assert t.implicit_deprecated is None
    assert t.notify is None
    assert t.resolved_action is None
    assert t.until is None



# Generated at 2022-06-23 07:21:32.309161
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    task = Task()
    assert (task.all_parents_static()==True)

# Generated at 2022-06-23 07:21:37.750711
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    t = Task()
    t.vars = dict()
    p = Task()
    p.vars = dict(a=1, b=2)
    t._parent = p
    assert t.get_vars()==dict(a=1, b=2)


# Generated at 2022-06-23 07:21:48.637914
# Unit test for constructor of class Task
def test_Task():
    #Test defaults and setters
    #test_task holds the Task instance
    test_task = Task()
    assert test_task.action == 'meta'
    assert test_task.args == {}
    assert test_task.name == 'meta'
    assert test_task.loop is None
    assert test_task.notify is None
    assert test_task.tags == set()
    assert test_task.until is None
    assert test_task.retries is None
    assert test_task.register == 'meta'
    assert test_task.ignore_errors is False
    assert test_task.run_once is False
    assert test_task.delegate_to == ''
    assert test_task.delegate_facts is False
    assert test_task.vars == {}
    assert test_task.when is None
    assert test

# Generated at 2022-06-23 07:21:49.284638
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    pass

# Generated at 2022-06-23 07:22:00.579950
# Unit test for constructor of class Task
def test_Task():
    t = Task(dict(action='test', args=dict()))
    assert t.action == 'test'
    assert t.args == dict()
    assert t.resolved_action == 'test'
    assert t.any_errors_fatal is False
    assert t.failed_when == ''
    assert t.ignore_errors is False
    assert t.loop is None
    assert t.notify == []
    assert t.poll is 0
    assert t.register == ''
    assert t.retries == 0
    assert t.until == ''
    assert t.until_retries == 0
    assert t.changed_when == ''
    assert t.always_run is False
    assert t.delegate_to == ''
    assert t.delegate_facts is False
    assert t.do_not_log is False

# Generated at 2022-06-23 07:22:12.963848
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    task = Task()

# Generated at 2022-06-23 07:22:14.214249
# Unit test for method deserialize of class Task

# Generated at 2022-06-23 07:22:16.246371
# Unit test for method load of class Task
def test_Task_load():
    task = Task()
    task._load({'action': 'dummy'})


# Generated at 2022-06-23 07:22:28.947986
# Unit test for constructor of class Task
def test_Task():
    action = 'ping'
    ds = {'action': action}

    t = Task.load(ds, task_uuid='bleh', role=None)
    assert t.action == action
    assert t.task_type == 'regular'
    assert t.task_uuid == 'bleh'

    t = Task.load(ds, task_uuid='blah', role=None)
    assert t.action == action
    assert t.task_type == 'regular'
    assert t.task_uuid == 'blah'

    action = 'meta'
    ds = {'action': action}
    t = Task.load(ds, task_uuid='blah', role=None)
    assert t.action == action
    assert t.task_type == 'meta'

# Generated at 2022-06-23 07:22:41.247973
# Unit test for constructor of class Task
def test_Task():
    # Make sure AnsibleModule and AnsibleExitJson are loaded
    import ansible.module_utils.basic

    # Test a simple module run
    t = Task()
    assert t.action == 'command'

    t = Task.load(dict(action='shell', args='ls -al /tmp'))
    assert t.action == 'shell'
    assert t.args == {'_raw_params': 'ls -al /tmp'}
    assert t.action == t['action']
    assert t.args == t['args']

    # with the 'args' passed in a list, it should wind up as a dict
    # due to the ModuleArgsParser
    t = Task.load(dict(action='shell', args=['ls', '-al', '/tmp']))
    assert t.action == 'shell'
    assert t.args

# Generated at 2022-06-23 07:22:51.928886
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    task = Task()
    task.vars = {'test_1': 1, 'test_2': 2}
    assert task.get_vars() == {'test_1': 1, 'test_2': 2}

    task_2 = Task()
    task_2._parent = task
    assert task_2.get_vars() == {'test_1': 1, 'test_2': 2}

    task_2.vars = {'test_3': 3, 'test_4': 4}
    assert task_2.get_vars() == {'test_1': 1, 'test_2': 2, 'test_3': 3, 'test_4': 4}


# Generated at 2022-06-23 07:22:52.888932
# Unit test for constructor of class Task
def test_Task():
    Task(dict())

# Generated at 2022-06-23 07:23:02.046251
# Unit test for method load of class Task
def test_Task_load():
    task = Task()
    task.load({
            u'when': u'whatever',
            u'skip_tags': [u'foo', u'bar'],
            u'loop': u'{{foo}}',
            u'action': u'my_action',
            u'with_items': u'{{items}}',
            u'with_first_found': [u'/etc/foo.conf', u'/etc/foo.local.conf'],
            u'args': {u'name': u'test'}
        })
    assert task.when == 'whatever'
    assert task.skip_tags == ['foo', 'bar']
    assert task.loop == '{{foo}}'
    assert task.action == 'my_action'
    assert task.with_items == '{{items}}'
    assert task.with_first_

# Generated at 2022-06-23 07:23:08.321257
# Unit test for method get_name of class Task
def test_Task_get_name():
    # Initializing test data
    task_obj = Task()
    task_obj.action = 'action'
    # Expected result
    expected_result = 'action'

    # Invoke test target method
    actual_result = task_obj.get_name()

    # Test if the result is equal to expected result
    assert actual_result == expected_result, 'Expected result should be action but it is %s' % actual_result


# Generated at 2022-06-23 07:23:19.201944
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():

    # import is here to avoid import loops
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.role_include import IncludeRole

    task = Task()
    taskInclude = TaskInclude()
    task.parent = taskInclude

    assert task.get_first_parent_include() == taskInclude

    taskInclude2 = TaskInclude()
    taskInclude.parent = taskInclude2

    assert task.get_first_parent_include() == taskInclude2

    includeRole = IncludeRole()
    taskInclude2.parent = includeRole

    assert task.get_first_parent_include() == taskInclude2



# Generated at 2022-06-23 07:23:30.587291
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.task_include import TaskInclude

    t1 = Task().load({}, include_role=True)
    t2 = Task().load({})
    t3 = TaskInclude().load({})
    t4 = TaskInclude().load({})
    t4.static = False

    assert t1.all_parents_static() == True
    assert t2.all_parents_static() == True

    t2._parent = t1
    assert t2.all_parents_static() == True
    t1.static = False
    assert t2.all_parents_static() == False

    t3._parent = t2
    assert t3.all_parents_static() == False
    t1.static = True
    assert t3.all_parents_static() == False

    t4._parent = t

# Generated at 2022-06-23 07:23:42.142449
# Unit test for method serialize of class Task
def test_Task_serialize():
    _task = Task()
    _task.deserialize({'action': 'setup', 'delegate_to': 'somehost', 'delegated_vars': 'some_var', 'register': 'some_var', 'ignore_errors': True, 'first_available_file': '/path/to/file', 'until': 'some_task', 'retries': 1, 'delay': 1, 'changed_when': 'some_task', 'failed_when': 'some_task', 'name': 'some_task', 'tags': ['some_tag'], 'when': 'some_task', 'args': {'module_name': 'setup'}, 'loop': 'some_task', 'environment': {'name': 'value'}, 'ignore_errors': True, 'local_action': 'setup'})
    ser = _task.serialize()


# Generated at 2022-06-23 07:23:57.809497
# Unit test for method copy of class Task
def test_Task_copy():
    ml = MetaLexer()
    task_1_other = {"action": "module_name", "args": {"module_name": "module_name"}}
    task_1 = Task(data=task_1_other, token=ml.tokenize_task(task_1_other['action']))
    task_2_other = {"action": "module_name_1", "args": {"module_name": "module_name_1"}}
    task_2 = Task(data=task_2_other, token=ml.tokenize_task(task_2_other['action']))
    # Create Block
    with pytest.raises(AnsibleParserError):
        block_1 = Block(data=task_1, token=ml.tokenize_task(task_1['action']))
    # Create TaskInclude
    block

# Generated at 2022-06-23 07:24:11.164350
# Unit test for method get_include_params of class Task
def test_Task_get_include_params():
    from ansible.playbook.task_include import TaskInclude
    t = Task()
    t.vars = dict(k='v')
    t.action = 'test_action_type'
    assert t.get_include_params() == dict()
    ti = TaskInclude()
    ti.vars = dict(k1='v1')
    ti.action = 'test_action_type'
    assert ti.get_include_params() == dict()
    t._parent = ti
    assert t.get_include_params() == dict(k1='v1')
    t.action = 'include'
    assert t.get_include_params() == dict(k1='v1', k='v')
    ti.action = 'include'

# Generated at 2022-06-23 07:24:23.072422
# Unit test for method get_name of class Task
def test_Task_get_name():
    t = Task()
    assert t.get_name() == '<unnamed task>'
    t.action = 'setup'
    assert t.get_name() == 'setup'
    t.name = 'abc'
    assert t.get_name() == 'abc'
    del t.name
    t.action = 'command'
    t.args['_raw_params'] = 'uptime'
    assert t.get_name() == 'uptime'
    t.action = 'command'
    t.args['_raw_params'] = 'echo ${foo}'
    assert t.get_name() == 'echo ${foo}'
    t.args['_raw_params'] = 'echo {foo}'
    assert t.get_name() == 'echo {foo}'
    t.args['_raw_params']

# Generated at 2022-06-23 07:24:31.477092
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():


    fake_loader_mock = MagicMock()
    # Set up the mock to return a source hash
    fake_loader_mock.get_basedir.return_value = '/root'
    fake_loader_mock.get_real_file.return_value = 'fake_file'

    # Setup the context that the method being tested needs
    m = Task()
    m._role._role_path = 'fake_role_path'
    m._role._role_name = 'fake_role_name'
    m._parent = None
    m._loader = fake_loader_mock

    m._parent = TaskInclude()
    m._parent._role._role_path = 'fake_parent_role_path'
    m._parent._role._role_name = 'fake_parent_role_name'
    m._parent._

# Generated at 2022-06-23 07:24:40.139405
# Unit test for method __repr__ of class Task
def test_Task___repr__():
  import sys
  import inspect
  import json
  from ansible.errors import AnsibleError

  # Create a dummy instance for testing
  test_instance = Task()

  # Run unit tests
  # Simple test
  test_value1 = test_instance.__repr__()
  test_expect1 = '<Task>'
  assert test_value1 == test_expect1, 'Expected value {}, received value {}'.format(test_expect1, test_value1)


# Generated at 2022-06-23 07:24:49.602534
# Unit test for method __repr__ of class Task
def test_Task___repr__():
    from ansible.playbook.task_include import TaskInclude
    t = Task()

    t_a_debug = t.__repr__()
    check = '<Task debug: {}>' == t_a_debug
    assert check

    t.action = 'test'
    t.args = 'test'
    t.delegate_to = 'test'
    t.deprecated = True
    t.implicit = 'test'
    t.loop = 'test'
    t.name = 'test'
    t.resolved_action = 'test'
    t.tags = 'test'
    t.until = 'test'
    t.loop_control = 'test'
    t.when = 'test'
    t._block = 'test'
    t._parent = 'test'

# Generated at 2022-06-23 07:24:52.522676
# Unit test for method load of class Task
def test_Task_load():
    args = {
        'action': 'collect_facts',
        'register': 'ansible_facts',
        'collections': ['ansible.builtin']
    }
    Task.load(args)


# Generated at 2022-06-23 07:25:01.109757
# Unit test for method get_vars of class Task
def test_Task_get_vars():
    h = AnsibleHost('localhost')
    p = Play().load(dict(
        hosts=h,
        remote_user="root",
        gather_facts=True,
        roles=[Role().load(
            dict(
                name="a",
                tasks=[Task().load(dict(
                    name="b",
                    loop_control=dict(loop_var="x"),
                    include_role=dict(name="c")
                ))]
            )
        )]
    ), variable_manager=VariableManager, loader=DataLoader())
    task = p.get_tasks()[0]

    # ok, task w/o parent
    assert task.get_vars() == dict(loop_control=dict(loop_var="x"), include_role=dict(name="c"))

    # ok, task with parent (Play or Role)


# Generated at 2022-06-23 07:25:12.972682
# Unit test for method deserialize of class Task
def test_Task_deserialize():
    role_data = dict(name='foo',
                     default_vars=dict(a=1, b=2),
                     tasks=[dict(action='debug',
                                 module_args=dict(msg='Hello world!'),
                                 name='hello world')],
                     handlers=[dict(action='debug',
                                    module_args=dict(msg='Handler Hello world!'),
                                    name='handlers hello world')],
                     vars=[dict(a=1, b=2)],
                     meta=dict(dict(a=1, b=2)),
                     dependencies=[])

    role_obj = Role()
    role_obj.deserialize(role_data)


# Generated at 2022-06-23 07:25:14.935432
# Unit test for method copy of class Task
def test_Task_copy():
  # create a mock task
  task = Task()
  task.copy()


# Generated at 2022-06-23 07:25:27.593397
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()
    task.action = 'setup'
    task.args = {'filter': 'ansible_*'}
    task.delegate_to = 'localhost'
    task.environment = {'ANSIBLE_NO_LOG': 'true'}
    task.ignore_errors = True
    task.loop = [
        '1.1.1.1',
        '1.1.1.2',
    ]
    task.loop_control = 'loop_control'
    task.name = 'task_name'
    task.notify = [
        'notify_name',
    ]
    task.register = 'setup_result'
    task.tags = [
        'tags',
    ]
    block = Block()

# Generated at 2022-06-23 07:25:30.708695
# Unit test for method get_first_parent_include of class Task
def test_Task_get_first_parent_include():
    Task_obj = Task()
    Task_obj._parent = None
    assert Task_obj.get_first_parent_include() == None

# Generated at 2022-06-23 07:25:37.232198
# Unit test for method serialize of class Task
def test_Task_serialize():
    from ansible.playbook.handlerlist import HandlerList
    handles = Handler()
    obj = Task(
        block=Block(),
        handlers=HandlerList.from_list(handles),
        role=Role(),
    )
    obj.deserialize({})
    assert 'parent' not in obj.serialize()
    assert 'role' not in obj.serialize()



# Generated at 2022-06-23 07:25:39.526259
# Unit test for method set_loader of class Task
def test_Task_set_loader():
    task = Task()
    loader = DictDataLoader({})
    task.set_loader(loader)
    assert task._loader == loader


# Generated at 2022-06-23 07:25:52.762643
# Unit test for method all_parents_static of class Task
def test_Task_all_parents_static():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    t = Task()
    assert t.all_parents_static() == True
    t._parent = Block()
    assert t.all_parents_static() == True

    t._parent = TaskInclude()
    assert t.all_parents_static() == True
    t._parent._parent = TaskInclude()
    assert t.all_parents_static() == True
    t._parent._parent._parent = HandlerTaskInclude()
    assert t.all_parents_static() == False
    t._parent._parent._parent = Block()
    assert t.all_parents_static() == False
    t._parent._parent._parent.statically_loaded = True
    assert t.all_parents

# Generated at 2022-06-23 07:26:04.769216
# Unit test for method serialize of class Task
def test_Task_serialize():
    task = Task()

# Generated at 2022-06-23 07:26:09.037232
# Unit test for method load of class Task
def test_Task_load():
    # we don't have to test play, because the load method
    # is dummy.
    # Test to load task
    task = Task()
    task.load(dict(meta=dict(key='value')))
    # Test to load ansible task
    ansible_task = AnsibleTask()
    ansible_task.load(dict(meta=dict(key='value')))

