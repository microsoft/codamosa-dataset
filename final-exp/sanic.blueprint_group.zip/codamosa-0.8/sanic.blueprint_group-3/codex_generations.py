

# Generated at 2022-06-12 08:31:06.551724
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # given
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    # when
    @bpg.middleware('request')
    def middleware_a(request):
        pass
    # then
    assert middleware_a in bp1.request_middleware
    assert middleware_a in bp2.request_middleware



# Generated at 2022-06-12 08:31:11.889665
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @bp.middleware('request')
    async def test_middleware(request):
        request.ctx.test_value = 'Middleware Applied'

    bp.middleware(test_middleware)(test_middleware)
    bp.middleware('request', test_middleware)(test_middleware)

    # Register Blueprint group under the app
    app.blueprint(bp_group)
    app.blueprint(bpg)

    _, response = app.test_client.get('/')
    assert response.text == 'Middleware Applied'

# Generated at 2022-06-12 08:31:22.775507
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')    
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')    

    bpg1 = BlueprintGroup(bp1, bp2, bp3)
    bpg2 = BlueprintGroup(bp4, bp5, bpg1)

# Generated at 2022-06-12 08:31:32.135989
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    for bp in [bp1,bp2,bp3,bp4]:
        bpg.append(bp)

    assert not bp1.middlewares
    assert not bp2.middlewares
    assert not bp3.middlewares
    assert not bp4.middlewares

    @bpg.middleware()
    async def middleware(request):
        pass

    assert bp1.middlewares
    assert bp2.middlewares

# Generated at 2022-06-12 08:31:45.416112
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:31:57.356969
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class fake_Blueprint:
        def __init__(self, *args, **kwargs):
            self.middleware_list = []
            self.middleware_dict = {}

        def middleware(self, *args, **kwargs):
            self.middleware_dict = {
                "middleware": "middleware",
                "args": args,
                "kwargs": kwargs,
            }
            return self.middleware_list.append(self.middleware_dict)

    @BlueprintGroup.middleware("fake_method")
    def fake_func(*args, **kwargs):
        pass

    fake_bp = fake_Blueprint()
    fake_bpg = BlueprintGroup()
    fake_bpg.append(fake_bp)

    fake_func()


# Generated at 2022-06-12 08:32:08.175357
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def middleware(request):
        print('hello')


# Generated at 2022-06-12 08:32:19.409982
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_BlueprintGroup_middleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:32:28.013076
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')
    
    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)
    
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.url_prefix = '/test'
    bpg.version = 'test'
    bpg.strict_slashes = True
    

# Generated at 2022-06-12 08:32:35.026561
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint("bp1", url_prefix="/api/v1", version="1.0")
    bp2 = sanic.Blueprint("bp2", url_prefix="/api/v2", version="1.0")
    bp3 = sanic.Blueprint("bp3", url_prefix="/api/v3", version="1.0")
    bp4 = sanic.Blueprint("bp4", url_prefix="/api/v4", version="1.0")
    bp5 = sanic.Blueprint("bp5", url_prefix="/api/v5", version="1.0")
    bp6 = sanic.Blueprint("bp5", url_prefix="/api/v6", version="1.0")

# Generated at 2022-06-12 08:32:45.977130
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @blueprint.middleware("request")
    async def middleware(request):
        pass

    @blueprint1.middleware("request")
    async def middleware(request):
        pass

    group = BlueprintGroup()
    group.append(blueprint)
    group.append(blueprint1)

    # Group middleware
    @group.middleware("request")
    async def middleware(request):
        pass

    assert blueprint.middlewares["request"][0] == middleware
    assert blueprint1.middlewares["request"][0] == middleware

    assert blueprint.middlewares["request"][1] == middleware
    assert blueprint1.middlewares["request"][1] == middleware



# Generated at 2022-06-12 08:32:56.959632
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic import response
    from sanic.blueprints import BlueprintGroup

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp_group = BlueprintGroup(bp1, bp2)

    @bp_group.middleware
    async def method_middleware(request):
        request.context = {"key": "value"}

    @bp1.route('/')
    async def _handler1(request):
        return response.json({"first_bp": request.context})

    @bp2.route('/')
    async def _handler2(request):
        return response.json({"second_bp": request.context})

    app = sanic.Sanic()
    app.blueprint(bp_group)
    _, response1 = app.test_

# Generated at 2022-06-12 08:33:04.169940
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        return True
    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        return True


    @bpg.middleware('request')
    async def bpg_middleware(request):
        return True

    class MockRequest:
        pass

    request = MockRequest()

# Generated at 2022-06-12 08:33:12.945665
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()

    blueprint1 = Blueprint('bp1')
    blueprint2 = Blueprint('bp2')

    blueprint_group._blueprints.append(blueprint1)
    blueprint_group._blueprints.append(blueprint2)

    @blueprint_group.middleware('request')
    async def bp1_only_middleware(request):
        pass

    assert len(blueprint_group._blueprints) == 2
    assert len(blueprint_group._blueprints[0]._middleware['request']) == 1
    assert len(blueprint_group._blueprints[1]._middleware['request']) == 1


# Generated at 2022-06-12 08:33:21.905836
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = Sanic('test_BlueprintGroup_middleware')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bp = Blueprint('bp1', url_prefix='/bp1')
    bpg.append(bp)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    request, response = app.test_client.get('/api/v1/bp1')
    assert response.status == 404



# Generated at 2022-06-12 08:33:30.142031
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # GIVEN
    class FakeBlueprint:
        def __init__(self, name):
            self.name = name
            self.middlewares = []

        def middleware(self, fn, *args, **kwargs):
            self.middlewares.append((fn, args, kwargs))

    bp1 = FakeBlueprint("bp1")
    bp2 = FakeBlueprint("bp2")
    
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    # WHEN
    @bpg.middleware 
    def test_middleware():
        pass

    # THEN
    assert bp1.middlewares == [(test_middleware, (), {})]
    assert bp2.middlewares == [(test_middleware, (), {})]

# Generated at 2022-06-12 08:33:42.202050
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Add middleware to Blueprint Group
    """
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Create Blueprint Group
    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware('request')
    async def bp_middleware(request):
        print('middleware applied for both bp1 and bp2')

    # Register Blueprint group under the app
    app.blueprint(bpg)
    assert bp1.middlewares == {'request': [bp_middleware]}
    assert bp2.middlewares == {'request': [bp_middleware]}


# Generated at 2022-06-12 08:33:50.223762
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')

    group_middleware_context = {
        'bp1': False,
        'bp2': False,
        'bp3': False,
    }

    def bp1_only_middleware(request):
        group_middleware_context['bp1'] = True

    def bp2_only_middleware(request):
        group_middleware_context['bp2'] = True

    def bp3_only_middleware(request):
        group_middleware_context['bp3'] = True


# Generated at 2022-06-12 08:33:57.538662
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    my_bp = Blueprint('my_bp', url_prefix='/my_bp')
    bp_group = BlueprintGroup('my_bp', url_prefix='/my_bp')
    assert bp_group.blueprints == []
    bp_group.append(my_bp)

    @bp_group.middleware('request')
    async def testMiddleWare(request):
        request['test_request'] = 'test'

    assert len(bp_group.blueprints) == 1
    assert bp_group.blueprints[0].middlewares == [testMiddleWare]
    assert my_bp.middlewares == [testMiddleWare]

# Generated at 2022-06-12 08:34:08.607901
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/bp1')

    mw_called = 0
    @bpg.middleware
    async def mw(request):
        nonlocal mw_called
        mw_called += 1

    test_app = sanic.Sanic('test_BlueprintGroup_middleware')
    test_app.blueprint(bpg)

    @bp1.route('/')
    async def handler(request):
        return text('')

    @bp2.route('/')
    async def handler(request):
        return text('')

    request, response = test_app.test_client.get

# Generated at 2022-06-12 08:34:18.952313
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MockMiddleware(sanic.response.HTTPResponse):
        pass

    class MockBlueprint:
        def __init__(self):
            self.middleware_register = []

        def middleware(self, fn, *args, **kwargs):
            self.middleware_register.append((fn, args, kwargs))

    blueprint = MockBlueprint()
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    blueprint_group.middleware(MockMiddleware)

    assert blueprint.middleware_register == [(MockMiddleware, (), {})]



# Generated at 2022-06-12 08:34:27.070983
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.response import text
    from sanic.testing import SanicTestClient, create_test_server

    app = sanic.Sanic()
    bp_v1 = Blueprint('bp_v1', url_prefix='/bp_v1', version="v1")
    bp_v2 = Blueprint('bp_v2', url_prefix='/bp_v2', version="v2")

    bp_v1_1 = Blueprint('bp_v1_1', url_prefix='/bp_v1', version="v1")
    bp_v1_2 = Blueprint('bp_v1_2', url_prefix='/bp_v1', version="v1")

    bp_v2_1 = Blueprint('bp_v2_1', url_prefix='/bp_v2', version="v2")


# Generated at 2022-06-12 08:34:35.071637
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware_for_bp1(request):
        print('applied on Blueprint : bp1 Only')

    def middleware_for_bp2(request):
        print('applied on Blueprint : bp2 Only')

    def common_middleware_for_blueprint(request):
        print('common middleware applied for both bp1 and bp2')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")


# Generated at 2022-06-12 08:34:40.216143
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('bp1', 'bp')

    def middleware_fn():
        pass

    bpg = BlueprintGroup('/version/api')
    bpg.append(bp)
    bpg.middleware(middleware_fn)

    assert bp._middlewares['request'][0] is middleware_fn
    assert bp._middlewares['request'][1] == {}

# Generated at 2022-06-12 08:34:47.182122
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def test_middleware(request):
        pass

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-12 08:34:57.149068
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api")
    bpg2 = BlueprintGroup(bp3, bpg1, url_prefix="/api")
    app = App()
    app.blueprint(bpg2)

    @bp1.middleware("request")
    async def handler(request):
        pass

    assert handler in bp1.middleware['request']

# Generated at 2022-06-12 08:35:06.150571
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        assert request.app

    # Example of a nested Blueprint Group
    bg = BlueprintGroup* 2

    bg.append(bp1)
    bg.append(bp2)

    @bg.middleware('request')
    async def bg_middleware(request):
        assert request.app

    # The same middleware can be applied to bp1, bp2 and bg

    app = sanic.Sanic()
    app.blueprint(group)
    app.blueprint(bg)


# Example of

# Generated at 2022-06-12 08:35:13.228452
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-12 08:35:19.285391
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp', url_prefix='/bp')

    bpg = BlueprintGroup(bp, url_prefix='/api')

    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        print('applied on Blueprint : bp Only')

    @bp.route('/')
    async def bp_route(request):
        return text('bp')

    return bpg, bp


# Generated at 2022-06-12 08:35:27.581879
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Blueprint with BlueprintGroup
    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # BlueprintGroup to BlueprintGroup
    bpg2 = BlueprintGroup(bpg1, url_prefix="/api/v2")

    # BlueprintGroup of BlueprintGroup
    bpg3 = BlueprintGroup(bp1, bpg2, url_prefix="/api", version="v1")

    app = Sanic("test_BlueprintGroup_middleware")


# Generated at 2022-06-12 08:35:39.128350
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg1 = BlueprintGroup()
    bpg2 = BlueprintGroup()

    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg1.middleware(lambda x: x)

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

    bpg2.append(bpg1)
    bpg2.append(bp3)

    bpg2.middleware(lambda x: x)

    assert len(bp1.middlewares) == 2
    assert len(bp2.middlewares) == 2

# Generated at 2022-06-12 08:35:47.507479
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bp_stub = Blueprint('bp_stub')
    bpg2 = BlueprintGroup()
    bpg2.append(bp1)
    bpg2.append(bp_stub)
    bp_stub.update_blueprint(bp3)

    @bpg.middleware
    async def middleware_fn(request):
        return text('bp1_middleware')

    @bp1.listener('before_server_start')
    async def before_server_start_fn(app, loop):
        return text

# Generated at 2022-06-12 08:35:56.891351
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    def set_bp1_middleware(request):
        return text('bp1_middleware')

    def set_bp2_middleware(request):
        return text('bp2_middleware')

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    # Check if middleware can be set using callables
    bp_group.middleware(set_bp1_middleware, set_bp2_middleware)
    assert bp1.middlewares == [set_bp1_middleware]
    assert bp2.middlewares == [set_bp2_middleware]



# Generated at 2022-06-12 08:36:04.821448
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """ Unit test for method middleware of class BlueprintGroup. """
    blueprint_obj = Blueprint(name="blueprint_obj")
    blueprint_group_obj = BlueprintGroup(url_prefix="url_prefix")

    @blueprint_obj.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @blueprint_group_obj.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    return

# Generated at 2022-06-12 08:36:14.892208
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bps = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bps.middleware('request')
    async def bps_middleware(request):
        print('common middleware applied for both bps')


# Generated at 2022-06-12 08:36:24.601295
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert group.middleware == group_middleware

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:36:36.720054
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')
    @bpg.middleware('request')
    async def bpg_middleware(request):
        print('applied on BlueprintGroup')
    #Check the middleware for blueprint bp1

# Generated at 2022-06-12 08:36:46.210996
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class MockBlueprint(sanic.Blueprint):
        """
        A mock blueprint class to test the Blueprint Group Middleware behavior
        """

        _middleware = {}

        @staticmethod
        def middleware(
            fn: Union[Callable, List[Callable]], *args, **kwargs
        ) -> Callable:
            """
            A static method to update the middleware dictionary
            """
            global _middleware
            MockBlueprint._middleware[fn.__name__] = (args, kwargs)

        @staticmethod
        def get_middleware() -> dict:
            """
            Returns the middleware dictionary
            """
            global _middleware
            return MockBlueprint._middleware

    # Create a Blueprint Group
    bpg = BlueprintGroup()

    # Create a nested Blueprint Group
    bpg1 = BlueprintGroup

# Generated at 2022-06-12 08:36:57.358079
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    @bp1.middleware('request')
    async def bp1_only_middleware(request):
            print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
            return text('bp1')


# Generated at 2022-06-12 08:37:07.880564
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create Mocks
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    # Create a Blueprint Group
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware(with_context=True)
    async def new_middleware_one(request):
        pass

    @bpg.middleware(with_context=False)
    def new_middleware_two(request):
        pass

    assert len(bp1._middleware) == 2
    assert len(bp2._middleware) == 2

    new_middleware_one(context=True)
    new_middleware_two(context=False)


# Generated at 2022-06-12 08:37:26.052932
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(name=__name__)
    bp = Blueprint("test", url_prefix="/test")
    bpg = BlueprintGroup(bp)
    from sanic.blueprints import Blueprint
    Blueprint.middleware = BlueprintGroup.middleware

    @bpg.middleware("request")
    def test_middleware(request):
        request["test"] = "test"

    @bp.route("/test")
    async def bp_route(request):
        return text("test")

    app.blueprint(bp)
    app.blueprint(bpg)
    _, response = app.test_client.get("/test/test")
    assert response.status == 200
    assert response.text == "test"

# Generated at 2022-06-12 08:37:37.620718
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from sanic.response import text
    from sanic.utils import sanic_endpoint_test

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp2', url_prefix='/bp3')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/param')
    async def bp2_route(request):
        return text('bp2')

    @bp3.route('/param')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-12 08:37:48.994644
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def mock_middleware(request):
        pass

    # Create a mock blueprint group with 3 blueprints
    bpg = BlueprintGroup()

    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    # Register middleware without parameters
    bpg.middleware(mock_middleware)

    assert bp1.middlewares == [mock_middleware]
    assert bp2.middlewares == [mock_middleware]
    assert bp3.middlewares == [mock_middleware]

    # Register middleware with parameters
    bpg.middleware("request")(mock_middleware)


# Generated at 2022-06-12 08:37:59.167268
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')

    @bp.middleware('request')
    async def bp_middleware_request(request):
        return text('bp_middleware_request')

    @bp.middleware('response')
    async def bp_middleware_response(request, response):
        return text('bp_middleware_response')

    @bp.middleware('error')
    async def bp_middleware_error(request, exception):
        return text('bp_middleware_error')

    @bp.route('/')
    async def bp_route(request):
        return text('bp_route')



    bpg = BlueprintGroup(url_prefix="/api", version="v1")


# Generated at 2022-06-12 08:38:09.331099
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    main_bp = Blueprint("main_bp")
    child_bp = Blueprint("child_bp")
    main_bp.blueprint(child_bp)

    @main_bp.middleware("request")
    async def mom_request(request):
        pass

    @child_bp.middleware("request")
    async def child_request(request):
        pass

    @main_bp.middleware("response")
    async def mom_response(request, response):
        pass

    @child_bp.middleware("response")
    async def child_response(request, response):
        pass

    def test_middleware(app):
        for method in ["request", "response"]:
            assert len(app.blueprints["main_bp"].middlewares[method]) == 2

# Generated at 2022-06-12 08:38:19.679597
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # GIVEN
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup(bp1, bp2)

    # WHEN
    @group.middleware('request')
    async def group_middleware(request):
        request.app.group_middleware = request.app.group_middleware + 1
        return None

    # THEN
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1
    assert bp1.middlewares['request'][0][0] == group_middleware
    assert bp2.middlewares['request'][0][0] == group_middleware



# Generated at 2022-06-12 08:38:26.973393
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test Class BlueprintGroup method middleware."""
    app = sanic.Sanic('test_BlueprintGroup_middleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

# Generated at 2022-06-12 08:38:34.921368
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-12 08:38:45.825276
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp3 = Blueprint("bp3", url_prefix="/bp4")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp3.route("/")
    def bp1_route(request):
        return text("bp1")

    @bp4.route("/<param>")
    def bp2_route(request, param):
        return text(param)

    @bpg.middleware("request")
    async def bpg_middleware(request):
        pass

    app = Sanic("test_BlueprintGroup_middleware", strict_slashes=False)

# Generated at 2022-06-12 08:38:55.012590
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    class Midware:
        @staticmethod
        @bp1.middleware('request')
        async def example_middleware(request):
            print('applied on Blueprint : bp1 Only')

        @staticmethod
        @bp2.middleware('request')
        async def example_middleware(request):
            print('applied on Blueprint : bp2 Only')

    bp_group = BlueprintGroup()

    @bp_group.middleware('request')
    async def example_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    bp_group.append(bp1)

# Generated at 2022-06-12 08:39:15.674325
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bpg.middleware('request')
    async def common_middleware(request):
        print('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-12 08:39:24.928488
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v2")


# Generated at 2022-06-12 08:39:34.665224
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert request.app is app
        request.bp1_only_middleware = True

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:39:42.183591
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @Blueprint.middleware('request')
    def bp_request_middleware(request):
        pass

    @Blueprint.middleware('response')
    def bp_response_middleware(request, response):
        pass

    @BlueprintGroup.middleware('request')
    def bpg_request_middleware(request):
        pass

    @BlueprintGroup.middleware('response')
    def bpg_response_middleware(request, response):
        pass

    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp, bp2, url_prefix="/api", version="v1")
    assert len(bp.middlewares.request) == 1

# Generated at 2022-06-12 08:39:50.871152
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest.mock import Mock, call

    bp1 = Mock(spec=sanic.blueprints.Blueprint)
    bp2 = Mock(spec=sanic.blueprints.Blueprint)

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware()
    def middleware():
        pass

    assert bp1.middleware.called
    assert bp2.middleware.called
    assert bp1.middleware.call_args == call(middleware, func=None)
    assert bp2.middleware.call_args == call(middleware, func=None)


# Generated at 2022-06-12 08:39:59.332444
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    @bp1.middleware('request')
    async def test_bp1_middleware(request):
        print('test_bp1_middleware applied')
        print("blueprint version: ", request.blueprint.version)
        print("blueprint url_prefix: ", request.blueprint.url_prefix)
        print("blueprint strict_slashes: ", request.blueprint.strict_slashes)

    @bp2.middleware('request')
    async def test_bp2_middleware(request):
        print('test_bp2_middleware applied')
        print("blueprint version: ", request.blueprint.version)
        print("blueprint url_prefix: ", request.blueprint.url_prefix)
        print("blueprint strict_slashes: ", request.blueprint.strict_slashes)


# Generated at 2022-06-12 08:40:04.801816
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        pass
    
    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

# Generated at 2022-06-12 08:40:14.848348
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:40:24.380728
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp3.middleware('request')
    async def bp3_middleware(request):
        return fr'bp3_middleware'

    @bpg.middleware('request')
    async def bpg_middleware(request):
        return fr'bpg_middleware'

    app.blueprint(bp3)
    app.blueprint(bpg)
    

# Generated at 2022-06-12 08:40:34.254372
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Blueprint Group without any blueprint
    bpg1 = BlueprintGroup(url_prefix='/v1', version="v1")
    assert len(bpg1.blueprints) == 0
    assert bpg1.url_prefix == "/v1"
    assert bpg1.version == "v1"

    bp1 = Blueprint('bp1')
    bp1.websocket_route('/ws')(lambda x: None)

    bp2 = Blueprint('bp2')
    bp2.websocket_route('/ws')(lambda x: None)

    bpg2 = BlueprintGroup(bp1, bp2)
    assert len(bpg2.blueprints) == 2

    @bpg2.middleware('request')
    async def group_middleware(request):
        pass

    assert bp1.request