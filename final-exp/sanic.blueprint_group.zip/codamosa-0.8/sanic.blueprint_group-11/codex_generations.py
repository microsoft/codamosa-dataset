

# Generated at 2022-06-12 08:31:16.245338
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from unittest import mock

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bpg2 = BlueprintGroup(bpg, bp5, bp6, url_prefix="/api2/3")

    fn = mock.MagicMock()
    bpg2.middleware(fn)

   

# Generated at 2022-06-12 08:31:28.231148
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """test middleware function of BlueprintGroup class"""
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bp1.middleware("request")(lambda request: None)
    bp2.middleware("request")(lambda request: None)

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bp1.middlewares.get("request")) == 1
    assert len(bp2.middlewares.get("request")) == 1

    # apply middleware on bpg
    bpg.middleware("request")(lambda request: None)

    assert len(bp1.middlewares.get("request")) == 2
    assert len(bp2.middlewares.get("request")) == 2

# Generated at 2022-06-12 08:31:35.928496
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1


# Generated at 2022-06-12 08:31:47.238012
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        return text('group_middleware')

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

    @group.middleware('request')
    async def group_middleware2(request):
        return text('group_middleware2')

    assert len(bp1.middlewares['request']) == 2
    assert len(bp2.middlewares['request']) == 2


# Generated at 2022-06-12 08:31:54.738347
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp_app = sanic.Sanic("Test Blueprint Group middleware")

    @bp_app.middleware('request')
    async def common_middleware(request):
        request["bp_app_common_middleware_applied"] = True

    bp1 = Blueprint("test-bp1", url_prefix="/bp1")

    @bp1.middleware('request')
    async def common_middleware_bp1(request):
        request["bp1_app_common_middleware_applied"] = True

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1 route")

    bp2 = Blueprint("test-bp2", url_prefix="/bp2")


# Generated at 2022-06-12 08:31:57.621717
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware('request')
    async def test_middleware(request):
        print('test_middleware')

    assert test_middleware.__name__ == 'test_middleware'


# Generated at 2022-06-12 08:32:05.706110
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        assert request.method == 'GET'

    request, response = group.handle_request(sanic.request.Request(
        'GET', '/bp1/blah', None, None,
        sanic.request.RequestParameters(), 0))



# Generated at 2022-06-12 08:32:17.287907
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # building required objects for testing
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert 'applied on Blueprint : bp1 Only' is not None


# Generated at 2022-06-12 08:32:27.236481
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp', url_prefix='/')
    bpg = BlueprintGroup(url_prefix='/api')
    bpg.append(bp)

    # Test without bp's middleware
    aioresponses(bp.app)
    @bp.middleware('request')
    async def bp_middleware(request):
        request['bp_middleware'] = 'applied'

    @bp.route('/middleware')
    async def middleware(request):
        return json({"middleware": request.get('bp_middleware', 'null')})

    _, response = bp.app.test_client.get('/api/middleware')
    assert response.json() == {'middleware': 'null'}

    # Test with bpg's middleware

# Generated at 2022-06-12 08:32:34.395569
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("Test")

    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @app.route("/")
    async def handler(request):
        return text("OK")

    @bpg.middleware("request")
    async def middleware_bp1(request):
        return text("Middleware")

    bp1.add_route(handler, '/')
    bp2.add_route(handler, '/')

    app.blueprint(bpg)

    request, response = app.test_client.get("/bp1")
    assert response.text == "Middleware"

# Generated at 2022-06-12 08:32:46.501576
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:32:57.152904
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    app.config.from_pyfile("tests/unit/config.json")
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bp3 = sanic.Blueprint("bp3")
    bp4 = sanic.Blueprint("bp4")
    bp5 = sanic.Blueprint("bp5")
    bpg1 = BlueprintGroup("api", "v1")
    bpg2 = BlueprintGroup("api", "v2")
    bpg3 = BlueprintGroup("api", "v3")
    bpg1.append(bp1)
    bpg1.append(bp2)
    bpg2.append(bpg1)
    bpg2.append(bp3)

# Generated at 2022-06-12 08:33:04.310059
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = Blueprint.group(bp1, bp2, url_prefix='/api', version='v1')

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp3.middleware('request')
    async def bp3_only_middleware(request):
        print('applied on Blueprint : bp3 only')


# Generated at 2022-06-12 08:33:14.392888
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    request = sanic.request.Request(
        app, sanic.protocol.HttpProtocol(app))

    def middleware_function(request):
        request.feed_data(b'awesome')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)

    @bpg.middleware()
    async def group_middleware(request):
        request.feed_data(b'awesome')
        await request.app.handle_request(request)

    assert not hasattr(request, "feed_data")

    app.handle_request(request)

    assert hasattr(request, "feed_data")

# Generated at 2022-06-12 08:33:26.055797
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4)

    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp3 and bp4')

    assert hasattr(bp3, '_middleware')
    assert hasattr(bp4, '_middleware')

    @bpg.middleware('request')
    async def group_middleware1(request):
        print('common middleware applied for both bp3 and bp4')

# Generated at 2022-06-12 08:33:38.090508
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    app = sanic.Sanic("BlueprintGroup_Test_App")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version=1)

    @bpg.middleware('request')
    async def test_middleware(request):
        print("Test middleware will run twice")

    bp1.add_route(lambda x: None, "/")
    bp2.add_route(lambda x: None, "/")

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1

    assert bp1.middlewares["request"][0][0] is test

# Generated at 2022-06-12 08:33:43.029858
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    group2 = BlueprintGroup()
    group2.append(bp3)
    group2.append(bp4)
    group2.append(group)

    # Check parent middleware
    assert bp1.middlewares['request'] == []
    assert bp2.middlewares['request'] == []

    # Check nested blueprint middleware
    assert bp3.middlewares['request'] == []
   

# Generated at 2022-06-12 08:33:52.166973
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("test")
    bp2 = Blueprint("test")
    bp3 = Blueprint("test")

    bpg = BlueprintGroup("test")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)

    @bpg.middleware("request")
    async def test(request):  # type:(sanic.Request) -> None
        pass

    assert test in (bp1.middlewares["request"] + bp2.middlewares["request"]), \
        "BlueprintGroup.middleware is not working"



# Generated at 2022-06-12 08:33:58.000495
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    for blueprint in bpg.blueprints:
        assert len(blueprint.request_middleware) == 1


# Generated at 2022-06-12 08:34:08.813565
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create Blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    # Create Blueprint Group
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # Call bpg.middleware('request') which should not raise anything
    @bpg.middleware('request')
    async def request_middleware(request):
        pass
    
    # Call bpg.middleware('response') which should not raise anything
    @bpg.middleware('response')
    async def response_middleware(request, response):
        pass
    
    # Call bpg.middleware('exception') which should not raise anything

# Generated at 2022-06-12 08:34:20.185770
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.listener("after_server_start")
    def bp1_listener_after_server_start(app, loop):
        pass

    @bp2.listener("after_server_start")
    def bp2_listener_after_server_start(app, loop):
        pass

    @bp1.listener("after_server_stop")
    def bp1_listener_after_server_stop(app, loop):
        pass

    @bp2.listener("after_server_stop")
    def bp2_listener_after_server_stop(app, loop):
        pass


# Generated at 2022-06-12 08:34:31.327682
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Arrange
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:36.029710
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    _handler = lambda x : x
    group.middleware(_handler)
    assert bp1.has_middleware(_handler)
    assert bp2.has_middleware(_handler)


# Generated at 2022-06-12 08:34:46.034470
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api', version='v1')
    bpg.append(bp1) # not using the Blueprints.group method to avoid circular imports i.e. Blueprint

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:34:56.597565
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:05.892617
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class BlueprintStub(Blueprint):
        def group(self, *args, url_prefix=None, version=None, register=True,
                  strict_slashes=None):
            bg = BlueprintGroup(url_prefix=url_prefix, version=version,
                                strict_slashes=strict_slashes)
            for bp in args:
                bg.append(bp)
            if register:
                self.register_blueprint(bg)
            return bg

    @BlueprintStub.middleware('response')
    async def middleware_func(request, response):
        return text('middleware_func')


    @BlueprintStub.route('/test')
    async def bp(request):
        return text('bp')


# Generated at 2022-06-12 08:35:13.118818
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware("request")
    async def bp_group_middleware(request):
        pass

    assert hasattr(bp1.middlewares["request"], "__iter__")
    assert hasattr(bp2.middlewares["request"], "__iter__")

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1

    assert bp_group_middleware in bp1.middlewares["request"]
    assert bp_group_middleware in bp2.middlewares["request"]

# Generated at 2022-06-12 08:35:22.352301
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Application(sanic.Sanic):
        pass

    @BlueprintGroup.middleware('request')
    def test_bpGroup_middle():
        pass

    app = Application()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpGroup = BlueprintGroup()

    bpGroup.append(bp1)
    bpGroup.append(bp2)

    assert hasattr(bp1, 'middleware')
    assert hasattr(bp2, 'middleware')
    assert hasattr(bpGroup, 'middleware')

    # assert isinstance(bpGroup.middleware, partial)
    # assert isinstance(bpGroup.middleware, partial)

    # assert isinstance(bp1.middleware, partial)
   

# Generated at 2022-06-12 08:35:31.447872
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():        
    from sanic import Sanic

    app = Sanic('test_BlueprintGroup_middleware')
    
    bp = Blueprint('test_BlueprintGroup_middleware', url_prefix='/test')
    bpg = BlueprintGroup(url_prefix='')
    bpg.append(bp)

    @bp.route('/')
    async def hello(request):
        return text('Hello World!')

    @bpg.middleware
    async def print_on_request(request):
        print("Middleware applied! {}".format(request))
        response = await request.app.router.dispatch(request)
        return response

    app.blueprint(bpg)
    assert len(bpg.blueprints) == 1
    assert len(bp.middlewares) == 1

# Generated at 2022-06-12 08:35:38.967935
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This function is used to unit test the BlueprintGroup middleware feature.
    """
    bp1 = sanic.Blueprint("bp1")
    bp2 = sanic.Blueprint("bp2")
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bp1_mw_count = 0
    bp2_mw_count = 0

    @bp1.middleware("request")
    async def bp1_mw(request):
        """
        This method is used to unit test the BlueprintGroup middleware feature.
        """
        nonlocal bp1_mw_count
        bp1_mw_count += 1


# Generated at 2022-06-12 08:35:53.154523
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:36:04.099834
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """ Unit test for method middleware of class BlueprintGroup """
    class FakeBlueprint:
        middleware_list = []

        def middleware(self, middleware, *args, **kwargs):
            self.middleware_list.append(middleware)
    fake_bp1 = FakeBlueprint()
    fake_bp2 = FakeBlueprint()
    bp_group = BlueprintGroup()
    bp_group.append(fake_bp1)
    bp_group.append(fake_bp2)

    @bp_group.middleware
    def middleware_stub(*args, **kwargs):
        pass

    assert middleware_stub in fake_bp1.middleware_list
    assert middleware_stub in fake_bp2.middleware_list

# Generated at 2022-06-12 08:36:10.068067
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    flag = 0
    @group.middleware('request')
    async def group_middleware(request):
        flag = 1
    
    assert flag == 1
    

# Generated at 2022-06-12 08:36:17.251521
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def dummy_middleware(*args, **kwargs):
        dummy_middleware.called = True

    dummy_middleware.called = False

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.middleware(dummy_middleware) is None
    assert bp1.middlewares[-1] == dummy_middleware
    assert bp2.middlewares[-1] == dummy_middleware


# Generated at 2022-06-12 08:36:25.000387
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Testing BlueprintGroup.middleware
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware("request")
    def group_request_middleware(request):
        """
        Dummy request middleware
        """
        request["group_request_middleware"]=True

    @bp2.middleware("request")
    def bp2_request_middleware(request):
        """
        Dummy request middleware
        """
        request["bp2_request_middleware"]=True

    assert "group_request_middleware" not in bp1.request_middleware_stack
   

# Generated at 2022-06-12 08:36:37.000548
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from .router import Router
    from .blueprint import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    assert not bp1.middlewares['request']
    assert not bp2.middlewares['request']

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1

    app = sanic.Sanic("test_BlueprintGroup")

# Generated at 2022-06-12 08:36:46.313947
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bg1 = BlueprintGroup()
    bg1.append(bp1)
    bg1.append(bp2)
    @bp1.middleware("request")
    def middleware_bp1(request):
        pass
    @bp2.middleware("request")
    def middleware_bp2(request):
        pass
    @bg1.middleware("request")
    def middleware_bg1(request):
        pass
    assert middleware_bp1 in bp1.middlewares["request"]
    assert middleware_bp2 in bp2.middlewares["request"]
    assert middleware_bg1 in bp1.middlewares["request"]
    assert middleware_bg1 in bp2.middlew

# Generated at 2022-06-12 08:36:57.433315
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    bp = Blueprint(url_prefix="v1")

    @bp.middleware("request")
    async def bp_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp.route("/")
    async def bp_route(request):
        return sanic.response.text("bp1")

    # TODO: Mock BlueprintGroup
    bpg = BlueprintGroup()
    bpg.append(bp)

    @bpg.middleware("request")
    async def group_middleware(request):
        print("common middleware applied for both bp1 and bp2")

    assert "bp_only_middleware" in bp._middlewares
    assert "group_middleware" in bp._middlewares



# Generated at 2022-06-12 08:37:08.013987
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    @sanic.Blueprint.group("/api", url_prefix="/v1")
    @sanic.Blueprint.group("/api", url_prefix="/v2")
    async def bp1(request):
        return text("bp1")

    app = sanic.Sanic("test_BlueprintGroup_middleware")

    # Blueprint Group Middleware
    @bp1.middleware("response")
    async def group_middleware(request, response):
        response.headers["X-BPGroup-middleware"] = "applied"

    # Blueprint Middleware
    @bp1[0].middleware("response")
    async def blueprint_middleware(request, response):
        response.headers["X-Blueprint-middleware"] = "applied"

    # Blueprint Group Middleware

# Generated at 2022-06-12 08:37:12.535533
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    app.blueprint(BlueprintGroup(url_prefix='/v1', strict_slashes=True))
    app.blueprint(BlueprintGroup(url_prefix='/v2', strict_slashes=True))


# Generated at 2022-06-12 08:37:26.730271
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')
    assert bp1.middlewares['request'][0] == group_middleware
    assert bp2.middlewares['request'][0] == group_middleware


# Generated at 2022-06-12 08:37:36.927509
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert group.blueprints[0].request_middleware[0].__name__ == 'group_middleware'
    assert group.blueprints[1].request_middleware[0].__name__ == 'group_middleware'


# Generated at 2022-06-12 08:37:48.260336
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    assert len(bp1.middlewares.request) == 0
    assert len(bp2.middlewares.request) == 0
    assert len(bp3.middlewares.request) == 0
    assert len(bp4.middlewares.request) == 0
    assert len(bpg.blueprints[0].middlewares.request) == 0

# Generated at 2022-06-12 08:37:59.085671
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    def mw(fn): 
        return fn

    @bpg.middleware()
    def mw(): 
        pass

    @bpg.middleware('request')
    def mw(): 
        pass

    # check blueprint related middlewares and blueprintgroup related middlewares
    assert len(bp1.middlewares['request']) == 0
    assert len(bp2.middlewares['request']) == 0
    assert len(bpg.middlewares['request']) == 1

    # check blueprintgroup related middlewares
    assert len(bpg._blueprints[0].middlewares['request']) == 0
   

# Generated at 2022-06-12 08:38:09.272637
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    This unit test mimics the same functionality as the one shown in the
    module documentation.
    """

    app = sanic.Sanic("sanic_blueprint_middleware_test")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp1.blueprint_group = BlueprintGroup(url_prefix="/api", version="v1")
    bp1.blueprint_group.append(bp1)
    bp1.blueprint_group.append(bp2)

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")


# Generated at 2022-06-12 08:38:19.602462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # ~~~~~~~~ Preparing test fixtures ~~~~~~~~
    # Prepare test application
    app = sanic.Sanic(__name__)

    # Register a group of blueprints
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    for blueprint in [bp1, bp2, bpg]:
        app.blueprint(blueprint)

    # Register Middleware for the Blueprint Group
    middleware_list = []


# Generated at 2022-06-12 08:38:26.964150
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    f_path = os.path.dirname(__file__)
    app = Sanic(__name__)
    app.blueprint(bp1)
    app.blueprint(bp2)


# Generated at 2022-06-12 08:38:38.766511
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bg = sanic.blueprints.BlueprintGroup(url_prefix='/group')
    bg.append(bp1)
    bg.append(bp2)

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')

    @bg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    app.blueprint(bg)


# Generated at 2022-06-12 08:38:43.824472
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp = Blueprint('test_BlueprintGroup_middleware')
    bpg = BlueprintGroup()
    bpg.append(bp)
    @bp.middleware
    async def handler(request):
        pass

    assert handler in bp.middlewares['request']


# Generated at 2022-06-12 08:38:50.366864
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

# Generated at 2022-06-12 08:39:11.219894
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:39:21.472438
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestMiddleware():

        def __init__(self):
            self.has_been_called = False

        async def __call__(self, request, *args, **kwargs):
            self.has_been_called = True

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    mw = TestMiddleware()

    # Test single blueprint
    bpg.middleware(mw)
    assert bp1.middlewares
    assert bp2.middlewares

    # Test list of blueprints
    bpg.middleware(mw, bp1)
    assert bp1.middle

# Generated at 2022-06-12 08:39:28.142367
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v1")

    bpg = BlueprintGroup("/api", "v1")
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def group_middleware_1(request):
        print("common middleware 1 applied for both bp1 and bp2")

    @bpg.middleware("request")
    async def group_middleware_2(request):
        print("common middleware 2 applied for both bp1 and bp2")


# Generated at 2022-06-12 08:39:37.175880
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    assert len(group.blueprints) == 2

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1


# Generated at 2022-06-12 08:39:41.261885
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def assert_middleware(fn):
        assert fn(1) == 5

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    group = Blueprint.group(bp1, bp2)
    group.middleware(assert_middleware)
    assert len(bp1.middleware_stack) == 1
    assert len(bp2.middleware_stack) == 1

# Generated at 2022-06-12 08:39:50.870907
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    # Create a Blueprint Group
    bpg = BlueprintGroup()

    # Add Blueprint1, Blueprint2, Blueprint3, Blueprint4 to the Group
    bpg.append(bp1)
    bpg.append(bp2)

    # Other way to add Blueprint3 and Blueprint4
    bpg.insert(0, bp3)
    bpg.insert(0, bp4)


# Generated at 2022-06-12 08:39:59.331310
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        """
        Sanic App class for testing purposes
        """
        pass

    @sanic.exceptions.add_status_code(404)
    class Test404(Exception):
        """
        Exception class that can be used to test the status 404
        """

    def blueprint_custom_handler(request: sanic.request.Request,
                                 exception: Test404,
                                 app: App):
        """
        Test custom exception handler method that can be used to
        test the custom handlers being applied across the blueprint
        group.
        """
        return text(request.url)


# Generated at 2022-06-12 08:40:05.798776
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # GIVEN a BlueprintGroup containing two blueprints
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup(bp1, bp2)

    # WHEN the BlueprintGroup.middleware method is used to register the
    # middleware
    @bpg.middleware
    def test_middleware(request):
        # DO NOTHING
        pass

    # THEN the blueprint should have the middleware applied
    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1

# Generated at 2022-06-12 08:40:15.738398
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # GIVEN
    bp1 = Blueprint('bp1', url_prefix='/bp1')

    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp2.strict_slashes = False


    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # WHEN
    bpg.middleware(group_middleware)

    # THEN

# Generated at 2022-06-12 08:40:25.775548
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprint.Blueprint.middleware("request")
    async def blueprint_middleware_test(request):
        return True

    bp1 = sanic.blueprint.Blueprint("bp1", url_prefix="/bp1")
    bp2 = sanic.blueprint.Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(url_prefix="/api")
    assert bp1.middlewares["request"][0](None) == blueprint_middleware_test(None)

    bpg.append(bp1)
    assert bpg.blueprints[0].middlewares["request"][0](None) == blueprint_middleware_test(None)
    assert bpg.middleware(blueprint_middleware_test)(None) == blueprint_middleware_test(None)
    b

# Generated at 2022-06-12 08:40:57.899432
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    
    # Test without parameter and without decorator
    bp1 = Blueprint('bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        return

    group = BlueprintGroup()
    group.append(bp1)

    assert bp1.middlewares[0][0] == bp1_only_middleware
    assert bp1.middlewares[0][1] == 'request'

    # Test with parameter and with decorator
    bp2 = Blueprint('bp2')
    group.append(bp2)

    @group.middleware('response')
    async def group_middleware(request):
        return

    assert bp2.middlewares[0][0] == group_middleware
    assert bp2.middlewares[0][1]

# Generated at 2022-06-12 08:41:04.152874
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    sanic_app = sanic.Sanic("unit-test-for-BlueprintGroup-middleware")
    bp1 = Blueprint("bp1", url_prefix="/bp1", version="v1")
    bp2 = Blueprint("bp2", url_prefix="/bp2", version="v2")
    bg1 = BlueprintGroup("bp3", "bp4", url_prefix="/api", version="v1")
    bg1.middleware(bp1.middleware)
    assert len(bp1.__middleware__["request"]) == 1
    assert len(bp1.__middleware__["response"]) == 0
    assert len(bp1.__middleware__["static"]) == 0
