

# Generated at 2022-06-12 08:31:11.286255
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class FakeBlueprint(sanic.Blueprint):
        def __init__(self):
            self.middlewares = []

        def middleware(self, fn, *args, **kwargs):
            self.middlewares.append((fn, args, kwargs))

        def get_middlewares(self):
            return self.middlewares
    
    bp1 = FakeBlueprint()
    bp2 = FakeBlueprint()
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware
    async def bpg_middleware_1(request):
        pass

    @bpg.middleware('request', attach_to='request')
    async def bpg_middleware_2(request):
        pass


# Generated at 2022-06-12 08:31:20.347666
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    application = sanic.Sanic("BlueprintGroupMiddleware")
    app = application
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:31:28.235307
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:31:35.865994
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    param = {"x": "test"}

    @bpg.middleware(request=True, response=False)
    async def middleware_test(request, response):
        param["x"] = "test1"
    assert param["x"] == "test1"


# Generated at 2022-06-12 08:31:47.537167
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Test BlueprintGroup.middleware"""

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    # create BlueprintGroup with bp2, bp2
    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # test method middleware of class

# Generated at 2022-06-12 08:31:53.607549
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)
    @group.middleware('request')
    async def bp1_only_middleware(request):
        print('common middleware applied for both bp1 and bp2')

# Generated at 2022-06-12 08:32:00.225200
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class App(sanic.Sanic):
        pass

    class BpA(sanic.Blueprint):
        pass

    class BpB(sanic.Blueprint):
        pass

    bpA = BpA("bpA")
    bpB = BpB("bpB")

    app = App()
    app.blueprint(BlueprintGroup(bpA, bpB))

    @bpA.middleware("request")
    def mw_bpA(request):
        pass

    @bpB.middleware("request")
    def mw_bpB(request):
        pass

    @BlueprintGroup.middleware("request")
    def mw_group(request):
        pass

    assert mw_bpA in bpA.request_middleware
    assert mw_bpB in bpB

# Generated at 2022-06-12 08:32:09.411303
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp1_spied = spy(bp1)
    bp2_spied = spy(bp2)
    bp_group = BlueprintGroup()
    bp_group.append(bp1_spied)
    bp_group.append(bp2_spied)

    @bp_group.middleware('request')
    def bp_group_req_middleware(request):
        pass

    @bp_group.middleware('response')
    def bp_group_res_middleware(request, response):
        pass

    assert bp1_spied.middleware.call_count == 2
    assert bp1_spied.middleware.call_args_list[0].kwargs.get('list_type')

# Generated at 2022-06-12 08:32:20.414083
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class fake_app:

        def register_middleware(self, middleware, *args, **kwargs):
            fn = args[0]
            args = list(args)[1:]
            if "bp1_only_middleware" == fn.__name__:
                assert "request" == kwargs["attach_to"]
                return None

            elif "group_middleware" == fn.__name__:
                assert "request" == kwargs["attach_to"]
                return None

        class spec:
            app = True

    @sanic.blueprint("bp1", url_prefix="/bp1")
    class blueprint1:

        @blueprint1.middleware("request")
        def bp1_only_middleware(self, request):
            pass


# Generated at 2022-06-12 08:32:28.859831
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    group1 = Blueprint.group(bp1, bp2)

    group2 = Blueprint.group(bp3, bp4, url_prefix="/group", version="v1")

    @group1.middleware('request')
    async def group1_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @group2.middleware('request')
    async def group2_middleware(request):
        print('common middleware applied for both bp3 and bp4')

    assert group1.blueprints == [bp1, bp2]

# Generated at 2022-06-12 08:32:42.349659
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(url_prefix='/bp1g')
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup(url_prefix='/bp2g')
    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg3 = BlueprintGroup(url_prefix='/bp3g')

# Generated at 2022-06-12 08:32:51.952791
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix='/api', version='v1')
    bpg.append(bp3)
    bpg.append(bp4)
    bpg.middleware(lambda x: x)(lambda x: x)
    assert bp3.middlewares == [lambda x: x]
    assert bp4.middlewares == [lambda x: x]

# Generated at 2022-06-12 08:33:00.827593
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    async def request_middleware(request):
        request['message'] = 'Success'
        return request

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')

    bp1_middleware_1_count = 0
    bp2_middleware_1_count = 0
    bp3_middleware_1_count = 0
    bp4_middleware_1_count = 0
    bp5_middleware_1_count = 0


# Generated at 2022-06-12 08:33:12.716611
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:33:24.533896
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestMiddleware:
        def __init__(self, req, res):
            pass

        async def __call__(self, req, res):
            pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg1 = BlueprintGroup(url_prefix='/bpg1').append(bp1).append(bp2)
    bpg2 = BlueprintGroup(url_prefix='/bpg2').append(bp3).append(bp4)

# Generated at 2022-06-12 08:33:31.456703
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for BlueprintGroup class method middleware
    """
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = Blueprint.group(bp1, bp2)
    bpg = BlueprintGroup(url_prefix='/blp_group')
    bpg.append(bp3)
    bpg.append(bp4)
    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')


# Generated at 2022-06-12 08:33:43.426340
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test to check the BlueprintGroup middleware functionality

    https://github.com/huge-success/sanic/pull/1722
    """

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp5')

    group1 = BlueprintGroup()
    group2 = BlueprintGroup()

    group1.append(bp1)
    group1.append(bp2)
    group2.append(bp3)
    group2.append(bp4)

    group1.append(group2)

    global bp_middleware, middleware_called_count
    bp_middle

# Generated at 2022-06-12 08:33:53.774701
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        pass

    app = App()
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")
    bpg1 = BlueprintGroup(url_prefix="/bpg1")
    bpg2 = BlueprintGroup(url_prefix="/bpg2")

    bp1.middleware_list = []
    bp2.middleware_list = []
    bp3.middleware_list = []
    bp4.middleware_list = []
    bpg1.middleware_list = []
    bpg2.middleware_list = []

   

# Generated at 2022-06-12 08:34:05.352169
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup()
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:34:12.263139
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    # bp3 = Blueprint('bp3', url_prefix='/bp4')
    # bp4 = Blueprint('bp4', url_prefix='/bp4')
    # bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    count = 0

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return

# Generated at 2022-06-12 08:34:26.267911
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Register a blueprint route
    @BlueprintGroup.middleware('request')
    async def test_middleware(request):
        return text('middleware')

    # Register a blueprint route
    @BlueprintGroup.route('/')
    async def test_route(request):
        return text('route')

    # Construct a Blueprint
    bp = Blueprint('test', url_prefix='/test')
    # Register above routes to the Blueprint
    Blueprint.middleware(bp, request=test_middleware)
    Blueprint.route(bp, '/', test_route)

    # Construct Blueprint Group
    bpg = BlueprintGroup()
    # add the bp to the bpg
    bpg.append(bp)

    # Get the app from the Blueprint
    app = bpg.get_app()

    # check if the middleware works correctly
   

# Generated at 2022-06-12 08:34:33.268869
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)

    @bg.middleware()
    async def middleware(request):
        print("applied on Blueprint Group: bg")

    assert middleware.__name__ == "middleware"
    assert middleware.__qualname__ == "test_BlueprintGroup_middleware.<locals>.middleware"

    assert bp1._middlewares == [middleware]
    assert bp2._middlewares == [middleware]

# Generated at 2022-06-12 08:34:40.423932
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    app = sanic.Sanic()
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-12 08:34:52.207621
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('bp', url_prefix='/bp')
    bpg = BlueprintGroup(bp, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def common_middleware(request):
        pass

    @bpg.middleware('request')
    def common_middleware_kw_only(request, x=None):
        pass

    assert len(bp._middleware) == 2
    app.blueprint(bpg, url_prefix="/bpg")
    assert app.blueprints["/bpg/bp"].url_prefix == "/api/bp"
    assert app.blueprints["/bpg/bp"].version == "v1"

# Generated at 2022-06-12 08:35:01.324494
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware(request):
        pass

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bg = BlueprintGroup()
    bg.append(bp1)
    bg.append(bp2)

    assert len(list(bp1.middleware_stack)) == 0
    assert len(list(bp2.middleware_stack)) == 0
    bg.middleware(middleware)
    assert len(list(bp1.middleware_stack)) == 1
    assert len(list(bp2.middleware_stack)) == 1

# Generated at 2022-06-12 08:35:11.010884
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1', version='v1')
    bp2 = Blueprint('bp2', url_prefix='/bp2', version='v2')
    bp_group = BlueprintGroup(bp1, bp2)

    # Check there is no middleware yet
    assert bp_group.middleware.middlewares == []
    assert bp1.middleware.middlewares == []
    assert bp2.middleware.middlewares == []

    @bp_group.middleware('response')
    async def bp_group_middleware1(request):
        pass

    @bp_group.middleware('response')
    async def bp_group_middleware2(request):
        pass

    # Check middleware was added to bp_group
    assert bp_

# Generated at 2022-06-12 08:35:20.820196
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')

    # First level blueprint group
    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

# Generated at 2022-06-12 08:35:28.606430
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix='/bpg', version='v1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.middleware('request')
    async def request_bp1(request):
        print('request BP1 middleware')


# Generated at 2022-06-12 08:35:37.143539
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')


# Generated at 2022-06-12 08:35:40.437422
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware()
    def blueprint_group_middleware(request):
        pass

    @BlueprintGroup.middleware(methods=["GET", "POST"])
    def blueprint_group_middleware(request):
        pass

    assert blueprint_group_middleware.__name__ == "blueprint_group_middleware"

# Generated at 2022-06-12 08:35:52.700630
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp = Blueprint('bp', url_prefix='/bp')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp_group = BlueprintGroup(bp, bp2)

    @bp_group.middleware()
    async def common_bp_group_middleware(request):
        print('common middleware applied for all bp1 and bp2')

    @bp.middleware()
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware()
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:35:59.860940
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @bp1.middleware(name='test')
    async def foo():
        pass
    assert len(bp1.middlewares) == 0
    
    @bp1.group.middleware()
    async def bar():
        pass
    assert len(bp1.middlewares) == 1
    assert bp1.middlewares[0][0] is bar
    assert len(bp1.middlewares[0][1]) == 0
    assert bp1.middlewares[0][2] is None

# Generated at 2022-06-12 08:36:04.436259
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic import Blueprint
    from test_blueprints import test_middleware

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        assert True

    test_middleware(group)

# Generated at 2022-06-12 08:36:12.790241
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware('request')
    async def middleware_func(request):
        return {}

    bp = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)

    assert isinstance(bpg.middleware, partial)
    assert bp.middlewares.get('request') == [middleware_func]
    assert bp2.middlewares.get('request') == [middleware_func]

# Generated at 2022-06-12 08:36:23.298975
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup("/bp3")
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp1.route("/")
    async def bp1_route(request):
        return text("bp1")

    @bp2.route("/<param>")
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:36:35.331698
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    @bpg.middleware
    async def assert_bp_is_set(request):
        assert request.blueprint == 'bp1' or request.blueprint == 'bp2'
    @bp1.route('/1')
    async def handle_bp1(request):
        return text(request.blueprint)
    @bp2.route('/2')
    async def handle_bp2(request):
        return text(request.blueprint)
    app = Sanic('test_BlueprintGroup_middleware')
    app.blueprint(bpg)
   

# Generated at 2022-06-12 08:36:46.015213
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    server = None

    async def bp1_route(request):
        assert request.app is app
        return sanic.response.text("OK")

    @app.middleware('request')
    async def bp1_only_middleware(request):
        assert request.app is not None

    @app.middleware('request')
    async def bp2_only_middleware(request):
        assert request.app is not None

    @app.middleware('request')
    async def group_middleware(request):
        assert request.app is not None

    @app.middleware('request')
    async def bpg_only_middleware(request):
        assert request.app is not None


# Generated at 2022-06-12 08:36:56.428259
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @bp.middleware
    async def function_1(request):
        pass

    @bp.middleware()
    async def function_2(request):
        pass

    @bp.middleware('request')
    async def function_3(request):
        pass

    @bp.middleware('request')
    async def function_4(request):
        pass

    @bp.middleware('response')
    async def function_5(request):
        pass

    @bp.middleware
    async def function_6(request):
        pass

    @bp.middleware('request')
    async def function_7(request):
        pass

    @bp.middleware('response')
    async def function_8(request):
        pass

# Generated at 2022-06-12 08:37:01.060899
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint = Blueprint('test', url_prefix='test')
    blueprint_group._blueprints.append(blueprint)

    @blueprint_group.middleware('request')
    async def test_middleware(request):
        print('test_middleware')

    assert blueprint.middlewares['request'][0] == test_middleware


# Generated at 2022-06-12 08:37:10.192072
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()

    def middleware(function):
        def function2(*args, **kwargs):
            assert 1 == 1
            return function(*args, **kwargs)
        return function2

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')

    @bp1.route('/')
    async def bp1_route(request):
        assert 1 == 1

    @bp2.route('/')
    async def bp2_route(request):
        assert 1 == 1

    @bp3.route('/')
    async def bp3_route(request):
        assert 1 == 1

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)


# Generated at 2022-06-12 08:37:29.667848
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test BlueprintGroup.append
    """
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.blueprints == [bp1, bp2]


# Generated at 2022-06-12 08:37:35.471104
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = BlueprintGroup("/api", "v1", True)

    assert len(group) == 0

    group.append(bp1)

    assert len(group) == 1

    group.append(bp2)

    assert len(group) == 2


# Generated at 2022-06-12 08:37:46.713500
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class FakeApp:

        def __init__(self):
            self.blueprints = []

        def blueprint(self, bp):
            self.blueprints.append(bp)

    def blueprint_middleware(a, b):
        return a, b

    app = FakeApp()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup(url_prefix="/api", version="v1")

    bp_middleware_fn, bp_middleware_args, bp_middleware_kwargs = (
        group.middleware(blueprint_middleware))

    bp_middleware_fn(bp1)
    bp_middleware_fn(bp2)


# Generated at 2022-06-12 08:37:58.409289
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = sanic.Blueprint(name='bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint(name='bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint(name='bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint(name='bp4', url_prefix='/bp4')
    bp5 = sanic.Blueprint(name='bp5', url_prefix='/bp5')
    bp6 = sanic.Blueprint(name='bp6', url_prefix='/bp6')
    bp7 = sanic.Blueprint(name='bp7', url_prefix='/bp7')
    bp8 = sanic.Blueprint(name='bp8', url_prefix='/bp8')

# Generated at 2022-06-12 08:38:08.939865
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    group = BlueprintGroup()

    assert len(group) == 0

    group.append(Blueprint('t', url_prefix='/t'))

    # Should not have an effect since the item is a Blueprint
    group.append(Group(Blueprint('t', url_prefix='/t')))
    group.append(Group(Blueprint('t', url_prefix='/t')), Blueprint('t', url_prefix='/t'))

    assert len(group) == 2

    group.append(Blueprint('t', url_prefix='/t'))
    group.append(Blueprint('t', url_prefix='/t'))

    assert len(group) == 4

    group = BlueprintGroup()

    assert len(group) == 0

    group.append(Blueprint('t', url_prefix='/t'))

# Generated at 2022-06-12 08:38:13.413429
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    item1 = Blueprint("test_bp1", url_prefix="/test_bp1")
    item2 = Blueprint("test_bp2", url_prefix="/test_bp2")
    bpg = BlueprintGroup()
    bpg.append(item1)
    bpg.append(item2)
    bpg[1] = item1
    assert bpg[1] == item1


# Generated at 2022-06-12 08:38:19.976564
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bpg = BlueprintGroup()
    bpg._blueprints = [Blueprint("blueprint1")]

    # changing value at index 0
    bpg[0] = Blueprint("blueprint2")
    assert bpg._blueprints[0].name == "blueprint2"

    # changing value at index 0
    bpg[0] = Blueprint("blueprint3")
    assert bpg._blueprints[0].name == "blueprint3"


# Generated at 2022-06-12 08:38:23.719893
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    """
    Test BlueprintGroup index selection
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg[0] == bp1
    assert bpg[1] == bp2


# Generated at 2022-06-12 08:38:33.859494
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test Blueprint Group middleware method.
    """

    # Get an instance of the sanic app
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    # Create a Blueprint entity
    bp = Blueprint("test", url_prefix="/bp")

    # Create a BlueprintGroup Entity
    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    # Append Blueprint to BlueprintGroup
    bpg.append(bp)

    # Create a mock function
    mock_fn = MagicMock(name='fn')

    # Create dummy middleware
    @bpg.middleware('request')
    def fn(request):
        mock_fn(request)

    # Create dummy request

# Generated at 2022-06-12 08:38:43.193902
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    """
    Test functionality of `BlueprintGroup.append` to add a new `Blueprint`
    object to the Blueprint Group.
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg.blueprints) == 2
    assert bpg.blueprints[0].url_prefix == "/api/bp1"
    assert bpg.blueprints[1].url_prefix == "/api/bp2"


# Generated at 2022-06-12 08:38:59.871053
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group.append(bp4)
    assert len(group.blueprints) == 4
    assert group.blueprints[0].url_prefix == "/bp1"
    assert group.blueprints[1].url_prefix == "/bp2"
    assert group.blueprints[2].url_prefix == "/bp3"

# Generated at 2022-06-12 08:39:09.662992
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    # Group of blueprints
    bp1 = Blueprint('bp', url_prefix='/bp')
    bp2 = Blueprint('bp', url_prefix='/bp')

    bp3 = Blueprint('bp', url_prefix='/bp')
    bp4 = Blueprint('bp', url_prefix='/bp')

    group = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    group1 = BlueprintGroup(bp3, bp4, url_prefix="/api1", version="v2")
    bp5 = Blueprint('bp', url_prefix='/bp5')
    group2 = BlueprintGroup(group1, bp5, url_prefix="/api2", version="v3")

    # Register Blueprint group under the app
    assert len(bp1.middlewares["request"]) == 0
   

# Generated at 2022-06-12 08:39:13.851270
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp = sanic.Blueprint("bp1")

    # insert an item inside the BlueprintGroup
    bpg = BlueprintGroup()
    bpg.append(bp)

    # check if the item was inserted
    assert len(bpg) == 1
    assert bpg[0] is bp

    # Update the item and verify the update
    bp2 = sanic.Blueprint("bp2")
    bpg[0] = bp2
    assert bpg[0] is bp2



# Generated at 2022-06-12 08:39:23.163098
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    iterator = bpg.__iter__()
    iterator_list = list(iterator)

    assert iterator_list == [bp1, bp2, bp3, bp4]


# Generated at 2022-06-12 08:39:29.878682
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Setup
    bp = Blueprint(
        'test_bp_middleware_blueprint_group', url_prefix='')
    bp.middleware('request', lambda r: r)

    # bp1 = Blueprint('test_bp_middleware_blueprint_group_bp_1', url_prefix='/')
    # bp2 = Blueprint('test_bp_middleware_blueprint_group_bp_2', url_prefix='/')

    bpg = BlueprintGroup(bp)

    # Execute

    # Verify
    assert len(bp.middlewares['request']) == 1

    # Cleanup - none necessary



# Generated at 2022-06-12 08:39:38.273341
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    """
    Testcase for Blueprint Group class
    """
    # Usage Example for blueprint group
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api/v1")
    bpg2 = BlueprintGroup(bp1, bp2, url_prefix="/api/v2")

    assert len(bpg) == 2
    assert len(bpg2) == 2

    assert bpg[0] is bp3
    assert bpg[1] is bp4

    assert bpg2[0] is bp

# Generated at 2022-06-12 08:39:44.356625
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    """
    Unit test to check if the method `__len__` of class BlueprintGroup works
    as expected.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    len_bpg = len(bpg)

    assert len_bpg == 2



# Generated at 2022-06-12 08:39:49.351635
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    bpg.insert(0, bp1)
    bpg.insert(1, bp2)
    assert bp1 == bpg[0]
    assert bp2 == bpg[1]


# Generated at 2022-06-12 08:39:58.570783
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Testing BlueprintGroup.middleware method.
    """

    _MIDDLEWARE = "middleware"
    _BLUEPRINT = "blueprint"
    _REQUEST = "request"
    _RESPONSE = "response"

    class Request:
        """
        Request object.
        """

        pass

    class Response:
        """
        Response object.
        """

        pass

    class Blueprint:
        """
        Blueprint object.
        """

        def __init__(self):
            self.middleware_request = None
            self.middleware_response = None
            self.middleware_exception = None

        def middleware(self, fn, *args, **kwargs):
            """
            Update the middleware_* field.
            """


# Generated at 2022-06-12 08:39:59.451284
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    assert False



# Generated at 2022-06-12 08:40:25.653337
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint('module1'))
    blueprint_group.append(sanic.Blueprint('module2'))
    blueprint_group.append(sanic.Blueprint('module3'))
    len_blueprint_group = len(blueprint_group)
    assert len_blueprint_group == 3


# Generated at 2022-06-12 08:40:35.164366
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:40:44.708613
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class BP1(mock.MagicMock):
        pass

    class BP2(mock.MagicMock):
        pass

    class BP3(mock.MagicMock):
        pass

    class BP4(mock.MagicMock):
        pass

    bp1 = BP1()
    bp2 = BP2()
    bp3 = BP3()
    bp4 = BP4()

    def dummy_func():
        pass

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    bp1.middleware.assert_not_called()
    bp2.middleware.assert_not_called()

    apply_middleware = bp_group.middleware
    apply_middleware(dummy_func)

# Generated at 2022-06-12 08:40:50.734025
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    # Define a Blueprint object for test purpose
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    # This would be a valid scenario when the user calls like below
    del bpg[0]
    bpg.extend([bp1, bp2])
    del bpg[0]
    assert len(bpg) == 1
    assert bpg[0] == bp2



# Generated at 2022-06-12 08:40:54.633555
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    assert len(bpg) == 2

# Generated at 2022-06-12 08:40:55.498820
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    pass



# Generated at 2022-06-12 08:41:00.904636
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2, bp3]

    del bpg[1]
    assert bpg._blueprints == [bp1, bp3]
