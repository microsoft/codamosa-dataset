

# Generated at 2022-06-12 08:31:11.219904
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint("bp1", url_prefix="/bp1", strict_slashes=False)
    blueprint2 = Blueprint(
        "bp2", url_prefix="/bp2", version="v1", strict_slashes=True
    )
    group = BlueprintGroup(blueprint, blueprint2, url_prefix="/api")

    @group.middleware('request')
    async def group_middleware(request):
        pass

    assert len(blueprint.middlewares["request"]) == 1
    assert len(blueprint2.middlewares["request"]) == 1

# Generated at 2022-06-12 08:31:20.291341
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup()

    # mock blueprint objects
    bp = Blueprint('bp')
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    bpg.append(bp)
    bpg.append(bp1)
    bpg.append(bp2)
    bp.middleware = MagicMock()
    bp1.middleware = MagicMock()
    bp2.middleware = MagicMock()

    @bpg.middleware('request')
    async def bp_middleware(request):
        pass

    assert bp.middleware.call_count == 1
    assert bp1.middleware.call_count == 1
    assert bp2.middleware.call_count == 1

# Generated at 2022-06-12 08:31:28.206176
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test for method middleware of class BlueprintGroup
    """
    app = sanic.Sanic()
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg2 = BlueprintGroup(url_prefix="/api2", version="v2")
    bpg2.append(bp1)
    bpg2.append(bp2)
    bpg2.append(bp3)
    b

# Generated at 2022-06-12 08:31:40.485965
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # pylint: disable=protected-access
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2]

    @bpg.middleware('request')
    async def bpg_middleware1(request):
        request['bpg_middleware1'] = 'bpg_middleware1'

    @bpg.middleware('request')
    async def bpg_middleware2(request):
        request['bpg_middleware2'] = 'bpg_middleware2'

    @bp1.middleware('request')
    async def bp1_middleware(request):
        request['bp1_middleware'] = 'bp1_middleware'


# Generated at 2022-06-12 08:31:50.483663
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class app(sanic.Sanic):
        blueprint_groups: List[BlueprintGroup] = []

        def blueprint(self, bp: "BlueprintGroup") -> "BlueprintGroup":
            self.blueprint_groups.append(bp)
            return bp

        async def _internal_handler(self, request, callback, **parameters):
            pass

    # Instantiate the Blueprint
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    # Instantiate the Blueprint group
    group = BlueprintGroup(url_prefix="/api", version="v1")

    # Add the Blueprint to the Blueprint Group
    group.append(bp1)
    group.append(bp2)

    # Create the Test Application

# Generated at 2022-06-12 08:31:58.810122
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("BlueprintGroup-middleware")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:32:06.110735
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('test', url_prefix='/test')
    bp.add_route(lambda r: 'Ok', '/')
    bpg = BlueprintGroup(bp, url_prefix='/api')
    app = sanic.Sanic()

    @bpg.middleware
    def test_middleware(request):
        return text('Middleware')

    app.blueprint(bpg)
    request, response = app.test_client.get('/api/test')
    assert response.text == 'Middleware'

# Generated at 2022-06-12 08:32:09.932391
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('test', url_prefix='/test')

    bg = BlueprintGroup()
    bg.append(bp)

    @bg.middleware
    async def test_middleware(request):
        request['test'] = True

    assert len(bp.middlewares['request']) == 1
    assert bp.middlewares['request'][0].__name__ == 'test_middleware'



# Generated at 2022-06-12 08:32:16.316698
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """Unit test for method middleware of class BlueprintGroup."""
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    # test: middleware
    def test_middleware_func(*args, **kwargs):
        pass
    bpg.middleware(test_middleware_func)
    assert len(bp1.middlewares['request']) == 1
    assert len(bp1.middlewares['response']) == 0
    assert len(bp2.middlewares['request'])

# Generated at 2022-06-12 08:32:23.432488
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    
    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        """
        This is a middleware for bpg
        """
        print('applied on BlueprintGroup : bpg Only')
    
    assert bp3 == bpg.blueprints[0]
    assert bp4 == bpg.blueprints[1]
    assert bpg.blueprints[0].middleware_stack == [{'args': (), 'kwargs': {}, 'func': bpg_only_middleware, 'event': 'request'}]

# Generated at 2022-06-12 08:32:31.869034
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    import unittest
    import unittest.mock

    class TestBlueprintGroupMiddleware(unittest.TestCase):
        def test_blueprint_middleware_no_args(self):
            bp1 = Blueprint("bp1")
            bp2 = Blueprint("bp2")
            bp3 = Blueprint("bp3")

            bp_group = BlueprintGroup()
            bp_group.append(bp1)
            bp_group.append(bp2)
            bp_group.append(bp3)

            @bp_group.middleware
            async def bp_middleware(*args, **kwargs):
                pass

            for bp in bp_group:
                self.assertIn(bp_middleware, bp._middleware["request"])


# Generated at 2022-06-12 08:32:42.759740
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg1 = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bpg1, bp3, url_prefix="/api", version="v2")

    @bpg2.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for all blueprints of group bpg2')

    assert len(bp1.middlewares) == 1
    assert len(bp2.middlewares) == 1
    assert len(bp3.middlewares) == 1


# Unit test

# Generated at 2022-06-12 08:32:53.462764
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp = Blueprint('test', url_prefix='/test')

    @bp.route('/', methods=['GET', 'POST'])
    async def bp_route_handler(request):
        return text('OK')

    @bp.middleware('request')
    async def bp_middleware_handler(request):
        request['middleware'] = 'OK'


    # Register Blueprint at route '/test/'
    app.blueprint(bp)

    # Register Blueprint Group at route '/'
    bpg = BlueprintGroup(bp)
    app.blueprint(bpg)

    request, response = app.test_client.get('/test/')
    assert response.status == 200
    assert response.text == 'OK'

    request, response

# Generated at 2022-06-12 08:33:04.452774
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class MiddlewareClass:
        def __init__(self):
            self.middleware_calls = []

        async def __call__(self, request):
            self.middleware_calls.append(request)

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup(bp1, bp2)

    middleware = MiddlewareClass()

    @bpg.middleware('request')
    async def test_middleware_function(request):
        middleware.middleware_calls.append(request)

    @bp1.route('/bp1')
    async def test_bp1_route(request):
        return text('bp1')

    @bp2.route('/bp2')
    async def test_bp2_route(request):
        return text

# Generated at 2022-06-12 08:33:14.249343
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    # Check that @middleware decorator can be used without arguments
    @bp1.middleware('request')
    async def bp1_middleware(request):
        pass

    bpgroup = BlueprintGroup()
    bpgroup.append(bp1)
    bpgroup.append(bp2)

    # Check that @middleware decorator can be used without arguments
    @bpgroup.middleware('request')
    async def group_middleware(request):
        pass



# Generated at 2022-06-12 08:33:25.929089
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def test_middleware(request):
        print('applied on Blueprint : bp1 Only')
        return "middleware pass"

    app = sanic.Sanic()

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
        return "middleware pass"


# Generated at 2022-06-12 08:33:37.992851
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp1, bpg, url_prefix="/api", version="v1")
    # Testing for blueprint group
    bpg.middleware(lambda req: req)
    bpg.middleware(lambda req: req, 'request')
    bpg.middleware(lambda req: req, 'response')
    bpg

# Generated at 2022-06-12 08:33:44.238004
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp = Blueprint('test', url_prefix='/test')

    bpg = BlueprintGroup()
    bpg.append(bp)

    @bpg.middleware
    async def test(request):
        pass

    @bp.middleware('request')
    async def test2(request):
        pass

    app.blueprint(bpg)

    assert len(app.request_middleware) == 2

# Generated at 2022-06-12 08:33:51.344686
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)
    group.middleware(bp1_only_middleware)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/')
    async def bp2_route(request):
        return text('bp2')

    # Register Blueprint group under the app
    app.blueprint(group)


# Generated at 2022-06-12 08:34:01.242278
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp4 = Blueprint("bp4")

    bp_group = BlueprintGroup("/test_bp")

    bp_group.append(bp1)
    bp_group.append(bp2)
    bp_group.append(bp3)
    bp_group.append(bp4)

    @bp_group.middleware("request")
    def my_middleware(request):
        request["data"] = "done"

    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"])

# Generated at 2022-06-12 08:34:11.838531
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)



# Generated at 2022-06-12 08:34:20.638451
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg._blueprints = [bp1, bp2, bp3, bp4]
    mware_count = [0, 0, 0, 0]

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return

# Generated at 2022-06-12 08:34:29.680588
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    def middleware_func_target(request):
        request["middleware_on_blueprint_group"] = True

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bp_group = BlueprintGroup()
    bp_group.append(bp1)
    bp_group.append(bp2)

    bp_group.middleware(middleware_func_target)
    assert middleware_func_target in bp1.middlewares()
    assert middleware_func_target in bp2.middlewares()


# Generated at 2022-06-12 08:34:37.834392
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware("request")
    async def common_middleware(request):
        pass

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        pass

    @bp2.middleware("request")
    async def bp2_only_middleware(request):
        pass

    middlewares = [m for m in bp1.middlewares["request"]]
    assert len(middlewares) == 2
    assert len(bp2.middlewares["request"]) == 2
    assert common_

# Generated at 2022-06-12 08:34:49.363572
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp = Blueprint("bp")
    group = BlueprintGroup()
    group.append(bp)

    @bp.route("/")
    async def bp_handler(request):
        return text("OK")

    @bp.route("/<id>")
    async def bp_handler_id(request, id):
        return text("OK")

    @group.middleware("request")
    async def bp_middleware_1(request):
        pass

    @group.middleware("request")
    async def bp_middleware_2(request):
        pass

    @group.middleware("response")
    async def bp_middleware_3(request, response):
        pass

    app.blueprint(group)

    request,

# Generated at 2022-06-12 08:34:57.149235
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert len(bp1.middlewares['request']) == 0
    assert len(bp2.middlewares['request']) == 0

    @group.middleware('request')
    def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    assert len(bp1.middlewares['request']) == 1
    assert len(bp2.middlewares['request']) == 1


# Generated at 2022-06-12 08:35:06.150878
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:09.854006
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class BlueprintMock:
        def middleware(self, fn, *args, **kwargs):
            pass

    blueprint = BlueprintMock()
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)
    blueprint_group.middleware(lambda: None)

# Generated at 2022-06-12 08:35:20.329557
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('blueprintGroupMiddleware')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # Create a BlueprintGroup
    bpg = BlueprintGroup()

    # Register bp1 and bp2 under the BlueprintGroup
    bpg.append(bp1)
    bpg.append(bp2)

    # Register a middleware using the BlueprintGroup instance
    @bpg.middleware
    async def middleware(request):
        print('common middleware applied for both bp1 and bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:27.266750
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test case for the method middleware of the class BlueprintGroup
    """
    app = sanic.Sanic()
    bp = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(bp)

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        assert True == True

    @bp.route('/')
    async def bp1_route(request):
        return text('bp1')

    # Register Blueprint group under the app
    app.blueprint(bpg)
    client = app.test_client
    request, response = client.get('/bp1/')
    assert response.text == 'bp1'

# Generated at 2022-06-12 08:35:41.135554
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    bp1 = Blueprint("bp1")

    @bp1.middleware("request")
    def before_request(request):
        pass

    @bp1.middleware("response")
    def after_request(request, response):
        pass

    @bp1.middleware("exception")
    async def exception_middleware(request, exception):
        pass

    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")
    bp1g = BlueprintGroup(bp2, bp3)

    @bp1g.middleware("request")
    def before_request_group(request):
        pass

    @bp1g.middleware("response")
    def after_request_group(request, response):
        pass



# Generated at 2022-06-12 08:35:46.007594
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp1', url_prefix='/bp1')
    bg = BlueprintGroup(url_prefix='/bp2')
    bg.append(bp)

    @bp.middleware('request')
    @bg.middleware('request')
    async def test_bp_middleware(request):
        pass

    assert len(bp.middlewares['request']) == 1
    assert len(bg.middlewares['request']) == 1

# Generated at 2022-06-12 08:35:55.599626
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class A(sanic.Sanic):
        middleware_a = []

        async def handle_request(self, request, handler):
            self.middleware_a.append("a")
            return await handler(request)

    class B(sanic.Sanic):
        middleware_b = []

        async def handle_request(self, request, handler):
            self.middleware_b.append("b")
            return await handler(request)

    async def foo(request):
        return text("foo")

    async def bar(request):
        return text("bar")

    async def middleware_a(request):
        return text("middleware_a")

    async def middleware_b(request):
        return text("middleware_b")

    bp1 = Blueprint("bp1")
    bp1.add_route

# Generated at 2022-06-12 08:36:06.247759
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    class Middleware:
        def __init__(self, app, args):
            self.app = app

    class Blueprint(sanic.Blueprint):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._middleware = []

        def middleware(self, fn, *args, **kwargs):
            self._middleware.append((fn, args, kwargs))

    class App:
        def blueprint(self, bp):
            pass

    app = App()
    blueprint1 = Blueprint("bp1")
    blueprint2 = Blueprint("bp2")

    blueprintGroup = BlueprintGroup()
    blueprintGroup.append(blueprint1)
    blueprintGroup.append(blueprint2)


# Generated at 2022-06-12 08:36:15.146446
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Blueprint group middleware applied to a single blueprint
    """
    # preparing test data
    bp = Blueprint("bp1", url_prefix="bp1")
    app = sanic.Sanic("BP-Test")
    app.blueprint(bp)

    # testing function
    @bp.middleware("request")
    async def bp_only_middleware(request):
        print("applied on Blueprint : bp Only")

    @bp.route("/")
    async def bp_route(request):
        return text("bp1")

    # run test
    request, response = app.test_client.get("/bp1/")
    assert response.status == 200
    assert response.text == "bp1"



# Generated at 2022-06-12 08:36:23.437325
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert bp1.request_middleware is not None
    assert bp2.request_middleware is not None

    assert len(bp1.request_middleware) == 1
    assert len(bp2.request_middleware) == 1


# Generated at 2022-06-12 08:36:35.486274
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.server import HttpProtocol

    def handle(self, request):
        pass

    def middleware_fn(request):
        pass

    protocol: HttpProtocol = HttpProtocol(None)
    bp1 = BlueprintGroup(url_prefix="/bp1")
    bp2 = BlueprintGroup(url_prefix="/bp2")

    bp1.append(Blueprint("bp1"))
    bp2.append(Blueprint("bp2"))

    for bp_item in bp1.blueprints + bp2.blueprints:
        bp_item._register_middleware(middleware_fn, "request")
        protocol._register_blueprint_for_handler(
            handle, bp_item, [], bp_item.version, bp_item.strict_slashes
        )



# Generated at 2022-06-12 08:36:46.043302
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test method middleware for class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)

    @group.middleware('request')
    def group_middleware(request):
        pass

    # Register Blueprint group under the app
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    app.blueprint

# Generated at 2022-06-12 08:36:57.161744
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic import Sanic

    async def handler(request):
        return response.text('OK')

    app = Sanic('test_BlueprintGroup_middleware')

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)


# Generated at 2022-06-12 08:37:07.626789
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(BlueprintGroup(bp3, bp4, version="v2"))

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert False
        print('1 appied on Blueprint : bp1 Only')
