

# Generated at 2022-06-12 08:31:12.793426
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')
    bp7 = Blueprint('bp7', url_prefix='/bp7')
    bp8 = Blueprint('bp8', url_prefix='/bp8')
    bp9 = Blueprint('bp9', url_prefix='/bp9')
    bp10 = Blueprint('bp10', url_prefix='/bp10')

# Generated at 2022-06-12 08:31:22.819851
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestBlueprintGroup(BlueprintGroup):
        pass

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    test_bp_group = TestBlueprintGroup()
    test_bp_group.append(bp1)
    test_bp_group.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:31:32.166420
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Test BlueprintGroup class method middleware to ensure that
    the middleware is applied to all of the Blueprint in the
    Blueprint Group.
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    middleware_registry = set()

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        middleware_registry.add('bp1_only_middleware')
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')



# Generated at 2022-06-12 08:31:45.369077
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    group = BlueprintGroup(bp1, bp2)

    @bp1.middleware("request", "bp1_only")
    async def bp1_middleware(request):
        print("applied on Blueprint : bp1 Only")

    @bp2.middleware("request", "bp2_only")
    async def bp2_middleware(request):
        print("applied on Blueprint : bp2 Only")

    @group.middleware("request", "bp_common")
    async def bp_middleware(request):
        pass

    # Check blueprint middleware
    assert len(bp1.middlewares["request"]) == 2

# Generated at 2022-06-12 08:31:57.288121
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    Blueprint = sanic.Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup('/api', version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        print('bp1')


# Generated at 2022-06-12 08:32:08.135492
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    bp1_middleware_1_calls = []
    bp2_middleware_1_calls = []
    bp3_middleware_1_calls = []

    bp1_middleware_2_calls = []
    bp2_middleware_2_calls = []
    bp3_middleware_2_calls

# Generated at 2022-06-12 08:32:17.040452
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.blueprints.Blueprint.group(url_prefix='/group')
    class TestClass:
        pass

    @TestClass.middleware('request')
    def test_middleware(request):
        assert request is not None

    test_blueprint = TestClass()
    test_blueprint.middleware(lambda request: True)
    assert len(test_blueprint.middlewares['request']) == 2

    sanic.blueprints.Blueprint.group(test_blueprint)
    assert len(test_blueprint.middlewares['request']) == 2

# Generated at 2022-06-12 08:32:26.997880
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")
    blueprints = BlueprintGroup(url_prefix='')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @blueprints.middleware('request')
    async def group_middleware(request):
        print

# Generated at 2022-06-12 08:32:34.129338
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.blueprints import BlueprintGroup
    from sanic.blueprints import Blueprint

    # create Blueprint and BlueprintGroup
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # register Sanic instance
    app = Sanic()

    # register Blueprint and BlueprintGroup
    app.blueprint(bpg)

    # create sample routes
    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-12 08:32:44.651440
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:32:52.567969
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('test_bp')

    bp.middleware(middleware_middleware_test)

    bpg = BlueprintGroup()
    bpg.append(bp)

    @bpg.middleware('request')
    async def middleware_test(request):
        pass

    assert middleware_test in bp.request_middleware



# Generated at 2022-06-12 08:32:57.457834
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint('bp1', url_prefix='/bp1')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    @blueprint.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @blueprint_group.middleware('request')
    async def group_middleware(request):
        pass



# Generated at 2022-06-12 08:33:07.421150
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    # add middleware without any parameters
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    @bpg.middleware
    def bp_middleware(request):
        return text("bp1 & bp2")
    bps = bpg.blueprints
    for bp in bps:
        assert bp.middlewares['request'][-1][0] == bp_middleware
        assert bp.middlewares['request'][-1][1] == ()
        assert bp.middlewares['request'][-1][2] == {}

    # add middleware with parameters

# Generated at 2022-06-12 08:33:17.302701
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    
    def verify_bp1_middleware_registered(middleware_name='bp1_only_middleware'):
        assert(middleware_name in bp1.middlewares['request'])
    
    def verify_bp2_middleware_registered(middleware_name='bp2_only_middleware'):
        assert(middleware_name in bp2.middlewares['request'])
    
    # Tests when function and middleware_name are passed
    def bp1_only_middleware():
        pass


# Generated at 2022-06-12 08:33:21.930978
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint

    blueprint_one = Blueprint("blueprint_one")

    blueprint_two = Blueprint("blueprint_two")

    blueprint_group = BlueprintGroup()

    blueprint_group.append(blueprint_one)
    blueprint_group.append(blueprint_two)

    @blueprint_group.middleware()
    def middleware_one(request):
        pass

    assert len(blueprint_one.middlewares) == 1
    assert len(blueprint_two.middlewares) == 1
    assert blueprint_one.middlewares[0].__name__ == 'middleware_one'
    assert blueprint_two.middlewares[0].__name__ == 'middleware_one'

    @blueprint_group.middleware('request')
    def middleware_two(request):
        pass



# Generated at 2022-06-12 08:33:30.171064
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Test 1: Test Blueprint Group middleware
    # ---------------------------------------------------------------------------#
    app = sanic.Sanic("TestBlueprintGroupMiddlewareApp")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    @bp1.route("/")
    def bp1_route_handler(request):
        return text("bp1")

    @bp2.route("/")
    def bp2_route_handler(request):
        return text("bp2")

    @bp1.middleware("request")
    async def bp1_only_middleware(request):
        print("applied on Blueprint : bp1 Only")

    group = BlueprintGroup("/group")
    group.append(bp1)

# Generated at 2022-06-12 08:33:42.264911
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint('bp')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp.middleware('request')
    async def bp_only_middleware(request):
        print('applied on Blueprint : bp Only')

    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    assert len(bp1.middlewares['request']) == 1
    assert len

# Generated at 2022-06-12 08:33:46.465833
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpg = BlueprintGroup()

    async def async_handler1(*args, **kwargs):
        pass

    async def async_handler2(*args, **kwargs):
        pass

    bpg.append(sanic.Blueprint("bp1"))
    bpg.append(sanic.Blueprint("bp2"))

    bpg.middleware(async_handler1, "request")

    result1 = bpg[0].middlewares['request'][-1]
    result2 = bpg[1].middlewares['request'][-1]

    assert result1 == result2
    assert result1 == async_handler1

    bpg.middleware(async_handler2)("request")

    result1 = bpg[0].middlewares['request'][-1]
    result2 = bpg[1].middlew

# Generated at 2022-06-12 08:33:53.846660
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp = Blueprint("test_bp")
    bp2 = Blueprint("test_bp_2")

    @bp.middleware("request")
    def my_middleware(request):
        print("middleware applied")

    bpg = BlueprintGroup(bp, bp2)

    @bpg.middleware("request")
    def my_group_middleware(request):
        print("group middleware applied")

    assert bp.middleware("request") == [my_middleware]
    assert bp2.middleware("request") == [my_group_middleware]


# Generated at 2022-06-12 08:34:01.261593
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')

    test_bp = BlueprintGroup('test_bp', url_prefix='/test_bp')

    @test_bp.middleware('request')
    async def response_middleware(request):
        pass

    assert len(test_bp.blueprints) == 0

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = BlueprintGroup('bpg1', url_prefix='/bpg1')

    bp5.append(bp3)

# Generated at 2022-06-12 08:34:12.455620
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Given
    app = sanic.Sanic("test")
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    @bp3.route('/')
    async def bp3_route(request):
        return text('bp3')


# Generated at 2022-06-12 08:34:21.643281
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    def test_middleware(request):
        pass

    bg = BlueprintGroup()

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bg.append(bp1)
    bg.append(bp2)

    assert bg is not None
    assert bp1 is not None
    assert bp2 is not None

    assert len(bg.blueprints) == 2
    assert type(bp1) == Blueprint
    assert type(bp2) == Blueprint

    bg.middleware(test_middleware)

    for _bp in bg.blueprints:
        assert len(_bp.middlewares) == 1

    bg.middleware(test_middleware, 'request')

    for _bp in bg.blueprints:
        assert len(_bp.middlewares) == 2

# Generated at 2022-06-12 08:34:32.251216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp = Blueprint('test', url_prefix='/test')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('response')
    bp.middleware('request')
    bp.middleware('request')
    bp.middleware('request')
    bp.middleware('request')
    bp.middleware('request')
    bp.middleware('request')
    bp.middleware('request')
    bp

# Generated at 2022-06-12 08:34:39.995203
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')

    # Register the spy middleware to each of the Blueprints
    @bp1.middleware('request')
    async def bp1_request_spy_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_request_spy_middleware(request):
        print('applied on Blueprint : bp2 Only')


# Generated at 2022-06-12 08:34:51.803109
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class TestApp(sanic.Sanic):
        """
        We will create a new class to make it simple to create the
        Blueprint object. This will make the testing simple
        """

        def register_blueprint(self, bp, *args, **kwargs):
            """
            Override the default implementation of Sanic App to
            redirect the call to the Blueprint register method.
            """
            bp.register(self, *args, **kwargs)
            return bp

    app = TestApp()
    bp1 = Blueprint("bp1", url_prefix='/bp1')
    bp2 = Blueprint("bp2", url_prefix='/bp2')
    bp3 = Blueprint("bp3", url_prefix='/bp3')
    bp4 = Blueprint("bp4", url_prefix='/bp4')
    group

# Generated at 2022-06-12 08:35:01.084144
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1,bp2)

    @group.middleware('request')
    async def group_middleware(request):
        pass

    assert group._blueprints[0].middleware_stack['request'][-1]() == group_middleware()
    assert group._blueprints[1].middleware_stack['request'][-1]() == group_middleware()


# Generated at 2022-06-12 08:35:11.015903
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic('test_BlueprintGroup_middleware', log_config=None)
    app.config.from_pyfile = MagicMock(return_value=True)
    # Need a new version of sanic to support this
    # https://github.com/huge-success/sanic/pull/1299
    # app.blueprint = MagicMock(return_value=True)
    app.error_handler = MagicMock(return_value=True)
    app.listener = MagicMock(return_value=True)
    app.register_listener = MagicMock(return_value=True)
    app.router.add_route = MagicMock(return_value=True)
    app.router.add_static = MagicMock(return_value=True)
    bp1 = Blueprint

# Generated at 2022-06-12 08:35:20.820602
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    bp = Blueprint('bp')
    bpg = BlueprintGroup('/bpg')
    bpg.append(bp)

    @bp.middleware('request')
    async def bp_middleware(request):
        return 'bp'

    @bpg.middleware('request')
    async def bpg_middleware(request):
        return 'bpg'

    @bpg.middleware('request')
    async def bpg_middleware1(request):
        return 'bpg1'

    assert bp.middlewares['request'][0].__name__ == bpg_middleware.__name__
    assert bp.middlewares['request'][1].__name__ == bpg_middleware1.__name__

# Generated at 2022-06-12 08:35:21.622180
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
  BlueprintGroup.middleware


# Generated at 2022-06-12 08:35:26.831841
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware('request')
    async def bpg_only_middleware(request):
        print('applied on Blueprint : bpg Only')

    assert len(bp1.request_middleware) == 1
    assert len(bp2.request_middleware) == 1



# Generated at 2022-06-12 08:35:40.194865
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2
    assert bpg[0].name == 'bp1'
    assert bpg[1].name == 'bp2'

    del bpg[0]

    assert len(bpg) == 1
    assert bpg[0].name == 'bp2'


# Generated at 2022-06-12 08:35:48.140466
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    '''
    This method will unit test the middleware method of class BlueprintGroup
    '''

    from sanic.testing import SanicTestClient

    bp1 = Blueprint('bp1', url_prefix='/bp1')

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    app = Sanic('test_BlueprintGroup_middleware')

    @app.listener('before_server_start')
    async def setup_test(app, loop):
        # pylint: disable=unused-argument
        app.blueprint(bp1)


# Generated at 2022-06-12 08:35:57.232613
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # Create a new Blueprint Object
    bp1 = Blueprint(url_prefix='bp1')
    # Assign a function to the 'url_prefix' property
    bp1.url_prefix = 'bp1'
    # Create a new Blueprint Object
    bp2 = Blueprint(url_prefix='bp2')
    # Assign a function to the 'url_prefix' property
    bp2.url_prefix = 'bp2'
    # Create a new Blueprint Object
    bp3 = Blueprint(url_prefix='bp3')
    # Assign a function to the 'url_prefix' property
    bp3.url_prefix = 'bp3'
    # Create a new Blueprint Object
    bp4 = Blueprint(url_prefix='bp4')
    # Assign a function to the 'url_prefix' property

# Generated at 2022-06-12 08:36:02.591155
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bp3 = Blueprint('bp3')
    bp4 = Blueprint('bp4')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    bpg.insert(1, bp3)
    assert bpg[1] == bp3
    bpg.insert(1, bp4)
    assert bpg[2] == bp3
    assert bpg[1] == bp4

# Generated at 2022-06-12 08:36:07.256889
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    # Create a blueprint group without url_prefix nor version
    blueprint_group = BlueprintGroup()

    # Append a blueprint to blueprint group
    blueprint = Blueprint("a")
    blueprint_group.append(blueprint)

    # Retrieve blueprint from blueprint_group
    assert blueprint_group[0] == blueprint

    # Retrieve blueprints
    assert list(blueprint_group) == [blueprint]

    # Retrieve blueprints
    assert len(blueprint_group) == 1



# Generated at 2022-06-12 08:36:16.323931
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:36:21.455337
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup('bpg', url_prefix="/bpg")


# Generated at 2022-06-12 08:36:26.074954
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    app = sanic.Sanic()
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg.blueprints == [bp1, bp2]


# Generated at 2022-06-12 08:36:35.369692
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    test_blueprint_group = BlueprintGroup()
    test_blueprint_group.append(Blueprint('bp1', url_prefix='/bp1'))
    test_blueprint_group.insert(0, Blueprint('bp2', url_prefix='/bp2'))
    assert test_blueprint_group[0].name == 'bp2'
    assert test_blueprint_group[0].url_prefix == '/bp2'
    assert test_blueprint_group[1].name == 'bp1'
    assert test_blueprint_group[1].url_prefix == '/bp1'


# Generated at 2022-06-12 08:36:43.796970
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.insert(0, bp3)
    assert bpg[0] == bp3
    assert len(bpg) == 2

    bp1.insert(0, bp2)
    assert len(bp1) == 2

# Generated at 2022-06-12 08:37:00.781251
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    # Check the item at index 0 and check the prefix
    assert bpg[0].url_prefix == '/api/bp4'
    assert bpg[0].name == 'bp3'
    assert bpg[0].version == 'v1'

    # Check the item at index 0 and check the prefix
    assert bpg[1].url_prefix == '/api/bp4'

# Generated at 2022-06-12 08:37:10.031177
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:37:19.209438
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    assert isinstance(bpg, BlueprintGroup) is True
    assert isinstance(bpg, MutableSequence) is True
    bpg.append(bp1)
    bpg.append(bp2)

    assert len(bpg) == 2

    assert bpg[0] is bp1
    assert bpg[1] is bp2

    del bpg[0]
    assert bpg[0] is bp2

    bpg[0] = bp1
    assert bpg[0] is bp1

    bpg.insert(0, bp2)
    assert bpg[0] is bp2
   

# Generated at 2022-06-12 08:37:25.403424
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    # Constructor
    bpg = BlueprintGroup(url_prefix='/test', version='v1', strict_slashes='true')

    # get URL Prefix
    assert bpg.url_prefix == '/test'

    # get Version
    assert bpg.version == 'v1'

    # get strict slash behavior
    assert bpg.strict_slashes == 'true'


# Generated at 2022-06-12 08:37:32.220980
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    assert next(iter(group)) == bp1
    assert next(iter(group)) == bp2
    assert len(list(iter(group))) == 0


# Generated at 2022-06-12 08:37:37.547511
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = BlueprintGroup()
    assert len(group) == 0

    group.append(bp1)
    assert len(group) == 1

    group.insert(0, bp2)
    assert len(group) == 2



# Generated at 2022-06-12 08:37:47.345928
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Blueprint for testing
    blue_print = Blueprint('blue_print')
    blue_print._middlewares = {'request': []}

    # BlueprintGroup for testing
    grp_blueprint = BlueprintGroup()
    grp_blueprint._blueprints = []
    grp_blueprint._blueprints.append(blue_print)

    # Custom middleware
    async def is_blue_print(request):
        ''' Just a dummy middleware to test '''

    grp_blueprint.middleware(is_blue_print)(is_blue_print)
    assert (blue_print._middlewares['request'][0] == is_blue_print)

# Generated at 2022-06-12 08:37:53.209264
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    from sanic.blueprints import Blueprint

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    group = Blueprint.group(bp1, bp2)

    assert len(group) == 2



# Generated at 2022-06-12 08:38:00.696691
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    # test cases
    # 1 - append a blueprint /b
    # 2 - append a blueprintgroup /bg -> /bg/b1, /bg/b2
    # 3 - append a blueprintgroup /bg -> /bg/b1, /bg/bg2/b2, /bg/bg2/b3
    # 4 - append a blueprint /b then a blueprintgroup /bg -> /b, /bg/b1,
    #     /bg/b2

    # Blueprint Group
    bg = BlueprintGroup()

    # Blueprint
    b = Blueprint('b')
    b.url_prefix = ''
    bg.append(b)
    assert bg.url_prefix is None
    assert bg.version is None
    assert bg.strict_slashes is None
    assert b.url_prefix == ''
    assert b.get

# Generated at 2022-06-12 08:38:03.493198
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic.blueprints import Blueprint
    bpg = BlueprintGroup("/bp", version="v1")
    bp1 = Blueprint("b1")
    bp1.route("/")(lambda r: None)
    bpg.append(bp1)
    assert bpg.blueprints[0].url_prefix == "/bp/b1"
    assert bpg.blueprints[0].version == "v1"
    assert bpg.blueprints[0].strict_slashes == None


# Generated at 2022-06-12 08:38:30.754017
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)
    assert bpg[0] == bp1
    assert bpg[1] == bp2
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg[0] = bp3
    bpg[1] = bp4
    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-12 08:38:39.461295
# Unit test for method append of class BlueprintGroup
def test_BlueprintGroup_append():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp3
    assert bpg[1] == bp4


# Generated at 2022-06-12 08:38:43.238866
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    bpg = BlueprintGroup()

    bpg.append(Blueprint('bp1', url_prefix='/bp1'))
    bpg.append(Blueprint('bp2', url_prefix='/bp2'))

    assert len(bpg) == 2


# Generated at 2022-06-12 08:38:45.186266
# Unit test for constructor of class BlueprintGroup
def test_BlueprintGroup():
    from sanic.blueprints import BlueprintGroup
    assert BlueprintGroup()

# Generated at 2022-06-12 08:38:51.859698
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.append(sanic.Blueprint('bp1', url_prefix='/bp1'))
    blueprint_group.append(sanic.Blueprint('bp2', url_prefix='/bp2'))
    @blueprint_group.middleware('request')
    async def foo(request):
        pass
    assert blueprint_group.blueprints[0].middlewares['request'][-1] == foo
    assert blueprint_group.blueprints[1].middlewares['request'][-1] == foo

# Generated at 2022-06-12 08:38:58.181354
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    bpg = BlueprintGroup()
    bpg._blueprints = [bp1, bp2, bp3, bp4]
    assert len(bpg) == 4
    assert bp1 in bpg
    bpg.__delitem__(1)
    assert len(bpg) == 3
    assert bp2 not in bpg


# Generated at 2022-06-12 08:39:03.827574
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bpg = BlueprintGroup(url_prefix='/api/v1')
    bp = Blueprint('user', url_prefix='/user')
    bpg.append(bp)
    # Check if this method will return the blueprint object
    assert isinstance(bpg[0], Blueprint)
    # Now check if a item is not present in the list
    with pytest.raises(IndexError):
        bpg[1]


# Generated at 2022-06-12 08:39:09.981156
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    assert len(bpg) == 0

    bpg.append(bp3)
    bpg.append(bp4)

    assert len(bpg) == 2

    del bpg[0]

    assert len(bpg) == 1


# Generated at 2022-06-12 08:39:10.789979
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    BlueprintGroup()


# Generated at 2022-06-12 08:39:14.809916
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup()
    bpg[0] = bp1
    assert bpg.blueprints[0] == bp1
    assert bpg[0] == bp1


# Generated at 2022-06-12 08:39:55.137868
# Unit test for method __delitem__ of class BlueprintGroup
def test_BlueprintGroup___delitem__():
    bp = Blueprint('bp')
    bp2 = Blueprint('bp2')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.append(bp2)
    del bpg[1]
    assert len(bpg._blueprints) == 1
    assert bpg._blueprints[0] == bp


# Generated at 2022-06-12 08:40:03.531792
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:40:10.995027
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    group = BlueprintGroup()
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)
    group[1] = bp4
    if group[1] == bp4:
        return True
    else:
        return False

# Generated at 2022-06-12 08:40:16.743049
# Unit test for method __iter__ of class BlueprintGroup
def test_BlueprintGroup___iter__():
    """
    Test for method __iter__ of class BlueprintGroup
    """
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    group = Blueprint.group(bp1, bp2)
    group_bprint_iterator = group.__iter__()

    assert next(group_bprint_iterator) == bp1
    assert next(group_bprint_iterator) == bp2



# Generated at 2022-06-12 08:40:26.429478
# Unit test for method __getitem__ of class BlueprintGroup
def test_BlueprintGroup___getitem__():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bp3)
    bpg.append(bp4)

    assert bpg[0] == bp1
    assert bpg[1] == bp2
    assert bpg[3] == bp4


# Generated at 2022-06-12 08:40:35.609798
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    assert hasattr(BlueprintGroup, 'middleware')
    assert callable(BlueprintGroup.middleware)

    # Setup for testing
    app = sanic.Sanic(__name__)
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:40:38.842682
# Unit test for method __len__ of class BlueprintGroup
def test_BlueprintGroup___len__():
    # BlueprintGroup.__len__
    from sanic import Blueprint
    b = Blueprint("test_bp", url_prefix="/test")
    bg = BlueprintGroup()
    bg.append(b)
    assert len(bg) == 1
    assert bg.__len__() == 1


# Generated at 2022-06-12 08:40:44.912104
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    # Setup Test
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(url_prefix="/api/v1")
    # Execution
    bpg.append(bp1)

    # Verification
    assert bpg[0] == bp1

    # Teardown
    del bpg


# Generated at 2022-06-12 08:40:53.916760
# Unit test for method __setitem__ of class BlueprintGroup
def test_BlueprintGroup___setitem__():
    app = sanic.Sanic('test_BlueprintGroup___setitem__')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')
    test_group = BlueprintGroup('/test_group')
    test_group.extend([bp1, bp2])
    test_group.__setitem__(0, bp3)
    assert test_group[0] == bp3
    assert test_group[1] == bp2
    assert len(test_group) == 2
    test_group.__setitem__(1, bp4)

# Generated at 2022-06-12 08:41:02.356585
# Unit test for method insert of class BlueprintGroup
def test_BlueprintGroup_insert():
    blueprint = Blueprint('test_group', url_prefix='/bp_group')

    @blueprint.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @blueprint.route('/')
    async def bp1_route(request):
        return text('bp1')

    bp_group = BlueprintGroup(url_prefix='/prefix')
    bp_group.insert(0, blueprint)

    app = Sanic('test_BlueprintGroup_insert')
    app.blueprint(bp_group)

    _, response = app.test_client.get('/prefix/')
    assert response.text == 'bp1'

    _, response = app.test_client.get('/prefix/abc')