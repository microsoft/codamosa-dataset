

# Generated at 2022-06-12 08:31:03.938782
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass

# Generated at 2022-06-12 08:31:12.280744
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("blueprint-group-middleware")
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bpg = BlueprintGroup(bp1, bp2)

    @bpg.middleware('request')
    async def group_request_middleware(request):
        pass

    @bpg.middleware('response')
    async def group_response_middleware(request, response):
        pass

    blueprint_group_middleware = bp1.middlewares.copy()
    blueprint_group_middleware.update(bp2.middlewares)


# Generated at 2022-06-12 08:31:21.603886
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bpg.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')
        
    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

# Generated at 2022-06-12 08:31:31.608195
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Create class BlueprintGroup
    bpGroup = BlueprintGroup()

    # Create class Blueprint
    bp = Blueprint(__name__)
    # Register BlueprintGroup in Blueprint
    bp.blueprint_group = bpGroup

    # Register Blueprint in BlueprintGroup
    bpGroup.append(bp)

    # Create Decorator which is used to call the middleware function
    @bpGroup.middleware('request')
    async def bp_middleware_function(request):
        pass

    # Create Decorator which is used to call the middleware function
    @bpGroup.middleware('request', 'response')
    async def bp_middleware_function1(request, response):
        pass

    bp_middleware_function("request")
    bp_middleware_function1("request", "response")



# Generated at 2022-06-12 08:31:39.008873
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic.router import RouteExists
    from sanic.response import text
    from sanic.testing import SanicTestClient

    app = Sanic("Test")

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")
    bp3 = Blueprint("bp3", url_prefix="/bp3")
    bp4 = Blueprint("bp4", url_prefix="/bp4")

    bpg = BlueprintGroup(url_prefix="/api")
    bpg.append(bp3)
    bpg.append(bp4)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

   

# Generated at 2022-06-12 08:31:46.922365
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint, BlueprintGroup

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    def test_middleware(request):
        print('applied on Blueprint : bp1 Only')

    bp1_middleware_count, bp2_middleware_count = 5, 7
    bp1_middleware_list = [test_middleware] * bp1_middleware_count
    bp2_middleware_list = [test_middleware] * bp2_middleware_count

    group = Blueprint.group(bp1, bp2)
    group.middleware(test_middleware)

    assert bp1_middleware_count + 1 == len(bp1.middlewares)

# Generated at 2022-06-12 08:31:54.390566
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    grp = BlueprintGroup().append(bp1).append(bp2)
    @grp.middleware("request")
    def test_middleware(request):
        pass
    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1

    bp1 = Blueprint('bp1')
    bp2 = Blueprint('bp2')
    grp = BlueprintGroup().append(bp1).append(bp2)
    @grp.middleware
    def test_middleware(request):
        pass
    assert len(bp1.middlewares["request"]) == 1
    assert len(bp2.middlewares["request"]) == 1

# Generated at 2022-06-12 08:32:02.115946
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class Mock(object):
        pass
    mock = Mock()
    mock.middleware = Mock()
    mock.middleware.side_effect = lambda x, *a, **k: x
    bpg = BlueprintGroup()
    bpg.append(mock)
    @bpg.middleware
    def middleware1(x):
        return x
    assert mock.middleware.called
    @bpg.middleware(a=2)
    def middleware2(x):
        return x
    assert mock.middleware.called

# Generated at 2022-06-12 08:32:09.814949
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Create a Blueprint and apply a middleware function.
    """
    bpg = BlueprintGroup(url_prefix='/api')
    bp1 = Blueprint(url_prefix='/bp1')
    bp2 = Blueprint(url_prefix='/bp2')
    bpg.append(bp1)
    bpg.append(bp2)

    @bpg.middleware()
    def bp_group_middleware(request):
        request['data'] = "from bp_group_middleware"

    assert bp1.middlewares[0] == bp_group_middleware
    assert bp2.middlewares[0] == bp_group_middleware



# Generated at 2022-06-12 08:32:20.680213
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():

    bpm = Blueprint("bpm", url_prefix="/bpm")

    @bpm.middleware("request")
    def bpm_middleware(request):
        pass

    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bp2 = Blueprint("bp2", url_prefix="/bp2")

    bpg1 = BlueprintGroup("/bpg1", strict_slashes=False)
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup("/bpg2", version="1")
    bpg2.append(bpg1)
    bpg2.append(bpm)

    @bpg2.middleware("request")
    def bpg2_middleware(request):
        pass


# Generated at 2022-06-12 08:32:30.180253
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("bp1")
    bp2 = Blueprint("bp2")
    bp3 = Blueprint("bp3")

    bpg1 = BlueprintGroup()
    bpg1.append(bp1)
    bpg1.append(bp2)

    bpg2 = BlueprintGroup()
    bpg2.append(bp3)
    bpg2.append(bpg1)

    @bpg2.middleware("response")
    async def test_bpg2_middleware(request, response):
        print("bpg2 response middleware")

    assert bp1._middleware_stack["response"][0][0] == test_bpg2_middleware
    assert len(bp1._middleware_stack["response"]) == 1

# Generated at 2022-06-12 08:32:32.777346
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware('request')
    def middleware(request):
        print('middleware')


# Generated at 2022-06-12 08:32:43.453357
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # Required imports
    import pytest
    from sanic.blueprints import Blueprint
    from sanic.response import text, html

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    # Create a dummy app
    app = sanic.Sanic()
    app.blueprint(bpg)

    @bp1.route('/')
    async def bp1_route(request, var):
        return text(var)

    @bp2.route('/<var:int>')
    async def bp2_route(request, var):
        return html(f"{var}")

    # Validate only Blueprint

# Generated at 2022-06-12 08:32:54.144675
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class App(sanic.Sanic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.config.REQUEST_TIMEOUT = 1

    app = App()

    async def bp2_only_middleware(request):
        print("Middleware: bp2")

    class Rv:
        pass

    rv = Rv()
    rv.status = 404
    rv.body = None

    # Create a Blueprint Group
    bpg = BlueprintGroup()

    # Create a BP1 and add it to the Blueprint Group
    bp1 = Blueprint("bp1", url_prefix="/bp1")
    bpg.append(bp1)

    # Create a BP2 and add it to the Blueprint Group

# Generated at 2022-06-12 08:33:04.601312
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic("test_BlueprintGroup_middleware")

    bp1 = Blueprint("bp1", url_prefix="bp1")
    bp2 = Blueprint("bp2", url_prefix="bp2")

    bpg = BlueprintGroup("bpg", url_prefix="api")

    @bp1.middleware("request")
    async def bp1_middleware(request):
        print("bp1")

    @bp2.middleware("request")
    async def bp2_middleware(request):
        print("bp2")

    @bpg.middleware("request")
    async def bpg_middleware(request):
        print("bpg")


# Generated at 2022-06-12 08:33:07.445853
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    group = BlueprintGroup()

    @group.middleware
    async def dummmy_middleware(request):
        pass

# Generated at 2022-06-12 08:33:17.302584
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bg = BlueprintGroup()

    # blueprint as functions
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bg.extend((bp1, bp2))

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    # blueprint as inner blueprint
    bp3 = Blueprint('bp3', url_prefix='/bp3')
    b

# Generated at 2022-06-12 08:33:25.712526
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint(url_prefix="/bp1")
    bp2 = sanic.Blueprint(url_prefix="/bp2")
    bp3 = sanic.Blueprint(url_prefix="/bp3")

    group = BlueprintGroup(url_prefix="/api", version="v1")
    group.append(bp1)
    group.append(bp2)
    group.append(bp3)

    @group.middleware
    def middleware(request):
        pass

    for bp in group.blueprints:
        assert bp.middleware_stack[0] == middleware



# Generated at 2022-06-12 08:33:31.298420
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware('request')
    async def group_middleware_1(request):
        print('common middleware applied for both bp1 and bp2')

    @BlueprintGroup.middleware('request', 'response')
    async def group_middleware_2(request, response):
        print('executing the request response middleware')

    # Register Blueprint group under the app
    pass

# Generated at 2022-06-12 08:33:32.358467
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    pass


# Generated at 2022-06-12 08:33:45.402744
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(url_prefix="/api", version="v1")

    bpg.append(bp1)
    bpg.append(bp2)

    bpg2 = BlueprintGroup(url_prefix="/api", version="v1")

    bpg2.append(bp3)
    bpg2.append(bp4)

    bpg.append(bpg2)


# Generated at 2022-06-12 08:33:54.923688
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg2 = BlueprintGroup(bp4, url_prefix="/api", version="v1")

    bpg = BlueprintGroup(bp3, bpg2, url_prefix="/api", version="v2")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)


# Generated at 2022-06-12 08:34:02.421840
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.request import Request

    def func():
        pass
    app = sanic.Sanic()
    bp = Blueprint('test')
    bpg = BlueprintGroup()
    bpg.append(bp)
    bpg.middleware(func)
    func()
    assert app.request_middleware == [func]
    assert bp.request_middleware == [func]
    assert bpg.middleware(func) == None



# Generated at 2022-06-12 08:34:10.942196
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg = BlueprintGroup(url_prefix="/api", version="v1", strict_slashes=False)
    bpg2 = BlueprintGroup(url_prefix="/api/v2", version=2, strict_slashes=True)

    bpg.append(bp1)
    bpg.append(bp2)
    bpg.append(bpg2)

# Generated at 2022-06-12 08:34:20.219545
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(app_name="test")

    bp1 = Blueprint('bp1', url_prefix='/bp1', version="v1")
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on blueprint : bp2 Only')

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on blueprint : bp1 Only')

    @bpg.middleware('request')
    async def bp1_middleware(request):
        print('bp1 middleware')

# Generated at 2022-06-12 08:34:31.367470
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')

    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg = BlueprintGroup(bp1, bp2)

    @bp1.middleware('response')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:39.328525
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.expose("/")
    def handler(request):
        return text("OK")

    app = sanic.Sanic('test_app')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp3')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')


# Generated at 2022-06-12 08:34:45.843908
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bpGroup = BlueprintGroup()
    mock_fn = MagicMock()
    mock_fn.__name__ = "test_middleware"
    bpGroup.middleware(mock_fn, 'request')
    mock_fn.assert_not_called()
    bpGroup.append(Blueprint('test'))
    bpGroup.middleware(mock_fn, 'request')
    mock_fn.assert_called_once()



# Generated at 2022-06-12 08:34:56.494953
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit test implementation to verify the implementation of the
    BlueprintGroup.middleware method with nested Blueprint groups.
    """

    class TestApp(sanic.Sanic):
        def __init__(self, *args, **kwargs):
            super(TestApp, self).__init__(*args, **kwargs)
            self._middleware_registry = {}

        @property
        def middleware_registry(self):
            return self._middleware_registry

        def add_middleware(self, name, middleware):
            """
            Add middleware for a specific name in the application context
            """
            self._middleware_registry[name] = middleware

        def apply_middleware_for(self, name, *args, **kwargs):
            """
            Apply middleware on fly
            """

# Generated at 2022-06-12 08:35:01.001103
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @BlueprintGroup.middleware("request")
    def bluprint_middleware(request):
        print("middleware applied on Blueprint")

    assert bluprint_middleware.__name__ == "bluprint_middleware"
    assert bluprint_middleware.__doc__ is None

# Generated at 2022-06-12 08:35:17.194715
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @bp1.route('/im')
    async def bp1_route(request):
        return text('bp1')


# Generated at 2022-06-12 08:35:25.743319
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def bp1_only_middleware(request):
        request['test'] = 'test'

    @bp1.middleware('request')
    async def bp1_middleware(request):
        assert request.get('test') == 'test'


# Generated at 2022-06-12 08:35:32.555957
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    # create a blueprint group
    group = BlueprintGroup()
    # create a blueprint and add it to the group
    bp = Blueprint('test')
    group.append(bp)
    # create a function that will be registered as middleware
    async def middleware_func(request):
        request['group-middleware'] = True
    # call the middleware method in order to register the middleware
    group.middleware(middleware_func)
    # assert that the middleware has been successfully registered
    assert bp.middlewares['request'][0] == middleware_func


# Generated at 2022-06-12 08:35:40.410530
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    
    bp3 = Blueprint('bp3', url_prefix='/bp4')
    bp4 = Blueprint('bp4', url_prefix='/bp4')

    bp5 = Blueprint('bp5', url_prefix='/bp5')
    bp6 = Blueprint('bp6', url_prefix='/bp6')

    bpg1 = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")
    bpg2 = BlueprintGroup(bp5, bp6, url_prefix="/api", version="v1")


# Generated at 2022-06-12 08:35:48.244612
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    @sanic.Blueprint.middleware('request')
    async def bp1_only_middleware(request):
        print('applied on Blueprint : bp1 Only')

    @sanic.Blueprint.middleware('request')
    async def bp2_only_middleware(request):
        print('applied on Blueprint : bp2 Only')

    @BlueprintGroup.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bp1.middleware(bp1_only_middleware)
    bp2.middleware(bp2_only_middleware)



# Generated at 2022-06-12 08:35:57.311256
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2, url_prefix='/test')

    trace = []

    @bp1.middleware('request')
    async def bp1_middleware(request):
        trace.append(1)

    @bp2.middleware('request')
    async def bp2_middleware(request):
        trace.append(2)

    # Apply a middleware for both Blueprints
    @bpg.middleware('request')
    async def bpg_middleware(request):
        trace.append(3)


# Generated at 2022-06-12 08:36:06.296114
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    class request:
        pass
    class response:
        pass

    @asyncio.coroutine
    def test_handler(request, arg1, arg2=None):
        return response

    app = sanic.Sanic('test_BlueprintGroup_middleware')
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup('/api')
    bpg.append(bp1)
    bpg.append(bp2)

    @bp1.route('/one')
    @bp2.route('/two')
    async def test_handler(request):
        return response

    @bpg.middleware('request')
    async def test_middleware(request):
        request.test_middleware

# Generated at 2022-06-12 08:36:11.390462
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint_group = BlueprintGroup()
    blueprint_group.middleware(str)(str)
    blueprint_group.blueprints = [
        Blueprint(name="test_bp1"),
        Blueprint(name="test_bp2")
    ]

    for blueprint in blueprint_group.blueprints:
        assert len(blueprint.middlewares) == 1



# Generated at 2022-06-12 08:36:22.475094
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    """
    Unit Test for middleware method of class BlueprintGroup
    """
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    group = Blueprint.group(bp1, bp2)

    @group.middleware('request')
    async def group_middleware(request):
        assert True

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        assert True

    @bp2.middleware('request')
    async def bp2_only_middleware(request):
        assert True

    app = sanic.Sanic()
    app.blueprint(group)



# Generated at 2022-06-12 08:36:29.588150
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bg = BlueprintGroup()
    bg.append(Blueprint("BP1"))
    bg.append(Blueprint("BP2"))
    bg.append(Blueprint("BP3"))

    @bg.middleware()
    async def mw(request):
        pass

    assert len(bg.blueprints[0].middleware) == 1
    assert len(bg.blueprints[1].middleware) == 1
    assert len(bg.blueprints[2].middleware) == 1

    @bg.middleware("request")
    async def rmw(request):
        pass

    assert len(bg.blueprints[0].request_middleware) == 1
    assert len(bg.blueprints[1].request_middleware) == 1
    assert len(bg.blueprints[2].request_middleware) == 1


# Generated at 2022-06-12 08:36:47.025045
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = sanic.Blueprint('bp1', url_prefix='/bp1')
    bp2 = sanic.Blueprint('bp2', url_prefix='/bp2')
    bp3 = sanic.Blueprint('bp3', url_prefix='/bp3')
    bp4 = sanic.Blueprint('bp4', url_prefix='/bp4')

    bpg = BlueprintGroup(bp3, bp4, url_prefix="/api", version="v1")

    @bp1.middleware('request')
    async def bp1_only_middleware(request):
        pass

    @bp1.route('/')
    async def bp1_route(request):
        pass


# Generated at 2022-06-12 08:36:57.917776
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup(bp1, bp2)
    @bp1.middleware('response')
    def bp1_middleware(request, response):
        pass
    @bp2.middleware('request')
    def bp2_middleware(request):
        pass
    @bpg.middleware('request')
    def bpg_middleware(request):
        pass
    assert bp1_middleware in bpg.blueprints[0].middlewares['response']
    assert bp2_middleware in bpg.blueprints[1].middlewares['request']
    assert bpg_middleware in bpg.blueprints[0].middlewares

# Generated at 2022-06-12 08:37:08.423210
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)
    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')

    bpg = BlueprintGroup(bp1, bp2, url_prefix="/api", version="v1")

    @bp1.route('/')
    async def bp1_route(request):
        return text('bp1')

    @bp2.route('/<param>')
    async def bp2_route(request, param):
        return text(param)

    @bpg.middleware('request')
    async def group_middleware(request):
        print('common middleware applied for both bp1 and bp2')

    # Register Blueprint group under the app

# Generated at 2022-06-12 08:37:18.555216
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic.response import text
    app = sanic.Sanic("Test")

    bp1 = Blueprint("bp1", url_prefix="/test")
    bp2 = Blueprint("bp2", url_prefix="/test")

    @bp1.route("/test")
    def bp_test(request):
        return text("bp1")

    @bp2.route("/test")
    def bp_test(request):
        return text("bp2")

    bp_group = BlueprintGroup("/api", "v1")
    bp_group.append(bp1)
    bp_group.append(bp2)


# Generated at 2022-06-12 08:37:24.077293
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint('bp', url_prefix='/bp')
    blueprint_group = BlueprintGroup(blueprint)

    @blueprint_group.middleware('request')
    async def bp_only_middleware(request):
        print('applied on Blueprint Group : bp_only_middleware')

# Generated at 2022-06-12 08:37:29.233599
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic()
    bp_group = BlueprintGroup()
    bp_group.append(Blueprint("test", url_prefix="/test"))
    bp_group.append(Blueprint("test2", url_prefix="/test2"))
    test_fn = lambda x: 2
    bp_group.middleware(test_fn)
    assert all([bp.middlewares[0] == test_fn for bp in bp_group.blueprints])
    bp_group = BlueprintGroup()
    bp_group.append(Blueprint("test", url_prefix="/test"))
    bp_group.append(Blueprint("test2", url_prefix="/test2"))
    bp_group.middleware(test_fn, args=1, kwargs=2)

# Generated at 2022-06-12 08:37:38.324580
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    blueprint = Blueprint('test')
    blueprint_group = BlueprintGroup()
    blueprint_group.append(blueprint)

    @blueprint_group.middleware('request')
    async def test_middleware(request):
        request['test'] = 'test'

    @blueprint.route('/')
    async def test_view(request):
        return text('OK')

    app = Sanic('test_BlueprintGroup_middleware')
    app.blueprint(blueprint_group)

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text == 'OK'
    assert request['test'] == 'test'

# Generated at 2022-06-12 08:37:49.404546
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    app = sanic.Sanic(__name__)

    # Create blueprints
    p1 = Blueprint("p1", url_prefix="/p1")
    p2 = Blueprint("p2", url_prefix="/p2")

    # Create blueprint groups
    g1 = BlueprintGroup()
    g1.append(p1)
    g1.append(p2)

    # Create a blueprint group under blueprint group
    g2 = BlueprintGroup()
    g2.append(g1)

    @g2.middleware('request')
    async def g1_middleware_function(request):
        request['middleware'] = 'applied'
        assert request['middleware'] == 'applied'

    # Register blueprint groups
    app.blueprint(g2)

# Generated at 2022-06-12 08:37:58.766427
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    bp1 = Blueprint("test", url_prefix="/test1")
    bp2 = Blueprint("test", url_prefix="/test2")

    bpg = BlueprintGroup()
    bpg.append(bp1)
    bpg.append(bp2)

    assert bpg.middleware(lambda request: None) is not None
    assert bpg.middleware(lambda request: None)(lambda request: None) is not None
    assert bpg.middleware(lambda request: None)(lambda request: None)(
        lambda request: None
    ) is not None
    assert bpg.middleware(lambda request: None)(lambda request: None)(
        lambda request: None
    )(lambda request: None) is not None



# Generated at 2022-06-12 08:38:09.096778
# Unit test for method middleware of class BlueprintGroup
def test_BlueprintGroup_middleware():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import BaseHTTPResponse
    from sanic.views import HTTPMethodView

    bp1 = Blueprint('bp1', url_prefix='/bp1')
    bp2 = Blueprint('bp2', url_prefix='/bp2')
    bpg = BlueprintGroup()

    bpg.append(bp1)
    bpg.append(bp2)

    # Test for Middleware without any extension arguments
    @bpg.middleware
    async def group_middleware(request: Request) -> BaseHTTPResponse:
        return text('common middleware applied for both bp1 and bp2')

    # Test for Middleware with extension arguments